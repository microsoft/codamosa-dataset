

# Generated at 2022-06-24 10:12:35.213137
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from .std import TqdmDefaultWriteLock
    from .utils import LOCK_FLAGS

    import itertools
    import time
    import threading
    t = tqdm_gui(itertools.repeat(1), total=2)
    time.sleep(0.1)
    assert t.last_print_n == 0
    assert len(t.xdata) > 0
    t.update(2)
    assert t.last_print_t < time.perf_counter()  # just sanity check
    assert len(t.xdata) == 2

    # Try with lock

# Generated at 2022-06-24 10:12:47.788622
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from collections import deque
    import matplotlib.pyplot as plt
    from time import time

    total = 10
    n = 0
    cur_t = time()
    elapsed = cur_t - cur_t
    delta_it = n - n
    # last_time = time()
    delta_t = cur_t - cur_t

    # Inline due to multiple calls
    total = total
    xdata = deque([])
    ydata = deque([])
    zdata = deque([])
    fig, ax = plt.subplots(figsize=(6, 2.2))
    line1, = ax.plot(xdata, ydata, color='b')
    line2, = ax.plot(xdata, zdata, color='k')

# Generated at 2022-06-24 10:12:57.798294
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    try:
        tqdm
    except NameError:
        from .tqdm import tqdm

    from sys import executable
    from warnings import filterwarnings
    from .utils import _range

    # Ignore the TqdmExperimentalWarning when running the unit tests
    filterwarnings("ignore", category=TqdmExperimentalWarning)

    with tqdm_gui(total=100, file=open(os.devnull, "w")) as pbar:
        for i in _range(100):
            pbar.update()
    pbar.close()
    with tqdm_gui(total=100, file=open(os.devnull, "w")) as pbar:
        for i in _range(100):
            pbar.update()
    pbar.close()

    # test auto close

# Generated at 2022-06-24 10:12:59.665807
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    n = 5
    DISPLAY = tqdm_gui(total=n, leave=True).display
    DISPLAY()
    DISPLAY()
    DISPLAY()
    DISPLAY()
    DISPLAY()

# Generated at 2022-06-24 10:13:04.637476
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    """Unit test for function tgrange"""
    with tgrange(5) as t:
        for i in t:
            assert i == t.n - 1

# Generated at 2022-06-24 10:13:11.185980
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time
    from .utils import FormatCustomText
    t = tqdm_gui(total=10, unit_scale=True)
    dx = 0.1
    labels = ["first", "second"]
    with t.disable_tqdm():  # avoid spam by tqdm
        for i in range(10):
            t.set_postfix(FormatCustomText(
                "custom", labels[i % 2], i / 10.0, i / 10))
            t.update()
            time.sleep(dx)
        t.close()

# Generated at 2022-06-24 10:13:14.956282
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    t = tqdm_gui(total=5)
    for i in range(5):
        t.update()
        t.display()

# Generated at 2022-06-24 10:13:26.681358
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib.pyplot as plt
    import time

    with tqdm_gui(total=1) as pbar:
        assert isinstance(pbar, std_tqdm)
        assert isinstance(pbar, tqdm_gui)
        assert plt.isinteractive()
        assert pbar.axis.get_xlabel() == "percent"
        assert pbar.axis.get_ylabel() == "it/s"

        pbar.update(1)
        time.sleep(1)  # Ensure mininterval has passed
        assert pbar.total == 1
        assert pbar.n == 1
        assert len(pbar.xdata) == 1
        assert len(pbar.ydata) == 1
        assert len(pbar.zdata) == 1

# Generated at 2022-06-24 10:13:30.651393
# Unit test for function tgrange
def test_tgrange():
    from .std import tqdm
    for _ in tgrange(4):
        for _ in tqdm(tgrange(4), leave=False):  # works with nested tqdm!
            pass
        pass

# Generated at 2022-06-24 10:13:37.272696
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """Test the GUI progress bar"""
    import time
    with tqdm_gui(total=80, leave=False) as t:  # pragma: no cover
        for i in t:
            time.sleep(0.016)

if __name__ == '__main__':  # pragma: no cover
    tqdm_gui()
    tqdm_gui(total=80, leave=False)
    tqdm_gui(total=100, leave=True)

# Generated at 2022-06-24 10:13:46.520084
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    l = tgrange(1000)
    for _ in l:
        pass
    l.close()


if __name__ == '__main__':  # pragma: no cover
    from time import sleep
    for i in trange(10, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=False):
            for k in trange(100, desc='3nd loop'):
                s = i + j + k
                sleep(0.01)
    test_tgrange()

# Generated at 2022-06-24 10:13:49.924024
# Unit test for function tgrange
def test_tgrange():
    for i in tgrange(3):
        assert i < 3

# Generated at 2022-06-24 10:13:56.493616
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from datetime import datetime as dt
    with tqdm_gui(total=1000, desc="testing tqdm.gui()") as bar:
        for i in _range(1000):
            bar.update()
            sleep(0.01)


if __name__ == "__main__":
    # Unit test for constructor of class tqdm_gui
    test_tqdm_gui()

# Generated at 2022-06-24 10:14:01.647427
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import gc
    with tqdm(total=1) as pbar:
        gc.collect()
        # there should be no tqdm_gui instances
        assert len(pbar._instances) == 0

        # if we call close, _instances should be removed
        pbar.close()
        assert len(pbar._instances) == 0

        # the same should apply after calling the destructor
        del pbar
        gc.collect()
        assert len(pbar._instances) == 0

# Generated at 2022-06-24 10:14:12.547339
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Test tqdm_gui.clear on a simple use case.
    """
    import time
    try:
        # Avoid race condition in closing the figure
        _ = tqdm_gui(range(100), position=0)
        for _ in tqdm_gui(range(100), position=1):
            time.sleep(0.01)
    except Exception:
        pass
    finally:
        tqdm_gui.clear(1)



# Generated at 2022-06-24 10:14:22.046649
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    import sys
    import os

    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO

    t = tqdm(total=1000)
    assert "tqdm" in plt.get_backend()
    assert plt.isinteractive(), plt.get_backend()
    assert "tqdm" in plt.get_backend(), plt.get_backend()
    t.close()
    assert "module" == plt.get_backend()

    # simulate what happens when run within jupyter notebook
    t = tqdm(total=1000)
    saved_stdout = sys.stdout
    sys.stdout = StringIO()

# Generated at 2022-06-24 10:14:27.221519
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # pylint: disable=protected-access
    tgr = tgrange(10)
    tgr.display()
    tgr.clear()
    assert tgr.xdata == []
    assert tgr.ydata == []
    assert tgr.zdata == []
    tgr.close()

# Generated at 2022-06-24 10:14:33.247443
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    with tqdm(total=10000, leave=False) as t:
        for i in _range(10000):
            sleep(0.005)
            t.set_description("Testing...")
            t.update(1)


if __name__ == "__main__":  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-24 10:14:43.694852
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    """Unit test for method clear of class tqdm_gui"""
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    assert not plt.isinteractive()
    with tqdm(total=10,
              disable=True,
              leave=True,
              gui=True,
              unit_scale=False) as t:
        toolbar = mpl.rcParams['toolbar']
        wasion = plt.isinteractive()
        try:
            # Remember if external environment is interactive
            t.clear()
        except (AttributeError, NotImplementedError):
            print("tqdm_gui.clear() is not implemented")
        finally:
            # Remember if external environment is interactive
            mpl.rcParams['toolbar'] = toolbar
            # Return

# Generated at 2022-06-24 10:14:46.526989
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Test tqdm_gui.close"""
    if tqdm_gui._instances:
        for instance in tqdm_gui._instances[:]:
            instance.close()
            assert instance.disable

# Generated at 2022-06-24 10:14:55.217864
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    import time
    t_gui = tqdm_gui(total=5, leave=True, disable=False)
    t_gui.close()
    assert plt.isinteractive() is False
    t_gui.plt.ion()
    assert plt.isinteractive() is True

    # Unit test for method display of class tqdm_gui
    t_gui.display()
    assert t_gui.last_print_t is not None
    assert t_gui.last_print_n is not None
    t_gui.last_print_n = 0
    t_gui.last_print_t = time.time() - 0.2
    assert t_gui.last_print_t is not None
    assert t_gui.last_print_n is not None



# Generated at 2022-06-24 10:15:05.265127
# Unit test for function tgrange
def test_tgrange():
    import matplotlib.pyplot as plt
    import time
    plt.ion()
    for i in tgrange(100):
        time.sleep(0.01)
    for i in tgrange(10, desc="test_tgrange"):
        time.sleep(0.01)
    for i in tgrange(10, 0, -1, desc="test_tgrange"):
        time.sleep(0.01)
    for i in tgrange(100, unit="test_tgrange"):
        time.sleep(0.01)
    for i in tgrange(100, unit_scale=True):
        time.sleep(0.01)
    for i in tgrange(100, mininterval=0.2):
        time.sleep(0.01)

# Generated at 2022-06-24 10:15:12.139227
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        import matplotlib.pyplot as plt
        with tqdm_gui(total=10) as t:
            for i in t:
                pass
        assert t.mpl.rcParams['toolbar'] == 'toolbar2'
        assert t.wasion == plt.isinteractive()
    finally:
        # Restore initial settings
        t.mpl.rcParams['toolbar'] = t.toolbar
        if not t.wasion:
            t.plt.ioff()

# Generated at 2022-06-24 10:15:13.386068
# Unit test for function tgrange
def test_tgrange():
    for i in tgrange(4):
        assert i in _range(4)

# Generated at 2022-06-24 10:15:19.196733
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from collections import deque

    from .std import tqdm as std_tqdm
    from .gui import tqdm_gui

    times = deque([-1])
    t = tqdm_gui(total=5)
    times.append(t._time())
    _test_tqdm_gui_display_add(t, times, 1)
    _test_tqdm_gui_display_add(t, times, 2)
    _test_tqdm_gui_display_add(t, times, 3)
    t.close()

    t = tqdm_gui(total=5)
    times.append(t._time())
    _test_tqdm_gui_display_add(t, times, 1)
    _test_tqdm_gui_display

# Generated at 2022-06-24 10:15:25.244420
# Unit test for function tgrange
def test_tgrange():
    import time

    itr = tgrange(10)
    for i in itr:
        time.sleep(0.1)
        if i == 5:
            itr.set_description('testing')
    # TODO: remove when the code is stable
    return tgrange

# Generated at 2022-06-24 10:15:32.929179
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from unittest.case import TestCase
    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO

    fd = StringIO()
    pbar = tqdm_gui(iterable=_range(0, 10), file=fd)
    for _ in pbar:
        pass
    pbar.close()
    assert fd.getvalue() == ""
    fd.seek(0)
    # call clear
    pbar.clear()
    assert fd.getvalue() == ""



# Generated at 2022-06-24 10:15:35.630991
# Unit test for function tgrange
def test_tgrange():
    l = []
    for _ in tgrange(4):
        l.append(1)
        time.sleep(.5)
    assert l == [1] * 4



# Generated at 2022-06-24 10:15:39.149958
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Test that `clear()` doesn't crash
    """
    t = tqdm_gui(range(10))
    t.clear()

# Generated at 2022-06-24 10:15:41.774880
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # test_tqdm_gui_close : code coverage #931
    with tqdm(total=1) as t:
        pass
    t.close()


# Generated at 2022-06-24 10:15:43.183812
# Unit test for function tgrange
def test_tgrange():
    for i in tgrange(10, 50, 25):
        pass



# Generated at 2022-06-24 10:15:53.133574
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .std import tqdm
    import matplotlib.pyplot as plt

    t = tqdm(total=2)
    t.close()
    assert not len(t._instances), "tqdm not removed from tqdm._instances"

    # Simulate interactive mode
    plt.ion()
    t = tqdm(total=2)
    t.close()
    assert not plt.isinteractive(), "tqdm didn't restore tqdm.ioff()."

    # Simulate non-interactive mode
    plt.ioff()
    t = tqdm(total=2)
    t.close()
    assert not plt.isinteractive(), "tqdm didn't restore tqdm.ioff()."

    # Simulate toolbar mode
    import matplotlib as mpl

# Generated at 2022-06-24 10:15:54.113816
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    t = tqdm_gui()
    t.clear()

# Generated at 2022-06-24 10:16:02.893450
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    with tqdm(total=None, miniters=1, mininterval=0.5,
              desc='Testing tqdm_gui', leave=True) as t:
        t.update()
        t.close()

if __name__ == "__main__":
    from time import sleep
    with trange(9, desc='1st loop') as t:
        for i in t:
            sleep(0.01)
    with trange(9, desc='2nd loop') as t:
        for i in t:
            sleep(0.01)
    with trange(9, desc='3rd loop') as t:
        for i in t:
            sleep(0.01)
    test_tqdm_gui_close()

# Generated at 2022-06-24 10:16:13.136905
# Unit test for function tgrange
def test_tgrange():
    import sys
    from .std import tqdm
    from .utils import format_sizeof

    # Python2.7, 3.2, and 3.3 do not support "yield from"
    # so the tests for them are a bit more limited
    if sys.version_info[:2] == (2, 7):
        # only test the initializer
        ti = tgrange(100)
        assert ti == tqdm(xrange(100), gui=True)
    elif sys.version_info[:2] == (3, 2):
        # only test the initializer
        ti = tgrange(100)
        assert ti == tqdm(range(100), gui=True)
    elif sys.version_info[:2] == (3, 3):
        # only test the initializer
        ti = t

# Generated at 2022-06-24 10:16:17.256638
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    t = tqdm_gui(total=10, leave=True)
    for i in _range(10):
        t.update()
        time.sleep(0.05)


if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-24 10:16:18.891787
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    for x in trange(100, desc="tgrange test"):
        pass

# Generated at 2022-06-24 10:16:21.563002
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .gui import tqdm_gui as tqdm
    from .gui import trange
    from time import sleep
    for i in tqdm(trange(100)):
        sleep(0.01)
        if i == 50:
            break

# Generated at 2022-06-24 10:16:23.931469
# Unit test for function tgrange
def test_tgrange():
    tgr = tgrange(10)
    for _ in tgr:
        pass
    assert tgr.n == 10

# Generated at 2022-06-24 10:16:35.200855
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import numpy as np
    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'
    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()

    def _close():
        mpl.rcParams['toolbar'] = toolbar
        if not wasion:
            plt.ioff()

    fig, ax = plt.subplots(figsize=(9, 2.2))
    # self.fig.subplots_adjust(bottom=0.2)
    total = 10
    xdata = []
    ydata = []
    zdata = []
    line1,

# Generated at 2022-06-24 10:16:46.339603
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import os
    import time
    from .utils import _decr_instances, _decr_instances_after

    with _decr_instances_after(tqdm_gui._instances):
        @tqdm_gui
        def foo():
            pass

        @tqdm_gui
        def bar():
            pass

        @tqdm_gui(disable=True)
        def baz():
            pass

        assert foo.disable is False
        assert bar.disable is False
        assert baz.disable is True

        @_decr_instances(tqdm_gui._instances)
        def test_close_all():
            """Test if close_all method on tqdm_gui objects works."""
            # n = 100
            # t = trange(n, leave=True)
            # #

# Generated at 2022-06-24 10:16:55.226653
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from .utils import _time
    from .std import format_interval
    for disable in False, True:
        for unit_scale in False, True:
            for desc in None, "description":
                for mininterval in [0, 0.1, 1, 10]:
                    for miniters in [1, 10]:
                        for dynamic_ncols in [False, True]:
                            t = tqdm_gui(desc=desc, mininterval=mininterval,
                                         miniters=miniters,
                                         dynamic_ncols=dynamic_ncols,
                                         disable=disable,
                                         unit_scale=unit_scale)

                            assert hasattr(t, 'total')
                            assert hasattr(t, 'dynamic_ncols')

# Generated at 2022-06-24 10:17:05.760848
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    from contextlib import contextmanager

    @contextmanager
    def matplotlib_ctx():
        import matplotlib as mpl
        import matplotlib.pyplot as plt
        # Remember if external environment uses toolbars
        toolbar = mpl.rcParams['toolbar']
        mpl.rcParams['toolbar'] = 'None'
        # Remember if external environment is interactive
        wasion = plt.isinteractive()
        plt.ion()
        try:
            yield
        finally:
            # Restore toolbars
            mpl.rcParams['toolbar'] = toolbar
            # Return to non-interactive mode
            if not wasion:
                plt.ioff()
        # XXX: This is a hack to suppress matplotlib warnings
        # see https

# Generated at 2022-06-24 10:17:16.910784
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .std import TqdmTypeError, TqdmKeyError, TqdmDeprecationWarning

    import matplotlib as mpl
    import matplotlib.pyplot as plt

    # Set interactive mode for Matplotlib
    plt.ion()

    # Create a figure
    fig, ax = plt.subplots(figsize=(9, 2.2))
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 0.001)

    # Instantiate a tqdm_gui object
    tqdm_obj = tqdm_gui(total=10)
    tqdm_obj.bar_format = "ok"
    tqdm_obj.n = 0

    # Method clear should not fail without an argument
    tqdm_obj.clear()

    # Method

# Generated at 2022-06-24 10:17:18.230181
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    for n in trange(5):
        sleep(1)

# Generated at 2022-06-24 10:17:20.583767
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    # create an instance if tqdm_gui
    t = tqdm_gui(some_iterable)
    # call method clear
    t.clear()

# Generated at 2022-06-24 10:17:31.178762
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # Test if closing the only object deletes the window
    with tqdm_gui(total=1, leave=True) as pbar_1:
        pbar_1.update()

    # Test if closing the only object deletes the window
    with tqdm_gui(total=1, leave=True) as pbar_1:
        pbar_1.update()

    # Test if closing the only object deletes the window
    with tqdm_gui(total=1, leave=True) as pbar_1:
        pbar_1.update()

    # Test if closing the only object deletes the window
    with tqdm_gui(total=1, leave=True) as pbar_1:
        pbar_1.update()

    # Test if closing the only object deletes the window

# Generated at 2022-06-24 10:17:37.736882
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import time
    with tqdm_gui(ascii=True, total=15) as t:
        for i in range(10):
            t.update(1)
            time.sleep(0.1)
        t.clear()
        for i in range(5):
            t.update(1)
            time.sleep(0.1)
    assert t.n == 15
    assert t.smoothing == 0

# Generated at 2022-06-24 10:17:41.326068
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from nose.tools import assert_equal
    t = tqdm(range(1))
    t.close()
    assert_equal(hasattr(t, 'ax'), False)

# Generated at 2022-06-24 10:17:49.944955
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from collections import deque
    # Make sure that the return value of method close of class tqdm_gui
    # is the same as the return value of method close of class tqdm
    # Usage example: >>> test_tqdm_gui_close().close()
    test_close = tqdm_gui("Testing tqdm_gui method close")
    x = std_tqdm("Testing tqdm method close")
    test_close.disable = x.disable = False
    test_close._instances = std_tqdm._instances = deque([test_close, x])
    test_close.toolbar = x.toolbar = "None"
    test_close.plt = x.plt = ""
    test_close.mpl = x.mpl = ""

# Generated at 2022-06-24 10:18:01.247720
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import pprint
    # import sys
    import time
    import traceback
    from math import sin
    from io import StringIO
    from subprocess import check_output, CalledProcessError
    class Dummy: pass
    try:
        from matplotlib import pyplot as plt
    except ImportError:
        plt = Dummy()
        plt.pause = Dummy()
    from .tqdm_gui import tqdm_gui
    try:
        from .gui import BACKEND
    except ImportError:
        if plt.__class__.__name__ == 'Dummy':
            print("\n\nGUI support not installed. Skipping display tests.")
            return
        tqdm_gui.display()
        raise
    # code_text = "".join(
    #     traceback.extract_stack()

# Generated at 2022-06-24 10:18:04.874577
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from sys import stderr
    for attr in ('wasion', 'toolbar', 'disable', 'leave', 'ax',
                 'line1', 'line2', 'hspan', 'fig'):
        assert getattr(tqdm(total=5), attr)
    tqdm(total=5).close()
    assert not getattr(tqdm(total=5), attr)


# Generated at 2022-06-24 10:18:07.309343
# Unit test for function tgrange
def test_tgrange():
    with tqdm(tgrange(10)) as t:
        assert not t.disable
        for i in t:
            assert not t.disable
    assert t.disable