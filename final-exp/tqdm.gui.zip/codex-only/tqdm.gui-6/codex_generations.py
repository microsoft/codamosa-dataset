

# Generated at 2022-06-24 10:12:34.426244
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        # pylint: disable=missing-docstring
        # pylint: disable=expression-not-assigned
        import matplotlib
    except ImportError:
        return
    except RuntimeError:
        # already installed in non-interactive environment
        return
    with tqdm_gui(total=10) as t:
        t.clear()

if __name__ == '__main__':  # pragma: no cover
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import time
    from pylab import ion
    ion()
    t = tqdm_gui(total=50)
    for i in range(50):
        t.update()
        time.sleep(0.01)
    t.close()

# Generated at 2022-06-24 10:12:47.658597
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """
    Unit test for method display of class tqdm_gui.

    test_tqdm_gui_display()
    """
    from .std import tqdm as _tqdm
    import matplotlib.pyplot as plt

    plt.ion()  # turn interactive on

    t = _tqdm(total=None, unit='s')
    for _ in t:
        t.display()
        plt.pause(1e-9)

    t = _tqdm(total=None)
    for _ in t:
        t.display()
        plt.pause(1e-9)

# Add a weak test

# Generated at 2022-06-24 10:12:56.971040
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    try:
        from matplotlib.pyplot import figure as figure_m
    except ImportError:
        return  # nothing to test
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch('matplotlib.pyplot.figure') as fig_m:
        fig_m.side_effect = Exception('Boom!')
        try:
            tqdm_gui('Hello, world!')
        except Exception:
            pass
        assert isinstance(fig_m.mock_calls[0][1][0], figure_m), \
            "tqdm_gui instantiation must use matplotlib.pyplot.figure"

# Generated at 2022-06-24 10:12:59.563982
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # check that clear doesn't raise any exception
    with tqdm(total=100, desc='{0}') as pbar:
        pbar.clear()
        sleep(0.02)


# Generated at 2022-06-24 10:13:01.514522
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm(total=10) as pbar:
        for i in tgrange(1, 10):
            pbar.update()

# Generated at 2022-06-24 10:13:09.087676
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from matplotlib import pyplot as plt
    from numpy.random import rand
    from time import sleep

    for i in trange(5, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=False):
            for k in trange(50):
                sleep(0.01)

    for i in trange(100, desc='infinite loop'):
        try:
            _ = rand(200, 200)
            plt.pause(0.001)
        except KeyboardInterrupt:
            break


if __name__ == "__main__":
    test_tqdm_gui_display()

# Generated at 2022-06-24 10:13:11.067007
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from time import sleep
    for i in tqdm_gui(range(4)):
        sleep(.2)
        tqdm.clear()

# Generated at 2022-06-24 10:13:16.849171
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    try:
        t_ = tqdm_gui()
        t_.clear()
    except Exception:
        raise AssertionError()

# Generated at 2022-06-24 10:13:19.801092
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import mock
    t = tgrange(0)
    t.stop = mock.Mock()
    t.close()
    assert t.stop.call_count == 1

# Generated at 2022-06-24 10:13:25.775154
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    # Assert tqdm_gui can be imported and initialized
    std_tqdm(10, disable=True).close()
    tgrange(10, disable=True).close()
    tqdm(10, disable=True).close()

if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-24 10:13:31.033704
# Unit test for function tgrange
def test_tgrange():
    from .std import tqdm
    from time import sleep

    for _ in tgrange(3):
        sleep(0.1)

    for _ in tgrange(3, 5):
        sleep(0.1)

    for _ in tgrange(5, 3, -1):
        sleep(0.1)

# Generated at 2022-06-24 10:13:37.644867
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Test tqdm_gui clear method"""
    import time
    import unittest

    f = tqdm_gui(["test_tqdm_gui_clear"], gui=True)
    time.sleep(0.1)
    f.clear()
    assert f.n == 1, "Failed clearing"
    f.close()
    unittest.TestCase().assertTrue("Test tqdm_gui clear method")

# Generated at 2022-06-24 10:13:42.656583
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no branch
    from time import sleep

    from .gui import tqdm_gui
    from .utils import _range

    with tqdm_gui(_range(0, 100), desc="Loading...", unit="B") as pbar:
        for i in pbar:
            sleep(0.01)
            pbar.update(5)
            pbar.set_description("Processing: %s" % i)
            pbar.set_postfix_str("Estimated: %.1fs" % (pbar.n / pbar.avg))

# Generated at 2022-06-24 10:13:49.287249
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import time

    for n in tqdm_gui(range(int(10e6)), leave=False, ncols=60):
        if n > 2e6:
            time.sleep(0.001)
    tqdm_gui(range(int(10e6))).close()


if __name__ == "__main__":
    test_tqdm_gui_display()

# Generated at 2022-06-24 10:14:00.262619
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    try:
        from matplotlib.pyplot import ion, pause, close
    except ImportError:
        return
    ion()

    t = tqdm_gui(total=100000000, smoothing=0.0)

    # Initial display
    t.display()
    pause(1e-9)
    close()

    # Display recurrence
    t.display()
    t.display()
    t.display()
    pause(1e-9)
    close()

    # Check if recurrence works
    t.display()
    t.display()
    t.display()
    pause(3)

    # Check if recurrence works
    t.display()
    t.display()
    t.display()
    pause(3)
    close()



# Generated at 2022-06-24 10:14:11.613415
# Unit test for function tgrange
def test_tgrange():
    from platform import python_implementation
    if python_implementation() == 'PyPy':  # pragma: no cover
        warn("Gui is too slow on PyPy", TqdmExperimentalWarning, stacklevel=2)
        return

    # Dummy values
    for n in tgrange(12):
        for i in _range(10):
            with tqdm(total=n) as t:
                for j in _range(n):
                    t.update(1)

    # Test live display
    with tqdm(total=10) as t:
        for i in _range(5):
            t.update(1)
            t.refresh()
            sleep(0.2)

    print("\nDONE")


if __name__ == '__main__':
    test_tgrange()

# Generated at 2022-06-24 10:14:21.201692
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # Check mpl version
    import matplotlib as mpl
    if not mpl.rcParams['interactive'] or \
            (mpl.rcParams['toolbar'] != 'None' and
             mpl.rcParams['toolbar'] != 'toolmanager'):
        raise RuntimeError("In order to run the display() test, "
                           "Matplotlib's interactive plotting mode "
                           "must be on and its toolbar hidden")

    from .tqdm import trange
    from time import sleep

    t = trange(100)
    for i in t:
        sleep(0.01)
        t.display()  # DO NOT REMOVE THIS LINE
    assert t.display() is None
    t.close()

if __name__ == '__main__':
    test_tqdm_gui_

# Generated at 2022-06-24 10:14:27.064691
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    t = tqdm_gui(total=100, leave=False)
    for i in t:
        assert t.disable
        break
    return t


if __name__ == "__main__":
    t = test_tqdm_gui()
    t.close()

# Generated at 2022-06-24 10:14:34.449116
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    """
    Unit test for class tqdm_gui
    """
    import matplotlib.pyplot as plt

    with tqdm_gui(total=10) as t:
        for i in _range(10):
            # update progressbar
            t.update(1)

    # display new figure
    if not plt.get_fignums():
        plt.plot([1, 2, 3])
        plt.title("It is a test")
        plt.xlabel("x axis")
        plt.ylabel("y axis")
        plt.show()

# Generated at 2022-06-24 10:14:39.782718
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    for i in trange(4, desc='1st loop', leave=True):
        for j in trange(5, desc='2nd loop', leave=True, unit='it'):
            for k in trange(50, desc='3nd loop', leave=True, unit='it'):
                sleep(0.01)

# Generated at 2022-06-24 10:14:42.387698
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from tqdm.gui import tqdm_gui
    from time import sleep
    for i in tqdm_gui(range(10)):
        sleep(0.1)

# Generated at 2022-06-24 10:14:45.930094
# Unit test for function tgrange
def test_tgrange():
    """Unit test for function tgrange."""
    x = tgrange(100)
    try:
        assert len(x) == 100
        assert isinstance(x, tqdm_gui)
    finally:
        x.close()


# Generated at 2022-06-24 10:14:54.908848
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    try:
        from matplotlib.animation import FuncAnimation
        FuncAnimation
    except ImportError:
        raise ImportError(
            "matplotlib update required (probably to v1.3). Please run `pip "
            "install -U matplotlib`")

    # Hide the plot so it doesn't keep open and delay test suite
    from matplotlib.pyplot import get_backend
    from tempfile import NamedTemporaryFile
    from os import remove

    bak = get_backend()

# Generated at 2022-06-24 10:14:57.841458
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=5, unit="test") as pbar:
        for i in range(5):
            pbar.update(1)
            pbar.clear()
            pbar.display()

# Generated at 2022-06-24 10:15:01.729734
# Unit test for function tgrange
def test_tgrange():
    """Simple unit test for function tgrange"""
    for _ in tgrange(4):
        for _ in tgrange(4):
            for i in tgrange(4, desc="test_tgrange"):
                assert i in range(4)



# Generated at 2022-06-24 10:15:06.809298
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib.pyplot as plt
    from .std import tqdm

    with tqdm_gui(10, desc="test", unit="it", leave=True) as t:
        for i in t:
            t.update(1)
    assert len(plt.get_fignums()) == 1  # check if figure is open


if __name__ == "__main__":  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-24 10:15:17.523476
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from .utils import format_sizeof, _supports_unicode
    from .std import format_interval

    for i in tgrange(25, desc="tgrange desc", ascii=not _supports_unicode):
        pass
    assert i == 24  # range is non-inclusive

    for i in trange(9, desc="trange desc", ascii=not _supports_unicode):
        pass
    assert i == 8  # range is non-inclusive

    for i in tqdm_gui(8, desc="tqdm_gui desc", ascii=not _supports_unicode):
        pass
    assert i == 7  # range is non-inclusive


# Generated at 2022-06-24 10:15:26.323215
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from unittest import TestCase
    with TestCase().subTest('close'):
        import matplotlib
        import matplotlib.pyplot
        old_toolbar = matplotlib.rcParams['toolbar']
        with tqdm_gui(total=10) as pbar:
            matplotlib.rcParams['toolbar'] = 'None'
            pbar.close()
        assert matplotlib.rcParams['toolbar'] == old_toolbar

# Generated at 2022-06-24 10:15:29.836555
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep as time_sleep
    from .gui import tgrange, _decr_instances
    _decr_instances()
    for _ in tgrange(10):
        time_sleep(0.01)

# Generated at 2022-06-24 10:15:33.201454
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm_gui(total=10) as t:
        for i in range(10):
            t.update()


if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-24 10:15:38.134684
# Unit test for function tgrange
def test_tgrange():
    for i in tgrange(5):
        assert i in [0, 1, 2, 3, 4]


if __name__ == "__main__":
    from time import sleep
    for i in tgrange(5):
        sleep(0.5)

# Generated at 2022-06-24 10:15:48.858406
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # region test data
    xdata = [0, 10.02, 20.04]
    ydata = [0.001, 0.002, 0.003]
    zdata = [0.001, 0.002, 0.003]
    ymax = 0.0035
    # endregion

    # region test arguments
    arg1 = xdata
    arg2 = ydata
    arg3 = zdata
    # endregion

    # region test plot
    fig, ax = plt.subplots()
    line1, = ax.plot(arg1, arg2, color='b')
    line2, = ax.plot(arg1, arg3, color='k')
    ax.set_ylim(0, 0.001)
    ax.set_xlim(0, 60)
    ax.invert_xaxis

# Generated at 2022-06-24 10:15:54.481673
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep

    with tqdm_gui(total=10, desc="test") as t:
        for i in range(10):
            t.update(i)
            sleep(0.1)


if __name__ == "__main__":  # pragma: no cover
    test_tqdm_gui()

# Generated at 2022-06-24 10:16:03.971311
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt

    # Check that tqdm_gui closes instantly
    x = tqdm_gui()
    x.close()
    assert not plt.get_fignums()

    # Check that tqdm_gui(leave=True) remains open
    x = tqdm_gui(leave=True)
    x.close()
    assert plt.get_fignums()

    # Check that tqdm_gui(leave=True) closes from explicit display
    x = tqdm_gui(leave=True)
    x.display()
    assert not plt.get_fignums()
    for _ in tqdm_gui(10000):
        pass

    # Check that tqdm_gui(disable=True) does not open anything

# Generated at 2022-06-24 10:16:11.144869
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib as mpl
    import matplotlib.pyplot as plt

    if 'DISPLAY' not in mpl.rcParams:
        mpl.rcParams['backend'] = 'Agg'
    if 'DISPLAY' not in plt.rcParams:
        plt.rcParams['backend'] = 'Agg'
    t = tqdm_gui(10)
    assert t.gui
    try:
        t.n = 0
        assert t.n == 0
    except:
        raise
    t.close()

# Generated at 2022-06-24 10:16:13.098360
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import matplotlib as mpl
    import matplotlib.pyplot as plt

    plt.ion()

    for i in tqdm(range(10)):
        plt.draw()
        plt.clf()
        assert True

# Generated at 2022-06-24 10:16:16.112630
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    # Disabled until GUI can be properly tested
    pass


if __name__ == '__main__':
    set_slower_interval()
    test_tgrange()

# Generated at 2022-06-24 10:16:26.447028
# Unit test for function tgrange
def test_tgrange(): # pragma: no cover
    from sys import version_info
    from time import sleep
    from .gui import trange
    from .gui import trange
    from .gui import tqdm
    from .gui import tqdm_gui

    for n in trange(3, desc='1st loop'):
        for m in tqdm(range(3), desc='2nd loop'):
            if version_info[0] < 3:
                sleep(0.01)
            else:
                sleep(0.05)

    # test iterables
    for i in tqdm([1, 2, 3]):
        sleep(0.01)

    # test int
    for i in tqdm(10):
        sleep(0.01)

    # test kwargs

# Generated at 2022-06-24 10:16:36.937152
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import os
    import sys
    from contextlib import closing
    import time

    with closing(tqdm_gui(total=10)) as pbar:
        for i in _range(10):
            pbar.update()
            time.sleep(0.1)
    # Test with Python 2.7, 3.3 and 3.4 syntax:
    with tqdm_gui(total=10) as pbar:
        for i in _range(10):
            pbar.update()
            time.sleep(0.1)

    time.sleep(0.5)

    with tqdm_gui('test', miniters=2, mininterval=0.01) as pbar:
        pbar.update(5)
        pbar.update(5, now=True)

    time.sleep(0.5)



# Generated at 2022-06-24 10:16:47.636266
# Unit test for function tgrange
def test_tgrange():
    from time import sleep
    from tqdm.py3compat import range

    def getsize(iterable):
        return len(list(iterable))

    assert getsize(tgrange(1)) == 1
    assert getsize(tgrange(100000000)) == 100000000
    assert getsize(tgrange(10, 100, -1)) == getsize(tgrange(10, 100))
    assert getsize(tgrange(100, 10, -1)) == getsize(tgrange(100, 10))
    assert getsize(tgrange(100, 10, 1)) == getsize(tgrange(100, 10))
    assert getsize(tgrange(100, 10, -1)) == getsize(tgrange(100, 10, 1))

# Generated at 2022-06-24 10:16:50.746197
# Unit test for function tgrange
def test_tgrange():
    for i in tgrange(4, leave=False):
        pass

if __name__ == '__main__':
    test_tgrange()

# Generated at 2022-06-24 10:16:56.898659
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Tests :func:`~tqdm.gui.tqdm_gui.clear` method.
    """
    t = tqdm(total=3)
    t.update(2)
    try:
        t.clear()
        assert t.n == 3
    except NotImplementedError:
        pass
    finally:
        t.close()

# Generated at 2022-06-24 10:16:59.689033
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    for i in tqdm_gui(range(1, 41), desc='tqdm_gui_test'):
        sleep(0.01)

# Generated at 2022-06-24 10:17:00.274334
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # TODO: Write unit tests
    pass

# Generated at 2022-06-24 10:17:11.613290
# Unit test for function tgrange
def test_tgrange():
    with tqdm(tgrange(3)) as t:
        for i in t:
            assert i == t.n - 1
    assert t.n == 3
    assert abs(t.avg_rate - 1.0) < 0.01

if __name__ == '__main__':  # pragma: no cover
    from os import getpid
    from random import random
    from time import sleep
    from math import sqrt

    # Run test
    test_tgrange()

    # Test GUI
    try:
        from threading import Thread
        p = Thread(target=test_tgrange)
        p.start()
        p.join()
    except ImportError:
        warn("Cannot test GUI in current Python version. Try Python 2.7 or 3.4+",
             TqdmExperimentalWarning)

# Generated at 2022-06-24 10:17:14.202732
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .utils import _supports_unicode

    _supports_unicode()
    for n in tqdm_gui([1, 2]):
        pass

# Generated at 2022-06-24 10:17:23.590956
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    for __ in tqdm_gui([0, 1, 2, 3, 4]):
        pass
    for __ in tqdm_gui(xrange(10)):
        pass
    tqdm_gui(xrange(5))
    tqdm_gui(5)
    tqdm_gui()
    total = 100
    tqdm_gui(total=total)
    tqdm_gui([0, 1, 2, 3, 4], total=total)
    tqdm_gui(xrange(5), total=total)
    tqdm_gui(total=total)
    tqdm_gui(xrange(5), total=total)
    tqdm_gui(xrange(5), total=total, miniters=total)

# Generated at 2022-06-24 10:17:30.316991
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    For testing tqdm_gui close method.
    """
    mpl = pytest.importorskip('matplotlib')
    mplrc = mpl.rcParams.copy()
    tq = tqdm([1, 2, 3])
    tq.close()
    assert mpl.rcParams == mplrc



# Generated at 2022-06-24 10:17:35.832011
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    with tqdm_gui(total=10) as t:
        for i in t:
            t.set_description("testing")
        assert t.smoothing == 0.3
        t.close()


if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-24 10:17:38.766236
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
  f = tqdm_gui(total=1)
  f.clear()
  f.close()

if __name__ == '__main__':
  test_tqdm_gui_clear()

# Generated at 2022-06-24 10:17:48.350511
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import matplotlib.pyplot as plt
    import matplotlib as mpl

    # Restore toolbars
    mpl.rcParams['toolbar'] = 'None'
    plt.close("all")

    # Test clear
    with tqdm(total=100) as pbar:
        assert plt.fignum_exists(pbar.fig.number)
        pbar.clear()
        assert plt.fignum_exists(pbar.fig.number)
        pbar.close()
        assert not plt.fignum_exists(pbar.fig.number)


test_tqdm_gui_clear()

# Generated at 2022-06-24 10:17:52.072516
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep

    for _ in tqdm(range(10)):
        sleep(0.5)
    for _ in tqdm(range(10)):
        sleep(0.5)
    for _ in trange(10):
        sleep(0.5)

if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-24 10:17:58.366138
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from unittest import TestCase

    class TqdmGuiDisplayTest(TestCase):
        def setUp(self):
            self.t = tqdm_gui()

        def tearDown(self):
            self.t.close()

        def test_init(self):
            """Check that tqdm initializes correctly"""
            self.assertIsNone(self.t.last_print_n)
            self.assertIsNotNone(self.t.start_t)

        def test_display1(self):
            """Check that display() performs as intended"""
            t = self.t
            t.n = 10
            t.last_print_t = 0
            t.last_print_n = 0
    
            t.display()
    
            self.assertIsNotNone(t.last_print_n)


# Generated at 2022-06-24 10:18:02.341795
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import gc
    t = tqdm_gui(total=2)
    t.close()
    assert t.disable == True
    t2 = tqdm_gui(total=2)
    t2.close()
    gc.collect()

# Generated at 2022-06-24 10:18:08.071070
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():  # pragma: no cover
    """
    Test clear() method of tqdm_gui class.
    """
    tbar = tqdm_gui(10)
    tbar.clear()


# Set up a hook to close tqdm_gui when Python exits
# http://blog.dscpl.com.au/2014/01/executing-code-when-python-exits.html
import atexit
atexit.register(tqdm_gui.close)

# Generated at 2022-06-24 10:18:13.723339
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with open('test_tqdm_gui.log', 'w') as f:
        with tqdm_gui(total=10, file=f, leave=True) as pb_dummy:
            pass


if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-24 10:18:24.731242
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    for i in tgrange(4, 25, 10, desc='1st loop'):
        for j in trange(6, desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                k += i
                k -= j
        k = 0
    # Test with disable=True
    for _ in tgrange(4, desc='1st loop', disable=True):
        pass
    # Test postfix
    import time
    for _ in trange(3, desc='1st loop'):
        for j in trange(6, desc='2nd loop'):
            time.sleep(0.1)
            tqdm.write("    inner loop: %d" % j)
    # Test with no tqdm instance in scope

# Generated at 2022-06-24 10:18:31.305182
# Unit test for function tgrange
def test_tgrange():
    with tqdm(tgrange(10), ascii=True) as t:
        for i in t:
            t.set_description('Foobar')
            t.set_postfix(OrderedDict(a='b'))
            t.set_postfix(OrderedDict(c='d'), refresh=False)
            t.set_postfix(OrderedDict(e='f'), refresh=True)
    assert t.n == 10


if __name__ == "__main__":
    r = test_tgrange()

# Generated at 2022-06-24 10:18:33.339386
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .tests.gui_tests import tqdm_gui_close
    tqdm_gui_close()

# Generated at 2022-06-24 10:18:38.533107
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time

    with tqdm_gui(total=10, mininterval=0, miniters=8) as pbar:
        for i in _range(10):
            time.sleep(0.1)
            pbar.update()
        pbar.close()
        time.sleep(0.1)
    # try with bar_format
    with tqdm_gui(total=10, bar_format='{bar}|{n_fmt}/{total_fmt}[{elapsed}<{remaining}]') as pbar:
        for i in _range(10):
            time.sleep(0.1)
            pbar.update()
        pbar.close()
        time.sleep(0.1)
    # try leave

# Generated at 2022-06-24 10:18:41.219220
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    it = tgrange(10)
    for j in it:
        pass
    assert j + 1 == 10 and len(it.xdata) == 10

# Generated at 2022-06-24 10:18:48.369849
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    from numpy.random import binomial, random

    n = n_it = n_epochs = 100
    pbar = tqdm_gui(n)
    for i in range(n):
        sleep(0.1 * binomial(1, random(), 1))
        pbar.update()
    pbar.close()

    pbar = tqdm_gui(n_it, 'Epochs: ')
    for epoch in range(n_epochs):
        pbar.set_description('Epochs: ')
        pbar.update(1)
        for i in tqdm_gui(n, leave=False):
            sleep(0.1 * binomial(1, random(), 1))
            pbar.update()
    pbar.close()

# Generated at 2022-06-24 10:18:58.290319
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .utils import FormatCustomText
    with tqdm_gui(total=10) as bar:
        for i in bar:
            if (i == 5):
                bar.close()
    with tqdm_gui(total=10, dynamic_ncols=True) as bar:
        for i in bar:
            if (i == 5):
                bar.close()
        bar.close()
    with tqdm_gui(total=10, ascii=True) as bar:
        for i in bar:
            if (i == 5):
                bar.close()
        bar.close()
    with tqdm_gui(total=10, ascii=True, ascii_ignore=True) as bar:
        for i in bar:
            if (i == 5):
                bar.close()
        bar

# Generated at 2022-06-24 10:19:08.145231
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    t = tqdm_gui(disable=False)
    assert t.disable is False
    assert t.n == 0
    assert t.last_print_n == 0
    assert len(t.xdata) == 0
    assert len(t.ydata) == 0
    assert len(t.zdata) == 0
    assert t.mpl is not None
    assert t.plt is not None
    assert t.toolbar != 'None'
    assert t.mininterval == 0.5
    assert t.fig is not None
    assert t.ax is not None
    assert len(t.line1.lines) == 1
    assert t.line1.get_color() == 'b'
    assert len(t.line2.lines) == 1
    assert t.line2.get_

# Generated at 2022-06-24 10:19:13.510112
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    # Initialise tqdm
    with tqdm_gui(total=5, miniters=1, mininterval=0.5, unit='iB', ascii=True) \
            as pbar:
        for i in range(5):
            pbar.update(1)

    # Close tqdm
    pbar.close()


# Generated at 2022-06-24 10:19:16.599618
# Unit test for function tgrange
def test_tgrange():
    for _ in tgrange(4):
        sleep(0.5)


if __name__ == "__main__":
    test_tgrange()

# Generated at 2022-06-24 10:19:20.470298
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from time import sleep
    with tgrange(10) as t:
        [sleep(0.01) for _ in t]


if __name__ == "__main__":
    # $ python -m tqdm.gui
    test_tgrange()

# Generated at 2022-06-24 10:19:27.699445
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib
    matplotlib.use("Qt5Agg")
    import matplotlib.pyplot as plt
    import shutil

    # Prepare
    t = tqdm_gui(total=100, leave=False, postfix={'loss': 0.1})
    t.display()
    plt.pause(1e-9)
    before = plt.get_fignums()
    assert len(before) > 0
    assert matplotlib.rcParams['toolbar'] == 'None'

    # Run
    t.close()
    plt.pause(1e-9)
    after = plt.get_fignums()

    # Check
    assert before == after
    assert matplotlib.rcParams['toolbar'] == 'None'
    assert shutil.get_terminal_

# Generated at 2022-06-24 10:19:40.142373
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .std import _supports_unicode
    from .utils import _term_move_up

    # Unit test for method close of class tqdm_gui

# Generated at 2022-06-24 10:19:49.761868
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep as tsleep
    import matplotlib.pyplot as plt
    from collections import namedtuple

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    _offset_text = namedtuple("_offset_text", ["get_va", "set_va"])
    _axhline = namedtuple("_axhline", ["get_xy", "set_va"])


# Generated at 2022-06-24 10:19:56.601825
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from contextlib import ExitStack
    from io import StringIO
    from matplotlib.testing.decorators import cleanup
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from matplotlib.testing.compare import compare_images
    import PIL

    @cleanup
    def main():
        with ExitStack() as stack:
            # save some state
            # original_interactive = plt.isinteractive()
            # stack.enter_context(plt.isinteractive(True))
            # backup = plt.rcParams.copy()
            # stack.callback(plt.rcParams.update, backup)

            # remove all figures
            stack.callback(plt.close, 'all')

            # prepare the monkeypatch
            import random
            random

# Generated at 2022-06-24 10:20:03.866882
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import matplotlib as mpl
    with tqdm(total=5) as pbar:
        assert len(pbar.xdata) == 0
        assert mpl.rcParams['toolbar'] is 'None'
        pbar.update(3)
        assert len(pbar.xdata) == 1

    assert mpl.rcParams['toolbar'] is not 'None'
    assert os.environ["TEST_ENV"] != "CI"  # tqdm closes the window

# Generated at 2022-06-24 10:20:10.501709
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import matplotlib
    matplotlib.use('Agg')
    t = tqdm_gui(total=100, leave=False)
    for i in _range(100):
        t.update()
        if i % 10 == 0:
            t.display()
    t.close()
    matplotlib.use('TkAgg')


if __name__ == "__main__":
    test_tqdm_gui_display()

# Generated at 2022-06-24 10:20:12.027446
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():  # pragma: no cover
    for _ in tqdm_gui(range(10)):
        pass

# Generated at 2022-06-24 10:20:16.378075
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import random
    random.seed(0)
    bar = tqdm_gui(total=None, leave=True)
    n = 2
    while n < 100:
        elapsed = random.random()
        n += 1
        bar.display(n=n, n_fmt=str(n), elapsed=elapsed)

# Generated at 2022-06-24 10:20:25.871222
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .compat import StringIO
    from .utils import FormatTransferDict, transfer_format_to_str

    class TqdmIO(FormatTransferDict, StringIO):
        """Testing write method of class tqdm_gui"""

        def write(self, buf, **kwargs):
            self.setvalue(str(buf))

        def flush(self, **kwargs):
            # Py3k compatibility
            pass

    # Test tqdm close method
    with TqdmIO() as io:
        tgrange(5, file=io).close()
        io.seek(0)
        io.read()
        io.write('\n')
        assert io.getvalue() == '\n'
        io.setvalue(transfer_format_to_str(io.flatten()))
        assert io.getvalue

# Generated at 2022-06-24 10:20:27.902633
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # Create a tqdm_gui object and assert that it's disabled when closed
    tqdm_gui().close()
    assert tqdm_gui(disable=True).disable

# Generated at 2022-06-24 10:20:34.127714
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from unittest import TestCase
    import matplotlib as mpl
    import matplotlib.pyplot as plt

    if mpl.get_backend() == "TkAgg":
        raise unittest.SkipTest("TkAgg backend")

    class Test(TestCase):
        def setUp(self):
            self.__was_interactive = plt.isinteractive()
            plt.ion()
            self.__total = 10
            self.__t = tqdm_gui(total=self.__total)
            self.__t.start()

        def tearDown(self):
            plt.close(self.__t.fig)
            if not self.__was_interactive:
                plt.ioff()


# Generated at 2022-06-24 10:20:42.971530
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    import sys
    import time
    from random import random

    # CLI mode testing
    for _ in tqdm(range(5)):
        time.sleep(random())

    # GUI mode testing
    tqdm_gui.pandas = True

# Generated at 2022-06-24 10:20:45.943770
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """Export tqdm_gui(x).clear()"""
    with tqdm_gui(total=10) as t:
        t.clear()
        t.close()



# Generated at 2022-06-24 10:20:51.601172
# Unit test for function tgrange
def test_tgrange():
    for i in tgrange(3, desc='1st loop'):
        for j in tgrange(100, desc='2nd loop'):
            for k in tgrange(100, desc='3nd loop'):
                pass
    # Test closing
    pbar = tgrange(3, desc='1st loop')
    pbar.close()
    with pbar:
        for i in _range(3):
            pass

# Generated at 2022-06-24 10:20:53.170045
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    for i in tgrange(10, 15, 2):
        sleep(0.1)



# Generated at 2022-06-24 10:21:02.480901
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        import matplotlib
        import matplotlib.pyplot as plt
        matplotlib.use('TkAgg')
        matplotlib.rcParams['toolbar'] = 'None'
    except ImportError:
        return

    with tqdm(total=10) as t:
        for i in _range(10):
            t.update()

    assert plt.isinteractive()
    assert matplotlib.rcParams['toolbar'] == 'None'
    plt.close('all')
    matplotlib.rcParams['toolbar'] = 'toolbar2'
    assert not plt.isinteractive()
    assert matplotlib.rcParams['toolbar'] == 'toolbar2'

# Generated at 2022-06-24 10:21:04.249871
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .gui.tests import test_tqdm_gui_close
    test_tqdm_gui_close()

# Generated at 2022-06-24 10:21:07.525780
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    with std_tqdm(total=10) as pbar:
        for x in pbar:
            if x <= 6:
                pbar.display()

if __name__ == "__main__":
    test_tqdm_gui_display()

# Generated at 2022-06-24 10:21:09.825622
# Unit test for function tgrange
def test_tgrange():
    list(tgrange(1000))


if __name__ == '__main__':
    test_tgrange()

# Generated at 2022-06-24 10:21:15.264584
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .std import tqdm

    t = tqdm(total=100, desc="desc")
    try:
        for i in range(104):
            t.update(i)
            if i == 33:
                t.set_description("desc2", refresh=False)
    finally:
        t.close()
        t.close()

# Test the behavior of `bar_format`

# Generated at 2022-06-24 10:21:18.220171
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with trange(10) as t:
        for i in t:
            t.set_description("test")
            assert t == i
            assert len(t) == 10
            break

# Generated at 2022-06-24 10:21:20.920676
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm(total=100) as pbar:
        for _ in range(100):
            pbar.update(1)
    return

# Generated at 2022-06-24 10:21:26.258681
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from math import isfinite
    from random import gauss
    for _ in tqdm(range(100), miniters=1):
        sleep(0.05)
    for _ in tqdm(range(100), miniters=1, leave=True):
        sleep(0.05)

    # test for issue #971
    for _ in tqdm([]):
        sleep(1)
    t = tqdm(range(1), miniters=1, total=None)
    if isfinite(t.total):
        raise AssertionError("Total should be None")
    if t.percent:
        raise AssertionError("Percent should be 0")
    t.write("Total should be None")