

# Generated at 2022-06-24 10:12:37.022833
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        from matplotlib import pyplot as plt
        t = tqdm_gui(range(1000), desc="test")
        t.write("test")  # should not raise any error after clear()
        t.clear()
        t.display()  # should not raise any error after clear()
        plt.close("all")
    except ImportError:
        pass

# Generated at 2022-06-24 10:12:43.654151
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import numpy as np
    import matplotlib.pyplot as plt
    from matplotlib import patches, lines
    t = tqdm_gui(total=200, disable=False, ncols=20, bar_format="{percentage:3.0f}%|{bar}{r_bar}")
    for _ in t:
        t.display()
    t.close()

# Generated at 2022-06-24 10:12:50.560265
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .std import TqdmTypeError
    from .utils import format_sizeof
    from .tqdm import _term_move_up
    from time import sleep
    from datetime import datetime
    import matplotlib.pyplot as plt  # noqa
    from six.moves import zip, range

    if plt.get_backend() in ["MacOSX", "TkAgg", "GTK", "GTKAgg"]:
        return  # pragma: no cover
    print("\n- Testing method display of class tqdm_gui")

    with tqdm(total=100, unit="iB", unit_scale=True, unit_divisor=1024,
              desc="test", leave=True) as t:
        for i in range(100):
            sleep(0.01 * i)
           

# Generated at 2022-06-24 10:12:59.112884
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .std import sys
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    class TqdmHelper(tqdm_gui):
        """TqdmHelper() is needed to propagate disable flag."""
        def __init__(self, *args, **kwargs):
            super(TqdmHelper, self).__init__(*args, **kwargs)
            self._restore = None

        def display(self, *args, **kwargs):
            try:
                with redirect_stdout(StringIO()):
                    super(TqdmHelper, self).display(*args, **kwargs)
            except AttributeError:
                pass

        def disable(self, *args, **kwargs):
            super(TqdmHelper, self).disable(*args, **kwargs)


# Generated at 2022-06-24 10:13:02.329762
# Unit test for function tgrange
def test_tgrange():
    l = tgrange(30, leave=False)
    for i in l:
        pass


if __name__ == '__main__':
    try:
        test_tgrange()
        print("Test passed !")
    except Exception as e:
        print(e)

# Generated at 2022-06-24 10:13:12.068920
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import time
    t = tqdm_gui(total=5, leave=False)
    for _ in range(5):
        time.sleep(0.3)
        t.update()
    time.sleep(0.3)
    t.clear()
    assert len(t.xdata) == 0
    t.close()


if __name__ == "__main__":  # pragma: no cover
    for _ in tqdm_gui(range(10), desc='1st loop'):
        for _ in tqdm_gui(range(4), desc='2nd loop', leave=True):
            for _ in tqdm_gui(range(100), desc='3nd loop', leave=False):
                pass

    import time

# Generated at 2022-06-24 10:13:18.749632
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    it = tqdm_gui(total=3, leave=False, gui=True)
    for i in range(3):
        if i == 1:
            it.last_print_n = 0
            it.last_print_t = it._time() - 1.0
        it.update()
    it.close()

# Generated at 2022-06-24 10:13:24.536386
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    import sys  # NOQA
    _, err = sys.stdout, sys.stderr
    sys.stdout, sys.stderr = open('.test.out', 'w'), open('.test.err', 'w')


# Generated at 2022-06-24 10:13:36.164564
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from nose.tools import assert_equal
    from math import isnan
    # Python 3 compatibility for Python 2 (more complicated due to 1-hour
    # warnings)
    from .utils import _range

    from io import StringIO
    from contextlib import redirect_stdout
    f = StringIO()
    with redirect_stdout(f):
        # Assert smoothness
        for w in _range(1, 11):
            msg = tqdm_gui(total=10, ncols=72, smoothing=w / 10, leave=False)
            assert_equal(len(msg) > 0, True)
            for i in _range(10):
                msg.update()
            msg.close()

        # Assert initial and dynamic bar

# Generated at 2022-06-24 10:13:43.318210
# Unit test for function tgrange
def test_tgrange():  # pragma: no cover
    from .std import tqdm as std_tqdm
    from .std import trange as std_trange
    # Check that tgrange is a synonym for tqdm
    for a in [(1, 2), [1, 2], {1, 2}]:
        for k in ["total", "ncols", "miniters", "mininterval", "maxinterval"]:
            d1 = dict(zip(k, a))
            d2 = dict(zip("tqdm_" + k, a))
            r1 = list(tgrange(2, **d1))
            r2 = list(tqdm(std_trange(2), **d2))
            assert r1 == [0, 1]
            assert r2 == [0, 1]
    assert tqdm

# Generated at 2022-06-24 10:13:51.239103
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    from copy import copy
    for n in tqdm_gui(xrange(1, 100), leave=False):
        xdata = copy(n)
        ydata = copy(n)
        zdata = copy(n)


if __name__ == "__main__":
    print("\nTesting tqdm_gui method display()...\n")
    test_tqdm_gui_display()
    print("\n=> tqdm_gui.display() test is successful!\n")

# Generated at 2022-06-24 10:13:53.467675
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # TODO: unit test for tqdm_gui clear method
    pass

# Generated at 2022-06-24 10:13:57.270590
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg

    t = tqdm_gui(_range(1000))
    t.close()

    # Make sure the figure is closed to avoid memory leak. See #1568
    fig = Figure()
    FigureCanvasAgg(fig)
    fig.clf()
    fig.clear()
    del fig

# Generated at 2022-06-24 10:14:03.698281
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """test"""
    # first test

# Generated at 2022-06-24 10:14:16.157032
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import time
    t = tqdm_gui([], miniters=1)
    t.start()
    time.sleep(0.01)
    t.display()
    time.sleep(0.01)
    t.display()
    time.sleep(0.01)
    t.display()
    time.sleep(0.01)
    t.display()
    time.sleep(0.01)
    t.display()
    time.sleep(0.01)
    t.display()
    time.sleep(0.01)
    t.display()
    time.sleep(0.01)
    t.display()
    time.sleep(0.01)
    t.close()
    time.sleep(0.01)


if __name__ == '__main__':
    import doctest
   

# Generated at 2022-06-24 10:14:20.358525
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():  # pragma: no cover
    from time import sleep
    with tqdm_gui(total=100) as pbar:
        for _ in range(100):
            sleep(0.1)
            pbar.update()


if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-24 10:14:24.773324
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Test tqdm_gui close method."""
    t = tqdm(total=10)
    assert t.gui
    try:
        t.close()
    except AttributeError:
        raise Exception("test_tqdm_gui_close failed")
    assert t.mpl.rcParams['toolbar'] is not None
    assert t.plt.isinteractive() is False



# Generated at 2022-06-24 10:14:32.590018
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    list(tqdm(list(range(10))))
    list(tqdm(list(range(10)), total=100))
    list(tqdm(list(range(10)), total=None))
    list(tqdm(list(range(10)), unit="uB"))
    list(tqdm(list(range(10)),
              unit="uB",
              bar_format="{bar}{r_bar}|{n_fmt}/{total_fmt} [{elapsed}<{remaining}]"))
    list(tqdm(list(range(10)), unit="uB", mininterval=0.5))
    list(tqdm(list(range(10)), unit="uB", miniters=2))
    from collections import deque

# Generated at 2022-06-24 10:14:37.829161
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from easydev import TempFile
    import sys

    with TempFile(suffix=".png") as fh:
        t = tqdm(total=100)
        for i in range(100):
            t.display()
            t.n = i + 1
            sys.stdout.flush()
            t.mpl.pyplot.savefig(fh.name)


if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)