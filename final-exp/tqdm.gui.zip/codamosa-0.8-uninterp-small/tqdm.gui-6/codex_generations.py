

# Generated at 2022-06-26 09:46:46.102615
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.clear()
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:46:55.763986
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui_0 = tqdm_gui()
    # print("type(tqdm_gui_0.disable)")
    # print("tqdm_gui_0.disable")
    # print("type(tqdm_gui_0.gui)")
    # print("tqdm_gui_0.gui")
    assert tqdm_gui_0.disable == False
    assert tqdm_gui_0.gui == True

# Generated at 2022-06-26 09:46:56.933781
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    pass


# Generated at 2022-06-26 09:47:10.127989
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from tqdm.gui import tqdm_gui
    xdata = []
    ydata = []
    zdata = []
    mininterval = 1
    last_print_n = 0
    last_print_t = 0
    n = 0
    cur_t = 0
    total = 0
    line1 = 0
    line2 = 0
    ax = 0
    fig = 0

# Generated at 2022-06-26 09:47:22.441116
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.disable = False
    tqdm_gui_0.n = 1
    tqdm_gui_0.start_t = 1
    tqdm_gui_0.last_print_n = 1
    tqdm_gui_0.last_print_t = 1
    tqdm_gui_0.total = None
    tqdm_gui_0.xdata = [1]
    tqdm_gui_0.ydata = [1]
    tqdm_gui_0.zdata = [1]
    tqdm_gui_0.ax = None
    tqdm_gui_0.line1 = None
    tqdm_gui_0.line2 = None
    tqdm_gui

# Generated at 2022-06-26 09:47:28.394215
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .std import tqdm as std_tqdm
    # Test for case: clear. 
    # Ensure that bar is cleared after the ETA is finalized
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.clear()

# Generated at 2022-06-26 09:47:32.822711
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    def test_case_1():
        tqdm_gui_1 = tqdm_gui(ncols=88)

    # Should work fine when pass the test
    test_case_1()


# Generated at 2022-06-26 09:47:38.942044
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # Create a tqdm_gui object with mininterval=1 and miniters=1
    tqdm_gui_1 = tqdm_gui(mininterval=1, miniters=1)
    tqdm_gui_1.clear()


# Generated at 2022-06-26 09:47:49.993886
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.refresh(nolock=True, lock_args=())
    tqdm_gui_0.close(nolock=True, lock_args=())
    tqdm_gui_0.write(nolock=True, lock_args=(), s=None)
    tqdm_gui_0.clear()


if __name__ == '__main__':
    from .main import _main
    _main(gui=True)

# Generated at 2022-06-26 09:47:52.620771
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    t = tqdm_gui()
    t.total = 10
    t.display()


# Generated at 2022-06-26 09:48:08.664690
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    test_case_0()

# Generated at 2022-06-26 09:48:16.064699
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # Initializing tqdm_gui_0
    tqdm_gui_0 = tqdm_gui()

    # Testing if error is raised
    try:
        # Executing method close
        tqdm_gui_0.close()
        # Logging warning
        warn("Caught the expected warning", RuntimeWarning, stacklevel=4)
    except RuntimeWarning:
        # Logging failure
        warn("Error not raised as expected", RuntimeWarning, stacklevel=4)


# Generated at 2022-06-26 09:48:28.696072
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui_0 = tqdm_gui()
    assert tqdm_gui_0.disable
    assert tqdm_gui_0.bar_format
    assert tqdm_gui_0.mininterval
    assert tqdm_gui_0.miniters
    assert tqdm_gui_0.desc
    assert tqdm_gui_0.postfix
    assert tqdm_gui_0.unit
    assert tqdm_gui_0.unit_scale
    assert tqdm_gui_0.unit_divisor
    assert tqdm_gui_0.initial
    assert tqdm_gui_0.total
    assert tqdm_gui_0.unit_scale
    assert tqdm_gui_0.smoothing

# Generated at 2022-06-26 09:48:31.297857
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_0 = tqdm_gui()
    assert (tqdm_gui_0.clear() == None)


# Generated at 2022-06-26 09:48:39.577307
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    with tqdm_gui(disable=True) as t:
        t.n = 10
        t.last_print_n = 0
        t.start_t = 1
        t.last_print_t = 1
        t.total = 100
        t.xdata = [1]
        t.ydata = [10]
        t.zdata = [1]
        t.ax = t.ax
        t.line1 = t.line1
        t.line2 = t.line2
        cur_t = 1
        t.display()


# Generated at 2022-06-26 09:48:51.649440
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui_1 = tqdm_gui()
    assert tqdm_gui_1.disable == False
    assert tqdm_gui_1.position == 0
    assert tqdm_gui_1.total is None
    assert tqdm_gui_1.unit_scale == False
    assert tqdm_gui_1.desc is None
    assert tqdm_gui_1.dynamic_ncols == True
    assert tqdm_gui_1.ascii == None
    assert tqdm_gui_1.bar_format is None
    assert tqdm_gui_1.postfix == {}
    assert tqdm_gui_1.unit == ''
    assert tqdm_gui_1.gui == True
    assert tqdm_gui_1.leave == False
    assert t

# Generated at 2022-06-26 09:49:01.615752
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from matplotlib import pyplot
    from matplotlib.testing.decorators import cleanup
    from unittest import TestCase

    @cleanup
    class TestTqdmGuiDisplay(TestCase):  # noqa
        def setUp(self):
            self.tqdm_gui_cur_t = 1
            self.tqdm_gui_elapsed = 1
            self.tqdm_gui_delta_it = 1
            self.tqdm_gui_delta_t = 1
            self.tqdm_gui_n = 1
            self.tqdm_gui_total = 1
            self.tqdm_gui_start_t = 1
            self.tqdm_gui_last_print_n = 1
            self.tqdm_gui_last_print_t = 0


# Generated at 2022-06-26 09:49:15.781941
# Unit test for method close of class tqdm_gui

# Generated at 2022-06-26 09:49:23.233077
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():       # Added by O. Shalit (2018/04/20)
    try:
        warn("GUI is experimental/alpha", TqdmExperimentalWarning, stacklevel=2)
        import matplotlib as mpl
        import matplotlib.pyplot as plt

        tqdm_gui_0 = tqdm_gui()
        tqdm_gui_0.clear()
    except Exception as e:
        raise e


# Generated at 2022-06-26 09:49:36.726333
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from tqdm.gui import tqdm_gui
    from unittest import mock

    _gui = tqdm_gui(gui=True)
    _gui.disable = False
    _gui.last_print_t = _gui.start_t = 0
    _gui.last_print_n = 0
    _gui.mininterval = 0.5
    _gui.maxinterval = 0.5
    _gui.n = 100
    _gui.total = None
    _gui.unit = None
    _gui.unit_scale = False
    _gui.leave = False
    _gui.miniters = 1
    _gui.mininterval = 0.5
    _gui.maxinterval = 1

# Generated at 2022-06-26 09:50:14.362835
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # Initialize
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.n = tqdm_gui_0._time()
    tqdm_gui_0.start_t = tqdm_gui_0._time()
    tqdm_gui_0.last_print_n = 0
    tqdm_gui_0.last_print_t = 0
    tqdm_gui_0.total = None
    tqdm_gui_0.xdata = [1]
    tqdm_gui_0.ydata = [2]
    tqdm_gui_0.zdata = [3]
    tqdm_gui_0.ax = tqdm_gui_0.plt.subplots()
    tqdm_gui_0.line

# Generated at 2022-06-26 09:50:21.230933
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from matplotlib import pyplot as plt
    @tqdm_gui(total = 100)
    def add():
        for i in _range(100):
            yield i
    for i in add():
        pass
    for i in _range(10):
        tqdm_gui.clear()
    plt.show()

if __name__ == '__main__':
    test_case_0()
    test_tqdm_gui_clear()

# Generated at 2022-06-26 09:50:32.475338
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui_0 = tqdm_gui()
    print(tqdm_gui_0)
    tqdm_gui_1 = tqdm_gui(desc='Progressing...')
    print(tqdm_gui_1)
    tqdm_gui_2 = tqdm_gui(desc='Progressing...', position=0)
    print(tqdm_gui_2)
    tqdm_gui_3 = tqdm_gui(position=0)
    print(tqdm_gui_3)
    tqdm_gui_4 = tqdm_gui(position=0, leave=False)
    print(tqdm_gui_4)
    tqdm_gui_5 = tqdm_gui(position=0, leave=False, ascii=False)
   

# Generated at 2022-06-26 09:50:41.493422
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """
    Unittest for tqdm_gui.display()
    """
    import matplotlib.pyplot as plt
    import matplotlib as mpl

    class dummy_plt:
        """
        Dummy object for testing.
        """
        def __init__(self, *args, **kwargs):

            class dummy_mpl:
                """
                Dummy object for testing.
                """
                rcParams = {"dummy": "dummy"}

            self.mpl = dummy_mpl
            # Dummy functions which do nothing
            self.subplots = self._dummy
            self.axhspan = self._dummy
            self.legend = self._dummy
            self.ticklabel_format = self._dummy
            self.grid = self._dummy
            self.plot = self

# Generated at 2022-06-26 09:50:48.880257
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_clear = tqdm_gui(mininterval=0.1).clear()
    tqdm_gui = tqdm_gui(mininterval=0.1)
    tqdm_gui_clear = tqdm_gui.clear()

if __name__ == "__main__":
    test_case_0()
    test_tqdm_gui_clear()

# Generated at 2022-06-26 09:51:01.679119
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    main = tqdm_gui()
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_2 = tqdm_gui()
    tqdm_gui_3 = tqdm_gui(3)
    tqdm_gui_4 = tqdm_gui(4)
    tqdm_gui_5 = tqdm_gui(5)
    tqdm_gui_6 = tqdm_gui(6)
    tqdm_gui_7 = tqdm_gui(7)
    tqdm_gui_8 = tqdm_gui(8)
    tqdm_gui_9 = tqdm_gui(9)
    tqdm_gui_10 = tqdm_gui(10)
    tqdm_gui_11 = tqdm_

# Generated at 2022-06-26 09:51:03.525307
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    test_case_0()


# Generated at 2022-06-26 09:51:12.975317
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from collections import deque
    from sys import version_info as v
    from warnings import catch_warnings, warn
    from .std import tqdm
    from .gui import tqdm_gui
    from .gui import tqdm_gui as tqdm_gui_class
    from .utils import _range

    is_py2 = v[0] == 2
    is_py3 = v[0] >= 3
    if is_py2 or is_py3:
        range = _range

    with catch_warnings(record=True) as w:
        tqdm_gui_1 = tqdm_gui(total=5)
    assert len(w) == 1 and 'GUI is experimental/alpha' in str(w[0].message)


# Generated at 2022-06-26 09:51:15.780341
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.close()


# Generated at 2022-06-26 09:51:17.953755
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    x = tqdm_gui(0)
    x.close()


# Generated at 2022-06-26 09:52:21.558068
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .std import TqdmTypeError
    from .std import TqdmKeyError
    from .std import TqdmDeprecationWarning
    from .std import tqdm
    from .std import tqdm_gui
    t = tqdm(total = 100)
    t.close()
    t = tqdm_gui(total = 100)
    t.close()
    try:
        with tqdm(total = 100) as t:
            raise TqdmTypeError()
    except TqdmTypeError:
        pass
    try:
        with tqdm(total = 100) as t:
            raise TqdmKeyError()
    except TqdmKeyError:
        pass

# Generated at 2022-06-26 09:52:25.637770
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:52:34.465669
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from collections import deque
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import unittest

# Generated at 2022-06-26 09:52:39.475326
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Test for the method close of class tqdm_gui
    """
    tqdm_gui_close = tqdm_gui()
    tqdm_gui_close.close()


# Generated at 2022-06-26 09:52:48.891289
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from collections import Counter
    from tqdm.gui import tqdm_gui
    from io import StringIO
    import sys
    old_stdout = sys.stdout
    my_stdout = sys.stdout = StringIO()
    for _ in tqdm_gui(range(10)):
        tqdm_gui.clear()
        if not tqdm_gui.disable:
            print(_)
            my_stdout.write(_)
    sys.stdout = old_stdout
    text = my_stdout.getvalue().strip()
    assert (text == '0123456789' or text == '9876543210')
    assert tqdm_gui.get_lock().locked()
    tqdm_gui.close()
    assert not tqdm_gui.get_lock().locked()
   

# Generated at 2022-06-26 09:52:52.272122
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()
    test_case_0()



# Generated at 2022-06-26 09:52:54.689185
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from pytest import raises

    tqdm_gui_1 = tqdm_gui('Test Close' , unit= 'It',total=100)
    tqdm_gui_1.close()


# Generated at 2022-06-26 09:53:07.870303
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib.pyplot as mp
    import numpy as np

    tqdm_gui_0 = tqdm_gui()
    assert not tqdm_gui_0.disable

    tqdm_gui_0.n = 1
    tqdm_gui_0.miniters = 2
    tqdm_gui_0.mininterval = 3
    tqdm_gui_0.dynamic_miniters = False
    tqdm_gui_0.maxinterval = 4
    tqdm_gui_0.last_print_n = 5
    tqdm_gui_0.total = 6
    tqdm_gui_0.unit = 'test'
    tqdm_gui_0.unit_scale = False
    tqdm_gui_0.unit_divisor = 3

# Generated at 2022-06-26 09:53:19.755734
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    import matplotlib as mpl
    from collections import deque
    from .utils import _range

    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.disable = False
    tqdm_gui_1.mpl = mpl
    tqdm_gui_1.plt = plt
    tqdm_gui_1.toolbar = mpl.rcParams['toolbar']
    tqdm_gui_1.mininterval = 0.5
    tqdm_gui_1.fig = plt.subplots(figsize=(9, 2.2))[0]
    tqdm_gui_1.xdata = deque([])
    tqdm_gui_1.ydata = deque([])

# Generated at 2022-06-26 09:53:29.924556
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from collections import deque
    tqdm_gui_1 = tqdm_gui()
    # data structures for line
    tqdm_gui_1.xdata = deque([])
    tqdm_gui_1.ydata = deque([])
    tqdm_gui_1.zdata = deque([])
    # data structures for text
    tqdm_gui_1.d = {}
    # data structures for progressbar
    tqdm_gui_1.poly_lims = [0, 1, 2, 3]
    # data structures for time
    tqdm_gui_1.n = 7
    tqdm_gui_1.cur_t = 13
    tqdm_gui_1.elapsed = 6
    tqdm_gui_1.delta_it = 2
   