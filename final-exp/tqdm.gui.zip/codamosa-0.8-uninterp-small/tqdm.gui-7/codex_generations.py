

# Generated at 2022-06-26 09:46:25.622769
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from tqdm.gui import tqdm_gui
    obj_0 = tqdm_gui()
    obj_0.clear()


# Generated at 2022-06-26 09:46:31.522123
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Unit test for method close of class tqdm_gui
    """
    var_0 = tqdm_gui()
    var_0.close()



# Generated at 2022-06-26 09:46:34.793831
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    var_0 = tqdm_gui()
    var_0.close()  # Deconstructor


# Generated at 2022-06-26 09:46:38.279872
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    var_37 = tgrange(2)
    assert not var_37.disable
    var_37.close()
    assert var_37.disable


# Generated at 2022-06-26 09:46:41.005650
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # Execute method
    test_case_0()

# Generated at 2022-06-26 09:46:46.426411
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    print('\nTesting method clear of class tqdm_gui')
    print("TIME: ", time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())))
    print("PID:  ", os.getpid())
    var_0 = tqdm_gui()
    var_0.clear()



# Generated at 2022-06-26 09:46:49.206194
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    var_0 = tqdm_gui()
    var_0.close()


# Generated at 2022-06-26 09:46:58.508631
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import unittest

    class TqdmGuiTest(unittest.TestCase):
        def test_constructor(self):
            var_0 = tgrange()
            self.assertIsInstance(var_0, tqdm_gui)
            self.assertRaises(ValueError, tgrange, total=None)
            self.assertRaises(ValueError, tgrange, total=None, miniters=1)

    t = TqdmGuiTest()
    t.test_constructor()
    t.test_case_0()

# Generated at 2022-06-26 09:47:10.954930
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # Instances
    var_0 = tgrange()
    # Methods
    var_0.display()
    del var_0

if __name__ == "__main__":
    from os import getcwd
    from sys import path
    path.insert(0, getcwd() + "/../../..")

    from time import sleep
    from numpy import random
    # import unittest

    # class Testcase(unittest.TestCase):
    #     def test_test_case_0(self):
    #         test_case_0()
    #         pass
    #
    #     def test_tqdm_gui_display(self):
    #         test_tqdm_gui_display()
    #         pass
    #
    # unittest.main()

    test_tqdm_

# Generated at 2022-06-26 09:47:14.637747
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    var_1 = tqdm_gui()
    var_1.disable = True
    var_1.display()



# Generated at 2022-06-26 09:47:29.286601
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    for _ in tgrange(10):
        test_case_0()
        sleep(0.2)

# Generated at 2022-06-26 09:47:32.110127
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    var_0 = tqdm_gui()
    var_0.close()


# Generated at 2022-06-26 09:47:36.930067
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # Prints 0 to 9
    for i in tgrange(10):
        print("\t#" + str(i), end='')
        time.sleep(0.02)
    print("")



# Generated at 2022-06-26 09:47:41.456118
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():

    # ---------
    #  Arrange
    # ---------

    var_1 = tqdm_gui(range(1))
    var_1.clear()

    # ---------
    #  Act
    # ---------

    var_1.clear()

    # ---------
    #  Assert
    # ---------

    pass


# Generated at 2022-06-26 09:47:52.050310
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    var_0 = tgrange()

# Generated at 2022-06-26 09:47:55.713468
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():    
    var_0 = tqdm_gui()
    assert var_0 is not None



# Generated at 2022-06-26 09:48:02.500004
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot
    matplotlib.pyplot.ion = True
    gui = tqdm_gui(position=1, postfix=None, gui=True)
    gui.display()
    gui = tqdm_gui(position=1, postfix=None, gui=True)
    gui.display()


# Generated at 2022-06-26 09:48:03.657975
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    var_0 = [tgrange, tqdm_gui, trange][1]
    var_1 = var_0()
    var_1.close()


# Generated at 2022-06-26 09:48:06.204912
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    var_0 = tgrange()
    var_0.clear()

# Generated at 2022-06-26 09:48:17.226370
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib.pyplot as plt
    g = tqdm_gui(total=100, disable=False)
    g.close()
    # print("Disable = True test successful")
    g = tqdm_gui(total=100, disable=True)
    g.close()
    # print("Iteration count test successful")
    g = tqdm_gui(total=100, disable=False)
    for i in _range(100):
        g.update(i)
    g.close()
    # print("Addition and removal of progress bar test successful")
    test_case_0()
    if plt.isinteractive():
        # print("Interactive mode test successful")
        pass
    else:
        # print("Non-interactive mode test successful")
        pass

# Generated at 2022-06-26 09:48:46.469802
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import numpy as np

    n = 1000
    x = np.linspace(0, 1, n) + 0.5 * (1 + 1j) * np.random.randn(n)
    for i in tqdm(list(range(100))):
        y = np.abs(np.fft.fft(x))
    # You need to close the progressbar manually
    tqdm.close()
    plt.plot(y)
    plt.title("FFT")
    plt.show()



# Generated at 2022-06-26 09:48:49.944118
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import unittest

    class tqdm_gui_display_TestCase(unittest.TestCase):
        def test_example(self):
            self.assertEqual(True, True)

    unittest.main()


# Generated at 2022-06-26 09:48:55.306566
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    var = tqdm_gui()
    for i in var:
        print(i)

if __name__ == "__main__":
    pass
    # test_tqdm_gui()

# Generated at 2022-06-26 09:49:03.804207
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from collections import Counter
    from time import sleep
    from tqdm.gui import tqdm_gui

    t = tqdm_gui(4, disable=False)
    for i in t:
        assert not t.disable, i
        sleep(.5)
    t.close()
    assert t.disable, 'closed'
    t.close()
    assert t.disable, 'closed again'
    t = tqdm_gui(4, disable=False)
    t.close()
    assert t.disable, 'closed before iter'
    t = tqdm_gui(0, disable=False)
    t.close()
    assert t.disable, 'closed before iter with total=0'
    assert not t.dynamic_ncols, 'dynamic_ncols disabled'
    t = tqdm_

# Generated at 2022-06-26 09:49:04.565977
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    assert tqdm_gui()

# Generated at 2022-06-26 09:49:09.079256
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from tqdm.gui import tqdm_gui
    from tqdm._tqdm import IS_PYTHON2, IS_PYPY
    from tqdm.utils import _term_move_up
    # Create a fake file
    import io
    file_0 = io.StringIO() if IS_PYTHON2 else io.BytesIO()
    if IS_PYTHON2:
        file_0.write(str(u"\n"))
        file_0.flush()
        file_0.seek(0)
    else:
        file_0.write("\n".encode("UTF-8"))
        file_0.flush()
        file_0.seek(0)
    # Create tqdm_gui instance

# Generated at 2022-06-26 09:49:11.835499
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    var_0 = tqdm_gui()
    var_0.close()



# Generated at 2022-06-26 09:49:15.404815
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # Initialize an object of class tqdm_gui
    a = tqdm_gui()
    assert a is not None
    

# Generated at 2022-06-26 09:49:16.549566
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .gui import tqdm_gui
    t = tqdm_gui(0)
    t.clear(1)


# Generated at 2022-06-26 09:49:26.643434
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import io, sys, re
    import matplotlib
    import matplotlib.pyplot as plt
    import matplotlib.animation as animation
    import numpy as np
    from tqdm.gui import tqdm
    from tqdm import tnrange, tqdm as tqdm_std
    from datetime import timedelta

    try:  # Python 3+
        from tkinter import Tk, Label, Frame, Entry
        from tkinter.ttk import Progressbar
        from tkinter.ttk import Separator, Style
        from tkinter.ttk import Combobox
    except ImportError:  # Python 2
        from Tkinter import Tk, Label, Frame, Entry
        from ttk import Progressbar
        from ttk import Separator, Style
        from ttk import Combob

# Generated at 2022-06-26 09:49:48.330438
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .utils import _range
    from .std import trange

    # tqdm_gui_0 = tqdm_gui()
    # tqdm_gui_1 = tqdm_gui(2)
    # tqdm_gui_2 = tqdm_gui(0, 2)
    # tqdm_gui_3 = tqdm_gui(0, 2, 2)
    # tqdm_gui_4 = tqdm_gui(0, 2, 2, 12)
    # tqdm_gui_5 = tqdm_gui(12)
    # tqdm_gui_6 = tqdm_gui(_range(12))
    # tqdm_gui_7 = tqdm_gui(0, 2, 2, 12, 0)
    # tqdm_gui_8 = t

# Generated at 2022-06-26 09:49:57.190735
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # create test object
    tgui = tqdm_gui()

    # check that graph is not empty and displayed
    assert not tgui.disable, "disable flag should be False"
    assert tgui.plt.isinteractive(), "plot should be displayed"
    assert tgui.mpl.rcParams['toolbar'] == 'None', "toolbar should be hidden"
    assert tgui.wasion, "wasion flag should be True"

test_case_0()
test_tqdm_gui_display()

# Generated at 2022-06-26 09:50:11.000462
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import copy
    import types

    # Create an instance of tqdm_gui
    tqdm_gui_0 = tqdm_gui()

    # Create an instance of tqdm_gui
    # Create an instance of tqdm_gui for testing
    tqdm_gui_0_test = tqdm_gui()

    # Create an instance of tqdm_gui
    # Create an instance of tqdm_gui for testing
    tqdm_gui_0_test_2 = copy.deepcopy(tqdm_gui_0)

    # set the expected result
    expected_result_0 = copy.deepcopy(tqdm_gui_0)

    # Close the tqdm_gui created in the test case
    tqdm_gui_0_test.close()

    # Close the tqdm_gui

# Generated at 2022-06-26 09:50:12.418043
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui(clear())



# Generated at 2022-06-26 09:50:17.029925
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    l = [x for x in range(10)]

    with tqdm_gui(total=len(l)) as pbar:
        for i in l:
            pbar.update()



# Generated at 2022-06-26 09:50:20.946401
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()



# Generated at 2022-06-26 09:50:25.416205
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    frobnicator = tqdm_gui()
    frobnicator.display()
    frobnicator.display()
    frobnicator.display()
    frobnicator.display()



# Generated at 2022-06-26 09:50:30.097981
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # init
    tqdm_gui_1 = tqdm_gui()
    assert(isinstance(tqdm_gui_1, tqdm_gui))
    # close method
    tqdm_gui_1.close()
    assert(tqdm_gui_1.disable == True)


# Generated at 2022-06-26 09:50:31.415956
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    pass


# Generated at 2022-06-26 09:50:40.329899
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from collections import deque

    import matplotlib as mpl
    import matplotlib.pyplot as plt
    kwargs = {}
    kwargs['gui'] = True

    warn("GUI is experimental/alpha", TqdmExperimentalWarning, stacklevel=2)
    self.mpl = mpl
    self.plt = plt

    self.mininterval = max(self.mininterval, 0.5)
    self.fig, ax = plt.subplots(figsize=(9, 2.2))
    # self.fig.subplots_adjust(bottom=0.2)
    total = self.__len__()  # avoids TypeError on None #971
    if total is not None:
        self.xdata = []
        self.ydata = []
        self.zdata = []

# Generated at 2022-06-26 09:51:14.890426
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui_display = tqdm_gui(total=1)
    assert tqdm_gui_display.display() is None


# Generated at 2022-06-26 09:51:24.629494
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.disable = False
    class A(object):
        pass
    tqdm_gui_1.n = 10
    tqdm_gui_1.start_t = 4
    tqdm_gui_1.last_print_n = 0
    tqdm_gui_1.last_print_t = 3
    tqdm_gui_1.total = None

# Generated at 2022-06-26 09:51:28.465214
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:51:32.974131
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.start()
    tqdm_gui_1.display()
    tqdm_gui_1.clear()
    tqdm_gui_1.close()


# Generated at 2022-06-26 09:51:43.988786
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import sys
    import time

# Generated at 2022-06-26 09:51:52.755477
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Case to check if 'close' is working on tqdm_gui
    """
    try:
        # Creating a tqdm_gui object
        tqdm_gui_1 = tqdm_gui()
        # call 'close' on the object
        tqdm_gui_1.close()
    except Exception as e:
        raise e
    else:
        assert True


# Generated at 2022-06-26 09:51:58.188238
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    tqdm_gui_0 = tqdm_gui()
    toolbar = mpl.rcParams['toolbar']
    wasion = plt.isinteractive()
    tqdm_gui_0.close()
    assert(tqdm_gui_0.disable == True)
    assert(mpl.rcParams['toolbar'] == toolbar)
    assert(plt.isinteractive() == wasion)


# Generated at 2022-06-26 09:52:07.477211
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.disable = False

    # set up mock
    tqdm_gui_0._instances = []
    tqdm_gui_0.toolbar = 'None'
    tqdm_gui_0.mpl = 'None'
    tqdm_gui_0.plt = 'None'
    tqdm_gui_0.wasion = 'None'
    tqdm_gui_0.disable = 'None'

    tqdm_gui_0.close()

# Generated at 2022-06-26 09:52:14.398868
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import unittest
    import logging
    class Tqdm_guiTestCase(unittest.TestCase):
        def setUp(self):
            self.tqdm_gui_0 = tqdm_gui()
            self.tqdm_gui_1 = tqdm_gui(1)
            self.tqdm_gui_2 = tqdm_gui(total=1)
            self.tqdm_gui_3 = tqdm_gui(initial=1)
            self.tqdm_gui_4 = tqdm_gui(desc='test')
            self.tqdm_gui_5 = tqdm_gui(desc='test', position=1)
            self.tqdm_gui_6 = tqdm_gui(desc='test', mininterval=0.01)

# Generated at 2022-06-26 09:52:22.500696
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """
    Tests method display of class tqdm_gui
    """

    try:
        import matplotlib.pyplot as plt
        from matplotlib.backends.backend_qt4agg import FigureCanvasQTAgg as FigureCanvas
    except ImportError as e:
        pass

    try:
        from mock import patch
    except ImportError as e:
        pass

    mock_patch = patch('matplotlib.pyplot.pause')
    mock_pause = mock_patch.start()
    tqdm_gui_0 = tqdm_gui(total=20)

    tqdm_gui_0.display()

    mock_patch.stop()
    plt.close('all')


# Generated at 2022-06-26 09:53:30.117263
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    pop_units = ["", "K", "M", "G", "T", "P", "E", "Z", "Y"]
    tqdm_gui_1 = tqdm_gui(total=100)
    tqdm_gui_1.n = 10
    tqdm_gui_1.start_t = time.time() - 10
    tqdm_gui_1.last_print_n = 5
    tqdm_gui_1.last_print_t = time.time() - 5
    tqdm_gui_1.display()
    assert tqdm_gui_1.xdata[0] == 0.10
    assert tqdm_gui_1.ydata[0] == 1
    assert tqdm_gui_1.zdata[0] == 0.10
    assert tqdm

# Generated at 2022-06-26 09:53:36.215907
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.disable = True
    tqdm_gui_1.close()
    tqdm_gui_1.disable = False
    tqdm_gui_1.wasion = True
    tqdm_gui_1.plt.close(tqdm_gui_1.fig)
    tqdm_gui_1.toolbar = 'None'
    tqdm_gui_1.leave = True
    tqdm_gui_1._instances = []
    tqdm_gui_1.close()
    tqdm_gui_0.disable = False
    tqdm_gui_1.disable = True

# Generated at 2022-06-26 09:53:44.999890
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui_0 = tqdm_gui()
    assert isinstance(tqdm_gui_0, tqdm_gui) == True

    # Coverage test
    try:
        tqdm_gui("a")
    except TypeError:
        pass
    tqdm_gui([3, 4], ascii=True)


# Generated at 2022-06-26 09:53:50.412904
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from tqdm.gui import tqdm_gui
    import matplotlib.pyplot as plt
    import numpy as np
    import time
    import unittest

    import numpy.testing as npt

    # Test case displays figure
    def test_case_1():
        tqdm_gui_1 = tqdm_gui(total=5)
        for i in range(5):
            tqdm_gui_1.update(1)
        tqdm_gui_1.close()

    # Test case displays figure and tests x and y data
    def test_case_2():
        tqdm_gui_2 = tqdm_gui(total=5)
        for i in range(5):
            tqdm_gui_2.update(1)
        tqdm_gui_2.close

# Generated at 2022-06-26 09:53:53.295942
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.clear()


# Generated at 2022-06-26 09:53:57.502200
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # Test tqdm_gui_0
    tqdm_gui_0 = tqdm_gui()
    assert tqdm_gui_0.gui == True

# Generated at 2022-06-26 09:54:02.184042
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.close()


# Generated at 2022-06-26 09:54:07.998794
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # testing a standard case, when tqdm_gui_1.total is not None
    tqdm_gui_1 = tqdm_gui(total=100)
    tqdm_gui_1.n = 10
    tqdm_gui_1.start_t = 0
    tqdm_gui_1.last_print_n = 5
    tqdm_gui_1.last_print_t = tqdm_gui_1.start_t
    x = tqdm_gui_1._time()
    tqdm_gui_1.display()
    assert tqdm_gui_1.xdata == [10.0]
    assert tqdm_gui_1.ydata == [2.0]
    assert tqdm_gui_1.zdata == [0.2]
    assert t

# Generated at 2022-06-26 09:54:11.278389
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()



# Generated at 2022-06-26 09:54:14.597047
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # Call function close of class tqdm_gui
    tqdm_gui_close_0 = tqdm_gui.close(tqdm_gui())
