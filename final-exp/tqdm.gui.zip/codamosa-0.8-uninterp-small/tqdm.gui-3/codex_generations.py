

# Generated at 2022-06-26 09:46:45.556570
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    var_0 = tqdm_gui(20)
    var_0.update(1)
    var_0.close()
    var_0.clear()
    var_0.display()
    var_0.close()
    print('Executed constructor test for tqdm_gui')



# Generated at 2022-06-26 09:46:49.597452
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    var_0 = tqdm_gui()
    var_0.display()

if __name__ == '__main__':
    main()

# Generated at 2022-06-26 09:46:52.084837
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    obj = tqdm_gui()
    obj.close()


# Generated at 2022-06-26 09:46:55.465230
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    var_0 = tgrange()
    var_1 = var_0.close()
    assert var_1 is None


# Generated at 2022-06-26 09:46:57.714121
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    var_0 = tqdm_gui()
    var_1 = var_0.display()
    return var_1


# Generated at 2022-06-26 09:47:10.581870
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    var_1 = tgrange(9)
    var_2 = tgrange(81)
    var_3 = tgrange(9)
    var_4 = tgrange(81)
    var_5 = tgrange(9)
    var_6 = tgrange(81)
    var_7 = tgrange(9)
    var_8 = tgrange(81)
    var_9 = tgrange(9)
    var_10 = tgrange(81)
    var_11 = tgrange(9)
    var_12 = tgrange(81)
    var_13 = tgrange(9)
    var_14 = tgrange(81)
    var_15 = tgrange(9)
    var_16 = tgrange(81)
    var_17 = tgr

# Generated at 2022-06-26 09:47:15.746731
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    try:
        var_0 = tqdm_gui()
        try:
            var_0["clear"]()
        finally:
            var_0.close()
    finally:
        pass


# Generated at 2022-06-26 09:47:25.278884
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # create an object
    var_2 = tqdm_gui(unit='B', unit_scale=True, dynamic_ncols=True)
    n = var_2.n
    cur_t = var_2._time()
    elapsed = cur_t - var_2.start_t
    delta_it = n - var_2.last_print_n
    delta_t = cur_t - var_2.last_print_t

    # Inline due to multiple calls
    total = var_2.total
    xdata = var_2.xdata
    ydata = var_2.ydata
    zdata = var_2.zdata
    ax = var_2.ax
    line1 = var_2.line1
    line2 = var_2.line2
    # instantaneous rate
    y = delta

# Generated at 2022-06-26 09:47:29.162706
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    Test argument
        * args : 
        * kwargs : 
    """
    var_0 = tgrange()
    var_0.clear
    return



# Generated at 2022-06-26 09:47:31.968484
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    var_0 = tqdm_gui()
    var_0.close()


# Generated at 2022-06-26 09:48:00.498121
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    for _ in tqdm_gui(range(10)):
        pass



# Generated at 2022-06-26 09:48:01.603258
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    var_0 = tqdm_gui()
    var_0.close()
    del var_0


# Generated at 2022-06-26 09:48:14.614926
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from tqdm.gui import tqdm_gui

    obj_0 = {}
    if '*' in obj_0:
        del obj_0['*']

    with tqdm_gui(total=len(obj_0)) as _progressbar:
        for ii, ky in enumerate(obj_0):
            obj_0[ky] = None
            _progressbar.update(1)

# After running the following unit test, please run
# the previous test_tqdm_gui_clear() to make sure all
# windows are correctly closed
if __name__ == "__main__":  # pragma: no cover
    for _ in trange(3):
        test_case_0()
        print()

# Generated at 2022-06-26 09:48:16.868855
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.display()



# Generated at 2022-06-26 09:48:20.594022
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    start_time = time.time()
    print("Running test test_tqdm_gui_clear...")

    for i in tgrange(10):
        sleep(1)

    elapsed_time = time.time() - start_time
    print("Done running test test_tqdm_gui_clear.")
    print("Elapsed time:", elapsed_time)


# Generated at 2022-06-26 09:48:32.467362
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    var_0 = tqdm_gui()
    var_0._instances = [var_0]
    var_0.n = 10
    var_0._time = lambda : 0
    var_0.start_t = 0
    var_0.last_print_n = 0
    var_0.last_print_t = 0
    var_0.total = None
    var_0.xdata = []
    var_0.ydata = []
    var_0.zdata = []
    var_0.ax = None
    var_0.line1 = None
    var_0.line2 = None
    var_0.hspan = None
    var_0.disable = False
    var_0._loc_stack = []
    var_0.dynamic_ncols = None
    var_0

# Generated at 2022-06-26 09:48:35.425306
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    var_1 = tgrange()
    var_1.close()


# Generated at 2022-06-26 09:48:37.543258
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    from tqdm.gui import tqdm, trange

    for i in trange(10):
        sleep(0.1)

# Generated at 2022-06-26 09:48:39.226890
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    pass


# Generated at 2022-06-26 09:48:42.326701
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    var_1 = tqdm_gui()
    var_1.clear()


# Generated at 2022-06-26 09:49:24.504854
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # Initialize tqdm_gui_1 (span of 2 seconds)
    tqdm_gui_1 = tqdm_gui(8, dynamic_ncols=True,
                          smoothing=0, unit='B',
                          unit_scale=False, ascii=True,
                          miniters=1, mininterval=0.1,
                          leave=False, file=None,
                          gui=True, ncols=80,
                          disable=False, unit_divisor=1024,
                          initial=0, desc=None, total=None,
                          postfix=None, position=None,
                          maxinterval=10.0, mininterval_save=10)
    # Sleep for 1 second
    import time
    time.sleep(1)
    # call method close
   

# Generated at 2022-06-26 09:49:29.172206
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # Arrange
    tqdm_gui_1 = tqdm_gui()

    # Act
    tqdm_gui_1.clear()



# Generated at 2022-06-26 09:49:34.288211
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import pytest
    print("test_tqdm_gui_display")
    example_display = tqdm_gui(1)
    example_display.display()
    assert example_display.display() == None
    

# Generated at 2022-06-26 09:49:38.122847
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_2 = tqdm_gui()

    tqdm_gui_2.clear()



# Generated at 2022-06-26 09:49:41.868504
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:49:44.731042
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui_0 = tqdm_gui()
    assert tqdm_gui_0.disable == False
    assert tqdm_gui_0.mininterval == 0.1


# Generated at 2022-06-26 09:49:48.406013
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.close()


# Generated at 2022-06-26 09:49:52.760977
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:50:03.143012
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    import matplotlib as mpl
    import copy
    import random

    class tqdm_test(tqdm_gui):
        def __init__(self, *args, **kwargs):
            self.mpl = mpl
            self.plt = plt
            kwargs = kwargs.copy()
            kwargs['gui'] = True
            self.disable = False
            self.fmt = '[{bar}] {rate_fmt} {n_fmt}/{total_fmt}'
            self.dynamic_ncols = False
            self.leave = True
            self.unit = ''
            self.unit_scale = False
            self.mininterval = 0
            self.miniters = 0

# Generated at 2022-06-26 09:50:13.737541
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from collections import deque
    import numpy as np
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    
    plt.ioff()
    tqdm_gui_0 = tqdm_gui()
    n = tqdm_gui_0.n
    cur_t = tqdm_gui_0._time()
    tqdm_gui_0.start_t = cur_t
    tqdm_gui_0.last_print_n = n
    tqdm_gui_0.last_print_t = cur_t
    elapsed = cur_t - tqdm_gui_0.start_t
    delta_it = n - tqdm_gui_0.last_print_n
    delta_t = cur_t - tqdm_gui_0

# Generated at 2022-06-26 09:51:23.745564
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """
    Unit test for constructor of class tqdm_gui
    """
    from nose import with_setup
    from nose.plugins.attrib import attr
    # Clear previous instances in case of repeated runs
    tqdm_gui.clear = lambda *_, **__: None
    tqdm_gui.clear_instance = lambda *_, **__: None
    test_case_0_setup = test_case_0
    test_case_0_teardown = lambda : None
    @with_setup(test_case_0_setup, test_case_0_teardown)
    def test_none_type_arg():
        test_case_0()
    test_case_0_setup = test_case_0
    test_case_0_teardown = lambda : None

# Generated at 2022-06-26 09:51:26.876590
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:51:29.820836
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui_0 = tqdm_gui()



# Generated at 2022-06-26 09:51:34.831955
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .std import TqdmTypeError, TqdmKeyError
    try:
        tqdm_gui_0 = tqdm_gui()
        tqdm_gui_0.clear(ascii='|/-\\')
    except Exception:
        assert False, 'Expected pass, but fail.'
    finally:
        tqdm_gui_0.close()
        if del_attr: del tqdm_gui_0


# Generated at 2022-06-26 09:51:42.720745
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from pylab import plot
    from collections import deque

    xdata = []
    ydata = []
    plot(xdata,ydata)
    plot(xdata,ydata)
    xdata.append(1)
    ydata.append(2)
    plot(xdata,ydata)
    plot(xdata,ydata)
    xdata.popleft()
    ydata.popleft()
    plot(xdata,ydata)

# Generated at 2022-06-26 09:51:45.994296
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    return tqdm_gui_0.close()


# Generated at 2022-06-26 09:51:50.435848
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    with tqdm_gui_0.get_lock():
        tqdm_gui_0._instances.remove(tqdm_gui_0)
    old_toolbar = tqdm_gui_0.mpl.rcParams['toolbar']
    tqdm_gui_0.mpl.rcParams['toolbar'] = 'None'
    tqdm_gui_0.disable = True
    if not tqdm_gui_0.wasion:
        tqdm_gui_0.plt.ioff()
    if tqdm_gui_0.leave:
        tqdm_gui_0.display()

# Generated at 2022-06-26 09:51:54.437208
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui_obj = tqdm_gui(iterable=None)
    tqdm_gui_obj.display()

if __name__ == "__main__":
    test_case_0()
    test_tqdm_gui_display()

# Generated at 2022-06-26 09:52:01.068559
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    import matplotlib as mpl
    mpl.rcParams['toolbar']='None'
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()

# Generated at 2022-06-26 09:52:09.529224
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .utils import _decr_instances
    import matplotlib.pyplot as plt
    import matplotlib as mpl

    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.disable = False
    _decr_instances(tqdm_gui_0)
    tqdm_gui_0.disable = False
    tqdm_gui_0.leave = False
    tqdm_gui_0.disable = False
    tqdm_gui_0.leave = False
    tqdm_gui_0.mpl = mpl
    tqdm_gui_0.mpl = mpl
    tqdm_gui_0.plt = plt

# Generated at 2022-06-26 09:54:15.897134
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import warnings
    from unittest import TestCase, main

    with warnings.catch_warnings(record=True) as warn_queue:
        warnings.simplefilter('always')
        try:
            test_case_0()
        except Exception as e:
            msg = str(e)
            raise AssertionError(msg)
        else:
            assert 0 == len(warn_queue)

if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-26 09:54:28.914434
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """Unit test for method display of class tqdm_gui"""
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.disable = False
    tqdm_gui_1.total = 100
    tqdm_gui_1.start_t = 0
    tqdm_gui_1.last_print_t = 0
    tqdm_gui_1.last_print_n = 0
    tqdm_gui_1.n = 50
    tqdm_gui_1.lines = {}
    tqdm_gui_1.format_dict = {}
    tqdm_gui_1.format_dict['bar'] = '[{bar}]'
    tqdm_gui_1.format_dict['bar_format'] = '{desc}{percentage}{bar}'


# Generated at 2022-06-26 09:54:32.651884
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.display()


# Generated at 2022-06-26 09:54:36.181968
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.close()


# Generated at 2022-06-26 09:54:38.323422
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # - Testing
    # self.clear()
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.clear()



# Generated at 2022-06-26 09:54:48.925287
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    class tqdm_dummy:
        def __init__(self):
            self.disable = False
            self.n = 42
            self.last_print_n = 0
            self.start_t = 0
            self.last_print_t = 0
            self.total = 100
    # Test 1
    tqdm = tqdm_gui()
    tqdm.display(tqdm_dummy())
    # Test 2
    tqdm = tqdm_gui(total=None)
    tqdm.display(tqdm_dummy())


# Generated at 2022-06-26 09:54:54.759163
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:54:57.914282
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    try:
        tqdm_gui(range(5))
    except:
        assert False, "Failed to create tqdm_gui instance"


# Generated at 2022-06-26 09:55:00.811490
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    assert(hasattr(tqdm_gui_0, "clear"))


# Generated at 2022-06-26 09:55:09.384650
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    self = tqdm_gui()
    self.total = 100
    self.n = 0
    self.start_t = self._time()
    self.last_print_t = self.start_t
    self.last_print_n = 0
    self.disable = False
    self.wasion = True
    from collections import deque
    self.xdata = deque([])
    self.ydata = deque([])
    self.zdata = deque([])
    self.plt.pause(1e-9)
    self.display()
    self.total = None
    self.display()