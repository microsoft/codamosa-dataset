

# Generated at 2022-06-26 09:46:41.572214
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui()
    return

if __name__ == "__main__":
    test_case_0()
    test_tqdm_gui()
    def aFunc(n):
        if n <= 0:
            return
        aFunc(n-1)

    aFunc(5)

# Generated at 2022-06-26 09:46:47.829554
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import numpy as np
    import matplotlib
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches
    matplotlib.use('TkAgg')
    tqdm_gui_0 = tqdm_gui(total=100)
    tqdm_gui_0._time = lambda: np.random.random()
    tqdm_gui_0.n = np.random.randint(0, tqdm_gui_0.total)  # random integral
    tqdm_gui_0.last_print_n = np.random.randint(0, tqdm_gui_0.total)  # random integral
    tqdm_gui_0.last_print_t = 0
    tqdm_gui_0.start_t = 0
    tq

# Generated at 2022-06-26 09:46:55.464869
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    # Test if tqdm_gui_0._instances is empty after closing tqdm_gui_0
    tqdm_gui_0.close()
    # assert that tqdm_gui._instances is empty
    assert tqdm_gui._instances == []


# Generated at 2022-06-26 09:46:57.763004
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_instance = tqdm_gui()
    tqdm_gui_instance.clear()


# Generated at 2022-06-26 09:47:01.217326
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_obj = tqdm_gui()
    tqdm_gui_obj.close()


# Generated at 2022-06-26 09:47:11.979470
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    import matplotlib as mpl
    from warnings import warn
    # Make sure tqdm_gui is built
    from .std import TqdmExperimentalWarning, tqdm as std_tqdm
    from .utils import _range
    # import pickle

    colour = 'g'
    tqdm_gui_0 = tqdm_gui(colour=colour)
    tqdm_gui_0.disable = False

    # Restore toolbars
    mpl.rcParams['toolbar'] = tqdm_gui_0.toolbar
    # Return to non-interactive mode
    if not tqdm_gui_0.wasion:
        plt.ioff()

# Generated at 2022-06-26 09:47:16.624369
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    test_case_0()

if __name__ == '__main__':
    test_tqdm_gui()

# vim: set tabstop=4 shiftwidth=4:

# Generated at 2022-06-26 09:47:25.572988
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import numpy as np
    class args(object):
        disable = False
        leave = True
        mininterval = 0.25
        unit = "B"
        unit_scale = True
        ascii = False
        # unit_divisor = 1000
        # miniters = 1
        sma_window = 3
        last_print_t = "???"
        n = 0
        # ncols = 100
        # refresh_lock = "???"
        # position = 0
        # desc = None
        # desc_needed = 0
        # dynamic_ncols = False
        # smoothing = None
        # bar_format = None
        # bar_template = None
        # bar_length = None
        # postfix = None
        start_t = "???"
    self = tqdm_gui

# Generated at 2022-06-26 09:47:27.656571
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """
    Test case used to ensure the method display of class tqdm_gui works as intended
    """
    tqdm_gui_display = tqdm_gui()
    tqdm_gui_display.display()


# Generated at 2022-06-26 09:47:33.503568
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from collections import deque
    from tqdm.gui import tqdm_gui

    assert tqdm_gui._instances is not None
    assert tqdm_gui._instances is not None
    assert tqdm_gui._instances is not None
    assert tqdm_gui._instances is not None
    assert tqdm_gui._instances is not None
    assert tqdm_gui._instances is not None
    assert tqdm_gui._instances is not None
    assert tqdm_gui._instances is not None
    assert tqdm_gui._instances is not None


# Generated at 2022-06-26 09:47:49.121187
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.clear()


# Generated at 2022-06-26 09:47:52.275373
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import numpy

    tqdm.monitor_interval = 0.
    total_n = 60
    for n in tqdm(numpy.arange(1, total_n+1),total=60, smoothing=0.05):
        pass
    assert tqdm.n == total_n - 1

# Generated at 2022-06-26 09:48:05.325323
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui_1 = tqdm_gui(total = 100, display_format = "test")
    tqdm_gui_2 = tqdm_gui(total = 100, disable = False, unit = "test")
    tqdm_gui_3 = tqdm_gui(total = 100, dynamic_ncols = True, mininterval = 1)
    tqdm_gui_4 = tqdm_gui(total = 100, desc = "test", smoothing = 0.1, postfix = "test")
    tqdm_gui_5 = tqdm_gui(total = 100, bar_format = "test", initial = 0, leave = True, unit = "test", maxinterval = 3)

# Generated at 2022-06-26 09:48:06.503153
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    try:
        test_case_0()
    except:
        return False
    return True


# Generated at 2022-06-26 09:48:07.920545
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    test_case_0()

# Generated at 2022-06-26 09:48:12.459236
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_1 = tqdm_gui()

    tqdm_gui_1.close()
    assert (tqdm_gui_1.disable == True)


# Generated at 2022-06-26 09:48:19.407352
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.n = 2
    tqdm_gui_1.total = 3
    tqdm_gui_1.bar_format='{bar}{desc}{percentage}{r_bar}'
    tqdm_gui_1.desc = 'test1'
    tqdm_gui_1.display()
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.n = 1
    tqdm_gui_0.total = 1
    tqdm_gui_0.desc = 'test'
    tqdm_gui_0.bar_format='{bar}{desc}{percentage}{r_bar}'
    tqdm_gui_0.display()
    tqdm_gui

# Generated at 2022-06-26 09:48:29.677854
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_c = tqdm_gui()
    tqdm_gui_c.total = 100
    tqdm_gui_c.n = 1
    tqdm_gui_c.disable = False
    tqdm_gui_c.get_lock = lambda: None
    tqdm_gui_c._instances = [tqdm_gui_c]
    # tqdm_gui_c.get_lock = mock.MagicMock()
    # tqdm_gui_c._instances = mock.MagicMock()
    tqdm_gui_c.start_t = -1
    tqdm_gui_c.last_print_n = 1
    tqdm_gui_c.last_print_t = -1
    tqdm_gui_c.leave = False


# Generated at 2022-06-26 09:48:32.332273
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    test_case_0()
    return tqdm_gui_0.display()


# Generated at 2022-06-26 09:48:36.293487
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:49:02.487874
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    with _range(10) as t:
        t.set_description("Test tqdm_gui_display")
        t.display()


# Generated at 2022-06-26 09:49:08.221808
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.close()


# Generated at 2022-06-26 09:49:17.103108
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib as mpl
    mpl.rcParams['toolbar'] = 'None'
    import matplotlib.pyplot as plt

    # set up test environment
    plt.ion()
    fig, ax = plt.subplots(figsize=(9, 2.2))
    total = 100
    xdata = []
    ydata = []
    zdata = []
    line1, = ax.plot(xdata, ydata, color='b')
    line2, = ax.plot(xdata, zdata, color='k')
    ax.set_ylim(0, 0.001)
    ax.set_xlim(0, 100)
    ax.set_xlabel("percent")

# Generated at 2022-06-26 09:49:26.781909
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    try:
        from matplotlib import pyplot as plt  # NOQA
    except ImportError:  # pragma: no cover
        raise Exception("tqdm.gui requires matplotlib")
    try:
        from IPython import get_ipython  # NOQA
    except ImportError:  # pragma: no cover
        raise Exception("tqdm.gui requires ipython")
    try:
        get_ipython().run_line_magic("matplotlib", 'qt')  # NOQA
    except AttributeError:  # pragma: no cover
        raise Exception("tqdm.gui requires ipython")
    try:
        test_case_0()  # NOQA
    except Exception as e:
        assert e.__class__.__name__ == 'TypeError'

# Generated at 2022-06-26 09:49:31.132541
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # verify that a warning is raised for this experimental feature
    tqdm_gui(disable=0, gui=True).clear()


# Generated at 2022-06-26 09:49:44.243029
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    total = 5
    tqdm_gui_1 = tqdm_gui(total=total)
    assert len(tqdm_gui_1.xdata) == 0
    assert len(tqdm_gui_1.ydata) == 0
    assert len(tqdm_gui_1.zdata) == 0
    assert tqdm_gui_1.last_print_n == 0
    assert tqdm_gui_1.last_print_t == 0
    assert tqdm_gui_1.n == 0
    assert tqdm_gui_1.total == total
    assert tqdm_gui_1.disable is False
    assert tqdm_gui_1.unit == ""
    assert tqdm_gui_1.unit_scale == False

# Generated at 2022-06-26 09:49:57.898287
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # Initialize a tqdm_gui object
    tqdm_gui_0 = tqdm_gui()
    # Getting the parameters of the object
    n = tqdm_gui_0.n
    cur_t = tqdm_gui_0._time()
    elapsed = cur_t - tqdm_gui_0.start_t
    delta_it = n - tqdm_gui_0.last_print_n
    delta_t = cur_t - tqdm_gui_0.last_print_t
    total = tqdm_gui_0.total
    ax = tqdm_gui_0.ax
    y = delta_it / delta_t
    z = n / elapsed
    # Call the method
    tqdm_gui_0.display()
    # Check the returned value
   

# Generated at 2022-06-26 09:50:11.257896
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    total = 5.0
    n = 2.0
    cur_t = 5.0
    elapsed = 5.0
    delta_it = 2.0
    delta_t = 5.0
    xdata = [2, 3]
    ydata = [0.4, 0.6]
    zdata = [0.4, 0.6]
    ax = tqdm_gui.mpl.pyplot.subplot()
    line1 = tqdm_gui.mpl.pyplot.Line2D([], [])
    line2 = tqdm_gui.mpl.pyplot.Line2D([], [])
    hspan = tqdm_gui.plt.axhspan(0, 0.001, xmin=0, xmax=0, color='g')

    t = tqdm_gui

# Generated at 2022-06-26 09:50:21.523850
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # Create an instance of class tqdm_gui
    tracker = tqdm_gui()

    # Set tracker attributes
    tracker.mininterval = 0.5
    tracker.n = 1.0
    tracker.last_print_n = 0
    tracker.last_print_t = 0
    tracker.xdata = []
    tracker.unit = ''
    tracker.unit_scale = False
    tracker.disable = False
    tracker.total = None
    tracker.leave = False
    tracker.start_t = 0
    tracker._time = lambda: 1.0
    tracker.ydata = []
    tracker.zdata = []
    tracker.mininterval = 0.5
    tracker.gui = True
    tracker.toolbar = mpl.rcParams['toolbar']
    tracker.ax = None
    tracker.w

# Generated at 2022-06-26 09:50:30.985755
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # Instantiate tqdm_gui object
    tqdm_gui_1 = tqdm_gui()
    # instantiate buffer object
    buffer_1 = io.StringIO()
    # Redirect stdout to buffer_1
    sys.stdout = buffer_1
    
    # This is needed to remove the output of tqdm from the test output
    try:
        # Displaying the tqdm_gui amount
        tqdm_gui_1.display()
    finally:
        sys.stdout = sys.__stdout__
    # Assert the content of the buffer is correct
    assert buffer_1.getvalue() == ''

# Generated at 2022-06-26 09:51:21.051639
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_1 = tqdm_gui(total=1)
    tqdm_gui_1.update(1)
    tqdm_gui_1.close()



# Generated at 2022-06-26 09:51:25.032048
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # Test with no arguments
    try:
        test_case_0()
    except TypeError as e:
        print(e)

test_tqdm_gui_close()

# Generated at 2022-06-26 09:51:28.297646
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear(): pass
#     tqdm_gui_clear = tqdm_gui()
#     tqdm_gui_clear.clear()

# Generated at 2022-06-26 09:51:36.879550
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import sys
    # Try to import matplotlib without error
    try:
        import matplotlib as mpl
        mpl.use('module://theano.tests.unittest_tools.GuiTestProgram')
    except:
        print("matplotlib not loaded (probably due to DISPLAY error)", file=sys.stderr)
        return

    # with warnings.catch_warnings(record=True) as w:
    #     import matplotlib

    # Check if matplotlib is loaded
    try:
        import matplotlib.pyplot as plt
        plt.figure()
        plt.close()
    except:
        print("matplotlib not loaded (probably due to DISPLAY error)", file=sys.stderr)
        return

    # Check if we can import tqdm_gui
    import t

# Generated at 2022-06-26 09:51:39.231135
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    pbar = tqdm_gui()
    pbar.display()



# Generated at 2022-06-26 09:51:42.660917
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # test for class tqdm
    test_case_0()
    # test for class tqdm_gui
    test_case_1()

if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-26 09:51:45.917287
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.clear()


# Generated at 2022-06-26 09:51:50.435058
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import sys
    import unittest as ut
    import matplotlib.pyplot as plt

    class TestTqdm(ut.TestCase):
        def setUp(self):
            self.t = tqdm_gui()

        def test_gui(self):
            self.assertEqual("gui", self.t.gui)

        def test_get_lock(self):
            lock = self.t.get_lock()
            self.assertIn("RLock", str(lock), 'self.t.get_lock() returns {}'.format(str(lock)))

        def test_get_free_pos(self):
            self.assertEqual(None, self.t.get_free_pos())

        def test_set_lock(self):
            lock = self.t.get_lock()
            self.assertEqual

# Generated at 2022-06-26 09:51:53.478426
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_0 = tqdm(total = 2)
    tqdm_gui_0.clear()
    tqdm_gui_0.close()



# Generated at 2022-06-26 09:52:00.225634
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from collections import Iterator
    from tqdm.utils import _term_move_up
    from .std import tqdm_gui
    # prepare for the case
    for attr in ['disable', 'n', 'last_print_n', 'unit_scale']:
        setattr(tqdm_gui, attr, True)
    tqdm_gui.unit = "it"
    desc, total = "", 10
    iterable = range(total)
    iterable, tqdm_gui.iterable = (iterable, iterable)
    tqdm_gui.n, tqdm_gui.last_print_n, tqdm_gui.miniters = (0, 0, 0)
    tqdm_gui.disable = tqdm_gui.n = tqdm_gui.last_print_