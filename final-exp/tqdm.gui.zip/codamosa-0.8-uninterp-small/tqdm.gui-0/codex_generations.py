

# Generated at 2022-06-26 09:46:40.715166
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
        tqdm_gui_0 = tqdm_gui()
        for i in trange(10):
            pass
        tqdm_gui_0.clear()
        tqdm_gui_0.close()


# Generated at 2022-06-26 09:46:46.581937
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    total = 100
    tqdm_g_0 = tqdm_gui(total=total)
    # get_lock(), __len__(), format_meter() should return correct results
    assert not tqdm_g_0.get_lock()
    assert tqdm_g_0.__len__() == total
    assert tqdm_g_0.format_meter() is not None


# Generated at 2022-06-26 09:46:53.511381
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    for i in tqdm_gui(range(3)):
        # Do nothing
        # print("tqdm_gui: %d" %i)
        pass

if __name__ == "__main__":
    # test_tqdm_gui()
    test_case_0()

# Generated at 2022-06-26 09:46:57.359945
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """
    Test our class tqdm_gui.
    """
    print("Testing class tqdm_gui")
    test_case_0()

test_tqdm_gui()



# Generated at 2022-06-26 09:47:10.397233
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from tqdm._utils import _term_move_up
    from tqdm import tgrange
    from tqdm._utils import _term_width
    import time

    mpl = tqdm_gui_0.mpl
    plt = tqdm_gui_0.plt
    with mpl.rc_context():
        plt.ion()
        for i in tgrange(51):
            time.sleep(0.2)

    with mpl.rc_context():
        plt.ion()
        for i in tgrange(51):
            time.sleep(0.2)

if __name__ == "__main__":
    import sys
    import matplotlib
    # Initialize Matplotlib backend

# Generated at 2022-06-26 09:47:11.875980
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui().close()



# Generated at 2022-06-26 09:47:24.191797
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    # ========================
    # Setup test parameters
    # ========================
    # Initialize the class instance.
    tqdm_gui_0 = tqdm_gui()
    # Store the parameter `disable` before overwriting it.
    tqdm_gui_0_disable = tqdm_gui_0.disable
    # Store the parameter `toolbar` before overwriting it.
    tqdm_gui_0_toolbar = tqdm_gui_0.toolbar
    # Store the parameter `wasion` before overwriting it.
    tqdm_gui_0_wasion = tqdm_gui_0.wasion
    # Store the parameter `fig` before overwriting it.
    tqdm_gui_0_fig = tqdm_

# Generated at 2022-06-26 09:47:33.405470
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from collections import deque
    tqdm_gui_1 = tqdm_gui()
    # saving attributes for test and restoring at the end
    tqdm_gui_1.toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'
    tqdm_gui_1.disable = False
    tqdm_gui_1.last_print_n = 0
    tqdm_gui_1.unit = "it"
    tqdm_gui_1.unit_scale = False
    tqdm_gui_1.leave = False
    tqdm_gui_1.mininterval = 0.5
    tqdm_gui_1.miniters = 1

# Generated at 2022-06-26 09:47:39.605749
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # Constructor for class tqdm_gui
    tqdm_gui_1 = tqdm_gui()
    # Call method close of class tqdm_gui
    tqdm_gui_1.close()
    # AssertionError: ".close() invoked without disable=True"



# Generated at 2022-06-26 09:47:49.810696
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # checking square bar in "for loop" mode
    tqdm_gui_0 = tqdm_gui() 
    tqdm_gui_0.display()
    tqdm_gui_0.close()
    
    # checking square bar in "until loop" mode
    tqdm_gui_1 = tqdm_gui(total=100, leave=True)
    tqdm_gui_1.display()
    tqdm_gui_1.close()


# Generated at 2022-06-26 09:48:26.273654
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # function will update self.xdata
    # function will update self.ydata
    # function will update self.zdata
    # function will update self.line1
    # function will update self.line2
    # function will update self.ax
    # function will update self.hspan
    pass


if __name__ == "__main__":
    # NOTE: in interactive mode, it's recommended to use `tqdm.gui.main()`
    #       that will run tests in a new process (preventing crashes)
    test_case_0()
    test_tqdm_gui_display()

# Generated at 2022-06-26 09:48:32.660758
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    def func():
        """
        Unit test for method clear of class tqdm_gui
        """
        from .std import tqdm_gui
        return tqdm_gui
    # Initial parameters for test
    test_tqdm_gui_clear_0 = tqdm_gui()
    # Call the function under test
    assert func() == test_tqdm_gui_clear_0, "";


# Generated at 2022-06-26 09:48:41.661843
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import numpy as np
    tqdm_gui_0 = tqdm_gui(total = 100)
    tqdm_gui_0.n = 0
    tqdm_gui_0.last_print_n = 0
    tqdm_gui_0.last_print_t = np.random.randint(0, 100)
    tqdm_gui_0.start_t = np.random.randint(0, 3)
    tqdm_gui_0.total = 100

# Generated at 2022-06-26 09:48:52.220865
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from io import StringIO
    from tqdm.gui import tgrange, trange
    import matplotlib as mpl
    # import matplotlib.pyplot as plt
    # import numpy as np

    @tqdm_gui
    def test_update():
        for x in tgrange(10):
            pass

    # plt.ioff()

    # save stdout
    stdout_ = sys.stdout
    sys.stdout = StringIO()

    # Test
    test_update()
    # test_update()
    # test_update()

    # restore stdout
    sys.stdout = stdout_

    # Test
    # print(plt.isinteractive())
    # plt.show()



# Generated at 2022-06-26 09:48:58.387061
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui_0 = tqdm_gui()
    # Test function
    tqdm_gui_0.display(desc="Test display of class tqdm_gui")


if __name__ == "__main__":
    test_tqdm_gui_display()

# Generated at 2022-06-26 09:49:00.411285
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    for _ in tqdm_gui(range(3)):
        pass

# Generated at 2022-06-26 09:49:08.535353
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import collections
    import matplotlib as mpl
    import matplotlib.pyplot as plt

    pbar = tqdm_gui(total=10, unit='iB', unit_scale=True)

    for i in pbar:
        pbar.display()


# Generated at 2022-06-26 09:49:17.202657
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """
    Test case for method display of class tqdm_gui
    """

    # Initialize a tqdm_gui object
    tqdm_gui_0 = tqdm_gui()

    # Use decorator to run the display method
    @tqdm_gui.write_decorator
    def display():
        """
        Custom display method for tqdm_gui
        """

        # Get instance for tqdm_gui
        tqdm_gui_0 = tqdm.get_instances()[0]

        # Compute rate of iteration
        n = tqdm_gui_0.n
        cur_t = tqdm_gui_0._time()
        elapsed = cur_t - tqdm_gui_0.start_t

# Generated at 2022-06-26 09:49:26.807524
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui_1 = tqdm_gui()
    assert tqdm_gui_1.disable == False
    assert tqdm_gui_1.mininterval == 0.5
    assert tqdm_gui_1.leave == True
    assert tqdm_gui_1.gui == True
    assert tqdm_gui_1.desc == None
    assert tqdm_gui_1.desc_str == None
    assert tqdm_gui_1.last_print_t == None
    assert tqdm_gui_1.last_print_n == None
    assert tqdm_gui_1.last_print_n == None
    assert tqdm_gui_1.leave == True
    assert tqdm_gui_1.get_lock() == 'RLock'
    assert tqdm

# Generated at 2022-06-26 09:49:32.477564
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm_gui(total=500) as t:
        for i in range(500):
            t.update(1)
            t.set_description("Processing")


# Generated at 2022-06-26 09:50:04.923745
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time
    try:
        with tqdm_gui(total=100) as t:
            for i in range(100):
                time.sleep(0.1)
                t.update(1)
    except Exception as e:
        print(e)


# Generated at 2022-06-26 09:50:12.046687
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_obj = tqdm_gui()
    # Asserting the call with no parameters
    tqdm_gui_obj.clear()
    # Asserting the call with invalid parameter
    # AssertionError: TypeError not raised
    # tqdm_gui_obj.clear(1)
    # AssertionError: TypeError not raised
    # tqdm_gui_obj.clear(1, 2)
    # AssertionError: TypeError not raised
    # tqdm_gui_obj.clear(1, 2, 3)


# Generated at 2022-06-26 09:50:20.079421
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():

    # Test for python2.7
    try:
        output = tqdm_gui()
    except ImportError:
        output = None
    assert output is not None

    # Test for python3.6
    try:
        output = tqdm_gui()
    except ImportError:
        output = None
    assert output is not None

    # Test for python3.6 with input kwargs
    try:
        output = tqdm_gui(1, 2, 3)
    except ImportError:
        output = None
    assert output is not None



# Generated at 2022-06-26 09:50:23.239257
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.close()


# Generated at 2022-06-26 09:50:28.008321
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # Creation of tqdm_gui_0
    tqdm_gui_0 = tqdm_gui()
    # Clear method of tqdm_gui_0
    tqdm_gui_0.clear()


# Generated at 2022-06-26 09:50:31.622267
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.clear()


# Generated at 2022-06-26 09:50:40.404107
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from collections import deque
    import matplotlib as mpl
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots()
    total = 52
    xdata = []
    ydata = []
    zdata = []
    # instant rate
    y = 23  # delta_it / delta_t
    # overall rate
    z = 13  # n / elapsed
    cur_t = 3.6
    ax.set_ylim(0, 0.001)
    # progressbar
    hspan = plt.axhspan(0, 0.001, xmin=0, xmax=0, color='g')
    ax.set_xlim(0, 100)
    ax.set_xlabel("percent")

# Generated at 2022-06-26 09:50:45.658652
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui.__new__(tqdm_gui)
    tqdm_gui_0.disable = true
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:50:50.735674
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    for i in tqdm_gui(range(10)):
        tqdm_gui_1 = tqdm_gui()

# tests: https://github.com/noamraph/tqdm/issues/8

# Generated at 2022-06-26 09:50:56.440393
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # test empty display
    _test_tqdm_gui_display(3, 0, False)
    # test not empty display
    _test_tqdm_gui_display(3, 10, True)


# Generated at 2022-06-26 09:51:56.770610
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import numpy as np
    n = 100
    tqdm_gui_1 = tqdm_gui(n, mininterval=0, desc='Testing GUI close()')
    for i in _range(n):
        tqdm_gui_1.update()
        time.sleep(0.01)
    tqdm_gui_1.close()
    if tqdm_gui_1.disable and tqdm_gui_1.__len__() == 0:
        print("GUI close method works like a charm!")
    else:
        print("GUI close method failed!")



# Generated at 2022-06-26 09:52:06.751710
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        tgp = tqdm_gui(total=50)
    except Exception:
        assert False, "tqdm_gui(total=50) failed, aborting"

    try:
        tgp.close()
    except Exception:
        assert False, "tqdm_gui.close() failed, aborting"

    try:
        assert tgp.disable, "tqdm_gui.disable is False, aborting"
    except Exception:
        assert False, "tqdm_gui.disable failed, aborting"


# Generated at 2022-06-26 09:52:10.033383
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    with tqdm(enumerate(range(10000)), unit="B") as t:
        for j,i in t:
            t.update()
            if j > 1:
                break


# Generated at 2022-06-26 09:52:11.971450
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui_0 = tqdm_gui()


# Generated at 2022-06-26 09:52:20.396120
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # Unused arguments are needed to create the objects.
    tqdm_gui_1 = tqdm_gui(0, unit_scale=True, disable=False)
    tqdm_gui_1.disable = False
    tqdm_gui_1.last_print_n = 0
    tqdm_gui_1.total = True
    tqdm_gui_1.close()
    # Check that the last_print_n has been set to None after calling the method.
    assert tqdm_gui_1.last_print_n is None


# Generated at 2022-06-26 09:52:25.047941
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm_gui(total=10) as pbar:
        for i in range(10):
            pbar.update()


# Generated at 2022-06-26 09:52:28.741916
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_1 = tqdm_gui()
    tol = 1e-8
    tqdm_gui_1.close()
    assert tqdm_gui_1.disable



# Generated at 2022-06-26 09:52:32.267588
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    This method tests tqdm_gui with a for loop
    """
    tqdm_gui_1 = tqdm_gui()
    for i in range(100):
        value = (i + 1)/100
        tqdm_gui_1.update(value)
    tqdm_gui_1.close()


# Generated at 2022-06-26 09:52:36.085067
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_close_0 = tqdm_gui()
    tqdm_gui_close_0.close()


# Generated at 2022-06-26 09:52:45.120981
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib.pyplot as plt
    from io import BytesIO

    # Test 1
    t = tqdm_gui()
    t.close()
    p = BytesIO()
    plt.savefig(p, format='png')

# Generated at 2022-06-26 09:54:41.494456
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():

    import matplotlib as mpl
    import matplotlib.pyplot as plt

    # Figure declaration
    fig, ax = plt.subplots(figsize=(9, 2.2))
    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'

    # Initialized parameters (overriding the __init__ method)
    n = 1
    cur_t = 0.5
    elapsed = 0.5
    delta_it = 0
    delta_t = 0
    total = None
    xdata = deque([0])
    ydata = deque([0])
    zdata = deque([0])
    line1, = ax.plot(xdata, ydata, color='b')

# Generated at 2022-06-26 09:54:48.004718
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # create empty tqdm_gui instance
    tqdm_gui_0 = tqdm_gui()

    # check if tqdm_gui instance is not empty
    if tqdm_gui_0 is not None:
        # call clear method with proper arguments
        # clear method has no defined return type.
        tqdm_gui_0.clear()



# Generated at 2022-06-26 09:54:57.601231
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # tqdm_gui_1 = tqdm_gui()
    # tqdm_gui_1.display()

    # tqdm_gui_2 = tqdm_gui()
    # tqdm_gui_2.display(1,2,3)

    tqdm_gui_3 = tqdm_gui()
    tqdm_gui_3.display(1,2,3,4)

    # tqdm_gui_4 = tqdm_gui()
    # tqdm_gui_4.display(1,2,3,4,5)

# tqdm_gui_display()


# Generated at 2022-06-26 09:55:09.987970
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_1 = tqdm_gui(total=1)
    tqdm_gui_2 = tqdm_gui(total=-1)
    tqdm_gui_3 = tqdm_gui(total=1, disable=False)
    tqdm_gui_4 = tqdm_gui(total=1, disable=False)
    tqdm_gui_5 = tqdm_gui(total=1, disable=False)
    tqdm_gui_6 = tqdm_gui(total=1, disable=False)
    tqdm_gui_7 = tqdm_gui(total=1, disable=False)
    tqdm_gui_8 = tqdm_gui(total=1, disable=False)

# Generated at 2022-06-26 09:55:14.023406
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.clear()


# Generated at 2022-06-26 09:55:17.783949
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.clear()


# Generated at 2022-06-26 09:55:21.669644
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui_1 = tqdm_gui(desc='Test of tqdm_gui')
    tqdm_gui_1.total = 100
    assert tqdm_gui_1.total == 100
    assert tqdm_gui_1.unit_scale
    # TODO: Test display()
    # TODO: Test close()

# Generated at 2022-06-26 09:55:34.203859
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """Unit test for constructor of class tqdm_gui"""
    # import tqdm.gui
    # with tqdm.gui.tqdm(total=100) as t:
    #     for i in range(100):
    #         t.update(1)

    import time

    total = 100
    with tqdm_gui(total=total) as t:
        for i in range(total):
            time.sleep(0.2)
            t.update(1)
    # from matplotlib import pyplot as plt
    # plt.show()


if __name__ == "__main__":
    """Run tests for the tqdm_gui class"""
    print("Testing tqdm_gui module")
    test_tqdm_gui()

# vim: set ts=4 sw=4 sts

# Generated at 2022-06-26 09:55:40.650097
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui().clear()  # To avoid error: AttributeError: 'tqdm_gui' object has no attribute 'clear'
    sys.stdout.write("\nTest clear(): Done\n")

test_case_0()
test_tqdm_gui_clear()

# Generated at 2022-06-26 09:55:43.182923
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # initialize instance of tqdm_gui
    #test = tqdm_gui()
    tqdm_gui()
    # invoke close of tqdm_gui
    #test.close()
    tqdm_gui.close

