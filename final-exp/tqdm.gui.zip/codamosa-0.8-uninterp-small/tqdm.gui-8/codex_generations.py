

# Generated at 2022-06-26 09:46:31.415565
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    for _ in tqdm_gui(tgrange()):
        pass


# Generated at 2022-06-26 09:46:34.585532
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    var_0 = ttqdm_gui()
    var_0.clear()


# Generated at 2022-06-26 09:46:37.524683
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # Create a new instance of class tqdm_gui
    assert isinstance(var_0, tqdm_gui)


# Generated at 2022-06-26 09:46:40.951148
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    var_0 = tgrange()
    var_0.close()


# Generated at 2022-06-26 09:46:49.392294
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # test case
    var_0 = tqdm_gui()
    var_0.close()
    var_1 = tqdm_gui()
    var_1.close()
    var_2 = tqdm_gui()
    var_2.close()
    var_3 = tqdm_gui()
    var_3.close()
    var_4 = tqdm_gui()
    var_4.close()
    var_5 = tqdm_gui()
    var_5.close()
    var_6 = tqdm_gui()
    var_6.close()
    var_7 = tqdm_gui()
    var_7.close()
    var_8 = tqdm_gui()
    var_8.close()
    var_9 = tqdm_gui()
    var

# Generated at 2022-06-26 09:46:52.582639
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    var_0 = tqdm_gui()
    var_0.close()


# Generated at 2022-06-26 09:47:01.416218
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # Initialization
    n = 10
    total = 10
    mininterval = 0.5
    miniters = 1
    desc = 'test'
    ncols = 120
    position = None
    leave = False
    unit = 'it'
    dynamic_ncols = False
    unit_scale = False
    colours = 'm'
    var_1 = tqdm_gui(n, total=total, mininterval=mininterval, miniters=miniters,
        desc=desc, ncols=ncols, position=position, leave=leave, unit=unit,
        dynamic_ncols=dynamic_ncols, unit_scale=unit_scale,
        colour=colours, gui=True)
    
    # Execution
    var_1.close()



# Generated at 2022-06-26 09:47:12.064926
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    xdata = []
    # self.ydata = []
    # self.zdata = []
    # self.line1, = ax.plot(self.xdata, self.ydata, color='b')
    # self.line2, = ax.plot(self.xdata, self.zdata, color='k')
    ax = [0,0]
    line1 = [0,0]
    line2 = [0,0]
    # instantaneous rate
    y = 1.0
    # overall rate
    z = 1.0
    # update line data
    xdata.append(100.0 * y * z / 1.0)

    # Discard old values
    # xmin, xmax = ax.get_xlim()
    # if (not total) and elapsed > xmin * 1.1:


   

# Generated at 2022-06-26 09:47:16.057945
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    var_0 = tgrange()
    var_1 = var_0.clear()
    assert var_1 is None


# Generated at 2022-06-26 09:47:18.254226
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    var_0 = tgrange()
    var_0.clear()


# Generated at 2022-06-26 09:47:42.468312
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui_0 = tqdm_gui()
    assert tqdm_gui_0.disable == False
    assert tqdm_gui_0.mininterval == 0.5
    assert tqdm_gui_0.miniters == 1
    assert tqdm_gui_0.total == None
    assert tqdm_gui_0.leave == False
    assert tqdm_gui_0.sp == None
    assert tqdm_gui_0.gui == True
    assert tqdm_gui_0.last_print_n == 0
    assert tqdm_gui_0.n == 0
    assert tqdm_gui_0.last_print_t == 0
    assert tqdm_gui_0.start_t == 0
    assert tqdm_gui_0.unit == None

# Generated at 2022-06-26 09:47:45.555955
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.close()


# Generated at 2022-06-26 09:47:52.494118
# Unit test for method close of class tqdm_gui

# Generated at 2022-06-26 09:47:56.248565
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    t = tqdm_gui()
    t.close()
    assert t.disable



# Generated at 2022-06-26 09:48:03.378325
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    t = tqdm_gui()
    t.__init__(total=100)
    t.display()
    t.moveto = 1
    t.display()
    t.__init__()
    t.display()
    t.__setattr__('total', 10000)
    t.display()
    t.__setattr__('total', None)
    t.display()


# Generated at 2022-06-26 09:48:10.382101
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import pytest
    from .gui import tqdm_gui
    from .utils import _range

    for l in [10, 100, 1000]:
        with pytest.raises(Exception):
            for _ in tqdm_gui(_range(l)):
                tqdm_gui.clear()

# Generated at 2022-06-26 09:48:13.955151
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm_gui(total=100) as t:
        for i in tqdm_gui(range(100)):
            t.set_description("test_tqdm_gui")
            t.update()


# Generated at 2022-06-26 09:48:25.171852
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui_1 = tqdm_gui(range(10))
    tqdm_gui_1.disable = False
    tqdm_gui_1.start()
    for i in range(10):
        tqdm_gui_1.update(1)
    tqdm_gui_1.close()


if __name__ == '__main__':
    test_case_0()
    test_tqdm_gui_display()

# Generated at 2022-06-26 09:48:38.985282
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    try:
        tqdm_gui_0.close()
    except:
        assert False
    assert tqdm_gui_0.disable == True
    assert tqdm_gui_0.wasion == False
    # test after leave
    tqdm_gui_0 = tqdm_gui()
    try:
        tqdm_gui_0.close(leave = True)
    except:
        assert False
    assert tqdm_gui_0.disable == True
    assert tqdm_gui_0.wasion == False
    # test with toolbar
    tqdm_gui_0 = tqdm_gui()
    try:
        tqdm_gui_0.close()
    except:
        assert False
    assert tqdm

# Generated at 2022-06-26 09:48:51.562627
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .utils import _term_move_up
    from .gui import tqdm_gui

    tqdm_gui(5)
    tqdm_gui(5, bar_format='{l_bar}{bar}|{n}')
    tqdm_gui(5, mininterval=1, miniters=1)
    tqdm_gui(5, miniters=1)
    tqdm_gui(5, miniters=1, leave=True)
    tqdm_gui(5, miniters=1, leave=True, dynamic_ncols=True)
    tqdm_gui(5, miniters=1, leave=True, dynamic_ncols=False)
    tqdm_gui(5, miniters=1, dynamic_ncols=True)
    t

# Generated at 2022-06-26 09:49:19.091585
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:49:26.446378
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .utils import DiscreteInvWc
    from .std import tqdm as tqdm_std

    size = 1000000
    values = DiscreteInvWc(size=size, p=0.001)
    tqdm_gui_0 = tqdm_gui(total=size, mininterval=0.1, leave=True)
    for i in values:
        if i == 1:
            tqdm_gui_0.clear()
        tqdm_gui_0.update(1)

    assert tqdm_gui_0.n == size

    tqdm_std_0 = tqdm_std(total=size, mininterval=0.1, leave=True)
    for i in values:
        if i == 1:
            tqdm_std_0.clear()
        tq

# Generated at 2022-06-26 09:49:32.095722
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from tqdm import tqdm

    # no exceptions should occur

    tqdm_gui_0 = tqdm()
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:49:43.344046
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from io import StringIO
    from tqdm.gui import tqdm_gui
    import sys

# Generated at 2022-06-26 09:49:47.335611
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # Testing for possible bug #971
    tqdm_gui_1 = tqdm_gui(total=None)
    tqdm_gui_1._last_print_t = tqdm_gui_1._time()
    tqdm_gui_1.display()

    tqdm_gui_2 = tqdm_gui(total=100)
    tqdm_gui_2._last_print_t = tqdm_gui_2._time()
    tqdm_gui_2.display()

# Generated at 2022-06-26 09:49:55.422161
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_close = tqdm_gui()
    tqdm_gui_close.disable = False
    assert tqdm_gui_close.disable == False, tqdm_gui_close.disable
    tqdm_gui_close.close()
    assert tqdm_gui_close.disable == True, tqdm_gui_close.disable



# Generated at 2022-06-26 09:50:04.565252
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    t = tqdm_gui()
    assert hasattr(t, "clear")
    assert callable(getattr(t, "clear"))
    try:
        t.clear()
    except Exception as e:
        raise Exception('tqdm_gui.clear(): test failed!', e)
    else:
        print('tqdm_gui.clear(): test OK!')

# Generated at 2022-06-26 09:50:14.333024
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # create a tqdm_gui instance
    tqdm_gui_0 = tqdm_gui()
    # check the value of its last_print_n (expected: 0)
    assert (tqdm_gui_0.last_print_n == 0)
    # check the value of its last_print_t (expected: 0)
    assert (tqdm_gui_0.last_print_t == 0)
    # check the value of its disable (expected: False)
    assert (tqdm_gui_0.disable == False)
    # check the value of its unit (expected: None)
    assert (tqdm_gui_0.unit is None)
    # check the value of its unit_scale (expected: False)
    assert (tqdm_gui_0.unit_scale == False)
    #

# Generated at 2022-06-26 09:50:23.160270
# Unit test for method close of class tqdm_gui

# Generated at 2022-06-26 09:50:33.232687
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # Initialize tqdm_gui object
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.display()


if __name__ == "__main__":
    from time import sleep

    # Testing of the tqdm_gui object
    test_case_0()
    # Testing of the display method of the tqdm_gui object
    test_tqdm_gui_display()

    tqdm_gui_0 = tqdm_gui()
    for n in tqdm_gui_0(range(10), desc='test'):
        sleep(1e-4)
    for n in tqdm_gui_0(range(50), desc='test with total', total=50):
        sleep(1e-4)