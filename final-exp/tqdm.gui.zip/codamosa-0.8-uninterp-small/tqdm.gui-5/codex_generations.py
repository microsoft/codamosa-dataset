

# Generated at 2022-06-26 09:46:34.846112
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # Silent tqdm instance
    tqdm_gui_1 = tqdm_gui(disable=True)

    # With total
    # Create tqdm_gui instance
    tqdm_gui_2 = tqdm_gui(total=5)
    # Test if instance attribute n is equal to 0
    assert(tqdm_gui_2.n == 0)
    # Test if instance attribute total is equal to 5
    assert(tqdm_gui_2.total == 5)
    # Test if instance attribute disable is equal to False
    assert(tqdm_gui_2.disable == False)
    # Test if instance attribute leave is equal to False
    assert(tqdm_gui_2.leave == False)
    # Test if instance attribute mininterval is equal to 0.1

# Generated at 2022-06-26 09:46:45.883327
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from collections import Counter
    from warnings import catch_warnings

    from .gui import trange
    from .std import tqdm

    with catch_warnings(record=True) as w:
        for _ in trange(4):
            pass

    assert len(w) == 1
    assert "GUI is" in str(w[0].message)
    assert __name__ in str(w[0].filename)

    with catch_warnings(record=True) as w:
        for _ in tqdm(range(1), disable=False, gui=True):
            pass

    assert len(w) == 1
    assert "GUI is" in str(w[0].message)
    assert __name__ in str(w[0].filename)


# Generated at 2022-06-26 09:46:53.196820
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.display()
    tqdm_gui_1.close()


if __name__ == '__main__':
    test_case_0()
    test_tqdm_gui_display()

# Generated at 2022-06-26 09:46:57.194861
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from nose.tools import assert_equal
    tqdm_gui_1 = tqdm_gui()
    result = tqdm_gui_1.clear()
    assert_equal(result, None)


# Generated at 2022-06-26 09:47:10.283538
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_close_instance = tqdm_gui()
    tqdm_gui_close_return_disable = tqdm_gui_close_instance.disable
    tqdm_gui_close_return_wasion = tqdm_gui_close_instance.wasion
    tqdm_gui_close_return_leave = tqdm_gui_close_instance.leave
    tqdm_gui_close_return_fig = tqdm_gui_close_instance.fig
    tqdm_gui_close_return_plt = tqdm_gui_close_instance.plt
    tqdm_gui_close_return_mpl = tqdm_gui_close_instance.mpl
    tqdm_gui_close_return_toolbar = tqdm_gui_close_instance.tool

# Generated at 2022-06-26 09:47:13.896036
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    test_case_0()


# Direct run
if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 09:47:20.057380
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    # Construct an instance of tqdm_gui
    tqdm_gui_0 = tqdm_gui()
    # Unit test for method close of class tqdm_gui
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:47:23.627471
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.clear()


# Generated at 2022-06-26 09:47:33.234296
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():

    from collections import deque

    from matplotlib import pyplot as plt
    import sys

    def test_func(n, arg2, arg3=1, arg4="hi"):
        # Print iterations progress
        print("\r{0:3.0f}%".format(100. * i / n), end='')
        sys.stdout.flush()

    total = 20

    # Create data
    xdata = list(range(total))
    ydata = [i + random() for i in xdata]

    # Create figure
    plt.ion()
    fig, ax = plt.subplots()
    # ax.legend()

    # Create a line
    line1, = plt.plot(xdata, ydata, label='test')
    fig.legend(loc='center right')


# Generated at 2022-06-26 09:47:43.418586
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_1 = tqdm_gui(initial=0)
    tqdm_gui_2 = tqdm_gui(desc='desc')
    tqdm_gui_3 = tqdm_gui(total=3)
    tqdm_gui_4 = tqdm_gui(position=0)
    tqdm_gui_5 = tqdm_gui(dynamic_ncols=True)
    tqdm_gui_6 = tqdm_gui(mininterval=0.1)
    tqdm_gui_7 = tqdm_gui(maxinterval=30)
    tqdm_gui_8 = tqdm_gui(miniters=10)
    tqdm_gui_9 = t

# Generated at 2022-06-26 09:47:59.295823
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    test_case_0()


if __name__ == "__main__":
    import nose
    nose.runmodule()

# Generated at 2022-06-26 09:48:02.499944
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_1 = tqdm_gui(total=100)
    tqdm_gui_1.close()


# Generated at 2022-06-26 09:48:06.599937
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from unittest.mock import MagicMock

    tqdm_gui_close = tqdm_gui()
    tqdm_gui_close.disable = False
    tqdm_gui_close.toolbar = "None"
    tqdm_gui_close.wasion = False
    tqdm_gui_close.lock = MagicMock()
    tqdm_gui_close.__len__ = MagicMock()
    tqdm_gui_close._instances = MagicMock()
    tqdm_gui_close.close()
    assert tqdm_gui_close.disable
    assert tqdm_gui_close.toolbar == "None"
    assert tqdm_gui_close.wasion == False


# Generated at 2022-06-26 09:48:10.179599
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.clear()


# Generated at 2022-06-26 09:48:12.520054
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()



# Generated at 2022-06-26 09:48:20.749913
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .plotting import tgrange
    # Test case 2
    tgrange(1)
    # Test case 3
    tgrange(10)
    # Test case 4
    tgrange(100)
    # Test case 5
    tgrange(1000)


# Generated at 2022-06-26 09:48:32.261269
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.bar_format = None
    tqdm_gui_0.close = None
    tqdm_gui_0.desc = None
    tqdm_gui_0.gui = None
    tqdm_gui_0.mininterval = None
    tqdm_gui_0.n = None
    tqdm_gui_0.postfix_str = None
    tqdm_gui_0.set_description = None
    tqdm_gui_0.unit = None
    tqdm_gui_0.update_to = None
    tqdm_gui_0.zdata = None
    tqdm_gui_0.clear()


# Generated at 2022-06-26 09:48:36.590473
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()

test_case_0()
test_tqdm_gui_close()

# Generated at 2022-06-26 09:48:50.787912
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import json

    d = {
        "bar_format": " {percentage:3.0f}% |{bar}|",
        "desc": "A",
        "dynamic_ncols": False,
        "file": None,
        "gui": True,
        "leave": False,
        "miniters": 1,
        "mininterval": 0.1,
        "monitor": False,
        "ncols": None,
        "postfix": {},
        "position": 0,
        "smoothing": 0.3,
        "sp": " ",
        "total": 10,
        "unit": "it",
        "unit_scale": False,
        "unit_divisor": 1000,
        "widgets": [],
    }
    tqdm_gui_instance = t

# Generated at 2022-06-26 09:48:57.858704
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    try:
        tqdm_gui()
        print("class tqdm_gui constructor test success.")
    except:
        print("class tqdm_gui constructor test failure.")


if __name__ == "__main__":
    test_case_0()
    test_tqdm_gui()

# Generated at 2022-06-26 09:49:17.621458
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(10) as t0:
        t0.clear()


if __name__ == '__main__':
    import sys
    import doctest
    sys.exit(doctest.testmod()[0])

# Generated at 2022-06-26 09:49:26.932302
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # use the `tqdm.gui.trange` function
    import sys
    final = []
    for x in trange(100, desc='A loop'):
        # work work work
        final.append(x + 1)
    sys.stdout.write("\n" + str(final))

    # use the `tqdm.gui.tqdm_gui` class
    # total is not None
    tqdm_gui_1 = tqdm_gui(total=100)
    for x in range(100):
        tqdm_gui_1.update(1)

    # total is None
    tqdm_gui_2 = tqdm_gui()
    for x in range(100):
        tqdm_gui_2.update(1)

# Test decorator

# Generated at 2022-06-26 09:49:31.385826
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.clear()


# Generated at 2022-06-26 09:49:34.013442
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    assert tqdm_gui_0.close()


# Generated at 2022-06-26 09:49:39.634317
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    d = {'disable': False, 'main_loop_running': False}
    inst = tqdm_gui(**d)
    inst.close()
    assert inst.disable == True


# Generated at 2022-06-26 09:49:48.290177
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """
    Unit test for constructor of class tqdm_gui
    """
    from collections import deque

    import matplotlib as mpl
    import matplotlib.pyplot as plt

    kwargs = {'gui':True}

    super(tqdm_gui, self).__init__(*args, **kwargs)

    if self.disable:
        return

    warn("GUI is experimental/alpha", TqdmExperimentalWarning, stacklevel=2)
    self.mpl = mpl
    self.plt = plt

    # Remember if external environment uses toolbars
    self.toolbar = self.mpl.rcParams['toolbar']
    self.mpl.rcParams['toolbar'] = 'None'

    self.mininterval = max(self.mininterval, 0.5)
   

# Generated at 2022-06-26 09:50:00.620844
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """
    Test tqdm_gui.

    :return:
    """
    from argparse import Namespace
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    tqdm_gui_0 = tqdm_gui()
    # print tqdm_gui_0.__dict__
    tqdm_gui_0.__init__(total=5)
    # print tqdm_gui_0.__dict__
    assert_equals(tqdm_gui_0.total, 5)

    tqdm_gui_1 = tqdm_gui(total=5)
    # print tqdm_gui_1.__dict__
    tqdm_gui_2 = tqdm_gui(total=5, desc='title')
    # print tqdm_gui

# Generated at 2022-06-26 09:50:12.046536
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """
    Test if the method display of class tqdm_gui is working properly.
    """
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.start_t = 0.0
    tqdm_gui_1.last_print_t = 0.0
    tqdm_gui_1.last_print_n = 0
    tqdm_gui_1.n = 1
    tqdm_gui_1.total = 1
    tqdm_gui_1.xdata = [0.0]
    tqdm_gui_1.ydata = [1.0]
    tqdm_gui_1.zdata = [1.0]
    tqdm_gui_1.ax = None
    tqdm_gui_1.line1 = None

# Generated at 2022-06-26 09:50:14.180934
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.close()


# Generated at 2022-06-26 09:50:26.943220
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from unittest import TestCase, TestLoader, TextTestRunner
    # Unit tests for tqdm_gui()
    class TestCases_tqdm_gui(TestCase):
        def setUp(self):
            pass
        def tearDown(self):
            pass
        def test_case_0(self):
            tqdm_gui_0 = tqdm_gui()
        def test_case_1(self):
            tqdm_gui_1 = tqdm_gui(total=10)

# Generated at 2022-06-26 09:51:01.492261
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_0 = tqdm_gui()
    # Test if a TypeError is raised when more then one arguments are given
    with pytest.raises(TypeError):
        tqdm_gui_0.clear(True, False)
    # Test if a AttributeError is raised when an argument of wrong type is given
    with pytest.raises(AttributeError):
        tqdm_gui_0.clear("")
    # Test if a TypeError is raised when not enough arguments are given
    with pytest.raises(TypeError):
        tqdm_gui_0.clear()



# Generated at 2022-06-26 09:51:07.535806
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Test case for method close
    """
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()
    # print ("Unit test for method close of class tqdm_gui performed.")
    return


# Generated at 2022-06-26 09:51:09.310429
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    assert tqdm_gui().clear() == None



# Generated at 2022-06-26 09:51:17.066145
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0._set_total(4)
    for _i in tqdm_gui_0: tqdm_gui_0.update()
    assert tqdm_gui_0.disable == True


# Generated at 2022-06-26 09:51:25.327056
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    total = 1
    n = 0
    cur_t = 0
    elapsed = 0
    delta_it = 0
    delta_t = 0
    xdata = []
    ydata = []
    zdata = []
    ax = None
    line1 = None
    line2 = None
    y = 0
    z = 0
    d = {}
    msg = ""


# Generated at 2022-06-26 09:51:30.040829
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_1 = tqdm_gui()
    try:
        tqdm_gui_1.clear()
    except:
        fail()


# Generated at 2022-06-26 09:51:41.433692
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import sys
    import random
    import time

    tqdm_gui_0 = tqdm_gui()

    tqdm_gui_0.total = 100
    tqdm_gui_0.start_t = time.time()
    tqdm_gui_0.last_print_n = 0
    tqdm_gui_0.last_print_t = tqdm_gui_0.start_t

    # Generate list of random numbers
    rand_num = [random.random() for i in range(100)]
    # Loop to "process" the random numbers
    for i in range(100):
        tqdm_gui_0.n = i
        tqdm_gui_0.display()
        time.sleep(rand_num[i])

    tqdm_gui_0.close()



# Generated at 2022-06-26 09:51:44.307609
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.close()
    assert tqdm_gui_1.disable==True, "tqdm_gui.close() function is not working as expected"


# Generated at 2022-06-26 09:51:54.550731
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    # Test code with tqdm.gui.tqdm_gui(...)
    test_case_0()
    # Test code with tqdm.gui.tgrange(...)
    test_case_1()

    # TODO: test case with tqdm.gui.tqdm(...)
    # TODO: test case with tqdm.gui.trange(...)

    # Test the close method
    test_case_0().close()

    # Close the GUI
    plt.close('all')


# Generated at 2022-06-26 09:51:56.581814
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.clear()


# Generated at 2022-06-26 09:52:28.741804
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_1 = tqdm_gui()
    # tqdm_gui_1.close()
    pass


# Generated at 2022-06-26 09:52:39.275953
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    test_iterable = iter([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    with tqdm_gui(total=10, initial=0, unit_scale=True, unit='iB') as t:
        for i in (test_iterable):
            t.update()
            # print(i)
    return



# Generated at 2022-06-26 09:52:44.463572
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib.pyplot as plt
    import numpy as np
    x = np.arange(0, 10)
    y = np.random.rand(10)
    with tqdm_gui(total=10) as t:
        for i in range(10):
            plt.cla()
            plt.plot(x, y, 'ro')
            plt.draw()
            plt.pause(0.05)
            y = np.roll(y, 1)
            t.update(1)


# Generated at 2022-06-26 09:52:49.710531
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    test_tqdm_gui_0()
    test_tqdm_gui_1()
    test_tqdm_gui_2()


# Generated at 2022-06-26 09:53:00.593846
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.n = 0.336
    tqdm_gui_0._time = lambda: 0.6
    tqdm_gui_0.start_t = 0.1
    tqdm_gui_0.last_print_n = 0.0
    tqdm_gui_0.last_print_t = 0.1
    tqdm_gui_0.total = float('nan')
    tqdm_gui_0.xdata = []
    tqdm_gui_0.ydata = []
    tqdm_gui_0.zdata = []
    tqdm_gui_0.ax = tqdm_gui_0.plt.subplots(figsize=(9, 2.2))[1]

# Generated at 2022-06-26 09:53:09.026556
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import numpy as np

# Generated at 2022-06-26 09:53:12.937546
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from tqdm._tqdm_gui import tqdm_gui
    r = tqdm_gui()
    r.close()


# Generated at 2022-06-26 09:53:16.061295
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """ /!\\ DO NOT CHANGE THE FUNCTION NAME /!\\ """
    test_case_0()

# Generated at 2022-06-26 09:53:23.332392
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    test_obj = tqdm_gui.__new__(tqdm_gui)
    try:
        test_obj.display()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-26 09:53:31.402654
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    cur_t=0
    n=0
    elapsed=0
    delta_it=0
    delta_t=0
    total=0
    xdata=[]
    ydata=[]
    zdata=[]
    ax=""
    line1=""
    line2=""
    y=0
    z=0
    ymin=0
    ymax=0
    t_ago=0
    d=""
    msg=""
    test_obj = tqdm_gui()
    test_obj.n=n
    test_obj.start_t=0
    test_obj.last_print_n=0
    test_obj.last_print_t=0
    test_obj.unit='it'
    test_obj.unit_scale=false
    test_obj.desc=''
    test_obj.total

# Generated at 2022-06-26 09:54:12.632025
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.disable = True
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:54:19.016749
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # test 0:
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()
    # test 1:
    tqdm_gui_1 = tqdm_gui(total=1000)
    for i in range(1000):
        tqdm_gui_1.update(1)
        tqdm_gui_1.display()
    tqdm_gui_1.close()
    # test 2:
    tqdm_gui_2 = tqdm_gui(total=1000)
    for i in range(1000):
        tqdm_gui_2.update(1)
        tqdm_gui_2.display(pos=i)
    tqdm_gui_2.close()
    # test 3:

# Generated at 2022-06-26 09:54:22.791354
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from matplotlib.backends.backend_qt5 import FigureCanvasQTAgg
    from matplotlib.figure import Figure

    fig = Figure()
    tqdm_gui_0 = tqdm_gui()

    tqdm_gui_0.display()

    # # if None is not tqdm_gui_0.fig:
    # if not (tqdm_gui_0.fig is None):
    #     print("tqdm_gui_0.fig = " + str(tqdm_gui_0.fig))
    # else:
    #     print("tqdm_gui_0.fig = None")


# # Unit test for method close of class tqdm_gui
# def test_tqdm_gui_close():
#     tqdm_gui_0 = tqdm_gui

# Generated at 2022-06-26 09:54:26.351950
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.display()


# Generated at 2022-06-26 09:54:34.684130
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    try:  # Python 3+
        from tkinter import Tk, PhotoImage, Frame
    except ImportError:  # Python 2
        try:
            from Tkinter import Tk, PhotoImage, Frame
        except ImportError:
            raise ImportError("Could not find tkinter module, check installation")

# Generated at 2022-06-26 09:54:41.778902
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # testing if __init__ of tqdm_gui works
    from collections import deque

    import matplotlib as mpl
    import matplotlib.pyplot as plt
    kwargs = {'gui': True}
    tqdm_gui_0 = tqdm_gui()

    # testing if tqdm_gui(enable=True) works
    tqdm_gui_1 = tqdm_gui(enable=True)

    # testing if tqdm_gui(gui=True) works
    tqdm_gui_2 = tqdm_gui(gui=True)

    # testing if tqdm_gui(disable=False) works
    tqdm_gui_3 = tqdm_gui(disable=False)

    # testing if tqdm_gui(disable=True) works
    tqdm

# Generated at 2022-06-26 09:54:49.356304
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    mpl.use('TkAgg')
    d = {'gui': True, 'ascii': True}
    # test constructor
    tqdm_gui_0 = tqdm_gui(**d)
    # test close
    # tqdm_gui_0.close()
    # test clear
    tqdm_gui_0.clear()

    plt.show()

# Generated at 2022-06-26 09:54:58.293575
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .utils import _supports_unicode
    from .utils import format_sizeof
    from .utils import format_interval
    tqdm_gui_0 = tqdm_gui()
    output = tqdm_gui_0._instances
    expected_output = []
    assert expected_output == output, '##### failed test_tqdm_gui_clear() ##########\n--- expected output ---\n{}--- output ---\n{}--- format ---\n{}--- type ---\n{}\n'.format(expected_output, output, format_interval(expected_output), type(expected_output))
    # reset
    tqdm_gui_0._instances = []
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:55:04.968482
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from pylab import plot, show
    N = 100
    M = 5
    for _ in tqdm_gui(range(N)):
        for _ in range(M):
            plot([1,2,3])
    show()

# Generated at 2022-06-26 09:55:07.780135
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()
