

# Generated at 2022-06-26 09:46:26.017917
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_1 = tqdm_gui()
    func_0 = var_0 = tqdm_gui_1.close()
    if(func_0 == var_0):
        print("Case 1 for tqdm_gui close passed")
    else:
        print("Case 1 for tqdm_gui close failed")


# Generated at 2022-06-26 09:46:30.245023
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    var_0 = tqdm_gui_0.close()


# Generated at 2022-06-26 09:46:32.008109
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui_0 = tqdm_gui()
    var_0 = tqdm_gui_0.display()


# Generated at 2022-06-26 09:46:45.102020
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm.gui.tqdm_gui.disable = False
    tqdm.gui.tqdm_gui._instances = [tqdm.gui.tqdm_gui()]
    tqdm.gui.tqdm_gui.disable = True
    test_case_0()
    tqdm.gui.tqdm_gui.disable = False

# https://matplotlib.org/api/_as_gen/matplotlib.axes.Axes.legend.html#matplotlib.axes.Axes.legend

if __name__ == '__main__':
    import pytest

    #pytest.main(["-vv", __file__])
    pytest.main([__file__])
    # test_tqdm_gui_close()

    # from utils import _test

# Generated at 2022-06-26 09:46:55.000615
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui_0 = tqdm_gui(5, desc='g1', ncols=8, postfix='pf')
    tqdm_gui_0.display()
    tqdm_gui_0.update()
    tqdm_gui_0.update()
    tqdm_gui_0.update()
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:46:58.395782
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """
    Test for GUI version of tqdm.
    """
    # Test for constructor of class tqdm_gui
    test_case_0()
    # Test for constructor of class tqdm_gui
    test_case_1()



# Generated at 2022-06-26 09:47:03.961643
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    assert not tqdm_gui_0.disable
    tqdm_gui_0.close()
    assert tqdm_gui_0.disable


# Generated at 2022-06-26 09:47:12.833754
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()
    # initialize
    tqdm_gui_0._instances = None
    tqdm_gui_0.disable = True
    tqdm_gui_0.dynamic_miniters = False
    tqdm_gui_0.mininterval = 0.1
    tqdm_gui_0.maxinterval = 10.0
    tqdm_gui_0.leave = True
    tqdm_gui_0.miniters = None
    tqdm_gui_0.ascii = False
    tqdm_gui_0.unit = 'it'
    tqdm_gui_0.unit_scale = False

# Generated at 2022-06-26 09:47:14.914521
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    test_case_0()


# Generated at 2022-06-26 09:47:18.353909
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.display()


# Generated at 2022-06-26 09:47:40.111981
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:47:44.093839
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.clear()


# Generated at 2022-06-26 09:47:46.645566
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui_0 = tqdm_gui()
    pass


# Generated at 2022-06-26 09:47:53.510048
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui_1 = tqdm_gui(total=10,desc='TestCase1',unit='it',unit_scale=False,
                          leave=False,gui=True)
    tqdm_gui_2 = tqdm_gui(total=10,desc='TestCase2',unit='it',unit_scale=False,
                          leave=False,gui=True)
    tqdm_gui_3 = tqdm_gui(total=10,desc='TestCase3',unit='it',unit_scale=False,
                          leave=False,gui=True)
    for i in tqdm_gui_1:
        tqdm_gui_1.update(1)
    for i in tqdm_gui_2:
        tqdm_gui_2.update(1)

# Generated at 2022-06-26 09:48:05.792633
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # Inputs are: iterable = iter(range(1, 10))
    tqdm_gui_0 = tqdm_gui(iter(range(1, 10)), desc='', total=None, file=None, ncols=None, mininterval=0.1, maxinterval=10.0, miniters=None, ascii=None, disable=False, unit='it', unit_scale=False, dynamic_ncols=False, smoothing=0.3, bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}{postfix}]', initial=0, position=None, postfix=None, unit_divisor=1000, gui=True, colour='g')


# Generated at 2022-06-26 09:48:17.284074
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    #for method close of class tqdm_gui
    #clear=True, leave=False
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()
    assert tqdm_gui_0.disable == True
    assert tqdm_gui_0.leave == False

    #clear=False, leave=False
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.close()
    assert tqdm_gui_1.disable == True
    assert tqdm_gui_1.leave == False

    #clear=True, leave=True
    tqdm_gui_2 = tqdm_gui()
    tqdm_gui_2.close()
    assert tqdm_gui_2.disable == True

# Generated at 2022-06-26 09:48:30.832456
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui()

if __name__ == '__main__':  # pragma: no cover
    from time import sleep
    from random import random
    # For testing
    for i in tqdm([1, 2, 3, 4]):
        sleep(0.2)
    with tqdm_gui([1, 2, 3, 4]) as t:
        for i in t:
            t.set_description('GENERATING %i' % i)
            sleep(0.2)
    with tqdm(total=100) as t:
        for i in _range(10):
            sleep(0.05)
            t.update(10)

# Generated at 2022-06-26 09:48:36.077185
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep

    for i in tqdm_gui(range(30)):
        sleep(0.1)


if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-26 09:48:50.536747
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    print("Unit test for constructor of class tqdm_gui:\n")

    # Initialize an object for class tqdm_gui
    tqdm_gui_7 = tqdm_gui(8, ascii = True)
    # Test __init__() method of class tqdm_gui
    tqdm_gui_7.__init__(8, ascii = True)
    # Test __init__() method of class tqdm_gui
    tqdm_gui_7.__init__(8, ascii = True)
    # Test __init__() method of class tqdm_gui
    tqdm_gui_7.__init__(8, ascii = True)
    # Test __init__() method of class tqdm_gui

# Generated at 2022-06-26 09:48:56.530915
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.display()

if __name__ == "__main__":
    test_case_0()
    test_tqdm_gui_display()

# Generated at 2022-06-26 09:49:19.482204
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # Initialize the instance
    tqdm_gui_0 = tqdm_gui()

    # Compare the constructor with a empty constructor
    assert tqdm_gui_0 is not None, 'Failure: tqdm_gui() is None'

# Generated at 2022-06-26 09:49:24.504134
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    t = tqdm_gui(10000000, mininterval=0.05)
    t.miniters = 1
    t.maxinterval = 0.05
    t.start()
    for i in range(10000000):
        if i == 5000000:
            t.clear()
        pass
    t.update(10000000)
    t.close()


# Generated at 2022-06-26 09:49:30.186761
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.close()
    assert(tqdm_gui_1.disable == True)


# Generated at 2022-06-26 09:49:38.813862
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import sys
    import time
    from os import getpid
    from random import randrange

    # Test with fixed value
    assert len(tqdm_gui(range(10))) == 10

    # Test with special args
    with tqdm_gui(total=100, mininterval=0, miniters=1,
                  file=sys.stdout,
                  ncols=0,
                  ascii=True,
                  desc="{0} foo".format(getpid()), dynamic_ncols=False,
                  unit="blah",
                  unit_scale=True,
                  leave=True,
                  ) as t:
        print('\n' * t.gui.clear_lines, end='')
        for i in range(10):
            t.update()
            time.sleep(0.01)

   

# Generated at 2022-06-26 09:49:45.735395
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    for i in trange(5):
        sleep(0.5)
    sleep(5)
    try:
        tqdm_gui_0.clear()
    except:
        print("clear method not defined for tqdm_gui")
        return False
    return True


# Generated at 2022-06-26 09:49:58.721971
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # Note: for this test case to work,
    # it is necessary to install the package matplotlib.
    # The test is disabled by the pragma "no cover".
    from unittest import TestCase
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import tqdm.gui

    class tqdm_gui_close(TestCase):
        """Test class for method close of class tqdm_gui"""
        def setUp(self):
            self.tb = mpl.rcParams['toolbar']
            mpl.rcParams['toolbar'] = 'None'
            self.wasion = plt.isinteractive()
            plt.ion()


# Generated at 2022-06-26 09:50:02.570291
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui_test = tqdm_gui()
    assert tqdm_gui_test is not None


# Generated at 2022-06-26 09:50:13.465210
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_1 = tqdm_gui(10, leave=False)
    tqdm_gui_2 = tqdm_gui(desc='title')
    tqdm_gui_3 = tqdm_gui(desc='title', leave=False)
    tqdm_gui_4 = tqdm_gui(10, total=100, leave=False)
    tqdm_gui_5 = tqdm_gui(desc='title', total=100, leave=False)
    tqdm_gui_6 = tqdm_gui(10, unit='t', leave=False)
    tqdm_gui_7 = tqdm_gui(desc='title', unit='t', leave=False)

# Generated at 2022-06-26 09:50:16.262343
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()



# Generated at 2022-06-26 09:50:23.676712
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # Set up the tqdm_gui class
    n = 0
    _time = time.time()
    last_print_n = 0
    last_print_t = _time
    start_t = _time
    total = 100
    xdata = 0
    ydata = 0
    zdata = 0
    #line1, = ax.plot(xdata, ydata, color='b')
    #line2, = ax.plot(xdata, zdata, color='k')

    # Call the display method
    tqdm_gui.display()

    # Ensure that updates were made
    assert(xdata > 0 and ydata > 0)
    assert(n > 0 and start_t > 0)
    assert(cur_t > 0 and delta_it > 0)

# Generated at 2022-06-26 09:50:44.643457
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    test_case_0()

if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-26 09:50:47.989726
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.clear()


# Generated at 2022-06-26 09:51:01.299408
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import random
    import time
    # testing with new instances
    with tqdm_gui(total=10) as t:
        for i in range(10):
            # Update progress and display the progressbar
            t.update(1)
            t.display()
            time.sleep(0.5)
    # testing with a closed instance
    t = tqdm_gui(total=0, gui=True)
    t.close()
    t.update()
    t.display()
    # testing with a finished instance
    try:
        with tqdm_gui(total=0, gui=True) as t:
            pass
        t.update()
        t.display()
    except Exception:
        pass

    # testing with a finished instance

# Generated at 2022-06-26 09:51:05.528182
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """ Test the method close of class tqdm_gui """
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:51:09.190265
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_close_0 = tqdm_gui(1, 0.9, 3)
    tqdm_gui_close_0.close()


# Generated at 2022-06-26 09:51:21.676812
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui(disable=True)
    tqdm_gui(leave=True)
    tqdm_gui(gui=True)
    tqdm_gui(gui=False)
    tqdm_gui(gui=None)
    tqdm_gui(gui=0)
    tqdm_gui(gui=1)
    tqdm_gui(gui=True, disable=True)
    tqdm_gui(gui=True, leave=True)
    tqdm_gui(gui=True, disable=False)
    tqdm_gui(gui=True, leave=False)


# Generated at 2022-06-26 09:51:26.064874
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # Instantiate an object of class tqdm_gui
    tqdm_gui_obj = tqdm_gui()

    # Call method display
    tqdm_gui_obj.display()

# Generated at 2022-06-26 09:51:32.366671
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # test tqdm_gui constructor
    tqdm_gui_0 = tqdm_gui()
    # check whether the constructor is not None
    assert tqdm_gui_0 is not None
    # check whether the constructor of tqdm_gui has not crashed
    assert tqdm_gui_0.disable is False

# Generated at 2022-06-26 09:51:43.812784
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from nose.tools import assert_true
    from nose.tools import assert_equal
    from nose.tools import assert_is_not_none
    from nose.tools import assert_is_instance
    from nose.tools import assert_false


# Generated at 2022-06-26 09:51:47.869523
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()
    assert tqdm_gui_0.disable == True


# Generated at 2022-06-26 09:52:25.190604
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui_0 = tqdm_gui()


# Generated at 2022-06-26 09:52:34.301631
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui(disable=True)
    tqdm_gui("test")
    tqdm_gui("test", disable=True)
    tqdm_gui("test", disable=False)
    tqdm_gui("test", 1, disable=True)
    tqdm_gui("test", 1, disable=False)
    tqdm_gui("test", 1, 2, disable=True)
    tqdm_gui("test", 1, 2, disable=False)
    tqdm_gui("test", total=1)
    tqdm_gui("test", unit="test")
    tqdm_gui("test", unit="test", unit_scale=True)
    tqdm_gui("test", unit="test", unit_scale=True, miniters=1)

# Generated at 2022-06-26 09:52:41.507165
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.clear()
    tqdm_gui_1.start()
    tqdm_gui_1.update(10)
    tqdm_gui_1.clear()
    tqdm_gui_1.close()
    tqdm_gui_1.clear()


# Generated at 2022-06-26 09:52:55.686800
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import time
    from .utils import format_sizeof

    test_case_0()
    test_case_1(tqdm_gui)
    test_case_2(tqdm_gui)
    test_case_3(tqdm_gui)
    test_case_4(tqdm_gui)
    test_case_5(tqdm_gui)
    test_case_6(tqdm_gui)
    test_case_7(tqdm_gui)
    test_case_8(tqdm_gui)
    test_case_9(tqdm_gui)
    test_case_10(tqdm_gui)
    test_case_11()
    test_case_13(tqdm_gui)
    test_case_14(tqdm_gui)
   

# Generated at 2022-06-26 09:53:02.791383
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # check that the display method in tqdm_gui prints the correct thing
    tqdm_gui_1 = tqdm_gui()
    assert(tqdm_gui_1.display() == "")


# Generated at 2022-06-26 09:53:05.662686
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # Create an instance of tqdm_gui
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.clear()


# Generated at 2022-06-26 09:53:12.858126
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Test for method tqdm_gui.close."""
    tqdm_gui_0 = tqdm_gui()
    assert tqdm_gui_0.disable == False
    tqdm_gui_0.close()
    assert tqdm_gui_0.disable == True


# Generated at 2022-06-26 09:53:16.527349
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:53:29.561929
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # Test case 0
    tqdm_gui_0 = tqdm_gui()
    # Test case 1
    tqdm_gui_1 = tqdm_gui('test_range')
    # Test case 2
    tqdm_gui_2 = tqdm_gui(12345)
    # Test case 3
    tqdm_gui_3 = tqdm_gui([1, 2, 3, 4])
    # Test case 4
    tqdm_gui_4 = tqdm_gui(['test'])
    # Test case 5
    tqdm_gui_5 = tqdm_gui({'test'})
    # Test case 6
    tqdm_gui_6 = tqdm_gui(True)
    # Test case 7
    tqdm_gui_7 = tqdm_gui

# Generated at 2022-06-26 09:53:31.033628
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.clear()


# Generated at 2022-06-26 09:54:52.394372
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # Test constructors
    # Construct with string input
    tqdm_gui_1 = tqdm_gui(total=10)
    tqdm_gui_2 = tqdm_gui(total=100)
    # Construct with list input
    tqdm_gui_3 = tqdm_gui([1, 2, 3, 4, 5], total=10)
    # Construct with tuple input
    tqdm_gui_4 = tqdm_gui((1, 2, 3, 4, 5), total=10)
    tqdm_gui_5 = tqdm_gui((1, 2, 3), total=10)
    # Construct with dict input
    dict_1 = {0: 'test', 1: 'test2'}
    tqdm_gui_6 = tqdm_gui(dict_1)


# Generated at 2022-06-26 09:55:03.938501
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .._tqdm import tqdm

    from collections import deque

    import matplotlib as mpl
    import matplotlib.pyplot as plt

    kwargs = dict()
    kwargs['gui'] = True
    colour = kwargs.pop('colour', 'g')
    # super(tqdm_gui, self).__init__(*args, **kwargs)

    if tqdm_gui_0.disable:
        return

    # warn("GUI is experimental/alpha", TqdmExperimentalWarning, stacklevel=2)
    tqdm_gui_0.mpl = mpl
    tqdm_gui_0.plt = plt

    # Remember if external environment uses toolbars
    tqdm_gui_0.toolbar = tqdm_gui_0.mpl.rc

# Generated at 2022-06-26 09:55:06.781812
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:55:12.110460
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from collections import deque

    import matplotlib as mpl
    import matplotlib.pyplot as plt

    t = tqdm_gui(total=100)

    # Remember if external environment uses toolbars
    t.toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'

    t.mininterval = max(t.mininterval, 0.5)
    t.fig, t.ax = plt.subplots(figsize=(9, 2.2))
    # t.fig.subplots_adjust(bottom=0.2)
    total = t.__len__()  # avoids TypeError on None #971
    if total is not None:
        t.xdata = []
        t.ydata = []
        t.zdata

# Generated at 2022-06-26 09:55:22.777569
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """
    Test the constructor of tqdm_gui.
    """
    from collections import deque

    # create an instance of tqdm_gui
    tqdm_gui_0 = tqdm_gui()

    # check type of instance variable self.n
    assert type(tqdm_gui_0.n) is int

    # check type of instance variable self.last_print_n
    assert type(tqdm_gui_0.last_print_n) is int

    # check type of instance variable self.last_print_t
    assert type(tqdm_gui_0.last_print_t) is float

    # check type of instance variable self.dynamic_ncols, which is defined
    # in class tqdm

# Generated at 2022-06-26 09:55:26.346020
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    h = tqdm_gui(disable=True)
    with h:
        pass


# Generated at 2022-06-26 09:55:35.463766
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():

    # First test for non-defined total
    test_tqdm_gui_0 = tqdm_gui(total=None)
    # Resetting of important variables
    test_tqdm_gui_0.n = 0
    test_tqdm_gui_0.last_print_n = 0
    test_tqdm_gui_0.total = None
    test_tqdm_gui_0.start_t = 1.4
    test_tqdm_gui_0.last_print_t = 1.4
    # Resetting of the xdata, ydata, zdata
    test_tqdm_gui_0.xdata = []
    test_tqdm_gui_0.ydata = []
    test_tqdm_gui_0.zdata = []
    # Here we are, now

# Generated at 2022-06-26 09:55:41.411756
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import random
    import time
    t = tqdm_gui(0, 10, desc="bar")
    for i in range(10):
        t.display()
        time.sleep(0.5)
        t.n += 1
    t.close()



# Generated at 2022-06-26 09:55:43.257523
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.clear()
    assert tqdm_gui_1.exit_status == ""


# Generated at 2022-06-26 09:55:55.944548
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui_0 = tqdm_gui()
    #
    # test if the constructor works with the following elements
    #
    assert type(tqdm_gui_0) is tqdm_gui
    assert tqdm_gui_0.bar_format is None
    assert tqdm_gui_0.postfix_len == 0
    assert tqdm_gui_0.pos == 0
    assert tqdm_gui_0.max_iter == 0
    assert tqdm_gui_0.interval == 0.1
    assert tqdm_gui_0.miniters == 0
    assert tqdm_gui_0.widgets is None
    assert tqdm_gui_0.disabled == False
    assert tqdm_gui_0.gui == True
    assert tqdm_gui