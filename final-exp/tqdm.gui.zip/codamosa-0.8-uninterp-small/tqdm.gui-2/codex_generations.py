

# Generated at 2022-06-26 09:46:56.675568
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    var_0 = tqdm_gui()
    assert var_0.disable == False
    assert var_0.mininterval == 0.5
    assert var_0.toolbar == mpl.rcParams['toolbar']
    assert var_0.mpl == mpl
    assert var_0.plt == plt
    assert var_0.wasion == plt.isinteractive()


# Generated at 2022-06-26 09:46:57.976304
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    pass


# Generated at 2022-06-26 09:47:00.830653
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    var_0 = tqdm_gui()
    var_0.clear()


# Generated at 2022-06-26 09:47:02.312435
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    pass


# Generated at 2022-06-26 09:47:08.441924
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt

    from .tqdm import tqdm
    from .gui import trange

    trange(10).display()
    plt.close()
    tqdm(trange(10), leave=False, ncols=2).display()
    plt.close()



# Generated at 2022-06-26 09:47:21.947284
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib.pyplot as plt
    import numpy as np
    class tqdm_gui_test(tqdm_gui):
        def __init__(self, *args, **kwargs):
            self.mpl = None
            self.plt = plt
            self.mininterval = 0.5
            self.disable = False
            self.disable_counter = 0
            self.total = 100
            self.unit = "blarg"
            self.unit_scale = False
            self.unit_divisor = 1
            self.leave = True
            self.last_print_n = 0
            self.last_print_t = None
            self.start_t = None
            self.n = 0
            self.dynamic_ncols = None
            self.bar_format = None


# Generated at 2022-06-26 09:47:30.722147
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from tqdm._tqdm import _trange, _range

    for j in _range(10):
        for total in (None, _range(100)):
            x = tqdm_gui(total=total, leave=False)
            for i in _trange(total) if total else _range(100):
                x.update()
                # time.sleep(0.01)


if __name__ == '__main__':
    test_tqdm_gui_display()
    # test_case_0()

# Generated at 2022-06-26 09:47:33.641376
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from contextlib import closing
    with closing(tqdm_gui()) as foo_1:
        pass



# Generated at 2022-06-26 09:47:36.708461
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    test_case_0()

if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-26 09:47:42.122887
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    method_name = "tqdm_gui.clear"
    print("Testing method: " + method_name + " of class tqdm_gui")
    try:
        t = tqdm(total=100000)
        # test method
        t.clear()
        t.close()
        print("Test case passed")
    except Exception as e:
        print("Test case failed: " + str(e))
