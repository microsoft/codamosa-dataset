

# Generated at 2022-06-26 09:46:36.312723
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    count = 0
    for test_case in (test_case_0):
        test_case()
        count += 1
    return count

# Generated at 2022-06-26 09:46:45.468964
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    msg = ''
    success = True

    try:
        var_0 = tgrange()
        var_0.display()
    except Exception:
        msg += 'FAILED:  tgrange().display()\n'
        success = False

    try:
        var_0 = tqdm_gui()
        var_0.display()
    except Exception:
        msg += 'FAILED:  tqdm_gui().display()\n'
        success = False

    assert success, msg


if __name__ == '__main__':
    test_case_0()
    test_tqdm_gui_display()

# Generated at 2022-06-26 09:46:52.486814
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """
    Test class tqdm_gui close method
    """
    # Initialize
    var_0 = tqdm_gui()
    # Expected result
    expected_result = None
    # Do the test
    var_0.close()


# Generated at 2022-06-26 09:46:53.969748
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    var_0 = tgrange()


# Generated at 2022-06-26 09:47:02.236629
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from tqdm.gui import tqdm_gui
    from tqdm._utils import _time
    with _range(100) as t:
        t._instances = set()
        t._gui = True
        t.disable = False
        t.start_t = _time()
        t.last_print_t = _time()
        t.n = 0
        t.last_print_n = 0
        t.miniters = 1
        t.mininterval = 0.5
        t.ascii = '#'
        t.desc = ''
        t.ncols = 80
        t.unit = ''
        t.unit_scale = True
        t.unit_divisor = 1000
        t.dynamic_ncols = True
        t.postfix = ''
        t.n

# Generated at 2022-06-26 09:47:05.175507
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    var_0 = tqdm_gui()
    var_0.close()


# Generated at 2022-06-26 09:47:07.512259
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui(total=1) as var_0:
        var_0.clear()


# Generated at 2022-06-26 09:47:10.330447
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    val_0 = test_case_0()
    val_0.close()



# Generated at 2022-06-26 09:47:22.533335
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    var = tqdm_gui()
    assert (var.disable == False)
    assert (var.gui == True)
    assert (var.iterable == None)
    assert (var.last_print_n == 0)
    assert (var.last_print_t == None)
    assert (var.mpl == None)
    assert (var.plt == None)
    assert (var.toolbar == None)
    assert (var.wasion == None)
    assert (var.ax == None)
    assert (var.fig == None)
    assert (var.hspan == None)
    assert (var.line1 == None)
    assert (var.line2 == None)
    assert (var.xdata == None)
    assert (var.ydata == None)
    assert (var.zdata == None)


# Generated at 2022-06-26 09:47:26.127922
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui.display(xdata,ydata,zdata,ax,line1,line2)


# Generated at 2022-06-26 09:48:05.354794
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    var_0 = tqdm_gui()
    assert var_0.disable == False
    assert var_0.leave == False
    assert var_0.ascii == False
    assert isinstance(var_0.mininterval, float)
    assert var_0.mininterval == 0.1
    assert isinstance(var_0.maxinterval, float)
    assert var_0.maxinterval == 10.0
    assert isinstance(var_0.unit, str)
    assert var_0.unit == 'it'
    assert var_0.unit_scale == False
    assert var_0.dynamic_ncols == False
    assert isinstance(var_0.smoothing, float)
    assert var_0

# Generated at 2022-06-26 09:48:10.598361
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from collections import deque

    import matplotlib as mpl
    import matplotlib.pyplot as plt

    kwargs = {}.copy()
    kwargs['gui'] = True
    colour = kwargs.pop('colour', 'g')

    # should be self
    self = tqdm_gui()

    if self.disable:
        assert 1==0, "self.disable should be False"

    total = self.__len__()  # avoids TypeError on None #971
    if total is not None:
        self.xdata = []
        self.ydata = []
        self.zdata = []
    else:
        self.xdata = deque([])
        self.ydata = deque([])
        self.zdata = deque([])
    self.line1, = plt

# Generated at 2022-06-26 09:48:12.776754
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    var_0 = tqdm_gui()
    var_1 = tqdm_gui().clear()



# Generated at 2022-06-26 09:48:28.018559
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from tqdm.gui import tqdm_gui
    from tqdm._utils import _range
    from tqdm.utils import format_dict
    from tqdm._version import __version__

    assert __version__ == '4.45.0'

    # Init
    tqdm_1 = tqdm_gui(total=0)

    tqdm_1.format_dict = format_dict
    tqdm_1.start_t = 1598459853.4630739
    tqdm_1.format_dict['n'] = 0
    tqdm_1.format_dict['desc'] = None
    tqdm_1.format_dict['unit'] = None
    tqdm_1.format_dict['total'] = 0

# Generated at 2022-06-26 09:48:37.783691
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .std import tgrange
    from .std import tqdm_gui
    var_0 = tgrange()
    var_1 = tqdm_gui(var_0)
    var_2 = tqdm_gui(var_0,
                     unit='blocks',
                     dynamic_ncols=True,
                     smoothing=0.2,
                     bar_format='{desc}[{percentage:3.0f}%]|{bar}|')
    var_1.display()
    var_2.display()
    pass

# Generated at 2022-06-26 09:48:41.424797
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    var_1 = tqdm_gui()
    var_2 = var_1.close()
    assert var_2 is None


# Generated at 2022-06-26 09:48:52.168168
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    var_0 = tqdm_gui()
    try:
        xdata = var_0.xdata
    except AttributeError:
        return

    # test upper bound on *y* axis
    from random import random
    from time import sleep

    orig_xdata = xdata[:]
    orig_ydata = var_0.ydata[:]
    for i in range(50):
        var_1 = random()
        var_0.display()
        var_0.update(1)
        sleep(0.01)
        assert var_0.ydata[-1] <= 1.1 * var_1, "y-axis upper bound"
    xdata = orig_xdata
    var_0.ydata = orig_ydata

    # test discrete update of *x* axis
    orig_xdata = xdata

# Generated at 2022-06-26 09:48:54.386023
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # Empty test for now
    pass

# Generated at 2022-06-26 09:49:03.612169
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib
    import matplotlib.pyplot as plt
    import numpy as np
    import time

    matplotlib.use('TkAgg')
    plt.ion()
    fo = tqdm(total=100)

    assert matplotlib.rcParams['toolbar'] == 'None'
    assert fo.mininterval == 0.5
    assert len(fo.xdata) == 101
    assert len(fo.ydata) == 101
    assert len(fo.zdata) == 101
    assert [len(i) for i in [fo.xdata, fo.ydata, fo.zdata]] == [101, 101, 101]
    assert fo.ax.get_ylim() == (0, 0.001)
    assert fo.ax.get_xlim() == (0, 100)


# Generated at 2022-06-26 09:49:07.398324
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    var_0 = test_case_0()
    var_0.close()