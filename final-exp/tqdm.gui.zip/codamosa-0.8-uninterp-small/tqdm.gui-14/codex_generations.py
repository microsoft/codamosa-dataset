

# Generated at 2022-06-26 09:46:59.389878
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from tkinter import Tk
    from tkinter.constants import YES, BOTH, RIGHT, LEFT, Y, TOP, BOTTOM

    root = Tk()

    progress = 0

    # Create two frames in the root
    frame_1 = Frame(root, bg="white")
    frame_2 = Frame(root, highlightbackground="black", highlightcolor="black",
                    highlightthickness=1)  # , bg="white")

    # Add the frames to the root
    frame_1.grid(row=0, column=0, sticky=N+S+E+W)
    frame_2.grid(row=1, column=0, sticky=N+S+E+W)

    # Add frame_1 to the

# Generated at 2022-06-26 09:47:06.906478
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """[summary]
    
    Returns:
        [type]: [description]
    """
    tqdm_gui_0 = tqdm_gui()
    assert(tqdm_gui_0._instances == [tqdm_gui_0])

    
# Unit test  for method close of class tqdm_gui

# Generated at 2022-06-26 09:47:11.433272
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.disable = True
    tqdm_gui_1.close()



# Generated at 2022-06-26 09:47:24.007118
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui_1 = tqdm_gui(total=100)
    tqdm_gui_1._instances = tqdm_gui._instances
    tqdm_gui_1.n = 0
    tqdm_gui_1.start_t = 0
    tqdm_gui_1.last_print_n = 0
    tqdm_gui_1.last_print_t = 0
    tqdm_gui_1.xdata = []
    tqdm_gui_1.ydata = []
    tqdm_gui_1.zdata = []

    tqdm_gui_1.display()

    assert tqdm_gui_1.xdata == [0]
    assert tqdm_gui_1.ydata == [0.0]
    assert tqdm_

# Generated at 2022-06-26 09:47:27.377404
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_close = tqdm_gui()
    tqdm_gui_close.close()


# Generated at 2022-06-26 09:47:40.112382
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    from .collections import deque

    from contextlib import closing

    with closing(tqdm_gui(total=100, leave=False)) as t:
        for i in _range(10):
            t.update()
            t.close()
            assert t.disable
            assert not hasattr(t, 'line1')
            assert hasattr(t, 'toolbar')
            assert t.toolbar == mpl.rcParams['toolbar']
            assert t.wasion == plt.isinteractive()
            assert t.fig is None
            assert t.ax is None
            t = tqdm_gui(10)
            assert not t.disable
            assert hasattr(t, 'line1')

# Generated at 2022-06-26 09:47:44.094330
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.clear()


# Generated at 2022-06-26 09:47:46.080011
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    print('Testing constructor of class tqdm_gui:')
    test_case_0()


# Generated at 2022-06-26 09:47:52.273819
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # Set up the test case
    tqdm_gui_1 = tqdm_gui()
    if tqdm_gui_1.disable:
        return None
    toolbar = tqdm_gui_1.mpl.rcParams['toolbar']
    tqdm_gui_1.mpl.rcParams['toolbar'] = 'None'
    tqdm_gui_1._instances.remove(tqdm_gui_1)
    wasion = tqdm_gui_1.plt.isinteractive()
    # The actual test
    tqdm_gui_1.close()
    # Check the results
    assert tqdm_gui_1.disable == True


# Generated at 2022-06-26 09:47:56.267836
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .std import tqdm
    t = tqdm()
    t.clear()
