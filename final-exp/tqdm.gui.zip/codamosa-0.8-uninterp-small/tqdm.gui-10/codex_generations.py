

# Generated at 2022-06-26 09:46:41.118806
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.disable = True
    tqdm_gui_0.disable = True
    tqdm_gui_0.disable = True
    tqdm_gui_0.close() # this call should not raise Exception

# Add the following to the end of tests/test_tqdm.py:

# Generated at 2022-06-26 09:46:47.390436
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    assert tqdm_gui._instances == []
    tqdm_gui_1 = tqdm_gui()
    assert tqdm_gui_1 in tqdm_gui._instances
    tqdm_gui_1.close()
    assert tqdm_gui_1 not in tqdm_gui._instances


if __name__ == '__main__':
    test_case_0()
    test_tqdm_gui_clear()

# Generated at 2022-06-26 09:46:50.918312
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.clear()


# Generated at 2022-06-26 09:46:53.969384
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    test_case_0()

if __name__ == "__main__":
    test_tqdm_gui()

# Generated at 2022-06-26 09:47:01.810530
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear(): 
    import sys
    import os
    import tempfile
    
    # Creates a temporary directory
    tmp_dir = tempfile.TemporaryDirectory()
    
    # Establish path to the temp directory
    tmp_dir_path = tmp_dir.name
    
    # Creates a random filename
    rand_filename = tempfile.NamedTemporaryFile(dir=tmp_dir_path, delete=False)
    
    # Establish path to the random filename
    rand_filename_path = rand_filename.name
    
    # First write on the file
    tmp_file = open(rand_filename_path, 'w')
    tmp_file.write("test_1")
    tmp_file.close()
    
    # Create a tqdm instance
    tqdm_instance = tqdm_gui()
    
   

# Generated at 2022-06-26 09:47:05.417570
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.clear()


# Generated at 2022-06-26 09:47:13.247085
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from time import sleep
    tqdm_gui_1 = tqdm_gui(
        desc='Test 1: Total:', total=100,
        bar_format='{l_bar}|{bar}|{n_fmt}/{total_fmt} [{elapsed}<{remaining}]')
    for i in tqdm_gui_1:
        tqdm_gui_1.write('Test 1: curr: %i' % i)
        sleep(i / 100)
    tqdm_gui_1.close()


# Generated at 2022-06-26 09:47:17.770003
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui_0 = tqdm_gui()
    assert type(tqdm_gui_0) == tqdm_gui


# Generated at 2022-06-26 09:47:19.849802
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.close()


# Generated at 2022-06-26 09:47:31.976001
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui_obj = tqdm_gui()
    total = tqdm_gui_obj.total
    xdata = tqdm_gui_obj.xdata
    ydata = tqdm_gui_obj.ydata
    zdata = tqdm_gui_obj.zdata
    ax = tqdm_gui_obj.ax
    line1 = tqdm_gui_obj.line1
    line2 = tqdm_gui_obj.line2

    assert(total == None)
    assert(len(xdata) == 0)
    assert(len(ydata) == 0)
    assert(len(zdata) == 0)
    assert(ax == None)
    assert(line1 == None)
    assert(line2 == None)


# Generated at 2022-06-26 09:48:04.885989
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .utils import _range
    from .std import format_interval, format_meter
    kwargs=dict(total=1000,desc="test_case",postfix=dict(a=1,b=2,c=3))
    init_tqdm_gui=tqdm_gui(**kwargs)
    trange_0 = _range(1000)
    for index_0 in trange_0:
        init_tqdm_gui.display()


# Generated at 2022-06-26 09:48:10.329116
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from time import sleep
    from numpy import zeros
    from numpy import random
    from numpy.linalg import norm
    with trange(100) as t0:
        for i in t0:
            t0.display()
            sleep(0.01)
    with trange(100) as t1:
        for i in t1:
            x = zeros(1000)
            x += random.normal(size=1000)
            t1.set_postfix(loss=norm(x, 1), refresh=True)
            sleep(0.001)
    with trange(100) as t2:
        for i in t2:
            t2.display()
            sleep(0.02)
            t2.set_postfix(loss=0.1, refresh=True)

# Generated at 2022-06-26 09:48:11.675510
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    test_case_0()


# Generated at 2022-06-26 09:48:18.761833
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import io
    import sys

    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.n = 1
    tqdm_gui_0.last_print_n = 0
    tqdm_gui_0.last_print_t = 0
    tqdm_gui_0.start_t = tqdm_gui_0._time()
    capturedOutput = io.StringIO()                  # Create StringIO object
    sys.stdout = capturedOutput                     #  and redirect stdout.
    tqdm_gui_0.display()
    sys.stdout = sys.__stdout__                     # Reset redirect.
    #  call the method
    assert capturedOutput.getvalue().strip() == ""


# Generated at 2022-06-26 09:48:25.215506
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    # tqdm_gui_0.close()
    # tqdm_gui_0.close()
    # tqdm_gui_0.close()
    # tqdm_gui_0.close()



# Generated at 2022-06-26 09:48:29.051574
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.clear()


# Generated at 2022-06-26 09:48:31.710418
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui = tqdm_gui()
    tqdm_gui.close()
    

# Generated at 2022-06-26 09:48:35.192844
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    if tqdm_gui_0 is not None:
        tqdm_gui_0.close()


# Generated at 2022-06-26 09:48:37.381659
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui_0 = tqdm_gui()
    assert isinstance(tqdm_gui_0.display(), None)



# Generated at 2022-06-26 09:48:51.082189
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.testing.decorators import image_comparison
    from tqdm.gui import tqdm_gui
    import numpy as np

    @image_comparison(baseline_images=['tqdm_gui_display'],
            extensions=['png'])
    def test_image():
        set_up = {'monitor':'test_tqdm_gui_display', 'gui':True}
        fig = plt.figure()
        ax = fig.add_subplot(111)
        t = tqdm_gui(np.linspace(0,1,1000),**set_up)
        for i in t:
            t.display()

# Generated at 2022-06-26 09:49:46.599986
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from matplotlib import pyplot as plt
    from six.moves import _thread
    from time import sleep
    from tqdm.gui import trange
    for i in trange(3, desc='1st loop'):
        for j in trange(100, desc='2nd loop'):
            for k in trange(100, desc='3nd loop'):
                sleep(0.01)
    plt.ioff()
    _thread.interrupt_main()


# Generated at 2022-06-26 09:49:51.625727
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:50:02.086289
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from math import ceil
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    list_of_args = [
        'test_case_0',
        'test_case_1',
        'test_case_2',
        'test_case_3'
    ]

# Generated at 2022-06-26 09:50:04.150904
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    a = tqdm_gui()
    a.close()


# Generated at 2022-06-26 09:50:11.716987
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # Test_1: disable = False
    widgets = [
        'Test: ',
        tqdm_gui.Percentage(),
        ' ',
        tqdm_gui.Bar(marker='0', left='[', right=']'),
        ' ',
        tqdm_gui.ETA()
    ]

    with tqdm_gui(total=20, widgets=widgets) as pbar:
        for i in range(0, 20):
            pbar.update(1)

    pbar.close()
    assert pbar.disable == True


# Generated at 2022-06-26 09:50:14.118303
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    #tqdm_gui_close()
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:50:16.263332
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """Sample test for tqdm_gui module"""
    test_case_0()

# Generated at 2022-06-26 09:50:30.029504
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui_0 = tqdm_gui()
    assert isinstance(tqdm_gui_0, tqdm_gui)

    tqdm_gui_0 = tqdm_gui(bar_format="")
    assert tqdm_gui_0.bar_format == ""

    tqdm_gui_0 = tqdm_gui(ascii=True)
    assert tqdm_gui_0.ascii

    tqdm_gui_0 = tqdm_gui(ascii=False)
    assert not tqdm_gui_0.ascii

    tqdm_gui_0 = tqdm_gui(desc="")
    assert tqdm_gui_0.desc == ""


# Generated at 2022-06-26 09:50:35.044289
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    """
    test method of class tqdm_gui that clear the progress bar.
    """
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.clear()
    tqdm_gui_1.display()


# Generated at 2022-06-26 09:50:48.153665
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    '''Test that display works successfully'''
    tqdm_gui_1 = tqdm_gui()

    # Check if total is not None
    tqdm_gui_1.total = 100
    tqdm_gui_1.display()
    assert tqdm_gui_1.ax.get_xlim() == (0, 100)
    assert tqdm_gui_1.xdata == []
    assert tqdm_gui_1.ydata == []
    assert tqdm_gui_1.zdata == []

    # Check if total is None
    tqdm_gui_1.total = None
    tqdm_gui_1.display()
    assert tqdm_gui_1.ax.get_xlim() == (0, 60)

# Generated at 2022-06-26 09:52:07.697214
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    def test_0():
        try:
            tqdm_gui_0.close()
        except:
            assert False
    def test_1():
        try:
            tqdm_gui_0.close()
        except:
            assert False
    def test_2():
        try:
            tqdm_gui_0.close()
        except:
            assert False
    def test_3():
        try:
            tqdm_gui_0.close()
        except:
            assert False
    def test_4():
        try:
            tqdm_gui_0.close()
        except:
            assert False

# Generated at 2022-06-26 09:52:09.795197
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui_obj = tqdm_gui(4)
    tqdm_gui_obj.display()

# Generated at 2022-06-26 09:52:14.954446
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_close_0 = tqdm_gui()
    tqdm_gui_close_0.close()


# Generated at 2022-06-26 09:52:23.057332
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # Initialize tqdm_gui object
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.n = 1.0
    tqdm_gui_0.start_t = 1.0
    tqdm_gui_0.last_print_n = 1.0
    tqdm_gui_0.last_print_t = 1.0
    tqdm_gui_0.total = 1.0
    tqdm_gui_0.xdata.append(1.0)
    tqdm_gui_0.ydata.append(1.0)
    tqdm_gui_0.zdata.append(1.0)
    # Assign object to variable ax
    ax = tqdm_gui_0.ax

# Generated at 2022-06-26 09:52:33.544881
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from tqdm._tqdm import trange

    try:
        tqdm_gui_1 = tqdm_gui(ncols=10)
        assert tqdm_gui_1.ncols == 10
    except NotImplementedError:
        pass  # not implemented on all platforms!


# Generated at 2022-06-26 09:52:43.425110
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui_0 = tqdm_gui(iterable=10, mininterval=1, miniters=1, maxiters=1, desc="Testing tqdm_gui", total=10, leave=True, position=0, ascii=True, disable=False, unit='it', unit_scale=False, dynamic_ncols=False, smoothing=0.3, bar_format=None, initial=0, ncols=100, write_bytes=False, file=None, nrows=None, postfix=None, gui=False)

if __name__ == '__main__':
    test_tqdm_gui()

# Generated at 2022-06-26 09:52:51.317847
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    with warnings.catch_warnings(record=True) as rec:
        with tqdm_gui(total=100) as t:
            t.update(1)
            #t.close()
            t.update(1)
        assert t.disable == True


# Generated at 2022-06-26 09:52:53.659197
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:53:02.034090
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    t_1 = tqdm_gui()
    t_2 = tqdm_gui(total=10)
    assert t_1.total is None
    assert t_2.total == 10


if __name__ == "__main__":
    from .main import _main
    _main(__file__)

# Generated at 2022-06-26 09:53:04.950719
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.close()


# Generated at 2022-06-26 09:54:29.410929
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # Parse the arguments
    import argparse
    parser = argparse.ArgumentParser(description='Test tqdm_gui GUI')
    parser.add_argument('-d', '--disable', action='store_true', dest='disable')
    parser.add_argument('-s', '--smoothing', action='store_true',
                        dest='smoothing')
    parser.add_argument('-t', '--range', action='store_true', dest='trange')
    parser.add_argument('-v', '--version', action='store_true', dest='version')
    parser.add_argument('--ncols', type=int)
    parser.add_argument('--ascii')
    parser.add_argument('--leave', action='store_true')

# Generated at 2022-06-26 09:54:40.433518
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    plt = tqdm_gui.plt
    tqdm_gui_display = tqdm_gui()
    tqdm_gui_display.n = 5.0
    tqdm_gui_display.n = 5.0
    tqdm_gui_display.start_t = 5.0
    tqdm_gui_display.last_print_n = 5.0
    tqdm_gui_display.last_print_t = 5.0
    tqdm_gui_display.total = 5.0
    tqdm_gui_display.xdata = 5.0
    tqdm_gui_display.ydata = 5.0
    tqdm_gui_display.zdata = 5.0
    tqdm_gui_display.ax = 5.0
    tqdm_gui_

# Generated at 2022-06-26 09:54:44.044672
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_close = tqdm_gui()
    tqdm_gui_close.close()


# Generated at 2022-06-26 09:54:52.071089
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    assert tqdm_gui_0.disable == False
    assert tqdm_gui_0.mininterval == 0.50001
    assert tqdm_gui_0.maxinterval == 10
    assert tqdm_gui_0.unit == 'it'
    assert tqdm_gui_0.desc == ''
    assert tqdm_gui_0.total == None
    assert tqdm_gui_0.dynamic_ncols == False
    assert tqdm_gui_0.leave == False
    assert tqdm_gui_0.sp == ' '
    assert tqdm_gui_0.ncols == None
    assert tqdm_gui_0.miniters is not None
    assert tqdm_gui_0.ascii == False
    assert tqdm_gui_0

# Generated at 2022-06-26 09:54:57.480614
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from matplotlib import pyplot as plt
    from time import sleep

    # new tqdm_gui instance
    for i in tqdm_gui(range(10)):
        sleep(0.1)

# test of tqdm decorator

# Generated at 2022-06-26 09:55:09.372306
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # Display an empty tqdm_gui instance
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.display()
    # Display a tqdm_gui instance in progress
    tqdm_gui_1 = tqdm_gui()
    for i in xrange(10):
        tqdm_gui_1.update(1)
        tqdm_gui_1.display()
    tqdm_gui_1.close()

if __name__ == "__main__":
    print("Starting tqdm.gui tests")
    test_case_0()
    test_tqdm_gui_display()
    print("Finished tqdm.gui tests")

# Generated at 2022-06-26 09:55:13.593918
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:55:19.122334
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui(): # pragma: no cover
    """Testcase for class tqdm_gui"""
    try: 
        test_case_0()
    except Exception as e:
        print(e)
        assert False

# Generated at 2022-06-26 09:55:20.667331
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from tqdm.gui import tqdm_gui
    tqdm_gui_0 = tqdm_gui()
    assert True



# Generated at 2022-06-26 09:55:24.844194
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.close()
