

# Generated at 2022-06-26 09:46:24.300959
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    pass  # tested in test_case_0


# Generated at 2022-06-26 09:46:31.148482
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    var_1 = tqdm_gui('', 100)
    var_1.update(var_1.last_print_n)


# Generated at 2022-06-26 09:46:33.795172
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    actual = tgrange()
    actual.close()


# Generated at 2022-06-26 09:46:35.213218
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tgrange()


# Generated at 2022-06-26 09:46:38.075608
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    var_0 = tgrange()
    var_1 = var_0.clear()
    del var_0
    del var_1


# Generated at 2022-06-26 09:46:41.005584
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    var_0 = tgrange()
    var_0.display()



# Generated at 2022-06-26 09:46:43.214004
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm(total=1) as t:
        assert t.disable


# Generated at 2022-06-26 09:46:45.684824
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    obj_0 = tqdm_gui()
    obj_0.clear()


# Generated at 2022-06-26 09:46:48.370869
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm_gui(total=100) as t:
        for i in range(100):
            time.sleep(0.1)
            t.update()

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 09:46:49.990478
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    var_1 = tqdm_gui()

# Generated at 2022-06-26 09:47:11.290537
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    try:
        test_case_0()
    except Exception:
        assert False, "constructor()"
    else:
        assert True


# Generated at 2022-06-26 09:47:21.381708
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.clear()
    # call_counter = 0
    # def tqdm_gui_clear_test_callback_1(self, *args, **kwargs):
    #     nonlocal call_counter
    #     call_counter += 1
    # with patch('tqdm._tqdm.tqdm_gui.tqdm_gui.clear', tqdm_gui_clear_test_callback_1):
    #     tqdm_gui_1.clear()
    # assert call_counter == 1


# Generated at 2022-06-26 09:47:23.857002
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    test_case_0()

test_tqdm_gui()

# Generated at 2022-06-26 09:47:31.242869
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0._instances = [tqdm_gui_0]
    tqdm_gui_0.disable = False
    tqdm_gui_0.close()
    assert tqdm_gui_0._instances == []
    assert tqdm_gui_0.disable == True
    assert tqdm_gui_0.wasion == tqdm_gui_0.plt.isinteractive()


# Generated at 2022-06-26 09:47:34.731429
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()

# Generated at 2022-06-26 09:47:39.027666
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.clear()
    assert tqdm_gui_0.disable == False


# Generated at 2022-06-26 09:47:43.890128
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    try:
        test_case_0()
    except NotImplementedError:
        print("Not a complete test case")



# Generated at 2022-06-26 09:47:48.141047
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # Test if method close is readable
    tqdm_gui_1 = tqdm_gui()
    assert tqdm_gui_1.close
    tqdm_gui_1.close()



# Generated at 2022-06-26 09:47:49.258289
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.display()

# Generated at 2022-06-26 09:47:54.530506
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import os
    import sys

    __file__ = "tqdm/gui.py"
    if sys.version_info < (3, ):
        tqdm_gui_0 = tqdm_gui()
        with tqdm_gui_0:
            for i in tqdm_gui(range(100)):
                pass
            with open(__file__) as f:
                for l in tqdm_gui(f):
                    pass
        tqdm_gui_0 = tqdm_gui()
        with tqdm_gui_0:
            for i in tqdm_gui(range(100)):
                pass
        tqdm_gui_0 = tqdm_gui()

# Generated at 2022-06-26 09:48:31.590987
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .utils import _range
    from .gui import trange

    tqdm_gui_0 = tqdm_gui()
    print(repr(tqdm_gui_0.n))
    for i in trange(10):
        pass
    # print(repr(tqdm_gui_0.n))

    tqdm_gui_1 = tqdm_gui()
    print(repr(tqdm_gui_1.n))

    tqdm_gui_2 = tqdm_gui(10)
    print(repr(tqdm_gui_2.n))
    print(repr(tqdm_gui_2.total))

    tqdm_gui_3 = tqdm_gui(0)
    print(repr(tqdm_gui_3.n))

# Generated at 2022-06-26 09:48:41.283417
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # set the time
    t_elapsed = 2.0
    t_initial = 1.0
    t_final = 3.0
    t_incr = 0.01
    t_expect = t_final - t_initial
    # set the n
    n_elapsed = 2
    n_initial = 1
    n_final = 100
    n_incr = 1
    n_expect = n_final - n_initial
    # generate dummy data of length n_expect + 1
    y_data = [i for i in _range(n_initial, n_final+1)]
    # initialize the dummy tqdm_gui
    dummy_tqdm = tqdm_gui(total=n_final)
    # instantiate the variables to avoid the "Is not defined" errors
    dummy_tqdm

# Generated at 2022-06-26 09:48:52.126671
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from collections import deque
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import warnings
    from .utils import _range

    tqdm_gui_1 = tqdm_gui(_range(100),gui=False)
    tqdm_gui_2 = tqdm_gui(_range(100),gui=True,total=100)
    tqdm_gui_3 = tqdm_gui(_range(100),gui=False,total=100)
    tqdm_gui_4 = tqdm_gui(total=100)

    assert tqdm_gui_1.gui == False
    assert tqdm_gui_2.gui == True
    assert tqdm_gui_3.gui == False
    assert tqdm_gui_4.gui == True

    assert t

# Generated at 2022-06-26 09:49:01.715840
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    # plt.ion()
    tqdm_gui_0 = tqdm_gui(disable=False, leave=True)
    # plt.pause(1e-8)
    tqdm_gui_0.display()
    tqdm_gui_0.close()
    tqdm_gui_1 = tqdm_gui(total=None, disable=False, leave=True)
    # plt.pause(1e-8)
    tqdm_gui_1.display()
    tqdm_gui_1.close()
    # plt.ioff()
    # plt.show()

if __name__ == '__main__':
    # test_case_0()
    test_tqdm_gui_display()

# Generated at 2022-06-26 09:49:15.804645
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import folium

    #########################################################################
    # Example: plot the evolution of the mean of an exponential distribution
    # on a given amount of time
    #########################################################################
    tqdm_gui_2 = tqdm_gui()
    import numpy as np
    # set seeds for reproducibility
    np.random.seed(42)
    mu = 0.5  # mean of distribution
    t_max = 100  # length of time interval
    n_max = 100000  # Number of time intervals
    n = 0
    t = 0
    mean = []  # List of mean values
    # Plot the evolution of the mean
    while t < t_max:
        t += 1.0 / n_max
        n += 1
        mean.append(mu * t)
        tqdm_gui_2.n = n

# Generated at 2022-06-26 09:49:23.990583
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    class my_tqdm_gui(tqdm_gui):
        def __init__(self):
            super(my_tqdm_gui, self).__init__(total=10)

        def display(*_, **__):
            super(my_tqdm_gui, self).display(*_, **__)

    tqdm_gui_0 = my_tqdm_gui()
    for i in range(10):
        tqdm_gui_0.n = i
        tqdm_gui_0.display()

# Generated at 2022-06-26 09:49:37.121540
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # Create a sample list of 3 elements
    lst = [i for i in range(3)]

    # Create a GUI tqdm instance that iterates over the list
    tqdm_gui_0 = tqdm_gui(lst)

    # Expected and actual output of close() method
    expected_output = None
    actual_output = tqdm_gui_0.close()

    # The expected and actual output should be the same
    assert actual_output == expected_output

    # Now check if tqdm_gui_0 is iterable
    expected_output = False
    actual_output = hasattr(tqdm_gui_0, "__next__")

    # The expected and actual output should be the same
    assert actual_output == expected_output

    # Now try to use next() method

# Generated at 2022-06-26 09:49:38.559477
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tc = tqdm_gui()


# Generated at 2022-06-26 09:49:47.761489
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from collections import deque
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    plt.switch_backend('TkAgg')
    import numpy as np
    instance = tqdm_gui(total = 100)
    delta_t = 10.1
    delta_t_old = delta_t
    xdata = []
    ydata = []
    zdata = []
    n = 67
    i = 0
    while (i < 100):
        n = n + 1
        # update xdata, ydata and zdata
        instance.progressbar(n, delta_t)
        ymin, ymax = plt.ylim()
        if n > ymax:
            ymax = 1.1 * n
            plt.ylim(ymin, ymax)
            pl

# Generated at 2022-06-26 09:49:59.416964
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    import sys
    # print(tqdm_gui.__doc__)
    with tqdm_gui(total=10) as t:
        for k in range(10):
            t.update(1)
            plt.pause(1)
    # print(tqdm.__doc__)
    for i in tqdm(range(10), desc='1st loop', bar_format='{l_bar}{bar:10}{r_bar}', ncols=100):
        for j in tqdm(range(5), desc='2nd loop', leave=False, ncols=100):
            for k in tqdm(range(100), desc='3nd loop', leave=False, ncols=100):
                pass
        print(i)
    tq

# Generated at 2022-06-26 09:50:49.413216
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:51:01.826558
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    from .utils import _supports_unicode, _term_move_up
    from .utils import format_sizeof, _environ_cols_wrapper
    import os
    fpath = os.path.join(os.getcwd(), 'file_to_find.txt')
    try:
        with open(fpath, 'w') as f:
            f.write('some content to check if the file is created or not')
    except IOError:
        pass
    try:
        os.remove(fpath)
    except (OSError, IOError):
        pass

    class tqdm_gui:

        def __init__(self, *args, **kwargs):
            self.disable = False
            self.leave = False
            self.mininterval = 1.0
            self.miniters = 1
           

# Generated at 2022-06-26 09:51:08.544348
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """
    Unitary testing of class tqdm_gui
    """
    try:
        test_case_0()
    except Exception as e:
        print(e)
        print("Class tqdm_gui constructor: failed")
        return
    print("Class tqdm_gui constructor: passed")


# Generated at 2022-06-26 09:51:10.367732
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    t_tqdm_gui = tqdm_gui()
    t_tqdm_gui.display()


# Generated at 2022-06-26 09:51:16.750049
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    for k in range(1, 10):
        tqdm_gui_test_case_0 = tqdm_gui()
        tqdm_gui_test_case_0.close()
        del tqdm_gui_test_case_0


# Generated at 2022-06-26 09:51:20.275201
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:51:26.120220
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    for n in range(1000):
        tqdm_gui_1 = tqdm_gui()
        tqdm_gui_1.n = n
        tqdm_gui_1.start_t = 10
        tqdm_gui_1.last_print_n = 1000
        tqdm_gui_1.last_print_t = 1000
        tqdm_gui_1.total = None
        tqdm_gui_1.xdata = list(range(1000))
        tqdm_gui_1.ydata = list(range(1000))
        tqdm_gui_1.zdata = list(range(1000))
        tqdm_gui_1.ax = tqdm_gui_1.fig
        tqdm_gui_1.display()
        # if n == 1:
       

# Generated at 2022-06-26 09:51:30.856276
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    """Test for method close of class tqdm_gui"""
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()

# Generated at 2022-06-26 09:51:37.046257
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # Instantiate an object of class tqdm_gui
    tqdm_gui_obj = tqdm_gui()
    # Unit test for method display of class tqdm_gui:
    # ------------------------------------------------------------------
    # c = tqdm_gui_obj.display()
    # ------------------------------------------------------------------
    # c = tqdm_gui_obj.display(**{'_': None, '__': None, '___': None, '____': None})
    # ------------------------------------------------------------------
    # import pdb; pdb.set_trace()
    # c = tqdm_gui_obj.display(**{'_': None, '__': None, '___': None, '____': None})
    # ------------------------------------------------------------------



# Generated at 2022-06-26 09:51:46.615858
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # Test the constructor of class tqdm_gui
    t1 = tqdm_gui()
    assert isinstance(t1, std_tqdm)
    assert isinstance(t1, tqdm_gui)

    t2 = tqdm_gui(42)
    assert isinstance(t2, std_tqdm)
    assert isinstance(t2, tqdm_gui)
    assert t2.total == 42

    t3 = tqdm_gui(unit='foo')
    assert t3.unit == 'foo'



# Generated at 2022-06-26 09:53:35.285534
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """Test the display() behavior of tqdm_gui."""
    # Setup of test case
    tqdm_gui_0 = tqdm_gui(total=20)
    tqdm_gui_0.n = 1
    tqdm_gui_0.last_print_n = 1
    tqdm_gui_0.last_print_t = 0
    tqdm_gui_0.start_t = 0
    tqdm_gui_0.refresh()
    tqdm_gui_0.n = 2
    tqdm_gui_0.last_print_n = 1
    tqdm_gui_0.last_print_t = 0
    tqdm_gui_0.start_t = 0
    tqdm_gui_0.refresh()



# Generated at 2022-06-26 09:53:39.547315
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_1 = tqdm_gui()
    assert tqdm_gui_1.gui == True


# Generated at 2022-06-26 09:53:47.651457
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    import matplotlib.pyplot as plt
    from matplotlib.testing.decorators import image_comparison

    def clear_plt():
        plt.gca().clear()

    @image_comparison(baseline_images=['gui'], remove_text=True, extensions=['png'])
    def test_case_0():
        t = tqdm_gui(range(100))
        t.clear = clear_plt
        for i in t:
            pass
        t.close()

    test_case_0()


# Generated at 2022-06-26 09:53:51.241008
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.display(True)


# Generated at 2022-06-26 09:53:55.327198
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()
    tqdm_gui_1 = tqdm_gui()


# Generated at 2022-06-26 09:53:59.627376
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from .std import tqdm
    import time

    for j in range(2):
        for i in tqdm(range(10)):
            time.sleep(0.1)


if __name__ == '__main__':
    #test_case_0()
    test_tqdm_gui_display()

# Generated at 2022-06-26 09:54:02.438289
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.clear()

# Generated at 2022-06-26 09:54:04.855920
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    # instantiate tqdm object with any required arguments
    tqdm_obj = tqdm_gui()
    # check if method clear returns nothing
    assert tqdm_obj.clear() is None



# Generated at 2022-06-26 09:54:13.909405
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    for i in tqdm_gui(range(10)):
        pass
    # Abbreviated tests:
    for i in tgrange(10):
        pass
    for i in tqdm(range(10)):
        pass
    for i in trange(10):
        pass


if __name__ == "__main__":
    test_case_0()
    test_tqdm_gui()

# Generated at 2022-06-26 09:54:17.733777
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.clear()

