

# Generated at 2022-06-26 09:46:45.952709
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # TODO: remove when posix is added
    from sys import platform as _platform
    # TODO: remove when ci is added
    from os import environ as _environ
    # TODO: remove when jenkins is added
    from os.path import expanduser as _expanduser
    from os.path import join as _join
    from os import makedirs as _makedirs
    from os.path import exists as _exists
    from shutil import rmtree as _rmtree
    # TODO: remove when travis is added
    if not _environ.get('CI', False):
        try:
            import matplotlib
        except ImportError:
            return
        # TODO: remove when github is added

# Generated at 2022-06-26 09:46:59.390676
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import sys
    import re
    import subprocess
    # import pytest
    # import tqdm
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import numpy as np

    # test_case_0
    # imitating a basic use case and a try/except of the constructor
    try:
        # variable = class_name(args)
        var_0 = tgrange()
    except:  # noqa
        print("An exception occurred in tqdm_gui constructor")

    # test_case_1
    # test for tqdm_gui class
    var_1 = tqdm_gui()
    # imitating a basic usecase and a try/except of the display function

# Generated at 2022-06-26 09:47:05.650493
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib as mpl
    import matplotlib.pyplot as plt

    t1 = tqdm_gui(1)
    assert t1.mpl == mpl
    assert t1.plt == plt
    t1.plt.close()



# Generated at 2022-06-26 09:47:13.304918
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    import numpy as np

    # Display progress bar and abandon progress bar after 100 seconds

    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 10)
    tqdm_gui().display()
    time.sleep(1)
    tqdm_gui().display()
    time.sleep(1)
    tqdm_gui().display()
    time.sleep(1)
    tqdm_gui().display()
    time.sleep(1)
    tqdm_gui().display()
    time.sleep(1)
    tqdm_gui().display()
    time.sleep(1)
    tqdm_gui().display()
   

# Generated at 2022-06-26 09:47:24.611665
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from collections import deque
    from unittest import TestCase

    with TestCase.assertRaises(TestCase, AttributeError):
        test_case_0()
        test_case_0().display()

    test_case_1 = tqdm_gui(desc='test case 1')
    test_case_2 = tqdm_gui(desc='test case 2', total=30)
    test_case_1.hspan = test_case_1.plt.axhspan(0, 0.001, xmin=0, xmax=0, color='g')
    test_case_2.hspan = test_case_2.plt.axhspan(0, 0.001, xmin=0, xmax=0, color='g')

    # n = self.n
    test_case_1.n

# Generated at 2022-06-26 09:47:27.976297
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm(total=10) as var_0:
        var_0.clear()
        var_0.update(1)


# Generated at 2022-06-26 09:47:34.312838
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # Initialise an instance of tqdm_gui
    var_test = tqdm_gui()
    # Call method display of class tqdm_gui on instance var_test
    var_test.display()

if __name__ == '__main__':
    """
    Start tqdm_gui if called directly
    """
    # Setup logging for `tqdm_gui` function
    import logging
    # Create a logger named 'tqdm_gui'.
    # `tqdm_gui` itself is a module
    logger = logging.getLogger('tqdm_gui')
    logger.setLevel(logging.DEBUG)
    # Create a new handler and add it to the logger
    handler = logging.StreamHandler()
    # Logging level
    handler.setLevel(logging.DEBUG)
    # Set the format

# Generated at 2022-06-26 09:47:42.268254
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # Initialize mock object(s)
    var_0 = tqdm_gui()
    var_1 = tqdm.std.tqdm()

    # Mock methods
    var_1.get_lock = mock.Mock(return_value=var_2)
    var_1._instances = mock.Mock(return_value=var_3)

    # Call method
    var_4 = var_0.close()
    if var_4 != var_5:
        raise AssertionError("var_4 != var_5")


# Generated at 2022-06-26 09:47:44.785300
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    var_0 = tqdm_gui()
    var_0.close()


# Generated at 2022-06-26 09:47:49.504953
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """
    Test constructor of class tqdm_gui.
    """
    var_0 = tqdm_gui()
    assert var_0.mininterval == 0.5
    assert var_0.disable == False
