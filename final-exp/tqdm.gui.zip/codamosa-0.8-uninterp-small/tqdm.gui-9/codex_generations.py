

# Generated at 2022-06-26 09:46:48.209719
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui_1 = tqdm_gui()
    n = tqdm_gui_1.n
    cur_t = tqdm_gui_1._time()
    elapsed = cur_t - tqdm_gui_1.start_t
    delta_it = n - tqdm_gui_1.last_print_n
    delta_t = cur_t - tqdm_gui_1.last_print_t

    # Inline due to multiple calls
    total = tqdm_gui_1.total
    xdata = tqdm_gui_1.xdata
    ydata = tqdm_gui_1.ydata
    zdata = tqdm_gui_1.zdata
    ax = tqdm_gui_1.ax
    line1 = tqdm_gui_1

# Generated at 2022-06-26 09:47:00.131252
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.n = 100
    tqdm_gui_1.total = 100
    tqdm_gui_1.start_t = 0
    tqdm_gui_1.last_print_n = 0
    tqdm_gui_1.last_print_t = 0
    tqdm_gui_1.disable = False
    tqdm_gui_1.leave = False
    tqdm_gui_1.lock = None
    tqdm_gui_1.unit = "it"
    tqdm_gui_1.unit_scale = False
    tqdm_gui_1.miniters = 1
    tqdm_gui_1.mininterval = 0

# Generated at 2022-06-26 09:47:11.583309
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    tqdm_gui_1 = tqdm_gui(total=100, ascii=True, unit="B", unit_scale=True,
                          unit_divisor=1024, miniters=20)
    tqdm_gui_1.set_description("test_tqdm_gui")
    for j in range(1, 100):
        tqdm_gui_1.update(j)
    assert (tqdm_gui_1.mpl is mpl and tqdm_gui_1.plt is plt)
    assert (tqdm_gui_1.toolbar == 'None')
    assert (tqdm_gui_1.mininterval >= 0.5)

# Generated at 2022-06-26 09:47:24.072213
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import sys
    from .utils import _supports_unicode, format_sizeof
    from .utils import format_interval, format_meter
    import os
    import math

    if os.environ.get('CI', None):
        sys.stderr.write("Skipping unit tests for tqdm_gui\n")
        sys.stderr.flush()
        return

    sys.stderr.write("Unit tests for tqdm_gui\n")
    sys.stderr.write("Python {}\n".format(sys.version))
    sys.stderr.write("Tcl/Tk {}\n".format(sys.tckversion))
    sys.stderr.write("Matplotlib {}\n".format(
        matplotlib.__version__))

# Generated at 2022-06-26 09:47:31.884881
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from matplotlib.figure import Figure
    from mock import patch
    import numpy as np
    _ = patch("tqdm.gui.tqdm_gui.Figure", spec=Figure)
    _ = patch("tqdm.gui.tqdm_gui.Axes", spec=np.array)
    _ = patch("tqdm.gui.tqdm_gui.Line2D", spec=np.array)
    tqdm_gui_test = tqdm_gui()
    assert isinstance(tqdm_gui_test.display(), None)

# Generated at 2022-06-26 09:47:42.909134
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    assert callable(tqdm_gui)
    assert callable(tqdm_gui(max_value = 100))
    assert callable(tqdm_gui(min_value = 0))
    assert callable(tqdm_gui(total = 100))
    assert callable(tqdm_gui(position = 2))
    assert callable(tqdm_gui(unit_scale = 5))
    assert callable(tqdm_gui(leave = True))
    assert callable(tqdm_gui(desc = "Hello!"))
    assert callable(tqdm_gui(lock_args = True))
    assert callable(tqdm_gui(lock_print = True))
    assert callable(tqdm_gui(postfix = None))

# Generated at 2022-06-26 09:47:47.903225
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    #Test for the case, where
    tqdm_gui_close_0 = tqdm_gui()
    tqdm_gui_close_0.disable = False
    tqdm_gui_close_0.wasion = True
    tqdm_gui_close_0.leave = True
    tqdm_gui_close_0.close()
    assert tqdm_gui_close_0.disable == True
    assert tqdm_gui_close_0.wasion == True

# Generated at 2022-06-26 09:47:51.375816
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm_gui(total=10) as t:
        for i in range(10):
            t.update()
    with tqdm_gui(total=10, unit_scale=True, unit_divisor=1000) as t:
        for i in range(10):
            t.update()



# Generated at 2022-06-26 09:47:58.057424
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    # Prepare the test
    test_iterator = [i for i in range(0, 100)]

    # Run the test
    tqdm_gui_0 = tqdm_gui(test_iterator)
    tqdm_gui_0.close()



# Generated at 2022-06-26 09:48:07.198217
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # Testing on manual parameters
    tqdm_gui_1 = tqdm_gui(iterable=range(0, 10), leave=True)
    assert tqdm_gui_1.disable == False
    assert tqdm_gui_1.total == 10
    assert tqdm_gui_1.leave == True
    assert tqdm_gui_1.dynamic_ncols == False
    assert tqdm_gui_1.file == None
    assert tqdm_gui_1.mininterval == 0.1
    assert tqdm_gui_1.miniters == None
    assert tqdm_gui_1.desc == None
    assert tqdm_gui_1.desc_no_bar == None
    assert tqdm_gui_1.desc_no_bar == None
    ncols

# Generated at 2022-06-26 09:48:37.258086
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    print("in test_tqdm_gui")
    total = 100
    t = tqdm_gui(total=total)
    for i in t:
        t.display()
        time.sleep(0.1)

if __name__ == "__main__":
    # test_case_0()
    test_tqdm_gui()

# Generated at 2022-06-26 09:48:51.054180
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from collections import deque

    import matplotlib as mpl
    import matplotlib.pyplot as plt
    kwargs = {'disable': False, 'gui': True}
    colour = 'g'
    tqdm_gui_1 = tqdm_gui()
    warn("GUI is experimental/alpha", TqdmExperimentalWarning, stacklevel=2)
    tqdm_gui_1.mpl = mpl
    tqdm_gui_1.plt = plt

    tqdm_gui_1.toolbar = tqdm_gui_1.mpl.rcParams['toolbar']
    tqdm_gui_1.mpl.rcParams['toolbar'] = 'None'


# Generated at 2022-06-26 09:48:55.294975
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.close()


# Generated at 2022-06-26 09:49:00.345524
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_1 = tqdm_gui()
    # do something
    tqdm_gui_1.close()
    tqdm_gui_2 = tqdm_gui()
    # do something
    tqdm_gui_2.close()

# Generated at 2022-06-26 09:49:07.714010
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    descriptor_0 = " GUI is experimental/alpha"
    descriptor_1 = "GUI is experimental/alpha"
    test_descriptor = TqdmExperimentalWarning
    assert descriptor_1 in str(test_descriptor)


# Generated at 2022-06-26 09:49:16.996467
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    import numpy as np

    def test_close_case_0(tqdm_gui_0):
        # test that the new instance of tqdm_gui is created
        assert (isinstance(tqdm_gui_0, tqdm_gui))

    def test_close_case_1(tqdm_gui_0):
        # test that the disable attribute of tqdm_gui_0 has been created
        assert (hasattr(tqdm_gui_0, 'disable'))
        # test that the disable attribute of tqdm_gui_0 has the correct datatype
        assert (isinstance(tqdm_gui_0.disable, bool))


# Generated at 2022-06-26 09:49:21.842081
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_0 = tqdm_gui()
    if not tqdm_gui_0.disable:
        tqdm_gui_0.clear()
    return True


# Generated at 2022-06-26 09:49:36.068133
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from matplotlib.axes import Axes
    from matplotlib.figure import Figure
    from matplotlib.pyplot import Axes as Axes_

    # Test whether tqdm_gui.display output is valid
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.display()
    # Test whether tqdm_gui.display output is valid
    tqdm_gui_0 = tqdm_gui()
    # Test `n` and `total` are valid values
    assert tqdm_gui_0.n >= 0 and tqdm_gui_0.total >= 0
    tqdm_gui_0.display()
    # Test whether tqdm_gui.display output is valid
    tqdm_gui_0 = tqdm_gui()
    # Test whether

# Generated at 2022-06-26 09:49:46.420336
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # Create a tqdm instance and initialize
    tqdm_gui_ = tqdm_gui()
    tqdm_gui_.display()
    assert tqdm_gui_.disable == False
    assert tqdm_gui_.leave == None
    assert tqdm_gui_.locked == False
    assert tqdm_gui_.mininterval == 0.20000000000000007
    assert tqdm_gui_.gui == True
    assert tqdm_gui_.wasion == True
    # Close the tqdm instance
    tqdm_gui_.close()
    assert tqdm_gui_.disable == True
    assert tqdm_gui_.leave == None
    assert tqdm_gui_.locked == False
    assert tqdm_gui_.mininterval == 0.20000000000000007
    assert tqdm_gui_.gui

# Generated at 2022-06-26 09:49:50.268376
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    import doctest
    doctest.testmod()


# Generated at 2022-06-26 09:50:25.481807
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_0 = tqdm_gui()
    for j in _range(20):
        tqdm_gui_0.update(1)
    tqdm_gui_0.clear()


# Generated at 2022-06-26 09:50:38.494394
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    '''
    test_tqdm_gui_display: test the display method of class tqdm_gui
    '''
    # Test case 0
    tqdm_gui_0 = tqdm_gui()
    # Test case 1
    tqdm_gui_1 = tqdm_gui(gui = True, desc = 'test_display_1')
    tqdm_gui_1.disable = False
    tqdm_gui_1.display()
    assert tqdm_gui_1.disable == False
    # Test case 2
    tqdm_gui_2 = tqdm_gui(gui = True, desc = 'test_display_2', total = 1e9,
                          miniters = 1)
    tqdm_gui_2.disable = False
    assert tqdm_gui_2

# Generated at 2022-06-26 09:50:45.438712
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    import matplotlib.pyplot as plt
    tqdm_gui_1 = tqdm_gui()
    # tqdm_gui_1.display()
    plt.show()

if __name__ == "__main__":
    # test_case_0()
    test_tqdm_gui_display()

# Generated at 2022-06-26 09:50:52.690299
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from collections import deque
    import matplotlib
    import matplotlib.pyplot as plt
    from .std import tqdm as std_tqdm

    from .std import TqdmExperimentalWarning
    from .std import tqdm as std_tqdm
    from .utils import _range

    class tqdm_gui(std_tqdm):
        def __init__(self, *args, **kwargs):
            from collections import deque

            import matplotlib as mpl
            import matplotlib.pyplot as plt
            kwargs = kwargs.copy()
            kwargs['gui'] = True
            colour = kwargs.pop('colour', 'g')
            super(tqdm_gui, self).__init__(*args, **kwargs)


# Generated at 2022-06-26 09:51:02.418129
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_test_close = tqdm_gui()
    tqdm_gui_test_close.close()
    if tqdm_gui_test_close.disable != True:
        raise Exception(
            "Test failed in tqdm_gui.close(): {}"
            .format(str(tqdm_gui_test_close.disable)))


if __name__ == '__main__':
    import sys
    import time


# Generated at 2022-06-26 09:51:05.956935
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm_gui() as t:
        for i in _range(1000):
            t.update()



# Generated at 2022-06-26 09:51:13.548366
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    from collections import deque
    from matplotlib import pyplot as plt
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import numpy as np
    import time

    tqdm_gui_0 = tqdm_gui()
    assert (tqdm_gui_0.mpl == mpl)
    assert (tqdm_gui_0.plt == plt)
    assert (tqdm_gui_0.toolbar == mpl.rcParams['toolbar'])
    mpl.rcParams['toolbar'] = 'None'
    assert (tqdm_gui_0.mininterval == max(tqdm_gui_0.mininterval, 0.5))
    assert (tqdm_gui_0.disable == False)

    total = t

# Generated at 2022-06-26 09:51:17.441749
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    old_disable = tqdm_gui().disable
    tqdm_gui().close()
    assert old_disable == tqdm_gui().disable


# Generated at 2022-06-26 09:51:25.434126
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():  # pragma: no cover
    import numpy as np
    from matplotlib import pyplot as plt
    from matplotlib import animation
    from tqdm import tqdm_gui

    fig = plt.figure()
    ax = plt.axes(xlim=(0, 2), ylim=(1, -3))
    line, = ax.plot([], [], lw=2)

    def init():
        x = np.linspace(0.5, 5, 50)
        y = x * np.sin(np.pi * x)
        line.set_data(x, y)
        return line,

    # animation function.  This is called sequentially
    def animate(i):
        scale = (2 + i / 10.0)
        x = np.linspace(0, 10, 100)


# Generated at 2022-06-26 09:51:32.938652
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.n = tqdm_gui_0.last_print_n = 0
    tqdm_gui_0.start_t = tqdm_gui_0.last_print_t = tqdm_gui_0._time()
    tqdm_gui_0.display()



# Generated at 2022-06-26 09:52:07.800706
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .std import TqdmExperimentalWarning as e_warn
    from tqdm.auto import tqdm as tqdm_gui
    with warnings.catch_warnings(record=True) as w:
        tqdm_gui()
        assert issubclass(w[-1].category, e_warn)
        assert "GUI is experimental/alpha" in str(w[-1].message)


# Generated at 2022-06-26 09:52:10.520277
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    # The method close() is implemented by the class tqdm_gui
    tqdm_gui_0.close()
    

# Generated at 2022-06-26 09:52:22.246513
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    """
    Unit test for method display of class tqdm_gui
    """
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import time
    import math

    # Remember if external environment uses toolbars
    toolbar = mpl.rcParams['toolbar']
    mpl.rcParams['toolbar'] = 'None'

    # Remember if external environment is interactive
    wasion = plt.isinteractive()
    plt.ion()

    fig, ax = plt.subplots()
    ax.set_xlabel('time, s')
    ax.set_ylabel('y')
    ax.grid()

    # Generate some data
    xdata = []
    ydata = []

    t_end = 10.0
    n_points = 1000

# Generated at 2022-06-26 09:52:32.501720
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    tqdm_gui_obj = tqdm_gui(ascii=True, desc='', total=2, leave=False,
    mininterval=0.1, miniters=1, maxinterval=10.0, maxiters=None,
    smoothing=0.3, bar_format='{n}/{total_fmt} {bar} {rate_fmt}{postfix}',
    initial=0, position=0, postfix=None, unit='it', unit_scale=False,
    dynamic_ncols=False, smoothing_kwargs=None, disable=False, unit_divisor=1000,
    gui=True, colour='g')
    tqdm_gui_obj.close()



# Generated at 2022-06-26 09:52:37.998926
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    try:
        tqdm_gui()
    except:
        # If GUI is not installed, then test should fail, as there is not
        # alternative tqdm_gui to fallback, thus:
        raise Exception('Test Case Failed!')

# Generated at 2022-06-26 09:52:48.275048
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    # constructor
    tqdm_gui_1 = tqdm_gui()
    # inherited attributes
    assert tqdm_gui_1.disable == False
    assert tqdm_gui_1.smoothing == None
    assert tqdm_gui_1.ascii == None
    assert tqdm_gui_1.unit_scale == False
    assert tqdm_gui_1.gui == False
    assert tqdm_gui_1.miniters == None
    assert tqdm_gui_1.dynamic_ncols == False
    assert tqdm_gui_1.last_print_t == None
    assert tqdm_gui_1.bar_format == None
    assert tqdm_gui_1.desc == None
    assert tqdm_gui_1._time == None
   

# Generated at 2022-06-26 09:52:59.929135
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui_1 = tqdm_gui()
    assert tqdm_gui_1._instances == []
    assert tqdm_gui_1.disable == False
    assert tqdm_gui_1.dynamic_miniters == False
    assert tqdm_gui_1.gui == True
    assert tqdm_gui_1.last_print_n == 0
    assert tqdm_gui_1.last_print_t == 0
    assert tqdm_gui_1.last_interval_start_t == 0
    assert tqdm_gui_1.leave == False
    assert tqdm_gui_1.lock_args == {}
    assert tqdm_gui_1.lock_print == False
    assert tqdm_gui_1.miniters == 1

# Generated at 2022-06-26 09:53:00.744253
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    pass


# Generated at 2022-06-26 09:53:03.458762
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    test = tqdm_gui()
    assert(test.clear() is None)


# Generated at 2022-06-26 09:53:05.982074
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui_0 = tqdm_gui()
    print(str(tqdm_gui_0))
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:54:13.118118
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.display()


# Generated at 2022-06-26 09:54:15.061668
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:54:28.671206
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    temperature = np.loadtxt("temperatures.csv", delimiter=",", usecols=(1,),
                             skiprows=1)
    # Setup of the figure for matplotlib
    fig = plt.figure(figsize=(10, 6))
    ax1 = fig.add_subplot(111)
    temp_min = -10
    temp_max = 35
    bins = np.arange(temp_min, temp_max + 1, 1)
    ax1.hist(temperature, bins=bins)
    ax1.set_title("Temperature distribution")
    ax1.set_xlabel("Temperature in degrees C")
    ax1.set_ylabel("Number of occurence")
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_2 = tqdm_

# Generated at 2022-06-26 09:54:31.315208
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    with tqdm_gui() as t:
        for i in t:
            pass

# Generated at 2022-06-26 09:54:40.137263
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        from matplotlib import pyplot as plt
    except ImportError:
        plt.ioff = lambda: False  # noqa: F821
        plt.isinteractive = lambda: False  # noqa: F821
    plt.close = lambda *args, **kwargs: None  # noqa: F821
    tqdm_gui_0 = tqdm_gui()
    tqdm_gui_0.disable = True
    tqdm_gui_0.toolbar = 'None'
    tqdm_gui_0.wasion = False
    tqdm_gui_0.close()


# Generated at 2022-06-26 09:54:50.949484
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    check_repr = std_tqdm()
    tqdm_gui_0 = tqdm_gui()
    assert repr(check_repr) == repr(tqdm_gui_0)
    tqdm_gui_1 = tqdm_gui(10)
    assert repr(tqdm_gui_1) == repr(tqdm_gui_0)
    tqdm_gui_2 = tqdm_gui(10, desc='tqdm_gui')
    assert repr(tqdm_gui_2) == repr(tqdm_gui_0)
    tqdm_gui_3 = tqdm_gui(10, desc='tqdm_gui', ncols=20)
    assert repr(tqdm_gui_3) == repr(tqdm_gui_0)
   

# Generated at 2022-06-26 09:54:55.981164
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    tqdm_gui_1 = tqdm_gui()
    tqdm_gui_1.disable = False
    tqdm_gui_1.close()
    assert tqdm_gui_1.disable == True


# Generated at 2022-06-26 09:55:03.516710
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    try:
        test_case_0()
    except AssertionError as e:
        print("AssertionError: ", e)
    except TypeError as e:
        print("TypeError: ", e)
    except ValueError as e:
        print("ValueError: ", e)
    except AttributeError as e:
        print("AttributeError: ", e)
    except ImportError as e:
        print("ImportError: ", e)
    except Exception as e:
        print("Exception: ", e)
    finally:
        pass


# Generated at 2022-06-26 09:55:06.568551
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    tqdm_gui_0 = tqdm_gui()



# Generated at 2022-06-26 09:55:13.433570
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    """Test tqdm_gui constructor"""
    try:
        tqdm_gui_0 = tqdm_gui()
        tqdm_gui_0.close()
    except Exception as e:
        print("Failed to initiate progress bar")
        print("tqdm_gui exception:", e)
        exit(1)
    print("tqdm_gui constructor test passed successfully")
    exit(0)


if __name__ == "__main__":
    test_tqdm_gui()