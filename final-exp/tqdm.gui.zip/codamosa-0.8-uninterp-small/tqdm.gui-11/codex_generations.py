

# Generated at 2022-06-26 09:46:42.917580
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    with tqdm_gui() as var_0:
        var_0.clear()


# # Unit test for method display of class tqdm_gui
# def test_tqdm_gui_display():
#     with tqdm_gui() as var_0:
#         var_0.display()



# Generated at 2022-06-26 09:46:50.374661
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from collections import deque
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    kwargs = {}
    kwargs['gui'] = True
    total = _range(10)  # avoids TypeError on None #971
    if total is not None:
        xdata = []
        ydata = []
        zdata = []
    else:
        xdata = deque([])
        ydata = deque([])
        zdata = deque([])
    line1, = plt.plot(xdata, ydata, color='b')
    line2, = plt.plot(xdata, zdata, color='k')
    plt.ylim(0, 0.001)
    if total is not None:
        plt.xlim(0, 100)
        pl

# Generated at 2022-06-26 09:46:52.884382
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    test_0 = tqdm_gui(total=None)

# Generated at 2022-06-26 09:46:55.000508
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    var_0 = tgrange()
    var_0.close()


# Generated at 2022-06-26 09:46:57.153420
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    var_0 = tgrange()
    var_1 = var_0.clear()


# Generated at 2022-06-26 09:47:02.387843
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    if __name__ == '__main__':
        tgrange()
        tgrange()
        var_1 = tgrange()
    else:
        var_1 = tgrange()
    var_1.close()


# Generated at 2022-06-26 09:47:12.356277
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # Test if the display method works correctly, including if the progress bar displays correctly
    # This test fails when using the tqdm.gui module. It needs to be fixed in the future
    try:
        # Test case 0
        # This test checks if the display method of class tqdm_gui can handle the case where we call display with no arguments
        # This test should fail
        test_case_0()
        print("Test case 0 passed")
    except:
        print("Test case 0 failed")

# Generated at 2022-06-26 09:47:19.044880
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    with tqdm() as var_0:
        var_1 = var_0.disable
        var_2 = var_0.get_lock()
        var_3 = var_0.leave
    var_0.close()
    var_0.close()
    var_0.close()


# Generated at 2022-06-26 09:47:21.809345
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    var_0 = tqdm_gui()
    var_0.clear()


# Generated at 2022-06-26 09:47:32.704370
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    from .gui import tqdm_gui
    from .gui import tgrange
    from .utils import _range

    temp_1 = tgrange()
    temp_1.close()
    temp_2 = tgrange()
    temp_2.close()
    temp_3 = tgrange()
    temp_3.close()
    temp_4 = tgrange()
    temp_4.close()
    temp_5 = tgrange()
    temp_5.close()
    temp_6 = tgrange()
    temp_6.close()
    temp_7 = tgrange()
    temp_7.close()
    temp_8 = tgrange()
    temp_8.close()
    temp_9 = tgrange()
    temp_9.close()
    temp_10 = tgrange()

# Generated at 2022-06-26 09:48:07.280787
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    from .std import tgrange
    var_1 = tgrange()


# Generated at 2022-06-26 09:48:17.822641
# Unit test for method close of class tqdm_gui
def test_tqdm_gui_close():
    var_0 = tqdm_gui()
    var_1 = int(0)
    var_2 = int(0)
    var_2 = var_0.get_lock()
    var_2.acquire()
    var_0._instances.remove(var_0)
    var_2.release()
    var_0.disable = True
    var_1 = var_0.mpl.rcParams['toolbar']
    var_2 = var_0.toolbar
    var_3 = var_2 == var_1
    var_4 = var_0.wasion
    var_5 = var_0.plt.isinteractive()
    var_6 = var_4 == var_5
    var_7 = var_0.leave
    if not var_7:
        var_0.pl

# Generated at 2022-06-26 09:48:20.968572
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    var_0 = tqdm_gui()
    var_0.clear()


# Generated at 2022-06-26 09:48:26.781516
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    try:
        import matplotlib.pyplot as plt
        tgrange()
    except Exception as err:
        import traceback
        print("ERROR CAUGHT IN TEST CASE:")
        traceback.print_exc()
        assert not err
    finally:
        plt.close("all")


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 09:48:39.346552
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    t_0 = tqdm_gui(0)
    t_1 = tqdm_gui(1)
    t_2 = tqdm_gui(2, unit_scale=True)
    t_3 = tqdm_gui(3, unit_scale=False, unit="test")
    t_4 = tqdm_gui(4, bar_format="{bar}")
    t_5 = tqdm_gui(5, bar_format="{bar} {postfix}")
    t_6 = tqdm_gui(5, bar_format="{bar} {postfix[0]}")
    t_7 = tqdm_gui(5, bar_format="{bar} {postfix[1]}")

# Generated at 2022-06-26 09:48:40.074744
# Unit test for constructor of class tqdm_gui
def test_tqdm_gui():
    var_0 = tgrange()


# Generated at 2022-06-26 09:48:51.390869
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    # Test the range() version
    tqdm.tgrange(100).display()
    # Test the total version
    tqdm.tqdm(100).display()
    # Test the iterator version
    tqdm.tqdm(xrange(100)).display()
    # Test the auto-increment version
    tqdm.tgrange(9, 100, 1).display()
    # Test the self-decrement version
    tqdm.tgrange(100, 9, -1).display()
    # Test the string version
    tqdm.tqdm("string").display()

if __name__ == '__main__':
    test_case_0()
    test_tqdm_gui_display()

# Generated at 2022-06-26 09:48:54.463334
# Unit test for method clear of class tqdm_gui
def test_tqdm_gui_clear():
    var_1 = tqdm_gui()


# Generated at 2022-06-26 09:48:56.649600
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    test_case_0()

# Generated at 2022-06-26 09:49:00.703600
# Unit test for method display of class tqdm_gui
def test_tqdm_gui_display():
    mytqdm = tqdm_gui(total=3)
    mytqdm.update(2)
    assert mytqdm.n == 2
    mytqdm.update()
    assert mytqdm.n == 3
    mytqdm.close()