

# Generated at 2022-06-17 10:51:52.316558
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:51:58.013137
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Create a mock object for the result
    result = type('', (), {})()
    result._result = {'diff': 'diff'}

    # Create a mock object for the display
    display = type('', (), {})()
    display.display = lambda x: x

    # Create a mock object for the callback module
    callback_module = CallbackModule()
    callback_module._display = display

    # Call the method
    callback_module.v2_on_file_diff(result)

# Generated at 2022-06-17 10:52:08.661293
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine

# Generated at 2022-06-17 10:52:09.798148
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:52:15.516215
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:52:16.156404
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:52:26.543952
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.module_utils._text import to_text
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.plugins.callback.minimal import CallbackModule
    import json
    import sys
    import os
    import tempfile
    import pytest
    import mock
    import io

    class TestDisplay(Display):
        def __init__(self):
            self.display_data = []

        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            self.display_data.append(msg)


# Generated at 2022-06-17 10:52:37.142404
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.unicode import to_unicode
    from ansible.utils.display import Display
    from ansible.plugins.callback.minimal import CallbackModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.playbook.task import Task

# Generated at 2022-06-17 10:52:47.719581
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Arrange
    result = {
        '_host': {
            'get_name': lambda: 'host'
        },
        '_result': {
            'rc': 1,
            'stdout': 'stdout',
            'stderr': 'stderr',
            'msg': 'msg'
        },
        '_task': {
            'action': 'action'
        }
    }

    # Act
    callback = CallbackModule()
    callback.v2_runner_on_failed(result)

    # Assert
    assert callback._display.display.call_count == 1

# Generated at 2022-06-17 10:52:48.247982
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:53:02.392268
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object of class CallbackBase
    mock_CallbackBase = CallbackBase()
    # Create a mock object of class CallbackModule
    mock_CallbackModule = CallbackModule()
    # Create a mock object of class Result
    mock_Result = Result()
    # Create a mock object of class Host
    mock_Host = Host()
    # Create a mock object of class Task
    mock_Task = Task()
    # Create a mock object of class Action
    mock_Action = Action()
    # Create a mock object of class TaskResult
    mock_TaskResult = TaskResult()
    # Create a mock object of class TaskResult
    mock_TaskResult = TaskResult()
    # Create a mock object of class TaskResult
    mock_TaskResult = TaskResult()
    # Create a mock object of class TaskResult
    mock_TaskResult = Task

# Generated at 2022-06-17 10:53:08.871105
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    import sys
    import os
    import tempfile
    import shutil
    import json
    import difflib

    class TestCallbackModule(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'minimal'

        def __init__(self):
            self.display = Display()

        def v2_on_file_diff(self, result):
            if 'diff' in result._result and result._result['diff']:
                self.display.display(self._get_diff(result._result['diff']))

    class Display:
        def __init__(self):
            self.string = ''


# Generated at 2022-06-17 10:53:17.814996
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-17 10:53:28.710712
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine

# Generated at 2022-06-17 10:53:29.352827
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:53:33.270681
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:53:33.704366
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:53:42.607603
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.module_utils._text import to_text
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import unwrap_var
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import wrap_var

# Generated at 2022-06-17 10:53:51.633543
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a mock object for the result
    result = Mock()
    result.action = 'setup'
    result.changed = False
    result.host = 'localhost'
    result.task = 'setup'
    result.task_action = 'setup'
    result.task_name = 'setup'
    result.task_args = 'setup'
    result.task_vars = 'setup'
    result.task_items = 'setup'
    result.task_include = 'setup'
    result.task_tags = 'setup'
    result.task_deps = 'setup'
    result.task_loop = 'setup'
    result.task_loop_args = 'setup'
    result.task_path = 'setup'
    result.task_uuid = 'setup'
    result.task_role_name = 'setup'

# Generated at 2022-06-17 10:54:02.946911
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a mock object of class CallbackModule
    mock_CallbackModule = CallbackModule()
    # Create a mock object of class Result
    mock_result = Result()
    # Create a mock object of class Host
    mock_host = Host()
    # Create a mock object of class Task
    mock_task = Task()
    # Create a mock object of class Action
    mock_action = Action()
    # Create a mock object of class Display
    mock_display = Display()
    # Create a mock object of class DumpResults
    mock_dump_results = DumpResults()
    # Create a mock object of class CleanResults
    mock_clean_results = CleanResults()
    # Create a mock object of class HandleWarnings
    mock_handle_warnings = HandleWarnings()
    # Create a mock object of class HandleException
    mock

# Generated at 2022-06-17 10:54:21.872165
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Create a mock object of class CallbackModule
    mock_self = CallbackModule()
    # Create a mock object of class Result
    mock_result = Result()
    # Create a mock object of class TaskResult
    mock_task_result = TaskResult()
    # Create a mock object of class Host
    mock_host = Host()
    # Create a mock object of class Task
    mock_task = Task()
    # Create a mock object of class ActionBase
    mock_action_base = ActionBase()
    # Create a mock object of class ActionModule
    mock_action_module = ActionModule()
    # Create a mock object of class AnsibleModule
    mock_ansible_module = AnsibleModule()
    # Create a mock object of class AnsibleModule
    mock_ansible_module_2 = AnsibleModule()
    # Create a mock

# Generated at 2022-06-17 10:54:36.088094
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create instance of class CallbackModule
    callback = CallbackModule()

    # Create instance of class Result
    result = Result()

    # Create instance of class Host
    host = Host()

    # Create instance of class Task
    task = Task()

    # Set attribute _host of instance result to instance host
    result._host = host

    # Set attribute _task of instance result to instance task
    result._task = task

    # Set attribute _result of instance result to dictionary
    result._result = {'changed': False}

    # Call method v2_runner_on_ok of instance callback with instance result as parameter
    callback.v2_runner_on_ok(result)

    # Assert that attribute _result of instance result is equal to dictionary
    assert result._result == {'changed': False}


# Generated at 2022-06-17 10:54:41.294544
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback = CallbackModule()
    assert callback.CALLBACK_VERSION == 2.0
    assert callback.CALLBACK_TYPE == 'stdout'
    assert callback.CALLBACK_NAME == 'minimal'

# Generated at 2022-06-17 10:54:45.161294
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:54:57.272325
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback.minimal import CallbackModule
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.color import stringc
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_

# Generated at 2022-06-17 10:55:05.215760
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object of class CallbackModule
    mock_CallbackModule = CallbackModule()
    # Create a mock object of class Result
    mock_result = Result()
    # Create a mock object of class Host
    mock_host = Host()
    # Set the name of the host
    mock_host.name = "test_host"
    # Set the host of the result
    mock_result._host = mock_host
    # Set the result of the result
    mock_result._result = {"test_key": "test_value"}
    # Call the method v2_runner_on_failed of the mock object
    mock_CallbackModule.v2_runner_on_failed(mock_result)
    # Check if the method _display.display was called with the right parameters
    mock_CallbackModule._display.display.assert_called_with

# Generated at 2022-06-17 10:55:17.414224
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import ansible.plugins.callback.minimal
    import ansible.playbook.task
    import ansible.vars.manager
    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.inventory.manager
    import ansible.utils.vars
    import ansible.parsing.dataloader
    import ansible.playbook.play
    import ansible.playbook.role
    import ansible.playbook.role_include
    import ansible.playbook.task_include
    import ansible.template
    import ansible.utils.plugin_docs
    import ansible.utils.display
    import ansible.plugins.callback
    import ansible.plugins.connection
    import ansible.plugins.lookup
    import ansible.plugins.action
    import ansible.plugins.cache

# Generated at 2022-06-17 10:55:25.377662
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.callback.minimal import CallbackModule
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.utils.color import stringc
    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Mapping


# Generated at 2022-06-17 10:55:33.229023
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Test with empty result
    result = {}
    result['diff'] = ''
    result['_result'] = result
    callback = CallbackModule()
    callback.v2_on_file_diff(result)

    # Test with a diff result
    result = {}
    result['diff'] = 'diff'
    result['_result'] = result
    callback = CallbackModule()
    callback.v2_on_file_diff(result)

# Generated at 2022-06-17 10:55:36.636473
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:55:59.367451
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object for result
    result = Mock()
    result._result = {'failed': True, 'msg': 'msg', 'changed': False, 'rc': 0}
    result._task = Mock()
    result._task.action = 'action'
    result._host = Mock()
    result._host.get_name.return_value = 'host'
    # Create a mock object for display
    display = Mock()
    # Create a mock object for callback
    callback = CallbackModule()
    callback._display = display
    # Call method v2_runner_on_failed
    callback.v2_runner_on_failed(result)
    # Check if the method _handle_exception was called
    callback._handle_exception.assert_called_once_with(result._result)
    # Check if the method _handle_warn

# Generated at 2022-06-17 10:56:06.368503
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping

# Generated at 2022-06-17 10:56:14.710503
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a mock object for the result
    result = Mock()
    result.get.return_value = False
    result._host = Mock()
    result._host.get_name.return_value = 'localhost'
    result._result = {'changed': False}
    result._task = Mock()
    result._task.action = 'setup'

    # Create a mock object for the display
    display = Mock()

    # Create the callback object
    callback = CallbackModule()
    callback._display = display

    # Call the method
    callback.v2_runner_on_ok(result)

    # Check the result
    display.display.assert_called_once_with("localhost | SUCCESS => {'changed': False}", color='green')


# Generated at 2022-06-17 10:56:21.939986
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a mock object of class CallbackModule
    callback = CallbackModule()
    # Create a mock object of class Result
    result = Result()
    # Call the method v2_runner_on_ok of class CallbackModule
    callback.v2_runner_on_ok(result)
    # Check if the method _clean_results of class CallbackModule is called
    assert callback._clean_results.called
    # Check if the method _handle_warnings of class CallbackModule is called
    assert callback._handle_warnings.called
    # Check if the method _display.display of class CallbackModule is called
    assert callback._display.display.called


# Generated at 2022-06-17 10:56:36.008439
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import pytest
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.color import stringc

# Generated at 2022-06-17 10:56:41.182083
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object of class CallbackBase
    mock_CallbackBase = CallbackBase()

    # Create a mock object of class CallbackModule
    mock_CallbackModule = CallbackModule()

    # Create a mock object of class Result
    mock_Result = Result()

    # Create a mock object of class Host
    mock_Host = Host()

    # Create a mock object of class Task
    mock_Task = Task()

    # Create a mock object of class TaskResult
    mock_TaskResult = TaskResult()

    # Create a mock object of class TaskResult
    mock_TaskResult = TaskResult()

    # Create a mock object of class TaskResult
    mock_TaskResult = TaskResult()

    # Create a mock object of class TaskResult
    mock_TaskResult = TaskResult()

    # Create a mock object of class TaskResult
    mock_Task

# Generated at 2022-06-17 10:56:50.992676
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import unittest
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C

    class TestCallbackModule(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'minimal'

        def v2_on_file_diff(self, result):
            if 'diff' in result._result and result._result['diff']:
                self._display.display(self._get_diff(result._result['diff']))

    class TestCallbackModule_v2_on_file_diff(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.addCleanup

# Generated at 2022-06-17 10:56:51.406897
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:56:51.772617
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:57:02.477296
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import sys
    import io
    import unittest
    from ansible.plugins.callback.minimal import CallbackModule

    class TestCallbackModule(unittest.TestCase):
        def setUp(self):
            self.capturedOutput = io.StringIO()
            sys.stdout = self.capturedOutput

        def test_v2_on_file_diff(self):
            result = {'diff': {'after': '', 'before': '', 'before_header': '', 'after_header': ''}}
            callback = CallbackModule()
            callback.v2_on_file_diff(result)
            self.assertEqual(self.capturedOutput.getvalue(), '\n')

        def tearDown(self):
            sys.stdout = sys.__stdout__


# Generated at 2022-06-17 10:57:41.654982
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import ansible.plugins.callback.minimal
    import ansible.playbook.task_include
    import ansible.vars.manager
    import ansible.vars.hostvars
    import ansible.vars.unsafe_proxy
    import ansible.template.template
    import ansible.template.vars
    import ansible.template.safe_eval
    import ansible.template.jinja2.environment
    import ansible.template.jinja2.filters
    import ansible.template.jinja2.loaders
    import ansible.template.jinja2.nativetypes
    import ansible.template.jinja2.runtime
    import ansible.template.jinja2.sandbox
    import ansible.template.jinja2.utils
    import ansible.template.jinja2.meta

# Generated at 2022-06-17 10:57:48.395686
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    import json
    import os
    import sys
    import tempfile
    import unittest

    class TestCallbackModule(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'minimal'

        def v2_on_file_diff(self, result):
            if 'diff' in result._result and result._result['diff']:
                self._display.display(self._get_diff(result._result['diff']))

    class TestCallbackModuleTestCase(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.old_stdout = sys.stdout
            self.old_st

# Generated at 2022-06-17 10:57:57.209065
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a mock object for the result
    result = Mock()
    result._host = Mock()
    result._host.get_name.return_value = "localhost"
    result._result = {"changed": False}
    result._task = Mock()
    result._task.action = "command"

    # Create a mock object for the display
    display = Mock()

    # Create a new CallbackModule object
    callback = CallbackModule()
    callback._display = display

    # Call the method v2_runner_on_ok
    callback.v2_runner_on_ok(result)

    # Check if the method _display.display was called with the correct parameters
    display.display.assert_called_with("localhost | SUCCESS => {}", color=None)


# Generated at 2022-06-17 10:57:57.910304
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:58:05.152576
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import unittest
    import ansible.plugins.callback.minimal as callback_minimal
    import ansible.plugins.callback as callback
    import ansible.plugins.callback.default as callback_default
    import ansible.plugins.callback.json as callback_json
    import ansible.plugins.callback.yaml as callback_yaml
    import ansible.plugins.callback.skippy as callback_skippy
    import ansible.plugins.callback.profile_roles as callback_profile_roles
    import ansible.plugins.callback.profile_tasks as callback_profile_tasks
    import ansible.plugins.callback.timer as callback_timer
    import ansible.plugins.callback.tree as callback_tree

# Generated at 2022-06-17 10:58:05.567952
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:58:12.234567
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object of class CallbackBase
    mock_callback_base = CallbackBase()

    # Create a mock object of class CallbackModule
    mock_callback_module = CallbackModule()

    # Create a mock object of class Result
    mock_result = Result()

    # Create a mock object of class Host
    mock_host = Host()

    # Create a mock object of class Task
    mock_task = Task()

    # Create a mock object of class TaskResult
    mock_task_result = TaskResult()

    # Create a mock object of class TaskResult
    mock_task_result = TaskResult()

    # Create a mock object of class TaskResult
    mock_task_result = TaskResult()

    # Create a mock object of class TaskResult
    mock_task_result = TaskResult()

    # Create a mock object of class Task

# Generated at 2022-06-17 10:58:22.199329
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test with a result that has a module_stderr
    result = {'_host': {'get_name': lambda: 'hostname'}, '_result': {'module_stderr': 'stderr'}, '_task': {'action': 'action'}}
    callback = CallbackModule()
    assert callback.v2_runner_on_failed(result) == 'hostname | FAILED! => {\n    "module_stderr": "stderr"\n}\n'
    # Test with a result that has no module_stderr

# Generated at 2022-06-17 10:58:33.674951
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test case 1
    result = {
        "_result": {
            "changed": True,
            "invocation": {
                "module_args": {
                    "name": "test",
                    "state": "present"
                }
            },
            "module_name": "user"
        },
        "_task": {
            "action": "user"
        },
        "_host": {
            "get_name": lambda: "test"
        }
    }
    cb = CallbackModule()
    cb.v2_runner_on_ok(result)
    assert cb._display.display_data == ["test | CHANGED => {'changed': True, 'invocation': {'module_args': {'name': 'test', 'state': 'present'}}, 'module_name': 'user'}"]

# Generated at 2022-06-17 10:58:40.132698
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    import sys
    import io

    class TestDisplay:
        def __init__(self):
            self.stdout = io.StringIO()
            self.stderr = io.StringIO()

        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            if stderr:
                self.stderr.write(msg)
            else:
                self.stdout.write(msg)

    class TestCallbackModule(CallbackModule):
        def __init__(self):
            self._display = TestDisplay()

    class TestRunnerResult:
        def __init__(self, host, result):
            self._host

# Generated at 2022-06-17 11:00:16.845488
# Unit test for method v2_runner_on_ok of class CallbackModule

# Generated at 2022-06-17 11:00:18.627412
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 11:00:26.039315
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import load_extra_

# Generated at 2022-06-17 11:00:29.153370
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Test with no parameters
    c = CallbackModule()
    assert c

    # Test with parameters
    c = CallbackModule({})
    assert c

# Generated at 2022-06-17 11:00:29.925581
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 11:00:35.048767
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Create a CallbackModule object
    cb = CallbackModule()

    # Create a result object
    result = type('', (), {})()
    result._result = {'diff': 'diff'}

    # Call the method v2_on_file_diff
    cb.v2_on_file_diff(result)

    # Check the result
    assert cb._get_diff(result._result['diff']) == 'diff'

# Generated at 2022-06-17 11:00:43.220306
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object of class CallbackBase
    mock_CallbackBase = CallbackBase()

    # Create a mock object of class CallbackModule
    mock_CallbackModule = CallbackModule()

    # Create a mock object of class Result
    mock_Result = Result()

    # Create a mock object of class Host
    mock_Host = Host()

    # Create a mock object of class Task
    mock_Task = Task()

    # Create a mock object of class ActionBase
    mock_ActionBase = ActionBase()

    # Create a mock object of class ActionModule
    mock_ActionModule = ActionModule()

    # Create a mock object of class ActionModule
    mock_ActionModule = ActionModule()

    # Create a mock object of class ActionModule
    mock_ActionModule = ActionModule()

    # Create a mock object of class ActionModule
    mock_Action

# Generated at 2022-06-17 11:00:43.873455
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 11:00:51.936777
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a mock object for the result
    result = Mock()
    result._host = Mock()
    result._host.get_name.return_value = 'localhost'
    result._result = {'changed': False}
    result._task = Mock()
    result._task.action = 'setup'

    # Create a mock object for the display
    display = Mock()

    # Create a CallbackModule object
    callback = CallbackModule(display)

    # Call the method v2_runner_on_ok
    callback.v2_runner_on_ok(result)

    # Check that the method v2_runner_on_ok called the method display of the display object
    display.display.assert_called_with('localhost | SUCCESS => {}', color='green')


# Generated at 2022-06-17 11:01:03.140148
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    import sys
    import os
    import tempfile
    import shutil
    import json
    import pytest
    import io
    import mock

    class TestCallbackModule(CallbackModule):
        def __init__(self):
            self._display = Display()
            self._display.verbosity = 3

        def _dump_results(self, result, indent=None, sort_keys=True, keep_invocation=False):
            return json.dumps(result, indent=indent, ensure_ascii=False, sort_keys=sort_keys)

    class Display:
        def __init__(self):
            self.columns = 80
            self.verbosity = 0
