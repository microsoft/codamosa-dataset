

# Generated at 2022-06-17 10:51:54.367366
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import unwrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import unwrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
   

# Generated at 2022-06-17 10:52:04.504437
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Create a mock object of class CallbackModule
    mock_CallbackModule = CallbackModule()

    # Create a mock object of class Result
    mock_result = Result()

    # Create a mock object of class TaskResult
    mock_task_result = TaskResult()

    # Create a mock object of class Host
    mock_host = Host()

    # Create a mock object of class Task
    mock_task = Task()

    # Create a mock object of class Play
    mock_play = Play()

    # Create a mock object of class PlayContext
    mock_play_context = PlayContext()

    # Create a mock object of class Playbook
    mock_playbook = Playbook()

    # Create a mock object of class PlaybookExecutor
    mock_playbook_executor = PlaybookExecutor()

    # Create a mock object of class PlaybookCL

# Generated at 2022-06-17 10:52:10.978745
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a mock object of class CallbackBase
    mock_display = CallbackBase()
    # Create a mock object of class CallbackModule
    mock_callback_module = CallbackModule()
    # Create a mock object of class Result
    mock_result = Result()
    # Set the attribute '_display' of mock_callback_module to mock_display
    mock_callback_module._display = mock_display
    # Call the method v2_runner_on_ok of mock_callback_module with mock_result as argument
    mock_callback_module.v2_runner_on_ok(mock_result)


# Generated at 2022-06-17 10:52:20.757073
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    import sys
    import io
    import unittest
    import unittest.mock

    class TestCallbackModule(CallbackModule):
        def __init__(self):
            self._display = unittest.mock.MagicMock()
            self._display.display = unittest.mock.MagicMock()
            self._dump_results = unittest.mock.MagicMock()
            self._dump_results.return_value = '{"diff": "diff"}'
            self._get_diff = unittest.mock.MagicMock()
            self._get_diff.return_value = 'diff'

    class TestCallbackBase(CallbackBase):
        def __init__(self):
            self._display = unitt

# Generated at 2022-06-17 10:52:28.075259
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeVars
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsVarsVars
    from ansible.vars.hostvars import HostVarsVarsVarsVars

# Generated at 2022-06-17 10:52:32.280067
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule.CALLBACK_VERSION == 2.0
    assert CallbackModule.CALLBACK_TYPE == 'stdout'
    assert CallbackModule.CALLBACK_NAME == 'minimal'

# Generated at 2022-06-17 10:52:42.616129
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    class TestCallbackModule(CallbackModule):
        def __init__(self):
            self.display = Display()
            self.call_count = 0


# Generated at 2022-06-17 10:52:55.097324
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Create a mock object for result
    result = Mock()
    # Create a mock object for result._result
    result._result = Mock()
    # Create a mock object for result._result['diff']
    result._result['diff'] = Mock()
    # Create a mock object for result._result['diff']['after']
    result._result['diff']['after'] = Mock()
    # Create a mock object for result._result['diff']['before']
    result._result['diff']['before'] = Mock()
    # Create a mock object for result._result['diff']['before_header']
    result._result['diff']['before_header'] = Mock()
    # Create a mock object for result._result['diff']['after_header']
    result._result['diff']['after_header'] = Mock()


# Generated at 2022-06-17 10:53:04.422645
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    import sys
    class TestCallbackModule(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'minimal'
        def v2_runner_on_ok(self, result):
            self._clean_results(result._result, result._task.action)
            self._handle_warnings(result._result)
            if result._result.get('changed', False):
                color = C.COLOR_CHANGED
                state = 'CHANGED'
            else:
                color = C.COLOR_OK
                state = 'SUCCESS'

# Generated at 2022-06-17 10:53:15.225955
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.callback import CallbackBase
   

# Generated at 2022-06-17 10:53:23.436179
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # create a callback module object
    callback = CallbackModule()

    # create a result object
    result = Result()

    # call the method
    callback.v2_runner_on_failed(result)


# Generated at 2022-06-17 10:53:24.208586
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:53:35.777091
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    import json

    class TestCallbackModule(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'minimal'

        def _command_generic_msg(self, host, result, caption):
            ''' output the result of a command run '''

            buf = "%s | %s | rc=%s >>\n" % (host, caption, result.get('rc', -1))
            buf += result.get('stdout', '')
            buf += result.get('stderr', '')
            buf += result.get('msg', '')

            return buf + "\n"

        def v2_runner_on_ok(self, result):
            self._clean

# Generated at 2022-06-17 10:53:47.916445
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Create a mock object of class CallbackModule
    mock_CallbackModule = CallbackModule()

    # Create a mock object of class Result
    mock_result = Result()

    # Create a mock object of class Host
    mock_host = Host()

    # Create a mock object of class Task
    mock_task = Task()

    # Create a mock object of class Play
    mock_play = Play()

    # Create a mock object of class PlayContext
    mock_play_context = PlayContext()

    # Create a mock object of class Playbook
    mock_playbook = Playbook()

    # Create a mock object of class Runner
    mock_runner = Runner()

    # Create a mock object of class Inventory
    mock_inventory = Inventory()

    # Create a mock object of class VariableManager
    mock_variable_manager = VariableManager()

    # Create

# Generated at 2022-06-17 10:53:57.157470
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-17 10:53:59.082167
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:54:09.844608
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object of class CallbackBase
    mock_CallbackBase = CallbackBase()
    # Create a mock object of class CallbackModule
    mock_CallbackModule = CallbackModule()
    # Create a mock object of class Result
    mock_Result = Result()
    # Create a mock object of class Host
    mock_Host = Host()
    # Create a mock object of class Task
    mock_Task = Task()
    # Create a mock object of class Play
    mock_Play = Play()
    # Create a mock object of class PlayContext
    mock_PlayContext = PlayContext()
    # Create a mock object of class Playbook
    mock_Playbook = Playbook()
    # Create a mock object of class PlaybookExecutor
    mock_PlaybookExecutor = PlaybookExecutor()
    # Create a mock object of class PlaybookCLI

# Generated at 2022-06-17 10:54:13.736554
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule().CALLBACK_VERSION == 2.0
    assert CallbackModule().CALLBACK_TYPE == 'stdout'
    assert CallbackModule().CALLBACK_NAME == 'minimal'

# Generated at 2022-06-17 10:54:24.197523
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display

# Generated at 2022-06-17 10:54:37.564378
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object for the result
    class MockResult:
        def __init__(self):
            self._result = {
                'changed': False,
                'msg': '',
                'rc': 0,
                'stderr': '',
                'stdout': '',
            }
            self._host = MockHost()
            self._task = MockTask()

    # Create a mock object for the host
    class MockHost:
        def __init__(self):
            self.name = 'localhost'

        def get_name(self):
            return self.name

    # Create a mock object for the task
    class MockTask:
        def __init__(self):
            self.action = 'shell'

    # Create a mock object for the display

# Generated at 2022-06-17 10:54:56.603887
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    display = Display()
    display.columns = 80
    display.verbosity = 2
    display.colorize = True
    display.set_terminal_title = False
    display.display = lambda x, y=None, z=None: x
    display.display_ok = lambda x: x
    display.display_error = lambda x: x
    display.display_warning = lambda x: x
    display.display_header = lambda x: x
    display.display_prompt = lambda x: x


# Generated at 2022-06-17 10:55:04.768227
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Create a mock object of class CallbackModule
    mock_CallbackModule = CallbackModule()
    # Create a mock object of class Result
    mock_Result = Result()
    # Create a mock object of class Host
    mock_Host = Host()
    # Create a mock object of class Task
    mock_Task = Task()
    # Create a mock object of class Action
    mock_Action = Action()
    # Create a mock object of class Play
    mock_Play = Play()
    # Create a mock object of class PlayContext
    mock_PlayContext = PlayContext()
    # Create a mock object of class Runner
    mock_Runner = Runner()
    # Create a mock object of class Playbook
    mock_Playbook = Playbook()
    # Create a mock object of class PlaybookExecutor
    mock_PlaybookExecutor = PlaybookExecutor()

# Generated at 2022-06-17 10:55:09.567751
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Create a CallbackModule object
    callback = CallbackModule()

    # Create a result object
    result = type('', (), {})()
    result._result = {'diff': 'diff'}

    # Test the method
    callback.v2_on_file_diff(result)


# Generated at 2022-06-17 10:55:15.850509
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback.minimal import CallbackModule
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.color import stringc
    from ansible.utils.plugin_docs import get_docstring
    from ansible.utils.sentinel import Sentinel
    from ansible.errors import AnsibleError
   

# Generated at 2022-06-17 10:55:23.406582
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_

# Generated at 2022-06-17 10:55:29.745173
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Create a CallbackModule object
    cb = CallbackModule()

    # Create a result object
    result = type('', (), {})()
    result._result = {'diff': 'diff'}

    # Test the method
    cb.v2_on_file_diff(result)

# Generated at 2022-06-17 10:55:38.769380
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a mock object for the result
    result = Mock()
    result.get.return_value = False
    result._host = Mock()
    result._host.get_name.return_value = "host"
    result._result = {
        "changed": False,
        "invocation": {
            "module_args": {
                "name": "test"
            }
        }
    }
    result._task = Mock()
    result._task.action = "test"

    # Create a mock object for the display
    display = Mock()

    # Create a CallbackModule object
    callback = CallbackModule()
    callback._display = display

    # Call the method
    callback.v2_runner_on_ok(result)

    # Check the result

# Generated at 2022-06-17 10:55:49.703347
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars

# Generated at 2022-06-17 10:55:58.116374
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    import json
    import sys
    import io
    import unittest

    class TestCallbackModule(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'minimal'

        def _command_generic_msg(self, host, result, caption):
            ''' output the result of a command run '''

            buf = "%s | %s | rc=%s >>\n" % (host, caption, result.get('rc', -1))
            buf += result.get('stdout', '')
            buf += result.get('stderr', '')
            buf += result.get('msg', '')

            return buf + "\n"


# Generated at 2022-06-17 10:55:59.176352
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:56:22.871385
# Unit test for method v2_runner_on_ok of class CallbackModule

# Generated at 2022-06-17 10:56:36.552673
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test with no changed
    result = {'changed': False}
    callback = CallbackModule()
    callback.v2_runner_on_ok(result)
    assert callback._display.display.call_count == 1
    assert callback._display.display.call_args[0][0] == '%s | SUCCESS => %s' % (result._host.get_name(), callback._dump_results(result._result, indent=4))
    assert callback._display.display.call_args[0][1] == C.COLOR_OK

    # Test with changed
    result = {'changed': True}
    callback = CallbackModule()
    callback.v2_runner_on_ok(result)
    assert callback._display.display.call_count == 1
    assert callback._display.display.call_args[0][0]

# Generated at 2022-06-17 10:56:47.930507
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object of class CallbackModule
    mock_CallbackModule = CallbackModule()
    # Create a mock object of class Result
    mock_result = Result()
    # Create a mock object of class Host
    mock_host = Host()
    # Create a mock object of class Task
    mock_task = Task()
    # Create a mock object of class Action
    mock_action = Action()
    # Create a mock object of class Display
    mock_display = Display()
    # Create a mock object of class DumpResults
    mock_dump_results = DumpResults()
    # Create a mock object of class HandleException
    mock_handle_exception = HandleException()
    # Create a mock object of class HandleWarnings
    mock_handle_warnings = HandleWarnings()
    # Create a mock object of class CommandGenericMsg


# Generated at 2022-06-17 10:56:55.974612
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # create a mock object
    mock_result = Mock()
    mock_result._host = Mock()
    mock_result._host.get_name.return_value = "test_host"
    mock_result._result = {'changed': True}
    mock_result._task = Mock()
    mock_result._task.action = "test_action"

    # create a mock object
    mock_display = Mock()
    mock_display.display = Mock()

    # create a CallbackModule object
    callback_module = CallbackModule()
    callback_module._display = mock_display

    # call the method
    callback_module.v2_runner_on_ok(mock_result)

    # assert the method was called

# Generated at 2022-06-17 10:56:56.451873
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:57:04.983581
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test with a result that has a module_stderr
    result = {'_result': {'module_stderr': 'module_stderr'}}
    callback = CallbackModule()
    callback.v2_runner_on_failed(result)
    assert callback._display.display.called
    assert callback._display.display.call_args[0][0] == 'module_stderr'
    assert callback._display.display.call_args[1]['color'] == 'red'

    # Test with a result that does not have a module_stderr
    result = {'_result': {'stdout': 'stdout', 'stderr': 'stderr', 'msg': 'msg'}}
    callback = CallbackModule()
    callback.v2_runner_on_failed(result)
    assert callback._

# Generated at 2022-06-17 10:57:14.822776
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

# Generated at 2022-06-17 10:57:23.530935
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroup

# Generated at 2022-06-17 10:57:31.239297
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Test with no diff
    result = {'diff': ''}
    callback = CallbackModule()
    callback.v2_on_file_diff(result)

    # Test with diff
    result = {'diff': 'diff'}
    callback = CallbackModule()
    callback.v2_on_file_diff(result)

# Generated at 2022-06-17 10:57:32.716403
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule() is not None

# Generated at 2022-06-17 10:58:08.837786
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import unwrap_var
    from ansible.utils.unsafe_proxy import wrap_text
    from ansible.utils.unsafe_proxy import unwrap_text
    from ansible.utils.unsafe_proxy import wrap_unsafe
    from ansible.utils.unsafe_proxy import unwrap_unsafe
    from ansible.utils.unsafe_proxy import wrap_errors

# Generated at 2022-06-17 10:58:16.214751
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.unicode import to_unicode
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    from ansible.utils.display import Display

# Generated at 2022-06-17 10:58:28.534165
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    import sys

    class TestDisplay(object):
        def __init__(self):
            self.displayed = []

        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            self.displayed.append(msg)

    class TestRunnerResult(object):
        def __init__(self, host, result):
            self._host = host
            self._result = result

    class TestHost(object):
        def __init__(self, name):
            self.name = name

        def get_name(self):
            return self.name


# Generated at 2022-06-17 10:58:29.129622
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:58:29.790145
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:58:39.111379
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

# Generated at 2022-06-17 10:58:41.201136
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 10:58:51.490761
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a new instance of CallbackModule
    cb = CallbackModule()

    # Create a new instance of Result
    result = Result()

    # Create a new instance of Host
    host = Host()

    # Set the value of the attribute result._host of result to host
    result._host = host

    # Create a new instance of Task
    task = Task()

    # Set the value of the attribute result._task of result to task
    result._task = task

    # Create a new instance of Action
    action = Action()

    # Set the value of the attribute task.action of task to action
    task.action = action

    # Create a new instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Set the value of the attribute action.ansible_module of action to ansible_module
    action.ansible_

# Generated at 2022-06-17 10:58:56.517252
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a mock object of class CallbackModule
    mock_CallbackModule = CallbackModule()

    # Create a mock object of class Result
    mock_result = Result()

    # Create a mock object of class Host
    mock_host = Host()

    # Create a mock object of class Task
    mock_task = Task()

    # Create a mock object of class Action
    mock_action = Action()

    # Create a mock object of class Display
    mock_display = Display()

    # Set attribute _display of mock_CallbackModule to mock_display
    mock_CallbackModule._display = mock_display

    # Set attribute _task of mock_result to mock_task
    mock_result._task = mock_task

    # Set attribute _host of mock_result to mock_host
    mock_result._host = mock_host

    # Set attribute action of

# Generated at 2022-06-17 10:59:06.507063
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import textwrap
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.utils.color import stringc
    from ansible.utils.unicode import to_unicode
    from ansible.utils.display import Display
    from ansible.utils.path import makedirs_safe
    from ansible.utils.hashing import checksum_s
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import is_complex_data

# Generated at 2022-06-17 11:00:29.073521
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Create a mock object of class CallbackModule
    callback = CallbackModule()
    # Create a mock object of class Result
    result = Result()
    # Create a mock object of class Host
    host = Host()
    # Create a mock object of class Task
    task = Task()
    # Create a mock object of class TaskResult
    task_result = TaskResult()
    # Create a mock object of class PlayContext
    play_context = PlayContext()
    # Create a mock object of class Play
    play = Play()
    # Create a mock object of class Playbook
    playbook = Playbook()
    # Create a mock object of class PlaybookExecutor
    playbook_executor = PlaybookExecutor()
    # Create a mock object of class PlaybookCLI
    playbook_cli = PlaybookCLI()
    # Create a mock object of class

# Generated at 2022-06-17 11:00:36.734416
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.plugins.callback.minimal import CallbackModule
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-17 11:00:46.395638
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.unicode import to_unicode
    from ansible.utils.display import Display
    from ansible.plugins.callback.minimal import CallbackModule
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

# Generated at 2022-06-17 11:00:53.826537
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test with a result that has a module_stderr
    result = {'_result': {'module_stderr': 'test_module_stderr'}}
    callback = CallbackModule()
    assert callback._command_generic_msg(result._result, "FAILED") == "test_module_stderr"

    # Test with a result that has a module_stdout
    result = {'_result': {'module_stdout': 'test_module_stdout'}}
    callback = CallbackModule()
    assert callback._command_generic_msg(result._result, "FAILED") == "test_module_stdout"

    # Test with a result that has a module_stdout and a module_stderr

# Generated at 2022-06-17 11:01:04.535935
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-17 11:01:15.333152
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.plugins.callback.minimal import CallbackModule
    import json
    import sys

    display = Display()
    display.verbosity = 4
    display.columns = 80
    display.colorize_errors = True
    display.colorize_ok = True
    display.colorize_skipped = True
    display.colorize_unreachable = True
    display.colorize_changed = True
    display.colorize_diff = True
    display.pager = False
    display.output = sys.stdout
    display.output_lock = None

    callback = CallbackModule()

# Generated at 2022-06-17 11:01:22.409891
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a mock object for the result
    result = Mock()
    result._host = Mock()
    result._host.get_name.return_value = "localhost"
    result._result = {'changed': False}
    result._task = Mock()
    result._task.action = "command"

    # Create a mock object for the display
    display = Mock()

    # Create a CallbackModule object
    callback = CallbackModule()
    callback._display = display

    # Call the method
    callback.v2_runner_on_ok(result)

    # Assert that the display object was called with the expected output
    display.display.assert_called_with("localhost | SUCCESS => {}", color=None)


# Generated at 2022-06-17 11:01:33.189495
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Create a dummy result object
    result = type('', (), {})
    result._result = {'diff': 'diff'}

    # Create a dummy display object
    display = type('', (), {})
    display.display = lambda x: x

    # Create a dummy object of class CallbackModule
    callback = CallbackModule()
    callback._display = display

    # Call the method v2_on_file_diff of class CallbackModule
    callback.v2_on_file_diff(result)

# Generated at 2022-06-17 11:01:33.909458
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-17 11:01:43.280320
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import ansible.plugins.callback.minimal
    import ansible.plugins.callback
    import ansible.playbook.task
    import ansible.vars.manager
    import ansible.inventory.manager
    import ansible.playbook.play
    import ansible.utils.vars
    import ansible.parsing.dataloader
    import ansible.executor.task_queue_manager
    import ansible.executor.playbook_executor
    import ansible.playbook.block
    import ansible.playbook.role
    import ansible.playbook.role.include
    import ansible.playbook.task_include
    import ansible.template
    import ansible.utils.template
    import ansible.errors
    import ansible.playbook.handler
    import ansible.plugins.callback
   