

# Generated at 2022-06-25 08:36:11.022567
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = None
    ignore_errors_0 = None
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)



# Generated at 2022-06-25 08:36:13.268606
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # 
    # TODO: Implement test code
    # 
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:36:16.829251
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Test case 1
    callback_module_1 = CallbackModule()
    result_1 = {
        "_result": {
            'diff': 'Some string.',
        },
    }
    callback_module_1.v2_on_file_diff(result_1)
    assert result_1 == {
        "_result": {
            'diff': 'Some string.',
        },
    }


# Generated at 2022-06-25 08:36:20.365609
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = callback_module_0.v2_runner_on_ok("result_0")


# Generated at 2022-06-25 08:36:21.939795
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:36:27.460499
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    results_0 = {"changed": False, "invocation": {"module_name": "debug"}}
    runner_result_0 = {"task_action": "debug"}
    runner_0 = {"_result": results_0, "_task": runner_result_0}
    result_0 = {"_result": results_0, "_task": runner_result_0}
    callback_module_0.v2_runner_on_ok(runner_0)

# Generated at 2022-06-25 08:36:30.897553
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_obj = CallbackModule()
    result = dict(diff = "diff")
    actual_return = callback_module_obj.v2_on_file_diff(result)
    expected_return = None
    assert actual_return is expected_return


# Generated at 2022-06-25 08:36:40.559271
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    call_back_module = CallbackModule()
    example_result = {
        "_ansible_ignore_errors": None,
        "_ansible_item_result": True,
        "_ansible_no_log": False,
        "_ansible_parsed": True,
        "changed": False,
        "invocation": {
            "module_args": {
                "follow": True,
                "path": "/home/testuser"
            },
            "module_name": "file"
        },
        "item": None,
        "rc": 1,
        "stderr": "*****\n***\n**\n*\n",
        "stdout": "",
        "stdout_lines": []
    }

    call_back_module.v2_runner_on_failed(example_result)


# Generated at 2022-06-25 08:36:46.019917
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result = CallbackModule()
    assert callback_module_0.v2_runner_on_ok(result) is None

# Generated at 2022-06-25 08:36:48.606932
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0
    #assert dir(callback_module_0)
    assert len(dir(callback_module_0)) == 22

# Generated at 2022-06-25 08:37:02.788188
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    mba = CallbackModule(display=None, options=None)
    assert(mba.CALLBACK_VERSION == 2.0)
    assert(mba.CALLBACK_TYPE == 'stdout')
    assert(mba.CALLBACK_NAME == 'minimal')



# Generated at 2022-06-25 08:37:05.042795
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()

test_case_0()
test_CallbackModule()

# Generated at 2022-06-25 08:37:14.286515
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    result = {
        "ansible_facts": {
            "discovered_interpreter_python": "/usr/bin/python"
        },
        "changed": false,
        "module_stderr": "",
        "module_stdout": "{\"changed\": false, \"failed\": false, \"meta\": {\"module_name\": \"setup\", \"module_set\": true}}",
        "stdout": "",
        "stdout_lines": []
    }

    obj = CallbackModule()
    obj.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:37:20.000015
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
        print("Testing for the constructor of class CallbackModule")
        callback_module_0=CallbackModule()
        assert callback_module_0.CALLBACK_VERSION is 2.0
        assert callback_module_0.CALLBACK_TYPE is "stdout"
        assert callback_module_0.CALLBACK_NAME is "minimal"
        assert callback_module_0 is not None


# Generated at 2022-06-25 08:37:24.857532
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result = dict()
    ignore_errors = bool()
    callback_module_1 = CallbackModule()
    return callback_module_1.v2_runner_on_failed(result, ignore_errors)


# Generated at 2022-06-25 08:37:34.807177
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    host_0 = Host('bc3e3306b4a4')
    host_0.set_name('host_0')
    task_0 = Task(('AnsibleEx1', 'AnsibleEx2'), 'shell = /bin/false')
    task_0.set_action('shell')
    result_0 = Result(host_0, task_0, {'changed': False})
    result_0.set__task(task_0)
    result_0._task = task_0
    result_0.set__host(host_0)
    result_0._host = host_0
    result_0.set__result({'changed': False})
    result_0._result = {'changed': False}
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_

# Generated at 2022-06-25 08:37:38.742255
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_v2_runner_on_ok_0 = CallbackModule()
    result_0 = (host, result, ignore_errors)
    result_0 = callback_module_v2_runner_on_ok_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:37:39.838089
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # test for initialization
    assert CallbackModule()


# Generated at 2022-06-25 08:37:46.831151
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result_0 = Mock()
    result_0.__getitem__.return_value = True
    result_0.__getitem__.return_value = True
    result_0.__getitem__.return_value = True
    result_0._result = {}
    result_0._result = {}
    result_0._result = {}
    result_0._result = {}
    result_0._result = {}
    result_0._result = {}
    result_0._result['diff'] = {}
    callback_module_0.v2_on_file_diff(result_0)


# Generated at 2022-06-25 08:37:48.991432
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    host = result = None
    action = 'ping'

    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:38:06.006585
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    result_0 = {'diff': {'after': '', 'before': '', 'before_header': '', 'after_header': ''}}
    module_0 = CallbackModule()
    module_0.v2_on_file_diff(result_0)


# Generated at 2022-06-25 08:38:15.525068
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()

    test_result_0 = dict()
    test_result_0['diff'] = \
        """New file /root/.ansible_check_options.  -rw-------. 1 root root 0 Sep  3 17:36 /root/.ansible_check_options
New file /root/.ansible_check_options.  -rw-------. 1 root root 0 Sep  3 17:36 /root/.ansible_check_options"""
    test_result_0['changed'] = True
    callback_module_0.v2_on_file_diff(test_result_0)

# Generated at 2022-06-25 08:38:26.846169
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Instantiate callback module instance and call method
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:38:34.418059
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # test case 0
    # default case
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed()
    '''
    result_0 = {'ansible_job_id': '2080572695.3519', 
    'changed': True, 
    'stdout': '', 
    'stdout_lines': [], 
    'stdout_plugin_option': 'oneline', 
    'stdout_plugin_result': '', 
    'stdout_plugin_result_lines': []}
    '''

# Generated at 2022-06-25 08:38:41.549767
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    # Prepare test data
    result = {
        '_result': {
            'stdout': '',
            'msg': '',
            'stderr': '',
            'rc': -1
        },
        '_task': {
            'action': 'setup'
        },
        '_host': {
            'get_name': lambda: 'localhost'
        }
    }
    ignore_errors = False
    # Call the method
    result = callback_module_0.v2_runner_on_failed(result, ignore_errors)
    # Check the result

# Generated at 2022-06-25 08:38:46.870432
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result = type('result', (object,), {'_result': {'diff': 'diff'}})
    result._result = type('result', (object,), {'diff': 'diff'})
    result._result.diff = 'diff'
    callback_module_0.v2_on_file_diff(result)



# Generated at 2022-06-25 08:38:48.315147
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result_0 = dummy('result_0')
    callback_module_0.v2_on_file_diff(result_0)


# Generated at 2022-06-25 08:38:50.110077
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()

if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-25 08:38:53.430993
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    pass

# Generated at 2022-06-25 08:38:55.780072
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    assert callback_module_0.v2_on_file_diff('result_0') == None


# Generated at 2022-06-25 08:39:17.561855
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    """
    Test v2_on_file_diff of class CallbackModule
    """

    # Init
    str_0 = "z\t%J!z'8< F"
    callback_module_0 = CallbackModule()
    str_1 = "z\t%J!z'8< F"
    str_2 = "z\t%J!z'8< F"
    str_3 = "z\t%J!z'8< F"
    str_4 = "z\t%J!z'8< F"
    str_5 = "z\t%J!z'8< F"
    str_6 = "z\t%J!z'8< F"
    str_7 = "z\t%J!z'8< F"

    # Behavior

# Generated at 2022-06-25 08:39:28.238013
# Unit test for method v2_on_file_diff of class CallbackModule

# Generated at 2022-06-25 08:39:29.461905
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule() is not None

# Generated at 2022-06-25 08:39:40.039984
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = "z\t%J!z'8< F"
    callback_module_0 = CallbackModule()
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    dict_12 = dict()
    dict_13 = dict()
    dict_14 = dict()
    dict_15 = dict()
    dict_16 = dict()
    dict_17 = dict()
    dict_18 = dict()
    dict_19 = dict()
    dict_20 = dict()


# Generated at 2022-06-25 08:39:43.794358
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    var_result = "g\r%a\r!d'8< F"
    assert callback_module_0.v2_on_file_diff(var_result) == None


# Generated at 2022-06-25 08:39:44.592898
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    var_0 = CallbackModule([])


# Generated at 2022-06-25 08:39:53.309215
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    assert  isinstance(test_case_0.var_0,Variable) and test_case_0.var_0.name == '$result'
    assert  test_case_0.var_0._host.name == 'z'
    assert  test_case_0.var_0.stdout == ""
    assert  'msg' not in test_case_0.var_0
    assert  test_case_0.var_0.stderr == ""
    assert  test_case_0.var_0.changed == False
    assert  test_case_0.var_0.rc == 0

# Generated at 2022-06-25 08:39:56.067384
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    str_0 = "B!aqC"
    callback_module_0 = CallbackModule()
    callback_module_0.v2_on_file_diff(str_0)


# Generated at 2022-06-25 08:39:58.404172
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = "z\t%J!z'8< F"
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(str_0)

# Generated at 2022-06-25 08:40:03.627804
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = "z\t%J!z'8< F"
    callback_module_0 = CallbackModule()
    # assert not equal: should fail.
    assert callback_module_0.v2_runner_on_ok(str_0) !=callback_module_0.v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:40:32.851749
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    print("Unit test for constructor of class CallbackModule")
    # Test 1
    callback_module_0 = CallbackModule()
    print("Your test 1 here!")

# Generated at 2022-06-25 08:40:37.610702
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = "z\t%J!z'8< F"
    callback_module_0 = CallbackModule()
    assert_equals("@\x84\x1e\x02}f\x8f\xed\x9d\xe2\x87\x1f\xec\x14\x92\xec\xe2\xfa", callback_module_0.v2_runner_on_ok(str_0))


# Generated at 2022-06-25 08:40:40.959532
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = "J\tNYsZ`q p+"
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:40:42.799783
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    str_0 = "z\t%J!z'8< F"
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(str_0)

# Generated at 2022-06-25 08:40:50.231753
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_1 = "OwC0Z.^\t@2xA-O^t\tX\t\\\tP\t`\t[\to\tG\tI\t}\t\tw\t3\tX\t\t)\t\t^\t\t\n\t\t\t\t\t\t\t\t\t^\t\t\t\t\t\t\t"
    callback_module_1 = CallbackModule()
    var_1 = callback_v2_runner_on_ok(str_1)


# Generated at 2022-06-25 08:40:57.801165
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = "z\t%J!z'8< F"
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(str_0)
    assert var_0 == None


# Generated at 2022-06-25 08:41:05.801078
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    str_0 = "z\t%J!z'8< F"
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_on_file_diff(str_0)


# Generated at 2022-06-25 08:41:11.761519
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_1 = "z\t%J!z'8< F"
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(str_1)


# Generated at 2022-06-25 08:41:24.195848
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
	# Create an instance of the CallbackModule class with empty constructor
	callback_module_0 = CallbackModule()
	
	# Invoke method v2_runner_on_ok of our CallbackModule instance and pass in the mock parameter
	# CallbackModule.v2_runner_on_ok(Mock('result'))
	var_0 = callback_module_0.v2_runner_on_ok(True)
	
	# Print the value of our test variable to the screen
	print(var_0)
	
	# Assert that var_0 contains the expected value
	# assert var_0 == ['SUCCESS']. 


# Generated at 2022-06-25 08:41:33.100381
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase

    loader = DataLoader()
    #inventories = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    #variable_manager = VariableManager(loader=loader, inventory=inventories)
    variable_manager = VariableManager()

    task = Task()
    task._role = None
    task.loop = None
    task.name = "test"
    task.action = "debug"

# Generated at 2022-06-25 08:42:45.005298
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = "z\t%J!z'8< F"
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:42:47.623791
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_1 = "R\tFw$@GK"
    callback_module_1 = CallbackModule()
    var_1 = callback_module_1.v2_runner_on_failed(str_1)


# Generated at 2022-06-25 08:42:48.980338
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_1 = "@W&Xs0k\b"
    callback_module_1 = CallbackModule()
    var_1 = callback_v2_runner_on_ok(str_1)


# Generated at 2022-06-25 08:42:55.931196
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = "z\t%J!z'8< F"
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok(str_0)
    assert var_0 == "z\t%J!z'8< F | SUCCESS =>"

# Generated at 2022-06-25 08:43:02.639110
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    str_0 = "As0h-a*\x7fn7~?4-"
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_on_file_diff(str_0)



# Generated at 2022-06-25 08:43:05.791879
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Setup scenario
    str_0 = "z\t%J!z'8< F"

    # Code to be tested
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(str_0)

    # Assert result is equal to expected
    assert (var_0 == 1)

# Generated at 2022-06-25 08:43:08.247381
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    str_0 = "z\t%J!z'8< F"
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_on_file_diff(str_0)


# Generated at 2022-06-25 08:43:14.792902
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_1 = "z\t%J!z'8< F"
    callback_module_1 = CallbackModule()
    var_1 = callback_v2_runner_on_failed(str_1)


# Generated at 2022-06-25 08:43:21.937495
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    str_0 = "l17S:qa^b?fjK7VuU"
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_on_file_diff(str_0)


# Generated at 2022-06-25 08:43:29.010552
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    str_0 = "z\t%J!z'8< F"
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.display(str_0)
