

# Generated at 2022-06-25 08:36:10.157400
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:36:12.585852
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed()


# Generated at 2022-06-25 08:36:17.328335
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_1 = fakes.FakeResult(host=None, task=None)
    callback_module_0.v2_runner_on_ok(result_1)


# Generated at 2022-06-25 08:36:21.343133
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result = dict()
    diff = dict()
    result['diff'] = diff
    callback_module_0.v2_on_file_diff(result)


# Generated at 2022-06-25 08:36:25.365512
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result = {'diff': u'- foo\n?  ++++\n+ bar\n'}
    try:
        callback_module_0.v2_on_file_diff(result)
    except:
        pass
    else:
        raise Exception(u"should fail")


# Generated at 2022-06-25 08:36:26.475472
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    assert 1 == 1

# Generated at 2022-06-25 08:36:30.525743
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    result = CallbackModule.v2_runner_on_ok(test_case_0)
    assert(result.name == 'minimal')
    assert(result.type == 'stdout')
    assert(result.CALLBACK_TYPE == 'stdout')
    assert(result.CALLBACK_NAME == 'minimal')


# Generated at 2022-06-25 08:36:34.140104
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    assert len(callback_module_1.v2_runner_on_failed(result="result_0", ignore_errors="ignore_errors_0")) > 0


# Generated at 2022-06-25 08:36:35.714006
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0 != None


# Generated at 2022-06-25 08:36:48.033549
# Unit test for method v2_runner_on_ok of class CallbackModule

# Generated at 2022-06-25 08:37:04.178464
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test with a 'dict' result value
    result_0 = {'stdout': 'Hello, world!', 'stderr': '', 'rc': 0, 'msg': '', 'changed': True}
    callback_module_0 = CallbackModule()
    callback_module_0.runner = {}
    callback_module_0.runner.display = {}
    callback_module_0.task = {}
    callback_module_0.task.action = 'run'
    callback_module_0.task.set_info = {}
    callback_module_0.task.set_info.return_value = None
    callback_module_0.task.succeeded = False
    callback_module_0.task.failed = False
    callback_module_0.task.skipped = False
    callback_module_0.task.bad

# Generated at 2022-06-25 08:37:10.715442
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result = Result()
    result._result = {'diff': '', 'invocation': {'module_args': '', 'module_name': ''}, 'ansible_job_id': '', '_ansible_no_log': False, '_ansible_item_result': False, 'changed': False}
    test_case_0()
    test_case_1()

# Generated at 2022-06-25 08:37:15.072037
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result = {
        'changed': True
    }
    result = object()
    callback_module_0.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:37:19.697146
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # test CallbackModule
    callback_module = CallbackModule()
    assert callback_module.CALLBACK_VERSION == 2.0
    assert callback_module.CALLBACK_TYPE == 'stdout'
    assert callback_module.CALLBACK_NAME == 'minimal'


# Generated at 2022-06-25 08:37:21.735556
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    cbmod=CallbackModule()
    cbmod.v2_on_file_diff(None)

# Generated at 2022-06-25 08:37:33.659803
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = AnsibleResult()
    base_0 = object()
    base_0.ansible_job_id = None
    base_0.__dict__ = dict()
    base_0.__dict__['__ansible_module__'] = None
    base_0.__dict__['__ansible_module__'] = "setup"
    base_0.changed = None
    base_0.__dict__['changed'] = False
    base_0.invocation = None
    base_0.__dict__['invocation'] = dict()
    base_0.invocation['module_name'] = "setup"
    base_0.__dict__['_ansible_verbose_always'] = False

# Generated at 2022-06-25 08:37:34.422679
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    assert True


# Generated at 2022-06-25 08:37:43.512731
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    # Test case 0
    result_0 = dict()
    result_0['_result'] = dict()
    result_0['_task'] = dict()
    result_0['_task']['action'] = 'setup'
    result_0['_result']['ansible_facts'] = dict()
    result_0['_result']['ansible_facts']['distribution'] = 'SUSE Linux Enterprise Server'
    result_0['_result']['ansible_facts']['distribution_major_version'] = 12
    result_0['_result']['ansible_facts']['distribution_release'] = 'SP1'
    result_0['_result']['ansible_facts']['distribution_version'] = '12.1'


# Generated at 2022-06-25 08:37:46.153189
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_1 = CallbackModule()
    try:
        callback_module_1.v2_runner_on_ok()
        assert False
    except TypeError:
        pass


# Generated at 2022-06-25 08:37:50.604936
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # method v2_on_file_diff should return an instance of string and should not return None 
    assert isinstance(CallbackModule().v2_on_file_diff({}), str) != None
    assert isinstance(CallbackModule().v2_on_file_diff({}), str) 


# Generated at 2022-06-25 08:38:00.932894
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    # Test function with no arguments
    var_0 = CallbackModule()
    var_1 = var_0.v2_runner_on_failed()
    assert var_1 == 0


# Generated at 2022-06-25 08:38:03.382337
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()
    var_0 = callback_module_1.v2_runner_on_failed(callback_module_0)


# Generated at 2022-06-25 08:38:08.219784
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module = CallbackModule()
    callback_module_0 = Result()
    callback_module_1 = Task()
    callback_module_2 = Runner()
    callback_module_2.task = callback_module_1
    callback_module_0.runner = callback_module_2
    var_0 = callback_module.v2_runner_on_ok(callback_module_0)


# Generated at 2022-06-25 08:38:09.210468
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    assert True


# Generated at 2022-06-25 08:38:11.987437
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    var_0 = CallbackModule()
    var_1 = CallbackModule()
    var_2 = var_1.v2_runner_on_failed(var_0)


# Generated at 2022-06-25 08:38:12.870950
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert "minimal" in CallbackModule.__name__

# Generated at 2022-06-25 08:38:26.000998
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible import constants as C
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.callback.minimal import CallbackModule
    import json
    import sys
    import shutil
    import tempfile

    # Initialization

# Generated at 2022-06-25 08:38:27.655490
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok(result=None)
    assert var_0 == None 


# Generated at 2022-06-25 08:38:29.270953
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    print(callback_module_0)

# Generated at 2022-06-25 08:38:32.739509
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    callback_module_result_0 = callback_module_0.v2_on_file_diff(callback_module_result_0)


# Generated at 2022-06-25 08:38:51.131796
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    #case 0: CallbackModule object is created with default paramters
    callback_module_0 = CallbackModule()
    #case 1: CallbackModule object is created with specified parameters
    callback_module_1 = CallbackModule(None, None, False)


# Generated at 2022-06-25 08:38:55.934115
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()
    var_0 = callback_module_1.v2_runner_on_ok(callback_module_0)


# Generated at 2022-06-25 08:39:04.305245
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    # Variable assignment for test case var_0
    result = 'diff'
    result_2 = None
    result_0 = { 'diff' : result_2 }
    result_1 = CallbackModule()
    result_3 = result_1._display
    result_3.display = mock.Mock()
    result_1._get_diff = mock.Mock()
    result_1._display = result_3
    result_1.v2_on_file_diff(result_0)
    result_1._display.display.assert_called_with(result_1._get_diff(result_2))

# Generated at 2022-06-25 08:39:07.963014
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    assert callback_module.__class__.__name__ == 'CallbackModule'


# Generated at 2022-06-25 08:39:12.440107
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    callback_module_1 = callback_module
    var_0 = callback_module_1.v2_runner_on_failed()


if __name__ == "__main__":
    test_CallbackModule_v2_runner_on_failed()

# Generated at 2022-06-25 08:39:17.386512
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    var_0 = CallbackModule()
    var_1 = CallbackModule()
    var_2 = var_1.v2_runner_on_ok(var_0)


# Generated at 2022-06-25 08:39:22.362638
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()

    var_0 = callback_module_0.v2_runner_on_ok(callback_module_0)

# Generated at 2022-06-25 08:39:26.020313
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()
    var_0 = callback_module_1.v2_runner_on_failed(callback_module_0)


# Generated at 2022-06-25 08:39:29.099208
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    var_0 = CallbackModule()


# Generated at 2022-06-25 08:39:29.861847
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    test_case_0()


# Generated at 2022-06-25 08:40:00.709234
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:40:04.910967
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()
    var_0 = callback_module_1.v2_runner_on_ok(callback_module_0)


# Generated at 2022-06-25 08:40:09.728520
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()
    var_0 = callback_module_1.v2_runner_on_ok(callback_module_0)


# Generated at 2022-06-25 08:40:16.900970
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Create a new instance of class CallbackModule
    callback_module = CallbackModule()

    # Create a new instance of class Result
    result = Result()

    # Call method v2_on_file_diff of class CallbackModule for argument result and keyword arguments
    callback_module.v2_on_file_diff(result)


# Generated at 2022-06-25 08:40:19.082340
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_2 = CallbackModule()
    var_1 = callback_module_2.v2_on_file_diff('result')


# Generated at 2022-06-25 08:40:26.904099
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()
    var_0 = callback_module_1.v2_runner_on_failed(callback_module_0)


# Generated at 2022-06-25 08:40:30.186182
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    assert callable(getattr(callback_module_0, 'v2_on_file_diff', None))


# Generated at 2022-06-25 08:40:33.443824
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()
    var_0 = callback_module_1.v2_runner_on_ok(callback_module_0)
    var_1 = callback_module_1.v2_runner_on_failed(callback_module_0)


# Generated at 2022-06-25 08:40:38.486559
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    var_0 = 'foo'
    var_1 = 12
    var_2 = 'foo'
    var_3 = True
    #var_4 = 'foo'
    #var_5 = 13
    callback_module_0.v2_runner_on_ok(var_0)
    callback_module_0.v2_runner_on_failed(var_1)
    callback_module_0.v2_runner_on_skipped(var_2)
    callback_module_0.v2_runner_on_unreachable(var_3)
    callback_module_0.v2_runner_on_ok("foo")
    #callback_module_0.v2_runner_on_failed("foo")
    callback_module_0.v2_runner

# Generated at 2022-06-25 08:40:40.890550
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()
    var_0 = callback_module_1.v2_runner_on_ok(callback_module_0)



# Generated at 2022-06-25 08:41:44.446266
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    callback_module_1 = CallbackModule()
    var_1 = callback_module_1.v2_runner_on_ok(callback_module_1)
    var_0 = callback_module.v2_runner_on_failed(callback_module_1)


# Generated at 2022-06-25 08:41:46.739187
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module = CallbackModule()
    var = CallbackModule()
    test_case_0_var = callback_module.v2_on_file_diff(var)
    assert test_case_0_var == None


# Generated at 2022-06-25 08:41:52.258542
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    cb = CallbackModule()
    assert cb.__class__.__name__ == 'CallbackModule'
    assert cb.__class__.__module__ == 'ansible.plugins.callback.minimal'
    assert cb.__class__.CALLBACK_VERSION == 2.0
    assert cb.__class__.CALLBACK_TYPE == 'stdout'
    assert cb.__class__.CALLBACK_NAME == 'minimal'
    assert cb.CALLBACK_VERSION == 2.0
    assert cb.CALLBACK_TYPE == 'stdout'
    assert cb.CALLBACK_NAME == 'minimal'


# Generated at 2022-06-25 08:41:52.967325
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    var_0 = CallbackModule()

# Generated at 2022-06-25 08:41:55.493245
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Set up mock objects and method return values
    callback_module_0 = CallbackModule()
    callback_module_0.v2_on_file_diff = unittest.mock.MagicMock()

    # Invoke method
    retval_0 = callback_module(
        'result_0',
    )

    # Assert return value
    assert retval_0 == callback_module_0.v2_on_file_diff()


# Generated at 2022-06-25 08:41:56.778186
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():

    # Test number: 0

    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_on_file_diff()


# Generated at 2022-06-25 08:41:59.280040
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()
    var_0 = callback_module_1.v2_runner_on_failed(callback_module_0)


# Generated at 2022-06-25 08:42:04.749995
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    assert callback_module.v2_runner_on_failed.__doc__ == 'Nothing done' # Check docstring is correctly captured


# Generated at 2022-06-25 08:42:09.732158
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()
    var_0 = callback_module_1.v2_runner_on_ok(callback_module_0)


# Generated at 2022-06-25 08:42:14.379289
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    return callback_module_0

if __name__ == "__main__":
    test_CallbackModule()

# Generated at 2022-06-25 08:44:50.651264
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    w_result = result._result
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()
    var_0 = callback_module_1.v2_runner_on_failed(w_result)


# Generated at 2022-06-25 08:44:53.516007
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_2 = CallbackModule()

    # Test with args
    # v2_runner_on_failed has 6 arguments.
    # v2_runner_on_failed(result, ignore_errors=False)
    # CallbackModule.v2_runner_on_failed(result, ignore_errors=False)
    assert False, "TODO: Implement your test here"


# Generated at 2022-06-25 08:44:55.524651
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:45:01.732525
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Create object
    callback_module_0 = CallbackModule()

    # Check if test method exists
    if hasattr(callback_module_0, 'v2_on_file_diff'):
        # Call test method
        callback_module_0.v2_on_file_diff(__import__('ansible_collections.ansible.builtin').plugins.callbacks.__getattribute__('CallbackModule'))

        # Check if result is correct
        assert True
    else:
        # Result is false if test method does not exist
        assert False


# Generated at 2022-06-25 08:45:04.986392
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(callback_module_1)


# Generated at 2022-06-25 08:45:14.982386
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    if (not (callback_module.CALLBACK_TYPE == 'stdout')):
        print("Expected {}, but got {}".format('stdout', callback_module.CALLBACK_TYPE))
        assert False
    if (not (callback_module.CALLBACK_VERSION == 2.0)):
        print("Expected {}, but got {}".format(2.0, callback_module.CALLBACK_VERSION))
        assert False
    if (not (callback_module.CALLBACK_NAME == 'minimal')):
        print("Expected {}, but got {}".format('minimal', callback_module.CALLBACK_NAME))
        assert False

# Generated at 2022-06-25 08:45:17.926250
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed()

# Generated at 2022-06-25 08:45:19.812697
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok(callback_module_1)


if __name__ == '__main__':
    test_CallbackModule_v2_runner_on_ok()

# Generated at 2022-06-25 08:45:20.610055
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()

# Generated at 2022-06-25 08:45:29.854982
# Unit test for method v2_runner_on_ok of class CallbackModule