

# Generated at 2022-06-25 08:36:11.024705
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_1 = CallbackModule()
    task_ctxt = {}
    result_ctxt = {}
    task_ctxt['action'] = 'push'
    result_ctxt['changed'] = True
    result_ctxt['ansible_facts'] = {'test1':'test1'}
    result_ctxt['rc'] = 1
    result_ctxt['stderr'] = 'test'
    result_ctxt['stdout'] = 'test'
    result_ctxt['msg'] = 'test'
    result_ctxt['eid'] = 'test'
    result_ctxt['ansible_job_id'] = 'test'
    result_ctxt['ansible_module_name'] = 'test'
    result_ctxt['stdout_lines'] = 'test'
    result_ctxt

# Generated at 2022-06-25 08:36:14.998006
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result = dict()
    assert callback_module_0.v2_on_file_diff(result) is None
    result['diff'] = 'Test String'
    assert callback_module_0.v2_on_file_diff(result) is None


# Generated at 2022-06-25 08:36:15.630629
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    cbm = CallbackModule()


# Generated at 2022-06-25 08:36:20.685664
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()

    result_0 = {'stdout': '', 'msg': '', 'changed': False}
    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:36:29.691333
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_v2_runner_on_ok_0 = CallbackModule()
    result = type('result', (object,), {
        "_host": type('host', (object,), {
            "name": "host_01",
            "uuid": "uuid_01",
            "groups": ["group_01", "group_02"],
            "Updated": "",
            "msg": type('msg', (object,), {
                "stderr": "",
                "stdout": "",
                "rc": 0,
            }),
        }),
        "_task": type('task', (object,), {
            "action": "action_01",
        }),
    })
    callback_module_v2_runner_on_ok_0.v2_runner_on_ok(result)


#

# Generated at 2022-06-25 08:36:33.576525
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    try:
        assert True
    except AssertionError as e:
        print("Test case 0 failed: " + str(e))
    else:
        print("Test case 0 passed")


# Generated at 2022-06-25 08:36:34.507674
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()

# Generated at 2022-06-25 08:36:35.387718
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert callable(CallbackModule)


# Generated at 2022-06-25 08:36:47.805105
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module = CallbackModule()

# Generated at 2022-06-25 08:36:50.320008
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result_0 = "result_0"
    callback_module_0.v2_on_file_diff(result_0)


# Generated at 2022-06-25 08:37:00.114380
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_temp = CallbackModule()
    callback_module_temp.v2_runner_on_failed(result, ignore_errors=True)


# Generated at 2022-06-25 08:37:01.475355
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()

# Generated at 2022-06-25 08:37:14.170654
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    result_1 = {'msg': '', 'stdout': '', '_ansible_parsed': True, 'changed': False, 'failed': True, 'warnings': [], '_ansible_no_log': False, '_ansible_item_label': '', 'rc': 10, 'invocation': {'module_name': 'setup', 'module_args': ''}, 'stderr': '', '_ansible_ignore_errors': False, '_ansible_item_result': True, 'stdout_lines': [], '_ansible_verbose_always': True, '_ansible_no_log_values': []}
    ignore_errors_1 = False

# Generated at 2022-06-25 08:37:17.533310
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result_0 = {}
    result_0['diff'] = {}
    callback_module_0.v2_on_file_diff(result_0)



# Generated at 2022-06-25 08:37:20.086353
# Unit test for constructor of class CallbackModule
def test_CallbackModule():

    (result, error_message) = call_construction(CallbackModule)
    assert result == True, error_message


if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-25 08:37:21.664074
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    pass


# Generated at 2022-06-25 08:37:27.443616
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    data_0 = {'reason': 'Non-zero return code', 'changed': False, 'rc': 1, 'cmd': 'pwd'}
    result = callback_module_0.v2_runner_on_failed(data_0)


# Generated at 2022-06-25 08:37:32.042488
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0.CALLBACK_VERSION == 2.0
    assert callback_module_0.CALLBACK_TYPE == 'stdout'
    assert callback_module_0.CALLBACK_NAME == 'minimal'


# Generated at 2022-06-25 08:37:39.850286
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = dict({})
    result_0['_result'] = dict({})
    result_0['_result']['changed'] = False
    result_0['_task'] = dict({})
    result_0['_task']['action'] = 'setup'
    result_0['_host'] = dict({})

    result_0['_host']['get_name'] = lambda: 'localhost'

    callback_module_0.v2_runner_on_ok(result_0)

# Generated at 2022-06-25 08:37:44.315427
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result__result_0 = {'diff': 'diff_0'}
    result_0 = {'_result': result__result_0}
    callback_module_1 = CallbackModule.v2_on_file_diff(callback_module_0, result_0)

    assert callback_module_0 is callback_module_1


# Generated at 2022-06-25 08:37:55.059722
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = b'(\x03\xbd\xc7\x99\x8d\xc4\xd1k\x87S\xb2\x19\x1d\xed\x87'
    ignore_errors_0 = False
    callback_module_0_v2_runner_on_failed = callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)
    if callback_module_0_v2_runner_on_failed == None:
        pass
    else:
        raise Exception('Test Failed')


# Generated at 2022-06-25 08:38:02.308242
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    bytes_0 = b'\xc2\x00\xac\r.\xf4\xf4SCo\xbb\x9c!\n'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_skipped(bytes_0)
    callback_module_1 = CallbackModule()
    var_1 = callback_v2_runner_on_ok(var_0)


# Generated at 2022-06-25 08:38:08.553687
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_0 = b'\xc2\x00\xac\r.\xf4\xf4SCo\xbb\x9c!\n'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_skipped(bytes_0)
    float_0 = 3447.88
    callback_module_1 = CallbackModule(float_0)
    var_1 = callback_module_1.v2_runner_on_failed(var_0)
    assert var_0 != var_1

# Generated at 2022-06-25 08:38:13.700491
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bytes_0 = b'\xc2\x00\xac\r.\xf4\xf4SCo\xbb\x9c!\n'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_skipped(bytes_0)
    float_0 = 3447.88
    callback_module_1 = CallbackModule(float_0)


# Generated at 2022-06-25 08:38:19.862183
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # These two lines are to disable pylint complaning about unecessary
    # module attr access and no-self-use
    # pylint: disable=E1101
    # pylint: disable=R0201

    # Normal operation
    bytes_0 = b'\x1a\xbe\x9dX\xd0\xc7\xe7\x93\x13\x1e\x9a\x95'
    var_0 = CallbackModule(bytes_0)

    # Assert that the object was constructed correctly
    assert var_0

    # Passing an invalid argument for the display parameter
    bytes_0 = b'\x8c\x03\x82\x1e\xebQ\x19\x18\x06\x0e\xf4o\xac'

# Generated at 2022-06-25 08:38:26.664772
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    bytes_0 = b'\x02+\xa8\xb6\x1a\xc7\x9a\x8e\xf5\x91\x95\x00\xb3'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(bytes_0)
    float_0 = 940.3632707717015
    callback_module_1 = CallbackModule(float_0)


# Generated at 2022-06-25 08:38:31.858962
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    bytes_0 = b'\xdf\xb0\x8e\x87\xcd\xf4\xbd\x8f\xe5\x02\x12\xdb\xc5\x2f\x0b\x1e\xb8\x17\xb3!\n'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(bytes_0)
    int_0 = 48
    callback_module_1 = CallbackModule(int_0)


# Generated at 2022-06-25 08:38:38.256853
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_0 = b'\xbb\xc4\xdb2\x8f\xd1\xc6Z\xcc\xe9\xfb\xe0\xbe\x1b\xbe\xc9'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(bytes_0)
    long_0 = 344788
    callback_module_1 = CallbackModule(long_0)


# Generated at 2022-06-25 08:38:41.573605
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    bytes_0 = b'\xc2\x00\xac\r.\xf4\xf4SCo\xbb\x9c!\n'
    callback_module_0 = CallbackModule()
    callback_module_0.v2_on_file_diff(bytes_0)


# Generated at 2022-06-25 08:38:47.617525
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
  bytes_0 = b'\xc2\x00\xac\r.\xf4\xf4SCo\xbb\x9c!\n'
  callback_module_0 = CallbackModule()
  var_0 = callback_v2_runner_on_failed(bytes_0)
  float_0 = 3447.88
  callback_module_1 = CallbackModule(float_0)
  callback_v2_runner_on_failed(callback_module_1)


# Generated at 2022-06-25 08:39:05.527579
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    class_0 = CallbackModule

    callback_module_0 = class_0()


# Generated at 2022-06-25 08:39:09.572559
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    # This is a bug
    # callback_module_0 = CallbackModule()
    # var_0 = callback_v2_runner_on_ok(...)
    # raise Exception("Implicit return value of CallbackModule.v2_runner_on_ok() is not a Result")
    assert False


# Generated at 2022-06-25 08:39:19.358561
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    format_0 = '{0:>6}'
    format_1 = '{0:<5}'
    format_2 = '{0:<10.5}'
    format_3 = '{{{0}}}'
    bytes_0 = b'\xc2\x00\xac\r.\xf4\xf4SCo\xbb\x9c!\n'
    callback_module_0 = CallbackModule()
    callback_v2_runner_on_failed(bytes_0)
    str_0 = '{0:d}'
    str_1 = '\t\n'
    str_2 = '\t\n'
    str_3 = '\t\n'
    str_4 = '-\x11'
    str_5 = '\t\n'
    str

# Generated at 2022-06-25 08:39:26.230929
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test
    bytes_0 = b'\xd5\xad\x9a>\x80D\xe7\xea\x0c\xaa\xba\x7f'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(bytes_0)
    float_0 = 8236.958
    callback_module_1 = CallbackModule(float_0)


# Generated at 2022-06-25 08:39:28.513459
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()

# Generated at 2022-06-25 08:39:31.284885
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    # Instance of class CallbackModule
    callback_module_0 = CallbackModule()

    # TODO: more tests
    # Test only ensures that this method is callable
    int_0 = callback_module_0.v2_runner_on_failed(int_0)



# Generated at 2022-06-25 08:39:38.127522
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    bytes_0 = b'\xff\xd3\x9b$\x8d\xc6\x1e\x98\x8c\x11\x89\xab\x90'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(bytes_0)
    float_0 = 1299.15
    callback_module_1 = CallbackModule(float_0)


# Generated at 2022-06-25 08:39:44.628755
# Unit test for constructor of class CallbackModule
def test_CallbackModule():

    bytes_0 = b'\xb1\xdb\x93\x86\x88#\xd0\xc1\xe9\xa2O\xd0\x89\xe2\x92\\\xeb\x9e\x95\x9c'
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_skipped(bytes_0)


# Generated at 2022-06-25 08:39:52.403081
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    print("Executing test for method v2_runner_on_failed of class CallbackModule")
    bytes_0 = b'\xc2\x00\xac\r.\xf4\xf4SCo\xbb\x9c!\n'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_skipped(bytes_0)
    float_0 = 3447.88
    callback_module_1 = CallbackModule(float_0)


# Generated at 2022-06-25 08:39:56.032413
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    v2_on_file_diff_0 = CallbackModule()
    v2_on_file_diff_1 = CallbackModule()
    v2_on_file_diff_1 = CallbackModule()
    v2_on_file_diff_0.v2_on_file_diff()


# Generated at 2022-06-25 08:40:30.729527
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Input: v2_runner_on_failed(bytes_0)
    bytes_0 = b'@\x00\x00\x00\n'
    callback_module_0 = CallbackModule()
    callback_module_v2_runner_on_failed(callback_module_0, bytes_0)


# Generated at 2022-06-25 08:40:36.227384
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    bytes_0 = b'u\xcc\xcd\xa3\x96\x9f\x0e\xb5\x00\xdf\x01\x00\x00\x00'
    var_0 = callback_v2_on_file_diff(bytes_0)
    float_0 = 0.6
    callback_module_0 = CallbackModule(float_0)


# Generated at 2022-06-25 08:40:39.549681
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    try:
        CallbackModule()
    except:
        pass


# Generated at 2022-06-25 08:40:50.278914
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_2 = CallbackModule(0)

# Generated at 2022-06-25 08:40:58.043429
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    result = {}
    result['diff'] = '''
- file.txt
+ file.txt
@@ -1 +1 @@
-hello
+hello2
'''
    callback_module_0 = CallbackModule()
    callback_module_0.v2_on_file_diff(result)

# Generated at 2022-06-25 08:41:07.236646
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # First, set up the test
    bytes_0 = b'\xc2\x00\xac\r.\xf4\xf4SCo\xbb\x9c!\n'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(bytes_0)
    # Second, test the results
    assert var_0 == None, "'v2_runner_on_ok' did not return the correct value"


# Generated at 2022-06-25 08:41:13.569780
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-25 08:41:25.466635
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-25 08:41:31.794899
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
        bytes_0 = b'\xab\x94\x91\xaa\x92;\xd2\xa0\xa8\x1c\x1f'
        callback_module_0 = CallbackModule()
        callback_module_0.v2_runner_on_ok(bytes_0)
        bytes_1 = b'\xc2\x00\xac\r.\xf4\xf4SCo\xbb\x9c!\n'
        callback_module_1 = CallbackModule()
        callback_module_1.v2_runner_on_ok(bytes_1)

if __name__ == '__main__':
    test_case_0()
    test_CallbackModule_v2_runner_on_ok()

# Generated at 2022-06-25 08:41:33.460710
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    result = Result()
    callback_module = CallbackModule()
    callback_module.v2_on_file_diff(result)


# Generated at 2022-06-25 08:42:46.849678
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create an instance of the CallbackModule class
    callback_module = CallbackModule()

    # Execute method v2_runner_on_failed
    callback_module.v2_runner_on_failed()

    # Verify that the method v2_runner_on_failed called the self._handle_exception method
    assert callback_module._handle_exception.called
    # Verify that the method v2_runner_on_failed called the self._handle_warnings method
    assert callback_module._handle_warnings.called

    # Check the result of the v2_runner_on_failed method
    assert isinstance(result, str)
    assert result == "FAILED! => {'rc': -1, 'failed': True, 'changed': False, 'stderr': '', 'msg': '', 'stdout': ''}"

# Generated at 2022-06-25 08:42:53.305152
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bytes_0 = b'\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
    callback_module_0 = CallbackModule()
    callback_module_0.v2_on_file_diff(callback_module)
    assert callback_module_0.CALLBACK_TYPE == 'stdout'
    assert callback_module_0.CALLBACK_NAME == 'minimal'
    callback_module_

# Generated at 2022-06-25 08:42:58.684257
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_0 = b'\x1f\x19\xc0;\xdb\xef\x0c\xad\\$\x8e\xc5\x90\x00\x83\x00\x00\x01\x01\x08\n\n\n\x01'

    bytes_1 = b'\x1f\x19\xc0;\xdb\xef\x0c\xad\\$\x8e\xc5\x90\x00\x83\x00\x00\x01\x01\x08\n\n\n\x01'

    CallbackModule_0 = CallbackModule()
    var_0 = CallbackModule_0.v2_runner_on_failed(bytes_0, bytes_1)
    assert var_0 == None



# Generated at 2022-06-25 08:43:04.100208
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_0 = b'\xc2\x00\xac\r.\xf4\xf4SCo\xbb\x9c!\n'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(bytes_0)
    float_0 = 3447.88
    callback_module_1 = CallbackModule(float_0)


# Generated at 2022-06-25 08:43:06.321736
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()


# Generated at 2022-06-25 08:43:09.641970
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_0 = b'\xc2\x00\xac\r.\xf4\xf4SCo\xbb\x9c!\n'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(bytes_0)
    callback_module_0.v2_runner_on_failed(var_0)


# Generated at 2022-06-25 08:43:11.744220
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert isinstance(CallbackModule, object)
    assert isinstance(CallbackModule, CallbackBase)


# Generated at 2022-06-25 08:43:17.922947
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bytes_0 = b'\xe4\xb7\xbf\x8f\xef\xfd\x7f\x03\x11\x9f\x11\xce\x1b\x7f\xc3\xe5\x96\x98\xde\xb9\xcb\x08\xe1\x8e\xec\xa5A\xdc\x18\xd1\x9b\xd1\xbb'
    bytes_1 = b'\xaf$\xec\x07\xfc\xa9\x0f\xfa\xaa\x8f\xff\xfa\xab\x8f\xf4\x9f\xbc\x0c\xee\xbc\xb2\xf3'
    float_0 = 927.9

# Generated at 2022-06-25 08:43:24.255556
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    bytes_0 = b'\xc2\x00\xac\r.\xf4\xf4SCo\xbb\x9c!\n'
    var_0 = callback_v2_runner_on_skipped(bytes_0)
    result_0 = '\xff\xf4\xd3\xf5\xc3\xe5\xee\xf6'
    float_0 = 3447.88
    callback_module_1 = CallbackModule(float_0)


# Generated at 2022-06-25 08:43:32.654671
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    result = FakeResult({"diff": "\tExpected: {'rc': 0, 'stdout': 'foo'}\n\tActual:   {'rc': 0, 'stdout': 'bar'}"})
    callback = CallbackModule()
    callback.v2_on_file_diff(result)
    assert callback.display.displayed == [
        u'--- \n'
        u'+++ \n'
        u'@@ -1 +1 @@\n'
        u'-Expected: {\'rc\': 0, \'stdout\': \'foo\'}\n'
        u'+Actual:   {\'rc\': 0, \'stdout\': \'bar\'}'
    ]
