

# Generated at 2022-06-25 08:36:17.641917
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    host_0 = "f9a4b12a36d24d4e9a8a8389401c4d6e"
    color_0 = "e05634f379824a07b36f2b7da3b471d3"

    str_0 = "71b5f5c5f5d547a0ba8ff8666c389d56"
    callback_module_0 = CallbackModule(str_0)
    result_0 = Result(host_0, ResultState.HOST_UNREACHABLE, {'msg': 'UNREACHABLE! => {\'changed\': False, \'unreachable\': True}'})

# Generated at 2022-06-25 08:36:18.882245
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    assert True


# Generated at 2022-06-25 08:36:22.630453
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    display_0 = CallbackModule('the specified credentials were rejected by the server')
    result_0 = CallbackModule('the specified credentials were rejected by the server')
    display_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:36:29.359032
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.playbook import Playbook, PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars import VariableManager

    v = VariableManager()
    i = Inventory()
    g = Group('g1')
    i.add_group(g)
    h = Host('h1')
    i.add_host(h)
    g.add_host(h)
    t = Task()
    b = Block(Task())
    b.add_task(t)

# Generated at 2022-06-25 08:36:34.780768
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    host_0 = Host()
    host_0.set_name('host_0')
    result_0 = Result(host_0)
    result_0._task.action = '<lambda>'
    callback_module_0 = CallbackModule('<lambda>')
    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:36:41.519496
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    str_0 = 'the specified credentials were rejected by the server'
    callback_module_0 = CallbackModule(str_0)
    dict_0 = {}
    dict_0['diff'] = 'the specified credentials were rejected by the server'
    result_0 = callback_module_0.v2_on_file_diff(dict_0)
    assert result_0 == None


# Generated at 2022-06-25 08:36:48.476703
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Tests that the method defined in this callback module is able to run without raising an exception
    str_0 = 'the specified credentials were rejected by the server'
    callback_module_0 = CallbackModule(str_0)
    assert isinstance(callback_module_0, CallbackModule)
    try:
        callback_module_0.v2_runner_on_failed()
    except:
        raise AssertionError('An exception was raised when trying to run the method defined in this Callback Module.')


# Generated at 2022-06-25 08:36:54.742242
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Testing if the instance was created correctly
    test_case_0()

# If this file is called directly, then run the test
if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-25 08:37:04.284191
# Unit test for method v2_runner_on_ok of class CallbackModule

# Generated at 2022-06-25 08:37:11.184841
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():

    str_0 = 'the specified credentials were rejected by the server'
    callback_module_0 = CallbackModule(str_0)

    result_0 = dict()
    str_1 = 'diff'
    result_0[str_1] = str_0
    result_1 = callback_module_0.v2_on_file_diff(result_0)

    assert result_1 is None


# Generated at 2022-06-25 08:37:20.988386
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    str_0 = 'test_CallbackModule'
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    assert callback_module_0.CALLBACK_VERSION == 2.0
    assert callback_module_0.CALLBACK_TYPE == 'stdout'
    assert callback_module_0.CALLBACK_NAME == 'minimal'

# # Unit test for function _command_generic_msg

# Generated at 2022-06-25 08:37:25.628534
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    str_0 = ''
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    callback_module_0.v2_on_file_diff(str_0)

# Generated at 2022-06-25 08:37:32.170710
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Initialization of TestCase instance
    testCase = TestCase(methodName = 'v2_on_file_diff')

    # test CallbackModule instance creation
    callback_module_0 = CallbackModule()

    # test method v2_on_file_diff of CallbackModule
    testCase.assertEqual(callback_module_0.v2_on_file_diff(), None, 'Test v2_on_file_diff of callback_module_0')


# Generated at 2022-06-25 08:37:33.775412
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    str_0 = ''
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)

# Generated at 2022-06-25 08:37:36.499728
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Setup
    str_0 = ''
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)

    # Invocation
    var_0 = callback_module_0.v2_on_file_diff(str_0)

    # Verification
    assert not var_0

# Generated at 2022-06-25 08:37:43.628320
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = ''
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    var_0 = callback_v2_runner_on_ok(str_0)


# Generated at 2022-06-25 08:37:48.119487
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():

    # Setup
    str_1 = ''
    dict_1 = {}
    callback_module_1 = CallbackModule(dict_1)
    callback_module_1.v2_on_file_diff(str_1)

    # Check return type
    assert isinstance(callback_module_1.v2_on_file_diff(str_1), type(None))


# Generated at 2022-06-25 08:37:52.860066
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = ''
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    var_0 = callback_v2_runner_on_ok(str_0)


# Generated at 2022-06-25 08:38:01.179517
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    result_0 = {}
    result_0['_result'] = {'msg': 'msg', 'rc': 0, 'stdout': 'stdout', 'stderr': 'stderr', 'changed': False}
    result_0['_task'] = 'task'
    result_0['_host'] = 'host'
    callback_v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:38:03.404834
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    var_0 = callback_module_0.v2_on_file_diff()


# Generated at 2022-06-25 08:38:12.208330
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    assert(isinstance(callback_module_0, CallbackModule))


# Generated at 2022-06-25 08:38:13.334739
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    args_0 = 'result'
    args_1 = 'ignore_errors'


# Generated at 2022-06-25 08:38:14.924532
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    list_0 = []
    var_0 = callback_module_0._clean_results(list_0, list_0)


# Generated at 2022-06-25 08:38:20.779852
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = ''
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    var_0 = callback_module_0.v2_runner_on_failed(str_0)
    assert var_0 == None, "Unable to find expected result"


# Generated at 2022-06-25 08:38:24.017190
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    var_0 = callback_v2_runner_on_ok(str_0)


# Generated at 2022-06-25 08:38:28.886103
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    try:
        str_0 = ''
        dict_0 = {}
        callback_module_0 = CallbackModule(dict_0)
        var_0 = callback_module_0.v2_runner_on_ok(str_0)
        raise RuntimeError("Expected TypeError but got {}".format(type(ex)))
    except TypeError as ex:
        print("Expected TypeError")


# Generated at 2022-06-25 08:38:32.696734
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    str_0 = ''
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    var_0 = callback_module_0.v2_on_file_diff(str_0)


# Generated at 2022-06-25 08:38:40.450406
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = 'test_str'
    dict_0 = {'test_key': 'test_value'}
    Test_CallbackModule_0 = CallbackModule(dict_0)
    Test_CallbackModule_0.v2_runner_on_ok(str_0)
    assert Test_CallbackModule_0._handle_warnings(dict_0) == None,\
'Failed to assert that _handle_warnings return value of CallbackModule equals expected.'
    assert Test_CallbackModule_0._clean_results(dict_0, str_0) == None,\
'Failed to assert that _clean_results return value of CallbackModule equals expected.'

# Generated at 2022-06-25 08:38:45.614035
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = ''
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    var_0 = callback_v2_runner_on_ok(str_0)


# Generated at 2022-06-25 08:38:48.137240
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    str_0 = ''
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    result_0 = dict_0
    dict_0 = {}
    dict_0['diff'] = ()
    result_0['_result'] = dict_0
    callback_v2_on_file_diff(result_0)


# Generated at 2022-06-25 08:39:09.126205
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Case 0
    str_0 = ''
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    var_0 = callback_module_0.v2_on_file_diff(str_0)

# Generated at 2022-06-25 08:39:13.325898
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = ''
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    # TODO: Refactor CallbackModule.v2_runner_on_ok to not have the 'result' parameter
    # It is unused in its default implementation
    callback_v2_runner_on_ok(dict_0)


# Generated at 2022-06-25 08:39:20.111046
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = 'test string'
    dict_0 = {'foo': 'bar'}
    dict_1 = {'foo': 'bar', 'baz': 'qux'}
    callback_module_0 = CallbackModule(dict_0)
    callback_module_0._display = mock.Mock()
    callback_module_0._dump_results = mock.Mock(return_value=dict_1)
    callback_module_0._handle_exception = mock.Mock()
    callback_module_0._handle_warnings = mock.Mock()
    callback_module_0._display.display.return_value = None
    callback_module_0.v2_runner_on_failed(str_0)

# Generated at 2022-06-25 08:39:21.417916
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    assert True


# Generated at 2022-06-25 08:39:26.837549
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    import os
    #Test 1
    # Input: <empty>
    # Output: CallbackModule object

    #Test 2
    # Input: {'bool_0': True}
    # Output: CallbackModule object

    #Test 3
    # Input: {'array_0': ['1', '2']}
    # Output: CallbackModule object

    #Test 4
    # Input: {'dict_0': {}}
    # Output: CallbackModule object

# Generated at 2022-06-25 08:39:31.050423
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = ''
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    var_0 = callback_v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:39:34.234929
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert 0


# Generated at 2022-06-25 08:39:35.758697
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)


# Generated at 2022-06-25 08:39:40.365652
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = ''
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    var_0 = callback_module_0.v2_runner_on_failed(str_0)
    print(var_0)


# Generated at 2022-06-25 08:39:43.831618
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_2 = 'msg'
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    var_0 = callback_module_0.v2_runner_on_failed(str_2)


# Generated at 2022-06-25 08:40:16.114797
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    CallbackModule(dict_0)


# Generated at 2022-06-25 08:40:23.140869
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    dict_0 = {'v2_on_file_diff': 'on-file-diff'}
    callback_module_0 = CallbackModule(dict_0)
    str_0 = ''
    dict_1 = {'v2_on_file_diff': 'on-file-diff'}
    result_0 = Result(str_0, callback_module_0, dict_1)
    callback_module_0.v2_on_file_diff(result_0)


# Generated at 2022-06-25 08:40:29.996656
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = ''
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    var_0 = callback_v2_runner_on_failed(str_0)
    assert(var_0) # is True or False


# Generated at 2022-06-25 08:40:33.607061
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    obj = CallbackModule()
    assert not obj
    assert obj.__class__.__name__ == 'CallbackModule'

# Generated at 2022-06-25 08:40:35.913544
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    str_0 = ''
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    var_0 = callback_v2_on_file_diff(str_0)


# Generated at 2022-06-25 08:40:41.084804
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    result_0 = Result()
    str_0 = ''
    result_0._result = str_0
    callback_module_0.v2_on_file_diff(result_0)

# Generated at 2022-06-25 08:40:46.407320
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = ''
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    var_0 = callback_v2_runner_on_ok(str_0)


# Generated at 2022-06-25 08:40:49.986320
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = ''
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    var_0 = callback_module_0.v2_runner_on_failed(str_0)
    assert(var_0 == 'undefined')
    

# Generated at 2022-06-25 08:40:56.643358
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    var_0 = callback_v2_runner_on_ok()


# Generated at 2022-06-25 08:40:58.652046
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = ''
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    var_0 = callback_module_0.v2_runner_on_ok(str_0)


# Generated at 2022-06-25 08:41:57.915546
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    print(__name__)

    module = CallbackModule(str())
    assert isinstance(module, CallbackModule)

# Generated at 2022-06-25 08:42:02.752796
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    noc_0 = {'v2_on_file_diff': 'noc_0_v2_on_file_diff'}
    dict_0 = {'v2_on_file_diff': 'dict_0_v2_on_file_diff'}
    eg_1 = {'v2_on_file_diff': 'eg_1_v2_on_file_diff'}
    dict_1 = {'v2_on_file_diff': 'dict_1_v2_on_file_diff'}

    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_on_file_diff(dict_0, dict_1)


# Generated at 2022-06-25 08:42:05.650854
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)



# Generated at 2022-06-25 08:42:10.535623
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    print('Test Case 0')
    str_0 = ''
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    var_0 = callback_module_0.v2_runner_on_failed(str_0)
    print(var_0)


# Generated at 2022-06-25 08:42:14.045020
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    str_1 = ''
    dict_1 = {}
    callback_module_1 = CallbackModule(dict_1)

# Generated at 2022-06-25 08:42:16.783672
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = ''
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    var_0 = callback_module_0.v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:42:18.340434
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule(var_0)



# Generated at 2022-06-25 08:42:22.288750
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = ''
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    var_0 = callback_module_0.v2_runner_on_ok(str_0)


# Generated at 2022-06-25 08:42:29.994108
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_1 = CallbackModule()
    dict_1 = {}
    dict_1['changed'] = False
    dict_1['diff'] = "{u'after': u'/path/to/file', u'after_header': u'', u'before': u'/path/to/file', u'before_header': u''}"
    dict_1['msg'] = "All items completed"
    dict_1['rc'] = 0
    dict_1['start'] = '2017-09-21 12:32:45.283360'
    dict_1['stderr'] = ''
    dict_1['stdout'] = ''
    dict_1['stdout_lines'] = []
    dict_1['warnings'] = []

# Generated at 2022-06-25 08:42:32.213864
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = ''
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    var_0 = callback_v2_runner_on_ok(str_0)


# Generated at 2022-06-25 08:45:20.121622
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    str_0 = ''
    var_0 = callback_module_0.v2_on_file_diff(str_0)
    assert var_0 == "NO DIFF AVAILABLE :('"


# Generated at 2022-06-25 08:45:29.336137
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    module_name, func_name = ('test_callback', '_test_case_0')
    func = globals()['test_case_0']
    callback = CallbackModule({})
    result = types.SimpleNamespace()
    host = types.SimpleNamespace()
    result._host = host
    host.get_name = lambda: 'foo'
    result._result = dict(failed=True, module_stderr='bad boy')
    task = types.SimpleNamespace()
    task.action = 'shell'
    result._task = task
    callback.display = MagicMock()
    func(callback, result)
    assert callback.display.call_count == 1
    args, kwargs = callback.display.call_args_list[0]

# Generated at 2022-06-25 08:45:34.216558
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = ''
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    var_0 = callback_v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:45:34.802959
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    assert True

# Generated at 2022-06-25 08:45:39.421041
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create an instance of class CallbackModule
    obj = CallbackModule()

    # Call method v2_runner_on_ok of obj with local variable result
    obj.v2_runner_on_ok(result)

# Generated at 2022-06-25 08:45:44.668977
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    str_0 = ''
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    var_0 = callback_module_0._display.display(str_0)
    assert var_0 == None


# Generated at 2022-06-25 08:45:49.692906
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
   dict_0 = {}
   callback_module_0 = CallbackModule(dict_0)
   var_0 = v2_on_file_diff(str_0)


# Generated at 2022-06-25 08:45:52.205744
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    assert test_case_0() == 'PASS'



# Generated at 2022-06-25 08:45:55.011747
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = ''
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    var_0 = callback_module_0.v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:45:59.870936
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    dict_0 = {}
    callback_module_0 = CallbackModule(dict_0)
    str_0 = ''
    var_0 = callback_v2_runner_on_ok(str_0)
