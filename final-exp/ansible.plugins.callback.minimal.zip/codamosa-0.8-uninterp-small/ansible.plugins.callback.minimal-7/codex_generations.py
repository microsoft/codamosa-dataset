

# Generated at 2022-06-25 08:36:11.922801
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    # Testing on default arguments
    callback_module_0.v2_runner_on_failed("result_0")


# Generated at 2022-06-25 08:36:13.227583
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert isinstance(callback_module_0, CallbackModule)

# Generated at 2022-06-25 08:36:18.910503
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = {}
    result_0['changed'] = False
    result_1 = {}
    result_1['changed'] = True
    ansible_runner_result_0 = AnsibleRunnerResult()
    ansible_runner_result_0._result = result_0
    ansible_runner_result_0._result = result_1
    ansible_runner_result_0._host = AnsibleHost()
    ansible_runner_result_0._task = AnsibleTask()
    ansible_runner_result_0._task.action = 'shell'
    ansible_runner_result_0._task.action = 'debug'
    ansible_runner_result_0._task.action = 'ping'
    ansible_runner_result_0._task.action = 'setup'

# Generated at 2022-06-25 08:36:23.357757
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create an instance of the CallbackModule class
    callback_module = CallbackModule()
    task_0 = runner_result_t()
    assert result_0._host.get_name() == 'default'
    callback_module.v2_runner_on_ok(task_0)


# Generated at 2022-06-25 08:36:29.642824
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_2 = {}
    result_2['stdout'] = ''
    result_2['stderr'] = ''
    result_2['rc'] = 0
    result_2['changed'] = False
    result_2['msg'] = 'Completed'
    result_2['_ansible_parsed'] = True
    result_2['_ansible_no_log'] = False
    result_2['invocation'] = {'module_name': 'setup'}
    result_2['_ansible_ignore_errors'] = None
    result_2['_ansible_no_log'] = False
    result_2['_ansible_item_result'] = True
    result_2['_ansible_delegated_vars'] = {}

# Generated at 2022-06-25 08:36:31.252564
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # CallbackModule.v2_runner_on_ok(result)
    return True


# Generated at 2022-06-25 08:36:40.751430
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_v2_runner_on_failed_0 = CallbackModule()
    result_0 = AnsibleResult()
    result_0._task.action = 'some string'
    result_0._task.action = 'some string'
    result_0._task.action = 'some string'
    result_0._task.action = 'some string'
    result_0._task.action = 'some string'
    result_0._task.action = 'some string'
    result_0._host.get_name = 'some string'
    result_0._host.get_name = 'some string'
    result_0._host.get_name = 'some string'
    result_0._host.get_name = 'some string'
    result_0._host.get_name = 'some string'
    result_0

# Generated at 2022-06-25 08:36:46.328567
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()

    # Execute method
    callback_module_0.v2_runner_on_failed(result, ignore_errors=False)



# Generated at 2022-06-25 08:36:47.804232
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:36:49.243526
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()

    # Unit test for case 0
    test_case_0()


# Generated at 2022-06-25 08:36:57.995047
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    test_v2_runner_on_ok = CallbackModule()
    result = "ok"
    test_v2_runner_on_ok.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:36:59.125670
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:37:03.916337
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = CallbackModule.Result()
    result_0.failed = False
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors=False)


# Generated at 2022-06-25 08:37:16.600099
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Instantiate CallbackModule object
    callback_module_1 = CallbackModule()
    test_v2_on_file_diff_result_0 = {}
    test_v2_on_file_diff_result_0['diff'] = {}
    test_v2_on_file_diff_result_0['diff']['before'] = '2018-12-13T02:08:57.000000Z'
    test_v2_on_file_diff_result_0['diff']['after'] = '2018-12-13T02:08:57.000000Z'
    test_v2_on_file_diff_result_0['diff']['before_header'] = '--- 2018-12-13T02:08:57.000000Z'

# Generated at 2022-06-25 08:37:18.963047
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(result=None)


# Generated at 2022-06-25 08:37:22.083072
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = ansible.plugins.callback.CallbackBase()
    result_0._result = {'changed': False}
    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:37:28.026422
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    # Initialize
    callback_module_0._clean_results = mock.Mock()
    callback_module_0._handle_warnings = mock.Mock()

    callback_module_0.v2_runner_on_ok(result=mock.Mock())


# Generated at 2022-06-25 08:37:32.462306
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    try:
        callback_module_1 = CallbackModule()
        callback_module_1.v2_runner_on_ok(Result=None)
    except Exception as e:
        assert(e.message.startswith('Not yet implemented'))
    else:
        assert(False)


# Generated at 2022-06-25 08:37:42.728471
# Unit test for method v2_runner_on_ok of class CallbackModule

# Generated at 2022-06-25 08:37:46.567301
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    result_0 = dict()
    result_0['diff'] = 'diff-text'
    result_0 = set_result(result_0)
    callback_module_0 = CallbackModule()
    callback_module_0.v2_on_file_diff(result_0)


# Generated at 2022-06-25 08:37:54.876265
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    assert True == True


# Generated at 2022-06-25 08:37:59.436872
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    if (callback_module is not None):
        print ("Test Case 0 :  Success")
    else:
        print ("Test Case 0 :  Fail")




# Generated at 2022-06-25 08:38:05.591805
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = Mock()
    result_0._result = {
    }

    result_0._host = Mock()
    result_0._host.get_name = Mock(return_value="host_name")
    result_0._task = Mock()
    result_0._task.action = "action_0"

    callback_module_0.v2_runner_on_failed(result_0)


# Generated at 2022-06-25 08:38:06.953365
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    pass


# Generated at 2022-06-25 08:38:12.163217
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    result_1 = dict()
    result_1['changed'] = True
    result_1['diff'] = None
    result_1['rc'] = 0
    
    callback_module_1 = CallbackModule()
    result_2 = callback_module_1.v2_on_file_diff(result_1)

    assert result_2 is None



# Generated at 2022-06-25 08:38:14.906574
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        result = CallbackModule()
        print("Successfully instantiated the class")
    except:
        print("Unable to instantiate the class")


# main function
if __name__ == "__main__":
    test_CallbackModule()

# Generated at 2022-06-25 08:38:18.506217
# Unit test for constructor of class CallbackModule
def test_CallbackModule():

    # Test cases for each if statment in the constructor
    # Test case 1
    # Success case
    callback_module_1 = CallbackModule()

    return True


# Generated at 2022-06-25 08:38:21.043500
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    test_case_0.callback_module_0.v2_on_file_diff()


# Generated at 2022-06-25 08:38:24.928363
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result = CallbackModule()
    result._result = {"diff": "diff"}
    expected = "diff"
    actual = callback_module_0.v2_on_file_diff(result)
    assert actual == expected


# Generated at 2022-06-25 08:38:30.334007
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = {'_ansible_parsed': True, 'invocation': {'module_args': {'key_items': 'value_1', 'key_kv': 'key_value_2'}}, '_ansible_no_log': False, '_ansible_item_result': True, '_ansible_life_cycle_nonpersistent_state': {'_ansible_dry_run': False, '_ansible_no_log': False}, '_ansible_item_label': 'item_0', 'item': 'item_1', '_ansible_parsed': True, 'omit': 'omit_0', '_ansible_no_log': False}

# Generated at 2022-06-25 08:38:41.948996
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = 'z}(pp)'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(str_0)
    assert var_0 == None


# Generated at 2022-06-25 08:38:44.392200
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:38:49.672686
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Input param result: _result = {'diff': '''diff --git a/test_callback.py b/test_callback.py
    # index cee09f7..b84d87c 100644
    # --- a/test_callback.py
    # +++ b/test_callback.py
    # @@ -1,6 +1,6 @@
    #  from __future__ import absolute_import, division, print_function
    #  from ansible.compat.tests import unittest
    # -from ansible.utils.color import stringc
    # +from ansible.compat.color import stringc
    #
    #  class TestStringc(unittest.TestCase):
    #      def test_stringc(self):'''}
    diff = result._result['diff']
    if diff:
        self

# Generated at 2022-06-25 08:39:00.825703
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    int_0 = 0
    int_1 = 0
    int_2 = 0
    str_0 = '4G4D4~'
    str_1 = '}'
    str_2 = 'v{{'
    str_3 = '8V?R)'
    str_4 = 'oZP+'
    str_5 = '`G{5'
    str_6 = 'Y>Yb'
    str_7 = 'tF1n'
    str_8 = '#'
    str_9 = '>K#d'
    str_10 = 'r`j/'
    str_11 = 'stkn'
    str_12 = '{D_z'
    str_13 = 'R;$'
    str_14 = '|kfq'

# Generated at 2022-06-25 08:39:06.153885
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test case 0
    str_0 = 'z}(pp)'
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:39:11.618933
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    str_0 = 'z}(pp)'
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_on_file_diff(str_0)
    assert var_0 == None


# Generated at 2022-06-25 08:39:16.814582
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = 'z}(pp)'
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok(str_0)


# Generated at 2022-06-25 08:39:24.977485
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    # Set up test input
    diff = "test string"

    result = {"diff": diff}
    expected = diff

    # Call method under test
    actual = callback_module_0._get_diff(result)

    # Verify that the results are as expected
    assert actual == expected
    # cleanup function
    cleanup_function()

# Generated at 2022-06-25 08:39:31.200422
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = 'z}(pp)'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(str_0)
    assert var_0 == 0


# Generated at 2022-06-25 08:39:32.907415
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    '''
    Function tests the return value of method v2_runner_on_failed of class CallbackModule
    '''
    # @TODO test method v2_runner_on_failed of class CallbackModule


# Generated at 2022-06-25 08:39:51.122252
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()


# Generated at 2022-06-25 08:39:53.725728
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = 'ii}'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(str_0)


# Generated at 2022-06-25 08:40:00.951612
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()
    assert callback_module_1._display.__class__ == Display
    assert callback_module_1.CALLBACK_TYPE == 'stdout'
    assert callback_module_1.COLOR_SKIP == 'cyan'
    assert callback_module_1.CALLBACK_NAME == 'minimal'
    assert callback_module_1.CALLBACK_VERSION == 2.0
    assert callback_module_1.COLOR_CHANGED == 'yellow'
    assert callback_module_1.COLOR_OK == 'green'
    assert callback_module_1.C.COLOR_ERROR == 'red'
    assert callback_module_1.C.COLOR_UNREACHABLE == 'dark gray'


# Generated at 2022-06-25 08:40:03.961943
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0.__class__ == CallbackModule
    assert callback_module_0.CALLBACK_VERSION == 2.0
    assert callback_module_0.CALLBACK_TYPE == 'stdout'
    assert callback_module_0.CALLBACK_NAME == 'minimal'


# Generated at 2022-06-25 08:40:06.650554
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
  assert True


# Generated at 2022-06-25 08:40:10.131373
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    obj = CallbackModule()
    result = {'diff': "foo\nbar\nbaz\n"}
    expected_output = "foo\nbar\nbaz\n"
    output = obj.v2_on_file_diff(result)

    assert output == expected_output


# Generated at 2022-06-25 08:40:16.509859
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    str_0 = 'U+8[#'
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_on_file_diff(str_0)
    assert (isinstance(var_0, bool)) == True


# Generated at 2022-06-25 08:40:25.466398
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Variable(s)
    str_0 = 'z}(pp)'
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule(str_0)
    # Check if callback_module_0 was properly initialized
    assert callback_module_0._handle_wrapper() == '<ansible.plugins.callback.CallbackBase object at 0x7f54dccb2f28>'
    assert callback_module_0.CALLBACK_NAME is 'minimal'
    assert callback_module_0.CALLBACK_VERSION is 2.0
    assert callback_module_0.CALLBACK_TYPE is 'stdout'
    # Check if callback_module_1 was properly initialized

# Generated at 2022-06-25 08:40:35.872272
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    str_0 = ''
    str_1 = 'LZi'
    str_2 = 'NUw'
    str_3 = 'Y_'
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(str_0, str_1, str_2, str_3)
    str_0 = 'Q'
    str_1 = 'R'
    str_2 = 'S'
    str_3 = 'T'
    var_0 = callback_module_0.v2_runner_on_failed(str_0, str_1, str_2, str_3)
    str_0 = 'QA{'
    str_1 = 'Rfj'
    str_2 = 'S:_'

# Generated at 2022-06-25 08:40:41.084750
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    str_1 = 'z}(pp)'
    callback_module_1 = CallbackModule()
    command_generic_msg_1 = callback_module_1.command_generic_msg(str_1)

# Generated at 2022-06-25 08:41:23.064182
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = 'z}(pp)'
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok(str_0)
    if (var_0 == None):
        raise AssertionError("v2_runner_on_ok(var_0) == None")
    if (var_0 != None):
        raise AssertionError("v2_runner_on_ok(var_0) != None")


# Generated at 2022-06-25 08:41:28.596616
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = 'f}G`y'
    str_1 = '['
    str_2 = 'XHef'
    json_0 = {"5i-|x}y'": '2[Gt7n'}
    var_0 = CallbackModule()
    var_0.v2_runner_on_failed(str_0, str_1, str_2, json_0)


# Generated at 2022-06-25 08:41:32.735663
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    str_0 = 'z}(pp)'
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_on_file_diff(str_0)
    if var_0:
        print('Success')
    else:
        print('Failure')


# Generated at 2022-06-25 08:41:33.811518
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:41:39.011172
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = 'z}(pp)'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_unreachable(str_0)



# Generated at 2022-06-25 08:41:43.124711
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = 'z}(pp)'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(str_0)

# Generated at 2022-06-25 08:41:44.745351
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert isinstance(callback_module_0, CallbackModule) == True



# Generated at 2022-06-25 08:41:54.082873
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    # in case of no exception
    try:
        callback_module_0 = CallbackModule()
        callback_module_0.v2_runner_on_failed(str)
        callback_module_0.v2_runner_on_failed(str, ignore_errors=False)

    # in case of exception
    except NameError as e:
        assert type(callback_module_0) == CallbackModule
        callback_module_0.v2_runner_on_failed(str)
        callback_module_0.v2_runner_on_failed(str, ignore_errors=False)
        assert type(e) == NameError
        assert e.message == 'name \'callback_v2_runner_on_unreachable\' is not defined'


# Generated at 2022-06-25 08:41:56.775373
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 08:41:58.160693
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = 'z}(pp)'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:43:19.636592
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = 'z}(pp)'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:43:21.235252
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = 'z}(pp)'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(str_0)


# Generated at 2022-06-25 08:43:23.914787
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = 'z}(pp)'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(str_0)


# Generated at 2022-06-25 08:43:30.697728
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Setup data for test
    result_0 = {
        'diff' : {
            'after' : '',
            'before' : ''
        }
    }
    # Run test
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_on_file_diff(result_0)
    # Assert result
    assert isinstance(var_0, )



# Generated at 2022-06-25 08:43:32.576040
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    str_0 = 'z-*'
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_on_file_diff(str_0)



# Generated at 2022-06-25 08:43:38.574284
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
	str_0 = 'ztA5e5S'
	str_1 = 'A7Vu}N'
	str_2 = '9f>t'
	str_3 = '"u,P'
	callback_module_0 = CallbackModule()
	callback_module_1 = CallbackModule()
	callback_module_2 = CallbackModule()
	callback_module_3 = CallbackModule()
	var_0 = callback_module_0._feed_queue(str_0, str_1)
	var_1 = callback_module_1._handle_warnings(str_2)
	var_2 = callback_module_2._handle_exception(str_3)
	var_3 = callback_module_3._get_diff(str_1)


# Generated at 2022-06-25 08:43:48.906768
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    str_0 = 'z}(pp)'
    callback_module_0 = CallbackModule()
    assert callback_module_0._play.playbook.handlers is not None
    assert callback_module_0.CALLBACK_TYPE == 'stdout'
    assert callback_module_0.CALLBACK_VERSION == 2.0
    assert callback_module_0._display.display('h_V 0_4', color='yellow') is None
    assert callback_module_0._last_task_banner == '***********************************'
    assert callback_module_0._pending_results == 0
    assert callback_module_0.disabled is False
    assert callback_module_0._play is not None
    assert callback_module_0.enabled == False
    assert callback_module_0._playbook is not None
    assert callback_module_0

# Generated at 2022-06-25 08:43:51.502460
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    str_0 = 'z}(pp)'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(str_0)


# Generated at 2022-06-25 08:43:54.267781
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    # Create an instance of the class to be tested
    def function():
        return None
    callback_module_0 = CallbackModule()

    # Test the method v2_runner_on_ok on the object
    return callback_module_0.v2_runner_on_ok(function)


# Generated at 2022-06-25 08:44:01.407062
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    text_0 = 'z}(pp)'
    callback_module_0 = CallbackModule()
    ansible_0 = Ansible()
    var_0 = callback_v2_runner_on_ok(ansible_0)
