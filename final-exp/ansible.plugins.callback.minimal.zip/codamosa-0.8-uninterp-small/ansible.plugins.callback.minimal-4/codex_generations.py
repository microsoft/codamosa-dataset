

# Generated at 2022-06-25 08:36:11.605188
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():

    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()
    callback_module_2 = CallbackModule()
    result_0 = {}
    result_0['diff'] = {'before': '', 'after': '', 'before_header': '', 'after_header': ''}
    callback_module_0.v2_on_file_diff(result_0)



# Generated at 2022-06-25 08:36:14.812833
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = object()
    result_0.result = object()
    result_0.result.get = object()
    result_0.task = object()
    result_0.host = object()
    result_0.host.get_name = object()

    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:36:19.573728
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    result = {'diff':{}}
    test_object = CallbackModule()
    test_object.v2_on_file_diff(result)



# Generated at 2022-06-25 08:36:20.369091
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    pass

# Generated at 2022-06-25 08:36:23.451567
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
  callback_module_0 = CallbackModule()
  result_0 = result( )
  result_0._result = { 'diff':'nonsens', }
  callback_module_0.v2_on_file_diff( result_0 )
  #assert callback_module_0._get_diff(result._result['diff']), "The method v2_on_file_diff of class CallbackModule must return a value"


# Generated at 2022-06-25 08:36:24.454961
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    pass


# Generated at 2022-06-25 08:36:25.315121
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    test_case_0()


# Generated at 2022-06-25 08:36:28.446271
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module = CallbackModule()

    result = type('obj', (object,), {'_result': {'diff': 'some diff'}})
    print(result._result['diff'])
    callback_module.v2_on_file_diff(result)



# Generated at 2022-06-25 08:36:38.952828
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = {"invocation": {"module_name": "slowlog", "module_args": {"match": "blah", "redis_pass": "redis_pass", "redis_db": "redis_db", "redis_port": "redis_port", "redis_host": "redis_host"}}, "runner_on_ok": []}
    result_1 = {"invocation": {"module_name": "slowlog", "module_args": {"match": "blah", "redis_pass": "redis_pass", "redis_db": "redis_db", "redis_port": "redis_port", "redis_host": "redis_host"}}, "runner_on_ok": []}

# Generated at 2022-06-25 08:36:49.717791
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    from ansible.plugins.callback import CallbackBase
    cb = CallbackBase()
    info = {
        'invocation': {
            'module_args': {
                '_raw_params': 'command',
                '_uses_shell': False,
                'argv': None,
                'chdir': None,
                'creates': None,
                'executable': None,
                'removes': None,
                'warn': True
            }
        },
        'changed': False,
        'diff': {
            'after': '',
            'before': '',
            'before_header': 'file.src',
            'after_header': 'file.dest'
        }
    }
    cb.v2_on_file_diff(info)


# Generated at 2022-06-25 08:37:00.489112
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(tuple_0)

# Generated at 2022-06-25 08:37:10.394265
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_on_file_diff(tuple_0)

if __name__ == '__main__':
    test_functions = [
        test_case_0,

        test_CallbackModule_v2_on_file_diff
    ]

    failed_tests = [
        test_function for test_function in test_functions if test_function() != True]

    print('test suite, %d tests run, %d tests failed.' % (len(test_functions), len(failed_tests)))

# Generated at 2022-06-25 08:37:14.612699
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    tuple_0 = (1, 2, 3)
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok(tuple_0)


# Generated at 2022-06-25 08:37:18.494894
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(tuple_0)
    assert var_0 == None


# Generated at 2022-06-25 08:37:22.522891
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Build a tuple as the first parameters of v2_runner_on_ok
    tuple_0 = ()
    # Build a instance of CallbackModule
    callback_module_0 = CallbackModule()
    # Call method v2_runner_on_ok of CallbackModule
    callback_module_0.v2_runner_on_ok(tuple_0)


# Generated at 2022-06-25 08:37:26.162706
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    a = CallbackModule()
    assert a is not None

if __name__ == "__main__":
    test_case_0()
    test_CallbackModule()

# Generated at 2022-06-25 08:37:30.122918
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Tests the execution of the method v2_on_file_diff of class CallbackModule
    test_case_0()

if __name__ == "__main__":
    test_CallbackModule_v2_on_file_diff()

# Generated at 2022-06-25 08:37:33.838666
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Set up mock object
    callback_module_0 = CallbackModule()
    tuple_0 = ()
    var_0 = callback_v2_runner_on_failed(tuple_0)
    var_1 = callback_module_0.v2_on_file_diff(var_0)



# Generated at 2022-06-25 08:37:36.241841
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(tuple_0)

# Generated at 2022-06-25 08:37:40.112067
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    tuple_0 = ()
    var_0 = callback_module_0.v2_runner_on_failed(tuple_0)
    var_0 = callback_module_0.v2_runner_on_failed(tuple_0)


# Generated at 2022-06-25 08:37:49.498787
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok(tuple_0)


# Generated at 2022-06-25 08:37:52.860915
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase

    res = CallbackBase.call('ok', 'ran whatever')
    assert res == 'ran whatever'


# Generated at 2022-06-25 08:37:55.829698
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert isinstance(callback_module_0, CallbackModule)
    assert isinstance(callback_module_0, CallbackBase)

# Generated at 2022-06-25 08:37:59.256086
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert type(callback_module_0) == CallbackModule


# Generated at 2022-06-25 08:38:05.758314
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0._clean_results(tuple_0)
    var_1 = callback_module_0._dump_results()
    var_2 = callback_module_0._display.display()
    var_3 = callback_module_0._handle_warnings(tuple_0)
    var_0 = callback_module_0.v2_runner_on_ok(tuple_0)


# Generated at 2022-06-25 08:38:09.548749
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0.CALLBACK_NAME == 'minimal'
    assert callback_module_0.CALLBACK_VERSION == 2.0
    assert callback_module_0.CALLBACK_TYPE == 'stdout'
    assert callback_module_0.CALLBACK_NAME == 'minimal'


# Generated at 2022-06-25 08:38:12.636873
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Class instantiation
    callback_module_0 = CallbackModule()

    # Test the following method:
    var_0 = callback_module_0.v2_on_file_diff('test_result_0')


# Generated at 2022-06-25 08:38:15.633183
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Get an instnace of the CallbackModule class
    callback_module = CallbackModule()
    # Gather parameters for the method
    result = None
    # Execute the method with its parameters
    callback_module.v2_on_file_diff(result)

# Generated at 2022-06-25 08:38:18.694040
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(tuple_0)


# Generated at 2022-06-25 08:38:22.584679
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    tuple_0 = ()
    string_0 = callback_module_0.v2_on_file_diff(tuple_0)


# Generated at 2022-06-25 08:38:38.949872
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_on_file_diff(tuple_0)


# Generated at 2022-06-25 08:38:42.072604
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    print("Testing for CallbackModule")
    test_case_0()
    print("Done")

if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-25 08:38:45.487385
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok(tuple_0)


# Generated at 2022-06-25 08:38:49.691148
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok(tuple_0)
    assert var_0 is None

# Generated at 2022-06-25 08:38:51.722521
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok(tuple_0)


# Generated at 2022-06-25 08:38:55.461435
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(tuple_0)



# Generated at 2022-06-25 08:39:02.106848
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    tuple_0 = (None, True)
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(tuple_0, True)


# Generated at 2022-06-25 08:39:09.564714
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():

    callback_module = CallbackModule()

    # Test case
    tuple_0 = ()
    tuple_1 = (tuple_0,)
    var_0 = tuple_1
    var_1 = callback_module.v2_on_file_diff(var_0)



# Generated at 2022-06-25 08:39:15.163295
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_on_file_diff(tuple_0)


# Generated at 2022-06-25 08:39:19.267782
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Initialization of global variables
    global tuple_0
    global callback_module_0
    global var_0

    tuple_0 = ()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(tuple_0)
    if callback_module_0.v2_runner_on_failed(var_0) != None:
        return False
    else:
        return True

if __name__ == '__main__':
    test_CallbackModule_v2_runner_on_failed()

# Generated at 2022-06-25 08:39:51.124138
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # TODO: Implement test
    return True


# Generated at 2022-06-25 08:39:53.725290
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(tuple_0)


# Generated at 2022-06-25 08:39:56.751384
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    dictionary_0 = {'diff': ''}
    tuple_0 = (dictionary_0,)
    callback_module_0 = CallbackModule()
    callback_module_0.v2_on_file_diff(tuple_0)


# Generated at 2022-06-25 08:40:05.947273
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Initialization
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    # CallbackModule.v2_runner_on_failed calls self._handle_exception
    # CallbackModule.v2_runner_on_failed calls self._handle_warnings
    # CallbackModule.v2_runner_on_failed calls self._display.display
    # CallbackBase._display.display calls self.display
    # CallbackBase.display calls print
    var_0 = callback_v2_runner_on_failed(tuple_0)


# Generated at 2022-06-25 08:40:08.168643
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    module_0 = setup_module_0()
    module_0.v2_on_file_diff()


# Generated at 2022-06-25 08:40:12.532768
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Init class
    tuple_0 = ()
    callback_module_0 = CallbackModule()

    # Call method
    callback_module_0.v2_runner_on_ok(tuple_0)


# Generated at 2022-06-25 08:40:18.185379
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(tuple_0)


# Generated at 2022-06-25 08:40:21.491763
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    tuple_0 = ('tuple_0', 102)
    output = callback_module_0.v2_runner_on_failed(tuple_0, True)

    assert output.status_code == 200


# Generated at 2022-06-25 08:40:24.397793
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    callback_module_0._command_generic_msg(tuple_0, tuple_0, tuple_0)
    callback_module_0._clean_results(tuple_0, tuple_0)
    callback_module_0._handle_warnings(tuple_0)
    callback_module_0._get_diff(tuple_0)
    callback_module_0._dump_results(tuple_0, tuple_0)
    callback_module_0._handle_exception(tuple_0)

# Generated at 2022-06-25 08:40:27.768707
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    # No exception should be raised
    try:
        callback_module_0.v2_runner_on_ok(tuple_0)
    except Exception:
        assert False


# Generated at 2022-06-25 08:41:36.257995
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    def test_case_1():
        tuple_0 = ()
        callback_module_0 = CallbackModule()

    def test_case_2():
        tuple_0 = ()
        callback_module_0 = CallbackModule()
        var_0 = callback_module_0.v2_runner_on_failed(tuple_0)

    def test_case_3():
        tuple_0 = ()
        callback_module_0 = CallbackModule()
        var_0 = callback_module_0.v2_runner_on_ok(tuple_0)

    def test_case_4():
        tuple_0 = ()
        callback_module_0 = CallbackModule()
        var_0 = callback_module_0.v2_runner_on_skipped(tuple_0)


# Generated at 2022-06-25 08:41:40.522032
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    assert_equal(callback_module_0.callback_version, 2.0)
    assert_equal(callback_module_0.callback_type, 'stdout')
    assert_equal(callback_module_0.callback_name, 'minimal')
    assert_equal(callback_module_0.CALLBACK_VERSION, 2.0)
    assert_equal(callback_module_0.CALLBACK_TYPE, 'stdout')
    assert_equal(callback_module_0.CALLBACK_NAME, 'minimal')


# Generated at 2022-06-25 08:41:44.378662
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    result_v2_on_file_diff = callback_module_0.v2_on_file_diff(tuple_0)

# Generated at 2022-06-25 08:41:46.613511
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok(tuple_0)


# Generated at 2022-06-25 08:41:48.317442
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(tuple_0)


# Generated at 2022-06-25 08:41:52.834480
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result = None
    ignore_errors = 0
    callback_module = CallbackModule()
    print (callback_module.v2_runner_on_failed(result, ignore_errors))


# Generated at 2022-06-25 08:41:54.208841
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    assert isinstance(callback_module_0, CallbackModule)


# Generated at 2022-06-25 08:41:56.607073
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    new_diff = {}
    result = {}
    result['diff'] = new_diff

    tuple_0 = (result,)
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_on_file_diff(tuple_0)
    assert var_0 is None



# Generated at 2022-06-25 08:41:58.069868
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(tuple_0)


# Generated at 2022-06-25 08:42:11.285573
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(tuple_0)
    tuple_1 = ()
    var_1 = callback_v2_runner_on_ok(tuple_1)
    assert var_1 == (None,)
    tuple_2 = ()
    var_2 = callback_v2_runner_on_skipped(tuple_2)
    assert var_2 == (None,)
    tuple_3 = ()
    var_3 = callback_v2_runner_on_unreachable(tuple_3)
    assert var_3 == (None,)
    tuple_4 = ()
    var_4 = callback_v2_on_file_diff(tuple_4)
    assert var_4 == (None,)

# Generated at 2022-06-25 08:44:50.254493
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(tuple_0)


# Generated at 2022-06-25 08:44:51.945277
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    obj = CallbackModule()
    # str(obj)
    obj.v2_on_file_diff(result)



# Generated at 2022-06-25 08:44:57.916712
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(tuple_0)
    assert var_0 == None


# Generated at 2022-06-25 08:45:02.395773
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    var_0 = v2_runner_on_ok(tuple_0)


# Generated at 2022-06-25 08:45:05.015903
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    assert(callback_module_0._dump_results() == "" )

# Generated at 2022-06-25 08:45:10.739009
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_on_file_diff(tuple_0)


# Generated at 2022-06-25 08:45:13.917217
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Initialize objects
    # Change this line to run a specific test case
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    var_2 = callback_module_0.v2_on_file_diff(tuple_0)
    assert(var_2 == None), "var_2 is %r" % var_2


# Generated at 2022-06-25 08:45:18.121842
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    tuple_0 = ()
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(tuple_0)


# Generated at 2022-06-25 08:45:21.592496
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_skipped(result)

# Generated at 2022-06-25 08:45:24.003372
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import ansible.plugins.callback.minimal
    tuple_0 = ()
    obj_0 = ansible.plugins.callback.minimal.CallbackModule()
    obj_0.v2_runner_on_ok(tuple_0)