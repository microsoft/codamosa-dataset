

# Generated at 2022-06-25 08:36:05.533788
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()


# Generated at 2022-06-25 08:36:07.109496
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok("result_0")


# Generated at 2022-06-25 08:36:08.236928
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()

if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-25 08:36:10.991824
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    callback_module_1._handle_exception({'failed': True})
    callback_module_1._handle_warnings({'warnings': 'test warning'})
    callback_module_1._display.display('test message', color='COLOR_ERROR')


# Generated at 2022-06-25 08:36:13.068614
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Run the v2_runner_on_ok method of the CallbackModule class
    test_module = CallbackModule()
    test_module.v2_runner_on_ok('Not sure about this one')


# Generated at 2022-06-25 08:36:15.090445
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = {}
    ignore_errors_0 = False
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:36:17.692556
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    assert True == True


# Generated at 2022-06-25 08:36:21.808316
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    print("\n--- start test_CallbackModule ---\n\n")

    test_case_0()

    print("\n--- end test_CallbackModule ---\n\n")


# Execute this script
test_CallbackModule()

# Generated at 2022-06-25 08:36:24.413256
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_1 = CallbackModule()
    result_1 = 'result'
    result_2 = callback_module_1.v2_on_file_diff(result_1)


# Generated at 2022-06-25 08:36:26.582760
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        test_case_0()
    except BaseException as e:
        print("Exception in User Defined Callback Module")
        
test_CallbackModule()

# Generated at 2022-06-25 08:36:33.576163
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_on_file_diff(callback_module_0)


# Generated at 2022-06-25 08:36:37.749543
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    callback_module_0 = CallbackModule()

    # Run method v2_runner_on_failed of class CallbackModule
    callback_module_0.v2_runner_on_failed(result, ignore_errors=False)


# Generated at 2022-06-25 08:36:48.976198
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = callback_v2_runner_on_ok(callback_module_0)

# Generated at 2022-06-25 08:36:54.418915
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    result = CallbackModule()
    callback_module_0 = result
    var_0 = callback_v2_runner_on_ok(callback_module_0)


# Generated at 2022-06-25 08:36:57.536733
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_object = CallbackModule()


if __name__ == '__main__':
    test_case_0()
    test_CallbackModule()

# Generated at 2022-06-25 08:37:00.477137
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callbackModule_0 = CallbackModule()

    try:
        callbackModule_0.v2_runner_on_ok()
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-25 08:37:02.324485
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Instantiating an empty class
    tmp = CallbackModule()


# Generated at 2022-06-25 08:37:05.934147
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    var_0 = callback__handle_exception(callback_module_0)
    var_1 = callback__handle_warnings(callback_module_0)


# Generated at 2022-06-25 08:37:11.348686
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(callback_module_0)
    var_0 = str(var_0)
    if (var_0 == 'None') :
        return True
    else:
        return False



# Generated at 2022-06-25 08:37:14.602877
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(callback_module_0)


# Generated at 2022-06-25 08:37:33.632353
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    v2_runner_on_ok_0 = CallbackModule()
    v2_runner_on_ok_1 = CallbackModule()
    v2_runner_on_ok_2 = CallbackModule()
    v2_runner_on_ok_3 = CallbackModule()
    v2_runner_on_ok_4 = CallbackModule()
    v2_runner_on_ok_5 = CallbackModule()
    v2_runner_on_ok_6 = CallbackModule()
    v2_runner_on_ok_7 = CallbackModule()
    v2_runner_on_ok_8 = CallbackModule()
    v2_runner_on_ok_9 = CallbackModule()
    v2_runner_on_ok_10 = CallbackModule()

# Generated at 2022-06-25 08:37:39.572459
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_on_file_diff(callback_module_0)

    # Test attribute 'v2_on_file_diff' with normal values.
    assert callback_module_0.v2_on_file_diff(var_0) == var_0

    # Test attribute 'v2_on_file_diff' with bad values.
    with pytest.raises(TypeError):
        assert callback_module_0.v2_on_file_diff()

    # Test attribute 'v2_on_file_diff' with bad values.
    with pytest.raises(TypeError):
        assert callback_module_0.v2_on_file_diff(var_0) == 1



# Generated at 2022-06-25 08:37:44.649581
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callbackModule_0 = CallbackModule()

# Generated at 2022-06-25 08:37:45.893564
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 08:37:47.629789
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module = CallbackModule()
    var = callback_v2_on_file_diff(callback_module)
    assert True


# Generated at 2022-06-25 08:37:53.134997
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(callback_module_1)
    assert var_0 == "127.0.0.1 | OK => {u'changed': False, u'ping': u'pong'}"


# Generated at 2022-06-25 08:37:57.461367
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_1 = CallbackModule()
    result_1 = {}
    result_1['diff'] = 1
    var_1 = callback_v2_on_file_diff(result_1)


# Generated at 2022-06-25 08:38:03.100767
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule('name').CALLBACK_NAME == 'minimal'
    assert CallbackModule('name').CALLBACK_TYPE == 'stdout'
    assert CallbackModule('name').CALLBACK_VERSION == 2.0


# Generated at 2022-06-25 08:38:07.367113
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    m_0 = CallbackModule()
    m_1 = {'changed': True}
    m_2 = MockTask(m_1, m_0)
    m_3 = MockResult(m_2, m_0)
    m_0.v2_runner_on_ok(m_3)


# Generated at 2022-06-25 08:38:10.695344
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = C.RESULT_OK
    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:38:26.836192
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # set up parameters
    callback_module = CallbackModule()
    result = "some_result_str"
    ignore_errors = False

    # invoke the method
    result_0 = callback_module.v2_runner_on_failed(result, ignore_errors)



# Generated at 2022-06-25 08:38:29.413442
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = Result()
    var_0 = callback_module_0.v2_runner_on_failed(result_0, False)


# Generated at 2022-06-25 08:38:32.501770
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_on_file_diff(callback_module_0)


# Generated at 2022-06-25 08:38:35.320176
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    assert isinstance(callback_module_0, CallbackModule)
    # Call method v2_runner_on_ok
    result = callback_v2_runner_on_ok(callback_module_0)
    assert not (result is None)


# Generated at 2022-06-25 08:38:36.628097
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Add your test here
    raise Exception('Test not implemented')


# Generated at 2022-06-25 08:38:41.336275
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callable(getattr(callback_module_0,"_command_generic_msg"))
    assert callable(getattr(callback_module_0,"v2_runner_on_ok"))


# Generated at 2022-06-25 08:38:45.728899
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a new instance of the class
    callback_module_0 = CallbackModule()

    # Call the method
    var_0 = callback_module_0.v2_runner_on_ok(result_0)



# Generated at 2022-06-25 08:38:49.605115
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    var_1 = callback_v2_runner_on_failed(callback_module_1)


# Generated at 2022-06-25 08:38:55.194660
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callbackModule_0 = CallbackModule()
    var_0 = result._result['diff']
    callbackModule_0.v2_on_file_diff(var_0)

# Generated at 2022-06-25 08:39:03.184813
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_1 = CallbackModule()
    real_result_1 = callback_module_1.v2_runner_on_ok(result)
    expected_result_1 = '''%s | SUCCESS => %s''' % (result._host.get_name(), callback_module_1._dump_results(result._result, indent=4))
    assert real_result_1 == expected_result_1


# Generated at 2022-06-25 08:39:33.128430
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    """Unit test for constructor"""
    # Supply an empty "inline" to obtain a properly-formatted help message
    # when the callback is invoked
    CallbackModule(display=None)


# Generated at 2022-06-25 08:39:38.079146
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_1 = CallbackModule()
    # AssertionError: No result specified
    result_str_1 = 'result'
    # AssertionError: No diff specified
    result_str_2 = 'diff'
    # AssertionError: No diff specified
    var_1 = callback_v2_on_file_diff(callback_module_1, result_str_1, result_str_2)


# Generated at 2022-06-25 08:39:41.686911
# Unit test for constructor of class CallbackModule
def test_CallbackModule():

    # Test #0: make sure we can construct a new object of this class
    callback_module = CallbackModule()
    assert callback_module is not None

# Generated at 2022-06-25 08:39:43.936518
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    global callback_module_0
    callback_module_0 = CallbackModule()
    assert type(callback_module_0) is CallbackModule


# Generated at 2022-06-25 08:39:53.495011
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    # This test should exit cleanly
    var_0 = 0  # Type: int
    callback_module_0 = CallbackModule()

    # This test should throw a TypeError
    try:
        var_0 = callback_module_0.v2_runner_on_ok(100)  # v2_runner_on_ok needs type "Any"
    except Exception:
        var_0 = 1

    # This test should throw a TypeError
    try:
        var_0 = callback_module_0.v2_runner_on_ok(100)  # v2_runner_on_ok needs type "Any"
    except Exception:
        var_0 = 1

#

# Generated at 2022-06-25 08:39:56.839492
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # self, result, ignore_errors=False):
    cb = CallbackModule()
    result = object()
    ignore_errors = object()

    # call the function being tested
    cb.v2_runner_on_failed(result, ignore_errors)



# Generated at 2022-06-25 08:40:02.992859
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = result()
    callback_module_0.v2_runner_on_failed(result_0)



# Generated at 2022-06-25 08:40:04.911428
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(callback_module_0)


# Generated at 2022-06-25 08:40:06.568258
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    var_1 = callback_v2_runner_on_failed(callback_module_1)


# Generated at 2022-06-25 08:40:08.829974
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = "f2iWGiq6YsU6n84n"
    ignore_errors_0 = 0.4310534743353613
    # v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:41:10.695723
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    input_x = random.random()
    input_y = random.random()
    assert output == expected_output


# Generated at 2022-06-25 08:41:16.151068
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    fake_result = object()
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok(fake_result)
    

# Generated at 2022-06-25 08:41:18.676293
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    test_case_0()
    test_case_1()

# Generated at 2022-06-25 08:41:22.096047
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = result()
    var_0 = CallbackModule.v2_runner_on_failed(callback_module_0, result_0)


# Generated at 2022-06-25 08:41:26.990889
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    c = CallbackModule()
    c.v2_runner_on_failed("result", ignore_errors=False)
    c.v2_runner_on_failed("result", ignore_errors=True)


# Generated at 2022-06-25 08:41:29.189128
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed()



# Generated at 2022-06-25 08:41:33.816899
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module = CallbackModule()
    file_diff = {}
    callback_module.v2_on_file_diff(file_diff)


# Generated at 2022-06-25 08:41:41.128555
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    var_0 = {
        '_result': {
            'diff': 'diff output'
        },
        '_task': 'task',
        '_host': 'host'
    }

    var_1 = callback_v2_on_file_diff(callback_module_0, var_0)



# Generated at 2022-06-25 08:41:45.237598
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Parameters:
    #    result: <ansible.runner.ReturnData object>
    #    ignore_errors: <boolean>
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(callback_module_0)


# Generated at 2022-06-25 08:41:49.376687
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    assert callback_module != None


# Generated at 2022-06-25 08:44:16.387771
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Try to run the method without importing the entire class
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok()
    assert var_0 is not None

# Generated at 2022-06-25 08:44:22.575856
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0._dump_results()
    var_1 = callback_module_0._get_diff(result_diff)
    var_2 = callback_module_0.v2_on_file_diff(result_0)


# Generated at 2022-06-25 08:44:27.527145
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    var_0 = CallbackModule()
    var_1 = RunnerResult()
    var_2 = var_0.v2_runner_on_ok(var_1._result)



# Generated at 2022-06-25 08:44:32.589909
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = runner_result()
    callback_module_0.v2_runner_on_failed(result_0)


# Generated at 2022-06-25 08:44:33.866629
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback = CallbackModule()
    assert callback is not None


# Generated at 2022-06-25 08:44:35.958527
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed()

# Generated at 2022-06-25 08:44:40.305432
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    # Call method
    test_case_0()

# Generated at 2022-06-25 08:44:44.667389
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert (callback_module_0.CALLBACK_VERSION == 2.0)
    assert (callback_module_0.CALLBACK_TYPE == 'stdout')
    assert (callback_module_0.CALLBACK_NAME == 'minimal')
    assert (callback_module_0.CALLBACK_NEEDS_WHITELIST == False)



# Generated at 2022-06-25 08:44:46.882758
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0 is not None


# Generated at 2022-06-25 08:44:50.843995
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    test_case_0()
