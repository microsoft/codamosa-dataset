

# Generated at 2022-06-25 08:36:12.763588
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert(hasattr(test_case_0, '_display'))
    assert(hasattr(test_case_0, '_dump_results'))
    assert(hasattr(test_case_0, '_get_diff'))

# Generated at 2022-06-25 08:36:24.319973
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_instance_0 = CallbackModule()
    result_0 = Result()
    result_0.action = 'ANSIBLE_VERSION_FACTS'
    result_0.ansible_facts = {'ansible_version': {'full': '2.8.6', 'major': 2, 'minor': 8, 'revision': 6, 'string': '2.8.6'}}
    result_0.invocation = {'module_args': {'filter': None, 'gather_subset': ['!all', '!min'], 'gather_timeout': 10}, 'module_name': 'setup'}
    result_0.changed = False
    callback_module_instance_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:36:28.133089
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    print("Testing constructor of class CallbackModule")
    callback_module_0 = CallbackModule()
    print("\tinstance callback_module_0 is of type ", type(callback_module_0))
    print("\tinstance callback_module_0 is of type CallbackModule", isinstance(callback_module_0, CallbackModule))


# Generated at 2022-06-25 08:36:29.856309
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    record_results = []
    callback_module_1 = CallbackModule()




# Generated at 2022-06-25 08:36:33.367775
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()

    # prepare test data
    result_0 = 'unknown_0'

    callback_module_0.v2_on_file_diff(result_0)



# Generated at 2022-06-25 08:36:35.383927
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert callable(CallbackModule)
    callback_module = CallbackModule()
    assert isinstance(callback_module, CallbackModule)


# Generated at 2022-06-25 08:36:47.757808
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_1 = CallbackModule()
    result = type('result', (object,), {'action': None,
                                        '_result': {'changed': True, 'failed': False, 'warnings': [], 'skipped': False, 'msg': '', 'rc': 0, 'invocation': {'module_args': {'state': 'started', 'name': 'syslog'}}, 'start': '2019-04-01 09:54:23.858407', 'reboot': False, 'end': '2019-04-01 09:54:27.461517', 'delta': '3.60311', 'stdout': '', 'stderr': ''},
                                        '_host': type('Host', (object,), {'get_name': ''})
                                       })

# Generated at 2022-06-25 08:36:54.408481
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = None
    callback_module_0.v2_runner_on_ok(result_0)



# Generated at 2022-06-25 08:36:58.783353
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    # args
    result_0 = None  # type: Result
    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:37:00.544555
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:37:19.472713
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test with _task.action equal to C.MODULE_NO_JSON and 'ansible_job_id' not in _result._result
    callback_module_0 = CallbackModule()
    result_0 = {"_ansible_parsed": True, "_ansible_no_log": False, "_ansible_item_result": True, "_ansible_ignore_errors": False, "_ansible_item_label": None, "_ansible_summary_markers": [], "item": None, "failed": False, "changed": True, "_ansible_no_log_values": [], "changed_when": True, "invocation": {"module_args": {"state": "started", "pattern": "tomcat"}}}
    callback_module_0.v2_runner_on_ok(result_0)
    # Test with _task.

# Generated at 2022-06-25 08:37:25.724299
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()

    result = object()
    ignore_errors = object()

    returned_0 = callback_module_0.v2_runner_on_failed(result, ignore_errors)
    assert returned_0 is None, "Test 0 FAILED, v2_runner_on_failed() should return None"


# Generated at 2022-06-25 08:37:30.497879
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    print("Testing v2_runner_on_ok...")
    callback_module_0 = CallbackModule()
    result_0 = None
    callback_module_0.v2_runner_on_ok(result_0)
    print("v2_runner_on_ok successfully tested")


# Generated at 2022-06-25 08:37:34.125684
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callbackModule = CallbackModule()


# Generated at 2022-06-25 08:37:40.163608
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    # Check the initialized variable of attribute CallbackBase
    # assert callback_module.display.columns == 80
    # assert callback_module.display.verbosity == 0
    # assert len(callback_module.tqm) == 0
    # assert len(callback_module.skipped_tasks) == 0
    # assert len(callback_module.display) == 0
    assert callback_module.CALLBACK_VERSION == 2.0 #CALLBACK_VERSION = 2.0
    assert callback_module.CALLBACK_TYPE == 'stdout' #CALLBACK_TYPE = 'stdout'
    assert callback_module.CALLBACK_NAME == 'minimal' #CALLBACK_NAME = 'minimal'
    # assert callback_module.show_custom_stats.__name__ == 'show

# Generated at 2022-06-25 08:37:42.573459
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    attr_0 = callback_module_0.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:37:47.615554
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    ansible_result = {'msg': '', 'stderr': '', 'rc': 5, 'invocation': {'module_name': 'setup'}, 'stdout': '', 'stdout_lines': [], 'warnings': []}
    callback_module_1.v2_runner_on_failed(ansible_result, ignore_errors=False)


# Generated at 2022-06-25 08:37:48.388743
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert callable(CallbackModule)


# Generated at 2022-06-25 08:37:56.901422
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    class result_0:
        class _result_0:
            changed = False
            ansible_id = 'ansible_id_0'
            ansible_job_id = 'ansible_job_id_0'
            ansible_facts = None
            stderr = 'stderr_0'
            start = 'start_0'
            delta = 'delta_0'
            end = 'end_0'
            msg = 'msg_0'
            warn = 'warn_0'
            _ansible_no_log = '_ansible_no_log_0'
            exception = 'exception_0'
            module_stderr = 'module_stderr_0'
            stdout = 'stdout_0'

# Generated at 2022-06-25 08:38:05.479082
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:38:23.167125
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Invoke method v2_runner_on_ok
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok("result_0")


# Generated at 2022-06-25 08:38:28.367710
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    assert callback_module_0.v2_on_file_diff() == None


# Generated at 2022-06-25 08:38:30.295874
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok("result")


# Generated at 2022-06-25 08:38:36.628294
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = callback_module_0.v2_runner_on_failed(result)


# Generated at 2022-06-25 08:38:39.132453
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module = CallbackModule()
    callback_module.v2_runner_on_ok("")


# Generated at 2022-06-25 08:38:41.869100
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    assert any(callback_module_0.v2_runner_on_failed()) == False


# Generated at 2022-06-25 08:38:47.269215
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    display_1 = callback_module_0.call_log[-1]["kwargs"]['display']
    result_2 = callback_module_0.call_log[-1]["kwargs"]['result']
    callback_module_0._display = display_1
    callback_module_0.v2_runner_on_ok(result=result_2)


# Generated at 2022-06-25 08:38:48.184248
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    assert isinstance(callback_module, CallbackModule)


# Generated at 2022-06-25 08:38:50.329105
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok(result=None)


# Generated at 2022-06-25 08:38:56.535807
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = Mock()
    result_0._host = Mock()
    result_0._host.get_name = Mock()
    result_0._result = None
    result_0._task = Mock()
    result_0._task.action = None
    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:39:28.828749
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Setup of test data
    result_0 = dict()
    result_0['ansible_job_id'] = '82966536.4714065'
    result_0['_ansible_verbose_always'] = True
    result_0['changed'] = True
    result_0['invocation'] = dict()
    result_0['invocation']['module_args'] = dict()
    result_0['invocation']['module_args']['get_facts'] = False
    result_0['invocation']['module_args']['content'] = 'def test_case_0()'
    result_0['invocation']['module_args']['path'] = 'testcase.py'
    result_0['invocation']['module_args']['force'] = True
    # Assert

# Generated at 2022-06-25 08:39:31.148661
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    # Fail test if method not implemented
    assert hasattr(CallbackModule, 'v2_runner_on_failed')

    # fail test if callback_module_0 is not a class of CallbackModule
    assert isinstance(callback_module_0, CallbackModule)


# Generated at 2022-06-25 08:39:36.424233
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    assert callback_module_0.CALLBACK_VERSION == 2.0
    assert callback_module_0.CALLBACK_TYPE == 'stdout'
    assert callback_module_0.CALLBACK_NAME == 'minimal'


# Generated at 2022-06-25 08:39:41.854339
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = {}
    callback_module_0.v2_runner_on_failed(result_0, False)


# Generated at 2022-06-25 08:39:44.094624
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_obj = CallbackModule()
    assert callable(getattr(callback_module_obj, 'v2_runner_on_failed', None))


# Generated at 2022-06-25 08:39:54.615455
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result = argparse.Namespace()
    result._result = {}
    result._result['task_action'] = 'fail'
    result._result['msg'] = 'bad task'
    result._result['changed'] = True
    result._result['invocation'] = {
        'module_name': 'test_module',
        'module_args': 'test_args'
    }
    result._task = argparse.Namespace()
    result._task.action = 'test_action'
    result._host = argparse.Namespace()
    result._host.get_name = lambda: 'test_host'
    callback_module_0.v2_runner_on_failed(result)

# Generated at 2022-06-25 08:39:58.513514
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_1 = CallbackModule()
    result_1 = dict()
    result_1 = {"diff": "some_diff"}
    callback_module_1.v2_on_file_diff(result_1)
    # TODO
    # compare the result of _get_diff() with the provided diff
    #assert ...


# Generated at 2022-06-25 08:40:01.134122
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    fail_msg = ""
    fail_msg += "Something went wrong"
    assert True, fail_msg


# Generated at 2022-06-25 08:40:07.688375
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    unit_test_result = CallbackModule()
    assert unit_test_result != None, "Constructor of class CallbackModule failed"


# Generated at 2022-06-25 08:40:18.914961
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_1 = CallbackModule()
    result = {"_ansible_verbose_always": False, "_ansible_no_log": False, "item": {}, "_ansible_item_result": True, "_ansible_ignore_errors": None, "msg": None, "_ansible_parsed": True, "_ansible_diff": {"before": "test_string_11", "after": "test_string_12", "before_header": "test_string_13", "after_header": "test_string_14"}, "_ansible_selective": False, "skip_reason": "Conditional result was False", "_ansible_syslog_facility": None}
    callback_module_1.v2_runner_on_ok(result)
    assert 1 == 1


# Generated at 2022-06-25 08:40:54.687674
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    with patch('ansible.plugins.callback.CallbackBase._clean_results') as mock_clean_results:
        mock_clean_results.return_value = 'mock_clean_results return value'
        with patch('ansible.plugins.callback.CallbackBase._handle_warnings') as mock_handle_warnings:
            mock_handle_warnings.return_value = 'mock_handle_warnings return value'
            with patch('ansible.plugins.callback.CallbackBase._display') as mock_display:
                mock_display.return_value = 'mock_display return value'

# Generated at 2022-06-25 08:40:57.369681
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback.minimal import CallbackModule
    callback_module_1 = CallbackModule()
    result_1 = None
    ignore_errors_1 = False
    callback_module_1.v2_runner_on_failed(result_1,
                                          ignore_errors_1)


# Generated at 2022-06-25 08:41:00.766901
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    print("Method v2_runner_on_failed(self, result, ignore_errors=False):")
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(result, ignore_errors=False)


# Generated at 2022-06-25 08:41:09.723427
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Call the method under test
    callback_module_0 = CallbackModule()
    result = {'_ansible_parsed': False, '_ansible_item_result': True, '_ansible_verbose_always': False, '__ansible_module_name': 'setup', '_ansible_no_log': False, 'changed': False, 'skip_reason': 'Conditional result was False', 'msg': 'All items completed', '_ansible_item_label': True}
    result._host = 'host'

# Generated at 2022-06-25 08:41:17.221521
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    print("Unit test for method v2_on_file_diff of class CallbackModule")
    callback_module_0 = test_case_0()
    test_input_0 = {'diff': {}}
    assert callback_module_0.v2_on_file_diff(test_input_0) is None

if __name__ == "__main__":
    test_CallbackModule_v2_on_file_diff()

# Generated at 2022-06-25 08:41:23.770451
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = FakeResult("result_0")
    result_0._host = FakeHost("host_0")
    result_0._result = {"changed": False, "invocation": {"module_args": "module_args_0", "module_name": "module_name_0"}}
    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:41:31.544270
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    # Test logger.
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    callback_module_0=CallbackModule()
    # Ansible play context.
    play_context_0 = PlayContext()
    callback_module_

# Generated at 2022-06-25 08:41:33.533863
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result = NULL
    callback_module_0.v2_runner_on_ok(result)



# Generated at 2022-06-25 08:41:37.879158
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
        callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:41:39.001946
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    print("")

# Generated at 2022-06-25 08:42:50.595715
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    if type(callback_module) != CallbackModule:
        raise Exception('CallbackModule constructor failed.')

CallbackModule()

# Generated at 2022-06-25 08:42:57.897599
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    my_callback_module = CallbackModule()
    assert my_callback_module.CALLBACK_TYPE == "stdout"
    assert my_callback_module.CALLBACK_NAME == "minimal"
    assert my_callback_module.CALLBACK_VERSION == 2.0
    assert my_callback_module.display.plugin_type == "stdout"
    assert my_callback_module.display.plugin_name == "minimal"
    assert my_callback_module.display.plugin_version == 2.0

# Generated at 2022-06-25 08:43:06.027216
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    import json
    result = dict(json.loads('{    "msg": "",    "rc": 0,    "stdout": "",    "stderr": "",    "start": "2014-04-13 03:12:29.904191",    "end": "2014-04-13 03:12:29.906205",    "delta": "0:00:00.002013",    "invocation": {        "module_args": "cat /root/.bash_history"    },    "_ansible_verbose_always": true,    "item": ""}'))
    callback_module_0.v2_runner_on_failed(result, True)


# Generated at 2022-06-25 08:43:07.741998
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    c = CallbackModule()
    c.v2_runner_on_ok(result=None)  # placehoder for test method


# Generated at 2022-06-25 08:43:18.182074
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result = {'_ansible_version': 2.7, '_ansible_no_log': False, '_ansible_verbose_always': True, '_ansible_ignore_conditions': None, 'actions': 'db_shutdown', 'changed': False, 'cmd': '/bin/bash', '_ansible_parsed': True, 'delta': '0:00:00.005059', 'end': '2019-08-17 10:32:45.124337', 'msg': 'non-zero return code', 'rc': 257, 'start': '2019-08-17 10:32:45.119278', 'stderr': '', 'stderr_lines': [], 'stdout': '', 'stdout_lines': []}

# Generated at 2022-06-25 08:43:20.645715
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    result = "result"
    callback_module_0 = CallbackModule()
    callback_module_0.v2_on_file_diff(result)


# Generated at 2022-06-25 08:43:23.349459
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result = "result"
    callback_module_0.v2_runner_on_ok(result)
    assert True


# Generated at 2022-06-25 08:43:29.109265
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Debug on
    C.COMMAND_DEBUG = True
    callback_module_0 = CallbackModule()
    assert type(callback_module_0) == CallbackModule


# Generated at 2022-06-25 08:43:35.693496
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result = {'diff': 'sample string 1'}
    value = callback_module_0.v2_on_file_diff(result)


# Generated at 2022-06-25 08:43:38.049179
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    assert not hasattr(callback_module_0, 'v2_on_file_diff')
