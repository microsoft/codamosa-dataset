

# Generated at 2022-06-25 08:36:08.912098
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert callable(CallbackModule)

# Generated at 2022-06-25 08:36:10.849169
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = dict()
    ignore_errors_0 = False
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:36:12.424410
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()
    assert callback_module

# Generated at 2022-06-25 08:36:15.304680
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()

    callback_module_0.runner_on_ok({'changed': True, 'ansible_facts': {'fact1': 'value1', 'fact2': 'value2'}}, None)

# Generated at 2022-06-25 08:36:21.629615
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()
    assert callback_module_1.CALLBACK_TYPE == 'stdout'
    assert callback_module_1.CALLBACK_NAME == 'minimal'
    assert callback_module_1.CALLBACK_VERSION == 2.0


# Generated at 2022-06-25 08:36:25.234795
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    
    result_0 = V2RunnerResult(None, None, None, None, None, None, {}, 'V2RunnerResult.exception')
    
    callback_module_0.v2_runner_on_failed(result_0)


# Generated at 2022-06-25 08:36:28.050164
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = Result()
    ignore_errors_0 = False
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:36:32.472880
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    result_1 = None # TODO: add real value
    ignore_errors_1 = None # TODO: add real value
    callback_module_1.v2_runner_on_failed(result_1, ignore_errors_1)


# Generated at 2022-06-25 08:36:33.986794
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    assert True


# Generated at 2022-06-25 08:36:34.880448
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()

# Generated at 2022-06-25 08:36:48.024914
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = test_case_0()
    ignore_errors_0 = True
    try:
        callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)
    except:
        raise


# Generated at 2022-06-25 08:36:54.410627
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module = CallbackModule()
    result = callback_module.v2_on_file_diff("result")
    assert result is None


# Generated at 2022-06-25 08:36:58.998278
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:37:07.265498
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    '''
    Ensures that the output callback plugin `minimal' works correctly
    '''

    callback_module_v2_on_file_diff_0 = CallbackModule()
    if callback_module_v2_on_file_diff_0:
        result = dict()
        result['diff'] = dict()
        if callback_module_v2_on_file_diff_0._get_diff(result['diff']) is not None:
            res = True
            assert res


# Generated at 2022-06-25 08:37:08.756998
# Unit test for constructor of class CallbackModule
def test_CallbackModule():

    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:37:09.868134
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    assert True


# Generated at 2022-06-25 08:37:17.416399
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result = 'result_0'
    arg_0 = callback_module_0.v2_runner_on_ok(result)
    assert arg_0 == None

if __name__ == '__main__':
    test_case_0();
    test_CallbackModule_v2_runner_on_ok()

# Generated at 2022-06-25 08:37:21.579250
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # def v2_on_file_diff(self, result):
    callback_module_0 = CallbackModule()
    result_0 = "result_0"

    # Invoke method
    # callback_module_0.v2_on_file_diff(result_0)

    # Additional testing code
    # None



# Generated at 2022-06-25 08:37:25.767759
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()
    actual = isinstance(callback_module_1, CallbackModule)
    assert actual is True


# Generated at 2022-06-25 08:37:28.786416
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_on_file_diff({'diff': 'diff', 'diff': True})


# Generated at 2022-06-25 08:37:38.980822
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    bytes_0 = b'\xf0\x02\x01\xe9\x05\xc1\xee\x89\x17\xd3\xa2\xb3\x1e\x8dN\x92'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(callback_module_0, bytes_0)

# Generated at 2022-06-25 08:37:45.213862
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_0 = b'\x87v\x9a\x95\xeb\xdb\xf8\x19b\xef-\xd2\x7fr\x92'
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(bytes_0)



# Generated at 2022-06-25 08:37:50.251575
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    bytes_0 = b'E'
    callback_module_0 = CallbackModule()
    callback_module_0.v2_task_start("task_name", "task_id")
    var_0 = callback_module_0._display.display(bytes_0)
    callback_module_0.v2_runner_on_ok(True)
    callback_module_0.v2_task_finish("task_name", "task_id")
    assert len(callback_module_0.results_raw) == 5


# Generated at 2022-06-25 08:37:53.211160
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():

    # Call method.
    result = CallbackModule.v2_on_file_diff(self, result)
    assert result == "test result"


# Generated at 2022-06-25 08:37:58.054434
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    # The following will fail with TypeError: 'Error' object is not iterable
    # v2_on_file_diff(callback_module_0, callback_module_0)


# Generated at 2022-06-25 08:38:02.633005
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    bytes_0 = b'\x87v\x9a\x95\xeb\xdb\xf8\x19b\xef-\xd2\x7fr\x92'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_on_file_diff(bytes_0)


# Generated at 2022-06-25 08:38:08.804255
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C

    # First, we mock all objects we need to instantiate the class under
    # test.
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C

    # First, we mock all objects we need to instantiate the class under
    # test.
    callback_module_0 = CallbackModule()
    result = None
    callback_module_0.v2_runner_on_ok(result)



# Generated at 2022-06-25 08:38:16.502272
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_it_0 = b'\x87v\x9a\x95\xeb\xdb\xf8\x19b\xef-\xd2\x7fr\x92'
    bytes_it_1 = b'\xe5\x95\xce\x8f\x9b\x05\x11\x078-\x83\xa4\xfe\x95\x8f\x9a\xa3'
    bool_it_2 = False
    callback_module_it_0 = CallbackModule()
    callback_module_it_1 = callback_module_it_0.v2_runner_on_failed(bytes_it_0, it_2)


# Generated at 2022-06-25 08:38:20.986012
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    with patch('ansible.plugins.callback.CallbackBase.display') as mock_display:
        callback_module_0 = CallbackModule()
        callback_module_0.v2_runner_on_failed(bytes_0, true)



# Generated at 2022-06-25 08:38:25.832738
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    bytes_0 = b'\x87v\x9a\x95\xeb\xdb\xf8\x19b\xef-\xd2\x7fr\x92'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_unreachable(bytes_0)

# Generated at 2022-06-25 08:38:46.243701
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bytes_0 = b'\x87v\x9a\x95\xeb\xdb\xf8\x19b\xef-\xd2\x7fr\x92'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_unreachable(bytes_0)


# Generated at 2022-06-25 08:38:51.613942
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Set up mock
    mock_result = Mock()

    # Set up parameters
    result = mock_result

    # Invoke method
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_ok(result)

    # Check
    assert var_0 == None


# Generated at 2022-06-25 08:38:53.898192
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    assert 1 == 0



# Generated at 2022-06-25 08:39:01.494490
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    cbm = CallbackModule()
    assert hasattr(cbm, '_set_options')
    assert hasattr(cbm, '_display')
    assert hasattr(cbm, '_dump_results')
    assert hasattr(cbm, '_handle_warnings')
    assert hasattr(cbm, '_clean_results')
    assert hasattr(cbm, '_get_diff')
    assert hasattr(cbm, '_handle_exception')
    assert hasattr(cbm, 'v2_on_any')
    assert hasattr(cbm, 'v2_runner_on_failed')
    assert hasattr(cbm, 'v2_runner_on_ok')
    assert hasattr(cbm, 'v2_runner_on_skipped')

# Generated at 2022-06-25 08:39:05.808049
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    v2_runner_on_failed_0 = CallbackModule()
    result_0 = v2_runner_on_failed_0._handle_exception(var_0)
    result_1 = v2_runner_on_failed_0._handle_warnings(var_0)
    bool_0 = v2_runner_on_failed_0._task.action in C.MODULE_NO_JSON and 'module_stderr' not in var_0
    if bool_0:
        v2_runner_on_failed_0._display.display(v2_runner_on_failed_0._command_generic_msg(result_0._host.get_name(), var_0, "FAILED"), color=C.COLOR_ERROR)

# Generated at 2022-06-25 08:39:09.698077
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    print(bytes_xor(bytes_0, bytes_1))


# Generated at 2022-06-25 08:39:17.609422
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    model_0 = CallbackModule()
    assert(isinstance(model_0.v2_runner_on_failed, collections.FunctionType))
    assert(isinstance(model_0.v2_on_file_diff, collections.FunctionType))
    assert(isinstance(model_0.v2_runner_on_skipped, collections.FunctionType))
    assert(isinstance(model_0.v2_runner_on_unreachable, collections.FunctionType))
    assert(isinstance(model_0.v2_runner_on_ok, collections.FunctionType))
    assert(isinstance(model_0._display, collections.Mapping))
    assert(isinstance(model_0._handle_warnings, collections.FunctionType))
    assert(isinstance(model_0._handle_exception, collections.FunctionType))
   

# Generated at 2022-06-25 08:39:25.035286
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_0 = b'\x87v\x9a\x95\xeb\xdb\xf8\x19b\xef-\xd2\x7fr\x92'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_unreachable(bytes_0)


# Generated at 2022-06-25 08:39:30.147296
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert(isinstance(callback_module_0,CallbackModule))


# Generated at 2022-06-25 08:39:35.089999
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_on_file_diff(callback_module_0.CallbackModule)


# Generated at 2022-06-25 08:40:09.559325
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_0 = b'\x87v\x9a\x95\xeb\xdb\xf8\x19b\xef-\xd2\x7fr\x92'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_unreachable(bytes_0)


# Generated at 2022-06-25 08:40:16.602919
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_0 = b'\x87v\x9a\x95\xeb\xdb\xf8\x19b\xef-\xd2\x7fr\x92'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_unreachable(bytes_0)


# Generated at 2022-06-25 08:40:19.245275
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(callback_module_0)


# Generated at 2022-06-25 08:40:27.625970
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_0 = b'\x87v\x9a\x95\xeb\xdb\xf8\x19b\xef-\xd2\x7fr\x92'
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed()


# Generated at 2022-06-25 08:40:28.345201
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert callable(CallbackModule)

# Generated at 2022-06-25 08:40:35.801145
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    dict_0 = dict()
    dict_0['ansible_job_id'] = bytes_0

    # Set up the arguments with which the function is called
    method_args = dict()
    method_args['result'] = dict_0
    method_args['ignore_errors'] = True

    # Test the function
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(**method_args)


# Generated at 2022-06-25 08:40:40.024400
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_v2_runner_on_failed(bytes_0)


# Generated at 2022-06-25 08:40:46.536678
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bytes_0 = b'-\xc2}\x9c \xca\x00\xa6\xf0w&\xcb\xc6\x08\x19'
    callback_module_0 = CallbackModule(bytes_0)
    bool_0 = isinstance(callback_module_0, CallbackModule)
    assert bool_0


# Generated at 2022-06-25 08:40:50.371893
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_0 = b'\x87v\x9a\x95\xeb\xdb\xf8\x19b\xef-\xd2\x7fr\x92'
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(bytes_0)


# Generated at 2022-06-25 08:40:53.221077
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:41:49.845579
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    callback_module_v2_runner_on_failed()


# Generated at 2022-06-25 08:41:58.043471
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Instantiate
    callback_module_0 = CallbackModule()

    # Test without argument
    try:
        callback_module_0.v2_runner_on_ok()
    except TypeError as error:
        assert error.args[0] == "v2_runner_on_ok() missing 1 required positional argument: 'result'"


# Generated at 2022-06-25 08:42:08.083618
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    bytes_0 = b'\x87v\x9a\x95\xeb\xdb\xf8\x19b\xef-\xd2\x7fr\x92'
    var_0 = callback_v2_runner_on_unreachable(bytes_0)
    var_1 = callback_v2_runner_on_unreachable(bytes_0)



# Generated at 2022-06-25 08:42:11.562420
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_3 = b'\x10^\x8e\xbd\xbb\x90\xa6\x94\x9e\xcb\xc5\xde\xcf\xfd'
    callback_module_3 = CallbackModule()
    var_1 = callback_module_3.v2_runner_on_failed(bytes_3)


# Generated at 2022-06-25 08:42:13.240657
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()


# Generated at 2022-06-25 08:42:15.122678
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert isinstance(callback_module_0, CallbackModule)


# Generated at 2022-06-25 08:42:21.069904
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    bytes_0 = b'\x80\xbf\x1a\xe3\xe0\xce\x8c\xaa\x0c\x9d\x97\xb0'
    callback_module_0 = CallbackModule()
    callback_module_0.v2_on_file_diff(bytes_0)


# Generated at 2022-06-25 08:42:28.723213
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bytes_0 = b'\x87v\x9a\x95\xeb\xdb\xf8\x19b\xef-\xd2\x7fr\x92'
    callback_module_0 = CallbackModule()

    # test for method v2_runner_on_unreachable
    callback_v2_runner_on_unreachable(callback_module_0, bytes_0)

    # test for method v2_runner_on_ok
    callback_v2_runner_on_ok(callback_module_0, bytes_0)

    # test for method v2_runner_on_failed
    callback_v2_runner_on_failed(callback_module_0, bytes_0)

    # test for method v2_runner_on_skipped
    callback_v2_runner_on_

# Generated at 2022-06-25 08:42:30.259040
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    fixture = CallbackModule()

    fixture.v2_runner_on_failed(result, ignore_errors=False)

    assert True


# Generated at 2022-06-25 08:42:33.220124
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_0 = b'\x87v\x9a\x95\xeb\xdb\xf8\x19b\xef-\xd2\x7fr\x92'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(bytes_0)


# Generated at 2022-06-25 08:45:10.305763
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    bytes_0 = b'\x87v\x9a\x95\xeb\xdb\xf8\x19b\xef-\xd2\x7fr\x92'
    var_1 = callback_module_1.v2_runner_on_failed(bytes_0)
    assert True


# Generated at 2022-06-25 08:45:11.669577
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()

if __name__ == "__main__":
    test_CallbackModule()

# Generated at 2022-06-25 08:45:20.578678
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bytes_0 = b'\x87v\x9a\x95\xeb\xdb\xf8\x19b\xef-\xd2\x7fr\x92'
    callback_module_0 = CallbackModule()
    assert(callback_v2_runner_on_unreachable(bytes_0) != None)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 08:45:25.470439
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.__class__
    var_1 = callback_module_0.CALLBACK_NAME
    var_2 = callback_module_0.CALLBACK_TYPE
    var_3 = callback_module_0.CALLBACK_VERSION
    var_4 = callback_module_0.v2_on_any()
    var_5 = callback_module_0.v2_on_any(**kwargs)


# Generated at 2022-06-25 08:45:27.380344
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        callback_module_0 = CallbackModule()
    except Exception:
        assert False,"Error in constructor of class CallbackModule."


# Generated at 2022-06-25 08:45:29.375567
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    mod = CallbackModule()
    mod.v2_runner_on_ok(obj)

# Generated at 2022-06-25 08:45:35.410052
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    bytes_0 = b'\x87v\x9a\x95\xeb\xdb\xf8\x19b\xef-\xd2\x7fr\x92'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_on_file_diff(bytes_0)

# Generated at 2022-06-25 08:45:39.809486
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    bytes_0 = b'\xd4\x91\x98\x00'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_on_file_diff(bytes_0)


# Generated at 2022-06-25 08:45:50.765395
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    bytes_0 = b'{{\r\n  "changed": false, \r\n  "invocation": {\r\n    "module_args": {\r\n      "meta": "defaults", \r\n      "src": "/home/vagrant/ansible-test/ansible-test/test_dir", \r\n      "dest": "/etc/ansible/test_dir", \r\n      "state": "directory"\r\n    }, \r\n    "module_name": "file"\r\n  }, \r\n  "failed": true, \r\n  "msg": "Destination /etc/ansible/test_dir not writable"\r\n}}'
    var_0 = callback_v2_runner_on_un

# Generated at 2022-06-25 08:45:55.073899
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    bytes_0 = b'\x87v\x9a\x95\xeb\xdb\xf8\x19b\xef-\xd2\x7fr\x92'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_on_file_diff(bytes_0)
