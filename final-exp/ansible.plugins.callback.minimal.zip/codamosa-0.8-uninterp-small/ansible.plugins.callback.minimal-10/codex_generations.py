

# Generated at 2022-06-25 08:36:11.363517
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()
    assert( isinstance(callback_module_1, CallbackModule) )


# Generated at 2022-06-25 08:36:14.701757
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module = CallbackModule()
    result = { "diff": True }
    callback_module.v2_on_file_diff(result)
    assert len(callback_module._display.display_messages) == 1


# Generated at 2022-06-25 08:36:21.586589
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    assert "ERROR" in callback_module.v2_runner_on_failed()
    assert "Changed" in callback_module.v2_runner_on_failed()
    assert "FAILED" in callback_module.v2_runner_on_failed()


# Generated at 2022-06-25 08:36:24.521510
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = {"rc": -1}
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors=False)


# Generated at 2022-06-25 08:36:30.897794
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()
    assert callback_module_1 is not None, "Could not instantiate CallbackModule"
    assert callback_module_1.CALLBACK_TYPE == 'stdout', "CallbackModule attrib CALLBACK_TYPE should be 'stdout'"
    assert callback_module_1.CALLBACK_VERSION == 2.0, "CallbackModule attrib CALLBACK_VERSION should be 2.0"
    assert callback_module_1.CALLBACK_NAME == 'minimal', "CallbackModule attrib CALLBACK_NAME should be 'minimal'"


# Generated at 2022-06-25 08:36:34.190921
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result = call_v2_runner_on_ok(callback_module_0)
    assert result


# Generated at 2022-06-25 08:36:35.453066
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    check = CallbackModule()
    assert check is not None


# Generated at 2022-06-25 08:36:47.849265
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    runner_on_ok = {"invocation": {"module_args": {}}}
    runner_on_ok_result_0 = {"failed": False, "changed": False, "rc": 0, "invocation": {"module_args": {}}, "ansible_job_id": "746381071592.7545"}
    runner_on_ok_result_1 = {"invocation": {"module_args": {}}, "ansible_job_id": "746381071592.7545"}
    runner_on_ok_result_2 = {"changed": False, "invocation": {"module_args": {}}, "ansible_job_id": "746381071592.7545"}

# Generated at 2022-06-25 08:36:54.762098
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = {
        'warnings': [
            "warning"
        ]
    }
    result_0 = {'warnings': ['warning'], 'changed': False, '_ansible_no_log': False, '_ansible_verbose_always': False}
    result_0 = {'warnings': ['warning'], 'changed': False, '_ansible_no_log': False, '_ansible_verbose_always': False}
    result_0 = {'warnings': ['warning'], 'changed': False, '_ansible_no_log': False, '_ansible_verbose_always': False}

# Generated at 2022-06-25 08:37:04.283230
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    cls = CallbackModule
    # Check if the base class of cls is CallbackBase
    assert issubclass(cls, CallbackBase)
    # Check if the constructor is defined
    assert hasattr(cls, '__init__')
    assert type(getattr(cls, '__init__')) is FunctionType
    # Check if the class variables are defined
    assert hasattr(cls, 'CALLBACK_VERSION')
    assert hasattr(cls, 'CALLBACK_TYPE')
    assert hasattr(cls, 'CALLBACK_NAME')
    # Check if the instance variables are defined
    assert hasattr(cls(), '_display')
    assert hasattr(cls(), '_disable_log_messages')
    assert hasattr(cls(), '_disable_warnings')
    assert hasattr

# Generated at 2022-06-25 08:37:11.999500
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_1 = CallbackModule()
    result = None
    callback_module_1.v2_on_file_diff(result)


# Generated at 2022-06-25 08:37:17.039986
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    callback_module_0.CALLBACK_TYPE = 'stdout'
    callback_module_0.CALLBACK_VERSION = 2.0
    callback_module_0.CALLBACK_NAME = 'minimal'



# Generated at 2022-06-25 08:37:20.712876
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()

    result_0 = {'diff': '# Generated by CallbackModule.v2_runner_on_failed()'}
    assert callback_module_0.v2_on_file_diff(result_0)



# Generated at 2022-06-25 08:37:32.900330
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:37:35.385195
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result_0 = dict()
    result_0["diff"] = dict()
    assert callback_module_0.v2_on_file_diff(result_0) == None


# Generated at 2022-06-25 08:37:38.167680
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result_0 = {}
    result_0['diff'] = {}
    callback_module_0.v2_on_file_diff(result_0)


# Generated at 2022-06-25 08:37:42.965723
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result = "result_0"
    callback_module_0.v2_on_file_diff(result)


# Generated at 2022-06-25 08:37:53.575113
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()

    class DummyHost:
        name = "TestHost"
        def get_name(self):
            return self.name

    class DummyTask:
        action = "TestAction"

    class DummyResult:
        def __init__(self, result_dict, host, task):
            self._result = result_dict
            self._host = host
            self._task = task

    test_host = DummyHost()
    test_task = DummyTask()


# Generated at 2022-06-25 08:37:58.609237
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = result()
    ignore_errors_0 = False
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:38:02.678435
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    result_2 = 'result_2'
    ignore_errors_3 = 'ignore_errors_3'
    assert callback_module_1.v2_runner_on_failed(result_2, ignore_errors_3) == None


# Generated at 2022-06-25 08:38:20.404148
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():

    # Input Parameters
    result = None # Provide correct value

    callback_module_0 = CallbackModule()

    # Calling method v2_on_file_diff
    result = callback_module_0.v2_on_file_diff(result)


# Generated at 2022-06-25 08:38:29.914752
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    runner_result_0 = CallbackModule.result_t(task=CallbackModule.task_t(), host=CallbackModule.host_t())

# Generated at 2022-06-25 08:38:35.390626
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result = {'diff':'+ module: test'}

    callback_module_0._display.display = lambda a, b=None, c=None, d=None, e=None, f=None, g=None, h=None: 'hello'
    assert callback_module_0.v2_on_file_diff(result) == None


# Generated at 2022-06-25 08:38:39.254711
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    callback_module.v2_runner_on_failed(result, ignore_errors=False)


# Generated at 2022-06-25 08:38:44.129943
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:38:45.915879
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = callback_module_0.v2_runner_on_ok("result_0")


# Generated at 2022-06-25 08:38:49.776632
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_v2_runner_on_failed = CallbackModule()
    callback_module_v2_runner_on_failed.v2_runner_on_failed()

# Generated at 2022-06-25 08:38:59.968818
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    callback_module_0 = CallbackModule()
    result_0 = result_1 = None

    # TODO: Add tests for when no _display.display method is defined
    # Currently this is not possible because _display is an ansible plugin
    # object, which cannot be easily mocked without patch

    # TODO: Add tests for when no _dump_results or _display.display methods
    # are defined

    # TODO: Add tests for when the _display.display method does not accept
    # arguments

    # TODO: Add tests for when the _dump_results method does not return str
    # Currently this is not possible because _dump_results is an ansible plugin
    # method, which cannot be easily mocked without patch

    # TODO: Add tests for when the _dump_results method does not return a
    # string

    # TODO: Add tests

# Generated at 2022-06-25 08:39:06.368266
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = result()

    # test invocation of method v2_runner_on_ok of class CallbackModule
    assert_equal(callback_module_0.v2_runner_on_ok(result_0), None)


# Generated at 2022-06-25 08:39:16.913765
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    test_result = dict()

# Generated at 2022-06-25 08:39:40.136868
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:39:47.056798
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result_0 = Dummy()
    result_0._result = { 'diff': True }
    result_0._result['diff'] = 'diff'

    # Test know exceptions
    try:
        callback_module_0.v2_on_file_diff(result_0)
    except:
        pass
    else:
        print('ExpectedException not raised!')
        assert False


#
# Class definition for a dummy
#

# Generated at 2022-06-25 08:39:54.468112
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    import ansible
    callback_module_0 = CallbackModule()
    assert callback_module_0.__class__ == CallbackModule
    assert callback_module_0.__dict__.get("CALLBACK_VERSION") == 2.0
    assert callback_module_0.__dict__.get("CALLBACK_NAME") == 'minimal'
    assert callback_module_0.__dict__.get("CALLBACK_TYPE") == 'stdout'


# Generated at 2022-06-25 08:39:57.208864
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    print("Unit test for constructor of class CallbackModule")
    try:
        test_case_0()
    except:
        print("Exception in the test case 0")
        raise



# Generated at 2022-06-25 08:40:06.855913
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    results_0 = {
};
    task_0 = {
        'action':  'configure'
    };
    host_0 = {
        'name': 'host-0'
    };
    result_0 = {
        '_task': task_0,
        '_host': host_0,
        '_result': results_0
    };
    result_1 = {
        '_task': task_0,
        '_host': host_0,
        '_result': results_0
    };
    callback_module_0.v2_runner_on_ok(result_0)
    callback_module_0.v2_runner_on_ok(result_1)


# Generated at 2022-06-25 08:40:08.524970
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()

if __name__ == "__main__":
    test_CallbackModule()

# Generated at 2022-06-25 08:40:12.826130
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = sentinel
    ignore_errors_0 = None
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)



# Generated at 2022-06-25 08:40:18.679322
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result_0 = {'diff': [], 'encoding': 'UTF-8', 'dest': 'test_data/test_file', 'msg': '', 'src': False}
    result_0_0 = callback_module_0.v2_on_file_diff(result_0)
    assert result_0_0 is None


# Generated at 2022-06-25 08:40:21.377840
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    result = {}
    ignore_errors = False
    return_val = callback_module.v2_runner_on_failed(result, ignore_errors=False)
    assert return_val is None


# Generated at 2022-06-25 08:40:22.697585
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_1 = MockAnsibleResult()
    callback_module_0.v2_runner_on_ok(result_1)


# Generated at 2022-06-25 08:40:58.384085
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Initialize CallbackModule object
    callback_module_0 = CallbackModule()
    # Get test result from class Result
    result_0 = None
    # Get hostname from class Host
    host = None
    # Prepare test argument
    result = result_0
    # Run test
    callback_module_0.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:41:05.996463
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():

    callback_module_1 = CallbackModule()
    result_1 = unittest.mock.Mock(**{'_result': unittest.mock.DEFAULT})
    callback_module_1.v2_on_file_diff(result_1)


# Generated at 2022-06-25 08:41:11.225981
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_1 = CallbackModule()
    result_1 = callback_module_1.v2_runner_on_ok('result_1')
    return result_1


# Generated at 2022-06-25 08:41:13.590075
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()
    assert( isinstance( callback_module_1, CallbackBase ) )
    assert( callback_module_1.CALLBACK_VERSION == 2.0 )
    assert( callback_module_1.CALLBACK_TYPE == 'stdout' )
    assert( callback_module_1.CALLBACK_NAME == 'minimal' )

# Generated at 2022-06-25 08:41:16.123573
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_1 = CallbackModule()
    callback_module_1.v2_on_file_diff(result)


# Generated at 2022-06-25 08:41:22.357764
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_v2_runner_on_ok_0 = CallbackModule()
    result_0 = Dummy()
    callback_module_v2_runner_on_ok_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:41:27.292064
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = {}
    ignore_errors_0 = bool()
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)



# Generated at 2022-06-25 08:41:35.770661
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestCallbackModule(unittest.TestCase):
        def setUp(self):
            self.test_object = CallbackModule()

        @patch('ansible.plugins.callback.CallbackBase._handle_exception')
        @patch('ansible.plugins.callback.CallbackBase._handle_warnings')
        @patch('ansible.plugins.callback.CallbackBase._display.display')
        def test_case(self, mock__display_display, mock__handle_warnings, mock__handle_exception):
            test_result = dict()
            test_result['_result'] = dict()
            test_result['_result']['_host'] = dict()

# Generated at 2022-06-25 08:41:40.312913
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_1 = CallbackModule() # create object
    callback_module_1.v2_on_file_diff({"diff":{"before":"./_test1.py","after":"./_test2.py","before_header":"before_header_test","after_header":"after_header_test"}})


# Generated at 2022-06-25 08:41:46.295731
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_1 = CallbackModule()

    class result:
        class _task:
            class action:
                pass
        class _result:
            pass
        class _host:
            class get_name:
                pass
    result._task.action = 'some action'
    result._result = {'changed': True}
    callback_module_1.v2_runner_on_ok(result)

# Generated at 2022-06-25 08:42:54.825801
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()
    assert isinstance(callback_module_1, CallbackModule)


# Generated at 2022-06-25 08:42:58.697451
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:43:03.412623
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert(callback_module_0.CALLBACK_VERSION == 2.0)
    assert(callback_module_0.CALLBACK_TYPE == 'stdout')
    assert(callback_module_0.CALLBACK_NAME == 'minimal')


# Generated at 2022-06-25 08:43:04.534041
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    result = CallbackModule()
    assert result is not None


# Generated at 2022-06-25 08:43:06.399419
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module = CallbackModule()


# Generated at 2022-06-25 08:43:07.983450
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module = CallbackModule()
    callback_module.v2_runner_on_ok()
    return False


# Generated at 2022-06-25 08:43:16.718303
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert callback_module_0._display is not None
    assert callback_module_0._last_task_banner is False
    assert callback_module_0._disable_warnings is False
    assert callback_module_0._display.verbosity < 2
    assert callback_module_0.CALLBACK_VERSION == 2.0
    assert callback_module_0.CALLBACK_TYPE == 'stdout'
    assert callback_module_0.CALLBACK_NAME == 'minimal'


# Generated at 2022-06-25 08:43:20.012385
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    assert hasattr(callback_module_0, '_display')


# Generated at 2022-06-25 08:43:25.568253
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    test_data = [
        {"runner_on_ok": {"result":"result_1"}},
        {"runner_on_ok": {"result":"result_2"}}
    ]
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok(test_data[0]["runner_on_ok"]["result"])
    callback_module_0.v2_runner_on_ok(test_data[1]["runner_on_ok"]["result"])

# Generated at 2022-06-25 08:43:29.109258
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    test_case_1 = CallbackModule()
    assert not test_case_1.v2_runner_on_failed(result=None)
