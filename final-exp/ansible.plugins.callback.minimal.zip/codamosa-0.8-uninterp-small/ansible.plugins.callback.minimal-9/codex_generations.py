

# Generated at 2022-06-25 08:36:13.327472
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:36:17.939218
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_1 = CallbackModule()
    result_2 = dict()
    host_3 = dict()
    task_4 = dict()
    result_5 = dict()
    task_4['action'] = 'something'
    host_3['get_name'] = lambda: 'test_host'
    result_5['changed'] = False
    result_2['_result'] = result_5
    result_2['_task'] = task_4
    result_2['_host'] = host_3
    callback_module_1.v2_runner_on_ok(result_2)


# Generated at 2022-06-25 08:36:20.257613
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    print("Unit test for method v2_runner_on_ok of class CallbackModule")


# Generated at 2022-06-25 08:36:25.557575
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    result=dict()
    result['diff']=''
    result2=dict()
    result2['diff']='diff.txt'
    callback_module_1 = CallbackModule()
    callback_module_1.v2_on_file_diff(result)
    callback_module_1.v2_on_file_diff(result2)

test_case_0()    
test_CallbackModule_v2_on_file_diff()

# Generated at 2022-06-25 08:36:26.801420
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()

# vim: set expandtab ts=4 sts=4 sw=4 ft=python ai :

# Generated at 2022-06-25 08:36:31.057000
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result = Result(success=True,changed=True,msg="something",result_item="result_item")
    result._result = dict(diff="  hello\n  world\n-hello\n-world\n?  hello\n")
    result1 = Result(success=True,changed=True,msg="something",result_item="result_item")
    result1._result = dict(diff=[ "@@ -1,1 +1,2 @@\n-hello\n+hello","@@ -2,2 +2,2 @@\n-world\n+world" ])
    result2 = Result(success=True,changed=True,msg="something",result_item="result_item")

# Generated at 2022-06-25 08:36:33.521852
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok()

# Generated at 2022-06-25 08:36:35.491205
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed("result", True)


# Generated at 2022-06-25 08:36:45.348441
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = mock(name="result_0", _result={})
    _host_0 = mock(name="_host_0", get_name=mock(return_value='host_name_0'))
    setattr(result_0, '_host', _host_0)
    _task_0 = mock(name="_task_0", action="action_0")
    setattr(result_0, '_task', _task_0)

    assert callback_module_0.v2_runner_on_failed(result_0) == {}


# Generated at 2022-06-25 08:36:47.763298
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    result = None
    cb = CallbackModule()
    cb.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:36:57.806185
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
  # 1. Create callback_module_0
  callback_module_0 = CallbackModule()

  # 2. Call method v2_runner_on_failed on callback_module_0 with valid arguments
  result = v2_runner_on_failed(callback_module_0, result, ignore_errors)


# Generated at 2022-06-25 08:37:02.213111
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    result_2 = Result()
    ignore_errors_3 = False
    callback_module_1.v2_runner_on_failed(result_2, ignore_errors_3)


# Generated at 2022-06-25 08:37:07.755185
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    class A:
        def __init__(self):
            self._host = 'hostname'
            self._result = {"changed": False}
    result_0 = A()
    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:37:08.862235
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()

# Generated at 2022-06-25 08:37:12.850729
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_on_failed({'host': 'myhost', 'result': {'rc': 0}})



# Generated at 2022-06-25 08:37:14.697017
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:37:17.274249
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    assert callback_module_0.v2_on_file_diff() is None

# Generated at 2022-06-25 08:37:19.152856
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module = CallbackModule()
    callback_module.v2_runner_on_ok(None)

# Generated at 2022-06-25 08:37:27.347274
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    job_id = 0
    result = {'changed': False, 'msg': 'test message', 'ansible_job_id': job_id}
    host = 'test_host'
    result_obj = type('result_obj', (object,), {'_result': result, '_host': type('host_obj', (object,), {'get_name': lambda self: host})})
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok(result_obj)


# Generated at 2022-06-25 08:37:31.269068
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module = CallbackModule()
    assert callback_module is not None
    result = callback_module.v2_runner_on_ok(result=None)
    assert result is None
    #print(result)


# Generated at 2022-06-25 08:37:48.043566
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    cb_mock = CallbackModule()
    cb_mock.v2_runner_on_ok(None)


# Generated at 2022-06-25 08:37:49.993878
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule()


# Generated at 2022-06-25 08:37:53.287048
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    try:
        test_case_0()
    except:
        print("\nFAILED: The constructor for class CallbackModule failed.")
        assert False


# Generated at 2022-06-25 08:37:57.076595
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = ''
    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:38:00.546570
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    try:
        callback_module_0 = CallbackModule()
        callback_module_0.v2_on_file_diff()
    except Exception as e:
        assert(False or e)


# Generated at 2022-06-25 08:38:09.417216
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = mock.Mock()
    result_0.task.action = "shell"
    result_0._result = dict()
    result_0._result['msg'] = 'asdf'
    result_0._result['ansible_job_id'] = 'asdf'
    result_0._host.get_name.return_value = "localhost"

    # Test case 1: action on result._result is shell, no ascii color

# Generated at 2022-06-25 08:38:11.417321
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_1 = CallbackModule(display=None)
    assert callback_module_1.display == None
    pass


# Generated at 2022-06-25 08:38:18.547157
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = {}
    result_0['_ansible_parsed'] = False
    result_0['_ansible_no_log'] = False
    result_0['_ansible_item_label'] = 'Result'
    result_0['_ansible_verbose_always'] = True
    result_0['_ansible_selection_mark'] = None
    result_0['_ansible_verbose_override'] = False
    result_0['_ansible_ignore_errors'] = False
    result_0['_ansible_is_check'] = False
    result_0['_ansible_no_log_values'] = None
    result_0['_ansible_done'] = False

# Generated at 2022-06-25 08:38:22.052075
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_on_ok({'stdout': '', 'rc': 0})


# Generated at 2022-06-25 08:38:26.956955
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:39:01.965574
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_1 = CallbackModule()
    result = {'diff': '# diff'}
    assert callback_module_1.v2_on_file_diff(result) == None


# Generated at 2022-06-25 08:39:04.291087
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    """
    Constructor of class CallbackModule
    """
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:39:14.066188
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test case 0
    callback_module_0 = CallbackModule()
    result_0 = {
        'rc': 0
    }
    result_0['stderr'] = ''
    result_0['stdout'] = ''
    result_0['msg'] = ''
    result_0['_ansible_verbose_always'] = False

    # Call the function
    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:39:16.764017
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Test if instantiation of CallbackModule raises no errors
    test_case_0()

# Generated at 2022-06-25 08:39:28.015362
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule() # instance creation

# Generated at 2022-06-25 08:39:29.070616
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    pass

# Generated at 2022-06-25 08:39:30.097949
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert repr(test_case_0) == '<module>'

# Generated at 2022-06-25 08:39:34.767238
# Unit test for constructor of class CallbackModule
def test_CallbackModule():

    # create instance of CallbackModule
    callback_module_0 = CallbackModule()

    assert callback_module_0 != None



# Generated at 2022-06-25 08:39:35.910234
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:39:43.536867
# Unit test for constructor of class CallbackModule
def test_CallbackModule():

    callback_module_0 = CallbackModule()
    assert isinstance(callback_module_0, CallbackModule)
    assert callback_module_0.CALLBACK_VERSION == 2.0
    assert callback_module_0.CALLBACK_TYPE == 'stdout'
    assert callback_module_0.CALLBACK_NAME == 'minimal'

# Generated at 2022-06-25 08:40:24.699456
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Init test variables
    num_0 = 84
    string_0 = "X9c;5_F;QS>:GAfh:e8$Y^0-"
    string_1 = "7IPW8R;l#f0uD1wqg\\^i*`bYVub_\\<tGv?Zm!9R&z7VnLfDq3*yW<g2YcBVH<t#o5NGlh_9X.*c1L_{`S?<wE@W:$f<G!!V4=P4)"
    string_2 = "p"
    string_3 = "yI+:A:<Y6]Fwn6UJ"
    string_4 = ";@"

# Generated at 2022-06-25 08:40:31.207340
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    runner_on_failed_0 = CallbackModule()
    runner_on_failed_0.v2_runner_on_failed(runner_on_failed_0)
    runner_on_failed_0.set_runner_on_failed(runner_on_failed_0)


# Generated at 2022-06-25 08:40:39.166193
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    # Initialization
    msg_1 = 'x;l'
    result_1 = ('x;l')
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_on_ok(result_1)

    # Test State
    assert result_1[0:5] == "x;l"
    assert result_1[0:5] == result_1[5:10]
    assert len(result_1) == 10

    # Clean Up
    del result_1
    del msg_1
    del callback_module_1
    del callback_module_0
    del str_0


# Generated at 2022-06-25 08:40:42.027202
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    str_0 = 'x;l'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_unreachable(str_0)


# Generated at 2022-06-25 08:40:44.435051
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    test_case_0()

# Generated at 2022-06-25 08:40:46.076722
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    result = {}
    result['diff'] = {}
    CallbackModule().v2_on_file_diff(result)


# Generated at 2022-06-25 08:40:49.452820
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    print('Call test_CallbackModule_v2_runner_on_ok')
    result = random_int_0
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:40:54.687784
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Initialize CallbackModule object
    callback_module_0 = CallbackModule()
    # Verify default values
    var_0 = CallbackModule.CALLBACK_VERSION
    assert var_0 == 2.0, "CALLBACK_VERSION(2.0) not equals to " + var_0
    var_0 = CallbackModule.CALLBACK_TYPE
    assert var_0 == "stdout", "CALLBACK_TYPE('stdout') not equals to " + var_0
    var_0 = CallbackModule.CALLBACK_NAME
    assert var_0 == "minimal", "CALLBACK_NAME('minimal') not equals to " + var_0



# Generated at 2022-06-25 08:40:56.956394
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result_0 = mock()
    result_0._result = dict()
    result_0._result['diff'] = 'x;l'
    callback_module_0.v2_on_file_diff(result_0)


# Generated at 2022-06-25 08:40:57.346682
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    pass

# Generated at 2022-06-25 08:42:02.849436
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    test_case_0()

# Generated at 2022-06-25 08:42:10.984100
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    str_0 = 'M%'
    str_1 = 'RV&'
    str_2 = 'd*s'
    int_0 = 0
    int_1 = 1
    float_0 = 1.0
    list_0 = [2, 3, 4]
    dict_0 = {'a': 1, 'b': 2, 'c': 3}
    callback_module_0 = CallbackModule()
    tuple_0 = (int_1, float_0, list_0, dict_0)
    var_0 = callback_v2_runner_on_ok(str_2, tuple_0, int_0, str_1)


# Generated at 2022-06-25 08:42:20.679412
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback_module_0 = CallbackModule()
    callback_module_0._handle_warnings(str_0)
    callback_module_0.v2_on_file_diff(str_0)
    callback_module_0.v2_runner_on_failed(str_0)
    callback_module_0.v2_runner_on_ok(str_0)
    callback_module_0.v2_runner_on_skipped(str_0)
    callback_module_0.v2_runner_on_unreachable(str_0)

# Generated at 2022-06-25 08:42:22.759417
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    str_0 = ';q'
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_on_file_diff(str_0)


# Generated at 2022-06-25 08:42:30.409074
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Create instance of class with the "array" attribute
    callback_module_0 = CallbackModule()
    callback_module_0.array = []
    # Create test data
    dict_0 = dict({'Key 2': 'Value 2', 'Key 1': 'Value 1', 'Key 3': 'Value 3'})
    expected_0 = '{\n    "Key 1": "Value 1", \n    "Key 2": "Value 2", \n    "Key 3": "Value 3"\n}'
    # Call the method to test
    actual_return_0 = callback_module_0.v2_on_file_diff(dict_0)
    # Assert the expected results with the actual results
    # check if the "array" attribute has the same data as provided
    assert actual_return_0 == expected_0


# Generated at 2022-06-25 08:42:32.896569
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Set up mock objects
    CallbackModule_obj = CallbackModule
    result = mock.Mock( spec=['_result'] )
    ignore_errors = False

    CallbackModule_obj.v2_runner_on_failed(result, ignore_errors)


# Generated at 2022-06-25 08:42:34.444874
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = Result()
    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:42:41.363636
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
	# Instantiating an object of class CallbackModule
	obj_callback_module = CallbackModule()
	# Calling the v2_runner_on_failed method of CallbackModule class with several arguments
	obj_callback_module.v2_runner_on_failed(result, ignore_errors=False)


# Generated at 2022-06-25 08:42:42.788214
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    assert(True)


# Generated at 2022-06-25 08:42:46.022742
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test if a TypeError is raised for an invalid argument
    with pytest.raises(TypeError):
        # Call function with incorrect argument types
        CallbackModule.v2_runner_on_failed(int)
        CallbackModule.v2_runner_on_failed(int, str)


# Generated at 2022-06-25 08:45:40.326705
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    print ('\nTest for method v2_runner_on_failed of class CallbackModule')
    str_0 = 'x;l'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(str_0)
    # Expecting error here
    assert var_0 != 'asdfasdf'


# Generated at 2022-06-25 08:45:41.612163
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
  # No test case
  pass


# Generated at 2022-06-25 08:45:44.270287
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    assert callback_module_0.v2_runner_on_ok


# Generated at 2022-06-25 08:45:49.660684
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # print("test for constructor of class CallbackModule")
    test_case_0()

if __name__ == "__main__":
    test_CallbackModule()

# Generated at 2022-06-25 08:45:56.153310
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    c = CallbackModule()
    c.v2_runner_on_skipped(result)
    c.v2_runner_on_ok(result)
    c.v2_runner_on_unreachable(result)
    c.v2_on_file_diff(result)
    c.v2_runner_on_failed(result)

# Coverage test of function _command_generic_msg
# NOTE: This function is only used by CallbackModule
#       So in the real scenario, it will not be used.

# Generated at 2022-06-25 08:45:58.095135
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    color = null
    state = null
    self = null
    result = null
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_ok(result)


# Generated at 2022-06-25 08:46:03.701239
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Assume any object (and its instance) of type 'dict'
    result_0 = dict()
    test_case_0(result_0)
