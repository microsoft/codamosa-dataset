

# Generated at 2022-06-11 13:37:00.915244
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    # override the test class with a mocked one:
    # - in order to test if the parent method '_handle_warnings' has been called
    # - in order to test if the parent method '_handle_exception' has been called
    # - in order to test if the parent method '_display.display' has been called with specific params
    class CallbackModuleMocked(CallbackModule):

        def __init__(self, *args, **kwargs):
            self._display = Mock()
            return super(CallbackModuleMocked, self).__init__(*args, **kwargs)

        def _handle_warnings(self, result):
            self.warnings_handled = True
            return super(CallbackModuleMocked, self)._handle_warnings(result)

        def _handle_exception(self, result):
            self.exception

# Generated at 2022-06-11 13:37:08.365891
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    c = CallbackModule()
    c._display = MockClass()
    temp_result = {}
    temp_result['diff'] = "DIFF.txt"
    temp_result['src'] = "FILE.txt"
    temp_result['dest'] = "FILE.txt"
    result = MockClass()
    result._result = temp_result
    c.v2_on_file_diff(result)
    assert c._display.display_val == 'DIFF.txt'


# Generated at 2022-06-11 13:37:16.936367
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    # Mock result
    result = MockResult({
        'changed': False,
        'result': {
            'contacted': {
                '1.1.1.1': {
                    'changed': False,
                    'invocation': {
                        'module_args': 'arguments',
                 },
                 'rc': 0,
                 'stdout': 'stdout',
                 'stderr': 'stderr',
                 'stdout_lines': 'stdout_lines',
                 'stderr_lines': 'stderr_lines',
                 'warnings': ['warning'],
                 'msg': 'message',
                },
            },
        },
    })

    # Mock CallbackModule
    callback = MockCallbackModule()

    # Mock display

# Generated at 2022-06-11 13:37:23.694385
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    "Unit test to validate the v2_runner_on_ok method of class CallbackModule"
    cb = CallbackModule()
    cb._display.display = lambda x,y:print(x,y)
    cb.v2_runner_on_ok(dict(changed=False,_host=dict(get_name=lambda: 'host'),_result=dict()))


# Generated at 2022-06-11 13:37:26.399520
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    obj = CallbackModule()
    assert obj.CALLBACK_VERSION == 2.0
    assert obj.CALLBACK_TYPE == 'stdout'
    assert obj.CALLBACK_NAME == 'minimal'

# Generated at 2022-06-11 13:37:31.186092
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
  text_chunk = """
    @@ -1 +1 @@

    -2
    +3
  """
  result = {}
  result['diff'] = text_chunk
  output = CallbackModule()
  output._display = OutputDummy()
  output.v2_on_file_diff(result)


# Generated at 2022-06-11 13:37:32.270025
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    pass


# Generated at 2022-06-11 13:37:40.156831
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Prepare test data: file_name, before, after, expected_answer
    test_data = [
        {'file_name': 'path/to/file.txt',
         'before': """line1
_line2_
line3""",
         'after': '''line1
line2
line3''',
         'expected_answer': ''
        }
    ]
    # Test
    for test_sample in test_data:
        cbm = CallbackModule()
        cbm.v2_on_file_diff(test_sample)
        pass

# Generated at 2022-06-11 13:37:50.590849
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    import ansible.utils.template as template

    new_result = {'diff': 'zmiana'}
    result = type('', (object,), {'_result': new_result})

    class MockDisplay(object):
        def __init__(self):
            self.display_called = False

        def display(self, *args, **kargs):
            self.display_called = True

    class MockCallbackModule(CallbackModule):
        def v2_on_file_diff(self, result):
            super(MockCallbackModule, self).v2_on_file_diff(result)

    callback = MockCallbackModule()
    callback.set_options({})
    callback._display = MockDisplay()
    callback.v2_on

# Generated at 2022-06-11 13:37:51.571062
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule() is not None

# Generated at 2022-06-11 13:38:05.201144
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from io import StringIO

    from ansible import context

    stdout_io = StringIO()
    stderr_io = StringIO()

    class Host:
        def get_name(self):
            return 'test-host'

    class Result:
        def __init__(self):
            self._result = {'changed': True, 'foo': 'bar'}
            self._host = Host()

    callback = CallbackModule()
    callback._display.verbosity = 0
    callback._display.output = stdout_io
    callback._display._stderr = stderr_io

    with context.CLIARGS._store.context(stdout_io=stdout_io, stderr_io=stderr_io, color=True):
        callback.v2_runner_on_ok(Result())
   

# Generated at 2022-06-11 13:38:06.256770
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    CallbackModule(display=None)

# Generated at 2022-06-11 13:38:06.968044
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    pass

# Generated at 2022-06-11 13:38:08.971057
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    c = CallbackModule()
    c.v2_runner_on_failed(result=result)
    assert True

# Generated at 2022-06-11 13:38:09.806513
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    pass

# Generated at 2022-06-11 13:38:19.026571
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from collections import namedtuple
    import pytest
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    # Create objects for code being tested
    display = object()
    loader = DataLoader()
    variable_manager = VariableManager()
    host = namedtuple('Host', ['get_name'])('hostname')
    result = namedtuple('Result', ['_host', '_result', '_task'])(host, {'stdout':'stdout', 'stderr':'stderr'}, {'action':'module'})

    # Create the object to be tested
    callback = Callback

# Generated at 2022-06-11 13:38:29.980073
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import os
    import sys
    import ansible.plugins.callback
    import ansible.utils.unsafe_proxy
    import ansible.utils.template
    import ansible.module_utils.basic
    import ansible.module_utils.common.removed
    import ansible.module_utils.facts.virtual
    
    current_dir = os.path.dirname(os.path.abspath(__file__))
    base_dir = os.path.dirname(current_dir)
    module_name = os.path.join(current_dir, 'fixtures', 'library', 'test_runner_on_ok.py')
    
    sys.path.append(current_dir)
    sys.path.append(base_dir)
    
    C = ansible.plugins.callback.CallbackBase()

# Generated at 2022-06-11 13:38:40.813856
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    '''
    Unit test for method v2_runner_on_ok of class CallbackModule
    '''
    from ansible.plugins.callback.minimal import CallbackModule
    from ansible.plugins.callback import CallbackBase
    import json
    import sys
    import tempfile
    import time

    test_host_name = 'test_server'
    test_stdout = '''
    {
        "changed": true,
        "invocation": {
            "module_args": {
                "name": "test.log"
            },
            "module_name": "copy"
        },
        "ping": "pong",
        "src": "/root/test.log"
    }
    '''

    test_stdout_dict = json.loads(test_stdout)

    test_result = create_

# Generated at 2022-06-11 13:38:51.016034
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    cm = CallbackModule()
    # Bad value for Result
    assert cm._dump_results("badValue") == "badValue", "Unexpected value when Result is bad"

    # Result is correct and test should pass
    time = datetime(year=2018, month=5, day=16, hour=10, minute=20, second=30)
    runner_result = Result("host1", "task1", "action1", Result.State.FAILED, time, time, time, time, time, time, time, time, time, time, time)
    runner_result.set_result("result")
    assert cm._dump_results(runner_result._result) == "result", "Unexpected value when Result is correct"

    # Correct format of host but incorrect format of result
    runner_result.set_host("host1")
    assert cm

# Generated at 2022-06-11 13:39:01.749993
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # calling instance of the class
    inst = CallbackModule()
    inst_runner_on_ok_args = {
        "_host": {
            "name": "localhost"
        },
        "_task": {
            "action": "TEST_ACTION"
        },
        "_result": {
            "changed": False,
            "_ansible_no_log": False
        }
    }

    # test with changed = False
    result = inst.v2_runner_on_ok(inst_runner_on_ok_args)
    assert result == "localhost | SUCCESS => {\n"

    # test with changed = True
    inst_runner_on_ok_args['_result']['changed'] = True
    result = inst.v2_runner_on_ok(inst_runner_on_ok_args)
   

# Generated at 2022-06-11 13:39:09.429669
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    return CallbackModule()

# Generated at 2022-06-11 13:39:19.845858
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils import context_objects as co
    import json

    inventory = InventoryManager(loader=DataLoader(), sources="mock_hosts")
    variables = VariableManager(loader=DataLoader(), inventory=inventory)
    pbex = PlaybookExecutor(playbooks=["test_playbook.yml"], inventory=inventory, variable_manager=variables, loader=DataLoader())
    pbex._tq

# Generated at 2022-06-11 13:39:29.921909
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Declaration of objects and variables
    obj = CallbackModule()
    result = dict()
    # Assign values to the variables
    result['invocation'] = {'module_name': 'setup', 'module_args': {}}

# Generated at 2022-06-11 13:39:40.253563
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible import constants as C
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.callback.minimal import CallbackModule
    import json
    import io

    class TestDisplay:
        def __init__(self):
            self.displayed = []
        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            self.displayed.append(msg)

    class TestResult:
        def __init__(self, host, action):
            self._host = host
            self._task = {'action': action}
            self._result = {}

    class TestHost:
        def __init__(self, name):
            self.name = name
        def get_name(self):
            return self.name

    module = Call

# Generated at 2022-06-11 13:39:50.743295
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    import pytest
    from collections import namedtuple
    from ansible.plugins.callback.minimal import CallbackModule
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C

    Options = namedtuple('Options', ['connection', 'module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'listhosts', 'listtasks', 'listtags', 'syntax'])
    options = Options(connection='smart', module_path=None, forks=10, become=None, become_method=None, become_user=None, check=False, listhosts=False, listtasks=False, listtags=False, syntax=False)
    my_call_minimal = CallbackModule()

# Generated at 2022-06-11 13:39:57.560333
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import sys
    temp_stdout = sys.stdout
    try:
        from io import StringIO
        sys.stdout = capture_stdout = StringIO('\n')
        callback = CallbackModule()
        result = type("result", (), {})
        result._result = {'diff': 'line1\nline2\n'}
        callback.v2_on_file_diff(result)
        assert capture_stdout.getvalue() == '--- line1\n+++ line2\n'
    finally:
        sys.stdout = temp_stdout

# Generated at 2022-06-11 13:40:05.080495
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    with patch('ansible.plugins.callback.minimal.AnsibleRunner') as r:
        r.return_value.get_diff.return_value = "Testing"
        c = CallbackModule()
        result = namedtuple('result', '_result')(_result={'diff': ""})
        assert c.v2_on_file_diff(result) == None
        r.return_value.get_diff.assert_called_with({})
        result._result['diff'] = "Test"
        c.v2_on_file_diff(result)
        r.return_value.get_diff.assert_called_with("Test")

# Generated at 2022-06-11 13:40:10.886360
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result = {
        'stdout': '[{}]',
        'stderr': '',
        'rc': 1,
        'msg': 'Non-zero return code',
    }
    cb = CallbackModule()
    assert cb._command_generic_msg('host', result, 'FAILED') == """host | FAILED | rc=1 >>
[{}]\n"""
    

# Generated at 2022-06-11 13:40:19.985747
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    display = object()
    result = object()

    callback = CallbackModule(display)

    result._host.get_name.return_value = "host1"
    result._result.get.return_value = False
    result._result.get.return_value = "module1"

    result._result = {
        "changed": False,
        "_ansible_verbose_always": True,
        "invocation": {
            "module_args": {}
        }
    }

    assert callback.v2_runner_on_ok(result) == None
    assert result._host.get_name.call_count == 1
    assert result._result.get.call_count == 1


# Generated at 2022-06-11 13:40:24.177985
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    '''
    Testing method v2_on_file_diff
    '''
    test_result = {'diff': {'before': 'b', 'after': 'a'}}
    test_class = CallbackModule()
    test_class.v2_on_file_diff(test_result)


# Generated at 2022-06-11 13:40:47.015709
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import json, os
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    from ansible_collections.ansible.community.plugins.callback.minimal import CallbackModule

    class TestCallbackModule(unittest.TestCase):

        def setUp(self):
            self.decoded = {
                'before': 'before_data',
                'after': 'after_data',
                'before_header': 'before_header',
                'after_header': 'after_header'
            }

            self.callback = CallbackModule()


# Generated at 2022-06-11 13:40:51.950575
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    class RunnerResult:
        def __init__(self):
            self._host = {'get_name': 'host_name'}
            self._result = {}

    result = RunnerResult()
    result._task = {'action': 'shell'}
    callback = CallbackModule()
    callback.v2_runner_on_ok(result)


# Generated at 2022-06-11 13:40:53.431623
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
	callback_module = CallbackModule()
	assert callback_module != None

# Generated at 2022-06-11 13:41:04.071047
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Parameters
    from ansible.constants import CALLBACK_VERSION
    from ansible.executor.task_result import TaskResult
    # test for changed results
    module_result = dict(
        ansible_job_id='1',
        ansible_facts=[],
        changed=True,
        _ansible_no_log=False,
        _ansible_item_result=False,
        _ansible_ignore_errors=False,
        _ansible_selectattr=None,
        _ansible_verbose_always=False,
        msg="Hello")


# Generated at 2022-06-11 13:41:08.480697
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # inputs
    result = 'arg_result'
    result._result = {'changed': True}
    result._task = 'arg_task'
    result._task.action = 'arg_task_action'

    # target object
    obj = CallbackModule()

    # call the method
    obj.v2_runner_on_ok(result)

# Generated at 2022-06-11 13:41:13.036164
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    """
    Unit test for method v2_runner_on_failed of class CallbackModule
    """

    # Create a CallbackModule object
    callback_module_obj = CallbackModule()

    # Test: call to v2_runner_on_failed
    result = {}
    actual_output = callback_module_obj.v2_runner_on_failed(result, ignore_errors=False)
    expected_output = "FAILED! => {}"
    assert expected_output == actual_output


# Generated at 2022-06-11 13:41:15.023918
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callbackModule = CallbackModule()
    assert type(callbackModule).__name__ == "CallbackModule"

# Generated at 2022-06-11 13:41:19.771527
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    display = callbacks.Display()
    c = CallbackModule()

    c.set_options(display=display,
                  errored_task=dict(
                      task=dict(name="Test with error")
                  )
    )

    assert display.display_messages[0] == 'Test with error | FAILED! => {}'



# Generated at 2022-06-11 13:41:29.633264
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Given
    class TestDisplayAnsi:
        def display(self, s, *args):
            print(s)
    class TestCallbackModule(CallbackModule):
        pass
    class TestResult:
        def __init__(self, expected_result):
            self._result = expected_result
            self._task = {'action': 'EXEC'}
        def get_name(self):
            return 'host1'
    class TestConstants:
        COLOR_ERROR = 'red'
    m = TestCallbackModule()
    m._display = TestDisplayAnsi()
    m.C = TestConstants()
    s = "unit-test"
    expected_result = {
        'msg': s,
    }
    r = TestResult(expected_result)
    # When
    m.v2_runner_on_

# Generated at 2022-06-11 13:41:37.843090
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    class TestClass1(CallbackModule):
        def __init__(self, test_dict):
            self.results = test_dict

        def v2_on_file_diff(self, result):
            if 'diff' in result._result and result._result['diff']:
                self.results['results'] = self._get_diff(result._result['diff'])

    class TestClass2(CallbackModule):
        def __init__(self, test_dict):
            self.results = test_dict

        def v2_on_file_diff(self, result):
            if 'diff' in result._result and result._result['diff']:
                self.results['results'] = self._get_diff(result._result['diff'])


# Generated at 2022-06-11 13:42:23.859738
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    from ansible.plugins.callback.minimal import CallbackModule
    from ansible.utils.display import Display
    # NOTE: The Display class is a stubbed version of Display from cli/cli.py
    class Display(Display):
        def __init__(self):
            Display.__init__(self, verbosity=3)

        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            return msg

    testobj = CallbackModule(Display())

    import unittest
    # Construct a dummy AnsibleResult object
    class AnsibleResult(object):
        def __init__(self):
            self._result = {'diff': 'A dummy diff'}

    # Test result._result['diff'] is not empty
    testresult = AnsibleResult()
   

# Generated at 2022-06-11 13:42:34.445313
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import json
    import sys

    # Set up the callback object
    cb = CallbackModule()

    # Class to mock the action object and provide extra properties
    class Action():
        def __init__(self):
            self.action = 'test'

    # Class to mock the host object and provide extra properties
    class Host():
        def __init__(self, hostname):
            self.name = hostname
            self.get_name = lambda: hostname

    # Class to mock the result object and provide extra properties
    class Result():
        def __init__(self, task, host, result):
            self._task = task
            self._host = host
            self._result = result

    # Class to mock the display object
    class Display():
        def __init__(self):
            self.output = ''


# Generated at 2022-06-11 13:42:46.603814
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import io

    # Create a io.StringIO object to hold the output results
    output = io.StringIO()
    output.write("""{ "changed": true, "rc": 0, "stderr": "", "stdout": "", "stdout_lines": [], "warnings": [{ "msg": "Using fallback", "version": "2.2" }] }""")
    output.seek(0)

    # Create a instance of CallbackModule
    cb = CallbackModule()
    cb.set_options(display=ouput)

    # Create a instance of Result to execute v2_runner_on_ok method
    res = Result()

# Generated at 2022-06-11 13:42:47.618542
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    c = CallbackModule()

# Generated at 2022-06-11 13:42:53.843596
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():

    # Setup
    cbmodule = CallbackModule()
    result = type(
        '',
        (object,),
        {'_result': {
            'diff': 'difference'
        }}
    )()

    # Exercise
    cbmodule.v2_on_file_diff(result)

    # Verify
    diff = cbmodule._get_diff(result._result['diff'])
    assert diff == 'difference'

# Generated at 2022-06-11 13:42:55.416089
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    """
    param: None
    return: instance of the CallbackModule class
    """
    callback = CallbackModule()
    return callback



# Generated at 2022-06-11 13:43:01.467581
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    class Options(object):
        """This is a dummy class used to mock the options of ansible"""
        module_path = './modules'
        forks = 5
        become = False
        become_method = 'sudo'
        become_user = ''
        check = False
        diff = False
        inventory = './inventory'
        remote_user = ''
        private_key_file = None
        listhosts = False
        listtasks = False
        listtags = False
        syntax = False
        module_lang = 'C'
        timeout = 10
        poll_interval = 15
        tmpdir = '/tmp'
        verbosity = 3
        extra_vars = []
        subset = None
        test_run = False

    class Host(object):
        """This class is used to mock the host object"""

# Generated at 2022-06-11 13:43:03.986775
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    obj = CallbackModule()
    assert isinstance(obj, CallbackModule)


# Generated at 2022-06-11 13:43:04.704088
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    global c
    c = CallbackModule()

test_CallbackModule()

# Generated at 2022-06-11 13:43:09.751942
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback = CallbackModule()
    result = {
            "_result": {
                "changed": False
                },
            "_task": {
                "action": "test_no_json"
                },
            "_host": {
                "get_name": lambda : "host"
                }
            }
    callback.v2_runner_on_ok(result)
    assert callback._display._output == ' host | SUCCESS => None\n'


# Generated at 2022-06-11 13:44:38.307409
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test the results
    callback = CallbackModule()
    result = result()
    result._result = {
        'failed': False,
        'changed': True
    }
    callback.v2_runner_on_failed(result)
    assert callback._display.display_called == 1
    assert callback._display.display_called_with == []

    callback._display.reset_mock()
    result._result = {
        'failed': True,
        'changed': False
    }
    callback.v2_runner_on_failed(result)
    assert callback._display.display_called == 1
    assert callback._display.display_called_with == []


# Generated at 2022-06-11 13:44:40.289618
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback = CallbackModule()
    callback.v2_runner_on_failed("A result")


if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-11 13:44:43.045373
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    module = CallbackModule()
    fake_host = FakeHost()
    fake_result = FakeResult()
    module.v2_runner_on_ok(fake_result)
    assert True


# Generated at 2022-06-11 13:44:51.564141
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-11 13:44:59.609594
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Run code of method to be tested
    test_module = CallbackModule()
    test_result = "Test result"
    test_result_changed = False
    test_result_action = "Test result action"
    test_result_display = "Test result display"
    # Create mock method to be used by tested method
    with patch.object(CallbackBase, '_dump_results') as mock_dump_results, patch.object(CallbackBase, '_display') as mock_display:
        mock_dump_results.return_value = test_result_display
        test_result_obj = MagicMock()
        test_result_obj.__dict__ = {"_result" : test_result, "_result.get" : test_result_changed,
                                    "_task" : MagicMock()}

# Generated at 2022-06-11 13:45:09.127967
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    # Arrange
    import unittest.mock as mock
    cb = CallbackModule()
    result = mock.MagicMock()

    # Act
    result._task.action = C.MODULE_NO_JSON
    result._result = {}
    cb._clean_results(result._result, result._task.action)
    result._result = {}
    cb.v2_runner_on_ok(result)
    result._result = {"changed": True}
    cb.v2_runner_on_ok(result)
    result._result = {"changed": False}
    cb.v2_runner_on_ok(result)
    result._result = {"ansible_job_id": "123"}
    cb.v2_runner_on_ok(result)

    # Assert
    result._

# Generated at 2022-06-11 13:45:11.028816
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    obj = CallbackModule()
    result = {'changed':True}
    obj.v2_runner_on_ok(result)

# Generated at 2022-06-11 13:45:22.432916
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    import sys
    from io import StringIO

    out = StringIO()
    sys.stdout = out

    callback = CallbackModule()
    callback.CALLBACK_TYPE = 'stdout'
    callback.CALLBACK_VERSION = 2.0
    callback.CALLBACK_NAME = 'test'
    callback._display.verbosity = 2

    # example of result

# Generated at 2022-06-11 13:45:32.119824
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    """
    Test if the v2_runner_on_failed is correctly handle
    """
    # Test 1 : Create a class that extend CallbackModule
    class TestClass(CallbackModule):
        pass
    
    # Test 2 : Create a object that extend TestClass
    test_callback = TestClass()

    # Test 3 : Test if the v2_runner_on_failed is correctly handle
    result = {'stdout': 'pip install OK!', 'stderr': '', 'msg': '', 'rc': 0}
    test_callback._command_generic_msg("test", result, "FAILED")
    result = {'stdout': 'pip install OK!', 'stderr': '', 'msg': '', 'rc': 1}
    test_callback._command_generic_msg("test", result, "FAILED")

# Generated at 2022-06-11 13:45:36.175926
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    result_data = {
        'diff': {
            'after': 'file_content',
            'before': 'file_content',
            'before_header': '',
            'after_header': ''
        },
        'changed': False
    }
    callback = CallbackModule()
    callback.v2_on_file_diff(result_data)