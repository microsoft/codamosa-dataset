

# Generated at 2022-06-11 13:36:57.252713
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    ca = CallbackModule()
    result = dict(changed=True)
    ca._clean_results(result)
    color, state, msg = ca._display.display(" |  => \n", color=C.COLOR_CHANGED)
    assert color == C.COLOR_CHANGED
    assert state == '\n'
    assert msg == '\n'


# Generated at 2022-06-11 13:37:08.852301
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.callback.minimal import CallbackModule
    from ansible import constants as C
    from ansible.plugins.callback.minimal import test_CallbackModule_v2_runner_on_ok as test
    callback = CallbackModule()

    result = CallbackBase.callback_plugin()
    result._task = type('', (), {'action': str()})()
    result._task.action = 'action'
    result._result = {'result': 'hello', 'changed': False}
    result._host = type('', (), {'get_name': str()})()
    result._host.get_name = lambda: 'hostname'


# Generated at 2022-06-11 13:37:17.318078
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    """
    CallbackModule.v2_on_file_diff() Test
    """

    expected = '-#!/bin/bash\n+#!/bin/bash\n # This script does the configuration of a node\n'

    result = {'diff':
                {'after': '/etc/ansible/hosts\n',
                 'before_header': 'Binary files /etc/ansible/hosts and /etc/ansible/hosts differ\n',
                 'before': '/etc/ansible/hosts\n',
                 'after_header': '--- /etc/ansible/hosts\n+++ /etc/ansible/hosts\n@@ -1,7 +1,7 @@\n'},
              'changed': True,
              'msg': 'file content changed'}

    bm = CallbackModule()


# Generated at 2022-06-11 13:37:21.201751
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result = "result"
    ignore_errors = False
    callback = CallbackModule()
    callback.v2_runner_on_failed(result, ignore_errors=False)


# Generated at 2022-06-11 13:37:31.239039
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import io
    import sys
    from ansible.utils.color import stringc

    display_io = io.StringIO()
    display = io.TextIOWrapper(display_io, encoding='utf-8')
    sys.stdout = display


# Generated at 2022-06-11 13:37:32.318442
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert isinstance(CallbackModule(), CallbackBase)

# Generated at 2022-06-11 13:37:33.352480
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    pass


# Generated at 2022-06-11 13:37:34.447196
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    x = CallbackModule()

# Generated at 2022-06-11 13:37:39.871948
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    host = "test_host"
    runner_result = RunnerResult(host)
    runner_result._result = {'rc': -1, 'stdout': "printout", 'stderr': 'printout', 'msg': "printout"}
    callback = CallbackModule()
    callback.v2_runner_on_failed(runner_result)


# Generated at 2022-06-11 13:37:42.949424
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    module = CallbackModule()
    assert module.CALLBACK_VERSION == 2.0
    assert module.CALLBACK_TYPE == 'stdout'
    assert module.CALLBACK_NAME == 'minimal'

# Generated at 2022-06-11 13:37:51.712452
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    def fake_get_diff(_):
        return '1c1\n< difference\n---\n> difference\n'

    import ansible.plugins.callback.minimal
    ansible.plugins.callback.minimal.CallbackModule._get_diff = fake_get_diff
    CallbackModule.v2_on_file_diff(None, None)


# Generated at 2022-06-11 13:37:59.447967
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.color import stringc
    # Create play result dictionary
    play_result = {
        '_ansible_parsed': True,
        '_ansible_no_log': False,
        'stats': {
            'skipped': {
                'web': 0
            },
            'failed': {
                'web': 0
            },
            'ok': {
                'web': 1
            },
            'changed': {
                'web': 0
            },
            'processed': {
                'web': 1
            },
            'unreachable': {
                'web': 0
            }
        },
        'changed': False
    }
    # Create task result dictionary

# Generated at 2022-06-11 13:38:01.584819
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # CallbackModule_v2_runner_on_failed() is tested in test_minimal_callback.py
    pass


# Generated at 2022-06-11 13:38:02.267573
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
   assert CallbackModule()

# Generated at 2022-06-11 13:38:08.434278
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    m = CallbackModule()
    class Result():
        def __init__(self):
            self._result = {'stdout': 'OK', 'stderr': ''}
    class Host():
        def get_name(self):
            return 'localhost'
    r = Result()
    r._host = Host()
    r._task = {'action': 'test'}
    m.v2_runner_on_ok(r)
    assert True

# Generated at 2022-06-11 13:38:16.050800
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # create an instance of the CallbackModule class
    test_module = CallbackModule(display=None)

    # create a test AnsibleResult
    test_result = "test text"
    test_action = "test action"
    test_result_class = TestResult(test_result,test_action)

    # call v2_runner_on_ok
    test_module.v2_runner_on_ok(test_result_class)

    # print out state and results
    test_module._display.display("passed", color=C.COLOR_OK)


# Generated at 2022-06-11 13:38:25.581678
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    call_back_obj = CallbackModule()
    result = {}
    result._result = {"diff": ["Hello World"], "_ansible_verbose_always": True, "results": ["Hello World"], "_ansible_no_log": False, "invocation": {"module_args": {"name": "Hello World", "password": "Hello World"}, "module_name": "Hello World"}, "_ansible_parsed": True, "_ansible_module_name": "Hello World", "_ansible_module_setup": True, "changed": True, "_ansible_no_log_values": ["Hello World"], "item": "Hello World", "_ansible_module_name": "Hello World", "_ansible_module_setup": True}
    call_back_obj._handle_warnings(result._result)
    call_back_obj.v2_runner_

# Generated at 2022-06-11 13:38:26.148383
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    pass

# Generated at 2022-06-11 13:38:29.744221
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    '''
    This function will perform unit test for constructor of
    class CallbackModule defined in callback_minimal.py
    '''
    empty_class = CallbackModule()
    assert isinstance(empty_class, CallbackBase)

# Generated at 2022-06-11 13:38:39.526827
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    cm = CallbackModule()
    result = { "msg": "n/a",
               "invocation": { "module_args": "n/a" },
               "diff": { "before": "n/a",
                         "after": "n/a" }
             }

    a_diff_string = """diff --git a/file/one b/file/one
index 0a1a4c4..3a6a4ad 100644
--- a/file/one
+++ b/file/one
@@ -1,2 +1,2 @@
-old line
-
+new line
+"""
    assert cm.v2_on_file_diff(result) == a_diff_string


# Generated at 2022-06-11 13:38:51.256130
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    '''
    Test to see if the method v2_runner_on_failed of class CallbackModule
    runs without error and returns expected result
    '''
    module = CallbackModule()
    result = {'_result': {}}
    module.v2_runner_on_failed(result)

# Generated at 2022-06-11 13:39:01.982891
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    mod = CallbackModule()
    mod._handle_warnings = lambda x: None
    mod._clean_results = lambda x,y: None
    mod._display = TestDisplay()
    mod._dump_results = lambda x, indent=4: json.dumps(x)


    # Test action in C.MODULE_NO_JSON
    mod.v2_runner_on_ok(Result(Task(action="some_action"), Host("sample_host"), {'changed': True, 'ansible_facts': {'some_fact': 'some value'}}))
    assert mod._display.status == "sample_host | CHANGED => {\"ansible_facts\": {\"some_fact\": \"some value\"}}"
    assert mod._display.color == C.COLOR_CHANGED


# Generated at 2022-06-11 13:39:06.334010
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import json
    result_dict = json.loads("""{'rc': 0, 'stderr': '', 'stdout': '', 'stdout_lines': []}""")
    result = MinimalRunnerResult("test_host", "test_action", result_dict, changed=True)
    callback = CallbackModule()
    callback.v2_runner_on_ok(result)


# Generated at 2022-06-11 13:39:15.799875
# Unit test for method v2_on_file_diff of class CallbackModule

# Generated at 2022-06-11 13:39:22.899811
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import ansible.plugins.callback.minimal
    import ansible.vars.hostvars

    result = ansible.vars.hostvars.HostVars(host_specific_var_results=['diff'])
    result._result = {'diff': 'Hello'}

    cb = ansible.plugins.callback.minimal.CallbackModule()
    assert cb.v2_on_file_diff(result) == "Hello"
    assert cb.v2_on_file_diff(result) != "World"

# Generated at 2022-06-11 13:39:32.141431
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import sys
    import os
    import json
    import re
    result = type('result', (), {})()
    result._result = {u'changed': False, u'invocation': {u'module_args': u'', u'module_name': u'command'}, u'rc': 0, u'stderr': u'', u'stdout': u'', u'warnings': []}
    result._task = type('task', (), {})()
    result._task.action = u'command'
    result._host = type('host', (), {})()
    result._host.get_name = lambda: u'localhost'
    callback = CallbackModule()
    callback._dump_results = lambda res, indent: '[dump_results]'
    callback._clean_results = lambda res, action: '[clean_results]'


# Generated at 2022-06-11 13:39:42.573606
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    testresult = dict()
    testresult['diff'] = dict()
    testresult['diff']['before'] = 'before'
    testresult['diff']['after'] = 'after'
    testresult['diff']['before_header'] = 'before_header'
    testresult['diff']['after_header'] = 'after_header'

    testresultclass = type("result",(object,),{})
    testcallbackclass = CallbackModule("minimal")
    testresultclass._result = testresult
    testresultclass._task = type("task",(object,),{})
    testresultclass._host = type("host",(object,),{})
    testresultclass._host.get_name = lambda: "host_name"
    testresultclass.task_fieldname = "any_task_fieldname"
   

# Generated at 2022-06-11 13:39:43.165875
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    assert 0 == 0

# Generated at 2022-06-11 13:39:49.616746
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    """
    Unit test for method v2_on_file_diff of class CallbackModule
    """

    CallBackModule = CallbackModule()

    result = []

    # check with diff = true
    result._result = {'diff':True}
    CallBackModule.v2_on_file_diff(result)

    # check with diff = False
    result._result = {'diff':False}
    CallBackModule.v2_on_file_diff(result)

# Generated at 2022-06-11 13:39:55.357557
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Example of test case
    result = 'example'
    ignore_errors = False
    cm = CallbackModule()
    assert cm.v2_runner_on_failed(result, ignore_errors) == 1
    # Example of test case
    result = 'example'
    ignore_errors = False
    cm = CallbackModule()
    assert cm.v2_runner_on_failed(result, ignore_errors) == 1


# Generated at 2022-06-11 13:40:18.853173
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback = CallbackModule()

    task = FakeTask()
    task.action = 'ping'
    task.name = 'ping'
    task.args = {'_ansible_no_log': False, 'action': 'ping', '_ansible_verbose_always': True, '_ansible_version': 2,
                 '_ansible_no_log_warn': False, '_ansible_debug': False, 'msg': 'Test msg'}
    task.args_keys = ['msg', '_ansible_debug', '_ansible_version', '_ansible_no_log_warn', '_ansible_verbose_always',
                      '_ansible_no_log', 'action']

    host = FakeHost(name='127.0.0.1')

# Generated at 2022-06-11 13:40:19.914538
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    obj = CallbackModule()
    assert type(obj) == CallbackModule

# Generated at 2022-06-11 13:40:30.975361
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import ansible.plugins.callback as callback
    class MyDisplay:
        def __init__(self):
            self.string = ''
        def display(self, msg, color=None, stderr=None, screen_only=None, log_only=None):
            self.string += msg
    fake_display = MyDisplay()
    basic = callback.CallbackModule(display=fake_display)
    class MyResult:
        def __init__(self):
            self.changed = "True"
            self.msg = ""
            self.failed = "True"
            self.stderr = ""
            self.stdout = ""
    class MyHost:
        def get_name(self):
            return "test_host"

# Generated at 2022-06-11 13:40:40.777213
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    """ Method v2_on_file_diff of class CallbackModule """
    
    # Create instance of class CallbackModule
    callbackModule = CallbackModule()

    # Create instance of class Result
    result = Result()

    # isinstance(obj, class)
    if isinstance(result, Result):

        # Count the number of instance variables of the class Result
        numberOfInstanceVariables = 0

        # Object.__dict__ contains the instance variables of the class
        for key in result.__dict__.keys():
            numberOfInstanceVariables += 1

        # Output of number of instance variables of the class Result
        print("numberOfInstanceVariables: {}".format(numberOfInstanceVariables))

        # Assert that numberOfInstanceVariables is not equal to 0
        assert numberOfInstanceVariables != 0

        # Assign value to the instance

# Generated at 2022-06-11 13:40:42.978337
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule().CALLBACK_TYPE == 'stdout'
    assert CallbackModule().CALLBACK_NAME == 'minimal'

# Generated at 2022-06-11 13:40:51.637285
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result = 'Pytest result'

    class TestCallbackModule:

        def __init__(self):
            self.display_result = ""

        def _handle_exception(self, result):
            pass

        def _handle_warnings(self, result):
            pass

        def _display(self, result, color):
            self.display_result = result

        def _command_generic_msg(self, host, result, caption):
            return ""

    testmodule = TestCallbackModule()
    cb = CallbackModule(display=testmodule)

    cb.v2_runner_on_failed(result=result)

    assert "FAILED! => " in testmodule.display_result


# Generated at 2022-06-11 13:41:02.191935
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # The input parameters (result)
    hostname = 'hostname'
    action = 'action'
    changed = 'changed'
    task_id = 'task_id'
    full_parsed = 'full_parsed'
    diff = 'diff'
    private = 'private'
    default_vars = 'default_vars'


# Generated at 2022-06-11 13:41:11.414860
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    gen_lines = lambda result:{'diff':result}
    gen_results = lambda diff,changed,msg='':{'changed':changed,'msg':msg,'diff':diff}
    display = lambda u: u

    # Case: no diff
    test_result = _CallbackModule_v2_on_file_diff_private(CallbackModule(), None, pfdisplay=display)
    assert test_result is None

    # Case: diff
    test_result = _CallbackModule_v2_on_file_diff_private(CallbackModule(), gen_lines(gen_results(['line1', 'line2'], True)), pfdisplay=display)
    assert test_result == ['line1', 'line2']

    # Case: no changed

# Generated at 2022-06-11 13:41:14.436842
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    c = CallbackModule()
    assert(c.CALLBACK_TYPE == 'stdout')
    assert(c.CALLBACK_NAME == 'minimal')

# Generated at 2022-06-11 13:41:16.584836
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    instance = CallbackModule()
    print(instance)

# Unit test code
if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-11 13:41:56.933092
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import mock

    callback_module = CallbackModule()

    class DumpResultsMock(mock.Mock):
        def __init__(self):
            self.indent = 4
            self.result = self.get_result()
            super(DumpResultsMock, self).__init__(return_value=self)

        def get_result(self):
            return {'changed': False}

        def __call__(self, *args, **kwargs):
            if args[0] == self.result:
                return 'ansible.plugins.callback.minimal::SUCCESS => ' + \
                       '{' + \
                       '\n' + ' ' * self.indent + '"changed": false' + \
                       '\n' + ' ' * (self.indent - 4) + '}'


# Generated at 2022-06-11 13:42:05.739997
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    cb = CallbackModule()
    result = {'skipped': False, 'changed': False, 'failed': True, 
        'unreachable': False, 'rc': 0, 'stdout': '', 'module_stdout': '', 
        'warnings': [], 'stdout_lines': [], 'module_stdout_lines': [], 
        'stderr': '', 'module_stderr': '', 'stderr_lines': [], 'module_stderr_lines': [], 
        'msg': '', 'invocation': {'module_name': 'shell', 'module_args': {'creates': '/tmp/f', 'removes': '/tmp/f', 'executable': None}}}
    result._host = {'get_name': lambda: 'localhost'}

# Generated at 2022-06-11 13:42:12.561182
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    module = CallbackModule()
    p = {'invocation': {'module_args': 'arguments'}}
    m = "module"
    res = {
        'failed': True,
        'module_stderr': 'There was an error executing this module',
        'module_stdout': 'More detailed message about the module results',
        'msg': 'There was an error executing this module',
        'rc': 1
    }
    result = {'_result': res, '_task': p, '_host': m, '_task.action': 'debug'}

# Generated at 2022-06-11 13:42:20.819306
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.utils.color import stringc
    from ansible.plugins.callback import CallbackBase

    class FakeHost:
        ''' Fake Host '''
        def __init__(self, host_name):
            self.name = host_name

        def get_name(self):
            return self.name

    class FakeTask:
        ''' Fake Runner '''
        def __init__(self, action):
            self.action = action

    class FakeResult(dict):
        ''' Fake Result '''
        def __init__(self, host, re, task):
            self.host = host
            super(FakeResult, self).__init__(**re)
            self._task = task

    class FakeDisplay:
        ''' Fake Display '''

# Generated at 2022-06-11 13:42:32.089041
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import sys
    import tempfile
    import ansible.plugins.callback.minimal as minimal
    import ansible.plugins.callback.minimal as module

    # create a tempfile
    temp_dir = tempfile.gettempdir()
    _, temp_file = tempfile.mkstemp(dir=temp_dir)

    # create a file to save the output for the unit test
    try:
        sys.stdout
    except AttributeError:
        sys.stdout = open(temp_file, 'w')


# Generated at 2022-06-11 13:42:39.263254
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    from ansible.plugins.callback import CallbackBase

    class TestClass(object):
        """ test class """

    test_instance = TestClass()
    test_instance.display = TestClass()
    test_instance.display.display = TestClass()
    
    def get_diff(arg):
        """ test function """

    test_instance.get_diff = get_diff

    result = TestClass()
    result.diff = ''
    result.diff = 'test diff'

    results = {'failed': False, 'changed': False, 'diff': []}
    results['diff'] = result.diff

    result._result = results

    test_callback_module = CallbackModule(display=test_instance)
    test_callback_module.v2_on_file_diff(result)

    results['changed'] = True
    result._

# Generated at 2022-06-11 13:42:40.348907
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    test_class = CallbackModule()

# Generated at 2022-06-11 13:42:51.845478
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible import context
    from ansible.plugins.loader import callback_loader
    from ansible.playbook.task import Task
    from ansible.plugins.callback import _get_redirected_stdout

    callback = callback_loader.get('minimal')
    context._init_global_context(run_once=True)
    task = Task()
    task.action = 'shell'
    host = {'name': 'localhost', 'ipv4': '127.0.0.1'}

# Generated at 2022-06-11 13:42:57.893927
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    '''
    This tests the v2_runner_on_failed method of the CallbackModule class
    '''
    test_obj = CallbackModule()
    test_host = MockHost()

    class MockResult:
        def __init__(self):
            self._host = test_host
            self._task = MockTask()
            self._result = {'changed':True}

    test_result = MockResult()

    test_obj.v2_runner_on_failed(test_result, ignore_errors=False)


# Generated at 2022-06-11 13:42:58.885806
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-11 13:44:20.025847
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    '''
    v2_on_file_diff is a public method of CallbackModule
    '''
    callback = CallbackModule()
    callback.v2_on_file_diff({'diff': 'text'})

# Generated at 2022-06-11 13:44:28.601969
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    testObj = CallbackModule()

    # mock result
    result = {

        # task
        "_task": {
            'action': 'setup'
        },

        # host
        "_host": {
            'get_name': lambda: '1.1.1.1'
        },

        # result
        "_result": {
            'rc': 0,
            'stdout': '',
            'stderr': '',
            'msg': ''

        }
    }

    # call method
    actual = testObj.v2_runner_on_failed(result)

    # check results
    expected = "1.1.1.1 | FAILED! => {\n\n}\n"

    print('Actual:   {}'.format(actual))
    print('Expected: {}'.format(expected))


# Generated at 2022-06-11 13:44:31.079957
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    x = CallbackModule()
    assert isinstance(x, CallbackModule)

# Unit test of _command_generic_msg():
#   If we have a generic message, it gets displayed on the command line

# Generated at 2022-06-11 13:44:36.424654
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Instantiate object
    obj = CallbackModule()
    # Get fake result
    class FakeResult(object):
        def __init__(self):
            self._result = {}
        def __getitem__(self, key):
            return self._result[key]
        def __setitem__(self, key, value):
            self._result[key] = value
    result = FakeResult()
    # Add diff
    result['diff'] = dict(before='foo', after='bar')
    # Call method
    obj.v2_on_file_diff(result)

# Generated at 2022-06-11 13:44:41.540283
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    class AnsibleResult:
        def __init__(self,host, result, caption):
            self._host = host
            self._result = result
            self._task = caption

    class AnsibleHost:
        def get_name(self):
            return "testhost"

    class Display:
        def display(self, message, color='C.COLOR_OK'):
            return message

    task_result = AnsibleResult('testhost',{'test':'value'},'Test_task')
    display = Display()
    callback = CallbackModule()
    expected_results = 'testhost | FAILED! => {\n    "test": "value"\n}\n'

# Generated at 2022-06-11 13:44:50.000033
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    # Test variable
    t = {'changed': True, 'msg': 'message', 'stdout': 'test message for stdout', 'stderr': 'test message for stderr'}

    # Test object
    r = MockRunner()
    h = MockHost()
    r.host = h
    r.result = t

    # Test output
    cm = CallbackModule()
    cm.v2_runner_on_ok(r)

    # Test assertion
    assert cm._display.display.call_count == 1
    call_args, call_kwargs = cm._display.display.call_args

# Generated at 2022-06-11 13:44:54.199586
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import io
    try:
        from unittest.mock import patch, call
    except ImportError:
        from mock import patch, call

    module = CallbackModule()
    result = type('Result', (object,), {"_result": {'diff': 'difference'}})()
    module.v2_on_file_diff(result)

    mock = patch.object(module._display, 'display')
    mock.assert_called_once_with(module._get_diff('difference'))


# Generated at 2022-06-11 13:44:54.697207
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    assert True

# Generated at 2022-06-11 13:44:56.135179
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback = CallbackModule()
    assert callback != None
    assert isinstance(callback,CallbackModule)

# Generated at 2022-06-11 13:45:05.497537
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    test_module_name = "test_module"
    test_host_name = "test_host"
    test_task_name = "test_task"
    test_result = {}
    
    import ansible.plugins.callback.minimal
    callback = ansible.plugins.callback.minimal.CallbackModule()
    import ansible.playbook.task
    test_task = ansible.playbook.task.Task()
    test_task.action = test_module_name
    import ansible.inventory.host
    test_host = ansible.inventory.host.Host(test_host_name)
    import ansible.executor.task_result
    import ansible.constants
    test_task_result = ansible.executor.task_result.TaskResult(test_host, test_result, test_task)

