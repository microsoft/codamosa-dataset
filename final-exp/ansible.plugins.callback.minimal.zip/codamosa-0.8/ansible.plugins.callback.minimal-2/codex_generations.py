

# Generated at 2022-06-11 13:36:52.326176
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    pass


# Generated at 2022-06-11 13:36:56.027608
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    result = {}
    result['diff'] = 'This is a diff'
    result_object = type('obj', (object,), result)
    cb = CallbackModule()
    cb.v2_on_file_diff(result_object)
    assert cb == cb

# Generated at 2022-06-11 13:37:04.753479
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    module_under_test = CallbackModule()
    mock_result = MockResult()
    mock_result._task = MockTask()
    module_under_test.display = MockDisplay()
    module_under_test._dump_results = MockDumpResults()
    module_under_test._handle_warnings = MockHandleWarnings()
    module_under_test.v2_runner_on_failed(mock_result)
    assert module_under_test.display.actual() == "host | FAILED! => msg", "Test expected behaviour for v2_runner_on_failed"


# Generated at 2022-06-11 13:37:13.238020
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    """Test callback plugins/minimal.py v2_on_file_diff method"""
    # Prepare test data
    result_dic = dict(
        _result=dict(
            diff='@@ -1,6 +1,6 @@\n-# BEGIN ANSIBLE MANAGED BLOCK\n # END ANSIBLE MANAGED BLOCK\n+# BEGIN ANSIBLE MANAGED BLOCK\n # END ANSIBLE MANAGED BLOCK\n ##\n'
        )
    )

    # Run test
    test_obj = CallbackModule()
    test_obj.v2_on_file_diff(result_dic)

# Generated at 2022-06-11 13:37:16.768097
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    import ansible.plugins.callback

    # Create object test_instance
    test_instance = ansible.plugins.callback.CallbackModule()

    # Create object test_instance_1
    test_instance_1 = ansible.plugins.callback.CallbackModule()

    # Assert
    assert test_instance is not None
    assert test_instance_1 is not None

# Generated at 2022-06-11 13:37:17.646768
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback = CallbackModule()

# Generated at 2022-06-11 13:37:24.254789
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback.minimal import CallbackModule

    display = Print()
    callback = CallbackModule(display)

    result = FakeResult()
    result._host = FakeHost(name='')

    display.reset()
    callback.v2_runner_on_ok(result)
    assert display.get_text() == " | SUCCESS => {}\n"


# Generated at 2022-06-11 13:37:28.847841
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Input for test
    result = dict()
    result['changed'] = False

    # Expected output
    buf = "(localhost) | SUCCESS => {}\n"

    # Test
    callback = CallbackModule()
    output = callback.v2_runner_on_ok(result)

    # Check
    assert(output == buf)



# Generated at 2022-06-11 13:37:39.872134
# Unit test for method v2_runner_on_ok of class CallbackModule

# Generated at 2022-06-11 13:37:46.659124
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Arrange
    callback = CallbackModule()
    test_result = "Test result"
    class result_object:
        def __init__(self):
            self._result = test_result
            self._task = "test_task"
        def get_name(self):
            return "test host"
    # Act
    callback.v2_runner_on_ok(result_object())
    # Assert
    assert test_result == callback._dump_results(test_result)


# Generated at 2022-06-11 13:37:57.574310
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Dummy results
    result = {
        '_host': {
            'get_name': lambda: 'Dummy host',
        },
        '_result': {
            'stdout': 'Some output',
        },
        '_task': {
            'action': 'Some action',
        },
    }

    # Instantiate a mock display object
    class MockDisplay:
        color = ''
        display_msg = ''
        def display(self, msg, color):
            self.color = color
            self.display_msg = msg

    display = MockDisplay()

    # Instantiate a callback
    callback = CallbackModule()

    # Configure the callback display
    callback._display = display

    # Run callback
    callback.v2_runner_on_ok(result)

    # Check that the display is OK

# Generated at 2022-06-11 13:38:08.225322
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import json
    import logging
    import pprint

    logging.basicConfig(level=logging.DEBUG)

    # configure the display to not show anything
    display_obj = logging.getLogger('ansible.parsing.yaml.objects')
    display_obj.setLevel(logging.CRITICAL)

    # instantiate the callback module
    callback_module = CallbackModule()
    callback_module.set_options(verbosity=logging.INFO)

    # create a result object
    fake_host = {'hostname': 'localhost'}
    result_obj = {
        '_host': fake_host,
        '_task': {'action': 'fakeaction'},
        '_result': {'changed': False},
    }

    # run the callback
    callback_module.v2_runner_on

# Generated at 2022-06-11 13:38:12.332889
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Initialization of a CallbackModule
    c = CallbackModule()

    # Tests
    assert(c.CALLBACK_VERSION == 2.0)
    assert(c.CALLBACK_TYPE == 'stdout')
    assert(c.CALLBACK_NAME == 'minimal')

# Generated at 2022-06-11 13:38:15.723197
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    test_obj = CallbackModule()
    res = {'diff': "Unified diff of the file changes."}
    assert(test_obj.v2_on_file_diff(res) == "Unified diff of the file changes.")

# Generated at 2022-06-11 13:38:25.027234
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import sys
    sys.path.append("../../")

    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.plugins.callback.minimal import CallbackModule
    from ansible.utils.color import stringc

    log_output = []
    def display(msg, color=None, stderr=False, screen_only=False, log_only=False):
        if color:
            log_output.append(color(msg))
        else:
            log_output.append(msg)

    class fake_v2_playbook_on_play_start(object):
        def __init__(self, playbook):
            self.playbook = playbook
        def __getattr__(self, name):
            return getattr(self.playbook, name)


# Generated at 2022-06-11 13:38:36.071587
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import sys
    from collections import namedtuple

    from ansible.plugins.callback import CallbackBase

    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group


# Generated at 2022-06-11 13:38:44.200858
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.playbook.task import Task
    from ansible.utils.display import Display
    from ansible.plugins.callback.minimal import CallbackModule
    import sys
    import os
    import json

    sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))
    sys.path.append(os.path.join(os.path.dirname(__file__), '../../..'))

    display = Display()

    cb = CallbackModule(display)
    cb._display = display
    task = Task()
    task.action = 'shell'


# Generated at 2022-06-11 13:38:55.289068
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    custom_options = {'verbosity': 1, 'inventory': 'hosts', 'listhost': '', 'subset': '', 'module_path': '', 'extra_vars': ['daemon=1'], 'forks': 2, 'ask_pass': '', 'private_key_file': '', 'ssh_common_args': '', 'ssh_extra_args': '', 'sftp_extra_args': '', 'scp_extra_args': '', 'become': '', 'become_method': '', 'become_user': '', 'become_ask_pass': '', 'ask_value_pass': '', 'verbosity': 4, 'check': '', 'listhost': '', 'listtasks': '', 'listtags': '', 'syntax': '', 'diff': ''}
    custom_args

# Generated at 2022-06-11 13:39:04.801630
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Create a mock object to replace 'ansible.plugins.callback.CallbackBase'
    class CallbackModuleMock(object):
        def __init__(self):
            self.color = False

        @staticmethod
        def display(msg, color=None, stderr=False, screen_only=False, log_only=False):
            pass

    # Create a mock object to replace 'ansible.plugins.callback.CallbackBase._get_diff'
    def _get_diff_mock(self, diff):
        return ''

    CallbackBase._get_diff = _get_diff_mock

    result_dict = {'diff': 'dummy'}
    result = type('obj', (object,), {'_result': result_dict})

    # Create a CallbackModule object
    c = CallbackModule()

    #

# Generated at 2022-06-11 13:39:11.158138
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    class Result:
        def __init__(self, host, result, task):
            self._host = host
            self._result = result
            self._task = task

    class Host:
        def get_name(self):
            return 'testHost'

    host = Host()
    task = 'testTask'
    result = Result(host, {'changed': True}, task)
    callbackModule = CallbackModule()
    callbackModule._display.display = lambda msg, color: print(msg)

    callbackModule.v2_runner_on_ok(result)


# Generated at 2022-06-11 13:39:28.603473
# Unit test for constructor of class CallbackModule
def test_CallbackModule():

    # instantiate callback object
    cb = CallbackModule()

    # test display variable
    assert hasattr(cb, '_display') # _display variable

    # test version variable
    assert hasattr(cb, 'CALLBACK_VERSION') # CALLBACK_VERSION variable
    assert isinstance(cb.CALLBACK_VERSION, float) # CALLBACK_VERSION is float

    # test type variable
    assert hasattr(cb, 'CALLBACK_TYPE') # CALLBACK_TYPE variable
    assert isinstance(cb.CALLBACK_TYPE, str) # CALLBACK_TYPE is str

    # test name variable
    assert hasattr(cb, 'CALLBACK_NAME') # CALLBACK_NAME variable
    assert isinstance(cb.CALLBACK_NAME, str) # CALLBACK_NAME is str

    # test v2_runner_on_failed

# Generated at 2022-06-11 13:39:31.488273
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test with changed=False
    cm = CallbackModule()
    host = FakeHost()
    result = FakeResult(changed=False)
    cm.v2_runner_on_ok(result)


# Generated at 2022-06-11 13:39:41.866211
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
  # Initialize test environment.
  from ansible.plugins.callback import CallbackBase
  from ansible import constants as C
  def get_task():
    # Create task object
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    # Initialize task object
    options = dict()
    options['connection'] = 'ssh'
    options['module_path'] = None
    options['forks'] = 5
    options['become'] = True
    options['become_method'] = 'sudo'
    options['become_user'] = None
    options['check'] = False

# Generated at 2022-06-11 13:39:47.632228
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test the function without fake results
    callback = CallbackModule()
    result = ("%s | SUCCESS => aaaaa\n" % ('host1'))
    assert callback.v2_runner_on_ok(result) == result
    # Test the function with fake results
    result = "host2 | SUCCESS => bbbbb"
    assert callback.v2_runner_on_ok(result) == result


# Generated at 2022-06-11 13:39:57.681867
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    import json
    import re


# Generated at 2022-06-11 13:40:07.588436
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # define a test host list
    test_hosts = ['test_host']
    # setup a fake display object
    class FakeDisplay(object):
        def display(self, result, color=C.COLOR_OK):
            self.display = result
        def get_color(self, result):
            return C.COLOR_OK
    # setup a fake result object
    result = {}
    result['_result'] = {'changed': False}
    result['_result']['msg'] = 'This is a result message.'
    result['_task'] = {'action': 'test_action'}
    result['_host'] = {'get_name': 'test_host'}
    # run the v2_runner_on_ok method
    cb = CallbackModule()
    cb._display = FakeDisplay()
    cb

# Generated at 2022-06-11 13:40:17.457635
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    """
    # Class CallbackModule, method v2_runner_on_failed
    """
    import json
    import unittest
    from unittest.mock import patch, MagicMock

    class TestCallbackModule(unittest.TestCase):

        def setUp(self):
            self.mock_display = MagicMock()
            self.callback = CallbackModule()
            self.callback._display = self.mock_display

        def tearDown(self):
            del self.callback

        def test_no_json(self):
            r = MagicMock()
            h = MagicMock()
            h.get_name.return_value = "localhost"
            r._host = h

# Generated at 2022-06-11 13:40:18.014585
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    assert True == True

# Generated at 2022-06-11 13:40:20.313229
# Unit test for method v2_runner_on_ok of class CallbackModule

# Generated at 2022-06-11 13:40:30.430292
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    """
    unit test for constructor of class CallbackModule
    """

    import sys
    from ansible.plugins.callback.minimal import CallbackModule

    if sys.version_info[0] >= 3:
        assert issubclass(CallbackModule, object)

    cb = CallbackModule()

    assert hasattr(cb, '_command_generic_msg')
    assert hasattr(cb, 'v2_runner_on_failed')
    assert hasattr(cb, 'v2_runner_on_ok')
    assert hasattr(cb, 'v2_runner_on_skipped')
    assert hasattr(cb, 'v2_runner_on_unreachable')
    assert hasattr(cb, 'v2_on_file_diff')

# Generated at 2022-06-11 13:40:53.437464
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    """
    Tests Ansible callback plugin method v2_on_file_diff of class CallbackModule
    This is called with the results of a file diff when using --diff.
    """

    # assert that using this module does not crash
    ans_module = CallbackModule()
    for i in range(1, 5):
        test_file_diff = {'before_header': '', 'before': '', 'after_header': '', 'after': '', 'before_footer': '', 'after_footer': ''}
        test_file_diff['before'] = "Test string number" + str(i)
        test_file_diff['after'] = "Test string number" + str(i)
        ans_module.v2_on_file_diff(test_file_diff)



# Generated at 2022-06-11 13:41:04.070595
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # create an instance of 'CallbackModule' class
    obj = CallbackModule()
    # check if 'CallbackModule' class is a subclass of 'CallbackBase' class
    assert issubclass(CallbackModule, CallbackBase)
    # check if 'obj' instance of 'CallbackModule' class is an instance of superclass 'CallbackBase'
    assert isinstance(obj, CallbackBase)
    # check if value of CALLBACK_TYPE from superclass is assigned to 'CALLBACK_TYPE' variable in subclass
    assert CallbackModule.CALLBACK_TYPE == CallbackBase.CALLBACK_TYPE
    # check if value of CALLBACK_NAME from superclass is assigned to 'CALLBACK_NAME' variable in subclass
    assert CallbackModule.CALLBACK_NAME == CallbackBase.CALLBACK_NAME
    # check if value of CALLBACK_VERSION from

# Generated at 2022-06-11 13:41:12.485216
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    mock_result = FakeResult()
    mock_result._task.action = 'command'
    mock_result._host.get_name.return_value = 'testhost1'
    mock_result._result = {'rc': 4, 'stdout': '', 'stderr': '', 'msg': '', 'changed': True}

    callback = CallbackModule()

    callback.v2_runner_on_failed(mock_result, ignore_errors=False)

    assert(callback._display.display.call_count == 1)
    ((message, color), kwargs) = callback._display.display.call_args

# Generated at 2022-06-11 13:41:23.147410
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import sys
    import os
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    sys.stdout = open(os.devnull, 'w')
    sys.stderr = open(os.devnull, 'w')

# Generated at 2022-06-11 13:41:25.025450
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    assert CallbackModule.v2_runner_on_failed('result') == None


# Generated at 2022-06-11 13:41:30.823598
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    task_result = Mock()
    host = Mock()
    host.get_name.return_value = 'hostname'
    result = Mock()
    result.get.return_value = True

    task_result._result = result
    task_result._task.action = 'copy'
    task_result._host = host

    callback_module = CallbackModule()
    callback_module.v2_runner_on_ok(task_result)
    assert result.get.called 



# Generated at 2022-06-11 13:41:38.172013
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Given a CallbackModule object
    obj = CallbackModule()

    # When: 
    #    result._result contains a key named diff
    #    result._result['diff'] is False
    #    _get_diff(result._result['diff']) is "" when passed to display.display
    class result:
        class _result:
            diff = False
        _result = _result()
    obj._display = MockDisplay()
    obj._get_diff = MagicMock(return_value="")
    obj.v2_on_file_diff(result)

    # Then:
    #    assert that _display.display is called once
    assert obj._display.display.call_count == 1


# Generated at 2022-06-11 13:41:40.469609
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    result = FakeResult()
    result._result = {'diff': 'AAAAAAAAAAAAAAAAAAAAAAAA'}
    CallbackModule.v2_on_file_diff(result)

# Test class

# Generated at 2022-06-11 13:41:46.422825
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    """
    constructor test
    """
    callback = CallbackModule()

    data = {}
    data['invocation'] = dict(module_args=dict(key='value', key1='value'))

    assert callback.vars == dict()
    assert callback.options is None
    assert callback.playbook is None
    assert callback.dir_name is None
    assert callback._dump_results(data) != ''
    assert callback._dump_results(data) == "{u'invocation': {u'module_args': {u'key1': u'value', u'key': u'value'}}}"

# Generated at 2022-06-11 13:41:48.682868
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
  print('XXXXXXXXXXXXXXXXXXXXXXXX')
  print(CallbackModule)
  print('XXXXXXXXXXXXXXXXXXXXXXXX')
  assert CallbackModule()



# Generated at 2022-06-11 13:42:23.904624
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-11 13:42:34.486129
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.action.normal import ActionModule as _ActionModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    host = 'localhost'
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/dev/null'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-11 13:42:39.798135
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
	result = {'stdout': '', 'stderr': '', 'msg': 'failed to login'}
	assert CallbackModule()._command_generic_msg("test", result, "FAILED") == "test | FAILED | rc=-1 >>\nfailed to login\n\n"


# Generated at 2022-06-11 13:42:44.720859
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import callback_minimal
    import sys
    import io

    # init the callback module
    sys.stdout = io.StringIO()
    callback = callback_minimal.CallbackModule()
    result = callback.v2_runner_on_failed(None)
    assert sys.stdout.getvalue() == None

# Generated at 2022-06-11 13:42:55.616731
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback = CallbackModule()

# Generated at 2022-06-11 13:42:58.105550
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback = CallbackModule()
    assert (not callback == None) and isinstance(callback, CallbackModule)

if __name__ == '__main__':
    test_CallbackModule()
    print('CallbackModule is Good')

# Generated at 2022-06-11 13:43:06.992272
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Declare variable for class CallbackModule
    callbackModule = CallbackModule()

    # Declare variable for this test
    result = 'ok'
    color = C.COLOR_OK
    output = 'output'

    # Mock method v2_runner_on_ok of class CallbackModule
    class Mock(object):

        def display(self, result, color=''):
            pass

    mockObj = Mock()
    callbackModule._display = mockObj
    callbackModule._dump_results = lambda output: output

    expected = 'output'

    actual = callbackModule.v2_runner_on_ok(result)

    assert expected == actual

# Generated at 2022-06-11 13:43:14.669616
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Tests for "success" actions
    for action in ['command', 'shell', 'setup']:
        result = FakeResult(action)
        result._result['stdout'] = 'all ok'
        c = CallbackModule()
        c.v2_runner_on_ok(result)
        assert c._display.display.call_count == 1
        assert c._display.display.call_args[0][0] == 'all ok'
    # Tests for "changed" actions.
    for action in ['copy', 'template', 'file', 'synchronize']:
        result = FakeResult(action)
        result._result['changed'] = True
        c = CallbackModule()
        c.v2_runner_on_ok(result)
        assert c._display.display.call_count == 1
        assert c._display.display

# Generated at 2022-06-11 13:43:15.624266
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    obj = CallbackModule()

# Generated at 2022-06-11 13:43:25.637734
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import json
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    display = Display()

# Generated at 2022-06-11 13:44:49.500110
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule().CALLBACK_VERSION == 2.0

# Generated at 2022-06-11 13:44:51.804658
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result = {'failed': True}
    callback = CallbackModule()
    display = 'failed | FAILED! => {'
    assert callback.v2_runner_on_failed(result) == display


# Generated at 2022-06-11 13:44:54.673284
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    module = CallbackModule()

    res = {
            "_ansible_parsed": True,
            "changed": True,
            "diff": {
                "after": "",
                "before": "",
                "before_header": "FILE1",
                "after_header": "FILE2"
            }
    }

    module.v2_on_file_diff(res)

# Generated at 2022-06-11 13:44:57.960585
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    result = {
        "_result": {
            "msg": "Success",
            "changed": False
        }
    }
    cm = CallbackModule()
    assert cm.v2_runner_on_ok(result) == "Success"


# Generated at 2022-06-11 13:45:07.199947
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import tempfile
    import os
    import shutil

    (fd, tmp_path) = tempfile.mkstemp()
    cb = CallbackModule()

    # create a file with some content
    file = open(tmp_path, 'w')
    file.write("line1\nline2\nline3\nline4\n")
    file.close()

    # create a diff in a temporary directory
    before_path = os.path.join(tempfile.mkdtemp(), "before")
    after_path = os.path.join(tempfile.mkdtemp(), "after")

    shutil.copy2(tmp_path, before_path)
    os.close(fd)
    os.unlink(tmp_path)

    file = open(tmp_path, 'w')

# Generated at 2022-06-11 13:45:12.992184
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    # Arrange
    import json
    result = json.dumps({
        "failed": True,
        "ansible_facts": {},
        "changed": False,
        "_ansible_no_log": False,
        "invocation": {
            "module_args": "",
            "module_name": ""
        }
    })

    result = json.loads(result)

    # Act
    c = CallbackModule()
    response = c.v2_runner_on_failed(result)

    # Assert
    assert response == None


# Generated at 2022-06-11 13:45:23.795128
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    class Testminimal:
        def __init__(self):
            self.result = {'changed': False, 'stderr': '', 'cmd': [], 'rc': 0, 'stdout': '', '_ansible_no_log': False, '_ansible_parsed': True, 'stdout_lines': [], 'failed': True, 'warnings': []}
            self.result['invocation'] = {'module_name': 'command', 'module_args': {'creates': None, 'warn': True, 'executable': None, 'removes': None, '_raw_params': 'uname -a', 'chdir': None, 'argv': None, 'stdin': None}}

    expected = 'FAILED! => { ... \n'
    test_minimal = CallbackModule()

# Generated at 2022-06-11 13:45:33.496849
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class FakeHost():
        def __init__(self):
            self.vars = dict()
            self.name = "localhost"
            self.groups = []

    class FakeTask():
        def __init__(self):
            self.action = ""

    class FakeResult():
        def __init__(self):
            self._result = dict()
            self._result["changed"] = False

    task = FakeTask()
    result = FakeResult()
    result._result["changed"] = True
    result._task = task
    result._host = FakeHost()
    result._result = {"changed": True}

    module = CallbackModule()

# Generated at 2022-06-11 13:45:39.616004
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import json
    cb=CallbackModule()
    cb.v2_runner_on_failed(json.dumps({'host':'localhost','result':{'rc':0,'stdout':'[WARNING]: Could not match supplied host pattern, ignoring: do not use\n'}}))



# Generated at 2022-06-11 13:45:48.257392
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    mock_display = MockDisplay()
    removed_lines = [{"before_header": "- existing_data", "before": "- existing_data"}]
    added_lines = [{"after_header": "+ new_data", "after": "+ new_data"}]
    unchanged_lines = [{"after": "", "before": "unchanged_line"}]
    mixed_lines = [{"after": "changed_line", "before": "changed_line"}]
    no_diff = []
    for lines in [removed_lines, added_lines, unchanged_lines, mixed_lines, no_diff]:
        callback = CallbackModule()
        callback._display = mock_display
        result = dict(diff=lines)
        callback.v2_on_file_diff(result)
        assert mock_display.displayed.pop() == lines

