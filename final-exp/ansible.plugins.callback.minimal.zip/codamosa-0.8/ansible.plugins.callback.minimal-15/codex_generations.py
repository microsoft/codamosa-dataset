

# Generated at 2022-06-11 13:37:04.691477
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackModule
    from ansible import constants as C
    from collections import namedtuple
    result = namedtuple('result', '_host _result _task')
    result._host = namedtuple('_host', 'get_name')
    result._host.get_name.return_value = 'localhost'
    result._result = {
        'changed': False,
        'stdout': 'command output',
        'stderr': 'command error',
        'msg': 'command message',
        'rc': 0,
    }
    result._task = namedtuple('_task', 'action')
    result._task.action = 'command'
    callback = CallbackModule()

# Generated at 2022-06-11 13:37:10.983465
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # create an instance of CallbackModule
    cb = CallbackModule()
    cb._display = MockDisplay()
    
    # create an instance of Result
    result = Result()
    result._host = MockHost()
    result._task = MockTask()
    result._result = dict()
    result._result['changed'] = False
    
    cb.v2_runner_on_ok(result)


# Generated at 2022-06-11 13:37:18.590701
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import mock
    import os
    import sys
    import shutil
    import tempfile
    import pytest
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes

    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    display = mock.MagicMock()
    result = mock.MagicMock()

    # store current dir for later restore
    current_dir = os.getcwd()

    # store current stdout for later restore
    current_stdout = sys.stdout
    sys.stdout = StringIO()

    # create temporary test directory and set as current dir
    tmpdir = tempfile.mkdtemp()
    os.chdir(tmpdir)


# Generated at 2022-06-11 13:37:27.691986
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    mock_display = MagicMock()
    mock_task     = MagicMock(action="ping")
    mock_host     = MagicMock(get_name=Mock(return_value="localhost"))
    mock_result   = Mock(changed=False, _task=mock_task, _host=mock_host, _result={"changed": False})
    cb = CallbackModule(mock_display)

    # v2_runner_on_ok called with a result object whose task's action is not in MODULE_NO_JSON
    cb.v2_runner_on_ok(mock_result)
    mock_display.display.assert_called_once_with("localhost | SUCCESS => {}", color=None)

    # v2_runner_on_ok called with a result object whose task's action is in MODULE

# Generated at 2022-06-11 13:37:38.671250
# Unit test for method v2_on_file_diff of class CallbackModule

# Generated at 2022-06-11 13:37:41.382779
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    cb = CallbackModule()
    cb.v2_runner_on_ok({'changed': False})
    cb.v2_runner_on_ok({'changed': True})

# Generated at 2022-06-11 13:37:51.571571
# Unit test for method v2_runner_on_ok of class CallbackModule

# Generated at 2022-06-11 13:37:53.830377
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # test data
    result = None
    # instantiate the test
    test = CallbackModule()
    # run the test
    test.v2_on_file_diff(result)

# Generated at 2022-06-11 13:37:54.598087
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    c = CallbackModule()

# Generated at 2022-06-11 13:37:58.241863
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result = {"_result": {"_host": {"_name": "localhost"}, "msg": "", "failed": True, "invocation": {"module_name": "command"}, "_task": {"action": "command"}}}
    assert(CallbackModule.v2_runner_on_failed(None, result) == None)

# Generated at 2022-06-11 13:38:16.090572
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Import module
    import sys
    sys.path.append("../")
    from ansible.plugins.callback.minimal import CallbackModule

    # Prepare arguments
    import ansible.plugins.callback as callback
    result = callback.CallbackModule()
    result._host.get_name = lambda: '127.0.0.1'
    result._task.action = 'ping'
    result._result = {'changed': False, 'invocation': {'module_args': {'data': 'pong'}}, 'parsed': True, 'ping': 'pong'}

    # Run method
    instance = CallbackModule()
    instance.v2_runner_on_failed(result)

    # Check if call was successful
    assert True


# Generated at 2022-06-11 13:38:22.722751
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    pass
    # pm = PluginManager()
    # pm.add_directory(os.path.join(os.path.dirname(__file__), '..', '..', 'callback_plugins'))
    # cb_map = pm.load_callback_plugins(callback_load_method='load_plugins', callback_plugin_dir=os.path.join(os.path.dirname(__file__), '..', '..', 'callback_plugins'))
    # cb = cb_map['minimal']
    # assert cb is not None
    # assert isinstance(cb, CallbackModule)
    # assert isinstance(cb, CallbackBase)
    # assert cb.CALLBACK_VERSION == 2.0
    # assert cb.CALLBACK_TYPE == 'stdout'
    # assert cb.C

# Generated at 2022-06-11 13:38:33.350664
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.callback.minimal import CallbackModule
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    import json


# Generated at 2022-06-11 13:38:42.879947
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import os
    import sys

    # output format to test
    stdout_old = sys.stdout
    sys.stdout = open('/tmp/test_CallbackModule_v2_runner_on_failed_stdout', 'w')

    # creating a dummy object
    result = type('obj', (object,), {
        '_task': type('obj', (object,), {
            'action': 'some_action'
        }),
        '_host': type('obj', (object,), {
            'get_name': lambda self: 'host'
        }),
        '_result': {
            'cmd': 'echo ok',
            'rc': 0,
            'stdout': 'test output',
            'stderr': '',
            'msg': ''
        }
    })

    cb = Callback

# Generated at 2022-06-11 13:38:45.294626
# Unit test for constructor of class CallbackModule
def test_CallbackModule():

    # Execute constructor of class CallbackModule
    callback_module = CallbackModule()

    # Check the type of callback_module
    assert isinstance(callback_module, CallbackModule)

# Generated at 2022-06-11 13:38:56.459683
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # get a reference to the class
    CallbackModule_class_reference = CallbackModule
    # create an instance of the class - note that we don't create an instance
    # of the CallbackBase class, as we do not need to fully test the behaviour
    # of CallbackBase, just that of the overridden method.
    CallbackModule_instance = CallbackModule_class_reference()
    # create a mock context manager - this will be used to prevent the
    # 'with' statement from formatting the output, so that we can test
    # for the correct output
    class MockDisplay():
        def __enter__(self):
            return self
        # This method is called by the 'with' statement. We use it to
        # prevent the 'display' method from stripping whitespace from
        # the output.

# Generated at 2022-06-11 13:38:57.421705
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    obj = CallbackModule()
    assert obj

# Generated at 2022-06-11 13:39:05.816895
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Input parameters for method v2_on_file_diff
    result = {
      "changed": true,
      "comment": "File b/test changed",
      "diff": ["--- a/test\n", "+line2\n"],
      "invocation": {
        "module_args": {
          "follow": false,
          "path": "b/test"
        }
      },
      "msg": "File b/test changed"
    }

    # Expected return value
    expected_result = None

    # Instantiate class and call method
    cb = CallbackModule()
    actual_result = cb.v2_on_file_diff( result )

    # Assert that method returned expected value
    assert actual_result == expected_result

# Generated at 2022-06-11 13:39:06.621704
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callbackModules = CallbackModule()

# Generated at 2022-06-11 13:39:14.082470
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # pylint: disable=unused-argument
    def mock_dump_results(value, indent):
        return value

    def mock_handle_exception(value):
        return value

    def mock_handle_warnings(value):
        return value

    cr = CallbackModule()
    cr._dump_results = mock_dump_results
    cr._handle_exception = mock_handle_exception
    cr._handle_warnings = mock_handle_warnings

    assert cr.CALLBACK_VERSION == 2.0
    assert cr.CALLBACK_TYPE == 'stdout'
    assert cr.CALLBACK_NAME == 'minimal'

# Generated at 2022-06-11 13:39:26.825947
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    result = {'ansible_facts': {'distribution': 'CentOS'}, 'changed': True, 'invocation': {'module_args': {'state': 'present'}}, 'stdout': 'test'}
    cb = CallbackModule()
    result = MockedResult(result)
    cb.v2_runner_on_ok(result)

# Generated at 2022-06-11 13:39:29.217850
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    pass


# Generated at 2022-06-11 13:39:39.265751
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    print('Testing method v2_runner_on_ok')
    # Testing when result._result.get('changed', False) is True
    print('Testing when result._result.get(\'changed\', False) is True')
    myVar = True
    result = {'changed': myVar}
    i = result['changed']
    print(i)
    myCallback = CallbackModule()
    myCallback.v2_runner_on_ok(result)
    # Testing when result._result.get('changed', False) is False
    print('Testing when result._result.get(\'changed\', False) is False')
    myVar = False
    result = {'changed': myVar}
    i = result['changed']
    print(i)
    myCallback = CallbackModule()
    myCallback.v2_runner_on_ok

# Generated at 2022-06-11 13:39:40.110970
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    assert 1 == 1

# Generated at 2022-06-11 13:39:40.717803
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert True

# Generated at 2022-06-11 13:39:51.202389
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # create a fake result
    result = FakeResult()
    result._task.action = "fake_action"
    result._result = {"fake_result_key": "fake_result_value"}
    result._host.get_name.return_value = "fake_host_name"
    # create a fake display
    display = FakeDisplay()
    # create an instance of CallbackModule
    callback_module = CallbackModule()
    # set the fake display to the callback module
    callback_module._display = display
    # call the method on the instance
    callback_module.v2_runner_on_failed(result)
    # assert that the display was called
    assert display.display_text == "fake_host_name | FAILED! => {\n    \"fake_result_key\": \"fake_result_value\"\n}"
   

# Generated at 2022-06-11 13:39:59.925529
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    import json
    import tempfile
    import os


# Generated at 2022-06-11 13:40:10.766400
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    """
    Validate that the v2_runner_on_failed function of the CallbackModule
    class properly changes the color of the output to red (error) and
    changes the state to FAILED.
    """

    test_obj = CallbackModule()

    result = type('test', (object,), {'_result':{'stdout': 'FAILED', 'stderr': 'blah', 'msg': 'Error', 'rc': 1}, '_host':type('test', (object,), {'get_name':lambda:'localhost'})})

    # Test the v2_runner_on_failed function.
    test_output = test_obj.v2_runner_on_failed(result, ignore_errors=False)


# Generated at 2022-06-11 13:40:19.881326
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    c = CallbackModule()
    assert c.CALLBACK_VERSION == 2.0
    assert c.CALLBACK_TYPE == 'stdout'
    assert c.CALLBACK_NAME == 'minimal'
    assert hasattr(c, '_display')
    assert hasattr(c, 'v2_runner_on_failed')
    assert hasattr(c, 'v2_runner_on_ok')
    assert hasattr(c, 'v2_runner_on_skipped')
    assert hasattr(c, 'v2_runner_on_unreachable')
    assert hasattr(c, 'v2_on_file_diff')
    assert hasattr(c, 'v2_runner_on_async_failed')
    assert hasattr(c, 'v2_runner_on_async_ok')

# Generated at 2022-06-11 13:40:30.934133
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    ''' Unit test for method v2_runner_on_ok of class CallbackModule '''

    # setting 'changed' attribute of a result object to False
    result = type('result', (object,), {'_result': dict(changed=False),'_task': type('task', (object,), {'action': None})})
    result._task.action = 'setup'

    # setting 'ansible_job_id' attribute of a result object to None
    result._result.update(ansible_job_id=None)

    # setting 'host' attribute of a result object to 'localhost'
    result._host = type('host', (object,), {'get_name': lambda x: 'localhost'})

    # setting return value of method _handle_warnings of class CallbackModule to None
    # setting return value of method _handle_

# Generated at 2022-06-11 13:40:48.207188
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback = CallbackModule()
    assert isinstance(callback, CallbackModule)
    assert isinstance(callback, CallbackBase)

# Generated at 2022-06-11 13:40:48.788877
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-11 13:40:50.619879
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    cm = CallbackModule()
    result = {}
    cm.v2_runner_on_failed(result)

# Generated at 2022-06-11 13:40:58.203076
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Arrange
    result = {
      "changed": True,
      "diff": {
        "after": "",
        "before": "",
        "after_header": "",
        "before_header": "",
        "before_header_lines": [],
        "after_header_lines": [],
        "before_lines": [],
        "after_lines": []
      }
    }

    # Act
    callback = CallbackModule()
    result = callback.v2_on_file_diff(result)

    # Assert
    #assert result == 0



# Generated at 2022-06-11 13:40:59.378815
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    pass


# Generated at 2022-06-11 13:41:05.865345
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    task_result = {'foo': 'bar', 'changed': True}
    task = Mock()
    task.action = 'random'
    result = Mock()
    result.action = 'random'
    result._task = task
    result._host = 'testhost'
    result._result = task_result
    callback = CallbackModule()
    callback.v2_runner_on_ok(result)

# Unit tests for method _command_generic_msg
# of class CallbackModule

# Generated at 2022-06-11 13:41:13.394464
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    test_log_file = "/tmp/ansible_log.txt"
    callbacks = CallbackModule()

# Generated at 2022-06-11 13:41:23.747558
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import json
    import sys
    import mock

# Generated at 2022-06-11 13:41:32.831454
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import playbooks
    import ansible.constants as C
    import ansible.utils.template as template
    import ansible.callbacks as callbacks
    import ansible.callbacks.display as display
    import ansible.inventory.host as host
    import ansible.inventory.group as group
    import ansible.inventory.manager as imgr
    import ansible.utils.crypto as crypto
    import os

    class V2CallbackModule(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'minimal'
        CALLBACK_NEEDS_WHITELIST = True
        CALLBACK_NO_CLOBBER = ['stdout']


# Generated at 2022-06-11 13:41:41.236479
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    from ansible.utils.display import Display
    from ansible.plugins import callback_loader

    display = Display()
    display.verbosity = 3

    plugin = callback_loader.get(u'minimal', display)

    r = {}
    r['_result'] = {}
    r['_result']['stdout'] = "Ran command as user"
    r['_task'] = {}
    r['_task']['action'] = 'shell'
    r['_host'] = {}
    r['_host']['get_name'] = lambda: 'localhost'

    # test for success
    plugin.v2_runner_on_failed(r, True)


if __name__ == '__main__':
    # simple unit test
    test_CallbackModule_v2_runner_on_failed()

# Generated at 2022-06-11 13:42:31.095122
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Setup test fixture
    C.COLOR_OK = ""
    C.COLOR_ERROR = ""
    C.COLOR_CHANGED = ""
    C.COLOR_SKIP = ""
    C.COLOR_UNREACHABLE = ""
    C.MODULE_NO_JSON = []
    class display:
        def __init__(s):
            s.out = []
        def display(s, out, color):
            s.out.append(out)

# Generated at 2022-06-11 13:42:38.761023
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a test object to test CallbackModule.v2_runner_on_failed()
    class TestClass:
        def __init__(self, name):
            self.name = name

        def get_name(self):
            return self.name

    # Create a mock display object
    class Display:
        def __init__(self):
            self.display_string = ''

        def display(self, string):
            self.display_string += string

    # Create mock objects to test the function
    test_object = TestClass("test")
    display = Display()
    result = "Not OK"
    callback = CallbackModule(display)

    # Test the function, it should produce the default error message
    callback.v2_runner_on_failed(test_object, result, False)

# Generated at 2022-06-11 13:42:47.968791
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    result = "ok"

    class dummy_display:
        def display(result):
            return
    class dummy_result:
        def __init__(self, result):
            self._result = result
            self._task = "ok"
    class dummy_host:
        def get_name(self):
            return "ok"

    result = dummy_result(result)
    result._host = dummy_host()
    result._task = 'ok'

    callback_module = CallbackModule()
    callback_module.display = dummy_display()
    callback_module.v2_runner_on_ok(result)


# Generated at 2022-06-11 13:42:57.686691
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    obj = CallbackModule()
    print(obj.CALLBACK_NAME)

# Generated at 2022-06-11 13:43:02.239295
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback = CallbackModule()
    callback.v2_runner_on_failed("result")
    callback.v2_runner_on_ok("result")
    callback.v2_runner_on_skipped("result")
    callback.v2_runner_on_unreachable("result")
    callback.v2_on_file_diff("diff")

# Generated at 2022-06-11 13:43:11.802689
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Define input parameters for method v2_runner_on_failed of class callback_plugin.
    # Define values of type class 'ansible.executor.task_result.TaskResult' for parameter result
    result = TaskResult()
    result._task = dict()
    result._task['action'] = str()
    result._result = dict()
    result._result['changed'] = True

    # Define value of type class 'ansible.plugins.callback.CallbackBase' for parameter self
    self = CallbackBase()
    self._handle_exception = Mock()
    self._handle_warnings = Mock()
    self._display = classMock()

    # Call method v2_runner_on_failed of class callback_plugin
    CallbackModule.v2_runner_on_failed(self, result)

    # Assert set_

# Generated at 2022-06-11 13:43:12.221868
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    pass

# Generated at 2022-06-11 13:43:13.345069
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback = CallbackModule()
    assert callback

# Generated at 2022-06-11 13:43:15.766850
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    obj = CallbackModule()
    assert obj.CALLBACK_VERSION == 2.0
    assert obj.CALLBACK_TYPE == 'stdout'
    assert obj.CALLBACK_NAME == 'minimal'

# Generated at 2022-06-11 13:43:25.676502
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    results = {"msg": "test message", "rc": 255}
    results_dict = {"_result": results, "_host": {"get_name": lambda: "hostname"} }
    cb = CallbackModule()

    assert not cb._command_generic_msg(results_dict["_host"]["get_name"](), results, "failed")
    assert not cb.v2_runner_on_failed(results_dict, ignore_errors=False)
    assert not cb.v2_runner_on_ok(results_dict)
    assert not cb.v2_runner_on_skipped(results_dict)
    assert not cb.v2_runner_on_unreachable(results_dict)
    assert not cb.v2_on_file_diff(results_dict)

# Generated at 2022-06-11 13:45:01.798628
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():

    # Input test data
    input_data = {
        'diff': {
            'after': '# Sample file\n',
            'before': '',
            'delta': '0,1d0\n< # Sample file\n',
            'after_header': '',
            'before_header': '',
            'binary': False,
            'before_footer': '',
            'after_footer': '',
        }
    }

    # Execute
    from ansible import constants as C
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.callback.minimal import CallbackModule
    import sys
    import ansible.plugins.loader as plugins
    obj = CallbackModule()

# Generated at 2022-06-11 13:45:08.845430
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible_runner import Runner
    from ansible_runner.inventory import Inventory
    from ansible_runner.playbook import Playbook
    print ("Unit test for method v2_runner_on_failed of class CallbackModule")

    # Create and execute a Runner object
    r = Runner(inventory, playbook, envvars, host_pattern, private_data_dir, data_crypt)
    r.run()

    # Call method v2_runner_on_failed
    r.playbook.callback.v2_runner_on_failed(r.results[0], ignore_errors=False)
    print ("Test OK!")

# Generated at 2022-06-11 13:45:10.815449
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    module = CallbackModule()
    result = { "changed" : "true"}
    module.v2_runner_on_failed(result)

# Generated at 2022-06-11 13:45:22.247436
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    # Initialise the callback module
    callbackModule = CallbackModule()

    # Initialise mocked object
    result = type('', (object,), {'_task': type('', (object,), {'action': 'command'}), '_host': type('', (object,), {'get_name': lambda: 'test_host'}), '_result': {'msg': 'command failed'}})

    # Call the method in the callback module to be tested and check the result
    assert callbackModule.v2_runner_on_failed(result) == 'test_host | FAILED! => {\n    "msg": "command failed"\n}\n'

    # Initialise mocked object

# Generated at 2022-06-11 13:45:32.109064
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    from collections import namedtuple
    from ansible import constants as C
    import os

    class MockDisplay:
        '''Mock the display class'''
        def display(self, text, color=C.COLOR_OK):
            '''Mock the display.display function'''
            pass

    class MockTask:
        '''Mock the task class'''
        def __init__(self, action='ping'):
            self.action = action

    class MockResult:
        '''Mock the result class'''
        def __init__(self, host='127.0.0.1', result=None, task=None):
            self._host = namedtuple('MockHost', ['get_name'])(host)
            self._result = result
            self._task = task


# Generated at 2022-06-11 13:45:35.433811
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    C.COLOR_ERROR = 5
    result = type('Result', (object,), {'_result':{'message':'test_message'}, '_host':type('Host', (object,), {'get_name':lambda self: 'test_host'})})
    caplog_plugin_manager = type('CaplogPluginManager', (object,), {'_display':type('Display', (object,), {'display':lambda self, msg, *args, **kwargs:print(msg)})})
    plugin_manager = caplog_plugin_manager()
    plugin_manager.v2_runner_on_failed(result)


# Generated at 2022-06-11 13:45:45.418119
# Unit test for constructor of class CallbackModule
def test_CallbackModule():

    # __init__ is not a requirement of callback modules, so this test is mostly for
    # coverage purposes.

    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook.task_include import TaskInclude

    class TestModule(CallbackBase):

        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'test'
        CALLBACK_NAME = 'test'

        def __init__(self):
            self.super_ref = super(TestModule, self)
            self.super_ref.__init__()

    # Test some members of the base class is what we expect

    callback = TestModule()

    assert callback._display is not None
    assert callback._display._verbosity == 0

# Generated at 2022-06-11 13:45:49.044232
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    CallbackModule_instance = CallbackModule()
    result = "hello world"
    result._result = {'diff': True}
    assert CallbackModule_instance.v2_on_file_diff(result) == None
    result._result = {'diff': False}
    assert CallbackModule_instance.v2_on_file_diff(result) == None

# Generated at 2022-06-11 13:45:52.389232
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Initialize a ShellModule object
    callback_module_fixture = CallbackModule()

    # Initialize a Host instance
    host_fixture = Host("myhost")

    # Initialize a TaskResult object
    task_result_fixture = TaskResult("some task", host_fixture)

    # Initialize a runner_on_ok method
    callback_module_fixture.v2_runner_on_ok(task_result_fixture)


# Generated at 2022-06-11 13:45:56.493099
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result = {
        '_task': {
            'action': 'ping'
        },
        '_host': {
            'get_name': lambda: 'test_host'
        }
    }

    minimal = CallbackModule()
    response = minimal.v2_runner_on_failed(result)
    assert response == 'test_host | FAILED! => {\n}\n\n'

