

# Generated at 2022-06-11 13:36:55.735763
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    from ansible.playbook.play_context import PlayContext

    task_args = {}
    task_args.update({'one': 1})
    task_args.update({'two': 2})

    # Call the method with one and two as input arguments
    assert CallbackModule.v2_on_file_diff(task_args, task_args) == None

# Generated at 2022-06-11 13:36:59.922391
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # arrange
    callBackModule = CallbackModule()
    result = {'diff': 'diff_file_here'}
    # act
    callBackModule.v2_on_file_diff(result)
    # assert
    # Can't assert anything

# Generated at 2022-06-11 13:37:10.788408
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from collections import namedtuple

    # Create a play context
    Options = namedtuple('Options', ['connection', 'module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'listhosts', 'listtasks', 'listtags', 'syntax'])
    options = Options(connection='local', module_path=['/to/mymodules'], forks=10, become=None, become_method=None, become_user=None, check=False, listhosts=False, listtasks=False, listtags=False, syntax=False)


# Generated at 2022-06-11 13:37:12.487772
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    '''unit test for method v2_runner_on_ok of class CallbackModule'''
    pass

# Generated at 2022-06-11 13:37:19.319884
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # create an instance of the CallbackModule class to test
    callback = CallbackModule()

    # create a mock result object
    class Result:
        def __init__(self):
            self._task = ""
            class Host:
                def get_name(self):
                    return "test_host"
            self._host = Host()
            self._result = {"msg": "This is a test message."}
    result = Result()

    # run the method v2_runner_on_failed on the mock result object
    callback.v2_runner_on_failed(result)

    # assert that the method called self._display.display with the correct output
    assert(callback._display.display.call_args[0][0] == "test_host | FAILED! => {    \"msg\": \"This is a test message.\"}\n")

# Generated at 2022-06-11 13:37:28.001430
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Initialize a fake object that simulates the result object obtained
    # from ansible
    # Result object
    # <ansible.executor.task_result.TaskResult object at 0x104e87550>

    # Fake object to simulate the result object
    class FakeResult():
        def __init__(self):
            self._result = {
                'changed': False,
                'failed': False,
            }
            self._task = {
                'action': 'fake_action',
            }
            self._host = {
                'get_name': lambda: 'fake_name',
            }

    result = FakeResult()
    callbackModule = CallbackModule()
    # result._result is used into function _clean_results()
    # and because this function modify the original dictionary, we create a
    # copy to prevent side-effects


# Generated at 2022-06-11 13:37:28.555330
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    assert(False)

# Generated at 2022-06-11 13:37:39.645324
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible import configuration
    from ansible.context import CLIContext

    context = CLIContext()
    config = configuration.Configuration(context, stdout_callback='minimal')
    display = config.load_callback_plugin('minimal', 'display')
    callback = CallbackModule(display=display)

# Generated at 2022-06-11 13:37:50.087754
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Create a dummy CallbackModule object
    callback = CallbackModule()
    # A dummy result for the test
    result = type("Result", (object,), {'_result': {'diff': '--- before\n+++ after\n@@ -1,2 +1,2 @@\n-this\n+that\n'}})
    from io import StringIO
    # Save original stdout
    old_stdout = sys.stdout
    # Redirect output to a string buffer
    mystdout = StringIO()
    sys.stdout = mystdout
    # Call the callback
    callback.v2_on_file_diff(result)
    # Get stdout back
    sys.stdout = old_stdout
    # Assert that the diff has been outputted to stdout

# Generated at 2022-06-11 13:37:54.442035
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    myCbModule = CallbackModule()
    result = {
        '_host' : '127.0.0.1',
        '_result' : {
            'changed' : True,
            'msg' : 'Hello World',
            'stdout' : 'Hello World',
        }
    }
    myCbModule.v2_runner_on_failed(result)

# Generated at 2022-06-11 13:37:58.830214
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    pass


# Generated at 2022-06-11 13:38:10.000446
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    """Unit test for method v2_runner_on_ok of class CallbackModule"""
    from ansible.utils.color import stringc
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    from ansible.plugins.callback import CallbackModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    import json

    loader = DataLoader()
    display = Display()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-11 13:38:18.587561
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test call to method v2_runner_on_ok with not changed result
    host = {'name': 'localhost'}
    result = {'changed': False}
    cb = CallbackModule()
    actual = cb.v2_runner_on_ok(host, result)

    expected = ''
    assert actual == expected, 'Expected: {}, but was: {}'.format(expected, actual)

    # Test call to method v2_runner_on_ok with changed result
    result = {'changed': True}
    actual = cb.v2_runner_on_ok(host, result)

    expected = ''
    assert actual == expected, 'Expected: {}, but was: {}'.format(expected, actual)

# Generated at 2022-06-11 13:38:23.090345
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # setup
    callback_module = CallbackModule
    result = {'diff': {'after': 'new', 'before': 'old'}}
    # test
    assert callback_module.v2_on_file_diff(result)
    # teardown (none)


# Generated at 2022-06-11 13:38:29.000209
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create test objects
    callback_module = CallbackModule(display=None)
    host = FakeAnsibleHost('testhost', 'testhost', 'testhost')
    task = FakeAnsibleTask('testtaskname', 'test_role', None)
    result = FakeAnsibleResult(host=host, task=task)

    # Test
    callback_module.v2_runner_on_ok(result)


# Generated at 2022-06-11 13:38:39.923725
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import json


# Generated at 2022-06-11 13:38:43.774756
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    # Test variables used in this test
    test_vars = {
        'ansible_module_name': 'fake_module_name',
        'ansible_job_id': 'fake_job_id',
        'changed': True,
        'test_dict': {
            'test_key1': 'test_value1',
            'test_key2': 'test_value2'
        },
        'test_list': [
            'list_item1',
            'list_item2',
            'list_item3'
        ]
    }

    # Create a test result

# Generated at 2022-06-11 13:38:44.617703
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
  assert CallbackModule(display=None)

# Generated at 2022-06-11 13:38:55.836936
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import sys
    sys.path.insert(0, './lib')
    from ansible.plugins.callback.minimal import CallbackModule

# Generated at 2022-06-11 13:38:57.183555
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    c = CallbackModule()
    assert c.CALLBACK_TYPE == 'stdout'

# Generated at 2022-06-11 13:39:06.330038
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    test_CallbackModule = CallbackModule()
    assert test_CallbackModule.v2_on_file_diff() == "\\ No newline at end of file\n"



# Generated at 2022-06-11 13:39:07.542855
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    a=CallbackModule()
    a.v2_on_file_diff('result')

# Generated at 2022-06-11 13:39:08.290842
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    pass



# Generated at 2022-06-11 13:39:10.278070
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    from ansible.utils.display import Display

    display = Display()

    cb = CallbackModule(display)
    assert cb.display == display

# Generated at 2022-06-11 13:39:20.783207
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    """Test if the callback method do proper calls"""

    # Test v2_runner_on_ok method
    print("Test the method v2_runner_on_ok")

    # Create an instance of the CallbackModule class
    cbm_instance = CallbackModule()

    # Create an instance of the Response class
    response_instance = Response()

    # Create an instance of the RunnerResult class
    runner_result_instance = RunnerResult()

    # Create an instance of the Task class
    task_instance = Task()

    # Create an instance of the Host class
    host_instance = Host()

    # Create an instance of the Runner class
    runner_instance = Runner()

    # Set the task attribute of the runner_result_instance to task_instance
    runner_result_instance._task = task_instance

    # Set the host attribute of the runner_

# Generated at 2022-06-11 13:39:25.788650
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    """
    It is possible that the ansible.utils.display.Display class
    has been re-assigned by the time this test is run, so this
    test should be loaded before any other tests in this module.
    """
    CallbackModule().v2_on_file_diff({ "_result" : { "diff" : "The diff." } })



# Generated at 2022-06-11 13:39:28.238823
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    f = CallbackModule()
    result = 'FAILED'
    f.v2_runner_on_failed(result)

# Generated at 2022-06-11 13:39:36.289277
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    from UnitTest.Fixture.AnsibleModuleMock import AnsibleModuleMock
    from UnitTest.Fixture.TerminalMock import TerminalMock

    moduleMock = AnsibleModuleMock("module")
    terminalMock = TerminalMock()

    callbackModule = CallbackModule(moduleMock, terminalMock)
    callbackModule.v2_on_file_diff("diff")

    # Check that _get_diff was called with "diff" as argument
    assert terminalMock.call_log[0][0] == "callbackModule._get_diff"
    assert terminalMock.call_log[0][1][0] == "diff"

# Generated at 2022-06-11 13:39:37.397160
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # This unit test is empty so far
    pass

# Generated at 2022-06-11 13:39:41.738146
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    plugin = CallbackModule()
    fake_results = {'diff': {'after': 'newfile', 'before': 'oldfile'}}
    result = DummyRunnerResult(fake_results)
    plugin.v2_on_file_diff(result)


# Mock classes for unittest purposes


# Generated at 2022-06-11 13:40:01.072157
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import ansible.plugins.callback.minimal
    from collections import namedtuple
    # fake result class
    Result = namedtuple('Result', '_result')
    obj = ansible.plugins.callback.minimal.CallbackModule()
    obj._display = FakeDisplay()
    result = Result({'diff': 1})
    obj.v2_on_file_diff(result)
    obj._display.should.have.call_count(1)
    result = Result({'diff': 0})
    obj.v2_on_file_diff(result)
    obj._display.should.have.call_count(1)


# Generated at 2022-06-11 13:40:06.522868
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Create an instance of CallbackModule
    minimal_output = CallbackModule()

    # Call _command_generic_msg() function
    # and check the type of output
    assert isinstance(minimal_output._command_generic_msg("host", {'rc':200}, "caption"), str)

# Test if the object is an instance of CallbackBase

# Generated at 2022-06-11 13:40:16.592832
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    '''
    Unit test for method v2_runner_on_ok of class CallbackModule
    '''
    module = __import__('ansible.plugins.callback.minimal', globals(), locals(), ['CallbackModule'], -1)
    module.CallbackModule.CALLBACK_NAME = 'minimal'
    module.CallbackModule.CALLBACK_TYPE = 'stdout'
    module.CallbackModule.CALLBACK_VERSION = 2.0
    callback = module.CallbackModule()
    result = {'changed': False, 'invocation': {'module_args': {'_ansible_verbosity': 0, '_ansible_check_mode': False}}, '_ansible_no_log': False, '_ansible_parsed': True, 'warnings': []}

# Generated at 2022-06-11 13:40:23.088456
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.callbacks import CallbackBase
    callbackBase = CallbackBase()
    callbackBase.display = CallbackBase()
    callbackBase.display.display = lambda buf, color=None: buf
    import random
    import string
    result = dict()
    result['_host'] = dict()
    result['_host']['get_name'] = lambda: ''.join(random.choice(string.ascii_letters) for _ in range(10))
    result['_result'] = dict()
    result['_result']['rc'] = random.randint(0, 100)
    result['_result']['stdout'] = ''.join(random.choice(string.ascii_letters) for _ in range(10))

# Generated at 2022-06-11 13:40:34.149434
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Arrange
    from ansible.executor.task_result import TaskResult
    import ansible.vars.hostvars as hostvars
    import ansible.vars.hostvars as host
    import ansible.utils.vars as vars
    import ansible.utils.vars as utils
    # TODO: Mock a host.
    #host = hostvars.HostVars(hostname='host', variable_manager=vars.VariableManager(), loader=utils.DataLoader())
    result = TaskResult(host)

# Generated at 2022-06-11 13:40:43.039877
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    results = dict(
        changed=False,
        stderr="",
        stdout="Hello World",
        rc=0,
    )

    result = object()
    result._result = results
    result._task = object()
    result._task.action = "command"
    result._host = object()
    result._host.get_name = lambda: "hostname"

    c = CallbackModule()
    c.v2_runner_on_ok(result)

    assert c._stdout_buffer == "hostname | SUCCESS => {\n    \"changed\": false, \n    \"rc\": 0, \n    \"stderr\": \"\", \n    \"stdout\": \"Hello World\""


# Generated at 2022-06-11 13:40:50.159323
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
   response = "'msg': 'The task includes an option with an undefined variable. The error was: \'to_ascii\' is undefined\n\nThe error appears to have been in '/home/user2018/Ansible/tests/playbooks/provision_playbook.yml': line 4, column 3, but may\nbe elsewhere in the file depending on the exact syntax problem.\n\nThe offending line appears to be:\n\n\n- hosts: web\n  ^ here\n'"
   assert CallbackModule.v2_runner_on_failed(response) == response

# Generated at 2022-06-11 13:41:00.318668
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    """Test that CallbackModule.v2_on_file_diff works correctly
    """
    cb = CallbackModule()

# Generated at 2022-06-11 13:41:10.233060
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import json
    import pytest
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # setup

# Generated at 2022-06-11 13:41:20.695223
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import ansible.utils.json_objects as json_objects
    import ansible.plugins.callback as callback

    myTree = {}

# Generated at 2022-06-11 13:41:57.614550
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    cls = __import__('ansible.plugins.callback.minimal').plugins.callback.minimal.CallbackModule()
    result = __import__('ansible.results').results.Result()
    result._result = {'changed': True, 'foo': 'bar'}
    cls.v2_runner_on_ok(result)


# Generated at 2022-06-11 13:42:04.377698
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import json
    result = {}
    result['_result'] = {}
    diff = """diff --git a/test.txt b/test.txt
    index 4c6be51..59dfdf0 100644
    --- a/test.txt
    +++ b/test.txt
    @@ -1 +1,2 @@
     foo
    +bar"""
    result['_result']['diff'] = diff
    cback_mod = CallbackModule()
    cback_mod.v2_on_file_diff(result)
    assert(True)

# Generated at 2022-06-11 13:42:06.661306
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule.CALLBACK_VERSION == 2.0
    assert CallbackModule.CALLBACK_TYPE == 'stdout'
    assert CallbackModule.CALLBACK_NAME == 'minimal'

# Generated at 2022-06-11 13:42:13.252574
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    """
    Test method v2_runner_on_ok of class CallbackModule (minimal.py)
    """
    from ansible.plugins.callback.minimal import CallbackModule
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.data import AnsibleSequence
    from ansible.plugins.loader import ResultLoader

    callback = CallbackModule()
    result_loader = ResultLoader()
    result_loader._result_cache = {'a':{'changed': False}}
    result_loader.get_result = lambda t: result_loader._result_cache['a']
    result = AnsibleMapping()
    result._result = result_loader
    result._host = 'a'
    color = C.COLOR_OK
    state = 'SUCCESS'

# Generated at 2022-06-11 13:42:13.792139
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    CallbackModule()

# Generated at 2022-06-11 13:42:23.090411
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import tempfile
    import shutil
    import json

    filename_dst = tempfile.mkstemp()[1]
    filename_src = tempfile.mkstemp()[1]

    with open(filename_src, 'w+') as file_obj:
        file_obj.write('hello')

    with open(filename_dst, 'w+') as file_obj:
        file_obj.write('bye')

    cbc = CallbackModule()


# Generated at 2022-06-11 13:42:31.947971
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback = CallbackModule()
    result = { }
    result['diff'] = 'this is a test'
    result['result'] = 'this is a test of the on_file_diff method'
    returned = callback.v2_on_file_diff(result)
    assert result['result'] == returned

    result = 'test'
    returned = callback.v2_on_file_diff(result)
    assert not returned

    result = { }
    result['result'] = 'this is a test of the on_file_diff method'
    returned = callback.v2_on_file_diff(result)
    assert not returned


# Generated at 2022-06-11 13:42:32.915522
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule() is not None

# Generated at 2022-06-11 13:42:39.614127
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
	import mock
	from ansible.playbook.play_context import PlayContext
	from ansible.playbook.task_include import TaskInclude
	from ansible.vars.manager import VariableManager
	from ansible.vars.hostvars import HostVars
	from ansible.vars.reserved import Reserved
	from ansible.inventory.host import Host

	# Set up a class for use with the mock.patch context manager,
	# so that we can mock the method which we want to test
	mock_obj = mock.Mock(spec=CallbackModule)

	# Create a test action plugin instance
	cm1 = CallbackModule()

	# This is the value to be returned by the mocked method
	volatile_dict = {'changed': True}

# Generated at 2022-06-11 13:42:51.108898
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Simple test case to check method v2_runner_on_ok of class CallbackModule
    callback = CallbackModule()

# Generated at 2022-06-11 13:44:08.712407
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import sys

    # Create an instance of the CallbackModule class
    cb = CallbackModule()

    # Create a test result

# Generated at 2022-06-11 13:44:09.229148
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    pass

# Generated at 2022-06-11 13:44:14.119189
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # given
    callbackModule = CallbackModule()
    failedResult = {'msg': 'failed'}
    result = MockResult(failedResult)

    # when
    callbackModule.v2_runner_on_failed(result)

    # then
    assert callbackModule._display.display.call_args_list[0][0][0].startswith("FAILED! => ")


# Generated at 2022-06-11 13:44:21.572767
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():

    # mock the display object
    d=Mock()
    c=CallbackModule(display=d)

    # create an expected diff
    diff="""diff --git a/test_host/somefile.txt b/test_host/somefile.txt
index 5f43af9..30a46af 100644
--- a/test_host/somefile.txt
+++ b/test_host/somefile.txt
@@ -1 +1 @@
-test
+test2
"""

    # create a result object and call the module's method
    result=Mock()
    result.return_value.run_command.return_value.stdout = diff
    result._result = dict(diff=diff)
    result._host=dict(name='test_host')
    c.v2_on_file_diff(result)

    # expect that

# Generated at 2022-06-11 13:44:27.483987
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    cb = CallbackModule()
    cmd = "ls"
    results = dict(
        stdout="test.sh",
        stderr="test.sh",
        msg="test.sh"
    )
    host = "testhost"
    result = dict(
        _result=results,
        _task=cmd,
        _host=host
    )
    cb.v2_runner_on_failed(result)
    assert "testhost | FAILED! => test.sh" in cb.out


# Generated at 2022-06-11 13:44:35.294367
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    import ansible.plugins.callback.minimal as minimal
    import json
    import io

    caller_name = 'test_minimal'
    my_io = io.StringIO()

# Generated at 2022-06-11 13:44:40.920230
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible import utils
    from ansible.utils.unicode import to_unicode
    from ansible.compat.six import text_type
    from ansible.compat.six.moves import StringIO
    import json
    # TODO: Why not use a string here instead of a list?
    # Why use json.dumps()?
    # The following line is equivalent to
    # dummy_result = ['{"changed": false, "skipped": true, "msg": "The conditional check '(ansible_distribution in list(['Centos', 'Ubuntu']) or ansible_distribution_version in list(['7.4.1708', '16.04'])) and ansible_os_family == 'RedHat'' returned False"}

# Generated at 2022-06-11 13:44:43.489043
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule().CALLBACK_VERSION == 2.0
    assert CallbackModule().CALLBACK_NAME == 'minimal'
    assert CallbackModule().CALLBACK_TYPE == 'stdout'

# Generated at 2022-06-11 13:44:44.527108
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    module = CallbackModule()
    assert module is not None

# Generated at 2022-06-11 13:44:49.116324
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # CallbackModule(display, options)
    callback = CallbackModule(None, {'verbosity': 1})
    assert callback._display
    assert callback._options
    assert callback.verbose
    assert not callback.debug
    assert not callback.deprecated_verbose
    assert not callback.silent
    assert callback.verbosity == 1
    assert callback.verbosity_level == 1
    assert callback.filter_result