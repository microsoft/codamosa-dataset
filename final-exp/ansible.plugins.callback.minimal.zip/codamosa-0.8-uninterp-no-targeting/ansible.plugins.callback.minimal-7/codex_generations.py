

# Generated at 2022-06-21 03:55:00.981727
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
	c = CallbackModule()
	assert c.CALLBACK_VERSION == 2.0
	assert c.CALLBACK_TYPE == 'stdout'
	assert c.CALLBACK_NAME == 'minimal'

# Generated at 2022-06-21 03:55:05.817956
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    module = CallbackModule()
    assert module.CALLBACK_VERSION == 2.0
    assert module.CALLBACK_TYPE == 'stdout'
    assert module.CALLBACK_NAME == 'minimal'


# Generated at 2022-06-21 03:55:15.220451
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    CallbackModule_object = CallbackModule()
    CallbackModule_object.v2_runner_on_ok(result)
    CallbackModule_object._dump_results(result._result, indent=4)
    CallbackModule_object._handle_warnings(result._result)
    CallbackModule_object._clean_results(result._result, result._task.action)
    CallbackModule_object._display.display(self._command_generic_msg(result._host.get_name(), result._result, state), color=color)
    CallbackModule_object._display.display("%s | %s => %s" % (result._host.get_name(), state, self._dump_results(result._result, indent=4)), color=color)


# Generated at 2022-06-21 03:55:27.164612
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    from unittest.mock import Mock, patch

    result = Mock
    result._host = Mock
    result._host.get_name.return_value = 'myhost'

    # Mocks
    display = Mock()
    dump_results = Mock(return_value="{\"skip\": \"reason\"}")
    callback_module = CallbackModule()

    # Setup
    callback_module._display = display
    callback_module._dump_results = dump_results

    # Begin test
    expected_result = "myhost | SKIPPED\n"
    callback_module.v2_runner_on_skipped(result)

    # Verify
    display.display.assert_called_with(expected_result, color=C.COLOR_SKIP)
    dump_results.assert_not_called()


# Generated at 2022-06-21 03:55:35.893289
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Initialize a stub class
    class StubDisplay:
        def display(self, output, color=None):
            pass

    display = StubDisplay()

    # Initialize a stub class
    class StubHost:
        def get_name(self):
            return "testHost"

    host = StubHost()

    # Initialize the function class and call the function
    callbackModule = CallbackModule(display)

# Generated at 2022-06-21 03:55:40.461492
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # verify that a string is returned
    c = CallbackModule()
    result = {"diff": "hello\n"}
    diff = c.v2_on_file_diff(result)
    assert type(diff) == type("")

# Generated at 2022-06-21 03:55:46.617227
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    result = {'changed': False, 'ansible_facts': {'timezone': 'UTC'}}
    name = 'host1'
    result = Result(name, result)
    display = Display()
    callback = CallbackModule(display)
    callback.v2_runner_on_ok(result)
    assert display.lines[0] == "host1 | SUCCESS => {\n    \"ansible_facts\": {\n        \"timezone\": \"UTC\"\n    }\n}"

# Generated at 2022-06-21 03:55:58.275833
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import io
    import sys
    import json
    import pytest
    import yaml
    from collections import namedtuple

    mock_display = io.StringIO()

    result = namedtuple('Result', ['host', 'result'])
    result.host = "smarl-vm"
    result.result = {
        "changed": False,
        "msg": "",
        "rc": 1,
        "stderr": "",
        "stdout": ""
    }

    sys.stdout = mock_display

    callback_plugin = CallbackModule()
    callback_plugin.CALLBACK_VERSION = 2.0
    callback_plugin.CALLBACK_TYPE = 'stdout'
    callback_plugin.CALLBACK_NAME = 'minimal'


# Generated at 2022-06-21 03:56:07.589167
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    c = CallbackModule()
    c._display = DummyDisplay()

    result = DummyResult()
    result._host = DummyHost()
    result._host.get_name.return_value = 'test_host'

    c.v2_runner_on_skipped(result)

    assert(c._display.data[0] == 'test_host | SKIPPED')
    assert(c._display.colors[0] == C.COLOR_SKIP)



# Generated at 2022-06-21 03:56:18.856651
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    result = dict()
    result['mode'] = '0644'
    result['remote_checksum'] = '1f7a7a472abf3dd9643fd615f6da379c'
    result['checksum'] = 'dc724af18fbdd4e3477f9005d99f754f'
    result['remote_mode'] = '0644'
    result['path'] = '/root/.ansible/tmp/ansible-tmp-1530152648.25-49562483504412/source'
    result['owner'] = 'root'
    result['group'] = 'root'
    result['size'] = 256560
    result['state'] = 'file'
    result['uid'] = 0
    result['gid'] = 0

# Generated at 2022-06-21 03:56:38.051220
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.callback.minimal import CallbackModule

    class Options:
        module_path = None
        connection = None
        remote_user = None
        ack_pass = None
        sudo = None
        sudo_user = None
        become = None
        become_method = None
        become_user = None
        check = None
        diff = None
        private_key_file = None
        verbosity = None
        syntax = None
        start_at_task = None


# Generated at 2022-06-21 03:56:49.576789
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    import sys

    class Options(object):
        verbosity = 0
        connection = 'connection'
        module_path = None
        remote_user = 'remote_user'
        private_key_file = None
        ssh_common_args = None
        ssh_extra_args = None
        sftp_extra_args = None
        scp_extra_args = None
        become = None
        become_method = None
        become_user = None
        become_ask_pass = None
        ask_pass = None
        verbosity = 0
        check = False
        list

# Generated at 2022-06-21 03:56:50.148746
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-21 03:56:56.022459
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.task import Task

    result = dict(
        diff = [
            ('before/test',
            '+++'),
            ('before/test',
            '+test')
        ]
    )
    res = dict()
    res['diff'] = result['diff']
    host = 'testhost'
    task = Task()

    callback = CallbackModule()
    result = callback._get_diff(res['diff'])

    assert result == '\ntesthost | FAILED! => before/test:\n+++\ntesthost | FAILED! => \n+test\n'


# Generated at 2022-06-21 03:56:57.637857
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    """
    This is a unit test for method v2_runner_on_skipped.
    """
    cb = CallbackModule()
    result = dict()
    result["_host"] = {"get_name": lambda: "blah"}
    cb.v2_runner_on_skipped(result)
    assert 1 != 1

# Generated at 2022-06-21 03:57:03.428279
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    callback = CallbackModule()
    task_result = {
    }
    host = '127.0.0.1'
    result = '%s | UNREACHABLE! => {}' % (host)
    assert callback.v2_runner_on_unreachable(task_result, host) == result


# Generated at 2022-06-21 03:57:07.070657
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    module = __import__("ansible.plugins.callback.minimal")
    CallbackModule = module.CallbackModule
    callbackModule = CallbackModule()
    callbackModule.v2_runner_on_failed(result)



# Generated at 2022-06-21 03:57:13.586967
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    '''
    Test CallbackModule.v2_on_file_diff() method.
    '''

    # Create the CallbackModule object
    callback = CallbackModule()
    # Create the result object
    result = {'diff': 'diff', '_result': {'diff': 'diff'}}
    # Call the method
    callback.v2_on_file_diff(result)
    # Check the result
    assert callback._get_diff(result._result['diff']) == 'diff'


# Generated at 2022-06-21 03:57:17.204275
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    from ansible.plugins.callback import CallbackBase
    obj = CallbackBase()
    def test():
        obj.display('test')
    obj.display = test
    #TODO: Add asserts to this test
    assert C.COLOR_ERROR == 'RED'
    obj.v2_on_file_diff(None)

# Generated at 2022-06-21 03:57:20.058496
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    obj = CallbackModule()
    result= obj.v2_runner_on_failed('result')
    if result == 'result':
        return True
    else:
        return False

# Generated at 2022-06-21 03:57:46.004320
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():

    # Call to v2_runner_on_skipped()
    # Call to _display.display()
    # Call to display()
    # Call to display()
    # Failure: TypeError (display() missing 1 required positional argument: 'msg')

    result = Result()

    self._display.display("%s | SKIPPED" % (result._host.get_name()), color=C.COLOR_SKIP)
    
    # Local variables:
    # result: <class 'ansible.plugins.callback.CallbackModule'>
    # result._host: Host(name=None)
    # result._host.get_name(): str
    # result._host.get_name() = name: str
    # result._host.get_name() = name: str
    # result._result: <class 'ansible.plugins.callback.Result'>


# Generated at 2022-06-21 03:57:53.826925
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    def __init__(self):
        self.display = object()

    c = CallbackModule()
    c.__init__ = __init__
    result = {'_result': {
                'foo': 'bar',
                'baz': 'qux',
              },
              '_host': {
                'get_name.return_value': 'localhost'
              }
            }
    c.v2_runner_on_skipped(result)

# Generated at 2022-06-21 03:58:02.653046
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    check_Call_return = True
    check_Display_return = True
    class Display():
        def __init__():
            pass

        def display(x, y):
            if y != C.COLOR_ERROR:
                check_Display_return = False
            pass

    class CallbackModule1(CallbackModule):
        def __init__(self):
            self.dev_null = False
            self.no_log = False
            self.show_custom_stats = False
            self._display = Display()

        def set_options(self, task_queue_manager, options):
            self.options = options

        def set_play_context(self, play_context):
            self.play_context = play_context

    class Test_v2_runner_on_failed():
        def __init__(self):
            self._result

# Generated at 2022-06-21 03:58:11.629502
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
   from ansible.plugins.callback.minimal import CallbackModule
   file_diff_obj_dict = {'diff': 'test.txt'}
   args = {'_result': file_diff_obj_dict}
   file_diff_obj = type('test_file_diff_obj', (object,), args)
   file_diff_obj.__module__ = None

   def get_diff_dict(self, result):
       return 'test.txt'

   CallbackModule._get_diff = get_diff_dict
   result = CallbackModule.v2_on_file_diff(file_diff_obj)
   assert result == None

# Generated at 2022-06-21 03:58:14.595999
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    callback = CallbackModule()
    test_result = 'test/result'
    callback.v2_runner_on_skipped(test_result)
    assert False


# Generated at 2022-06-21 03:58:25.998164
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.utils.color import stringc

    args = dict(host=dict(name="host.example.com"),
                task=dict(action="test action"),
                result=dict(changed=True,
                            diff=dict(after="changed after", before="changed before")),
                _ansible_verbosity=4,
                _ansible_no_log=False)

    # Initialize object
    cb = CallbackModule()
    cb.set_options(args)

    # Callback method to test
    cb._display.display = stringc

    # Test
    cb.v2_runner_on_failed(args, ignore_errors=False)
    assert cb._display.display.called



# Generated at 2022-06-21 03:58:27.845513
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    test_instance = CallbackModule()
    assert test_instance.v2_runner_on_failed() == None

# Generated at 2022-06-21 03:58:34.687278
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import mock
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 2
    result = mock.Mock()
    result.action = 'setup'
    callback = CallbackModule()
    callback.set_options({})
    callback._display = display
    callback._dump_results = mock.Mock()
    callback.v2_runner_on_failed(result)
    assert result.action == 'setup'
    assert result._result == {}


# Generated at 2022-06-21 03:58:46.729827
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import sys
    import unittest
    from unittest import mock

    sys.modules['ansible'] = mock.MagicMock()
    sys.modules['ansible'].constants = mock.MagicMock()
    sys.modules['ansible'].constants.COLOR_CHANGED = 'COLOR_CHANGED'

    sys.modules['ansible.plugins.callback'] = mock.MagicMock()
    sys.modules['ansible.plugins.callback.CallbackBase'] = mock.MagicMock()
    sys.modules['ansible.plugins.callback.CallbackBase'].display = mock.MagicMock()

    # Mock display object
    sys.modules['ansible.plugins.callback.CallbackBase'].display.display = mock.MagicMock()

    from ansible.plugins.callback import CallbackBase
    from ansible import constants

# Generated at 2022-06-21 03:58:55.045864
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    test_result_diff = dict()

    # test with valid result 
    test_result_diff['diff'] = 'this is a diff'
    test_result = dict()
    test_result['_result'] = test_result_diff
    callBackModule = CallbackModule()
    callBackModule.v2_on_file_diff(test_result)

    # test with invalid result 
    test_result_diff = dict()
    test_result = dict()
    test_result['_result'] = test_result_diff
    callBackModule = CallbackModule()
    callBackModule.v2_on_file_diff(test_result)

    return 0


# Generated at 2022-06-21 03:59:09.993055
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    pass

# Generated at 2022-06-21 03:59:19.975603
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callbackModule = CallbackModule(playbook)
    callbackModule._handle_exception = lambda x: None
    callbackModule._handle_warnings = lambda x: None
    callbackModule._clean_results = lambda x, y: None
    callbackModule._dump_results = lambda x, indent=4: None
    result = MagicMock(spec=[])
    result.get_name = lambda: 'test.test.com'
    result._task = MagicMock(spec=[])
    result._task.action = 'shell'
    result._result = {'changed': True}
    assert callbackModule.v2_runner_on_ok(result) == None
    result._result = {'changed': False}
    assert callbackModule.v2_runner_on_ok(result) == None

# Generated at 2022-06-21 03:59:26.835459
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Construct test data for method CallbackModule.v2_runner_on_failed
    result = {"_ansible_verbose_always": True, "_ansible_no_log": False, "changed": True, "invocation": {"module_args": {"name": "testuser"}}}
    # Create a object of class CallbackModule
    v2_runner_on_failed = CallbackModule()
    # Evaluate the method CallbackModule.v2_runner_on_failed
    assert(v2_runner_on_failed.v2_runner_on_failed(result))


# Generated at 2022-06-21 03:59:31.642202
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    print("Testing v2_on_file_diff")

    # Test diff with an example
    result = {'diff': [{'after_header': 'foo', 'before_header': 'bar',
                        'before_lines': ['line 1', 'line 2'],
                        'after_lines': ['line 3', 'line 4']}]}

    callback = CallbackModule()

    # Check that the diff is displayed on the console
    assert callback._get_diff(result['diff']) == """+foo
-bar
@@ -1,2 +1,2 @@
-line 1
-line 2
+line 3
+line 4
"""

    return

test_CallbackModule_v2_on_file_diff()

# Generated at 2022-06-21 03:59:34.913976
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    cb = CallbackModule()
    assert (cb.CALLBACK_VERSION == 2.0)
    assert (cb.CALLBACK_TYPE == 'stdout')
    assert (cb.CALLBACK_NAME == 'minimal')

# Generated at 2022-06-21 03:59:39.178578
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    from ansible import constants as C
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.callback.minimal import CallbackModule

    obj = CallbackModule()
    result = CallbackBase()
    result._result = {'diff': True}
    assert 'diff' in result._result and result._result['diff']


# Generated at 2022-06-21 03:59:45.700164
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import sys, os
    sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
    from ansible.utils.unicode import to_unicode
    import json
    import base64
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-21 03:59:54.783306
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    result = {"started": 0, "finished": 1, "_host": "localhost", "elapsed": 0.002, "item": {}, "invocation": {"module_args": {"_ansible_module_name": "ping"}, "_ansible_module_name": "ping"}}
    result_o = {"started": 0, "finished": 1, "_host": "localhost", "elapsed": 0.002}
    cb = CallbackModule()
    cb.v2_runner_on_skipped(result)
    expected = cb.v2_runner_on_skipped(result_o)
    assert result == result_o

# Generated at 2022-06-21 04:00:02.076767
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    host = ["test"]
    result = {"unreachable": True}
    result_expected = "test | UNREACHABLE! => {'unreachable': True, 'msg': 'Failed to connect to the host via ssh: ssh: Could not resolve hostname test: Name or service not known', 'changed': False}"
    c = CallbackModule()
    c.v2_runner_on_unreachable(result)
    assert result_expected == c.stderr.getvalue()


# Generated at 2022-06-21 04:00:05.083567
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    test = CallbackModule()
    test.v2_runner_on_skipped("result")
    print("v2_runner_on_skipped test complete")

#Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-21 04:00:35.056203
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    import os
    from ansible.plugins.callback.minimal import CallbackModule

    callback = CallbackModule()

    assert callback

    assert callback._dump_results == CallbackBase._dump_results
    assert callback._dump_results == CallbackModule._dump_results

    assert callback._get_diff == CallbackBase._get_diff
    assert callback._get_diff == CallbackModule._get_diff

    assert callback._load_name_to_path_map == CallbackBase._load_name_to_path_map
    assert callback._load_name_to_path_map == CallbackModule._load_name_to_path_map

    assert callback._handle_exception == CallbackBase._handle_exception
    assert callback._handle_exception == CallbackModule._handle_exception

    assert callback._handle_warnings == Callback

# Generated at 2022-06-21 04:00:41.820215
# Unit test for method v2_runner_on_unreachable of class CallbackModule

# Generated at 2022-06-21 04:00:53.790259
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    """Unit test for test_CallbackModule"""
    my_callback = CallbackModule()
    my_callback.CALLBACK_VERSION = 1.1
    assert my_callback.CALLBACK_VERSION == 1.1
    my_callback.CALLBACK_TYPE = 'amqp'
    assert my_callback.CALLBACK_TYPE == 'amqp'
    my_callback.CALLBACK_TYPE = 'stdout'
    assert my_callback.CALLBACK_TYPE == 'stdout'
    my_callback.CALLBACK_NAME = 'minimal'
    assert my_callback.CALLBACK_NAME == 'minimal'
    my_callback.CALLBACK_NAME = 'always'
    assert my_callback.CALLBACK_NAME == 'always'
    my_callback.CALLBACK_VERSION = 2.0


# Generated at 2022-06-21 04:01:02.768602
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    from ansible.utils.color import stringc
    red_color = stringc(None, C.COLOR_UNREACHABLE)

# Generated at 2022-06-21 04:01:05.109705
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    callbackModule = CallbackModule()
    import json
    result = json.dumps({'msg': 'test'})
    callbackModule.v2_runner_on_unreachable('test_host', result, False)

# Generated at 2022-06-21 04:01:17.804263
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():

    class TestAnsibleModule:
        def __init__(self, arg1):
            self.params = {'arg1': arg1}

    class TestAnsibleResult:
        class _AnsibleHost:
            def __init__(self, name):
                self.name = name

            def get_name(self):
                return self.name

        def __init__(self, host, result):
            self._host = TestAnsibleResult._AnsibleHost(host)
            self._result = result

    class TestAnsibleDisplay:
        def __init__(self):
            self.messages = []

        def display(self, message, color):
            self.messages.append((message, color))

    display = TestAnsibleDisplay()
    callback = CallbackModule()
    module = TestAns

# Generated at 2022-06-21 04:01:28.311901
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
  import sys, constants
  # print(str(constants.MODULE_NO_JSON))
  result = {
    '_host': 'host',
    '_result': {
      'changed': False,
      'ansible_job_id': 'job_id',
      'ansible_facts': {'fact1': 'val1', 'fact2': 'val2'}
    },
    '_task': {
      'action': 'action'
    }
  }
  callback = CallbackModule()
  callback.v2_runner_on_ok(result)

  # self._display.display("%s | %s => %s" % (result._host.get_name(), state, self._dump_results(result._result, indent=4)), color=color)
  capture = sys.stdout.getvalue().strip

# Generated at 2022-06-21 04:01:30.670948
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback = CallbackModule()
    assert callback.CALLBACK_VERSION == 2.0
    assert callback.CALLBACK_TYPE == 'stdout'
    assert callback.CALLBACK_NAME == 'minimal'


# Generated at 2022-06-21 04:01:40.985842
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    class TestResult(object):
        def __init__(self):
            self._host = 'server0'

# Generated at 2022-06-21 04:01:44.132006
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    m = CallbackModule()
    assert m.CALLBACK_VERSION == 2.0
    assert m.CALLBACK_TYPE == 'stdout'
    assert m.CALLBACK_NAME == 'minimal'

# Generated at 2022-06-21 04:02:37.789192
# Unit test for method v2_on_file_diff of class CallbackModule

# Generated at 2022-06-21 04:02:39.474843
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback = CallbackModule()
    callback.v2_runner_on_ok(['changed'], True)

# Generated at 2022-06-21 04:02:43.440344
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    assert callback_module._command_generic_msg('localhost', {}, 'FAILED') == 'localhost | FAILED | rc=-1 >>\n\n'
    assert callback_module._command_generic_msg('localhost', { 'stdout': 'some text' }, 'FAILED') == 'localhost | FAILED | rc=-1 >>\nsome text\n'


# Generated at 2022-06-21 04:02:50.788304
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    from collections import namedtuple
    from ansible.executor.task_result import TaskResult

    module = CallbackModule()
    result = TaskResult("localhost", "setup")
    result.is_skipped = True
    result._host = namedtuple("Host", "get_name")("localhost")

    try:
        module.v2_runner_on_skipped(result)
        assert False
    except SystemExit:
        assert True

# Generated at 2022-06-21 04:03:01.080763
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    from ansible.module_utils.six import StringIO
    from ansible.plugins.callback.default import CallbackModule

    plugin = CallbackModule()
    plugin.set_options({'connection': 'smart'})
    plugin._display = Display()

    result = MockAnsibleResult(host="localhost", result={"stdout": "foo", "stderr": "bar"})
    plugin.v2_runner_on_unreachable(result)

    host_msg, stdout_msg, stderr_msg = plugin.stdout.splitlines()
    assert host_msg == 'localhost | UNREACHABLE! => {"stderr": "bar", "stdout": "foo"}'
    assert stdout_msg == 'stderr: bar'
    assert stderr_msg == 'stdout: foo'

# Unit

# Generated at 2022-06-21 04:03:10.000973
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    from ansible.plugins.callback.minimal import CallbackModule
    from ansible.utils.color import colorize, hostcolor
    from ansible.utils.display import Display
    import json

    class MockDisplay:
      def __init__(self):
        self.values = []

      def display(self, text, color=None, stderr=False, screen_only=False, log_only=False):
        self.values.append([text, color, stderr, screen_only, log_only])

    display = MockDisplay()
    callback = CallbackModule(display)
    result={'msg': 'Test message'}
    callback.v2_runner_on_unreachable(result)

# Generated at 2022-06-21 04:03:17.854844
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    # Create the object
    c = CallbackModule()
    # Create a result
    result = type('result', (object,), {'_host': type('host', (object,), {'get_name': lambda x: 'testhost'})(), '_result': {'_ansible_verbose_always': True, 'msg': 'test message', 'failed': True, 'changed': True}})()
    # Run the v2_runner_on_unreachable method
    c.v2_runner_on_unreachable(result)


# Generated at 2022-06-21 04:03:23.158234
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import pytest

    def v2_on_file_diff(result):
        if 'diff' in result._result and result._result['diff']:
            self._display.display(self._get_diff(result._result['diff']))

    test_result = {'diff': [{'before_header': '# before', 'after_header': '# after', 'before': '# before', 'after': '# after'}]}
    CallbackModule.v2_on_file_diff(CallbackModule, pytest.result)
    assert(CallbackModule.v2_on_file_diff(CallbackModule, test_result) == None)

# Generated at 2022-06-21 04:03:31.588229
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    # set up fake args
    args = dict()
    args['_ansible_version'] = '2.4.3.0'

    # set up fake host
    class Host:
        def get_name(self):
            return 'localhost'

    host = Host()

    # set up fake host result
    class HostResult:
        def __init__(self, result_dict):
            self._result = result_dict

    result_dict = dict()
    result_dict['changed'] = False
    host_result = HostResult(result_dict)

    # set up fake action
    class Task:
        def __init__(self, action_str):
            self.action = action_str

    action = Task('setup')

    # create new runner result

# Generated at 2022-06-21 04:03:43.032867
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test setup
    test_result = dict(
        _host = dict(
            get_name = lambda: 'test_host'
        ),
        _task = dict(
            action = 'setup'
        ),
        _result = dict(
            changed = False,
            foo = 'bar',
            fail = dict(msg = 'this field should be dropped')
        )
    )

    # Test call
    CallbackModule.v2_runner_on_ok(
        instance = None,
        result = test_result
    )

    # Test assertions
    # 'fail' is dropped, 'changed' is included, 'blue' is included
    assert test_result._result.keys() == ['changed', 'foo']
