

# Generated at 2022-06-21 03:55:06.799610
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import re
    import os
    import ansible
    import ansible.plugins
    import ansible.plugins.callback

    # Instantiate callback module object
    output_dir = os.path.join(os.path.dirname(ansible.__file__), 'plugins', 'callback', 'minimal_output')
    callback_module = ansible.plugins.callback.minimal_output.CallbackModule(display=ansible.plugins.callback.minimal_output.Display())

    # Instantiate result object
    result = ansible.plugins.callback.minimal_output.Result()

    # Populate result._result with "diff" contents read from file
    with open(os.path.join(output_dir, 'test_CallbackModule_v2_on_file_diff_diff.txt')) as tf:
        result._result = {}
       

# Generated at 2022-06-21 03:55:16.191603
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    obj = CallbackModule()

# Generated at 2022-06-21 03:55:20.864520
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    module = CallbackModule()
    assert None == module.v2_runner_on_failed('_result', 'ignore_errors')
    module.v2_runner_on_failed('_result', False)
    assert None == module.v2_runner_on_failed('_result', False)


# Generated at 2022-06-21 03:55:26.005131
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    try:
        # test ansible.plugins.callback.CallbackModule.v2_on_file_diff
        module = AnsibleModule()
        result = module.run_command('uname -a')
        my_callback = CallbackModule()
        my_callback.v2_on_file_diff(result['diff'])
        assert my_callback.v2_on_file_diff(result['diff']) is None
    except Exception as e:
        pytest.fail("Exception raised: %s" % str(e))



# Generated at 2022-06-21 03:55:35.267459
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    ''' Test method v2_on_file_diff of class CallbackModule '''
    from ansible import context
    context._init_global_context(load_plugins=False)
    result = MockResult()

# Generated at 2022-06-21 03:55:41.262029
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    '''
    Test v2_runner_on_unreachable method of class CallbackModule
    '''
    # Init devops mock object
    devops_mock = DevopsClientMock()
    devops_mock.run_command = MagicMock(return_value=('127.0.0.1', ''))

    # Create playbook and inventory
    pb = PlayBook(playbooks=PLAYBOOKS, inventory=HOSTS, default_remote_user=USERNAME, default_remote_pass=PASSWORD)
    pb.set_devops_client(devops_mock)

    # Force to set the callback module to minimal
    pb.set_callback('ansible.plugins.callback.minimal.CallbackModule')

    # Execute playbook
    pb.run()

    # Get output

# Generated at 2022-06-21 03:55:50.017583
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    import ansible.utils.template
    # ansible_facts.py is only valid for ansible 2.3 and later
    import ansible.executor.module_common
    from ansible.utils.parse import parse_kv
    from ansible.collections.ansible.netcommon.plugins.module_utils.network.common.utils import dict_diff

    ansible.utils.template.template = lambda a, b, c: b
    ansible.executor.module_common.ModuleBase._fail_json = lambda a, b, c: b
    ansible.utils.parse.parse_kv = parse_kv
    ansible.collections.ansible.netcommon.plugins.module_utils.network.common.utils.dict_diff = dict_diff
    class RunnerResult(object):
        host = result = action = _task

# Generated at 2022-06-21 03:55:52.476323
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    cb = CallbackModule()
    cb.v2_runner_on_skipped("")

# Generated at 2022-06-21 03:56:04.095997
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # We substitute display because we don't want to pollute sys.stdout
    # with the print function
    class Display():
        def __init__(self):
            self.to_display = ""

        def display(self, msg, color=None):
            self.to_display = msg

    class Task():
        def __init__(self):
            self.action = None

    class Host():
        def __init__(self):
            self.name = "host0"

        def get_name(self):
            return self.name

    class Result():
        def __init__(self, task, host):
            self.host = host
            self.task = task
            self.module_name = None
            self.result = None
            self.failed = False
            self.changed = False


# Generated at 2022-06-21 03:56:07.854191
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()
    assert CallbackModule.CALLBACK_VERSION == 2.0
    assert CallbackModule.CALLBACK_TYPE == 'stdout'
    assert CallbackModule.CALLBACK_NAME == 'minimal'

# Generated at 2022-06-21 03:56:19.159526
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    input = {
        'invocation': {
            'module_name': 'test'
        },
        'msg': 'msg'
    }
    output = 'foohost | UNREACHABLE! => {'
    output += '\n    "invocation": {"module_name": "test"},'
    output += '\n    "msg": "msg"'
    output += '\n}\n'
    assert(CallbackModule().v2_runner_on_unreachable(mock_result('foohost', input)) == output)


# Generated at 2022-06-21 03:56:25.190468
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():

    class Options:
        verbosity = 0

    class Runner:
        options = Options()

    class Display:
        display = lambda s, x, y: print(x)

    class Host:
        name = "TestHost"

    class TaskResult:
        host = Host()

    cb = CallbackModule(Runner(), Display())

    cb.v2_runner_on_skipped(TaskResult())

# Generated at 2022-06-21 03:56:26.611839
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    from ansible.plugins.callback.default import CallbackModule
    cm = CallbackModule()


# Generated at 2022-06-21 03:56:30.594518
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    CallbackModule.v2_on_file_diff({'diff' : '''diff --git /tmp/foo /tmp/bar
--- /tmp/foo	2018-10-09 13:01:44.000000000 +0000
+++ /tmp/bar	2018-10-09 13:01:44.000000000 +0000
@@ -1 +1 @@
-foo
+bar'''})


# Generated at 2022-06-21 03:56:40.972708
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    """
    Test v2_runner_on_ok method from this callback class
    """
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_result import TaskResult
    from ansible.utils.color import stringc
    from ansible.utils.display import Display

    result = {}
    host_name = 'host.local'
    task = TaskInclude()
    task_result = TaskResult(host=host_name, task=task, task_fields=dict(action='action'))
    task_result._result = result
    obj = CallbackModule()
    obj._display = Display()

    # Test with no changed results
    obj._task = task
    result['changed'] = False
    result['ansible_job_id'] = ''

# Generated at 2022-06-21 03:56:51.152454
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # create result object
    result = type('', (), {})()
    setattr(result, "_host", "test_host")
    # create error object
    error = type('', (), {})()
    setattr(error, "_result", { "changed": True, "rc": -1, "stderr": "stdout_stderr" })
    setattr(error, "_task", type('', (), {})())
    # set result
    setattr(result, "_result", error)
    # set task
    task = type('', (), {})()
    setattr(task, "action", "test_action")
    setattr(task, "_display", type('', (), {})())
    getattr(error, "_task").action = task
    # set display
    display = type('', (), {})()
    setattr

# Generated at 2022-06-21 03:56:56.480894
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
  import warnings
  warnings.simplefilter("ignore")
  cb = CallbackModule()
  result = dict()
  result['msg'] = 'test'
  result['rc'] = 0
  result['warnings'] = ['test']
  cb.v2_runner_on_failed(result, ignore_errors = False)




# Generated at 2022-06-21 03:57:04.857024
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    reference = """mock_host | FAILED! => {
    "failed": true, 
    "msg": "the remote module failed!"
}
"""
    result = {'failed': True, 'msg': 'the remote module failed!'}
    with mock.patch.object(CallbackModule, '_display'):
        callback = CallbackModule()
        callback.v2_runner_on_failed(result)
        assert callback.display.display.call_args[0][0] == reference



# Generated at 2022-06-21 03:57:07.522248
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callback = CallbackModule()
    assert callback.CALLBACK_TYPE == 'stdout'
    assert callback.CALLBACK_NAME == 'minimal'
    assert callback.CALLBACK_VERSION == 2.0


# Generated at 2022-06-21 03:57:08.026262
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    pass

# Generated at 2022-06-21 03:57:26.634425
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_result import TaskResult
    from ansible.executor.stats import AggregateStats
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    play = Play()
    play_context = PlayContext()
    play_context.network_os = 'ios'
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._extra_vars = { 'ansible_network_os': 'ios' }

# Generated at 2022-06-21 03:57:33.395709
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    import unittest
    class TestCallbackModule(unittest.TestCase):
        hostname = 'test_host'
        msg = 'test_msg'
        task = 'test_task'
        def setUp(self):
            self.cb = CallbackModule()
        def test_v2_runner_on_skipped(self):
            self.cb.v2_runner_on_skipped(self)
            self.assertEqual(self.cb._display.display(msg, color=C.COLOR_SKIP))
    unittest.main()

# Generated at 2022-06-21 03:57:45.708058
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    results = { '_ansible_verbose_always': True, '_ansible_no_log': True, '_ansible_verbose': True, '_ansible_debug': True, '_ansible_version': '4.4.0.dev0'}
    display = { 'verbosity': 4}
    host = { 'name': 'localhost', '_ansible_no_log': False, '_ansible_verbose_always': False, '_ansible_verbose': False, '_ansible_debug': False}
    task = { 'action': 'command' }
    
    import json
    import os
    from ansible.utils.path import unfrackpath
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

# Generated at 2022-06-21 03:57:58.439597
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # result._result['diff'] exists and is not empty
    # should call _get_diff and display on screen
    result = TestResult()
    result._result = {'diff': 'this is diff'}
    callback = CallbackModule()
    callback.display = TestDisplay()
    callback.v2_on_file_diff(result)

    # result._result['diff'] exists and is empty
    # should not call _get_diff and not display on screen
    result = TestResult()
    result._result = {'diff': ''}
    callback = CallbackModule()
    callback.display = TestDisplay()
    callback.v2_on_file_diff(result)

    # result._result['diff'] not exists
    # should not call _get_diff and not display on screen
    result = TestResult()

# Generated at 2022-06-21 03:58:00.760884
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule() is not None

if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-21 03:58:04.607424
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    c = CallbackModule()
    c.v2_display = MagicMock()
    c.v2_runner_on_failed({})
    assert c.v2_display.call_count == 1

# Generated at 2022-06-21 03:58:14.087174
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    from ansible.compat.tests import unittest
    from ansible.module_utils._text import to_bytes

    class TestUnreachable(unittest.TestCase):
        def setUp(self):
            self.cm = CallbackModule()

        def test_output_is_string(self):
            result = {'ansible_facts': {'foo': 'bar'}, '_ansible_verbose_always': True, 'changed': True, '_ansible_no_log': False}
            self.assertEqual(type(self.cm.v2_runner_on_unreachable('host', result)), to_bytes)

    unittest.main()

# Generated at 2022-06-21 03:58:20.973248
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    c = CallbackModule()
    c.v2_runner_on_ok({'changed':False, 'ansible_facts':{'os_name': 'Ubuntu', 'hostname': 'hostname'}})
    c.v2_runner_on_ok({'changed':True, 'ansible_facts':{'os_name': 'Ubuntu', 'hostname': 'hostname'}})


# Generated at 2022-06-21 03:58:21.562721
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    assert True

# Generated at 2022-06-21 03:58:32.000560
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import json
    import mock

    # Get the object to test
    local = CallbackModule()

    # Mock display
    global_display = mock.Mock()
    local._display = global_display

    # Mock result object
    class MockResult:
        def __init__(self, changed, action, host_name, result):
            self._result = result
            self._task = MockTask()
            self._host = MockHost(host_name)
            self._task.action = action
            self._result['changed'] = changed

        def _dump_results(self, result, indent):
            return json.dumps(result)

    # Mock task object
    class MockTask:
        action = None

    # Mock host object

# Generated at 2022-06-21 03:58:53.117807
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    callback_module = CallbackModule()
    result = Result()
    result._host = Host()
    result._host.get_name = MagicMock(return_value="my_mocked_host")
    callback_module.v2_runner_on_skipped(result)
    callback_module._display.display.assert_called_once_with("{} | SKIPPED".format("my_mocked_host"), color=C.COLOR_SKIP)


# Generated at 2022-06-21 03:58:56.134394
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
	callback_module_minimal = CallbackModule()
	callback_module_minimal.v2_runner_on_failed('error', ignore_errors=True)
	assert True


# Generated at 2022-06-21 03:59:00.079551
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    m = CallbackModule()
    assert m.CALLBACK_VERSION == 2.0
    assert m.CALLBACK_TYPE == 'stdout'
    assert m.CALLBACK_NAME == 'minimal'

# Generated at 2022-06-21 03:59:11.759877
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    class fake_result:
        def __init__(self, host, task, result, action = "command"):
            self._host = host
            self._task = task
            self._result = result
            self._task.action = action
    class fake_display:
        fake_result_list = []
        def display(self, message, color = ""):
            self.fake_result_list.append(message)

    task = "fake_task"
    host = "fake_host"
    result = {'changed': True, 'msg': 'Success'}
    action = "command"
    fake_result = fake_result(host, task, result, action)
    fake_display = fake_display()
    callbackModule = CallbackModule()
    callbackModule._display = fake_display
    callbackModule.v2_runner_

# Generated at 2022-06-21 03:59:20.832202
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    cb = CallbackModule()
    # Test without result._host.get_name() resulting in an AttributeError

# Generated at 2022-06-21 03:59:27.550722
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # arrange
    result = {
        "changed": False,
        "invocation": {
            "module_args": "",
            "module_name": "command"
        },
        "rc": 1
    }

    callbackModule = CallbackModule()
    callbackModule.display = Display()
    callbackModule.display.display = Display.display
    callbackModule._dump_results = Display.dump_result
    callbackModule._handle_exception = Display.handle_exception
    callbackModule._handle_warnings = Display.handle_warnings

    # act
    callbackModule.v2_runner_on_failed(result)

    # assert
    msg = "FAILED! => {'changed': False, 'invocation': {'module_args': '', 'module_name': 'command'}, 'rc': 1}"
    assert msg

# Generated at 2022-06-21 03:59:37.038670
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback.minimal import CallbackModule
    from ansible.utils.color import stringc
    color = C.COLOR_OK
    state = 'SUCCESS'
    host = 'testhost'
    result = {'result_key': "result_value", 'changed': False}
    obj = CallbackModule()
    assert obj._dump_results(result, indent=4) == "{'changed': False, 'result_key': 'result_value'}"
    assert obj._display.display("{0} | {1} => {2}".format(host, state, obj._dump_results(result, indent=4)), color=color) == stringc("{0} | {1} => {2}".format(host, state, obj._dump_results(result, indent=4)), color)


# Generated at 2022-06-21 03:59:44.329946
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    result={"host": "host", "_result": {}, "_host": {"get_name": lambda: "host"}}
    result["_result"]["stdout_lines"]=["line1", "line2"]
    result["_result"]["stderr_lines"]=["line3", "line4"]
    result["_result"]["msg"]="message"
    result["_result"]["rc"]=1
    module = CallbackModule()
    assert module.v2_runner_on_unreachable(result) == "host | UNREACHABLE! => {'msg': u'message', 'stderr_lines': [u'line3', u'line4'], 'stdout_lines': [u'line1', u'line2'], 'rc': 1}\n"


# Generated at 2022-06-21 03:59:45.285618
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    obj = CallbackModule()

# Generated at 2022-06-21 03:59:56.647892
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common.collections import ImmutableDict
    import json

    # Define expected output of method.

# Generated at 2022-06-21 04:00:36.155850
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result = {
        'invocation': {
            'module_args': 'hostname',
            'module_name': 'setup'
        },
        'warnings': [],
        'error': 'command not found'
    }
    obj = CallbackModule()
    assert obj._command_generic_msg('host', result, 'FAILED') == 'host | FAILED | rc=-1 >>\ncommand not found\n\n'


# Generated at 2022-06-21 04:00:40.534505
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # Method v2_runner_on_skipped is automatically and exclusively tested by test_callback_skippy.py
    pass

# Generated at 2022-06-21 04:00:51.562099
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    module = CallbackModule()
    import json
    result = json.loads('{"module_stdout": "sudo: a password is required\n", "module_stderr": "", "changed": false, "msg": "Failed to set permissions on the file. Use become, become_method, or become_user to execute commands with elevated privileges.", "rc": 1, "invocation": {"module_args": {"follow": true, "mode": "600", "path": "/etc/sudoers.d/ansible"}, "module_name": "file"}}')
    module.v2_runner_on_ok(result)
    # Indirect test for CallbackModule._display.display()
    # TODO: test for CallbackModule._display.display(msg, color)



# Generated at 2022-06-21 04:01:01.418834
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    callback = CallbackModule()
    result = object()
    result._host = object()
    result._result = object()
    result._host.get_name = lambda: 'test_host'

    class MockDisplay(object):
        def __init__(self):
            self.display = []
        def display(self, msg, color=None):
            self.display.append({'msg': msg, 'color': color})

    callback._display = MockDisplay()
    callback._dump_results = lambda x, y: "dumped_results"
    callback.v2_runner_on_unreachable(result)
    assert callback._display.display[0]['msg'] == 'test_host | UNREACHABLE! => dumped_results'
    assert callback._display.display[0]['color'] == 'red'

# Generated at 2022-06-21 04:01:03.825050
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result = {'_host': {'get_name': lambda: 'host'}, '_result': {}}
    CallbackModule().v2_runner_on_failed(result)


# Generated at 2022-06-21 04:01:10.983010
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    v2_runner_on_failed = CallbackModule.v2_runner_on_failed

    class DummyClass:
        pass

    class DummyResult:
        def __init__(self):
            self._result = DummyClass()
            self._result.rc = "rc_test"
            self._result.changed = True
            self._result.stdout = "stdout_test"
            self._result.stderr = "stderr_test"
            self._result.msg = "msg_test"

            self._host = DummyClass()
            self._host.get_name = lambda: "host_name_test"

            self._task = DummyClass()
            self._task.action = "action_test"

    assert v2_runner_on_failed(DummyResult(), ignore_errors=False)

# Generated at 2022-06-21 04:01:17.487416
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # Create a dummy class with method v2_runner_on_skipped
    class TestClass():
        def v2_runner_on_skipped(self, result):
            print("result._host.get_name() | SKIPPED")

    # Instantiate it and call method v2_runner_on_skipped
    tc = TestClass()
    tc.v2_runner_on_skipped(None)


# Generated at 2022-06-21 04:01:19.918084
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    m = CallbackModule()
    m._display = None
    m.v2_runner_on_skipped(None)

# Generated at 2022-06-21 04:01:20.695805
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()

# Generated at 2022-06-21 04:01:29.728293
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    from ansible.plugins.callback.minimal import CallbackModule
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    from ansible.plugins.display import Display

    class MockDisplay(Display):
        def __init__(self):
            self.display_data = []

        def display(self, data, color=None):
            self.display_data.append((data, color))

    class MockResult:
        def __init__(self, host, result):
            self._result = result
            self._host = MockHost(host)
    
    class MockHost:
        def __init__(self, host):
            self.host = host
        
        def get_name(self):
            return self.host


# Generated at 2022-06-21 04:02:59.914898
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    import copy
    import os
    import tempfile
    from ansible import constants
    from ansible.plugins import callback_loader
    from ansible.utils.display import Display
    from ansible.module_utils._text import to_bytes

    display = Display()
    test_callback_plugins_path = os.path.join(os.path.join(os.path.dirname(__file__), "callback_plugins"))
    callback_plugins_paths = [test_callback_plugins_path] if test_callback_plugins_path else None
    callback_loader.add_directory(callback_plugins_paths)

    callback = callback_loader.get('minimal', display)
    assert callback is not None
    assert callback._display.display is not None
    assert callback._dump_results is not None

    # v2_runner_on_

# Generated at 2022-06-21 04:03:00.695333
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    pass

# Generated at 2022-06-21 04:03:02.318297
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    instance = CallbackModule()
    instance.v2_runner_on_failed({})


# Generated at 2022-06-21 04:03:06.287561
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    import mock
    import json

    class_instance = CallbackModule()
    class_instance._display = mock.Mock()

    class_instance.v2_runner_on_skipped(mock.Mock())

    class_instance._display.assert_called_once_with('host | SKIPPED', color='yellow')


# Generated at 2022-06-21 04:03:17.416669
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    """
    Unit test for method v2_on_file_diff of class CallbackModule
    """
    from ansible import context
    import os
    import tempfile
    import shutil
    import pytest

    class FakeCallbackModule(CallbackModule):
        """
        Fake subclass of CallbackModule to allow mocking of _get_diff
        """
        def __init__(self):
            self._diff = None

        def _get_diff(self, diff):
            """
            Method to write diff to temporary file to be called later by test
            """
            self._diff = diff

        def get_diff(self):
            """
            Method to retrieve written diff for test
            """
            return self._diff

    # Create dummy files used to create diff
    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-21 04:03:17.893438
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    CallbackModule()

# Generated at 2022-06-21 04:03:18.606182
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    x = CallbackModule()
    assert x

# Generated at 2022-06-21 04:03:21.456319
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    args = {}
    assert CallbackModule(**args)

# Generated at 2022-06-21 04:03:30.521407
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Developped with version 2.x of the API
    # https://github.com/ansible/ansible/blob/v2.4.3.0-1/lib/ansible/plugins/callback/minimal.py
    # Lines 6 to 8 :
    # CALLBACK_VERSION = 2.0
    # CALLBACK_TYPE = 'stdout'
    # CALLBACK_NAME = 'minimal'

    CALLBACK_VERSION = 2.0
    CALLBACK_TYPE = 'stdout'
    CALLBACK_NAME = 'minimal'

    mock_result = MockResult()
    mock_ignore_errors = False

    # Created with :
    # ansible -m fail -i 'localhost,' -c local all
    # https://raw.githubusercontent.com/ansible/ansible/v2.4.3.0-1

# Generated at 2022-06-21 04:03:33.465794
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    host = {'name':'localhost'}
    result = {'_host':host}
    cb = CallbackModule()
    cb.v2_runner_on_skipped(result)