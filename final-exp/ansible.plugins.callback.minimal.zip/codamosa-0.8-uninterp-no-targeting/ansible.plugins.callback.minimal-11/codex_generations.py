

# Generated at 2022-06-21 03:54:59.948286
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
	module = CallbackModule()
	module.v2_runner_on_ok('test')

# Generated at 2022-06-21 03:55:02.584200
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    module = CallbackModule()
    result = Result()
    module.v2_runner_on_skipped(result)
    assert result.failure

# Generated at 2022-06-21 03:55:08.982408
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.color import stringc

    def _colorize_diff(diff):
        # colorize
        # difflib using < and > while unified_diff using - and +
        ret = diff.replace('-', stringc(C.COLOR_DIFF_REMOVED, '-'))
        ret = ret.replace('+', stringc(C.COLOR_DIFF_ADDED, '+'))
        ret = ret.replace('^', stringc(C.COLOR_DIFF_LINES, '^'))
        return ret

    # Initialize a CallbackModule
    cm = CallbackModule()

    # Test of method v2_on_file_diff
    # Case1: diff is empty
    result = CallbackBase._Result({'diff': ''})
   

# Generated at 2022-06-21 03:55:09.526301
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    assert 0

# Generated at 2022-06-21 03:55:13.798519
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    """Unit test for ansible.plugins.callback.minimal.CallbackModule.v2_runner_on_skipped
    """
    actual = None
    expected = None
    c = CallbackModule()
    c.v2_runner_on_skipped()
    assert actual == expected

# Generated at 2022-06-21 03:55:18.266576
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback = CallbackModule()
    result = {'_host': {'get_name': lambda: 'host'}, '_task': {'action': 'action'}, '_result': {'changed': True, 'some_test_field': 'some_value'}}

    callback.v2_runner_on_ok(result)

# Generated at 2022-06-21 03:55:22.855579
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    module = CallbackModule()
    result = dict()
    result['_host'] = dict()
    result['_host']['get_name'] = lambda: "myhost"
    module.v2_runner_on_skipped(result)


# Generated at 2022-06-21 03:55:25.237311
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    Info = CallbackModule()
    assert (Info != None)
    return True


# Generated at 2022-06-21 03:55:29.080906
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test default no-op behavior of v2_runner_on_failed method
    # Test path for 'ansible.plugins.callback.minimal'
    # Test with 'ansible.plugins.callback.CallbackModule' as instance
    pass

# Generated at 2022-06-21 03:55:29.658912
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert True

# Generated at 2022-06-21 03:55:43.067552
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    class MockedResult():
        def __init__(self):
            self._result = {'diff': 'test diff'}

    from six import StringIO
    import sys

    capturedOutput = StringIO()
    sys.stdout = capturedOutput

    cbm = CallbackModule()
    result = MockedResult()
    cbm.v2_on_file_diff(result)
    sys.stdout = sys.__stdout__ # Reset redirect.
    assert capturedOutput.getvalue() == '\n{0}\n{1}\n{2}\n'.format('+------------------+','|     test diff    |','+------------------+')


# Generated at 2022-06-21 03:55:45.808804
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    # Arrange
    result_obj = Result()

    # Act
    # CallbackModule.v2_runner_on_unreachable(result_obj, result)

    # Assert
    # TODO: mock stuff
    assert True

# Generated at 2022-06-21 03:55:57.839105
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    import sys
    import io
    import pytest
    from ansible.plugins.callback.minimal import CallbackModule

    output = io.BytesIO()
    sys.stdout = output
    result = {
        "_host": "host1",
        "_result": {
            "a": 1,
            "b": 2,
            "changed": False,
            "invocation": {
                "module_args": {
                    "msg": "hello world"
                },
                "module_name": "debug"
            }
        },
        "_task": {
            "action": "debug",
            "args": {},
            "loop": None,
            "name": "debug"
        }
    }
    c = CallbackModule()
    c.v2_runner_on_skipped(result)

    # Ass

# Generated at 2022-06-21 03:56:09.961575
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    from ansible.plugins.callback import CallbackModule
    from ansible.parsing.ajson import AnsibleJSONEncoder
    encoder = AnsibleJSONEncoder()
    host = 'localhost'
    diff = {'before': {'new': '', 'old': 'old'}, 'after': {'new': 'new', 'old': ''}, 'before_header': 'old', 'after_header': 'new'}

# Generated at 2022-06-21 03:56:13.300380
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule.CALLBACK_NAME == 'minimal'
    assert CallbackModule.CALLBACK_TYPE == 'stdout'
    assert CallbackModule.CALLBACK_VERSION == 2.0

# Generated at 2022-06-21 03:56:18.464158
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    result = Mock()
    result._host = Mock()
    result._host.get_name = lambda: "test"
    result._result = {'msg': 'inaccessible'}
    callback = CallbackModule()
    callback.display = Mock()
    callback.v2_runner_on_unreachable(result)
    assert callback.display.call_count == 1
    assert callback.display.call_args == call("test | UNREACHABLE! => {'msg': 'inaccessible'}", color='UNREACHABLE')
    callback.display.reset_mock()

# Generated at 2022-06-21 03:56:28.542689
# Unit test for method v2_runner_on_ok of class CallbackModule

# Generated at 2022-06-21 03:56:31.996406
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():

    # check that a 'TOKEN' is properly removed from a string
    result = {'host1': {'invocation': {'module_args': {'TOKEN': 'TOKEN'}}}}
    assert CallbackModule._remove_TOKEN({'host': 'host1', 'result': result}) == 'host1 | UNREACHABLE! => {u\'msg\': u\'token: TOKEN\'}'

# Generated at 2022-06-21 03:56:41.614742
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.vars.unsafe_proxy import UnsafeProxy

    play_context = PlayContext()
    task = {'task': {'vars': {'a': 1}}}
    result = {'changed': True}

    task_result = TaskResult(host=UnsafeProxy({'name': '127.0.0.1', 'ansible_connection': 'local'}), task=task, result=result)
    task_result._task = task
    ret = CallbackModule().v2_runner_on_ok(task_result, play_context)

    assert ret is None
    assert result.get('_ansible_parsed') is None



# Generated at 2022-06-21 03:56:44.701276
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():

    # Create mocks
    result = Mock()
    result.__nonzero__ = Mock()
    result.__nonzero__.return_value = True
    result._result = {'diff': 'lines'}

    # Create real object
    actual = CallbackModule()

    # Call method
    actual.v2_on_file_diff(result)

    # Check results
    assert result.__nonzero__.call_count == 1
    assert result.diff == result._result['diff']

    return

# Generated at 2022-06-21 03:57:03.577629
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host, Group
    from ansible.playbook.task import Task
    from ansible.plugins.callback import CallbackBase
    import json

    loader = DataLoader()
    play = Play().load({}, loader=loader, variable_manager=VariableManager(), loader=loader)
    tqm = None
    host = Host(name="test_01")
    host.set_variable('ansible_host', '127.0.0.1')

# Generated at 2022-06-21 03:57:10.617301
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    class _Result:
        def __init__(self):
            self._host = _Host()
    class _Host:
        def get_name(self):
            return 'test_host'
    class _Display:
        def display(self, msg, color):
            print("msg = {0}, color = {1}".format(msg, color))
            assert msg == 'test_host | SKIPPED'
            assert color == 'yellow'
    
    result = _Result()
    display = _Display()
    callback = CallbackModule()
    callback._display = display
    callback.v2_runner_on_skipped(result)

# Generated at 2022-06-21 03:57:13.844170
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # First argument to constructor is an instance of class AnsibleDisplay.
    # For unittest purposes, AnsibleDisplay is replaced by a MagicMock class.
    mock_display = MagicMock()
    callback = CallbackModule(mock_display)
    assert callback != None

# Generated at 2022-06-21 03:57:15.349605
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    module = CallbackModule() #TODO: Test fails
    assert module is not None

# Generated at 2022-06-21 03:57:22.063009
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import ansible.constants as C

    result = {}
    result['stdout'] = 'test'
    result['stdout_lines'] = ['line1', 'line2']
    result['warnings'] = ['Warning:']

    MockCallbackModule = CallbackModule()
    MockCallbackModule.v2_runner_on_ok(result)

    #TODO: add additional asserts here


# Generated at 2022-06-21 03:57:30.680652
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible import constants as C
    
    # Set up parameters
    result = dict()
    result['hostname'] = 'test_host'
    result['changed'] = True
    
    # Set up callback object
    callback = CallbackModule()
    
    # Trigger v2_runner_on_ok()
    callback.v2_runner_on_ok(result)
    
    # Check results
    assert result.get('changed') == False
    assert result.get('hostname') == 'test_host'
    assert callback.v2_runner_on_ok(result)
    

# Generated at 2022-06-21 03:57:33.903812
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    # Single test case for method v2_runner_on_unreachable of class CallbackModule
    # We will only check if the method can be called, but not the result.
    module = CallbackModule()
    result = {}
    module.v2_runner_on_unreachable(result)



# Generated at 2022-06-21 03:57:45.935490
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    class TestObj():
        class TestResult():
            def __init__(self, task, host, result):
                self._task = task
                self._host = host
                self._result = result

            def _result(self):
                return self._result

            def _task(self):
                return self._task

            def _host(self):
                return self._host


    mod = CallbackModule()
    
    class Host:
        def __init__(self, host_name):
            self.host_name = host_name

        def get_name(self):
            return self.host_name

    test_obj = TestObj()
    
    class Result:
        def __init__(self, status, host_name, change_result):
            self.host_name = host_name
            self.status = status

# Generated at 2022-06-21 03:57:58.566739
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    from ansible.module_utils.six import StringIO
    from ansible.utils.color import stringc
    import ansible.plugins.callback.minimal as callback

    # test with default implicit color setting
    callback_obj = callback.CallbackModule()
    callback_obj._display.display = StringIO()
    callback_obj.v2_runner_on_skipped({ '_host': { 'get_name': lambda: 'hostname' } })

    test_string_output = callback_obj._display.display.getvalue()

    assert(len(test_string_output) == 28)
    assert(test_string_output.startswith(stringc(None, 'hostname')))
    assert(test_string_output.endswith(stringc(C.COLOR_SKIP, 'SKIPPED\n')))

    callback

# Generated at 2022-06-21 03:58:10.498999
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Instanciate an instance of CallbackModule and store it in the obj variable.
    obj = CallbackModule()

    result = {
        'stdout': 'hello',
        '_host': 'test_host',
        '_result': {
            'changed': False,
            'foo': {
                'bar': 'baz'
            },
            'fake_key': 'not_a_real_key',
        },
        '_task': {
            'action': 'test_action'
        }
    }

    # Call the v2_runner_on_ok method of the CallbackModule obj with the result dictionary
    obj.v2_runner_on_ok(result)

    # Retrieve the output from the v2_runner_on_ok call

    # Check for success.

    return True

# Generated at 2022-06-21 03:58:26.245736
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callbackModule = CallbackModule()
    assert callbackModule.CALLBACK_NAME == 'minimal'
    assert callbackModule.CALLBACK_VERSION == 2.0
    assert callbackModule.CALLBACK_TYPE == 'stdout'

# Generated at 2022-06-21 03:58:27.424092
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    pass


# Generated at 2022-06-21 03:58:35.132277
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    from ansible import context
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    play_context = PlayContext()
    play_context.prompt = lambda *args, **kwargs: None
    context._init_global_context(play_context)

    cb = CallbackModule()
    assert isinstance(cb, CallbackModule)

    import ansible.executor.task_result as task_result
    result = task_result.TaskResult()
    cb.v2_runner_on_skipped(result)

# Generated at 2022-06-21 03:58:40.695978
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    print("\n\n\n----------testing class CallbackModule, method v2_runner_on_failed----------\n")
    test_callback = CallbackModule()
    test_result = {'invocation':{}, 'msg':'test message', 'rc':5}
    test_callback.v2_runner_on_failed(test_result)



# Generated at 2022-06-21 03:58:52.471421
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
  from ansible.plugins.callback.minimal import CallbackModule
  from ansible.plugins.callback import CallbackBase, CallbackRegistry
  from ansible import constants as C
  import sys

  cb = CallbackModule()
  registry = CallbackRegistry()
  registry.add_callback('minimal', CallbackModule)

  registry.set_options(sys.argv[1:])
  registry.process_queue()

  class host_instance:
    def __init__(self):
      self.name = 'test_host'
      self.get_name = lambda: self.name

  class result_instance:
    def __init__(self):
      self._result = {'test': 'content'}
      self._host = host_instance()

  result = result_instance()
  cb.v2_

# Generated at 2022-06-21 03:58:54.118534
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    c = CallbackModule()

# Generated at 2022-06-21 03:59:00.867024
# Unit test for method v2_runner_on_unreachable of class CallbackModule

# Generated at 2022-06-21 03:59:12.569630
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.hostvars import HostVars

    # mock objects
    task_result = TaskResult(host="localhost", task=dict(name="task_mock"))

# Generated at 2022-06-21 03:59:21.495448
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    import ansible.constants as C

    class ResultCallback(CallbackBase):
        def v2_runner_on_unreachable(self,result):
            print("unreachable")

    variable_manager = VariableManager()
    loader = DataLoader()
    # create inventory, use path to host config file as source or hosts in a comma separated string
    inventory = Inventory(loader=loader, variable_manager=variable_manager,host_list='hosts')
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-21 03:59:31.984917
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import pytest
    from ansible.plugins.callback import CallbackBase
    callback = CallbackModule()
    result = {'result': 'ok', 'rc': 0, 'msg': 'This is a test.\n', 'stderr_lines': [], 'stdout_lines': ['This is a test.'], 'stdout': 'This is a test.\n', 'invocation': {'module_args': {'_raw_params': 'uname'}}, '_ansible_verbose_always': True, 'changed': False}

# Generated at 2022-06-21 04:00:02.209815
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.plugins.callback import CallbackBase

    class TestCallback(CallbackBase):
        def __init__(self):
            self.color = True

        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            print (msg)

    callback = TestCallback()

    result = type('', (), {})()
    result._result = {   "changed":False,
                        "msg":"snapshot created",
                        "snapshot_name":"qa-snap"}
    result._task = type('', (), {})()
    result._task.action = "snapshot"
    result._host = type('', (), {})()
    result._host.get_name = lambda: "qa"

    assert callback.v2_runner_on_ok(result) == None
   

# Generated at 2022-06-21 04:00:03.409948
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    cb = CallbackModule()
    # TODO



# Generated at 2022-06-21 04:00:06.331745
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    cb = CallbackModule()
    assert cb.CALLBACK_VERSION == 2.0
    assert cb.CALLBACK_TYPE == 'stdout'
    assert cb.CALLBACK_NAME == 'minimal'

# Generated at 2022-06-21 04:00:07.146253
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule is not None

# Generated at 2022-06-21 04:00:13.918179
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a mock callback display object
    callback_display_class = MockCallbackDisplayClass()
    # Create a mock display object
    display_class = MockDisplayClass()
    # Create an instance of the CallbackModule class
    callbackModule_obj = CallbackModule()
    # Assign the mock display object to the _display attribute of the CallbackModule class
    callbackModule_obj._display = display_class
    # Create a mock result object
    result_class = MockResultClass()
    # Create a mock task object
    task_class = MockTaskClass()
    # Assign a mock task object to the _task attribute of the mock result object
    result_class._task = task_class
    # Create a mock host object
    host_class = MockHostClass()
    # Assign a mock host object to the _host attribute of the mock result object
   

# Generated at 2022-06-21 04:00:19.417524
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module = CallbackModule()
    result = [{'before':'before', 'after':'after'}]
    callback_module.v2_on_file_diff(result)
    assert callback_module._get_diff(result._result['diff']) == "@@ -1 +1 @@\n-before\n+after\n"


# Generated at 2022-06-21 04:00:26.015770
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # object creation and assignment of local variable to hold diff
    # for use in if statement
    cb = CallbackModule()
    result = {'diff': 'foo bar baz'}

    # execution of method
    cb.v2_on_file_diff(result)


# Generated at 2022-06-21 04:00:37.930568
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.plugins.callback.minimal import CallbackModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.play_context import PlayContext

    _play_context = PlayContext()
    _play_context.become = False
    _play_context.become_method = 'sudo'
    _play_context.become_user = 'root'
    _play_context.diff = False
    _play_context.force_handlers = False
    _play_context.remote_addr = '127.0.0.1'
    _play_context.remote_user = 'dummy'
    _play_context.connection = 'local'
    _play_context.only_tags = []
    _play_context.skip_tags = []
    _play_

# Generated at 2022-06-21 04:00:39.509345
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # Given runner
    result = MockResult()
    # When execution
    CallbackModule().v2_runner_on_skipped(result)


# Generated at 2022-06-21 04:00:51.559288
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    clb = CallbackModule()
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.task.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.utils.vars import combine_vars
    import json
    host = Host(name='foohostname')
    task = Task(action='shell', args=dict(msg='Hello world!'))
    result = TaskResult(host, task, dict(changed=False, invocation=dict(module_args=''), msg='', rc=0, stdout='Hello world!\n'))
    clb.v2_runner_on_

# Generated at 2022-06-21 04:01:50.446460
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule(display=None) is not None

if __name__ == '__main__':
    pytest.main([__file__, "-v", "-s"])

# Generated at 2022-06-21 04:01:59.400684
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import io
    import sys
    import unittest

    # result._result: {'diff': {'after': 'new', 'before': 'old', 'before_header': 'testfile.txt', 'dst': '/tmp/testfile.txt'}}
    mystdout = io.StringIO()
    sys.stdout = mystdout

    result = unittest.mock.Mock()
    setattr(result, '_result', {'diff': {'after': 'new', 'before': 'old', 'before_header': 'testfile.txt', 'dst': '/tmp/testfile.txt'}})

    cb = CallbackModule()
    cb.v2_on_file_diff(result)

    sys.stdout = sys.__stdout__

    assert '[+] new' in mystdout

# Generated at 2022-06-21 04:02:08.722860
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    print("--------- Unit test for method v2_runner_on_ok of class CallbackModule -------")
    from ansible.plugins.callback.minimal import CallbackModule
    from ansible.utils import AnsibleJSONEncoder
    from ansible.plugins.loader import callback_loader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.inventory.manager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    import os
    import json
    import ansible.constants as C



# Generated at 2022-06-21 04:02:11.695347
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    """Test creation of a CallbackModule object"""

    cb = CallbackModule()
    assert CallbackModule.CALLBACK_NAME == cb.CALLBACK_NAME
    assert CallbackModule.CALLBACK_TYPE == cb.CALLBACK_TYPE
    assert CallbackModule.CALLBACK_VERSION == cb.CALLBACK_VERSION

# Generated at 2022-06-21 04:02:17.042700
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    '''
    This is a test function for method v2_runner_on_ok of class CallbackModule
    '''
    # test arguments
    result = None

    # test call of method
    callback_plugin = CallbackModule()
    return_value = callback_plugin.v2_runner_on_ok(result)

    assert return_value is None

# Generated at 2022-06-21 04:02:21.937012
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
	host = "host"
	result = "result"
	display = "display"
	retval = {
		"_host":host,
		"_result":result,
		"_display":display
	}
	test = CallbackModule(display)
	test.v2_runner_on_skipped(retval)

# Generated at 2022-06-21 04:02:26.839973
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Instantiate test class.
    test_class = CallbackModule
    result = {"diff": "Hello, world!"}
    test_class_instance = test_class()
    assert test_class_instance.v2_on_file_diff(result) == None


# Generated at 2022-06-21 04:02:37.857725
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-21 04:02:45.423371
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import unittest
    import ansible.errors
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    # import ansible.utils.jsonify
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    task = Task()
    task._role = None
    task.action = 'command'
    task.args = {}
    task._ds = {}
    task._task_vars = {}
    task._upstream_task = None
    task.tags

# Generated at 2022-06-21 04:02:54.285850
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    print("Test the method v2_runner_on_unreachable of class CallbackModule")

    # Create an instance of class CallbackModule
    cbm = CallbackModule()

    # Create an instance of class HostVars
    hv = HostVars()

    # Create an instance of class Result
    result = Result(hv,hv)

    # Execute the method v2_runner_on_unreachable
    cbm.v2_runner_on_unreachable(result)
