

# Generated at 2022-06-21 07:30:33.017212
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategymodule = StrategyModule()
    assert strategymodule != None


# Generated at 2022-06-21 07:30:44.586357
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    hosts_left = ['host1', 'host2']
    hosts_left_mod = ['host1', 'host2']
    host_tasks = [('host1', 'task'), ('host2', 'task')]
    play_context = PlayContext()
    iterator = object()
    cls = StrategyModule()
    cls._tqm._queued_results = 1
    cls._tqm._workers = 2
    cls._tqm.default_callback_whitelist = ['debug']
    cls._tqm.search_path = ['TEST_PLAYBOOK_DIR']
    results = [Result(), Result()]
    results[0]._host = 'host1'
    results[1]._host = 'host2'
    results[0]._result = False

# Generated at 2022-06-21 07:30:48.791536
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    strategy_module._inventory = 'inventory'
    strategy_module._loader = 'loader'
    strategy_module._variable_manager = 'variable_manager'
    strategy_module._hosts = 'hosts'
    strategy_module.run = 'run'
    assert strategy_module._inventory == 'inventory'
    assert strategy_module._loader == 'loader'
    assert strategy_module._variable_manager == 'variable_manager'
    assert strategy_module._hosts == 'hosts'
    assert strategy_module.run == 'run'


# Generated at 2022-06-21 07:31:01.553559
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # ansible.parsing.dataloader.DataLoader -> ansible.module_utils._text.to_bytes
    monkeypatch.setattr(ansible.module_utils._text, 'to_bytes', lambda x, errors='strict': x)

    # ansible.parsing.dataloader.DataLoader -> ansible.utils.vars.combine_vars
    monkeypatch.setattr(ansible.utils.vars, 'combine_vars', lambda x, y, z=None: x)

    # ansible.parsing.dataloader.DataLoader -> ansible.utils.vars.isidentifier
    monkeypatch.setattr(ansible.utils.vars, 'isidentifier', lambda x: x == 'name')

    _loader = DataLoader()
    _options = Options()

# Generated at 2022-06-21 07:31:09.597840
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=DataLoader()),
        variable_manager=VariableManager(),
        loader=DataLoader(),
        options=Options(),
        passwords={},
        stdout_callback=DefaultCallback(),
    )
    sm = StrategyModule(tqm)
    assert sm._tqm == tqm
    assert sm._pending_results == 0


# Generated at 2022-06-21 07:31:22.480059
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    TASK_1 = Task()
    TASK_2 = Task()
    TASK_3 = Task()
    TASK_4 = Task()
    TASK_1.name = "task 1"
    TASK_2.name = "task 2"
    TASK_3.name = "task 3"
    TASK_4.name = "task 4"

    TASK_1.action = "setup"
    TASK_2.action = "copy"
    TASK_3.action = "copy"
    TASK_4.action = "copy"

    HOST_1 = Host()
    HOST_2 = Host()
    HOST_3 = Host()
    HOST_1.name = "host 1"

# Generated at 2022-06-21 07:31:29.515118
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule()
    assert test._options is not None
    assert test._loader is not None
    assert test._variable_manager is not None
    assert test._hosts_cache is not None
    assert test._hosts_cache_all is not None
    print("test_StrategyModule success")

# Test of the update_active_connections method

# Generated at 2022-06-21 07:31:33.824920
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    seq = SequenceMatcher(None, "StrategyModule_run", "run")
    assert seq.ratio() > 0.50, 'Test failed: function is renamed'

# Generated at 2022-06-21 07:31:35.349659
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass # TODO


# Generated at 2022-06-21 07:31:43.761870
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    inventory = Inventory()
    play = Play()
    play_context = PlayContext()
    task_result = TaskResult()
    task_result_it = iter(task_result)
    hosts_left = iter(['1', '2'])
    iterator = iter(['3', '3', '3'])
    strategy_module = StrategyModule()
    strategy_module._tqm = TaskQueueManager()
    display = Display()
    task_queued = None
    # Test for no exception
    try:
        strategy_module.run(iterator, play_context)
    except Exception as e:
        assert type(e) == AttributeError
    # Test for exception
    try:
        strategy_module.run(iterator, play_context)
    except Exception as e:
        assert type(e) == AttributeError
    #

# Generated at 2022-06-21 07:32:36.932375
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import unittest2 as unittest
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.hashing import hash_all
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.executor import action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    loader = AnsibleLoader(None)

# Generated at 2022-06-21 07:32:38.144560
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-21 07:32:42.247852
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_obj = StrategyModule(tqm, hosts, iterator, variable_manager, loader)
    strategy_module_obj._step = 0
    strategy_module_obj._take_step = Mock(return_value=True)
    strategy_module_obj.run(iterator, play_context)
    assert strategy_module_obj != Mock()
    pass

# Generated at 2022-06-21 07:32:43.810518
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-21 07:32:48.602820
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.test.test_strategy
    import ansible.plugins.test.test_strategy_linear

# Generated at 2022-06-21 07:32:49.667751
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass



# Generated at 2022-06-21 07:33:03.607842
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Unit test for constructor of class StrategyModule"""

    # Test the constructor
    ###############
    # Required args that are specific to this class
    tqm = MagicMock()

    # The rest of the args are common to all subclasses
    loader = DictDataLoader({})
    variable_manager = MagicMock()
    host_list = [MagicMock()]
    top_level_tasks_only = MagicMock()
    playbook = MagicMock()

    strategy_module = StrategyModule(tqm, loader, variable_manager, host_list, top_level_tasks_only, playbook)
    assert strategy_module._tqm == tqm
    assert strategy_module._loader == loader
    assert strategy_module._variable_manager == variable_manager
    assert strategy_module._host_list == host_list

# Generated at 2022-06-21 07:33:10.050752
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(
        tqm=None,
        variable_manager=None,
        loader=None,
        shared_loader_obj=None,
        options=None,
        passwords=None,
    )
    assert strategy_module is not None

# Generated at 2022-06-21 07:33:11.004001
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-21 07:33:16.231196
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    myStrategyModule = ansible.executor.strategy_plugins.StrategyModule(runner=Mock())
    myStrategyModule.run(iterator=Mock(), play_context=Mock())


# Generated at 2022-06-21 07:35:13.370850
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:35:18.785572
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(
        tqm=None,
        loader=None,
        variable_manager=None,
        shared_loader_obj=None,
        stdout_callback=None
    )
    assert strategy.get_name() == 'linear'
    assert strategy._blocked_hosts == {}
    assert strategy._pending_results == 0
    assert strategy._hosts_cache == {}
    assert strategy._hosts_cache_all == []

# Generated at 2022-06-21 07:35:23.670638
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    play_context = StrategyModule()
    iterator = StrategyModule()
    result = StrategyModule().run(iterator, play_context)
    assert result == StrategyModule()._tqm.RUN_OK


# Generated at 2022-06-21 07:35:33.092846
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(
        tqm=None,
        new_stdin=None,
        connection_info={},
        loader=None,
        variable_manager=None,
        passwords={},
    )
    assert sm._tqm is None
    assert sm._new_stdin is None
    assert sm._connection_info == {}
    assert sm._loader is None
    assert sm._variable_manager is None
    assert sm._passwords == {}
    assert sm._shared_loader_obj is None


################################################################################
# TEST SUITE                                                                   #
################################################################################

from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-21 07:35:34.112769
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-21 07:35:36.292786
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule()
    except:
        assert False



# Generated at 2022-06-21 07:35:43.107410
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' StrategyModule.__init__()'''

    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=None, sources='localhost,'),
        variable_manager=VariableManager(loader=None, inventory=None),
        loader=None,
        options=Options(listtags=False, listtasks=False, listhosts=False, syntax=False, connection='ssh',
                        module_path=None, forks=100, remote_user='root',
                        private_key_file=None, ssh_common_args=None, ssh_extra_args=None, sftp_extra_args=None, scp_extra_args=None,
                        become=False, become_method=None, become_user='root', verbosity=None, check=False, start_at_task=None),
        passwords={},
    )

# Generated at 2022-06-21 07:35:53.713663
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  # ===========================================
  #
  # Test input data
  #
  # ===========================================
  #
  class Iterator(object):
    batch_size = 3
    _play = "play.yml"
    max_fail_percentage = 20
    def __init__(self, hosts):
      self.hosts = hosts
      self.host_index = 0
      self.hosts_left = hosts
      self._tasks = [ "task1", "task2", "task3", "task4", "task5" ]
      self._failed_hosts = {}
    def mark_host_failed(self, host):
      self._failed_hosts[host.name] = True
      self.batch_size = self.batch_size - 1
    def add_tasks(self, tasks):
      self._t

# Generated at 2022-06-21 07:35:56.039812
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule(StrategyModule):
        pass

    assert TestStrategyModule

# Generated at 2022-06-21 07:36:01.959619
# Unit test for constructor of class StrategyModule