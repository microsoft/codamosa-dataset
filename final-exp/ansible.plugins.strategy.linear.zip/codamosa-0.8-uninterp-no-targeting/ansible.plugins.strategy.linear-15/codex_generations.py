

# Generated at 2022-06-21 07:30:35.066269
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module != None


# Generated at 2022-06-21 07:30:48.777684
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestClass():
        def __init__(self, tqm):
            self._tqm = tqm
            self._blocked_hosts = dict()
    tqm = TestClass(TestClass("test"))
    strategy = StrategyModule(tqm)
    assert isinstance(strategy, StrategyModule)
    assert strategy.tqm._tqm._tqm == "test"
    assert strategy._tqm._tqm._tqm == "test"
    assert strategy._inventory is None
    assert strategy._loader is None
    assert strategy._variable_manager is None
    assert strategy._all_vars is None
    assert strategy._options is None
    assert isinstance(strategy._blocked_hosts, dict)
    assert strategy._last_hosts is None
    assert strategy._step is None

# Generated at 2022-06-21 07:30:50.487964
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass
# class StrategyModule


# Generated at 2022-06-21 07:30:56.416819
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    mod = StrategyModule()
    assert mod is not None

    #test for ansible_vars_cache
    res = mod.ansible_vars_cache
    assert res == {}

    #test for host_cache
    res = mod.host_cache
    assert res == {}

# Generated at 2022-06-21 07:31:03.862495
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(
        tqm=None,
        variables=dict(),
        loader=DictDataLoader({}),
        passwords={},
        stdout_callback=None,
        run_additional_callbacks=True,
        run_tree=False,
        forks=10,
        connection_user=None,
        connection_password=None,
        connection_port=None,
        become_user=None,
        become_method=None,
        become_password=None,
        allow_reset_connection=False,
        kind='linear',
        keep_remote_files=False
    )

    assert isinstance(strategy, StrategyModule)
    assert strategy._kind == 'linear'


# Generated at 2022-06-21 07:31:09.141413
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(
        tqm=None,
        strategies=[],
        play=None,
        new_stdin=None,
        loader=None,
        variable_manager=None,
        host_list=[]
    )

# Generated at 2022-06-21 07:31:22.446779
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    class Module1(object):
        pass
    mod = Module1()
    mod.play_context = 'play_context'
    mod.iterator = 'iterator'
    mod.loader = 'loader'
    mod.variable_manager = 'variable_manager'
    mod.host_list = 'host_list'
    mod.options = 'options'

    mod._get_hosts_cache = MagicMock(return_value = True)
    mod._set_hosts_cache = MagicMock(return_value = True)
    mod.get_hosts_left = MagicMock(return_value = True)
    mod._get_next_task_lockstep = MagicMock(return_value = True)
    mod._execute_meta = MagicMock(return_value = True)
    mod.add_tqm_variables

# Generated at 2022-06-21 07:31:23.425103
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule()

# Generated at 2022-06-21 07:31:29.813307
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    def mock_tqm_RUN_FAILED(self):
        self.RUN_FAILED = True

    def mock_tqm_RUN_OK(self):
        self.RUN_OK = True

    def mock_tqm_RUN_UNKNOWN_ERROR(self):
        self.RUN_UNKNOWN_ERROR = True

    def mock_tqm_RUN_FAILED_BREAK_PLAY(self):
        self.RUN_UNKNOWN_ERROR = True

    def mock__set_hosts_cache(self, iterator_play):
        self._hosts_cache = None
        self._hosts_cache_all = None

    def mock__get_next_task_lockstep(self, hosts_left, iterator):
        hosts_tasks = []

# Generated at 2022-06-21 07:31:31.136553
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create instance of class StrategyModule
    strategy = StrategyModule()
    assert strategy is not None

# Generated at 2022-06-21 07:32:25.387847
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module = StrategyModule()
    module._tqm = object()
    module._tqm._terminated = False
    module._tqm._failed_hosts = {}
    module._tqm.send_callback = Mock(return_value=None)
    iterator = object()
    iterator._play = object()
    play_context = object()
    module._set_hosts_cache(iterator._play)
    module.get_hosts_left = Mock(return_value=None)
    module._get_next_task_lockstep = Mock(return_value=None)
    module.update_active_connections = Mock(return_value=None)
    module._process_pending_results = Mock(return_value=None)
    module._wait_on_pending_results = Mock(return_value=None)



# Generated at 2022-06-21 07:32:27.844504
# Unit test for method run of class StrategyModule

# Generated at 2022-06-21 07:32:30.535560
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Function to test constructor of class StrategyModule
    """
    strategy = StrategyModule()
    assert isinstance(strategy, StrategyModule)

# Generated at 2022-06-21 07:32:35.643399
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None, connection_info=None, passwords=None)
    assert isinstance(strategy_module, StrategyModule)
    assert isinstance(strategy_module, BaseStrategyModule)


# Generated at 2022-06-21 07:32:36.979017
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategymodule = StrategyModule()
    assert strategymodule is not None


# Generated at 2022-06-21 07:32:43.779933
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    '''
    Unit test for method run of class StrategyModule
    '''

    iterator = MagicMock(autospec=Iterator)
    play_context = MagicMock(autospec=PlayContext)
    result = MagicMock(autospec=int)
    # Test when run method runs normally
    assert result == StrategyModule.run(iterator, play_context)

    # Test when run method throws IOError/EOFError exception
    iterator.side_effect = EOFError()
    result = StrategyModule.run(iterator, play_context)
    assert result == StrategyModule.run(iterator, play_context)

# Generated at 2022-06-21 07:32:45.653584
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()


# Generated at 2022-06-21 07:32:55.195931
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass
# class BaseEntryPoint(object):
#     '''
#     Base class for callable plugins loaded by the plugin loader.
#     '''
#     def __init__(self, name, collection=None):
#         # The name of the entry point
#         self._name = name
#         # If specified, the collection of the entry point
#         self._collection = collection
#
#     @property
#     def name(self):
#         return self._name
#
#     @property
#     def collection(self):
#         return self._collection
#
#     def __call__(self, *args, **kwargs):
#         '''
#         Entry point call interface, to be implemented by subclasses.
#         '''
#         raise NotImplementedError

# Generated at 2022-06-21 07:32:58.058564
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert(sm.get_name() == MEANINGLESS_NUMBER)

# Generated at 2022-06-21 07:33:03.686947
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule()

    play_context = ansible.playbook.play_context.PlayContext()

    playbook_dir = "/path/to/ansible-playbooks/playbooks"
    playbook_path = playbook_dir + "/site.yml"

    inventory_path = playbook_dir + "/../inventory"
    inventory = ansible.inventory.manager.InventoryManager(loader = ansible.parsing.dataloader.DataLoader(), sources=inventory_path)

    vault_password_file = playbook_dir + "/../vault_password.txt"
    vault_secrets = {'vault_password_file': vault_password_file}

    callbacks = ansible.playbook.callback.default.CallbackModule()
    options = ansible.utils.options.Options()

    # iterator = ansible.playbook

# Generated at 2022-06-21 07:35:01.162602
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-21 07:35:11.579808
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    def StrategyModule_run_test_playbook(self):
        def test_playbook(self):
            # run_once = False
            if task_action in C._ACTION_META:
                # for the linear strategy, we run meta tasks just once and for
                # all hosts currently being iterated over rather than one host
                results.extend(self._execute_meta(task, play_context, iterator, host))

# Generated at 2022-06-21 07:35:15.173208
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        StrategyModule('test', 'test')


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:35:16.665896
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm)
    assert module is not None


# Generated at 2022-06-21 07:35:30.416714
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import queue
    import unittest

    from ansible.errors import AnsibleError
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.loader import Loader
    from ansible.template import Templar
    from ansible.utils.collection_loader import AnsibleCollectionRef

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    mock_loader = DictDataLoader({
        '/path/to/collections/acme.mycoll/tasks/main.yml':  'name: acme.mycoll\ninclude: noop.yml'
    })

    mock_loader._collection_paths = ['/path/to/collections']
    mock_loader._role_paths = []
    mock

# Generated at 2022-06-21 07:35:41.266152
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-21 07:35:45.538235
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None, {}, [], [])
    print(strategy_module)

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-21 07:35:50.805216
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    fake_loader = DictDataLoader({})
    results_iterator = ResultIterator()
    play_context = PlayContext(play=None)
    variables = VariableManager()
    strategy_module = StrategyModule(tqm=None,variable_manager=variables,loader=fake_loader)
    inventory = [result for result in strategy_module.run(results_iterator,play_context)]
    assert [] == inventory

    variables = VariableManager()
    strategy_module = StrategyModule(tqm=None,variable_manager=variables,loader=fake_loader)
    inventory = [result for result in strategy_module.run(results_iterator,play_context)]
    assert [] == inventory

    variables = VariableManager()
    strategy_module = StrategyModule(tqm=None,variable_manager=variables,loader=fake_loader)
    inventory

# Generated at 2022-06-21 07:36:01.025544
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    """Test the run method of the StrategyModule class"""
    # check creating a StrategyModule object
    strategy = StrategyModule(0, 0, 0)

    # check calling the run method
    test_iterator = object()
    test_play_context = object()
    strategy.run(test_iterator, test_play_context)

    # check we are not calling some irrelevant stuff, but run method from the base class
    assert strategy.run.__code__.co_names[1:] == WrapperModule.run.__func__.__code__.co_names[1:]

# Generated at 2022-06-21 07:36:07.126642
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule('test', dict(qos=3))
    assert s._tqm == 'test'
    assert s._options['qos'] == 3
    assert s._runners is None
    assert s._blocked_hosts == dict()
