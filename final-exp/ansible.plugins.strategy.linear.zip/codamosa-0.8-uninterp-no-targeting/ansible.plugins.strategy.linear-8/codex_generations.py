

# Generated at 2022-06-21 07:30:37.898928
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    works = True
    try:
        StrategyModule.run('', '')
    except:
        works = False
    assert works

# Generated at 2022-06-21 07:30:42.157339
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, BaseStrategyModule), \
        "class StrategyModule(BaseStrategyModule): pass"
    print("test class: OK")


# Generated at 2022-06-21 07:30:53.367204
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=None),
        variable_manager=VariableManager(),
        loader=DataLoader(),
        options=Options(),
        passwords={},
    )

    tqm._stdout_callback = ResultCallback()
    my_strategy_module = StrategyModule(tqm)

    assert my_strategy_module._tqm == tqm
    assert my_strategy_module._display == tqm._stdout_callback
    assert my_strategy_module._fail_hosts is False
    assert my_strategy_module._blocked_hosts == {}
    assert my_strategy_module._pending_results == 0
    assert my_strategy_module._workers_lock == threading.Lock()
    assert my_strategy_module._noop_

# Generated at 2022-06-21 07:31:01.101368
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   loader = 'loader'
   final_q = 'final_q'
   host_list = 'host_list'
   module_vars = 'module_vars'
   tqm = 'tqm'
   variable_manager = 'variable_manager'
   StrategyModule(loader=loader,
                  final_q=final_q,
                  host_list=host_list,
                  module_vars=module_vars,
                  tqm=tqm,
                  variable_manager=variable_manager)

# Generated at 2022-06-21 07:31:13.303237
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    '''
    StrategyModule run
    '''

    _tqm = mock.Mock()
    _tqm._terminated = False
    display = mock.Mock()
    _tqm.send_callback.return_value = None
    _tqm.RUN_OK = 0
    _tqm._failed_hosts = {}
    iterator = mock.Mock()
    play_context = mock.Mock()

    strategy_module = StrategyModule(_tqm, display)
    strategy_module._tqm = mock.Mock()
    strategy_module._tqm._terminated = False
    strategy_module._set_hosts_cache = mock.Mock()
    strategy_module._get_next_task_lockstep = mock.Mock()
    strategy_module._process_pending_

# Generated at 2022-06-21 07:31:15.613734
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm != None


# Generated at 2022-06-21 07:31:25.402428
# Unit test for method run of class StrategyModule

# Generated at 2022-06-21 07:31:27.984744
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a StrategyModule instance with a valid constructor
    assert StrategyModule(Tqm(None))

    # Create a StrategyModule instance with an invalid constructor
    try:
        StrategyModule(None)
    except:
        pass


# Generated at 2022-06-21 07:31:38.153349
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-21 07:31:44.596595
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create StrategyModule object with given arguments
    strategy_module = StrategyModule(
        tqm=None,
        loader=None,
        variable_manager=None,
        shared_loader_obj=None,
        options=None,
        passwords=None,
    )

    assert strategy_module._tqm is None
    assert strategy_module._variable_manager is None
    assert strategy_module._loader is None
    assert strategy_module._shared_loader_obj is None
    assert strategy_module._options is None
    assert strategy_module._passwords is None
    assert strategy_module._hosts_left is None
    assert strategy_module._hosts_cache is None
    assert strategy_module._hosts_cache_all is None
    assert strategy_module._iterator is None
    assert strategy_module._fallback is None

# Generated at 2022-06-21 07:32:35.110722
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # set up for test
    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    # run unit test
    strategy = StrategyModule(loader=loader, inventory=inventory, variable_manager=variable_manager, tqm=None)
    assert strategy._tqm is None
    assert strategy._inventory == inventory
    assert strategy._loader == loader
    assert strategy._variable_manager == variable_manager

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-21 07:32:37.565669
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None, host_hash=None, pass_1=None)


# Generated at 2022-06-21 07:32:45.569712
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=Loader(), sources=''),
        variable_manager=VariableManager(),
        loader=Loader(),
        options=Options(),
        passwords={},
        stdout_callback='default',
    )
    iterator = PlayIterator(
        play=Play().load(dict(
            name="Ansible Play",
            hosts = "all",
            gather_facts = 'no',
            tasks=[dict(action=dict(module='setup'))],
        ), tqm._loader),
        play_context=PlayContext(),
        variable_manager=VariableManager(),
        all_vars={})
    testobj = StrategyModule(tqm)
    result = testobj.run(iterator, PlayContext())
    assert result == testobj._tqm.RUN_OK

# Generated at 2022-06-21 07:32:47.382894
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    new_StrategyModule = StrategyModule(tqm=None, strategy='linear')
    assert isinstance(new_StrategyModule, StrategyModule)


# Generated at 2022-06-21 07:32:55.768178
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import ansible.plugins.loader
    import ansible.template
    import ansible.vars
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.task import Task
    # case 1
    class AnsibleRunner:
        def __init__(self, result, play_context, variable_manager, loader, options, passwords, stdout_callback):
            self.result = result
            self.play_context = play_context
            self.variable_manager = variable_manager
            self.loader = loader
            self.options = options
            self.passwords = passwords
            self.stdout_callback = stdout_callback

# Generated at 2022-06-21 07:32:58.675005
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("\n")
    module = StrategyModule()
    module.run(iterator, play_context)

# Generated at 2022-06-21 07:33:02.211998
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t = StrategyModule(
        tqm=None,
        host_list=[],
        module_vars=dict(),
        timeout=300,
    )
    assert t.get_name() == 'linear'

# Generated at 2022-06-21 07:33:13.264626
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    results_callback = lambda x: x
    callback_plugin = CallbackModule(results_callback)
    queue_items = QueueManager(10)
    variable_manager = MagicMock()
    loader = MagicMock()
    stdout_callback = None
    strategy_module = StrategyModule(queue_items, variable_manager, loader, stdout_callback)
    assert (strategy_module._tqm == queue_items)
    assert (strategy_module._variable_manager == variable_manager)
    assert (strategy_module._loader == loader)
    assert (strategy_module._stdout_callback == stdout_callback)


# Generated at 2022-06-21 07:33:26.277158
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Variables
    hostvars = dict()
    failed_hosts = dict()
    tqm = dict()
    tqm.update({'_failed_hosts': failed_hosts})
    iterator = dict()
    iterator.update({'_play': hostvars})
    play_context = dict()

    unit = dict()
    unit.update({'_variable_manager': hostvars})
    unit.update({'_hosts_cache': hostvars})
    unit.update({'_loader': hostvars})
    unit.update({'_hosts_cache_all': hostvars})

    unit.update({'_tqm': tqm})
    unit.update({'_tqm': tqm})
    unit.update({'_tqm': tqm})
   

# Generated at 2022-06-21 07:33:27.734238
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Implementation of the StrategyCallbackModule class

# Generated at 2022-06-21 07:34:32.582869
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy is not None
    return strategy

# Generated at 2022-06-21 07:34:34.062967
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:34:39.580629
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from units.compat import unittest
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_path_spec
    from units.mock.playbook_executor import PlaybookExecutorMock
    from units.mock.playbook_loader import (
        PlaybookLoaderMock,
        MockOptions,
    )

# Generated at 2022-06-21 07:34:45.088288
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = Host(name='server')
    strategy = StrategyModule(loader=None, inventory=None, variable_manager=None,
                              loader_class=None, tqm=None, shared_loader_obj=False)
    assert strategy is not None

# Generated at 2022-06-21 07:34:46.252676
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  StrategyModule.run()


# Generated at 2022-06-21 07:34:47.917344
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategyModule = StrategyModule()
    pass

# Generated at 2022-06-21 07:34:59.922046
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    options = Options()
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._extra_vars = {"ansible_ssh_pass": "pass", "ansible_become_pass": "pass"}
    passwords = {}
    tqm = TaskQueueManager(
            inventory=InventoryManager(loader=loader, variable_manager=variable_manager),
            variable_manager=variable_manager,
            loader=loader,
            options=options,
            passwords=passwords,
            stdout_callback='default',
        )
    iterator = DefaultIterator(tqm)
    play_context = PlayContext()

# Generated at 2022-06-21 07:35:11.138056
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
#     pass
#     myIter = ansible.iterator.TaskIterator(
#         ansible.inventory.Inventory("/etc/ansible/hosts"),
#         ansible.playbook.Play.load(playbook_data()),
#     )

    inventory = ansible.inventory.Inventory("/etc/ansible/hosts")
    play = ansible.playbook.Play.load(playbook_data())
    myIter = ansible.iterator.TaskIterator(inventory, play)


# Generated at 2022-06-21 07:35:19.935677
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    Mod = module_loader.get_module_class('shell')
    mod = Mod()
    mod.test = 'success'
    mod.run_command = lambda x, y: dict(diff=dict(), rc=0)
    
    
    
    
    Mod = module_loader.get_module_class('debug')
    mod = Mod()
    mod.test = 'success'
    mod.run_command = lambda x, y: dict(diff=dict(), rc=0)
    
    Mod = module_loader.get_module_class('shell')
    mod = Mod()
    mod.test = 'success'
    
    
    
    
    
    assert True


run_test(test_StrategyModule_run)

# Generated at 2022-06-21 07:35:30.025397
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    def test_loader(path):
        return ''
    config = ConfigParser()
    loader = DataLoader()
    variable_manager = VariableManager()
    displays = CallbackModule()
    tqm = TaskQueueManager(
        inventory=['127.0.0.1'],
        variable_manager=variable_manager,
        loader=loader,
        options=opt,
        passwords={},
        stdout_callback=displays,
        run_tree=False,
    )
    loader.set_basedir(path.dirname(__file__))
    strategy = StrategyModule(tqm, loader)
    assert strategy

# Generated at 2022-06-21 07:37:25.149952
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    Stats = namedtuple('Stats', 'ok changed skipped failures unreachable')
    AggregateStats = namedtuple('AggregateStats', 'processed ok changed skipped failures unreachable custom')
    class Playbook:
        def __init__(self, hosts=None):
            self.hosts = hosts
            self.stats = Stats(0, 0, 0, 0, 0)
            self.aggregate = AggregateStats(0, 0, 0, 0, 0, 0, {})
            self.filters = {}
            self.roles = []
            self.handlers = []
            self.max_fail_percentage = 0
            
        def get_variable(self, name):
            return None
    class Runner:
        def __init__(self, runner_module_name=None, tasks=None):
            self.tasks = tasks

# Generated at 2022-06-21 07:37:28.064757
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(task_queue_manager=None)

# Generated at 2022-06-21 07:37:35.392768
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from units.mock.loader import DictDataLoader
    from units.mock.inventory import Host
    from units.mock.collection_loader import MockCollectionLoader
    from units.mock.vars_plugin import MockVarsModule

    def iter_tasks(play):
        yield ('task1', play.get_tasks()[0])
        yield ('task2', play.get_tasks()[1])

    play = Play().load(dict(
        name="play",
        hosts=['localhost'],
        gather_facts='no',
        tasks=[
            dict(action=dict(module='mock', args=dict(state='ok')))
        ]
    ), loader=DictDataLoader())

    host = Host(name='localhost')
    host.set_variable('ansible_connection', 'local')

   

# Generated at 2022-06-21 07:37:39.109894
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(
        tqm=None,
        variable_manager=None,
        loader=None
    )


# Generated at 2022-06-21 07:37:41.104123
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm is not None


# Generated at 2022-06-21 07:37:53.748361
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule(StrategyModule):
        def __init__(self, tqm):
            super(TestStrategyModule, self).__init__(tqm)
            self._test_var = 1

        def _test_StrategyModule(self):
            return self._test_var

    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=DataLoader()),
        variable_manager=VariableManager(),
        loader=DataLoader(),
        shared_loader_obj=None,
        options=Options(),
        passwords={},
        stdout_callback=None,
        run_additional_callbacks=False,
        run_tree=False,
    )

    strategy_module = TestStrategyModule(tqm)

    assert strategy_module._test_StrategyModule() == 1

# Unit

# Generated at 2022-06-21 07:38:04.764853
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Load the module so we can mock it
    try:
        module = load_module('strategy', 'linear')
    except:
        raise Exception('Failed to load the strategy linear module')

    # Create the mock objects and replace the actual objects with them

# Generated at 2022-06-21 07:38:16.142865
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module = AnsibleModule()
    module.ARCHITECTURE = 'noarch'
    module.DISTRIBUTION = 'redhat'
    module.DISTRIBUTION_MAJOR_VERSION = '7'
    module.DISTRIBUTION_VERSION = '7.5'
    module.VENDOR = 'redhat'
    module.RELEASE = '7.5.1804'
    module.MACHTYPE = 'x86_64'
    module.SYSTEM = 'Linux'
    module.DEFAULT_INTERPRETER_PYTHON = '/usr/bin/python3'
    module.HOSTNAME = 'localhost.localdomain'
    module.OBSOLETE_LINK = 'https://github.com/ansible/ansible/blob/devel/EXAMPLES.md'


# Generated at 2022-06-21 07:38:26.211589
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    def func_arg2(a, b):
        return a, b

    m = MagicMock(side_effect=func_arg2)
    m2 = MagicMock(return_value=0)

# Generated at 2022-06-21 07:38:28.768373
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy.name == 'linear'