

# Generated at 2022-06-21 07:30:39.134997
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategy = StrategyModule()
  assert isinstance(strategy, StrategyModule)

# Generated at 2022-06-21 07:30:43.199840
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert Strategies.StrategyModule is not None
    # Construct object for testing
    strategy = Strategies.StrategyModule()
    assert strategy is not None
    # Check that the instance is of class StrategyModule
    assert isinstance(strategy, Strategies.StrategyModule)

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-21 07:30:45.469879
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module = StrategyModule()
    # TODO

# Generated at 2022-06-21 07:30:48.795896
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #test_StrategyModule:
    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=None, sources='localhost,'),
        variable_manager=None,
        loader=None,
        options=Options(),
        passwords={},
    )
    strategy = StrategyModule(tqm)
    assert strategy._tqm == tqm

# unit test for the helper method add_tqm_variables

# Generated at 2022-06-21 07:30:53.720917
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # all of these tasks should be executed
    playbook_obj = playbook.Playbook.load('./yaml/strategy_module.yml', variable_manager=variable_manager.VariableManager(), loader=loader.DataLoader())
    strategy = StrategyModule(playbook=playbook_obj)
    strategy.run(iterator=playbook_obj)
    assert strategy.playbook_result.stats.processed == 3



# Generated at 2022-06-21 07:31:03.628782
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # A. Initialize the main objects
    loader = DataLoader()
    variable_manager = VariableManager()

    # B. Initialize the strategy module
    strategy = StrategyModule(loader=loader, variable_manager=variable_manager)

    # C. Check the values
    assert strategy._hosts_cache is None
    assert strategy._hosts_cache_all is None
    assert strategy._bound_hosts is None
    assert strategy._step is False
    assert strategy._last_task_banner == ''
    assert strategy._pending_results == 0
    assert strategy._blocked_hosts == {}
    assert strategy._fallback is None
    assert strategy._notified_handlers == {}
    assert strategy._actived_notified_handlers == {}
    assert strategy._conditional is None
    assert strategy._subset is None
    assert strategy

# Generated at 2022-06-21 07:31:04.595276
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule()
    assert strategy_module.run() == None

# Generated at 2022-06-21 07:31:09.187364
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_plugin = StrategyModule(loader=None, tqm=None)
    assert isinstance(strategy_plugin, StrategyModule)
    assert isinstance(strategy_plugin, BaseExecutionStrategy)


# Generated at 2022-06-21 07:31:10.996315
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-21 07:31:23.088251
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create objects of TestHost, TestQueueManager and TestVariableManager
    host = TestHost()
    queue_manager = TestQueueManager()
    variable_manager = TestVariableManager()

    # Create object of class StrategyModule
    strategy_module = StrategyModule(
        host,
        queue_manager,
        variable_manager
    )

    assert strategy_module._host == host
    assert strategy_module._tqm == queue_manager
    assert strategy_module._variable_manager == variable_manager
    assert strategy_module._hosts_cache == {}
    assert strategy_module._hosts_cache_all == {}
    assert 'max_fail_percentage' not in strategy_module._global_vars
    assert 'step' not in strategy_module._global_vars
    assert strategy_module._tqm._terminated == False

# Generated at 2022-06-21 07:32:11.595761
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(delete=False)
    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    play_book = PlaybookExecutor([tmpfile.name])
    stats = callbacks.AggregateStats()
    playbook_cb = callbacks.PlaybookCallbacks(verbose=utils.VERBOSITY)
    runner_cb = callbacks.PlaybookRunnerCallbacks(stats, verbose=utils.VERBOSITY)

    # create a host manager for test
    host_manager = vault.VaultLib()

    # create a loader for test
    loader = DataLoader()

    # create a variable manager for test
    variable_manager = VariableManager()

    # create a dummy inventory

# Generated at 2022-06-21 07:32:15.180884
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy is not None
    assert isinstance(strategy, StrategyModule)
    assert isinstance(strategy, BaseStrategy)

# Generated at 2022-06-21 07:32:25.327354
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(
        tqm=None,
        connection_info=None,
        loader=None,
        variable_manager=None,
        shared_loader_obj=None,
        run_tree=None,
        Settings=None,
    )

    assert strategy_module is not None
    assert strategy_module._hosts_cache is None
    assert strategy_module._hosts_cache_all is None
    assert strategy_module._blocked_hosts is not None
    assert strategy_module._active_connections is not None
    assert strategy_module._final_q is None
    assert strategy_module._workers is not None
    assert strategy_module._step is False
    assert strategy_module._pending_results == 0
    assert strategy_module._final_q_notified == False



# Generated at 2022-06-21 07:32:30.209100
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_iter = MagicMock()
    test_iter._play = MagicMock()
    test_iter._play._connection_info = MagicMock()
    test_play_context = MagicMock()
    test_play_context._host = 'all'
    strategy_module = StrategyModule()
    strategy_module.add_tqm = MagicMock()
    
    
    set_module_args(dict(
       
    ))

    with pytest.raises(AnsibleExitJson) as exec_info:
        result = strategy_module.run(test_iter,test_play_context)
        result = strategy_module.run(test_iter,test_play_context)

    
    
    
    
    
    
    
    
    
    
    
    
    


# Generated at 2022-06-21 07:32:32.855576
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(
        tqm=None
    )


# Generated at 2022-06-21 07:32:41.721141
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # create an instance of the Ansible playbook
    pb = AnsiblePlaybook()
    # create an instance of the Ansible inventory
    inventory = pb.get_inventory()
    # create an instance of the Ansible variable manager, which will be passed to the constructor of strategy
    vmanager = VariableManager(loader=pb._loader, inventory=inventory, version_info=CLI.version_info(gitinfo=False))
    # create an instance of the Ansible loader, which will be passed to the constructor of strategy
    loader = DataLoader()
    # create an instance of the Ansible options, which will be passed to the constructor of strategy
    options = Options()
    # create an instance of the Ansible passwords, which will be passed to the constructor of strategy
    passwords = dict()
    # create an instance of the Ansible stdout callback
    callback = callbacks

# Generated at 2022-06-21 07:32:43.189494
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-21 07:32:46.545162
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Test StrategyModule"""
    strategy = StrategyModule(variable_manager=VariableManager())
    assert strategy != None

# Generated at 2022-06-21 07:32:50.412136
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # New object of class StrategyModule - Strategy set to linear
    s = StrategyModule()

    # Check strategy
    assert s._strategy == 'linear'



# Generated at 2022-06-21 07:33:00.815018
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(1, 1, 1, 1, 1, 1)
    assert module._tqm is not None
    assert module._variable_manager is not None
    assert module._loader is not None
    assert module._final_q is not None
    assert module._hosts_queue is not None
    assert module._result_q is not None
    assert module._step is not None
    assert module._hosts_cache is not None
    assert module._hosts_cache_all is not None

# Generated at 2022-06-21 07:34:49.698035
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    """
    StrategyModule#run is the linear strategy for running the play

    Test if we can queue the next task for all hosts, and
    wait for the queue to drain before moving on to the next task
    """

    # Configure the module object
    module = StrategyModule()
    module._tqm = TaskQueueManager

    # Configure the test case

# Generated at 2022-06-21 07:34:55.226176
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    s = StrategyModule(None, None, None, None, None)
    assert(isinstance (s.run(None, None), int))


# Generated at 2022-06-21 07:34:56.818569
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass
# Unit tests for class StrategyModule

# Generated at 2022-06-21 07:34:57.629045
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:34:59.030747
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # TODO
    pass


# Generated at 2022-06-21 07:35:06.968706
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    '''
    Unit test for method run of class StrategyModule
    '''
    # Input parameters for the method
    strategy_module = StrategyModule()
    iterator = iterator
    play_context = play_context

    # Return value of the method (if any)
    return_value = strategy_module.run(iterator, play_context)
    assert return_value == None


# Generated at 2022-06-21 07:35:18.729297
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    TQM = mock.Mock()
    loader = mock.Mock()
    variable_manager = mock.Mock()

    strategy = StrategyModule(TQM, display, loader, variable_manager)

    assert(isinstance(strategy, StrategyModule))
    assert(strategy._tqm == TQM)
    assert(strategy._display == display)
    assert(strategy._loader == loader)
    assert(strategy._variable_manager == variable_manager)
    assert(strategy.module_defaults == C.DEFAULT_MODULE_ARGS)
    assert(strategy._play_context == None)
    assert(strategy._callbacks == [])
    assert(strategy._async_notified == {})
    assert(strategy._async_poll == {})
   

# Generated at 2022-06-21 07:35:31.067392
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pb = PlaybookExecutor(
        playbooks=['/Users/bobschro/repos/ansible/test/sanity/integration/default/test_playbook.yml'],
        inventory=InventoryManager(loader=None, sources=['/Users/bobschro/repos/ansible/test/sanity/integration/default/hosts']),
        variable_manager=VariableManager(loader=None, inventory=InventoryManager(loader=None, sources=['/Users/bobschro/repos/ansible/test/sanity/integration/default/hosts'])),
        loader=DataLoader(),
        passwords={}
    )

# Generated at 2022-06-21 07:35:35.744230
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None

# Unit test to ensure that we can instantiate a StrategyModule object, then
# call the run() method on it and have it perform without errors

# Generated at 2022-06-21 07:35:41.614879
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, BaseStrategy)
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''
    This is the default interface for `ansible-playbook` to use for
    executing tasks and handlers. There is no reason why this
    interface should not be used for executing ad-hoc tasks and
    handlers, however other approaches exist for that purpose.
    '''
    # StrategyModule will not init if you do not pass _tqm
    try:
        StrategyModule.__init__(self)
    except:
        pass

# Generated at 2022-06-21 07:39:44.194241
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    iterator = Mock(spec=HostState, batch_size=10, hosts_left=['host'])
    play_context = Mock()
    hosts = Mock()
    strategy_module = StrategyModule(hosts)
    strategy_module.run(iterator, play_context)



# Generated at 2022-06-21 07:39:55.009761
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy._tqm is None
    assert strategy._inventory is None
    assert strategy._variable_manager is None
    assert strategy._loader is None
    assert strategy._shared_loader_obj is None
    assert strategy._final_q is None
    assert strategy._failq is None
    assert strategy._callbacks is None
    assert strategy._result_callbacks is None
    assert strategy._stats is None
    assert strategy._run_additional_callbacks is None
    assert strategy._notified_handlers is None
    assert strategy._step is None
    assert strategy._concurrency is None
    assert strategy._iterator is None
    assert strategy._last_host_check is None
    assert strategy._last_task_check is None
    assert strategy._last_function_check is None
    assert strategy._last_notified_check

# Generated at 2022-06-21 07:40:02.145882
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    play_context = PlayContext()
    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=DataLoader(), sources=''),
        variable_manager=VariableManager(),
        loader=DataLoader(),
    )
    strategy = StrategyModule(tqm)

    display.display("Testing constructor")

# Generated at 2022-06-21 07:40:10.941745
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    sut = StrategyModule()

    # Mock object without attribute run
    mclass = MagicMock(side_effect=AnsibleError('Test error case'))

    try:
        sut.run(mclass, MagicMock())
    except AnsibleError as e:
        assert msg == to_text(e)
