

# Generated at 2022-06-21 07:30:33.708749
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(tqm=DummyTQM()), StrategyModule)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:30:34.964260
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule()
    assert strategy_module.run() == 0


# Generated at 2022-06-21 07:30:36.504419
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module is not None



# Generated at 2022-06-21 07:30:47.897992
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    iter = Iterator(inventory, variable_manager)
    play = Play()
    play._variable_manager = variable_manager
    play._iterator = iter
    strategy = StrategyModule(tqm=None, play=play)
    strategy._set_hosts_cache(play)
    r = strategy.run(iter, play_context)
    assert r == 0


# Generated at 2022-06-21 07:31:01.328048
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #Mocking of class TQM to pass as first parameter to constructor of class StrategyModule
    class TQM():
        
        def __init__(self):
            self._failed_hosts = []
            self._unreachable_hosts = []
            self._stats = {}
            self._callbacks = {}
            self._terminated = False
            self._notified_handlers = set()
            self._workers = 10
            self._last_task_banner = None
            self._last_play = None
            self._last_task_type = None


        def cleanup(self):
            pass

        def _process_pending_results(self):
            pass

        def _wait_on_pending_results(self):
            pass

        def send_callback(self):
            pass


# Generated at 2022-06-21 07:31:03.195750
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.linear
    strategy = ansible.plugins.strategy.linear.StrategyModule('test', object)
    assert strategy is not None

# Generated at 2022-06-21 07:31:05.421082
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule(Tqm()) is not None)

# Generated at 2022-06-21 07:31:14.998808
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    #!/usr/bin/env python
    from __future__ import (absolute_import, division, print_function)
    __metaclass__ = type

    # save the original ImportModule
    original_import_module = ansible.module_utils.basic.AnsibleModule.import_module

    # import a module which we can mock
    module = ansible.module_utils.basic.AnsibleModule.import_module('test')

    # mock the basic module
    test_module = mock.MagicMock()
    test_module.return_value = module
    ansible.module_utils.basic.AnsibleModule.import_module = test_module

    from ansible.plugins.strategy.linear import StrategyModule

    # restore the ImportModule
    ansible.module_utils.basic.AnsibleModule.import_module = original

# Generated at 2022-06-21 07:31:24.860534
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Run method run of class StrategyModule with default args
    print("Unit test for method run of class StrategyModule")
    play = Play().load(dict(
                name = "Ansible Play 0",
                hosts = "all",
                gather_facts = "no",
                tasks = [
                  # Task 0
                  Task(dict(
                    name = "Task 0",
                    action = {
                      "__ansible_module__" : "setup"
                    }
                  ))
                ]
              ), variable_manager = VariableManager(), loader = DataLoader())
    tqm = None
    play_context = PlayContext()
    iterator = TaskIterator(tqm, play, play_context, players=100, variable_manager=VariableManager(), loader=DataLoader())
    strategy_module = StrategyModule()

# Generated at 2022-06-21 07:31:26.969531
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule()
    assert isinstance(module, StrategyModule)


# Generated at 2022-06-21 07:32:11.511695
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    loader = DictDataLoader({
        "foo.yml": """
        ---
        - hosts: all
          gather_facts: no
          connection: local
          tasks: []
        """,
    })

    inventory = InventoryManager(loader=loader, sources=["foo.yml"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    # Passwords=None -> prompts for password, PrivateKeyFile=None -> (not specified)
    # Credentials=None -> no credentials needed
    tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        passwords=None,
        stdout_callback=None,
        run_tree=False,
    )

# Generated at 2022-06-21 07:32:23.723981
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MockTQM()
    block_count = 1
    action = 'ping'
    role = 'common'
    play = MockPlay()
    play._play_context = MockPlay
    host = MockHost(block_count, play)
    host.set_name('hostname')
    tqm._hosts_cache = [host]
    loader = MockLoader()
    variable_manager = MockVariableManager()
    host_match = False
    delegate_to = ''
    delegate_facts = False
    strategy = StrategyModule(tqm, variable_manager, loader)
    assert strategy._tqm._hosts_cache is not None
    mock_task = MockTask(action, role, play)
    assert mock_task._role is None
    assert mock_task._play is None
    mock_task = Mock

# Generated at 2022-06-21 07:32:27.054551
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule()
    assert strategy_module.run() == None

# Generated at 2022-06-21 07:32:37.966796
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  inventory_file = 'test/inventory/ansible_hosts'
  test_file = 'test/test_strategy_module.py'
  args = ['-i', inventory_file, test_file]
  mixer = Mixer(args=args)
  options = mixer.options
  loader = DataLoader()
  variable_manager = VariableManager(loader=loader, options=options)
  play_context = PlayContext()
  play = Play().load(test_file, variable_manager, loader)
  tqm = TaskQueueManager(
    inventory=InventoryManager(loader=loader, sources=['test/inventory/ansible_hosts']),
    variable_manager=variable_manager,
    loader=loader,
    options=options,
    passwords={},
  )
  strategy_module = StrategyModule(tqm)


# Generated at 2022-06-21 07:32:45.769859
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(
        tqm = '''
        tqm
        ''',
        connection_info= '''
        connection_info
        ''',
        disable_pyu_caching = '''
        disable_pyu_caching
        ''',
        loader = '''
        loader
        ''',
        variable_manager = '''
        variable_manager
        ''',
        shared_loader_obj = '''
        shared_loader_obj
        ''',
        run_additional_callbacks = '''
        run_additional_callbacks
        ''',
        final_q = '''
        final_q
        ''',
        strategy = '''
        strategy
        ''',
        host_hash_filename = '''
        host_hash_filename
        '''
    )
   

# Generated at 2022-06-21 07:32:54.394371
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    max_fail_percentage = None
    batch = None
    final_q = None
    handlers = None
    rescue_q = None
    rescue = None
    always_q = None
    always = None
    fail_state = None
    fail_state_q = None
    pending_results = None
    noop_q = None
    strategy = StrategyModule(max_fail_percentage, batch, final_q, handlers, rescue_q, rescue, always_q, always, fail_state, fail_state_q, pending_results, noop_q)
    play = None
    play_context = None
    iterator = None
    strategy.run(play, play_context, iterator)

# Generated at 2022-06-21 07:33:05.248249
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # Initial test environment
    # Create a mock object from ansible.plugins.loader.action_loader.ActionModuleLoader
    mock_new_loader = mock.Mock()

    # Create a mock object from ansible.plugins.cliconf.cfx.CliConf
    mock_new_cli = mock.Mock()

    # Create a mock object from ansible.plugins.connection.network_cli.Connection
    mock_new_CliConf = mock.Mock()

    # Create a mock object from ansible.plugins.action.network_cli.ActionModule
    mock_new_ActionModule = mock.Mock()

    # Create a mock object from ansible_collections.cisco.asa.plugins.module_utils.network.asa.asa.get_capabilities
    mock_get_capabilities = mock.Mock()
    mock_

# Generated at 2022-06-21 07:33:11.737126
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for constructor of class StrategyModule
    '''

    # TODO: This test should be completed
    # test_host = random.choice(['host1', 'host2', 'host3'])

    StrategyModule(loader=None, tqm=None, options=None, variable_manager=None)

# Generated at 2022-06-21 07:33:17.137568
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    mock_iterator = Mock()
    mock_play_context = Mock()
    s = StrategyModule(Mock())
    assert s.run(mock_iterator, mock_play_context) == None

# Generated at 2022-06-21 07:33:18.648323
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-21 07:34:59.560316
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
	# Run method run of class StrategyModule
	pass


# Generated at 2022-06-21 07:35:10.953337
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mock_tqm = mock.Mock()
    mock_tqm._terminated = False
    mock_tqm._failed_hosts = {}
    mock_tqm._unreachable_hosts = {}
    mock_tqm._stats = mock.Mock()

    mock_loader = mock.Mock()
    mock_inventory = mock.Mock()
    mock_variable_manager = mock.Mock()
    sm = StrategyModule(tqm=mock_tqm, loader=mock_loader, inventory=mock_inventory, variable_manager=mock_variable_manager, shared_loader_obj=False)

    assert sm._tqm is mock_tqm
    assert sm._loader is mock_loader
    assert sm._inventory is mock_inventory
    assert sm._variable_manager is mock

# Generated at 2022-06-21 07:35:16.811414
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    '''
    Test function for method run of class StrategyModule
    '''
    my_StrategyModule = StrategyModule(
        loader, tqm, variables,
        all_vars, host_list,
        play)
    my_StrategyModule.run(iterator, play_context)


# Generated at 2022-06-21 07:35:27.831105
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None, None)
    # Default values for private variables
    assert strategy_module.__name == 'linear'
    assert strategy_module.__hosts_cache == {}
    assert strategy_module.__hosts_cache_all == {}
    assert strategy_module.__noop_task == None
    assert strategy_module.__workers_count == 5
    assert strategy_module.__pending_results == 0
    assert strategy_module.__blocked_hosts == {}


# Generated at 2022-06-21 07:35:31.896048
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("Testing run of class StrategyModule")
    # TODO: Test run of class StrategyModule here
    pass


# Generated at 2022-06-21 07:35:41.792500
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    _tqm = MagicMock()
    strategy = StrategyModule(_tqm)
    strategy._tqm._terminated = False
    strategy.get_hosts_left = MagicMock(return_value=[MagicMock()])
    strategy._set_hosts_cache = MagicMock()
    strategy._get_next_task_lockstep = MagicMock(return_value=[(MagicMock(), MagicMock())])
    strategy._tqm.send_callback = MagicMock()
    strategy._tqm._workers.append(MagicMock())
    strategy._tqm._failed

# Generated at 2022-06-21 07:35:53.275851
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.utils.boolean import boolean
    from ansible.executor import task_queue_manager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import action_loader
    from ansible.errors import AnsibleError, AnsibleParserError, AnsibleUndefinedVariable
    from ansible.playbook.included_file import IncludedFile
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars_v2 import Host

# Generated at 2022-06-21 07:35:58.064260
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TaskQueueManager()
    assert isinstance(tqm, TaskQueueManager)
    strategy = StrategyModule(tqm)
    assert isinstance(strategy, StrategyModule)


# Generated at 2022-06-21 07:35:59.534430
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass



# Generated at 2022-06-21 07:36:02.364122
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm=None, variables={'item': '1'}, loader=None, play_context={}, shared_loader_obj=None, strategy='linear')

    assert module

    module.run(iterator=None, play_context=None)

# Generated at 2022-06-21 07:39:46.348469
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert None != sm

# Generated at 2022-06-21 07:39:48.023090
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    utility method which tests the constructor of class StrategyModule
    '''
    module = StrategyModule()
    assert module is not None

# Generated at 2022-06-21 07:39:48.841352
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:39:52.468942
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

#TODO: implement test_StrategyModule_get_hosts_remaining

# Generated at 2022-06-21 07:40:01.291828
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock strategy module
    strategy_module = StrategyModule()
    # Create a mock task
    task = Task()
    # Create a mock play_context
    play_context = PlayContext()
    # Create a mock iterator
    iterator = PlayIterator()
    # Test return value if strategy_module._tqm._terminated is true
    strategy_module._tqm._terminated = True
    assert strategy_module.run(iterator, play_context) == strategy_module._tqm.RUN_OK
    strategy_module._tqm._terminated = False
    # Test return value if strategy_module._tqm is not RUN_OK
    strategy_module._tqm = "test"
    assert strategy_module.run(iterator, play_context) == strategy_module._tqm

