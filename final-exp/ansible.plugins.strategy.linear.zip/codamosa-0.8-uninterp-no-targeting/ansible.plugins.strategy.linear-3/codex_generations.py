

# Generated at 2022-06-21 07:30:33.292888
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    p = StrategyModule()
    p.run(play_context,iterator )
# Stub for method run of class StrategyModule

# Generated at 2022-06-21 07:30:45.387116
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    #test 0
    from ansible.config.manager import ConfigManager
    from ansible.errors import AnsibleError
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars
    from ansible.vars.clean import strip_internal_keys
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.reserved import merge_hash
    from ansible.vars.clean import strip_internal_keys
    from ansible.vars.hostvars import HostVars

# Generated at 2022-06-21 07:30:50.991900
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    ansible_module_path = "/usr/local/lib/python3.4/dist-packages/ansible/plugins/strategy/linear.py"
    abs_path = os.path.abspath(__file__)
    directory, bash_file_name = os.path.split(abs_path)
    ansible_module_directory, ansible_module_file_name = os.path.split(ansible_module_path)
    test_file_name = "test_" + ansible_module_file_name
    test_file_path = directory + "/" + test_file_name
    os.system("cp " + ansible_module_path + " " + test_file_path)

    ansible_module = importlib.machinery.SourceFileLoader("test_linear", test_file_path)
    test

# Generated at 2022-06-21 07:30:59.075960
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible import context
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager, _init_global_debugger
    from ansible.plugins.loader import callback_loader, connection_loader, lookup_loader

    inventory = InventoryManager(loader=DataLoader(), sources=[])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    play_context = PlayContext()

# Generated at 2022-06-21 07:31:12.361623
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a fake ansible.playbook.PlaybookExecutor.run
    fake_run = MagicMock()

    # Create a fake constructor for class ansible.playbook.PlaybookExecutor
    def fake_PlaybookExecutor(*args, **kwargs):
        # Return a fake instance of ansible.playbook.PlaybookExecutor
        return_value = MagicMock(spec=ansible.playbook.PlaybookExecutor)
        return_value.run = fake_run
        return return_value

    # Create a instance of class ansible.playbook.playbook.Play with a fake
    # constructor for class ansible.playbook.PlaybookExecutor
    play = MagicMock(spec=ansible.playbook.play.Play)
    play.__class__.__name__ = 'Play'
    play.__class__

# Generated at 2022-06-21 07:31:23.742048
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # the input to run().
    iterator = object()
    play_context = object()
    # how to send commands to the host
    connection = Connection(object())
    # the options used to create the host
    options = Options()
    # the host
    host = Host(object(), connection, options)
    # the callback module
    callback = CallbackModule()
    # the loader module
    loader = PluginLoader([
        'strategy',
        'strategy_plugins',
    ])

    strategy = loader.get(
        'linear',
        cls=StrategyModule,
        tqm=TaskQueueManager(
            host_list=[
                host,
            ],
            callback=callback,
            stats=AggregateStats(),
        ),
    )

    assert strategy

# Generated at 2022-06-21 07:31:34.731028
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    '''
    Unit test for StrategyModule.run
    '''
    import ansible.plugins.loader as loader_module
    import ansible.plugins.action as action_module
    import ansible.plugins.connection as connection_module
    import ansible.plugins.strategy as strategy_module
    import ansible.playbook.play_context as play_context

    loader_plugin = loader_module.ActionLoader()
    action_plugins = loader_plugin.all()
    for action_plugin in action_plugins:
        action_module.ActionBase.get_by_name(action_plugin)

    class FakedTask:
        def __init__(self, action, args={}):
            self.action = action
            self.args = args

    class FakedPlayContext:
        def __init__(self):
            self.forks

# Generated at 2022-06-21 07:31:35.635823
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-21 07:31:36.609807
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-21 07:31:39.071604
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass
################################################################################
# This is the new classes that were added in the refactor
################################################################################



# Generated at 2022-06-21 07:32:18.339247
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    SUT = StrategyModule()
    assert 0 == SUT.run(None, None)

# Generated at 2022-06-21 07:32:32.499582
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # load test json data from json file
    test_data = load_json_data('success')

    # create a StrategyModule object
    strategyModule_obj = StrategyModule(loader=None, tqm=None, options=None, var_manager=None, passwords=None)

    # create a iterator object
    play_context = PlayContext(play=None, options=None, variable_manager=None, all_vars=dict())
    iterator = iterator.HostIterator(inventory=None, play=None, play_context=play_context, variable_manager=None, all_vars=dict(), options=None, passwords=None)

    # run the test
    results = strategyModule_obj.run(iterator, play_context)

    # assert test results
    assert results == 0



# Generated at 2022-06-21 07:32:34.891850
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # test_object = StrategyModule([])
    # assert test_object.run is not None
    pass

# Implementing MetaScript class

# Generated at 2022-06-21 07:32:36.194567
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-21 07:32:44.826550
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module = StrategyModule()
    import ansible_collections.sstar.automation2.plugins.strategies.linear as linear_strategy
    module._tqm = linear_strategy.LinearStrategy('test')
    module._tqm._terminated = False
    module._tqm._failed_hosts = {}
    module._tqm.RUN_OK = 0
    module._tqm.RUN_UNKNOWN_ERROR = -1
    module._tqm.threads_started = {'test': 'test'}
    import ansible_collections.sstar.automation2.plugins.strategies.lib as linear_strategy_lib
    linear_strategy_lib.module = module
    module._tqm.send_callback = linear_strategy_lib.send_callback

# Generated at 2022-06-21 07:32:52.637777
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test for missing inventory_manager and variable_manager
    try:
        StrategyModule()
        assert False
    except:
        assert True

    # Test for constructor with inventory_manager and variable_manager
    try:
        loader = DataLoader()
        inventory = Inventory(loader, [])
        variable_manager = VariableManager(loader, inventory, None)
        StrategyModule(inventory_manager=inventory, variable_manager=variable_manager)
    except:
        assert False


# Generated at 2022-06-21 07:33:04.797582
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule()
    strategy_module._tqm.send_callback = MagicMock()
    strategy_module._step = False
    strategy_module._next_task_lockstep = []
    strategy_module._blocked_hosts = {}
    strategy_module._pending_results = 0
    strategy_module._tqm._failed_hosts = {}
    strategy_module._tqm._terminated = False

    # create test object
    iterator = MagicMock()
    iterator._play = MagicMock()
    iterator._play.batch_size = 8
    iterator._play.max_fail_percentage = 10
    iterator.is_failed = MagicMock(return_value=False)
    iterator.increment = MagicMock()
    iterator.add_tasks = MagicMock()

# Generated at 2022-06-21 07:33:08.460592
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule( 'inventory', 'variable_manager', 'loader', 'options', 'passwords', 'stdout_callback')
    return strategy_module

# Generated at 2022-06-21 07:33:13.253593
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Test if the constructor of the class works without issues
    >>> StrategyModule(tqm, variable_manager, loader)
    <ansible.executor.task_queue_manager.StrategyModule object at 0x7f7e7fefd550>
    """
    pass


# Generated at 2022-06-21 07:33:25.061268
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    host1 = Host("127.0.0.0")
    host_list = [host1]
    task1 = Task()
    task2 = Task()
    tasks = [task1, task2]
    play_context = PlayContext()
    block1 = Block()
    block2 = Block()

    iterator = [task1, task2]

    module = MagicMock()
    module.run.return_value = 1

    strategy = StrategyModule(module)

    strategy.run(iterator, play_context)
    assert(strategy.run(iterator, play_context) == 1)

# Generated at 2022-06-21 07:35:20.081539
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    x = [1, 4, 5]
    y = [1, 3, 5, 6]
    #
    # V1:
    #
    # >>> x = [3, 4, 6, 8, 10]
    # >>> y = [1, 2, 3, 5, 6, 7, 9, 10]
    #
    # >>> for i in [1, 3, 5]:
    # ...     for j in x:
    # ...         if j == i:
    # ...             print i, j
    # ...
    # 1 3
    # 3 3
    # 5 6
    #
    # >>> for i in y:
    # ...     for j in x:
    # ...         if j == i:
    # ...             print i, j
    # ...
    # 3 3
    # 5 6
    # 6

# Generated at 2022-06-21 07:35:20.932955
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert True == True


# Generated at 2022-06-21 07:35:32.144306
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=None, sources=''),
        variable_manager=VariableManager(),
        loader=DataLoader(),
        options=Options(),
        passwords={},
        stdout_callback=None,
    )
    strategy = StrategyModule(tqm)
    assert isinstance(strategy, StrategyModule)
    assert isinstance(strategy, BaseStrategy)
    assert strategy._tqm is tqm
    assert strategy._blocked_hosts == {}
    assert strategy._last_hosts == []
    assert strategy._last_results == []
    assert strategy._final_q is None
    assert strategy._pending_results == 0
    assert strategy._hosts_cache is None
    assert strategy._hosts_cache_all is None
    assert strategy._iterator is None


# Generated at 2022-06-21 07:35:39.563851
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategyModule = StrategyModule(tqm=None,
                                    strategy='linear',
                                    loader=None,
                                    variable_manager=None,
                                    host_list=None)
    strategyModule._set_hosts_cache(iterator._play)
    strategyModule._tqm.RUN_UNKNOWN_ERROR
    strategyModule._tqm.RUN_OK
    strategyModule._tqm.RUN_FAILED_BREAK_PLAY
    

# Generated at 2022-06-21 07:35:43.014681
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy = _get_strategy()
    r = strategy.run(iterator=None, play_context=None)
    assert r == 0


# Generated at 2022-06-21 07:35:46.680414
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule('host')
    except TypeError as e:
        print(e)
        raise Exception


# Generated at 2022-06-21 07:35:52.347401
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    tqm = Tqm(None)
    strategy = StrategyModule('test', tqm)
    strategy._tqm._terminated = True
    iterator = HostIterator(
        inventory=Inventory("localhost"),
        variable_manager=VariableManager(loader=None),
        play=Play(),
        play_context=PlayContext()
    )
    result = strategy.run(iterator, PlayContext())
    assert result == tqm.RUN_OK


# Generated at 2022-06-21 07:35:53.693148
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule()


# Generated at 2022-06-21 07:35:55.102822
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:35:56.553292
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:39:46.081899
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    l = loader.Fake_loader()
    t = templar.Fake_templar(loader=l)
    st = StrategyModule(loader=l, tqm=None, templar=t)
    iterator = Fake_iterator()
    play_context = Fake_play_context()
    assert st.run(iterator, play_context) == st._tqm.RUN_OK

# Generated at 2022-06-21 07:39:53.763436
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Using mock to replace ansible.plugins.loader.all
    with patch("ansible.plugins.loader.all", MagicMock(return_value={"action": MagicMock()})):
        # Using mock to replace ansible.playbook.helpers.load_list_of_blocks
        with patch("ansible.playbook.helpers.load_list_of_blocks", return_value=[MagicMock()]):
            # Using mock to replace ansible.plugins.loader.action_loader.get
            with patch("ansible.plugins.loader.action_loader.get", side_effect=KeyError):
                with patch("ansible.playbook.play_context.PlayContext.set_task_and_variable_override", MagicMock(return_value=None)):
                    base_strategy = StrategyBase()
                    tqm

# Generated at 2022-06-21 07:39:54.778492
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-21 07:40:02.076334
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  import ansible.utils.module_docs_fragments
  from ansible.modules.packaging.os import yum
  from ansible.module_utils.facts import is_local_address

  localhost = Host("127.0.0.1")
  localhost.vars = dict(ansible_connection=dict(type="local", local_address="127.0.0.1"))

  localhost2 = Host("127.0.0.1")
  localhost2.vars = dict(ansible_connection=dict(type="local", local_address="127.0.0.1"))

  test_module = yum.YumModule(is_local_address("127.0.0.1"))
  test_module_action = ActionModule(is_local_address("127.0.0.1"))
  test