

# Generated at 2022-06-21 07:30:48.246583
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import os
    import tempfile
    import shutil
    import ansible.utils.module_docs as module_docs
    import ansible.playbook.play_context as play_context
    import ansible.playbook.play as play

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.strategy.linear import StrategyModule as linearStrategy

    from ansible.utils.color import stringc
    from ansible.errors import AnsibleError, AnsibleOptionsError, AnsibleParserError

# Generated at 2022-06-21 07:30:59.401881
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(
        tqm = None,
        strategy = 'free',
        host_list = [],
        loader = DictDataLoader(),
        variables = dict(a=1,b=2),
        shared_loader_obj = False,
        play_context = PlayContext(),
        variable_manager = VariableManager(),
        loader_cache = dict(),
        hosts_cache = dict(),
        hosts_cache_all = dict(),
        verbosity = 1
        )
    assert(not isinstance(strategy, StrategyModule))

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:31:01.062382
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module = StrategyModule()
    module.run(iterator, play_context)


# Generated at 2022-06-21 07:31:02.628414
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(), StrategyModule)

# Generated at 2022-06-21 07:31:13.923850
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    '''
    Unit test for constructor of class StrategyModule
    '''

    tqm = TaskQueueManager()
    test_variable_manager = VariableManager()
    test_loader = DataLoader()
    options = Options()
    test_inventory = Inventory(loader=test_loader, variable_manager=test_variable_manager, host_list='tests/test_strategy_linear_inventory.yml')
    test_strategy_module = StrategyModule(tqm, test_inventory, options, test_variable_manager, test_loader)

    assert tqm == test_strategy_module._tqm
    assert options == test_strategy_module._options
    assert test_inventory == test_strategy_module._inventory
    assert test_loader == test_strategy_module._loader
    assert test_variable_manager == test_str

# Generated at 2022-06-21 07:31:25.402619
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-21 07:31:37.507443
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    TQM = MagicMock()
    TQM._terminated = False

    iterator = MagicMock()
    iterator._play = MagicMock()
    iterator._play.handlers = []
    iterator._play.cleanup_tasks = []
    iterator._play.max_fail_percentage = None

    play_context = MagicMock()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.verbosity = 1
    play_context.check_mode = False
    play_context.any_errors_fatal = True

    module = StrategyModule(TQM)
    TQM.get_active_connections = MagicMock(side_effect=NotImplementedError)
    module._set_hosts_cache = MagicMock()
    module

# Generated at 2022-06-21 07:31:40.198875
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = None
        strategy = StrategyModule(tqm)
        assert strategy != None
    except:
        assert False


# Generated at 2022-06-21 07:31:51.504473
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Creates an instance of the StrategyModule class
    try:
        StrategyModule()
    except:
        print("Test 1: StrategyModule() failed")
        return

    # Creates an instance of the StrategyModule class and checks if it is the correct type
    try:
        module = StrategyModule()
        assert isinstance(module, StrategyModule)
    except:
        print("Test 2: StrategyModule() failed")
        return

    # Creates an instance of the StrategyModule class, sets _tqm to None,
    # and checks if it is the correct type
    try:
        module = StrategyModule()
        module._tqm = None
        assert isinstance(module, StrategyModule)
    except:
        print("Test 3: StrategyModule() failed")
        return

    print("Test 1 - 3: StrategyModule() passed")

#

# Generated at 2022-06-21 07:32:02.771700
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' test_StrategyModule.py: Unit test for constructor of class StrategyModule '''

    # create a dummy AnsibleTowerJobTemplate object
    tower_job_template = AnsibleTowerJobTemplate()

    # create a dummy AnsibleTowerJobTemplateCredential object
    tower_job_template_credential = AnsibleTowerJobTemplateCredential()

    # create a dummy AnsibleTowerJobCredential object
    tower_job_credential = AnsibleTowerJobCredential()

    # create a dummy AnsibleTowerJob object
    tower_job = AnsibleTowerJob()

    # create a dummy Lock object
    lock = Lock()

    # create a dummy AnsibleTowerInventoryUpdate object
    tower_inventory_update = AnsibleTowerInventoryUpdate()

    # create a dummy AnsibleTower

# Generated at 2022-06-21 07:32:47.172502
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module

# Generated at 2022-06-21 07:32:48.370522
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-21 07:32:53.186085
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TaskQueueManager(connection_loaders=['paramiko'])
    tqm._stdout_callback = 'yaml'
    tqm._terminated = False
    strategy = None
    try:
        strategy = StrategyModule(tqm)
        print(strategy)
    finally:
        if strategy:
            strategy.cleanup()

# Generated at 2022-06-21 07:33:04.084454
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    StrategyModule test case
    '''

    # Create the object
    p = StrategyModule(
        tqm=None,
        run_additional_callbacks=False,
        run_tree=False,
        stdout_callback=None
    )

    assert p.tqm is None
    assert not p.run_additional_callbacks
    assert not p.run_tree
    assert p.stdout_callback is None
    assert p._blocked_hosts == {}
    assert p._pending_results == 0
    assert p._final_q is None
    assert p._tqm.run_state == 'STRATEGY_IN_PROGRESS'

# Generated at 2022-06-21 07:33:15.625981
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyModule
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.utils.vars import combine

# Generated at 2022-06-21 07:33:20.953103
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #initializing the StrategyModule object
    obj = StrategyModule()
    assert(isinstance(obj, StrategyModule))
    assert(obj.get_option('batch_size') == 1)
    assert(obj.name == 'linear')


# Generated at 2022-06-21 07:33:22.973253
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # StrategyModule.run(iterator=None, play_context=None)
    return None


# Generated at 2022-06-21 07:33:34.617929
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    playbook = Playbook()
    tqm = TaskQueueManager()
    hosts = Hosts()
    loader = None
    variables = VariableManager()
    inventory = Inventory(loader=loader, host_list=['localhost'])
    
    def get_vars(play=None, host=None, task=None, _hosts=None, _hosts_all=None):
        return variables.get_vars(play=play, host=host, task=task, _hosts=_hosts, _hosts_all=_hosts_all)

    def get_hosts_left(iterator=None):
        return inventory.get_hosts(iterator._play.hosts)

    StrategyModule.get_vars = get_vars
    StrategyModule.get_hosts_left = get_hosts_left

    strategy = Strategy

# Generated at 2022-06-21 07:33:45.768001
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    args = dict(
        host_list=['HOST_name'],
        module_path=['MOD_PATH'],
        forks=1,
        timeout=1000,
        remote_user='user_name',
        remote_pass='a',
        callbacks='a',
        stats='a',
        become=False,
        verbosity=0,
        check=False,
        diff=False
    )
    options = Options(**args)
    loader = DataLoader()
    passwords = dict(conn_pass='password')
    inventory = Inventory(loader=loader, variable_manager=None, host_list=['HOST_name'])

# Generated at 2022-06-21 07:33:46.671490
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass



# Generated at 2022-06-21 07:35:55.635303
# Unit test for method run of class StrategyModule

# Generated at 2022-06-21 07:35:58.449375
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
	mod = StrategyModule()
	mod.run("iterator", "play_context")


# Generated at 2022-06-21 07:36:00.039190
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    module = StrategyModule()
    assert module is not None


# Generated at 2022-06-21 07:36:12.929281
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-21 07:36:24.001706
# Unit test for method run of class StrategyModule

# Generated at 2022-06-21 07:36:35.216789
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module = AnsibleModule(
        argument_spec=dict(
            hosts=dict(type='list', required=True),
            play_context=dict(type='str', required=True),
            iterator=dict(type='str', required=True),
        ),
        supports_check_mode=False,
    )

    p = module.params
    hosts = p["hosts"]
    play_context = p["play_context"]
    iterator = p["iterator"]

    # Create mock object
    iterator_obj = Mock(Iterator)
    play_context_obj = Mock(PlayContext)
    hosts_obj = Mock(Host)
    hosts_obj.get_name = Mock(return_value="host_name")

    # Populate iterator

# Generated at 2022-06-21 07:36:44.339703
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        #test constructor with all parameters
        tqm = TaskQueueManager(
            inventory=InventoryManager(loader=None),
            variable_manager=VariableManager(),
            loader=None,
            options=Options(),
            passwords={},
            stdout_callback='',
            run_tree=True,
        )
        strategy = StrategyModule(tqm)
    except Exception as e:
        raise AssertionError('Failed to instantiate StrategyModule object with all parameters provided: {0}'.format(e))
    try:
        #test constructor with mandatory parameters only
        strategy = StrategyModule(tqm)
    except Exception as e:
        raise AssertionError('Failed to instantiate StrategyModule object with only mandatory parameters provided: {0}'.format(e))

# Generated at 2022-06-21 07:36:54.497566
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Creating a host and setting its name
    host_test = Host()
    host_test.name = "--test-host--"
    # Creating a TaskResult
    task_test = TaskResult(host_test, "fake", "fake")
    # Creating a task.
    task_test_2 = Task()
    task_test_2.action = "fake"
    # Creating a AttributeDict object
    options_test = AttributeDict()
    # Creating a loader object
    loader_test = DataLoader()
    # Creating a variable manager.
    variable_manager_test = VariableManager()
    # Creating an iterator
    test_iterator = HostIterator()
    # Creating a TQM object

# Generated at 2022-06-21 07:36:55.442151
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:36:59.058450
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(Tqm())
    assert isinstance(strategy, StrategyModule)
    strategy.cleanup()
