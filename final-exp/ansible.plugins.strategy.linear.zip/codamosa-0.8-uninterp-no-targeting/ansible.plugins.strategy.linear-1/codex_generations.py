

# Generated at 2022-06-21 07:30:34.926220
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm=None)
    assert isinstance(module, StrategyModule)


# Generated at 2022-06-21 07:30:48.661660
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategyModule = StrategyModule()
    strategyModule._variable_manager = VariableManager()
    strategyModule._queue = TaskQueueManger()
    strategyModule._tqm = TaskQueueManger()
    strategyModule._variable_manager._vars_cache = dict()
    strategyModule._variable_manager._vars_cache['junk'] = 'junk'
    strategyModule._result_q = SetQueue()
    strategyModule._blocked_hosts = dict()
    strategyModule._pending_results = 0
    strategyModule._workers = dict()
    strategyModule._loader = DataLoader()
    strategyModule._inventory = Inventory()
    iterator = HostIterator()
    play_context = PlayContext()
    try:
        strategyModule.run(iterator, play_context)
    except:
        pass


# Generated at 2022-06-21 07:30:49.737936
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-21 07:31:01.615628
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    hosts = get_hosts(hosts)
    strategy = get_strategy(hosts, 'linear')

    # Unit test: normal execution
    iterator = get_iterator(hosts)
    play_context = get_play_context()
    result = strategy.run(iterator, play_context)
    assert result == 0

    # Unit test: Exception during normal execution
    iterator = get_iterator(hosts)
    play_context = get_play_context()
    result = strategy.run(iterator, play_context)
    assert result == 0


## ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# TODO: Impelement class TestModule
# class TestModule(object):
#     def __init__(self):
#         pass

# Generated at 2022-06-21 07:31:13.522511
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule(0, 1, 2, 3)

    assert(test._play_context is not None)
    assert(test._iterator is not None)
    assert(test._variable_manager is not None)
    assert(test._all_vars is not None)
    assert(test._hosts_cache is not None)
    assert(test._hosts_cache_all is not None)
    assert(test._tqm is not None)
    assert(test._loader is not None)
    assert(test._blocked_hosts is not None)
    assert(test._final_q is not None)
    assert(test._last_hosts is not None)
    assert(test._step is not None)
    assert(test._step_num is not None)
    assert(test._pending_results is not None)

# Generated at 2022-06-21 07:31:24.274381
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    host1 = MagicMock()
    host1.name = 'host1'
    host2 = MagicMock()
    host2.name = 'host2'
    host3 = MagicMock()
    host3.name = 'host3'

    play1 = MagicMock()
    play1.name = 'play1'
    play2 = MagicMock()
    play2.name = 'play2'

    block1 = MagicMock()
    block1.name = 'block1'
    block2 = MagicMock()
    block2.name = 'block2'
    block3 = MagicMock()
    block3.name = 'block3'
    block4 = MagicMock()
    block4.name = 'block4'
    block5 = MagicMock()
    block5.name = 'block5'

# Generated at 2022-06-21 07:31:28.896311
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule(tqm=None)
    strategy_module.run(iterator=None, play_context=None) # TODO: not defined
    pass

# Class WorkerExit

# Generated at 2022-06-21 07:31:31.981566
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_strategy = StrategyModule()
    assert isinstance(my_strategy, StrategyModule)


# Generated at 2022-06-21 07:31:35.206269
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # call the constructor
    strategy_module = StrategyModule()
    assert strategy_module is not None

# Unit test to check attribute initialization of class StrategyModule

# Generated at 2022-06-21 07:31:40.199015
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' test_StrategyModule unit test

    >>> strategy = StrategyModule(tqm=None, hosts_cache=None)
    >>> strategy.name
    'linear'
    '''
    return

if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-21 07:32:21.938139
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(), StrategyModule)



# Generated at 2022-06-21 07:32:23.522460
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:32:36.035103
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test class constructor:
    AnsibleStrategy.StrategyModule
    '''

    class TestModuleClass(object):
        '''
        Fake module class for testing
        '''
        pass

    module_loader = StrateLoader()
    module_loader.exception = None
    module_loader.module_name = 'test_name'
    module_loader.path_info = '/test/path'

    test_module = TestModuleClass()
    test_module.HAS_RUN = False
    test_module.RUN_TASK_COUNT = 0
    test_module.HAS_CLEANUP = False
    test_module.HAS_SETUP = False
    test_module.HAS_EXIT_JSON = False
    test_module.HAS_EXIT_JSON = False


# Generated at 2022-06-21 07:32:41.169115
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, object)

    assert StrategyModule.__doc__ is not None

    assert StrategyModule.__init__.__doc__ is not None

    assert not StrategyModule.__init__.__defaults__

    assert StrategyModule.run.__doc__ is not None

    assert not StrategyModule.run.__defaults__


# unit test for StrategyModule

# Generated at 2022-06-21 07:32:44.672208
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(TQM, PLAYBOOK)

    assert strategy.get_name() == 'Linear'


# Generated at 2022-06-21 07:32:52.917780
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module = AnsibleModule(
        argument_spec = dict(
            batch_size = dict(required=False, type='int', default=50),
            any_errors_fatal = dict(required=False, type='bool', default=False),
            max_fail_percentage = dict(required=False, type='int')
        ),
        supports_check_mode=True
    )
    args = dict(
        batch_size = 50,
        any_errors_fatal = False,
        max_fail_percentage = None
    )
    result = dict(
        changed=False,
        original_message='',
        message=''
    )

    playbook_path = os.path.join(DATA_PATH, 'playbook_graph.yml')

# Generated at 2022-06-21 07:33:04.908386
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    playbook_class = Playbook()
    playbook_data = {}
    playbook_class._entries = []
    tqm_class = TaskQueueManager(None, None, 'ansible', playbook_class)
    host_manager_class = HostManager()

    host_vars = {'ansible_network_os': 'ios'}
    host_class = Host(name="Bogie")
    host_class.vars = host_vars
    allgroup_vars_entries = {}
    host_class.groups = ['all']
    host_manager_class._groups = ['all']
    allgroup_class = Group('all')
    allgroup_class._vars = {'ansible_user': 'ansible', 'ansible_password': 'ansible_pass'}

# Generated at 2022-06-21 07:33:07.377763
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    StrategyModule.run(iterator, play_context)


# Generated at 2022-06-21 07:33:17.355348
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test vars
    class Object(object):
        pass
    tqm = Object()
    tqm.hostvars = {}
    tqm.inventory = Object()
    tqm.inventory.get_hosts = lambda: []
    tqm.inventory.get_host_variable = lambda x,y: None
    tqm.inventory.get_host_variables = lambda x: []
    tqm.variable_manager = Object()
    tqm.variable_manager.__getitem__ = lambda x: {}
    tqm.run_handlers = False
    tqm.load_callbacks = False
    tqm.stats = Object()
    tqm.stats.__getitem__ = lambda x: {}
    tqm.run_handlers = False

# Generated at 2022-06-21 07:33:18.877698
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()


# Generated at 2022-06-21 07:35:03.385940
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-21 07:35:10.390728
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # test method run of class StrategyModule
    # Create instance of class StrategyModule
    s = StrategyModule(
        tqm=None,
        strategy='linear',
        host_list=[],
        module_handlers=None,
        play_context=None,
        loader=None,
        variable_manager=None,
        shared_loader_obj=None,
        final_q=None
    )
    assert s
    # Call method run of class StrategyModule
    assert s.run(iterator=None, play_context=None) == 0


# Generated at 2022-06-21 07:35:20.035838
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TaskQueueManager()
    t = StrategyModule(tqm)
    assert t.name == 'linear'
    assert t.get_hosts_left([]) == []
    assert t.get_next_task_lockstep([], []) == []
    assert t.get_next_task_for_host([], []) == []
    assert t._tqm == tqm
    assert t._tqm.options.get_option(constants.STRATEGY) == 'linear'
    assert t._batches == t._tqm.batches
    assert t._blocked_hosts[0] == {}
    assert t._pending_results == 0
    assert t._failed_hosts[0] == {}
    assert t._workers_done_queue[0] == {}
    assert t._

# Generated at 2022-06-21 07:35:31.599189
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    inventory = Inventory(loader, variable_manager, host_list=[])
    strategy = StrategyModule()
    play = Play().load(dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        strategies = [dict(name='free')],
        tasks = [
            dict(action=dict(module='shell', args='ls'))
        ]
    ), variable_manager=variable_manager, loader=loader)

    tqm = None

# Generated at 2022-06-21 07:35:41.704226
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule()
    play = Play()
    strategy_module._queue_task(strategy_module, play)
    play_context = PlayContext()
    tests = list()
    tests.append((strategy_module.get_hosts_left((strategy_module.update_active_connections())), True))
    tests.append((strategy_module.get_next_task_lockstep(play, play_context), True))
    tests.append((strategy_module.get_goals(play), True))
    tests.append((strategy_module.set_active_queue(play, play_context), True))
    tests.append((strategy_module.run(play, play_context), True))
    for test in tests:
        if test[1] == True:
            assert test[0] != None

# Generated at 2022-06-21 07:35:53.697200
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Instantiation of an object of class StrategyModule
    strategy = StrategyModule()

    # Instantiations of objects of class PlaybookExecutor and PlayContext, here they are empty
    playbook_executor = PlaybookExecutor([])
    play_context = PlayContext()

    # Instantiation of an object of class TaskQueueManager, here with one worker, otherwise by default there are 5
    task_queue_manager = TaskQueueManager(inventory=None, variable_manager=None, loader=None, options=None, passwords=None, stdout_callback=None, run_tree=None, settings=None, stdout_callback=None, one_worker=1)

    # Call the method run of strategy, without passing the parameters
    strategy.run(playbook_executor, play_context)

#if __name__ == "__main__":
#    test_

# Generated at 2022-06-21 07:36:05.051482
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule(tqm=None)
    strategy_module.cancel = MagicMock(return_value=None)
    strategy_module.set_hosts_cache = MagicMock(return_value=None)
    strategy_module._add_tqm_variables = MagicMock(return_value=None)
    strategy_module._wait_on_pending_results = MagicMock(return_value=None)
    strategy_module._process_pending_results = MagicMock(return_value=None)
    strategy_module.update_active_connections = MagicMock(return_value=None)
    strategy_module._take_step = MagicMock(return_value=None)
    strategy_module._get_next_task_lockstep = MagicMock(return_value=None)
   

# Generated at 2022-06-21 07:36:08.241073
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    StrategyModule_instance = StrategyModule(TQM(None))

    # Test with positive values
    assert StrategyModule_instance.run(None, None) == 0

    # Test with negative values
    try:
        StrategyModule_instance.run(None, None)
        assert False
    except:
        assert True



# Generated at 2022-06-21 07:36:10.991002
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # StrategyModule is an abstract class. It should not be instantiated.
    # The constructor of abstract class should raise TypeError
    with pytest.raises(TypeError):
        StrategyModule()

# Generated at 2022-06-21 07:36:15.098611
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy = StrategyModule(tqm)

    assert strategy.run(iterator, play_context) is strategy._tqm.RUN_OK
