

# Generated at 2022-06-17 14:12:34.676896
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:12:36.148772
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-17 14:12:45.609263
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # create a mock object for the iterator
    iterator = MagicMock()
    iterator.get_next_task_for_host.return_value = (None, None)
    iterator.mark_host_failed.return_value = None
    iterator.is_failed.return_value = False
    iterator.get_active_state.return_value = None
    iterator.add_tasks.return_value = None
    iterator.batch_size = 1
    iterator.ITERATING_RESCUE = None
    iterator.ITERATING_ALWAYS = None
    iterator.ITERATING_UNREACHABLE = None
    iterator.FAILED_RESCUE = None
    iterator.FAILED_ALWAYS = None
    iterator.FAILED_UNREACHABLE = None
    iterator._play = MagicMock()
    iterator._play

# Generated at 2022-06-17 14:12:57.670699
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create an instance of class StrategyModule
    strategy_module = StrategyModule()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Host
    host = Host()

    # Create an instance of class Host
    host1 = Host()

    # Create an instance of class Host
    host2 = Host()

    # Create an instance of class Host
    host3 = Host()

    # Create an instance of class Host
    host4 = Host()

    # Create an instance of class Host
    host5 = Host()

    # Create an instance of class Host
    host6 = Host()

    # Create an instance of class Host
    host7 = Host()

    # Create an instance of class Host
    host8 = Host()

    # Create an instance of class Host
    host9 = Host()

    #

# Generated at 2022-06-17 14:13:00.304238
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None, variable_manager=None, loader=None)
    assert strategy_module is not None


# Generated at 2022-06-17 14:13:02.185548
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:13:14.155284
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    iterator.batch_size = 1
    iterator.get_active_state = MagicMock(return_value=iterator)
    iterator.get_next_task_for_host = MagicMock(return_value=(iterator, iterator))
    iterator.is_failed = MagicMock(return_value=False)
    iterator.mark_host_failed = MagicMock()
    iterator.add_tasks = MagicMock()
    iterator._play = MagicMock()
    iterator._play.max_fail_percentage = None
    iterator._play.strategy = 'linear'
    iterator._play.tags = []
    iterator._play.hosts = 'localhost'
    iterator._play.name = 'test'
    iterator._play.roles = []
    iterator._

# Generated at 2022-06-17 14:13:15.422619
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:13:26.620346
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object of class PlayContext
    play_context = PlayContext()
    # Create a mock object of class Play
    play = Play()
    # Create a mock object of class TaskQueueManager
    tqm = TaskQueueManager()
    # Create a mock object of class Host
    host = Host()
    # Create a mock object of class Iterator
    iterator = Iterator()
    # Create a mock object of class StrategyModule
    strategy_module = StrategyModule()
    # Create a mock object of class Host
    host = Host()
    # Create a mock object of class Task
    task = Task()
    # Create a mock object of class TaskResult
    task_result = TaskResult()
    # Create a mock object of class IncludedFile
    included_file = IncludedFile()
    # Create a mock object of class AnsibleError
    ansible

# Generated at 2022-06-17 14:13:38.977571
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # create a mock object for the iterator
    iterator = MagicMock()
    iterator.get_next_task_for_host.return_value = (None, None)
    iterator.get_failed_hosts.return_value = []
    iterator.get_failed_hosts.return_value = []
    iterator.get_unreachable_hosts.return_value = []
    iterator.get_changed_hosts.return_value = []
    iterator.get_skipped_hosts.return_value = []
    iterator.get_ok_hosts.return_value = []
    iterator.get_all_hosts.return_value = []
    iterator.get_failed_hosts.return_value = []
    iterator.get_failed_hosts.return_value = []

# Generated at 2022-06-17 14:14:23.418442
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = mock.MagicMock()
    iterator._play = mock.MagicMock()
    iterator._play.max_fail_percentage = None
    iterator.batch_size = 1
    iterator.get_next_task_for_host = mock.MagicMock()
    iterator.get_next_task_for_host.return_value = (mock.MagicMock(), mock.MagicMock())
    iterator.is_failed = mock.MagicMock()
    iterator.is_failed.return_value = False
    iterator.mark_host_failed = mock.MagicMock()
    iterator.get_active_state = mock.MagicMock()
    iterator.get_active_state.return_value = mock.MagicMock()

# Generated at 2022-06-17 14:14:24.498877
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:14:30.536545
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a strategy module object
    strategy_module = StrategyModule()

    # Check if the object is an instance of StrategyModule
    assert isinstance(strategy_module, StrategyModule)

    # Check if the object is an instance of BaseStrategyModule
    assert isinstance(strategy_module, BaseStrategyModule)

    # Check if the object is an instance of object
    assert isinstance(strategy_module, object)


# Generated at 2022-06-17 14:14:42.278284
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object
    class Mock_StrategyModule(StrategyModule):
        def __init__(self, tqm, strategy, host_list, variable_manager, loader, options, passwords, stdout_callback, run_additional_callbacks, run_tree):
            self.tqm = tqm
            self.strategy = strategy
            self.host_list = host_list
            self.variable_manager = variable_manager
            self.loader = loader
            self.options = options
            self.passwords = passwords
            self.stdout_callback = stdout_callback
            self.run_additional_callbacks = run_additional_callbacks
            self.run_tree = run_tree
            self.pending_results = 0
            self.blocked_hosts = {}
            self.hosts_

# Generated at 2022-06-17 14:14:50.950006
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object of class PlayContext
    play_context = MagicMock()
    # Create a mock object of class Play
    play = MagicMock()
    # Create a mock object of class TaskQueueManager
    tqm = MagicMock()
    # Create a mock object of class Inventory
    inventory = MagicMock()
    # Create a mock object of class VariableManager
    variable_manager = MagicMock()
    # Create a mock object of class Loader
    loader = MagicMock()
    # Create a mock object of class Options
    options = MagicMock()
    # Create a mock object of class StrategyModule
    strategy_module = MagicMock()
    # Create a mock object of class Host
    host = MagicMock()
    # Create a mock object of class TaskResult
    task_result = MagicMock()
    #

# Generated at 2022-06-17 14:14:53.995158
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None, variable_manager=None, loader=None)
    assert strategy_module is not None


# Generated at 2022-06-17 14:14:54.797687
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:14:56.695899
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:14:58.205306
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:15:00.739939
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule()
    strategy_module.run(iterator, play_context)


# Generated at 2022-06-17 14:16:17.331521
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-17 14:16:18.705632
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:16:20.438718
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:16:23.399147
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None, strategy='linear', hosts=[], variable_manager=None, loader=None)
    assert strategy_module is not None


# Generated at 2022-06-17 14:16:24.933419
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:16:27.211380
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:16:39.704667
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a fake inventory
    fake_loader = DictDataLoader({})
    fake_inventory = Inventory(loader=fake_loader, variable_manager=VariableManager(), host_list=[])
    # Create a fake variable manager
    fake_variable_manager = VariableManager()
    # Create a fake loader
    fake_loader = DictDataLoader({})
    # Create a fake options
    fake_options = Options()
    # Create a fake passwords
    fake_passwords = dict(conn_pass=dict(conn_pass='123'))
    # Create a fake stdout callback
    fake_stdout_callback = CallbackModule()
    # Create a fake tqm

# Generated at 2022-06-17 14:16:45.251119
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(
        tqm=None,
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
    )
    assert strategy_module is not None


# Generated at 2022-06-17 14:16:55.376537
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Setup
    strategy_module = StrategyModule()
    strategy_module._tqm = Mock()
    strategy_module._tqm.RUN_OK = 0
    strategy_module._tqm.RUN_FAILED_BREAK_PLAY = 1
    strategy_module._tqm.RUN_UNKNOWN_ERROR = 2
    strategy_module._tqm.send_callback = Mock()
    strategy_module._tqm._terminated = False
    strategy_module._tqm._failed_hosts = {}
    strategy_module._tqm._workers = []
    strategy_module._tqm._stats = Mock()
    strategy_module._tqm._stats.increment = Mock()
    strategy_module._tqm._stats.summarize = Mock()
    strategy_module._tqm

# Generated at 2022-06-17 14:16:57.974465
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:19:36.935892
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    iterator.batch_size = 1
    iterator.get_active_state = MagicMock(return_value=iterator)
    iterator.get_next_task_for_host = MagicMock(return_value=(iterator, iterator))
    iterator.is_failed = MagicMock(return_value=False)
    iterator.mark_host_failed = MagicMock()
    iterator.add_tasks = MagicMock()
    iterator._play = MagicMock()
    iterator._play.max_fail_percentage = None
    iterator._play.strategy = 'linear'
    iterator._play.tags = []
    iterator._play.hosts = 'localhost'
    iterator._play.roles = []
    iterator._play.handlers = []
    iterator._play

# Generated at 2022-06-17 14:19:45.957248
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object of class TaskQueueManager
    mock_tqm = MagicMock(spec=TaskQueueManager)
    mock_tqm.RUN_OK = 0
    mock_tqm.RUN_UNKNOWN_ERROR = 1
    mock_tqm.RUN_FAILED_BREAK_PLAY = 2
    mock_tqm._terminated = False
    mock_tqm._failed_hosts = {}
    mock_tqm.send_callback = MagicMock()
    mock_tqm.send_callback.return_value = None

    # Create a mock object of class Play
    mock_play = MagicMock(spec=Play)
    mock_play.max_fail_percentage = None

    # Create a mock object of class Iterator

# Generated at 2022-06-17 14:19:47.080806
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None

# Generated at 2022-06-17 14:19:59.566225
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock inventory
    inventory = InventoryManager(loader=None, sources=[])
    # Create a mock loader
    loader = DictDataLoader({})
    # Create a mock variable manager
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    # Create a mock options
    options = Options()
    # Create a mock passwords
    passwords = dict()
    # Create a mock stdout
    stdout = StringIO()
    # Create a mock tqm
    tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        options=options,
        passwords=passwords,
        stdout_callback=stdout,
    )
    # Create a mock play

# Generated at 2022-06-17 14:20:01.095492
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:20:11.420706
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    iterator._play = MagicMock()
    iterator._play.max_fail_percentage = None
    iterator.batch_size = 1
    iterator.is_failed = MagicMock(return_value=False)
    iterator.mark_host_failed = MagicMock()
    iterator.get_next_task_for_host = MagicMock(return_value=(MagicMock(), MagicMock()))
    iterator.get_active_state = MagicMock(return_value=MagicMock())
    iterator.add_tasks = MagicMock()

    # Create a mock object for the play_context
    play_context = MagicMock()

    # Create a mock object for the tqm
    tqm = MagicMock()
    tqm._termin

# Generated at 2022-06-17 14:20:13.151496
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:20:26.563929
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = mock.Mock()
    iterator.batch_size = 1
    iterator.get_active_state = mock.Mock(return_value=iterator)
    iterator.get_next_task_for_host = mock.Mock(return_value=(iterator, iterator))
    iterator.is_failed = mock.Mock(return_value=False)
    iterator.mark_host_failed = mock.Mock(return_value=False)
    iterator.add_tasks = mock.Mock(return_value=False)
    iterator._play = mock.Mock()
    iterator._play.max_fail_percentage = None

    # Create a mock object for the play_context
    play_context = mock.Mock()

    # Create a mock object for the tqm
    tq

# Generated at 2022-06-17 14:20:32.442023
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object of class PlayContext
    play_context = PlayContext()

    # Create a mock object of class TaskQueueManager
    tqm = TaskQueueManager()

    # Create a mock object of class Host
    host = Host()

    # Create a mock object of class Play
    play = Play()

    # Create a mock object of class PlayIterator
    iterator = PlayIterator()

    # Create a mock object of class VariableManager
    variable_manager = VariableManager()

    # Create a mock object of class Loader
    loader = Loader()

    # Create a mock object of class Options
    options = Options()

    # Create a mock object of class StrategyModule
    strategy_module = StrategyModule(tqm, host, play, iterator, variable_manager, loader, options)

    # Call method run of class StrategyModule

# Generated at 2022-06-17 14:20:33.544614
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy is not None