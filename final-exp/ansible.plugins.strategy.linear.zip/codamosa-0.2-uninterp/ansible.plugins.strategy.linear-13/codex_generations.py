

# Generated at 2022-06-17 14:12:37.850136
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None, strategy='linear', hosts=[], variable_manager=None, loader=None)
    assert strategy_module is not None


# Generated at 2022-06-17 14:12:50.293388
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object
    mock_iterator = MagicMock()
    mock_play_context = MagicMock()
    mock_self = MagicMock()
    mock_self._tqm = MagicMock()
    mock_self._tqm.RUN_OK = 0
    mock_self._tqm.RUN_UNKNOWN_ERROR = -1
    mock_self._tqm.RUN_FAILED_BREAK_PLAY = 1
    mock_self._tqm._terminated = False
    mock_self._tqm._failed_hosts = {}
    mock_self._tqm._stats = MagicMock()
    mock_self._tqm._stats.custom = MagicMock()
    mock_self._tqm._stats.custom.get_host_status_counts = Magic

# Generated at 2022-06-17 14:13:01.032651
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    iterator.batch_size = 1
    iterator.get_active_state = MagicMock(return_value=iterator)
    iterator.get_next_task_for_host = MagicMock(return_value=(iterator, iterator))
    iterator.is_failed = MagicMock(return_value=False)
    iterator.mark_host_failed = MagicMock(return_value=False)
    iterator.add_tasks = MagicMock(return_value=False)
    iterator._play = MagicMock()
    iterator._play.max_fail_percentage = None
    iterator._play.handlers = []
    iterator._play.cleanup_tasks = []
    iterator._play.post_tasks = []
    iterator._play.roles = []


# Generated at 2022-06-17 14:13:03.248314
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:13:14.771494
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    iterator.__iter__.return_value = [1, 2, 3]
    iterator.__next__.return_value = 1
    iterator.__len__.return_value = 3
    iterator.batch_size = 3
    iterator.get_next_task_for_host.return_value = (1, 2)
    iterator.is_failed.return_value = False
    iterator.mark_host_failed.return_value = None
    iterator.add_tasks.return_value = None
    iterator.get_active_state.return_value = 1
    iterator.get_failed_hosts.return_value = []
    iterator.get_failed_hosts.return_value = []
    iterator.get_hosts_left.return_value = []

# Generated at 2022-06-17 14:13:16.016622
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:13:17.442972
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:13:21.879686
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(
        tqm=None,
        connection_info=None,
        loader=None,
        variable_manager=None,
        host_list=None,
        play=None,
        options=None,
        passwords=None
    )
    assert strategy_module is not None


# Generated at 2022-06-17 14:13:23.453537
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:13:30.357000
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = mock.MagicMock()
    # Create a mock object for the play_context
    play_context = mock.MagicMock()
    # Create a mock object for the StrategyModule
    strategy_module = StrategyModule(iterator, play_context)
    # Call the run method of the StrategyModule
    strategy_module.run(iterator, play_context)
    # Check if the run method of the StrategyModule was called
    assert strategy_module.run.called


# Generated at 2022-06-17 14:14:10.578138
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:14:13.842831
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None, strategy='linear', host_list=[], options=None, variable_manager=None, loader=None, passwords=None)
    assert strategy_module is not None


# Generated at 2022-06-17 14:14:15.236262
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:14:24.271333
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object
    mock_iterator = MagicMock()
    mock_play_context = MagicMock()
    mock_self = MagicMock()
    mock_self.get_hosts_left = MagicMock(return_value = [])
    mock_self._tqm = MagicMock()
    mock_self._tqm.RUN_OK = 0
    mock_self._tqm._terminated = False
    mock_self._set_hosts_cache = MagicMock()
    mock_self._get_next_task_lockstep = MagicMock(return_value = [])
    mock_self._process_pending_results = MagicMock(return_value = [])
    mock_self._wait_on_pending_results = MagicMock(return_value = [])
    mock_

# Generated at 2022-06-17 14:14:34.740185
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Setup
    strategy_module = StrategyModule()
    strategy_module._tqm = MagicMock()
    strategy_module._tqm.RUN_OK = 0
    strategy_module._tqm.RUN_FAILED_BREAK_PLAY = 1
    strategy_module._tqm.RUN_UNKNOWN_ERROR = 2
    strategy_module._tqm._terminated = False
    strategy_module._tqm._failed_hosts = {}
    strategy_module._tqm.send_callback = MagicMock()
    strategy_module._tqm.send_callback.side_effect = lambda x, y: x
    strategy_module._tqm.send_callback.return_value = None
    strategy_module._tqm.get_failed_hosts = MagicMock()
    strategy

# Generated at 2022-06-17 14:14:46.761727
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock(spec=Iterator)
    iterator.__iter__.return_value = [1, 2, 3]
    iterator.__next__.side_effect = [1, 2, 3, StopIteration]
    iterator.get_active_state.return_value = 'active_state'
    iterator.get_next_task_for_host.return_value = ('next_task', 'next_state')
    iterator.mark_host_failed.return_value = None
    iterator.batch_size = 1
    iterator.is_failed.return_value = False
    iterator.add_tasks.return_value = None
    iterator._play = MagicMock(spec=Play)
    iterator._play.max_fail_percentage = None

# Generated at 2022-06-17 14:14:48.074932
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:14:55.094414
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    # Create a mock object for the play_context
    play_context = MagicMock()
    # Create a mock object for the loader
    loader = MagicMock()
    # Create a mock object for the variable_manager
    variable_manager = MagicMock()
    # Create a mock object for the host_list
    host_list = MagicMock()
    # Create a mock object for the tqm
    tqm = MagicMock()
    # Create a mock object for the inventory
    inventory = MagicMock()
    # Create a mock object for the variable_manager
    variable_manager = MagicMock()
    # Create a mock object for the loader
    loader = MagicMock()
    # Create a mock object for the options
    options = MagicMock()

# Generated at 2022-06-17 14:15:05.388821
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object of class PlayContext
    play_context = PlayContext()
    # Create a mock object of class Play
    play = Play()
    # Create a mock object of class Host
    host = Host()
    # Create a mock object of class Task
    task = Task()
    # Create a mock object of class TaskResult
    task_result = TaskResult()
    # Create a mock object of class TaskQueueManager
    task_queue_manager = TaskQueueManager()
    # Create a mock object of class VariableManager
    variable_manager = VariableManager()
    # Create a mock object of class Loader
    loader = Loader()
    # Create a mock object of class HostsCache
    hosts_cache = HostsCache()
    # Create a mock object of class HostsCacheAll
    hosts_cache_all = HostsCacheAll()
   

# Generated at 2022-06-17 14:15:15.012187
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    iterator.batch_size = 1
    iterator.get_active_state = MagicMock(return_value=iterator)
    iterator.get_next_task_for_host = MagicMock(return_value=(iterator, iterator))
    iterator.is_failed = MagicMock(return_value=False)
    iterator.mark_host_failed = MagicMock(return_value=False)
    iterator.add_tasks = MagicMock(return_value=False)
    iterator._play = MagicMock()
    iterator._play.max_fail_percentage = None
    iterator._play.serial = 1
    iterator._play.strategy = 'linear'
    iterator._play.tags = []
    iterator._play.hosts = []

# Generated at 2022-06-17 14:16:05.704866
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    iterator.batch_size = 1
    iterator.get_active_state = MagicMock(return_value=iterator)
    iterator.get_next_task_for_host = MagicMock(return_value=(iterator, iterator))
    iterator.is_failed = MagicMock(return_value=False)
    iterator.mark_host_failed = MagicMock(return_value=False)
    iterator.add_tasks = MagicMock(return_value=False)
    iterator._play = MagicMock()
    iterator._play.max_fail_percentage = None

    # Create a mock object for the play_context
    play_context = MagicMock()

    # Create a mock object for the tqm
    tqm = MagicMock()
   

# Generated at 2022-06-17 14:16:07.784780
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None, strategy='linear', hosts=None, variable_manager=None, loader=None, options=None, passwords=None)
    assert strategy_module is not None


# Generated at 2022-06-17 14:16:19.084779
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-17 14:16:31.087459
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    # Create a mock object for the play_context
    play_context = MagicMock()
    # Create a mock object for the loader
    loader = MagicMock()
    # Create a mock object for the variable_manager
    variable_manager = MagicMock()
    # Create a mock object for the host_list
    host_list = MagicMock()
    # Create a mock object for the tqm
    tqm = MagicMock()
    # Create a mock object for the inventory
    inventory = MagicMock()
    # Create a mock object for the variable_manager
    variable_manager = MagicMock()
    # Create a mock object for the loader
    loader = MagicMock()
    # Create a mock object for the options
    options = MagicMock()

# Generated at 2022-06-17 14:16:42.427244
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object
    mock_iterator = MagicMock()
    mock_play_context = MagicMock()
    mock_self = MagicMock()
    mock_self._tqm = MagicMock()
    mock_self._tqm.RUN_OK = MagicMock()
    mock_self._tqm.RUN_UNKNOWN_ERROR = MagicMock()
    mock_self._tqm.RUN_FAILED_BREAK_PLAY = MagicMock()
    mock_self._tqm._terminated = MagicMock()
    mock_self._set_hosts_cache = MagicMock()
    mock_self.get_hosts_left = MagicMock()
    mock_self._get_next_task_lockstep = MagicMock()

# Generated at 2022-06-17 14:16:45.914326
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a strategy module
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:16:55.619552
# Unit test for method run of class StrategyModule

# Generated at 2022-06-17 14:17:07.206985
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    # Create a mock object for the play_context
    play_context = MagicMock()
    # Create a mock object for the tqm
    tqm = MagicMock()
    # Create a mock object for the loader
    loader = MagicMock()
    # Create a mock object for the variable_manager
    variable_manager = MagicMock()
    # Create a mock object for the inventory
    inventory = MagicMock()
    # Create a mock object for the variable_manager
    variable_manager = MagicMock()
    # Create a mock object for the stdout_callback
    stdout_callback = MagicMock()
    # Create a mock object for the options
    options = MagicMock()
    # Create a mock object for the variable_manager
    variable_

# Generated at 2022-06-17 14:17:08.796118
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:17:17.294578
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock inventory
    inventory = InventoryManager(loader=None, sources='localhost,')
    # Create a mock loader
    loader = DictDataLoader({})
    # Create a mock variable manager
    variable_manager = VariableManager()
    # Create a mock options
    options = Options()
    # Create a mock passwords
    passwords = dict()
    # Create a mock stdout
    stdout = six.StringIO()
    # Create a mock tqm
    tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        options=options,
        passwords=passwords,
        stdout_callback=stdout,
    )
    # Create a mock play

# Generated at 2022-06-17 14:18:35.517068
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:18:47.052051
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = Mock()
    iterator._play = Mock()
    iterator._play.max_fail_percentage = None
    iterator._play.batch_size = 1
    iterator._play.serial = 1
    iterator.batch_size = 1
    iterator.serial = 1
    iterator.hosts = [Mock()]
    iterator.hosts[0].name = 'host1'
    iterator.hosts[0].vars = {}
    iterator.hosts[0].vars['ansible_connection'] = 'local'
    iterator.hosts[0].vars['ansible_python_interpreter'] = '/usr/bin/python'
    iterator.hosts[0].vars['ansible_host'] = 'host1'

# Generated at 2022-06-17 14:18:53.241685
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create an instance of class StrategyModule
    strategy_module = StrategyModule(
        tqm=None,
        connection_info=None,
        loader=None,
        variable_manager=None,
        host_list=None,
        play=None,
        options=None,
        passwords=None
    )

    # Check if the instance is created successfully
    assert strategy_module is not None


# Generated at 2022-06-17 14:18:56.982483
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert isinstance(strategy_module, StrategyModule)
    assert isinstance(strategy_module, BaseStrategy)
    assert isinstance(strategy_module, object)


# Generated at 2022-06-17 14:19:05.047233
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Setup test objects
    iterator = Iterator()
    play_context = PlayContext()
    strategy_module = StrategyModule()

    # Test with valid parameters
    result = strategy_module.run(iterator, play_context)
    assert result == strategy_module._tqm.RUN_OK

    # Test with invalid parameters
    iterator = None
    play_context = None
    result = strategy_module.run(iterator, play_context)
    assert result == strategy_module._tqm.RUN_UNKNOWN_ERROR


# Generated at 2022-06-17 14:19:07.937271
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None, strategy='linear', host_list=[], options=None, variable_manager=None, loader=None)
    assert strategy_module is not None


# Generated at 2022-06-17 14:19:17.871966
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    iterator.batch_size = 1
    iterator.get_active_state = MagicMock()
    iterator.get_active_state.return_value = 'ITERATING_RESCUE'
    iterator.get_next_task_for_host = MagicMock()
    iterator.get_next_task_for_host.return_value = (None, None)
    iterator.is_failed = MagicMock()
    iterator.is_failed.return_value = False
    iterator.mark_host_failed = MagicMock()
    iterator.mark_host_failed.return_value = True
    iterator.add_tasks = MagicMock()
    iterator.add_tasks.return_value = True
    iterator._play = MagicMock()
    iterator._

# Generated at 2022-06-17 14:19:19.575127
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:19:30.647814
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    iterator.batch_size = 1
    iterator.get_next_task_for_host.return_value = (None, None)
    iterator.is_failed.return_value = False
    iterator.get_active_state.return_value = None
    iterator.mark_host_failed.return_value = None
    iterator.add_tasks.return_value = None
    iterator._play = MagicMock()
    iterator._play.max_fail_percentage = None
    iterator._play.serial = 1
    iterator._play.strategy = 'linear'
    iterator._play.name = 'test_play'
    iterator._play.hosts = ['localhost']
    iterator._play.roles = []
    iterator._play.tags = []
    iterator._

# Generated at 2022-06-17 14:19:32.795163
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:20:47.266424
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:20:48.613819
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:20:50.391244
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None

# Generated at 2022-06-17 14:20:51.308040
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:20:52.667877
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create an instance of class StrategyModule
    strategy_module = StrategyModule()
    # Test method run of class StrategyModule
    strategy_module.run()


# Generated at 2022-06-17 14:20:54.603153
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:21:01.077710
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(
        tqm=None,
        strategy='free',
        hosts=[],
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
        run_additional_callbacks=None,
        run_tree=False,
        subset=None
    )
    assert strategy_module is not None


# Generated at 2022-06-17 14:21:12.675716
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None, strategy='linear', host_list=[], options=None, variable_manager=None, loader=None, passwords=None)
    assert strategy_module._strategy == 'linear'
    assert strategy_module._host_list == []
    assert strategy_module._options == None
    assert strategy_module._variable_manager == None
    assert strategy_module._loader == None
    assert strategy_module._tqm == None
    assert strategy_module._passwords == None
    assert strategy_module._inventory == None
    assert strategy_module._all_vars == None
    assert strategy_module._hosts_cache == None
    assert strategy_module._hosts_cache_all == None
    assert strategy_module._play_context == None
    assert strategy_module._workers == None
    assert strategy_

# Generated at 2022-06-17 14:21:20.788485
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object of class PlayContext
    play_context = PlayContext()
    # Create a mock object of class Play
    play = Play()
    # Create a mock object of class Host
    host = Host()
    # Create a mock object of class Task
    task = Task()
    # Create a mock object of class TaskResult
    task_result = TaskResult()
    # Create a mock object of class TaskQueueManager
    task_queue_manager = TaskQueueManager()
    # Create a mock object of class VariableManager
    variable_manager = VariableManager()
    # Create a mock object of class Loader
    loader = Loader()
    # Create a mock object of class Options
    options = Options()
    # Create a mock object of class Display
    display = Display()
    # Create a mock object of class C
    c = C()
   

# Generated at 2022-06-17 14:21:32.063116
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock(spec=Iterator)
    iterator.batch_size = 1
    iterator.get_active_state = MagicMock(return_value=None)
    iterator.get_next_task_for_host = MagicMock(return_value=(None, None))
    iterator.mark_host_failed = MagicMock(return_value=None)
    iterator.is_failed = MagicMock(return_value=False)
    iterator.add_tasks = MagicMock(return_value=None)
    iterator._play = MagicMock(spec=Play)
    iterator._play.max_fail_percentage = None
    iterator._play.strategy = 'linear'
    iterator._play.tags = []
    iterator._play.hosts = 'localhost'
    iterator._play