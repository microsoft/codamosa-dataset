

# Generated at 2022-06-17 14:12:35.276654
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:12:36.724763
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:12:49.669758
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    # Create a mock object for the play_context
    play_context = MagicMock()
    # Create a mock object for the loader
    loader = MagicMock()
    # Create a mock object for the variable_manager
    variable_manager = MagicMock()
    # Create a mock object for the host_list
    host_list = MagicMock()
    # Create a mock object for the tqm
    tqm = MagicMock()
    # Create a mock object for the strategy
    strategy = MagicMock()
    # Create a mock object for the display
    display = MagicMock()
    # Create a mock object for the Options
    options = MagicMock()
    # Create a mock object for the variable_manager
    variable_manager = MagicMock()

# Generated at 2022-06-17 14:12:51.302740
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None

# Generated at 2022-06-17 14:13:01.762407
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object of class PlayContext
    play_context = MagicMock()
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'root'
    play_context.password = '123456'
    play_context.port = 22
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.become_pass = '123456'
    play_context.become_exe = ''
    play_context.become_flags = ''
    play_context.no_log = False
    play_context.verbosity = 0
    play_context.check_mode = False
    play_context.only_tags = []

# Generated at 2022-06-17 14:13:13.801569
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    iterator.batch_size = 1
    iterator.get_active_state = MagicMock(return_value=iterator)
    iterator.get_next_task_for_host = MagicMock(return_value=(iterator, iterator))
    iterator.is_failed = MagicMock(return_value=False)
    iterator.mark_host_failed = MagicMock(return_value=False)
    iterator.add_tasks = MagicMock(return_value=False)

    # Create a mock object for the play_context
    play_context = MagicMock()

    # Create a mock object for the tqm
    tqm = MagicMock()
    tqm.RUN_OK = 0
    tqm.RUN_FAILED_BRE

# Generated at 2022-06-17 14:13:26.003634
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = mock.Mock()
    iterator.run_state = 'foo'
    iterator.batch_size = 'bar'
    iterator.get_active_state.return_value = 'baz'
    iterator.get_next_task_for_host.return_value = ('qux', 'quux')
    iterator.is_failed.return_value = 'corge'
    iterator.mark_host_failed.return_value = 'grault'
    iterator.add_tasks.return_value = 'garply'
    iterator.get_failed_hosts.return_value = 'waldo'
    iterator.get_failed_hosts.return_value = 'fred'
    iterator.get_failed_hosts.return_value = 'plugh'
    iterator.get_failed_

# Generated at 2022-06-17 14:13:38.520812
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Setup test
    strategy_module = StrategyModule()
    strategy_module._tqm = Mock()
    strategy_module._tqm.RUN_OK = 0
    strategy_module._tqm.RUN_FAILED_BREAK_PLAY = 1
    strategy_module._tqm.RUN_UNKNOWN_ERROR = 2
    strategy_module._tqm._terminated = False
    strategy_module._tqm._failed_hosts = {}
    strategy_module._tqm.send_callback = Mock()
    strategy_module._tqm.send_callback.return_value = None
    strategy_module._tqm.send_callback.side_effect = None
    strategy_module._tqm.send_callback.side_effect = None
    strategy_module._tqm.send_callback

# Generated at 2022-06-17 14:13:48.995881
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    iterator.batch_size = 1
    iterator.get_active_state = MagicMock(return_value = 'ITERATING_TASKS')
    iterator.get_next_task_for_host = MagicMock(return_value = ('ITERATING_TASKS', 'task'))
    iterator.is_failed = MagicMock(return_value = False)
    iterator.mark_host_failed = MagicMock(return_value = None)
    iterator.add_tasks = MagicMock(return_value = None)
    iterator._play = MagicMock()
    iterator._play.max_fail_percentage = None
    iterator._play.tags = []
    iterator._play.any_errors_fatal = False
    iterator._play.host

# Generated at 2022-06-17 14:13:50.184475
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-17 14:14:45.592082
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    iterator.batch_size = 1
    iterator.get_active_state.return_value = iterator
    iterator.get_next_task_for_host.return_value = (iterator, iterator)
    iterator.is_failed.return_value = False
    iterator.mark_host_failed.return_value = None
    iterator.add_tasks.return_value = None

    # Create a mock object for the play_context
    play_context = MagicMock()

    # Create a mock object for the loader
    loader = MagicMock()

    # Create a mock object for the variable_manager
    variable_manager = MagicMock()

    # Create a mock object for the inventory
    inventory = MagicMock()

    # Create a mock object for the variable_manager


# Generated at 2022-06-17 14:14:46.900763
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:14:49.516033
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None, connection_info=None, loader=None, variable_manager=None, shared_loader_obj=None)
    assert strategy_module is not None


# Generated at 2022-06-17 14:14:57.366916
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    # Create a mock object for the play_context
    play_context = MagicMock()
    # Create a mock object for the StrategyModule
    strategy_module = MagicMock()
    # Create a mock object for the StrategyModule
    strategy_module.run(iterator, play_context)
    # Check if the run method of the StrategyModule was called
    assert strategy_module.run.called


# Generated at 2022-06-17 14:14:59.635285
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a strategy module object
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:15:04.055079
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(
        tqm=None,
        connection_info=None,
        loader=None,
        variable_manager=None,
        host_list=None,
        play=None,
        options=None,
        passwords=None,
    )
    assert strategy_module is not None


# Generated at 2022-06-17 14:15:11.833120
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None, strategy='linear', host_list=[], options=None, variable_manager=None, loader=None, passwords=None)
    assert strategy_module._strategy == 'linear'
    assert strategy_module._host_list == []
    assert strategy_module._options == None
    assert strategy_module._variable_manager == None
    assert strategy_module._loader == None
    assert strategy_module._passwords == None
    assert strategy_module._tqm == None
    assert strategy_module._inventory == None
    assert strategy_module._workers == {}
    assert strategy_module._notified_handlers == {}
    assert strategy_module._blocked_hosts == {}
    assert strategy_module._failed_hosts == {}
    assert strategy_module._pending_results == 0
    assert strategy

# Generated at 2022-06-17 14:15:18.468469
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object of class PlayContext
    play_context = PlayContext()
    # Create a mock object of class Play
    play = Play()
    # Create a mock object of class PlayIterator
    iterator = PlayIterator()
    # Create a mock object of class TaskQueueManager
    tqm = TaskQueueManager()
    # Create a mock object of class VariableManager
    variable_manager = VariableManager()
    # Create a mock object of class Loader
    loader = Loader()
    # Create a mock object of class Options
    options = Options()
    # Create a mock object of class CallbackModule
    callback_module = CallbackModule()
    # Create a mock object of class StrategyModule
    strategy_module = StrategyModule(tqm, variable_manager, loader, options, callback_module)
    # Create a mock object of class Host
   

# Generated at 2022-06-17 14:15:19.429975
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:15:20.348222
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:16:47.278894
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:16:48.864186
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None

# Generated at 2022-06-17 14:16:50.830892
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:16:52.663965
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:16:54.434543
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:17:02.930262
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = mock.MagicMock()
    # Create a mock object for the play_context
    play_context = mock.MagicMock()
    # Create a mock object for the StrategyModule
    strategy_module = mock.MagicMock()
    # Create a mock object for the StrategyModule
    strategy_module.run(iterator, play_context)
    # Check if the run method of the StrategyModule was called
    assert strategy_module.run.called


# Generated at 2022-06-17 14:17:05.396710
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:17:14.852159
# Unit test for method run of class StrategyModule

# Generated at 2022-06-17 14:17:16.527876
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:17:17.625903
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:20:18.319679
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the task queue manager
    tqm = mock.MagicMock()
    tqm.RUN_OK = 0
    tqm.RUN_FAILED_BREAK_PLAY = 1
    tqm.RUN_UNKNOWN_ERROR = 2
    tqm.send_callback.return_value = None
    tqm.send_callback.side_effect = lambda x, **kwargs: None
    tqm._terminated = False
    tqm._failed_hosts = {}
    tqm._workers = []
    tqm.get_failed_hosts.return_value = []
    tqm.get_failed_hosts.side_effect = lambda: []
    tqm.get_hosts_left.return_value = []

# Generated at 2022-06-17 14:20:21.381579
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule()
    strategy_module.run(iterator, play_context)


# Generated at 2022-06-17 14:20:23.223255
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None, strategy='free', hosts=[], variable_manager=None, loader=None)
    assert strategy_module is not None


# Generated at 2022-06-17 14:20:32.438168
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    # Create a mock object for the play_context
    play_context = MagicMock()
    # Create a mock object for the loader
    loader = MagicMock()
    # Create a mock object for the variable_manager
    variable_manager = MagicMock()
    # Create a mock object for the tqm
    tqm = MagicMock()
    # Create a mock object for the inventory
    inventory = MagicMock()
    # Create a mock object for the variable_manager
    variable_manager = MagicMock()
    # Create a mock object for the loader
    loader = MagicMock()
    # Create a mock object for the options
    options = MagicMock()
    # Create a mock object for the stdout_callback
    stdout_callback = MagicM

# Generated at 2022-06-17 14:20:33.805858
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:20:36.044658
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy is not None


# Generated at 2022-06-17 14:20:42.500489
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(
        tqm=None,
        connection_info=None,
        loader=None,
        variable_manager=None,
        host_list=None,
        play=None,
        options=None,
        passwords=None,
    )
    assert strategy_module is not None

# Generated at 2022-06-17 14:20:52.595074
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    iterator.batch_size = 1
    iterator.get_active_state = MagicMock(return_value=iterator)
    iterator.get_next_task_for_host = MagicMock(return_value=(iterator, iterator))
    iterator.is_failed = MagicMock(return_value=False)
    iterator.mark_host_failed = MagicMock()
    iterator.add_tasks = MagicMock()

    # Create a mock object for the play_context
    play_context = MagicMock()

    # Create a mock object for the tqm
    tqm = MagicMock()
    tqm.RUN_OK = 0
    tqm.RUN_FAILED_BREAK_PLAY = 1
    tqm.R

# Generated at 2022-06-17 14:20:54.232366
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:21:04.115966
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    iterator.batch_size = 1
    iterator.get_active_state = MagicMock(return_value=iterator)
    iterator.get_next_task_for_host = MagicMock(return_value=(iterator, iterator))
    iterator.is_failed = MagicMock(return_value=False)
    iterator.mark_host_failed = MagicMock()
    iterator.add_tasks = MagicMock()
    iterator._play = MagicMock()
    iterator._play.max_fail_percentage = None
    iterator._play.strategy = 'linear'
    iterator._play.tags = []
    iterator._play.any_errors_fatal = False
    iterator._play.handlers = []
    iterator._play.post_tasks = []
