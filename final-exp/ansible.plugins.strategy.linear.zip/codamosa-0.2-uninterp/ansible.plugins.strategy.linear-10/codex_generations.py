

# Generated at 2022-06-17 14:12:46.951276
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    iterator.batch_size = 1
    iterator.get_active_state = MagicMock(return_value=iterator)
    iterator.get_next_task_for_host = MagicMock(return_value=(None, None))
    iterator.is_failed = MagicMock(return_value=False)
    iterator.mark_host_failed = MagicMock()
    iterator.add_tasks = MagicMock()
    iterator.get_failed_hosts = MagicMock(return_value=[])
    iterator.get_failed_hosts_count = MagicMock(return_value=0)
    iterator.get_ok_hosts = MagicMock(return_value=[])

# Generated at 2022-06-17 14:12:58.546655
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock(spec=Iterator)
    # Create a mock object for the play_context
    play_context = MagicMock(spec=PlayContext)
    # Create a mock object for the loader
    loader = MagicMock(spec=DataLoader)
    # Create a mock object for the variable_manager
    variable_manager = MagicMock(spec=VariableManager)
    # Create a mock object for the inventory
    inventory = MagicMock(spec=Inventory)
    # Create a mock object for the variable_manager
    variable_manager = MagicMock(spec=VariableManager)
    # Create a mock object for the tqm
    tqm = MagicMock(spec=TaskQueueManager)
    # Create a mock object for the stdout_callback
    stdout_callback = MagicMock

# Generated at 2022-06-17 14:13:01.324651
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a new StrategyModule object
    strategy_module = StrategyModule()
    # Check if the object is an instance of StrategyModule
    assert isinstance(strategy_module, StrategyModule)


# Generated at 2022-06-17 14:13:03.691161
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module is not None


# Generated at 2022-06-17 14:13:06.145247
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module is not None


# Generated at 2022-06-17 14:13:13.301817
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object of class PlayContext
    play_context = PlayContext()
    # Create a mock object of class PlayIterator
    iterator = PlayIterator()
    # Create a mock object of class TaskQueueManager
    tqm = TaskQueueManager()
    # Create a mock object of class VariableManager
    variable_manager = VariableManager()
    # Create a mock object of class Loader
    loader = Loader()
    # Create a mock object of class Options
    options = Options()
    # Create a mock object of class Inventory
    inventory = Inventory()
    # Create a mock object of class VariableManager
    variable_manager = VariableManager()
    # Create a mock object of class C
    C = C()
    # Create a mock object of class Display
    display = Display()
    # Create a mock object of class PlayContext
    play_context = Play

# Generated at 2022-06-17 14:13:16.551198
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:13:27.470186
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    iterator.run_state = 'test'
    iterator.batch_size = 1
    iterator.get_active_state.return_value = 'test'
    iterator.get_next_task_for_host.return_value = ('test', 'test')
    iterator.mark_host_failed.return_value = None
    iterator.is_failed.return_value = False
    iterator.add_tasks.return_value = None
    iterator._play = 'test'

    # Create a mock object for the play_context
    play_context = MagicMock()

    # Create a mock object for the tqm
    tqm = MagicMock()
    tqm.RUN_OK = 'test'
    tqm.RUN_UNKNOWN_

# Generated at 2022-06-17 14:13:29.736506
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:13:44.102257
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    iterator._play = MagicMock()
    iterator._play.max_fail_percentage = None
    iterator.batch_size = 1
    iterator.get_active_state = MagicMock(return_value=iterator)
    iterator.get_next_task_for_host = MagicMock(return_value=(iterator, None))
    iterator.is_failed = MagicMock(return_value=False)
    iterator.mark_host_failed = MagicMock()
    iterator.add_tasks = MagicMock()
    iterator.get_block_list = MagicMock(return_value=([iterator], [iterator]))

    # Create a mock object for the play_context
    play_context = MagicMock()

    # Create a mock object for the loader


# Generated at 2022-06-17 14:14:29.580092
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a mock object for the tqm
    tqm = Mock()
    # Create a mock object for the loader
    loader = Mock()
    # Create a mock object for the variable manager
    variable_manager = Mock()
    # Create a mock object for the inventory
    inventory = Mock()
    # Create a mock object for the variable manager
    shared_loader_obj = Mock()
    # Create a mock object for the options
    options = Mock()
    # Create a mock object for the stdout callback
    stdout_callback = Mock()
    # Create a mock object for the stats
    stats = Mock()
    # Create a mock object for the stdout callback
    run_additional_callbacks = Mock()
    # Create a mock object for the stdout callback
    run_tree = Mock()
    # Create a mock object for the stdout

# Generated at 2022-06-17 14:14:41.316800
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # create a StrategyModule object
    strategy_module = StrategyModule()
    # create a PlayContext object
    play_context = PlayContext()
    # create a Host object
    host = Host()
    # create a TaskResult object
    task_result = TaskResult()
    # create a Task object
    task = Task()
    # create a Host object
    host = Host()
    # create a TaskResult object
    task_result = TaskResult()
    # create a Task object
    task = Task()
    # create a Host object
    host = Host()
    # create a TaskResult object
    task_result = TaskResult()
    # create a Task object
    task = Task()
    # create a Host object
    host = Host()
    # create a TaskResult object
    task_result = TaskResult()
    # create a Task object

# Generated at 2022-06-17 14:14:44.752017
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None, strategy='linear', host_list=[], options=None, variable_manager=None, loader=None, passwords=None)
    assert strategy_module is not None


# Generated at 2022-06-17 14:14:46.989041
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None, strategy='free', hosts=[], variable_manager=None, loader=None)
    assert strategy_module is not None


# Generated at 2022-06-17 14:14:49.569997
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a strategy module object
    strategy_module = StrategyModule()
    # Check if the strategy module object is created
    assert strategy_module is not None


# Generated at 2022-06-17 14:15:02.071336
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # create an instance of the class under test
    strategy_module = StrategyModule()
    # create an instance of the class AnsibleTaskQueueManager
    tqm = AnsibleTaskQueueManager()
    # create an instance of the class AnsibleOptions
    options = AnsibleOptions()
    # create an instance of the class AnsibleVariableManager
    variable_manager = AnsibleVariableManager()
    # create an instance of the class AnsibleLoader
    loader = AnsibleLoader()
    # create an instance of the class AnsibleInventory
    inventory = AnsibleInventory()
    # create an instance of the class AnsiblePlaybook
    playbook = AnsiblePlaybook()
    # create an instance of the class AnsiblePlay
    play = AnsiblePlay()
    # create an instance of the class AnsibleTask
    task = AnsibleTask()
    # create an instance

# Generated at 2022-06-17 14:15:04.033007
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:15:11.210571
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object of class TaskQueueManager
    tqm = mock.MagicMock()
    # Create a mock object of class PlayContext
    play_context = mock.MagicMock()
    # Create a mock object of class Iterator
    iterator = mock.MagicMock()
    # Create a mock object of class StrategyModule
    strategy_module = StrategyModule(tqm)
    # Call method run of class StrategyModule
    strategy_module.run(iterator, play_context)
    # Check if method run of class StrategyModule was called
    assert strategy_module.run.called
    # Check if method run of class StrategyModule was called with the right parameters
    strategy_module.run.assert_called_with(iterator, play_context)


# Generated at 2022-06-17 14:15:15.185873
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create an instance of class StrategyModule
    strategy_module = StrategyModule()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Play
    play = Play()

    # Create an instance of class Iterator
    iterator = Iterator(play=play)

    # Test the run method
    strategy_module.run(iterator, play_context)


# Generated at 2022-06-17 14:15:16.215837
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:16:39.748362
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    iterator._play = MagicMock()
    iterator._play.max_fail_percentage = None
    iterator.batch_size = 1
    iterator.get_next_task_for_host = MagicMock(return_value=(MagicMock(), MagicMock()))
    iterator.get_active_state = MagicMock(return_value=MagicMock())
    iterator.is_failed = MagicMock(return_value=False)
    iterator.mark_host_failed = MagicMock()
    iterator.add_tasks = MagicMock()
    # Create a mock object for the play_context
    play_context = MagicMock()
    # Create a mock object for the tqm
    tqm = MagicMock()
    tqm._termin

# Generated at 2022-06-17 14:16:41.133501
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:16:43.587865
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:16:54.881674
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = mock.MagicMock()
    iterator._play = mock.MagicMock()
    iterator._play.max_fail_percentage = None
    iterator.batch_size = 1
    iterator.get_next_task_for_host = mock.MagicMock()
    iterator.get_next_task_for_host.return_value = (mock.MagicMock(), mock.MagicMock())
    iterator.is_failed = mock.MagicMock()
    iterator.is_failed.return_value = False
    iterator.mark_host_failed = mock.MagicMock()
    iterator.get_active_state = mock.MagicMock()
    iterator.get_active_state.return_value = mock.MagicMock()

# Generated at 2022-06-17 14:16:57.544994
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module is not None


# Generated at 2022-06-17 14:16:58.292637
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:17:08.649341
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Setup
    strategy_module = StrategyModule()
    strategy_module._tqm = Mock()
    strategy_module._tqm.RUN_OK = 0
    strategy_module._tqm.RUN_UNKNOWN_ERROR = 1
    strategy_module._tqm.RUN_FAILED_BREAK_PLAY = 2
    strategy_module._tqm.send_callback = Mock()
    strategy_module._tqm.send_callback.return_value = None
    strategy_module._tqm.send_callback.side_effect = None
    strategy_module._tqm._terminated = False
    strategy_module._tqm._failed_hosts = {}
    strategy_module._tqm._stats = Mock()

# Generated at 2022-06-17 14:17:17.228910
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    iterator.batch_size = 2
    iterator.get_active_state = MagicMock(return_value=iterator)
    iterator.get_next_task_for_host = MagicMock(return_value=(iterator, iterator))
    iterator.is_failed = MagicMock(return_value=False)
    iterator.mark_host_failed = MagicMock(return_value=False)
    iterator.add_tasks = MagicMock(return_value=False)
    iterator.get_failed_hosts = MagicMock(return_value=False)
    iterator.get_failed_hosts.return_value = []
    iterator.get_failed_hosts.return_value = []
    iterator.get_failed_hosts.return_value = []


# Generated at 2022-06-17 14:17:24.433314
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    # Create a mock object for the play_context
    play_context = MagicMock()
    # Create a mock object for the StrategyModule
    strategy_module = MagicMock()
    # Create a mock object for the StrategyModule
    strategy_module.run(iterator, play_context)
    # Check if the method run of the class StrategyModule was called
    assert strategy_module.run.called


# Generated at 2022-06-17 14:17:26.073344
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy is not None


# Generated at 2022-06-17 14:18:48.377821
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    iterator.batch_size = 2
    iterator.get_active_state = MagicMock(return_value=iterator)
    iterator.get_next_task_for_host = MagicMock(return_value=(iterator, iterator))
    iterator.is_failed = MagicMock(return_value=False)
    iterator.mark_host_failed = MagicMock(return_value=None)
    iterator.add_tasks = MagicMock(return_value=None)
    iterator._play = MagicMock()
    iterator._play.max_fail_percentage = None
    iterator._play.get_variable_manager = MagicMock(return_value=iterator)
    iterator._play.get_loader = MagicMock(return_value=iterator)
    iterator._

# Generated at 2022-06-17 14:18:59.499881
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    iterator.batch_size = 1
    iterator.get_next_task_for_host.return_value = (None, None)
    iterator.is_failed.return_value = False
    iterator.mark_host_failed.return_value = None
    iterator.get_active_state.return_value = None
    iterator.get_failed_hosts.return_value = []
    iterator.get_failed_hosts.return_value = []
    iterator.get_failed_hosts.return_value = []
    iterator.get_failed_hosts.return_value = []
    iterator.get_failed_hosts.return_value = []
    iterator.get_failed_hosts.return_value = []

# Generated at 2022-06-17 14:19:10.228914
# Unit test for method run of class StrategyModule

# Generated at 2022-06-17 14:19:20.472303
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    iterator.batch_size = 1
    iterator.get_active_state = MagicMock(return_value=iterator)
    iterator.get_next_task_for_host = MagicMock(return_value=(iterator, iterator))
    iterator.is_failed = MagicMock(return_value=False)
    iterator.mark_host_failed = MagicMock(return_value=False)
    iterator.add_tasks = MagicMock(return_value=False)
    iterator.get_failed_hosts = MagicMock(return_value=False)
    iterator.get_failed_hosts.return_value = []
    iterator.get_failed_hosts.return_value = []
    iterator.get_failed_hosts.return_value = []


# Generated at 2022-06-17 14:19:23.439211
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a new StrategyModule object
    strategy_module = StrategyModule()

    # Check if the object is an instance of the class StrategyModule
    assert isinstance(strategy_module, StrategyModule)


# Generated at 2022-06-17 14:19:33.985592
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    iterator.batch_size = 1
    iterator.get_active_state = MagicMock(return_value=iterator)
    iterator.get_next_task_for_host = MagicMock(return_value=(iterator, iterator))
    iterator.mark_host_failed = MagicMock(return_value=iterator)
    iterator.is_failed = MagicMock(return_value=iterator)
    iterator.add_tasks = MagicMock(return_value=iterator)
    iterator._play = MagicMock()
    iterator._play.max_fail_percentage = None
    iterator._play.serial = 1
    iterator._play.strategy = 'linear'
    iterator._play.tags = []
    iterator._play.hosts = 'localhost'
    iterator._

# Generated at 2022-06-17 14:19:36.142955
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module = StrategyModule()
    assert module.run() == 'Not implemented.'

# Generated at 2022-06-17 14:19:47.224245
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    iterator.batch_size = 2
    iterator.get_active_state = MagicMock(return_value=iterator)
    iterator.get_next_task_for_host = MagicMock(return_value=(iterator, iterator))
    iterator.is_failed = MagicMock(return_value=False)
    iterator.mark_host_failed = MagicMock(return_value=False)
    iterator.add_tasks = MagicMock(return_value=False)
    iterator.get_failed_hosts = MagicMock(return_value=False)
    iterator.get_failed_hosts.return_value = ['host1', 'host2']
    iterator.get_failed_hosts.return_value = ['host1', 'host2']
    iterator

# Generated at 2022-06-17 14:19:49.761082
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:19:57.088440
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object for the iterator
    iterator = MagicMock()
    # Create a mock object for the play_context
    play_context = MagicMock()
    # Create a mock object for the StrategyModule
    strategy_module = MagicMock()
    # Create a mock object for the StrategyModule
    strategy_module.run(iterator, play_context)
    # Check if the run method of the StrategyModule was called
    assert strategy_module.run.called


# Generated at 2022-06-17 14:21:15.520544
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:21:22.346965
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object of class PlayContext
    play_context = MagicMock(spec=PlayContext)
    # Create a mock object of class TaskQueueManager
    tqm = MagicMock(spec=TaskQueueManager)
    # Create a mock object of class VariableManager
    variable_manager = MagicMock(spec=VariableManager)
    # Create a mock object of class Loader
    loader = MagicMock(spec=Loader)
    # Create a mock object of class Options
    options = MagicMock(spec=Options)
    # Create a mock object of class Inventory
    inventory = MagicMock(spec=Inventory)
    # Create a mock object of class Host
    host = MagicMock(spec=Host)
    # Create a mock object of class Task
    task = MagicMock(spec=Task)
    # Create a mock object of

# Generated at 2022-06-17 14:21:24.600437
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module is not None


# Generated at 2022-06-17 14:21:35.442280
# Unit test for method run of class StrategyModule

# Generated at 2022-06-17 14:21:46.903768
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock inventory
    inventory = InventoryManager(loader=None, sources='')
    # Create a mock variable manager
    variable_manager = VariableManager(loader=None, inventory=inventory)
    # Create a mock loader
    loader = DataLoader()
    # Create a mock options
    options = Options()
    # Create a mock passwords
    passwords = dict()
    # Create a mock stdout
    stdout = six.StringIO()
    # Create a mock tqm
    tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        options=options,
        passwords=passwords,
        stdout_callback=None,
    )
    # Create a mock play

# Generated at 2022-06-17 14:21:48.479171
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None

# Generated at 2022-06-17 14:21:53.073633
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module.get_name() == 'linear'
    assert strategy_module.get_hosts_left(None) == []
    assert strategy_module.get_next_task_lockstep(None, None) == []
    assert strategy_module.run(None, None) == 0

# Generated at 2022-06-17 14:21:54.686259
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-17 14:21:57.848212
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None, strategy='linear', host_list=[], options=None, variable_manager=None, loader=None, passwords=None)
    assert strategy_module is not None


# Generated at 2022-06-17 14:21:59.186358
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None
