

# Generated at 2022-06-25 12:09:19.398333
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:09:21.037287
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:09:24.390887
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test case 1
    test_case_0()

if __name__ == '__main__':
    # Test case 1
    test_StrategyModule()

# Generated at 2022-06-25 12:09:31.113561
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # input arguments for the strategy_module
    host = {'name': 'test'}
    task = {'name': 'test'}
    iterator = {'name': 'test'}
    play_context = {'name': 'test'}
    pbex = None
    strategy_module_0 = StrategyModule(pbex)
    try:
        retval = strategy_module_0.run(iterator, play_context)
        assert(retval == 0)
        print('test1: success')
    except Exception as e:
        print(e)
        print('test1: failed')


# Generated at 2022-06-25 12:09:35.575985
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule(b'\x13\xc0\xfc\xfe\xa0\xdcm\xebQ\x19\x81\x88\xcf\x87')
    strategy_module_0._tqm = QueueManager()
    iterator = Iterator(0)
    play_context = PlayContext()
    strategy_module_0.run(iterator, play_context)


# Test for method _take_step of class StrategyModule

# Generated at 2022-06-25 12:09:46.976906
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\x13\xc0\xfc\xfe\xa0\xdcm\xebQ\x19\x81\x88\xcf\x87'
    strategy_module_0 = StrategyModule(bytes_0)
    iterator_0 = StrategyModule(strategy_module_0)
    play_context_0 = StrategyModule()
    strategy_module_0.run(iterator_0, play_context_0)
    exception = None
    try:
        strategy_module_0.run(iterator_0, play_context_0)
    except Exception as e:
        exception = e
    assert type(exception) is AttributeError
    


# Generated at 2022-06-25 12:09:49.111043
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test for the constructor.
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:09:53.597034
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x13\xc0\xfc\xfe\xa0\xdcm\xebQ\x19\x81\x88\xcf\x87'
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:09:54.530558
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:10:01.868741
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_1 = b'\t{\x1c\xed\xcf\x8a\xb4\xe4\xa4\x0b0\x1fQ\x1d\xcb\x90\x98\xc4\x88\xa7\x0f'
    strategy_module_1 = StrategyModule(bytes_1)
    host_inventory_0 = HostInventory()
    iterator_1 = StrategyIterator(strategy_module_1, host_inventory_0)
    play_context_0 = PlayContext()
    strategy_module_1.run(iterator_1, play_context_0)


# Generated at 2022-06-25 12:10:57.027385
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\x13\xc0\xfc\xfe\xa0\xdcm\xebQ\x19\x81\x88\xcf\x87'
    strategy_module_0 = StrategyModule(bytes_0)
    dict_0 = {}
    play_context_0 = PlayContext(dict_0)
    iterator_0 = HostIterator(strategy_module_0)
    test_case_0(iterator_0, play_context_0)


# Generated at 2022-06-25 12:11:09.003779
# Unit test for method run of class StrategyModule

# Generated at 2022-06-25 12:11:10.358196
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Vi

# Generated at 2022-06-25 12:11:19.201092
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\x13\xc0\xfc\xfe\xa0\xdcm\xebQ\x19\x81\x88\xcf\x87'
    strategy_module_0 = StrategyModule(bytes_0)
    iterator_0 = set()
    play_context_0 = set()
    strategy_module_0.run(iterator_0, play_context_0)
    assert strategy_module_0._tqm._terminated


# Generated at 2022-06-25 12:11:20.370323
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:11:23.974865
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x13\xc0\xfc\xfe\xa0\xdcm\xebQ\x19\x81\x88\xcf\x87'
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:11:29.170167
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\xfe\xbe\xc1~\xa7\x81\xaex\xc7L\x9d\x10\xab\x18\x10'
    strategy_module_0 = StrategyModule(bytes_0)
    strategy_module_0.run(iterator, play_context)


# Generated at 2022-06-25 12:11:35.537196
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\x13\xc0\xfc\xfe\xa0\xdcm\xebQ\x19\x81\x88\xcf\x87'
    strategy_module_0 = StrategyModule(bytes_0)
    iterator_0 = Iterator(strategy_module_0)
    play_context_0 = PlayContext()
    strategy_module_0.run(iterator_0, play_context_0)

# Run the tests
#test_case_0()
test_StrategyModule_run()

# Generated at 2022-06-25 12:11:39.219388
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as exception_0:
        print("Error in test_case_0: %s" % exception_0)

# Initializes the module and calls the main function
if __name__ == "__main__":
    try:
        test_StrategyModule()
    except Exception as exception_0:
        print("Error in main: %s" % exception_0)

# Generated at 2022-06-25 12:11:40.358022
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:13:11.652211
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit test entry point
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:13:18.856137
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\x1f\x8f\x9a\xa6\x82J\xaf\x13\x89M\xc5\x1b\x0e\x9c\x02\xa2\xf6\xd5\x83b\xbe\x18\x01\x9d\xad\x0f\xf3'
    iterator = TaskIterator()
    play_context = PlayContext()
    strategy_module_0 = StrategyModule(bytes_0)
    strategy_module_0.run(iterator, play_context)
    return None


# Generated at 2022-06-25 12:13:22.005713
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_2 = b'\x83\xa6\xa5\xda\x06\xb6\xbe\xa0\xad\xf6\xc1$\xe3\x9eK\x93\x90\xb8l'
    strategy_module_0 = StrategyModule(bytes_2)


# Generated at 2022-06-25 12:13:25.070732
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\x13\xc0\xfc\xfe\xa0\xdcm\xebQ\x19\x81\x88\xcf\x87'
    strategy_module_0 = StrategyModule(bytes_0)
    strategy_module_0 = getattr(StrategyModule, 'run')
    assert_true(strategy_module_0)

# Generated at 2022-06-25 12:13:27.533758
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as exception:
        print(exception)

test_StrategyModule()

# Generated at 2022-06-25 12:13:35.632031
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_1 = b'\x12\xa1\xbb\xb2\x8d\x9a\xc3\xdd\x8d\x1f\x92\x90\x9e\x8f'
    strategy_module_0 = StrategyModule(bytes_1)
    iterator_0 = iterator_0 = Iterator([], 1, 1, 0)
    iterator_1 = iterator_1 = Iterator([], 1, 1, 0)
    strategy_module_0.run(iterator_0, iterator_1)

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 12:13:42.156359
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_1 = b'\x13\xc0\xfc\xfe\xa0\xdcm\xebQ\x19\x81\x88\xcf\x87'
    strategy_module_0 = StrategyModule(bytes_1)
    bytes_2 = b'\x02\xbb\x9d\x96\xc8\xdd\x80\x98\xf0\x8f\x0c\x9b\xd5'
    bytes_3 = b'\x90\x06\xd64\xd2?\xe2\x9d\xd0\xa7\xdd\x80\x98\xf0'

# Generated at 2022-06-25 12:13:43.814810
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:13:46.630002
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    host_0 = Host(name='host_0')
    task_result_0 = TaskResult(host_0)
    host_1 = Host(name='host_1')
    task_result_1 = TaskResult(host_1)
    strategy_module_0 = StrategyModule(task_result_0, task_result_1)
    strategy_module_0.run()


# Generated at 2022-06-25 12:13:55.191093
# Unit test for method run of class StrategyModule

# Generated at 2022-06-25 12:15:36.908127
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()


# Generated at 2022-06-25 12:15:40.299762
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\x13\xc0\xfc\xfe\xa0\xdcm\xebQ\x19\x81\x88\xcf\x87'
    strategy_module_0 = StrategyModule(bytes_0)

# test_case_0
if __name__ == '__main__':
    
    test_case_0()
    
    # Unit test for method run of class StrategyModule
    test_StrategyModule_run()

# Generated at 2022-06-25 12:15:42.404896
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x13\xc0\xfc\xfe\xa0\xdcm\xebQ\x19\x81\x88\xcf\x87'
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:15:46.908127
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\x13\xc0\xfc\xfe\xa0\xdcm\xebQ\x19\x81\x88\xcf\x87'
    strategy_module_0 = StrategyModule(bytes_0)
    bytes_1 = b'\xec\x17\x18\x8e\x13\xa1\x1f\xad\xea\xec\xba\xd1'
    iterator_0 = Iterator(bytes_1)
    strategy_module_0.run(iterator_0)

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 12:15:47.582326
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:15:53.918970
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\x13\xc0\xfc\xfe\xa0\xdcm\xebQ\x19\x81\x88\xcf\x87'
    strategy_module_0 = StrategyModule(bytes_0)

# Generated at 2022-06-25 12:15:54.662792
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:16:00.742499
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\x13\xc0\xfc\xfe\xa0\xdcm\xebQ\x19\x81\x88\xcf\x87'
    strategy_module_0 = StrategyModule(bytes_0)

    bytes_0 = b'\x13\xc0\xfc\xfe\xa0\xdcm\xebQ\x19\x81\x88\xcf\x87'
    iterator_0 = PlayIterator(bytes_0)

    bytes_0 = b'\x13\xc0\xfc\xfe\xa0\xdcm\xebQ\x19\x81\x88\xcf\x87'
    play_context_0 = PlayContext(bytes_0)


# Generated at 2022-06-25 12:16:01.871245
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("TEST: test_StrategyModule_run")

    strategy_module_0 = StrategyModule()


# Generated at 2022-06-25 12:16:06.634676
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x13\xc0\xfc\xfe\xa0\xdcm\xebQ\x19\x81\x88\xcf\x87'
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:18:16.667537
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    playbook0 = AnsiblePlaybook()
    playbook0.set_variable_manager(VariableManager())
    playbook0.set_loader(DataLoader())
    playbook = playbook0
    strategy_module = StrategyModule()
    strategy_module.set_tqm(TaskQueueManager())
    strategy_module.set_loader(DataLoader())
    strategy_module.set_variable_manager(VariableManager())
    iterator = HostIterator()
    play_context = PlayContext()
    strategy_module.run(iterator, play_context)


# Generated at 2022-06-25 12:18:18.773164
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 12:18:19.942236
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:18:21.668516
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True

# end of class StrategyModule.

# class StrategyModule


# Generated at 2022-06-25 12:18:25.873990
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule()
    assert isinstance(strategy_module_1, StrategyModule)



# Generated at 2022-06-25 12:18:28.029743
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_1 = StrategyModule()
    # Get a next task to run
    iterator = None
    play_context = None
    strategy_module_1.run(iterator, play_context)



# Generated at 2022-06-25 12:18:34.834860
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule()
    assert strategy_module_1.__doc__ == "The linear strategy is simple - get the next task and queue\n        it for all hosts, then wait for the queue to drain before\n        moving on to the next task"
    assert strategy_module_1.__init__.__doc__ == "StrategyModule constructor"
    assert strategy_module_1.get_hosts_left.__doc__ == "Returns a list of all hosts which have not yet had all of their\n        tasks completed\n        "
    assert strategy_module_1.get_failed_hosts.__doc__ == "Returns a list of all failed hosts"

# Generated at 2022-06-25 12:18:36.308316
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule()
    strategy_module_0.run()


# Generated at 2022-06-25 12:18:38.547956
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # An instance of the class to be tested
    strategy_module = StrategyModule()

    # The iterator
    iterator = Iterator()

    # The play_context
    play_context = PlayContext()

    result = strategy_module.run(iterator, play_context)


# Generated at 2022-06-25 12:18:40.927444
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert isinstance(strategy_module, StrategyModule)
