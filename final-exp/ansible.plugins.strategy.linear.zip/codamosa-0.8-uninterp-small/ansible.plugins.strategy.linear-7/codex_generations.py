

# Generated at 2022-06-25 12:09:26.285864
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    data_set_0 = set()
    strategy_module_0 = StrategyModule(data_set_0)
    strategy_module_0.dump_opts = {'_text2': 'n/a ', '_text1': 'v2_playbook_on_no_hosts_remaining', '_text3': None}
    iterator_0 = PlayIterator()
    play_context_0 = PlayContext()
    r = strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:09:30.013291
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)

if __name__ == '__main__':
    #test_StrategyModule()
    print('Current module name: %s' % __name__)

# Generated at 2022-06-25 12:09:33.087495
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    s_module_0 = StrategyModule()
    attr_0 = s_module_0.run
    try:
        attributeError
    except NameError:
        pass
    else:
        raise Exception("Shouldn't have thrown AttributeError")
    try:
        attributeError
    except NameError:
        pass
    else:
        raise Exception("Shouldn't have thrown AttributeError")


# Generated at 2022-06-25 12:09:35.544239
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    iterator_0 = None
    play_context_0 = None
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:09:40.192385
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = test_case_0()
    assert(result is None)
    print('Test StrategyModule succeed!')
# end


if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:09:42.028113
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:09:46.479689
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    
    iterator_0 = iterator.TaskIterator(set_0)
    play_context_0 = PlayContext()

    strategy_module_0.run(iterator_0, play_context_0)

# Generated at 2022-06-25 12:09:50.901923
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    tqm_0 = TestTQM(dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict())
    strategy_module_0.set_tqm(tqm_0)
    strategy_module_0.set_inventory(set_0)
    loader_0 = DataLoader()
    strategy_module_0.set_loader(loader_0)
    variable_manager_0 = VariableManager()
    strategy_module_0.set_variable_manager(variable_manager_0)
    task_iterator_0 = TaskIterator(set_0, set_0, set_0, set_0)
    strategy_module

# Generated at 2022-06-25 12:09:56.374956
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    iterator_0 = BasicIterator()
    play_context_0 = PlayContext()
    # The run method of class StrategyModule can have an AssertionError exception
    try:
        strategy_module_0.run(iterator_0, play_context_0)
    except AssertionError as exception_0:
        # Preserve the exception
        exception_0_object = sys.exc_info()
        exception_0_type = exception_0.__class__.__name__
        exception_0_message = exception_0.message
        sys.exc_clear()
        raise AssertionError(exception_0_object, exception_0_type, exception_0_message)


# Generated at 2022-06-25 12:10:04.152424
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception:
        import traceback
        traceback.print_exc()
        assert False


# Generated at 2022-06-25 12:10:43.994040
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.vars.manager import VariableManager
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import connection_loader
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)

    class TaskQueueManager0(TaskQueueManager):
        def __init__(self, list_0):
            self._hostvars = list_0


# Generated at 2022-06-25 12:10:49.291048
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)

    #case 1
    iterator_0 = Iterator()
    play_context_0 = PlayContext()
    strategy_module_0.run(iterator_0, play_context_0)

    #case 2
    iterator_0 = Iterator()
    play_context_0 = PlayContext()
    strategy_module_0.run(iterator_0, play_context_0)

    #case 3
    iterator_0 = Iterator()
    play_context_0 = PlayContext()
    strategy_module_0.run(iterator_0, play_context_0)

# Generated at 2022-06-25 12:10:51.226811
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set(["test"])
    strategy_module_0 = StrategyModule(set_0)
    assert strategy_module_0._block_list is set_0


# Generated at 2022-06-25 12:10:53.657185
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Test the constructor
    '''
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    print("function %s : passed\n" % sys._getframe().f_code.co_name)


# Generated at 2022-06-25 12:10:56.448836
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    iterator_0 = Iterator()
    play_context_0 = PlayContext()

    return_value_0 = strategy_module_0.run(iterator_0, play_context_0)

# Generated at 2022-06-25 12:11:08.692362
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    strategy_module_0.add_active_connection = mock.Mock()
    set_1 = set()
    strategy_module_0._tqm._workers = set_1
    iterator_0 = HostVarIterator([], {}, {}, set_1)
    set_2 = set()
    iterator_0._hosts = set_2
    iterator_0._host_states = {}
    iterator_0._host_state = None
    iterator_0._tqm = strategy_module_0._tqm
    iterator_0._variable_manager = strategy_module_0._variable_manager
    iterator_0._cur_state = {}
    iterator_0._cur_block = None
    iterator_0._included_files_v

# Generated at 2022-06-25 12:11:19.803451
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Positive test
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    iterator_0 = MockIterator()
    play_context_0 = PlayContext()
    strategy_module_0.run(iterator_0, play_context_0)
    # Negative test
    strategy_module_1 = StrategyModule(set_0)
    play_context_1 = PlayContext()
    try:
        strategy_module_1.run(iterator_0, play_context_1)
    except BaseException as e:
        display.debug(to_text(e), wrap_text=False)
        assert False



# Generated at 2022-06-25 12:11:24.438090
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    iterator_0 = iterator()
    play_context_0 = play_context()
    strategy_module_0.run(iterator_0, play_context_0)

if __name__ == "__main__":
    test_case_0()
    test_StrategyModule_run()

# Generated at 2022-06-25 12:11:29.772808
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # test 1
    set_0 = set()
    StrategyModule_0 = StrategyModule(set_0)
    iterator_0 = iterator_0_yield_from_()
    play_context_0 = PlayContext()
    result = StrategyModule_0.run(iterator_0, play_context_0)
    assert result == 0



# Generated at 2022-06-25 12:11:32.359439
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_1 = set()
    strategy_module_1 = StrategyModule(set_1)
    # assert strategy_module_1.set == set_1


# Generated at 2022-06-25 12:13:45.744788
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-25 12:13:54.729366
# Unit test for method run of class StrategyModule

# Generated at 2022-06-25 12:13:58.200786
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    obj_0 = StrategyModule(set_0)
    assert isinstance(obj_0, StrategyModule)
    assert isinstance(obj_0, BaseExecutionStrategy)
    assert isinstance(obj_0, object)
    assert isinstance(obj_0, PlayContext)
    assert isinstance(obj_0, CallbackBase)


# Generated at 2022-06-25 12:13:59.561615
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)


# Generated at 2022-06-25 12:14:00.878475
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)



# Generated at 2022-06-25 12:14:02.663365
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    assert False
    assert False
    assert False


# Generated at 2022-06-25 12:14:03.399821
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:14:04.530776
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)


# Generated at 2022-06-25 12:14:13.764238
# Unit test for method run of class StrategyModule

# Generated at 2022-06-25 12:14:21.170087
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # Set to True or False depending on whether you want to run this test
    run_test = True

    if run_test == False:
        return

    strategy_module_0 = StrategyModule()
    # AssertionError is expected
    with pytest.raises(AssertionError):
        strategy_module_0.run(None, None)

    # AssertionError is expected
    with pytest.raises(AssertionError):
        strategy_module_0.run('str_0', None)

    # AssertionError is expected
    with pytest.raises(AssertionError):
        strategy_module_0.run(None, 'str_0')

    # TypeError is expected

# Generated at 2022-06-25 12:18:01.315830
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)


# Generated at 2022-06-25 12:18:02.618253
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    assert type(strategy_module_0) is StrategyModule


# Generated at 2022-06-25 12:18:04.420171
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    iterator_0 = None
    play_context_0 = None
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:18:06.272867
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    iterator_0 = None
    play_context_0 = None
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:18:10.807986
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    assert strategy_module_0.run(iterator, play_context) == 'ok'
    assert strategy_module_0.run(iterator_0, play_context) > 0
    assert strategy_module_0.run(iterator_1, play_context) > 0
    assert strategy_module_0.run(iterator_2, play_context) == 'failed'
    assert strategy_module_0.run(iterator_3, play_context) == 'failed'
    assert strategy_module_0.run(iterator_4, play_context) == 'failed'
    assert strategy_module_0.run(iterator_5, play_context) == 'failed'

# Generated at 2022-06-25 12:18:11.610868
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Testing StrategyModule...')
    test_case_0()


# Generated at 2022-06-25 12:18:12.635239
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)


# Generated at 2022-06-25 12:18:15.949400
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    set_0 = set()
    strategy_module_0 = StrategyModule(set_0)
    assert strategy_module_0.task_queue_manager is None 
    assert strategy_module_0.host_list is set_0 
    assert strategy_module_0.blocked_hosts == {} 
    assert strategy_module_0.active_connections == {} 
    assert strategy_module_0.pending_results == 0 
    assert strategy_module_0.step is False 


# Generated at 2022-06-25 12:18:19.025962
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # should not throw an exception
    test_case_0()

if __name__ == '__main__':
    import __main__
    import sys

    sys.modules[__main__.__name__] = __main__

    test_StrategyModule()

# Generated at 2022-06-25 12:18:20.151038
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()