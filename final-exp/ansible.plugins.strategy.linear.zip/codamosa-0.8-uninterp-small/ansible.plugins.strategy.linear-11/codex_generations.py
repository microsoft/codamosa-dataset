

# Generated at 2022-06-25 12:09:31.115391
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    #
    # set up
    #
    str_0 = 'ZB,!G2Z&Cr%-=E@'
    strategy_module_0 = StrategyModule(str_0)
    iterator_0 = iterator.Iterator(strategy_module_0)
    play_context_0 = playbook.PlayContext()
    #
    # run
    #
    strategy_module_0.run(iterator_0, play_context_0)
    #
    # tear down
    #


if __name__ == "__main__":
    import sys
    import inspect

    test_case_0()

    members = inspect.getmembers(sys.modules[__name__], inspect.isfunction)

# Generated at 2022-06-25 12:09:34.718850
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    s0 = StrategyModule('ZB,!G2Z&Cr%-=E@')
    iterator = s0._get_iterator()
    iterator._play = 'ZB,!G2Z&Cr%-=E@'
    play_context = 'ZB,!G2Z&Cr%-=E@'
    s0.run(iterator, play_context)


# Generated at 2022-06-25 12:09:35.500874
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:09:37.244258
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:09:38.885128
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:09:41.038014
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule()
    iterator = None

    # Test case 1
    try:
        strategy_module_0.run(iterator, iterator)
    except AnsibleError as e:
        pass


# Generated at 2022-06-25 12:09:43.650030
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:09:45.719384
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 12:09:48.799148
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    import sys
    test_StrategyModule()
    print('\nAll test case passed!')
    sys.exit(0)

# Generated at 2022-06-25 12:09:51.341720
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\nUnit test for constructor of class StrategyModule")
    test_case_0()

# Usage main

# Generated at 2022-06-25 12:11:04.202353
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert_true(isinstance(sm,BaseStrategyModule))


# Unit tests for method create_lock_dir. Unit testing will create
# the lock directory at /tmp/ansible_locks.
# Please make sure that the test_create_lock_dir method is the first test
# in the file, since the clean up method is called at the end of test
# method test_create_lock_dir and if this is not the first test method,
# then clean up method will not be called and lock directory will not be deleted.

# Generated at 2022-06-25 12:11:10.703933
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # StrategyModule.__init__(tqm, hosts, tqm_variables, loader, options, passwords, stdout_callback, run_additional_callbacks=True, run_tree=False, variable_manager=None, load_callbacks=True)
    module = StrategyModule(tqm = None, hosts = None, tqm_variables = None, loader = None, options = None, passwords = None, stdout_callback = None, run_additional_callbacks=True, run_tree=False, variable_manager=None, load_callbacks=True)
    assert module is not None

# Generated at 2022-06-25 12:11:22.885931
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    class FakeTqm:
        class FakeHost:
            name = 'host'
            vars = dict()
            _vars_per_host = dict()
            failed = False
            unreachable = False
            _connections = dict()
            _variable_manager = dict()
            _task = None
            _play = None
            def get_name(self):
                return self.name
            def set_variable_manager(self, variable_manager):
                self._variable_manager = variable_manager
            def set_task(self, task):
                self._task = task
            def set_play(self, play):
                self._play = play

        class FakePlay:
            name = 'play'
            _included_files = []
            hosts = ['host']
            _handlers = []
            _tasks = []

# Generated at 2022-06-25 12:11:24.062412
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # execute test
    pass

# Generated at 2022-06-25 12:11:30.108824
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # create object
    args = ""
    kwargs = {'loader':None, 'inventory':None, 'variable_manager':None, 'stdout_callback':None, 'options':None}
    strategy_module = StrategyModule(args, kwargs)
    # call method
    # args = strategy_module.run(iterator, play_context)
    # assert result

# Tests of class StrategyModule

# Generated at 2022-06-25 12:11:32.698703
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    template = StrategyModule()
    if type(template) is StrategyModule:
        print("Test passed")
    else:
        print("Test failed")


# Generated at 2022-06-25 12:11:37.319807
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    try:
        _StrategyModule = StrategyModule()
        #_iterator, _play_context
        assert 'RUN_OK' in _StrategyModule.run(_iterator, _play_context)
        return 0
    except Exception as e:
        print(e)
        return 1

_StrategyModule = StrategyModule()

# Class StrategyBase defines all the methods needed to run ansible strategies
# It is a base class for all strategies

# Generated at 2022-06-25 12:11:40.411545
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = DummyTaskQueueManager()
    assert isinstance(tqm, DummyTaskQueueManager)
    strategy = StrategyModule(tqm)
    assert strategy is not None
    assert isinstance(strategy, StrategyModule)
    assert strategy._tqm == tqm
    assert strategy._tqm._terminated == False


# Generated at 2022-06-25 12:11:45.192136
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule('/foo', {}, {}, True, True, 'bar', 'baz', 'bam')
    assert s._disabled is True
    assert s._loader_path is '/foo'
    assert s._loader_roles_path == []
    assert s._shared_loader_obj
    assert s._variable_manager_class is 'bar'
    assert s._inventory_manager_class is 'baz'

# Generated at 2022-06-25 12:11:52.490431
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test: initialize StrategyModule with invalid tqm
    try:
        null_tqm = None
        s = StrategyModule(tqm=null_tqm)
        assert False
    except AnsibleError:
        pass

    # Test: initialize StrategyModule with a valid tqm
    tqm = TaskQueueManager(inventory=InventoryManager(loader=None, sources='localhost,'), variable_manager=None, loader=None)
    s = StrategyModule(tqm=tqm)
    assert type(s) == StrategyModule
    assert s.get_worker_threads() == C.DEFAULT_FORKS
    assert s._workers_count == 1

# Generated at 2022-06-25 12:14:50.965091
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Creating variables for test
    _tqm = MagicMock()
    iterator = MagicMock()
    play_context = MagicMock()
    action_loader = MagicMock()
    loader = MagicMock()
    variable_manager = MagicMock()
    shared_loader_obj = MagicMock()
    final_q = MagicMock()
    strategy_host_state_noop_count = None
    display = MagicMock()
    host_state_noop_count = dict()
    hosts_state_noop_count = dict()
    blocked_hosts = dict()
    hosts_all_results = dict()
    pending_results = dict()
    hosts_results = dict()
    host_consumed = dict()
    hosts_consumed = dict()
    hosts_queue_items = dict()
    hosts

# Generated at 2022-06-25 12:14:57.418418
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  module = ansible.plugins.loader.action_loader.get('copy', class_only=True)
  task = Task()
  task.set_loader(DictDataLoader({
    'tasks/foo.yml': '- name: foo\n  copy: src=a dest=b'
  }))
  task.action = 'copy'
  task.args = {'src': 'a', 'dest': 'b'}
  play_context = PlayContext()
  result = StrategyModule.run(module, task, play_context)
  assert result == {'invocation': {'module_name': 'copy', 'module_args': {'dest': 'b', 'src': 'a'}}, 'changed': False, 'failed': False}


# Generated at 2022-06-25 12:15:06.532877
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a test tqm object
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
    )

    # Create a test StrategyModule object
    test_strategy_module = StrategyModule(tqm)

    # Create a test iterator
    test_iterator = iterator.Iterator(
        tqm=tqm,
        inventory=None,
        variable_manager=None,
        loader=None,
        play=None,
        play_context=None,
    )

    # Create a test play context

# Generated at 2022-06-25 12:15:07.042379
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass



# Generated at 2022-06-25 12:15:13.627791
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 12:15:21.239878
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    
    mock_iterator = Mock()
    mock_iterator._play = set_up_iterator_test_data()

    mock_play_context = Mock()
    mock_play_context.prompt = 'test prompt'

    mock_loader = Mock()

    mock_variable_manager = Mock()
    mock_variable_manager.get_vars.return_value = {'mock_key' : 'mock_value'}

    mock_shared_loader_obj = Mock()
    mock_shared_loader_obj.module_loader = 'test_module_loader'

    mock_display = Mock()

    mock_all_vars = Mock()
    mock_all_vars.get_vars.return_value = {'mock_key' : 'mock_value'}

    mock_task_queue_manager = Mock()

# Generated at 2022-06-25 12:15:29.258103
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import os
    from ansible import constants as C

    # Create a new instance of a data loader.
    loader = DataLoader()

    # Create a new instance of a variable manager.
    variable_manager = VariableManager()

    # Create a new instance of the TQM to setup the queue manager, host inventory and variable manager
    tqm = TaskQueueManager(
        inventory=Inventory(loader=loader, variable_manager=variable_manager, host_list=os.getcwd() + '/tests/inventory'),
        variable_manager=variable_manager,
        loader=loader,
        passwords=dict(vault_pass='secret'),
        stdout_callback=None,
    )

    # Create a new instance of a playbook executor, using the CLASSIC strategy

# Generated at 2022-06-25 12:15:30.009864
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(), StrategyModule)

# Generated at 2022-06-25 12:15:31.167898
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    '''
    Unit test for method run of class StrategyModule
    '''
    pass

# Generated at 2022-06-25 12:15:34.453726
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.debug("create a StrategyModule object and assign it to variable strategy_module")
    strategy_module = StrategyModule(
        tqm=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
    )

    display.debug("assert that variable strategy_module is an instance of "
                  "the class StrategyModule")
    assert(isinstance(strategy_module, StrategyModule))
