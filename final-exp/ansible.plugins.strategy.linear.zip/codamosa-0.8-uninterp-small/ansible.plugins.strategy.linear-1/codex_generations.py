

# Generated at 2022-06-25 12:09:24.189653
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()


# Generated at 2022-06-25 12:09:26.682187
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    """Test the StrategyModule class, method run"""
    print('Testing StrategyModule, method run')
    test_case_0()
    print('    >> all tests passed')


# Generated at 2022-06-25 12:09:34.660786
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    host_0 = Host('host_0')
    inventory_0 = InventoryManager(hosts=[host_0])
    play_context_0 = PlayContext()
    host_1 = Host('host_1')
    host_2 = Host('host_2')
    role_0 = Role()
    role_0._role_name = 'role_0_name'
    handler_0 = Handler()
    handler_0._name = 'handler_0_name'
    handler_0._action = 'handler_0_action'
    handler_0._tags = ['handler_0_tags']
    role_0._handlers = [handler_0]
    task_0 = Task()
    task_0._role = role_0
    role_1 = Role()
    role_1._role_name = 'role_1_name'


# Generated at 2022-06-25 12:09:37.066072
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    try:
        test_case_0()
        print("test case 0 passed.")

    except Exception as e_0:
        print("test case 0 failed")
        print(e_0)


if __name__ == "__main__":

    test_StrategyModule()

# Generated at 2022-06-25 12:09:41.065544
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test_case_0(strategy_module_0)
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:09:52.584292
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("Test: run")
    test_case_0()

# No unit test for method _load_included_file of class StrategyModule
# No unit test for method _copy_included_file of class StrategyModule
# No unit test for method _prepare_and_create_noop_block_from of class StrategyModule
# No unit test for method _execute_meta of class StrategyModule
# No unit test for method _get_next_task_lockstep of class StrategyModule
# No unit test for method _set_hosts_cache of class StrategyModule
# No unit test for method _take_step of class StrategyModule
# No unit test for method _wait_on_pending_results of class StrategyModule
# No unit test for method _process_pending_results of class StrategyModule
# No unit test for method add_tqm_variables of

# Generated at 2022-06-25 12:09:55.494959
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception:
        print('CTF-Python-APT{}'.format(__file__[-4:].replace('_','-').replace('.','0')))

# Generated at 2022-06-25 12:09:58.555219
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-25 12:10:02.001481
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    args_0 = '\\7'
    strategy_module_0 = StrategyModule(args_0)
    #iterator_0 = Iterator(iterator)
    play_context_0 = PlayContext()
    iterator_0 = 0
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:10:05.042606
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import tempfile
    from ansible.utils.display import Display
    from ansible.plugins.strategy.linear import StrategyModule
    import sys
    import os

    fd, temp_path = tempfile.mkstemp()
    sys.stdout = os.fdopen(fd, 'w')

    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 12:11:02.362496
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()
# test_StrategyModule_run()


# Generated at 2022-06-25 12:11:08.040171
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

# Program entry
if __name__ == '__main__':
    # Configure the logger
    if not logger.handlers:
        configure_logger()

    # Start unit test
    test_StrategyModule_run()
    test_AsyncTaskExecutor_run()
    test_TaskQueueManager_run()
    test_PlaybookExecutor_run()
    test_CLI_main()

# Generated at 2022-06-25 12:11:12.894937
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str1 = StrategyModule(hosts=2, tqm=None, loader=None, variable_manager=None, shared_loader_obj=None)
    test_case_0()
    #assert  == True
    return True
# test_StrategyModule_run()


# Generated at 2022-06-25 12:11:14.820878
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()


# Generated at 2022-06-25 12:11:17.621605
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # str_0 = 'w'
    test_case_0()


# Generated at 2022-06-25 12:11:20.229596
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    dict0 = {'w':'w', 'c':'c'}
    assert dict0 == dict(tuple(dict0.items()))
    return


# Generated at 2022-06-25 12:11:30.628275
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print(sys._getframe().f_code.co_name)
    # NOTE: one shall note that this file was manually editted by changing
    # the filename of module 'ansible.plugins.strategy.linear.Linear' to
    # 'ansible.plugins.strategy.linear.StrategyModule'

    # To run this unit test:
    # $ nosetests ansible/plugins/strategy/linear.py
    # - or -
    # $ nosetests ansible/plugins/strategy/linear.py:test_StrategyModule_run

    # create a mock for the 'QueueManager' class
    class tqm(object):
        '''
        This class is used to mock the internal class 'QueueManager'
        '''

# Generated at 2022-06-25 12:11:38.771700
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create a config object
    config_0 = ConfigParser.ConfigParser()
    config_0.read('/etc/ansible/ansible.cfg')

    # create a loader object
    loader_0 = DataLoader(None)

    # create a play_context object
    play_context_0 = PlayContext()

    # create a options object
    options_0 = Options()

    # create a inventory object
    inventory_0 = Inventory(loader_0, host_list=['localhost'], sources='/etc/ansible/hosts')

    # create a variable_manager object
    variable_manager_0 = VariableManager(loader=loader_0, inventory=inventory_0)

    # create a passwords object
    passwords_0 = passwords()

    # create a callback_loader object

# Generated at 2022-06-25 12:11:40.944213
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    _iterator = None
    _play_context = None
    _result = None

    # Expected call
    test_case_0()

    # Expected call
    _result = strategy_loader._load_strategy(strategy_loader.C.STRATEGY_LINEAR)

# Generated at 2022-06-25 12:11:42.146947
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:13:06.025095
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('\n========= Test StrategyModule =======')
    names, hosts, tqm, share_vars, loader, options, passwords, callback, stdout_callback = None, None, None, None, None, None, None, None, None
    strategy_0 = StrategyModule(names, hosts, tqm, share_vars, loader, options, passwords, callback, stdout_callback)
    print('\nStrategyModule: ', strategy_0)
    str_0 = str(strategy_0)
    print('\nstrategy_0: ', str_0)
    print('\n======================================\n')


# Generated at 2022-06-25 12:13:07.901453
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # try simple test case for this method
    strategy_module_instance = StrategyModule([])
    test_case_0()
    pass

# Unit tests for class StrategyModule

# Generated at 2022-06-25 12:13:11.684412
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\nTest StrategyModule constructor...")
    tqm_0 = TaskQueueManager(inventory=None, variable_manager=None, loader=None)
    strategy_obj_0 = StrategyModule(tqm_0, 1)
    return


# Generated at 2022-06-25 12:13:14.751732
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    c = StrategyModule()
    c.init()
    c.run()
    pass


# Generated at 2022-06-25 12:13:19.862597
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # unit test run method
    test_play = Play().load(dict(
        name = "Ansible Play",
        hosts = "all",
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='test', args='foo=bar'))
        ]
    ), variable_manager=variable_manager, loader=loader)
    result = ResultCallback()
    test_strategy = StrategyModule(tqm=TestTaskQueueManager(inventory=TestInventory(), loader=loader, variable_manager=variable_manager, result_callback=result), play=test_play)
    test_iterator = TaskIterator(play=test_play, play_context=play_context, variable_manager=variable_manager, all_vars=dict())

# Generated at 2022-06-25 12:13:20.738921
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

# Generated at 2022-06-25 12:13:23.646090
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = 'w'
    str_2 = 'q'
    str_3 = 'a'
    str_4 = 'z'
    StrategyModule(str_1, str_2, str_3, str_4)

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:13:26.741466
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule(loader=None, variable_manager=None, host_list=None, options=None, shared_loader_obj=None, variable_manager_obj=None, host_manager_obj=None, stdout_callback=None)
    strategy_module.run(iterator='iterator_0', play_context='play_context_0')
    assert True # TODO: implement your test here


# Generated at 2022-06-25 12:13:31.114787
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    arg_0 = 'w'
    arg_1 = 'w'
    arg_2 = 'w'
    obj_3 = StrategyModule(arg_1, arg_2)
    obj_3.run(arg_0)
test_StrategyModule_run()

# Generated at 2022-06-25 12:13:34.142582
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Local Variables:
# # tab-width:4
# # indent-tabs-mode:nil
# # End:
# vim: set syntax=python expandtab tabstop=4 shiftwidth=4:

# Generated at 2022-06-25 12:16:31.716916
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #test_case_0()
    pass
#
#
#

# Generated at 2022-06-25 12:16:34.281900
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategyModule_0 = StrategyModule()
    iterator_0 = iterator()
    play_context_0 = play_context()
    try:
        strategyModule_0.run(iterator_0, play_context_0)
    except(TypeError):
        print("TypeError")


# Generated at 2022-06-25 12:16:36.015932
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as e:
        print(e)


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:16:38.729238
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    obj_0 = StrategyModule()
    obj_0.run(iterator, play_context)
    obj_0.run(iterator, play_context)
    obj_0.run(iterator, play_context)
    obj_0.run(iterator, play_context)
    obj_0.run(iterator, play_context)

# Generated at 2022-06-25 12:16:39.975898
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = StrategyModule()
    assert str_0 is not None, 'Failed creating a StrategyModule'



# Generated at 2022-06-25 12:16:42.624333
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Test case 0: default case
    _hosts = [
        {
            'name': 'a'
        },
        {
            'name': 'b'
        },
        {
            'name': 'c'
        }
    ]

    iterator = TaskIterator(_hosts=_hosts)



# Generated at 2022-06-25 12:16:44.740619
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()

    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:16:53.375071
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # ansible.errors.AnsibleModuleError: Missing required argument
    ansible.errors.AnsibleModuleError = exceptions.Exception
    setattr(ansible.errors.AnsibleModuleError, 'message', str_0)
    # ansible.parsing.yaml.objects.AnsibleBaseYAMLObject.bad_end_marker:abc,,,,,
    ansible.parsing.yaml.objects.AnsibleBaseYAMLObject = exceptions.Exception
    setattr(ansible.parsing.yaml.objects.AnsibleBaseYAMLObject, 'message', b'Error: ansible.parsing.yaml.objects.AnsibleBaseYAMLObject.bad_end_marker')
    # ansible.vars.hostvars.HostVars:abc,,,,,
    ans

# Generated at 2022-06-25 12:16:55.013034
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = StrategyModule('/home/burtnolej/Development/pythonapps3/clean/ansible/lib/ansible/executor/v2_task_queue_manager')


# Generated at 2022-06-25 12:16:58.417525
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print('*** Test for method run of class StrategyModule')
    print('*** Result should be the same')
    print('*** Input:')
    for arg in [test_case_0]:
        print('*** iterator = ' + arg[0])
        print('*** play_context = ' + arg[1])
    print('*** Result:')
    print('*** ' + StrategyModule().run(test_case_0))

# Test for class StrategyModule