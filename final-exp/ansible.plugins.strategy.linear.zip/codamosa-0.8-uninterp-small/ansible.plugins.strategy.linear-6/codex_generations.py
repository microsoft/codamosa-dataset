

# Generated at 2022-06-25 12:09:22.143769
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\x86\xea'
    strategy_module_0 = StrategyModule(bytes_0)
    iterator_0 = None
    play_context_0 = None
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:09:26.899499
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\x86\xea'
    strategy_module_0 = StrategyModule(bytes_0)

    strategy_module_0.run(strategy_module_0.tqm, None)

    # after execution, the object should be garbage-collectible
    garbage_collect()


# Generated at 2022-06-25 12:09:28.919226
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as e:
        print(repr(e))
        assert False


# Generated at 2022-06-25 12:09:32.575304
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = b'\x8d\xca\x1f\x1a\x8e'
    strategy_module_0 = StrategyModule(bytes_0)
    result_boolean_0 = strategy_module_0.run(None, None)

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 12:09:38.808365
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import AggregateVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.errors import AnsibleError

# Generated at 2022-06-25 12:09:47.063001
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # create an instance of the StrategyModule
    strategy_module_0 = StrategyModule(bytes_0)

    # get the run method of StrategyModule and set the first argument
    strategy_module_run_0 = strategy_module_0.run
    iterator = iterator_0
    play_context = play_context_0

    # invoke the run method
    return_value = strategy_module_run_0(iterator, play_context)

# Assign our test case modules and unit test functions to the run_list variable

# Generated at 2022-06-25 12:09:57.256532
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import threading
    import os
    import tempfile
    import sys
    import traceback
    import ansible.constants as C
    import ansible.defaults as defaults
    import ansible.utils
    import ansible.utils.template
    import ansible.utils.vars
    import ansible.inventory.manager
    import ansible.playbook.play
    import ansible.cli
    import ansible.cli.playbook
    import ansible.playbook.play_context
    import ansible.playbook.playbook
    import ansible.playbook.task_include
    import ansible.vars
    import ansible.vars.manager

    from ansible.errors import AnsibleError, AnsibleOptionsError, AnsibleUndefinedVariable, AnsibleFileNotFound
    from ansible.module_utils.six import string_

# Generated at 2022-06-25 12:10:01.099228
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  # Test case 0
  bytes_0 = b'\x86\xea'
  strategy_module_0 = StrategyModule(bytes_0)
  iterator_0 = None
  play_context_0 = None
  # assert strategy_module_0.run(iterator_0, play_context_0) == 0


# Generated at 2022-06-25 12:10:03.280923
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Input parameters
    iterator = 'iterator'
    play_context = 'play_context'
    
    strategy_module_0 = StrategyModule()
    assert strategy_module_0.run(iterator, play_context) == None

# Generated at 2022-06-25 12:10:05.638082
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x86\xea'
    strategy_module_0 = StrategyModule(bytes_0)
    test_case_0()

# Generated at 2022-06-25 12:10:52.071609
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    connection = MockConnection()
    play_context = MockPlayContext()
    play_context._connection._shell.proc.poll.return_value = 0
    play_context._shell.run.return_value = (0, '', '', '')
    iterator = MockTaskIterator()
    base_loader = MockBaseLoader()
    variable_manager = MockVariableManager()

    strategy_module = StrategyModule(connection, play_context, iterator, base_loader, variable_manager)
    assert isinstance(strategy_module, StrategyModule)
    assert strategy_module.connection == connection
    assert strategy_module.play_context == play_context
    assert strategy_module.iterator == iterator
    assert strategy_module.loader == base_loader
    assert strategy_module.variable_manager == variable_manager


# Generated at 2022-06-25 12:11:02.513539
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create new class strategyModule, named strategyModule
    strategyModule = StrategyModule()
    # Create new class iterator, named iterator
    iterator = iterator()
    # Create new class PlayContext, named play_context
    play_context = PlayContext()

    # Check if host is in the list of failed_hosts
    assert strategyModule._tqm._failed_hosts["host"] not in strategyModule._tqm._failed_hosts.keys()
    # Check if result is not equal to 0
    assert strategyModule._tqm.RUN_OK != 0

    # Check if there is a task with tag 'hello'
    assert "hello" in strategyModule._tqm._tags

    # Check if there is a task with tag 'world'
    assert "world" in strategyModule._tqm._tags

    # Check if the name of the

# Generated at 2022-06-25 12:11:03.559860
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule())


# Generated at 2022-06-25 12:11:06.421976
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        module = StrategyModule()
        assert isinstance(module, StrategyModule)
        assert isinstance(module, BaseStrategyModule)

#Unit test for class method run()

# Generated at 2022-06-25 12:11:12.426949
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    inventory_db = InventoryDatabase(":memory:")
    fake_loader = DictDataLoader({})
    variable_manager = VariableManager(loader=fake_loader, inventory=inventory_db)
    connection_cache={}
    tqm = TaskQueueManager(
        inventory=inventory_db,
        variable_manager=variable_manager,
        loader=fake_loader,
        passwords={},
        stdout_callback=None,
        run_additional_callbacks=False,
        run_tree=False,
        connection_cache=connection_cache
    )

# The following lines are used when running this file as a script
if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-25 12:11:19.288294
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    This unit test is used to test the constructor of class StrategyModule.
    """
    strategy_module = StrategyModule(tqm=None, strategy='linear', host_list=[], queue=None, variable_manager=None, loader=None)
    assert strategy_module.run(iterator=None, play_context=None) == strategy_module._tqm.RUN_OK



# Generated at 2022-06-25 12:11:21.091161
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule()
    assert isinstance(module, BaseStrategy)
    assert isinstance(module, StrategyModule)

# Generated at 2022-06-25 12:11:23.316572
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    """
    strategy : strategy_base 
    """
    strategy = strategy_base() 
    strategy.run()



# Generated at 2022-06-25 12:11:33.670174
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # First load up the PluginLoader to make sure we are getting the correct StrategyModule class loaded
    # this is done by loading up the strategy plugin (that implements the base StrategyModule class)
    loader = PluginLoader(
        class_name='StrategyModule',
        module_name='ansible.plugins.strategy',
        path=None,
        package=None,
        config=None,
        subdir=None,
        aliases=None
    )

    loader.add_directory(C.DEFAULT_STRATEGY_PLUGIN_PATH)
    loader.add_directory(C.DEFAULT_STRATEGY_PLUGIN_PATH, with_subdir=True)
    try:
        strategy_plugins = loader.all(class_only=True)
    except AnsibleError as e:
        strategy_plugins = []
        display.error

# Generated at 2022-06-25 12:11:40.555133
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    map1 = dict()
    map1['my_first'] = dict()
    map1['my_first']['inventory'] = dict()
    map1['my_first']['inventory']['hostvars'] = dict()
    map1['my_first']['inventory']['hostvars']['my_first'] = dict()
    map1['my_first']['inventory']['hostvars']['my_first']['ansible_host'] = '127.0.0.1'
    map1['my_first']['inventory']['hostvars']['my_first']['ansible_port'] = 22
    map1['nodes'] = dict()
    map1['nodes']['inventory'] = dict()

# Generated at 2022-06-25 12:13:34.882089
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Set up mocks
    def run(dummy_iterator, dummy_play_context):
        pass
    StrategyModule.run = run
    strategy_module = StrategyModule(dummy_tqm, dummy_variable_manager, dummy_loader, dummy_options, dummy_passwords)

    # Perform test
    try:
        strategy_module.run(dummy_iterator, dummy_play_context)
    except:
        err = True
        print("Unexpected error:", sys.exc_info()[0])
    else:
        err = False
    assert not err


# Unit test method run of class StrategyModule
# Coverage: 84.6%

# Generated at 2022-06-25 12:13:36.738205
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("", "", "", "")
    assert strategy_module is not None

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:13:38.034101
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    m = StrategyModule()
    m.run(iterator, play_context)
    

# Generated at 2022-06-25 12:13:44.187372
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    ACTION_FAIL = 'fail'
    ACTION_SUCCESS = 'success'
    ACTION_UNREACHABLE = 'unreachable'
    ACTION_NOOP = 'noop'

    def create_results(task, host, results_list, ignore_errors=False, action=ACTION_SUCCESS):
        action_result = ActionResult(task, host, action=action)
        results_list.append(action_result)
        if ignore_errors:
            action_result._ignore_errors = True

    task_result = TaskResult(host=Host(), task=Task(action='setup'), return_data={})

    results_list = []
    ignore_errors = False
    for host in Hosts():
        create_results(task_result._task, host, results_list, ignore_errors)

# Generated at 2022-06-25 12:13:45.193740
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(TQM({}), {})

# Generated at 2022-06-25 12:13:46.456757
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm, hosts, tqm._variable_manager, loader)


# Generated at 2022-06-25 12:13:47.349580
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    s = StrategyModule()
    s.run()


# Generated at 2022-06-25 12:13:47.834608
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-25 12:13:53.051732
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_runner, test_iterator, test_play_context, test_inventory, test_variable_manager, test_loader, test_tqm = _prepare_mocks()

    test_pm = StrategyModule(test_tqm)
    test_pm.get_hosts_left = MagicMock(return_value = ["127.0.0.1", "172.17.0.1"])
    test_pm._get_next_task_lockstep = MagicMock(return_value = [("1st-host", "1st-task"), ("2nd-host", "2nd-task")])
    test_pm._execute_meta = MagicMock(return_value = [("meta-result-for-host-1", "meta-result-for-host-2")])
    test_pm.update_active_connect

# Generated at 2022-06-25 12:14:00.096137
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    state_mock = mock.MagicMock()
    addr_state_mock = ['192.168.1.103', '127.0.0.1']
    state_mock.return_value = '192.168.1.103'
    state_mock.side_effect = addr_state_mock
    inventory_mock = mock.MagicMock()
    inventory_mock.hosts = ['host1','host2','host3','host4','host5']
    hosts_mock = mock.MagicMock()
    hosts_mock.__len__.return_value = 5
    iterator_mock = mock.MagicMock()
    iterator_mock.get_next_task_for_host.return_value = ['task1', 'task2', 'task3', 'task4', 'task5']


# Generated at 2022-06-25 12:18:11.086126
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None

# Generated at 2022-06-25 12:18:16.066995
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule()
    display.debug = mock.MagicMock()
    strategy_module.update_active_connections = mock.MagicMock()
    strategy_module.get_hosts_left = mock.MagicMock(return_value=['temp'])
    iterator = mock.MagicMock()
    iterator.batch_size = 1
    iterator.is_failed = mock.MagicMock(return_value=False)
    iterator._play.max_fail_percentage = None
    iterator._get_next_task_lockstep = mock.MagicMock(return_value=['temp'])
    strategy_module._pending_results = 1
    strategy_module._process_pending_results = mock.MagicMock(return_value=1)
    strategy_module._wait_on_pending_results = mock

# Generated at 2022-06-25 12:18:21.888022
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    config = ConfigParser()
    config.read("../../ansible.cfg")
    loader = DataLoader()
    passwords = dict()
    inventory = InventoryManager(loader=loader, sources="../../inventory")
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        passwords=passwords,
        stdout_callback='default',
    )
    strategy_module = StrategyModule(tqm)
    iterator = None
    play_context = None
    strategy_module.run(iterator,play_context)

# Generated at 2022-06-25 12:18:31.685868
# Unit test for method run of class StrategyModule

# Generated at 2022-06-25 12:18:37.675955
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.plugins.strategy import StrategyModule

    strategy = StrategyModule()

    # Empty iterator will raise an exception, which is acceptable
    try:
        strategy.run(iterator = None, play_context = None)
        assert True == False
    except:
        pass

    # Task with no hosts
    class Iterator():
        def __init__(self):
            self._play = Play()

        def get_next_task_for_host(self, host, peek = False):
            return None
        def mark_host_failed(self, host):
            return None
        def is_failed(self, host):
            return None
        def add_tasks(self, host, block):
            return None
    play = Play()
    play.included_files = []


# Generated at 2022-06-25 12:18:46.786623
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  # create StrategyModule object
  strategy_module = StrategyModule(loader, variable_manager, host_list)

  # create task object with valid field inputs
  task = Task(action=dict(module='test'))

  # create play object
  play = Play()

  # create play context
  play_context = PlayContext()

  # create iterator with task, play and play_context as parameters
  iterator = TaskIterator(task, play, play_context)

  # set hosts cache