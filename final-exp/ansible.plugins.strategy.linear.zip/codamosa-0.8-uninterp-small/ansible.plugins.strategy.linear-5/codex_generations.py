

# Generated at 2022-06-25 12:09:26.016339
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule()
    # TODO: Iterator, PlayContext
    # TODO: should return boolean
    strategy_module.run()


# Generated at 2022-06-25 12:09:30.013038
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_num = 1109.0
    strategy_module_obj = StrategyModule(float_num)
    # Uncomment this line when testing the test case
    # test_case_0()

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 12:09:30.877280
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:09:32.059810
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(1109.0)


# Generated at 2022-06-25 12:09:33.273925
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    test_case_1()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:09:33.973112
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:09:34.989425
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(0)



# Generated at 2022-06-25 12:09:36.187829
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:09:48.623552
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    long_0 = long('-738')
    long_1 = long('-938')
    long_2 = long('-711')
    long_3 = long('-894')
    long_4 = long('-145')
    long_5 = long('-362')
    long_6 = long('-607')
    long_7 = long('-522')
    long_8 = long('-95')
    long_9 = long('-947')
    long_10 = long('-837')
    long_11 = long('-269')
    long_12 = long('-738')
    long_13 = long('-938')
    long_14 = long('-711')
    long_15 = long('-894')
    long_16 = long('-145')
    long

# Generated at 2022-06-25 12:09:50.681440
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.0
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:10:33.728690
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO:
    # mock = MagicMock()

    # strategy_module_0 = StrategyModule()
    # strategy_module_1 = StrategyModule()

    assert True



# Generated at 2022-06-25 12:10:37.473935
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule()
    # invalid types for iterator, play_context
    with pytest.raises(TypeError):
        strategy_module_0.run(iterator=strategy_module_0, play_context=strategy_module_0)


# Generated at 2022-06-25 12:10:38.410505
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:10:41.932269
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule()
    assert_equals(strategy_module_1._name, 'strategy')
    assert_list_equal(strategy_module_1._get_host_variables.__code__.co_varnames,
                      ['self', 'host', 'iterator', 'all_vars', 'play_context'])


# Generated at 2022-06-25 12:10:43.200734
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:10:44.913934
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    with pytest.raises(Exception, match=r"Not yet implemented"):
        strategy_module_0 = StrategyModule()
        strategy_module_0.run()


# Generated at 2022-06-25 12:10:49.030968
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # build the test bed
    # initialize the strategy module
    strategy_module_1 = StrategyModule()

    # create a dummy play context
    play_context_1 = PlayContext()

    # create a dummy iterator
    iterator_1 = None

    # run the strategy module
    try:
        strategy_module_1.run(iterator_1, play_context_1)
    except Exception as e:
        print("exception: %s" % e)
        assert(False)

    # clean up
    pass


# Generated at 2022-06-25 12:10:54.357923
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("Test StrategyModule Class")
    print("Test run")
    print()
    strategy_module_0 = StrategyModule(load=False, variable_manager=None, loader=None)
    inventory = HostInventoryModule(loader=None, variable_manager=None)
    play = Play()
    play_context = PlayContext()
    iterator = TaskIterator(play=play, play_context=play_context, inventory=inventory, variable_manager=None, all_vars=dict())

    try:
        strategy_module_0.run(iterator, play_context)
    except TypeError:
        print("Test passed")
    else:
        print("Test failed")


# Generated at 2022-06-25 12:11:06.320889
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Init the StrategyModule class and get handle
    strategy_module = StrategyModule()

    # Prepare the ansible inventory
    inventory = {
        "localhost": {
            "hosts": ["localhost"],
            "vars": {
                "ansible_connection": "local"
            }
        }
    }
    # Build a mock of the play context to pass to the run method
    play_context = {
        'remote_addr': '34.251.174.79',
        'remote_user': 'vagrant',
        'password': 'vagrant',
        'become_method': 'sudo',
        'become_user': 'root',
        'become_pass': 'vagrant',
        'port': 22,
    }

    # Build the inventory and get a handle

# Generated at 2022-06-25 12:11:19.068504
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule(
        run_additional_callbacks=False,
        stdout_callback='default',
        load_callbacks_from_file=False,
        stdout_callback_whitelist=[],
        stdout_callback_blacklist=[]
    )
    # Failed because run_additional_callbacks is not a boolean and the default value is True
    assert strategy_module_1.run_additional_callbacks == True
    # Failed because stdout_callback is not a str and the default value is 'default'
    assert strategy_module_1.stdout_callback == 'default'
    # Failed because load_callbacks_from_file is not a boolean and the default value is False
    assert strategy_module_1.load_callbacks_from_file == False
    # Failed because stdout_callback

# Generated at 2022-06-25 12:12:07.655027
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    class TestStrategyModule(StrategyModule):
        def _wait_on_pending_results(self, iterator):
            pass

        def add_tqm_variables(self, vars, play):
            pass

        def _execute_meta(self, task, play_context, iterator, host):
            pass

    class TestManager:
        def __init__(self):
            self._terminated = False
            self._stdout_callback = None
            self._notified_handlers = dict()
            self._failed_hosts = dict()

        @property
        def keep_localhost(self):
            return True

        @property
        def stdout_callback(self):
            return self._stdout_callback

        def get_host_list(self):
            return []


# Generated at 2022-06-25 12:12:15.584441
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    play = Play().load(dict(
        name = "Ansible Play",
        hosts = "all",
        gather_facts = "no",
        tasks = [
            dict(action=dict(module="setup", args=dict()))
        ]
    ), variable_manager=VariableManager(), loader=None)
    inventory = InventoryManager(loader=None, sources='localhost,')
    tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=VariableManager(),
        loader=None,
        options=None,
        passwords=dict(),
        stdout_callback=None,
    )
    sm = StrategyModule(tqm)
    result = sm.run(Iterator(play), PlayContext())
    assert type(result) == int


# Generated at 2022-06-25 12:12:21.808047
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TmpOption():
        def __init__(self, display=0, step=None, start_at_task=None):
            self.display = display
            self.step = step
            self.start_at_task = start_at_task

    class TmpVarManger():
        class TmpInventory():
            def __init__(self, hosts):
                self.hosts = dict()
                for host in hosts:
                    self.hosts[host] = None
        def __init__(self, hosts):
            self.inventory = self.TmpInventory(hosts)

    class TmpTqm():
        def __init__(self, hosts):
            self._failed_hosts = dict()
            self._terminated = False

# Generated at 2022-06-25 12:12:23.353915
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategymodule = StrategyModule()
    strategymodule.run(iterator = None, play_context = None)




# Subclass of BaseStrategyModule, see base.py


# Generated at 2022-06-25 12:12:29.049892
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # initialize StrategyModule object
    stg = StrategyModule()
    # change the value of a private variable of object so that the object is initialized
    stg._tqm = True
    # create a FakeContainer object to save the result after executing the run() method
    container = FakeContainer()
    # create a FakeIterator object
    iterator = FakeIterator()
    # fill in the iterator variable of class StrategyModule with the object FakeIterator to be able to execute method run() of class StrategyModule
    stg.set_iterator(iterator)
    # create a FakePlayContext object
    play_context = FakePlayContext()
    # initialize hosts_left variable with a list of FakeHost objects
    hosts_left = [FakeHost()]
    # change the value of a private variable of object so that the object is initialized
    stg._blocked_hosts = {}
   

# Generated at 2022-06-25 12:12:39.085552
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    '''
    StrategyModule run() test method
    '''
    # Test with failed host and
    # failed_percentage = 0.0
    test1 = StrategyModule()
    test1.add_tqm_variables(variable_manager, play=iterator._play)
    test1.run(iterator, play_context)
    # Test with failed host and
    # failed_percentage = 1.0
    test2 = StrategyModule()
    test2.add_tqm_variables(variable_manager, play=iterator._play)
    test2.run(iterator, play_context)
    # Test with failed host and
    # failed_percentage = 100.0
    test3 = StrategyModule()
    test3.add_tqm_variables(variable_manager, play=iterator._play)

# Generated at 2022-06-25 12:12:41.734943
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' strategy_module.py:TestStrategyModule '''

    # This will fail if initialisation without params fails
    # It should also fail if _queue_task or _wait_on_pending_results are called
    # before initialisation.
    my_stratmod = StrategyModule()

# Generated at 2022-06-25 12:12:52.057867
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TaskQueueManager(None)
    host_list = [Host("test_host_1"),Host("test_host_2")]
    loader = None
    variable_manager = VariableManager()
    display = Display()
    sm = StrategyModule(tqm,host_list,loader,variable_manager,display)
    assert(sm._tqm == tqm)
    assert(sm._host_list == host_list)
    assert(sm._loader ==loader)
    assert(sm._variable_manager == variable_manager)
    assert(sm._display == display)
test_StrategyModule()
 

# Generated at 2022-06-25 12:12:53.208432
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    taskqueue = TaskQueueManager()
    strategy = StrategyModule(taskqueue)
    assert strategy is not None

# Generated at 2022-06-25 12:12:55.195096
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = Mock()
        strategy = StrategyModule(tqm)
        assert strategy._tqm == tqm
    except:
        assert True == False, "Unit test for constructor of class StrategyModule is failed"


# Generated at 2022-06-25 12:14:52.225708
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '_get_next_task_lockstep')
    assert StrategyModule._get_next_task_lockstep.__code__.co_argcount == 2
    assert StrategyModule._get_next_task_lockstep.__code__.co_varnames == ('self', 'hosts_left', 'iterator')
    assert StrategyModule._get_next_task_lockstep.__code__.co_argcount == 2
    assert StrategyModule._get_next_task_lockstep.__code__.co_varnames == ('self', 'hosts_left', 'iterator')
    assert StrategyModule._get_next_task_lockstep.__code__.co_argcount == 2

# Generated at 2022-06-25 12:14:53.960444
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create an StrategyModule object
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-25 12:15:03.845701
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module = StrategyModule()
    iterator = Iterator()
    iterator.resume_state = {}
    iterator._play = Play()
    iterator._play.hostvars = {}
    iterator._play.tasks = []
    iterator._play.handlers = []
    iterator._play.basedir = ''
    iterator._play.post_validate = lambda *args, **kwargs: True
    iterator._play.default_vars = lambda *args, **kwargs: {}
    iterator._play.post_validate = lambda *args, **kwargs: True
    iterator._play.playbook = Playbook()
    iterator._play.playbook.vars_files = 'vars_files'
    iterator._play.playbook.basedir = 'basedir'

# Generated at 2022-06-25 12:15:04.982781
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule(None)
    assert strategy_module.run(None,None)

# Generated at 2022-06-25 12:15:06.951126
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory("inventory", loader=loader, variable_manager=variable_manager)
    strategy_module = StrategyModule(inventory, loader, variable_manager)


# Generated at 2022-06-25 12:15:09.113698
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # TODO: create test
    return True

# Test StrategyModule class

# Generated at 2022-06-25 12:15:11.679823
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategymodule = StrategyModule (tqm=None, variable_manager=None, loader=None)
    iterator = object()
    play_context = object()
    
    try:
        strategymodule.run(iterator, play_context)
    except:
        pass

# Generated at 2022-06-25 12:15:20.466906
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Construct a mock object for the iterator
    play_context = {}
    iterator = MagicMock()
    iterator._play = "play"
    strategy_module = StrategyModule(play_context, iterator)
    assert strategy_module.run(iterator, play_context) == strategy_module._tqm.RUN_OK
    strategy_module._pending_results = 1
    assert strategy_module.run(iterator, play_context) == strategy_module._tqm.RUN_OK
    assert strategy_module._tqm._terminated is True
    assert len(strategy_module._blocked_hosts) == 0

    play_context = {}
    iterator = MagicMock()
    iterator._play = "play"
    strategy_module = StrategyModule(play_context, iterator)
    strategy_module._tqm._use

# Generated at 2022-06-25 12:15:22.029429
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm=None, loader=None, inventory=None, variable_manager=None)
    assert module is not None


# Generated at 2022-06-25 12:15:25.027799
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(TQM())
    strategy_module.run(None, None)
    strategy_module.get_hosts_left(None)
    strategy_module.get_failed_hosts(None)
    strategy_module.cleanup()