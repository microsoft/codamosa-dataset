

# Generated at 2022-06-25 12:09:24.871199
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = None
    iterator_0 = True
    strategy_module_0 = StrategyModule(bytes_0)
    strategy_module_0.run(iterator_0)

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 12:09:26.940063
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



#-------------#
# set up code #
#-------------#

# Set up for testing StrategyModule


# Generated at 2022-06-25 12:09:30.700353
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    iterator_0 = None
    play_context_0 = None
    strategy_module_0.run(iterator_0,
                          play_context_0)


# Generated at 2022-06-25 12:09:31.597598
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:09:34.977945
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    iterator_0 = Iterator()
    play_context_0 = PlayContext()

    # Call the run method with arguments: iterator and play_context
    assert_equals(strategy_module_0.run(iterator_0, play_context_0), 0)

# Generated at 2022-06-25 12:09:38.832072
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    iterator_0 = None
    play_context_0 = None
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:09:45.355558
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Boilerplate code to run the test.
if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1:
        print('Usage: python3 test_v2_playbook.py')
        sys.exit(1)
    print('Running tests...')
    test_StrategyModule()

# Generated at 2022-06-25 12:09:55.732252
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0) #bytes_0 is a object of class bytes
    assert strategy_module_0._poll_interval == 10.0
    assert strategy_module_0._pending_results == 0
    assert strategy_module_0._blocked_hosts == {}
    assert strategy_module_0._tqm is None
    assert strategy_module_0._inventory is None
    assert strategy_module_0._loader is None
    assert strategy_module_0._variable_manager is None
    assert strategy_module_0._notified_handlers == {}
    assert strategy_module_0._listeners == []
    assert strategy_module_0._step is False
    assert strategy_module_0._last_hosts == []
    assert strategy_module_0._hosts_

# Generated at 2022-06-25 12:10:00.287851
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    iterator_0 = None
    play_context_0 = None
    strategy_module_0.run(iterator_0, play_context_0)

if __name__ == '__main__':
    test_case_0()
    # test_StrategyModule_run()

# Generated at 2022-06-25 12:10:03.410958
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    def test_StrategyModule_run_0():
        bytes_1 = None
        iterator_0 = None
        play_context_0 = PlayContext()
        ret_val_1 = strategy_module_0.run(iterator_0, play_context_0)
        print(ret_val_1)


# Generated at 2022-06-25 12:10:44.913907
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    iterator_0 = None
    play_context_0 = None
    play_context_1 = None
    play_context_2 = None
    play_context_3 = None
    play_context_4 = None
    play_context_5 = None
    play_context_6 = None
    play_context_7 = None
    play_context_8 = None
    play_context_9 = None
    play_context_10 = None
    play_context_11 = None
    play_context_12 = None
    play_context_13 = None
    play_context_14 = None
    play_context_15 = None
    play_context_16 = None
    play_context_17 = None
    play_context_18 = None

# Generated at 2022-06-25 12:10:46.238696
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:10:46.988820
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:10:53.219371
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # setup mock data

    # step is called as a result of _take_step. We can't mock _take_step, so we have to stub it
    def step_call(task):
        return True
    strategy_module_0 = StrategyModule(None)
    strategy_module_0._take_step = step_call

    # # this is called by _copy_included_file
    # def generate_task_list_call(play, variable_manager, loader, itr):
    #     return (None, None)
    # strategy_module_0._generate_task_list = generate_task_list_call

    # this is called by _execute_meta
    def get_vars_call(play=None, host=None, task=None, _hosts=None, _hosts_all=None):
        return None


# Generated at 2022-06-25 12:10:58.428488
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    bytes_0 = None
    iterator_0 = PlayIterator(bytes_0)
    bytes_0 = None
    play_context_0 = PlayContext(bytes_0)
    int_0 = strategy_module_0.run(iterator_0, play_context_0)
    assert int_0 == 1


# Generated at 2022-06-25 12:11:07.558155
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_1 = StrategyModule()
    bytes_0 = None
    iterator_0 = None
    play_context_0 = None
    assert strategy_module_1.run(iterator_0, play_context_0) == 0
    strategy_module_2 = StrategyModule()
    bytes_0 = None
    iterator_1 = None
    play_context_1 = None
    assert strategy_module_2.run(iterator_1, play_context_1) == 0

if __name__ == "__main__":
    test_case_0()
    test_StrategyModule_run()
    print("Passed")

# Generated at 2022-06-25 12:11:19.976366
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

include_strategies_dir = os.path.dirname(os.path.dirname(__file__))

C.STRATEGY_PLUGINS_PATH = [os.path.join(include_strategies_dir, 'strategy_plugins')]

for loader in find_plugin_files(C.STRATEGY_PLUGINS_PATH):
    try:
        strategy_module = import_module(loader)
    except ImportError as e:
        display.warning("plugin loader (%s) failed: %s" % (loader, to_text(e)))
        continue
    display.info("found strategy plugin %s" % loader)
    loaded_strategy_plugins[strategy_module._load_name] = strategy_module



# Generated at 2022-06-25 12:11:23.013869
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Setup:
    iterator = None
    play_context = None

    # Exercise:
    strategy_module_0 = StrategyModule(None)
    strategy_module_0.run(iterator, play_context)

    # Verify:



# Generated at 2022-06-25 12:11:24.635404
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    iterator_0 = None
    play_context_0 = None
    assert strategy_module_0.run(iterator_0, play_context_0) == 0


# Generated at 2022-06-25 12:11:34.919353
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.utils.display import Display
    display = Display()
    task_queue_manager_0 = TaskQueueManager(bytes_0)
    bytes_0 = None
    strategy_module_0 = StrategyModule(task_queue_manager_0)
    task_queue_manager_0.get_groups_dict.return_value = {}
    task_queue_manager

# Generated at 2022-06-25 12:12:18.765169
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:12:24.234406
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    iterator_0 = None
    play_context_0 = None
    assert strategy_module_0.run(iterator_0, play_context_0) == 0

    # Test cases with failures

# Generated at 2022-06-25 12:12:25.502520
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule()
    result_0 = strategy_module_0.run(None, None)

    assert result_0 == None


# Generated at 2022-06-25 12:12:28.152783
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    iterator_0 = Iterator()
    play_context_0 = PlayContext()
    strategy_module_0.run(iterator_0, play_context_0)

# Generated at 2022-06-25 12:12:31.995580
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    iterator_0 = None
    play_context_0 = None
    assert_equal(strategy_module_0.run(iterator_0, play_context_0), 0)

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 12:12:36.891094
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  strategy_module_0 = get_StrategyModule_instance(0)
  iterator_0 = get_TaskIterator_instance(0)
  play_context_0 = get_PlayContext_instance(0)
  result = strategy_module_0.run(iterator_0, play_context_0);
  assert result == 'RUN_UNKNOWN_ERROR'


# Generated at 2022-06-25 12:12:41.528709
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    iterator_0 = iterator_0
    play_context_0 = play_context_0
    int_0 = strategy_module_0.run(iterator_0, play_context_0)
    # Assertion for verifying expected result
    assert int_0 == 0, "Unable to assert the expected result"

# Generated at 2022-06-25 12:12:44.560124
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = None
    iterator_0 = None
    play_context_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    strategy_module_0._set_hosts_cache(iterator_0._play)

    test_case_0()
    test_case_1()
    test_case_2()

# Generated at 2022-06-25 12:12:47.946533
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    try:
        bytes_0 = None
        strategy_module_0 = StrategyModule(bytes_0)
        # iterator is not necessary for unit test
        iterator = None
        play_context = None
        result = strategy_module_0.run(iterator, play_context)
    except NameError as e:
        print("Function Test: test_StrategyModule_run exception when executing function: " + str(e))

# main function for unit test

# Generated at 2022-06-25 12:12:51.725523
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    iterator_0 = None
    play_context_0 = None
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:13:51.344218
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert isinstance(strategy_module, StrategyModule)


# Generated at 2022-06-25 12:13:58.880358
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create an instance of class StrategyModule
    # For this test case we are passing in the following values for parameters:
    # tqm - mock.MagicMock()
    # var_manager - mock.MagicMock()
    # loader - mock.MagicMock()
    # options - mock.MagicMock()
    # shared_loader_obj - mock.MagicMock()

    loader_obj = mock.MagicMock()
    shared_loader_obj = mock.MagicMock()
    options_obj = mock.MagicMock()
    var_manager_obj = mock.MagicMock()
    tqm_obj = mock.MagicMock()

    test_case_StrategyModule = StrategyModule(tqm_obj, var_manager_obj, loader_obj, options_obj, shared_loader_obj)

    # Use asserts

# Generated at 2022-06-25 12:13:59.933423
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategymodule = StrategyModule()
    assert(strategymodule)


# Generated at 2022-06-25 12:14:05.982904
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3
    int_4 = 4
    int_5 = 5
    int_6 = 6
    int_7 = 7
    int_8 = 8
    int_10 = 10
    int_11 = 11
    int_12 = 12
    int_13 = 13
    int_14 = 14
    int_15 = 15
    int_16 = 16
    int_17 = 17
    int_18 = 18
    int_19 = 19
    int_20 = 20
    int_21 = 21
    int_22 = 22
    int_23 = 23
    int_24 = 24
    int_25 = 25
    int_26 = 26
    int_27 = 27
    int_28 = 28
    int_

# Generated at 2022-06-25 12:14:14.464455
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # check the creation of a new StrategyModule object
    obj = StrategyModule(playbook, tqm, variable_manager, loader)
    assert isinstance(obj, StrategyModule)
    assert obj.playbook is playbook
    assert obj.tqm is tqm
    assert obj.variable_manager is variable_manager
    assert obj.loader is loader
    assert obj.host_list is None
    assert obj.host_work_key is None
    assert obj.blocked_hosts == {}
    assert obj.pending_results == 0
    assert obj.workers == 0
    assert obj.shutdown == False
    assert obj._step is False
    assert obj.step_stop is False
    assert obj._tqm_variables == {}
    assert obj.hosts_cache is None

# Generated at 2022-06-25 12:14:15.262347
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    obj = StrategyModule(0, None)
    obj.run(iterator, play_context)

# Generated at 2022-06-25 12:14:21.853164
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case = 0

    # TEST CASE 0
    if test_case == 0:
        print('Test Case 0\n')
        StrategyModule = FakeStrategyModule()

        # TEST CASE 0.0
        print('\nTest Case 0.0\n')
        print('\nCalling StrategyModule.run()\n')
        obj = StrategyModule
        iterator = Fake_iterator
        play_context = Fake_play_context
        assert obj.run(iterator, play_context) == 2

        # TEST CASE 0.1
        print('\nTest Case 0.1\n')
        print('Executing the run method of StrategyModule class\n')
        obj = StrategyModule
        iterator = Fake_iterator
        play_context = Fake_play_context
        assert obj.run(iterator, play_context) == 1

        # TEST CASE

# Generated at 2022-06-25 12:14:25.399564
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    args = dict()
    args.update({"iterator": iterator_0, "play_context": play_context_0})
    # Test procedure call
    try:
        result = StrategyModule_0.run(**args)
    except:
        result = None
    assert result == 0

# Generated at 2022-06-25 12:14:28.053469
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_instance = StrategyModule()
    iterator = Iterator()
    play_context = PlayContext()
    strategy_module_instance.run(iterator,play_context)

if __name__ == "__main__":
    test_StrategyModule_run()

# Generated at 2022-06-25 12:14:30.653823
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:16:40.374736
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\n")
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-25 12:16:41.146056
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert type(StrategyModule()) == StrategyModule


# Generated at 2022-06-25 12:16:49.695934
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    var_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=var_manager, host_list='')
    play_context = PlayContext()
    tqm = TaskQueueManager(inventory=inventory, variable_manager=var_manager, loader=loader, options=None, passwords=None, stdout_callback='nocapture')
    strategy = StrategyModule(tqm)
    play = Play().load('test.yaml', variable_manager=var_manager, loader=loader)
    pbio = PlaybookIterator(loader=loader, inventory=inventory, play=play)
    strategy.run(pbio, play_context)


# Generated at 2022-06-25 12:16:51.142775
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    target = StrategyModule()
    int_0 = 10
    # TODO: mock iterator and play_context

# Generated at 2022-06-25 12:16:53.254959
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    obj = StrategyModule(tqm=None)
    obj.run(iterator=None, play_context=None)

# END class StrategyModule

# BEGIN class StrategyModule_0

# Generated at 2022-06-25 12:16:55.501975
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule")
    int_1 = 1
    print(int_1)

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:17:02.145846
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule(loader=loader_0, variable_manager=variable_manager_0, host_list=host_list_0)
    strategy_module_1 = StrategyModule(loader=loader_0, variable_manager=variable_manager_0, host_list=host_list_0)
    play_context_0 = PlayContext(new_stdin=new_stdin_0)
    iterator_0 = TestIterator(play=play_0, pattern='', inventory=inventory_0)
    success_0 = strategy_module_0.run(iterator_0, play_context_0)
    if success_0:
        int_0 = 1
        print(int_0)
    else:
        int_0 = 0
        print(int_0)


# Generated at 2022-06-25 12:17:08.190573
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategymodule_0 = StrategyModule(name='foobar')
    strategymodule_1 = StrategyModule(name='foobar')
    variablemanager_0 = VariableManager()
    variablemanager_1 = VariableManager()
    variablemanager_2 = VariableManager()
    variablemanager_3 = VariableManager()
    variablemanager_4 = VariableManager()
    variablemanager_5 = VariableManager()
    variablemanager_6 = VariableManager()
    variablemanager_7 = VariableManager()
    variablemanager_8 = VariableManager()
    variablemanager_9 = VariableManager()
    variablemanager_10 = VariableManager()
    variablemanager_11 = VariableManager()
    variablemanager_12 = VariableManager()
    variablemanager_13 = VariableManager()
    variablemanager_14 = VariableManager()
    variablemanager_15 = VariableManager()
    variablemanager_16 = VariableManager()

# Generated at 2022-06-25 12:17:14.219564
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 12:17:18.775775
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    test_StrategyBase()
    test_StrategyBase_add_tqm_variables()
    test_StrategyBase_add_tqm_variables_add_host_variables()
    test_StrategyBase_add_tqm_variables_add_task_and_generator_variables()
    test_StrategyBase_clear_host_caches()
    test_StrategyBase_copy_included_file()
    test_StrategyBase_copy_module_args()
    test_StrategyBase_create_noop_task()
    test_StrategyBase_create_noop_task_name()
    test_StrategyBase_create_noop_task_set_parent()
    test_StrategyBase_create_noop_task_tags()
   