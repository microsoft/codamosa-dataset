

# Generated at 2022-06-25 12:09:23.969161
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print("Completed unit test for constructor of class StrategyModule")



# Generated at 2022-06-25 12:09:25.010756
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:09:28.389721
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = 2175.0
    strategy_module_0 = StrategyModule(float_0)
    iterator_0 = MagicMock()
    play_context_0 = MagicMock()
    strategy_module_0.run(iterator_0, play_context_0)

# Generated at 2022-06-25 12:09:30.882771
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Init a StrategyModule object
    strategy_module_0 = StrategyModule(5)
    # Call method run of StrategyModule with appropriate arguments
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 12:09:35.388559
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = 2175.0
    strategy_module_0 = StrategyModule(float_0)
    iterator_0 = HostListIterator(None, None, None, None)
    play_context_0 = PlayContext(None, None, None, None, None, None, None, None, None, None, None, None, None, None, None)
    result_0 = strategy_module_0.run(iterator_0, play_context_0)
    assert result_0 == 0


# Generated at 2022-06-25 12:09:41.190085
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    with raises(TypeError):
        StrategyModule()
    with raises(TypeError):
        StrategyModule(2.5)
    with raises(TypeError):
        StrategyModule(2175.0, in_0=2175.0, in_1=(), in_2=2175.0, in_3=2175.0, in_4=2175.0, in_5=2175.0, in_6=2175.0, in_7=2175.0, in_8=2175.0, in_9=2175.0, in_10=2175.0, in_11=2175.0)
    with raises(TypeError):
        StrategyModule('a')
    with raises(TypeError):
        StrategyModule(4)
    with raises(TypeError):
        StrategyModule(3.5)


# Generated at 2022-06-25 12:09:52.719934
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Initialize a global variable
    global C
    C = AnsibleCoreCI()

    inventory_0 = []
    inventory_1 = [inventory_0]

    play_context_0 = PlayContext()
    strategy_module_1 = StrategyModule(inventory_1, play_context_0)
    play_context_0.connection = "local"
    connection_loader_0 = ConnectionLoader(inventory_1, strategy_module_1, play_context_0)
    playbook_executor_0 = PlaybookExecutor(inventory_1, play_context_0, loader_0, connection_loader_0, strategy_module_1, "", "")
    play_context_0.remote_addr = ""

# Generated at 2022-06-25 12:10:01.671534
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = 2175.0
    strategy_module_0 = StrategyModule(float_0)
    iterator_0 = iterator.Iterator()
    play_context_0 = PlayContext(play=Play().load(loader=DataLoader(), variable_manager=VariableManager(), loader_type="DataLoader"), variable_manager=VariableManager())
    iterator_1 = iterator.Iterator()
    play_context_1 = PlayContext(play=Play().load(loader=DataLoader(), variable_manager=VariableManager(), loader_type="DataLoader"), variable_manager=VariableManager())
    strategy_module_1 = StrategyModule(float_0)

    # Testing when raise exception
    with pytest.raises(AnsibleNoConnHandler):
        result_0 = strategy_module_0.run(iterator_0, play_context_0)
        result_1 = strategy

# Generated at 2022-06-25 12:10:03.306307
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:10:08.041277
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()

################################################################################
#
# Start of program
#
################################################################################

if __name__ == '__main__':
    try:
        # For test purposes
        test_case_0()
    except TypeError as e:
        print (str(e))

# Generated at 2022-06-25 12:10:54.073447
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()



# Generated at 2022-06-25 12:10:56.938482
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    playbook_instance = playbook.PlayBook.load("linear.yml")
    strategy_module_instance = StrategyModule()
    print("Testing run of class StrategyModule")
    strategy_module_instance.run(playbook_instance._entries, playbook_instance._entries)

# Generated at 2022-06-25 12:11:05.207919
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test default constructor
    strategy_module = StrategyModule()
    assert strategy_module is not None

    # Test parameterized constructor
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory()
    hosts = inventory.get_hosts()
    host = hosts[0]
    strategy_module = StrategyModule(loader, variable_manager, host, hosts)
    assert strategy_module is not None


# Generated at 2022-06-25 12:11:12.416945
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from collections import namedtuple
    from ansible import constants as C
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.utils.display import Display
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins import action

    # Source of the dummy data used in the test case
    #ActionBase.BYPASS_HOST_LOOP = True
    #TaskResult.is_unreachable = True
    #TaskResult.is_failed = True
    #TaskResult._task.action in C._ACTION_META
    #task.any_errors_

# Generated at 2022-06-25 12:11:24.200329
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():


    _tqm = TaskQueueManager()
    _tqm.send_callback = MagicMock()
    _tqm._terminated = False
    _tqm._failed_hosts = {}

    iterator = MagicMock()
    iterator.get_next_task_for_host = MagicMock(return_value=(1,2))
    iterator.get_active_state = MagicMock(return_value=1)
    iterator.is_failed = MagicMock(return_value=False)
    iterator.mark_host_failed = MagicMock(return_value=None)
    iterator.add_tasks = MagicMock(return_value=None)
    iterator._play = MagicMock()
    iterator._play.max_fail_percentage = None
    iterator.batch_size = 3


# Generated at 2022-06-25 12:11:25.362677
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:11:29.862221
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from unit.loader import LoaderModule
    from unit.vars import VariableManager
    from unit.playbook import Playbook

    strategy_module_run = StrategyModule()

    play_context = dict()
    iterator = dict()

    strategy_module_run.run(iterator, play_context)

# Generated at 2022-06-25 12:11:33.122169
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()


if __name__ == "__main__":
    # Test case for class StrategyModule
    test_StrategyModule()
    # Test case for constructor of class StrategyModule
    test_case_0()

# Generated at 2022-06-25 12:11:40.223817
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # in this test, the return value of the play_context object is mocked.
    # that is why this test is failing for now.
    # the playbook_ds object is also mocked, since it is not needed for
    # testing the run method.

    # This is the host list that will be used to populate the hosts.
    #host_list = {'host': {'name': 'host', 'groups': ['group1']}}

    # This is the play_context object that is needed by the task queue manager.
    #play_context = PlayContext(playbook_ds=[])

    # This is the strategy object that is used.
    strategy_module = StrategyModule()

    # This is the task iterator object that will be used to iterate over the
    # tasks.
    iterator = TaskIterator()

    # This is the TaskQueueManager object that will be

# Generated at 2022-06-25 12:11:42.406136
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    logging.basicConfig(level=logging.DEBUG, format='%(levelname)s:%(funcName)s:%(message)s')
    strategy_module_0 = StrategyModule()
    logging.debug('test_StrategyModule: module_args: %s' % strategy_module_0.module_args)



# Generated at 2022-06-25 12:12:47.003901
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_var_manager = VariableManager()
    my_loader = DataLoader()
    tqm = TaskQueueManager(
        inventory=my_inventory,
        variable_manager=my_var_manager,
        loader=my_loader,
        passwords={},
        stdout_callback=None,
        run_tree=False,
        )
    strategy = StrategyModule(tqm)



# Generated at 2022-06-25 12:12:53.282021
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    task = Task()
    task_vars = VariableManager
    play_context = PlayContext()
    iterator = StrategyIterator()

    strategyModule = StrategyModule()
    strategyModule.run(iterator, play_context)


if __name__ == "__main__":
    print("testing the StrategyModule Class")
    test_StrategyModule_run()

# Generated at 2022-06-25 12:12:58.567008
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import ansible.playbook
    from ansible.inventory import Inventory

    tqm = TaskQueueManager()
    host_list = [
        Host(name="test")
    ]
    host_list[0]._set_variable_manager(VariableManager())
    host_list[0].set_variable('ansible_connection', 'local')
    host_list[0].set_variable('ansible_command_timeout', 10)

    class Play(Play):
        def __init__(self):
            self._ds = dict(
                name="test",
                hosts="all",
                gather_facts="no",
                tasks=[
                    dict(action=dict(module="shell", args="hostname"))
                ]
            )
            self._variable_manager = VariableManager()
            self._loader = C.loader
            self._options

# Generated at 2022-06-25 12:13:05.277292
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    _tqm = Mock()
    _tqm.RUN_OK = 0
    _tqm.RUN_UNKNOWN_ERROR = 1
    _tqm.RUN_FAILED_BREAK_PLAY = 2
    _tqm._failed_hosts = {}

    _variable_manager = Mock()
    _loader = Mock()
    _inventory = Mock()
    _included_file_cache = dict()
    _hosts_cache = dict()
    _hosts_cache_all = dict()

    playbook = Mock()
    playbook.get_variable_manager.return_value = _variable_manager

    class FakeSetting:
        def __init__(self, value, is_set=True):
            self.is_set = is_set
            self.value = value


# Generated at 2022-06-25 12:13:07.532223
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    #t = StrategyModule(tqm, loader, variable_manager, shared_loader_obj)
    pass


# =================================================================================
# Helper methods for StrategyBase
# =================================================================================

# =================================================================================
# Helper methods for StrategyModule
# =================================================================================

# Generated at 2022-06-25 12:13:09.581674
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy


# Generated at 2022-06-25 12:13:18.589955
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(
        tqm=None,
        hosts='127.0.0.1',
        queue='myqueue',
        variable_manager='myvar',
        loader='myloader',
        settings='mysetting',
        passwords='mypasswords',
        stdout_callback='mycallback',
        run_additional_callbacks='mycallbacks',
        run_tree='mytree',
        stdout_callback_plugin='plugin'
    )
    assert strategy_module.name=='linear'
    assert strategy_module.hosts=='127.0.0.1'
    assert strategy_module._tqm==None
    assert strategy_module.queue=='myqueue'
    assert strategy_module._variable_manager=='myvar'
    assert strategy_module._loader=='myloader'
   

# Generated at 2022-06-25 12:13:19.561776
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = StrategyModule()
    assert isinstance(result, StrategyModule)

# Generated at 2022-06-25 12:13:20.833475
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Initializing the class under test
    strategy_module = StrategyModule()


# Generated at 2022-06-25 12:13:26.768621
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    ansible.utils.plugins.module_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../../lib/ansible/modules/unknown'))
    utils.template.environment.loader = FileSystemLoader(os.path.join(os.path.dirname(__file__), '../../../lib/ansible/plugins/templates/'))
    utils.template.environment.filters = utils.plugins.filter_loader.FilterModule()._filters
    ansible.plugins.filter.add_directory(os.path.join(os.path.dirname(__file__), '../../../lib/ansible/plugins/filter'))

# Generated at 2022-06-25 12:15:47.258571
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # create an instance of SUT
    strategy_module = StrategyModule()
    # set up necessary parameters for method run
    iterator = None
    play_context = None
    # call method run
    result = strategy_module.run(iterator, play_context)
    print(result)
    # assert result
    assert result == True



# Generated at 2022-06-25 12:15:50.609288
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  tq = TaskQueueManager(
      inventory = InventoryManager(loader=None, sources=None),
      variable_manager = VariableManager(),
      loader = None,
      options = Options(),
      passwords = None,
  )
  sm = StrategyModule(tqm = tq)
  iterator = PlayIterator()
  play_context = PlayContext()
  assert sm.run(iterator, play_context) == None

# Generated at 2022-06-25 12:15:55.836973
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    strategy_module = StrategyModule()

    assert len(strategy_module._blocked_hosts) == 0
    assert strategy_module._pending_results == 0
    assert strategy_module._last_hosts_cache is None
    assert strategy_module._hosts_cache is None
    assert strategy_module._hosts_cache_setup is False
    assert strategy_module._hosts_cache_all is None
    assert strategy_module._hosts_cache_all_setup is False
    assert strategy_module._results_queue is None
    assert strategy_module._results_lock is None
    assert strategy_module._new_tqm is None


# Generated at 2022-06-25 12:15:58.133261
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module = StrategyModule()
    # Testing with a any instance of class Iterator
    iterator = Iterator()
    # Testing with a any instance of class PlayContext
    play_context = PlayContext()

    try:
        # Testing method run of class StrategyModule
        module.run(iterator, play_context)
    except Exception:
        # Testing with a any type of exception
        pass


# Generated at 2022-06-25 12:16:01.046246
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategymodule = StrategyModule()
    assert strategymodule
    assert not strategymodule._hosts_cache
    assert strategymodule._hosts_cache_all is None


# Generated at 2022-06-25 12:16:10.563285
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    host = Host('localhost')
    results_queue = Queue()
    callbacks = PlaybookCallbacks(verbose=0)
    variable_manager = VariableManager()
    loader = DataLoader()
    play = Play().load(dict(
        name = "Ansible Play debug",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [dict(action=dict(module='shell', args='ls'), register='shell_out'),
                 dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))]
    ), variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-25 12:16:13.801356
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test case when strategy is 'linear'
    options = Options()
    options.strategy = 'linear'
    strategy_module = StrategyModule(tqm=None, options=options, variable_manager=None, loader=None)
    assert strategy_module.get_name() == options.strategy
    assert strategy_module.get_type() == options.strategy

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:16:20.253090
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.plugins.task.include_vars import TaskModule as include_vars_TaskModule
    from ansible.plugins.connection.ssh import Connection as ssh_Connection

    # Create a FakeAnsibleModule
    module = FakeAnsibleModule()

    # Create a FakeTaskExecutor with a fake load_included_file method
    task_executor = FakeTaskExecutor()

    # Create a FakeTaskQueueManager
    task_queue_manager = FakeTaskQueueManager()

    # Create a FakeActionBase
    action_base = FakeActionBase()

    # Create a FakeActionBaseV2
    action_base_v2 = FakeActionBaseV2()

    # Create a FakeVarsPlugin
    vars_plugin = FakeVarsPlugin()

    # Create a FakeIncludedFile
    included_file = FakeIncludedFile()



# Generated at 2022-06-25 12:16:21.476312
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print('Test of method run of class StrategyModule')
    raise NotImplementedError


# Generated at 2022-06-25 12:16:21.950529
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    _ = StrategyModule()