

# Generated at 2022-06-25 12:09:24.824587
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit test entry point.

# Generated at 2022-06-25 12:09:27.880406
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'dFwNy0k/7wf/e'
    strategy_module_0 = StrategyModule(str_0)
    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:09:32.023394
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    playbook_dir = '/etc/ansible/playbook'
    str_0 = 'dFwNy0k/7wf/e'
    strategy_module_0 = StrategyModule(str_0)
    iterator_0 = BaseIterator()
    play_context_0 = PlayContext()
    strategy_module_0.run(iterator_0, play_context_0)

# Generated at 2022-06-25 12:09:33.251731
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    display.verbosity = 2
    # Test for call StrategyModule::run(iterator, play_context)
    test_case_0()

# Generated at 2022-06-25 12:09:36.359312
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = '5j2Q+'
    iterator_0 = Iterator(str_0)
    play_context_0 = PlayContext()
    strategy_module_0 = StrategyModule('dFwNy0k/7wf/e')
    bool_0 = strategy_module_0.run(iterator_0, play_context_0)

# Generated at 2022-06-25 12:09:40.372186
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_case_0()

print('Testing function run')
test_StrategyModule_run()
print('Passed test case run')


# Generated at 2022-06-25 12:09:46.275246
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # preparation
    name_0 = C.strategy_plugins['linear']
    strategy_module_0 = StrategyModule(name_0)
    iterator_0 = InMemoryIterator(iterator_task_list=[])
    play_context_0 = PlayContext(play=None)

    # test case
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:09:49.372949
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 12:09:50.632561
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit test

# Generated at 2022-06-25 12:09:52.325791
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:10:45.499380
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    if __name__ == '__main__':
        test_case_0()

        print('All unit tests for StrategyModule are passed')

# Generated at 2022-06-25 12:10:47.145447
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'dFwNy0k/7wf/e'
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:10:50.513508
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = 'dFwNy0k/7wf/e'
    play_0 = Play()
    play_0.name = 'dFwNy0k/7wf/e'
    iterator_0 = play_0.get_iterator()
    strategy_module_0 = StrategyModule(str_0)
    strategy_module_0.run(iterator_0, None)


# Generated at 2022-06-25 12:10:52.914187
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = 'jqC3nwAVwvBh'
    strategy_module_0 = StrategyModule(str_0)
    # AssertionError: None != -127
    assert_not_equal(str_0, strategy_module_0.run())


# Generated at 2022-06-25 12:10:54.703113
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule('/ywBH0C/xenA/1')
    assert strategy_module.run(iterator, play_context) == False


# Generated at 2022-06-25 12:11:01.577179
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    host_0 = Host('fOIzUoOWdU')
    task_0 = Task()
    iterator_0 = PlayIterator(1, 1, [host_0], 1, task_0)
    play_context_0 = PlayContext()
    strategy_module_0 = StrategyModule('XzVIr')
    strategy_module_0.run(iterator_0, play_context_0)


# Generated at 2022-06-25 12:11:06.901569
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = 'dFwNy0k/7wf/e'
    strategy_module_0 = StrategyModule(str_0)

    # Check that run does not throw an exception
    try:
        strategy_module_0.run(iterator=None, play_context=None)
    except:
        print("Exception thrown in StrategyModule.run()")
        assert(0)

# Generated at 2022-06-25 12:11:19.416363
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = 'dFwNy0k/7wf/e'
    strategy_module_0 = StrategyModule(str_0)
    assert isinstance(strategy_module_0, StrategyModule)
    str_1 = '|5_5'
    queue_manager_0 = QueueManager(str_1)
    strategy_module_0.update_queue_manager(queue_manager_0)
    role_0 = Role()
    iterator_0 = iterator.TaskIterator(role_0)
    assert isinstance(iterator_0, iterator.TaskIterator)
    play_context_0 = PlayContext()
    assert isinstance(play_context_0, PlayContext)
    result = strategy_module_0.run(iterator_0, play_context_0)
    assert isinstance(result, int)
    assert result

# Generated at 2022-06-25 12:11:22.155015
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = 'dFwNy0k/7wf/e'
    strategy_module_0 = StrategyModule(str_0)

    # call method run(iterator, play_context) of StrategyModule instance
    # currently, it always returns RUN_OK which is 0


# Generated at 2022-06-25 12:11:27.256916
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = 'dFwNy0k/7wf/e'
    iterator_0 = Iterator()
    play_context_0 = PlayContext()
    strategy_module_0 = StrategyModule(str_0)
    result = strategy_module_0.run(iterator_0, play_context_0)
    print(result)


# Generated at 2022-06-25 12:12:56.322344
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:13:00.605099
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    global failed_list_0
    failed_list_0 = []

    # Unit test for method run of class StrategyModule
    str_0 = 'dFwNy0k/7wf/e'
    iterator_0 = None
    play_context_0 = None
    strategy_module_0 = StrategyModule(str_0)

    # There is no unit test for method run of class StrategyModule
    #assert strategy_module_0.run(iterator, play_context) ==
try:
    test_case_0()
except NotImplementedError as e:
    failed_list_0.append(e)
    

# Generated at 2022-06-25 12:13:01.496051
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Run the unit tests

# Generated at 2022-06-25 12:13:05.410253
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = 'dFwNy0k/7wf/e'
    strategy_module_0 = StrategyModule(str_0)
    iterator = '*!@'
    play_context = 'f4?!P-l'
    result = strategy_module_0.run(iterator, play_context)


# Generated at 2022-06-25 12:13:09.938227
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    try:
        test_case_0()
    except Exception as e:
        print("[FAILED] Failed to execute unit test case: test_case_0().")
        print("[FAILED] Error:", str(e))
        return -1
    else:
        print("[PASSED] Executed unit test case: test_case_0().")
        return 0


# Generated at 2022-06-25 12:13:18.919242
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'dFwNy0k/7wf/e'
    strategy_module_0 = StrategyModule(str_0)
    str_1 = 'L1xB5j5Kt1ewc'
    strategy_module_0._prepare_and_create_noop_block_from(str_0, str_1)
    str_0 = 'a0LzM2DNT1Iey'
    strategy_module_0._execute_meta(str_0, str_1)
    str_0 = '7VuT9KxW7lMJc'
    list_0 = [str_0]
    str_1 = '1Qm9mqsZlJmR6'
    strategy_module_0.update_active_connections(list_0, str_1)


# Generated at 2022-06-25 12:13:20.864969
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 12:13:21.621701
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:13:23.087957
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert test_case_0() == None

# test_StrategyModule()

# vim: set et ts=8 sw=4 sts=4:

# Generated at 2022-06-25 12:13:24.056658
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test_case_0
    test_case_0()


# Generated at 2022-06-25 12:16:51.015786
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = 'dFwNy0k/7wf/e'
    assert_equals(strategy_module_0.run(iterator_0, play_context_0), strategy_module_0._tqm.RUN_OK)


# Generated at 2022-06-25 12:16:57.474463
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Init parameter for test method
    str_0 = 'dFwNy0k/7wf/e'
    iterator_0 = None
    play_context_0 = None

    # Init instance for test method
    strategy_module_0 = StrategyModule(str_0)

    # get attribute for test method
    try:
        strategy_module_0.run(iterator_0, play_context_0)
    except AssertionError as e:
        logger.error("AssertionError raised in test_StrategyModule_run: " + str(e))
        raise e
    except Exception as e:
        logger.error("Exception raised in test_StrategyModule_run: " + str(e))
        raise e
    else:
        logger.info("Success")
        # If we get to this point, the test was successful

# Generated at 2022-06-25 12:17:02.533286
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Setup the Mocking of the AnsibleModule class
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO
    m = StringIO()
    ansible_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
    )
    ansible_module.exit_json = lambda **kwargs: m.write(json.dumps(kwargs))

    # Setup the Mocking of the AnsiblePlay class
    from ansible.playbook.play import Play

# Generated at 2022-06-25 12:17:04.446799
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = 'dFwNy0k/7wf/e'
    strategy_module_0 = StrategyModule(str_0)

    test_case_0()


# Generated at 2022-06-25 12:17:05.165416
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:17:08.033986
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    stmt_0 = '(y+j4xv-0^C)'
    value_0 = to_unicode('ok')
    value_1 = None
    res_pl_0 = StrategyModule.run(value_0, stmt_0, value_1)
    assert res_pl_0.split('-')[0] == 'ok'

# Generated at 2022-06-25 12:17:08.703527
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:17:09.950404
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Testing
if __name__ == '__main__':
    print("Testing")
    test_StrategyModule()

# Generated at 2022-06-25 12:17:10.627454
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:17:12.485385
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("\n=== test of StrategyModule.run ===")
    test_case_0()
    # not implemented yet
    print("=== end of test of StrategyModule.run ===\n")

test_StrategyModule_run()