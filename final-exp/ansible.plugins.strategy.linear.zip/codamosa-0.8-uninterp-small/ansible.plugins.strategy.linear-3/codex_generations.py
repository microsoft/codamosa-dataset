

# Generated at 2022-06-25 12:09:27.396387
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = 2061.0
    strategy_module_0 = StrategyModule(float_0)
    iterator_0 = Iterator([])
    play_context_0 = PlayContext()
    strategy_module_0.run(iterator_0, play_context_0)

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-25 12:09:30.298847
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test the constructor of class StrategyModule
    # pass

    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:09:34.074877
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    float_0 = 3052.0
    strategy_module_0 = StrategyModule(float_0)

    iterator_0 = None
    play_context_0 = None
    result = strategy_module_0.run(iterator_0, play_context_0)

    print(result)
    assert result == strategy_module_0._tqm.RUN_OK


# Generated at 2022-06-25 12:09:35.364494
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:09:39.641193
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print (strategy_module_0.get_variable_manager.__doc__)
    print (strategy_module_0.set_variable_manager.__doc__)
    print (strategy_module_0.get_loader.__doc__)
    print (strategy_module_0.get_hosts_left.__doc__)
    print (strategy_module_0.run.__doc__)
    print (strategy_module_0.set_hosts_cache.__doc__)
    print (strategy_module_0.add_tqm_variables.__doc__)



# Generated at 2022-06-25 12:09:42.723984
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 12:09:45.217259
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()


if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:09:47.195109
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-25 12:09:55.129298
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    playbook = Playbook.load('../test_cases/test-case-0.yaml', variable_manager=VariableManager(), loader=Loader())
    play = playbook.get_plays()[0]

    tqm = TaskQueueManager(
        inventory=Inventory(loader=Loader(), variable_manager=VariableManager(), host_list='localhost'),
        variable_manager=VariableManager(),
        loader=Loader(),
        passwords={},
    )

    StrategyModule(tqm).run(Iterator(inventory=Inventory(host_list='localhost'), play=play, play_context=PlayContext()), PlayContext())


# Generated at 2022-06-25 12:09:58.599508
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    if not is_private_func(StrategyModule, '__init__'):
        pytest.skip("Incorrect test for private func: %s" % '__init__')
    test_case_0()

# Check for class StrategyModule

# Generated at 2022-06-25 12:10:48.137328
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    assert strategy_module_0.__class__.__name__ == "StrategyModule"
    assert isinstance(strategy_module_0, object)
    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:10:49.599508
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None
    assert isinstance(strategy_module, StrategyModule)


# Generated at 2022-06-25 12:10:51.789167
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule()
    assert isinstance(strategy_module_1, StrategyModule)
    assert strategy_module_1.name == 'linear'
    assert strategy_module_1.enabled == True



# Generated at 2022-06-25 12:10:54.263940
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    try:
        assert isinstance(strategy_module_0, StrategyModule)
        print("test_StrategyModule() passed")
    except:
        print("test_StrategyModule() failed")


# Generated at 2022-06-25 12:10:56.256822
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    assert isinstance(strategy_module_0, StrategyModule),'Test Failed: test_StrategyModule #0'


# Generated at 2022-06-25 12:11:08.476048
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    Playbook._load = MagicMock(name="_load")
    Playbook._load.return_value = True
    Play._load = MagicMock(name="_load")
    Play._load.return_value = True
    ResultBase._init = MagicMock(name="_init")
    ResultBase._init.return_value = True
    ResultBase._new = MagicMock(name="_new")
    ResultBase._new.return_value = True
    StrategyModule._get_next_task_lockstep = MagicMock(name="_get_next_task_lockstep")
    StrategyModule._get_next_task_lockstep.return_value = True
    StrategyModule._process_pending_results = MagicMock(name="_process_pending_results")
    StrategyModule._process_pending_results.return_value

# Generated at 2022-06-25 12:11:21.309862
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule()
    outfile_name = 'test_StrategyModule_run_outfile.txt'
    with open(outfile_name, 'w') as outfile:
        saved_stdout = sys.stdout
        sys.stdout = outfile

        # Create a new object of class Play
        play_0 = Play()

        # Create a new object of class PlayContext
        play_context_0 = PlayContext()

        # Create a new object of class InventoryManager
        inventory_manager_0 = InventoryManager()

        # Create a new object of class VariableManager
        variable_manager_0 = VariableManager()

        # Create a new object of class Playbook
        playbook_0 = Playbook()

        # Create a new object of class Host
        host_0 = Host()

        # Create a new object of class

# Generated at 2022-06-25 12:11:31.916734
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule()
    iterator_1 = Mock()
    play_context_2 = Mock()
    out = strategy_module_0.run(iterator_1, play_context_2)
    assert out == 0
    # setup
    strategy_module_0._tqm._terminated = True
    out = strategy_module_0.run(iterator_1, play_context_2)
    assert out == 0
    # setup
    iterator_1.get_failed_hosts = MagicMock(name='get_failed_hosts')
    iterator_1.get_failed_hosts.return_value = set()
    iterator_1._play = Mock()
    iterator_1._play.handlers = []
    iterator_1.run_handlers = MagicMock(name='run_handlers')
   

# Generated at 2022-06-25 12:11:32.931277
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:11:35.797152
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create an empty playbook dictionary
    playbook = {}
    # Run the run method of the StrategyModule class with playbook and None as parameters
    strategy_module_0 = StrategyModule()
    strategy_module_0.run(playbook, None)


# Generated at 2022-06-25 12:13:37.033357
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

#----------------------------------------------------------------------

# Generated at 2022-06-25 12:13:39.428626
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert isinstance(strategy_module, object)
    print("unit test for class StrategyModule constructor:Pass")


# Generated at 2022-06-25 12:13:40.551479
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    print(strategy_module_0)


# Generated at 2022-06-25 12:13:49.318140
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule()
    #Test 1
    #Test 2
    #Test 3
    #Test 4
    #Test 5
    #Test 6
    #Test 7
    #Test 8

    #Test 9
    #Test 10
    #Test 11
    #Test 12
    #Test 13
    #Test 14
    #Test 15
    #Test 16

    #Test 17
    #Test 18
    #Test 19
    #Test 20
    #Test 21
    #Test 22
    #Test 23
    #Test 24

    #Test 25
    #Test 26
    #Test 27
    #Test 28
    #Test 29
    #Test 30
    #Test 31
    #Test 32

    #Test 33
    #Test 34
    #Test 35
    #Test 36
    #Test 37
    #Test

# Generated at 2022-06-25 12:13:51.850201
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    strategy_module_1 = StrategyModule()
    assert strategy_module_0 == strategy_module_1


# Generated at 2022-06-25 12:13:55.896408
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("")
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
    print("Unit test for constructor of class StrategyModule")

    # Construct an object of class StrategyModule
    strategy_module_obj = StrategyModule()

    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
    print("")


# Generated at 2022-06-25 12:14:02.633520
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule()
    assert isinstance(strategy_module, StrategyModule)
    assert isinstance(strategy_module, BaseTaskQueueManager)
    assert isinstance(strategy_module, object)
    assert hasattr(strategy_module, '_tasks_name_cache')
    assert hasattr(strategy_module, '_tasks_loop_cache')
    assert hasattr(strategy_module, '_tasks_block_state_cache')
    assert hasattr(strategy_module, '_blocked_hosts')
    assert hasattr(strategy_module, '_queue')
    assert hasattr(strategy_module, '_pending_results')
    assert hasattr(strategy_module, '_pending_results_lock')

# Generated at 2022-06-25 12:14:03.384584
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()


# Generated at 2022-06-25 12:14:12.035358
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    assert isinstance(strategy_module_0, StrategyModule)
    assert isinstance(strategy_module_0, BaseStrategyModule)
    assert isinstance(strategy_module_0, object)

    assert hasattr(strategy_module_0, '_execute_meta')
    assert hasattr(strategy_module_0, '_load_included_file')
    assert hasattr(strategy_module_0, '_copy_included_file')
    assert hasattr(strategy_module_0, '_get_next_task_lockstep')
    assert hasattr(strategy_module_0, 'run')
    assert hasattr(strategy_module_0, 'run_handlers')
    assert hasattr(strategy_module_0, 'run_queue')

# Generated at 2022-06-25 12:14:15.419033
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule()

# make sure if we call StrategyModule.add_tqm_variables a few times
# the variable tqm_vars will not be set more than once