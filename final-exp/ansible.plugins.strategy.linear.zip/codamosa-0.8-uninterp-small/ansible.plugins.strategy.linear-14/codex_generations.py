

# Generated at 2022-06-25 12:09:28.919897
# Unit test for method run of class StrategyModule

# Generated at 2022-06-25 12:09:29.881859
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:09:31.333269
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:09:33.037806
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)
    assert bool_0
    assert strategy_module_0

# Generated at 2022-06-25 12:09:39.115022
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    playbook_path = ''
    inventory_path = ''
    host_list = ''
    verbosity = ''
    options = True
    loader_0 = DataLoader()
    variable_manager_0 = VariableManager()
    inventory_0 = Inventory(loader_0, variable_manager_0, host_list)
    tqm_0 = TaskQueueManager(
        inventory_0,
        loader_0,
        variable_manager_0,
        options,
        passwords=None,
        stdout_callback=None,
        run_tree=False,
    )
    display_0 = Display()
    callback_0 = CallbackBase()

# Generated at 2022-06-25 12:09:42.356142
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bool_0 = True
    bool_1 = bool_0
    for i in range(10):
        strategy_module_0 = StrategyModule(bool_1)
        iterator_0 = 'a'
        iterator_1 = iterator_0
        play_context_0 = '~'
        play_context_1 = play_context_0
        result = strategy_module_0.run(iterator_1, play_context_1)
        bool_1 = not bool_0


# Generated at 2022-06-25 12:09:44.490318
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule")
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:09:46.468351
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:09:49.326845
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Boolean value
    bool_0 = False
    # Default value Iterator
    iterator_0 = Iterator()
    # Default value PlayContext
    play_context_0 = PlayContext()

    strategy_module_0 = StrategyModule(bool_0)
    strategy_module_0.run(iterator_0, play_context_0)

if __name__ == "__main__":
    test_case_0()
    test_StrategyModule_run()
    print("Test finished")

# Generated at 2022-06-25 12:09:51.484922
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()


# Generated at 2022-06-25 12:10:41.009253
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    print(strategy_module_0)
    print(type(strategy_module_0))
    print(strategy_module_0.__doc__)
    print(strategy_module_0.__dict__)
    #print(strategy_module_0.__module__)
    print(strategy_module_0.__init__)
    #print(strategy_module_0.__weakref__)
    print(strategy_module_0._hosts_cache)
    print(strategy_module_0._hosts_cache_all)
    strategy_module_0._hosts_cache = 'dummy'
    strategy_module_0._hosts_cache_all = 'dummy'


# Generated at 2022-06-25 12:10:43.260446
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as exception_instance:
        print("Assertion failed in test_StrategyModule")
        print(exception_instance)

# Test the constructor of class StrategyModule
test_StrategyModule()

# Generated at 2022-06-25 12:10:48.017356
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule()
    test_iterator_0 = iterator.Iterator(None)
    test_iterator_0.iterator_task_count = 0
    test_iterator_0.iterator_failed_hosts = {}
    test_iterator_0._play = play.Play()
    test_iterator_0._play.hosts = frozenset(set(['127.0.0.1']))
    test_play_context_0 = play_context.PlayContext(None)
    strategy_module_0.run(test_iterator_0, test_play_context_0)


# Generated at 2022-06-25 12:10:51.868760
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule()
    iterator_0 = iterator.Iterator(play_0)
    strategy_module_0.run(iterator_0, play_context_0)
    #  check if StrategyModule instance has a run method
    assert hasattr(strategy_module, "run")
    #  check if the return type of run is int
    assert isinstance(strategy_module.run(iterator, play_context), int)

test_StrategyModule_run()

# Generated at 2022-06-25 12:10:55.144374
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    print(strategy_module_0.__dict__)
    print(strategy_module_0.__class__.__name__)
    print(strategy_module_0.__doc__)
    if (strategy_module_0 != None):
        print(True)
    else:
        print(False)


# Generated at 2022-06-25 12:10:56.684438
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    # Test if __init__ is working correctly
    assert True


# Generated at 2022-06-25 12:11:00.095566
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    assert type(strategy_module_0) is StrategyModule


# Generated at 2022-06-25 12:11:05.625850
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # get InventoryManager instance
    inventory_manager_0 = InventoryManager(loader=None, sources=['test/test_inventories/test_inventory'])
    inventory_manager_0.parse_sources()

    # get variable manager instance
    variable_manager_0 = VariableManager(loader=None, inventory=inventory_manager_0)
    # get datastructure for test case

# Generated at 2022-06-25 12:11:08.446278
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    #TODO: Create test case for test_StrategyModule


# Generated at 2022-06-25 12:11:11.992449
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule()
    iterator = Mock(Iterator)
    play_context = Mock(PlayContext)
    strategy_module_0.run(iterator, play_context)

# Generated at 2022-06-25 12:12:34.982084
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    assert strategy_module_0 is not None


# Generated at 2022-06-25 12:12:38.928079
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 12:12:43.567467
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test constructor of class StrategyModule
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:12:49.362615
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    print(strategy_module_0)
    assert strategy_module_0._tqm is None, "strategy_module_0._tqm should be None but is " + str(strategy_module_0._tqm)
    assert strategy_module_0._unreachable_hosts is None, "strategy_module_0._unreachable_hosts should be None but is " + str(strategy_module_0._unreachable_hosts)
    assert strategy_module_0._inventory is None, "strategy_module_0._inventory should be None but is " + str(strategy_module_0._inventory)

# Generated at 2022-06-25 12:12:51.165142
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule()
    test_case_0()
    strategy_module_0.run()

# Generated at 2022-06-25 12:12:52.590767
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    #er = StrategyModule.run(self=strategy_module_0, iterator=None, play_context=None)
    pass


# Generated at 2022-06-25 12:12:54.716799
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_1 = StrategyModule()
    iterator = None
    play_context = None
    # run() method raises not implemented error
    with pytest.raises(NotImplementedError):
        strategy_module_1.run(iterator, play_context)


# Generated at 2022-06-25 12:12:55.778881
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule()
    strategy_module_0.run(iterator, play_context)

# Generated at 2022-06-25 12:12:58.053890
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    iterator_0 = iterator.Iterator(runner_internal.get_runner_internal())
    play_context_0 = PlayContext()
    strategy_module_0 = StrategyModule()
    strategy_module_1 = strategy_module_0
    strategy_module_1.run(iterator_0, play_context_0)

# Generated at 2022-06-25 12:13:00.707240
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print('Testing run ... ', end='')

    # Setup
    strategy_module = StrategyModule()
    strategy_module._tqm.get_next_task_for_host = Mock(return_value=('some task', 'some host'))

    # Test
    strategy_module.run(iterator='some iterator', play_context='some play context')

    # Verify


# Generated at 2022-06-25 12:14:55.428033
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    host = Host('localhost')
    host.name = 'test_name'
    host.port = 'test_port'
    host.vars = dict(a=1, b=2)
    task = Task()
    task.action = 'test_action'
    task.args = dict(x=1, y=2)
    task._role = Role()
    task._role._metadata = None
    play = Play()
    play.hosts = ['localhost']
    PLAY_REACHABLE = 'test_play_reachable'
    PLAY_FAILED = 'test_play_failed'
    PLAY_UNREACHABLE = 'test_play_unreachable'
    PLAY_FAILED_BREAK_PLAY = 'test_play_failed_break_play'
    RUN_OK = 'test_run_ok'


# Generated at 2022-06-25 12:15:05.115743
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from mock import Mock
    from mock import patch
    from mock import sentinel
    strategy_module = StrategyModule()
    iterator = Mock()
    play_context = Mock()
    strategy_module.run(iterator, play_context)
    strategy_module._pending_results = 1
    strategy_module.update_active_connections = Mock()
    strategy_module._wait_on_pending_results = Mock()
    strategy_module.run(iterator, play_context)
    strategy_module._pending_results = 1
    strategy_module.get_hosts_left = Mock()
    strategy_module.get_hosts_left.return_value = []
    strategy_module._tqm = Mock()
    strategy_module.run(iterator, play_context)

# Generated at 2022-06-25 12:15:11.933628
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import os
    import sys
    import mock
    import pkgutil
    import yaml

    mock_loader = mock.MagicMock()
    mock_variable_manager = mock.MagicMock()
    mock_all_vars = {}

    mock_options = mock.MagicMock()
    mock_options.conn_pass = None
    mock_options.private_key_file = None
    mock_options.connection = 'ssh'
    mock_options.timeout = 10
    mock_options.remote_user = 'user'
    mock_options.sudo = False
    mock_options.ask_sudo_pass = False
    mock_options.module_path = None
    mock_options.module_path_preserve_bytes = False
    mock_options.become = False

# Generated at 2022-06-25 12:15:14.237953
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-25 12:15:21.532576
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Set up mock objects
    iterator_obj = MagicMock(spec=Iterator)
    play_context_obj = MagicMock(spec=PlayContext)
    # Instantiate object using clean method
    tqm_obj = MagicMock()
    options_obj = MagicMock()
    inventory_obj = MagicMock()
    variable_manager_obj = MagicMock()
    loader_obj = MagicMock()
    passwords_obj = MagicMock()
    stdout_callback_obj = MagicMock()
    stats_obj = MagicMock()
    test_obj = StrategyModule(tqm_obj, options_obj, inventory_obj, variable_manager_obj, loader_obj, passwords_obj, stdout_callback_obj, stats_obj)

# Generated at 2022-06-25 12:15:22.595898
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module = StrategyModule()
    assert module.run(iterator, play_context)

# Generated at 2022-06-25 12:15:23.594646
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()


# Generated at 2022-06-25 12:15:31.116453
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule(tqm=None, hosts=['host1', 'host2'], inventory=None, variable_manager=None, loader=None, options=None, passwords=None, stdout_callback=None, run_additional_callbacks=None, run_tree=False, play_context=None, new_stdin=None)
    #iterator resolved to an instance of HostIterator
    iterator = HostIterator(hosts=None, play=None, inventory=None, variable_manager=None, all_vars=None, options=None)
    #play_context resolved to an instance of PlayContext

# Generated at 2022-06-25 12:15:32.300525
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    #strategy = StrategyModule(
    strategy = Linear()
    strategy.run(iterator, play_context)



# Generated at 2022-06-25 12:15:34.048117
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(name="strategy_test", tqm=None, loader=None, variable_manager=None)
    assert strategy_module.name == "strategy_test"
