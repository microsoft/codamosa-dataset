

# Generated at 2022-06-25 12:09:21.352070
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    try:
        test_case_0()
    except:
        print("Test case 0 failed")

# Generated at 2022-06-25 12:09:25.100127
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = False
    strategy_module_0 = StrategyModule(bool_0)

if __name__ == '__main__':
    test_StrategyModule()
    test_case_0()

# Generated at 2022-06-25 12:09:33.433686
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.playbook.vars.manager
    import ansible.template.template
    import ansible.template.vars
    import ansible.vars.manager
    import ansible.inventory.host
    import ansible.inventory.manager
    import ansible.playbook.play_context

    # Create a dummy task queue manager
    task_queue_manager_0 = TaskQueueManager()

    # Create a dummy play
    play_0 = ansible.playbook.play.Play()

    # Create a dummy block
    block_0 = ansible.playbook.block.Block()

# Generated at 2022-06-25 12:09:34.122211
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:09:37.126095
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bool_0 = False
    strategy_module_0 = StrategyModule(bool_0)
    iterator_0 = iterator.Iterator([])
    play_context_0 = object()
    result_0 = strategy_module_0.run(iterator_0, play_context_0)
    assert result_0 == 0


# Generated at 2022-06-25 12:09:41.424374
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bool_0 = False
    strategy_module_0 = StrategyModule(bool_0)
    strategy_module_0.run(iterator, play_context)

# Test simple variable creation

# Generated at 2022-06-25 12:09:51.548110
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from .fixtures.test_playbook_v2_play_context import TestPlaybookV2PlayContext

    bool_0 = False
    strategy_module_0 = StrategyModule(bool_0)
    variable_manager_0 = VariableManager()
    loader_0 = DataLoader()
    iterator_0 = TestPlaybookV2PlayContext()
    play_context_0 = PlayContext()
    # run the method and check the result
    result = strategy_module_0.run(iterator_0, play_context_0)
    #assert result == self._tqm.RUN_UNKNOWN_ERROR


# Generated at 2022-06-25 12:09:56.797647
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
    bool_21 = bool()
    bool_22 = bool()
    bool_23 = bool()
    bool_24 = bool()

# Generated at 2022-06-25 12:10:02.467197
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    strategy_module_0 = StrategyModule()

    bool_0 = False
    play_context_0 = PlayContext()
    iterator_0 = HostIterator(bool_0, play_context_0)

    result = strategy_module_0.run(iterator_0, play_context_0)

    # Assert the expected call.
    # Call the method directly with the implemented args.
    # assert_equal(stub.method_1(arg_1, arg_2), ...)


# Generated at 2022-06-25 12:10:13.256232
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    bool_0 = False
    strategy_module_0 = StrategyModule(bool_0)

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible import context
    from ansible.executor.playbook_executor import PlaybookExecutor
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list="tests/inventory")
    variable_manager.set_inventory(inventory)
    play_context = context.CLIARGS._get_kwargs()
    play_context.pop('vault_password', None)

# Generated at 2022-06-25 12:10:58.035630
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    s = StrategyModule()
    #Test with valid argument

    #Test with invalid argument



# Generated at 2022-06-25 12:11:03.289907
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    block_0 = module_0.Block()
    strategy = StrategyModule(None, block_0, None)
    iterator = PlayIterator(block_0, None, None)
    play_context = PlayContext(None)
    strategy.run(iterator, play_context)

# Generated at 2022-06-25 12:11:05.617469
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    pass

import ansible.playbook.hostblock as module_1


# Generated at 2022-06-25 12:11:10.766297
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    block_0 = module_0.Block()
    execution_recorder_0 = ExecutionRecorder()
    loader_0 = DataLoader()
    variable_manager_0 = VariableManager()
    inventory_0 = Inventory()
    strategy_module_0 = StrategyModule(tqm=None, loader=loader_0, variable_manager=variable_manager_0, hosts=[inventory_0])
    strategy_module_0.run(iterator=[block_0], play_context=execution_recorder_0)



# Generated at 2022-06-25 12:11:13.384006
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj_strategy = StrategyModule(loader=None, variable_manager=None, host_list=None)


# Generated at 2022-06-25 12:11:24.743910
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    local_loader = module_0.DataLoader()
    local_variable_manager = module_0.VariableManager()
    print("Test start")

# Generated at 2022-06-25 12:11:26.103752
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()


# Generated at 2022-06-25 12:11:27.908117
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass # TODO: implement your test here


# Generated at 2022-06-25 12:11:29.068995
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()


# Generated at 2022-06-25 12:11:37.754365
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import ansible.playbook.base as module_0
    import ansible.playbook.block as module_1
    import ansible.playbook.helpers as module_2
    import ansible.playbook.iterator as module_3
    import ansible.playbook.play as module_4
    import ansible.playbook.play_context as module_5
    from ansible.playbook import strategy_loader
    import ansible.playbook.task as module_7
    import copy
    class MockRole(object):
        def __init__(self, metadata):
            self._metadata = metadata
        def has_run(self, host):
            return True
    strategy_loader.add_strategy('AnsibleModule', StrategyModule)
    Play_0 = module_4.Play()
    Play_0._state = module_4

# Generated at 2022-06-25 12:12:34.512677
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    
    args = ''
    kwargs = {}

    retobj = test_instance.run(args, **kwargs)
    return (True, retobj)


# Generated at 2022-06-25 12:12:35.418351
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert True == True

# Generated at 2022-06-25 12:12:44.129315
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    configuration = AnsibleEngine.DataModel()

# Generated at 2022-06-25 12:12:45.839449
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategyModule = StrategyModule()
    iterator = Iterator()
    play_context = PlayContext()
    strategyModule.run(iterator, play_context)


# Generated at 2022-06-25 12:12:55.070738
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  hosts = [Host(name='foo'),Host(name='bar')]
  tqm = Mock(return_value=[{'host': 'foo', 'task': {'taskname': 'task1'}, '_result': {'foo': 'bar'}}])
  it = Mock(return_value=[{'host': 'foo', 'task': {'taskname': 'task1'}, '_result': {'foo': 'bar'}, '_task': {'taskname': 'task1'}}])
  pc = Mock(return_value=[{'host': 'foo', 'task': {'taskname': 'task1'}, '_result': {'foo': 'bar'}, '_task': {'taskname': 'task1'}}])

# Generated at 2022-06-25 12:13:00.742672
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  # construct object
  sm = StrategyModule(connection_loader=None, callback_loader=None, variable_manager=None, loader=None, options=None, passwords=None, stdout_callback=None, run_tree=False, stats=None)
  # verify internal data has been instantiated
  assert sm._tqm is not None
  assert sm._variable_manager is not None
  assert sm._loader is not None
  assert sm._stdout_callback is not None
  assert sm._run_tree is False
  assert sm._stats is not None
  assert sm._hosts_cache is None
  assert sm._hosts_cache_all is None

  # test _get_next_task_lockstep()
  host1 = Host('host1')
  res = sm._get_next_task_lockstep([host1], None)


# Generated at 2022-06-25 12:13:01.418276
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()

# Generated at 2022-06-25 12:13:05.537021
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(
        tqm=TaskQueueManager(),
        variable_manager=VariableManager(),
        loader=None,
        options=Options(),
        passwords=None,
    )
    assert strategy_module._tqm
    assert strategy_module._variable_manager
    assert isinstance(strategy_module.get_hosts_left, list)


# Generated at 2022-06-25 12:13:09.613452
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # check can init correctly
    try:
        strategy_module = StrategyModule()
    except Exception as e:
        print("EXCEPTION: %s" % e)
        assert False, "StrategyModule fails to init"

    print("StrategyModule init successfully")

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:13:18.650493
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    '''
    Unit test for method run of class StrategyModule
    '''
    # inputs
    args = dict()
    args['daemonize'] = None
    args['remote_user'] = 'user'
    args['remote_pass'] = 'pass'
    args['become'] = None
    args['become_method'] = 'sudo'
    args['become_user'] = 'user'
    args['become_pass'] = 'pass'
    args['ssh_common_args'] = ''
    args['ssh_extra_args'] = ''
    args['sftp_extra_args'] = ''
    args['scp_extra_args'] = ''
    args['become_exe'] = ''
    args['become_flags'] = ''
    args['pipelining'] = None

# Generated at 2022-06-25 12:15:19.048107
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  pass

# Generated at 2022-06-25 12:15:20.627157
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module != None
    assert isinstance(strategy_module, StrategyModule)

# Generated at 2022-06-25 12:15:22.724121
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule(None, None)
    strategy_module.add_block()
    strategy_module._initialize_control_step()
    strategy_module.run()

# Test case for StrategyModule class

# Generated at 2022-06-25 12:15:30.593498
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    config_instance = config.Config(parser=None)
    variable_manager = variable_manager.VariableManager()
    loader = loader.DataLoader()
    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=None, host_list='tests/unit/inventory.json'))
    variable_manager._extra_vars = {'hostvars': {}}
    options = Options()
    options.host_key_checking = False
    options.privilege_escalation = None
    options.connection = "ssh"
    options.remote_user = None
    options.timeout = 10
    options.become = False
    options.become_method = None
    options.become_user = None
    options.become_password = False
    options.verbosity = 1
    options.check = False
    options

# Generated at 2022-06-25 12:15:36.047294
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    host1 = Host(name="host1")
    host2 = Host(name="host2")
    host3 = Host(name="host3")
    host1.set_variable('ansible_ssh_host', 'host1')
    host1.set_variable('ansible_ssh_port', 22)
    host2.set_variable('ansible_ssh_host', 'host2')
    host2.set_variable('ansible_ssh_port', 22)
    host3.set_variable('ansible_ssh_host', 'host3')
    host3.set_variable('ansible_ssh_port', 22)

    # mock callback data
    stdout_lines = [
        b'task output',
    ]

    stdout = b'\n'.join(stdout_lines)

# Generated at 2022-06-25 12:15:36.582725
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-25 12:15:37.928853
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' strategy_plugin_test.py:test_StrategyModule '''

    assert StrategyModule(tqm)


# Generated at 2022-06-25 12:15:38.608287
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()


# Generated at 2022-06-25 12:15:44.072998
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # _set_hosts_cache
    hosts_cache = {}
    hosts_cache_all = {}
    class Host:
        def __init__(self,name):
            self.name = name
        def get_name(self):
            return self.name
    class Play:
        def __init__(self,inventory):
            self.inventory = inventory
        def get_hosts(self,include_patterns, exclude_patterns):
            print(include_patterns)
            print(exclude_patterns)
            return self.inventory
    class Inventory:
        def __init__(self,hosts,groups):
            self.hosts = hosts
            self.groups = groups
        def get_hosts(self,include_patterns, exclude_patterns):
            print(include_patterns)

# Generated at 2022-06-25 12:15:44.802724
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy is not None