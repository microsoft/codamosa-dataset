

# Generated at 2022-06-25 12:09:27.599282
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    str_0 = 'H9U6}_U6E'
    strategy_module_0 = StrategyModule(str_0)

    iterator_0 = iterator.TaskIterator()
    play_context_0 = PlayContext()
    strategy_module_0.run(iterator_0, play_context_0)
    #assert iterator_0._play._handlers == [], 'iterator_0._play._handlers == []'
    assert strategy_module_0._tqm._terminated == False, 'strategy_module_0._tqm._terminated == False'

# Generated at 2022-06-25 12:09:30.231172
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test if the constructor works
    try:
        test_case_0()
        print('Test passed')
    except Exception:
        # print('Test failed')
        raise Exception


# Generated at 2022-06-25 12:09:37.178118
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # These are tests made to validate the method run of the class StrategyModule
    # We will create a StrategyModule instance and call the method 'run' with
    # some random integer and try to see what happens
    str_1 = 'q=!hUDMj9HZW:V'
    strategy_module_1 = StrategyModule(str_1)
    integer_1 = random.randint(-2**63, 2**63)
    integer_1 = random_integer(integer_1)
    iterator_1 = random.randint(-2**63, 2**63)
    iterator_1 = iterator(iterator_1)
    play_context_1 = random.randint(-2**63, 2**63)
    play_context_1 = PlayContext(play_context_1)

# Generated at 2022-06-25 12:09:44.586010
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_0 = StrategyModule()
    iterator_0 = iterator.Iterator(None, None, None)
    play_context_0 = play.PlayContext()
    strategy_module_0.run(iterator_0, play_context_0)
    strategy_module_0.run(None, play_context_0)
    strategy_module_0.run(iterator_0, None)



# Generated at 2022-06-25 12:09:49.730739
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    r'''
    StrategyModule.run
    '''
    strategy_module_0 = StrategyModule('test_value_0')
    strategy_module_1 = StrategyModule('test_value_1')
    strategy_module_2 = StrategyModule('test_value_2')
    strategy_module_3 = StrategyModule('test_value_3')


# Generated at 2022-06-25 12:09:51.536124
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # place holder
    assert True == True


# Generated at 2022-06-25 12:09:56.181797
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'QTzm=5IG]`C.H9'
    strategy_module_0 = StrategyModule(str_0)
    if (strategy_module_0 is None):
        print("\033[1;31mWrong\033[0m")
    else:
        print("\033[1;32mRight\033[0m")



# Generated at 2022-06-25 12:09:57.510761
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('success_0')


# Generated at 2022-06-25 12:10:00.369072
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str = 'QTzm=5IG]`C.H9'
    strategy_module_0 = StrategyModule(str)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:10:02.785499
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Arrange
    dummy_string = 'stupid_string'
    
    # Act
    strategy_module = StrategyModule(dummy_string)

    # Assert
    dummy_string.assert_called_once_with()



# Generated at 2022-06-25 12:10:50.512798
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' unit test for constructor of class StrategyModule '''

    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=None, sources=''),
        variable_manager=VariableManager(),
        loader=None,
        options=Options(),
        passwords={},
    )
    sm = StrategyModule(tqm=tqm)
    assert sm is not None

# Generated at 2022-06-25 12:10:58.594200
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.connection import Connection
    from ansible.plugins.strategy import StrategyModule
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

# Generated at 2022-06-25 12:11:09.432253
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # mock host
    host = mock.Mock()
    host.get_name.return_value = 'localhost'
    # mock iterator
    iterator = mock.Mock()
    # mock play_context
    play_context = mock.Mock()
    # mock module object
    module = mock.Mock()
    # create strategy module object
    strategy_module = StrategyModule(module)
    # create method run mock object
    strategy_module.get_hosts_left = mock.Mock(side_effect=['localhost'])
    strategy_module._set_hosts_cache = mock.Mock()
    strategy_module.add_tqm_variables = mock.Mock()
    strategy_module._get_next_task_lockstep = mock.Mock(side_effect=[(host, '')])
    strategy_

# Generated at 2022-06-25 12:11:22.030885
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # create a StrategyModule object
    strategy_module = StrategyModule()

    # create a dummy variable manager for testing
    variable_manager = VariableManager()

    # create a dummy loader for testing
    loader = DataLoader()

    # create a dummy inventory for testing
    inventory = InventoryManager(loader=loader, sources='localhost,', variable_manager=variable_manager)

    # create a dummy variable manager for testing
    variable_manager = VariableManager()

    # create a dummy queue manager for testing
    queue_manager = QueueManager()

    # create a TaskQueueManager object

# Generated at 2022-06-25 12:11:23.944197
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    my_StrategyModule = StrategyModule()
    assert isinstance(my_StrategyModule, StrategyModule)


# Generated at 2022-06-25 12:11:27.463279
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    print("Test StrategyModule(): ", strategy)
    assert strategy is not None

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:11:31.668934
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.strategy import StrategyModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible import context
    import ansible.constants as C
    add_all_plugin_dirs()

# Generated at 2022-06-25 12:11:32.655090
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  pass


# Generated at 2022-06-25 12:11:37.283689
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        strategy = StrategyModule(task_queue_manager=None)
        if isinstance(strategy, StrategyModule):
            log.info("StrategyModule : ok")
        else:
            log.info("StrategyModule : failed")
            return 1

    except Exception as e:
        log.error("StrategyModule : failed with error %s" % str(e))
        return 1

    return 0


# Generated at 2022-06-25 12:11:38.800689
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("Test if StrategyModule_run() function works successfully.")
    test_StrategyModule_run.__wrapped__()


# Generated at 2022-06-25 12:13:37.471550
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_inventory_file

# Generated at 2022-06-25 12:13:45.807126
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    def _factory(module_name, *args, **kwargs):
        def f():
            return module_name
        return f

    def teardown():
        pass

    # Create basic mocks
    loader = Mock()
    hosts = [Mock()]
    tqm = Mock()
    tqm._terminated = False

    # Create objects that are not mocks
    tqm._failed_hosts = {}
    iterator = Mock()
    iterator._play = Mock()
    iterator._play.get_variable_manager = Mock()
    iterator._play.get_variable_manager.return_value = Mock()
    iterator._play.get_variable_manager.return_value.get_vars.return_value = {'hostvars': {}}

# Generated at 2022-06-25 12:13:47.613440
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None

# Generated at 2022-06-25 12:13:49.164424
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for constructor of class StrategyModule
    '''
    strategy = StrategyModule()
    assert strategy is not None


# Generated at 2022-06-25 12:13:57.461345
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ############################################################
    # Setup
    ############################################################
    import ansible.plugins.loader
    tqm = MockTQM(None, 0, None, None, None)
    tqm._stats = MockStats(tqm)

    inventory = ansible.inventory.Inventory(host_list='/tmp/junk')

    variable_manager = ansible.vars.VariableManager()
    playbook_path = "/tmp/junk"
    loader, playbook, ds = ansible.cli.load_playbook(playbook_path, variable_manager=variable_manager, loader=None)
    variable_manager.set_inventory(inventory)
    play = datastructure_loader.DataLoader().load(ds[0])
    iterator = ansible.playbook.PlayIterator(inventory, play, variable_manager)

# Generated at 2022-06-25 12:14:01.854770
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  inventory = InventoryManager(loader=None, sources='''
  localhost ansible_connection=local
  ''')
  variable_manager = VariableManager(loader=None, inventory=inventory)
  tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback='default',
        run_additional_callbacks=False,
        run_tree=False,
  )
  strategy = StrategyModule(tqm, None)
  assert strategy is not None


# Generated at 2022-06-25 12:14:04.740105
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=None, sources='localhost,'),
        variable_manager=None,
        loader=None,
        passwords=None,
        stdout_callback='default',
    )
    sm = StrategyModule(tqm)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:14:06.006039
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-25 12:14:14.498641
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' strategy_module.py:TestStrategyModule.test_strategy_module_constructor '''
    # This test case works with ansible 2.8
    # The StrategyModule class implemented in this file is used in ansible 2.8

    # Create a options object
    options = mock.Mock()
    options.connection = 'smart'
    options.module_path = '/path/to/mymodules'
    options.forks = 5
    options.remote_user = 'user'
    options.private_key_file = None
    options.ssh_common_args = None
    options.ssh_extra_args = None
    options.sftp_extra_args = None
    options.scp_extra_args = None
    options.become = False
    options.become_method = 'sudo'

# Generated at 2022-06-25 12:14:16.400566
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TaskQueueManager()
    StrategyModule(tqm)



# Generated at 2022-06-25 12:18:43.900707
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(None, None, None, None)
    assert module

# Generated at 2022-06-25 12:18:45.218002
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule()
    assert isinstance(strategyModule, StrategyModule), "wrong type of object"

# Generated at 2022-06-25 12:18:52.484955
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    mock_variable_manager = mock.Mock()
    mock_loader = mock.Mock()
    mock_iterator = mock.Mock()
    mock_play_context = mock.Mock()
    mock_tqm= mock.Mock()
    mock_tqm.RUN_OK = 0
    mock_tqm.RUN_FAILED_BREAK_PLAY = 1
    mock_tqm.RUN_UNKNOWN_ERROR = 2
    mock_tqm._terminated = False
    mock_tqm._failed_hosts = {}
    mock_play = mock.Mock()
    mock_iterator._play = mock_play
    mock_iterator.mark_host_failed = mock.Mock()
    mock_play.max_fail_percentage = None