

# Generated at 2022-06-11 17:03:43.255585
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    my_strategy_module = StrategyModule()
    my_iterator = my_strategy_module._tqm.get_iterator()

    my_play_context = PlayContext()
    my_play_context.remote_addr = '127.0.0.1'
    my_play_context.port = 22
    my_play_context.remote_user = 'test'
    my_play_context.connection = 'ssh'
    my_play_context.timeout = 10
    my_play_context.shell = 'test'
    my_play_context.become = True
    my_play_context.become_method = 'test'
    my_play_context.become_user = 'test'
    my_play_context.verbosity = 0
    my_play_context.extra_vars = ['test']

# Generated at 2022-06-11 17:03:50.822733
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for StrategyModule
    '''

    ################################################################
    # For each test case, initialize an instance of
    # StrategyModule and and do a check test for the following items:
    # 1. whether the values of initialized attributes are as expected
    ################################################################
    # test case 1
    # no call to constructor
    strategy_obj = StrategyModule()
    assert(strategy_obj.get_name() == 'linear')

    # test case 2
    # call to constructor

# Generated at 2022-06-11 17:03:54.702410
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    try:
        assert isinstance(strategy, StrategyModule)
    except AssertionError:
        print('Test Strategy Module Class constructor failed')
        return
    print('Test Strategy Module Class constructor passed')


# Generated at 2022-06-11 17:04:02.571684
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    options = Options()
    options.connection = 'ssh'
    options.module_path = None
    options.forks = 10
    options.become = False
    options.become_method = 'sudo'
    options.become_user = ''
    options.check = False
    options.listhosts = None
    options.listtasks = None
    options.listtags = None
    options.syntax = None
    options.tags = []
    options.skip_tags = []
    options.extra_vars = []
    options.extra_vars_file = None
    options.inventory = None
    options.ask_vault_pass = False
    options.new_vault_password_file = None
    options.output_file = None
    options.one_line = None


# Generated at 2022-06-11 17:04:04.683963
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule()
    assert strategyModule is not None

# Generated at 2022-06-11 17:04:15.669578
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import ansible_collections
    import ansible_collections.ansible.community.plugins.module_utils.network.ftd.common.ftd_client_init as ftd_client_init
    from ansible_collections.ansible.community.plugins.module_utils.network.ftd.common.ansible_collections.ansible.community.plugins.module_utils.network.ftd.common import ftd_host_argument_spec
    ansible_collections.ansible.community.plugins.module_utils.network.ftd.common.ftd_client_init.load_params = mock.MagicMock()
    ftd_host_argument_spec.load_params = mock.MagicMock()

# Generated at 2022-06-11 17:04:17.397598
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module = StrategyModule()
    module.run()

# Generated at 2022-06-11 17:04:19.387590
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    runner = RunnerModule()
    strategy = StrategyModule(runner)
    assert(strategy)


# Generated at 2022-06-11 17:04:21.077493
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t = StrategyModule(None)
    assert t is not None

# Generated at 2022-06-11 17:04:23.518543
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule() is not None;

if __name__ == "__main__":
    test_StrategyModule();

# Generated at 2022-06-11 17:05:03.983847
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # linear, serial, free and debug
    strategy = StrategyModule()
    assert strategy is not None

# Unit test function

# Generated at 2022-06-11 17:05:10.818975
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module._tqm is None
    assert strategy_module.get_hosts_remaining_in_play(None) == []
    assert strategy_module.get_failed_hosts(None) == []
    assert strategy_module.get_changed_hosts(None) == []
    assert strategy_module.add_tqm_variables({}, None) == {}
    assert strategy_module.run(None, None) == None



# Generated at 2022-06-11 17:05:17.584743
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # --- mock get_next_task_for_host return value ---
    class Bunch(object):
        pass

    get_next_task_for_host_return = Bunch()
    get_next_task_for_host_return.is_failed = lambda : False
    get_next_task_for_host_return.parent = None
    # --- mock get_next_task_for_host return value ---

    # --- mock iterator.get_next_task_for_host ---
    def my_get_next_task_for_host(host, peek=False):
        return get_next_task_for_host_return
    # --- mock iterator.get_next_task_for_host ---

    # --- mock iterator ---
    class Bunch(object):
        pass

    iterator = Bunch()

# Generated at 2022-06-11 17:05:26.943130
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # initialize the test class
    strategy_module = StrategyModule()

    # define the test data structures
    test_iterator = {'get_next_task_for_host':[{'peek':True,'peek':True,'peek':True,'peek':True}]}
    test_play_context = {'get_metadata':[],
                        'get_play':[]}
    play = [{'serial':None},
            {'serial':1,'serial':2},
            {'serial':3},
            {'serial':4}]

    # define the return values
    task = {'action':['run_once'],
            'any_errors_fatal':[False],
            'args':['_raw_params'],
            'ignore_errors':[False],
            'run_once':[True]}

    results

# Generated at 2022-06-11 17:05:28.645249
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # run runs the task list ,returns result or unknown error

    assert 1==1

# Generated at 2022-06-11 17:05:39.128826
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()

    assert strategy_module is not None, 'Failed to instantiate StrategyModule class'
    assert hasattr(strategy_module, '_tqm'), 'Failed to define _tqm variable for StrategyModule class'
    assert hasattr(strategy_module, '_inventory'), 'Failed to define _inventory variable for StrategyModule class'
    assert hasattr(strategy_module, '_variable_manager'), 'Failed to define _variable_manager variable for StrategyModule class'
    assert hasattr(strategy_module, '_loader'), 'Failed to define _loader variable for StrategyModule class'
    assert hasattr(strategy_module, '_shared_loader_obj'), 'Failed to define _shared_loader_obj variable for StrategyModule class'

# Generated at 2022-06-11 17:05:49.479135
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    playbook_name = playbook.Playbook(
        name='test_playbook',
        playbooks=[],
        host_list=[])

    tqm = shared_loader_obj._tqm

    tqm._unreachable_hosts = dict((h.name, True) for h in tqm._inventory.get_hosts())
    tqm._stats.compute(tqm._inventory, tqm._variable_manager, tqm._loader, tqm._tqm_options, tqm._stdout_callback)

    play = playbook_name._entries[0]

    play_iterator = PlayIterator(play)
    if not play_iterator._play.hosts:
        raise AnsibleError("play [%s] has no hosts defined" % play_iterator._play.name)


# Generated at 2022-06-11 17:05:59.342533
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():#test_run
    initial_call_count = display.send_call_count
    tqm = TaskQueueManager(stdout_callback=results_logger)
    try:
        result = 0
        iterator = PlayIterator()
        play_context = PlayContext()
        strategyinstance = StrategyModule(loader=None, tqm=tqm, variable_manager=None, shared_loader_obj=None)
        result = strategyinstance.run(iterator, play_context)
    finally:
        tqm.cleanup()
    assert display.send_call_count > initial_call_count

# Generated at 2022-06-11 17:06:08.976753
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    play_file = os.path.join(sys.path[0], "./playbooks/playbook.yml")
    hosts_file = os.path.join(sys.path[0], "./playbooks/inventory")
    print("Ansible Extra arguments: -i %s %s" % (hosts_file, play_file))

    variable_manager = VariableManager()
    variable_manager.extra_vars = {"ansible_ssh_user": "root1", "ansible_ssh_pass": "123456"}
    loader = DataLoader()
    loader.set_basedir(os.path.join(sys.path[0], "./playbooks"))
    passwords = {}
    inventory = InventoryManager(loader, variable_manager, host_list=hosts_file)

# Generated at 2022-06-11 17:06:13.763537
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    '''
    # test case for method run
    '''
    myStrat = StrategyModule()
    iterator = None
    play_context = None
    Expect = None
    # run the method
    Result = myStrat.run(iterator, play_context)
    assert Result == Expect


# Generated at 2022-06-11 17:06:52.510458
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
	pass # TODO: implement your test here



# Generated at 2022-06-11 17:06:59.979209
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    loader = DictDataLoader({
        u'hosts': [
            u'localhost',
            u'example.org',
            u'example.com',
        ],
        u'localhost': {
            u'host_specific_vars': u'bar'
        },
        u'example.org': {
            u'host_specific_vars': u'bar'
        }
    })

    inventory = InventoryManager(loader=loader, sources=['hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    tqm = None

    strategy = StrategyModule(tqm, variable_manager=variable_manager)
    assert strategy

# Generated at 2022-06-11 17:07:00.580912
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 17:07:03.268962
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(
        tqm = None,
        variables = None,
        loader = None,
        options = None,
        passwords = None,
        stdout_callback = None,
    )


# Generated at 2022-06-11 17:07:05.704098
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Instance of class StrategyModule
strategy_module = StrategyModule()




# Generated at 2022-06-11 17:07:07.168433
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # This function will be executed for side-effect, unless error occurs
    pass

# Generated at 2022-06-11 17:07:10.020021
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test for constructor of class StrategyModule
    module = StrategyModule()
    assert module is not None

if __name__ == '__main__':
    import pytest
    pytest.main(['-x', __file__])

# Generated at 2022-06-11 17:07:18.282268
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # instantiate a StrategyModule object
    # instantiate a Play object
    # instantiate a PlayContext object
    # instantiate a Playbook object
    # instantiate a PlaybookExecutor object
    # instantiate a TaskQueueManager object
    # instantiate an Inventory object
    # instantiate a Host object
    # instantiate a DataLoader object
    # instantiate a VariableManager object
    # instantiate a ResultCallback object
    # instantiate a Runner object
    # get random value
    # try to call method run of StrategyModule object
    # test if exception was thrown
    # test if function call returns correct value
    pass

# Generated at 2022-06-11 17:07:30.156658
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import os
    import sys
    current_dir = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(current_dir)
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import RoleInclude

# Generated at 2022-06-11 17:07:30.922779
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass



# Generated at 2022-06-11 17:08:52.759474
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)
    # Initialize needed objects
    tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
    )
    strategy = StrategyModule(tqm)
    assert tqm == strategy._tqm
    assert strategy._pending_results == 0
    assert strategy._workers_size == 5
    assert strategy._hosts_cache == {}
    assert strategy._hosts_cache_all == {}
    assert strategy._stopping == False
    assert strategy._workers == {}
    assert strategy._blocked_hosts == {}
    assert strategy._last_hosts

# Generated at 2022-06-11 17:08:57.521182
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Construct class StrategyModule with default parameters
    module = StrategyModule(tqm=None)
    assert module

    # Construct class StrategyModule with specific parameters
    module = StrategyModule(tqm=None, host_name=None)
    assert module


# Generated at 2022-06-11 17:09:04.545524
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_play = Play().load({
        'name': 'test play',
        'hosts': ['testhost'],
        'gather_facts': 'no',
        'tasks': [{
            'action': {
                'module': 'debug',
                'args': {'msg': '{{hostvars["testhost"]["ansible_hostname"]}}-{{hostvars["testhost"]["ansible_facts"]["distribution"]}}'}
            },
        }]},
        variable_manager=VariableManager(), loader=DataLoader(),
        options=Options(tags={}))

# Generated at 2022-06-11 17:09:05.624375
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass # TODO


# Generated at 2022-06-11 17:09:06.321521
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-11 17:09:12.933770
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Initialize objects
    iterator = TaskIterator(None)
    iterator._play = Play()
    play_context = PlayContext()
    tqm = TaskQueueManager()
    strategy_module = StrategyModule(tqm)

    # Test start: Run the method and check result
    result = strategy_module.run(iterator, play_context)
    assert result == 2

if __name__ == '__main__':
    test_StrategyModule_run()

# Generated at 2022-06-11 17:09:14.500994
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy = StrategyModule()
    strategy.run(iterator=None, play_context=None)


# Generated at 2022-06-11 17:09:16.095431
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()

# Generated at 2022-06-11 17:09:17.622402
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # TODO: Implement
    assert True


# Generated at 2022-06-11 17:09:18.269354
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-11 17:12:07.162464
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    """
    # unit test for method run of class StrategyModule
    """
    strategy_module = StrategyModule(tqm=None, strategy=None, strategy_option_values=None, variable_manager=None, loader=None, passwords=None)
    iterator = None
    play_context = None
    assert strategy_module.run(iterator, play_context) == 0, 'test_StrategyModule_run assert#1 has failed.'
# END of the unit test

# unit test for class StrategyModule

# Generated at 2022-06-11 17:12:12.648957
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  # Case 1:
  # setting up the data for the test
  tqm = mock.create_autospec(TaskQueueManager)
  # calling the method under test
  strgy_mod = StrategyModule(tqm)
  iterator = mock.create_autospec(Iterator)
  play_context = mock.create_autospec(PlayContext)
  excp = strgy_mod.run(iterator, play_context)
  assert excp == tqm.RUN_OK


# Generated at 2022-06-11 17:12:21.304754
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    options = Options()
    loader = DataLoader()
    variable_manager = VariableManager()
    passwords = dict()
    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=loader, sources=''),
        variable_manager=variable_manager,
        loader=loader,
        passwords=passwords,
        stdout_callback=None,
    )

    strategy = StrategyModule(tqm)
    iterator = StrategyIterator(loader=loader)
    play_context = PlayContext()

    strategy.run(iterator, play_context)

    return True


# Generated at 2022-06-11 17:12:23.163563
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    assert s._display is not None



# Generated at 2022-06-11 17:12:27.855619
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Unit test must be run with python -m ansible_test.unit.utils.ansible_runner.ansible_runner
# Note that this test case is incomplete.
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-11 17:12:30.506004
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module is not None
    assert strategy_module._tqm is None


# Generated at 2022-06-11 17:12:41.859043
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # TODO: Improve this test
    # Create a fake v2_playbook_on_task_start
    v2_playbook_on_task_start = MagicMock()

    # Create a fake display
    display = MagicMock()

    # Create a fake _tqm
    _tqm = MagicMock()
    _tqm.send_callback = v2_playbook_on_task_start
    
    # Create a fake get_hosts_left
    get_hosts_left = MagicMock()

    # Create a fake _get_next_task_lockstep
    _get_next_task_lockstep = MagicMock()

    # Create a fake _wait_on_pending_results
    _wait_on_pending_results = MagicMock()

    # Create a fake _copy_

# Generated at 2022-06-11 17:12:42.964233
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	pass


# Generated at 2022-06-11 17:12:44.638474
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  s = StrategyModule()
  s.run(iterator, play_context)
 


# Generated at 2022-06-11 17:12:52.575505
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # set up mock inventory and variables
    test_inventory = ansible_inventory.InventoryManager(loader=None, sources=[])
    test_inventory.hosts = {
        'test_host': ansible_inventory.Host('test_host',
                                            port=22,
                                            groups=['test_group'],
                                            has_key=True),
    }

    test_inventory.groups = {
        'test_group': ansible_inventory.Group('test_group'),
    }

    test_inventory.hosts['test_host'].groups.append(test_inventory.groups['test_group'])

    test_variable_manager = VariableManager()
    test_variable_manager.extra_vars = {
        'test_variable': True,
    }

    # set up mock top task queue manager
   