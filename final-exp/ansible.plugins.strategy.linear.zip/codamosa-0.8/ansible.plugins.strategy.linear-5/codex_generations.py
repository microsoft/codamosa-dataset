

# Generated at 2022-06-11 17:03:36.543968
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager()
    loader = DataLoader()
    test_strategy = StrategyModule(
        tqm=None,
        loader=loader,
        inventory=inventory,
        variable_manager=variable_manager,
        passwords={}
    )
    assert test_strategy.get_hosts_left() == {'localhost': None}


# Generated at 2022-06-11 17:03:44.336148
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    my_play = play.Play()
    my_play.play_hosts = ['127.0.0.1','127.0.0.2','127.0.0.3','127.0.0.4','127.0.0.5','127.0.0.6']
    # Designing the iterator using the test play
    my_iterator = iterator.TaskIterator(my_play)
    # Creating instance of StrategyModule class
    my_smodule = StrategyModule(my_iterator, None)
    # Executing the function run from class StrategyModule
    assert my_smodule.run(my_iterator, None) == None

# Generated at 2022-06-11 17:03:46.016388
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy


# Generated at 2022-06-11 17:03:47.147806
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    set_module_args({})


# Generated at 2022-06-11 17:03:49.381432
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("test_loader")
    assert strategy_module._tqm == "test_loader"

test_StrategyModule()

# Generated at 2022-06-11 17:03:50.726023
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None

# Generated at 2022-06-11 17:03:57.390966
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Call function run with a fake task queue manager and a fake iterator to test
    # if the basic workflow of run is correct

    fake_tqm = FailingTaskQueueManager(inventory='inventory.ini')

    fake_iterator = FakeIterator()

    fake_strat = StrategyModule(tqm=fake_tqm)

    result = fake_strat.run(iterator=fake_iterator, play_context=None)

    assert result == fake_tqm.RUN_UNKNOWN_ERROR


# Generated at 2022-06-11 17:03:58.028519
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
	pass

# Generated at 2022-06-11 17:04:03.323932
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=None, sources=''),
        variable_manager=VariableManager(),
        loader=None,
        passwords={},
        stdout_callback=None,
        run_tree=False,
    )
    results = ResultCallback()
    strategy = StrategyModule(tqm, results)

    assert strategy.progress_callback is results

# Generated at 2022-06-11 17:04:13.842249
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_strategy = StrategyModule()
    assert test_strategy._tqm is None
    assert test_strategy._shared_loader_obj is None
    assert test_strategy._default_qsize is None
    assert test_strategy._step is None
    assert test_strategy._loader is None
    assert test_strategy._variable_manager is None
    assert test_strategy._host_result_callback is None
    assert test_strategy._result_pruner is None
    assert test_strategy._workers is None
    assert test_strategy._final_q is None
    assert test_strategy._blocked is None
    assert test_strategy._tqm_stdout_handler is None


# Generated at 2022-06-11 17:04:54.566968
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test class instantiation without args
    strategy_module = StrategyModule()
    assert strategy_module.__class__.__name__ == 'StrategyModule'
    assert strategy_module.__doc__ == 'Execute tasks in a linear fashion'


# Generated at 2022-06-11 17:04:59.420229
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = None
        loader = DataLoader()
        variable_manager = VariableManager()
        strategy = StrategyModule(tqm, loader, variable_manager)
        if strategy is None:
            return False
        return True
    except:
        return False


# Generated at 2022-06-11 17:05:00.933478
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy.get_name() == 'linear'

# Generated at 2022-06-11 17:05:08.181509
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    '''
    unit test for method run of class StrategyModule
    '''
    # _tqm should be initialized with a ansible.executor.task_queue_manager.TaskQueueManager()
    # _hosts_cache should be initialized with a dict
    # _hosts_cache_all should be initialized with a dict
    # _loader should be initialized with a ansible.parsing.dataloader.DataLoader()
    # _variable_manager should be initialized with a ansible.vars.manager.VariableManager()
    # imain should be initialized with a ansible.playbook.play.Play()
    # iterator should be initialized with a ansible.executor.task_iterator.TaskIterator()
    # play_context should be initialized with a ansible.playbook.play.PlayContext()
    # queue_name should be initialized with a

# Generated at 2022-06-11 17:05:10.798741
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-11 17:05:14.022271
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    ########## Get the strategy_module 
    strategy_module = StrategyModule.load()
    ######### test method run
    strategy_module.run()

# Generated at 2022-06-11 17:05:17.456927
# Unit test for constructor of class StrategyModule
def test_StrategyModule():    # pylint: disable=unused-argument
    strategy_module = StrategyModule()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-11 17:05:19.492405
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass
# This is a test for method: get_hosts_left of class StrategyModule

# Generated at 2022-06-11 17:05:22.302781
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a StrategyModule instance
    test_StrategyModule = StrategyModule()
    assert(isinstance(test_StrategyModule, StrategyModule))


# Generated at 2022-06-11 17:05:34.566504
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    result_callback = ResultCallback()
    stats = callbacks.AggregateStats()
    tqm = TaskQueueManager(loader=loader,
                           variable_manager=variable_manager,
                           result_callback=result_callback,
                           stats=stats,
                           run_additional_callbacks=C.DEFAULT_LOAD_CALLBACK_PLUGINS,
                           run_tree=False,
                           mix_callback_plugins=True)
    sm = StrategyModule(tqm)
    assert sm.get_host_list() == tqm.send_callback.host_list
    assert sm.get_queue_depth() == tqm.send_callback.queue_depth

# Generated at 2022-06-11 17:06:44.544160
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-11 17:06:55.714028
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  def mock_get_hosts_left(self):
    return 'mock_hosts'
  def mock_get_next_task_lockstep(self, hosts_left, iterator):
    return 'mock_tasks'
  def mock__execute_meta(self, task, play_context, iterator, host):
    return 'mock_result'
  def mock__execute_meta():
    return 'mock_pending_results'
  def mock__wait_on_pending_results(self, iterator):
    return 'mock_results'
  def mock_update_active_connections(self, results):
    return
  def mock_IncludedFile_process_include_results(self, host_results, iterator, loader, variable_manager):
    return

# Generated at 2022-06-11 17:07:05.678628
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    
    # For the test, we create a tempfile, write the content to it, then create a AnsibleFile object with the tempfile
    # We use the function getvalue() to the the data inside the tempfile
    fd, path = tempfile.mkstemp()
    new_playbook = AnsibleFile(path=path, mode='w')

# Generated at 2022-06-11 17:07:17.086995
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	test_tqm = TestTaskQueueManager()
	test_loader = TestLoader()
	test_variable_manager = TestVariableManager()
	test_inventory = TestInventory()

	test_module_name = 'test_module'
	test_module_path = '/usr/module_path'

	display.verbosity = 4
	test_module_loader = TestModuleLoader(module_name=test_module_name, module_path=test_module_path)

	runner_name = 'test_runner'
	test_runner = TestRunner()


# Generated at 2022-06-11 17:07:18.670090
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 17:07:30.516302
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    loader = DictDataLoader({
        "test.yml": """---
        - name: TEST PLAY
        hosts: local
        tasks:
        - name: TEST TASK ONE
          ping:
        - name: TEST TASK TWO
          ping:
        """,
    })
    tqm = None
    inventory = Inventory('localhost,')
    variable_manager = VariableManager()
    strategy_module = StrategyModule(tqm, inventory, variable_manager, loader, None)
    strategy_module._tqm = "mock tqm"
    assert ('_tqm' in strategy_module.__dict__)
    # '_inventory' is the object of class Inventory (src/lib/ansible/inventory/__init__.py)
    assert ('_inventory' in strategy_module.__dict__)
   

# Generated at 2022-06-11 17:07:31.230691
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
	pass


# Generated at 2022-06-11 17:07:39.234013
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule(None, None, None)
    strategy_module._get_next_task_lockstep = MagicMock()
    strategy_module._execute_meta = MagicMock()
    strategy_module._process_pending_results = MagicMock()
    strategy_module._wait_on_pending_results = MagicMock()
    strategy_module.update_active_connections = MagicMock()
    strategy_module._load_included_file = MagicMock()
    _1 = strategy_module.run(iterator=R(None), play_context=R())
    _2 = strategy_module.run(iterator=R(None), play_context=R())
    return _1, _2


# unit test for method get_hosts_left of class StrategyModule

# Generated at 2022-06-11 17:07:49.331501
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    host1 = host.Host('test_host')
    host1.name = 'test_host'
    host1.play = play.Play().load(dict(
        name='test',
        host_pattern='test_host',
        gather_facts='no',
        tasks=[dict(action=dict(module='command', args=dict(cmd='finger')))]),
        variable_manager=variable_manager.VariableManager(),
        loader=loader.DataLoader()
    )
    host1._play_context = play_context.PlayContext()
    host1._play_context._play = host1.play
    host1._play_context.setup_cache()
    host1._play_context._options = Options()
    host1._play_context._parent = host1

# Generated at 2022-06-11 17:07:52.413372
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule()
    assert module is not None

if __name__ == '__main__':
    # Unit test for class StrategyModule
    test_StrategyModule()

# Generated at 2022-06-11 17:10:24.705399
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create an instance of class StrategyModule
    strategy_module = StrategyModule()

    # We need to set the following attribute for the method run to work
    strategy_module._tqm = "something"

    # Calling run method of class StrategyModule with different set of arguments
    # set _tqm = "something"
    strategy_module.run("iterator", "play_context")
    # set _tqm = None
    strategy_module._tqm = None

    # We need to set the following attributes for the method run to work
    strategy_module._tqm = None
    strategy_module._loader = "something"
    strategy_module._variable_manager = "something"
    strategy_module._host_manager = "something"

    # Calling run method of class StrategyModule with different set of arguments
    # set _tqm and _

# Generated at 2022-06-11 17:10:26.024968
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    obj = StrategyModule('TestStrategyModule')
    obj.run()


# Generated at 2022-06-11 17:10:36.333349
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    from ansible.playbook.play_iterator import PlayIterator
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Create the objects we need to run a playbook
    loader = DataLoader()
    variable_manager = VariableManager()  # is default
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)
    
    play_context = PlayContext()
    play_context.become = False


# Generated at 2022-06-11 17:10:41.820819
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # mock the AnsibleTqm object
    tqm = Mock(spec=TaskQueueManager)

    # mock the play iterator
    iterator = Mock(spec=PlayIterator)

    # mock the play context
    play_context = Mock(spec=PlayContext)

    # set up the strategy_module
    strategy_module = StrategyModule(tqm)

    # execute the run method of the strategy_module
    strategy_module.run(iterator, play_context)


# Generated at 2022-06-11 17:10:53.285465
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm, play, iterator, play_context)
    assert strategy_module.name == 'Linear'
    assert strategy_module._tqm == tqm
    assert strategy_module._play == play
    assert strategy_module._iterator == iterator
    assert strategy_module._play_context == play_context
    assert strategy_module._tqm.tasks_left == 0
    assert strategy_module._tqm.send_callback == None
    assert strategy_module._queue_name == 'linear'
    assert strategy_module.display == None
    assert strategy_module._host_pinned == False
    assert strategy_module._hosts_left_count == 0
    assert strategy_module._workers_left == []
    assert strategy_module._pending_results == 0
    assert strategy_module._bl

# Generated at 2022-06-11 17:11:02.351965
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import ansible.playbook.play_context
    import ansible.executor.task_queue_manager
    import ansible.executor.task_result
    import ansible.plugins.action
    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.inventory.manager
    import ansible.vars.manager
    import ansible.parsing.dataloader
    import ansible.playbook.play
    import ansible.plugins.loader
    import ansible.template.template

    host = ansible.inventory.host.Host('localhost')
    group = ansible.inventory.group.Group('test')
    group.add_host(host)
    inventory = ansible.inventory.manager.InventoryManager(loader=None, sources=['localhost,'])
    inventory.groups = [group]

# Generated at 2022-06-11 17:11:04.692557
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    strategy_module.__init__()
    assert isinstance(strategy_module, StrategyModule)

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-11 17:11:05.825846
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=tqm) is not None



# Generated at 2022-06-11 17:11:15.108098
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Create a mock object and  mocks
    strategy_module = StrategyModule()
    strategy_module._get_next_task_lockstep = MagicMock()
    strategy_module._execute_meta = MagicMock()
    strategy_module._take_step = MagicMock()
    strategy_module._load_included_file = MagicMock()
    strategy_module._copy_included_file = MagicMock()
    strategy_module._prepare_and_create_noop_block_from = MagicMock()
    super(StrategyModule, strategy_module).run = MagicMock()
    strategy_module._tqm.send_callback = MagicMock()
    strategy_module._variable_manager.get_vars = MagicMock()
    strategy_module.add_tqm_variables = MagicMock()


# Generated at 2022-06-11 17:11:23.936887
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module.get_name() == 'linear'
    assert strategy_module.get_option('strategy') == 'linear'
    assert strategy_module.RUN_OK == 0
    assert strategy_module.RUN_ERROR == 1
    assert strategy_module.RUN_FAILED_BREAK_PLAY == 2
    assert strategy_module.RUN_FAILED_HOST_LOOP == 3
    assert strategy_module.RUN_FAILED_FATAL == 4
    assert strategy_module.RUN_UNKNOWN_ERROR == 255