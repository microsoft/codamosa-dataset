

# Generated at 2022-06-11 17:03:28.005356
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TaskQueueManager()
    sm = StrategyModule(tqm)
    tqm.cleanup()


# Generated at 2022-06-11 17:03:39.324870
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  from ansible.vars.unsafe_proxy import AnsibleUnsafeText
  from ansible.module_utils.common._collections_compat import Mapping
  from ansible.module_utils.six.moves import StringIO
  from ansible.parsing.dataloader import DataLoader
  from ansible.executor.task_queue_manager import TaskQueueManager
  from ansible.executor.playbook_executor import PlaybookExecutor
  from ansible.playbook.play import Play
  from ansible.template import Templar
  from ansible.inventory.manager import InventoryManager
  from ansible.plugins.loader import add_all_plugin_dirs, action_loader, module_loader
  from ansible.cli import CLI
  from ansible.utils.plugins import load_plugins

# Generated at 2022-06-11 17:03:48.799095
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    runner = unittest.mock.Mock()
    strategy = 'linear'
    tqm = unittest.mock.Mock()

    stmg = StrategyModule(runner, strategy, tqm)

    assert stmg._tqm == tqm
    assert stmg._play_name == None
    assert stmg._strategy == strategy
    assert stmg._get_next_task_lockstep == False
    assert stmg._blocked_hosts == {}
    assert stmg._pending_results == 0
    assert stmg._workers == {}
    assert stmg._notified_handlers == {}
    assert len(stmg._conditional_results) == 0
    assert stmg._step == None
    assert stmg._get_worker() != False
    assert stmg._inventory == runner.inventory

# Generated at 2022-06-11 17:03:58.644805
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyModule
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task


    strategy = StrategyModule()
    loader = DataLoader()
    variable_manager = VariableManager()
    host = Host()
    iterator = Play()
    play_context = PlayContext()
    task = Task()
    task._role = None
    task._task_fields = ['action']
    task.action = 'ping'
    

# Generated at 2022-06-11 17:04:02.154966
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(isinstance(StrategyModule(), StrategyModule))
    assert(isinstance(StrategyModule(), DefaultRunner))
    assert(isinstance(StrategyModule(), RunnerBase))
    assert(isinstance(StrategyModule(), object))


# Generated at 2022-06-11 17:04:03.692818
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    StrategyModule.run()


# Generated at 2022-06-11 17:04:06.790661
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-11 17:04:08.556354
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module = StrategyModule()
    module.run()



# Generated at 2022-06-11 17:04:11.159572
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule()
    strategy_module.run(iterator, play_context)
# Test the class StrategyModule

# Generated at 2022-06-11 17:04:23.998084
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    class _Test_StrategyModule_Run():
        def test_should_run_ok(self):
            _StrategyModule = StrategyModule()
            _StrategyModule._tqm = mock.Mock()
            _StrategyModule._tqm.run_state = 'pending'
            _StrategyModule._tqm.RUN_OK = 'OK'
            _StrategyModule._tqm.RUN_FAILED_BREAK_PLAY = 'FAILED_BREAK_PLAY'
            _StrategyModule._tqm.RUN_UNKNOWN_ERROR = 'UNKNOWN_ERROR'
            _StrategyModule.set_pattern_callback = lambda *args, **kwargs: None
            _StrategyModule.add_tqm_variables = lambda *args, **kwargs: None
            _StrategyModule

# Generated at 2022-06-11 17:05:12.510679
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    def do(self, iterator, play_context):

        # iterate over each task, while there is one left to run
        result = self._tqm.RUN_OK
        work_to_do = True

        self._set_hosts_cache(iterator._play)


# Generated at 2022-06-11 17:05:23.765136
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test case 1
    # Raise exception and return False
    print('Test case 1')

    tqm = Mock()
    tqm.run_handlers = Mock()

    try:
        StrategyModule(tqm=tqm)
        print('Exception is not raised for tqm = None')
        assert False
    except AnsibleError:
        print('AnsibleError raised, test passed')
        assert True
    except:
        print('AnsibleError not raised but exception raised, test failed')
        assert False

    # Test case 2
    # Return True
    print('Test case 2')
    tqm = Mock()
    tqm.run_handlers = Mock()


# Generated at 2022-06-11 17:05:25.324903
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule() is not None

# Generated at 2022-06-11 17:05:29.722561
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # Arrange
    iterator = None
    play_context = None

    strategy_module_obj = strategy_module.StrategyModule()

    # Act
    actual_result = strategy_module_obj.run(iterator, play_context)

    # Assert
    assert actual_result is None

# Generated at 2022-06-11 17:05:31.177507
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 17:05:33.808574
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  params = {
      'tqm': Mock(spec=TaskQueueManager()),
      'variable_manager': Mock(spec=VariableManager()),
      'loader': Mock(spec=DataLoader()),

  }
  obj = StrategyModule(**params)
  iterator = Mock(spec=PlayIterator())
  play_context = Mock(spec=PlayContext())
  assert isinstance(obj, StrategyModule)
  obj.run(iterator, play_context)

 

# Generated at 2022-06-11 17:05:39.595335
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    loader_mock = MagicMock(spec=DataLoader)
    variable_manager_mock = MagicMock(spec=VariableManager)
    tqm_mock = MagicMock(spec=TaskQueueManager)
    strategy = StrategyModule(tqm_mock, loader_mock, variable_manager_mock)
    assert strategy._tqm == tqm_mock
    assert strategy._loader == loader_mock
    assert strategy._variable_manager == variable_manager_mock


# Generated at 2022-06-11 17:05:48.133043
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.display import Display

    # (self)
    # (iterator, play_context)
    iterator = None
    play_context = PlayContext()

    strategy_module = StrategyModule()
    strategy_module._display = Display()
    try:
        strategy_module.run(iterator, play_context)
    except:
        logger.error('Test failed!')
        sys.exit(1)
    else:
        logger.info('Test succeeded')
        sys.exit(0)

if __name__ == "__main__":
    test_StrategyModule_run()

# Generated at 2022-06-11 17:05:50.143003
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # default args
    run_test(StrategyModule, dict())



# Generated at 2022-06-11 17:05:58.707034
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Unit test for StrategyModule constructor"""
    # Create StrategyModule
    strategy = StrategyModule(
        tqm=None,
        hosts=None,
        loader=None,
        variable_manager=None,
        shared_loader_obj=None,
        final_q=None,
        run_tree=None,
        step=None)
    # test for attributes of class StrategyModule
    assert strategy.hostvars == {}
    assert strategy.hostvars_count == 0


# Generated at 2022-06-11 17:07:18.362654
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():


    # =============================================================================================
    # Unit test for method run of class StrategyModule
    # =============================================================================================
    # Create an object of class StrategyModule
    sm = StrategyModule(tqm=None, inventory=None, variable_manager=None, loader=None)

    # AssertionError: play_context argument of type PlayContext is required
    try:
        sm.run(iterator=None, play_context=None)
    except AssertionError as e:
        pass
    else:
        #self.fail('AssertionError exception was not raised')
        raise AssertionError('AssertionError exception was not raised')

    pc = PlayContext(play=None)

    # TypeError: run() missing 1 required positional argument: 'iterator'

# Generated at 2022-06-11 17:07:30.310410
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    #- Setup
    obj = StrategyModule(b_tqm={
        "run_state": "0",
        "RUN_OK": "0",
        "RUN_UNKNOWN_ERROR": "-1",
        "RUN_FAILED_HOSTS": "2",
        "RUN_FAILED_BREAK_PLAY": "4",
        "send_callback": test_StrategyModule_run_1,
        "_terminated": False
    }, tqm=None, i_b_tqm=None)

    assert obj._tqm.run_state == obj._tqm.RUN_OK
    assert obj._tqm.run_state != obj._tqm.RUN_UNKNOWN_ERROR
    assert obj._tqm.run_state != obj._tqm.R

# Generated at 2022-06-11 17:07:31.414990
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-11 17:07:37.373639
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():


    def test_helper_run(mocker, strategy_module, iterator, play_context, expected_result):
        fake_tqm = MagicMock()
        fake_tqm.send_callback = MagicMock(return_value=True)
        strategy_module._tqm = fake_tqm
        assert strategy_module.run(iterator, play_context) == expected_result

    # Don't have any test for now
    pass


################################################################################
# ExecutionModule class
################################################################################


# Generated at 2022-06-11 17:07:39.216791
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm is not None


# Generated at 2022-06-11 17:07:40.273951
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-11 17:07:49.915239
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    C.HOST_NAME = os.getenv("HOST_NAME")
    C.HOST_IP = os.getenv("HOST_IP")
    C.HOST_KEY = os.getenv("HOST_KEY")
    C.HOST_PORT = os.getenv("HOST_PORT")
    C.HOST_USER = os.getenv("HOST_USER")
    C.HOST_FINGERPRINT = os.getenv("HOST_FINGERPRINT")
    C.HOSTS = os.getenv("HOSTS")
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    passwords = dict(vault_pass='secret')

# Generated at 2022-06-11 17:07:51.556198
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy != None


# Generated at 2022-06-11 17:07:55.815194
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # setup a test StrategyModule object
    strategy = StrategyModule()
    print(strategy)
    assert(strategy is not None)
    assert(strategy._blocked_hosts == {})
    assert(strategy._tqm is not None)



# Generated at 2022-06-11 17:07:57.209644
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    #import pdb; pdb.set_trace()
    pass 

# Generated at 2022-06-11 17:10:33.988540
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible_collections.ansible.community.tests.unit.modules.test_yum import AnsibleModule
    module = AnsibleModule()
    strategy_module = StrategyModule(module)
    strategy_module.run()

# Generated at 2022-06-11 17:10:42.753659
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    data = { "hosts_left" : {"hosts" : ["host1", "host2"]} }
    ws = MagicMock()
    ws.get_worker.return_value = data
    pr = MagicMock()
    pr.get_pending_results.return_value = []
    pr.process_pending_results.return_value = []
    tqm = MagicMock()
    tqm.get_worker_status.return_value = {}
    tqm.RUN_OK = 1
    tqm._workers.return_value = ws
    tqm._pending_results.return_value = pr
    tqm._tqm_variables.return_value = {}
    tqm._terminated.return_value = False

# Generated at 2022-06-11 17:10:53.822554
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
	hosts = Host("host1", groups=[])
	hosts.name="host1"
	hosts.subset=None
	hosts.subset_count=1
	hosts.subset_hosts=None
	hosts.subset_pattern=None
	hosts.subset_restrict_count=True
	tasks = Task("task1", groups=[])
	tasks.action="setup"
	tasks.args={}
	tasks.block=None
	tasks.changed_when=()
	tasks.collect_facts=True
	tasks.delegate_facts=False
	tasks.delegate_to="host2"
	tasks.delegate_when=()
	tasks.deps=[b64encode("task2")]
	tasks.environment={}
	

# Generated at 2022-06-11 17:10:54.724434
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module = StrategyModule()

# Generated at 2022-06-11 17:10:56.416693
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()

# Generated at 2022-06-11 17:11:04.338664
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    #
    # Test for method run
    #
    host = MagicMock()
    task = MagicMock()
    play_context = MagicMock()
    iterator = MagicMock()
    loader = MagicMock()
    strategy = StrategyModule()
    assert strategy.run(iterator, play_context) == strategy._tqm.RUN_OK
    # check that it calls get_next_task_lockstep properly
    strategy.get_next_task_lockstep = MagicMock()
    strategy.run(iterator, play_context)
    strategy.get_next_task_lockstep.assert_called_once_with(iterator._play.hosts, iterator)
    # check that it handles IOError
    strategy.get_next_task_lockstep = MagicMock(side_effect=IOError)
    assert strategy.run

# Generated at 2022-06-11 17:11:13.843094
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    def create_iterator(hosts, hosts_left):
        return MagicMock(
            _hosts=hosts,
            hosts_left=hosts_left,
            get_next_task_for_host=lambda h, p: (h, p, ),
            add_tasks=lambda h, t: None,
            mark_host_failed=lambda h: None,
            is_failed=lambda h: False,
        )
    host = MagicMock(name='host')
    task = MagicMock(name='task', action='setup', args={})
    play_context = {'cache': None}
    iterator = create_iterator([host], [host])

# Generated at 2022-06-11 17:11:25.099142
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Test StrategyModule.run()
tm = TaskResult()
tm.result = 'success'
tm.action = 'ping'
tm.host = 'localhost'
tm.add_host_result(host = 'host1', result = dict(changed = True, msg = 'some message'))
tm.add_host_result(host = 'host2', result = dict(changed = True, msg = 'some message'))
tm.add_host_result(host = 'host3', result = dict(changed = True, msg = 'some message'))
tm.add_host_result(host = 'host4', result = dict(changed = True, msg = 'some message'))

si = StrategyModule()
si.add_task_result(task_result = tm)

# Generated at 2022-06-11 17:11:34.358304
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    ansible.plugins.strategy.linear.StrategyModule test
    '''

    tqm = MagicMock()
    tqm.RUN_OK = 4

    tqm_instance = StrategyModule(tqm)

    assert isinstance(tqm_instance, StrategyModule)
    assert isinstance(tqm_instance, BaseModuleExecutor)
    assert isinstance(tqm_instance, object)
    assert tqm_instance.tqm == tqm
    assert tqm_instance.tqm_result == tqm.RUN_OK
    assert tqm_instance.blocked_hosts == {}
    assert tqm_instance.pending_results == 0
    assert tqm_instance.workers == {}
    assert tqm_instance.hosts

# Generated at 2022-06-11 17:11:42.562567
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    alias = 'localhost'
    host = Host(alias)
    host.name = '192.168.0.3'

    play_context = PlayContext()
    host_list = [host]
    play = Play().load({}, variable_manager=None, loader=None)
    iterator = TaskIterator(play, host_list)
    result = StrategyModule().run(iterator, play_context)

    assert result == 2