

# Generated at 2022-06-11 17:03:41.869072
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.plugins.strategy import StrategyModule
    from ansible.utils.display import Display
    options = Options()
    loader = DataLoader()
    passwords = dict()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    display = Display()
    strategy = StrategyModule(loader=loader, display=display)

# Generated at 2022-06-11 17:03:44.994075
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(
        tqm=None,
        connection_info=None,
        terminals=None,
        loader=None,
        variable_manager=None,
        loader_cache=None
    )
    assert strategy_module is not None


# Generated at 2022-06-11 17:03:52.033026
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy.add_strategy("test_strategy", StrategyModule)

    # we'll patch loader, inventory, variable_manager, and host_list for testing
    fake_loader = DictDataLoader({})
    fake_inventory = InventoryManager(loader=fake_loader, sources=[])
    fake_variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)
    fake_host_list = [
        Host(name="test1", port=22),
        Host(name="test2", port=22),
        Host(name="test3", port=22)
    ]

# Generated at 2022-06-11 17:03:57.310127
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test Constructor
    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=DataLoader()),
        variable_manager=VariableManager(),
        loader=DataLoader(),
        options=None,
        passwords=None,
        stdout_callback='default',
    )
    s = StrategyModule(tqm)
    assert s._tqm == tqm



# Generated at 2022-06-11 17:04:05.999553
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock
    strategy_module = StrategyModule()

    # mock the iterator
    strategy_module._iterator = mock.MagicMock()
    strategy_module._iterator.get_failed_hosts.return_value = ['localhost']

    # mock the plays
    strategy_module._tqm = mock.MagicMock()
    plays = [mock.MagicMock()]
    plays[0].get_failed_hosts.return_value = ['localhost']
    strategy_module._tqm.get_plays.return_value = plays

    # mock the stdin
    strategy_module._stdin_path = mock.MagicMock()
    strategy_module._stdin_path.read.return_value = "roles: [test]"

    # mock the loader
    strategy_module._loader = mock.MagicMock()

    #

# Generated at 2022-06-11 17:04:16.233774
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    args = dict(
        connection='smart',
        module_path=None,
        forks=5,
        become=None,
        become_method=None,
        become_user=None,
        check=False,
        diff=False,
        listhosts=None,
        subset=None,
        syntax=None
    )
    from ansible.playbook import Playbook
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Get the test playbooks
    pb_path = '../../test_data/test_playbooks/'

# Generated at 2022-06-11 17:04:17.856027
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # testing check
    assert 1==1


# Generated at 2022-06-11 17:04:18.952243
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert True

# Generated at 2022-06-11 17:04:20.603992
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  s = StrategyModule()
  s.run()


# Generated at 2022-06-11 17:04:28.835483
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule()
    assert module.__class__.__name__ == 'StrategyModule'
    assert module.get_hosts_remaining_for_loop is StrategyModule.get_hosts_remaining_for_loop
    assert module.get_hosts_left is StrategyModule.get_hosts_left
    assert module.get_next_task_lockstep is StrategyModule.get_next_task_lockstep
    assert module.add_tqm_variables is StrategyModule.add_tqm_variables
    assert module.add_tqm_variables is StrategyModule.add_tqm_variables
    assert module.pre_execute is StrategyModule.pre_execute
    assert module.run is StrategyModule.run

# Generated at 2022-06-11 17:05:20.435905
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  play_context = {
    'become_user': '',
    'become': False,
    'become_method': None,
    'become_flags': [],
    'connection': '',
    'remote_user': '',
    'no_log': False,
    'verbosity': 0,
    'module_extras': [],
    'diff': False}
  host = ''
  task = ''
  tc = StrategyModule()
  tc.add_tqm_variables({})
  result = tc.run(host, task, play_context)
  assert(result == 'RUN_FAILED')
  assert(tc.run_is_completed == True)


# Generated at 2022-06-11 17:05:21.292860
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert True == True

# Generated at 2022-06-11 17:05:28.919378
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Load test file
    data_loader = DataLoader()
    myinventory = Inventory(loader=data_loader, variable_manager=None, host_list='./tests/v2_playbook/hosts')
    variable_manager = VariableManager(loader=data_loader, inventory=myinventory)
    myplaybook = Playbook.load('./tests/v2_playbook/test_playbook.yml', variable_manager=variable_manager, loader=data_loader)
    mytasks_list = myplaybook.get_plays_by_name('Test Play one')[0].compile()

    # Create a task queue manager

# Generated at 2022-06-11 17:05:38.400395
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(
        tqm=None,
        strategy='linear',
        hosts=[Host(name='localhost')],
        variables={"ansible_connection": ["local"]},
        loader=None,
        shared_loader_obj=None,
        final_q=None,
        options=None,
        passwords=None,
        stdout_callback=None,
        run_additional_callbacks=None,
        run_tree=True,
        forks=None,
    )
    assert type(strategy_module) == StrategyModule
    assert len(strategy_module._blocked_hosts) == 0
    assert len(strategy_module._workers) == 0


# Generated at 2022-06-11 17:05:39.070171
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-11 17:05:46.388779
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        sm = StrategyModule(
            tqm=None, 
            inventory=None, 
            variable_manager=None, 
            loader=None, 
            options=None, 
            passwords=None,
        )
        assert type(sm) is StrategyModule
    except Exception as e:
        print("\033[31m%s\033[0m" % e)
        exit()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-11 17:05:53.989535
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    host_list = [Host("host1.example.org"),Host("host2.example.org")]
    task1 = Task("task1")
    task2 = Task("task2")
    task2.action = "some action"
    task3 = Task("task3")
    task3.action = "meta: some_meta_action"
    task3.register_as_first_task_for_host("host1.example.org")
    display.verbosity = 3
    strategy_module = StrategyModule(tqm=None)
    strategy_module.add_host(host=host_list[0], task=task1)
    strategy_module.add_host(host=host_list[1], task=task1)
    strategy_module.add_host(host=host_list[0], task=task2)


# Generated at 2022-06-11 17:05:55.505692
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-11 17:05:56.145234
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module = StrategyModule()


# Generated at 2022-06-11 17:06:02.026355
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test normal operation
    module = StrategyModule()
    assert module.get_name() == 'linear'

    # test with no name parameter
    module = StrategyModule(name=None)
    assert module.get_name() == 'linear'

    # test non-default name
    module = StrategyModule(name='non_default')
    assert module.get_name() == 'non_default'


# Generated at 2022-06-11 17:07:15.216882
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-11 17:07:17.716741
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a strategy module object
    strategy_module = StrategyModule()
    assert strategy_module is not None


if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-11 17:07:29.694692
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # copy of the test strategy module 'test_mod.py'
    import test_mod
    # copy of the test strategy module 'test_mod_2.py'
    import test_mod_2
    # copy of the test strategy module 'test_mod_3.py'
    import test_mod_3

    import os
    import sys
    import tempfile
    from textwrap import dedent

    from ansible.utils.display import Display
    display = Display()

    from ansible.compat.tests import unittest

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

# Generated at 2022-06-11 17:07:38.615566
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    TQM = namedtuple('TQM', ['RUN_OK', 'RUN_UNKNOWN_ERROR', 'RUN_FAILED_BREAK_PLAY'])
    tqm = TQM(0, 1, 2)
    Host = namedtuple('Host', ['name', '_is_failed'])
    host = Host('host', False)
    Hosts = namedtuple('Hosts', ['batch_size', 'is_failed'])
    hosts = Hosts(2, False)
    TaskResult = namedtuple('TaskResult', ['failed', 'is_failed', 'is_changed', 'is_skipped', 'is_unreachable', '_host', '_task'])
    task_result = TaskResult(False, False, False, False, False, host, None)

# Generated at 2022-06-11 17:07:39.425139
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   pass

# Generated at 2022-06-11 17:07:46.294969
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    state = get_state()
    state.register_plugin('for_testing', TestPlugin())
    strategyModule = StrategyModule(tqm=None, variables=None, loader=None, options=None, passwords=None)
    strategyModule._tqm = TestTqm()
    iterator = TestIterator()
    play_context = TestPlayContext()
    assert strategyModule.run(iterator, play_context) == strategyModule._tqm.RUN_UNKNOWN_ERROR


# Generated at 2022-06-11 17:07:57.703606
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Test StrategyModule constructor
    """
    # Create a new StrategyModule instance
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    play = Play().load(dict(
        name='test play',
        hosts='test_host',
        gather_facts='no',
        tasks=[dict(action='test')]
    ), variable_manager=None, loader=None)
    playbook = Playbook().load(dict(
        plays=[play]
    ), variable_manager=None, loader=None)

    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
    )
    strategy = StrategyModule(tqm, playbook)

   

# Generated at 2022-06-11 17:08:10.015370
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    m = ModuleStore(None)
    m.set(
        'action_loader',
        MockModule(),
        'action_loader'
    )
    m.set(
        'inventory',
        MockModule(),
        'inventory'
    )
    m.set(
        'play_context',
        MockModule(),
        'play_context'
    )
    m.set(
        'playbook_files',
        MockModule(),
        'playbook_files'
    )
    m.set(
        'role_cache',
        MockModule(),
        'role_cache'
    )
    m.set(
        'variable_manager',
        MockModule(),
        'variable_manager'
    )

# Generated at 2022-06-11 17:08:21.849417
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for constructor of class StrategyModule

    Checking the 'strategy_module_class' attribute of the tqm object is
    StrategyModule.
    '''

    loader_obj = DictDataLoader({
        "/path/to/playbook_dir/playbook.yml": """
        - hosts: all
          tasks:
            - name: ping
              ping:
          """,
    })
    variable_manager = VariableManager()

    playbook_path = "/path/to/playbook_dir/playbook.yml"

    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=loader_obj, sources=playbook_path),
        variable_manager=variable_manager,
        loader=loader_obj,
        passwords={},
    )

    assert tqm.strategy_module_

# Generated at 2022-06-11 17:08:23.023469
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass



# Generated at 2022-06-11 17:11:23.715913
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_list = [Host("127.0.0.1"), Host("127.0.0.2")]
    sut = StrategyModule(host_list, {'name': 'test', 'hosts': 'testhosts'}, None)
    assert isinstance(sut, StrategyModule)
    assert isinstance(sut._tqm, TaskQueueManager)
    assert isinstance(sut._variable_manager, VariableManager)
    assert isinstance(sut._loader, DataLoader)
    assert isinstance(sut._inventory, Inventory)
    assert len(sut._inventory.get_hosts()) == 2
    assert len(get_all_blocks(sut._tqm._workers)) == 0

# Generated at 2022-06-11 17:11:25.569677
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(3)
    assert strategy_module._workers == 3


# Generated at 2022-06-11 17:11:33.069977
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import __main__
    import ansible.executor
    import ansible.inventory
    import ansible.playbook.block
    import ansible.playbook.task
    import ansible.utils.vars

    # Create a fake inventory file
    inven_output = """
    [all]
    localhost ansible_ssh_pass=passwd
    [web]
    localhost ansible_ssh_pass=passwd
    """
    tmpfile = "tmpfile"
    with open(tmpfile, 'w') as f:
        f.write(inven_output)

    # Create a fake task file
    task_content = """
    - name: Test module
      command: /usr/bin/whoami
      register: result
      when: TEST_MODULE
    """

# Generated at 2022-06-11 17:11:36.183887
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module = StrategyModule(tqm=None)
    result = module.run(iterator=None, play_context=None)
    assert result is None


# Generated at 2022-06-11 17:11:48.840160
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    inventory = None
    variable_manager = VariableManager()
    loader = DataLoader()
    passwords = dict()
    options =  None
    iterator = PlayIterator(inventory, variable_manager, loader, passwords, None)
    play_context =  None
    sm = StrategyModule(loader, None, None, None, None)
    sm.run(iterator, play_context)

# This tests the following functions
# 1. run
# 2. update_active_connections
# 3. get_hosts_left
# 4. _process_pending_results
# 5. get_next_task_lockstep
# 6. _get_next_task_lockstep
# 7. _execute_meta
# 8. _wait_on_pending_results
# 9. _queue_task
# 10. _step
# 11. _take_

# Generated at 2022-06-11 17:11:51.960946
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-11 17:12:01.847201
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create inventory object and pass to var manager
    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)

    # create datastructure that represents our play, including tasks, this is basically what our YAML loader does internally.
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='ls'), register='shell_out'),
                dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
             ]
        )

    # Create play object, playbook objects use .load instead of init or new methods,
    # this will also automatically create the task objects from the info

# Generated at 2022-06-11 17:12:11.902974
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create a HostManager object
    host_manager = HostManager()
    assert host_manager

    # create a loader object
    loader_obj = DataLoader()
    assert loader_obj

    # create a variable manager object
    variable_manager_obj = VariableManager()
    assert variable_manager_obj

    # create a callback object
    callback_obj = CallbackBase()
    assert callback_obj

    # create a task queue manager object
    task_queue_manager_obj = TaskQueueManager(
        host_manager=host_manager,
        variable_manager=variable_manager_obj,
        loader=loader_obj,
        passwords={},
        stdout_callback=callback_obj,
        )
    assert task_queue_manager_obj

    # create a strategy object

# Generated at 2022-06-11 17:12:14.746617
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm, variable_manager, loader)
    assert isinstance(strategy_module, StrategyModule)


# Generated at 2022-06-11 17:12:16.194907
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module = StrategyModule()

    assert module.run() == 'success'