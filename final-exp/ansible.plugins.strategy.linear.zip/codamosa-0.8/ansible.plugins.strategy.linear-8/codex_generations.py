

# Generated at 2022-06-11 17:03:43.177270
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    mock_loader = MagicMock()
    mock_iterator = MagicMock()
    mock_play_context = MagicMock()
    mock_variable_manager = MagicMock()
    mock_blocked_hosts = MagicMock()
    mock_tqm = MagicMock()
    mock_tqm._failed_hosts = MagicMock()
    mock_hosts_tuple = MagicMock()
    mock_task_queue_item = MagicMock()
    mock_task_queue_item._role = MagicMock()
    mock_task_queue_item._metadata = MagicMock()
    mock_task_queue_item._metadata.allow_duplicates = True
    mock_task_queue_item.name = "test_name"
    mock_task_queue_item.action = "test_action"

# Generated at 2022-06-11 17:03:50.794732
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queue_manager = MagicMock()
    variable_manager = MagicMock()
    loader = MagicMock()

    strategy_module_instance = StrategyModule(task_queue_manager, variable_manager, loader)

    assert strategy_module_instance._tqm == task_queue_manager
    assert strategy_module_instance._variable_manager == variable_manager
    assert strategy_module_instance._loader == loader
    assert strategy_module_instance._step is False
    assert strategy_module_instance._last_host is None
    assert strategy_module_instance._hosts_cache is None
    assert strategy_module_instance._hosts_cache_all is None
    assert strategy_module_instance._blocked_hosts == dict()
    assert strategy_module_instance._workers_left == list()
    assert strategy_module_instance._pending

# Generated at 2022-06-11 17:03:52.154567
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("***** test_StrategyModule_run *****")
    #module = StrategyModule()
    #module.run(iterator, play_context)

# Generated at 2022-06-11 17:03:53.331768
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule()
    assert module is not None

# Generated at 2022-06-11 17:04:01.743017
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    inventory = InventoryManager(loader=None, sources='localhost,')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    loader = DataLoader()
    tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        passwords=dict(),
    )
    sm = StrategyModule(tqm=tqm)
    sm._tqm = tqm
    assert sm.tqm is not None
    assert sm._tqm is not None
    assert sm._hosts_cache is not None
    assert sm._hosts_cache_all is not None
    assert isinstance(sm._blocked_hosts, dict)
    assert isinstance(sm._workers_lock, Lock)

# Generated at 2022-06-11 17:04:13.886066
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    hosts = [Host()]
    variable_manager.set_inventory(Inventory(loader=loader, host_list=hosts))
    options = Options()
    dummy_tqm = DummyTQM(loader=loader, variable_manager=variable_manager, options=options)
    dummy_iterator = DummyIterator()

    # Test default constructor
    strategy_module = StrategyModule(tqm=dummy_tqm, strategy='TestStrategyModule', iterator=dummy_iterator, play_context=dict())
    assert strategy_module._tqm == dummy_tqm
    assert strategy_module._iterator == dummy_iterator
    assert strategy_module._step is False
    assert strategy_module.get_name() == 'TestStrategyModule'


# Generated at 2022-06-11 17:04:15.743917
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-11 17:04:17.045247
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        assert StrategyModule('test')._name == 'test'

# Generated at 2022-06-11 17:04:27.254143
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    S = StrategyModule(loader=None,var_manager=None)
    assert S._loader == None
    assert S._var_manager == None
    assert isinstance(S._shared_loader_obj, SharedLoaderObj)
    assert isinstance(S._variable_manager, VariableManager)
    # assert S._variable_manager.default_env == []
    assert S._failures_per_host == 0
    assert S._blocked_hosts == {}
    assert S._final_qd == None
    assert S._search_hosts == {}
    assert S._explicit_hosts == []
    assert S._hosts_cache == {}
    assert S._hosts_cache_all == {}
    assert S._hosts_cache_seen == {}
    assert S._hosts_cache_count == 0
    

# Generated at 2022-06-11 17:04:30.166260
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    mod = AnsibleModule(argument_spec={}, supports_check_mode=False, bypass_checks=True)
    strategy_module = StrategyModule(mod, ['localhost'])
    assert hasattr(strategy_module, 'run')
    strategy_module.run(None, None, 0)



# Generated at 2022-06-11 17:05:25.237588
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-11 17:05:27.255917
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_object = StrategyModule()
    strategy_module_object.run()



# Generated at 2022-06-11 17:05:30.047612
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module = StrategyModule()
    module.add_tqm_variables({})
    assert module.run({}, {}, False)


# Generated at 2022-06-11 17:05:32.468650
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert(strategy_module)

# Generated at 2022-06-11 17:05:34.877962
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategyModule = StrategyModule(0,0,0)
    strategyModule.run(0,0)
    assert True


# Generated at 2022-06-11 17:05:46.623715
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule()

    class Host:
        def __init__(self, name):
            self.name = name
            self.get_name = lambda: name

    hosts_left = [Host('node1')]

    class Task:
        def __init__(self, name, action, ignore_errors, parent, role, args, collections=None):
            self.name = name
            self.action = action
            self.ignore_errors = ignore_errors
            self._parent = parent
            self._role = role
            self.args = args
            self.collections = collections

    class Play:
        def __init__(self, max_fail_percentage):
            self.max_fail_percentage = max_fail_percentage

    class PlayContext:
        pass


# Generated at 2022-06-11 17:05:49.998696
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ test_StrategyModule()
    Unit test for constructor of class StrategyModule
    """
    strategy_module = StrategyModule('test')
    assert strategy_module.get_name() == 'test'



# Generated at 2022-06-11 17:05:51.226276
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(Tqm()) is not None

# Generated at 2022-06-11 17:05:54.115161
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    run_module_test(StrategyModule, 'linear', os.path.abspath(os.path.dirname(__file__)))


# Generated at 2022-06-11 17:05:59.719344
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for module: StrategyModule
    '''

    print("Testing StrategyModule")
    print("")
    print("Constructor")
    print("-----------")
    print("")
    print("This will be tested by testing the other functions which use objects of class StrategyModule.")
    print("")
    return None

# Generated at 2022-06-11 17:07:57.248571
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test case 1
    runner = Runner(connection=None, module_name=None, module_path=None, module_args=None, module_vars=None,
                    callback=None, fork=True, use_persistent_connections=False,
                    vault_password=None, output_path=None, stdout_callback=None,
                    module_compression=None, diff=False, check=False,
                    diff_peek=None, diff_match=None, diff_ignore_lines=None,
                    local_tmp=None, remote_tmp=None, environment=None)

# Generated at 2022-06-11 17:08:09.431966
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    class Object(object):
        pass
    options = Object()
    options.log_path = None
    options.private_key_file = '/home/thukral/.ssh/id_rsa'
    options.connection = 'paramiko'
    options.remote_user = 'rightscale'
    options.acl_public_key_file = '/home/thukral/.ssh/id_rsa.pub'
    options.listtags = False
    options

# Generated at 2022-06-11 17:08:21.464149
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Initializing the class objects
    filesystem_loader = C.AnsibleLoader()
    inventory = InventoryManager(loader=filesystem_loader, sources='localhost,')
    variable_manager = VariableManager(loader=filesystem_loader, inventory=inventory)
    loader = DataLoader()
    passwords = dict(vault_pass='secret')

# Generated at 2022-06-11 17:08:32.962258
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock
    options = mock.Mock()
    options.listtags = False
    options.listtasks = False
    options.listhosts = False
    options.syntax = False
    options.connection = 'ssh'
    options.module_path = None
    options.forks = 5
    options.remote_user = 'centos'
    options.private_key_file = None
    options.ssh_common_args = None
    options.ssh_extra_args = None
    options.sftp_extra_args = None
    options.scp_extra_args = None
    options.become = False
    options.become_method = 'sudo'
    options.become_user = ''
    options.verbosity = 3
    options.check = False
    options.extra_vars = []
   

# Generated at 2022-06-11 17:08:41.457964
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.module_utils.connection import Connection
    from ansible.plugins.loader import action_loader, connection_loader

    class DummyCallbacks(object):
        def handler(self, *args, **kwargs):
            pass

        def v2_playbook_on_task_start(self, *args, **kwargs):
            pass

        def v2_playbook_on_setup(self, *args, **kwargs):
            pass

        def v2_playbook_on_play_start(self, *args, **kwargs):
            pass

        def v2_playbook_on_stats(self, *args, **kwargs):
            pass

    class MockPattern(object):
        def search(self, s):
            return True

    class MockThread(object):
        def start(self):
            pass

# Generated at 2022-06-11 17:08:43.848353
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("testing method run of class Strategy")
    module = StrategyModule(None, None)

    # TODO: mock module and add test case



# Generated at 2022-06-11 17:08:45.395768
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    strategyModule = StrategyModule()

    assert strategyModule is not None


# Generated at 2022-06-11 17:08:48.869052
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    assert s is not None

import os
import sys
sys.path.insert(1, os.path.join(sys.path[0], '..'))
from ansible.plugins.strategy import StrategyBase


# Generated at 2022-06-11 17:08:51.583016
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    mod = StrategyModule()

    mod.run(iterator=None, play_context=None)
    # assert False # TODO: implement your test here


# Generated at 2022-06-11 17:08:52.714030
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    assert True == False


# Generated at 2022-06-11 17:13:03.102730
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Run Strategy Module
    try:
        tqm = TaskQueueManager()
    except Exception as e:
        print("Error calling TaskQueueManager():\n{}".format(get_exception()))

    import ansible_base
    ansible_base.variable_manager.extra_vars = {'ansible_playbook_python': sys.executable}

    try:
        strategy = StrategyModule(tqm)
    except Exception as e:
        print("Error calling StrategyModule():\n{}".format(get_exception()))

