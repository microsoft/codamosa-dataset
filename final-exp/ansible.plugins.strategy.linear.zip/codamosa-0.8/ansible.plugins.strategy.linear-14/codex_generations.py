

# Generated at 2022-06-11 17:03:37.000766
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule()
    assert strategy_module.run() == None
import os
import sys
import pytest
import shutil

from ansible_collections.ansible.community.plugins.module_utils.common.config import ConfigFactory
from ansible_collections.ansible.community.plugins.module_utils.common.config_module import ConfigModule

from ansible_collections.ansible.community.tests.unit.plugins.test_dummy import get_data_path


# Generated at 2022-06-11 17:03:37.782363
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-11 17:03:46.437988
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module_name = 'StrategyModule'
    directory = settings.get_config_value("DEFAULT", "roles_path")
    if directory is None:
        settings.set_config_value("DEFAULT", "roles_path", ".")
    loader = DataLoader()
    variable_manager = VariableManager()

    class PlayContext(object):
        pass
    play_context = PlayContext()

    class Iterator(object):
        pass
    iterator = Iterator()

    class TaskQueueManager(object):
        pass
    tqm = TaskQueueManager()
    strategy_module = StrategyModule(tqm, loader, variable_manager, None, None)
    strategy_module._blocked_hosts = []
    strategy_module._tqm = tqm
    strategy_module._pending_results = 0
    strategy

# Generated at 2022-06-11 17:03:56.165836
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import lib.ansible.plugins.strategy.linear as linear
    import lib.ansible.plugins.strategy.free as free
    import lib.ansible.plugins.strategy.debug as debug
    global_vars = {}
    bootstrapping = False
    strategy_module = StrategyModule(global_vars, bootstrapping)
    assert strategy_module._tqm is None
    assert strategy_module.get_host_list("", "") is None
    assert strategy_module.get_host_list("", "", "") is None
    assert strategy_module.get_next_task_for_host("", "") is None
    assert strategy_module.get_next_task_for_host("", "", "") is None
    assert strategy_module.get_next_task_lockstep("") is None
    assert strategy

# Generated at 2022-06-11 17:03:57.451168
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  pass

###############################################################################

# Generated at 2022-06-11 17:04:06.109933
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    it = Iterator(pattern=[Host('h1')])
    it.current = 0
    l1 = [Host('h1')]
    l2 = [Host('h2')]
    l3 = [Host('h1'),Host('h2')]
    l4 = [Host('h1'),Host('h2'),Host('h3')]
    l5 = [Host('h1'),Host('h2'),Host('h3')]
    l6 = [Host('h1'),Host('h2'),Host('h3')]
    l7 = [Host('h1'),Host('h2'),Host('h3')]
    l8 = [Host('h1'),Host('h2'),Host('h3')]

    #Test with empty pattern
    assert(it.pattern == [])
    it.next()

# Generated at 2022-06-11 17:04:16.301176
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    TASK_BLOCK_ITERATOR = Iterator('strategyModule')
    HOST = Host('host1')
    TASK = Task()
    PLAY_CONTEXT = PlayContext()
    RESULT = 0
    PLAY_CONTEXT.network_os = ''
    PLAY_CONTEXT.remote_addr = ''
    HOST.get_name = lambda: 'host1'
    HOST.get_variable = lambda x: 'host1'

    strategyModule = StrategyModule(HOST, TASK, PLAY_CONTEXT)
    strategyModule._tqm = TASK_BLOCK_ITERATOR
    strategyModule._tqm._terminated = False
    strategyModule._set_hosts_cache = lambda: None
    strategyModule.get_hosts_left = lambda iterator: [HOST]
    strategyModule._

# Generated at 2022-06-11 17:04:18.923836
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Testing StrategyModule.__init__()
    strategy_module = StrategyModule()

    # Testing StrategyModule.run()
    strategy_module = StrategyModule()
    strategy_module.run()


# Generated at 2022-06-11 17:04:28.467286
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    fake_loader = DictDataLoader({
        "test.yml": "{\n- name: task1\n- name: task2\n}\n"
    })
    
    fake_play = Play().load(
        dict(
            name = "test play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='raw', args='ls'), register='shell_out'),
                dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
            ],
        ),
        variable_manager=VariableManager(),
        loader=fake_loader
    )

    fake_iterator = TaskIterator(fake_play)
    fake_options = Options()
    fake_variable_manager = VariableManager()
    fake_tq

# Generated at 2022-06-11 17:04:34.699340
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module = StrategyModule()
    uri = 'ansible://localhost/'
    msg = 'Test all arguments'
    data = {'results': []}
    display.display(msg, color='green')

# Generated at 2022-06-11 17:05:23.383974
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None, loader=None, play_context=None, variable_manager=None, all_vars=dict())
    assert strategy_module.name == 'linear'
    assert strategy_module._tqm == None
    assert strategy_module._loader == None
    assert strategy_module._play_context == None
    assert strategy_module._variable_manager == None
    assert strategy_module._hosts_cache == {}
    assert strategy_module._hosts_cache_all == {}
    assert strategy_module._tqm_variables == {}
    assert strategy_module._blocked_hosts == {}
    assert strategy_module._workers_size == 0
    assert strategy_module._queue_name == 'strategy_module'
    assert strategy_module._all_vars == dict()
    assert strategy

# Generated at 2022-06-11 17:05:34.255274
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    fm = FixtureManager(None)
    it = fm.get('iterator_fixture')
    pc = fm.get('play_context_fixture')
    sm = StrategyModule(tqm=mock.Mock(), iterator_class=it, variable_manager=mock.Mock(), loader=mock.Mock())
    sm.get_hosts_left = mock.Mock(return_value=[fm.get('host_fixture')])
    sm.get_next_task_lockstep = mock.Mock(return_value=[fm.get('host_fixture'), fm.get('task_fixture')])
    sm.done = mock.Mock()
    sm.run(it, pc)

# Generated at 2022-06-11 17:05:35.386840
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module = StrategyModule()
    module.run()

# Generated at 2022-06-11 17:05:36.476938
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  pass


# Generated at 2022-06-11 17:05:41.924494
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    if not is_local():
        pytest.skip("only local")

    module = StrategyModule()

    if sys.version_info < (3, 0, 0):
        assert module.run(None, None) == None
    else:
        assert module.run(None, None) is None


# ------------------------------------------------------------------------------------------------
# Class ActionBase
# ------------------------------------------------------------------------------------------------


# Generated at 2022-06-11 17:05:42.697414
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 17:05:50.389292
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ansible = Ansible()
    ansible.playbook = Playbook()
    ansible.playbook.become_method = "sudo"
    ansible.inventory = Inventory()
    ansible.vars = VariableManager()

    strategy = StrategyModule(tqm=TaskQueueManager(
        inventory=ansible.inventory,
        variable_manager=ansible.vars,
        loader=ansible.loader,
        passwords=ansible.passwords,
    ))
    print(strategy._tqm._inventory)
    print(strategy._tqm._variable_manager)



# Generated at 2022-06-11 17:05:55.964539
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(
        tqm=None,
        connection_info=None,
        passwords=None
    )
    assert isinstance(module, StrategyModule)
    assert module.tqm == None
    assert module.connection_info == None
    assert module.passwords == None


# Generated at 2022-06-11 17:06:02.660366
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create new connection
    connection = ConnectionBase()

    # create new loader
    loader = DataLoader()

    # create new inventory
    inventory = InventoryManager(loader=loader, sources='localhost,')

    # create new variable manager
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # create new strategy module
    strategy_module = StrategyModule(tqm=None, connection=connection,
                                     variable_manager=variable_manager, loader=loader)

    assert strategy_module

# Generated at 2022-06-11 17:06:04.375631
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy.__class__.__name__ == 'StrategyModule'


# Generated at 2022-06-11 17:07:18.773656
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    mod = StrategyModule()
    assert mod is not None
    assert mod._tqm is not None
    assert mod._tqm.is_failed is False
    assert mod._tqm.is_skipped is False
    assert mod._tqm.is_unreachable is False
    assert mod._tqm.no_hosts is False
    assert mod._tqm.no_hosts_match is False
    assert mod._tqm.no_groups is False
    assert mod._tqm.no_groups_match is False
    mod._tqm.cleanup()
    return mod


# Generated at 2022-06-11 17:07:30.566181
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    mock_iterator = MagicMock()
    mock_play_context = MagicMock()

    from ansible.playbook.play import Play
    mock_play = Play().load(dict(name='test_playbook', hosts=['localhost', 'test_host'], gather_facts='no'), variable_manager=VariableManager(), loader=None)
    mock_iterator._play = mock_play

    mock_self = MagicMock()
    mock_self._loader = None
    mock_self._variable_manager = VariableManager()
    mock_self._hosts_cache = {'test_host': {'name': 'test_host'}, 'localhost': {'name': 'localhost'}}

# Generated at 2022-06-11 17:07:35.018583
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mock_loader = Mock()
    mock_tqm = Mock()
    mock_variable_manager = Mock()
    mod = StrategyModule(loader = mock_loader, tqm = mock_tqm, variable_manager = mock_variable_manager)
    assert isinstance(mod, StrategyModule)


# Generated at 2022-06-11 17:07:46.733805
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    import unittest.mock
    import zlib
    with unittest.mock.patch('ansible.playbook.play_context.PlayContext') as mock_play_context:
        mock_play_context.connection = unittest.mock.MagicMock()
        with unittest.mock.patch('ansible.executor.task_queue_manager.TaskQueueManager') as mock_task_queue_manager:
            mock_task_queue_manager.return_value = unittest.mock.MagicMock()
            with unittest.mock.patch('ansible.executor.strategy.StrategyModule.get_hosts_remaining') as mock_get_hosts_remaining:
                mock_get_hosts_remaining.return_value = 0

# Generated at 2022-06-11 17:07:58.059258
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    test the constructor of class StrategyModule
    '''
    # create C object
    c = C()
    # create PlayContext object
    play_context = PlayContext()
    # create AllStats object
    stats = AllStats()
    # create HostVars object
    host_vars = HostVars()
    # create Iterator object
    iterator = Iterator()
    loader = Mock()
    variable_manager = Mock()

    strategy_module = StrategyModule(c, tqm=None, host_vars=host_vars, iterator=iterator, variable_manager=variable_manager, loader=loader)
    strategy_module.get_host_bits()
    strategy_module.get_error_on_undefined_vars()

# Generated at 2022-06-11 17:07:59.695394
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
    # obj = StrategyModule()


# Generated at 2022-06-11 17:08:12.101259
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    class TestStrategyModule(StrategyModule):
        """
        Make the Class StrategyModule visible for testing
        """
        pass

    # Creating Dummy objects for testing
    class Dummy(object):
        def __init__(self, values):
            for k, v in iteritems(values):
                setattr(self, k, v)

    tqm = Dummy({'send_callback': 'send_callback'})
    loader = Dummy({'load_file': 'load_file'})
    variable_manager = Dummy({})


# Generated at 2022-06-11 17:08:18.754819
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    inventory = InventoryManager(loader=None, sources='')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    loader = DataLoader()
    passwords = dict()
    display = Display()
    Options = namedtuple('Options', ['connection', 'module_path', 'forks',
                                     'become', 'become_method', 'become_user',
                                     'check', 'diff', 'listhosts', 'listtasks',
                                     'listtags', 'syntax', 'sudo_user'])

# Generated at 2022-06-11 17:08:23.641519
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sc = StrategyModule()
    assert type(sc) == StrategyModule
    assert sc.hosts_queue
    assert sc.host_results
    assert sc.workers
    assert sc.have_tasks_for_host
    assert sc.pending_results
    assert sc.blocked_hosts


# Generated at 2022-06-11 17:08:34.408253
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    inventory = load_example_inventory()
    templar = Templar(loader=None, variables={})
    loader = DataLoader()

    ansible = Ansible()
    ansible.vars = MagicMock()

    ansible.vars.setup_cache = MagicMock()
    ansible.vars.clear_failed_hosts = MagicMock()
    ansible.vars.clear_unreachable_hosts = MagicMock()
    ansible.vars.get_failed_hosts = MagicMock()
    ansible.vars.get_unreachable_hosts = MagicMock()
    ansible._tqm.cleanup = MagicMock()
    ansible._tqm.send_callback = MagicMock()
    ansible._tqm.run_handlers = MagicMock()


# Generated at 2022-06-11 17:11:11.362113
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
	pass

# Generated at 2022-06-11 17:11:14.892274
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create a new StrategyModule
    strategy_module = StrategyModule()
    # assert that strategy_module is an instance of StrategyModule class
    assert isinstance(strategy_module, StrategyModule)



# Generated at 2022-06-11 17:11:20.163019
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    my_play = Play().load(play_source_2, variable_manager=variable_manager, loader=loader)
    iterator = PlayIterator(my_play)
    iterator._play = my_play
    strategy = StrategyModule(tqm, iterator)
    assert strategy.run(iterator, play_context) == 0


# Generated at 2022-06-11 17:11:22.061345
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None, None, None, None, None, None)
    isinstance(strategy_module, object)


# Generated at 2022-06-11 17:11:30.909050
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule(
        tqm=Tqm(
            inventory=InventoryManager(
                loader=Loader(),
                sources=['localhost | 127.0.0.1']
            ),
            variable_manager=VariableManager(),
            loader=Loader(),
        )
    )

    t1 = Task()
    t2 = Task()
    t3 = Task()

    t1.action = 'ansible_test.success'
    t2.action = 'ansible_test.success'
    t3.action = 'ansible_test.success'

    t1._hosts = ['localhost']
    t2._hosts = ['localhost']
    t3._hosts = ['localhost']

    iterator = BlockIterator([t1, t2, t3])
    play_context = PlayContext()

    assert strategy

# Generated at 2022-06-11 17:11:36.979613
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Options(object):
        connection = 'ssh'
        module_path = None
        forks = 5
        private_key_file = None
        listhosts = None
        subset = None
        become = None
        become_method = None
        become_user = None
        check = False
        diff = False

    class VariableManager(object):
        def __init__(self):
            self.extra_vars = dict()
            self.options_vars = dict()

        def get_vars(self, loader=None, play=None, host=None, task=None):
            return dict()

    class Loader(object):
        def __init__(self):
            self.basedir = None


# Generated at 2022-06-11 17:11:39.430740
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    module = StrategyModule()
    module.run()



# Generated at 2022-06-11 17:11:50.310640
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    inventory = Inventory(loader, variable_manager, 'localhost,')
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-11 17:12:00.720877
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    #
    # setup
    #
    tqm = TaskQueueManager()
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_tqm(tqm)
    variable_manager.add_playbook_basedir(os.path.dirname(__file__))

    strategy = StrategyModule(tqm, loader, variable_manager)

    strategy._set_hosts_cache(Play())
    #
    # test
    #
    # method run is not testable.
    #
    # teardown
    #
    # cleanup
    tqm.cleanup()
    shutil.rmtree(C.DEFAULT_LOCAL_TMP, True)
    



# Generated at 2022-06-11 17:12:11.367330
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    # preparation
    strategy = StrategyModule()
    strategy._tqm.RUN_OK = 0
    iterator =  HostnameIterator()
    iterator._play = Host()
    iterator._play.max_fail_percentage = 100
    iterator._play.batch_size = 5
    hosts_left = []
    for i in range(5):
        hosts_left.append(Host())
    iterator._hosts = hosts_left
    hosts_left.append(Host())
    host_tasks = []
    for i in range(5):
        host_tasks.append((hosts_left[i], Task()))
    # action
    result = strategy.run(iterator, Host())
    # verification
    assert type(result) == int
    assert result == strategy._tqm.RUN_OK