

# Generated at 2022-06-11 17:03:36.337747
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(
        tqm=None,
        connection_info=None,
        passwords=None,
        stdout_callback=None,
        run_additional_callbacks=None,
        run_tree=None,
        loader=None,
        variable_manager=None,
        loader_cache=None,
    )
    print(module)
    def test_run(self, iterator, play_context):
        pass
    module.run = test_run
    print(module.run)

# Generated at 2022-06-11 17:03:45.892382
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    host = Host('1')
    play = Play()
    play.become = True
    play.become_method = 'sudo'
    play.become_user = 'bob'
    task = Task()
    task.action = 'ping'
    hosts = [host]
    role_result = RoleResult(host=host, role=host)
    iterator = TaskIterator(tasks=task, play=play, role_result=role_result, loader=None, variable_manager=None)
    _variable_manager = VariableManager()
    strategy = StrategyModule(tqm=None, variable_manager=_variable_manager, loader=None)
    play_context = PlayContext()
    strategy.run(iterator=iterator, play_context=play_context)


# Generated at 2022-06-11 17:03:47.726935
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(task_queue_manager=None)
    assert module is not None


# Generated at 2022-06-11 17:03:48.634156
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass


# Generated at 2022-06-11 17:03:52.462728
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tm = TestModule()
    pm = PlaybookExecutor(playbooks=['playbook.yml'], inventory=inventory, variable_manager=variable_manager, loader=loader, options=options, passwords=passwords)

# Generated at 2022-06-11 17:03:54.062145
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule()
    assert isinstance(module, StrategyModule)


# Generated at 2022-06-11 17:03:55.513760
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-11 17:04:05.230716
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   # Test the StrategyModule constructor
    runner = None
    tqm = None

# Generated at 2022-06-11 17:04:08.665895
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None, "StrategyModule did not create"

# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-11 17:04:18.248663
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	it = StrategyModule()
	assert (it.__doc__ == 'This is the linear strategy, which processes hosts sequentially, one at a time.  This is the default strategy.')
	assert (it.get_hosts_left == None)
	assert (it.get_hosts_remaining(iterator) == None)
	assert (it.add_tqm_variables(variables, play) == None)
	assert (it.run(iterator, play_context) == None)
	assert (it.get_next_task_lockstep(hosts_left, iterator) == None)
	assert (it.update_active_connections(results) == None)
	assert (it.handle_setup_error(host, task, task_vars) == None)

# Generated at 2022-06-11 17:05:05.784993
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module._blocked_hosts == {}
    assert strategy_module._workers_lock.acquire() is None
    assert strategy_module._pending_results == 0
    assert strategy_module._cur_worker_hidden == 0
    assert strategy_module._queue_items is None

# Generated at 2022-06-11 17:05:14.117231
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert hasattr(strategy, '_tqm') == True
    assert hasattr(strategy, '_loader') == True
    assert hasattr(strategy, '_variable_manager') == True
    assert hasattr(strategy, '_hosts_cache') == True
    assert hasattr(strategy, '_blocked_hosts') == True
    assert hasattr(strategy, '_pending_results') == True
    assert hasattr(strategy, '_pending_results_lock') == True
    assert hasattr(strategy, '_workers') == True
    assert hasattr(strategy, '_final_q') == True
    assert hasattr(strategy, '_step') == True
    assert hasattr(strategy, '_cur_worker') == True
    assert hasattr

# Generated at 2022-06-11 17:05:21.361397
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(
            tqm=None,
            hosts=[],
            module_util=None,
            connection_info=None,
            module_vars=None,
            play_context=None,
            loader=None,
            variable_manager=None,
            shared_loader_obj=None,
            output_callback=None,
            options=None)
    assert strategy is not None

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-11 17:05:23.207071
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    my_module = StrategyModule()
    assert(my_module.run() is 0)



# Generated at 2022-06-11 17:05:25.221945
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-11 17:05:30.872395
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Options:
        def __init__(self):
            self.become = False
            self.become_method = 'sudo'
            self.become_user = 'root'
            self.check = False
            self.verbosity = 4
            self.check_implicit_dependencies = False
            self.connection = 'smart'
            self.diff = False
            self.extra_vars = []
            self.flush_cache = None
            self.force_handlers = False
            self.force_pager = False
            self.inventory = ''
            self.listhosts = None
            self.listtags = None
            self.listtasks = None
            self.module_lang = ''
            self.module_path = None
            self.new_vault_password_file = None
            self.output_

# Generated at 2022-06-11 17:05:37.006679
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy = StrategyModule(
    )
    strategy.run(iterator, play_context)

    # testing the runner backends
    runner_name = 'local'
    runner_type = 'shell'
    run_once = True

    runner = BackendLoader.get_plugin_class(
        runner_name,
        class_only=True,
        aliases={},
        run_once=run_once,
    )

    return runner



# Generated at 2022-06-11 17:05:44.027934
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    ansible_playbook_params=dict(
        playbook=dict(
            hosts=''
        ),
        inventory=dict(
            host_list=''
        )
    )
    args=dict(
        ansible_playbook_params=ansible_playbook_params
    )
    strategy_module=StrategyModule(**args)
    strategy_module.run(iterator=None,play_context=None)
    #raise Exception('raw_params error')
# Unit test end


# Generated at 2022-06-11 17:05:45.616539
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Test StrategyModule module
    '''
    pass

# Generated at 2022-06-11 17:05:53.519834
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
  from ansible.playbook.base import Base
  from ansible.playbook.play import Play
  from ansible.playbook.play_context import PlayContext
  from ansible.executor.task_queue_manager import TaskQueueManager
  from ansible.inventory.host import Host
  from ansible.inventory.group import Group
  from ansible.vars.manager import VariableManager
  from ansible.parsing.dataloader import DataLoader
  from ansible.utils.vars import combine_vars
  from ansible.inventory.inventory import Inventory
  from ansible.playbook.handler import Handler
  from ansible.plugins.callbacks import CallbackBase
  from ansible.inventory.host import Host

# Generated at 2022-06-11 17:07:13.595961
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module

# Generated at 2022-06-11 17:07:21.873142
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pl = Mock()
    pl._tasks_left = True
    run_state = Mock()
    iterator = Mock()
    iterator._play = pl
    iterator.ITERATING_TASKS = run_state
    iterator.ITERATING_RESCUE = run_state
    iterator.ITERATING_ALWAYS = run_state
    iterator.FAILED_RESCUE = run_state
    iterator.mark_host_failed = Mock()
    iterator.get_active_state = Mock()
    iterator.get_active_state.return_value = run_state
    iterator.get_next_task_for_host = Mock()
    iterator.get_next_task_for_host.return_value = (run_state, 'result')
    host = Mock()
    hosts_left = [host]

# Generated at 2022-06-11 17:07:24.532467
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    m = StrategyModule()
    assert m.run is not None
    assert m.__init__ is not None


# Generated at 2022-06-11 17:07:26.815991
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(name="test_StrategyModule")
    assert module.name == "test_StrategyModule"

# Generated at 2022-06-11 17:07:36.851065
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import json
    from unit_tests.v2_0.test_loader import LoaderModuleTestCase
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Host, Inventory
    from ansible.playbook.block import Block

    loader = DataLoader()

    variable_manager = VariableManager()
    host = Host(name="127.0.0.1")
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[host])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-11 17:07:45.316263
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    '''
    Test class StrategyModule.
    '''
    # create mock object
    tqm = MagicMock()

    # create mock object
    iterator = MagicMock()

    # create mock object
    play_context = MagicMock()

    # create instance of class StrategyModule
    strat = StrategyModule(tqm)

    # define return value of method get_hosts_left
    strat.get_hosts_left = Mock(return_value=[])

    # call method run of class StrategyModule
    strat.run(iterator, play_context)



# Generated at 2022-06-11 17:07:46.216724
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	pass # TODO


# Generated at 2022-06-11 17:07:57.623218
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("---Create class StrategyModule---")
    #Create class StrategyModule
    container = Container()
    container.add_resource(MyStrategyModule(
        tqm=TaskQueueManager(
            inventory=InventoryManager(host_list=[
                'localhost',
                '127.0.0.1',
            ]),
            variable_manager=VariableManager(),
            loader=DataLoader(),
        ),
    ))
    container.start()
    #Get object
    task_queue_manager = container.get('TaskQueueManager')
    strategy_module = container.get('MyStrategyModule')
    print("---Test function get_hosts_left---")
    #Test function get_hosts_left
    result = strategy_module.get_hosts_left(task_queue_manager._iterator)

# Generated at 2022-06-11 17:08:09.924846
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # read ansible inventory file
    inv_filepath = os.path.join(os.environ.get('HOME'), '.ansible/hosts')
    reader = InventoryReader(loader=None, variable_manager=None)
    reader._inventory = Inventory(loader=reader._loader, variable_manager=reader._variable_manager, host_list=inv_filepath)

    # get the first host
    host = reader._inventory.get_hosts('all')[0]

    # create a play

    play_name = "test_play"
    play_source = play_name  # mock play source

    play_context_var = {}
    play_context = PlayContext(play=play, options=options, passwords=None, variable_manager=self._variable_manager, loader=self._loader)

    # create an iterator for the play using a

# Generated at 2022-06-11 17:08:11.234332
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert isinstance(strategy_module, StrategyModule)

# Generated at 2022-06-11 17:11:00.450731
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule(None, None, None)
    strategy_module.run(None, None)

# Generated at 2022-06-11 17:11:02.428801
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    myTest = StrategyModule()
    myTest.setUp()
    myTest.run()
    myTest.tearDown()


# Generated at 2022-06-11 17:11:07.217266
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = Mock()
    vars = Mock()
    loader = Mock()
    strategy = StrategyModule(tqm, vars, loader)
    assert strategy._hosts_cache is None
    assert strategy._hosts_cache_all is None
    assert strategy._tqm == tqm
    assert strategy._variable_manager == vars
    assert strategy._loader == loader
    assert strategy._active_connections == {}
    assert strategy._pending_results == 0
    assert len(strategy._blocked_hosts) == 0
    assert len(strategy._hosts_patterns) == 0


# Generated at 2022-06-11 17:11:15.826574
# Unit test for method run of class StrategyModule

# Generated at 2022-06-11 17:11:19.233441
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    loader = DictDataLoader({})
    inventory = Inventory('/tmp/test_inventory')

    si = StrategyModule(loader, inventory, variable_manager=VariableManager())
    assert si is not None


# Generated at 2022-06-11 17:11:21.267902
# Unit test for method run of class StrategyModule

# Generated at 2022-06-11 17:11:30.461427
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_plugin_loader
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.loader import get_all_plugin_paths
    from ansible.plugins.loader import get_all_plugin_names
    from ansible.plugins.loader import add_directory
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins import strategy
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-11 17:11:31.560748
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy is not None

# Generated at 2022-06-11 17:11:33.599283
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Creating a StrategyModule object
    strategy_module = StrategyModule()
    assert(strategy_module)


# Generated at 2022-06-11 17:11:34.278840
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass