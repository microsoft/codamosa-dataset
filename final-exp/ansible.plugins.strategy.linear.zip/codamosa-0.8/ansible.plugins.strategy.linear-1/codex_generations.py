

# Generated at 2022-06-11 17:03:42.779125
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Fixture creation
    options = Options()
    loader = DataLoader()
    display = Display()
    variable_manager = VariableManager()

    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['localhost'])

    play_context = PlayContext({"remote_user": "root", "password": "ansible"})
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[dict(action=dict(module='shell', args='ls'), register='shell_out'),
               dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))]
    )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-11 17:03:44.357715
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    '''
    unit test for run method of class StrategyModule
    '''
    pass



# Generated at 2022-06-11 17:03:54.573326
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    a = {
        "name": "test",
        "hosts": "localhost",
        "gather_facts": "no",
        "tasks": [
            {
                "name": "test1",
                "action": {
                    "module": "debug",
                    "args": {
                        "msg": "Hello"
                    }
                }
            }
        ]
    }
    b = {
        "name": "test",
        "hosts": "localhost",
        "gather_facts": "no",
        "tasks": []
    }

# Generated at 2022-06-11 17:04:04.879834
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule(loader='loader', variable_manager='variable_manager', tqm='tqm')
    strategy_module._pending_results = 0
    strategy_module._tqm._terminated = True
    hosts_left = [{"_name": "TEST_HOST"}]
    iterator = MagicMock()
    iterator._play = 'play'
    strategy_module._variable_manager = MagicMock()
    strategy_module._variable_manager.get_vars = MagicMock(return_value='vars')
    strategy_module._set_hosts_cache = MagicMock()
    strategy_module.get_hosts_left = MagicMock(return_value=hosts_left)

# Generated at 2022-06-11 17:04:06.847787
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(isinstance(StrategyModule(), StrategyModule))


# Generated at 2022-06-11 17:04:10.942858
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(
            tqm = None,
            connection_info = None,
            loader = None,
            variable_manager = None,
            loader_cache = None)
    assert isinstance(module, object)


# Generated at 2022-06-11 17:04:23.951707
# Unit test for method run of class StrategyModule

# Generated at 2022-06-11 17:04:31.260942
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Prepare dependencies
    from ansible.errors import AnsibleError, AnsibleUndefinedVariable
    from ansible.playbook.base import Base

    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

# Generated at 2022-06-11 17:04:36.787480
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test function without arguments
    #
    # In this example, we test instantiation with no arguments. This
    # is a difficult case because it will require the StrategyModule class
    # to set a default value for each of its attributes.
    display.debug("Test 1: Instantiation without arguments")

    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=None, sources=['']),
        variable_manager=VariableManager(),
        loader=None,
        passwords=dict(),
        stdout_callback=None,
        run_additional_callbacks=True,
        run_tree=False,
        settings=None
    )

    result = StrategyModule(tqm)

    assert result._tqm == tqm
    assert result._hosts_cache == dict()

# Generated at 2022-06-11 17:04:41.203832
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a new instance of the module
    strategy_module = StrategyModule(task_queue_manager=TaskQueueManager())

    # Check that it is of the correct type
    assert(isinstance(strategy_module, StrategyModule))

    # Return the instance
    return strategy_module

# Generated at 2022-06-11 17:05:36.210098
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print("Testing StrategyModule::run()")
    opts = Options()
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager,host_list='/home/rht/rht-devops-practice/ansible/hosts')
    variable_manager.set_inventory(inventory)
    
    play_source =  dict(
            name = "Ad-hoc",
            hosts = 'dbservers',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='{{inventory_hostname}}')))
             ]
        )
    
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    
    tqm = None

# Generated at 2022-06-11 17:05:47.120862
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy = StrategyBase()
    strategy.add_tqm_variables = MagicMock()
    strategy._copy_included_file = MagicMock()
    strategy._get_next_task_lockstep = MagicMock()
    strategy._load_included_file = MagicMock()
    strategy._prepare_and_create_noop_block_from = MagicMock()
    strategy.get_hosts_left = MagicMock()
    strategy.send_callback = MagicMock()
    strategy.set_host_variable = MagicMock()
    strategy._set_hosts_cache = MagicMock()
    strategy._wait_on_pending_results = MagicMock()
    strategy._blocked_hosts = {'_status': 'ok', 'item': 'ok'}

# Generated at 2022-06-11 17:05:59.982202
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module_obj=StrategyModule(loader=None, tqm=None, variables=None)
    
    # Test when iterator.has_next_task is False
    iterator=Mock(has_next_task=False)
    play_context=Mock()

    strategy_module_obj.run(iterator,play_context)
    
    # Test when iterator.has_next_task is True
    iterator=Mock(has_next_task=True)
    play_context=Mock()

    strategy_module_obj.run(iterator,play_context)
    
    # Test for IOError and EOFError.
    iterator=Mock(has_next_task=True)
    play_context=Mock()

    strategy_module_obj.run(iterator,play_context)


# Generated at 2022-06-11 17:06:02.450241
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    iterator = ()
    play_context = ()
    obj = StrategyModule()
    assert isinstance(obj.run(iterator, play_context), int)



# Generated at 2022-06-11 17:06:13.544276
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    task1 = Task()
    task1._ds = {'module': 'shell', 'include_role': 'role'}
    task1._role = Role()
    task1._role._metadata = None
    task1._parent = Task()
    task1._parent._role = Role()
    task1._parent._role._metadata = None
    task1._parent._ds = 'hostname'
    play1 = Play()
    play1._ds = 'name'
    iterator1 = PlayIterator()
    iterator1._play = play1
    iterator1._play._ds = ['hosts']
    play_context1 = PlayContext()
    play_context1._ds = 'vars'
    inventory1 = InventoryManager()
    inventory1._ds = 'inventory'
    variable_manager1 = VariableManager()
    variable_manager1._ds

# Generated at 2022-06-11 17:06:17.011713
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy1 = StrategyModule([],[],[])
    strategy2 = StrategyModule(None, None, None)
    assert type(strategy1) == type(strategy2)
    assert isinstance(strategy1, StrategyModule)
    assert isinstance(strategy2, StrategyModule)



# Generated at 2022-06-11 17:06:20.461113
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # first two params are not used here
    moduleObj = StrategyModule(None, None,
                               manager=Manager())
    assert moduleObj.run(None, None) == 1

if __name__ == "__main__":
    test_StrategyModule_run()

# Generated at 2022-06-11 17:06:26.667584
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    playbook = Playbook.load('test/ansible/plays/test_strategy.yml', variable_manager=VariableManager(), loader=Loader())
    strategy_module = StrategyModule(tqm=TaskQueueManager())
    strategy_module._make_new_tqm(playbook)
    # assert strategy_module.get_host_list().count == 1
    # assert strategy_module._inventory.groups.count == 1

# Generated at 2022-06-11 17:06:39.257412
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    lm = StrategyModule()
    lm.add_tqm_variables({},None)
    tqm_test = TaskQueueManager(test_Mocker())
    lm._tqm = tqm_test
    lm._take_step(None)
    lm._update_global_vars()
    lm._update_tqm_vars()
    lm._wait_on_pending_results(None)
    lm.add_host_to_blocked_list("xyz")
    lm.clear_blocked_hosts()
    lm.get_hosts_left(None)
    lm.get_next_task_lockstep([],None)
    lm.run(None,None)
    lm._set_hosts_cache(None)
    l

# Generated at 2022-06-11 17:06:40.483523
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():

    pass


# Generated at 2022-06-11 17:08:09.375913
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # initial data
    results = []
    host_tasks = []
    hosts_left = [host]
    def get_hosts_left(in_iterator):
        # return hosts_left
        pass
    def _execute_meta(self, in_task, in_play_context, in_iterator, in_host):
        # return results
        pass
    def _step(self, in_task):
        # return 1
        pass
    def _take_step(self, in_task):
        # return 1
        pass
    def _process_pending_results(self, in_iterator, in_max_passes):
        # return results
        pass
    def _wait_on_pending_results(self, in_iterator):
        # return results
        pass

# Generated at 2022-06-11 17:08:17.363209
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    fixture = StrategyModule(None, None)
    # Test with argument iterator of type 'object' and play_context of type 'object'
    try:
        result = fixture.run(iterator=object(), play_context=object())
    except:
        pass
    # Test with argument iterator of type 'int' and play_context of type 'int'
    try:
        result = fixture.run(iterator=int(), play_context=int())
    except:
        pass


# Generated at 2022-06-11 17:08:25.705513
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for constructor of class StrategyModule
    '''
    my_tqm = TestTQM(1, 1, 1)
    my_playbook = TestPlaybook()
    my_play = TestPlay(dict(name="test_play", hosts="some_host"))
    my_inventory = TestInventory()
    my_variable_manager = TestVariableManager()
    my_loader = TestDataLoader()
    my_strategy = StrategyModule(my_tqm, my_playbook, my_inventory, my_variable_manager, my_loader)

    assert my_strategy._tqm == my_tqm
    assert my_strategy._playbook == my_playbook
    assert my_strategy._inventory == my_inventory
    assert my_strategy._variable_manager == my_variable_manager

# Generated at 2022-06-11 17:08:26.533922
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()

# Generated at 2022-06-11 17:08:36.200247
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Constructor test for class StrategyModule
    '''
    strategy = StrategyModule()
    assert strategy.get_host_list(None, None) == []
    assert strategy.get_next_task_lockstep([], None) == []
    assert strategy.run(None, None) == None

if __name__ == '__main__':
    # Unit test
    config = {
              'debug' : True,
              'default_vars': { 'gather_facts': True },
              'inventory': InventoryManager(['localhost'])
             }

    test_obj = StrategyModule(1, config)

    def test_get_host_list():
        '''
        Unit test for get_host_list in class StrategyModule
        '''
        hosts = test_obj.get_host_list(None, None)


# Generated at 2022-06-11 17:08:36.958141
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    pass

# Generated at 2022-06-11 17:08:38.755436
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    my_strategy_module = StrategyModule()
    my_strategy_module.run('iterator', 'play_context')

# Generated at 2022-06-11 17:08:46.056291
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    a1=dict()
    a1["fork_count"] = 10
    a1["_restart_failed"] = [3,2]
    a1["_callbacks"] = []
    a1["_failed_hosts"] = []
    a1["_unreachable_hosts"] = []
    a1["_stats"] = {}
    a1["_notified_handlers"] = []
    a1["_notified_no_hosts"] = False
    a1["_terminated"] = False
    a1["_fire_event"] = True
    a1["_terminated"] = False
    a1["_event_loop"] =0
    a1["_cleanup_done"] = False
    a1["_host_pinned"] = False
    a1["_run_cleanup"] = True


# Generated at 2022-06-11 17:08:47.798034
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None


# Generated at 2022-06-11 17:08:54.505823
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    """
    run(self, iterator, play_context)
        The linear strategy is simple - get the next task and queue
        it for all hosts, then wait for the queue to drain before
        moving on to the next task
            
    """
    aid = 'test_StrategyModule_run'
    aid_prefix = 's' + aid + '_'
    module = get_test_module(StrategyModule)
    # ToDo: no test is implemented yet


# ==================================

# Generated at 2022-06-11 17:12:16.652224
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()

    assert strategy != None

# Generated at 2022-06-11 17:12:19.204925
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_strategy = StrategyModule(variable_manager='var_manager',loader='loader')


# Generated at 2022-06-11 17:12:23.813007
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    test_StrategyModule_obj = StrategyModule(connection='ssh', check=False, become=True, become_method='sudo',
                                             become_user='root', check_mode=False, verbosity=0,
                                             inventory= '../../../../ansible/hosts', passwords={})
    assert test_StrategyModule_obj != ""


# Generated at 2022-06-11 17:12:35.886868
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    # Setup test
    tqm = TaskQueueManager(loader=None, inventory=None)
    tqm._failed_hosts = { 'failed_hosts_1': True, 'failed_hosts_2': True }
    strategy = StrategyModule(tqm=tqm)
    strategy._variable_manager = VariableManager()
    strategy._loader = DataLoader()
    strategy._hosts_cache = { 'hosts_cache_1': { 'host_1': 'host_1' } }
    strategy._hosts_cache_all = { 'hosts_cache_all_1': { 'host_1': 'host_1' } }
    strategy._pending_results = 10
    strategy._blocked_hosts = { 'blocked_hosts_1': True }
    strategy._take_step = Mock()

   

# Generated at 2022-06-11 17:12:40.845802
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategymodule_instance = StrategyModule(tqm=None, hosts=None, inventory=None, variable_manager=None, loader=None, options=None, passwords=None)
    # test __init__(tqm, hosts, inventory, variable_manager, loader,
    #               options, passwords)
    assert strategymodule_instance is not None


# Generated at 2022-06-11 17:12:43.681202
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    strategy_module = StrategyModule()
    iterator = Iterator()
    play_context = PlayContext()
    strategy_module.run(iterator, play_context)


# Generated at 2022-06-11 17:12:51.793394
# Unit test for method run of class StrategyModule
def test_StrategyModule_run():
    print ('In unit test of StrategyModule method run')
    generator = Mock()
    play_context = Mock()
    strategy_module = StrategyModule(loader=None, inventory=None, variable_manager=None, loader_class=None)
    strategy_module.get_hosts_left = Mock()
    strategy_module.get_hosts_left.return_value = [1,2,3,4]
    strategy_module._get_next_task_lockstep = Mock()
    strategy_module._get_next_task_lockstep.return_value = [(1,2),(3,4)]
    strategy_module.update_active_connections = Mock()
    strategy_module.add_tqm_variables = Mock()
    strategy_module._tqm = Mock()
    strategy_module._tqm.RUN_