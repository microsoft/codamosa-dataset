

# Generated at 2022-06-23 02:00:42.532046
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(
        '/usr/share/ansible/ansible/module_utils/facts/system/distribution.py')
    assert not get_file_content('/file/that/doesnt/exist', default=None)

# Generated at 2022-06-23 02:00:45.519068
# Unit test for function get_mount_size
def test_get_mount_size():
    import tempfile

    testdir = tempfile.mkdtemp()

    # Run test on directory that exists
    assert len(get_mount_size(testdir)) != 0

    # Run test on directory that does not exist
    assert len(get_mount_size("/noexist")) == 0

# Generated at 2022-06-23 02:00:56.964127
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/proc/sys/kernel/hostname') == ['bogus']
    assert get_file_lines('/proc/sys/kernel/hostname', line_sep=';') == ['\n', '\n']
    assert get_file_lines('/proc/sys/kernel/hostname', line_sep=';\n') == ['bogus']
    assert get_file_lines('/proc/sys/kernel/hostname', line_sep='\n') == ['bogus']
    assert get_file_lines('/proc/sys/kernel/hostname', line_sep='AXAXAXAX') == ['bogus']
    assert get_file_lines('/etc/bogus') == []

# Generated at 2022-06-23 02:01:09.123406
# Unit test for function get_mount_size
def test_get_mount_size():
    import tempfile
    import uuid
    import shutil

    testdir = tempfile.mkdtemp()
    mountpoint = '%s/%s' % (testdir, uuid.uuid4())
    os.mkdir(mountpoint)


# Generated at 2022-06-23 02:01:10.416522
# Unit test for function get_mount_size
def test_get_mount_size():
    data = get_mount_size('/')
    assert not data == {}

# Generated at 2022-06-23 02:01:18.483386
# Unit test for function get_file_lines
def test_get_file_lines():
    '''Test get_file_lines'''
    lines = get_file_lines('/etc/passwd')
    assert len(lines) > 5

    # test line_sep handling
    lines = get_file_lines('/etc/group', line_sep='\n')
    assert len(lines) > 5
    lines = get_file_lines('/etc/group', line_sep=' ')
    assert len(lines) > 5

    return lines


# Generated at 2022-06-23 02:01:28.204702
# Unit test for function get_file_content
def test_get_file_content():
    from tempfile import NamedTemporaryFile
    from shutil import rmtree
    from os import makedirs, path

    # Test for sane behavior for non-existent paths
    assert get_file_content('/foo/bar/baz/this/does/not/exist') is None

    # Test for sane behavior for un-readable files
    ntf = NamedTemporaryFile()
    ntf.write('blargh')
    ntf.close()
    assert get_file_content(ntf.name) != 'blargh'

    # Test that we can read the file back with proper permissions
    ntf = NamedTemporaryFile()
    ntf.write('blargh')
    ntf.close()

# Generated at 2022-06-23 02:01:38.251323
# Unit test for function get_file_lines
def test_get_file_lines():
    test_lines = None
    # provide a list of lines with line terminators
    test_lines = [
        '192.168.1.1\n',
        '192.168.2.1\n',
        '192.168.3.1\n',
        '192.168.4.1\n',
        '192.168.5.1\n',
    ]

    # test splitting on \n
    for line_sep in ['\n', '\r\n']:
        test_file = ''.join(test_lines).replace('\n', line_sep)
        test_lines_broken = test_file.split(line_sep)

        test_lines_fixed = get_file_lines('', strip=False, line_sep=line_sep)

        assert test_lines_

# Generated at 2022-06-23 02:01:43.724150
# Unit test for function get_file_content
def test_get_file_content():
    expected_result = 'test_data'
    f = open("/tmp/ansible_test_file", 'w')
    f.write("%s\n" % expected_result)
    f.close()

    result = get_file_content("/tmp/ansible_test_file")
    assert result == expected_result

    os.remove("/tmp/ansible_test_file")


# Generated at 2022-06-23 02:01:51.855768
# Unit test for function get_file_lines

# Generated at 2022-06-23 02:02:00.149515
# Unit test for function get_file_lines
def test_get_file_lines():
    path = "/tmp/file"
    line_sep = ["\n", "\r\n"]

    f = open(path, "w")
    f.write("hello world\n")
    f.write("this is a test\n")
    f.write("this is the end\n")
    f.close()
    for separator in line_sep:
        lines = get_file_lines(path, line_sep=separator)
        assert(len(lines) == 3)
        assert(lines[0] == "hello world")
        assert(lines[1] == "this is a test")
        assert(lines[2] == "this is the end")
    os.remove(path)



# Generated at 2022-06-23 02:02:04.378966
# Unit test for function get_file_lines
def test_get_file_lines():
    # Given
    path = '/etc/services'
    line_sep = None

    # When
    lines_result = get_file_lines(path, True, line_sep)

    # Then
    assert len(lines_result) > 0

# Generated at 2022-06-23 02:02:14.657830
# Unit test for function get_file_content
def test_get_file_content():
    current_dir = os.path.dirname(os.path.realpath(__file__))
    test_dir = os.path.join(current_dir, 'test_files')
    assert get_file_content('{0}/test_file_1.txt'.format(test_dir)) == 'This is a test\n'
    assert get_file_content('{0}/test_file_1.txt'.format(test_dir), default='error') == 'This is a test\n'
    assert get_file_content('{0}/test_file_1.txt'.format(test_dir), strip=False) == 'This is a test\n'

# Generated at 2022-06-23 02:02:26.274491
# Unit test for function get_file_lines
def test_get_file_lines():
    # Simple test
    a = get_file_lines('/proc/meminfo', line_sep='\n')
    assert len(a) >= 2

    # Performs a multi-char line_sep test
    a = get_file_lines('/proc/meminfo', line_sep='\n\n')
    assert len(a) >= 2

    # test strip
    a = get_file_lines('/proc/meminfo', line_sep='\n', strip=True)
    assert len(a) >= 2

    a = get_file_lines('/proc/meminfo', line_sep='\n', strip=False)
    assert len(a) >= 2

    # test trailing line_sep

# Generated at 2022-06-23 02:02:37.238306
# Unit test for function get_file_lines
def test_get_file_lines():

    assert get_file_lines('/etc/passwd') == get_file_content('/etc/passwd', strip=True).splitlines()
    assert get_file_lines('/etc/passwd', strip=False) == get_file_content('/etc/passwd', strip=False).splitlines()
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_content('/etc/passwd', strip=True).splitlines()
    assert get_file_lines('/etc/passwd', strip=False, line_sep='\n') == get_file_content('/etc/passwd', strip=False).splitlines()

# Generated at 2022-06-23 02:02:43.822918
# Unit test for function get_mount_size
def test_get_mount_size():
    ret = get_mount_size('/')
    assert 'size_total' in ret
    assert 'size_available' in ret
    assert 'block_size' in ret
    assert 'block_total' in ret
    assert 'block_available' in ret
    assert 'block_used' in ret
    assert 'inode_total' in ret
    assert 'inode_available' in ret
    assert 'inode_used' in ret



# Generated at 2022-06-23 02:02:54.723437
# Unit test for function get_mount_size
def test_get_mount_size():
    # call function get_mount_size with a valid path
    mount_size = get_mount_size("/")
    assert mount_size.get('size_total') > 0
    assert mount_size.get('size_available') > 0
    assert mount_size.get('block_size') > 0
    assert mount_size.get('inode_available') > 0
    assert mount_size.get('inode_used') > 0

    # call function get_mount_size with an invalid path
    mount_size = get_mount_size("/invalid_path")
    assert mount_size == {}

# Generated at 2022-06-23 02:03:00.386556
# Unit test for function get_file_content
def test_get_file_content():
    tmpfile = '/tmp/get_file_content_unittest.tmp'

    # Should return default if file does not exist
    assert get_file_content(tmpfile, 'default') == 'default'

    fd = open(tmpfile, 'w')
    fd.write('content!')
    fd.close()

    # Should return content if file does exist
    assert get_file_content(tmpfile, 'default') == 'content!'
    assert get_file_content(tmpfile, 'default', strip=False) == 'content!\n'

    # Clean up
    os.remove(tmpfile)

# Generated at 2022-06-23 02:03:04.774778
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/aliases', default='foo') == 'foo'
    assert get_file_content('/etc/aliases', strip=False) != ''
    assert get_file_content('/etc/aliases') != ''

# Generated at 2022-06-23 02:03:10.906226
# Unit test for function get_mount_size
def test_get_mount_size():
    data = get_mount_size('/')
    assert data['size_total'] > 0
    assert data['size_available'] > 0
    assert data['block_size'] > 0
    assert data['block_total'] > 0
    assert data['block_available'] > 0
    assert data['inode_total'] > 0
    assert data['inode_available'] > 0

# Generated at 2022-06-23 02:03:22.303359
# Unit test for function get_file_content
def test_get_file_content():
    '''test get_file_content'''
    from os.path import abspath

    # Create a temp file to read from
    test_file = open(abspath('/tmp/.test.txt'), 'w+')
    lines = [
        'Ansible is an automation language and tool',
        'Ansible is used to provision and configure',
        'Ansible is written in Python and uses ssh',
        '',
        'Ansible is awesome',
    ]
    test_file.write('\n'.join(lines))
    test_file.close()

    # Try to read the file
    assert get_file_content('/tmp/.test.txt') == '\n'.join(lines)

# Generated at 2022-06-23 02:03:23.699549
# Unit test for function get_file_content
def test_get_file_content():
    get_file_content('/etc/redhat-release', strip=True)

# Generated at 2022-06-23 02:03:33.054515
# Unit test for function get_file_lines

# Generated at 2022-06-23 02:03:35.644183
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', "") == ""


# Generated at 2022-06-23 02:03:40.687227
# Unit test for function get_mount_size
def test_get_mount_size():
    '''
    Test the get_mount_size function
    '''
    assert get_mount_size('/')
    assert get_mount_size('/boot')
    # mount_size will be an empty dict if the mountpoint could not
    # be found or if os.statvfs() failed
    assert not get_mount_size('unknown mountpoint')

# Generated at 2022-06-23 02:03:50.694861
# Unit test for function get_mount_size
def test_get_mount_size():
    assert get_mount_size("/") == {'size_total': 514123776,
                                   'block_available': 3922080,
                                   'block_used': 47490364,
                                   'size_available': 420914176,
                                   'inode_used': 1035281,
                                   'block_size': 1024,
                                   'inode_available': 2491894,
                                   'inode_total': 2927175}



# Generated at 2022-06-23 02:03:57.859386
# Unit test for function get_file_lines
def test_get_file_lines():
    file_content = '''
a
b
c
'''

    assert get_file_lines('tests/unit/test_utils/test_get_file_lines') == file_content.splitlines()

    assert get_file_lines('tests/unit/test_utils/test_get_file_lines', strip=False) == ['\n', 'a\n', 'b\n', 'c\n', '']

    assert get_file_lines('tests/unit/test_utils/test_get_file_lines', line_sep='\n') == file_content.splitlines()

# Generated at 2022-06-23 02:04:08.837390
# Unit test for function get_file_lines

# Generated at 2022-06-23 02:04:20.928831
# Unit test for function get_file_lines
def test_get_file_lines():
    assert ["test"] == get_file_lines('/tmp/ansible_helpers_test_file', strip=True, line_sep=None)
    assert ["test"] == get_file_lines('/tmp/ansible_helpers_test_file', strip=False, line_sep=None)
    assert [""] == get_file_lines('/tmp/ansible_helpers_empty_file', strip=True, line_sep=None)
    assert [""] == get_file_lines('/tmp/ansible_helpers_empty_file', strip=False, line_sep=None)
    assert [""] == get_file_lines('/tmp/ansible_helpers_empty_file', strip=True, line_sep='\n')

# Generated at 2022-06-23 02:04:22.941867
# Unit test for function get_mount_size
def test_get_mount_size():
    print(get_mount_size('/'))



# Generated at 2022-06-23 02:04:30.952939
# Unit test for function get_file_lines
def test_get_file_lines():
    test_file_contents = """
    hello
    ansible
    world
    """

    path = '/tmp/test_file'
    with open(path, 'w') as f:
        f.write(test_file_contents)

    expected_list = ['hello', 'ansible', 'world']
    assert get_file_lines(path) == expected_list

    # Test alternate line separators
    assert get_file_lines(path, line_sep='ansible') == ['hello', '', 'world']
    assert get_file_lines(path, line_sep='world') == ['hello', 'ansible']
    assert get_file_lines(path, line_sep='world\n') == ['hello', 'ansible']

    # If strip is disabled newlines are preserved
    assert get_file_lines

# Generated at 2022-06-23 02:04:42.282971
# Unit test for function get_file_lines
def test_get_file_lines():
    from tempfile import NamedTemporaryFile

    def makefile():
        with NamedTemporaryFile(delete=False) as f:
            for x in range(10):
                f.write("line{}\n".format(x))
            return f.name

    # normal file
    fname = makefile()
    with open(fname) as f:
        assert get_file_lines(fname) == f.read().splitlines()

    # empty line
    open(fname, 'a').close()
    with open(fname) as f:
        assert get_file_lines(fname) == f.read().splitlines()

    # empty file
    open(fname, 'w').close()
    with open(fname) as f:
        assert get_file_lines(fname) == f.read().splitlines

# Generated at 2022-06-23 02:04:49.085830
# Unit test for function get_file_content
def test_get_file_content():
    test_content = 'This is a test file content\n'
    test_file = 'test_file'

# Generated at 2022-06-23 02:04:51.640823
# Unit test for function get_file_content
def test_get_file_content():
    requested_file = "/etc/fstab"
    file_contents = get_file_content(requested_file)
    assert file_contents is not None



# Generated at 2022-06-23 02:05:02.807135
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content("./test/test_file_ut") == "test_content"
    assert get_file_content("./test/test_file_ut", default="default_value") == "test_content"
    assert get_file_content("./test/test_file_ut", default="default_value", strip=True) == "test_content"
    assert get_file_content("./test/test_file_ut", default="default_value", strip=False) == "test_content"
    assert get_file_content("./test/test_file_ut_not_exist", default="default_value") == "default_value"
    assert get_file_content("./test/test_file_ut_not_exist", default="default_value", strip=True) == "default_value"

# Generated at 2022-06-23 02:05:08.784231
# Unit test for function get_file_content
def test_get_file_content():
    path = '/etc/hosts'
    data = get_file_content(path, strip=True)
    assert data is not None
    assert len(data) != 0

    path = '/etc/hosts.noexist'
    data = get_file_content(path, default='hello')
    assert data is not None
    assert len(data) != 0
    assert data == 'hello'


# Generated at 2022-06-23 02:05:18.862011
# Unit test for function get_file_lines
def test_get_file_lines():
    test_file = '/tmp/test.txt'

    open(test_file, 'w').close()

    assert get_file_lines(test_file, line_sep=';') == []
    assert get_file_lines(test_file, line_sep='\n') == []

    lines = ['a;b;c;d', 'e;f;g', 'h;i;j;k;l', 'm;\nn;o', 'p;q;r\ns;t;u', 'v\nw;x;y;z']
    with open(test_file, 'a') as f:
        for line in lines:
            f.write(line + '\n')

    assert get_file_lines(test_file, line_sep=';') == lines

    # test that we can handle newlines

# Generated at 2022-06-23 02:05:23.353061
# Unit test for function get_file_content
def test_get_file_content():
    assert 'abc' == get_file_content('/tmp/test_file', 'def')
    assert 'abc' == get_file_content('/tmp/test_file', default='def')


# Generated at 2022-06-23 02:05:27.576279
# Unit test for function get_file_content
def test_get_file_content():
    file_has_content = "/etc/issue"
    file_no_content = "/etc/not_a_file"
    assert get_file_content(file_has_content) != None
    assert get_file_content(file_no_content) == None
    assert get_file_content(file_no_content, "default") == "default"

# Generated at 2022-06-23 02:05:32.796570
# Unit test for function get_file_content
def test_get_file_content():
    path = '/etc/group'
    group_lines = get_file_content(path)
    if group_lines is None:
        print('Could not get content from file '+path)
        print('Aborting ...')
    else:
        print('First line of file '+path+': '+group_lines[0])


# Generated at 2022-06-23 02:05:40.070224
# Unit test for function get_mount_size
def test_get_mount_size():
    # Test for edge case when mount does not exist
    assert get_mount_size('/this/mount/does/not/exist') == {}

    # Test for edge case when mount exists
    assert get_mount_size('/proc') == { 'size_total': 0, 'size_available': 0,
        'block_size': 4096, 'block_total': 0, 'block_available': 0, 'block_used': 0,
        'inode_total': 0, 'inode_available': 0, 'inode_used': 0}

# Generated at 2022-06-23 02:05:44.218388
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/resolv.conf', 'Not Found') == get_file_content('/etc/resolv.conf')



# Generated at 2022-06-23 02:05:55.239207
# Unit test for function get_file_content
def test_get_file_content():
    # Test with regular file
    assert get_file_content('/dev/null') == ''
    assert get_file_content('/dev/null', default='foo') == ''

    # Test with file that does not exists
    assert get_file_content('/dev/nullx') is None
    assert get_file_content('/dev/nullx', default='foo') == 'foo'

    # Test with directory
    assert get_file_content('/usr') is None
    assert get_file_content('/usr', default='foo') == 'foo'

    # Test with file that is not readable
    assert get_file_content('/etc/shadow') is None

    # Test with strip=False
    assert get_file_content('/etc/shadow', strip=False) is None

    # Test with strip=True
    assert get_

# Generated at 2022-06-23 02:06:05.386986
# Unit test for function get_file_lines
def test_get_file_lines():
    path = 'blablabla'
    with open(path, 'w') as f:
        f.write('a,b,c\n')
        f.write('1,2,3\n')
        f.write('a,1,2,34\n')

    assert get_file_lines(path, line_sep='\n') == ['a,b,c', '1,2,3', 'a,1,2,34']
    assert get_file_lines(path, line_sep=',') == ['a', 'b', 'c', '1', '2', '3', 'a', '1', '2', '34']

# Generated at 2022-06-23 02:06:16.679472
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines(path='/etc/passwd') != ''
    assert get_file_lines(path='/no/such/file') == []

# Generated at 2022-06-23 02:06:18.770900
# Unit test for function get_file_content
def test_get_file_content():
    path = "/etc/passwd"
    data = get_file_content(path)
    assert data is not None
    assert data != ''


# Generated at 2022-06-23 02:06:30.133250
# Unit test for function get_file_content
def test_get_file_content():
    if os.path.exists('unit_test_file_to_not_exist'):
        os.remove('unit_test_file_to_not_exist')

    assert get_file_content('unit_test_file_to_not_exist', default='test') == 'test'

    with open('unit_test_file_to_exist', 'w+') as testfile:
        testfile.write('test1\ntest2\n')

    assert get_file_content('unit_test_file_to_exist', 'test') == 'test1\ntest2\n'

    assert get_file_content('unit_test_file_to_exist', default='test') == 'test1\ntest2\n'


# Generated at 2022-06-23 02:06:33.731728
# Unit test for function get_mount_size
def test_get_mount_size():
    assert 'block_available' in get_mount_size('/')

# Generated at 2022-06-23 02:06:38.467429
# Unit test for function get_file_content
def test_get_file_content():
    foo_txt = "FOOTEXT"

    f = open("foo.txt", "w")
    f.write(foo_txt)
    f.close()

    f = open("foo.txt", "r")
    data = f.read()
    f.close()
    os.remove("foo.txt")

    assert data == foo_txt


# Generated at 2022-06-23 02:06:50.124976
# Unit test for function get_mount_size
def test_get_mount_size():
    import pytest
    # Import this here to avoid a cyclical dependency
    from lib.memory import test_files

# Generated at 2022-06-23 02:06:57.694587
# Unit test for function get_mount_size
def test_get_mount_size():
    mount_size = get_mount_size('/')
    assert 'size_total' in mount_size
    assert 'size_available' in mount_size
    assert 'block_size' in mount_size
    assert 'block_total' in mount_size
    assert 'block_available' in mount_size
    assert 'block_used' in mount_size
    assert 'inode_total' in mount_size
    assert 'inode_available' in mount_size
    assert 'inode_used' in mount_size



# Generated at 2022-06-23 02:07:05.977700
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_lines('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=True, line_sep=None) == get_file_lines('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=True) == get_file_lines('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_lines('/etc/hosts', strip=False)


# Generated at 2022-06-23 02:07:06.528888
# Unit test for function get_file_content
def test_get_file_content():
    pass

# Generated at 2022-06-23 02:07:18.040966
# Unit test for function get_file_lines
def test_get_file_lines():
    input_text = '''---
# list of users
- name: "ansible"
  shell: /bin/bash
  groups: [wheel,users]
  state: present
  ssh_key: "ssh-rsa ..."
- name: "joe"
  shell: /bin/bash
  groups: [wheel,users]
  state: present
  ssh_key: "ssh-rsa ..."
'''
    fd, file_path = tempfile.mkstemp()
    os.write(fd, input_text)
    os.close(fd)
    output_list = get_file_lines(file_path, strip=False)

    assert len(output_list) == 12
    assert output_list[0] == '---'
    assert output_list[1] == '# list of users'

# Generated at 2022-06-23 02:07:26.230538
# Unit test for function get_file_content
def test_get_file_content():

    assert get_file_content('non-existing-file', default='foo') == 'foo'

    fd, tmpfile = mkstemp()
    try:
        os.close(fd)
        with open(tmpfile, 'w') as f:
            f.write('foo\nbar\n')

        assert get_file_content(tmpfile) == 'foo\nbar'
        assert get_file_content(tmpfile, strip=False) == 'foo\nbar\n'
    finally:
        os.unlink(tmpfile)

# Generated at 2022-06-23 02:07:36.376053
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/fstab')
    assert not get_file_content('/etc/fstab', 'default')
    assert get_file_content('/etc/ssh/sshd_config', strip=False)
    assert not get_file_content('/etc/ssh/sshd_config', 'default', False)
    assert not get_file_content('/tmp/does/not/exist')
    assert get_file_content('/tmp/does/not/exist', 'default')
    assert not get_file_content('/tmp/does/not/exist', strip=False)
    assert not get_file_content('/tmp/does/not/exist', 'default', False)

# Generated at 2022-06-23 02:07:41.918148
# Unit test for function get_mount_size
def test_get_mount_size():
    assert get_mount_size('/') == {'inode_used': 1405634, 'block_total': 134217728, 'inode_available': 1161491, 'inode_total': 2652175, 'block_used': 95788278, 'size_available': 2517271945216, 'block_available': 37929450, 'block_size': 4096, 'size_total': 4995118033920}



# Generated at 2022-06-23 02:07:54.170629
# Unit test for function get_file_lines
def test_get_file_lines():
    tmpdir = os.path.realpath(os.path.join(os.path.dirname(os.path.realpath(__file__)), '../test/test_data/test_get_file_lines'))
    file_sample = os.path.join(tmpdir, 'ansible.cfg')
    ret = get_file_lines(file_sample, strip=True)
    assert len(ret) == 4

    ret = get_file_lines(file_sample, strip=True, line_sep='\n')
    assert len(ret) == 4

    ret = get_file_lines(file_sample, strip=True, line_sep='\r\n')
    assert len(ret) == 2

    ret = get_file_lines(file_sample, strip=True, line_sep='\r')


# Generated at 2022-06-23 02:08:06.531320
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/hosts') == ['127.0.0.1 localhost', '::1 localhost']
    assert get_file_lines('/etc/hosts', strip=False) == ['127.0.0.1 localhost\n', '::1 localhost\n']
    assert get_file_lines('/etc/hosts', line_sep='\1') == ['127.0.0.1 localhost', '::1 localhost']
    assert get_file_lines('/etc/hosts', line_sep='\1', strip=False) == ['127.0.0.1 localhost\n', '::1 localhost\n']

# Generated at 2022-06-23 02:08:13.689536
# Unit test for function get_mount_size
def test_get_mount_size():
    assert get_mount_size("/") == {
        'block_available': 2056963,
        'block_size': 4096,
        'block_total': 2085726,
        'block_used': 28763,
        'inode_available': 1884628,
        'inode_total': 2097152,
        'inode_used': 21224,
        'size_available': 8597524480,
        'size_total': 8796086272
    }

# Generated at 2022-06-23 02:08:19.789349
# Unit test for function get_mount_size
def test_get_mount_size():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    mountpoint = "/tmp"
    mount_size = module.get_mount_size(mountpoint)
    module.exit_json(changed=False, mount_size=mount_size)



# Generated at 2022-06-23 02:08:24.861863
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines("/etc/hosts") == ["127.0.0.1\tlocalhost"]
    assert get_file_lines("/etc/passwd", strip=False) == ["root:x:0:0:root:/root:/bin/bash"]
    assert get_file_lines("/foo/bar/baz") == []
    assert get_file_lines("/etc/passwd", line_sep=":") == ["root", "x", "0", "0", "root", "/root", "/bin/bash"]

# Generated at 2022-06-23 02:08:30.027538
# Unit test for function get_mount_size
def test_get_mount_size():
    stats = get_mount_size('/')
    assert stats['size_total'] > 0
    assert stats['size_available'] > 0
    assert stats['inode_total'] > 0
    assert stats['inode_available'] > 0
    assert stats['block_total'] > 0
    assert stats['block_available'] > 0


# Generated at 2022-06-23 02:08:39.527439
# Unit test for function get_mount_size
def test_get_mount_size():
    mount_size = get_mount_size('/')

    assert(mount_size['block_total'] != 0)
    assert(mount_size['block_used'] != 0)
    assert(mount_size['block_available'] != 0)

    assert(mount_size['size_total'] != 0)
    assert(mount_size['size_available'] != 0)

    assert(mount_size['inode_total'] != 0)
    assert(mount_size['inode_used'] != 0)
    assert(mount_size['inode_available'] != 0)

# Generated at 2022-06-23 02:08:52.280940
# Unit test for function get_file_lines
def test_get_file_lines():
    lines = get_file_lines('/proc/self/mountinfo')
    assert len(lines) > 0
    assert lines[-1] == ''

    lines = get_file_lines('/proc/self/mountinfo', strip=False)
    assert len(lines) > 0
    assert lines[-1] == '\n'

    lines = get_file_lines('/proc/self/mountinfo', line_sep='\n')
    assert len(lines) > 0
    assert lines[-1] == ''

    lines = get_file_lines('/proc/self/mountinfo', line_sep='\n', strip=False)
    assert len(lines) > 0
    assert lines[-1] == '\n'


# Generated at 2022-06-23 02:09:00.238815
# Unit test for function get_mount_size
def test_get_mount_size():
        if os.uname()[0] == 'FreeBSD':
            # FreeBSD has no /boot mountpoint
            mountpoint = '/'
        else:
            mountpoint = '/boot'
        mount_size = get_mount_size(mountpoint)
        assert type(mount_size) == dict
        assert mount_size['size_total'] > 0
        assert mount_size['size_available'] > 0
        assert mount_size['block_size'] > 0
        assert mount_size['block_total'] > 0
        assert mount_size['block_available'] < mount_size['block_total']
        assert mount_size['block_used'] > 0
        assert mount_size['inode_total'] > 0
        assert mount_size['inode_available'] > 0
        assert mount_size['inode_used'] < mount_size

# Generated at 2022-06-23 02:09:09.258398
# Unit test for function get_file_lines

# Generated at 2022-06-23 02:09:10.850570
# Unit test for function get_mount_size
def test_get_mount_size():
    assert get_mount_size('/home/travis/build/ansible/ansible/test/units/modules/system')

# Generated at 2022-06-23 02:09:18.925604
# Unit test for function get_mount_size
def test_get_mount_size():
    test_mountpoint = '/bin'
    result = get_mount_size(test_mountpoint)
    assert len(result) == 9
    assert 'size_total' in result
    assert 'size_available' in result
    assert 'block_size' in result
    assert 'block_total' in result
    assert 'block_available' in result
    assert 'block_used' in result
    assert 'inode_total' in result
    assert 'inode_available' in result
    assert 'inode_used' in result

# Generated at 2022-06-23 02:09:23.875629
# Unit test for function get_file_content
def test_get_file_content():
    test_path = '/tmp/testfile'
    expected_content = 'test content'
    f = open(test_path, 'w')
    f.write(expected_content)
    f.close()
    result = get_file_content(test_path)
    os.remove(test_path)
    assert result == expected_content



# Generated at 2022-06-23 02:09:26.994129
# Unit test for function get_mount_size
def test_get_mount_size():
    mountpoint = '/'
    assert isinstance(get_mount_size(mountpoint), dict)
    assert get_mount_size('test') == {}


# Generated at 2022-06-23 02:09:37.796180
# Unit test for function get_mount_size
def test_get_mount_size():
    for mountpoint in ['/', '/boot', '/mnt/sdb1']:
        mount_size = get_mount_size(mountpoint)
        assert type(mount_size['size_total']) == long
        assert type(mount_size['size_available']) == long
        assert type(mount_size['block_size']) == long
        assert type(mount_size['block_total']) == long
        assert type(mount_size['block_available']) == long
        assert type(mount_size['block_used']) == long
        assert type(mount_size['inode_total']) == long
        assert type(mount_size['inode_available']) == long
        assert type(mount_size['inode_used']) == long


# Generated at 2022-06-23 02:09:49.110055
# Unit test for function get_file_content
def test_get_file_content():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestGetFileContent(unittest.TestCase):
        def test_manage_file_content(self):
            with patch('os.path.exists') as os_path_exists_mock:
                with patch('os.access') as os_access_mock:
                    with patch('__builtin__.open') as open_mock:
                        os_path_exists_mock.return_value = True
                        os_access_mock.return_value = True

                        # Test when the file has the expected content
                        mock_file = open_mock.return_value.__enter__.return_value
                        mock_file.read.return_value = 'Test'

# Generated at 2022-06-23 02:10:00.368211
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(
        'tests/unit/modules/test_facter_unit.py', 'default'
    ) == get_file_content(
        'tests/unit/modules/test_facter_unit.py'
    )
    assert get_file_content(
        'doesnotexist', 'default'
    ) == 'default'
    assert get_file_content('/dev/null') == ''
    assert get_file_content('/dev/null', '') == ''
    assert get_file_content('/dev/null', 'default') == 'default'
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', strip=False)

# Generated at 2022-06-23 02:10:08.256286
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines("/file/does/not/exist") == None
    assert get_file_lines("/etc/fstab") == get_file_lines("/etc/fstab", line_sep="\n")
    assert get_file_lines("/etc/fstab", line_sep="  ") == ["", "", "", "", "", ""]
    assert get_file_lines("/proc/loadavg", line_sep=" ") == ["0.00", "0.01", "0.05", "3/435", "24686"]

# Generated at 2022-06-23 02:10:09.187091
# Unit test for function get_file_content
def test_get_file_content():
    get_file_content('/test')

# Generated at 2022-06-23 02:10:13.288716
# Unit test for function get_mount_size
def test_get_mount_size():
    # get_mount_size has no dependencies, so no mock library is used

    # Set up dummy mount point
    from tempfile import mkdtemp
    from shutil import rmtree
    mountpoint = mkdtemp()
    try:
        assert get_mount_size(mountpoint) == {}
    finally:
        rmtree(mountpoint)

# Generated at 2022-06-23 02:10:16.058971
# Unit test for function get_file_content
def test_get_file_content():
    path = os.path.join(os.path.dirname(__file__), 'unit_data/file_content')
    expected_result = '123'

    result = get_file_content(path)

    assert result == expected_result



# Generated at 2022-06-23 02:10:20.986750
# Unit test for function get_mount_size
def test_get_mount_size():
    import nose
    import nose.tools as nt
    import sys
    import os

    # Test a valid path to a directory
    mountpoint1 = '/tmp'
    result1 = get_mount_size(mountpoint1)
    nt.assert_equal(result1['size_total'], result1['size_available'] + result1['block_used'] * result1['block_size'])
    nt.assert_equal(result1['inode_total'], result1['inode_used'] + result1['inode_available'])

    # Test an invalid path
    mountpoint2 = '/tmp/invalid'
    nt.assert_false(os.path.exists(mountpoint2))
    result2 = get_mount_size(mountpoint2)
    nt.assert_equal(result2, {})

# Generated at 2022-06-23 02:10:23.824565
# Unit test for function get_mount_size
def test_get_mount_size():
    mount_size = get_mount_size('/tmp')
    assert mount_size['size_total'] > 0

# Generated at 2022-06-23 02:10:28.588645
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content("/proc/meminfo", strip=False)[0] == "M"
    assert get_file_content("/proc/meminfo", strip=True)[0] == "M"
    assert get_file_content("/proc/meminfo_non_existent", strip=True) == None

# Generated at 2022-06-23 02:10:40.370101
# Unit test for function get_file_content
def test_get_file_content():
    test_fixture = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'unit',
        'modules',
        'utils',
        'test_fixture.txt'
    )

    assert get_file_content(test_fixture, "default") == "test string"
    assert get_file_content(test_fixture, "default", False) == "test string "
    assert get_file_content(test_fixture, "default") == get_file_content(test_fixture, "default")
    assert get_file_content('/no/such/file/path', "default") == "default"
    assert get_file_content('/etc/passwd', "default") != "default"