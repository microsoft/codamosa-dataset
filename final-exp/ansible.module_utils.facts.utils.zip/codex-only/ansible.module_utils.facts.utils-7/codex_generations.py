

# Generated at 2022-06-23 02:00:42.109797
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(__file__, strip=False) == open(__file__).read()
    assert get_file_content('/no/way/jose', strip=False) is None
    assert get_file_content(__file__, default='foo', strip=False) == open(__file__).read()
    assert get_file_content('/no/way/jose', default='foo', strip=False) == 'foo'
    assert get_file_content(__file__, strip=True) == open(__file__).read().strip()
    assert get_file_content('/no/way/jose', strip=True) is None



# Generated at 2022-06-23 02:00:48.608578
# Unit test for function get_file_content
def test_get_file_content():
    # Set up test data
    path = '/etc/hosts'
    default = 'default value'
    tests = [{'data': '127.0.0.1 localhost\n::1 localhost ip6-localhost ip6-loopback\nfe00::0 ip6-localnet\n', 'strip': True},
            {'data': '127.0.0.1 localhost\n::1 localhost ip6-localhost ip6-loopback\nfe00::0 ip6-localnet\n', 'strip': False},
            {'data': '', 'strip': True},
            {'data': '', 'strip': False}]

    # Run tests
    for test in tests:
        assert get_file_content(path, default=default, strip=test['strip']) == test['data']

    # Test error


# Generated at 2022-06-23 02:00:56.135020
# Unit test for function get_file_content

# Generated at 2022-06-23 02:01:01.814554
# Unit test for function get_file_lines
def test_get_file_lines():
    lines = get_file_lines("/proc/mounts")
    assert len(lines) > 2
    lines = get_file_lines("/proc/mounts", strip=False)
    assert len(lines) > 2
    assert lines[0].endswith("\n")
    assert lines[1].endswith("\n")


# Generated at 2022-06-23 02:01:13.938484
# Unit test for function get_mount_size
def test_get_mount_size():
    mount_size = get_mount_size('/tmp')
    assert isinstance(mount_size, dict), 'get_mount_size did not return a dictionary'
    assert isinstance(mount_size['size_total'], int), 'size_total was not integer'
    assert isinstance(mount_size['size_available'], int), 'size_available was not integer'
    assert isinstance(mount_size['block_size'], int), 'block_size was not integer'
    assert isinstance(mount_size['block_total'], int), 'block_total was not integer'
    assert isinstance(mount_size['block_available'], int), 'block_available was not integer'
    assert isinstance(mount_size['block_used'], int), 'block_used was not integer'

# Generated at 2022-06-23 02:01:25.120725
# Unit test for function get_mount_size
def test_get_mount_size():
    result = get_mount_size('/var/tmp')
    assert result['size_available'] >= 0, 'Failed to determine available size in bytes'
    assert result['size_total'] >= 0, 'Failed to determine total size in bytes'
    assert result['block_available'] >= 0, 'Failed to determine available size in blocks'
    assert result['block_size'] >= 0, 'Failed to determine block size'
    assert result['block_total'] >= 0, 'Failed to determine total size in blocks'
    assert result['block_used'] >= 0, 'Failed to determine used size in blocks'
    assert result['inode_available'] >= 0, 'Failed to determine available inodes'
    assert result['inode_total'] >= 0, 'Failed to determine total inodes'

# Generated at 2022-06-23 02:01:37.899728
# Unit test for function get_file_content
def test_get_file_content():
    from ansible.module_utils import basic

    # makedirs() requires a non-empty prefix
    if not os.path.exists('/tmp/ansible-test/'):
        os.makedirs('/tmp/ansible-test/')

    # First test with an empty file, this should return the default value
    open('/tmp/ansible-test/empty_file', 'w').close()

# Generated at 2022-06-23 02:01:47.193687
# Unit test for function get_file_content
def test_get_file_content():
    # Test file with content
    assert (get_file_content(os.path.join(os.path.dirname(__file__), 'test_get_file_content_file')) == "test_file_content")
    # Test file without content
    assert (get_file_content(os.path.join(os.path.dirname(__file__), 'test_get_file_content_file_no_content')) == "")
    # Test file nonexisting
    assert (get_file_content(os.path.join(os.path.dirname(__file__), 'test_get_file_content_file_non_existing')) == None)
    # Test file with content, default value

# Generated at 2022-06-23 02:01:53.699138
# Unit test for function get_mount_size
def test_get_mount_size():

    # Create temporary file to be used for mount
    import tempfile
    tmpfile = tempfile.NamedTemporaryFile()
    os.system('mount -t tmpfs none ' + str(tmpfile.name))

    # Get mount_size
    assert len(get_mount_size(str(tmpfile.name))) == 10

    # Unmount
    os.system('umount ' + str(tmpfile.name))

# Generated at 2022-06-23 02:01:56.685980
# Unit test for function get_file_content
def test_get_file_content():
    content = get_file_content(__file__, default="")
    assert type(content) is str
    assert len(content) > 0

# Generated at 2022-06-23 02:02:10.766849
# Unit test for function get_file_content
def test_get_file_content():

    # Test which checks that get_file_content function works properly
    def check(file_content, expected):
        assert get_file_content(file_content) == expected

    check("/dev/null", None)
    check("/dev/random", None)
    check("/dev/urandom", None)
    check("/dev/zero", None)
    check("/etc/passwd", "root:x:0:0:root:/root:/bin/bash")
    check("/etc/group", "root:x:0:")

# Generated at 2022-06-23 02:02:17.294367
# Unit test for function get_file_lines
def test_get_file_lines():
    expected_result_default_sep = ['This is a test', 'This is another test']
    expected_result_sep_n = ['This is a test\n', 'This is another test\n']
    expected_result_sep_rn = ['This is a test\r\n', 'This is another test\r\n']
    expected_result_sep_r = ['This is a test\r', 'This is another test\r']

    assert expected_result_default_sep == get_file_lines('test/test_file')
    assert expected_result_sep_n == get_file_lines('test/test_file', line_sep='\n')
    assert expected_result_sep_rn == get_file_lines('test/test_file', line_sep='\r\n')
   

# Generated at 2022-06-23 02:02:28.167875
# Unit test for function get_file_lines
def test_get_file_lines():
    from tempfile import mkstemp

    handle, path = mkstemp()
    with open(path, 'w') as f:
        f.write('\n'.join(map(str, range(3))))

    lines = get_file_lines(path)
    assert len(lines) == 3
    assert lines == [str(x) for x in range(3)]

    lines = get_file_lines(path, line_sep='\n')
    assert len(lines) == 3
    assert lines == [str(x) for x in range(3)]

    lines = get_file_lines(path, line_sep=' ')
    assert len(lines) == 1
    assert lines[0] == '\n'.join(map(str, range(3)))


# Generated at 2022-06-23 02:02:35.173625
# Unit test for function get_mount_size
def test_get_mount_size():
    test_mount = os.path.abspath(os.sep)
    expected_result = {'inode_used': 0, 'size_available': 5120, 'block_available': 5, 'block_used': 0, 'size_total': 10240, 'block_size': 1024, 'inode_total': 0, 'inode_available': 0, 'block_total': 5}

    result = get_mount_size(test_mount)

    assert expected_result == result



# Generated at 2022-06-23 02:02:45.366346
# Unit test for function get_file_lines
def test_get_file_lines():
    # Create a file and write data on it
    f = open('testfile_modified', 'w')
    f.write('  line1\nline2\nline3\n')
    f.close()

    # Run get_file_lines on file 'testfile_modified'
    data = get_file_lines('testfile_modified')
    assert data == ['line1', 'line2', 'line3']

    # Run get_file_lines on file 'testfile_modified' with strip=False
    data = get_file_lines('testfile_modified', strip=False)
    assert data == ['  line1', 'line2', 'line3']

    # Run get_file_lines on file 'testfile_modified' with strip=False and line_sep='\n'

# Generated at 2022-06-23 02:02:57.441123
# Unit test for function get_file_content
def test_get_file_content():
    test_path = '/tmp/file.content'
    test_path_raw = "/tmp/file.content\n"
    test_path_strip = 'file content\n'
    test_default = 'default'
    result_raw = get_file_content(test_path, default=test_default)
    result_strip = get_file_content(test_path, default=test_default, strip=False)
    if result_raw == result_strip:
        print('[ERROR] The raw content should be different from the stripped content!')
    if result_raw != test_path_raw:
        print('[ERROR] The content of the file is corrupted!')

    result_strip = get_file_content(test_path, default=test_default, strip=True)

# Generated at 2022-06-23 02:03:03.055070
# Unit test for function get_file_content
def test_get_file_content():
    # Test 1
    test1_test_file_contents = "test"
    test1_test_file = open("/tmp/test_file.txt", "w")
    test1_test_file.write(test1_test_file_contents)
    test1_test_file.close()
    test1_result = get_file_content("/tmp/test_file.txt")
    assert test1_result == test1_test_file_contents

    # Test 2
    test2_result = get_file_content("/tmp/test_file.txt", "nope")
    assert test2_result == test1_test_file_contents

    # Test 3
    test3_result = get_file_content("/tmp/test_file.txt", "nope", False)
    assert test3

# Generated at 2022-06-23 02:03:10.555989
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(path=os.path.abspath(__file__), default='default', strip=True)
    assert get_file_content(path=os.path.abspath(__file__), default='default', strip=False)
    assert get_file_content(path=os.path.abspath(__file__), default='default')
    assert get_file_content(path=os.path.abspath(__file__))



# Generated at 2022-06-23 02:03:21.218730
# Unit test for function get_file_lines
def test_get_file_lines():
    lines = get_file_lines("/proc/net/arp", line_sep="\n")
    assert len(lines) == 3
    assert lines[0] == "IP address       HW type     Flags       HW address            Mask     Device"
    lines = get_file_lines("/proc/net/arp", line_sep=None)
    assert len(lines) == 3
    assert lines[0] == "IP address       HW type     Flags       HW address            Mask     Device"
    lines = get_file_lines("/proc/net/arp", line_sep="  ")
    assert len(lines) == 3
    assert lines[0] == "IP addressHW typeFlagsHW addressMaskDevice"
    lines = get_file_lines("/proc/net/arp")
    assert len(lines) == 3
    assert lines

# Generated at 2022-06-23 02:03:30.657783
# Unit test for function get_file_lines
def test_get_file_lines():
    from ansible.module_utils.basic import AnsibleModule

    test_file_path = os.path.join(os.path.dirname(__file__), 'get_file_lines_test.txt')
    expected_value = ['Test1', 'Test2']

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )

    result = get_file_lines(test_file_path)
    os.remove(test_file_path)
    module.exit_json(changed=True, result=result)


# Generated at 2022-06-23 02:03:40.285600
# Unit test for function get_file_content
def test_get_file_content():
    # Get a temporary file
    import tempfile
    temp_file = tempfile.NamedTemporaryFile().name

    # Create content
    content = "abcd\n"

    # Write content to temp file
    with open(temp_file, "w") as f:
        f.write(content)

    # Read file and compare
    assert(get_file_content(temp_file, default="") == content)

    # Delete file
    os.remove(temp_file)

# Generated at 2022-06-23 02:03:44.365378
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/group', 'default') != 'default'
    assert get_file_content('/etc/foo_bar', 'default') == 'default'

    assert get_file_content('/etc/group', 'default') != 'default'
    assert get_file_content('/etc/foo_bar', 'default') == 'default'

# Generated at 2022-06-23 02:03:58.338663
# Unit test for function get_file_lines
def test_get_file_lines():
    assert [] == get_file_lines('/tmp/does_not_exist'), 'no file returns empty list'
    assert ['0'] == get_file_lines('/proc/0/status', strip=False), 'file with no newlines'

    testfile = '/tmp/testfile'
    with open(testfile, 'wb') as f:
        f.write(b'line1\nline2\nline3\n')
    assert ['line1', 'line2', 'line3'] == get_file_lines(testfile), 'normal operation'
    assert ['line1', 'line2', 'line3'] == get_file_lines(testfile, line_sep='\n'), \
        'can specify line_sep'

# Generated at 2022-06-23 02:04:00.807684
# Unit test for function get_mount_size
def test_get_mount_size():
    mount_size = get_mount_size('/tmp')
    assert mount_size['size_total'] > 0
    assert mount_size['size_available'] > 0
    assert mount_size['block_total'] > 0
    assert mount_size['block_available'] > 0
    assert mount_size['inode_total'] > 0
    assert mount_size['inode_available'] > 0



# Generated at 2022-06-23 02:04:06.627808
# Unit test for function get_file_content
def test_get_file_content():
    if 'TESTS' not in os.environ:
        return

    # Create a temp file for testing
    testfile_path = '/tmp/test_get_file_content'
    data = "This is a test file"
    try:
        testfile = open(testfile_path, 'w')
        testfile.write(data)
    except IOError:
        print("Unable to write to temp file for unit test")
        return

    # Test regular content retrieval
    ret = get_file_content(testfile_path)
    if ret != data:
        print("Expected: %s, got: %s" % (data, ret))
    else:
        print("OK")

    # Test file with extra whitespace
    ret = get_file_content(testfile_path, strip=True)

# Generated at 2022-06-23 02:04:18.663156
# Unit test for function get_mount_size
def test_get_mount_size():
    # Test the function, get_mount_size, returns the expected results for
    # the given mountpoint.

    # get_mount_size has a dictionary, mount_size, as a return value.
    # mount_size contains size_total, size_available, etc. as key to
    # reflect the results of statvfs.

    # Test data.
    test_mountpoint = "/tmp"
    test_mount_size = {
        'size_total': 5160960,
        'size_available': 3509280,
        'block_size': 4096,
        'block_total': 1280,
        'block_available': 864,
        'block_used': 416,
        'inode_total': 1440,
        'inode_available': 880,
        'inode_used': 560
    }

    assert get

# Generated at 2022-06-23 02:04:30.194868
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/dev/null') == []
    assert get_file_lines('/dev/null', line_sep=',') == ['']
    assert get_file_lines('/dev/null', line_sep='foo') == ['']
    assert get_file_lines('/dev/null', line_sep='foobar') == ['']
    assert get_file_lines('/dev/null', line_sep='  ') == ['']
    assert get_file_lines('/dev/null', line_sep='\t ') == ['']
    assert get_file_lines('/dev/null', line_sep='\n') == []
    assert get_file_lines('/dev/null', line_sep='foobar') == ['']
    assert get_

# Generated at 2022-06-23 02:04:33.788977
# Unit test for function get_file_content
def test_get_file_content():
    '''Unit test for function get_file_content'''
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')

# Generated at 2022-06-23 02:04:44.158332
# Unit test for function get_file_lines
def test_get_file_lines():
    import tempfile
    import shutil

    # Create test directory
    test_path = tempfile.mkdtemp()

    # Create test file
    file_path = os.path.join(test_path, 'test-file')
    with open(file_path, 'w+') as f:
        f.write('Test-Line-1\nTest-Line-2\nTest-Line-3')

    with open(file_path, 'r') as f:
        # Verify that lines are separated correctly
        assert get_file_lines(file_path, line_sep='\n') == ['Test-Line-1', 'Test-Line-2', 'Test-Line-3'], 'Lines not separated correctly'

        # Verify that line_sep is optional

# Generated at 2022-06-23 02:04:53.943999
# Unit test for function get_file_lines
def test_get_file_lines():
    filename = '/tmp/ansible_expect_file_lines'
    lines = ['a\n', 'b\n', 'c\n', 'd\n', 'e\n', 'f\n']
    expected = ['a', 'b', 'c', 'd', 'e', 'f']
    f = open(filename, 'w')
    for x in lines:
        f.write(x)
    f.close()
    f = open(filename, 'r')
    result = get_file_lines(f.name)
    assert result == expected
    os.unlink(filename)


# Generated at 2022-06-23 02:05:02.303267
# Unit test for function get_mount_size
def test_get_mount_size():
    mount_size = get_mount_size('/')
    assert mount_size is not None
    assert mount_size['size_total'] > 0
    assert mount_size['size_available'] > 0
    assert mount_size['block_size'] > 0
    assert mount_size['block_total'] > 0
    assert mount_size['block_available'] > 0
    assert mount_size['block_used'] > 0
    assert mount_size['inode_total'] > 0
    assert mount_size['inode_available'] > 0
    assert mount_size['inode_used'] > 0



# Generated at 2022-06-23 02:05:12.718615
# Unit test for function get_file_content
def test_get_file_content():
    from shutil import copyfile
    import random

    tmp_dir = "/tmp/file_tools"
    if not os.path.exists(tmp_dir):
        os.makedirs(tmp_dir)

    file_name = "file_tools.txt"
    file_path = os.path.join(tmp_dir, file_name)


# Generated at 2022-06-23 02:05:16.872787
# Unit test for function get_file_lines
def test_get_file_lines():
    if get_file_lines("/some/non/existing/path") is None:
        print("Failed to get file_lines")
    else:
        print("Successfully get file_lines")


# Generated at 2022-06-23 02:05:27.955634
# Unit test for function get_mount_size
def test_get_mount_size():
    # On Linux uses /proc/mounts to get a list of mounts.  On FreeBSD, /etc/fstab is used
    # if no /proc/mounts, but it does not have block and inode stats.
    #
    # So instead we get a list of mounts that are present and can be used to loop
    # on in order to generate test data
    mounts = []
    # Linux
    if os.path.exists('/proc/mounts'):
        with open('/proc/mounts') as mounts_file:
            for line in mounts_file.readlines():
                if line.startswith('/dev/'):
                    mounts.append(line.split(' ')[1])
    # FreeBSD

# Generated at 2022-06-23 02:05:42.327373
# Unit test for function get_file_content
def test_get_file_content():
    # Create test file
    TESTFILE = "test_file"
    open(TESTFILE, "w").close()

    assert None == get_file_content(TESTFILE, default=None, strip=True)
    assert "default" == get_file_content(TESTFILE, default="default", strip=True)
    assert "default" == get_file_content(TESTFILE, default="default", strip=False)

    # Write some data to file
    test_data = '1234567'.encode('utf-8')
    with open(TESTFILE, "wb") as f:
        f.write(test_data)

    # Test with strip = True
    assert '1234567' == get_file_content(TESTFILE, default="default", strip=True)
    # Test with strip = False

# Generated at 2022-06-23 02:05:46.145072
# Unit test for function get_file_content
def test_get_file_content():
    assert(get_file_content('test_file') == 'a')
    assert(get_file_content('test_file', default='b') == 'a')
    assert(get_file_content('test_file', strip=False) == 'a\n')
    assert(get_file_content('test_file2') == 'ab')
    assert(get_file_content('test_file2', strip=False) == 'ab\n')
    assert(get_file_content('test_file3', default='b') == 'b')
    assert(get_file_content('/tmp/test_file3', default='b') == 'b')
    assert(get_file_content('/tmp/test_file3') == None)
    assert(get_file_content('/tmp/test_file4') == None)

# Generated at 2022-06-23 02:05:55.392951
# Unit test for function get_mount_size
def test_get_mount_size():
    # Set up the test
    # Use a temp directory so we don't conflict with anything existing
    import tempfile
    import shutil
    import stat
    tmp_dir = tempfile.mkdtemp()
    test_file = tmp_dir + "/test_file"
    file_size = 100
    open(test_file, 'w').close()
    os.chmod(tmp_dir, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)
    os.chmod(test_file, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)

    # Run the test
    mount_size = get_mount_size(tmp_dir)

    # Tear down the test

# Generated at 2022-06-23 02:05:58.498233
# Unit test for function get_file_content
def test_get_file_content():
    content_expected = 'This is a test!'
    content_returned = get_file_content('/tmp/testfile')
    assert content_expected == content_returned


# Generated at 2022-06-23 02:06:07.066175
# Unit test for function get_file_content
def test_get_file_content():
    ''' Test for get_file_content '''

    test_path = '~/.ansible/test/unit_test_file'
    test_path = os.path.expanduser(test_path)
    test_path_dir = os.path.dirname(test_path)

    if not os.path.isdir(test_path_dir):
        os.makedirs(test_path_dir, 0o700)

    with open(test_path, 'w') as test_file:
        test_file.write('testing')
        test_file.close()

    test_out = get_file_content(test_path, None)
    assert test_out == 'testing'

    test_out = get_file_content(test_path, 'default_value', False)

# Generated at 2022-06-23 02:06:12.528415
# Unit test for function get_file_content
def test_get_file_content():
    file_path = '/tmp/ansible_test_file'
    test_string = 'This is a test'

    # Write test string to temp file
    test_string_file = open(file_path, 'w')
    test_string_file.write(test_string)
    test_string_file.close()

    # Test file exists
    assert os.path.exists(file_path)

    # Verify get_file_content returns the test string
    assert get_file_content(file_path) == test_string
    assert get_file_content(file_path, strip=False) == (test_string + '\n')

    # Delete the test file
    os.unlink(file_path)

    # Verify no file specified returns ''
    assert get_file_content('') == ''
    assert get_

# Generated at 2022-06-23 02:06:20.109398
# Unit test for function get_mount_size
def test_get_mount_size():
    mount_size = get_mount_size('/')

    print('Disk size: {0}'.format(mount_size['size_total']))
    print('Disk available: {0}'.format(mount_size['size_available']))
    print('Block size: {0}'.format(mount_size['block_size']))
    print('Block total: {0}'.format(mount_size['block_total']))
    print('Block available: {0}'.format(mount_size['block_available']))
    print('Block used: {0}'.format(mount_size['block_used']))
    print('Inode total: {0}'.format(mount_size['inode_total']))
    print('Inode available: {0}'.format(mount_size['inode_available']))

# Generated at 2022-06-23 02:06:30.275147
# Unit test for function get_file_content
def test_get_file_content():
    # Get files
    import os
    import tempfile
    tempdir = tempfile.mkdtemp()
    
    file1_path = os.path.join(tempdir, "test_file1")
    file1_content = "My test string"
    with open(file1_path,'w') as f:
        f.write(file1_content)
        
    file2_path = os.path.join(tempdir, "test_file2")
    file2_content = "My test string 2"
    with open(file2_path,'w') as f:
        f.write(file2_content)
        
    # Test script
    print("Test get_file_content")
    print("Test default value")

# Generated at 2022-06-23 02:06:36.241732
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd')
    assert not get_file_lines('/dev/notexists')
    lst = get_file_lines('/etc/passwd', line_sep=':')
    assert len(lst) > 1

# Generated at 2022-06-23 02:06:39.617698
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/dev/null', default='error') == 'error'
    assert get_file_content('/etc/hosts', default='error') == 'error'
    assert get_file_content('/etc/hosts', default='error') != 'error'

# Generated at 2022-06-23 02:06:41.524183
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/hosts', False) == ['#', '# /etc/hosts: static lookup table for host names', '#']

# Generated at 2022-06-23 02:06:53.595621
# Unit test for function get_mount_size
def test_get_mount_size():
    mount_size = get_mount_size('/')
    assert 'size_total' in mount_size
    assert 'size_available' in mount_size
    assert 'block_size' in mount_size
    assert 'block_total' in mount_size
    assert 'block_available' in mount_size
    assert 'block_used' in mount_size
    assert 'inode_total' in mount_size
    assert 'inode_available' in mount_size
    assert 'inode_used' in mount_size

    assert isinstance(mount_size['size_total'], int)
    assert isinstance(mount_size['size_available'], int)
    assert isinstance(mount_size['block_size'], int)
    assert isinstance(mount_size['block_total'], int)

# Generated at 2022-06-23 02:06:56.779354
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hostname', strip=False) == get_file_content('/etc/hostname', default='', strip=False)


# Generated at 2022-06-23 02:07:08.757169
# Unit test for function get_file_lines
def test_get_file_lines():
    import tempfile

    f = tempfile.NamedTemporaryFile()

# Generated at 2022-06-23 02:07:16.841999
# Unit test for function get_mount_size
def test_get_mount_size():
    mount_size = get_mount_size('/')
    assert isinstance(mount_size, dict)
    assert 'size_total' in mount_size
    assert 'size_available' in mount_size
    assert 'block_size' in mount_size
    assert 'block_total' in mount_size
    assert 'block_available' in mount_size
    assert 'block_used' in mount_size
    assert 'inode_total' in mount_size
    assert 'inode_available' in mount_size
    assert 'inode_used' in mount_size
    # We can't know the values of the dictionary

# Generated at 2022-06-23 02:07:24.233174
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('./testdata/file_utils/content1') == 'content\n'
    assert get_file_content('./testdata/file_utils/content1', strip=False) == 'content\n'
    assert get_file_content('./testdata/file_utils/content1', default='missing') == 'content'
    assert get_file_content('./testdata/file_utils/missing', default='missing') == 'missing'


# Generated at 2022-06-23 02:07:36.004337
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/dev/null', default='DEFAULT') == 'DEFAULT'
    assert get_file_content('/dev/null', default='DEFAULT', strip=False) == 'DEFAULT'
    assert get_file_content('/dev/null', default='DEFAULT', strip=True) == 'DEFAULT'
    assert get_file_content('/dev/zero', default='DEFAULT') == 'DEFAULT'
    assert get_file_content('/dev/zero', default='DEFAULT', strip=False) == 'DEFAULT'
    assert get_file_content('/dev/zero', default='DEFAULT', strip=True) == 'DEFAULT'
    assert get_file_content('/dev/zero', default=None, strip=False) is None