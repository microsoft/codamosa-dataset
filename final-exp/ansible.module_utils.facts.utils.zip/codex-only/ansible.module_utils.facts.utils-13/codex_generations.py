

# Generated at 2022-06-23 02:00:47.460818
# Unit test for function get_file_content
def test_get_file_content():
    import os
    import random
    import shutil
    import tempfile
    test_dir = tempfile.mkdtemp()
    test_file_path = os.path.join(test_dir, "testing")
    cnt = random.randint(1000, 2000)
    val_list = []
    for i in range(0, cnt):
        val = random.randint(0, 999999999)
        val_list.append(val)

    with open(test_file_path, "w") as test_file:
        for val in val_list:
            test_file.write("{}\n".format(val))
        test_file.close()

    file_content = get_file_content(test_file_path, strip=False)
    if file_content:
        file_content = file_content

# Generated at 2022-06-23 02:00:57.969759
# Unit test for function get_file_lines
def test_get_file_lines():
    line_sep = get_file_lines('/proc/1/cmdline', line_sep='\x00')
    assert line_sep == ['/sbin/init', 'cgroup_disable=memory', 'swapaccount=1', 'ro']
    # Note: The following line depends on python version and built-in module
    assert len(get_file_lines('/proc/1/environ', line_sep='\x00')) > 0
    assert len(get_file_lines('/proc/1/cmdline')) == 0
    assert len(get_file_lines('/')) == 0
    assert len(get_file_lines('/etc/profile')) > 0

# Generated at 2022-06-23 02:01:10.141610
# Unit test for function get_file_lines
def test_get_file_lines():

    # Test a file with two lines of text, separated by one or more EOL chars.
    os.chdir(os.path.dirname(__file__))
    line_sep = '\n'
    path = os.path.join(os.getcwd(), 'test_lines')
    lines1 = get_file_lines(path, line_sep=line_sep)
    assert len(lines1) == 2 and lines1[0].strip() == 'line1' and lines1[1].strip() == 'line2'

    # Test a file with two lines of text, separated by one or more EOL chars.
    line_sep = '\n'
    path = os.path.join(os.getcwd(), 'test_lines')

# Generated at 2022-06-23 02:01:12.287155
# Unit test for function get_file_content
def test_get_file_content():
    data = get_file_content(__file__)
    assert data and len(data) > 0

# Generated at 2022-06-23 02:01:24.340601
# Unit test for function get_mount_size
def test_get_mount_size():
    ret = get_mount_size('/home')
    assert 'block_available' in ret
    assert 'block_size' in ret
    assert 'block_total' in ret
    assert 'block_used' in ret
    assert 'inode_available' in ret
    assert 'inode_total' in ret
    assert 'inode_used' in ret
    assert 'size_total' in ret
    assert 'size_available' in ret
    assert ret['block_size'] > 0
    assert ret['inode_total'] > 0
    ret = get_mount_size('/noexists')
    assert ret == {}

# Generated at 2022-06-23 02:01:36.567191
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/dev/null') == []
    assert get_file_lines('/dev/zero') == ['\0' * 63]
    assert get_file_lines('/dev/zero', line_sep='\0') == ['\0'] * 63
    assert get_file_lines('/dev/zero', line_sep='\0', strip=False) == ['\0' * 63]
    assert get_file_lines('/dev/zero', line_sep='\0') == ['\0'] * 63
    assert get_file_lines('/dev/zero', line_sep='\0', strip=False) == ['\0' * 63]

# Generated at 2022-06-23 02:01:58.514636
# Unit test for function get_mount_size
def test_get_mount_size():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(),
    )

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()