

# Generated at 2022-06-23 02:00:46.181233
# Unit test for function get_file_lines
def test_get_file_lines():
    test_file_content = 'a\nb\nc\nd\ne\nf\ng\n'
    test_file = open('/tmp/ansible_test_get_file_lines', 'w')
    test_file.write(test_file_content)
    test_file.close()
    test_output = get_file_lines('/tmp/ansible_test_get_file_lines')
    os.remove('/tmp/ansible_test_get_file_lines')
    assert(test_output == ['a', 'b', 'c', 'd', 'e', 'f', 'g'])

# Generated at 2022-06-23 02:00:57.788147
# Unit test for function get_mount_size
def test_get_mount_size():
    try:
        os.statvfs('/')
    except OSError:
        return

    mount_size = get_mount_size('/')

    # Verify that all keys are in the dictionary
    assert(sorted(mount_size.keys()) == ['block_available', 'block_size', 'block_total', 'block_used',
                                         'inode_available', 'inode_total', 'inode_used',
                                         'size_available', 'size_total'])

    # Verify that all values are integers
    for value in mount_size.values():
        assert(type(value) == int)

    # Verify the sanity of the values
    assert(mount_size['size_available'] <= mount_size['size_total'])

# Generated at 2022-06-23 02:01:03.805656
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/dev/zero') == ''
    assert get_file_content('/dev/zero', strip=False) == ''
    assert get_file_content('/dev/zero', default='a') == 'a'
    assert get_file_content('/dev/zero', strip=False, default='b') == 'b'

# Generated at 2022-06-23 02:01:23.540121
# Unit test for function get_file_lines
def test_get_file_lines():
    test_file = "/tmp/test_file"
    test_file_content = "line1_sep_line2_sep_line3\n"
    test_file_list = ["line1", "line2", "line3"]
    test_file_list_2 = ["line1_sep_line2_sep_line3"]
    test_file_list_3 = ["line1_sep_line2_sep_line3\n"]

    test_file_list_sep = ["line1_sep_line2_sep_line3"]
    test_file_list_sep_2 = ["line1", "line2", "line3"]
    test_file_list_sep_3 = ["line1\nline2\nline3"]


# Generated at 2022-06-23 02:01:28.898306
# Unit test for function get_file_content
def test_get_file_content():
    # Create a tmp file with some test data
    tmp_file = '/tmp/test_gather'
    data = 'Test data'
    try:
        with open(tmp_file, 'w') as f:
            f.write(data)

        if data == get_file_content(tmp_file):
            return True
        else:
            return False
    finally:
        # Delete file
        os.remove(tmp_file)
    return False