

# Generated at 2022-06-23 02:00:38.554238
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines(b'/dev/null') == []
    assert get_file_lines('/dev/null') == []
    assert get_file_lines(1) == []
    

# Generated at 2022-06-23 02:00:47.638259
# Unit test for function get_file_lines
def test_get_file_lines():
    lines = ['a', 'b\n', 'c', 'd', 'e\n', 'f\n']
    lines_sep = ['a', 'b', 'c', 'd', 'e', 'f']

    # test with non existing file
    ret = get_file_lines('/tmp/non/existing/path/to/file')
    assert ret == []

    # create test file
    tf = open('/tmp/test_file', 'wb')
    for line in lines:
        tf.write(line)
    tf.close()

    # test default behavior
    ret = get_file_lines('/tmp/test_file')
    assert ret == lines_sep

    # test with line separator specified

# Generated at 2022-06-23 02:00:59.634810
# Unit test for function get_mount_size
def test_get_mount_size():
    import mock
    import sys

    if sys.version_info[0] < 3:
        from mock import patch
    else:
        from unittest.mock import patch

    expected_result = {
        'size_total': 1024,
        'size_available': 512,
        'block_size': 4,
        'block_total': 10,
        'block_available': 5,
        'block_used': 5,
        'inode_total': 20,
        'inode_available': 10,
        'inode_used': 10
    }


# Generated at 2022-06-23 02:01:01.321683
# Unit test for function get_mount_size
def test_get_mount_size():
    assert get_mount_size('/')



# Generated at 2022-06-23 02:01:13.304763
# Unit test for function get_file_lines
def test_get_file_lines():
    path = 'ansible/test/units/lib/ansible/module_utils/basic.py'
    result = get_file_lines(path)
    assert len(result) > 0, 'length of result is ' + str(len(result))
    assert isinstance(result, list), 'result type is ' + type(result)

    # Handle multiple separators (windows and linux)
    line_sep = '\n\r'
    path = 'ansible/test/units/lib/ansible/module_utils/net_tools/basics.py'
    result = get_file_lines(path, line_sep=line_sep)
    assert len(result) > 0, 'length of result is ' + str(len(result))
    assert isinstance(result, list), 'result type is ' + type(result)

# Generated at 2022-06-23 02:01:24.729414
# Unit test for function get_file_lines
def test_get_file_lines():
    print("Testing get_file_lines...")
    assert get_file_lines('/etc/hosts', strip=True, line_sep='\n') == ['127.0.0.1\tlocalhost', '127.0.1.1\tmy-laptop\n']

# Generated at 2022-06-23 02:01:37.829701
# Unit test for function get_file_lines
def test_get_file_lines():
    path = '/var/run/test.txt'
    os.system("echo -e 'abc\ndef\nghi' > '%s'" %(path))
    default = []
    result = get_file_lines(path)
    assert result == ['abc', 'def', 'ghi']
    result = get_file_lines(path, line_sep='\n')
    assert result == ['abc', 'def', 'ghi']
    result = get_file_lines(path, line_sep='\r\n')
    assert result == ['abc', 'def', 'ghi']
    result = get_file_lines(path, line_sep='ghi')
    assert result == ['abc\ndef\n', '']

# Generated at 2022-06-23 02:01:47.194461
# Unit test for function get_file_lines
def test_get_file_lines():
    filename = "testfile.txt"
    with open(filename, 'w') as f:
        f.write('''line1\nline2\nline3''')
    assert get_file_lines('invalid filename', strip=True, line_sep=None) == []
    assert get_file_lines(filename, strip=True, line_sep=None) == ['line1', 'line2', 'line3']
    # Test strip==False and line_sep=='\n'
    assert get_file_lines(filename, strip=False, line_sep='\n') == ['line1', 'line2', 'line3', '']
    # Test line_sep of len 2

# Generated at 2022-06-23 02:01:58.444204
# Unit test for function get_mount_size
def test_get_mount_size():
    import ansible.utils.unsafe_proxy
    mount_size = get_mount_size('/')
    assert type(mount_size) is dict, "get_mount_size returned: %s" % mount_size
    for key in ['size_total', 'size_available', 'block_size', 'block_total', 'block_available',
                'block_used', 'inode_total', 'inode_available', 'inode_used']:
        assert key in mount_size, "get_mount_size returned: %s" % mount_size
        assert type(mount_size[key]) is int, "get_mount_size returned: %s" % mount_size

# ===========================================

# Make coding more python3-ish
__metaclass__ = type

# Generated at 2022-06-23 02:02:10.504364
# Unit test for function get_file_lines
def test_get_file_lines():
    # Test basic functionality
    file_content = """
        this is line 1
        this is line 2
        this is line 3
    """
    tmpfile = "/tmp/test_get_file_lines"
    with open(tmpfile, "w") as f:
        f.write(file_content)
    data = get_file_lines(tmpfile)
    os.unlink(tmpfile)

    ansible_module = AnsibleModule(argument_spec=dict(
        path = dict(required=True, type='str'),
        strip = dict(required=False, default=True, type='bool'),
        line_sep = dict(required=False, type='str'),
        ))

    ansible_module.exit_json(changed=False, data=data)


# Generated at 2022-06-23 02:02:11.304218
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/proc/uptime', strip=False)

# Generated at 2022-06-23 02:02:15.446248
# Unit test for function get_file_content
def test_get_file_content():
    open('/tmp/foo', 'w').close()
    assert get_file_content('/tmp/foo') is None
    with open('/tmp/foo', 'w') as f:
        f.write('bar')
    assert get_file_content('/tmp/foo') == 'bar'
    assert get_file_content('/tmp/foo', strip=False) == 'bar\n'



# Generated at 2022-06-23 02:02:21.708394
# Unit test for function get_file_content
def test_get_file_content():
    '''test_get_file_content: test to ensure we can read a file and return contents'''
    assert get_file_content('/etc/resolv.conf', default="") is not ""
    assert get_file_content('/etc/resolv.conf', default="") is not None
    assert get_file_content('/etc/resolv.conf', default="") is not False


# Generated at 2022-06-23 02:02:31.426815
# Unit test for function get_mount_size
def test_get_mount_size():
    # Test positive use case for function get_mount_size

    # Arrange
    mountpoint = os.getcwd()

    # Act
    mount_size = get_mount_size(mountpoint)

    # Assert
    assert mount_size['size_total']
    assert mount_size['size_available']
    assert mount_size['block_size']
    assert mount_size['block_total']
    assert mount_size['block_available']
    assert mount_size['block_used']
    assert mount_size['inode_total']
    assert mount_size['inode_available']
    assert mount_size['inode_used']

    # Test negative use case for function get_mount_size
    # Arrange
    mountpoint = os.sep

    # Act

# Generated at 2022-06-23 02:02:40.108142
# Unit test for function get_mount_size
def test_get_mount_size():

    unittest.TestCase.assertDictEqual(get_mount_size('/'),
                {'size_total': 39459955712, 'inode_available': 243998, 'inode_total': 249993, 'inode_used': 5995, 'size_available': 29582987264, 'block_available': 749086, 'block_total': 940197, 'block_used': 196512, 'block_size': 4096})



# Generated at 2022-06-23 02:02:51.880161
# Unit test for function get_mount_size
def test_get_mount_size():
    if os.path.exists("/etc/fstab"):
        for line in get_file_lines("/etc/fstab"):
            cols = line.split()
            if cols and cols[0].startswith("/"):
                mountpoint = cols[1]
                mount_size = get_mount_size(mountpoint)
                assert mount_size['size_total'] > 0
                assert mount_size['size_available'] > 0
                assert mount_size['block_size'] > 0
                assert mount_size['block_total'] > 0
                assert mount_size['block_available'] > 0
                assert mount_size['block_used'] > 0
                assert mount_size['inode_total'] > 0
                assert mount_size['inode_available'] > 0

# Generated at 2022-06-23 02:02:57.999216
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content("/etc/passwd")
    assert not get_file_content("/etc/shadow")
    assert get_file_content("/etc/shadow", default="default")
    assert get_file_content("/etc/shadow", strip=False) != get_file_content("/etc/shadow")
    assert get_file_content("/etc/shadow", strip=False) == get_file_content("/etc/shadow", strip=False)

# Generated at 2022-06-23 02:02:59.947989
# Unit test for function get_mount_size
def test_get_mount_size():
    import sys
    assert get_mount_size('/')['size_total'] == sys.maxint


# Generated at 2022-06-23 02:03:10.359088
# Unit test for function get_mount_size
def test_get_mount_size():
    mountpoint = '/'

    # If the expected values changes, please modify get_mount_size() in util.py
    expected_result = {'block_available': 464557, 'size_available': 43905849344, 'size_total': 58161725440,
                       'inode_used': 41697, 'block_size': 4096, 'block_total': 1433887, 'block_used': 974330,
                       'inode_available': 337910, 'inode_total': 754607}

    assert get_mount_size(mountpoint) == expected_result, "Test result doesn't match the expected result"


# Generated at 2022-06-23 02:03:17.916641
# Unit test for function get_mount_size
def test_get_mount_size():
    import pytest
    from types import DictType

    ret = {}
    ret = get_mount_size(mountpoint='/')
    assert isinstance(ret, DictType)
    assert ret != {}
    ret = get_mount_size(mountpoint='/home/')
    assert isinstance(ret, DictType)
    assert ret != {}

    # bad mountpoint
    with pytest.raises(OSError):
        get_mount_size(mountpoint='/foo')
# end of test_get_mount_size

# Generated at 2022-06-23 02:03:18.799243
# Unit test for function get_mount_size
def test_get_mount_size():
    assert get_mount_size("/")

# Generated at 2022-06-23 02:03:30.946154
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd', strip=True) == get_file_lines('/etc/passwd', strip=True, line_sep='\n')
    assert get_file_lines('/etc/passwd', strip=True, line_sep='\n') == get_file_lines('/etc/passwd', strip=True, line_sep='\n')

# Generated at 2022-06-23 02:03:43.402328
# Unit test for function get_file_lines
def test_get_file_lines():
    test_file = r'test_file'
    test_data = r'this\n\n    is\x00\na\ttest\n'
    test_data_lines = ['this', '', '    is', 'a\ttest', '']

    for sep in '', '\n':
        for strip in True, False:
            with open(test_file, 'w') as f:
                if sep:
                    f.write(sep.join(test_data_lines))
                else:
                    f.write(test_data)
            res = get_file_lines(test_file, strip=strip)
            assert res == test_data_lines

if __name__ == "__main__":
    test_get_file_lines()

# Generated at 2022-06-23 02:03:58.338015
# Unit test for function get_mount_size
def test_get_mount_size():
    from ansible.module_utils import basic
    from ansible.module_utils import facts

    f = facts.Facts()
    result = f.populate()

    mountpoint_results = result.get('ansible_mounts')

    for mountpoint in mountpoint_results:
        mount_size = get_mount_size(mountpoint.get('mount'))

        if mount_size['size_total'] != mountpoint['size_total']:
            raise Exception("size_total should be equal to %s" % mountpoint['size_total'])

        if mount_size['size_available'] != mountpoint['size_available']:
            raise Exception("size_available should be equal to %s" % mountpoint['size_available'])

        if mount_size['block_size'] != mountpoint['block_size']:
            raise Exception

# Generated at 2022-06-23 02:03:59.486726
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/proc/mounts', line_sep='\n') == get_file_lines('/proc/mounts')

# Generated at 2022-06-23 02:04:03.513421
# Unit test for function get_file_content
def test_get_file_content():
    path = os.path.join(os.path.dirname(__file__), "test_files", "example_file.txt")
    result = get_file_content(path)
    assert result == "Hello World!"


# Generated at 2022-06-23 02:04:14.114576
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') is not None
    assert get_file_content('/bin/hostname') is not None
    assert get_file_content('/bin/hostname', default='empty') is not None
    assert get_file_content('/bin/hostname', default='empty', strip=False) is not None

    assert get_file_content('/bad/path', default='empty') == 'empty'
    assert get_file_content('/bad/path', default='empty', strip=False) == 'empty'

    assert get_file_content('/etc/hosts', default='empty') is not None
    assert get_file_content('/etc/hosts', default='empty', strip=False) is not None


# Generated at 2022-06-23 02:04:26.865081
# Unit test for function get_file_lines
def test_get_file_lines():
    content = '''
  hello
world
'''
    with open('/tmp/1', 'w') as f:
        f.write(content)

    data = get_file_lines('/tmp/1')
    assert data == ['', 'hello', 'world']
    data = get_file_lines('/tmp/1', strip=False)
    assert data == ['', '  hello', 'world', '']

    content = '''
  one
  two
  three

'''
    with open('/tmp/2', 'w') as f:
        f.write(content)

    data = get_file_lines('/tmp/2', line_sep=None)
    assert data == ['', '  one', '  two', '  three', '', '']

# Generated at 2022-06-23 02:04:38.307202
# Unit test for function get_file_content
def test_get_file_content():
    '''
    Unit test for function get_file_content
    '''
    # Initialise test data
    test_templates_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'library', 'system', 'test', 'templates')
    test_file_content = 'This is a test file'

    # Create a test file
    test_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'library', 'system', 'test', 'templates', 'test_file_content')
    with open(test_file, 'w') as file_handle:
        file_handle.write(test_file_content)

    # Test get_file_content using the test file that we created above

# Generated at 2022-06-23 02:04:43.959847
# Unit test for function get_mount_size
def test_get_mount_size():
    result = get_mount_size('/')
    assert result['size_total'] != 0
    assert result['size_available'] != 0
    assert result['block_size'] != 0
    assert result['block_total'] != 0
    assert result['block_total'] != 0
    assert result['inode_total'] != 0
    assert result['inode_available'] != 0
    assert result['inode_used'] != 0

# Generated at 2022-06-23 02:04:55.860327
# Unit test for function get_mount_size
def test_get_mount_size():
    '''
    Return a dict with following keys and values:
    size_total    - total mountpoint size in bytes
    size_available - available mountpoint size in bytes
    block_size    - blocksize in bytes
    block_total   - total blocks
    block_available - available blocks
    block_used    - used blocks
    inode_total   - total inodes
    inode_available- availabe inodes
    inode_used    - used inodes
    '''
    print(get_mount_size(os.path.pardir))
    print(get_mount_size(os.path.abspath(os.path.pardir)))
    print(get_mount_size(os.path.abspath(os.path.join(os.path.pardir, os.path.pardir))))

# Generated at 2022-06-23 02:05:06.002922
# Unit test for function get_file_content
def test_get_file_content():
    filename = '/tmp/test_fs_get_file_content'
    with open(filename, 'w') as f:
        f.write('test 1' + '\n')
        f.write('test 2' + '\n')
        f.write('test 3')

    assert get_file_content(filename) == "test 1\ntest 2\ntest 3"
    assert get_file_content(filename, strip=False) == "test 1\ntest 2\ntest 3"
    assert get_file_content(filename, default="test") == "test 1\ntest 2\ntest 3"

    os.remove(filename)


# Generated at 2022-06-23 02:05:15.269139
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(__file__) == open(__file__, 'r').read().strip()
    assert get_file_content(__file__, default='default') == open(__file__, 'r').read().strip()
    assert get_file_content(__file__, strip=False) == open(__file__, 'r').read()
    assert get_file_content(__file__, default='default', strip=False) == open(__file__, 'r').read()
    assert get_file_content(__file__ + '__does_not_exist', default='default', strip=False) == 'default'

# Generated at 2022-06-23 02:05:22.331524
# Unit test for function get_file_content
def test_get_file_content():
    assert(get_file_content("/etc/hosts", default="") == "")
    assert(get_file_content("/etc/hosts", default="", strip=False) == "")
    assert(get_file_content("/etc/hosts", default="") == "")
    assert(get_file_content("/etc/hosts", "") == "")
    assert(get_file_content("/etc/hosts", "", strip=False) == "")
    assert(get_file_content("/etc/hosts", "") == "")
    assert(get_file_content("/this/path/does/not/exist") == None)
    assert(get_file_content("/proc/cpuinfo", default=None, strip=False) != None)

# Generated at 2022-06-23 02:05:24.677127
# Unit test for function get_file_lines
def test_get_file_lines():
    ret = get_file_lines("/proc/uptime")
    assert(ret[0] == "972.75 786.99")

# Generated at 2022-06-23 02:05:30.836494
# Unit test for function get_file_content
def test_get_file_content():
    """get_file_content, returns contents of a file specified"""
    """should return contents of the file"""
    tmp = '/tmp/ansible_test_file'
    with open(tmp, "w") as tmp_file:
        tmp_file.write('boo')

    assert get_file_content(tmp) == 'boo'

    """should return default value if file does not exist"""
    assert get_file_content('/path/to/bogus', 'y') == 'y'

    """should return contents of the file and not strip"""
    tmp = '/tmp/ansible_test_file'
    with open(tmp, "w") as tmp_file:
        tmp_file.write('foo\n')
    assert get_file_content(tmp, strip=False) == 'foo\n'


# Generated at 2022-06-23 02:05:41.488889
# Unit test for function get_file_content
def test_get_file_content():
    file_contents = get_file_content('/proc/cpuinfo')
    assert isinstance(file_contents, basestring)
    assert 'processor' in file_contents

    # Test reading a non-existent file
    file_contents = get_file_content('/this/path/does/not/exist')
    assert file_contents == None

    # Test reading a file with no permissions
    if os.path.exists('/etc/shadow'):
        file_contents = get_file_content('/etc/shadow')
        assert file_contents == None



# Generated at 2022-06-23 02:05:44.912086
# Unit test for function get_mount_size
def test_get_mount_size():
    assert get_mount_size('/') is not None


# Generated at 2022-06-23 02:05:55.705972
# Unit test for function get_file_lines
def test_get_file_lines():
    test_data = (
        ('', []),
        ("\n", []),
        ('\n\n\n', []),
        ('a\nb\n', ['a', 'b']),
        ('a\nb\n\n', ['a', 'b']),
        ('\n\na\nb\n\n', ['a', 'b']),
        ('\na\nb\n\n', ['a', 'b']),
        ('\n\na\nb\n', ['a', 'b']),
        ('\na\nb\n', ['a', 'b']),
        ('a\na\nb\nb', ['a', 'a', 'b', 'b']),
        ('a\nb\na\nb', ['a', 'b', 'a', 'b']),
    )

# Generated at 2022-06-23 02:06:02.412632
# Unit test for function get_mount_size
def test_get_mount_size():

    ret = get_mount_size('/')
    assert ret['size_total'] > 1
    assert ret['size_available'] > 1
    assert ret['block_size'] > 1
    assert ret['block_total'] > 1
    assert ret['block_available'] > 1
    assert ret['block_used'] > 1
    assert ret['inode_total'] > 1
    assert ret['inode_available'] > 1
    assert ret['inode_used'] > 1



# Generated at 2022-06-23 02:06:08.957307
# Unit test for function get_mount_size
def test_get_mount_size():

    # Set up test fixture
    mountpoint = "foo"
    statvfs_result = os.statvfs(mountpoint)
    statvfs_result.f_frsize = os.statvfs(".").f_frsize

    # Set up expected result
    expected_result = {}
    expected_result['size_total'] = statvfs_result.f_frsize * statvfs_result.f_blocks
    expected_result['size_available'] = statvfs_result.f_frsize * statvfs_result.f_bavail
    expected_result['block_size'] = statvfs_result.f_bsize
    expected_result['block_total'] = statvfs_result.f_blocks
    expected_result['block_available'] = statvfs_result.f_b

# Generated at 2022-06-23 02:06:13.432091
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('tests/unit/modules/test_files/get_file_content_file') == 'Some file content\n'
    assert get_file_content('tests/unit/modules/test_files/get_file_content_file_empty') == ''



# Generated at 2022-06-23 02:06:17.310063
# Unit test for function get_file_lines
def test_get_file_lines():
    '''returns True if test is passed, False otherwise'''
    file_path = "/etc/fstab"
    lines = get_file_lines(file_path)
    if lines is not None:
        return True
    return False


# Generated at 2022-06-23 02:06:18.164720
# Unit test for function get_mount_size
def test_get_mount_size():
    assert get_mount_size('/')

# Generated at 2022-06-23 02:06:23.358946
# Unit test for function get_file_lines
def test_get_file_lines():
    assert ['a', 'b'] == get_file_lines('/tmp/test_get_file_lines', line_sep='\n')  # Normal case
    assert ['a', 'b'] == get_file_line

# Generated at 2022-06-23 02:06:27.414704
# Unit test for function get_mount_size
def test_get_mount_size():
    from ansible.module_utils.basic import AnsibleModule
    with AnsibleModule(argument_spec=dict()) as module:
        msg = "get_mount_size function failed to return a correct size of the filesystem"
        assert "size_available" in get_mount_size(module.tmpdir), msg


# Generated at 2022-06-23 02:06:40.591462
# Unit test for function get_file_content
def test_get_file_content():

    # Create temporary file
    (fd, path) = tempfile.mkstemp()
    handle = os.fdopen(fd, 'w')
    handle.write('hello world')
    handle.close()

    # Get the file content
    content = get_file_content(path)

    # Test that it's equal to 'hello world'
    assert content == 'hello world'

    # Get the file content again but this time with strip
    content = get_file_content(path, strip=True)

    # Test that it's equal to 'hello world' and stripped
    assert content == 'hello world'

    # Get the file content with the default value "default"
    content = get_file_content(path + '_non_existent', default='default')

    # Test that it's equal to 'default'
    assert content == 'default'

# Generated at 2022-06-23 02:06:52.464306
# Unit test for function get_file_content
def test_get_file_content():
    # Testing for get_file_content, should return 'default' value for all types
    # of exceptions, such as 'file does not exist', 'file is not readable'
    # or 'file cannot be opened'
    assert get_file_content('/this/file/does/not/exist', default=-1) == -1
    assert get_file_content('/etc/hosts', 'foo', 1, 'bar') == 'bar'
    assert not get_file_content('/etc/hosts', '')
    assert not get_file_content('/etc/hosts', default='')

    # Testing for get_file_content, should return content of existing
    # file, strip it if needed
    assert get_file_content('/etc/hosts', default=-1) != -1

# Generated at 2022-06-23 02:06:57.255443
# Unit test for function get_file_content
def test_get_file_content():
    test_path = os.path.realpath(__file__)

    assert get_file_content(test_path, strip=False) == open(test_path).read()
    assert get_file_content(test_path, strip=True) == open(test_path).read().strip()



# Generated at 2022-06-23 02:07:01.848621
# Unit test for function get_mount_size
def test_get_mount_size():
    import sys
    import json

    # Call get_mount_size with system root directory
    mount_size = get_mount_size(sys.prefix)

    if mount_size:
        # Pretty print mount_size
        print(json.dumps(mount_size, sort_keys=True, indent=4))

        # Test if keys exist in returned dictionary
        assert 'size_total' in mount_size
        assert 'size_available' in mount_size
        assert 'block_size' in mount_size
        assert 'block_total' in mount_size
        assert 'block_available' in mount_size
        assert 'block_used' in mount_size
        assert 'inode_total' in mount_size
        assert 'inode_available' in mount_size
        assert 'inode_used' in mount_size

        # Test

# Generated at 2022-06-23 02:07:12.751820
# Unit test for function get_file_lines
def test_get_file_lines():
    path = '/tmp/test_file'
    test_data = '''line 1
line 2
line 3
line 4
'''
    with open(path, "w") as f:
        f.write(test_data)

    # Test without stripping, without line separator
    lines = get_file_lines(path, strip=False)
    assert lines == ['line 1', 'line 2', 'line 3', 'line 4', '']

    # Test with stripping, without line separator
    lines = get_file_lines(path, strip=True)
    assert lines == ['line 1', 'line 2', 'line 3', 'line 4']

    # Test without stripping, with line separator
    lines = get_file_lines(path, strip=False, line_sep='line')

# Generated at 2022-06-23 02:07:15.668284
# Unit test for function get_mount_size
def test_get_mount_size():
    try:
        assert get_mount_size('/')
    except AssertionError:
        raise AssertionError('Could not get mount point size for /')

# Generated at 2022-06-23 02:07:27.418920
# Unit test for function get_file_lines
def test_get_file_lines():
    # Test the default behavior
    expected = [
        '127.0.0.1',
        '127.0.0.2',
        '127.0.0.3',
        '127.0.0.4',
    ]

    result = get_file_lines('/tmp/get_file_lines.txt')
    assert result == expected

    # Check that we can handle an empty file
    result = get_file_lines('/empty.txt')
    assert result == []
    result = get_file_lines('/empty.txt', 'default')
    assert result == 'default'

    # Check that we can handle files with a non unix-style newline

# Generated at 2022-06-23 02:07:36.649776
# Unit test for function get_file_content
def test_get_file_content():
    test_data = get_file_content('/etc/aliases', default='default_val', strip=True)
    assert(test_data != '')
    test_data = get_file_content('/etc/aliases', default='default_val', strip=False)
    assert(test_data != '')
    test_data = get_file_content('/nosuchfile', default='default_val', strip=False)
    assert(test_data == 'default_val')
    test_data = get_file_content('/nosuchfile', default='default_val', strip=True)
    assert(test_data == 'default_val')

# Generated at 2022-06-23 02:07:39.679946
# Unit test for function get_file_lines
def test_get_file_lines():
    path = 'tests/files/data/testfile'
    assert get_file_lines(path) == ['This is a', 'test file']
    assert get_file_lines(path, line_sep=' ') == ['This is a test file']

# Generated at 2022-06-23 02:07:51.349849
# Unit test for function get_file_lines
def test_get_file_lines():
    if 'TRAVIS' not in os.environ or os.environ['TRAVIS'] == 'false':
        assert get_file_lines('/etc/resolv.conf') == ['# Dynamic resolv.conf(5) file for glibc resolver(3) generated by resolvconf(8)', '#     DO NOT EDIT THIS FILE BY HAND -- YOUR CHANGES WILL BE OVERWRITTEN', 'nameserver 127.0.0.1']

# Generated at 2022-06-23 02:07:58.618390
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', strip=False) is not None
    assert get_file_content('/etc/hostname', default='hostname') == 'hostname'
    assert get_file_content('/etc/hostnam', default='hostname') == 'hostname'
    assert get_file_content('/etc/passwd', default='somethingelse') is not None
    assert get_file_content('/etc/passwd') is not None
    assert get_file_content('/etc/passwd').startswith('root:x:0:')
    assert get_file_content('/etc/passwd', strip=False).endswith('\n')

# Generated at 2022-06-23 02:08:10.356575
# Unit test for function get_file_content
def test_get_file_content():
    test_path = os.getcwd() + "/test_file_content"
    test_content = "Test 123\n"

    with open(test_path, 'w') as file_handle:
        file_handle.write(test_content)

    assert get_file_content(test_path) == test_content
    assert get_file_content(test_path, '') == test_content
    assert get_file_content(test_path, None) == test_content
    assert get_file_content(test_path, strip=False) == test_content + "\n"
    assert get_file_content(test_path, default='test') == test_content
    assert get_file_content(test_path, default='test', strip=False) == test_content + "\n"

# Generated at 2022-06-23 02:08:21.871552
# Unit test for function get_file_content
def test_get_file_content():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, mock_open

    with patch('ansible.module_utils.facts.system.get_file_content') as m_gfc:
        m_gfc.return_value = '1234'
        assert m_gfc() == '1234'

    with patch('ansible.module_utils.facts.system.get_file_content') as m_gfc:
        m_gfc.side_effect = [
            IOError,
            OSError,
        ]
        assert m_gfc() == None
        assert m_gfc() == None


# Generated at 2022-06-23 02:08:30.886034
# Unit test for function get_mount_size
def test_get_mount_size():
    assert get_mount_size('/') == {
                                 'block_size': 4096,
                                 'size_available': 54070398976,
                                 'block_used': 5970059,
                                 'block_available': 76749516,
                                 'size_total': 81943711744,
                                 'inode_total': 4883840,
                                 'inode_used': 239516,
                                 'block_total': 81957416,
                                 'inode_available': 4644324
                                }

# Generated at 2022-06-23 02:08:42.198114
# Unit test for function get_mount_size
def test_get_mount_size():
    test_data = {
        'size_total': 524288,
        'size_available': 131072,
        'block_size': 1024,
        'block_total': 512,
        'block_available': 128,
        'block_used': 384,
        'inode_total': 256,
        'inode_available': 128,
        'inode_used': 128
    }

    if os.path.exists('/tmp/test'):
        os.removedirs('/tmp/test')
    os.mkdir('/tmp/test')
    os.system("mount -t tmpfs tmpfs /tmp/test")

    os.system("truncate -s 512K /tmp/test/test_file")
    os.system("truncate -s 128K /tmp/test/test_file")

# Generated at 2022-06-23 02:08:53.405598
# Unit test for function get_file_content
def test_get_file_content():
    # Test 1: empty file
    assert get_file_content('t/data/empty') == ''
    assert get_file_content('t/data/empty', 'bar') == 'bar'

    # Test 2: a file with a default that is not used
    assert get_file_content('t/data/null', 'bar') == None
    assert get_file_content('t/data/null', 'bar', False) == None

    # Test 3: a file that is not there and getting the default
    assert get_file_content('t/data/doesnotexist', 'bar', False) == 'bar'

    # Test 4: a file that is not there with no default
    assert get_file_content('t/data/doesnotexist') == None

# Generated at 2022-06-23 02:09:00.936993
# Unit test for function get_file_lines
def test_get_file_lines():
    '''
    Test function get_file_lines
    '''
    assert(get_file_lines('/dev/null') == [])
    assert(get_file_lines('/bin/false') == [])
    assert(get_file_lines('/bin/true') == [])
    assert(get_file_lines('/bin/cat') == [])
    assert(get_file_lines('/bin/ls', line_sep='B') == [])
    assert(get_file_lines('/bin/ls', line_sep='B', strip=False) == '')
    assert(get_file_lines('/bin/ls', strip=False, line_sep='B') == '')

# Generated at 2022-06-23 02:09:09.430751
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/proc/1/cmdline', default=None, strip=True) is not None
    assert get_file_content('/proc/1/cmdline', default=None, strip=False) is not None
    assert get_file_content('/proc/1/cmdline', default='', strip=False) is not ''
    assert get_file_content('/tmp/doesnotexists', default='', strip=False) is not None
    assert get_file_content('/tmp/doesnotexists', default='', strip=False) == ''
    assert get_file_content('/proc/1/cmdline', default='', strip=False) is not ''
    assert get_file_content('/proc/1/cmdline', default='', strip=True) is not ''

# Generated at 2022-06-23 02:09:13.250217
# Unit test for function get_mount_size
def test_get_mount_size():
    # Tested on CentOS 7.1 with mounted directory /tmp
    assert get_mount_size('/test') == {}

    assert 'block_total' in get_mount_size('/tmp')
    assert get_mount_size('/tmp')['block_total'] == 2100363
    assert get_mount_size('/tmp')['block_available'] <= 2100363

# Generated at 2022-06-23 02:09:19.439959
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/bashrc') == get_file_lines('/etc/bashrc', line_sep=os.linesep)
    assert get_file_lines('/etc/bashrc', line_sep='') == get_file_content('/etc/bashrc').split('\n')
    assert get_file_lines('/etc/bashrc', line_sep='\n') == get_file_lines('/etc/bashrc')
    assert get_file_lines('/etc/bashrc', line_sep='\n\n') == get_file_lines('/etc/bashrc', line_sep='\n')

# Generated at 2022-06-23 02:09:27.081684
# Unit test for function get_mount_size
def test_get_mount_size():
    # Functionality testing for Mount size
    mount_size = get_mount_size('/tmp')
    assert mount_size
    assert mount_size['size_total']
    assert mount_size['size_available']
    assert mount_size['block_size']
    assert mount_size['block_total']
    assert mount_size['block_available']
    assert mount_size['block_used']
    assert mount_size['inode_total']
    assert mount_size['inode_available']
    assert mount_size['inode_used']


# Generated at 2022-06-23 02:09:38.194499
# Unit test for function get_mount_size
def test_get_mount_size():

    def mk_file(filename, content=None):
        '''Create file with given content'''
        with open(filename, 'w') as f:
            if content:
                f.write(content)

    import pytest
    import tempfile
    import shutil
    from ansible.module_utils.basic import AnsibleModule

    def test_unmount_and_delete(test_dir):
        '''Unmount mountpoint and remove mountpoint directory'''
        module = AnsibleModule(
            argument_spec={},
            supports_check_mode=True
        )
        if not module.check_mode:
            # Make sure we can unmount test_dir
            rc, stderr, stdout = module.run_command(['umount', test_dir])

            if rc == 0:
                # Remove directory
                shut

# Generated at 2022-06-23 02:09:49.472871
# Unit test for function get_file_lines
def test_get_file_lines():
    '''
    Unit test for get_file_lines()
    '''

    lines = [
        "line1",
        "line2",
        "line3",
        "line4",
        "line5",
    ]

    lines_check = [
        "line1",
        "line2",
        "line3",
        "line4",
        "line5",
    ]

    lines_alt = [
        "line1",
        "line2",
        "line3",
        "line4",
        "line5",
        "line6",
        "line7",
        "line8",
        "line9",
    ]


# Generated at 2022-06-23 02:09:54.698937
# Unit test for function get_file_lines
def test_get_file_lines():
    path = os.path.join(os.path.dirname(__file__), '..', 'data', 'mounts')
    lines = get_file_lines(path)
    assert len(lines) == 9


if __name__ == '__main__':
    test_get_file_lines()

# Generated at 2022-06-23 02:10:04.764188
# Unit test for function get_mount_size
def test_get_mount_size():
    # make a temporary directory to mount
    import tempfile
    mountpoint = tempfile.mkdtemp(prefix="ansible_mount_test_")

    # get the mount fstype
    import subprocess
    import platform
    is_linux = False
    try:
        subprocess.check_call(["which", "df"])
        is_linux = True
    except:
        pass

    if is_linux:
        cmd = "df --output=fstype {0}".format(mountpoint)
        proc = subprocess.Popen(cmd.split(), stdout=subprocess.PIPE)
        output, err = proc.communicate()
        fstype = (output.splitlines()[1]).strip()
    else:
        platform_system = platform.system()

# Generated at 2022-06-23 02:10:14.574872
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content("/etc/hosts", default="") == get_file_content("/etc/hosts", default="", strip=False)
    assert get_file_content("/etc/hosts", default="")
    assert get_file_content("/etc/hosts", strip=False, default="")
    assert get_file_content("/etc/passwd", default="")
    assert get_file_content("/etc/passwd", strip=False, default="")
    assert get_file_content("/etc/nofile", default="") == get_file_content("/etc/nofile", default="", strip=False)
    assert get_file_content("/etc/nofile", default="")
    assert get_file_content("/etc/nofile", strip=False, default="")

# Generated at 2022-06-23 02:10:25.113165
# Unit test for function get_file_lines
def test_get_file_lines():
    # test_doc_str
    '''
    [
        {'name': 'mountpoint', 'state': 'present', 'fstype': 'ext4', 'mount_options': None, 'dump': 1, 'passno': 2, 'device': '/dev/sdb1', 'bootpartition': False, 'bootdevice': False},
        {'name': 'mountpoint', 'state': 'present', 'fstype': None, 'mount_options': None, 'dump': 1, 'passno': 2, 'device': '/dev/sdb2', 'bootpartition': False, 'bootdevice': False},
    ]
    '''

    data = "abc,abc\ndef,def\nghi,ghi\njkl,jkl"
    assert data == get_file_content('/tmp/test_mounts')


# Generated at 2022-06-23 02:10:36.027324
# Unit test for function get_file_content
def test_get_file_content():
    '''
    Test cases for get_file_content
    '''
    # Create a file for our test
    test_file = "/tmp/system_info_ansible_test.txt"
    test_content = "Hello\nWorld\n"
    f = open(test_file, 'w')
    f.write(test_content)
    f.close()

    # Test for file not exist
    assert get_file_content('does_not_exist') == None

    # Test for file exist with good content
    assert get_file_content(test_file) == test_content

    # Test for file exist with good content (stripped)
    assert get_file_content(test_file, strip=True) == test_content.strip()

    # Test for file exist with bad (empty) content
    assert get_file_