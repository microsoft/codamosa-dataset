

# Generated at 2022-06-23 02:00:44.415067
# Unit test for function get_file_lines
def test_get_file_lines():
    content = """
      line1
      line2
      line3
      """
    path = '/tmp/testfile'

    def clean_up():
        if os.path.isfile(path):
            os.unlink(path)

    with open(path, 'w') as f:
        f.write(content)
    assert get_file_lines(path) == ['line1', 'line2', 'line3']
    clean_up()
    with open(path, 'w') as f:
        f.write(content + '\r')
    assert get_file_lines(path) == ['line1', 'line2', 'line3']
    clean_up()
    with open(path, 'w') as f:
        f.write(content + '\r\n')

# Generated at 2022-06-23 02:00:55.800049
# Unit test for function get_file_lines

# Generated at 2022-06-23 02:01:05.855733
# Unit test for function get_file_content
def test_get_file_content():
    """This is a unit test for utils.get_file_content()."""

    fixtures = [
        os.path.join(os.path.dirname(__file__), '../../test/unit/common/fixtures/file_lines'),
        os.path.join(os.path.dirname(__file__), '../../test/integration/targets/cygwin_sshd/fixtures/file_lines')
    ]

    for fixture in fixtures:
        result = get_file_content(fixture)
        assert result == 'line1\nline2\nline3\n'


# Generated at 2022-06-23 02:01:17.894352
# Unit test for function get_file_lines

# Generated at 2022-06-23 02:01:28.143961
# Unit test for function get_file_lines
def test_get_file_lines():
    '''
    Simple unit test for get_file_lines
    '''
    assert get_file_lines('/dev/null', strip=False) == []
    assert get_file_lines('/dev/null', strip=True) == []
    assert get_file_lines('/dev/null', line_sep=',') == []
    assert get_file_lines('/dev/null', strip=False, line_sep=',') == []

    assert get_file_lines('/dev/zero', strip=False) == []
    assert get_file_lines('/dev/zero', strip=True) == []
    assert get_file_lines('/dev/zero', line_sep=',') == []
    assert get_file_lines('/dev/zero', strip=False, line_sep=',') == []

# Generated at 2022-06-23 02:01:44.745649
# Unit test for function get_mount_size
def test_get_mount_size():
    size = get_mount_size('/')
    assert isinstance(size, dict)
    assert isinstance(size['size_total'], int)
    assert isinstance(size['size_available'], int)