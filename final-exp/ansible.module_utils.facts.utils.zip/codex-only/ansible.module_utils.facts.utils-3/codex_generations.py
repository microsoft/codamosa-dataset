

# Generated at 2022-06-23 02:00:46.548150
# Unit test for function get_file_content
def test_get_file_content():
    test_data = ('asdf\njkl;\n', 'asdf  \njkl;\n', 'asdf  \n\njkl;\n')
    for line in test_data:
        with open('/tmp/test_get_file_content', 'w') as f:
            f.write(line)
            f.close()

        data = get_file_content('/tmp/test_get_file_content', strip=False)
        assert(line == data)

        data = get_file_content('/tmp/test_get_file_content')
        assert(line.rstrip().rstrip('\n') == data)



# Generated at 2022-06-23 02:00:54.173105
# Unit test for function get_file_lines
def test_get_file_lines():
    ret = get_file_lines('/tmp/foo', True, None)
    assert ret == []
    ret = get_file_lines('/tmp/foo', False, None)
    assert ret == []
    ret = get_file_lines('/tmp/foo', True, '\n')
    assert ret == []
    ret = get_file_lines('/tmp/foo', False, '\n')
    assert ret == []



# Generated at 2022-06-23 02:01:06.052129
# Unit test for function get_file_content
def test_get_file_content():

    # test file exists and is readable
    test_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_file_content')
    content = get_file_content(test_path)
    assert content == 'foo bar baz'

    # test file exists but we can't read it
    # shouldn't fail, but should return default value
    os.chmod(test_path, 0)
    content = get_file_content(test_path)
    assert content is None
    os.chmod(test_path, 0o644)

    # test file doesn't exist
    test_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_file_content_2')

# Generated at 2022-06-23 02:01:14.587472
# Unit test for function get_mount_size
def test_get_mount_size():
    mount_size = get_mount_size('/dev/sda1')
    assert('size_total' in mount_size)
    assert('size_available' in mount_size)
    assert('block_size' in mount_size)
    assert('block_total' in mount_size)
    assert('block_available' in mount_size)
    assert('block_used' in mount_size)
    assert('inode_total' in mount_size)
    assert('inode_available' in mount_size)
    assert('inode_used' in mount_size)



# Generated at 2022-06-23 02:01:24.950845
# Unit test for function get_mount_size
def test_get_mount_size():
    mount_size = get_mount_size('/')
    assert 'size_total' in mount_size.keys()
    assert 'size_available' in mount_size.keys()
    assert 'block_size' in mount_size.keys()
    assert 'block_total' in mount_size.keys()
    assert 'block_available' in mount_size.keys()
    assert 'block_used' in mount_size.keys()
    assert 'inode_total' in mount_size.keys()
    assert 'inode_available' in mount_size.keys()
    assert 'inode_used' in mount_size.keys()
    assert mount_size['block_total'] > 0
    assert mount_size['inode_total'] > 0

# Generated at 2022-06-23 02:01:30.231007
# Unit test for function get_file_content
def test_get_file_content():
    test_cases = dict()
    test_cases["existing_file"] = dict()
    test_cases["existing_file"]["path"] = "/etc/hosts"
    test_cases["existing_file"]["expected_content"] = u'127.0.0.1\tlocalhost'

    test_cases["nonexistent_file"] = dict()
    test_cases["nonexistent_file"]["path"] = "/some/non-existent/path/some-file"
    test_cases["nonexistent_file"]["expected_content"] = None

    test_cases["file_with_no_contents"] = dict()
    test_cases["file_with_no_contents"]["path"] = "/dev/null"

# Generated at 2022-06-23 02:01:39.305486
# Unit test for function get_file_content
def test_get_file_content():
    # Test empty file
    empty_file = '/etc/group'
    if os.path.exists(empty_file) and os.access(empty_file, os.R_OK):
        empty_file = get_file_content(empty_file, default='')
        assert empty_file == '', 'The file %s should be empty' % empty_file

    # Test non-existent file
    non_existent_file = '/no_exist_file'
    non_existent_file = get_file_content(non_existent_file, default='')
    assert non_existent_file == '', 'The file %s should be empty' % non_existent_file

    # Test non-readable file
    non_readable_file = '/etc/shadow'

# Generated at 2022-06-23 02:01:41.312752
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/proc/cpuinfo', default='', strip=True)


# Generated at 2022-06-23 02:01:44.389843
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(os.path.join(os.path.dirname(__file__), 'test_utils', 'test_get_file_contents.txt')) == 'this is a test file'
    assert get_file_content(os.path.join(os.path.dirname(__file__), 'test_utils', 'test_get_file_contents.txt'), 'default') == 'this is a test file'
    assert get_file_content('/dev/null', 'default') == 'default'



# Generated at 2022-06-23 02:01:53.263087
# Unit test for function get_file_content
def test_get_file_content():
    try:
        fp = open("/tmp/test_file", "w")
        fp.write("test data")
        fp.close()
        expected_data = "test data"
        assert get_file_content("/tmp/test_file") == expected_data
        os.unlink("/tmp/test_file")
    except IOError:
        pass



# Generated at 2022-06-23 02:02:01.374868
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/proc/modules') == ['ansible_test 9664 0 - Live 0xffffffffa0e00000',
                                               'binfmt_misc 20576 1 - Live 0xffffffffa0da0000']
    assert get_file_lines('/proc/modules', strip=False) == ['ansible_test 9664 0 - Live 0xffffffffa0e00000\n',
                                                            'binfmt_misc 20576 1 - Live 0xffffffffa0da0000\n']
    assert get_file_lines('/proc/modules', line_sep='\n') == ['ansible_test 9664 0 - Live 0xffffffffa0e00000',
                                                              'binfmt_misc 20576 1 - Live 0xffffffffa0da0000']
    assert get_file_lines

# Generated at 2022-06-23 02:02:10.132667
# Unit test for function get_file_lines
def test_get_file_lines():
    content = """aaa
bbb
\n

ccc
ddd
"""
    assert get_file_lines('/tmp/not_exist', line_sep=None) == []
    assert get_file_lines('/tmp/not_exist', line_sep='\n') == []
    assert get_file_lines('/tmp/not_exist', line_sep='\r') == []
    assert get_file_lines('/tmp/not_exist', line_sep='\r\n') == []

    gfl = get_file_lines

    with open('/tmp/file', 'wb') as f:
        f.write(content)
    assert gfl('/tmp/file', line_sep='\n') == content.split('\n')

# Generated at 2022-06-23 02:02:20.168515
# Unit test for function get_mount_size
def test_get_mount_size():
    import tempfile
    # Create a temporary file and a directory
    tmp_file = tempfile.NamedTemporaryFile()
    tmp_dir = tempfile.mkdtemp()
    # Create an empty dictionary
    result = {}
    # Retrieve information about the temporary file
    result = get_mount_size(tmp_file.name)
    # Check if the key size_total exists or not
    assert result.has_key('size_total')
    # Check if the key size_available exists or not
    assert result.has_key('size_available')
    # Retrieve information about the temporary directory
    result = get_mount_size(tmp_dir)
    # Check if the key size_total exists or not
    assert result.has_key('size_total')
    # Check if the key size_available exists or not
    assert result

# Generated at 2022-06-23 02:02:23.005210
# Unit test for function get_mount_size
def test_get_mount_size():
    import tempfile
    tmp = tempfile.mkdtemp()
    result = get_mount_size(tmp)
    assert isinstance(result, dict)
    assert result['size_total'] > 0


# Generated at 2022-06-23 02:02:33.853111
# Unit test for function get_mount_size
def test_get_mount_size():
    mount_size = get_mount_size('/')
    assert 'size_total' in mount_size, 'total size key not found'
    assert 'size_available' in mount_size, 'available size key not found'
    assert 'block_size' in mount_size, 'block size key not found'
    assert 'block_total' in mount_size, 'total blocks key not found'
    assert 'block_available' in mount_size, 'available blocks key not found'
    assert 'block_used' in mount_size, 'used blocks key not found'
    assert 'inode_total' in mount_size, 'total inodes key not found'
    assert 'inode_available' in mount_size, 'available inodes key not found'
    assert 'inode_used' in mount_size, 'used inodes key not found'

# Generated at 2022-06-23 02:02:44.893525
# Unit test for function get_file_content
def test_get_file_content():
    # pylint: disable=E0602
    mock = __import__('sys').modules['ansible.module_utils.basic.mock']
    if mock is not None:
        mock.mock_module_application('ansible.module_utils', 'system')
        mock.mock_module_application('ansible.module_utils', 'os')

        # Mock os module
        mock_os = MagicMock(spec=os)
        mock_os.path.exists.return_value = True
        mock_os.path.isfile.return_value = True
        mock_os.path.isdir.return_value = False
        mock_os.path.islink.return_value = False
        mock_os.access.return_value = True

        # Mock os.statvfs module
        mock_statvfs

# Generated at 2022-06-23 02:02:51.192115
# Unit test for function get_file_content
def test_get_file_content():
    # Get the content of /etc/os-release
    assert (get_file_content('/etc/os-release'))
    # Get the content of /invalid/path
    assert (not get_file_content('/invalid/path'))



# Generated at 2022-06-23 02:03:01.265521
# Unit test for function get_mount_size
def test_get_mount_size():
    # mount point
    mount_point = '/'
    # get_mount_size
    mount_size = get_mount_size(mount_point)
    # Example:
    #  mount_size = {'block_used': 478709504,
    #                'block_size': 4096,
    #                'block_available': 145578805,
    #                'size_available': 719482859520,
    #                'inode_available': 252503687,
    #                'block_total': 292855889,
    #                'inode_used': 294517344,
    #                'size_total': 954760622080,
    #                'inode_total': 547021032}
    assert mount_size['block_used'] == 478709504
    assert mount_

# Generated at 2022-06-23 02:03:12.996936
# Unit test for function get_mount_size
def test_get_mount_size():
    from os.path import join
    import tempfile
    import platform

    tempdir = tempfile.mkdtemp()
    mountpoint =  join(tempdir, "mountpoint")
    tmpfs_mountpoint = join(tempdir, "tmpfs_mountpoint")
    mount_options = "-t tmpfs -o nr_inodes=100000,size=100k"

    # On some platforms (e.g. F20) there is no /sys/fs/cgroup,
    # so we can't test cgroups size.
    if platform.release() == "3.11.5-301.fc20.x86_64":
        skip_cgroup_test = True
    else:
        skip_cgroup_test = False


# Generated at 2022-06-23 02:03:24.556332
# Unit test for function get_file_content
def test_get_file_content():
    from os import mkdir, makedirs
    from tempfile import mkdtemp, mkstemp
    from shutil import rmtree

    # Create a temporary directory
    tmpdir = mkdtemp()
    mkdir(tmpdir + '/empty_file')
    mkstemp(tmpdir + '/file_with_contents')

    fd = open(tmpdir + '/file_with_contents', 'w')
    fd.write('test_string')
    fd.close()

    data = get_file_content(tmpdir + '/empty_file', default='empty_file')
    assert data == 'empty_file'

    data = get_file_content(tmpdir + '/file_with_contents')
    assert data == 'test_string'


# Generated at 2022-06-23 02:03:37.376107
# Unit test for function get_file_content
def test_get_file_content():
    """
    Test get_file_content function with different parameters
    """
    import os
    import tempfile

    # Test reading a valid file
    file_path = os.path.join(tempfile.gettempdir(), "anstest")
    file_content = "test string\n"
    with open(file_path, 'w') as f:
        f.write(file_content)
    assert get_file_content(file_path) == file_content

    # Test reading a valid file with strips = false
    with open(file_path, 'w') as f:
        f.write(file_content)
    assert get_file_content(file_path, strip=False) == file_content

    # Test reading a valid file with strips = true
    file_content = "    " + file_content + "    "

# Generated at 2022-06-23 02:03:40.442078
# Unit test for function get_file_lines
def test_get_file_lines():
    assert ['line 1', 'line 2', 'line 3'] == get_file_lines('test_file', line_sep='\n')
    assert ['line 1', 'line 2', 'line 3'] == get_file_lines('test_file', line_sep='\r\n')
    assert ['line 1', 'line 2', 'line 3'] == get_file_lines('test_file', line_sep='\r')
    assert ['line 1\nline 2\nline 3'] == get_file_lines('test_file', line_sep='m')


# Generated at 2022-06-23 02:03:43.441692
# Unit test for function get_file_content
def test_get_file_content():
    content = get_file_content('/proc/cmdline')
    assert (type(content) == str)


if __name__ == "__main__":
    import sys
    import unittest
    sys.exit(unittest.main())

# Generated at 2022-06-23 02:03:55.383204
# Unit test for function get_mount_size
def test_get_mount_size():
    mount_size = get_mount_size('/tmp')
    assert isinstance(mount_size, dict)
    assert isinstance(mount_size['block_total'], int)
    assert isinstance(mount_size['block_available'], int)
    assert isinstance(mount_size['block_used'], int)
    assert isinstance(mount_size['inode_total'], int)
    assert isinstance(mount_size['inode_available'], int)
    assert isinstance(mount_size['inode_used'], int)


# Generated at 2022-06-23 02:04:06.259721
# Unit test for function get_file_content
def test_get_file_content():
    '''Unit test for function get_file_content'''

    # return 'None' for non-existing file
    assert get_file_content('/tmp/doesnotexist') is None
    # return expected value for existing file
    with open('/tmp/get_file_content_test_file', 'w') as f:
        f.write('get_file_content test file')
    contents = get_file_content('/tmp/get_file_content_test_file')
    assert contents == 'get_file_content test file'

    # test stripping of contents
    contents = get_file_content('/tmp/get_file_content_test_file', strip=False)
    assert contents == 'get_file_content test file\n'

    # test default value

# Generated at 2022-06-23 02:04:17.529739
# Unit test for function get_file_content
def test_get_file_content():
    path = './test_file.txt'
    default = 'default'
    test_file = ''
    for i in range(0,1000):
        test_file += str(i) + " "

    test_file = test_file[:-1]

    fd = open('./test_file.txt', 'w')
    fd.write(test_file)
    fd.close()

    result = get_file_content(path, default)
    assert result == test_file

    result = get_file_content(path, default, strip=False)
    assert len(result) == len(test_file)
    assert result[0] == ' '

    os.remove(path)


# Generated at 2022-06-23 02:04:29.672093
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/shells', strip=False) == ['# /etc/shells: valid login shells', '/bin/sh', '/bin/bash']
    assert get_file_lines('/etc/shells') == ['# /etc/shells: valid login shells', '/bin/sh', '/bin/bash']
    assert get_file_lines('/etc/shells', line_sep='\n') == ['# /etc/shells: valid login shells', '/bin/sh', '/bin/bash']
    assert get_file_lines('/etc/shells', line_sep='(:|\n)') == ['# /etc/shells', 'valid login shells', '/bin/sh', '/bin/bash']

# Generated at 2022-06-23 02:04:41.411989
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/hosts') == ['127.0.0.1 localhost']
    assert get_file_lines('/etc/hosts', strip=False) == ['127.0.0.1 localhost\n']
    assert get_file_lines('/etc/hosts', line_sep='\n') == ['127.0.0.1 localhost']
    assert get_file_lines('/etc/hosts', strip=False, line_sep='\n') == ['127.0.0.1 localhost']
    assert get_file_lines('/etc/hosts', line_sep=':') == ['127.0.0.1 localhost']

# Generated at 2022-06-23 02:04:48.072777
# Unit test for function get_mount_size
def test_get_mount_size():
    def _test_get_mount_size(mountpoint, expected):
        ret = get_mount_size(mountpoint)
        assert expected == ret

    mountpoint = '/'
    expected = {
        'size_total': 17475039232,
        'size_available': 12142092288,
        'block_size': 4096,
        'block_total': 4298737,
        'block_available': 2908312,
        'block_used': 1390406,
        'inode_total': 1048576,
        'inode_available': 1030270,
        'inode_used': 18306,
    }

    _test_get_mount_size(mountpoint, expected)

# Generated at 2022-06-23 02:04:58.441798
# Unit test for function get_file_lines
def test_get_file_lines():
    import tempfile
    tmp_path = tempfile.NamedTemporaryFile(delete=True)
    tmp_path.write('foo\nbar\n')
    tmp_path.flush()
    assert get_file_lines(tmp_path.name) == ['foo','bar']
    tmp_path.close()

    tmp_path = tempfile.NamedTemporaryFile(delete=True)
    tmp_path.write('foo\nbar')
    tmp_path.flush()
    assert get_file_lines(tmp_path.name) == ['foo','bar']
    tmp_path.close()

    tmp_path = tempfile.NamedTemporaryFile(delete=True)
    tmp_path.write('foo\nbar')
    tmp_path.flush()

# Generated at 2022-06-23 02:04:59.373926
# Unit test for function get_file_content
def test_get_file_content():
    pass

# Generated at 2022-06-23 02:05:10.895328
# Unit test for function get_file_content
def test_get_file_content():
    ok_path = "/usr/local/bin/ansible-doc"
    noexist_path = "/usr/local/bin/not-present"
    noroot_path = "/root/.ssh/id_rsa"

    assert(get_file_content(ok_path) != None)
    assert(get_file_content(ok_path, False) != None)
    assert(get_file_content(ok_path, True) != None)
    assert(get_file_content(ok_path, False, False) != None)
    assert(get_file_content(ok_path, True, False) != None)

    assert(get_file_content(noexist_path) == None)
    assert(get_file_content(noexist_path, False) == None)

# Generated at 2022-06-23 02:05:20.197843
# Unit test for function get_file_content
def test_get_file_content():
    # Check empty parameter
    assert get_file_content('') is None
    # Check empty file
    assert get_file_content('/tmp/') is None
    # Check real file
    open('/tmp/test_file_content', "w").close()
    assert get_file_content('/tmp/test_file_content') == ''
    os.remove('/tmp/test_file_content')
    # Check file with content
    result = get_file_content('/etc/group')
    assert result.count("\n") == 12
    assert result.count("\n") == result.count("\n")
    # Check file with content and parameter
    result = get_file_content('/etc/group', default="default")
    assert result.count("\n") == 12

# Generated at 2022-06-23 02:05:23.100527
# Unit test for function get_file_content
def test_get_file_content():
    # Create a test file
    data = "foo\nbar\n"
    fh = open('/tmp/foo', 'w')
    fh.write(data)
    fh.close()

    assert get_file_content('/tmp/foo') == data

# Generated at 2022-06-23 02:05:26.090132
# Unit test for function get_mount_size
def test_get_mount_size():
    test_mount_size = get_mount_size('/')
    assert(test_mount_size['block_size'] == 4096)
    assert(test_mount_size['size_total'] == 1400996096)

# Generated at 2022-06-23 02:05:28.569045
# Unit test for function get_mount_size
def test_get_mount_size():
    assert get_mount_size('/home/packt/ansible') == {}



# Generated at 2022-06-23 02:05:39.888393
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content("/etc/passwd") is not None
    assert get_file_content("/etc/nonexistent", default=None) is None
    assert get_file_content("/etc/nonexistent", default="default") == "default"
    assert get_file_content("/etc/passwd", strip=False) is not None
    assert get_file_content("/etc/passwd", strip=True) is not None

# Generated at 2022-06-23 02:05:50.027920
# Unit test for function get_mount_size
def test_get_mount_size():
    stats = get_mount_size('/')
    assert type(stats) == dict

    if os.path.ismount('/'):
        assert type(stats['size_total']) == int
        assert type(stats['size_available']) == int

        assert type(stats['block_size']) == int
        assert type(stats['block_total']) == int
        assert type(stats['block_available']) == int
        assert type(stats['block_used']) == int

        assert type(stats['inode_total']) == int
        assert type(stats['inode_available']) == int
        assert type(stats['inode_used']) == int
    else:
        assert stats == {}

# Generated at 2022-06-23 02:05:57.011726
# Unit test for function get_file_content
def test_get_file_content():
    # Test for existing file
    assert get_file_content('/etc/passwd') is not None
    assert get_file_content('/dev/null') == ''
    assert get_file_content('/dev/random') is not None
    assert get_file_content('/dev/random', '') == ''
    assert get_file_content('/dev/random', None) is None
    assert get_file_content('/dev/random', '') == ''
    assert get_file_content('/nonexistingfile') is None
    assert get_file_content('/etc/passwd', 123) == 'root:x:0:0:root:/root:/bin/bash\n'

# Generated at 2022-06-23 02:06:18.764914
# Unit test for function get_file_lines
def test_get_file_lines():
    path = '/etc/hosts'
    assert(get_file_lines(path, line_sep=None))
    assert(get_file_lines('invalid_file', line_sep=None) == [])
    assert(get_file_lines(path, line_sep='\n'))
    assert(get_file_lines(path, line_sep=' '))
    assert(get_file_lines(path, line_sep=''))
    assert(get_file_lines(path, line_sep='\n\n'))

# Generated at 2022-06-23 02:06:21.985454
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd')


# Generated at 2022-06-23 02:06:28.431960
# Unit test for function get_file_content
def test_get_file_content():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
    )

    module.exit_json(msg=get_file_content('/proc/mounts'))


# Generated at 2022-06-23 02:06:40.865200
# Unit test for function get_file_lines
def test_get_file_lines():
    # Create a test file
    test_data = [
            u'line1\n',
            u'line2\r\n',
            u'line3\r\n',
            u'line4\n',
            u'line5\n',
            u'line6\n'
    ]
    path = '/tmp/test_get_file_lines'
    with open(path, 'w') as f:
        for line in test_data:
            f.write(line)

    data = get_file_lines(path)
    assert len(data) == 6
    for i in range(6):
        assert data[i] == test_data[i].strip()

    data = get_file_lines(path, strip=False)
    assert len(data) == 6

# Generated at 2022-06-23 02:06:44.027753
# Unit test for function get_file_content
def test_get_file_content():
    result = get_file_content("/etc/resolv.conf")
    assert result, "get_file_content failed for /etc/resolv.conf"

# Generated at 2022-06-23 02:06:56.033239
# Unit test for function get_mount_size
def test_get_mount_size():
    import sys
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict(
        mount_point=dict(type='str'),
    ))

    mount_size = get_mount_size(module.params['mount_point'])

    assert isinstance(mount_size['size_total'], (int, type(None)))
    assert isinstance(mount_size['size_available'], (int, type(None)))
    assert isinstance(mount_size['block_size'], (int, type(None)))
    assert isinstance(mount_size['block_total'], (int, type(None)))
    assert isinstance(mount_size['block_available'], (int, type(None)))

# Generated at 2022-06-23 02:07:07.198313
# Unit test for function get_file_content
def test_get_file_content():
    from nose.tools import assert_equal

    assert_equal(get_file_content('/etc/hostname'), 'no-hostname')
    assert_equal(get_file_content('/etc/hostname', default='no-hostname'), 'no-hostname')
    assert_equal(get_file_content('/etc/hostname\n'), 'no-hostname')
    assert_equal(get_file_content('/etc/hostname\n'), 'no-hostname')
    assert_equal(get_file_content('/etc/nosuchext', default='no-such'), 'no-such')
    assert_equal(get_file_content('/etc/nosuchfile', default='no-such'), 'no-such')

# Generated at 2022-06-23 02:07:12.289043
# Unit test for function get_file_lines
def test_get_file_lines():
    ''' test get_file_lines'''
    from tempfile import NamedTemporaryFile, mkstemp
    from shutil import rmtree
    from os import remove, chmod
    from stat import S_IRUSR, S_IWUSR, S_IRGRP, S_IWGRP, S_IROTH, S_IWOTH

    # no file
    assert get_file_lines('/no/file') == []
    # file
    with NamedTemporaryFile() as f:
        f.write(b'one\ntwo\nthree\n')
        f.seek(0)
        assert get_file_lines(f.name) == ['one', 'two', 'three']
    # empty file

# Generated at 2022-06-23 02:07:21.478558
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hostname') == 'ubuntu'
    assert get_file_content('/etc/hostname', strip=False) == 'ubuntu\n'
    assert get_file_content('/etc/non_existing_file', default='unit') == 'unit'
    assert get_file_content('/etc/hostname', strip=False) == 'ubuntu\n'
    assert get_file_content('/etc/hosts', default='unit') == '127.0.0.1	localhost\n127.0.1.1	ubuntu\n'


# Generated at 2022-06-23 02:07:32.062710
# Unit test for function get_file_content
def test_get_file_content():
    from tempfile import NamedTemporaryFile
    from shutil import rmtree
    from os import makedirs

    for data_format, data in [('{0}', 'abc'),
                              ('{0}\n', 'def'),
                              ('{0}\n\n{0}\n', 'ghi'),
                              ('{0}\r\n{0}\r\n{0}\r\n', 'jkl')]:
        (fd, tmp_file) = NamedTemporaryFile()
        tmp_file.write(data_format.format(data).encode())
        tmp_file.close()

        result = get_file_content(tmp_file.name)
        assert result == data


# Generated at 2022-06-23 02:07:38.723875
# Unit test for function get_mount_size
def test_get_mount_size():
    mountpoint = '/'
    result = get_mount_size(mountpoint)
    assert result['size_total'] > 0
    assert result['size_available'] > 0
    assert result['block_total'] > 0
    assert result['block_available'] > 0
    assert result['block_used'] >= 0
    assert result['inode_total'] > 0
    assert result['inode_available'] > 0
    assert result['inode_used'] >= 0

# Generated at 2022-06-23 02:07:42.574459
# Unit test for function get_file_content
def test_get_file_content():
    # Test file does not exists
    result1 = get_file_content('/some/non/existant/path/file.txt')
    assert result1 == None
    # Test file does exists
    result2 = get_file_content('/etc/passwd')
    assert result2 != None

# Generated at 2022-06-23 02:07:43.432926
# Unit test for function get_mount_size
def test_get_mount_size():
    ret = get_mount_size("/")
    assert ret['block_total'] > 0


# Generated at 2022-06-23 02:07:55.406338
# Unit test for function get_mount_size
def test_get_mount_size():
    assert os.path.isdir('/etc') == True
    mount_size = get_mount_size('/etc')
    assert isinstance(mount_size,dict)
    assert isinstance(mount_size['size_total'],int)
    assert isinstance(mount_size['size_available'],int)
    assert isinstance(mount_size['block_size'],int)
    assert isinstance(mount_size['block_total'],int)
    assert isinstance(mount_size['block_available'],int)
    assert isinstance(mount_size['block_used'],int)
    assert isinstance(mount_size['inode_total'],int)
    assert isinstance(mount_size['inode_available'],int)
    assert isinstance(mount_size['inode_used'],int)

# Generated at 2022-06-23 02:07:58.959925
# Unit test for function get_file_content
def test_get_file_content():
    path = "/etc/hosts"
    default = "hosts"
    if get_file_content(path) != get_file_content(path, default, strip=False):
        print("Failed test for get_file_content")
        exit(1)


# Generated at 2022-06-23 02:08:05.408271
# Unit test for function get_file_lines
def test_get_file_lines():
    path = '/etc/passwd'
    lines = get_file_lines(path)
    assert len(lines)
    assert 'root:' in lines
    assert 'ansible:' in lines
    lines = get_file_lines(path, strip=False)
    assert len(lines)
    assert 'root:\n' in lines
    assert 'ansible:\n' in lines

# Generated at 2022-06-23 02:08:16.407020
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/bin/ls', line_sep=None) == ['/bin/ls']
    assert get_file_lines('/bin/ls', line_sep='\n') == ['/bin/ls']
    assert get_file_lines('/bin/ls', line_sep='\n\n') == ['/bin/ls']
    assert get_file_lines('/bin//ls', line_sep='l') == ['/bin/', '/s']
    assert get_file_lines('/bin//ls', line_sep='ll') == ['/bin/']
    assert get_file_lines('/bin/ls', line_sep=' s') == ['/bin/', '']

# Generated at 2022-06-23 02:08:25.011053
# Unit test for function get_file_lines
def test_get_file_lines():
    assert ('a\nb\nc\n', ['a', 'b', 'c']) == (get_file_content('test_get_file_lines'), get_file_lines('test_get_file_lines'))
    assert ('a\nb\nc\n', ['a', 'b', 'c']) == (get_file_content('test_get_file_lines', '', False), get_file_lines('test_get_file_lines', False))
    assert ('a\nb\nc\n', ['a', 'b', 'c']) == (get_file_content('test_get_file_lines', '', False), get_file_lines('test_get_file_lines', False, None))

# Generated at 2022-06-23 02:08:31.119888
# Unit test for function get_mount_size
def test_get_mount_size():
    '''Test for get_mount_size function'''

    # Use / as test case
    mountpoint = "/"
    mount_size = get_mount_size(mountpoint)
    if 'size_total' not in mount_size or mount_size['size_total'] == 0:
        return False
    if 'size_available' not in mount_size or mount_size['size_available'] == 0:
        return False
    return True

# Generated at 2022-06-23 02:08:33.858095
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/proc/self/status')

# Generated at 2022-06-23 02:08:43.088571
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '''127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6
'''
    assert get_file_content('/etc/hosts', default='default') == '''127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6
'''

# Generated at 2022-06-23 02:08:54.167952
# Unit test for function get_mount_size
def test_get_mount_size():
    import os
    import tempfile
    tmpdir = tempfile.mkdtemp()
    os.mkdir(os.path.join(tmpdir, 'test1'))
    os.mkdir(os.path.join(tmpdir, 'test2'))
    os.mkdir(os.path.join(tmpdir, 'test3'))
    os.mkdir(os.path.join(tmpdir, 'test4'))

    result = get_mount_size(tmpdir)
    assert result is not None
    assert 'size_total' in result
    assert 'size_available' in result
    assert 'block_size' in result
    assert 'block_total' in result
    assert 'block_available' in result
    assert 'block_used' in result
    assert 'inode_total' in result

# Generated at 2022-06-23 02:09:01.229711
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/hosts', strip=False) == [
        '##',
        '# Host Database',
        '# ',
        '# localhost is used to configure the loopback interface',
        '# when the system is booting.  Do not change this entry.',
        '##',
        '127.0.0.1   localhost',
        '255.255.255.255 broadcasthost',
        '::1             localhost',
    ]


# Generated at 2022-06-23 02:09:09.842451
# Unit test for function get_file_content
def test_get_file_content():
    # Function 'unlocked' returns the correct string
    assert get_file_content("/etc/redhat-release", strip=False) == "CentOS release 6.9 (Final)\n"

    # Function 'locked' returns the correct string
    assert get_file_content("/root/.bash_history", strip=False) == "cat /etc/redhat-release\n"
    assert get_file_content("/root/.bash_history", strip=True) == "cat /etc/redhat-release"
    # Function 'locked' returns the correct string
    assert get_file_content("/root/.bash_history", strip=False) == "cat /etc/redhat-release\n"
    assert get_file_content("/root/.bash_history", strip=True) == "cat /etc/redhat-release"

# Generated at 2022-06-23 02:09:17.368251
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(path='/etc/hostname', default='no-hostname') == 'no-hostname'
    assert get_file_content(path='/etc/hostname', default='no-hostname', strip=False) == 'no-hostname'
    assert get_file_content(path='/etc/hostname', default='no-hostname', strip=True) == 'no-hostname'
    assert get_file_content(path='/etc/hostname', default=None, strip=None) is None
    assert get_file_content(path='/etc/passwd', default=None, strip=None) is None
    assert get_file_content(path='/etc/passwd', default='no-passwd', strip=False) is 'no-passwd'

# Generated at 2022-06-23 02:09:21.174450
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/some/fake/file') is None
    assert get_file_content('/some/fake/file', 1234) == 1234
    assert get_file_content('/etc/hostname') == 'localhost.localdomain'

# Generated at 2022-06-23 02:09:31.984393
# Unit test for function get_file_content
def test_get_file_content():
    gfc = get_file_content
    # Test valid file
    assert gfc("file_content/valid") == "test valid"
    # Test valid file in non-existing directory
    assert gfc("file_content/foo/valid") == None
    # Test non-existing file
    assert gfc("file_content/invalid") == None
    # Test invalid file in non-existing directory
    assert gfc("file_content/foo/invalid") == None
    # Test invalid file with default value
    assert gfc("file_content/invalid", "foo") == "foo"
    # Test valid file with custom default value
    assert gfc("file_content/valid", "foo") == "test valid"
    # Test valid file without stripping of newline

# Generated at 2022-06-23 02:09:41.340166
# Unit test for function get_mount_size
def test_get_mount_size():
    mount_size = get_mount_size('/')
    assert 'size_total' in mount_size
    assert 'size_available' in mount_size
    assert 'block_size' in mount_size
    assert 'block_total' in mount_size
    assert 'block_available' in mount_size
    assert 'block_used' in mount_size
    assert 'inode_total' in mount_size
    assert 'inode_available' in mount_size
    assert 'inode_used' in mount_size

    # We cannot check values here, as they may change on different systems
    # depending on available space.

# Generated at 2022-06-23 02:09:48.887942
# Unit test for function get_file_content
def test_get_file_content():
    test_path = "_file_content_test.txt"

    with open(test_path, "w") as f:
        f.write("test line\n")

    assert get_file_content(test_path, strip=True) == "test line"
    assert get_file_content(test_path, strip=False) == "test line\n"
    assert get_file_content("/path/does/not/really/exist", "default") == "default"

    os.remove(test_path)


# Generated at 2022-06-23 02:09:49.801513
# Unit test for function get_mount_size
def test_get_mount_size():
    mount_size = get_mount_size('/')
    assert type(mount_size) is dict

# Generated at 2022-06-23 02:09:51.709999
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/proc/sys/vm/swappiness', default='15') == '15'

# Generated at 2022-06-23 02:10:02.875739
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/tmp/does_not_exist', False) == []

    os.system('echo "a" > /tmp/test_get_file_lines')
    assert get_file_lines('/tmp/test_get_file_lines', False) == ['a']

    os.system('echo "a" >> /tmp/test_get_file_lines')
    assert get_file_lines('/tmp/test_get_file_lines', False) == ['a', 'a']

    os.system('echo "a" > /tmp/test_get_file_lines')
    assert get_file_lines('/tmp/test_get_file_lines', True) == ['a']

    os.system('echo "a" >> /tmp/test_get_file_lines')

# Generated at 2022-06-23 02:10:13.009328
# Unit test for function get_file_lines
def test_get_file_lines():
    # get list of lines from file
    assert get_file_lines('/etc/hosts') == ['127.0.0.1 localhost localhost.localdomain localhost4 localhost4.localdomain4', '::1 localhost localhost.localdomain localhost6 localhost6.localdomain6'], 'Fail to get list of lines from files.'
    assert get_file_lines('/etc/hosts', strip=False) == ['127.0.0.1 localhost localhost.localdomain localhost4 localhost4.localdomain4\n', '::1 localhost localhost.localdomain localhost6 localhost6.localdomain6'], 'Fail to get list of lines from files without striping.'

# Generated at 2022-06-23 02:10:19.367522
# Unit test for function get_mount_size

# Generated at 2022-06-23 02:10:31.042359
# Unit test for function get_file_content
def test_get_file_content():
    # test a simple file
    result = get_file_content('/tmp/does_not_exist', default=True)
    assert result is True

    # test a simple file
    result = get_file_content('/tmp/does_not_exist', default=False)
    assert result is False

    # test a simple file
    result = get_file_content('/tmp/does_not_exist')
    assert result is None

    # test a simple file
    result = get_file_content('/tmp/does_not_exist', strip=False)
    assert result is None

    # test a simple file
    result = get_file_content('/tmp/does_not_exist', default=None, strip=False)
    assert result is None

    # test a simple file

# Generated at 2022-06-23 02:10:42.609971
# Unit test for function get_mount_size
def test_get_mount_size():

    def create_test_file(file_name):
        with open(file_name, 'w') as f:
            f.write('Make sure that the file is larger than 1 block')
        return file_name

    import tempfile
    temp_dir = tempfile.mkdtemp()

    test_files = [create_test_file(temp_dir+'/'+file_name) for file_name in ['file1', 'file2', 'file3']]

    mount_size = get_mount_size(temp_dir)
    assert mount_size.get('block_size') >= 4096, 'block size should be 4096 or larger'
    assert mount_size.get('size_total') >= mount_size.get('size_available'), 'size_total is larger than size_available'
