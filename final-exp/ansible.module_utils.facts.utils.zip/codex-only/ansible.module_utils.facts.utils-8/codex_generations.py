

# Generated at 2022-06-23 02:00:39.670260
# Unit test for function get_mount_size
def test_get_mount_size():
    import tempfile
    tmpdir = tempfile.mkdtemp()
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    ret = get_mount_size(tmpdir)
    assert tmpdir in ret, 'Get mount size failed for: %s' % tmpdir
    assert tmpfile.name in ret, 'Get mount size failed for: %s' % tmpfile.name
    tmpfile.close()



# Generated at 2022-06-23 02:00:44.193388
# Unit test for function get_file_lines
def test_get_file_lines():

    ret = get_file_lines('/etc/group', strip=True, line_sep=':')

    assert isinstance(ret, list)
    assert len(ret) > 0
    assert isinstance(ret[0], str)
    assert ret[0].find(':') > 0


# Generated at 2022-06-23 02:00:55.705861
# Unit test for function get_file_lines
def test_get_file_lines():
    import pytest
    import shutil
    import tempfile
    import uuid

    n = uuid.uuid4()


# Generated at 2022-06-23 02:00:57.007585
# Unit test for function get_mount_size
def test_get_mount_size():
    assert get_mount_size('/')
    assert get_mount_size('/etc')

# Generated at 2022-06-23 02:01:09.166422
# Unit test for function get_file_lines

# Generated at 2022-06-23 02:01:12.588014
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines(__file__) == get_file_content(__file__).splitlines()
    assert get_file_lines(__file__, strip=False) == get_file_content(__file__, strip=False).splitlines()
    assert get_file_lines(__file__, line_sep='\n') == get_file_content(__file__).split('\n')
    assert get_file_lines(__file__, strip=False, line_sep='\n') == get_file_content(__file__, strip=False).split('\n')


# Generated at 2022-06-23 02:01:26.716854
# Unit test for function get_file_content
def test_get_file_content():
    from tempfile import NamedTemporaryFile
    from shutil import rmtree

    # Test a file containing "abcde"
    temp_file = NamedTemporaryFile(delete=False)
    temp_file.write("abcde")
    temp_file.close()

    assert get_file_content(temp_file.name, default="12345") == "abcde"

    os.unlink(temp_file.name)

    # Test a file containing "abcde\n"
    temp_file = NamedTemporaryFile(delete=False)
    temp_file.write("abcde\n")
    temp_file.close()

    assert get_file_content(temp_file.name, default="12345") == "abcde"

    os.unlink(temp_file.name)

    # Test a file containing "abcde\

# Generated at 2022-06-23 02:01:28.143406
# Unit test for function get_file_content
def test_get_file_content():
    get_file_content(path='/non/existent/file')

# Generated at 2022-06-23 02:01:34.865693
# Unit test for function get_file_content
def test_get_file_content():
    # Test file
    test_file_name = "/tmp/test_file"
    test_file_content = "test file content"
    # Create a small test file
    with open(test_file_name, 'w') as f:
        f.write(test_file_content)

    value = get_file_content(test_file_name)
    assert value == test_file_content
    os.remove(test_file_name)

# Generated at 2022-06-23 02:01:45.993182
# Unit test for function get_file_content
def test_get_file_content():
    '''
    :returns: Test results for function get_file_content.
    '''
    import tempfile

    # Test for non existent file.
    path = '/tmp/doesntexist'
    data = get_file_content(path)
    assert data is None, 'Data: %s' % data

    # Test for unreadable file.
    path = '/etc/shadow'
    data = get_file_content(path)
    assert data is None, 'Data: %s' % data

    # Test for readable/writeable file.
    with tempfile.NamedTemporaryFile() as f:
        path = f.name
        f.write('one two three\n')
        f.flush()
        data = get_file_content(path)


# Generated at 2022-06-23 02:01:48.578257
# Unit test for function get_mount_size
def test_get_mount_size():
    assert get_mount_size('/')



# Generated at 2022-06-23 02:01:58.873582
# Unit test for function get_file_content
def test_get_file_content():

    assert get_file_content('/tmp/does_not_exist') == None
    assert get_file_content('/tmp/does_not_exist', 'default') == 'default'
    assert get_file_content('/tmp/does_exist', 'default') == 'default'

    assert get_file_content('/tmp') == None
    assert get_file_content('/tmp', 'default') == 'default'

    assert get_file_content('/') == None
    assert get_file_content('/', 'default') == 'default'

    assert get_file_content('/etc/passwd') == 'default'
    assert get_file_content('/etc/passwd', 'default') == 'default'

# Generated at 2022-06-23 02:02:03.453762
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/nonexistent') == None
    assert get_file_content('/etc/hostname') == 'localhost'


# Generated at 2022-06-23 02:02:14.255736
# Unit test for function get_file_content
def test_get_file_content():

    # create read-only file
    f = open('/tmp/somefile', 'w')
    f.write('''Hello World,

This is a file.
It has multiple lines.
And some spaces.

   ''')
    f.close()
    os.chmod('/tmp/somefile', 0o444)
    assert get_file_content('/tmp/somefile', default='foo') == '''Hello World,

This is a file.
It has multiple lines.
And some spaces.

   '''
    assert get_file_content('/tmp/somefile', default='foo', strip=False) == '''Hello World,

This is a file.
It has multiple lines.
And some spaces.

   '''

# Generated at 2022-06-23 02:02:26.119705
# Unit test for function get_mount_size
def test_get_mount_size():
    assert get_mount_size('/') == {
        'block_available': 870405,
        'block_size': 4096,
        'block_total': 1267876,
        'block_used': 397470,
        'inode_available': 11294760,
        'inode_total': 12202938,
        'inode_used': 908178,
        'size_available': 36502597632,
        'size_total': 51824074752}


# Generated at 2022-06-23 02:02:34.049329
# Unit test for function get_file_lines
def test_get_file_lines():
    data = get_file_lines('/proc/devices')
    assert len(data) == 50
    data = get_file_lines('/proc/devices', line_sep='\n')
    assert len(data) == 50
    data = get_file_lines('/proc/devices', line_sep=' ')
    assert len(data) == 17
    data = get_file_lines('/proc/devices', line_sep='  ')
    assert len(data) == 50
    data = get_file_lines('/proc/devices', line_sep='   ')
    assert len(data) == 50

# Generated at 2022-06-23 02:02:45.039785
# Unit test for function get_mount_size
def test_get_mount_size():
    assert get_mount_size('/boot') == {'inode_used': 16, 'inode_total': 62, 'inode_available': 46, 'size_total': 112579584, 'block_used': 1758, 'block_total': 27684, 'block_available': 2592, 'block_size': 4096, 'size_available': 105929728}
    assert get_mount_size('/') == {'inode_used': 1207, 'inode_total': 63905, 'inode_available': 62698, 'size_total': 53574451200, 'block_used': 1459636, 'block_total': 6656025, 'block_available': 6330387, 'block_size': 4096, 'size_available': 4340109312}
    assert get_mount_size('/mnt')

# Generated at 2022-06-23 02:02:56.557299
# Unit test for function get_file_lines
def test_get_file_lines():
    test_file_path = '/tmp/test_get_file_lines'
    test_content = 'a\nb\nc\n'
    test_result = ['a', 'b', 'c']

    # Create a file containing test content
    test_fp = open(test_file_path, 'w')
    test_fp.write(test_content)
    test_fp.close()

    # Read test file line by line
    ret = get_file_lines(test_file_path, strip=False)

    # Delete the file
    os.remove(test_file_path)

    # Test if result and expected are the same
    if ret != test_result:
        return False

    return True



# Generated at 2022-06-23 02:02:58.699142
# Unit test for function get_file_lines
def test_get_file_lines():
    ret = get_file_lines('/etc/mtab', False)
    for line in ret:
        print(line)

if __name__ == '__main__':
    test_get_file_lines()

# Generated at 2022-06-23 02:03:10.260512
# Unit test for function get_mount_size
def test_get_mount_size():
    mount_size = get_mount_size('/')

    assert mount_size.get('size_total', None) is not None
    assert mount_size.get('size_available', None) is not None
    assert mount_size.get('block_size', None) is not None
    assert mount_size.get('block_total', None) is not None
    assert mount_size.get('block_available', None) is not None
    assert mount_size.get('block_used', None) is not None
    assert mount_size.get('inode_total', None) is not None
    assert mount_size.get('inode_available', None) is not None
    assert mount_size.get('inode_used', None) is not None

# Generated at 2022-06-23 02:03:17.512907
# Unit test for function get_mount_size

# Generated at 2022-06-23 02:03:29.210215
# Unit test for function get_file_lines
def test_get_file_lines():
    os.chdir(os.path.dirname(os.path.realpath(__file__)))
    assert get_file_lines('../test/get_file_lines.test') == ['a', 'b', '']
    assert get_file_lines('../test/get_file_lines.test', strip=False) == ['a', 'b', '   ']
    assert get_file_lines('../test/get_file_lines.test', line_sep='|') == ['a', 'b', '   ']
    assert get_file_lines('../test/get_file_lines.test', line_sep=',') == ['a\nb\n   ']
    assert get_file_lines('../test/nofile') == []

# Generated at 2022-06-23 02:03:35.105724
# Unit test for function get_file_content
def test_get_file_content():
    # test for a file that doesn't exist
    assert get_file_content('/etc/fstabXYZ', default='missing') == 'missing'

    # test for a file that we can't read
    assert get_file_content('/etc/fstabXYZ', default='missing') == 'missing'



# Generated at 2022-06-23 02:03:41.343828
# Unit test for function get_file_content
def test_get_file_content():
    path = 'tests/unit/ansible/test_module_utils/test_get_file_content/test.txt'

    result = get_file_content(path)
    assert result == 'I am a test file.'
    result = get_file_content(path, strip=False)
    assert result == 'I am a test file.\n'
    result = get_file_content('/does/not/exist')
    assert result is None

# Generated at 2022-06-23 02:03:47.681474
# Unit test for function get_mount_size
def test_get_mount_size():
    '''
    Test function get_mount_size on Linux and MacOS systems
    '''
    import platform
    import pprint

    pp = pprint.PrettyPrinter(indent=4)
    pp.pprint(get_mount_size('/'))


# Generated at 2022-06-23 02:03:56.091156
# Unit test for function get_file_content
def test_get_file_content():

    assert get_file_content("/dev/null", default='apple') == 'apple'
    assert get_file_content("/dev/null", strip=False, default='apple') == 'apple'
    assert get_file_content("/dev/null") == None
    assert get_file_content("/dev/zero") == ''
    assert get_file_content("/dev/zero", strip=False) == '\0'
    assert get_file_content("/dev/zero", default='banana') == ''
