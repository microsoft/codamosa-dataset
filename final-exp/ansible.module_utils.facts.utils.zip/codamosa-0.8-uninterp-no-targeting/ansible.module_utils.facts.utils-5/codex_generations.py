

# Generated at 2022-06-20 20:14:20.584528
# Unit test for function get_mount_size
def test_get_mount_size():
    os.statvfs = None
    result = get_mount_size("/tmp")
    assert (result == {})

    os.statvfs = lambda x: x
    result = get_mount_size("/tmp")
    assert (result == {})

    statvfs_result = os.statvfs("/tmp")
    statvfs_result.f_frsize = 1024
    statvfs_result.f_frsize = 1024
    statvfs_result.f_frsize = 1024
    statvfs_result.f_blocks = 100
    statvfs_result.f_bavail = 100
    statvfs_result.f_bsize = 1024
    statvfs_result.f_blocks = 1024
    statvfs_result.f_bavail = 1024
    statvfs

# Generated at 2022-06-20 20:14:29.408389
# Unit test for function get_file_content
def test_get_file_content():
    from tempfile import gettempdir
    from os.path import join
    from random import choice
    from string import ascii_letters
    from tempfile import mkstemp
    from os import close, remove

    fd, fname = mkstemp(dir=gettempdir())
    close(fd)

    write_this = [choice(ascii_letters) for i in range(100)]
    write_this = ''.join(write_this) + '\n'

    with open(fname, 'a') as f:
        f.writelines(write_this)

    try:
        assert write_this == get_file_content(fname)
    except:
        raise

    remove(fname)



# Generated at 2022-06-20 20:14:34.938541
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/dev/null', default='test') == 'test'
    assert get_file_content('/dev/stdout') == '\n'
    assert get_file_content('/dev/stdout', strip=False) == '\n'


# Generated at 2022-06-20 20:14:46.859013
# Unit test for function get_file_content
def test_get_file_content():
    assert 'full' == get_file_content('/proc/sys/kernel/hostname')

    # Test whether a filename with a space in it works
    assert 'full' == get_file_content('/proc/sys/kernel/hostname')

    # Test whether a file with a new line in it works
    assert 'full\n' == get_file_content('/proc/sys/kernel/hostname', strip=False)

    # Test a non-existant file returns the default value
    assert None == get_file_content('/proc/sys/kernel/hostname_bad')

    # Test a readable file with a 0 length returns the default value
    assert None == get_file_content('/proc/self/cmdline')

    # Test a unreadable file returns the default value (assuming you don't run this as root)

# Generated at 2022-06-20 20:14:47.950982
# Unit test for function get_file_content
def test_get_file_content():
    # TODO: Add test cases
    return

# Generated at 2022-06-20 20:14:51.077404
# Unit test for function get_mount_size
def test_get_mount_size():
    assert os.path.exists("/etc")
    assert os.access("/etc", os.R_OK)
    assert get_mount_size("/etc")

# Generated at 2022-06-20 20:14:58.378008
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('test/test_list.txt') == ['test1', 'test2', 'test3', 'test4', 'test5']
    assert get_file_lines('test/test_list.txt', line_sep='\r') == ['test1', 'test2', 'test3', 'test4', 'test5']
    assert get_file_lines(path='test/test_list.txt', line_sep='\n') == ['test1', 'test2', 'test3', 'test4', 'test5']
    assert get_file_lines('test/test_list.txt', line_sep='\r\n') == ['test1', 'test2', 'test3', 'test4', 'test5']


# Generated at 2022-06-20 20:15:01.664661
# Unit test for function get_mount_size
def test_get_mount_size():
    ''' test_get_mount_size '''
    assert 'size_total' in get_mount_size('/')

# Generated at 2022-06-20 20:15:07.493013
# Unit test for function get_mount_size
def test_get_mount_size():
    data = get_mount_size('/')
    assert data['size_total']
    assert data['size_available']
    assert data['block_size']
    assert data['block_total']
    assert data['block_available']
    assert data['block_used']
    assert data['inode_total']
    assert data['inode_available']
    assert data['inode_used']

# Generated at 2022-06-20 20:15:15.765906
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/dev/random') is None
    assert get_file_content('/dev/random', default='False') is 'False'
    assert isinstance(get_file_content('/etc/resolv.conf'), str)
    assert not isinstance(get_file_content('/etc/resolv.conf'), unicode)

    # Test Unicode support
    assert isinstance(get_file_content('/etc/resolv.conf', decode='utf-8'), unicode)



# Generated at 2022-06-20 20:15:57.718631
# Unit test for function get_mount_size
def test_get_mount_size():
    # Error: test a path that does not exist
    mount_size = get_mount_size('/unknown')
    assert mount_size == {}, "Return should be an empty dict"

    # Test a valid path
    mount_size = get_mount_size('/')
    assert 'size_total' in mount_size, "size_total should be in the dict"
    assert 'size_available' in mount_size, "size_available should be in the dict"
    assert 'block_size' in mount_size, "block_size should be in the dict"
    assert 'block_total' in mount_size, "block_total should be in the dict"
    assert 'block_available' in mount_size, "block_available should be in the dict"

# Generated at 2022-06-20 20:16:09.669787
# Unit test for function get_file_lines
def test_get_file_lines():
    '''Test function get_file_lines'''

    data_file = './test_data.txt'
    test_data = '\n'.join(['%d' % n for n in range(1, 10)]) + '\n'
    ofile = open(data_file, 'w')
    ofile.write(test_data)
    ofile.close()

    assert test_data.splitlines() == get_file_lines(data_file)
    assert test_data.splitlines() == get_file_lines(data_file, line_sep='\n')

    # test line_sep only works on trailing line separator
    assert [test_data] == get_file_lines(data_file, line_sep='12\n')

    # test other line_seps
    assert test_data

# Generated at 2022-06-20 20:16:18.882249
# Unit test for function get_file_lines
def test_get_file_lines():
    import tempfile
    lines = ['foo: bar', 'abc: xyz', 'ansible: awesome']
    path = tempfile.mktemp()
    with open(path, 'w') as f:
        f.write('\n'.join(lines))
        f.write('\n')
    result = get_file_lines(path)
    assert lines == result
    result = get_file_lines(path, line_sep=' ')
    assert len(result) == 1
    assert '\n'.join(lines) == result[0]
    os.unlink(path)

# Generated at 2022-06-20 20:16:23.002390
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/proc/1/stat') is not None, 'unable to get /proc/1/stat'
    assert get_file_content('/dev/null') == '', 'unable to get /dev/null'


# Generated at 2022-06-20 20:16:33.929931
# Unit test for function get_file_lines
def test_get_file_lines():
    test_file_content = '''
line1
line2
line3
line4
line5
'''

    (write_fd, write_path) = tempfile.mkstemp()
    os.write(write_fd, test_file_content)
    os.close(write_fd)

    # test normal split behavior
    result = get_file_lines(write_path)
    assert result == ['line1', 'line2', 'line3', 'line4', 'line5']

    # Test strip behavior
    result = get_file_lines(write_path, strip=False)
    assert result == ['line1', 'line2', 'line3', 'line4', 'line5', '']

    # Test line_sep behavior
    result = get_file_lines(write_path, line_sep='ine')

# Generated at 2022-06-20 20:16:35.956760
# Unit test for function get_mount_size
def test_get_mount_size():
    result = get_mount_size('/')
    assert result['block_used'] < result['block_total']


# Generated at 2022-06-20 20:16:37.638117
# Unit test for function get_mount_size
def test_get_mount_size():
    assert get_mount_size('/nonexistent') == {}

# Generated at 2022-06-20 20:16:46.940845
# Unit test for function get_file_lines
def test_get_file_lines():
    test_file_name = 'test_file_lines'

# Generated at 2022-06-20 20:16:54.477432
# Unit test for function get_file_lines
def test_get_file_lines():
    import tempfile
    test_lines = [':12345:0:99999:7:::', ':23456:0:99999:7:::', ':34567:0:99999:7:::', ':45678:0:99999:7:::']
    test_files = {}
    for test_sep in ('\n', '\n\n', '\n\n\n', ' \n ', '\n ', ' \n', '\n'):
        test_files[test_sep] = tempfile.NamedTemporaryFile()
        test_files[test_sep].write(test_sep.join(test_lines))
        test_files[test_sep].flush()


# Generated at 2022-06-20 20:17:01.206766
# Unit test for function get_file_lines
def test_get_file_lines():
    path = "/tmp/lines"
    f = open(path, "w")
    f.write("line1\nline2\nline3\n")
    f.close()

    lines = get_file_lines(path)
    assert len(lines) == 3 and lines[2] == "line3"

    lines = get_file_lines(path, line_sep="\n")
    assert len(lines) == 3 and lines[2] == "line3"

    lines = get_file_lines(path, line_sep="ine")
    assert len(lines) == 3 and lines[2] == "3"

    lines = get_file_lines(path, line_sep="\n", strip=False)
    assert len(lines) == 3 and lines[0] == "line1\n"

    os

# Generated at 2022-06-20 20:17:14.258462
# Unit test for function get_file_lines
def test_get_file_lines():
    # Test 1:
    # Test with path to file that does not exist
    assert get_file_lines('/nopath') == []

    # Test 2:
    # Test with path to file that exists but that cannot be read
    with open('/tmp/unit_test_pipe', 'w') as f:
        os.fchmod(f.fileno(), 0o500)
        assert get_file_lines('/tmp/unit_test_pipe') == []
        os.remove('/tmp/unit_test_pipe')

    # Test 3:
    # Test with path to file that has no content
    with open('/tmp/unit_test_pipe', 'w') as f:
        os.fchmod(f.fileno(), 0o700)

# Generated at 2022-06-20 20:17:16.372838
# Unit test for function get_mount_size
def test_get_mount_size():
    assert get_mount_size("/") != {}



# Generated at 2022-06-20 20:17:26.841170
# Unit test for function get_mount_size
def test_get_mount_size():
    mount_size = get_mount_size('/')
    assert(type(mount_size) == dict)
    assert(type(mount_size['size_total']) == int)
    assert(type(mount_size['size_available']) == int)
    assert(type(mount_size['block_size']) == int)
    assert(type(mount_size['block_total']) == int)
    assert(type(mount_size['block_available']) == int)
    assert(type(mount_size['block_used']) == int)
    assert(type(mount_size['inode_total']) == int)
    assert(type(mount_size['inode_available']) == int)
    assert(type(mount_size['inode_used']) == int)


# Generated at 2022-06-20 20:17:38.591376
# Unit test for function get_mount_size
def test_get_mount_size():
    path_to_mountpoint = os.path.abspath('.')
    result = get_mount_size(path_to_mountpoint)

    assert isinstance(result, dict), 'Expected a dictionary as result'
    assert 'size_total' in result, 'Expected size_total to be in result'
    assert 'size_available' in result, 'Expected size_available to be in result'
    assert 'block_size' in result, 'Expected block_size to be in result'
    assert 'block_total' in result, 'Expected block_total to be in result'
    assert 'block_available' in result, 'Expected block_available to be in result'
    assert 'block_used' in result, 'Expected block_used to be in result'

# Generated at 2022-06-20 20:17:49.048649
# Unit test for function get_file_content
def test_get_file_content():
    # Test for non-existent file
    assert get_file_content('/nonexistent/path') is None
    # Test for empty file
    with open('/tmp/emptyfile', 'w'):
        pass
    assert get_file_content('/tmp/emptyfile') == ""
    # Test for non-empty file
    with open('/tmp/emptyfile', 'w') as f:
        f.write("test line")
    assert get_file_content('/tmp/emptyfile') == "test line"
    # Test for default value
    assert get_file_content('/nonexistent/path', default='default') == 'default'
    assert get_file_content('/tmp/emptyfile', default='default') == ""

# Generated at 2022-06-20 20:17:59.618582
# Unit test for function get_file_lines
def test_get_file_lines():

    # Test valid path
    content = ['sshd@openssh.service', 'sshd.service']
    with open('/tmp/unit_test_get_file_lines.txt', 'wb') as fdesc:
        fdesc.write('\n'.join(content) + '\n')
    test1 = get_file_lines('/tmp/unit_test_get_file_lines.txt', strip=False)
    assert test1 == content

    # Test invalid path
    content = None
    test2 = get_file_lines('/tmp/invalid_path.txt', strip=False)
    assert test2 == content

    # Test strip
    content = ['sshd@openssh.service', 'sshd.service']

# Generated at 2022-06-20 20:18:10.139774
# Unit test for function get_mount_size
def test_get_mount_size():
    assert get_mount_size('/')['size_total'] > 0
    assert get_mount_size('/')['size_available'] > 0
    assert get_mount_size('/')['block_total'] > 0
    assert get_mount_size('/')['block_available'] > 0
    assert get_mount_size('/')['block_used'] > 0
    assert get_mount_size('/')['inode_total'] > 0
    assert get_mount_size('/')['inode_available'] > 0
    assert get_mount_size('/')['inode_used'] > 0
    assert get_mount_size('/')['block_size'] > 0


# Generated at 2022-06-20 20:18:15.032359
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd', strip=False, line_sep=':')[0] == 'root:x:0:0:root:/root:/bin/bash'
    assert get_file_lines('/etc/passwd', line_sep='\n')[0].split(':')[0] == 'root'


# Generated at 2022-06-20 20:18:26.889458
# Unit test for function get_file_content
def test_get_file_content():
    file_content = get_file_content('/proc/uptime')
    assert file_content

    file_content = get_file_content('/proc/uptime2')
    assert not file_content

    file_content = get_file_content('/proc/uptime2', default='1.00')
    assert file_content == '1.00'

    file_content = get_file_content('/proc/uptime', strip=False)
    assert file_content

    file_content = get_file_content('/proc/uptime', strip="   ")
    assert file_content

    file_content = get_file_content('/proc/uptime', strip='\t')
    assert file_content

    file_content = get_file_content('/proc/uptime', strip='\n')
    assert file

# Generated at 2022-06-20 20:18:33.105514
# Unit test for function get_mount_size
def test_get_mount_size():
    assert get_mount_size('/tmp') == {'block_total': 520032, 'block_available': 308620, 'size_available': 4754454528, 'inode_available': 518683, 'block_used': 211408, 'size_total': 5483622400, 'block_size': 4096, 'inode_used': 2884, 'inode_total': 520032}
    assert get_mount_size('/tmp/mount-not-exist') == {}

# Generated at 2022-06-20 20:18:47.004601
# Unit test for function get_mount_size
def test_get_mount_size():
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-20 20:18:54.953835
# Unit test for function get_mount_size
def test_get_mount_size():
    result = get_mount_size('/')
    assert result['size_total'] > 0
    assert result['size_available'] > 0
    assert result['block_size'] > 0
    assert result['block_total'] > 0
    assert result['block_available'] > 0
    assert result['block_used'] > 0
    assert result['inode_total'] > 0
    assert result['inode_available'] > 0
    assert result['inode_used'] > 0

# Generated at 2022-06-20 20:19:03.310051
# Unit test for function get_file_lines

# Generated at 2022-06-20 20:19:13.705975
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/dev/null') == []
    assert get_file_lines('/dev/null', line_sep=',') == []

    assert get_file_lines('/dev/null', strip=False) == ''
    assert get_file_lines('/dev/null', strip=False, line_sep=',') == ''

    assert get_file_lines('/etc/passwd', line_sep=':')[0] == get_file_lines('/etc/passwd', line_sep=':', strip=False)[0].strip()

    # zfs vfs.zfs.version.spa

# Generated at 2022-06-20 20:19:25.899276
# Unit test for function get_file_content
def test_get_file_content():
    '''test get_file_content'''
    import tempfile
    test_string = 'uX'
    tmp_file = tempfile.mkstemp()[1]
    with open(tmp_file, 'w') as f:
        f.write(test_string)
    assert get_file_content(tmp_file) == test_string
    assert get_file_content(tmp_file, default='hah') == test_string
    assert get_file_content(tmp_file, default='hah', strip=False) == 'uX\n'
    assert get_file_content(tmp_file, strip=False) == 'uX\n'

    with open(tmp_file, 'w') as f:
        f.write(test_string + '\n')

# Generated at 2022-06-20 20:19:35.478234
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == '127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4\n::1         localhost localhost.localdomain localhost6 localhost6.localdomain6'
    assert get_file_content('/etc/fstab', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4\n::1         localhost localhost.localdomain localhost6 localhost6.localdomain6\n'

# Generated at 2022-06-20 20:19:40.182432
# Unit test for function get_file_content
def test_get_file_content():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(supports_check_mode=True)
    assert get_file_content(None, default=None) is None
    assert get_file_content(module.params, default=None) is None
    assert get_file_content(module.params['path'], default=None) is None
    assert get_file_content(module.params['path'], default=None) == 'testing'

# Generated at 2022-06-20 20:19:51.106083
# Unit test for function get_mount_size
def test_get_mount_size():

    import pytest
    import sys

    # Test on an invalid mountpoint
    mount_size = get_mount_size("/invalid-mountpoint")
    assert not mount_size

    # Test on a valid mountpoint
    mount_size = get_mount_size("/")
    assert mount_size
    assert "size_total" in mount_size
    assert "size_available" in mount_size

    assert "block_size" in mount_size
    assert "block_total" in mount_size
    assert "block_available" in mount_size
    assert "block_used" in mount_size

    assert "inode_total" in mount_size
    assert "inode_available" in mount_size
    assert "inode_used" in mount_size

# Generated at 2022-06-20 20:19:55.572874
# Unit test for function get_file_lines
def test_get_file_lines():
    import tempfile
    fd, fname = tempfile.mkstemp(text=True)
    os.write(fd, b'foo\nbar\n')
    os.close(fd)
    assert get_file_lines(fname) == ['foo', 'bar']
    os.unlink(fname)
    assert get_file_lines(fname) == []

# Generated at 2022-06-20 20:20:01.500648
# Unit test for function get_file_lines
def test_get_file_lines():
    path = "/proc/loadavg"
    lines = get_file_lines(path)
    assert len(lines) == 1

    path = "/etc/fstab"
    lines = get_file_lines(path)
    assert len(lines) > 1

    path = "/var/log/ansible/log"
    lines = get_file_lines(path)
    assert len(lines) == 0

    path = "/var/log/ansible/log"
    lines = get_file_lines(path, default=['empty'])
    assert lines == ['empty']

# Unit test function get_file_content

# Generated at 2022-06-20 20:20:14.089229
# Unit test for function get_file_content
def test_get_file_content():
    # Test with file that exists
    assert 'root:x:0:0:root:/root:/bin/bash' == get_file_content('/etc/passwd')

    # Test with file that exists but is a directory
    assert None == get_file_content('/etc')

    # Test with file that exists and is a symlink
    assert None == get_file_content('/usr/bin/python2')

    # Test with file that exists and we can't read
    assert None == get_file_content('/usr/bin/python2')

    # Test with file that does not exist
    assert None == get_file_content('/path/to/file')

    # Test with file that is empty
    assert None == get_file_content('/dev/null')

    # Test with file that is empty but we want it read


# Generated at 2022-06-20 20:20:22.676283
# Unit test for function get_file_lines
def test_get_file_lines():
    file_name = '/tmp/temp_file_for_unittest_get_file_lines.txt'

# Generated at 2022-06-20 20:20:29.838087
# Unit test for function get_mount_size
def test_get_mount_size():
    assert get_mount_size('/') == {'block_available': 540847,
                                   'block_size': 4096,
                                   'block_total': 585719,
                                   'block_used': 44872,
                                   'inode_available': 1412330,
                                   'inode_total': 1468006,
                                   'inode_used': 55676,
                                   'size_available': 22563981312,
                                   'size_total': 24156418048}

# Generated at 2022-06-20 20:20:37.136159
# Unit test for function get_file_content
def test_get_file_content():

    class args_mock(dict):
        pass

    class modulemock:
        def __init__(self):
            self.fail_json = lambda *args, **kwargs: None
            self.params = args_mock()

    args = args_mock()
    args['path'] = '/proc/uptime'
    args['default'] = '12345'
    args['strip'] = True
    module = modulemock()

    assert get_file_content(args, module) == '12345'
    module.params['path'] = 'BadPath'
    assert get_file_content(args, module) == '12345'
    module.params['default'] = ''
    assert get_file_content(args, module) == ''
    module.params['path'] = '/proc/uptime'
    assert get_

# Generated at 2022-06-20 20:20:45.738636
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/tmp/does-not-exist') == []
    assert get_file_lines('/tmp/does-not-exist', strip=False) == []

    # non-existent file, with default
    assert get_file_lines('/tmp/does-not-exist', default=['banana']) == ['banana']

    # non-existent file, with default, with strip
    assert get_file_lines('/tmp/does-not-exist', default=['banana'], strip=False) == ['banana']

    # empty file, with default
    with open('/tmp/empty-file', 'w') as fd:
        fd.write('\n')
    assert get_file_lines('/tmp/empty-file', default=['banana']) == ['banana']

    # empty

# Generated at 2022-06-20 20:20:50.395856
# Unit test for function get_mount_size
def test_get_mount_size():
    # Test 1
    tmp_dir = os.path.dirname(os.tmpnam())  # Get something we can statvfs()
    assert get_mount_size(tmp_dir) == {'inode_total': 118056, 'inode_used': 118048, 'block_available': 89810176, 'block_used': 1186816, 'size_available': 922337199090569216, 'size_total': 922337199090998784, 'inode_available': 8, 'block_size': 4096, 'block_total': 90985216}

    # Test 2 - test statvfs() with a bogus directory
    assert get_mount_size('/bogus_directory') == {}

# Generated at 2022-06-20 20:20:52.719544
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/proc/cpuinfo') is not None
    assert get_file_content('/proc/cpuinfo.none') is None



# Generated at 2022-06-20 20:21:02.487256
# Unit test for function get_file_content
def test_get_file_content():
    data = get_file_content('/etc/fstab')
    assert data

    data = get_file_content('')
    assert not data

    data = get_file_content(None)
    assert not data

    data = get_file_content('/root/foobar')
    assert not data

    data = get_file_content('/tmp/foobar', 'foo')
    assert data == 'foo'

    data = get_file_content('/etc/fstab', 'foo')
    assert data != 'foo'

    # Try to read file without permission
    data = get_file_content('/etc/shadow')
    assert not data

    # Try to read file without permission
    data = get_file_content('/etc/shadow', 'foo')
    assert data == 'foo'

# Generated at 2022-06-20 20:21:04.950131
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd')[0].startswith('root:')
    assert get_file_lines('/nonexistent', default='Nonexistent') == 'Nonexistent'

# Generated at 2022-06-20 20:21:13.187936
# Unit test for function get_file_content
def test_get_file_content():
    this_module = sys.modules[__name__]
    tmp_path = tempfile.mktemp(prefix='unittest_', dir='/tmp')
    tmp_data = "test_data"
    with open(tmp_path, 'w') as tmp_file:
        tmp_file.write(tmp_data)
    result = this_module.get_file_content(tmp_path)
    assert result == tmp_data
    result = this_module.get_file_content(tmp_path, default="default")
    assert result == tmp_data
    os.remove(tmp_path)

# Generated at 2022-06-20 20:21:28.469783
# Unit test for function get_mount_size
def test_get_mount_size():
    import pytest
    from subprocess import Popen, PIPE

    # Test for available mountpoint
    assert get_mount_size('/') != {}

    # Test for unavailable mountpoint
    mount_point = 'tmp'
    cmd = 'mkdir %s' % mount_point
    p = Popen(cmd, stdout=PIPE, stderr=PIPE, shell=True)
    p.wait()
    assert p.returncode == 0
    assert get_mount_size(mount_point) == {}
    cmd = 'rmdir %s' % mount_point
    p = Popen(cmd, stdout=PIPE, stderr=PIPE, shell=True)
    p.wait()
    assert p.returncode == 0

# Generated at 2022-06-20 20:21:32.013992
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/dev/null', default='default') == 'default'
    assert get_file_content('/etc/passwd') == get_file_content(path='/etc/passwd')
    assert get_file_content('/dev/null', strip=False) is None


# Generated at 2022-06-20 20:21:35.772925
# Unit test for function get_file_lines
def test_get_file_lines():
    with open('/tmp/test', 'w') as f:
        f.write('\n')

    assert [] == get_file_lines('/tmp/test')
    os.remove('/tmp/test')

# Generated at 2022-06-20 20:21:45.086366
# Unit test for function get_file_content
def test_get_file_content():

    test_file = '/tmp/test_get_file_content'

    # Test: no such file
    if os.path.exists(test_file):
        os.unlink(test_file)
    result = get_file_content(test_file, default='default')
    assert result == 'default'

    # Test: exists and has content
    with open(test_file, "w") as f:
        f.write('some test content')
    result = get_file_content(test_file, default='default')
    assert result == 'some test content'

    # Test: exists and has no content
    with open(test_file, "w") as f:
        f.truncate()
    result = get_file_content(test_file, default='default')
    assert result == ''

    # Cleanup

# Generated at 2022-06-20 20:21:48.892898
# Unit test for function get_file_content
def test_get_file_content():
    # pylint: disable=redefined-outer-name
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    path = 'test-data/test-file'

    expected = 'This is some test\nfile content'

    result = get_file_content(path)

    if result != expected:
        module.fail_json(path=path, msg='Expected: {0}, got {1}.'.format(expected, result))
    else:
        module.exit_json(path=path, msg='File content as expected ({0}).'.format(result))



# Generated at 2022-06-20 20:21:57.107849
# Unit test for function get_file_content
def test_get_file_content():
    # Test for file that does not exist
    path = 'file_does_not_exist'
    default = 'default'
    strip = True
    result = get_file_content(path, default, strip)
    assert result == default

    # Test for file that exists, but is unreadable
    test_file = '/etc/shadow'
    result = get_file_content(test_file)
    assert result is None

    path = '/etc/fstab'
    result = get_file_content(path)
    assert result is not None

    path = '/etc/fstab'
    result = get_file_content(path, default, False)
    assert result is not None



# Generated at 2022-06-20 20:22:00.387092
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/proc/version', strip=False) == get_file_content('/proc/version', default=None, strip=False)
    assert get_file_content('/proc/this_file_does_not_exist', default=None, strip=False) is None

# unit test for function get_file_lines

# Generated at 2022-06-20 20:22:07.231227
# Unit test for function get_mount_size
def test_get_mount_size():
    mount_size = get_mount_size('/')
    assert 'size_total' in mount_size
    assert 'size_available' in mount_size
    assert 'block_size' in mount_size
    assert 'block_total' in mount_size
    assert 'block_available' in mount_size
    assert 'block_used' in mount_size
    assert 'inode_total' in mount_size
    assert 'inode_available' in mount_size
    assert 'inode_used' in mount_size



# Generated at 2022-06-20 20:22:11.858921
# Unit test for function get_file_content
def test_get_file_content():
    path = '/dev/null'
    assert get_file_content(path, 'default') == 'default'
    assert get_file_content(path, 'default', False) == 'default'
    assert get_file_content(path, None, False) == ''



# Generated at 2022-06-20 20:22:19.075459
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/proc/meminfo') == get_file_content('/proc/meminfo').splitlines()
    assert get_file_lines('/proc/meminfo', line_sep='\n') == get_file_content('/proc/meminfo', line_sep='\n').split('\n')
    assert get_file_lines('/proc/meminfo', line_sep=' ') == get_file_content('/proc/meminfo', line_sep=' ').split(' ')


# Generated at 2022-06-20 20:22:32.690604
# Unit test for function get_file_content
def test_get_file_content():
    path = '/var/log/messages'
    content = get_file_content(path, 'not found')
    assert content is not None, 'Did not return any content'
    assert content.startswith('*****'), 'Did not return the correct content'

    content = get_file_content(path, 'not found', strip=False)
    assert content is not None, 'Did not return any content'
    assert len(content) > 2300000, 'Did not return the correct content'
    assert content.startswith('*****'), 'Did not return the correct content'



# Generated at 2022-06-20 20:22:41.711390
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/proc/version') == ['Linux version 2.6.32-220.23.1.el6.x86_64 (mockbuild@c6b8.bsys.dev.centos.org) (gcc version 4.4.6 20120305 (Red Hat 4.4.6-4) (GCC) ) #1 SMP Fri Jun 22 12:19:21 BST 2012']

# Generated at 2022-06-20 20:22:55.014762
# Unit test for function get_file_content
def test_get_file_content():

    # Test: simple read from /etc/hostname
    correct = 'localhost\n'
    result = get_file_content('/etc/hostname', strip=False)
    assert result == correct

    # Test: reading from non-existing file /nonexisting
    correct = 'default'
    result = get_file_content('/nonexisting', default='default')
    assert result == correct

    # Test: reading from /etc/passwd with a strip
    correct = 'root'
    result = get_file_content('/etc/passwd').split(':')[0]
    assert result == correct

    # Test: reading from /etc/passwd without a strip
    correct = 'root\n'
    result = get_file_content('/etc/passwd', strip=False).split(':')[0]

# Generated at 2022-06-20 20:23:04.675348
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content("/tmp/does_not_exist",
                            default='test-default') == 'test-default'
    # a file that exists
    file = open("/tmp/test.txt", "w")
    file.write("test\n")
    file.close()
    assert get_file_content("/tmp/test.txt", default='test-default') == 'test'
    assert get_file_content("/tmp/test.txt", default='test-default', strip=False) == 'test\n'
    os.remove("/tmp/test.txt")
    assert get_file_content("/tmp/test.txt", default='test-default', strip=False) == 'test-default'

# Generated at 2022-06-20 20:23:11.836752
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/proc/sys/kernel/hostname') == 'localhost'
    assert get_file_content('/proc/sys/kernel/hostname', '') == ''
    assert get_file_content('/proc/sys/kernel/hostname', '$') == '$'
    assert get_file_content('/proc/sys/kernel/hostname', default='$') == '$'

# Generated at 2022-06-20 20:23:20.284577
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') != ''
    assert get_file_content('/etc/hosts') is not None
    assert get_file_content('/etc/hosts') != get_file_content('/root/fake_file')
    assert get_file_content('/root/fake_file') == None
    assert get_file_content('/etc/hosts',strip=False) == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts',default='fake_file',strip=False) != get_file_content('/etc/hosts')
    assert get_file_content('/root/fake_file',default='fake_file') == 'fake_file'

# Generated at 2022-06-20 20:23:24.446287
# Unit test for function get_mount_size
def test_get_mount_size():
    expected_result = {'block_available': 1380225,
                       'block_size': 4096,
                       'block_total': 2588672,
                       'block_used': 2086447,
                       'inode_available': 519237,
                       'inode_total': 656539,
                       'inode_used': 137301,
                       'size_available': 5714953728,
                       'size_total': 1006632960}

    result = get_mount_size('/')

    assert result == expected_result

# Generated at 2022-06-20 20:23:33.721058
# Unit test for function get_file_content
def test_get_file_content():
    def _check(test_content, expected):
        tmpfile = '/tmp/test_get_file_content'
        with open(tmpfile, 'w') as f:
            f.write(test_content)
        assert get_file_content(tmpfile) == expected

    _check('foo', 'foo')
    _check(' foo ', 'foo')
    _check('', '')
    _check(' ', ' ')
    _check(' foo', 'foo')
    _check('foo ', 'foo')
    _check(' foo ', 'foo')
    _check('foo\nbar\n', 'foo\nbar\n')
    _check('\nfoo\nbar\n', '\nfoo\nbar\n')

# Generated at 2022-06-20 20:23:44.153423
# Unit test for function get_file_content
def test_get_file_content():
    test_data = ['something', 'something else', 'more thing', '', 'other thing']
    test_path = '/tmp/test_file_content'
    with open(test_path, 'w') as f:
        f.write('\n'.join(test_data) + '\n')
    assert get_file_content(test_path) == '\n'.join(test_data)
    assert get_file_content(test_path) == '\n'.join(test_data).strip()
    assert get_file_content(test_path, default='test') == '\n'.join(test_data)
    assert get_file_content(test_path, default='test', strip=False) == '\n'.join(test_data) + '\n'

# Generated at 2022-06-20 20:23:52.457474
# Unit test for function get_mount_size
def test_get_mount_size():
    '''
    Test the function get_mount_size.
    '''
    from ansible_collections.community.systemd.tests.unit.compat.mock import patch
    import ansible_collections.community.systemd.plugins.module_utils.systemd.mount

    def test_get_mount_size_base(mock_statvfs_result, mount_size):
        with patch.object(ansible_collections.community.systemd.plugins.module_utils.systemd.mount, 'os') as mock_sys:
            mock_sys.statvfs.return_value = mock_statvfs_result
            result = ansible_collections.community.systemd.plugins.module_utils.systemd.mount.get_mount_size('/mnt')
        assert result == mount_size

    mock_

# Generated at 2022-06-20 20:24:06.510086
# Unit test for function get_mount_size
def test_get_mount_size():
    mountpoint = '/'
    mount_size = get_mount_size(mountpoint)
    assert mount_size['size_total'] >= 0
    assert mount_size['size_available'] >= 0