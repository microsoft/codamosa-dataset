

# Generated at 2022-06-20 20:14:21.312733
# Unit test for function get_mount_size
def test_get_mount_size():
    import pytest
    from os import path
    from pytest import raises

    with raises(OSError):
        get_mount_size('/non_existent_path')

    expected_keys = ['size_total', 'size_available', 'block_size', 'block_total', 'block_available',
                     'block_used', 'inode_total', 'inode_available', 'inode_used']
    assert expected_keys == sorted(get_mount_size('/').keys())

    assert get_mount_size('/')['inode_used'] == pytest.approx(get_mount_size('/')['inode_total'] -
                                                              get_mount_size('/')['inode_available'])

# Generated at 2022-06-20 20:14:28.411754
# Unit test for function get_mount_size
def test_get_mount_size():
    # Return value from get_mount_size
    mount_size = get_mount_size('/')

    assert 'size_total' in mount_size
    assert 'size_available' in mount_size
    assert 'block_size' in mount_size
    assert 'block_total' in mount_size
    assert 'block_available' in mount_size
    assert 'block_used' in mount_size
    assert 'inode_total' in mount_size
    assert 'inode_available' in mount_size
    assert 'inode_used' in mount_size

# Generated at 2022-06-20 20:14:34.449907
# Unit test for function get_mount_size
def test_get_mount_size():
    import pprint
    mountpoints = ['/', '/tmp', '/pyshared', '/pyshared/test']
    for mountpoint in mountpoints:
        print('mountpoint: %s' % mountpoint)
        pprint.pprint(get_mount_size(mountpoint))
        print('-' * 40)

# Generated at 2022-06-20 20:14:37.727775
# Unit test for function get_mount_size
def test_get_mount_size():
    mount_size = get_mount_size('/')

    if isinstance(mount_size, dict) and mount_size['size_total'] > 0:
        return True
    else:
        return False

# Generated at 2022-06-20 20:14:49.710931
# Unit test for function get_file_content
def test_get_file_content():
    data = {}

    data['blank file'] = get_file_content('/tmp/blank_file', 'test')
    assert data['blank file'] == 'test'

    data['non-existent file'] = get_file_content('/tmp/non_existent_file', 'test')
    assert data['non-existent file'] == 'test'

    data['no file'] = get_file_content('')
    assert data['no file'] is None

    with open('/tmp/test_get_file_content', 'w') as f:
        f.write('test')

    data['test file'] = get_file_content('/tmp/test_get_file_content')
    os.remove('/tmp/test_get_file_content')
    assert data['test file'] == 'test'


# Generated at 2022-06-20 20:14:58.225846
# Unit test for function get_mount_size
def test_get_mount_size():
    try:
        assert isinstance(get_mount_size("blah"), dict)
        assert get_mount_size("blah") == {}
    except (AssertionError, OSError):
        pass

    mount_size = get_mount_size("/")
    assert isinstance(mount_size, dict)
    assert mount_size['size_total'] > 0
    assert mount_size['size_available'] > 0
    assert mount_size['block_size'] > 0
    assert mount_size['block_total'] > 0
    assert mount_size['block_available'] > 0
    assert mount_size['block_used'] > 0
    assert mount_size['inode_total'] > 0
    assert mount_size['inode_available'] > 0
    assert mount_size['inode_used'] > 0




# Generated at 2022-06-20 20:15:09.368574
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('tests/unit/files/stdout') == ["one", "two", "three", "", "four", "five", "six"]

    assert get_file_lines('tests/unit/files/stdout', strip=False) == ["one", "two", "three", "", "four", "five", "six", "", ""]

    assert get_file_lines('tests/unit/files/stdout', line_sep=" ") == ["one", "two", "three", "", "four", "five", "six"]

    assert get_file_lines('tests/unit/files/stdout', line_sep=" " * 5) == ["one two three four five six"]

    # Test no file
    assert get_file_lines('tests/unit/files/no_such_file') == []

    #

# Generated at 2022-06-20 20:15:19.616766
# Unit test for function get_mount_size
def test_get_mount_size():

    # Create a temporary directory called 'mnt' in the current directory.
    f = os.path.realpath(__file__)
    d = os.path.dirname(f)
    mnt_path = os.path.join(d, 'mnt')
    try:
        os.mkdir(mnt_path)
    except OSError:
        pass

    # Test the function; the default temporary directory should have
    # 'block_size' : 4096, 'block_total' : 10240, 'block_available' : 10240,
    # 'inode_total' : 1024, 'inode_available' : 1023,
    # 'inode_used' : 1, 'size_available' : 4294963200, 'size_total' : 4294963200
    mnt_size = get_mount_size

# Generated at 2022-06-20 20:15:25.127374
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/dev/null', '__nonexistent__') != '__nonexistent__', 'get_file_content returned incorrect value'
    assert get_file_content('/dev/null', '') == '', 'get_file_content normalize output failed'

# Generated at 2022-06-20 20:15:34.669022
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/tmp/foo', strip=False) == []
    assert get_file_lines('/tmp/foo', strip=False, line_sep='\n\n') == []
    assert get_file_lines('/tmp/foo', strip=False, line_sep='\n') == []
    assert get_file_lines('/tmp/foo', strip=False, line_sep='bar') == []
    assert get_file_lines('/tmp/foo', strip=True, line_sep='\n\n') == []
    assert get_file_lines('/tmp/foo', strip=True, line_sep='\n') == []
    assert get_file_lines('/tmp/foo', strip=True, line_sep='bar') == []


# Generated at 2022-06-20 20:15:41.409064
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content("/etc/mtab")
    assert not get_file_content("/non/existing/file")
    assert get_file_content("/etc/mtab", default='') == ''
    assert get_file_content("/non/existing/file", default='') == ''

# Generated at 2022-06-20 20:15:52.569850
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines(b'/dev/null') == []
    assert get_file_lines(b'/dev/null', line_sep=b'\n') == []
    assert get_file_lines(b'/dev/null', line_sep=b'\n\n') == []

    assert get_file_lines(b'/dev/null', line_sep=b' ') == [b'', b'', b'']
    assert get_file_lines(b'/dev/null', line_sep=b'  ') == [b'', b'']
    assert get_file_lines(b'/dev/null', line_sep=b'\n ') == [b'', b'']
    assert get_file_lines(b'/dev/null', line_sep=b' \n')

# Generated at 2022-06-20 20:16:00.131197
# Unit test for function get_file_lines
def test_get_file_lines():
    path = '/etc/group'
    data = get_file_lines(path)

# Generated at 2022-06-20 20:16:04.038251
# Unit test for function get_mount_size
def test_get_mount_size():
    # Get mount size for non-exist mountpoint, should return empty dictionary
    assert get_mount_size('/nonexist') == {}



# Generated at 2022-06-20 20:16:14.124080
# Unit test for function get_file_lines
def test_get_file_lines():
    data = '''#dog man do
    "cat"
    '''
    assert get_file_lines('/non/existent/file', strip=False) == []
    assert get_file_lines('/non/existent/file', strip=True) == []

    assert get_file_lines('/etc/fstab', strip=False) != []
    assert get_file_lines('/etc/fstab', strip=True) != []

    assert get_file_lines('/etc/fstab', strip=False, line_sep='\n') != []
    assert get_file_lines('/etc/fstab', strip=False, line_sep='#') != []
    assert get_file_lines('/etc/fstab', strip=False, line_sep='\t') != []

# Generated at 2022-06-20 20:16:25.247749
# Unit test for function get_file_lines
def test_get_file_lines():
    f = open("/tmp/file", "w")
    f.write("first line")
    f.write("\n")
    f.write("second line")
    f.close()
    assert get_file_lines("/tmp/file") == ['first line', 'second line']
    assert get_file_lines("/tmp/doesnotexist") == []
    assert get_file_lines("/tmp/file", line_sep='\n') == ['first line', 'second line']
    assert get_file_lines("/tmp/file", line_sep='\n\n') == ['first line\nsecond line']
    assert get_file_lines("/tmp/file.gz") == []

# Generated at 2022-06-20 20:16:35.098239
# Unit test for function get_file_lines
def test_get_file_lines():
    # This test file will be removed after testing
    with open('test.txt', 'w') as f:
        f.write('line1\nline2\nline3')
    assert get_file_lines('test.txt') == ['line1', 'line2', 'line3']
    assert get_file_lines('test.txt', line_sep='\n') == ['line1', 'line2', 'line3']
    assert get_file_lines('test.txt', line_sep='\n\n') == ['line1\nline2\nline3']
    assert get_file_lines('test.txt', line_sep='\n\n', strip=False) == ['line1\nline2\nline3']

# Generated at 2022-06-20 20:16:38.689862
# Unit test for function get_file_content
def test_get_file_content():
    """Test get_file_content function"""
    hw = get_file_content("/proc/cpuinfo")
    hw_len = len(hw)

    # Basic test for existence
    assert hw_len > 0

# Generated at 2022-06-20 20:16:44.794389
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/shadow') == None
    assert get_file_content('/etc/passwd') != None
    assert get_file_content('/etc/passwd', default='default') != None
    assert get_file_content('/etc/some_file_which_doesnot_exist', default='default') == 'default'
    assert get_file_content('/etc/shadow', strip=False) == None

# Generated at 2022-06-20 20:16:53.146796
# Unit test for function get_file_lines
def test_get_file_lines():
    content_list = ['line1\n', 'line2\n', '\n', 'line4\n']
    content_str = ''.join(content_list)

    # Test no custom line separator
    ret = get_file_lines('/tmp/junk', line_sep=None)
    assert ret == []

    # Test with custom line separator
    ret = get_file_lines('/tmp/junk', line_sep='\n')
    assert ret == []

    # Test with custom line separator and content
    with open('/tmp/junk', 'w') as content_file:
        content_file.write(content_str)
    ret = get_file_lines('/tmp/junk', line_sep='\n')

# Generated at 2022-06-20 20:16:58.985994
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/dev/null') == []
    assert get_file_lines('/dev/null', strip=False) == ['']

    assert get_file_lines('/etc/hosts', line_sep=' ') == ['##', '127.0.0.1 localhost']

# Generated at 2022-06-20 20:17:03.016893
# Unit test for function get_mount_size
def test_get_mount_size():
    import sys
    import os

    if (sys.argv) > 2:
        print(get_mount_size(sys.argv[1]))
        return 0
    else:
        print("Usage: %s <dir>" % os.path.basename(sys.argv[0]))
        return 1


if __name__ == "__main__":
    import sys
    sys.exit(test_get_mount_size())

# Generated at 2022-06-20 20:17:06.617339
# Unit test for function get_mount_size
def test_get_mount_size():
    mount_size = get_mount_size('/')
    assert mount_size['size_total'] > 0
    assert mount_size['size_available'] > 0
    assert mount_size['block_size'] > 0
    assert mount_size['block_total'] > 0
    assert mount_size['block_available'] > 0
    assert mount_size['block_used'] > 0
    assert mount_size['inode_total'] > 0
    assert mount_size['inode_available'] > 0
    assert mount_size['inode_used'] > 0


# Generated at 2022-06-20 20:17:11.277826
# Unit test for function get_file_lines
def test_get_file_lines():
    # Returned list and compare
    def test(ifile, sep, expect):
        assert get_file_lines(ifile, line_sep=sep)[0:len(expect)] == expect


# Generated at 2022-06-20 20:17:24.417287
# Unit test for function get_mount_size
def test_get_mount_size():
    mount_size = get_mount_size('/')
    assert len(mount_size) == 11

    assert isinstance(mount_size['block_available'], int)
    assert isinstance(mount_size['block_size'], int)
    assert isinstance(mount_size['block_total'], int)
    assert isinstance(mount_size['block_used'], int)

    assert isinstance(mount_size['inode_available'], int)
    assert isinstance(mount_size['inode_total'], int)
    assert isinstance(mount_size['inode_used'], int)

    assert isinstance(mount_size['size_available'], int)
    assert isinstance(mount_size['size_total'], int)

#
# Given the path to a block device return the path for that device in

# Generated at 2022-06-20 20:17:31.473494
# Unit test for function get_mount_size
def test_get_mount_size():
    assert get_mount_size('/') == {'size_available': 150982758400, 'size_total': 314572800000, 'inode_total': 4194304, 'block_available': 4492637, 'inode_used': 83932, 'block_total': 4896430, 'block_size': 4096, 'inode_available': 4106372, 'block_used': 403793}


# Generated at 2022-06-20 20:17:39.052665
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_lines('/etc/passwd', line_sep='')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\r')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\r\n')

    passwd_lines = get_file_content('/etc/passwd')
    passwd_lines

# Generated at 2022-06-20 20:17:46.183258
# Unit test for function get_file_content
def test_get_file_content():
    import tempfile
    import shutil

    file_content = "foobar"
    content_path = tempfile.mkdtemp() + "/test_get_file_content_test"
    with open(content_path, 'w') as f:
        f.write(file_content)

    assert file_content == get_file_content(content_path)
    shutil.rmtree(tempfile.dirname(content_path))


# Generated at 2022-06-20 20:17:58.020820
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/no/file') == []
    assert get_file_lines('/etc/hosts') == ['127.0.0.1\tlocalhost\tlocalhost.mdnsservices',
                                            '255.255.255.255\tbroadcasthost',
                                            '::1             localhost\tlocalhost.localdomain']
    assert get_file_lines('/etc/hosts', False) == ['127.0.0.1\tlocalhost\tlocalhost.mdnsservices',
                                                   '255.255.255.255\tbroadcasthost',
                                                   '::1             localhost\tlocalhost.localdomain']

# Generated at 2022-06-20 20:18:04.439666
# Unit test for function get_file_content
def test_get_file_content():
    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as tmp:
        tmp.write('foo')
    assert get_file_content(path) == 'foo'
    os.remove(path)


# Generated at 2022-06-20 20:18:18.714839
# Unit test for function get_mount_size
def test_get_mount_size():
    from ansibullbot.utils.systemtools import get_mount_size
    import tempfile

    # Create a temporary file system
    tmpdir = tempfile.mkdtemp()
    os.system('mount|grep -q %s' % tmpdir)
    if os.system('mount|grep -q %s' % tmpdir):
        os.makedirs('%s/mnt' % tmpdir)
        os.system('sudo mount -t tmpfs none %s/mnt' % tmpdir)
    temp_file = '%s/mnt/tmpfile' % tmpdir

    # Create a file
    f = open(temp_file,'w')
    f.write('1234')
    f.close()

    # Get the mount size of this temporary file system

# Generated at 2022-06-20 20:18:20.879210
# Unit test for function get_file_content
def test_get_file_content():
    assert(get_file_content("/etc/hosts")) is not None
    assert(get_file_content("/etc/hosts", default="a") == "a")
    assert(get_file_content("/etc/hosts", default="a", strip=False) == "a")

# Generated at 2022-06-20 20:18:29.126414
# Unit test for function get_file_content
def test_get_file_content():
    # Test with empty file
    assert get_file_content("/tmp/abcd") is None
    assert get_file_content("/tmp/abcd", default="default") == "default"

    # Test with one line of content
    with open("/tmp/abcd", "w") as f:
        f.write("1234")

    assert get_file_content("/tmp/abcd") == "1234"
    assert get_file_content("/tmp/abcd", strip=False) == "1234"
    assert get_file_content("/tmp/abcd", default="default") == "1234"
    assert get_file_content("/tmp/abcd", default="default", strip=False) == "1234"

    # Test with multiple lines of content

# Generated at 2022-06-20 20:18:34.032383
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='does_not_exist') == 'does_not_exist'
    assert get_file_content('/dev/null') == ''
    assert get_file_content('/dev/null', strip=False) == ''
    assert get_file_content('/etc/resolv.conf', strip=False) is not None

# Generated at 2022-06-20 20:18:36.520926
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/shadow') is None



# Generated at 2022-06-20 20:18:44.840325
# Unit test for function get_mount_size
def test_get_mount_size():
    mount_size = get_mount_size('/')
    assert mount_size != {}
    assert mount_size['size_total'] != None
    assert mount_size['size_available'] != None
    assert mount_size['block_size'] != None
    assert mount_size['block_total'] != None
    assert mount_size['block_available'] != None
    assert mount_size['block_used'] != None
    assert mount_size['inode_total'] != None
    assert mount_size['inode_available'] != None
    assert mount_size['inode_used'] != None

# Generated at 2022-06-20 20:18:51.081942
# Unit test for function get_mount_size
def test_get_mount_size():
    mountpoint = os.sep
    mount_size = get_mount_size(mountpoint)

    assert isinstance(mount_size['size_total'], int)
    assert isinstance(mount_size['size_available'], int)
    assert isinstance(mount_size['block_size'], int)
    assert isinstance(mount_size['block_total'], int)
    assert isinstance(mount_size['block_available'], int)
    assert isinstance(mount_size['block_used'], int)
    assert isinstance(mount_size['inode_total'], int)
    assert isinstance(mount_size['inode_available'], int)
    assert isinstance(mount_size['inode_used'], int)



# Generated at 2022-06-20 20:18:58.476730
# Unit test for function get_mount_size
def test_get_mount_size():
    ret = get_mount_size('/dev/null')
    assert ret == {}, "Got unexpected %s" % ret

    ret = get_mount_size('/')
    # XXX - When testing in a VM, f_frsize and f_bsize can be different
    assert ret['size_total'] == ret['block_total'] * ret['block_size']
    assert ret['size_available'] == ret['block_available'] * ret['block_size']


# Generated at 2022-06-20 20:19:01.890035
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content("/bin/cat", default="default") != "default"
    assert get_file_content("/__not_exist__", default="default") == "default"
    assert get_file_content("/bin/cat", default="default") == get_file_content("/bin/cat", default="default")


# Generated at 2022-06-20 20:19:09.803425
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == "root:x:0:0:root:/root:/bin/bash"
    assert get_file_content('/etc/passwd', strip=False) == "root:x:0:0:root:/root:/bin/bash\n"
    assert get_file_content('/etc/non-existent-file', strip=False) is None
    assert get_file_content('/etc/non-existent-file', strip=False, default='mock default') == 'mock default'

# Generated at 2022-06-20 20:19:16.802351
# Unit test for function get_file_lines
def test_get_file_lines():
    import tempfile

    file_test_data = '''\
line1
line2
line3 
line4'''

    (fd, path) = tempfile.mkstemp(prefix='ansible_test_file_utils_')
    os.write(fd, file_test_data)
    os.close(fd)

    assert(get_file_lines(path) == ['line1', 'line2', 'line3', 'line4'])
    assert(get_file_lines(path, strip=False) == ['line1\n', 'line2\n', 'line3\n', 'line4'])

    os.unlink(path)

    assert(get_file_lines(path) == [])

# Generated at 2022-06-20 20:19:27.716626
# Unit test for function get_file_content
def test_get_file_content():
    import tempfile
    (handle, test_file_path) = tempfile.mkstemp()
    test_file_content = 'foo\nbaz\nbar\n'
    test_file_stripped_content = 'foobazbar'

    # Test file doesn't exist
    assert get_file_content(test_file_path) == None

    # Test file exists but is not readable
    # This can happen when running as root
    os.chmod(test_file_path, 0o444)
    assert get_file_content(test_file_path) == None

    # Test file readable
    os.chmod(test_file_path, 0o644)
    with open(test_file_path, 'w') as test_file:
        test_file.write(test_file_content)

    assert get_

# Generated at 2022-06-20 20:19:37.163012
# Unit test for function get_file_lines
def test_get_file_lines():
    temp_file = 'file_lines_test_file'
    temp_file_object = open(temp_file, 'w')
    temp_file_object.write('Line 1\nLine 2\nLine 3\nLine 4\n')
    temp_file_object.close()
    assert get_file_lines(temp_file) == ['Line 1', 'Line 2', 'Line 3', 'Line 4']
    assert get_file_lines(temp_file, line_sep=':') == get_file_lines(temp_file)
    assert get_file_lines(temp_file, line_sep='\n') == ['Line 1', 'Line 2', 'Line 3', 'Line 4']

# Generated at 2022-06-20 20:19:43.424466
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/ansible/hosts') == get_file_lines('/etc/ansible/hosts', line_sep='\n')
    assert get_file_lines('/etc/ansible/hosts', line_sep='\n') == get_file_lines('/etc/ansible/hosts', line_sep='\n\n')
    assert get_file_lines('/etc/ansible/hosts', line_sep='\n\n') == get_file_lines('/etc/ansible/hosts', line_sep='\n\n\n')

# Generated at 2022-06-20 20:19:54.024843
# Unit test for function get_file_content
def test_get_file_content():
    # Empty file
    assert get_file_content('/dev/null') == None
    assert get_file_content('/dev/null', 'default') == 'default'
    # Non-empty file
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', strip=True)
    assert len(get_file_content('/etc/passwd', strip=False)) > 0
    assert get_file_content('/etc/passwd', 'default') == get_file_content('/etc/passwd')
    # Non-existent file
    assert get_file_content('/does/not/exist') == None
    assert get_file_content('/does/not/exist', 'default') == 'default'

# Generated at 2022-06-20 20:20:01.760330
# Unit test for function get_file_content
def test_get_file_content():
    '''
      Test get_file_content function
    '''
    result = """
1.1.1.1
2.2.2.2
3.3.3.3
    """.strip()

    test_file = '/tmp/test_file'
    with open(test_file, 'w') as f:
        f.write(result)

    # Test without strip
    assert get_file_content(test_file) == result
    assert get_file_content(test_file, strip=False) == result
    assert get_file_content(test_file, strip=True) == result
    assert get_file_content(test_file, default=None) == result
    assert get_file_content(test_file, default='some value') == result

    # Test with strip

# Generated at 2022-06-20 20:20:13.384738
# Unit test for function get_file_content
def test_get_file_content():
    path = os.path.join(os.path.dirname(__file__), 'sample.txt')
    content = get_file_content(path)
    assert content == 'foo\nbar\nbaz'
    assert get_file_content(path + "not_exist") == None
    assert get_file_content(path + "not_exist", default="default_return") == "default_return"
    assert get_file_content(path, strip=False) == 'foo\nbar\nbaz\n'
    assert get_file_content(path, strip=True) == 'foo\nbar\nbaz'
    assert get_file_content(path, strip=False, default='default_return') == 'foo\nbar\nbaz\n'

# Generated at 2022-06-20 20:20:15.858877
# Unit test for function get_file_lines
def test_get_file_lines():
    lines = get_file_lines("/etc/passwd", line_sep=':')
    assert len(lines) > 0


# Generated at 2022-06-20 20:20:23.150602
# Unit test for function get_file_lines
def test_get_file_lines():
    test_lines = ['line1', 'line2', 'line3']
    test_string = 'line1\nline2\nline3'
    assert get_file_lines('test', strip=False, line_sep='\n') == test_lines
    # Test with optional line separator
    assert get_file_lines('test', strip=False, line_sep='\t') == [test_string]
    # Test with line separator as None
    assert get_file_lines('test', strip=False, line_sep=None) == test_lines

    # Test strip option
    assert get_file_lines('test', strip=True, line_sep='\n') == ['line1', 'line2', 'line3']

# Generated at 2022-06-20 20:20:33.302311
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/dev/null') == []
    assert get_file_lines('/dev/null', line_sep='hi') == []
    assert get_file_lines('/dev/null', line_sep='\n') == []
    assert get_file_lines('/dev/null', strip=False) == ''
    assert get_file_lines('/dev/null', strip=False, line_sep='\n') == []

    # yes, even a non-existent file is stripped!
    assert get_file_lines('/dev/xxx') == []

    # a file with one character is not an empty line as it is in the resulting list!
    assert get_file_lines('/dev/full') == [' ']
    # but with strip option it is