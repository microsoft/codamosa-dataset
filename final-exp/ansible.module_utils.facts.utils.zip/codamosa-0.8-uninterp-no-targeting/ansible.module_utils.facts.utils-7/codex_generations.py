

# Generated at 2022-06-20 20:14:12.063390
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', 'default') != 'default'
    assert get_file_content('no_such_file', 'default') == 'default'



# Generated at 2022-06-20 20:14:24.894791
# Unit test for function get_file_content
def test_get_file_content():
    """Test get_file_content"""

    # Setup file to read
    test_file = '/tmp/get_file_content_test'
    with open(test_file, 'w') as datafile:
        datafile.write('test_file_content')
    datafile.close()

    assert 'test_file_content' == get_file_content(test_file)
    assert 'test_file_content' == get_file_content(test_file, default='different_default')
    assert 'default' == get_file_content('/does/not/exist')

    # test stripping of whitespace
    with open(test_file, 'w') as datafile:
        datafile.write('test_file_content\n')
    datafile.close()
    assert 'test_file_content\n' == get_file

# Generated at 2022-06-20 20:14:28.157712
# Unit test for function get_file_content
def test_get_file_content():
    result = get_file_content('/etc/passwd', default='default value', strip=False)
    assert result == 'default value'
    result = get_file_content('/etc/passwd', default='default value')
    assert result != 'default value'

# Generated at 2022-06-20 20:14:33.340162
# Unit test for function get_mount_size
def test_get_mount_size():
    from ansible.module_utils import facts

    if facts.thismodule is not None:
        assert isinstance(get_mount_size('/'), dict)
        assert get_mount_size('/')['block_total'] > 0

# Generated at 2022-06-20 20:14:44.049268
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/fstab', line_sep='\n') == list(open('/etc/fstab'))
    assert get_file_lines('/etc/fstab') == list(open('/etc/fstab'))
    assert get_file_lines('/etc/fstab', strip=False, line_sep='\n') == open('/etc/fstab').read().split('\n')
    assert get_file_lines('/etc/fstab', strip=False) == open('/etc/fstab').read().splitlines()

# Generated at 2022-06-20 20:14:54.844813
# Unit test for function get_mount_size
def test_get_mount_size():
    print("Testing get_mount_size")
    mount_size = get_mount_size("/")
    assert mount_size['size_total'] != 0
    assert mount_size['size_available'] != 0
    assert mount_size['block_size'] != 0
    assert mount_size['block_total'] != 0
    assert mount_size['block_available'] != 0
    assert mount_size['block_used'] != 0
    assert mount_size['inode_total'] != 0
    assert mount_size['inode_available'] != 0
    assert mount_size['inode_used'] != 0
    print("get_mount_size test passed")


# Generated at 2022-06-20 20:15:06.168270
# Unit test for function get_mount_size
def test_get_mount_size():
    '''
    Ensure that get_mount_size() returns the expected mounted file system size,
    and returns an empty dictionary when /proc/mounts is inaccessible.
    '''
    mount_size = get_mount_size('/')
    # Assert that some values are being returned.
    assert mount_size

    # Assert that the total size is greater than the available size so that
    # it is clearly a legitimate result.
    assert mount_size['size_total'] > mount_size['size_available']

    # Assert that a non-existent device yields an empty dictionary.
    mount_size = get_mount_size('/asdfghjkl')
    assert not mount_size



# Generated at 2022-06-20 20:15:15.714930
# Unit test for function get_mount_size
def test_get_mount_size():
    mountpoint = "/"
    mount_size = get_mount_size(mountpoint)

    # Assert a subset of the expected values
    assert mount_size.has_key("size_total")
    assert mount_size.has_key("size_available")
    assert mount_size.has_key("inode_used")
    assert mount_size.has_key("inode_available")
    assert mount_size.has_key("block_used")
    assert mount_size.has_key("block_available")



# Generated at 2022-06-20 20:15:23.221897
# Unit test for function get_file_content
def test_get_file_content():
    import os
    import tempfile

    testdata = {
        'exists_readable': 'abc123',
        'exists_not_readable': 'abc123',
        'exists_empty': '',
        'exists_not_empty': 'abc123',
        'exists_not_empty': '\n \t \n',
        'exists_not_empty': '\n \t' + 'abc123' + '\n \t \n',
        'not_exists': 'xyz123',
        'not_exists_default_none': None,
    }

    os.makedirs('/tmp/ansible_test')
    open('/tmp/ansible_test/exists_readable', 'w').write(testdata['exists_readable'])

# Generated at 2022-06-20 20:15:30.560225
# Unit test for function get_file_content
def test_get_file_content():
    import random
    import string
    import tempfile

    # Create temp file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Create temp file content
    test_content = ''.join(random.choice(string.printable) for _ in range(1024))

    # Write temp file content
    with open(path, 'wb') as handle:
        handle.write(test_content)

    handle.close()

    # Get temp file content
    result = get_file_content(path)

    # Verify file contents
    assert isinstance(result, str)
    assert result == test_content

    os.remove(path)



# Generated at 2022-06-20 20:15:35.986887
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('./test-data/test-data.txt') == 'hello world'



# Generated at 2022-06-20 20:15:39.792728
# Unit test for function get_file_lines
def test_get_file_lines():
    path = os.path.dirname(os.path.realpath(__file__)) + '/../../tests/unit/module_utils/basic_test'
    f = get_file_lines(path)
    assert f == ['hello', 'world']

# Generated at 2022-06-20 20:15:50.624530
# Unit test for function get_file_lines
def test_get_file_lines():
    test_data = (
        (['test1', 'test2'], 'test1\ntest2', ''),
        (['test1', 'test2', ''], 'test1\ntest2\n', ''),
        (['test1', 'test2', 'test3'], 'test1;test2\ntest3', ';'),
        (['test1', 'test2', 'test3'], 'test1;test2;test3', ';'),
    )

    test_path = os.path.join(os.path.dirname(__file__), 'test_file')

# Generated at 2022-06-20 20:15:57.684057
# Unit test for function get_file_lines
def test_get_file_lines():
    if os.name == 'nt':
        # On Windows, we can't chdir to /root/.
        os.chdir(os.getenv('BUILDDIR'))

    with open('/tmp/test_get_file_lines', 'w') as f:
        f.write('foo\nbar\n')

    assert [u'foo', u'bar'] == get_file_lines('/tmp/test_get_file_lines')

    os.remove('/tmp/test_get_file_lines')



# Generated at 2022-06-20 20:16:09.630264
# Unit test for function get_file_lines

# Generated at 2022-06-20 20:16:17.595701
# Unit test for function get_mount_size
def test_get_mount_size():
    assert get_mount_size('/boot') == {'size_total': 327680, 'size_available': 240640, 'block_size': 4096, 'block_total': 80, 'block_available': 59, 'block_used': 21, 'inode_total': 512, 'inode_available': 451, 'inode_used': 61}

    # Note: Bad unit test since it depends on the system's /proc/meminfo values
    assert get_mount_size('/proc') == {}


# Generated at 2022-06-20 20:16:26.977005
# Unit test for function get_file_lines
def test_get_file_lines():
    '''Unit tests for get_file_lines()'''

    # setup
    path = '/var/tmp/ansible-test-file'
    line_sep = '\n'

    # test no file
    no_file_test_data = {
        'test1': {},
    }

    for test_name in no_file_test_data:
        test_data = no_file_test_data[test_name]
        test_data['result'] = get_file_lines(path, **test_data)
        expected = []
        if test_data['result'] != expected:
            print("test {} failed, expected {}, got {}".format(test_name, expected, test_data['result']))

# Generated at 2022-06-20 20:16:31.357333
# Unit test for function get_file_content
def test_get_file_content():
    # Test with existing file containing 'test'.
    assert get_file_content('/dev/null', default='default') == 'default'
    assert get_file_content('/dev/null', default=None) is None
    assert get_file_content('/dev/null', strip=False) == ''



# Generated at 2022-06-20 20:16:37.417130
# Unit test for function get_mount_size
def test_get_mount_size():
    import tempfile, os

    (dummy, file_path) = tempfile.mkstemp()
    mount_point = os.path.dirname(file_path)
    mount_size = get_mount_size(mount_point)
    os.remove(file_path)
    assert mount_size['size_total'] >= 0, "Size total is a positive number"
    assert mount_size['size_available'] >= 0, "Size available is a positive number"
    assert mount_size['block_total'] >= 0, "Block total is a positive number"
    assert mount_size['block_available'] >= 0, "Block available is a positive number"
    assert mount_size['block_used'] >= 0, "Block used is a positive number"

# Generated at 2022-06-20 20:16:46.401637
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/dev/null', default='foo') == 'foo'
    assert get_file_content('/dev/null') is None
    assert get_file_content('/dev/zero') == ''
    assert get_file_content('/proc/uptime') == get_file_content('/proc/uptime')
    assert get_file_content('/proc/uptime') != get_file_content('/etc/passwd')
    assert get_file_content('/proc/uptime', strip=False) == get_file_content('/proc/uptime', strip=False)
    assert get_file_content('/proc/uptime', strip=False) != get_file_content('/etc/passwd', strip=False)