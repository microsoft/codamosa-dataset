

# Generated at 2022-06-17 02:57:51.026301
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/proc/mounts', line_sep='\n') == get_file_lines('/proc/mounts')
    assert get_file_lines('/proc/mounts', line_sep='\n') == get_file_lines('/proc/mounts', line_sep='\n')
    assert get_file_lines('/proc/mounts', line_sep='\n') == get_file_lines('/proc/mounts', line_sep='\n\n')
    assert get_file_lines('/proc/mounts', line_sep='\n') == get_file_lines('/proc/mounts', line_sep='\n\n\n')
    assert get_file_lines('/proc/mounts', line_sep='\n') == get_

# Generated at 2022-06-17 02:58:00.499827
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=True) == '127.0.0.1\tlocalhost'
    assert get_file_content('/etc/hosts', strip=False, default='foo') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=True, default='foo') == '127.0.0.1\tlocalhost'
    assert get_file_

# Generated at 2022-06-17 02:58:07.579216
# Unit test for function get_file_lines

# Generated at 2022-06-17 02:58:16.651188
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default='foo', strip=True)

# Generated at 2022-06-17 02:58:26.111402
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd', line_sep=':') == ['root', 'x', '0', '0', 'root', '/root', '/bin/bash']
    assert get_file_lines('/etc/passwd', line_sep='\n') == ['root:x:0:0:root:/root:/bin/bash']
    assert get_file_lines('/etc/passwd', line_sep='\n', strip=False) == ['root:x:0:0:root:/root:/bin/bash\n']
    assert get_file_lines('/etc/passwd', line_sep='\n', strip=False) == ['root:x:0:0:root:/root:/bin/bash\n']

# Generated at 2022-06-17 02:58:30.544363
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=False) == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=False) != get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default=None, strip=True) != get_file_content('/etc/passwd', default=None, strip=False)

# Generated at 2022-06-17 02:58:43.090723
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', strip=False) == 'root:x:0:0:root:/root:/bin/bash\n'
    assert get_file_content('/etc/passwd') == 'root:x:0:0:root:/root:/bin/bash'
    assert get_file_content('/etc/passwd', default='foo') == 'root:x:0:0:root:/root:/bin/bash'

# Generated at 2022-06-17 02:58:52.598076
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', default='foo', strip=False) == get_file_content('/etc/hosts', strip=False)
    assert get_file_content('/etc/hosts', default='foo', strip=False) == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', default='foo', strip=False) != get_file_

# Generated at 2022-06-17 02:58:59.493057
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='') != get_file_content('/etc/hosts', default='default')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', strip=False, default='')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', strip=False, default='default')

# Generated at 2022-06-17 02:59:10.390911
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='', strip=False)
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='', strip=True)
    assert get_file_content('/etc/hosts', default='') == get_file_content('/etc/hosts', default='', strip=False)
    assert get_file_content('/etc/hosts', default='') == get_file_content('/etc/hosts', default='', strip=True)
    assert get_file_content('/etc/hosts', default='', strip=False) == get_file_content('/etc/hosts', default='', strip=False)

# Generated at 2022-06-17 02:59:24.129879
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo') != 'bar'
    assert get_file_content('/etc/hosts', default='foo', strip=False) != 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) != 'bar'
    assert get_file_content('/etc/hosts', default='foo', strip=False) != ''
    assert get_file_content('/etc/hosts', default='foo', strip=False) != '\n'
    assert get_file_content('/etc/hosts', default='foo', strip=False) != '\n\n'

# Generated at 2022-06-17 02:59:35.178233
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='default') == 'default'
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', strip=False, default=None)
    assert get_file_content('/etc/passwd', strip=False, default='default') == get_file_content('/etc/passwd', strip=False)

# Generated at 2022-06-17 02:59:41.983841
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='') != get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='') != get_file_

# Generated at 2022-06-17 02:59:52.652887
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:00:04.022521
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'

# Generated at 2022-06-17 03:00:16.931562
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', default='foo', strip=False) != get_file_content('/etc/hosts', default='foo', strip=True)
    assert get_file_content('/etc/hosts', default='foo', strip=False) != get_file_content('/etc/hosts', default='bar', strip=False)

# Generated at 2022-06-17 03:00:24.700954
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:00:36.193950
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=True) != get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default=None, strip=False) != get_file_content('/etc/passwd', default='', strip=False)
    assert get_file_content('/etc/passwd', default='', strip=False) == get_file_content('/etc/passwd', default='', strip=True)

# Generated at 2022-06-17 03:00:47.382457
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/dev/null') == ''
    assert get_file_content('/dev/null', default='foo') == 'foo'
    assert get_file_content('/dev/null', strip=False) == ''
    assert get_file_content('/dev/null', default='foo', strip=False) == 'foo'
    assert get_file_content('/dev/null', default='foo', strip=True) == 'foo'
    assert get_file_content('/dev/null', default='foo', strip=False) == 'foo'
    assert get_file_content('/dev/null', default='', strip=False) == ''
    assert get_file_content('/dev/null', default='', strip=True) == ''

# Generated at 2022-06-17 03:00:58.346076
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='', strip=True)
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='', strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='', strip=True)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='', strip=False)

# Generated at 2022-06-17 03:01:10.696557
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default=None, strip=True) != get_file_content('/etc/hosts', default=None, strip=False)
    assert get_file_content('/etc/hosts', default=None, strip=False) != get_file_content('/etc/hosts', default='', strip=False)
    assert get_file_content('/etc/hosts', default='', strip=False) == get_file_content('/etc/hosts', default='', strip=True)

# Generated at 2022-06-17 03:01:21.247828
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='default') == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=False) == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=True) == 'default'
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True)

# Generated at 2022-06-17 03:01:26.544404
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='notfound') == 'notfound'
    assert get_file_content('/etc/passwd', default='notfound', strip=False) == 'notfound'
    assert get_file_content('/etc/passwd', default='notfound', strip=True) == 'notfound'
    assert get_file_content('/etc/passwd', default='notfound', strip=False) == 'notfound'
    assert get_file_content('/etc/passwd', default='notfound', strip=True) == 'notfound'
    assert get_file_content('/etc/passwd', default='notfound', strip=False) == 'notfound'
    assert get_file_content('/etc/passwd', default='notfound', strip=True) == 'notfound'


# Generated at 2022-06-17 03:01:37.313971
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:01:46.559121
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 03:01:51.814486
# Unit test for function get_file_content
def test_get_file_content():
    # Test for file that does not exist
    assert get_file_content('/tmp/doesnotexist') is None

    # Test for file that exists but is not readable
    assert get_file_content('/root/doesnotexist') is None

    # Test for file that exists and is readable
    assert get_file_content('/etc/hosts') is not None


# Generated at 2022-06-17 03:02:00.347181
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='bar', strip=False)
    assert get_file_content

# Generated at 2022-06-17 03:02:11.880536
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='') == ''
    assert get_file_content('/etc/hosts', default='', strip=False) == ''
    assert get_file_content('/etc/hosts', default='', strip=True) == ''
    assert get_file_content('/etc/hosts', default=None) == '127.0.0.1\tlocalhost\n'

# Generated at 2022-06-17 03:02:17.838765
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='') != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default=None) != get_file_

# Generated at 2022-06-17 03:02:28.067465
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='bar', strip=False)
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo')
    assert get_file_content

# Generated at 2022-06-17 03:02:46.493210
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default=None, strip=True) is not None
    assert get_file_content('/etc/passwd', default=None, strip=False) is not None
    assert get_file_content('/etc/passwd', default=None, strip=True).strip() == get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default=None, strip=True).strip()

# Generated at 2022-06-17 03:02:57.409069
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='default')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='default', strip=True)
    assert get_file_content('/etc/hosts', strip=True) == get_file_content('/etc/hosts', default='default', strip=True)
    assert get_file_content('/etc/hosts', strip=True) != get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_content

# Generated at 2022-06-17 03:03:05.532820
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='') != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') != get_file_

# Generated at 2022-06-17 03:03:17.517696
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'

# Generated at 2022-06-17 03:03:27.799171
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', strip=False, default='foo')
    assert get_file_content('/etc/hosts', strip=False, default='foo') != get_file_content('/etc/hosts', strip=False, default='bar')

# Generated at 2022-06-17 03:03:38.942561
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='default') != 'default'
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default='default')
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd', default='default2')
    assert get_file_content('/etc/passwd', default='default', strip=False) != get_file_content('/etc/passwd', default='default', strip=True)
    assert get_file_content('/etc/passwd', default='default', strip=True) == get_file_content('/etc/passwd', default='default', strip=True)

# Generated at 2022-06-17 03:03:48.109096
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='') != get_file_content('/etc/hosts', default='default')
    assert get_file_content('/etc/hosts', default='default') == get_file_content('/etc/hosts', default='default')
    assert get_file_content('/etc/hosts', default='default') != get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='default') != get_file_content('/etc/hosts')

# Generated at 2022-06-17 03:03:55.353767
# Unit test for function get_file_content
def test_get_file_content():
    # Test file does not exist
    assert get_file_content('/tmp/does_not_exist') is None

    # Test file exists but is not readable
    os.mknod('/tmp/test_file')
    os.chmod('/tmp/test_file', 0o000)
    assert get_file_content('/tmp/test_file') is None

    # Test file exists and is readable
    os.chmod('/tmp/test_file', 0o400)
    assert get_file_content('/tmp/test_file') == ''

    # Test file exists and is readable and has content
    with open('/tmp/test_file', 'w') as f:
        f.write('test_file_content')
    assert get_file_content('/tmp/test_file') == 'test_file_content'

# Generated at 2022-06-17 03:04:05.386200
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='') == ''
    assert get_file_content('/etc/hosts', default='', strip=False) == ''
    assert get_file_content('/etc/hosts', default='', strip=True) == ''
    assert get_file_content('/etc/hosts', default=None) == '127.0.0.1\tlocalhost\n'

# Generated at 2022-06-17 03:04:17.794297
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='') == ''
    assert get_file_content('/etc/hosts', default='', strip=False) == ''
    assert get_file_content('/etc/hosts', default='', strip=True) == ''
    assert get_file_content('/etc/hosts', default=None) == '127.0.0.1\tlocalhost\n'

# Generated at 2022-06-17 03:04:32.211502
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False, default='foo') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', strip=False, default='foo') == get_file_content('/etc/hosts', default='foo')

# Generated at 2022-06-17 03:04:43.258411
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 03:04:47.387177
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='') == ''
    assert get_file_content('/etc/hosts', default='', strip=False) == ''
    assert get_file_content('/etc/hosts', default='', strip=True) == ''
    assert get_file_content('/etc/hosts', default=None) == None
    assert get_file_content('/etc/hosts', default=None, strip=False) == None
    assert get_file_content

# Generated at 2022-06-17 03:04:56.153460
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='default') == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'
    assert get_file_content('/etc/hosts', default=None, strip=True) == '#'
    assert get_file_content('/etc/hosts', default=None, strip=False) == '#\n'
    assert get_file_content('/etc/hosts', default=None, strip=True) == '#'
    assert get_file_content('/etc/hosts', default=None, strip=False) == '#\n'

# Generated at 2022-06-17 03:05:04.353884
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default=None, strip=True) == get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default=None, strip=True) != get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=False) != get_file_content('/etc/passwd', default=None, strip=False)

# Generated at 2022-06-17 03:05:17.539923
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='/etc/hosts') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', default='/etc/hosts', strip=False) == get_file_content('/etc/hosts', strip=False)
    assert get_file_content('/etc/hosts', default='/etc/hosts', strip=True) == get_file_content('/etc/hosts', strip=True)
    assert get_file_content('/etc/hosts', default='/etc/hosts', strip=False) == get_file_content('/etc/hosts', strip=False)

# Generated at 2022-06-17 03:05:29.209352
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=True) != get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default=None, strip=True) != get_file_content('/etc/passwd', default='', strip=True)
    assert get_file_content('/etc/passwd', default='', strip=True) != get_file_content('/etc/passwd', default='', strip=False)

# Generated at 2022-06-17 03:05:37.251696
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='bar', strip=False)

# Generated at 2022-06-17 03:05:47.342877
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='not_found')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='not_found', strip=False)
    assert get_file_content('/etc/hosts', strip=False).endswith('\n')
    assert get_file_content('/etc/hosts', strip=True).endswith('\n') == False
    assert get_file_content('/etc/hosts', strip=True) == get_file_content('/etc/hosts', default='not_found', strip=True)

# Generated at 2022-06-17 03:05:58.105983
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', strip=False)
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', strip=True)
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', strip=False)

# Generated at 2022-06-17 03:06:19.664325
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', strip=False)
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='default')
    assert get_file_content('/etc/hosts') != get_file_content('/etc/hosts', strip=False, default='default')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', strip=False, default='default')
    assert get_file_content('/etc/hosts', default='default') != get_file_content('/etc/hosts', strip=False, default='default')

# Generated at 2022-06-17 03:06:29.897224
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', strip=False)
    assert get_file_content('/etc/hosts') != get_file_content('/etc/hosts', strip=False, default='foo')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts', strip=False, default='foo')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', strip=False, default='bar')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', strip=True, default='foo')

# Generated at 2022-06-17 03:06:41.613565
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:06:50.987633
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=False) == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=False) == get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default=None, strip=True) != get_file_content('/etc/passwd', default=None, strip=False)

# Generated at 2022-06-17 03:07:01.879047
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default=None, strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default=None, strip=True) == '127.0.0.1\tlocalhost\n'

# Generated at 2022-06-17 03:07:09.821424
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:07:19.198320
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='foo', strip=False)

# Generated at 2022-06-17 03:07:28.965690
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd', default='default2')
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd', default='default', strip=False)

# Generated at 2022-06-17 03:07:36.705210
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:07:47.383404
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default=None, strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default=None, strip=True) == '127.0.0.1\tlocalhost\n'