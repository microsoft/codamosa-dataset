

# Generated at 2022-06-17 02:57:54.473600
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_lines('/etc/passwd', line_sep='\n')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n\n')

# Generated at 2022-06-17 02:58:01.862035
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 02:58:08.181667
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'

# Generated at 2022-06-17 02:58:17.207922
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd') + '\n'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == get_file_content('/etc/passwd', strip=False)
    assert get_file_content('/etc/passwd', default='foo', strip=False) == get_file_content('/etc/passwd') + '\n'

# Generated at 2022-06-17 02:58:26.340917
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 02:58:36.423597
# Unit test for function get_file_lines

# Generated at 2022-06-17 02:58:48.143491
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=False) == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=False) == get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default=None, strip=True) != get_file_content('/etc/passwd', default=None, strip=False)

# Generated at 2022-06-17 02:58:55.885672
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None)
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', strip=False)

# Generated at 2022-06-17 02:59:03.613778
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None)
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default=None, strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content

# Generated at 2022-06-17 02:59:15.408149
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='') != get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='') != get_file_

# Generated at 2022-06-17 02:59:28.273531
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_content('/etc/passwd', strip=True).splitlines()
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_content('/etc/passwd', strip=True).split('\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_content('/etc/passwd', strip=True).split('\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n') == get_file_content('/etc/passwd', strip=True).split('\n\n\n')

# Generated at 2022-06-17 02:59:37.872339
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/proc/mounts', line_sep='\n') == get_file_lines('/proc/mounts')
    assert get_file_lines('/proc/mounts', line_sep='\n') == get_file_lines('/proc/mounts', line_sep='\n')
    assert get_file_lines('/proc/mounts', line_sep='\n') == get_file_lines('/proc/mounts', line_sep='\n\n')
    assert get_file_lines('/proc/mounts', line_sep='\n') == get_file_lines('/proc/mounts', line_sep='\n\n\n')
    assert get_file_lines('/proc/mounts', line_sep='\n') == get_

# Generated at 2022-06-17 02:59:43.081428
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/proc/1/cmdline') == ['systemd']
    assert get_file_lines('/proc/1/cmdline', line_sep='\0') == ['systemd']
    assert get_file_lines('/proc/1/cmdline', line_sep='\0\0') == ['systemd']
    assert get_file_lines('/proc/1/cmdline', line_sep='\0\0\0') == ['systemd']
    assert get_file_lines('/proc/1/cmdline', line_sep='\0\0\0\0') == ['systemd']
    assert get_file_lines('/proc/1/cmdline', line_sep='\0\0\0\0\0') == ['systemd']
    assert get_file_lines

# Generated at 2022-06-17 02:59:52.862958
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default='default') == get_file_content('/etc/hosts', default='default', strip=True)
    assert get_file_content('/etc/hosts', default='default', strip=False) == get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_content('/etc/hosts', default='default', strip=True) == get_file_content('/etc/hosts', default='default', strip=True)

# Generated at 2022-06-17 03:00:04.196383
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_lines('/etc/passwd', line_sep='\n')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n\n')

# Generated at 2022-06-17 03:00:17.013897
# Unit test for function get_file_lines

# Generated at 2022-06-17 03:00:24.759829
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default='default') == get_file_content('/etc/hosts', default='default', strip=True)
    assert get_file_content('/etc/hosts', default='default', strip=False) == get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_content('/etc/hosts', default='default', strip=False) != get_file_content('/etc/hosts', default='default', strip=True)

# Generated at 2022-06-17 03:00:36.223772
# Unit test for function get_file_lines

# Generated at 2022-06-17 03:00:41.714829
# Unit test for function get_file_lines

# Generated at 2022-06-17 03:00:49.324754
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=True) != get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default=None, strip=False) != get_file_content('/etc/passwd', default='', strip=False)
    assert get_file_content('/etc/passwd', default='', strip=False) == get_file_content('/etc/passwd', default='', strip=True)

# Generated at 2022-06-17 03:00:58.543903
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default=None, strip=True) != get_file_content('/etc/hosts', default=None, strip=False)
    assert get_file_content('/etc/hosts', default=None, strip=False) == get_file_content('/etc/hosts', default=None, strip=False)
    assert get_file_content('/etc/hosts', default=None, strip=False) != get_file_content('/etc/hosts', default='', strip=False)

# Generated at 2022-06-17 03:01:04.940028
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=False, strip=True) is False
    assert get_file_content('/etc/hosts', default=False, strip=False) is False
    assert get_file_content('/etc/hosts', default=True, strip=True)

# Generated at 2022-06-17 03:01:13.754735
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') is not None
    assert get_file_content('/etc/passwd', default='foo') is not None
    assert get_file_content('/etc/passwd', default='foo') != 'foo'
    assert get_file_content('/etc/passwd', strip=False) is not None
    assert get_file_content('/etc/passwd', strip=False) != ''
    assert get_file_content('/etc/passwd', strip=False) != '\n'
    assert get_file_content('/etc/passwd', strip=False) != '\n\n'
    assert get_file_content('/etc/passwd', strip=False) != ' \n'

# Generated at 2022-06-17 03:01:19.889037
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='default') == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'

# Generated at 2022-06-17 03:01:31.015466
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd', strip=True) == get_file_lines('/etc/passwd', strip=True, line_sep='\n')
    assert get_file_lines('/etc/passwd', strip=True) == get_file_lines('/etc/passwd', strip=True, line_sep='\r\n')
    assert get_file_lines('/etc/passwd', strip=True) == get_file_lines('/etc/passwd', strip=True, line_sep='\r')
    assert get_file_lines('/etc/passwd', strip=True) == get_file_lines('/etc/passwd', strip=True, line_sep='\n\r')

# Generated at 2022-06-17 03:01:40.392047
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/hosts') == ['127.0.0.1\tlocalhost', '::1\tlocalhost']
    assert get_file_lines('/etc/hosts', line_sep='\n') == ['127.0.0.1\tlocalhost', '::1\tlocalhost']
    assert get_file_lines('/etc/hosts', line_sep='\t') == ['127.0.0.1', 'localhost', '::1', 'localhost']
    assert get_file_lines('/etc/hosts', line_sep='\t\n') == ['127.0.0.1', 'localhost', '::1', 'localhost']

# Generated at 2022-06-17 03:01:51.016533
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='', strip=False)
    assert get_file_content('/etc/passwd', default='', strip=False) != get_file_content('/etc/passwd', default='', strip=True)
    assert get_file_content('/etc/passwd', default='', strip=True) != get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content('/etc/passwd', default='foo', strip=True) == get_file_content('/etc/passwd', default='foo', strip=False)

# Generated at 2022-06-17 03:01:59.766944
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 03:02:11.348429
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_lines('/etc/passwd', line_sep='\n')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n\n')

# Generated at 2022-06-17 03:02:19.988493
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='') != get_file_content('/etc/hosts', default='default')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', strip=False, default='')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', strip=False, default='default')

# Generated at 2022-06-17 03:02:30.885842
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False).startswith('#')
    assert get_file_content('/etc/hosts', strip=True).startswith('127.0.0.1')
    assert get_file_content('/etc/hosts', strip=True).endswith('localhost')
    assert get_file_content('/etc/hosts', strip=True) == get_file_content('/etc/hosts', strip=True, default='')

# Generated at 2022-06-17 03:02:42.874317
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', strip=False)

# Generated at 2022-06-17 03:02:49.769519
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'

# Generated at 2022-06-17 03:03:01.263449
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='default') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='default') != get_file_content('/etc/hosts', default='default')
    assert get_file_content('/etc/hosts', default='default') != get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_content('/etc/hosts', default='default', strip=False) != get_file_content('/etc/hosts', default='default')

# Generated at 2022-06-17 03:03:11.784301
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='') != get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='foo', strip=False)

# Generated at 2022-06-17 03:03:22.065138
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='')

# Generated at 2022-06-17 03:03:28.898688
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='') != get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', strip=True)
    assert get_file_content('/etc/hosts', strip=True) == get_file_

# Generated at 2022-06-17 03:03:38.748271
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False, default='foo') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=True) == '127.0.0.1\tlocalhost'

# Generated at 2022-06-17 03:03:47.390901
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/dev/null') == ''
    assert get_file_content('/dev/null', default='foo') == 'foo'
    assert get_file_content('/dev/null', strip=False) == ''
    assert get_file_content('/dev/null', default='foo', strip=False) == 'foo'
    assert get_file_content('/dev/null', default='foo', strip=True) == 'foo'
    assert get_file_content('/dev/null', default='foo', strip=False) == 'foo'
    assert get_file_content('/dev/null', default='', strip=False) == ''
    assert get_file_content('/dev/null', default='', strip=True) == ''

# Generated at 2022-06-17 03:03:54.991773
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None)
    assert get_file_content('/etc/hosts') != get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', strip=False) != get_file_

# Generated at 2022-06-17 03:04:07.027205
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='test') == 'test'

# Generated at 2022-06-17 03:04:18.328980
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') is not None
    assert get_file_content('/etc/passwd', default='foo') is not None
    assert get_file_content('/etc/passwd', default='foo') != 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) is not None
    assert get_file_content('/etc/passwd', default='foo', strip=False) != 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo', strip=True)

# Generated at 2022-06-17 03:04:29.224358
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=False) == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=False) != get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default=None, strip=True) != get_file_content('/etc/passwd', default=None, strip=False)

# Generated at 2022-06-17 03:04:35.813115
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', strip=False, default='')
    assert get_file_content('/etc/passwd', strip=False, default='foo') == get_file_

# Generated at 2022-06-17 03:04:46.779531
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:04:55.769017
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', strip=False)
    assert get_file_content('/etc/passwd', strip=False, default='foo') == 'foo'
    assert get_file_content('/etc/passwd', strip=False, default='foo') == 'foo'
    assert get_file_content('/etc/passwd', strip=True, default='foo') == 'foo'
    assert get_file_content('/etc/passwd', strip=True, default='foo') == 'foo'
    assert get_file_content('/etc/passwd', strip=True, default='foo') == 'foo'
    assert get_file_content

# Generated at 2022-06-17 03:05:04.233000
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd') != get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd') != get_file_content('/etc/passwd', default='', strip=True)
    assert get_file_content('/etc/passwd') != get_file_content('/etc/passwd', default='', strip=False)
    assert get_file_content('/etc/passwd', default='', strip=True) != get_file_content('/etc/passwd', default='', strip=False)

# Generated at 2022-06-17 03:05:17.476560
# Unit test for function get_file_content
def test_get_file_content():
    # Test with a file that exists and is readable
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n::1\tlocalhost\n'

    # Test with a file that exists but is not readable
    assert get_file_content('/etc/shadow') is None

    # Test with a file that does not exist
    assert get_file_content('/does/not/exist') is None

    # Test with a file that exists and is readable, but has no content
    assert get_file_content('/etc/mtab') == ''

    # Test with a file that exists and is readable, but has no content
    assert get_file_content('/etc/mtab', default='default') == 'default'

    # Test with a file that exists and is readable, but has no content
   

# Generated at 2022-06-17 03:05:29.089947
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') is not None
    assert get_file_content('/etc/passwd', default='foo') is not None
    assert get_file_content('/etc/passwd', default='foo') != 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) is not None
    assert get_file_content('/etc/passwd', default='foo', strip=False) != 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo', strip=True)

# Generated at 2022-06-17 03:05:35.846945
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=True) == '127.0.0.1\tlocalhost'

# Generated at 2022-06-17 03:05:50.511155
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='', strip=False)
    assert get_file_content('/etc/passwd', default='', strip=False) != get_file_content('/etc/passwd', default='', strip=True)
    assert get_file_content('/etc/passwd', default='', strip=True) != get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content('/etc/passwd', default='foo', strip=True) != get_file_content('/etc/passwd', default='foo', strip=False)

# Generated at 2022-06-17 03:06:01.526254
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='default') != 'default'
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default='default')
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/group', default='default')
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default='default', strip=True)

# Generated at 2022-06-17 03:06:08.592347
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo') != 'bar'
    assert get_file_content('/etc/passwd', default='foo') != 'foo\n'
    assert get_file_content('/etc/passwd', default='foo', strip=False) != 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo\n'
    assert get_file_content('/etc/passwd', default='foo', strip=False) != 'bar'
    assert get_file_content('/etc/passwd', default='foo', strip=False) != 'foo\n'

# Generated at 2022-06-17 03:06:20.022596
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', strip=True) != get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', strip=True) == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content

# Generated at 2022-06-17 03:06:30.197938
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default='default', strip=True)
    assert get_file_content('/etc/passwd', default='default', strip=False) == get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', default='default', strip=True) == get_file_content('/etc/passwd', default='default', strip=True)

# Generated at 2022-06-17 03:06:41.650121
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts') != get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts') != get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', strip=False) != get_file_

# Generated at 2022-06-17 03:06:51.025616
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True)

# Generated at 2022-06-17 03:07:02.115074
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo') != 'bar'
    assert get_file_content('/etc/hosts', default='foo', strip=False) != 'bar'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) != 'bar'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) != 'bar'

# Generated at 2022-06-17 03:07:09.940676
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False, default='foo') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', strip=False, default='foo') == get_file_content('/etc/hosts', default='foo')

# Generated at 2022-06-17 03:07:19.222134
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=False, strip=True) is False
    assert get_file_content('/etc/hosts', default=False, strip=False) is False
    assert get_file_content('/etc/hosts', default=True, strip=True)

# Generated at 2022-06-17 03:07:36.461741
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo', strip=False) != get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo', strip=False) != get_file_content('/etc/hosts', default='foo', strip=True)

# Generated at 2022-06-17 03:07:47.190942
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='') == ''
    assert get_file_content('/etc/passwd', default='', strip=False) == ''
    assert get_file_content('/etc/passwd', default='', strip=True) == ''