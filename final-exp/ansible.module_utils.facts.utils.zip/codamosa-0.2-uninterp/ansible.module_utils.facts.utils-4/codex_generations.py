

# Generated at 2022-06-17 02:58:00.061644
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_content('/etc/passwd').splitlines()
    assert get_file_lines('/etc/passwd', strip=False) == get_file_content('/etc/passwd', strip=False).splitlines()
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_content('/etc/passwd').split('\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_content('/etc/passwd').split('\n\n')

# Generated at 2022-06-17 02:58:09.273016
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_lines('/etc/passwd', line_sep='\n')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n\n')

# Generated at 2022-06-17 02:58:18.722022
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/hosts') == ['127.0.0.1\tlocalhost', '127.0.1.1\tmyhostname']
    assert get_file_lines('/etc/hosts', line_sep='\n') == ['127.0.0.1\tlocalhost', '127.0.1.1\tmyhostname']
    assert get_file_lines('/etc/hosts', line_sep='\t') == ['127.0.0.1', 'localhost', '127.0.1.1', 'myhostname']
    assert get_file_lines('/etc/hosts', line_sep='\t', strip=False) == ['127.0.0.1', 'localhost', '127.0.1.1', 'myhostname']
    assert get

# Generated at 2022-06-17 02:58:28.827614
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', strip=False).startswith('#')
    assert get_file_content('/etc/hosts', strip=True).startswith('#')
    assert get_file_content('/etc/hosts', strip=True).endswith('\n')
    assert get_file_content('/etc/hosts', strip=False).endswith('\n')
    assert get_file_content('/etc/hosts', strip=True).count('\n') == 24

# Generated at 2022-06-17 02:58:35.442242
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/proc/1/cmdline', line_sep='\0') == ['systemd']
    assert get_file_lines('/proc/1/cmdline', line_sep='\x00') == ['systemd']
    assert get_file_lines('/proc/1/cmdline', line_sep='\0', strip=False) == ['systemd\x00']
    assert get_file_lines('/proc/1/cmdline', line_sep='\x00', strip=False) == ['systemd\x00']
    assert get_file_lines('/proc/1/cmdline', line_sep='\0', strip=False) == ['systemd\x00']

# Generated at 2022-06-17 02:58:47.609023
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/proc/1/cmdline', line_sep='\x00') == ['systemd']
    assert get_file_lines('/proc/1/cmdline', line_sep='\x00', strip=False) == ['systemd\x00']
    assert get_file_lines('/proc/1/cmdline', line_sep='\x00', strip=False) == ['systemd\x00']
    assert get_file_lines('/proc/1/cmdline', line_sep='\x00', strip=False) == ['systemd\x00']
    assert get_file_lines('/proc/1/cmdline', line_sep='\x00', strip=False) == ['systemd\x00']

# Generated at 2022-06-17 02:58:57.227167
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default=None, strip=True) != get_file_content('/etc/hosts', default=None, strip=False)
    assert get_file_content('/etc/hosts', default=None, strip=False) != get_file_content('/etc/hosts', default='', strip=True)
    assert get_file_content('/etc/hosts', default='', strip=True) != get_file_content('/etc/hosts', default='', strip=False)

# Generated at 2022-06-17 02:59:08.162125
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 02:59:16.171356
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='', strip=True)
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='', strip=False)
    assert get_file_content('/etc/passwd') != get_file_content('/etc/passwd', default='foo', strip=True)

# Generated at 2022-06-17 02:59:26.072874
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 02:59:38.180155
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=True) == '127.0.0.1\tlocalhost'

# Generated at 2022-06-17 02:59:44.968230
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo', strip=True)

# Generated at 2022-06-17 02:59:52.967586
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content('/etc/passwd', default='foo', strip=False) == get_file_content('/etc/passwd', default='foo', strip=False)

# Generated at 2022-06-17 03:00:04.263318
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default='foo', strip=True)

# Generated at 2022-06-17 03:00:17.042176
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False, default='foo') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', strip=False, default='foo') == get_file_content('/etc/hosts', default='foo')

# Generated at 2022-06-17 03:00:23.141676
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=False, strip=True) is False
    assert get_file_content('/etc/passwd', default=False, strip=False) is False
    assert get_file_content('/etc/passwd', default=True, strip=True)

# Generated at 2022-06-17 03:00:34.914276
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == '127.0.0.1\tlocalhost'

# Generated at 2022-06-17 03:00:46.174794
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='default') == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=False) == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=True) == 'default'
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True)

# Generated at 2022-06-17 03:00:55.762075
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 03:01:04.749778
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo') != 'bar'
    assert get_file_content('/etc/hosts', default='foo', strip=False) != 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) != 'bar'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) != 'bar'
    assert get_file_content('/etc/hosts', default='foo', strip=True) != 'foo'

# Generated at 2022-06-17 03:01:17.234768
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True)

# Generated at 2022-06-17 03:01:29.658338
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='default') != 'default'
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd', strip=False)
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd', strip=False).strip()
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', strip=False).strip()

# Generated at 2022-06-17 03:01:39.647484
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=False, strip=True) is False
    assert get_file_content('/etc/passwd', default=False, strip=False) is False
    assert get_file_content('/etc/passwd', default=True, strip=True)

# Generated at 2022-06-17 03:01:50.329493
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='default')
    assert get_file_content('/etc/passwd') != get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default='default')

# Generated at 2022-06-17 03:01:59.339491
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hostname') == 'localhost'
    assert get_file_content('/etc/hostname', default='test') == 'localhost'
    assert get_file_content('/etc/hostname', strip=False) == 'localhost\n'
    assert get_file_content('/etc/hostname', default='test', strip=False) == 'localhost\n'
    assert get_file_content('/etc/hostname', default='test', strip=True) == 'localhost'
    assert get_file_content('/etc/hostname', default='test', strip=False) == 'localhost\n'
    assert get_file_content('/etc/hostname', default='test', strip=True) == 'localhost'

# Generated at 2022-06-17 03:02:10.406763
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', strip=True)

# Generated at 2022-06-17 03:02:16.654898
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None)
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='default')
    assert get_file_content('/etc/hosts') != get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default=None, strip=False)

# Generated at 2022-06-17 03:02:24.394015
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 03:02:28.592422
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 03:02:37.566681
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n\n'
    assert get_file_content('/etc/hosts', default='foo') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == '127.0.0.1\tlocalhost\n\n'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == '127.0.0.1\tlocalhost'

# Generated at 2022-06-17 03:02:49.970352
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', default='foo') != get_file_

# Generated at 2022-06-17 03:03:01.346361
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='') == ''
    assert get_file_content('/etc/passwd', default='', strip=False) == ''
    assert get_file_content('/etc/passwd', default='', strip=True) == ''

# Generated at 2022-06-17 03:03:11.825973
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:03:24.281970
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False, default='foo') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=True) == '127.0.0.1\tlocalhost'

# Generated at 2022-06-17 03:03:31.646750
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=False) == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=False) != get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default=None, strip=True) != get_file_content('/etc/passwd', default=None, strip=False)

# Generated at 2022-06-17 03:03:35.721293
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 03:03:43.692596
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='default')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', strip=False).endswith('\n')
    assert get_file_content('/etc/passwd', strip=True).endswith('\n')
    assert get_file_content('/etc/passwd', strip=True).strip() == get_file_content('/etc/passwd', strip=True)
    assert get_file_content('/etc/passwd', strip=True).strip() == get_file_content('/etc/passwd', strip=True)

# Generated at 2022-06-17 03:03:53.244300
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:04:03.787339
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False, default='foo') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=True, default='foo') == '127.0.0.1\tlocalhost'
    assert get_file_content('/etc/hosts', strip=True) == '127.0.0.1\tlocalhost'
    assert get_file_

# Generated at 2022-06-17 03:04:13.465385
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) != 'foo\n'

# Generated at 2022-06-17 03:04:28.107359
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content('/etc/passwd', strip=True) != get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', strip=True) == get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content

# Generated at 2022-06-17 03:04:35.294717
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == '127.0.0.1\tlocalhost'
    assert get_

# Generated at 2022-06-17 03:04:46.413879
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd') != get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd') != get_file_content('/etc/passwd', default='', strip=True)
    assert get_file_content('/etc/passwd') != get_file_content('/etc/passwd', default='', strip=False)
    assert get_file_content('/etc/passwd') != get_file_content('/etc/passwd', default='foo', strip=True)

# Generated at 2022-06-17 03:04:49.165676
# Unit test for function get_file_content
def test_get_file_content():
    path = '/etc/hostname'
    content = get_file_content(path)
    assert content is not None
    assert content != ''


# Generated at 2022-06-17 03:04:57.021229
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default='default', strip=True)
    assert get_file_content('/etc/passwd', default='default', strip=False) == get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', default='default', strip=False) != get_file_content('/etc/passwd', default='default', strip=True)

# Generated at 2022-06-17 03:05:04.681911
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default=None, strip=True) == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default=None, strip=False) == get_file_content('/etc/hosts', default=None, strip=False)
    assert get_file_content('/etc/hosts', default=None, strip=True) != get_file_content('/etc/hosts', default=None, strip=False)

# Generated at 2022-06-17 03:05:17.681999
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', default='foo', strip=False) != get_file_content('/etc/hosts', default='foo', strip=True)
    assert get_file_content('/etc/hosts', default='foo', strip=True) == get_file_content('/etc/hosts', default='foo', strip=False).strip()

# Generated at 2022-06-17 03:05:29.367777
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:05:37.366876
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='default')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='default', strip=True)
    assert get_file_content('/etc/hosts', strip=True) != get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_content('/etc/hosts', strip=True) == get_file_content('/etc/hosts', default='default', strip=True)
    assert get_file_content

# Generated at 2022-06-17 03:05:47.417660
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', strip=False)
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='default')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', strip=True)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='default')
    assert get_file_content('/etc/hosts', strip=True) != get_file_content('/etc/hosts', default='default')

# Generated at 2022-06-17 03:06:00.621020
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default='default', strip=True)
    assert get_file_content('/etc/passwd', default='default', strip=False) == get_file_content('/etc/passwd', default='default', strip=False)

# Generated at 2022-06-17 03:06:08.014519
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True)

# Generated at 2022-06-17 03:06:19.821993
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True)

# Generated at 2022-06-17 03:06:30.010732
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == '127.0.0.1\tlocalhost'
    assert get_

# Generated at 2022-06-17 03:06:41.649188
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=None, strip=True)

# Generated at 2022-06-17 03:06:50.987718
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', strip=True)
    assert get_file_content('/etc/passwd', strip=False).endswith('\n')
    assert get_file_content('/etc/passwd', strip=True).endswith('\n') is False
    assert get_file

# Generated at 2022-06-17 03:07:01.877203
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='foo', strip=True)
    assert get_file_content('/etc/hosts', strip=True) != get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', strip=True) == get_file_content('/etc/hosts', default='foo', strip=True)
    assert get_file_content

# Generated at 2022-06-17 03:07:09.822533
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=True) == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=False) == get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default=None, strip=False) != get_file_content('/etc/passwd', default=None, strip=True)

# Generated at 2022-06-17 03:07:16.381255
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='default') == 'default'
    assert get_file_content('/etc/hosts') == '#'
    assert get_file_content('/etc/hosts', strip=False) == '#\n'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'


# Generated at 2022-06-17 03:07:26.025951
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='default')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='default', strip=True)
    assert get_file_content('/etc/hosts', strip=True) != get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_content('/etc/hosts', strip=True) == get_file_content('/etc/hosts', default='default', strip=True)
    assert get_file_content

# Generated at 2022-06-17 03:07:48.771879
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1 localhost'
    assert get_file_content('/etc/hosts', default='127.0.0.1 localhost') == '127.0.0.1 localhost'
    assert get_file_content('/etc/hosts', default='127.0.0.1 localhost', strip=False) == '127.0.0.1 localhost\n'
    assert get_file_content('/etc/hosts', default='127.0.0.1 localhost', strip=True) == '127.0.0.1 localhost'
    assert get_file_content('/etc/hosts', default='127.0.0.1 localhost', strip=False) == '127.0.0.1 localhost\n'
