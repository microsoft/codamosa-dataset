

# Generated at 2022-06-17 02:57:55.877661
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=None, strip=True)

# Generated at 2022-06-17 02:58:06.348700
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', strip=False)

# Generated at 2022-06-17 02:58:16.091431
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 02:58:26.054827
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_content('/etc/passwd').splitlines()
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_content('/etc/passwd').split('\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_content('/etc/passwd').split('\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n') == get_file_content('/etc/passwd').split('\n\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n\n') == get_file_

# Generated at 2022-06-17 02:58:33.725665
# Unit test for function get_file_lines
def test_get_file_lines():
    test_file = '/tmp/test_file'
    test_file_content = '''
    line1
    line2
    line3
    '''
    with open(test_file, 'w') as f:
        f.write(test_file_content)

    assert get_file_lines(test_file) == ['line1', 'line2', 'line3']
    assert get_file_lines(test_file, line_sep='\n') == ['line1', 'line2', 'line3']
    assert get_file_lines(test_file, line_sep='\n\n') == ['line1', 'line2', 'line3']
    assert get_file_lines(test_file, line_sep='\n\n\n') == ['line1', 'line2', 'line3']

# Generated at 2022-06-17 02:58:45.627800
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'

# Generated at 2022-06-17 02:58:54.122663
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_lines('/etc/passwd', line_sep='\n')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n\n')

# Generated at 2022-06-17 02:59:00.678644
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='foo', strip=True)
    assert get_file_content('/etc/hosts', default='foo', strip=False) != get_file_content('/etc/hosts', default='foo', strip=True)
    assert get_file_content

# Generated at 2022-06-17 02:59:11.283047
# Unit test for function get_file_lines

# Generated at 2022-06-17 02:59:17.071452
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=True) == '127.0.0.1\tlocalhost'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == '127.0.0.1\tlocalhost'
    assert get_file_

# Generated at 2022-06-17 02:59:26.789638
# Unit test for function get_file_content
def test_get_file_content():
    path = '/tmp/test_file'
    test_data = 'test data'
    with open(path, 'w') as f:
        f.write(test_data)
    assert get_file_content(path) == test_data
    assert get_file_content(path, default='default') == test_data
    assert get_file_content(path, strip=False) == test_data + '\n'
    assert get_file_content('/tmp/non_existent_file', default='default') == 'default'
    assert get_file_content('/tmp/non_existent_file') is None
    os.remove(path)

# Generated at 2022-06-17 02:59:35.584288
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 02:59:44.970004
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=False) == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=False) != get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default=None, strip=True) != get_file_content('/etc/passwd', default=None, strip=False)

# Generated at 2022-06-17 02:59:50.654936
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='default') != 'default'
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default='default')
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd', default='default2')
    assert get_file_content('/etc/passwd', default='default', strip=False) != get_file_content('/etc/passwd', default='default', strip=True)
    assert get_file_content('/etc/passwd', default='default', strip=True) == get_file_content('/etc/passwd', default='default', strip=True)

# Generated at 2022-06-17 03:00:01.934309
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/fstab', line_sep='\n') == get_file_lines('/etc/fstab')
    assert get_file_lines('/etc/fstab', line_sep='\n') == get_file_lines('/etc/fstab', line_sep='\n')
    assert get_file_lines('/etc/fstab', line_sep='\n') == get_file_lines('/etc/fstab', line_sep='\n\n')
    assert get_file_lines('/etc/fstab', line_sep='\n') == get_file_lines('/etc/fstab', line_sep='\n\n\n')
    assert get_file_lines('/etc/fstab', line_sep='\n') == get_

# Generated at 2022-06-17 03:00:16.063460
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='') != get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='') != get_file_

# Generated at 2022-06-17 03:00:24.013951
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default='default') == get_file_content('/etc/hosts', default='default', strip=True)
    assert get_file_content('/etc/hosts', default='default', strip=False) == get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_content('/etc/hosts', default='default', strip=False) == get_file_content('/etc/hosts', default='default', strip=False)

# Generated at 2022-06-17 03:00:35.909043
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content('/etc/passwd', strip=True) != get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', strip=True) == get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content

# Generated at 2022-06-17 03:00:47.298105
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default='default')
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='') != get_file_content('/etc/passwd', default='default')

# Generated at 2022-06-17 03:00:58.347297
# Unit test for function get_file_lines

# Generated at 2022-06-17 03:01:10.671400
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='', strip=False)
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='', strip=True)
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content('/etc/passwd', default='foo', strip=False) == get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file

# Generated at 2022-06-17 03:01:21.220887
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_lines('/etc/passwd', line_sep='\n')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n\n')

# Generated at 2022-06-17 03:01:26.545457
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'

# Generated at 2022-06-17 03:01:30.105912
# Unit test for function get_file_lines
def test_get_file_lines():
    path = '/tmp/test_file'
    test_data = '''
    line1
    line2
    line3
    '''
    with open(path, 'w') as f:
        f.write(test_data)
    lines = get_file_lines(path)
    assert lines == ['line1', 'line2', 'line3']
    os.remove(path)

# Generated at 2022-06-17 03:01:39.877961
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='') != get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='') != get_file_

# Generated at 2022-06-17 03:01:50.573823
# Unit test for function get_file_lines
def test_get_file_lines():
    path = '/tmp/test_get_file_lines'
    with open(path, 'w') as f:
        f.write('a\nb\nc\n')
    assert get_file_lines(path) == ['a', 'b', 'c']
    assert get_file_lines(path, line_sep='\n') == ['a', 'b', 'c']
    assert get_file_lines(path, line_sep='\n\n') == ['a\nb\nc']
    assert get_file_lines(path, line_sep='\n\n', strip=False) == ['a\nb\nc\n']
    assert get_file_lines(path, line_sep='\n\n', strip=False) == ['a\nb\nc\n']

# Generated at 2022-06-17 03:01:59.411972
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None)
    assert get_file_content('/etc/hosts', default=None) != get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default=None, strip=False) != get_file_content('/etc/hosts', default=None)
    assert get_file_content('/etc/hosts', default=None, strip=False) != get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', default='foo', strip=False) != get_file_content('/etc/hosts', default='foo')
    assert get_file_content

# Generated at 2022-06-17 03:02:10.918712
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) != get_file_

# Generated at 2022-06-17 03:02:19.860034
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/proc/1/cmdline', line_sep='\0') == ['systemd']
    assert get_file_lines('/proc/1/cmdline', line_sep='\x00') == ['systemd']
    assert get_file_lines('/proc/1/cmdline', line_sep='\x00', strip=False) == ['systemd\x00']
    assert get_file_lines('/proc/1/cmdline', line_sep='\x00', strip=False) == ['systemd\x00']
    assert get_file_lines('/proc/1/cmdline', line_sep='\x00', strip=False) == ['systemd\x00']

# Generated at 2022-06-17 03:02:25.856387
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='default') == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=None, strip=True)

# Generated at 2022-06-17 03:02:34.166972
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='default')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='default', strip=True)
    assert get_file_content('/etc/hosts', strip=True) != get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_content('/etc/hosts', strip=True) == get_file_content('/etc/hosts', default='default', strip=True)
    assert get_file_content

# Generated at 2022-06-17 03:02:41.640269
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default=None, strip=False) == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default=None, strip=False) != get_file_content('/etc/hosts', default=None, strip=False)
    assert get_file_content('/etc/hosts', default=None, strip=True) != get_file_content('/etc/hosts', default=None, strip=False)

# Generated at 2022-06-17 03:02:50.619302
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=False) == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=False) == get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default=None, strip=True) != get_file_content('/etc/passwd', default=None, strip=False)

# Generated at 2022-06-17 03:03:01.757523
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default='default', strip=True)
    assert get_file_content('/etc/passwd', default='default', strip=False) == get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', default='default', strip=False) != get_file_content('/etc/passwd', default='default', strip=True)

# Generated at 2022-06-17 03:03:11.805024
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:03:24.250821
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd') != get_file_content('/etc/group')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/group', default='foo')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/group', default='bar')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', strip=False)
    assert get_file_

# Generated at 2022-06-17 03:03:31.598444
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default='default', strip=True)
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content

# Generated at 2022-06-17 03:03:39.744019
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=True) != get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default=None, strip=True) != get_file_content('/etc/passwd', default='', strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=True) != get_file_content('/etc/passwd', default='', strip=False)

# Generated at 2022-06-17 03:03:49.195910
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:03:55.838532
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hostname') == 'localhost'
    assert get_file_content('/etc/hostname', default='foo') == 'localhost'
    assert get_file_content('/etc/hostname', default='foo', strip=False) == 'localhost\n'
    assert get_file_content('/etc/hostname', default='foo', strip=True) == 'localhost'
    assert get_file_content('/etc/hostname', default='foo', strip=False) == 'localhost\n'
    assert get_file_content('/etc/hostname', default='foo', strip=True) == 'localhost'
    assert get_file_content('/etc/hostname', default='foo', strip=False) == 'localhost\n'

# Generated at 2022-06-17 03:04:07.180057
# Unit test for function get_file_content
def test_get_file_content():
    # Test for file that exists
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'

    # Test for file that does not exist
    assert get_file_content('/etc/hosts_does_not_exist') is None

    # Test for file that exists but is not readable
    assert get_file_content('/etc/shadow') is None

    # Test for file that exists but is empty
    assert get_file_content('/etc/mtab') == ''

    # Test for file that exists but is empty and strip is False
    assert get_file_content('/etc/mtab', strip=False) == ''

    # Test for file that exists but is empty and strip is False and default is set

# Generated at 2022-06-17 03:04:18.361817
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='bar', strip=False)
    assert get_file_content('/etc/passwd', default='foo', strip=False) == get_file_content('/etc/passwd', default='foo', strip=False)

# Generated at 2022-06-17 03:04:29.226222
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='default') == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=False) == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=True) == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=False) == 'default'
    assert get_file_content('/etc/passwd', default='') == ''
    assert get_file_content('/etc/passwd', default='', strip=False) == ''
    assert get_file_content('/etc/passwd', default='', strip=True) == ''
    assert get_file_content('/etc/passwd', default='', strip=False) == ''

# Generated at 2022-06-17 03:04:38.948164
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False, default='foo') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=True) == '127.0.0.1\tlocalhost'

# Generated at 2022-06-17 03:04:49.359903
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='default') == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=None, strip=True)

# Generated at 2022-06-17 03:04:56.973240
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='default') != 'default'
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default='default')
    assert get_file_content('/etc/passwd', default='default', strip=False) != get_file_content('/etc/passwd', default='default')
    assert get_file_content('/etc/passwd', default='default', strip=False) == get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd', default='default', strip=False)

# Generated at 2022-06-17 03:05:04.660292
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') is not None
    assert get_file_content('/etc/passwd', default='foo') is not None
    assert get_file_content('/etc/passwd', default='foo') != 'foo'
    assert get_file_content('/etc/passwd', default='foo') != ''
    assert get_file_content('/etc/passwd', default='foo', strip=False) != ''
    assert get_file_content('/etc/passwd', default='foo', strip=False) != 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) is not None
    assert get_file_content('/etc/passwd', default='foo', strip=True) is not None

# Generated at 2022-06-17 03:05:17.678735
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') is not None
    assert get_file_content('/etc/passwd', default='foo') is not None
    assert get_file_content('/etc/passwd', default='foo') != 'foo'
    assert get_file_content('/etc/passwd', strip=False) is not None
    assert get_file_content('/etc/passwd', strip=False) != ''
    assert get_file_content('/etc/passwd', default='foo', strip=False) is not None
    assert get_file_content('/etc/passwd', default='foo', strip=False) != 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) != ''

# Generated at 2022-06-17 03:05:29.407345
# Unit test for function get_file_content
def test_get_file_content():
    # Test for file that exists and is readable
    assert get_file_content('/etc/hosts', default='default') == '127.0.0.1\tlocalhost\n'

    # Test for file that exists but is not readable
    assert get_file_content('/etc/shadow', default='default') == 'default'

    # Test for file that does not exist
    assert get_file_content('/etc/does_not_exist', default='default') == 'default'

    # Test for file that exists and is readable but is empty
    assert get_file_content('/etc/empty_file', default='default') == 'default'

    # Test for file that exists and is readable but is empty
    assert get_file_content('/etc/empty_file', default='default', strip=False) == 'default'

    # Test for

# Generated at 2022-06-17 03:05:37.395706
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='', strip=True)
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='', strip=False)
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default='', strip=False)
    assert get_file_content('/etc/passwd', strip=True) == get_file_content('/etc/passwd', default='', strip=True)

# Generated at 2022-06-17 03:05:49.439360
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=None, strip=True)

# Generated at 2022-06-17 03:06:00.296326
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/dev/null') == ''
    assert get_file_content('/dev/null', default='foo') == 'foo'
    assert get_file_content('/dev/null', default='foo', strip=False) == 'foo'
    assert get_file_content('/dev/null', strip=False) == ''
    assert get_file_content('/dev/null', default='foo', strip=True) == 'foo'
    assert get_file_content('/dev/null', strip=True) == ''
    assert get_file_content('/dev/null', default='foo', strip=False) == 'foo'
    assert get_file_content('/dev/null', strip=False) == ''

# Generated at 2022-06-17 03:06:12.716668
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', strip=True)
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', strip=False)
    assert get_file_content('/etc/passwd', strip=True) == get_file_

# Generated at 2022-06-17 03:06:22.327795
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/fstab', default='foo') == 'foo'
    assert get_file_content('/etc/fstab') == get_file_content('/etc/fstab', default=None)
    assert get_file_content('/etc/fstab', strip=False) == get_file_content('/etc/fstab', default=None, strip=False)
    assert get_file_content('/etc/fstab', strip=False).endswith('\n')
    assert get_file_content('/etc/fstab', strip=True).endswith('\n')
    assert get_file_content('/etc/fstab', strip=True).strip().endswith('\n') is False
    assert get_file_content('/etc/fstab', strip=True).strip() == get

# Generated at 2022-06-17 03:06:31.841939
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='default') != 'default'
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='default', strip=False) != get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='default', strip=False) != get_file_content('/etc/passwd', strip=False)
    assert get_file_content('/etc/passwd', default='default', strip=False) != get_file_content('/etc/passwd', strip=True)
    assert get_file_content('/etc/passwd', default='default', strip=True) != get_file_content

# Generated at 2022-06-17 03:06:39.293570
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd') == 'root:x:0:0:root:/root:/bin/bash\n'
    assert get_file_content('/etc/passwd', strip=False) == 'root:x:0:0:root:/root:/bin/bash\n'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'


# Generated at 2022-06-17 03:06:49.056347
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='default')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', strip=True) == get_file_content('/etc/passwd', default='default', strip=True)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default='default', strip=True)
    assert get_file_content('/etc/passwd', strip=True) != get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content

# Generated at 2022-06-17 03:06:56.112853
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default=None, strip=True) == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default=None, strip=True) != get_file_content('/etc/hosts', default=None, strip=False)
    assert get_file_content('/etc/hosts', default=None, strip=False) != get_file_content('/etc/hosts', default=None, strip=True)

# Generated at 2022-06-17 03:07:06.476617
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='') == ''
    assert get_file_content('/etc/passwd', default='', strip=False) == ''
    assert get_file_content('/etc/passwd', default='', strip=True) == ''

# Generated at 2022-06-17 03:07:18.044123
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='bar', strip=False)
    assert get_file_content('/etc/passwd', default='foo', strip=False) == get_file_content('/etc/passwd', default='bar', strip=True)
    assert get

# Generated at 2022-06-17 03:07:29.965903
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False, default='foo') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == '127.0.0.1\tlocalhost\n'

# Generated at 2022-06-17 03:07:37.307234
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='') == ''
    assert get_file_content('/etc/hosts', default='', strip=False) == ''
    assert get_file_content('/etc/hosts', default='', strip=True) == ''

# Generated at 2022-06-17 03:07:47.793298
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n\n'
    assert get_file_content('/etc/hosts', default='foo') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == '127.0.0.1\tlocalhost\n\n'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == '127.0.0.1\tlocalhost'