

# Generated at 2022-06-17 02:57:51.008264
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_

# Generated at 2022-06-17 02:58:00.475349
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar', strip=True)
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar', strip=False)
    assert get

# Generated at 2022-06-17 02:58:09.295631
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 02:58:18.719285
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 02:58:28.827425
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='foo', strip=False)

# Generated at 2022-06-17 02:58:35.443262
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=None, strip=True)

# Generated at 2022-06-17 02:58:47.609538
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 02:58:57.226638
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content("/etc/hosts", default="") == get_file_content("/etc/hosts")
    assert get_file_content("/etc/hosts", default="") != get_file_content("/etc/hosts", strip=False)
    assert get_file_content("/etc/hosts", default="") != get_file_content("/etc/hosts", default="foo")
    assert get_file_content("/etc/hosts", default="") != get_file_content("/etc/hosts", strip=False, default="foo")
    assert get_file_content("/etc/hosts", default="") != get_file_content("/etc/hosts", default="foo", strip=False)
    assert get_file_content("/etc/hosts", default="") != get_

# Generated at 2022-06-17 02:59:08.162667
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='127.0.0.1 localhost') == '127.0.0.1 localhost'
    assert get_file_content('/etc/hosts', default='127.0.0.1 localhost', strip=False) == '127.0.0.1 localhost\n'
    assert get_file_content('/etc/hosts', default='127.0.0.1 localhost', strip=False) == '127.0.0.1 localhost\n'
    assert get_file_content('/etc/hosts', default='127.0.0.1 localhost', strip=True) == '127.0.0.1 localhost'

# Generated at 2022-06-17 02:59:16.193496
# Unit test for function get_file_lines

# Generated at 2022-06-17 02:59:30.972813
# Unit test for function get_file_lines

# Generated at 2022-06-17 02:59:39.955612
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', strip=False).endswith('\n')
    assert get_file_content('/etc/passwd', strip=True).endswith('\n')
    assert get_file_content('/etc/passwd', strip=True).strip() == get_file_content('/etc/passwd', default=None, strip=True)

# Generated at 2022-06-17 02:59:50.917089
# Unit test for function get_file_content
def test_get_file_content():
    # Test file exists and is readable
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'

    # Test file exists but is not readable
    assert get_file_content('/etc/shadow') is None

    # Test file does not exist
    assert get_file_content('/etc/foo') is None

    # Test file exists and is readable but is empty
    assert get_file_content('/etc/mtab') == ''

    # Test file exists and is readable but is empty and default is set
    assert get_file_content('/etc/mtab', 'foo') == 'foo'

    # Test file exists and is readable but is empty and default is set and strip is True
    assert get_file_content('/etc/mtab', 'foo', True) == 'foo'

# Generated at 2022-06-17 03:00:02.237415
# Unit test for function get_file_lines

# Generated at 2022-06-17 03:00:16.233353
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=False) == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=False) != get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default=None, strip=True) != get_file_content('/etc/passwd', default=None, strip=False)

# Generated at 2022-06-17 03:00:24.414930
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_lines('/etc/passwd', line_sep='\n')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n\n')

# Generated at 2022-06-17 03:00:36.193401
# Unit test for function get_file_lines

# Generated at 2022-06-17 03:00:47.381646
# Unit test for function get_file_lines
def test_get_file_lines():
    # Test with a file with a single line
    assert get_file_lines('/etc/hosts') == ['127.0.0.1\tlocalhost']

    # Test with a file with multiple lines

# Generated at 2022-06-17 03:00:58.346625
# Unit test for function get_file_lines

# Generated at 2022-06-17 03:01:03.848142
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True)

# Generated at 2022-06-17 03:01:12.228105
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False, default='foo') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=True) == '127.0.0.1\tlocalhost'

# Generated at 2022-06-17 03:01:22.044906
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='') == ''
    assert get_file_content('/etc/passwd', default='', strip=False) == ''
    assert get_file_content('/etc/passwd', default='', strip=True) == ''

# Generated at 2022-06-17 03:01:32.680934
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='', strip=False)
    assert get_file_content('/etc/hosts') != get_file_content('/etc/hosts', default='', strip=True)
    assert get_file_content('/etc/hosts', default='', strip=True) != get_file_content('/etc/hosts', default='', strip=False)
    assert get_file_content('/etc/hosts', default='', strip=False) != get_file_content('/etc/hosts', default='', strip=True)
    assert get_file_content('/etc/hosts', default='', strip=True) == get_file_content('/etc/hosts', default='', strip=True)
    assert get

# Generated at 2022-06-17 03:01:41.026200
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True)

# Generated at 2022-06-17 03:01:51.504107
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='', strip=True)
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='', strip=False)
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='', strip=False)
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='', strip=False)

# Generated at 2022-06-17 03:02:00.149756
# Unit test for function get_file_content
def test_get_file_content():
    # Test file that exists
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'

    # Test file that doesn't exist
    assert get_file_content('/etc/hosts_does_not_exist') is None

    # Test file that exists but is not readable
    assert get_file_content('/etc/shadow') is None

    # Test file that exists but is empty
    assert get_file_content('/etc/mtab') == ''

    # Test file that exists but is empty and we want a default value
    assert get_file_content('/etc/mtab', default='default') == 'default'

    # Test file that exists but is empty and we want a default value

# Generated at 2022-06-17 03:02:11.719916
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='empty') == 'empty'
    assert get_file_content('/etc/passwd', default='empty', strip=False) == 'empty'
    assert get_file_content('/etc/passwd', default='empty', strip=True) == 'empty'
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True)

# Generated at 2022-06-17 03:02:17.723391
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False, default='foo') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', strip=False, default='foo') == get_file_content('/etc/hosts', default='foo')

# Generated at 2022-06-17 03:02:24.595718
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:02:34.003390
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='default') == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=False) == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=True) == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=False) == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=True) == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=False) == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=True) == 'default'

# Generated at 2022-06-17 03:02:47.127123
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='') != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default=None) == get_file_

# Generated at 2022-06-17 03:02:58.145236
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='foo', strip=True)
    assert get_file_content('/etc/hosts', strip=True) != get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', strip=True) == get_file_content('/etc/hosts', default='foo', strip=True)
    assert get_file_content

# Generated at 2022-06-17 03:03:05.991003
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 03:03:13.777112
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='default') != 'default'
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default='default')
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/group', default='default')
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default='default', strip=True)

# Generated at 2022-06-17 03:03:24.346383
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='foo', strip=False)

# Generated at 2022-06-17 03:03:31.679325
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='default')
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', strip=True)
    assert get_file_content('/etc/passwd', strip=True) == get_file_

# Generated at 2022-06-17 03:03:40.800021
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None)
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts', default=None)
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo', strip=False) != get_file_content('/etc/hosts', default='foo')

# Generated at 2022-06-17 03:03:50.606262
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) != 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == get_file_content('/etc/passwd', default='foo', strip=False)

# Generated at 2022-06-17 03:04:00.656927
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default=None, strip=True) == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default=None, strip=False) == get_file_content('/etc/hosts', default=None, strip=False)
    assert get_file_content('/etc/hosts', default=None, strip=False) != get_file_content('/etc/hosts', default=None, strip=True)

# Generated at 2022-06-17 03:04:08.519038
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', strip=True)
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='foo', strip=False)

# Generated at 2022-06-17 03:04:25.968234
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content('/etc/passwd', default='foo', strip=False) == get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo', strip=True)

# Generated at 2022-06-17 03:04:34.054626
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo', strip=False) == get_file_content('/etc/passwd', default='foo', strip=False)

# Generated at 2022-06-17 03:04:45.662266
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='foo', strip=False)

# Generated at 2022-06-17 03:04:54.897156
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo')

# Generated at 2022-06-17 03:05:04.011664
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None

# Generated at 2022-06-17 03:05:17.428639
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default=None, strip=True) != get_file_content('/etc/hosts', default=None, strip=False)
    assert get_file_content('/etc/hosts', default=None, strip=False) != get_file_content('/etc/hosts', default='', strip=False)
    assert get_file_content('/etc/hosts', default='', strip=False) == get_file_content('/etc/hosts', default='', strip=True)

# Generated at 2022-06-17 03:05:26.966586
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hostname') == 'localhost'
    assert get_file_content('/etc/hostname', default='test') == 'localhost'
    assert get_file_content('/etc/hostname', strip=False) == 'localhost\n'
    assert get_file_content('/etc/hostname', default='test', strip=False) == 'localhost\n'
    assert get_file_content('/etc/hostname_not_exist', default='test') == 'test'
    assert get_file_content('/etc/hostname_not_exist', default='test', strip=False) == 'test'


# Generated at 2022-06-17 03:05:35.677498
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False, default='foo') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', strip=False, default='foo') == get_file_content('/etc/hosts', default='foo')

# Generated at 2022-06-17 03:05:45.414852
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd') != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd') != get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default='', strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get

# Generated at 2022-06-17 03:05:55.898564
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='default') == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=False) == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=True) == 'default'
    assert get_file_content('/etc/passwd', default='') == ''
    assert get_file_content('/etc/passwd', default='', strip=False) == ''
    assert get_file_content('/etc/passwd', default='', strip=True) == ''

# Generated at 2022-06-17 03:06:16.903317
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default='default') == get_file_content('/etc/hosts', default='default', strip=True)
    assert get_file_content('/etc/hosts', default='default', strip=False) == get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_content('/etc/hosts', default='default', strip=False) != get_file_content('/etc/hosts', default='default', strip=True)

# Generated at 2022-06-17 03:06:27.218620
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default='default')
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd', default=None)

# Generated at 2022-06-17 03:06:30.725781
# Unit test for function get_file_content
def test_get_file_content():
    # Test file does not exist
    assert get_file_content('/tmp/doesnotexist') is None
    # Test file exists but is not readable
    assert get_file_content('/tmp/doesnotexist') is None
    # Test file exists and is readable
    assert get_file_content('/etc/hosts') is not None
    # Test file exists and is readable but is empty
    assert get_file_content('/etc/hosts') is not None
    # Test file exists and is readable but is empty
    assert get_file_content('/etc/hosts') is not None
    # Test file exists and is readable but is empty
    assert get_file_content('/etc/hosts') is not None
    # Test file exists and is readable but is empty

# Generated at 2022-06-17 03:06:41.829412
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=True) != get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default=None, strip=False) != get_file_content('/etc/passwd', default='', strip=False)
    assert get_file_content('/etc/passwd', default='', strip=False) == get_file_content('/etc/passwd', default='', strip=True)

# Generated at 2022-06-17 03:06:51.101951
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/dev/null') == ''
    assert get_file_content('/dev/null', default='foo') == 'foo'
    assert get_file_content('/dev/null', default='foo', strip=False) == 'foo'
    assert get_file_content('/dev/null', strip=False) == ''
    assert get_file_content('/dev/null', default='foo', strip=True) == 'foo'
    assert get_file_content('/dev/null', strip=True) == ''
    assert get_file_content('/dev/null', default='foo', strip=False) == 'foo'
    assert get_file_content('/dev/null', strip=False) == ''

# Generated at 2022-06-17 03:07:02.293392
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default=None, strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default=None, strip=True) == '127.0.0.1\tlocalhost\n'

# Generated at 2022-06-17 03:07:16.459093
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default='default', strip=True)
    assert get_file_content('/etc/passwd', default='default', strip=False) == get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', default='default', strip=True) == get_file_content('/etc/passwd', default='default', strip=True)

# Generated at 2022-06-17 03:07:26.102917
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='foo')

# Generated at 2022-06-17 03:07:35.026408
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='default') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='default', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='default', strip=True) == '127.0.0.1\tlocalhost'
    assert get_file_content('/etc/hosts', default='default', strip=False) == '127.0.0.1\tlocalhost\n'

# Generated at 2022-06-17 03:07:46.445099
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'