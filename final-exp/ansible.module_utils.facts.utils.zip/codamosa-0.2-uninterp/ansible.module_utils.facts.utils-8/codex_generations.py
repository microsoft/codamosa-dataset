

# Generated at 2022-06-17 02:57:54.526718
# Unit test for function get_file_lines

# Generated at 2022-06-17 02:58:01.913509
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 02:58:14.779710
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd') + '\n'
    assert get_file_content('/etc/passwd', strip=False, default='foo') == get_file_content('/etc/passwd', default='foo') + '\n'
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get

# Generated at 2022-06-17 02:58:25.951710
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='') == ''
    assert get_file_content('/etc/passwd', default='', strip=False) == ''
    assert get_file_content('/etc/passwd', default='', strip=True) == ''

# Generated at 2022-06-17 02:58:36.399104
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='', strip=False)
    assert get_file_content('/etc/hosts', default='/etc/hosts', strip=True) == get_file_content('/etc/hosts', default='', strip=True)

# Generated at 2022-06-17 02:58:48.142803
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default=None, strip=False) == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default=None, strip=False) != get_file_content('/etc/hosts', default=None, strip=False)
    assert get_file_content('/etc/hosts', default=None, strip=True) != get_file_content('/etc/hosts', default=None, strip=False)

# Generated at 2022-06-17 02:58:55.885685
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='test') == 'test'
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', strip=True) != get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', strip=True) == get_file_content

# Generated at 2022-06-17 02:59:06.194649
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False, default='foo') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=True, default='foo') == '127.0.0.1\tlocalhost'
    assert get_file_content('/etc/hosts', strip=True) == '127.0.0.1\tlocalhost'
    assert get_file_

# Generated at 2022-06-17 02:59:15.621929
# Unit test for function get_file_lines

# Generated at 2022-06-17 02:59:26.050144
# Unit test for function get_file_lines

# Generated at 2022-06-17 02:59:41.421531
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/dev/null', default='foo') == 'foo'
    assert get_file_content('/dev/null', default='foo', strip=False) == 'foo'
    assert get_file_content('/dev/null', default='') == ''
    assert get_file_content('/dev/null', default='', strip=False) == ''
    assert get_file_content('/dev/null', default=None) == None
    assert get_file_content('/dev/null', default=None, strip=False) == None
    assert get_file_content('/dev/null', default=False) == False
    assert get_file_content('/dev/null', default=False, strip=False) == False
    assert get_file_content('/dev/null', default=True) == True


# Generated at 2022-06-17 02:59:52.225251
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default=None, strip=False) == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default=None, strip=True) == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default=None, strip=False) == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=False) == get_file_content('/etc/passwd', default=None, strip=False)

# Generated at 2022-06-17 02:59:58.681385
# Unit test for function get_file_content
def test_get_file_content():
    # Test with a file that exists
    assert get_file_content('/etc/hosts') == '127.0.0.1 localhost\n'

    # Test with a file that does not exist
    assert get_file_content('/etc/does_not_exist') is None

    # Test with a file that exists but is not readable
    assert get_file_content('/etc/shadow') is None


# Generated at 2022-06-17 03:00:07.599769
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_lines('/etc/passwd', line_sep='\n')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n\n')

# Generated at 2022-06-17 03:00:17.943282
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None)
    assert get_file_content('/etc/hosts', default='test') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', strip=False)
    assert get_file_content('/etc/hosts', strip=False, default='test') == get_file_content('/etc/hosts', strip=False)
    assert get_file_content('/etc/hosts', strip=False, default='test') != get_file_

# Generated at 2022-06-17 03:00:24.046138
# Unit test for function get_file_lines

# Generated at 2022-06-17 03:00:35.908768
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_lines('/etc/passwd', line_sep='\n')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n\n')

# Generated at 2022-06-17 03:00:47.299323
# Unit test for function get_file_lines

# Generated at 2022-06-17 03:00:58.348092
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='default') == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'

# Generated at 2022-06-17 03:01:08.067441
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:01:20.936457
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='default')
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd', default='default2')
    assert get_file_content('/etc/passwd', default='default', strip=False) != get_file_content('/etc/passwd', default='default', strip=True)
    assert get_file_content('/etc/passwd', default='default', strip=False) == get_file_content('/etc/passwd', default='default', strip=False)

# Generated at 2022-06-17 03:01:26.330794
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_content('/etc/passwd').splitlines()
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_content('/etc/passwd').split('\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_content('/etc/passwd').split('\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n') == get_file_content('/etc/passwd').split('\n\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n\n') == get_file_

# Generated at 2022-06-17 03:01:37.239344
# Unit test for function get_file_lines

# Generated at 2022-06-17 03:01:46.515199
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='default') == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'

# Generated at 2022-06-17 03:01:57.328666
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_lines('/etc/passwd', line_sep='\n')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n\n')

# Generated at 2022-06-17 03:02:06.744104
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='test') == 'test'
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default=None, strip=True)

# Generated at 2022-06-17 03:02:17.816865
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'

    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True) is None

# Generated at 2022-06-17 03:02:28.068883
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', default='foo', strip=False) == get_file_content('/etc/hosts', strip=False)
    assert get_file_content('/etc/hosts', default='foo', strip=True) == get_file_content('/etc/hosts', strip=True)
    assert get_file_content('/etc/hosts', default='foo', strip=False) == get_file_content('/etc/hosts', strip=False)

# Generated at 2022-06-17 03:02:34.302084
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='') == get_file_content('/etc/hosts', default='', strip=False)
    assert get_file_content('/etc/hosts', default='') != get_file_content('/etc/hosts', default='', strip=True)
    assert get_file_content('/etc/hosts', default='') != get_file_content('/etc/hosts', default='', strip=False)
    assert get_file_content('/etc/hosts', default='', strip=True) != get_file_content('/etc/hosts', default='', strip=False)

# Generated at 2022-06-17 03:02:46.457696
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=None, strip=True)

# Generated at 2022-06-17 03:03:02.781945
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='default')
    assert get_file_content('/etc/hosts', default='default') != get_file_content('/etc/hosts', default='default2')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', strip=True)

# Generated at 2022-06-17 03:03:16.508699
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='default')
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default='default', strip=False)

# Generated at 2022-06-17 03:03:27.597582
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default='foo', strip=True)

# Generated at 2022-06-17 03:03:38.732091
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False, default='foo') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo') == '127.0.0.1\tlocalhost'
    assert get_

# Generated at 2022-06-17 03:03:47.388819
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'

    assert get_file_content('/etc/hosts', default='') == ''
    assert get_file_content('/etc/hosts', default='', strip=False) == ''
    assert get_file_content('/etc/hosts', default='', strip=True) == ''

    assert get_file_content('/etc/hosts', default=None) == '127.0.0.1\tlocalhost\n'

# Generated at 2022-06-17 03:03:51.497503
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 03:04:01.594330
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='foo', strip=False)

# Generated at 2022-06-17 03:04:08.780847
# Unit test for function get_file_content
def test_get_file_content():
    # Test for file that does not exist
    assert get_file_content('/tmp/does_not_exist') is None

    # Test for file that exists but is not readable
    assert get_file_content('/root/does_not_exist') is None

    # Test for file that exists and is readable
    assert get_file_content('/etc/hosts') is not None

    # Test for file that exists and is readable, but is empty
    assert get_file_content('/etc/hosts', default='empty') == 'empty'

    # Test for file that exists and is readable, but has no content
    assert get_file_content('/etc/hosts', default='empty', strip=False) == ''

    # Test for file that exists and is readable, but has no content

# Generated at 2022-06-17 03:04:18.955717
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default=None, strip=True) != get_file_content('/etc/hosts', default=None, strip=False)
    assert get_file_content('/etc/hosts', default=None, strip=False) == get_file_content('/etc/hosts', default=None, strip=False)
    assert get_file_content('/etc/hosts', default=None, strip=False) != get_file_content('/etc/hosts', default=None, strip=True)

# Generated at 2022-06-17 03:04:29.501884
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'

# Generated at 2022-06-17 03:04:46.943162
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:04:55.871004
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', strip=False).endswith('\n')
    assert get_file_content('/etc/passwd', strip=True).endswith('\n')
    assert get_file_content('/etc/passwd', strip=True).strip() == get_file_content('/etc/passwd', strip=True)
    assert get_file_content('/etc/passwd', strip=True).strip() == get_file_content('/etc/passwd', strip=True)

# Generated at 2022-06-17 03:05:04.268049
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default='foo', strip=True)

# Generated at 2022-06-17 03:05:17.502473
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', strip=False).endswith('\n')
    assert get_file_content('/etc/passwd', strip=False).startswith('root:')
    assert get_file_content('/etc/passwd', strip=True).startswith('root:')
    assert get_file_content('/etc/passwd', strip=True).endswith('\n')

# Generated at 2022-06-17 03:05:29.169571
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='') != get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='') != get_file_

# Generated at 2022-06-17 03:05:37.220352
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='') != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='') != get_file_

# Generated at 2022-06-17 03:05:47.297205
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='default') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', default='default') != get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', strip=False, default='')
    assert get_file_content('/etc/hosts', strip=False, default='default') == get_file_

# Generated at 2022-06-17 03:05:57.957327
# Unit test for function get_file_content
def test_get_file_content():
    # Test file does not exist
    assert get_file_content('/tmp/does_not_exist') is None

    # Test file exists and is readable
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'

    # Test file exists and is readable, but is empty
    assert get_file_content('/etc/mtab') == ''

    # Test file exists and is readable, but is empty, with a default value
    assert get_file_content('/etc/mtab', default='foo') == 'foo'

    # Test file exists and is readable, but is empty, with a default value
    assert get_file_content('/etc/mtab', default='foo', strip=False) == 'foo'

    # Test file exists and is readable, but is empty, with a default

# Generated at 2022-06-17 03:06:06.764594
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', strip=False)
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', strip=True)
    assert get_file_content('/etc/hosts', default='default') == get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_content('/etc/hosts', default='default') == get_file_content('/etc/hosts', default='default', strip=True)
    assert get_file_content('/etc/hosts', default='default') == get_file_content('/etc/hosts', strip=False)

# Generated at 2022-06-17 03:06:17.988773
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:06:32.654482
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', strip=True) == get_file_content('/etc/hosts', default='foo', strip=True)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='foo', strip=True)
    assert get_file_content('/etc/hosts', strip=True) != get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content

# Generated at 2022-06-17 03:06:42.991150
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo') != 'bar'
    assert get_file_content('/etc/passwd', default='foo', strip=False) != 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) != 'bar'
    assert get_file_content('/etc/passwd', default='foo', strip=False) != ''
    assert get_file_content('/etc/passwd', default='foo', strip=False) != '\n'
    assert get_file_content('/etc/passwd', default='foo', strip=False) != '\n\n'

# Generated at 2022-06-17 03:06:52.263110
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False, default='foo') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False, default='foo') == '127.0.0.1\tlocalhost\n'

# Generated at 2022-06-17 03:07:03.748799
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar', strip=True)
    assert get_file_content('/etc/passwd') != get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content

# Generated at 2022-06-17 03:07:17.197752
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None)
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', strip=False)

# Generated at 2022-06-17 03:07:27.004179
# Unit test for function get_file_content
def test_get_file_content():
    # Test file does not exist
    assert get_file_content('/tmp/does_not_exist') is None
    # Test file exists but is not readable
    assert get_file_content('/tmp/does_not_exist', default='default') == 'default'
    # Test file exists and is readable
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='default')
    # Test file exists and is readable but is empty
    assert get_file_content('/etc/hosts', default='default') == 'default'
    # Test file exists and is readable but is empty
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    # Test file exists and is readable but is empty

# Generated at 2022-06-17 03:07:35.362616
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'


# Generated at 2022-06-17 03:07:46.610863
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'