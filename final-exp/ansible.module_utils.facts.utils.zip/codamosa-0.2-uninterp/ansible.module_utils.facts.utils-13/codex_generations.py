

# Generated at 2022-06-17 02:58:00.035603
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/proc/cpuinfo') == get_file_content('/proc/cpuinfo', strip=True).splitlines()
    assert get_file_lines('/proc/cpuinfo', line_sep='\n') == get_file_content('/proc/cpuinfo', strip=True).split('\n')
    assert get_file_lines('/proc/cpuinfo', line_sep='\n\n') == get_file_content('/proc/cpuinfo', strip=True).split('\n\n')
    assert get_file_lines('/proc/cpuinfo', line_sep='\n\n\n') == get_file_content('/proc/cpuinfo', strip=True).split('\n\n\n')

# Generated at 2022-06-17 02:58:09.273467
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='', strip=False)
    assert get_file_content('/etc/hosts', default='', strip=False) != get_file_content('/etc/hosts', default='', strip=True)
    assert get_file_content('/etc/hosts', default='', strip=False) != get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_content('/etc/hosts', default='default', strip=False) == get_file_content('/etc/hosts', default='default', strip=True)

# Generated at 2022-06-17 02:58:18.717535
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd', default='default2')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', strip=True)
    assert get_file_content('/etc/passwd', strip=False) != get_file

# Generated at 2022-06-17 02:58:27.236471
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='foo', strip=False)

# Generated at 2022-06-17 02:58:36.621903
# Unit test for function get_file_lines

# Generated at 2022-06-17 02:58:48.273157
# Unit test for function get_file_lines

# Generated at 2022-06-17 02:58:57.298236
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='') != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='') != get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', default='') != get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', default='') != get_file_content('/etc/passwd', default='foo', strip=False)

# Generated at 2022-06-17 02:59:08.238556
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_lines('/etc/passwd', line_sep='\n')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n\n')

# Generated at 2022-06-17 02:59:18.673206
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content("/etc/hosts") == get_file_content("/etc/hosts", default="")
    assert get_file_content("/etc/hosts", strip=False) == get_file_content("/etc/hosts", default="", strip=False)
    assert get_file_content("/etc/hosts", default="") != get_file_content("/etc/hosts", default="default")
    assert get_file_content("/etc/hosts", strip=False) != get_file_content("/etc/hosts", strip=True)
    assert get_file_content("/etc/hosts", strip=False) != get_file_content("/etc/hosts", strip=True, default="")

# Generated at 2022-06-17 02:59:26.207336
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/hosts') == ['127.0.0.1\tlocalhost', '127.0.1.1\tubuntu']
    assert get_file_lines('/etc/hosts', strip=False) == ['127.0.0.1\tlocalhost\n', '127.0.1.1\tubuntu\n']
    assert get_file_lines('/etc/hosts', line_sep='\n') == ['127.0.0.1\tlocalhost', '127.0.1.1\tubuntu']
    assert get_file_lines('/etc/hosts', line_sep='\n', strip=False) == ['127.0.0.1\tlocalhost', '127.0.1.1\tubuntu']

# Generated at 2022-06-17 02:59:40.324321
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') is not None
    assert get_file_content('/etc/passwd', default='foo') is not None
    assert get_file_content('/etc/passwd', default='foo') != 'foo'
    assert get_file_content('/etc/passwd', strip=False) is not None
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', strip=False).endswith('\n')
    assert get_file_content('/etc/passwd', strip=True).endswith('\n') is False

# Generated at 2022-06-17 02:59:51.215246
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='', strip=True)
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='', strip=False)
    assert get_file_content('/etc/hosts', default='', strip=False) == get_file_content('/etc/hosts', default='', strip=False)
    assert get_file_content('/etc/hosts', default='', strip=True) == get_file_content('/etc/hosts', default='', strip=True)

# Generated at 2022-06-17 03:00:02.645978
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', strip=False, default='')
    assert get_file_content('/etc/hosts', strip=False, default='foo') == get_file_

# Generated at 2022-06-17 03:00:16.400312
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:00:22.481568
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='') == ''
    assert get_file_content('/etc/hosts', default='', strip=False) == ''
    assert get_file_content('/etc/hosts', default='', strip=True) == ''
    assert get_file_content('/etc/hosts', default=None) == '127.0.0.1\tlocalhost\n'

# Generated at 2022-06-17 03:00:28.267840
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='default') == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'

# Generated at 2022-06-17 03:00:37.633387
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='default') == 'default'
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False, default='default') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='default', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='default') == '127.0.0.1\tlocalhost'
    assert get_

# Generated at 2022-06-17 03:00:44.449124
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default=None, strip=True) != get_file_content('/etc/hosts', default=None, strip=False)
    assert get_file_content('/etc/hosts', default=None, strip=False) == get_file_content('/etc/hosts', default=None, strip=False)
    assert get_file_content('/etc/hosts', default=None, strip=True) != get_file_content('/etc/hosts', default=None, strip=False)

# Generated at 2022-06-17 03:00:54.735510
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content('/etc/passwd', default='foo', strip=False) == get_file_content('/etc/passwd', default='foo', strip=False)

# Generated at 2022-06-17 03:01:04.649041
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', strip=False)
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd') != get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get_file_

# Generated at 2022-06-17 03:01:17.264748
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', strip=False, default='')
    assert get_file_content('/etc/hosts', strip=False, default='foo') == get_file_

# Generated at 2022-06-17 03:01:29.658060
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', strip=False, default='foo') == get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', strip=False, default='foo') == get_file_content('/etc/passwd', strip=False)

# Generated at 2022-06-17 03:01:39.642362
# Unit test for function get_file_content
def test_get_file_content():
    # Test file with content
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'

    # Test file with no content
    assert get_file_content('/etc/hosts', 'no content') == 'no content'

    # Test file with no content and no default
    assert get_file_content('/etc/hosts') == ''

    # Test file with no content and no default and strip=False
    assert get_file_content('/etc/hosts', strip=False) == ''

    # Test file with content and strip=False
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'

    # Test file with no content and no default and strip=False
    assert get_file_

# Generated at 2022-06-17 03:01:50.329207
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False, default='foo') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', strip=True, default='foo') == get_file_content('/etc/hosts', default='foo')

# Generated at 2022-06-17 03:01:59.339687
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'

# Generated at 2022-06-17 03:02:10.409406
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default=None, strip=False) == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default=None, strip=False) != get_file_content('/etc/hosts', default=None, strip=False)
    assert get_file_content('/etc/hosts', default=None, strip=True) != get_file_content('/etc/hosts', default=None, strip=False)

# Generated at 2022-06-17 03:02:16.654176
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None)
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None, strip=False)
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='foo', strip=False)

# Generated at 2022-06-17 03:02:24.393922
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', strip=False)
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts') != get_file_content('/etc/hosts', strip=False, default='foo')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', strip=False, default='foo')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', strip=False, default='foo')

# Generated at 2022-06-17 03:02:33.847662
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='default') == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'

# Generated at 2022-06-17 03:02:44.180937
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 03:03:03.170145
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default=None, strip=True) != get_file_content('/etc/hosts', default=None, strip=False)
    assert get_file_content('/etc/hosts', default=None, strip=False) != get_file_content('/etc/hosts', default='', strip=False)
    assert get_file_content('/etc/hosts', default='', strip=False) == get_file_content('/etc/hosts', default='', strip=True)

# Generated at 2022-06-17 03:03:13.283894
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None

# Generated at 2022-06-17 03:03:24.314950
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content('/etc/passwd', strip=True) != get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', strip=True) == get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content

# Generated at 2022-06-17 03:03:31.646533
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='') == ''
    assert get_file_content('/etc/hosts', default='', strip=False) == ''
    assert get_file_content('/etc/hosts', default='', strip=True) == ''
    assert get_file_content('/etc/hosts', default=None) == '127.0.0.1\tlocalhost\n'

# Generated at 2022-06-17 03:03:35.721887
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False).endswith('\n')
    assert get_file_content('/etc/hosts', strip=True).endswith('\n') is False
    assert get_file_content('/etc/hosts', strip=True) == get_file_content('/etc/hosts', strip=True)
    assert get_file_content('/etc/hosts', strip=True) == get_file_content('/etc/hosts', strip=False).strip()
    assert get_file_content

# Generated at 2022-06-17 03:03:45.258312
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', strip=False, default='')
    assert get_file_content('/etc/passwd', strip=False, default='foo') == get_file_

# Generated at 2022-06-17 03:03:54.017530
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd', default='default2')
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd', default=None, strip=False)

# Generated at 2022-06-17 03:04:04.369501
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n\n'
    assert get_file_content('/etc/hosts', default='foo') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == '127.0.0.1\tlocalhost\n\n'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == '127.0.0.1\tlocalhost'

# Generated at 2022-06-17 03:04:17.424832
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='') == ''
    assert get_file_content('/etc/hosts', default='', strip=False) == ''
    assert get_file_content('/etc/hosts', default='', strip=True) == ''
    assert get_file_content('/etc/hosts', default=None) == '127.0.0.1\tlocalhost\n'

# Generated at 2022-06-17 03:04:28.161560
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', strip=False)
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content

# Generated at 2022-06-17 03:04:54.491454
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='default') == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=False) == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=True) == 'default'
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True)

# Generated at 2022-06-17 03:05:03.887662
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='') != get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='') != get_file_

# Generated at 2022-06-17 03:05:17.350822
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='default') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='default', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'

# Generated at 2022-06-17 03:05:28.927562
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='default')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default='default', strip=True)
    assert get_file_content('/etc/passwd', strip=True) != get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', strip=True) == get_file_content('/etc/passwd', default='default', strip=True)
    assert get_file_content

# Generated at 2022-06-17 03:05:37.030295
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='', strip=False)
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar', strip=False)
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='foo', strip=True)

# Generated at 2022-06-17 03:05:47.103401
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', strip=False, default='foo')
    assert get_file_content('/etc/hosts', strip=True) == get_file_content('/etc/hosts', strip=True, default='foo')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', strip=False, default='foo')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', strip=False, default='foo')
    assert get_file_content

# Generated at 2022-06-17 03:05:57.772954
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', strip=False, default='')
    assert get_file_content('/etc/hosts', strip=False, default='foo') == get_file_

# Generated at 2022-06-17 03:06:06.669091
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', default='foo') != 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) != 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) != get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo', strip=False) == get_file_content('/etc/hosts', default='foo', strip=False)
   

# Generated at 2022-06-17 03:06:11.707459
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='default') == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=None, strip=True)

# Generated at 2022-06-17 03:06:21.355631
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default=None, strip=False) == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default=None, strip=True) == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default=None, strip=False) != get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=False) != get_file_content('/etc/passwd', default=None, strip=True)

# Generated at 2022-06-17 03:07:03.672622
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default='default') == get_file_content('/etc/hosts', default='default', strip=True)
    assert get_file_content('/etc/hosts', default='default', strip=False) == get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_content('/etc/hosts', default='default', strip=False) != get_file_content('/etc/hosts', default='default', strip=True)

# Generated at 2022-06-17 03:07:17.163578
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1 localhost'
    assert get_file_content('/etc/hosts', default='foo') == '127.0.0.1 localhost'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == '127.0.0.1 localhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1 localhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == '127.0.0.1 localhost'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == '127.0.0.1 localhost\n'

# Generated at 2022-06-17 03:07:26.963602
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='default') == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=None, strip=True)

# Generated at 2022-06-17 03:07:35.293049
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo', strip=True)

# Generated at 2022-06-17 03:07:46.612109
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content('/etc/passwd', strip=True) != get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', strip=True) == get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content