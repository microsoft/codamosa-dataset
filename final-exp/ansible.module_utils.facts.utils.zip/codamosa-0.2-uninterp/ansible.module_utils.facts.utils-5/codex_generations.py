

# Generated at 2022-06-17 02:57:54.526769
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_lines('/etc/passwd', line_sep='\n')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n\n')

# Generated at 2022-06-17 02:58:04.708389
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 02:58:16.388475
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd', line_sep=':') == ['root', 'x', '0', '0', 'root', '/root', '/bin/bash']
    assert get_file_lines('/etc/passwd', line_sep='\n') == ['root:x:0:0:root:/root:/bin/bash']
    assert get_file_lines('/etc/passwd', line_sep='\n', strip=False) == ['root:x:0:0:root:/root:/bin/bash\n']
    assert get_file_lines('/etc/passwd', line_sep='\n', strip=False) == ['root:x:0:0:root:/root:/bin/bash\n']

# Generated at 2022-06-17 02:58:26.085066
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_lines('/etc/passwd', line_sep='\n')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n\n')

# Generated at 2022-06-17 02:58:30.545016
# Unit test for function get_file_content
def test_get_file_content():
    # Test file exists and is readable
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    # Test file exists but is not readable
    assert get_file_content('/etc/shadow') is None
    # Test file does not exist
    assert get_file_content('/etc/does_not_exist') is None
    # Test file exists and is readable, but has no content
    assert get_file_content('/etc/mtab') == ''
    # Test file exists and is readable, but has no content, but default value is set
    assert get_file_content('/etc/mtab', default='foo') == 'foo'
    # Test file exists and is readable, but has no content, but default value is set and strip is True

# Generated at 2022-06-17 02:58:43.094750
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_content('/etc/passwd', strip=True).splitlines()
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_content('/etc/passwd', strip=True).split('\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_content('/etc/passwd', strip=True).split('\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n', strip=False) == get_file_content('/etc/passwd', strip=False).split('\n\n')

# Generated at 2022-06-17 02:58:52.597656
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content('/etc/passwd', default='foo', strip=False) == get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo', strip=True)

# Generated at 2022-06-17 02:58:59.464878
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo', strip=False) == get_file_content('/etc/passwd', default='foo', strip=False)

# Generated at 2022-06-17 02:59:10.357336
# Unit test for function get_file_lines

# Generated at 2022-06-17 02:59:16.631106
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'

# Generated at 2022-06-17 02:59:30.562984
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'

# Generated at 2022-06-17 02:59:39.568127
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='default')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default='default', strip=True)
    assert get_file_content('/etc/passwd', strip=True) != get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', strip=True) == get_file_content('/etc/passwd', default='default', strip=True)
    assert get_file_content

# Generated at 2022-06-17 02:59:50.639031
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo', strip=False) == get_file_content('/etc/passwd', strip=False)
    assert get_file_content('/etc/passwd', default='foo', strip=True) == get_file_content('/etc/passwd', strip=True)
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', strip=True)

# Generated at 2022-06-17 03:00:01.916310
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:00:16.077225
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='') != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') != get_file_

# Generated at 2022-06-17 03:00:22.075553
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='default') == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'

# Generated at 2022-06-17 03:00:28.072476
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='default') == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=False) == 'default'
    assert get_file_content('/etc/passwd', default='') == ''
    assert get_file_content('/etc/passwd', default='', strip=False) == ''

# Generated at 2022-06-17 03:00:37.606040
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 03:00:44.765435
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False, default='foo') == '127.0.0.1\tlocalhost\n'

# Generated at 2022-06-17 03:00:54.884551
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1 localhost'
    assert get_file_content('/etc/hosts', default='foo') == '127.0.0.1 localhost'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1 localhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == '127.0.0.1 localhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == '127.0.0.1 localhost'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == '127.0.0.1 localhost\n'

# Generated at 2022-06-17 03:01:04.817821
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='') != get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) != 'foo\n'

# Generated at 2022-06-17 03:01:13.589804
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default=None, strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:01:21.825922
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default='test') == get_file_content('/etc/hosts', default='test', strip=True)
    assert get_file_content('/etc/hosts', default='test') != get_file_content('/etc/hosts', default='test2', strip=True)
    assert get_file_content('/etc/hosts', default='test', strip=False) != get_file_content('/etc/hosts', default='test', strip=True)

# Generated at 2022-06-17 03:01:32.505278
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', default='foo', strip=False) != get_file_content('/etc/hosts', default='bar', strip=False)
    assert get_file_content('/etc/hosts', default='foo', strip=False) != get_file_content('/etc/hosts', default='foo')
    assert get_file_content

# Generated at 2022-06-17 03:01:40.936547
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='default') == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'

# Generated at 2022-06-17 03:01:51.433493
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:02:00.090203
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:02:11.718996
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/dev/null', default='foo') == 'foo'
    assert get_file_content('/dev/null', default='foo', strip=False) == 'foo'
    assert get_file_content('/dev/null') is None
    assert get_file_content('/dev/null', strip=False) is None
    assert get_file_content('/dev/null', default='foo', strip=True) == 'foo'
    assert get_file_content('/dev/null', default='foo', strip=False) == 'foo'
    assert get_file_content('/dev/null', default=None, strip=True) is None
    assert get_file_content('/dev/null', default=None, strip=False) is None

# Generated at 2022-06-17 03:02:20.083614
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', strip=True) == get_file_content('/etc/hosts', default='foo', strip=True)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='foo', strip=True)
    assert get_file_content('/etc/hosts', strip=True) != get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content

# Generated at 2022-06-17 03:02:30.742591
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None)
    assert get_file_content('/etc/hosts', default='default') == get_file_content('/etc/hosts', default=None)
    assert get_file_content('/etc/hosts', default='default') != get_file_content('/etc/hosts', default='default2')
    assert get_file_content('/etc/hosts', default='default', strip=False) != get_file_content('/etc/hosts', default='default', strip=True)
    assert get_file_content('/etc/hosts', default='default', strip=False) == get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_

# Generated at 2022-06-17 03:02:43.205393
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 03:02:49.948025
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:03:01.343917
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None)
    assert get_file_content('/etc/hosts') != get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts') != get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', strip=False) == get_file_

# Generated at 2022-06-17 03:03:11.805043
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=False, strip=False) is False
    assert get_file_content('/etc/hosts', default=False, strip=True) is False
    assert get_file_content('/etc/hosts', default=True, strip=False)

# Generated at 2022-06-17 03:03:24.216143
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 03:03:31.547375
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', strip=False, default='default') == get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', strip=False, default='default') == get_file_content('/etc/passwd', default='default', strip=False)
    assert get

# Generated at 2022-06-17 03:03:39.712039
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='default') == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=None, strip=True)

# Generated at 2022-06-17 03:03:49.152607
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content('/etc/passwd', strip=True) != get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', strip=True) == get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content

# Generated at 2022-06-17 03:03:55.821064
# Unit test for function get_file_content
def test_get_file_content():
    # Test with a file that does not exist
    assert get_file_content('/tmp/doesnotexist') is None

    # Test with a file that exists but is not readable
    assert get_file_content('/tmp/doesnotexist') is None

    # Test with a file that exists and is readable
    assert get_file_content('/etc/hosts') is not None

    # Test with a file that exists and is readable, but has no content
    assert get_file_content('/etc/mtab') is None

    # Test with a file that exists and is readable, but has no content
    assert get_file_content('/etc/mtab', default='default') == 'default'

    # Test with a file that exists and is readable, but has no content

# Generated at 2022-06-17 03:04:05.538000
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='default') != 'default'
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default='default')
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/group', default='default')
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd', default='default', strip=False).strip()
    assert get_file_content('/etc/passwd', default='default') == get_file_

# Generated at 2022-06-17 03:04:19.443144
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default='default', strip=True)
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default='default', strip=False) == get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default='default', strip=True)

# Generated at 2022-06-17 03:04:29.980805
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True)

# Generated at 2022-06-17 03:04:40.104574
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=True) != get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default=None, strip=False) != get_file_content('/etc/passwd', default='', strip=False)
    assert get_file_content('/etc/passwd', default='', strip=False) == get_file_content('/etc/passwd', default='', strip=True)

# Generated at 2022-06-17 03:04:50.882286
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/dev/null', default='foo') == 'foo'
    assert get_file_content('/dev/null', default='foo', strip=False) == 'foo'
    assert get_file_content('/dev/null', default='foo', strip=True) == 'foo'
    assert get_file_content('/dev/null', default=None) is None
    assert get_file_content('/dev/null', default=None, strip=False) is None
    assert get_file_content('/dev/null', default=None, strip=True) is None
    assert get_file_content('/dev/null', default='') == ''
    assert get_file_content('/dev/null', default='', strip=False) == ''

# Generated at 2022-06-17 03:04:57.753079
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default=None, strip=True) == 'root:x:0:0:root:/root:/bin/bash\n'
    assert get_file_content('/etc/passwd', default=None, strip=False) == 'root:x:0:0:root:/root:/bin/bash\n'

# Generated at 2022-06-17 03:05:04.811103
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='') != get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='foo', strip=False)

# Generated at 2022-06-17 03:05:16.836662
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=True) == '127.0.0.1\tlocalhost'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:05:27.830736
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='no_file') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False, default='no_file') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=True) == '127.0.0.1\tlocalhost'

# Generated at 2022-06-17 03:05:36.347105
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='') == ''
    assert get_file_content('/etc/hosts', default='', strip=False) == ''
    assert get_file_content('/etc/hosts', default='', strip=True) == ''
    assert get_file_content('/etc/hosts', default=None) == '127.0.0.1\tlocalhost\n'

# Generated at 2022-06-17 03:05:46.326347
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False, default='foo') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=True) == '127.0.0.1\tlocalhost'

# Generated at 2022-06-17 03:06:03.466014
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='default')
    assert get_file_content('/etc/passwd', strip=False)
    assert get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', default='default', strip=True)
    assert get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', default='default', strip=True)
    assert get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', default='default', strip=True)

# Generated at 2022-06-17 03:06:16.904067
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='nope') == 'nope'
    assert get_file_content('/etc/hosts', default='nope', strip=False) == 'nope'
    assert get_file_content('/etc/hosts', default='nope', strip=True) == 'nope'
    assert get_file_content('/etc/hosts', default='nope', strip=False) == 'nope'
    assert get_file_content('/etc/hosts', default='nope', strip=True) == 'nope'
    assert get_file_content('/etc/hosts', default='nope', strip=False) == 'nope'
    assert get_file_content('/etc/hosts', default='nope', strip=True) == 'nope'


# Generated at 2022-06-17 03:06:27.218793
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='foo', strip=True)
    assert get_file_content('/etc/hosts', strip=True) != get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', strip=True) == get_file_content('/etc/hosts', default='foo', strip=True)
    assert get_file_content

# Generated at 2022-06-17 03:06:33.618503
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 03:06:43.815190
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/proc/cpuinfo')
    assert get_file_content('/proc/cpuinfo', default='foo') == 'foo'
    assert get_file_content('/proc/cpuinfo', strip=False)
    assert get_file_content('/proc/cpuinfo', strip=False, default='foo') == 'foo'
    assert get_file_content('/proc/cpuinfo', strip=True)
    assert get_file_content('/proc/cpuinfo', strip=True, default='foo') == 'foo'
    assert get_file_content('/proc/cpuinfo', strip=False)
    assert get_file_content('/proc/cpuinfo', strip=False, default='foo') == 'foo'
    assert get_file_content('/proc/cpuinfo', strip=True)
    assert get_

# Generated at 2022-06-17 03:06:53.007791
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default='default') == get_file_content('/etc/hosts', default='default', strip=True)
    assert get_file_content('/etc/hosts', default='default', strip=False) == get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_content('/etc/hosts', default='default', strip=False) == get_file_content('/etc/hosts', default='default', strip=False)

# Generated at 2022-06-17 03:07:04.596238
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=True) != get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default=None, strip=False) != get_file_content('/etc/passwd', default='', strip=False)
    assert get_file_content('/etc/passwd', default='', strip=False) == get_file_content('/etc/passwd', default='', strip=True)

# Generated at 2022-06-17 03:07:17.510421
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='foo', strip=False)

# Generated at 2022-06-17 03:07:27.256262
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='foo', strip=True)
    assert get_file_content('/etc/hosts', strip=True) != get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', strip=True) == get_file_content('/etc/hosts', default='foo', strip=True)
    assert get_file_content

# Generated at 2022-06-17 03:07:35.530586
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', strip=False).startswith('root:x:0:0:root:')
    assert get_file_content('/etc/passwd', strip=False).endswith(':/root:/bin/bash\n')
    assert get_file_content('/etc/passwd', strip=True).startswith('root:x:0:0:root:')
    assert get_file_content('/etc/passwd', strip=True).endswith(':/root:/bin/bash')
    assert get