

# Generated at 2022-06-17 02:57:55.405159
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_content('/etc/passwd').splitlines()
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_content('/etc/passwd').split('\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_content('/etc/passwd').split('\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n') == get_file_content('/etc/passwd').split('\n\n\n')

# Generated at 2022-06-17 02:58:06.314856
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1 localhost'
    assert get_file_content('/etc/hosts', default='foo') == '127.0.0.1 localhost'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1 localhost\n'
    assert get_file_content('/etc/hosts', strip=False, default='foo') == '127.0.0.1 localhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == '127.0.0.1 localhost\n'
    assert get_file_content('/etc/hosts', default='foo') == '127.0.0.1 localhost'
    assert get

# Generated at 2022-06-17 02:58:16.287357
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_lines('/etc/passwd', line_sep='\n')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n\n')

# Generated at 2022-06-17 02:58:26.054455
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=False, strip=True) is False
    assert get_file_content('/etc/hosts', default=False, strip=False) is False
    assert get_file_content('/etc/hosts', default=True, strip=True)

# Generated at 2022-06-17 02:58:36.398826
# Unit test for function get_file_lines
def test_get_file_lines():
    test_file = '/tmp/test_get_file_lines'
    with open(test_file, 'w') as f:
        f.write('line1\nline2\nline3\n')

    assert get_file_lines(test_file) == ['line1', 'line2', 'line3']
    assert get_file_lines(test_file, line_sep='\n') == ['line1', 'line2', 'line3']
    assert get_file_lines(test_file, line_sep='\n\n') == ['line1\nline2\nline3']
    assert get_file_lines(test_file, line_sep='\n\n\n') == ['line1\nline2\nline3\n']

# Generated at 2022-06-17 02:58:48.142380
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_content('/etc/passwd').splitlines()
    assert get_file_lines('/etc/passwd', strip=False) == get_file_content('/etc/passwd', strip=False).splitlines()
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_content('/etc/passwd').split('\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_content('/etc/passwd').split('\n\n')

# Generated at 2022-06-17 02:58:57.262990
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/proc/cpuinfo') == get_file_content('/proc/cpuinfo').splitlines()
    assert get_file_lines('/proc/cpuinfo', line_sep='\n') == get_file_content('/proc/cpuinfo').split('\n')
    assert get_file_lines('/proc/cpuinfo', line_sep='\n\n') == get_file_content('/proc/cpuinfo').split('\n\n')
    assert get_file_lines('/proc/cpuinfo', line_sep='\n\n\n') == get_file_content('/proc/cpuinfo').split('\n\n\n')
    assert get_file_lines('/proc/cpuinfo', line_sep='\n\n\n\n') == get_file_

# Generated at 2022-06-17 02:59:08.200524
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='') == ''
    assert get_file_content('/etc/hosts', default='', strip=False) == ''
    assert get_file_content('/etc/hosts', default='', strip=True) == ''
    assert get_file_content('/etc/hosts', default=None) == '127.0.0.1\tlocalhost\n'

# Generated at 2022-06-17 02:59:16.216484
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', strip=False)
    assert get_file_content('/etc/passwd') != get_file_content('/etc/passwd', strip=False, default='foo')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd', strip=False, default='foo')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', strip=False)
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd', default='foo')

# Generated at 2022-06-17 02:59:26.072864
# Unit test for function get_file_content
def test_get_file_content():
    # Test for file that does not exist
    assert get_file_content('/tmp/doesnotexist') is None

    # Test for file that exists
    assert get_file_content('/etc/hosts') is not None

    # Test for file that exists but is not readable
    assert get_file_content('/etc/shadow') is None

    # Test for file that exists and is readable
    assert get_file_content('/etc/hosts') is not None

    # Test for file that exists and is readable but is empty
    assert get_file_content('/etc/hosts') is not None

    # Test for file that exists and is readable but is empty
    assert get_file_content('/etc/hosts') is not None

    # Test for file that exists and is readable but is empty

# Generated at 2022-06-17 02:59:40.350578
# Unit test for function get_file_lines

# Generated at 2022-06-17 02:59:51.216233
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_content('/etc/passwd', strip=True).splitlines()
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_content('/etc/passwd', strip=True).splitlines()
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_content('/etc/passwd', strip=True).split('\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_content('/etc/passwd', strip=True).split('\n\n')

# Generated at 2022-06-17 03:00:02.642582
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:00:16.402483
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/proc/cpuinfo') == get_file_content('/proc/cpuinfo', strip=True).splitlines()
    assert get_file_lines('/proc/cpuinfo', line_sep='\n') == get_file_content('/proc/cpuinfo', strip=True).split('\n')
    assert get_file_lines('/proc/cpuinfo', line_sep='\n\n') == get_file_content('/proc/cpuinfo', strip=True).split('\n\n')
    assert get_file_lines('/proc/cpuinfo', line_sep='\n\n\n') == get_file_content('/proc/cpuinfo', strip=True).split('\n\n\n')

# Generated at 2022-06-17 03:00:24.282251
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/proc/cpuinfo') == get_file_content('/proc/cpuinfo').splitlines()
    assert get_file_lines('/proc/cpuinfo', line_sep='\n') == get_file_content('/proc/cpuinfo').split('\n')
    assert get_file_lines('/proc/cpuinfo', line_sep='\n\n') == get_file_content('/proc/cpuinfo').split('\n\n')
    assert get_file_lines('/proc/cpuinfo', line_sep='\n\n\n') == get_file_content('/proc/cpuinfo').split('\n\n\n')
    assert get_file_lines('/proc/cpuinfo', line_sep='\n\n\n\n') == get_file_

# Generated at 2022-06-17 03:00:36.163290
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:00:47.383774
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:00:58.346725
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 03:01:04.902731
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_lines('/etc/passwd', line_sep='\n')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n\n')

# Generated at 2022-06-17 03:01:13.701060
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_content('/etc/passwd', strip=True).splitlines()
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_content('/etc/passwd', strip=True).split('\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_content('/etc/passwd', strip=True).split('\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n') == get_file_content('/etc/passwd', strip=True).split('\n\n\n')

# Generated at 2022-06-17 03:01:29.698136
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default='foo', strip=True)

# Generated at 2022-06-17 03:01:39.453622
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:01:50.193118
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='', strip=True)
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='', strip=False)
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='', strip=False)
    assert get_file_content('/etc/hosts', strip=True) == get_file_content('/etc/hosts', default='', strip=True)

# Generated at 2022-06-17 03:01:59.302477
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='default')
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd', default='default2')
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', strip=True)
    assert get_file_content('/etc/passwd', default='default', strip=False) != get_file_content('/etc/passwd', default='default', strip=True)
    assert get_file_content('/etc/passwd', default='default', strip=False) != get_file_content('/etc/passwd', default='default2', strip=False)
    assert get_file

# Generated at 2022-06-17 03:02:10.021761
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd') != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd') != get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default='', strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get

# Generated at 2022-06-17 03:02:19.532360
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'

# Generated at 2022-06-17 03:02:30.643406
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='') != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo', strip=False) == get_file_content('/etc/passwd', default='foo', strip=False)

# Generated at 2022-06-17 03:02:42.874374
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo') != 'bar'
    assert get_file_content('/etc/passwd', default='foo') != ''
    assert get_file_content('/etc/passwd', default='foo') != None
    assert get_file_content('/etc/passwd', default='foo') != 'foo\n'
    assert get_file_content('/etc/passwd', default='foo', strip=False) != 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) != 'foo\n'
    assert get_file_content('/etc/passwd', default='foo', strip=False) != ''
    assert get_file

# Generated at 2022-06-17 03:02:47.931669
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None)
    assert get_file_content('/etc/hosts') != get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts') != get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default=None, strip=False)

# Generated at 2022-06-17 03:02:58.999228
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=True) == '127.0.0.1\tlocalhost'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == '127.0.0.1\tlocalhost'
    assert get_file_

# Generated at 2022-06-17 03:03:11.827357
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='default') != 'default'
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='default', strip=False) != get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='default', strip=False) != get_file_content('/etc/passwd', strip=False)
    assert get_file_content('/etc/passwd', default='default', strip=False) != get_file_content('/etc/passwd', strip=True)
    assert get_file_content('/etc/passwd', default='default', strip=True) != get_file_content

# Generated at 2022-06-17 03:03:24.250904
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', strip=False, default='foo') == get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', strip=False, default='foo') == get_file_content('/etc/passwd', strip=False)

# Generated at 2022-06-17 03:03:31.580410
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == '127.0.0.1\tlocalhost'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == '127.0.0.1\tlocalhost\n'

# Generated at 2022-06-17 03:03:35.649535
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='default') != 'default'
    assert get_file_content('/etc/passwd', default='default', strip=False) != 'default'
    assert get_file_content('/etc/passwd', default='default', strip=True) != 'default'
    assert get_file_content('/etc/passwd', default='default', strip=False) != 'default'
    assert get_file_content('/etc/passwd', default='default', strip=True) != 'default'
    assert get_file_content('/etc/passwd', default='default', strip=False) != 'default'
    assert get_file_content('/etc/passwd', default='default', strip=True) != 'default'

# Generated at 2022-06-17 03:03:43.489420
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', strip=False, default='')
    assert get_file_content('/etc/passwd', strip=False, default='foo') == get_file_

# Generated at 2022-06-17 03:03:53.141992
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 03:04:03.673655
# Unit test for function get_file_content
def test_get_file_content():
    # Test file does not exist
    assert get_file_content('/tmp/does_not_exist', default='test') == 'test'

    # Test file exists and is readable
    assert get_file_content('/etc/hosts', default='test') != 'test'

    # Test file exists but is not readable
    assert get_file_content('/etc/shadow', default='test') == 'test'

    # Test file exists and is readable but is empty
    assert get_file_content('/etc/shadow', default='test') == 'test'

    # Test file exists and is readable but is empty
    assert get_file_content('/etc/shadow', default='test') == 'test'

    # Test file exists and is readable but is empty
    assert get_file_content('/etc/shadow', default='test') == 'test'

# Generated at 2022-06-17 03:04:17.112157
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', strip=True)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', strip=True, default='foo')
    assert get_file_content('/etc/hosts', strip=False, default='foo') != get_file_content('/etc/hosts', strip=True, default='foo')

# Generated at 2022-06-17 03:04:27.774769
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/dev/null') == ''
    assert get_file_content('/dev/null', default='foo') == 'foo'
    assert get_file_content('/dev/null', default='foo', strip=False) == 'foo'
    assert get_file_content('/dev/null', strip=False) == ''
    assert get_file_content('/dev/null', default='foo', strip=True) == 'foo'
    assert get_file_content('/dev/null', strip=True) == ''
    assert get_file_content('/dev/null', default='foo', strip=False) == 'foo'
    assert get_file_content('/dev/null', strip=False) == ''

# Generated at 2022-06-17 03:04:35.125226
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='') == ''
    assert get_file_content('/etc/hosts', default='', strip=False) == ''
    assert get_file_content('/etc/hosts', default='', strip=True) == ''

# Generated at 2022-06-17 03:04:47.479416
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None)
    assert get_file_content('/etc/hosts', default=None) != get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default=None, strip=True) == get_file_content('/etc/hosts', default=None, strip=False)
    assert get_file_content('/etc/hosts', default=None, strip=True) != get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default=None, strip=False) != get_file_content('/etc/hosts', default=None, strip=False)

# Generated at 2022-06-17 03:04:56.210614
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='default') != 'default'
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd', strip=False)
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd', strip=False).strip()
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', strip=True)

# Generated at 2022-06-17 03:05:04.376222
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd') != get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd') != get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get_file_

# Generated at 2022-06-17 03:05:17.539690
# Unit test for function get_file_content
def test_get_file_content():
    # Test for file that exists and is readable
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'

    # Test for file that exists and is not readable
    assert get_file_content('/etc/shadow') is None

    # Test for file that does not exist
    assert get_file_content('/etc/does_not_exist') is None

    # Test for file that exists and is readable but is empty
    assert get_file_content('/etc/empty_file') is None

    # Test for file that exists and is readable but is empty with default value
    assert get_file_content('/etc/empty_file', default='default') == 'default'

    # Test for file that exists and is readable but is empty with default value and strip

# Generated at 2022-06-17 03:05:29.247508
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', strip=False, default='')
    assert get_file_content('/etc/hosts', strip=False, default='foo') == get_file_

# Generated at 2022-06-17 03:05:37.279632
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1 localhost'
    assert get_file_content('/etc/hosts', default='foo') == '127.0.0.1 localhost'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1 localhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == '127.0.0.1 localhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == '127.0.0.1 localhost'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == '127.0.0.1 localhost\n'

# Generated at 2022-06-17 03:05:47.343681
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='default') == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=False) == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=True) == 'default'
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True)

# Generated at 2022-06-17 03:05:58.117091
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default=None, strip=True) == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default=None, strip=False) == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default=None, strip=True) == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default=None, strip=False) == get_file_content('/etc/passwd', default=None)
    assert get_file_content

# Generated at 2022-06-17 03:06:06.895106
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True)

# Generated at 2022-06-17 03:06:11.170797
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=True) != get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default=None, strip=False) != get_file_content('/etc/passwd', default='', strip=False)
    assert get_file_content('/etc/passwd', default='', strip=False) == get_file_content('/etc/passwd', default='', strip=True)

# Generated at 2022-06-17 03:06:23.452622
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:06:32.449276
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='default')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='default', strip=True)
    assert get_file_content('/etc/hosts', strip=True) == get_file_content('/etc/hosts', default='default', strip=True)
    assert get_file_content('/etc/hosts', strip=True) != get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_content

# Generated at 2022-06-17 03:06:42.837686
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=True) != get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default=None, strip=False) != get_file_content('/etc/passwd', default='', strip=False)
    assert get_file_content('/etc/passwd', default='', strip=False) != get_file_content('/etc/passwd', default='', strip=True)

# Generated at 2022-06-17 03:06:52.073010
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 03:07:03.519621
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo', strip=True)

# Generated at 2022-06-17 03:07:17.068541
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='', strip=False)
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts', default='foo', strip=True)
    assert get_file_content('/etc/hosts', default='foo', strip=False) == get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_

# Generated at 2022-06-17 03:07:26.920846
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False, default='foo') == get_file_content('/etc/hosts', strip=False)
    assert get_file_content('/etc/hosts', strip=False, default='foo') == get_file_content('/etc/hosts', default='foo')

# Generated at 2022-06-17 03:07:35.257158
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', default='foo', strip=False) == get_file_content('/etc/passwd', default='foo', strip=False)

# Generated at 2022-06-17 03:07:46.609123
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default=None, strip=True) != get_file_content('/etc/hosts', default=None, strip=False)
    assert get_file_content('/etc/hosts', default=None, strip=False) != get_file_content('/etc/hosts', default='', strip=False)
    assert get_file_content('/etc/hosts', default='', strip=False) == get_file_content('/etc/hosts', default='', strip=True)