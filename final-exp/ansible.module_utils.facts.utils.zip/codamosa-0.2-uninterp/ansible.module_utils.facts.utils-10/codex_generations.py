

# Generated at 2022-06-17 02:58:00.091763
# Unit test for function get_file_lines

# Generated at 2022-06-17 02:58:07.387697
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_content('/etc/passwd', strip=True).splitlines()
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_content('/etc/passwd', strip=True).split('\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_content('/etc/passwd', strip=True).split('\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n') == get_file_content('/etc/passwd', strip=True).split('\n\n\n')

# Generated at 2022-06-17 02:58:16.619446
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd') != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd') != get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default='', strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get

# Generated at 2022-06-17 02:58:26.110887
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo', strip=False) == get_file_content('/etc/passwd', strip=False)
    assert get_file_content('/etc/passwd', default='foo', strip=True) == get_file_content('/etc/passwd', strip=True)
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', strip=True)

# Generated at 2022-06-17 02:58:30.544954
# Unit test for function get_file_lines

# Generated at 2022-06-17 02:58:35.608091
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content('/etc/passwd', default='foo', strip=True) == get_file_content('/etc/passwd', default='foo', strip=True)

# Generated at 2022-06-17 02:58:47.654432
# Unit test for function get_file_lines

# Generated at 2022-06-17 02:58:57.227335
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_

# Generated at 2022-06-17 02:59:08.162447
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/proc/1/cmdline', line_sep='\x00') == ['/sbin/init']
    assert get_file_lines('/proc/1/cmdline', line_sep='\x00', strip=False) == ['/sbin/init\x00']
    assert get_file_lines('/proc/1/cmdline', line_sep='\x00', strip=False) == ['/sbin/init\x00']
    assert get_file_lines('/proc/1/cmdline', line_sep='\x00', strip=False) == ['/sbin/init\x00']
    assert get_file_lines('/proc/1/cmdline', line_sep='\x00', strip=False) == ['/sbin/init\x00']
   

# Generated at 2022-06-17 02:59:16.171356
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='default') == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=False) == 'default'
    assert get_file_content('/etc/hosts', default='default', strip=True) == 'default'

# Generated at 2022-06-17 02:59:30.526840
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='default') != 'default'
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default='default')
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd', default='default2')
    assert get_file_content('/etc/passwd', default='default', strip=False) != get_file_content('/etc/passwd', default='default', strip=True)
    assert get_file_content('/etc/passwd', default='default', strip=True) == get_file_content('/etc/passwd', default='default', strip=True)

# Generated at 2022-06-17 02:59:39.530343
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='default') == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=False) == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=True) == 'default'
    assert get_file_content('/etc/passwd', default='') == ''
    assert get_file_content('/etc/passwd', default='', strip=False) == ''
    assert get_file_content('/etc/passwd', default='', strip=True) == ''

# Generated at 2022-06-17 02:59:50.603826
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=True) != get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default=None, strip=True) != get_file_content('/etc/passwd', default='', strip=True)
    assert get_file_content('/etc/passwd', default='', strip=True) != get_file_content('/etc/passwd', default='', strip=False)

# Generated at 2022-06-17 03:00:01.857594
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'

# Generated at 2022-06-17 03:00:16.029267
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=False) == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default='', strip=False) == get_file_content('/etc/passwd', default='', strip=True)
    assert get_file_content('/etc/passwd', default='', strip=False) == get_file_content('/etc/passwd', default=None, strip=False)

# Generated at 2022-06-17 03:00:23.973931
# Unit test for function get_file_content
def test_get_file_content():
    # Test file does not exist
    assert get_file_content('/tmp/does_not_exist') is None

    # Test file exists but is not readable
    assert get_file_content('/etc/shadow') is None

    # Test file exists and is readable
    assert get_file_content('/etc/hosts') is not None

    # Test file exists and is readable, but is empty
    assert get_file_content('/etc/mtab') == ''

    # Test file exists and is readable, but has only whitespace
    assert get_file_content('/etc/mtab', strip=True) == ''

    # Test file exists and is readable, but has only whitespace
    assert get_file_content('/etc/mtab', strip=False) == '\n'

    # Test file exists and is readable, but has only whites

# Generated at 2022-06-17 03:00:35.840402
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', strip=False, default='')
    assert get_file_content('/etc/hosts', strip=False, default='foo') == get_file_

# Generated at 2022-06-17 03:00:47.238448
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1 localhost'
    assert get_file_content('/etc/hosts', default='127.0.0.1 localhost') == '127.0.0.1 localhost'
    assert get_file_content('/etc/hosts', default='127.0.0.1 localhost', strip=False) == '127.0.0.1 localhost\n'
    assert get_file_content('/etc/hosts', default='127.0.0.1 localhost', strip=False) == '127.0.0.1 localhost\n'

# Generated at 2022-06-17 03:00:58.346531
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=True) != get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default=None, strip=False) != get_file_content('/etc/passwd', default='', strip=False)
    assert get_file_content('/etc/passwd', default='', strip=False) == get_file_content('/etc/passwd', default='', strip=True)

# Generated at 2022-06-17 03:01:04.902806
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='default') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='default', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='default', strip=True) == '127.0.0.1\tlocalhost'
    assert get_file_content('/etc/hosts', default='default', strip=False) == '127.0.0.1\tlocalhost\n'

# Generated at 2022-06-17 03:01:17.262894
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', strip=False)
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='default')
    assert get_file_content('/etc/hosts') != get_file_content('/etc/hosts', strip=False, default='default')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', strip=False, default='default')
    assert get_file_content('/etc/hosts', default='default') != get_file_content('/etc/hosts', strip=False, default='default')

# Generated at 2022-06-17 03:01:29.658019
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/dev/null', default='foo') == 'foo'
    assert get_file_content('/dev/null', default='foo', strip=False) == 'foo'
    assert get_file_content('/dev/null', default='foo', strip=True) == 'foo'
    assert get_file_content('/dev/null', default=None, strip=True) is None
    assert get_file_content('/dev/null', default=None, strip=False) is None
    assert get_file_content('/dev/null', default='', strip=True) == ''
    assert get_file_content('/dev/null', default='', strip=False) == ''
    assert get_file_content('/dev/null', default=0, strip=True) == 0
    assert get_file_content

# Generated at 2022-06-17 03:01:39.643125
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default='default', strip=True)
    assert get_file_content('/etc/passwd', default='default', strip=False) == get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', default='default', strip=True) == get_file_content('/etc/passwd', default='default', strip=True)

# Generated at 2022-06-17 03:01:50.330312
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1 localhost\n'
    assert get_file_content('/etc/hosts', default='default') == '127.0.0.1 localhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1 localhost\n'
    assert get_file_content('/etc/hosts', default='default', strip=False) == '127.0.0.1 localhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1 localhost\n'

# Generated at 2022-06-17 03:01:59.339030
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='') != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='bar', strip=False)

# Generated at 2022-06-17 03:02:10.406857
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=True) != get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default=None, strip=False) != get_file_content('/etc/passwd', default='', strip=True)
    assert get_file_content('/etc/passwd', default='', strip=True) != get_file_content('/etc/passwd', default='', strip=False)

# Generated at 2022-06-17 03:02:19.690704
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo')

# Generated at 2022-06-17 03:02:30.710975
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/dev/null') == ''
    assert get_file_content('/dev/null', default='foo') == 'foo'
    assert get_file_content('/dev/null', default='foo', strip=False) == 'foo'
    assert get_file_content('/dev/null', strip=False) == ''
    assert get_file_content('/dev/null', default='foo', strip=True) == 'foo'
    assert get_file_content('/dev/null', strip=True) == ''
    assert get_file_content('/dev/null', default='foo', strip=False) == 'foo'
    assert get_file_content('/dev/null', strip=False) == ''

# Generated at 2022-06-17 03:02:42.874601
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd') != get_file_content('/etc/group')
    assert get_file_content('/etc/passwd') != get_file_content('/etc/shadow')
    assert get_file_content('/etc/passwd') != get_file_content('/etc/shadow', default='foo')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/shadow', default='foo')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd', default='foo')

# Generated at 2022-06-17 03:02:49.768176
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default=None, strip=True) != get_file_content('/etc/passwd', default=None, strip=False)
    assert get_file_content('/etc/passwd', default=None, strip=False) != get_file_content('/etc/passwd', default='', strip=False)
    assert get_file_content('/etc/passwd', default='', strip=False) != get_file_content('/etc/passwd', default='', strip=True)

# Generated at 2022-06-17 03:03:04.140878
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='default')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', strip=True) == get_file_content('/etc/passwd', default='default', strip=True)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default='default', strip=True)
    assert get_file_content('/etc/passwd', strip=True) != get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content

# Generated at 2022-06-17 03:03:16.913812
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd') != get_file_content('/etc/passwd', default='/etc/passwd')
    assert get_file_content('/etc/passwd') != get_file_content('/etc/passwd', default='/etc/shadow')
    assert get_file_content('/etc/passwd') != get_file_content('/etc/passwd', default='/etc/shadow', strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default='/etc/shadow', strip=False)

# Generated at 2022-06-17 03:03:27.849217
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='default') != 'default'
    assert get_file_content('/etc/hosts', default='default') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', default='default') == get_file_content('/etc/hosts', strip=False)
    assert get_file_content('/etc/hosts', default='default', strip=False) != get_file_content('/etc/hosts', strip=False)
    assert get_file_content('/etc/hosts', default='default', strip=False) != get_file_content('/etc/hosts')

# Generated at 2022-06-17 03:03:38.976865
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:03:47.405890
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', strip=False, default='')
    assert get_file_content('/etc/passwd', strip=False, default='foo') == get_file_

# Generated at 2022-06-17 03:03:51.530870
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo', strip=False) == get_file_content('/etc/passwd', default='foo', strip=False)

# Generated at 2022-06-17 03:04:01.641778
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == '127.0.0.1\tlocalhost'

# Generated at 2022-06-17 03:04:08.782410
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='default') != 'default'
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='default', strip=False) != get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='default', strip=False) != get_file_content('/etc/passwd', strip=False)
    assert get_file_content('/etc/passwd', default='default', strip=False) != get_file_content('/etc/passwd', strip=True)
    assert get_file_content('/etc/passwd', default='default', strip=True) != get_file_content

# Generated at 2022-06-17 03:04:15.149701
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:04:26.644153
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 03:04:46.335654
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='default') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', default='default') != get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='default') != get_file_content('/etc/hosts', default='default')
    assert get_file_content('/etc/hosts', default='default') != get_file_content('/etc/hosts', default='default', strip=False)

# Generated at 2022-06-17 03:04:55.438552
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd')
    assert not get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', strip=False)
    assert get_file_content('/etc/passwd', strip=False).endswith('\n')
    assert not get_file_content('/etc/passwd', strip=False).endswith(' ')
    assert get_file_content('/etc/passwd', strip=True).endswith('\n')
    assert not get_file_content('/etc/passwd', strip=True).endswith(' ')

# Generated at 2022-06-17 03:05:04.097785
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', strip=False)
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='/etc/hosts')
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='/etc/hosts', strip=False)
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='/etc/hosts', strip=False)
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='/etc/hosts')
    assert get_file_content

# Generated at 2022-06-17 03:05:17.429098
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default=None, strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default=None, strip=True) == '127.0.0.1\tlocalhost\n'

# Generated at 2022-06-17 03:05:29.049900
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='test') == 'test'
    assert get_file_content('/etc/passwd', default='test', strip=False) == 'test'
    assert get_file_content('/etc/passwd', default='test', strip=True) == 'test'
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True)

# Generated at 2022-06-17 03:05:37.156891
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', strip=False, default='')
    assert get_file_content('/etc/passwd', strip=False, default='foo') == get_file_

# Generated at 2022-06-17 03:05:47.219206
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default=None)
    assert get_file_content('/etc/passwd', default=None) != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default=None) != get_file_

# Generated at 2022-06-17 03:05:57.884453
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', strip=False)
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', strip=True)
    assert get_file_content('/etc/hosts', default='default') == get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_content('/etc/hosts', default='default') == get_file_content('/etc/hosts', default='default', strip=True)
    assert get_file_content('/etc/hosts', default='default') != get_file_content('/etc/hosts', default='default', strip=False)

# Generated at 2022-06-17 03:06:06.733190
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default=None, strip=True) == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default='', strip=True) == get_file_content('/etc/hosts', default='', strip=True)
    assert get_file_content('/etc/hosts', default='', strip=True) != get_file_content('/etc/hosts', default=None, strip=True)

# Generated at 2022-06-17 03:06:11.006534
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n'

# Generated at 2022-06-17 03:06:31.063874
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo', strip=True)

# Generated at 2022-06-17 03:06:42.068252
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='') != get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='') != get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', default='') != get_file_content('/etc/hosts', default='foo', strip=False).strip()
    assert get_file_content('/etc/hosts', default='') != get_file_content('/etc/hosts', default='foo', strip=False).strip()
    assert get_file_content

# Generated at 2022-06-17 03:06:51.382833
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', strip=True)

# Generated at 2022-06-17 03:07:02.694767
# Unit test for function get_file_content
def test_get_file_content():
    # Test with a file that exists
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')

    # Test with a file that does not exist
    assert get_file_content('/etc/doesnotexist', default='foo') == 'foo'

    # Test with a file that exists but is not readable
    assert get_file_content('/etc/shadow', default='foo') == 'foo'

    # Test with a file that exists but is empty
    assert get_file_content('/etc/emptyfile', default='foo') == ''

    # Test with a file that exists and is not empty
    assert get_file_content('/etc/passwd', default='foo') != 'foo'

    # Test with a file that exists and is not empty
    assert get_file_

# Generated at 2022-06-17 03:07:16.649699
# Unit test for function get_file_content
def test_get_file_content():
    # Test file exists
    assert get_file_content('/etc/hosts', default='foo') == 'foo'

    # Test file does not exist
    assert get_file_content('/etc/hosts_does_not_exist', default='foo') == 'foo'

    # Test file exists but is not readable
    assert get_file_content('/etc/hosts', default='foo') == 'foo'

    # Test file exists and is readable
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'

    # Test file exists and is readable but has no content
    assert get_file_content('/etc/hosts', default='foo') == 'foo'

    # Test file exists and is readable but has no content

# Generated at 2022-06-17 03:07:26.181494
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', strip=False)
    assert get_file_content('/etc/passwd', strip=False, default='foo') == 'foo'
    assert get_file_content('/etc/passwd', strip=True)
    assert get_file_content('/etc/passwd', strip=True, default='foo') == 'foo'
    assert get_file_content('/etc/passwd', strip=False, default='foo') == 'foo'
    assert get_file_content('/etc/passwd', strip=False, default='foo') == 'foo'

# Generated at 2022-06-17 03:07:35.024272
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', strip=False)
    assert get_file_content('/etc/passwd', strip=False, default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', strip=True, default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', strip=True)

# Generated at 2022-06-17 03:07:40.132493
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 03:07:49.233498
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default=None, strip=True) is None
    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'