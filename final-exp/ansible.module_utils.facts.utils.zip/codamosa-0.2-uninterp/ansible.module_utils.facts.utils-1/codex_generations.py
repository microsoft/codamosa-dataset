

# Generated at 2022-06-17 02:57:55.876859
# Unit test for function get_file_lines

# Generated at 2022-06-17 02:58:06.348810
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='') == ''
    assert get_file_content('/etc/hosts', default='', strip=False) == ''
    assert get_file_content('/etc/hosts', default='', strip=True) == ''
    assert get_file_content('/etc/hosts', default=None) == '127.0.0.1\tlocalhost\n'

# Generated at 2022-06-17 02:58:16.519157
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_lines('/etc/passwd', line_sep='\n')
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_lines('/etc/passwd', line_sep='\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n') == get_file_lines('/etc/passwd', line_sep='\n\n\n\n')

# Generated at 2022-06-17 02:58:27.376145
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='', strip=False)
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')

# Generated at 2022-06-17 02:58:36.714865
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_content('/etc/passwd').splitlines()
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_content('/etc/passwd').split('\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_content('/etc/passwd').split('\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n') == get_file_content('/etc/passwd').split('\n\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n\n') == get_file_

# Generated at 2022-06-17 02:58:48.313136
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content("/etc/passwd", default="") != ""
    assert get_file_content("/etc/passwd", default="") == get_file_content("/etc/passwd", default="")
    assert get_file_content("/etc/passwd", default="") != get_file_content("/etc/group", default="")
    assert get_file_content("/etc/passwd", default="") != get_file_content("/etc/passwd", default="", strip=False)
    assert get_file_content("/etc/passwd", default="") != get_file_content("/etc/passwd", default="", strip=False).strip()

# Generated at 2022-06-17 02:58:56.022717
# Unit test for function get_file_lines

# Generated at 2022-06-17 02:59:06.386721
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', strip=False)
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='default')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='default')
    assert get_file_content('/etc/hosts') != get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_

# Generated at 2022-06-17 02:59:15.620764
# Unit test for function get_file_lines

# Generated at 2022-06-17 02:59:26.049549
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='default') == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=False) == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=True) == 'default'

    assert get_file_content('/etc/passwd', default=None, strip=False) is None
    assert get_file_content('/etc/passwd', default=None, strip=True) is None

    assert get_file_content('/etc/passwd', default='default', strip=False) == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=True) == 'default'


# Generated at 2022-06-17 02:59:38.345796
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='foo', strip=True)
    assert get_file_content('/etc/hosts', strip=True) != get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', strip=True) == get_file_content('/etc/hosts', default='foo', strip=True)
    assert get_file_content

# Generated at 2022-06-17 02:59:45.041892
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_content('/etc/passwd', strip=True).splitlines()
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_content('/etc/passwd', strip=True).split('\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_content('/etc/passwd', strip=True).split('\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n') == get_file_content('/etc/passwd', strip=True).split('\n\n\n')

# Generated at 2022-06-17 02:59:50.743212
# Unit test for function get_file_lines

# Generated at 2022-06-17 03:00:02.026068
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='default')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='default', strip=True)
    assert get_file_content('/etc/hosts', strip=True) != get_file_content('/etc/hosts', default='default', strip=False)
    assert get_file_content('/etc/hosts', strip=True) == get_file_content('/etc/hosts', default='default', strip=True)
    assert get_file_content

# Generated at 2022-06-17 03:00:16.132654
# Unit test for function get_file_lines

# Generated at 2022-06-17 03:00:24.044215
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:00:35.910724
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='') != get_file_content('/etc/hosts', default='default')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default='default', strip=False)

# Generated at 2022-06-17 03:00:47.298643
# Unit test for function get_file_lines

# Generated at 2022-06-17 03:00:58.346478
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_content('/etc/passwd', strip=True).splitlines()
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_content('/etc/passwd', strip=True).split('\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_content('/etc/passwd', strip=True).split('\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n') == get_file_content('/etc/passwd', strip=True).split('\n\n\n')

# Generated at 2022-06-17 03:01:03.848205
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_content('/etc/passwd').splitlines()
    assert get_file_lines('/etc/passwd', line_sep='\n') == get_file_content('/etc/passwd').split('\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n') == get_file_content('/etc/passwd').split('\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n') == get_file_content('/etc/passwd').split('\n\n\n')
    assert get_file_lines('/etc/passwd', line_sep='\n\n\n\n') == get_file_

# Generated at 2022-06-17 03:01:15.416315
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') is not None
    assert get_file_content('/etc/passwd', default='foo') is not None
    assert get_file_content('/etc/passwd', default='foo') != 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) is not None
    assert get_file_content('/etc/passwd', default='foo', strip=False) != 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo', strip=True)

# Generated at 2022-06-17 03:01:22.797333
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', strip=False, default='')
    assert get_file_content('/etc/passwd', strip=False, default='foo') == get_file_

# Generated at 2022-06-17 03:01:33.917661
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default=False, strip=False) is False
    assert get_file_content('/etc/hosts', default=False, strip=True) is False
    assert get_file_content('/etc/hosts', default=True, strip=False)

# Generated at 2022-06-17 03:01:41.193657
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='default') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', default='default') != get_file_content('/etc/hosts', default='default2')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', strip=False)

# Generated at 2022-06-17 03:01:51.642865
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:02:00.234214
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='default') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', default='default') != get_file_content('/etc/hosts', default='default2')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', strip=False)

# Generated at 2022-06-17 03:02:11.784518
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='test') == 'test'

# Generated at 2022-06-17 03:02:17.830118
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', strip=False)

# Generated at 2022-06-17 03:02:28.069489
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', strip=False)
    assert get_file_content('/etc/passwd', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/passwd', strip=True)
    assert get_file_content('/etc/passwd', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/passwd', strip=False)

# Generated at 2022-06-17 03:02:34.294754
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', strip=False)
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default='foo', strip=False)
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', default='foo', strip=False) != get_file_content('/etc/hosts', default='bar', strip=False)

# Generated at 2022-06-17 03:02:47.154433
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='default') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False, default='default') == get_file_content('/etc/hosts', default='default')
    assert get_file_content('/etc/hosts', strip=False, default='default') == get_file_content('/etc/hosts', default='default')

# Generated at 2022-06-17 03:02:58.188099
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='default') != 'default'
    assert get_file_content('/etc/passwd', default='default') == get_file_content('/etc/passwd', default='default')
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/group', default='default')
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd', default='default', strip=False)
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd', default='default', strip=False).strip()
    assert get_file_content('/etc/passwd', default='default') == get_file_

# Generated at 2022-06-17 03:03:06.038112
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', strip=False) == '127.0.0.1\tlocalhost\n\n'
    assert get_file_content('/etc/hosts', default='foo') == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == '127.0.0.1\tlocalhost\n\n'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == '127.0.0.1\tlocalhost'

# Generated at 2022-06-17 03:03:13.856298
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', strip=False) == 'foo'
    assert get_file_content('/etc/hosts') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', strip=False) == 'foo'
    assert get_file_content

# Generated at 2022-06-17 03:03:18.611199
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'

# Generated at 2022-06-17 03:03:28.334906
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None)
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default=None, strip=False)
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', strip=True) != get_file_content('/etc/hosts', default=None, strip=False)
    assert get_file_content('/etc/hosts', strip=True) == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content

# Generated at 2022-06-17 03:03:38.294210
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default=None, strip=False) == '127.0.0.1\tlocalhost\n'
    assert get_file_content('/etc/hosts', default=None, strip=True) == '127.0.0.1\tlocalhost\n'

# Generated at 2022-06-17 03:03:47.365907
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd', default='foo')

# Generated at 2022-06-17 03:03:54.967058
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default=None, strip=True) != get_file_content('/etc/hosts', default=None, strip=False)
    assert get_file_content('/etc/hosts', default=None, strip=True) != get_file_content('/etc/hosts', default='', strip=True)
    assert get_file_content('/etc/hosts', default='', strip=True) != get_file_content('/etc/hosts', default='', strip=False)

# Generated at 2022-06-17 03:04:05.196933
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False).startswith('#')
    assert not get_file_content('/etc/hosts', strip=True).startswith('#')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')

# Generated at 2022-06-17 03:04:20.332491
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'

# Generated at 2022-06-17 03:04:30.784566
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default=None, strip=True)
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar', strip=True)
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo', strip=True)

# Generated at 2022-06-17 03:04:41.426680
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', strip=False)
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default='', strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default='', strip=True)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default='', strip=False)
    assert get_file_content('/etc/passwd', strip=True)

# Generated at 2022-06-17 03:04:51.549715
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', strip=False).startswith('root:x:0:0:root:')
    assert get_file_content('/etc/passwd', strip=True).startswith('root:x:0:0:root:')
    assert get_file_content('/etc/passwd', strip=True).endswith('/bin/bash\n')
    assert get_file_content('/etc/passwd', strip=False).endswith('/bin/bash\n')
    assert get_file_content

# Generated at 2022-06-17 03:05:01.692668
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo') != get_file_content('/etc/passwd', default='bar')
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', default='foo', strip=False) != get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content('/etc/passwd', default='foo', strip=True) == get_file_content('/etc/passwd', default='foo')
    assert get_file_content

# Generated at 2022-06-17 03:05:08.343625
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', strip=False)
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='foo')
    assert get_file_content('/etc/hosts') != get_file_content('/etc/hosts', strip=False, default='foo')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', strip=False, default='foo')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', strip=False, default='foo')

# Generated at 2022-06-17 03:05:19.300090
# Unit test for function get_file_content
def test_get_file_content():
    # Test with a file that exists
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n::1\tlocalhost\n'

    # Test with a file that does not exist
    assert get_file_content('/etc/hosts_does_not_exist') is None

    # Test with a file that exists but is not readable
    assert get_file_content('/etc/shadow') is None

    # Test with a file that exists but is empty
    assert get_file_content('/etc/mtab') == ''

    # Test with a file that exists but is empty and strip is False
    assert get_file_content('/etc/mtab', strip=False) == ''

    # Test with a file that exists but is empty and strip is False and default is not None
    assert get

# Generated at 2022-06-17 03:05:30.991297
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='') == ''
    assert get_file_content('/etc/hosts', default='', strip=False) == ''
    assert get_file_content('/etc/hosts', default='', strip=True) == ''
    assert get_file_content('/etc/hosts', default=None) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=False) == 'foo'
    assert get

# Generated at 2022-06-17 03:05:38.274426
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default=None, strip=True) is None
    assert get_file_content('/etc/hosts', default=None, strip=False) is None
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'

# Generated at 2022-06-17 03:05:48.265530
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', default='foo') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd') + '\n'
    assert get_file_content('/etc/passwd', default='foo', strip=False) == get_file_content('/etc/passwd', strip=False)
    assert get_file_content('/etc/passwd', default='foo', strip=False) == get_file_content('/etc/passwd', default='foo') + '\n'

# Generated at 2022-06-17 03:06:05.294149
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='default')
    assert get_file_content('/etc/passwd', default='default') != get_file_content('/etc/passwd', default='default2')
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', strip=True)
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', strip=False)
    assert get_file_content('/etc/passwd', strip=True) == get_file_content('/etc/passwd', strip=True)
    assert get_file_content('/etc/passwd', default='default', strip=False)

# Generated at 2022-06-17 03:06:10.992781
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', strip=False, default='')
    assert get_file_content('/etc/hosts', strip=False, default='foo') == get_file_

# Generated at 2022-06-17 03:06:19.342386
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='foo') == 'foo'
    assert get_file_content('/etc/passwd', default='foo') != 'bar'
    assert get_file_content('/etc/passwd', default='foo', strip=False) != 'bar'
    assert get_file_content('/etc/passwd', default='foo', strip=False) != 'foo'
    assert get_file_content('/etc/passwd', default='foo', strip=False) != 'foo\n'
    assert get_file_content('/etc/passwd', default='foo', strip=False) != 'foo\n\n'
    assert get_file_content('/etc/passwd', default='foo', strip=False) != 'foo\n\n\n'
    assert get_file_

# Generated at 2022-06-17 03:06:29.533190
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='foo') == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=False) == 'foo'
    assert get_file_content('/etc/hosts', default='foo', strip=True) == 'foo'
    assert get_file_content('/etc/hosts', default='') == ''
    assert get_file_content('/etc/hosts', default='', strip=False) == ''
    assert get_file_content('/etc/hosts', default='', strip=True) == ''
    assert get_file_content('/etc/hosts', default=None) == '127.0.0.1\tlocalhost\n'

# Generated at 2022-06-17 03:06:41.578515
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == get_file_content('/etc/passwd', default='foo')
    assert get_file_content('/etc/passwd', strip=False) == get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', strip=False) != get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content('/etc/passwd', strip=True) != get_file_content('/etc/passwd', default='foo', strip=False)
    assert get_file_content('/etc/passwd', strip=True) == get_file_content('/etc/passwd', default='foo', strip=True)
    assert get_file_content

# Generated at 2022-06-17 03:06:50.947096
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', default='foo') != get_file_content('/etc/hosts', default='bar')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', strip=False) != get_file_content('/etc/hosts', strip=True)

# Generated at 2022-06-17 03:06:57.038137
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default=None, strip=True)
    assert get_file_content('/etc/hosts', default='foo') == get_file_content('/etc/hosts', default='foo', strip=True)
    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts', default=None, strip=False)
    assert get_file_content('/etc/hosts', default='foo', strip=False) == get_file_content('/etc/hosts', default='foo', strip=False)

# Generated at 2022-06-17 03:07:02.940495
# Unit test for function get_file_content
def test_get_file_content():
    # Test with a file that exists
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n'

    # Test with a file that does not exist
    assert get_file_content('/etc/hosts_does_not_exist') is None

    # Test with a file that exists but is not readable
    assert get_file_content('/etc/shadow') is None

# Generated at 2022-06-17 03:07:16.761775
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/dev/null') == ''
    assert get_file_content('/dev/null', default='foo') == 'foo'
    assert get_file_content('/dev/null', strip=False) == '\n'
    assert get_file_content('/dev/null', default='foo', strip=False) == 'foo'
    assert get_file_content('/dev/null', default='foo', strip=True) == 'foo'
    assert get_file_content('/dev/null', default='foo\n', strip=True) == 'foo'
    assert get_file_content('/dev/null', default='foo\n', strip=False) == 'foo\n'

# Generated at 2022-06-17 03:07:26.181340
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='')
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='', strip=True)
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', default='', strip=False)
    assert get_file_content('/etc/hosts', default='', strip=False) == get_file_content('/etc/hosts', default='', strip=True)
    assert get_file_content('/etc/hosts', default='', strip=False) == get_file_content('/etc/hosts', default='', strip=False)