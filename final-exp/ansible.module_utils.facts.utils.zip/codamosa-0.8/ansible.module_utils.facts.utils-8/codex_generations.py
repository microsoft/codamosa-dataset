

# Generated at 2022-06-11 05:31:28.703418
# Unit test for function get_file_content
def test_get_file_content():
    # Non existing file should return default
    result = get_file_content('/does/not/exist', default='default')
    assert result == 'default'

    # Non existing file should return default
    result = get_file_content('/etc/resolv.conf', default='default')
    assert result != 'default'

    # Read /etc/resolv.conf and verify it contains 8.8.8.8
    result = get_file_content('/etc/resolv.conf', default='default')
    assert '8.8.8.8' in result


# Generated at 2022-06-11 05:31:37.492821
# Unit test for function get_file_lines
def test_get_file_lines():
    path = 'get_mount_size_test'
    content = get_file_content(path, default='#')
    if content[0] != '#':
        print('Test fail: get_file_content()')
        return 1
    content = get_file_content(path, default='#', strip=False)
    if content[0] != '\n':
        print('Test fail: get_file_content()')
        return 1
    content = get_file_content(path, default='#', strip=True)
    if content != '#':
        print('Test fail: get_file_content()')
        return 1
    content = get_file_lines(path, strip=True, line_sep=None)

# Generated at 2022-06-11 05:31:42.784995
# Unit test for function get_file_lines
def test_get_file_lines():

    f = open(os.path.expanduser("~/test_file"), "w")
    f.write("line1\n")
    f.write("line2\n")
    f.close()

    lines = get_file_lines(os.path.expanduser("~/test_file"))
    assert lines == ["line1", "line2"]

# Generated at 2022-06-11 05:31:53.682037
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/etc/passwd') == get_file_content('/etc/passwd').splitlines()
    assert get_file_lines('/etc/passwd', False) == get_file_content('/etc/passwd', strip=False).splitlines()
    assert get_file_lines('/etc/passwd', True, ':') == get_file_content('/etc/passwd').split(':')
    assert get_file_lines('/etc/passwd', True, ':ff') == get_file_content('/etc/passwd').split('ff')
    assert get_file_lines('/etc/passwd', True, '') == []

# Generated at 2022-06-11 05:32:01.688639
# Unit test for function get_file_lines
def test_get_file_lines():
    sample_text = '''
    foo
    bar
    baz
    '''
    assert get_file_lines(None, strip=False) == []
    assert get_file_lines('', strip=False) == []
    assert get_file_lines(sample_text, strip=False) == ['', '    foo', '    bar', '    baz', '']
    assert get_file_lines(sample_text, strip=True) == ['', 'foo', 'bar', 'baz']
    assert get_file_lines(sample_text, line_sep='\n', strip=False) == ['', '    foo', '    bar', '    baz', '']

# Generated at 2022-06-11 05:32:07.219385
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines("") == []
    assert get_file_lines("/tmp/abc") == []
    assert get_file_lines("/tmp/hello", line_sep="abcd") == []
    assert get_file_lines("/tmp/hello", strip=False) == []
    assert get_file_lines("/tmp/hello", strip=True) == []
    assert get_file_lines("/tmp/hello", strip=False, line_sep="abcd") == []

# Generated at 2022-06-11 05:32:17.699357
# Unit test for function get_file_lines
def test_get_file_lines():

    # Create a temporary file.
    import tempfile
    (fd, path) = tempfile.mkstemp()
    file = open(path, "w")


# Generated at 2022-06-11 05:32:24.828496
# Unit test for function get_file_lines
def test_get_file_lines():
    '''
    Test for get_file_lines
    '''
    tmp_file = '/tmp/facts.d/facts.txt'
    f = open(tmp_file, 'w')
    f.write('a\n')
    f.write('b\n')
    f.write('c\n')
    f.close()
    assert get_file_lines(tmp_file, line_sep='\n') == ['a', 'b', 'c']
    assert get_file_lines(tmp_file, line_sep='\\n') == ['a\\n', 'b\\n', 'c']
    os.remove(tmp_file)

# Generated at 2022-06-11 05:32:34.644080
# Unit test for function get_file_lines
def test_get_file_lines():
    (fd, tmpfile) = tempfile.mkstemp()
    os.write(fd, "first line\000second line\000third line\000".replace("\000", os.linesep))
    os.close(fd)
    assert get_file_lines(tmpfile, line_sep=os.linesep) == ["first line", "second line", "third line"], \
        "get_file_lines works with line_sep"
    assert get_file_lines(tmpfile) == ["first line", "second line", "third line"], \
        "get_file_lines works without line_sep"

# Generated at 2022-06-11 05:32:43.296857
# Unit test for function get_file_content
def test_get_file_content():
    from tempfile import mkstemp
    from shutil import rmtree

    # Test empty file
    tmpdir = mkdtemp()
    (fd, file) = mkstemp(dir=tmpdir)
    close(fd)

    assert get_file_content(file) == None
    unlink(file)
    rmtree(tmpdir)

    # Test written file
    tmpdir = mkdtemp()
    (fd, file) = mkstemp(dir=tmpdir)

    # Write, read and check
    write(fd, 'TESTING')
    close(fd)

    assert get_file_content(file) == 'TESTING'
    unlink(file)
    rmtree(tmpdir)

# Generated at 2022-06-11 05:32:47.582388
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(__file__) == get_file_content.__doc__

# Generated at 2022-06-11 05:32:53.418160
# Unit test for function get_file_content

# Generated at 2022-06-11 05:32:54.541485
# Unit test for function get_file_content
def test_get_file_content():
    pass


# Generated at 2022-06-11 05:33:02.586798
# Unit test for function get_file_content
def test_get_file_content():
    # Mock a file path
    path = "/tmp/test1.txt"
    default = "Default"
    data_in_file = "test for get_file_content"

    # Write data to file
    with open(path, "w") as datafile:
        datafile.write(data_in_file)

    # Run module
    data = get_file_content(path, default=default)

    # Check result
    assert data == data_in_file

    # Remove file
    os.remove(path)

# Generated at 2022-06-11 05:33:09.446424
# Unit test for function get_file_content
def test_get_file_content():
    assert os.path.exists('/bin/ls')
    assert get_file_content('/bin/ls', '/bin/ls not found') == '/bin/ls not found'
    assert get_file_content('/etc/hosts', default='/etc/hosts not found') != '/etc/hosts not found'
    assert get_file_content('/etc/hosts', default='/etc/hosts not found').startswith('127.0.0.1')



# Generated at 2022-06-11 05:33:16.833979
# Unit test for function get_file_content
def test_get_file_content():
    # Return default when file path does not exist
    assert get_file_content('/path/does/not/exist', 'default') == 'default'

    # Return default when file path exists but is not readable
    assert get_file_content('/root/.bashrc', 'default') == 'default'

    # Return file content when file path exists and is readable
    content = get_file_content('/etc/issue', '')
    assert content
    assert 'Debian' in content

    # Return stripped file content when file path exists and is readable
    content = get_file_content('/etc/issue', '', strip=False)
    assert content
    assert 'Debian' in content
    assert content[0] == '\n'
    assert content[-1] == '\n'

    # Return default when file path exists, is readable but

# Generated at 2022-06-11 05:33:19.624183
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/motd') != None
    assert get_file_content('/etc/motd') != get_file_content('/dev/null')

# Generated at 2022-06-11 05:33:30.581098
# Unit test for function get_file_content
def test_get_file_content():
    def _write_file(path, contents):
        dir_name = os.path.dirname(path)

        if not os.path.exists(dir_name):
            os.makedirs(dir_name)

        # Write to file
        with open(path, 'w') as f:
            f.write(contents)

    def _assert_get_file_content(path, default, expected, strip):
        got = get_file_content(path, default, strip)
        assert got == expected

    # Setup
    temp_path = 'ansible_test'
    temp_file = 'ansible_test/get_file_content_test.txt'

    # Create file
    _write_file(temp_file, 'file content')

    # Perform test

# Generated at 2022-06-11 05:33:38.196642
# Unit test for function get_file_content
def test_get_file_content():
    """Test for get_file_content"""
    from tempfile import TemporaryFile
    from ansible_collections.community.general.tests.unit.compat.mock import patch, mock_open
    from ansible_collections.community.general.plugins.module_utils.basic import AnsibleModule

    module = AnsibleModule({})  # noqa

    path = '/test/file/path'
    default = 'default value'
    strip = False

    m = mock_open()
    with patch('builtins.open', m, create=True):
        with patch('os.path.exists', return_value=True):
            with patch('os.access', return_value=True):
                test_file = TemporaryFile()
                m.return_value = test_file
                assert get_file_content(path, default, strip)

# Generated at 2022-06-11 05:33:47.864637
# Unit test for function get_file_content
def test_get_file_content():
    # Create test files
    open("test1.tmp", "a").close()
    open("test2.tmp", "a").close()
    pw = open("test3.tmp", "w")
    pw.write("test")
    pw.close()
    pw = open("test4.tmp", "w")
    pw.write("test\ntest2\n")
    pw.close()
    pw = open("test5.tmp", "w")
    pw.write("  test  ")
    pw.close()
    pw = open("test6.tmp", "w")
    pw.write("  test\ntest2\n")
    pw.close()

    # Test empty file
    assert get_file_content("test1.tmp")          == None

# Generated at 2022-06-11 05:33:55.621473
# Unit test for function get_file_content
def test_get_file_content():
    def mock_open(path, strip=True, default=None):
        '''mock open'''
        return "testing"
    inventory_filename = 'invalid_file'
    assert get_file_content(inventory_filename) is None
    open_orig = open
    try:
        open = mock_open
        assert get_file_content(inventory_filename) is "testing"
    finally:
        open = open_orig

# Generated at 2022-06-11 05:34:02.309100
# Unit test for function get_file_content
def test_get_file_content():
    from tempfile import mkdtemp
    from shutil import rmtree
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    # create test directory
    path = mkdtemp()

    # test access denied
    assert get_file_content(os.path.join(path, 'not_found')) is None

    # write file contents
    file_name = 'test_file.txt'
    file_path = os.path.join(path, file_name)
    file_contents = 'hello world\n \n'
    with open(file_path, 'w') as f_out:
        f_out.write(file_contents)

    # test success scenario
    file_contents_expected = file_contents.strip()
    assert get_file_content

# Generated at 2022-06-11 05:34:05.325133
# Unit test for function get_file_content
def test_get_file_content():
    f = open('test_file', 'w+')
    f.write('teststring' + '\n')
    f.close()
    ret = get_file_content('test_file')
    assert ret == 'teststring'


# Generated at 2022-06-11 05:34:15.402181
# Unit test for function get_file_content
def test_get_file_content():
    # Creates a file with a content then reads the content of this file
    file_name = '/tmp/contains_fake_content'
    generated_content = "this is a fake content."
    with open(file_name, 'w+') as file_to_write:
        file_to_write.write(generated_content)
    file_to_write.close()

    # If a file could not be read then it should return the default content
    # if the file does not exist
    if os.path.exists(file_name):
        os.remove(file_name)
    assert get_file_content(file_name, default='hello world!') == 'hello world!'

    # if the file exists, but is not readable
    os.chmod(file_name, 0o000)

# Generated at 2022-06-11 05:34:25.542942
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content("/dev/null","bob") == "bob"
    assert get_file_content("/dev") == "/dev"

# Generated at 2022-06-11 05:34:31.558960
# Unit test for function get_file_content
def test_get_file_content():
    result = get_file_content('/etc/passwd')
    if os.path.exists('/etc/passwd') and os.access('/etc/passwd', os.R_OK) and len(result) > 0:
        print('get_file_content /etc/passwd: Success')
    else:
        print('get_file_content /etc/passwd: Failed')


# Generated at 2022-06-11 05:34:33.558283
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='EMPTY') != 'EMPTY'



# Generated at 2022-06-11 05:34:39.449271
# Unit test for function get_file_content
def test_get_file_content():
    test_contents = "Hello World"
    assert get_file_content('/tmp/test_datafile', default='hello', strip=False) == 'hello'

    with open('/tmp/test_datafile', 'w') as f:
        f.write(test_contents)

    assert get_file_content('/tmp/test_datafile', default='hello', strip=False) == test_contents
    os.unlink('/tmp/test_datafile')

# Generated at 2022-06-11 05:34:41.544329
# Unit test for function get_file_content
def test_get_file_content():
    '''
        Unit test for function get_file_content
    '''
    assert get_file_content('/proc/cpuinfo') != []

# Generated at 2022-06-11 05:34:48.191098
# Unit test for function get_file_content
def test_get_file_content():
    data = get_file_content('/etc/hosts', default='n/a')
    assert data == 'n/a'

    data = get_file_content('/etc/hosts', default='n/a', strip=False)
    assert data == 'n/a'

    data = get_file_content('/etc/hosts', default='n/a', strip=True)
    assert data != 'n/a'

    data = get_file_content('/etc/hosts', default='n/a', strip=False)
    assert data != 'n/a'



# Generated at 2022-06-11 05:34:52.479737
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/dev/random', default='Something') == 'Something'

# Generated at 2022-06-11 05:35:02.586539
# Unit test for function get_file_content
def test_get_file_content():
    sample_data = 'This is a simple test.\n'
    expected_data = 'This is a simple test.'
    f = open("/tmp/my-test-file", "w")

    # Test 1 - pass a file containing the string variable above without the newline character
    f.write(expected_data)
    f.close()
    result = get_file_content("/tmp/my-test-file")
    assert result == expected_data

    # Test 2 - pass a file containing the string variable above with the newline character
    f = open("/tmp/my-test-file", "w")
    f.write(sample_data)
    f.close()
    result = get_file_content("/tmp/my-test-file")
    assert result == expected_data

# Generated at 2022-06-11 05:35:09.088915
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/group') == 'root:x:0:\nauth:x:48:\n'
    assert get_file_content('/etc/group', default='') == 'root:x:0:\nauth:x:48:\n'
    assert get_file_content('/etc/non-existent-file') == None
    assert get_file_content('/etc/non-existent-file', default='') == ''
    assert get_file_content('/etc/non-existent-file', default="default value") == "default value"

# Generated at 2022-06-11 05:35:14.391784
# Unit test for function get_file_content
def test_get_file_content():
    # Create a file containing a string (no trailing newline)
    STR = "abc\ndef"
    TEST_FILE = "/tmp/ansible_test_file"
    TEST_FILE2 = "/tmp/ansible_test_file2"
    with open(TEST_FILE, "w") as f:
        f.write(STR)
    # Open the file without a trailing newline
    with open(TEST_FILE, "r") as f:
        file_contents = f.read()
    assert file_contents == STR, "File contents differ from expected"
    # Open the file with a trailing newline
    with open(TEST_FILE, "r") as f:
        file_contents = f.read() + '\n'

# Generated at 2022-06-11 05:35:24.626018
# Unit test for function get_file_content
def test_get_file_content():
    """
    get_file_content
    """
    from ansible.module_utils import basic
    import tempfile

    def get_file_content_assert(path, content, default=None):
        fh = open(path, 'r')
        fh_content = fh.read()
        assert fh_content == content, "%s: %s != %s" % (path, fh_content, content)
        assert basic.get_file_content(path) == content, "%s: basic.get_file_content() != %s" % (path, content)
        assert basic.get_file_content(path, default=default) == content, "%s: basic.get_file_content() default != %s" % (path, content)
        fh.close()


# Generated at 2022-06-11 05:35:27.793424
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='abc') == 'abc'
    assert get_file_content('/etc/passwd', default='', strip=False) is not None

# Generated at 2022-06-11 05:35:31.621405
# Unit test for function get_file_content
def test_get_file_content():
    content = get_file_content("/etc/passwd")
    assert "root" in content
    assert "bin" not in content
    content = get_file_content("/etc/passwd", strip = False)
    assert "root" in content
    assert "\n" in content


# Generated at 2022-06-11 05:35:37.727527
# Unit test for function get_file_content
def test_get_file_content():
    FILE_NAME = 'test_get_file_content.tmp'
    CONTENT = 'test_get_file_content'

    # create file
    f = open(FILE_NAME, 'w')
    try:
        # write content to file
        f.write(CONTENT)
    finally:
        f.close()

    # read file
    v = get_file_content(FILE_NAME)
    assert v == CONTENT
    v = get_file_content(FILE_NAME, default='N/A')
    assert v == CONTENT

    # delete file
    os.remove(FILE_NAME)

    # read again
    v = get_file_content(FILE_NAME, default='N/A')
    assert v == 'N/A'



# Generated at 2022-06-11 05:35:42.540802
# Unit test for function get_file_content
def test_get_file_content():
    paths = ["/sbin/init","/sbin/reboot","/sbin/rebootx","/etc/shadow"]

    for path in paths:
        data = get_file_content(path)
        if ("reboot" in path) and (data is not None):
            assert False
        else:
            assert True

    assert get_file_content("/this/file/does/not/exist") is None


# Generated at 2022-06-11 05:35:51.824362
# Unit test for function get_file_content
def test_get_file_content():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, mock_open

    class TestGetFileContent(unittest.TestCase):

        @patch("os.path.exists")
        def test_file_does_not_exist(self, mock_exists):
            mock_exists.return_value = False
            ret = get_file_content("/some/path")
            self.assertIsNone(ret, None)
            mock_exists.assert_called_with("/some/path")

        @patch("os.path.exists")
        def test_file_cannot_read(self, mock_exists):
            mock_exists.return_value = True
            ret = get_file_content("/some/path")

# Generated at 2022-06-11 05:36:08.081224
# Unit test for function get_file_content
def test_get_file_content():
    path = 'test_get_file_content.txt'
    content = 'test123'

    # create a file and check that it is returned as string
    with open(path, "w") as f:
        f.write(content)
    assert (get_file_content(path) == content)
    assert (get_file_content(path, default='default') == content)
    assert (get_file_content(path, default='default', strip=False) == content)

    # check that if file is empty, that we still get content
    with open(path, "w") as f:
        f.write('')
    assert (get_file_content(path) == '')
    assert (get_file_content(path, default='default') == 'default')

# Generated at 2022-06-11 05:36:17.833008
# Unit test for function get_file_content
def test_get_file_content():
    '''
    Test get_file_content function with various success/failure conditions to
    make sure it correctly handles them.
    '''

    from ansible.module_utils.facts import tmpdir

    original_umask = os.umask(0)

    ###########################################################################
    # Generate a test file to use in the tests that follow.
    ###########################################################################
    tfile = tmpdir + '/test_file'
    test_content = 'This is a test file'
    test_data = open(tfile, 'w')
    test_data.write(test_content)
    test_data.flush()
    test_data.close()

    ###########################################################################
    # Test 1: Make sure the expected content is returned when the file
    # path points to a file that exists
    ###########################################################################

# Generated at 2022-06-11 05:36:19.968108
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/proc/mounts', default='') != ''
    assert get_file_content('/this/path/does/not/exist', default='') == ''

# Generated at 2022-06-11 05:36:29.365542
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/resolv.conf') == get_file_content('/etc/resolv.conf', True)
    assert get_file_content('/etc/resolv.conf') == get_file_content('/etc/resolv.conf', False)
    assert get_file_content('/etc/resolv.conf', strip=False) == get_file_content('/etc/resolv.conf', strip=False)
    assert get_file_content('/etc/resolv.conf', strip=True) == get_file_content('/etc/resolv.conf', strip=False)
    assert get_file_content('/etc/resolv.conf', strip=False) == get_file_content('/etc/resolv.conf', strip=False)

# Generated at 2022-06-11 05:36:31.387933
# Unit test for function get_file_content
def test_get_file_content():
    assert(get_file_content('/dev/null') is '')
    assert(get_file_content('/dev/zero') is None)

# Generated at 2022-06-11 05:36:36.337163
# Unit test for function get_file_content
def test_get_file_content():
    # Valid file
    assert get_file_content('/etc/resolv.conf') != None
    assert get_file_content('/etc/passwd') != None

    # Invalid file
    assert get_file_content('/fake_file') == None
    assert get_file_content('/fake_file', default='fake_content') == 'fake_content'

# Generated at 2022-06-11 05:36:40.810139
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/tmp/doesnotexist',default='nope') == 'nope'
    assert get_file_content('/dev/zero',default='nope') is None
    assert get_file_content('/dev/null',default='nope') is None
    assert get_file_content('/dev/zero',default=True) is True

# Generated at 2022-06-11 05:36:46.226234
# Unit test for function get_file_content
def test_get_file_content():
    '''
    Test get_file_content function.

    :return: bool (True/False; success/fail)
    '''
    path = os.path.dirname(os.path.realpath(__file__)) + '/../../../test/ansible/data/system/paths'
    data = get_file_content(path=path)
    assert isinstance(data, str)
    assert data == '/usr/bin:/bin:/usr/sbin:/sbin:/opt/bin'


# Generated at 2022-06-11 05:36:48.418866
# Unit test for function get_file_content
def test_get_file_content():
    f = get_file_content('/etc/fstab')
    assert f != None
    assert len(f) > 0



# Generated at 2022-06-11 05:36:51.271881
# Unit test for function get_file_content
def test_get_file_content():
    path = '/etc/resolv.conf'
    default = 'notfound'
    data = 'nameserver 8.8.8.8'
    out = get_file_content(path, default=default)
    assert out == data

