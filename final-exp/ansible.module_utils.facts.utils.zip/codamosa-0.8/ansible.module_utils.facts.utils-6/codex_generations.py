

# Generated at 2022-06-11 05:31:32.870385
# Unit test for function get_file_lines
def test_get_file_lines():
    # Create a test directory
    test_dir = None

# Generated at 2022-06-11 05:31:41.664873
# Unit test for function get_file_content

# Generated at 2022-06-11 05:31:52.687751
# Unit test for function get_file_lines
def test_get_file_lines():
    path = os.path.dirname(os.path.realpath(__file__)) + "/fixtures/files/file_lines.txt"
    actual_output = get_file_lines(path)
    expected_output = ['This is the first line',
                       'This is the second line',
                       'This is the third line',
                       'This is the fourth line',
                       'This is the fifth line',
                       '',
                       'This is a blank line']
    assert actual_output == expected_output

    actual_output = get_file_lines(path, line_sep='\n')
    assert actual_output == expected_output

    actual_output = get_file_lines(path, line_sep='\n\n')

# Generated at 2022-06-11 05:32:00.091442
# Unit test for function get_file_lines
def test_get_file_lines():
    # Return a list of lines from a file
    assert get_file_lines('/proc/cpuinfo')
    # Return an empty list for a non-existing file
    assert not get_file_lines('/proc/xyz')
    # Return a list split by a non-default separator
    assert get_file_lines('/proc/cpuinfo', line_sep=':')
    assert not get_file_lines('/proc/cpuinfo', line_sep='X')
    # Check if strip option works
    assert get_file_lines('/proc/cmdline', strip=False)
    assert get_file_lines('/proc/cmdline', strip=True)

# Generated at 2022-06-11 05:32:05.497933
# Unit test for function get_file_content
def test_get_file_content():
    if not os.path.exists('/tmp/test'):
        f = open('/tmp/test', 'w')
        f.write('hello world!')
        f.close()

    assert get_file_content('/tmp/test') == 'hello world!'
    assert get_file_content('/tmp/test', default='coredump') == 'hello world!'

    os.remove('/tmp/test')


if __name__ == '__main__':
    test_get_file_content()

# Generated at 2022-06-11 05:32:07.060008
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content("/sys/hypervisor/uuid") != None



# Generated at 2022-06-11 05:32:15.621707
# Unit test for function get_file_lines
def test_get_file_lines():
    # Testing for lines separated by comma
    import tempfile

    data = 'a,b,c,d'

    def cleanup():
        os.remove(test_file.name)

    with tempfile.NamedTemporaryFile(mode='w', delete=False) as test_file:
        test_file.write(data)

    try:
        assert(get_file_lines(test_file.name) == ['a,b,c,d'])
        assert(get_file_lines(test_file.name, line_sep=',') == ['a', 'b', 'c', 'd'])
    finally:
        cleanup()

# Generated at 2022-06-11 05:32:24.724403
# Unit test for function get_file_content
def test_get_file_content():
    # Test for OS Error: IOError, EACCES
    def raiseOSError(*args):
        raise OSError(13, "Permission denied")

    oldstat = os.stat

    os.stat = raiseOSError

    try:
        assert get_file_content("/etc/passwd") is None

        os.stat = oldstat
    except AssertionError:
        os.stat = oldstat
        raise

    # Test for IO Error: IOError
    def raiseIOError(*args):
        raise IOError("Test Error")

    oldopen = open
    open = raiseIOError

    try:
        assert get_file_content("") is None

        open = oldopen
    except AssertionError:
        open = oldopen
        raise

    # Test for strip

# Generated at 2022-06-11 05:32:29.767863
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/fstab', strip=True)
    assert get_file_content('/etc/fstab', strip=False)
    assert get_file_content('/etc/fstab', default='test')
    assert not get_file_content('/etc/fstaba')
    assert not get_file_content('/etc/fstaba', default='test')


# Generated at 2022-06-11 05:32:39.938133
# Unit test for function get_file_lines
def test_get_file_lines():
    path = "/etc/hosts"
    expected_result = ['127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4', '::1         localhost localhost.localdomain localhost6 localhost6.localdomain6']
    assert get_file_lines(path) == expected_result

    path = "/etc/hosts"
    expected_result = ['127.0.0.1','::1']
    assert get_file_lines(path,line_sep=' ')[0:2] == expected_result

    path = "/etc/hosts"
    expected_result = ['127.0.0.1','::1']
    assert get_file_lines(path,line_sep='\t')[0:2] == expected_result

   

# Generated at 2022-06-11 05:32:51.138292
# Unit test for function get_file_lines
def test_get_file_lines():
    '''Test get_file_lines function'''

    # Test for file content with multiline
    test_data = get_file_lines('/etc/fstab', line_sep='\n')
    assert test_data[0] == 'LABEL=/1 / ext3 defaults 1 1'

    # Test for empty file content
    test_data = get_file_lines('/etc/fstab', line_sep='\n', strip=False)
    assert not test_data

    # Test for file content with one line
    test_data = get_file_lines('/proc/version', line_sep='\n', strip=False)

# Generated at 2022-06-11 05:32:57.854650
# Unit test for function get_file_lines
def test_get_file_lines():
    test_path = 'test_file'
    expected_output = ['some', 'test', 'data']
    with open(test_path, 'w') as test_file:
        for line in expected_output:
            test_file.write('{0}\n'.format(line))
    try:
        assert get_file_lines(test_path) == expected_output
    finally:
        os.remove(test_path)

# Generated at 2022-06-11 05:33:08.792760
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/tmp/foo/bar/baz', default='default_value', strip=False) == 'default_value'
    assert get_file_content('/tmp/foo/bar/baz', default='default_value') == 'default_value'

    assert get_file_content('/etc/hosts', strip=False) == get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts') == get_file_content('/etc/hosts', False)

    assert get_file_content('/etc/hosts', strip=True) != get_file_content('/etc/hosts', strip=False)


if __name__ == '__main__':
    test_get_file_content()

# Generated at 2022-06-11 05:33:17.530130
# Unit test for function get_file_lines
def test_get_file_lines():
    # Test when file does not exist
    assert get_file_lines("/does/not/exist") == []

    # Test when file is empty
    assert get_file_lines("/dev/null") == []

    # Test when file is not empty and stripping is on

# Generated at 2022-06-11 05:33:21.426020
# Unit test for function get_file_lines
def test_get_file_lines():
    lines = get_file_lines('/proc/mounts', line_sep='\n')
    assert len(lines) > 0
    assert lines[0].split(None, 2) == ['rootfs', '/', 'rootfs']

# Generated at 2022-06-11 05:33:32.152456
# Unit test for function get_file_content
def test_get_file_content():

    with open('get_file_content_test.txt', 'w+') as f:
        f.write('foo\nbar\nbaz\n')

    assert get_file_content('get_file_content_test.txt') == 'foo\nbar\nbaz'

    assert get_file_content('get_file_content_test.txt', strip=False) == 'foo\nbar\nbaz\n'

    os.chmod('get_file_content_test.txt', 0o000)
    assert get_file_content('get_file_content_test.txt') == None

    os.chmod('get_file_content_test.txt', 0o777)


# Generated at 2022-06-11 05:33:38.725789
# Unit test for function get_file_lines
def test_get_file_lines():
    test_line_break = '\n'

    # Test with binary file
    test_file_content = b'This is a test file\x00\n'
    test_path = '/tmp/ansible_test_get_file_lines_01'
    with open(test_path, 'w') as file_handle:
        file_handle.write(test_file_content)

    test_result = get_file_lines(test_path)
    test_expected_result = [test_file_content.rstrip(test_line_break)]
    assert test_result == test_expected_result, "unexpected result: {}".format(test_result)

    # Test with text file
    test_file_content = 'This is a test file\n'

# Generated at 2022-06-11 05:33:42.752126
# Unit test for function get_file_lines
def test_get_file_lines():
    lines = get_file_lines('/etc/os-release', False)
    assert lines is not None and type(lines) is list
    lines = get_file_lines('/does/not/exist', False)
    assert lines == []


# Unit tests for function get_file_content

# Generated at 2022-06-11 05:33:52.533357
# Unit test for function get_file_lines
def test_get_file_lines():
    file = open('test_file.txt', 'w')
    file.write('aaa\nbbb\ncccddd')
    file.close()

    assert(get_file_lines('test_file.txt') == ['aaa', 'bbb', 'cccddd'])
    assert(get_file_lines('test_file.txt', line_sep='\n') == ['aaa', 'bbb', 'cccddd'])
    assert(get_file_lines('test_file.txt', line_sep='dd') == ['aaa\nbbb\nccc', '', ''])
    assert(get_file_lines('test_file.txt', line_sep='a') == ['', '', '\nbbb\ncccddd'])

# Generated at 2022-06-11 05:34:01.611947
# Unit test for function get_file_content
def test_get_file_content():

    assert get_file_content('/proc/version') == get_file_content('/proc/version', default='unavailable')
    assert get_file_content('/proc/version') == get_file_content('/proc/version', default='unavailable', strip=True)
    assert get_file_content('/proc/version', default='unavailable', strip=False) == get_file_content('/proc/version', default='unavailable')
    assert get_file_content('/proc/version', default='unavailable', strip=False) != get_file_content('/proc/version', default='unavailable', strip=True)
    assert get_file_content('/proc/version', default='unavailable') != get_file_content('/proc/version', default='unavailable', strip=True)

# Generated at 2022-06-11 05:34:11.184984
# Unit test for function get_file_content
def test_get_file_content():
    content = get_file_content("/etc/shadow")

    if content.find("root") < 0:
        print("Failed to get contents of /etc/shadow")
        sys.exit(1)

    content = get_file_content("/etc/shadow")

    if content.find("root") > 0:
        print("No access permission for /etc/shadow")
        sys.exit(1)

    content = get_file_content("/etc/shadox")

    if content.find("root") > 0:
        print("File doesn't exist")
        sys.exit(1)


# Generated at 2022-06-11 05:34:15.222242
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/shadow') == None

    # note: we dont want to create this file if it doesn't exist, so we dont test it
    # assert get_file_content('/etc/shadow', 'ansible') == 'ansible'



# Generated at 2022-06-11 05:34:25.431485
# Unit test for function get_file_content
def test_get_file_content():
    import tempfile

    # Create temp files
    with open(tempfile.mkstemp()[1], 'w') as f:
        f.seek(0)
        f.write('foo\n')
    file_empty = tempfile.mkstemp()[1]
    file_unreadable = tempfile.mkstemp()[1]
    os.chmod(file_unreadable, 0o200)
    file_noperm = '/root/foo'

    # Test case 1: file with content
    assert get_file_content(f.name) == 'foo'

    # Test case 2: file with no content
    assert get_file_content(file_empty, 'empty') == 'empty'

    # Test case 3: file with no content but strip whitespace

# Generated at 2022-06-11 05:34:36.368599
# Unit test for function get_file_content
def test_get_file_content():
    test_string = "Hello"
    systemd_path = "/proc/1/comm"
    other_path = "/tmp/test"

    # Test with correct path, without stripping
    assert get_file_content(systemd_path) == 'systemd'
    # Test with correct path, with stripping
    assert get_file_content(systemd_path, strip=True) == 'systemd'
    # Test with incorrect path
    assert get_file_content("/this/path/does/not/exist") is None
    # Test with non-existent path
    assert get_file_content("/proc/invalid/path") is None
    # Test with default value
    assert get_file_content("/proc/invalid/path", default=test_string) == test_string
    # Test with non-existent path
    assert get_

# Generated at 2022-06-11 05:34:45.578819
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content("/root/test_file", strip=False) == "test"
    assert get_file_content("/root/test_file", strip=True) == "test"
    assert get_file_content("/root/test_file", default="default") == "test"
    assert get_file_content("/root/test_file", default="default", strip=False) == "test"
    assert get_file_content("/root/test_file", default="default", strip=True) == "test"
    assert get_file_content("/root/test_file2", default="default") == "default"
    assert get_file_content("/root/test_file2", strip=False) == None
    assert get_file_content("/root/test_file2", strip=True) == None


# Generated at 2022-06-11 05:34:51.947934
# Unit test for function get_file_content
def test_get_file_content():
    # test helper to return file contents
    test_path = '/tmp/test_get_file_content'

    # test file does not exist
    assert get_file_content(test_path) is None
    # test file exists but is unreadable
    os.makedirs('/tmp')
    open(test_path, 'w').close()
    assert get_file_content(test_path) is None

    # test file exists, readable and has content
    test_content = 'foo\nbar'
    with open(test_path, 'w') as f:
        f.write(test_content)
    # should read with no stripping
    assert get_file_content(test_path, strip=False) == test_content
    # should read with stripping

# Generated at 2022-06-11 05:34:58.539291
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(path='/etc/hosts', default=None) is not None
    assert get_file_content(path='/this/path/does/not/exist', default=None) is None
    assert get_file_content(path='/etc/hosts', default=None) == get_file_content(path='/etc/hosts', default=None, strip=False)
    assert get_file_content(path='/this/path/does/not/exist', default='default') == 'default'



# Generated at 2022-06-11 05:35:08.312195
# Unit test for function get_file_content
def test_get_file_content():
    '''
        Test the get_file_content function
    '''
    from ansible.module_utils.facts import get_file_content
    import tempfile
    import shutil

    # Test: non-existing file
    assert get_file_content('/no/such/path') is None

    # Test: Existing file
    tmp_dir = tempfile.mkdtemp()
    filename = tmp_dir + '/file.txt'
    data = 'Hello world\nThis is the second line\nLast line'
    with open(filename, 'w') as tmp_file:
        tmp_file.write(data)
    assert get_file_content(filename) == data
    assert get_file_content(filename, strip=False) == data
    assert get_file_content(filename, default='No data') == data
   

# Generated at 2022-06-11 05:35:18.145716
# Unit test for function get_file_content
def test_get_file_content():
    assert '1234' == get_file_content('/tmp/foobar', default='1234', strip=False)
    assert '1234' == get_file_content('/tmp/foobar', default='1234', strip=True)
    assert '1234' == get_file_content('/tmp/foobar', default='1234')
    assert '1234\n' == get_file_content('/tmp/foobar', default='1234\n', strip=False)
    assert '1234' == get_file_content('/tmp/foobar', default='1234\n', strip=True)
    assert '1234' == get_file_content('/tmp/foobar', default='1234\n')
    assert '' == get_file_content('/tmp/foobar', default='')

# Generated at 2022-06-11 05:35:21.168364
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/fstab', default=None) == get_file_lines('/etc/fstab', strip=True, line_sep='\n')


# Generated at 2022-06-11 05:35:29.531286
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/dev/null') == ''
    assert get_file_content('/dev/null', default='xxx') == 'xxx'
    assert get_file_content('/dev/null', strip=False) == ''
    assert get_file_content('/dev/null', strip=False, default='xxx') == 'xxx'
    assert get_file_content('/dev/null', strip=False, default='\n\n') == '\n\n'

# Generated at 2022-06-11 05:35:31.167505
# Unit test for function get_file_content
def test_get_file_content():
   assert get_file_content("does_not_exist", True, False) is True


# Generated at 2022-06-11 05:35:37.208630
# Unit test for function get_file_content
def test_get_file_content():
    check = get_file_content("/etc/passwd")
    assert isinstance(check, str)
    check = get_file_content("/etc/passwd", default='Eric')
    assert check == 'Eric'
    check = get_file_content("/etc/passwd", default='Eric', strip=False)
    assert check == 'Eric'
    check = get_file_content("/etc/passwd", default='', strip=False)
    assert check == ''
    check = get_file_content("/et", default='Eric')
    assert check == 'Eric'


# Generated at 2022-06-11 05:35:44.652614
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/resolv.conf', strip=False) != None
    assert get_file_content('/etc/resolv.conf') != None
    assert get_file_content('/nonexistent_file') == None
    assert get_file_content('/nonexistent_file', 'some_default') == 'some_default'
    assert get_file_content('/etc/resolv.conf', strip=False) == get_file_content('/etc/resolv.conf')
    assert get_file_content('/etc/resolv.conf', strip=True) != get_file_content('/etc/resolv.conf', strip=False)

# Generated at 2022-06-11 05:35:54.472911
# Unit test for function get_file_content
def test_get_file_content():
    def run_test(test, filepath, result):
        try:
            assert get_file_content(filepath, default='') == result
        except AssertionError as e:
            print("Test %s failed" % test)
            print("Error: " + str(e))

    filename = "ansible_test.file"
    filepath = "/tmp/" + filename
    data = "ABC123_File_Contents"

    # Test 1 - Create file and read data
    f = open(filepath, "wb+")
    f.write(data)
    f.close()

    run_test("1 - Create and read file", filepath, data)

    # Test 2 - Read file not present
    filepath = "/tmp/" + filename + "DEF"

# Generated at 2022-06-11 05:35:55.670376
# Unit test for function get_file_content
def test_get_file_content():
    path = './asdf'
    res = get_file_content(path,default='test')
    assert res == 'test'

# Generated at 2022-06-11 05:36:03.152583
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(__file__, strip=False)
    assert get_file_content('/sys/class/net/lo/carrier', default='Ignore') == '1'
    assert get_file_content('/sys/class/net/lo/carrier', default='Ignore', strip=False) == '1\n'
    assert get_file_content('/does/not/exist') is None
    assert get_file_content('/sys/class/net/does/not/exist', default='Ignore') == 'Ignore'



# Generated at 2022-06-11 05:36:05.606726
# Unit test for function get_file_content
def test_get_file_content():
    try:
        assert(get_file_content('/etc/hosts') != None)
    except OSError:
        pass


# Generated at 2022-06-11 05:36:15.374660
# Unit test for function get_file_content
def test_get_file_content():
    # Create a file
    f = open('/tmp/test', 'w')
    f.write('testing')
    f.close()

    # Check if the file exists and is readable
    assert os.path.exists('/tmp/test') == True
    assert os.access('/tmp/test', os.R_OK) == True

    # Check if the function returns the right content
    # of the test file
    assert get_file_content('/tmp/test', strip=False) == 'testing'
    assert get_file_content('/tmp/test', strip=True) == 'testing'

    # Check if the default returnvalue is returned
    # if the file does not exist
    assert get_file_content('/tmp/non_existant', strip=False, default='default') == 'default'
    assert get_file_

# Generated at 2022-06-11 05:36:22.748210
# Unit test for function get_file_content
def test_get_file_content():

    test_file_content = "TEST1\n"
    test_file_path = '/tmp/test_file_content'
    test_default = "TEST2\n"

    # Create the file
    f = open(test_file_path, 'w+')
    f.write(test_file_content)
    f.close()

    result = get_file_content(test_file_path, test_default)
    assert result == test_file_content

    # test default value
    result = get_file_content('/not_existing_path', test_default)
    assert result == test_default

    # remove file
    os.remove(test_file_path)



# Generated at 2022-06-11 05:36:34.243409
# Unit test for function get_file_content
def test_get_file_content():
    # Testing a non existing file
    assert get_file_content('/tmp/non-existing-file') is None
    assert get_file_content('/tmp/non-existing-file', default='test') == 'test'

    # Testing a existing file with string content
    f = open('/tmp/existing-file', 'w')
    f.write('test')
    f.close()

    assert get_file_content('/tmp/existing-file') == 'test'
    assert get_file_content('/tmp/existing-file', strip=False) == 'test'

    # Testing a existing file with new line content
    f = open('/tmp/existing-file', 'w')
    f.write('\ntest\n')
    f.close()


# Generated at 2022-06-11 05:36:39.370018
# Unit test for function get_file_content
def test_get_file_content():
    path = '/proc/version'
    data = 'Linux version 3.13.0-24-generic (buildd@roseapple) (gcc version 4.8.2 (Ubuntu 4.8.2-19ubuntu1) ) #46-Ubuntu SMP Thu Apr 10 19:11:08 UTC 2014'

    assert get_file_content(path) == data



# Generated at 2022-06-11 05:36:47.974694
# Unit test for function get_file_content
def test_get_file_content():

    assert get_file_content('/etc/hostname', default='unknown') != 'unknown', \
        "Could not read contents of /etc/hostname"
    assert get_file_content('/usr/bin/true', default='unknown') == 'unknown', \
        "Could read contents of /usr/bin/true"
    assert get_file_content('/etc/hostname', strip=True) != '\n', \
        "Could not strip whitespace from /etc/hostname"
    assert get_file_content('/usr/bin/true', strip=False) == '', \
        "Could not read contents of /usr/bin/true"
    assert get_file_content('/usr/bin/true', default='unknown', strip=False) == 'unknown', \
        "Could not return default value of 'unknown'"


#

# Generated at 2022-06-11 05:36:56.522411
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/sudoers', default='NoContent') == 'NoContent'
    assert get_file_content('/etc/sudoers', strip=False) == '#\n# This file MUST be edited with the ' \
                                                            '\'visudo\' command as root.\n#\n# Please consider ' \
                                                            'adding local content in /etc/sudoers.d/ instead ' \
                                                            'of directly modifying this file.\n#\n# See the man ' \
                                                            'page for details on how to write a sudoers file.\n#\n' \
                                                            'Defaults        env_reset\nDefaults        ' \
                                                            'secure_path="/usr/local/sbin:/usr/local/bin:' \
                                                           

# Generated at 2022-06-11 05:37:02.121519
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', None) != None
    assert get_file_content('/etc/hosts', 'No content', False) == 'No content'
    assert get_file_content('/etc/hosts', 'No content', False) != 'No content'
    assert get_file_content('/etc/hosts', 'No content', True) == 'No content'
    assert get_file_content('/etc/hosts', 'No content', True) != 'No content'



# Generated at 2022-06-11 05:37:08.607755
# Unit test for function get_file_content
def test_get_file_content():
    # Check if we don't care about file data type
    assert get_file_content(__file__, []) == get_file_content(__file__, [], False)

    # Check end of file content
    assert get_file_content(__file__, [])[-1] == '\n'
    assert get_file_content(__file__, [], False)[-1] == '\n'

    # Check if we can read file which is not empty
    assert get_file_content(__file__, []) == get_file_content(__file__, [], False)
    assert get_file_content(__file__, []) != get_file_content(__file__, "test", False)

# Generated at 2022-06-11 05:37:16.929354
# Unit test for function get_file_content
def test_get_file_content():
    test_content = 'This is a test! \n'
    test_file = '/tmp/ansible-test_file_content'

    # Ensure our test file does not exist
    if os.path.exists(test_file):
        os.remove(test_file)

    # Test file does not exist
    assert get_file_content(test_file, default='N/A') == 'N/A'

    test_fd = open(test_file, 'w')
    test_fd.write(test_content)
    test_fd.close()

    # Test with file being not readable
    os.chmod(test_file, 0o000)
    assert get_file_content(test_file, default='N/A') == 'N/A'
    os.chmod(test_file, 0o666)



# Generated at 2022-06-11 05:37:24.458073
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/dev/null') == ''
    assert get_file_content('/dev/zero') == ''
    assert get_file_content('/dev/zero', default='test') == ''
    assert get_file_content('does_not_exist') == None
    assert get_file_content('does_not_exist', default='test') == 'test'

    assert get_file_content('/dev/null', strip=False) == ''
    assert get_file_content('/dev/zero', strip=False) == ''
    assert get_file_content('/dev/zero', default='test', strip=False) == ''
    assert get_file_content('does_not_exist', strip=False) == None
    assert get_file_content('does_not_exist', default='test', strip=False)

# Generated at 2022-06-11 05:37:31.363035
# Unit test for function get_file_content
def test_get_file_content():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec = dict(
            path = dict(type='str', required=True),
            default = dict(type='str', required=False, default='foo'),
            strip = dict(type='bool', required=False, default=False),
        ),
    )
    path = module.params["path"]
    default = module.params["default"]
    strip = module.params["strip"]

    content = get_file_content(path, default, strip)

    module.exit_json(changed=False, meta=dict(content=content))


# Generated at 2022-06-11 05:37:39.710881
# Unit test for function get_file_content
def test_get_file_content():
    # Test file with one line
    assert get_file_content('/proc/self/mounts', default=None) == get_file_content('/proc/self/mounts', default=None,
                                                                                   strip=False)
    assert get_file_content('/proc/self/mounts', default=None) == get_file_content('/proc/self/mounts', default=None,
                                                                                   strip=True)

    # Test file with one line
    assert get_file_content('/tmp/doesnt_exists', default=None) is None
    assert get_file_content('/tmp/doesnt_exists', default='whatever') == 'whatever'

    # Test file with multiple lines