

# Generated at 2022-06-25 00:54:40.193741
# Unit test for function get_file_lines
def test_get_file_lines():
    print("Test for function get_file_lines")

    # Test for str
    var_0 = 'ansible_distribution'
    var_1 = get_file_lines(var_0)
    print("After test: {}".format(var_1))



# Generated at 2022-06-25 00:54:44.536615
# Unit test for function get_file_lines
def test_get_file_lines():
    try:
        assert(var_0 == ['requests_credssp'])
        print("get_file_lines passed")
    except AssertionError:
        print("get_file_lines FAILED")
        print("\tOutput:\t", var_0)
        print("\tExpected Output:\t [['requests_credssp']]")



# Generated at 2022-06-25 00:54:46.637988
# Unit test for function get_file_content
def test_get_file_content():
  path = 'requests_credssp'
  default = ''
  strip = True
  get_file_content(path, default, strip)


# Generated at 2022-06-25 00:54:50.871871
# Unit test for function get_file_content
def test_get_file_content():
    try:
        assert type(get_file_content('requests_credssp')) is str
    except AssertionError as e:
        print('get_file_content')
        print(e)
        raise e


# Generated at 2022-06-25 00:54:53.920466
# Unit test for function get_file_lines
def test_get_file_lines():
    print('0')
    test_case_0()
    print('1')



# Generated at 2022-06-25 00:54:55.081861
# Unit test for function get_file_content
def test_get_file_content():
    path = ''
    assert get_file_content(path) == None


# Generated at 2022-06-25 00:55:00.419716
# Unit test for function get_file_content
def test_get_file_content():
    # Testing if function actually returns string
    str_0 = 'ansible'
    var_0 = get_file_content(str_0)
    assert str == type(var_0)


# Generated at 2022-06-25 00:55:02.722200
# Unit test for function get_file_lines
def test_get_file_lines():
    test_case_0()

# Generated at 2022-06-25 00:55:07.548493
# Unit test for function get_file_content
def test_get_file_content():
    # Create a string of size 10MB
    test_file = 'file_content.txt'
    test_file_content = 'a' * 10485760

    # Write the content to disk
    with open(test_file, "w") as f:
        f.write(test_file_content)

    # The content from disk should match
    assert get_file_content(test_file) == test_file_content

    # Clean up
    os.remove(test_file)



# Generated at 2022-06-25 00:55:10.138161
# Unit test for function get_file_lines
def test_get_file_lines():
    str_0 = 'requests_credssp'
    var_0 = get_file_lines(str_0)

# Generated at 2022-06-25 00:55:22.955886
# Unit test for function get_file_content
def test_get_file_content():
    # Test with invalid file path
    try:
        var_0 = get_file_content('', default=None, strip=True)
        assert False
    except IOError:
        pass
    # Test with valid input
    try:
        var_0 = get_file_content('requests_credssp', default=None, strip=True)
        assert True
    except IOError:
        assert False


# Generated at 2022-06-25 00:55:23.922981
# Unit test for function get_file_content
def test_get_file_content():
    assert func(['foo', 'bar']) == 'foo'



# Generated at 2022-06-25 00:55:27.283043
# Unit test for function get_file_content
def test_get_file_content():
    '''
    Test the get_file_content function
    '''

    results = get_file_content('/etc/hosts', 'default')
    assert results != 'default'
    results = get_file_content('/etc/hosts_not_exists', 'default')
    assert results == 'default'



# Generated at 2022-06-25 00:55:31.921251
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'requests_credssp'
    var_0 = get_file_content(str_0)
    assert var_0 == ''


# Generated at 2022-06-25 00:55:34.352936
# Unit test for function get_file_content
def test_get_file_content():
    assert test_get_file_content.__name__ == 'test_get_file_content'


# Generated at 2022-06-25 00:55:36.409710
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'requests_credssp'
    var_0 = get_file_content(str_0)
    print(var_0)


# Generated at 2022-06-25 00:55:42.615439
# Unit test for function get_file_content
def test_get_file_content():
    str_1 = 'requests_credssp'
    str_2 = '  requests_credssp  '
    str_3 = 'requests_credssp\n'
    str_5 = 'requests_credssp\nrequests_credssp'
    bool_1 = False
    bool_2 = True
    str_4 = ' '
    var_1 = get_file_content(str_1)
    assert var_1 == str_2
    var_2 = get_file_content(str_1, default=str_4)
    assert var_2 == str_2
    var_3 = get_file_content(str_1, strip=bool_1)
    assert var_3 == str_3

# Generated at 2022-06-25 00:55:47.605985
# Unit test for function get_file_content
def test_get_file_content():
    os.chdir('/')
    assert get_file_content('/usr/bin/python')
    assert get_file_content('/usr/bin/python') == get_file_content('/usr/bin/python')


# Generated at 2022-06-25 00:55:52.922448
# Unit test for function get_file_content
def test_get_file_content():
    size_total = 'size_total'
    size_available = 'size_available'
    # Section "Requests"
    get_file_lines('requests_credssp') == ['https://aixtools.ibm.com/', 'https://aixtools.ibm.com/']

# Generated at 2022-06-25 00:55:53.924375
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(str_0, default=None, strip=True) is None


# Generated at 2022-06-25 00:55:57.101177
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'requests_credssp'
    assert get_file_content(str_0) == None


# Generated at 2022-06-25 00:55:59.225265
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/dev/null', default='DONE') == 'DONE'

# unit test for get_file_lines()

# Generated at 2022-06-25 00:56:00.479925
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('test_path') is None


# Generated at 2022-06-25 00:56:05.811412
# Unit test for function get_file_content
def test_get_file_content():
    results_00 = {'size_total': 25925062656, 'inode_available': 4995709, 'block_used': 14872121, 'size_available': 25582495936, 'block_total': 15099648, 'inode_used': 5028437, 'block_size': 4096, 'block_available': 12277527, 'inode_total': 10024146}
    assert results_00 == get_mount_size('/home/my_user')

# Generated at 2022-06-25 00:56:12.858104
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(path=None, default=None, strip=True) is None
    assert get_file_content(path='/usr/bin/', default='', strip=True) is ''
    assert get_file_content(path='/usr/bin/', default=None, strip=False) is None
    assert get_file_content(path='/usr/bin/', default='', strip=False) == ''
    assert get_file_content(path='/etc/passwd', default=None, strip=True) is not None
    assert get_file_content(path='/etc/passwd', default='', strip=True) is not ''



# Generated at 2022-06-25 00:56:21.765634
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='default') == 'default'
    assert isinstance(get_file_content('/etc/passwd', default='default'), str)
    assert get_file_content('/etc/passwd', default='default', strip=False) == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=False) == 'default'
    assert get_file_content('/etc/passwd', strip=False) == 'default'
    assert get_file_content('/etc/passwd', default='default', strip=False) == 'default'


# Generated at 2022-06-25 00:56:23.225540
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(str_0, '1', True) == var_0


# Generated at 2022-06-25 00:56:24.922225
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'requests_credssp'
    var_0 = get_file_content(str_0)


# Generated at 2022-06-25 00:56:31.999232
# Unit test for function get_file_content
def test_get_file_content():
    # Tests below are based on real files on my Fedora 30
    # Assertions with 'None' are made as the files are not present in the Ansible project
    assert get_file_content('/tmp/doesnotexist') is None
    assert get_file_content('/etc/sudoers') is None
    assert get_file_content('/usr/share/ansible_collections/ansible/community') == 'ansible.community'
    assert get_file_content('/etc/resolv.conf') == 'search example.com\nnameserver 10.64.0.2\nnameserver 8.8.8.8'



# Generated at 2022-06-25 00:56:33.779353
# Unit test for function get_file_content
def test_get_file_content():
    str_path = get_file_content('/proc/self/status', default='')
    assert str_path


# Generated at 2022-06-25 00:56:45.149849
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'requests_credssp'
    str_1 = 'fake path'
    str_2 = 'temp'
    str_3 = 'requests_credssp'
    str_4 = 'requests_credssp'
    str_5 = 'requests_credssp'
    str_6 = 'requests_credssp'
    str_7 = 'requests_credssp'
    str_8 = 'requests_credssp'
    str_9 = 'requests_credssp'
    var_0 = get_file_content(str_0)
    var_1 = get_file_content(str_1, default='fake path')
    var_2 = get_file_content(str_2, strip=False)
    var_

# Generated at 2022-06-25 00:56:53.781541
# Unit test for function get_file_content
def test_get_file_content():
    # Test with no file
    assert get_file_content('/path/to/file/that/does/not/exist') is None

    # Test with a file that is not readable
    os.mkdir('/tmp/ansible_temp_directory')
    f = open('/tmp/ansible_temp_directory/temp_file', 'a')
    f.close()
    assert get_file_content('/tmp/ansible_temp_directory/temp_file') is None

    # Test with a file that is readable
    f = open('/tmp/ansible_temp_directory/temp_file', 'w')
    f.write('123\n')
    f.close()
    assert get_file_content('/tmp/ansible_temp_directory/temp_file') == '123'

    # Test with a file that is

# Generated at 2022-06-25 00:56:54.565533
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('requests_credssp', default=None, strip=True)



# Generated at 2022-06-25 00:56:59.438006
# Unit test for function get_file_content
def test_get_file_content():
    path = 'requests_credssp'
    default = None
    strip = True

    get_file_content(path, default, strip)


# Generated at 2022-06-25 00:57:00.762747
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content() == ''

# Generated at 2022-06-25 00:57:05.704336
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'requests_credssp'
    var_0 = get_file_content(str_0, '', False)
    print(var_0)

    # Path does not exist
    str_1 = '/etc/resolv.conf'
    var_1 = get_file_content(str_1)
    print(var_1)

    str_2 = 'requests_credssp'
    var_2 = get_file_content(str_2)
    print(var_2)



# Generated at 2022-06-25 00:57:10.955338
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/tmp/foo', default='bar') == 'bar'
    assert get_file_content('/tmp/foo', default='bar', strip=True) == 'bar'
    assert get_file_content('/tmp/foo', default='bar', strip=False) == 'bar'
    assert get_file_content('/dev/null', default='bar') == None
    assert get_file_content('/dev/null', default='bar', strip=True) == None
    assert get_file_content('/dev/null', default='bar', strip=False) == None



# Generated at 2022-06-25 00:57:13.756273
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('./file_0') == 'file_0'


# Generated at 2022-06-25 00:57:15.785354
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'requests_credssp'
    var_0 = get_file_content(str_0)
    print(var_0)


# Generated at 2022-06-25 00:57:21.205904
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'ansible'
    str_1 = '<etc>'
    ret = get_file_content(str_0, str_1)
    assert ret == '<etc>'


# Generated at 2022-06-25 00:57:27.916414
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'requests_ric'
    var_0 = get_file_content(str_0)


# Generated at 2022-06-25 00:57:28.960235
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'requests_credssp'
    var_0 = get_file_content(str_0)
    print(var_0)


# Generated at 2022-06-25 00:57:31.323130
# Unit test for function get_file_content
def test_get_file_content():
    # Test function get_file_content
    # Attempts to read contents of a file
    print('TEST: get_file_content(): Attempting to read a file')
    test_file = 'test_file'
    test_content = 'this is a test'
    f = open(test_file, 'w')
    f.write(test_content)
    f.close()
    assert get_file_content(test_file) == test_content



# Generated at 2022-06-25 00:57:36.073961
# Unit test for function get_file_content
def test_get_file_content():
    # Function loads a file that is in a specific file path
    assert get_file_content(test_case_0)



# Generated at 2022-06-25 00:57:37.767494
# Unit test for function get_file_content
def test_get_file_content():
    var_0 = get_file_content('requests_credssp')
    assert type(var_0) == str

# Generated at 2022-06-25 00:57:38.977377
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('requests_credssp') == 'requests_credssp'


# Generated at 2022-06-25 00:57:42.856403
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'python-crypto'
    var_0 = get_file_content(str_0)
    print('str_0 is: %s' % str_0)
    print('var_0 is: %s' % var_0)
    print('var_0 is %s type long' % type(var_0))


# Generated at 2022-06-25 00:57:50.945488
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('requests_credssp') == 'CredSSP'
    assert get_file_content('requests_credssp', default='CredSSP') == 'CredSSP'
    assert get_file_content('requests_credssp', default='CredSSP', strip=False) == 'CredSSP'
    assert get_file_content('requests_credssp') == 'CredSSP'
    assert get_file_content('requests_credssp', default='CredSSP') == 'CredSSP'
    assert get_file_content('requests_credssp', default='CredSSP', strip=False) == 'CredSSP'

# Generated at 2022-06-25 00:57:53.445341
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('requests_credssp', default='') == ''
    assert get_file_content('requests_credssp', default='') == ''



# Generated at 2022-06-25 00:57:56.988377
# Unit test for function get_file_content
def test_get_file_content():
    path = os.path.dirname(os.path.realpath(__file__))+'/files/get_file_lines.txt'
    assert get_file_content(path) == 'abc'



# Generated at 2022-06-25 00:58:04.033145
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('requests_credssp') == None


# Generated at 2022-06-25 00:58:05.397713
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('mock_path/test/file_0', strip=False, default="") == ""


# Generated at 2022-06-25 00:58:06.223728
# Unit test for function get_file_content
def test_get_file_content():
    pass


# Generated at 2022-06-25 00:58:07.417135
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('requests_kerberos') is not None


# Generated at 2022-06-25 00:58:09.253633
# Unit test for function get_file_content
def test_get_file_content():
    assert (get_file_content(str_0) == var_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:58:10.776796
# Unit test for function get_file_content
def test_get_file_content():
    var_0 = get_file_content('requests_credssp')
    assert var_0 == 'requests_credssp'


# Generated at 2022-06-25 00:58:13.131618
# Unit test for function get_file_content
def test_get_file_content():
    # Test of printing file content
    print(get_file_content('/etc/hostname'))
    print(get_file_content('/etc/hostname', default='none'))
    print(get_file_content('/etc/hostname', strip=False))


# Generated at 2022-06-25 00:58:14.484276
# Unit test for function get_file_content
def test_get_file_content():
    var_0 = get_file_content('requests_credssp')
    assert var_0 is not None


# Generated at 2022-06-25 00:58:16.058303
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('requests_credssp') is not None
    assert get_file_content('') is None


# Generated at 2022-06-25 00:58:17.848971
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/ansible/ansible.cfg')


# Generated at 2022-06-25 00:58:30.384773
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/motd', 'Nothing') == 'Nothing'



# Generated at 2022-06-25 00:58:34.581527
# Unit test for function get_file_content
def test_get_file_content():
    print('Testing')
    os.environ['ANSIBLE_PYTHON_MODULE_ABS_PATH'] = '/usr/share/ansible/python/ansible/module_utils/'
    test_case_0()

test_get_file_content()

# Generated at 2022-06-25 00:58:40.321054
# Unit test for function get_file_content
def test_get_file_content():
    strPath = 'requests_credssp'
    varPath = 'requests_credssp'

    assert varPath == strPath

# Generated at 2022-06-25 00:58:44.222437
# Unit test for function get_file_content
def test_get_file_content():
    assert 'requests_credssp' != ''


# Generated at 2022-06-25 00:58:45.620466
# Unit test for function get_file_content
def test_get_file_content():
    print('Test')
    var_0 = test_case_0()
    print(var_0)



# Generated at 2022-06-25 00:58:52.025700
# Unit test for function get_file_content
def test_get_file_content():

    # our file will be tested here
    str_0 = 'requests_credssp'
    var_0 = get_file_content(str_0)
    assert var_0 == "requests-credssp==1.0.0"
    
    # our file will be tested here
    str_1 = 'requests_credssp_123'
    var_1 = get_file_content(str_1)
    assert var_1 == None

# Generated at 2022-06-25 00:58:56.349545
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(str_0, default) == get_file_content(str_0, default)


# Generated at 2022-06-25 00:58:58.288445
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'requests_credssp'
    result = get_file_content(str_0)
    assert type(result) == type('')



# Generated at 2022-06-25 00:59:04.914580
# Unit test for function get_file_content
def test_get_file_content():

    def test_get_file_content_0():
        str_0 = '/var/lib/tripleo-config/ansible/ansible_facts'
        var_0 = get_file_content(str_0)
        assert var_0 == None


# Generated at 2022-06-25 00:59:08.518696
# Unit test for function get_file_content
def test_get_file_content():
    assert test_case_0()


# Generated at 2022-06-25 00:59:29.472581
# Unit test for function get_file_content
def test_get_file_content():
    # Ensure that function works correctly and that there are no failures in parsing.
    assert get_file_content(str(), default=str(), strip=bool()) is not str()


# Generated at 2022-06-25 00:59:34.525286
# Unit test for function get_file_content
def test_get_file_content():
    import requests

    var_1 = get_file_content('/etc/profile', default='', strip=False)
    assert isinstance(var_1, str)

    data = get_file_content('/etc/profile', default='')
    assert isinstance(data, str)
    assert isinstance(data, str)

    assert var_1 == data


# Generated at 2022-06-25 00:59:36.998932
# Unit test for function get_file_content
def test_get_file_content():
    # Verify that the output of this function matches the output from
    # running the get_file_content function with no arguments
    assert get_file_content() == get_file_content()


# Generated at 2022-06-25 00:59:37.628282
# Unit test for function get_file_content
def test_get_file_content():
    pass


# Generated at 2022-06-25 00:59:40.109749
# Unit test for function get_file_content
def test_get_file_content():
    path = 'requests_credssp'
    default = None
    strip = True
    assert get_file_content(path, default, strip) is None


# Generated at 2022-06-25 00:59:43.149793
# Unit test for function get_file_content
def test_get_file_content():
    tester = get_file_content
    assert tester('requests_credssp') == 'ImportError'

# Generated at 2022-06-25 00:59:48.718485
# Unit test for function get_file_content
def test_get_file_content():
    # Inputs
    path = ''
    default = ''
    strip = ''

    # Expected output
    expected = ''

    # Perform the test
    result = get_file_content(path, default, strip)

    # Verify the results
    assert result == expected, 'get_file_content() did not return expected output. Got: %s' % result


# Generated at 2022-06-25 00:59:53.819288
# Unit test for function get_file_content
def test_get_file_content():
    test_path = '/etc/ansible/ansible.cfg'
    result = get_file_content(test_path)
    assert isinstance(result, str)

    result = get_file_content('foo')
    assert result is None
    

# Generated at 2022-06-25 01:00:01.988597
# Unit test for function get_file_content
def test_get_file_content():
    path = 'test_path'
    default = 'test_default'
    strip = True
    assert get_file_content(path, default, strip) == 'test_default'
    path = 'requests_credssp'
    default = 'test_default'
    strip = True
    assert get_file_content(path, default, strip) == 'test_default'
    path = 'requests_credssp'
    default = 'test_default'
    strip = True
    assert get_file_content(path, default, strip) == 'test_default'


# Generated at 2022-06-25 01:00:04.091588
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(str()) == None



# Generated at 2022-06-25 01:00:50.137431
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'passwd'
    str_1 = 'ansible'
    var_0 = get_file_content(str_0, str_1)
    assert(var_0 == str_1)


# Generated at 2022-06-25 01:00:52.320977
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', 'test_get_file_content') == get_file_content('/etc/passwd')
    assert get_file_content('/etc/passwd', 'test_get_file_content', False) == get_file_content('/etc/passwd', False)


# Generated at 2022-06-25 01:00:55.509390
# Unit test for function get_file_content
def test_get_file_content():
    fake_path__0 = 'fake/path/0'
    assert isinstance(get_file_content(fake_path__0), str)
    assert get_file_content(fake_path__0) == ''

    fake_path__1 = 'fake/path/1'
    assert isinstance(get_file_content(fake_path__1, 'test'), str)
    assert get_file_content(fake_path__1, 'test') == 'test'



# Generated at 2022-06-25 01:00:57.324069
# Unit test for function get_file_content
def test_get_file_content():
    pass


# Generated at 2022-06-25 01:01:04.695198
# Unit test for function get_file_content
def test_get_file_content():
    assert __salt__['file.get_file_content']('') == None

# Generated at 2022-06-25 01:01:13.118909
# Unit test for function get_file_content
def test_get_file_content():
    path = '/path/to/file'
    default = 'not_found'
    strip = True
    # Test with a bogus file to avoid polluting the real file system
    assert get_file_content(path, default=default, strip=strip) == default
    assert get_file_content(path, strip=strip) == default
    assert get_file_content(path, default=default) == default
    assert get_file_content(path) == default


# Generated at 2022-06-25 01:01:15.256657
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content("/usr/lib/python2.7/dist-packages/ansible/module_utils/facts/system/osx.py", strip=True) == '#!/usr/bin/python'


# Generated at 2022-06-25 01:01:18.604645
# Unit test for function get_file_content
def test_get_file_content():
    str = 'requests_credssp'
    var = get_file_content(str)


# Generated at 2022-06-25 01:01:25.795493
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'requests_credssp'
    str_1 = 'requests_credssp'
    str_2 = 'requests_credssp'
    str_3 = 'requests_credssp'
    var_0 = get_file_content(str_0)
    var_1 = get_file_content(str_1)
    var_2 = get_file_content(str_2)
    var_3 = get_file_content(str_3)


# Generated at 2022-06-25 01:01:26.756305
# Unit test for function get_file_content
def test_get_file_content():
    assert type(get_file_content('/etc/hosts')) is str


# Generated at 2022-06-25 01:03:03.844614
# Unit test for function get_file_content
def test_get_file_content():
    dirs = ['/tmp/', '/tmp/rotate_d']
    if not os.path.exists(dirs[0]):
        os.mkdir(dirs[0])
    if not os.path.exists(dirs[1]):
        os.mkdir(dirs[1])
    
    path = '/tmp/test.txt'
    with open(path, 'w') as f:
        f.write('654')
    assert get_file_content(path) == '654'
    
    with open(path, 'w') as f:
        f.write('asd654\n')
    assert get_file_content(path) == 'asd654'
    
    with open(path, 'w') as f:
        f.write('654')
    assert get_file_content

# Generated at 2022-06-25 01:03:05.805168
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(True) == None


# Generated at 2022-06-25 01:03:08.761708
# Unit test for function get_file_content
def test_get_file_content():
    # 1. simple test
    path = 'requests_credssp'
    default = 'This is default string'
    strip = True
    result = get_file_content(path, default, strip)

    assert type(result) == str


# Generated at 2022-06-25 01:03:17.126260
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'requests_credssp'
    dict_0 = get_file_content(str_0)
    assert dict_0 == None

    str_1 = 'requests_negotiate_sspi'
    dict_1 = get_file_content(str_1)
    assert dict_1 == None

    str_2 = 'requests_kerberos'
    dict_2 = get_file_content(str_2)
    assert dict_2 == None

    str_3 = 'gssapi'
    dict_3 = get_file_content(str_3)
    assert dict_3 == None

    str_4 = 'requests_gssapi'
    dict_4 = get_file_content(str_4)
    assert dict_4 == None


# Generated at 2022-06-25 01:03:22.187395
# Unit test for function get_file_content
def test_get_file_content():
    print('> test_get_file_content')
    test_case_0()
    print('< test_get_file_content')



# Generated at 2022-06-25 01:03:26.547805
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('requests_credssp', default='', strip=True) == ''



# Generated at 2022-06-25 01:03:31.821588
# Unit test for function get_file_content
def test_get_file_content():
    try:
        str_0 = 'requests_credssp'
        str_1 = 'requests_credssp'
        str_2 = 'requests_credssp'
        str_3 = 'requests_credssp'
        var_0 = get_file_content(str_0)
        assert var_0 == str_1
        var_0 = get_file_content(str_2, default='requests_credssp')
        assert var_0 == str_3
    except AssertionError as e:
        print('\x1b[1;31mFAILED\x1b[0m')
        raise e
    else:
        print('\x1b[1;32mPASSED\x1b[0m')


# Generated at 2022-06-25 01:03:36.847407
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('requests_credssp') == 'requests_credssp'  # Expected value


# Generated at 2022-06-25 01:03:41.676274
# Unit test for function get_file_content
def test_get_file_content():
    # Calls the function
    str_0 = 'requests_credssp'
    var_0 = get_file_content(str_0)
    str_1 = 'requests_credssp'
    var_1 = get_file_content(str_1, default='requests_credssp')
    str_2 = 'requests_credssp'
    var_2 = get_file_content(str_2, default='requests_credssp', strip=True)

    # evaluates
    assert var_0 == None
    assert var_1 == 'requests_credssp'
    assert var_2 == None



# Generated at 2022-06-25 01:03:44.617941
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'requests_credssp'
    var_0 = get_file_content(str_0,line_sep=None)
    str_1 = '''http://feedback.redd.it'''
    var_1 = get_file_content(str_0,line_sep=str_1)
    str_2 = 'requests_credssp'
    var_2 = get_file_content(str_0,default=str_2)
