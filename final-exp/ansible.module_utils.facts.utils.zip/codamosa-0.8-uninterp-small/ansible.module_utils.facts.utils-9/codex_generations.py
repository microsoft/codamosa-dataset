

# Generated at 2022-06-25 00:54:39.265859
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts', default='default') != 'default'


# Generated at 2022-06-25 00:54:41.918252
# Unit test for function get_file_content
def test_get_file_content():
    var_0 = get_file_content(str_0)
    assert var_0
    var_1 = get_file_content(str_1, str_2)
    assert var_1 == str_3


# Generated at 2022-06-25 00:54:45.743524
# Unit test for function get_file_lines
def test_get_file_lines():
    assert True == get_file_lines('/etc/fstab', strip=True)

# Generated at 2022-06-25 00:54:51.564359
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/proc/mounts')
    assert get_file_lines('/proc/mounts', False)
    assert get_file_lines('/proc/mounts', True, ' ')



# Generated at 2022-06-25 00:54:58.641244
# Unit test for function get_file_lines
def test_get_file_lines():

    assert os.path.exists(__file__) == True
    assert os.access(__file__, os.R_OK) == True

    # File exists, is readable and contains data
    result = get_file_lines(__file__)
    assert result == []

    # File exists, is readable and contains data
    result = get_file_lines(__file__, False)
    assert result != []

    # File existss, is readable but contains no data
    result = get_file_lines(os.devnull)
    assert result == []

    # File does not exist
    result = get_file_lines('/foo/bar/baz/file_does_not_exist')
    assert result == []



# Generated at 2022-06-25 00:55:02.531565
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('testfile', default='python') == 'python'



# Generated at 2022-06-25 00:55:04.699873
# Unit test for function get_file_content
def test_get_file_content():
    var_0 = get_file_content('/etc/os-release')
    assert var_0 is not None
    assert var_0.startswith('NAME="')



# Generated at 2022-06-25 00:55:06.861604
# Unit test for function get_file_lines
def test_get_file_lines():
    file_path = '/home/ansible'
    result = get_file_lines(file_path)
    file_path = '/home/ansible'
    result = get_file_lines(file_path)



# Generated at 2022-06-25 00:55:10.954155
# Unit test for function get_file_lines

# Generated at 2022-06-25 00:55:14.055833
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/fstab')


# Generated at 2022-06-25 00:55:24.473092
# Unit test for function get_file_content
def test_get_file_content():
    var_0 = '/tmp/'
    var_0 = '6]8,xhDUQ>/'
    var_0 = ':v*X9m0Mz]M'
    var_0 = 'T0+s-0&?q<h'
    var_0 = 'j=Cxh2T'
    var_0 = 'ZpB:mu*h#H3'
    var_0 = 'U8'
    var_0 = '_|.FSW'
    var_0 = 'G@!&'
    var_0 = ']C'
    var_0 = '2bN'
    var_0 = '|5e>j'
    var_0 = '$q3H&^i7z>0'

# Generated at 2022-06-25 00:55:31.715036
# Unit test for function get_file_content
def test_get_file_content():
    import os
    import tempfile

    path = os.path.join(tempfile.gettempdir(), 'ansible_test_file')

    # Write some data to the temporary file and then test that we can read it back.
    with open(path, 'w') as f:
        f.write('ABC\nCBA\n')

    data = get_file_content(path, default='XYZ')
    assert data == 'ABC\nCBA\n'

    data = get_file_content(path, default='XYZ', strip=True)
    assert data == 'ABC\nCBA'

    data = get_file_content(path, default='XYZ', strip='\n')
    assert data == 'ABC\nCBA'


# Generated at 2022-06-25 00:55:36.202690
# Unit test for function get_file_content
def test_get_file_content():
    assert not get_file_content('/etc/hosts')
    assert get_file_content('/etc/hosts', default='blah') == 'blah'

    assert get_file_content('/etc/hosts', strip=False)
    assert get_file_content('/etc/hosts', strip=False, default='blah') == 'blah'



# Generated at 2022-06-25 00:55:37.022899
# Unit test for function get_file_content
def test_get_file_content():
    assert callable(get_file_content)

# Generated at 2022-06-25 00:55:43.807803
# Unit test for function get_file_content
def test_get_file_content():
    # 1
    str_0 = '.vfd8Wy'
    var_0 = get_file_content(str_0)
    assert var_0 == "", "str 0: " + str(var_0)



# Generated at 2022-06-25 00:55:45.349229
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(str_0, None, True) == 'Am+.&1BN'



# Generated at 2022-06-25 00:55:47.792934
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/mtab', strip=False) == open('/etc/mtab').read()


# Generated at 2022-06-25 00:55:51.357959
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = '/proc/self/status'
    var_0 = get_file_content(str_0)


# Generated at 2022-06-25 00:55:56.270385
# Unit test for function get_file_content
def test_get_file_content():
    assert callable(get_file_content)
    assert get_file_content('/bin/grep') is not None


# Generated at 2022-06-25 00:55:58.829908
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = '$Y0`fZ=&'
    expected_0 = '0e-1'
    var_0 = get_file_content(str_0, strip=True)
    assert var_0 == expected_0


# Generated at 2022-06-25 00:56:03.660807
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1 localhost\n127.0.1.1 localhost\n'

# Generated at 2022-06-25 00:56:05.620204
# Unit test for function get_file_content
def test_get_file_content():
    astr = get_file_content('/etc/passwd')
    assert astr is not None


# Generated at 2022-06-25 00:56:13.725969
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', "File Not Found") == "File Not Found"

# Generated at 2022-06-25 00:56:20.187034
# Unit test for function get_file_content
def test_get_file_content():
    print('Starting function get_file_content')

    # Test case 1
    print('Testing get_file_content [case 1]')
    str_0 = '/proc/uptime'
    var_0 = get_file_content(str_0)
    if var_0 is not None:
        print('[+] get_file_content [case 1] --- pass')
    else:
        print('[+] get_file_content [case 1] --- fail')


# Generated at 2022-06-25 00:56:24.820990
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '127.0.0.1\tlocalhost\n127.0.1.1\tosboxes\n\n# The following lines are desirable for IPv6 capable hosts\n::1     ip6-localhost ip6-loopback\nfe00::0 ip6-localnet\nff00::0 ip6-mcastprefix\nff02::1 ip6-allnodes\nff02::2 ip6-allrouters\nff02::3 ip6-allhosts\n'


# Generated at 2022-06-25 00:56:28.531086
# Unit test for function get_file_content
def test_get_file_content():
    # Expected type - <type 'str'>
    assert isinstance(get_file_content('/bin/cat'), str)
    # Expected type - <type 'str'>
    assert isinstance(get_file_content('/bin/ls', strip=False), str)


# Generated at 2022-06-25 00:56:34.590815
# Unit test for function get_file_content
def test_get_file_content():
    # Test 1
    data = get_file_content('/etc/fstab', strip=True)
    if isinstance(data, str):
        print('Test 1 - PASS')
    else:
        print('Test 1 - FAIL')

    # Test 2
    data = get_file_content('/tmp/doesnotexist.txt', strip=True)
    if data is None:
        print('Test 2 - PASS')
    else:
        print('Test 2 - FAIL')


# Generated at 2022-06-25 00:56:36.690905
# Unit test for function get_file_content
def test_get_file_content():
    pass  # TODO: add this test


# Generated at 2022-06-25 00:56:41.277393
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'o'
    str_1 = 'm'
    str_2 = '1'
    var_0 = get_file_content(str_0)
    var_1 = get_file_content(str_1)
    var_2 = get_file_content(str_2)



# Generated at 2022-06-25 00:56:48.287555
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('A.txt') == 'This is a test case'
    assert get_file_content('B.txt') == 'This is a test case\n'
    assert get_file_content('C.txt') == 'This is a test case\n\n'
    assert get_file_content('C.txt', strip=False) == 'This is a test case\n\n'
    assert get_file_content('D.txt', default='default') == 'default'
    assert get_file_content('U.txt', default='default') == 'default'
    assert get_file_content('E.txt', default='default') == 'default'



# Generated at 2022-06-25 00:56:54.185577
# Unit test for function get_file_content
def test_get_file_content():
    dict_0 = {}
    str_0 = '/etc/fstab'
    assert get_file_content(str_0, strip=True) is not None, 'Missing results for function get_file_content'
    var_0 = get_file_content(str_0, dict_0)
    assert var_0 == dict_0, 'Expected {}, but got {}'.format(repr(dict_0), repr(var_0))


# Generated at 2022-06-25 00:56:56.689131
# Unit test for function get_file_content
def test_get_file_content():
    print(str(test_case_0.__name__))

    print('get_file_content(str_0)')
    print(str(test_case_0.var_0))



# Generated at 2022-06-25 00:57:00.191241
# Unit test for function get_file_content
def test_get_file_content():
    assert(get_file_content('/etc/fstab') == '/dev/mapper/centos-root /                       xfs     defaults        0 0\nUUID=6f5d6d83-4cd4-4e1c-b95b-84f121578b5f /boot                   xfs     defaults        0 0\n/dev/mapper/centos-swap swap                    swap    defaults        0 0\n')



# Generated at 2022-06-25 00:57:04.847539
# Unit test for function get_file_content
def test_get_file_content():

    # Print the input arguments
    print("str_0: " + str_0)

    # Run the Ansible module
    result = get_file_content(str_0)

    # Print the result
    print("result: " + result)
    print(type(result))
    pickle.dumps(result)
    print(type(pickle.dumps(result)))


# Generated at 2022-06-25 00:57:06.544729
# Unit test for function get_file_content
def test_get_file_content():
    assert callable(get_file_content)



# Generated at 2022-06-25 00:57:08.404999
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = '/etc/fstab'
    var_0 = get_file_content(str_0)
    print(var_0)



# Generated at 2022-06-25 00:57:10.570274
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/fstab') == test_case_0()

# Generated at 2022-06-25 00:57:13.723423
# Unit test for function get_file_content
def test_get_file_content():
    assert type(get_file_content('/etc/fstab')) is str


# Generated at 2022-06-25 00:57:14.865972
# Unit test for function get_file_content
def test_get_file_content():
    get_file_content(path='/etc/fstab')



# Generated at 2022-06-25 00:57:20.852759
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = '/etc/fstab'
    var_0 = get_file_content(str_0)
    assert type(var_0) is str


# Generated at 2022-06-25 00:57:23.449713
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/fstab') is not None



# Generated at 2022-06-25 00:57:27.179090
# Unit test for function get_file_content
def test_get_file_content():
    assert test_case_0() == 'abc'



# Generated at 2022-06-25 00:57:27.778728
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/fstab') is not None



# Generated at 2022-06-25 00:57:28.760658
# Unit test for function get_file_content
def test_get_file_content():
    assert var_0 == 'www.example.com'


# Generated at 2022-06-25 00:57:29.432919
# Unit test for function get_file_content
def test_get_file_content():

    assert test_case_0() == None

# Generated at 2022-06-25 00:57:30.500623
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(None) is None

# Generated at 2022-06-25 00:57:32.749199
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = '/etc/fstab'
    var_0 = get_file_content(str_0)



# Generated at 2022-06-25 00:57:35.756537
# Unit test for function get_file_content
def test_get_file_content():
    assert True
    test_case_0()

# Generated at 2022-06-25 00:57:37.824557
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'test/static/module_utils/ansible/module_utils/basic.py'
    var_0 = get_file_content(str_0)
    print("0", var_0)



# Generated at 2022-06-25 00:57:39.411564
# Unit test for function get_file_content
def test_get_file_content():
    try:
        test_case_0()
    except:
        return False
    return True

pass
# END OF FILE
# pylint: enable=unused-variable, superfluous-parens

# Generated at 2022-06-25 00:57:41.647424
# Unit test for function get_file_content
def test_get_file_content():
    test_case_0()



# Generated at 2022-06-25 00:57:48.131687
# Unit test for function get_file_content
def test_get_file_content():
    # Function return values
    ret_0 = None
    ret_1 = None
    ret_2 = None

    str_0 = '/etc/fstab'
    var_0 = get_file_content(str_0)

    str_1 = '/etc/hosts'
    var_1 = get_file_content(str_1)

    str_2 = '/foo/bar'
    var_2 = get_file_content(str_2)

    assert var_0 == ret_0
    assert var_1 == ret_1
    assert var_2 == ret_2


# Generated at 2022-06-25 00:57:51.938657
# Unit test for function get_file_content
def test_get_file_content():
    fd = open('/etc/fstab', 'w')
    fd.write('/dev/sda1 /path/to/mount ext3 defaults\n')
    fd.write('/dev/sda2 /path/to/mount/iso ext3 ro 0 0\n')
    fd.write('/dev/cdrom1 /path/to/mount/iso iso9660 ro 0 0\n')
    fd.write('/dev/cdrom1 /path/to/mount/iso iso9660 ro 0 0\n')
    fd.close()

# Generated at 2022-06-25 00:57:55.652685
# Unit test for function get_file_content
def test_get_file_content():
    print("Tests starting")
    test_case_0()

if __name__ == '__main__':
    test_get_file_content()

# Generated at 2022-06-25 00:58:04.455215
# Unit test for function get_file_content
def test_get_file_content():
    # Create mocked functions
    str_0 = '/etc/fstab'
    var_0 = get_file_content(str_0)

# Generated at 2022-06-25 00:58:13.752540
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = '/etc/fstab'
    str_1 = os.path.normpath('/home/workspace/tests/get_file_content_0')
    str_2 = os.path.normpath('/home/workspace/tests/get_file_content_1')
    str_3 = os.path.normpath('/home/workspace/tests/get_file_content_2')
    str_4 = os.path.normpath('/home/workspace/tests/get_file_content_3')

    obj_0 = get_file_content(str_0)
    assert obj_0

    obj_1 = get_file_content(str_1, default=None, strip=True)
    assert obj_1


# Generated at 2022-06-25 00:58:14.617869
# Unit test for function get_file_content
def test_get_file_content():
    test_case_0()


# Generated at 2022-06-25 00:58:15.621510
# Unit test for function get_file_content
def test_get_file_content():
    assert test_case_0() is not None



# Generated at 2022-06-25 00:58:16.617719
# Unit test for function get_file_content
def test_get_file_content():
    assert os.path.isfile('/etc/fstab') == True
    test_case_0()

# Generated at 2022-06-25 00:58:17.826391
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/fstab')
    assert get_file_content('/etc/fstab')



# Generated at 2022-06-25 00:58:28.999335
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = '/etc/fstab'
    str_1 = 'default'
    var_0 = get_file_content(str_0)
    var_1 = get_file_content(str_0, str_1)
    str_2 = 'proc            /proc           procfs rw 0 0'
    str_3 = '# proc /proc procfs rw 0 0'
    assert str_2 in var_0
    assert str_3 not in var_1


# Generated at 2022-06-25 00:58:30.163478
# Unit test for function get_file_content
def test_get_file_content():
    print('Test case #0:')
    test_case_0()


# Generated at 2022-06-25 00:58:32.703280
# Unit test for function get_file_content
def test_get_file_content():
    func_name = 'get_file_content'

    # Case #0
    test_case_0()

# Generated at 2022-06-25 00:58:34.274698
# Unit test for function get_file_content
def test_get_file_content():
    var_0 = get_file_content('/etc/fstab')
    assert var_0

# Generated at 2022-06-25 00:58:39.169661
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = '/etc/fstab'
    var_0 = get_file_content(str_0)


# Generated at 2022-06-25 00:58:40.018556
# Unit test for function get_file_content
def test_get_file_content():
    assert True



# Generated at 2022-06-25 00:58:43.664774
# Unit test for function get_file_content
def test_get_file_content():
    global result
    # Case 0
    try:
        test_case_0()
    except base_exception as e:
        print(str(e), '\n')
        result = False
    if not result:
        print('test get_file_content: FAIL\n')
    else:
        print('test get_file_content: PASS\n')


# Generated at 2022-06-25 00:58:45.157957
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/fstab') == get_file_content('/etc/fstab')


# Generated at 2022-06-25 00:58:47.098433
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = '/etc/fstab'
    var_0 = get_file_content(str_0)
    print(var_0)


# Generated at 2022-06-25 00:58:48.331799
# Unit test for function get_file_content
def test_get_file_content():
    print("Testing: get_file_content")

    ### Test 0
    test_case_0()



# Generated at 2022-06-25 00:58:51.137542
# Unit test for function get_file_content
def test_get_file_content():
    assert(get_file_content)

# Generated at 2022-06-25 00:58:55.205523
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = '/etc/fstab'
    var_0 = get_file_content(str_0)
    assert var_0 == "lab\t/\t\t\t\t\tufs\t\trw\t1\t1", "file content is different: %s" % var_0


# Generated at 2022-06-25 00:58:57.248231
# Unit test for function get_file_content
def test_get_file_content():
    """
    Make sure that the get_file_content() function works as expected.
    :return:
    """
    print("TEST 0: ")
    test_case_0()



# Generated at 2022-06-25 00:58:58.786453
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = '/etc/fstab'
    var_0 = get_file_content(str_0)


# Generated at 2022-06-25 00:59:01.305212
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/fstab', default=None, strip=True) is not None
    assert get_file_content('/etc/fstab', default=None, strip=True) is not None
    assert get_file_content('/etc/fstab', default=None, strip=False) is not None


# Generated at 2022-06-25 00:59:02.946543
# Unit test for function get_file_content
def test_get_file_content():
    # - str_0 should have a value of: /etc/fstab
    # - var_0 should have a value of: /etc/fstab
    test_case_0()


# Generated at 2022-06-25 00:59:07.506875
# Unit test for function get_file_content
def test_get_file_content():
    # test_case0
    try:
        str_0 = "/etc/fstab"
        var_0 = get_file_content(str_0)
    except Exception as e:
        assert False

    # test_case1
    try:
        str_1 = "/etc/fstab"
        var_1 = get_file_content(str_1)
    except Exception as e:
        assert False

    # test_case2
    try:
        str_2 = "/etc/fstab"
        var_2 = get_file_content(str_2)
    except Exception as e:
        assert False


# Generated at 2022-06-25 00:59:08.799762
# Unit test for function get_file_content
def test_get_file_content():
    test_case_0()



# Generated at 2022-06-25 00:59:09.998863
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/fstab') is not None

# Generated at 2022-06-25 00:59:18.081545
# Unit test for function get_file_content
def test_get_file_content():
    assert os.path.exists('/etc/fstab')
    a_0 = '/etc/fstab'
    a_1 = 'r'
    b_0 = get_file_content('/etc/fstab')
    c_0 = stat.S_IMODE(os.lstat(a_0).st_mode)
    assert len(b_0) == 1132



# Generated at 2022-06-25 00:59:29.142731
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(None) == None

# Generated at 2022-06-25 00:59:30.329621
# Unit test for function get_file_content
def test_get_file_content():
    var_0 = get_file_content('/etc/fstab')

    print(var_0)


# Generated at 2022-06-25 00:59:33.642669
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = '/etc/rc.local'
    var_0 = get_file_content(str_0)
    assert var_0 is not None


# Generated at 2022-06-25 00:59:36.343615
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = '/etc/fstab'
    var_0 = get_file_content(str_0)
    # print(var_0)
    assert var_0 is not None
    # print(str_1)
    # print(str_2)


# Generated at 2022-06-25 00:59:38.847020
# Unit test for function get_file_content
def test_get_file_content():
    test_cases = [
        (test_case_0, {})
    ]

    for func, args in test_cases:
        try:
            func(**args)
        except Exception as e:
            print(e)


if __name__ == '__main__':
    test_get_file_content()

# Generated at 2022-06-25 00:59:45.123887
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/fstab')
    assert get_file_content('/etc/fstab', strip=False)
    assert get_file_content('/etc/fstab', line_sep='\n')


# Generated at 2022-06-25 00:59:46.034027
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/fstab') != None


# Generated at 2022-06-25 00:59:47.493519
# Unit test for function get_file_content
def test_get_file_content():
    context = []
    test_case_0()
    assert context

# Tests for Ansible

# Generated at 2022-06-25 00:59:48.903352
# Unit test for function get_file_content
def test_get_file_content():
    assert test_case_0() == None, "test_case_0 failed."

print('Running unit tests')
test_get_file_content()
print('No unit tests failed')

# Generated at 2022-06-25 00:59:49.855685
# Unit test for function get_file_content
def test_get_file_content():
    assert True, 'Test to see if get_file_content returns expected result'

# Generated at 2022-06-25 00:59:54.000799
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = '/etc/fstab'
    var_0 = get_file_content(str_0)
    print(var_0)



# Generated at 2022-06-25 01:00:02.828251
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/fstab') == '# /etc/fstab: static file system information.\n#\n# <file system> <mount point>   <type>  <options>       <dump>  <pass>\n/dev/sda1        /               ext4    errors=remount-ro 0       1\n/dev/sdb1        /mnt            ext4    defaults        0       2\n/dev/sda2        swap            swap    defaults        0       0\n/dev/sdb3        /var/mariadb    ext4    defaults        0       2\n/dev/sdb4        /var/www/html   ext4    defaults        0       2'



# Generated at 2022-06-25 01:00:05.522392
# Unit test for function get_file_content
def test_get_file_content():
    with open("/etc/fstab", "r") as fh:
        assert get_file_content("/etc/fstab") == fh.read()

# Generated at 2022-06-25 01:00:08.171008
# Unit test for function get_file_content
def test_get_file_content():
    str_1 = '/etc/fstab'
    var_1 = get_file_content(str_1)
    assert var_1 == '/etc/fstab'


# Generated at 2022-06-25 01:00:13.126283
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = '/etc/fstab'
    str_1 = 'default'
    bool_0 = False
    var_0 = get_file_content(str_0, default=str_1, strip=bool_0)
    assert var_0 != None


# Generated at 2022-06-25 01:00:14.843515
# Unit test for function get_file_content
def test_get_file_content():
    print('==== test_get_file_content ====')

    test_case_0()



# Generated at 2022-06-25 01:00:18.828932
# Unit test for function get_file_content
def test_get_file_content():
    path = '/etc/fstab'
    default = 'foobar'
    strip = True
    data = None
    assert get_file_content(path, default, strip) == data
    strip = False
    data = None
    assert get_file_content(path, default, strip) == data


# Generated at 2022-06-25 01:00:22.958239
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content("/etc/fstab") is not None

    assert get_file_content("/etc/fstab1", default="1") == "1"

    assert get_file_content("/etc/fstab2", strip=False) is None

# Generated at 2022-06-25 01:00:29.226367
# Unit test for function get_file_content
def test_get_file_content():
    print('Testing get_file_content...')

    assert get_file_content('/etc/fstab') is not None
    assert get_file_content('/etc/fstab') != ''
    assert get_file_content('/fooooosdfsdfsdfsdfsdfsdfsdfsdf') == None
    print('get_file_content passed!')




# Generated at 2022-06-25 01:00:30.355112
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/fstab') is not None


# Generated at 2022-06-25 01:00:34.216404
# Unit test for function get_file_content
def test_get_file_content():
    print("test_get_file_content")
    str_0 = '/etc/fstab'
    var_0 = get_file_content(str_0)
    print(var_0)
    return var_0



# Generated at 2022-06-25 01:00:35.369324
# Unit test for function get_file_content
def test_get_file_content():
    assert len(test_case_0) == 0



# Generated at 2022-06-25 01:00:40.574334
# Unit test for function get_file_content
def test_get_file_content():
    # Initial test case
    #    str_0 = '/etc/fstab'
    #    var_0 = get_file_content(str_0)
    #
    #    assert var_0

    # File does not exist
    str_0 = '/etc/foobarbaz'
    var_0 = get_file_content(str_0)

    assert not var_0



# Generated at 2022-06-25 01:00:42.442063
# Unit test for function get_file_content
def test_get_file_content():
    test_case_0()


# Generated at 2022-06-25 01:00:46.986180
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/fstab')



# Generated at 2022-06-25 01:00:51.194923
# Unit test for function get_file_content
def test_get_file_content():
    assert not get_file_content('/etc/passwd', default='cheese')
    assert get_file_content('/etc/passwd', default='cheese') == 'cheese'
    assert get_file_content('/etc/passwd')
    assert get_file_content('/etc/fstab')


# Generated at 2022-06-25 01:00:52.278912
# Unit test for function get_file_content
def test_get_file_content():
    print(os.path.abspath(__file__))
    test_case_0()

# Generated at 2022-06-25 01:00:53.429381
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/aliases') != None, 'Unit test for function "get_file_content" failed'


# Generated at 2022-06-25 01:00:58.515848
# Unit test for function get_file_content
def test_get_file_content():
    # Test module get_file_content when called with a single argument
    actual = get_file_content('/etc/fstab')
    expected = '/dev/mapper/fedora-root /                       ext4    defaults        1 1\nUUID=f5f2bf7d-eab6-4c6e-ac3d-0b9a9b98c988 /boot                   ext4    defaults        1 2\n/dev/mapper/fedora-home /home                   ext4    defaults        1 2\n/dev/mapper/fedora-swap swap                    swap    defaults        0 0'

    assert actual == expected

    # Test module get_file_content when called with 2 arguments
    actual = get_file_content('/etc/fstab', '')
    expected = ''

    assert actual == expected

    # Test module

# Generated at 2022-06-25 01:01:03.469632
# Unit test for function get_file_content
def test_get_file_content():
    assert isinstance(get_file_content('foo'), str)


# Generated at 2022-06-25 01:01:09.114278
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/fstab') != None


# Generated at 2022-06-25 01:01:11.580984
# Unit test for function get_file_content
def test_get_file_content():
    assert test_case_0() == True


# Generated at 2022-06-25 01:01:15.067132
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = '/etc/fstab'
    var_0 = get_file_content(str_0)


# Generated at 2022-06-25 01:01:19.502368
# Unit test for function get_file_content
def test_get_file_content():
    path = '/etc/fstab'
    default = None
    strip = True
    assert os.path.exists(path)
    assert os.access(path, os.R_OK)
    assert True
    assert True
    assert True


# Generated at 2022-06-25 01:01:26.102240
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/fstab')
    # However, in Python 3.x, the following raises an error:
    # TypeError: 'NoneType' object is not subscriptable
    # assert get_file_content('/etc/fstab')[0] == '/'


# Generated at 2022-06-25 01:01:27.415249
# Unit test for function get_file_content
def test_get_file_content():
    print('No unit test for function get_file_content')
    print('Passed all test for function get_file_content')


# Generated at 2022-06-25 01:01:29.316213
# Unit test for function get_file_content
def test_get_file_content():
    # Expected result for excuting test_case_0
    assert get_file_content('/etc/fstab')



# Generated at 2022-06-25 01:01:32.560942
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(str_0) == var_0


# Generated at 2022-06-25 01:01:36.128768
# Unit test for function get_file_content
def test_get_file_content():
    assert test_case_0() == 'None'

# Generated at 2022-06-25 01:01:40.754290
# Unit test for function get_file_content
def test_get_file_content():
    ret = get_file_content('/etc/fstab', True, True)
    assert type(ret) == str

    ret = get_file_content('/etc/fstab', False, True)
    assert type(ret) == str

    ret = get_file_content('/etc/fstab', False, False)
    assert type(ret) == str

    ret = get_file_content('/etc/fstab', True, False)
    assert type(ret) == str


# Generated at 2022-06-25 01:01:45.574476
# Unit test for function get_file_content
def test_get_file_content():
    assert test_case_0() == '', 'Test get_file_content #0 failed.'


# Generated at 2022-06-25 01:01:49.786714
# Unit test for function get_file_content
def test_get_file_content():
    assert os.path.exists('/etc/fstab')

# This is a handy place to invoke the tests
if __name__ == '__main__':
    print('Running tests')
    print('Test case 0')
    print('Test get_file_content')
    test_case_0()
    test_get_file_content()

# Generated at 2022-06-25 01:01:54.087857
# Unit test for function get_file_content
def test_get_file_content():
    assert(test_case_0() == None)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:01:54.829353
# Unit test for function get_file_content
def test_get_file_content():
    data = get_file_content('/etc/fstab')
    assert data is not None



# Generated at 2022-06-25 01:01:57.963880
# Unit test for function get_file_content
def test_get_file_content():
    import os
    import tempfile
    fp, fn = tempfile.mkstemp()
    f = os.fdopen(fp, 'w')
    f.write('foo\nbar\nbaz\n')
    f.close()
    try:
        assert get_file_content(fn) == 'foo\nbar\nbaz'
    finally:
        os.unlink(fn)

# Test case for function get_mount_size

# Generated at 2022-06-25 01:02:00.912971
# Unit test for function get_file_content
def test_get_file_content():
    var_0 = get_file_content('/etc/fstab')  # noqa
    assert var_0 is not None


# Generated at 2022-06-25 01:02:05.567557
# Unit test for function get_file_content
def test_get_file_content():
    print('Test get_file_content')

    # Do not remove this print statement. It is needed to check the correctness
    test_case_0()


# Generated at 2022-06-25 01:02:10.048211
# Unit test for function get_file_content
def test_get_file_content():
    print(get_file_content.__name__)
    print(get_file_content.__doc__)


# Generated at 2022-06-25 01:02:13.016847
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = '/etc/fstab'
    var_0 = get_file_content(str_0)
    assert type(var_0) is str



# Generated at 2022-06-25 01:02:14.338899
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/fstab')



# Generated at 2022-06-25 01:02:18.434996
# Unit test for function get_file_content
def test_get_file_content():
    assert test_case_0() == None

# Generated at 2022-06-25 01:02:20.431506
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = '/etc/fstab'
    var_0 = get_file_content(str_0)
    return var_0



# Generated at 2022-06-25 01:02:22.265044
# Unit test for function get_file_content
def test_get_file_content():
    fs_tab_file = '/etc/fstab'
    fstab_file_contents = get_file_content(fs_tab_file)
    assert fstab_file_contents != None



# Generated at 2022-06-25 01:02:22.922574
# Unit test for function get_file_content
def test_get_file_content():
    assert test_case_0() == None



# Generated at 2022-06-25 01:02:24.480299
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = '/etc/fstab'
    var_0 = get_file_content(str_0)
    assert type(var_0) == str


# Generated at 2022-06-25 01:02:29.182783
# Unit test for function get_file_content
def test_get_file_content():
    passwd_file_path = '/etc/passwd'

# Generated at 2022-06-25 01:02:30.216350
# Unit test for function get_file_content
def test_get_file_content():

    # testing executing 'get_file_content'
    test_case_0()



# Generated at 2022-06-25 01:02:32.110036
# Unit test for function get_file_content
def test_get_file_content():
    # Function that returns a string
    str_0 = '/etc/fstab'
    var_0 = get_file_content(str_0)

    # Testing if the type of "var_0" is a string
    assert (isinstance(var_0, basestring)), 'assertion failed'



# Generated at 2022-06-25 01:02:35.897622
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = '/etc/fstab'
    var_0 = get_file_content(str_0)

    print('type(var_0)',type(var_0))
    print('var_0',var_0)
    assert(var_0 is not None)


# Generated at 2022-06-25 01:02:36.618731
# Unit test for function get_file_content
def test_get_file_content():
    test_case_0()



# Generated at 2022-06-25 01:02:44.389518
# Unit test for function get_file_content
def test_get_file_content():
    # Create a data structure to hold the parameters
    class Test_get_content(object):
        def __init__(self, path, default=None, strip=True):
            self.path = path
            self.default = default
            self.strip = strip

    # Test the output
    module = AnsibleModule(argument_spec={})
    # Create a new object of that data structure
    str_0 = '/etc/fstab'
    obj_0 = Test_get_content(str_0)
    # get the result of the function
    var_0 = get_file_content(obj_0.path)



# Generated at 2022-06-25 01:02:51.856404
# Unit test for function get_file_content
def test_get_file_content():
    print("Testing get_file_content()")
    str_0 = '/etc/fstab'
    var_0 = get_file_content(str_0)

    assert var_0 == "/dev/mapper/VolGroup00-LogVol00 /                       ext3    defaults        1 1\nnone /dev/pts devpts gid=5,mode=620 0 0\nnone /dev/shm tmpfs defaults 0 0\nnone /proc proc defaults 0 0\nnone /sys sysfs defaults 0 0\n/dev/hda /boot ext3 defaults 1 2\n/dev/hda2       swap    swap    defaults        0 0\n"


# Generated at 2022-06-25 01:02:55.847203
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/fstab') == get_file_content('/etc/fstab')


# Generated at 2022-06-25 01:02:58.327034
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = '/etc/fstab'
    var_0 = get_file_content(str_0)
    assert var_0 is not None


# Generated at 2022-06-25 01:03:05.245286
# Unit test for function get_file_content
def test_get_file_content():
    # Remove if a previous test left a file
    try:
        os.remove('/tmp/test-file')
    except OSError:
        pass

    assert get_file_content('/tmp/file-no-exists') is None
    assert get_file_content('/tmp/file-no-exists', 'value') == 'value'

    assert get_file_content('/tmp/test-file', 'value') == 'value'
    with open('/tmp/test-file', 'wb') as f:
        f.write(b'')

    assert get_file_content('/tmp/test-file') == ''
    assert get_file_content('/tmp/test-file', 'value') == ''


# Generated at 2022-06-25 01:03:06.281240
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/tmp/foo/bar') is None


# Generated at 2022-06-25 01:03:16.906187
# Unit test for function get_file_content
def test_get_file_content():
    # Check expected values
    assert get_file_content(str_0) == 1
    assert get_file_content(str_1) == 0

    # Check return type
    assert isinstance(get_file_content(str_0), int)

    # Verify type
    assert(get_file_content(str_0) == var_0)
    assert(get_file_content(str_1) == var_1)
    assert(get_file_content(str_0) == var_2)
    assert(get_file_content(str_1) == var_3)
    assert(get_file_content(str_0) == var_4)
    assert(get_file_content(str_1) == var_5)

    # Check return type

# Generated at 2022-06-25 01:03:17.709893
# Unit test for function get_file_content
def test_get_file_content():
    print(test_case_0())


# Generated at 2022-06-25 01:03:28.136865
# Unit test for function get_file_content
def test_get_file_content():
    # test_case_0
    str_0 = '/etc/fstab'
    var_1 = get_file_content(str_0)
    if(var_1):
        print('DBG: get_file_content match')
    else:
        print('DBG: get_file_content no match')
    # test_case_1
    str_2 = '/etc/group'
    var_3 = get_file_content(str_2)
    if(var_3):
        print('DBG: get_file_content match')
    else:
        print('DBG: get_file_content no match')
    # test_case_2
    str_4 = '/etc/passwd'
    var_5 = get_file_content(str_4)
    if(var_5):
        print

# Generated at 2022-06-25 01:03:32.032777
# Unit test for function get_file_content
def test_get_file_content():
    test_case_0()

# Generated at 2022-06-25 01:03:35.128700
# Unit test for function get_file_content
def test_get_file_content():
    assert test_case_0() == 'None'

# Generated at 2022-06-25 01:03:45.229139
# Unit test for function get_file_content

# Generated at 2022-06-25 01:03:47.650391
# Unit test for function get_file_content
def test_get_file_content():
    assert os.path.isfile('/etc/fstab')
    assert os.access('/etc/fstab', os.R_OK)

    return test_case_0()


# Generated at 2022-06-25 01:03:53.575301
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = '/etc/fstab'
    var_0 = get_file_content(str_0)
    assert var_0 is not None and var_0 != "", "get_file_content function failed (test case 0)"

    str_0 = '/etc/fstab'
    str_1 = '/etc/fstab'
    var_0 = get_file_content(str_0, default=str_1)
    assert var_0 is not None and var_0 != "", "get_file_content function failed (test case 1)"

    str_0 = '/etc/fstab'
    str_1 = 'some string'
    var_0 = get_file_content(str_0, default=str_1)
    assert var_0.strip() is not None and var_0.strip() != "" and var_

# Generated at 2022-06-25 01:04:02.388688
# Unit test for function get_file_content
def test_get_file_content():
    """
    Test function get_file_content
    """
    test_values = [
        ('/etc/fstab', '', True),
        ('/etc/fstab', '', False),
        ('/noexist/fstab', 'None', True),
        ('/etc/fstab', 'None', True, False),
        ('/etc/fstab', 'None', False, False),
        ('/noexist/fstab', 'None', True, False),
    ]

    for path, default, strip, return_none in test_values:
        assert get_file_content(path, default, strip), return_none



# Generated at 2022-06-25 01:04:07.024483
# Unit test for function get_file_content
def test_get_file_content():

    path = '/etc/fstab'
    default_value = 'x'

    # test 1
    var_0 = get_file_content(path, default_value)
    assert var_0 == default_value

    # test 2
    var_0 = get_file_content(path, default_value, False)
    assert var_0 == default_value


# Generated at 2022-06-25 01:04:10.614015
# Unit test for function get_file_content
def test_get_file_content():
    assert True == os.access(str_0, os.R_OK)
    assert os.path.exists(str_0) == True
    assert var_0 == ''


# Generated at 2022-06-25 01:04:14.702305
# Unit test for function get_file_content
def test_get_file_content():
    assert '/etc/fstab' == get_file_content(test_case_0, strip=True)
    assert '' == get_file_content(test_case_0, strip=False)

# Generated at 2022-06-25 01:04:15.484182
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content() == None

# Generated at 2022-06-25 01:04:18.792418
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = '/etc/fstab'
    var_0 = get_file_content(str_0)
    if var_0 == '/dev/md0 / ext3 defaults 0 1\n':
        return True
    return False

# Generated at 2022-06-25 01:04:28.535174
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/fstab') == test_case_0()
