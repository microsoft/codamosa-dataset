

# Generated at 2022-06-25 00:54:45.083742
# Unit test for function get_file_content
def test_get_file_content():
    test_case_0()

# Generated at 2022-06-25 00:54:45.675720
# Unit test for function get_file_content
def test_get_file_content():
    test_case_0()


# Generated at 2022-06-25 00:54:46.493985
# Unit test for function get_file_content
def test_get_file_content():
    test_case_0()


# Generated at 2022-06-25 00:54:48.122412
# Unit test for function get_file_content
def test_get_file_content():
    path = 'abs'
    strip = True
    ret = get_file_content(path)
    assert ret == 'abcdefg'


# Generated at 2022-06-25 00:54:54.001478
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/tmp/testfile') is None
    testfile = open('/tmp/testfile', 'w')
    testfile.write('testing content')
    testfile.close()
    assert get_file_content('/tmp/testfile') == 'testing content'
    os.unlink('/tmp/testfile')



# Generated at 2022-06-25 00:54:58.746808
# Unit test for function get_file_content
def test_get_file_content():
    path = 'test_data/get_file_content.data'
    test_data = 'blahblahblah\n'
    default = 'blahblahblah\n'
    value = get_file_content(path, default)
    assert value == test_data

    path = 'test_data/get_file_content.not_there'
    value = get_file_content(path, default)
    assert value == default


# Generated at 2022-06-25 00:55:04.549714
# Unit test for function get_file_content
def test_get_file_content():
    try:
        test_case_0()
    except Exception as e:
        print('Exception raised: ' + str(e))
        print('Failed to run test_case_0')

if __name__ == "__main__":
    for i in range(1000000):
        test_get_file_content()

# Generated at 2022-06-25 00:55:12.356713
# Unit test for function get_file_content
def test_get_file_content():
    """test_get_file_content"""
    assert get_file_content(os.path.join(os.path.dirname(__file__), '../../../../files/test/fixtures/ansible/test_get_file_content.txt')) == 'test_content\n'
    assert get_file_content(os.path.join(os.path.dirname(__file__), '../../../../files/test/fixtures/ansible/test_get_file_content.txt'), strip=False) == 'test_content\n'



# Generated at 2022-06-25 00:55:22.315010
# Unit test for function get_file_content
def test_get_file_content():
    assert 'T9]A7N|KW>u}7' == get_file_content('T9]A7N|KW>u}7', 'T9]A7N|KW>u}7')
    assert 'aRg"K8c0' == get_file_content('aRg"K8c0', 'aRg"K8c0')
    assert 'h?<9ePE6wt4L1e_y' == get_file_content('h?<9ePE6wt4L1e_y', 'h?<9ePE6wt4L1e_y')
    assert '2"Xe' == get_file_content('2"Xe', '2"Xe')
    assert '{5' == get_file_content('{5', '{5')
   

# Generated at 2022-06-25 00:55:28.031837
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'g?"3u(SaCrBusNI8'
    var_0 = get_file_content(str_0, str_0)
    assert var_0 == str_0

if __name__ == '__main__':
    test_case_0()
    test_get_file_content()

# Generated at 2022-06-25 00:55:40.524066
# Unit test for function get_file_content
def test_get_file_content():
    var_0 = 'XgZn0Y0lsz'
    test_case_0()
    var_1 = get_file_content('rpXZPb5e5U/i6zA/7x5O2EuV/', var_0, False)
    var_2 = get_file_content('rpXZPb5e5U/i6zA/7x5O2EuV/', var_0, True)
    var_3 = get_file_content('rpXZPb5e5U/i6zA/7x5O2EuV/', var_0, False)

# Generated at 2022-06-25 00:55:43.445770
# Unit test for function get_file_content
def test_get_file_content():
    print('Testing get_file_content')
    test_case_0()
    print('Test 0 Passed')


# Generated at 2022-06-25 00:55:44.333141
# Unit test for function get_file_content
def test_get_file_content():
    pass


# Generated at 2022-06-25 00:55:45.461002
# Unit test for function get_file_content
def test_get_file_content():
    t_0 = test_case_0()


# Generated at 2022-06-25 00:55:48.860425
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/shadow') is None
    assert get_file_content('/proc/cpuinfo') is not None
    assert get_file_content('/etc/shadow', strip=False) is None


# Generated at 2022-06-25 00:55:50.517687
# Unit test for function get_file_content
def test_get_file_content():
    test_case_0()

# Generated at 2022-06-25 00:55:51.383375
# Unit test for function get_file_content
def test_get_file_content():
	test_case_0()



# Generated at 2022-06-25 00:55:58.110512
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content("test_file", "default", strip=False) == "test_file"
    assert get_file_content("test_file", "default", strip=True) == "test_file"
    assert get_file_content("test_file", "default", strip=False) == "default"


# Generated at 2022-06-25 00:56:04.872043
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/tmp/tesdtfile', '/tmp/tesdtfile') == '/tmp/tesdtfile'
    assert get_file_content('/tmp/tesdtfile', '/tmp/tesdtfile', True) == '/tmp/tesdtfile'
    assert get_file_content('/tmp/tesdtfile', '/tmp/tesdtfile', False) == '/tmp/tesdtfile'
    assert get_file_content('/tmp/tesdtfile', '/tmp/tesdtfile', False, False) == '/tmp/tesdtfile'



# Generated at 2022-06-25 00:56:13.163621
# Unit test for function get_file_content
def test_get_file_content():
    var_0 = get_file_content('/root/.ssh/authorized_keys')
    print(var_0)

    var_1 = get_file_content('/etc/passwd')
    print(var_1)

    var_2 = get_file_content('/etc/')
    print(var_2)

    var_3 = get_file_content('/etc/', 'default')
    print(var_3)

    var_4 = get_file_content('/etc/', 'default', strip=False)
    print(var_4)

    var_5 = get_file_content('/root/.ssh/authorized_keys', strip=False)
    print(var_5)

    var_6 = get_file_content('/', 'default')
    print(var_6)

# Generated at 2022-06-25 00:56:18.934837
# Unit test for function get_file_content
def test_get_file_content():
    # Test 1
    str_0 = '../../ansible_collections/ansible/rht_ansible_tower_collections/plugins/modules/clc_module.py'
    assert get_file_content(str_0) == '#!/usr/bin/python'


# Generated at 2022-06-25 00:56:23.678471
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'g?"3u(SaCrBusNI8'
    var_0 = get_file_content(str_0, str_0)
    assert var_0 == str_0


# Generated at 2022-06-25 00:56:28.861445
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = '/var/log/syslog'
    var_0 = get_file_content(str_0)
    assert var_0 == 'This is expected content of /var/log/syslog\n'

    str_1 = 'g?"3u(SaCrBusNI8'
    var_1 = get_file_content(str_1, str_1)
    assert var_1 == str_1


# Generated at 2022-06-25 00:56:31.819600
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('test', 'test') == 'test'


# Generated at 2022-06-25 00:56:37.023898
# Unit test for function get_file_content
def test_get_file_content():
    res = get_file_content('/etc/issue', default='', strip=True)
    assert len(res) > 0
    res = get_file_content('/etc/issue', strip=False)
    assert '\n' in res
    res = get_file_content('/etc/issue', strip=True)
    assert '\n' not in res
    res = get_file_content('/etc/issue', '')
    assert len(res) > 0

# Generated at 2022-06-25 00:56:40.437217
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content("12345") == 12345
    assert get_file_content("1") == 1
    assert get_file_content("a") == "a"



# Generated at 2022-06-25 00:56:43.377704
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/shadow', 'no passwd') == 'no passwd'
    assert get_file_content('/etc/shadow', 'no passwd') != '/etc/shadow'


# Generated at 2022-06-25 00:56:46.490807
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(test_case_0(), 10, 12) == 10


# Generated at 2022-06-25 00:56:50.456252
# Unit test for function get_file_content
def test_get_file_content():
    try:
        assert(test_case_0() == 'g?"3u(SaCrBusNI8')
    except AssertionError:
        raise AssertionError('Assertion failed: test_case_0() == \'g?"3u(SaCrBusNI8\'')


# Generated at 2022-06-25 00:56:55.222295
# Unit test for function get_file_content
def test_get_file_content():
    with open('test', 'w') as file:
        file.write('Hello World')
    assert get_file_content('test') == 'Hello World'
    assert get_file_content('test', strip=False) == 'Hello World\n'
    assert get_file_content('test', strip=False, default='123') == 'Hello World\n'
    assert get_file_content('no_exist_file', default='123') == '123'


# Generated at 2022-06-25 00:57:07.304180
# Unit test for function get_file_content
def test_get_file_content():
    # Verify call to method works
    str_0 = "g?'3u(SaCrBusNI8"
    var_0 = get_file_content(str_0, default="")
    assert var_0 == str_0

    # Verify call to method works
    str_0 = "g?.3u(SaCrBusNI8"
    var_0 = get_file_content(str_0, default="")
    assert var_0 == str_0

    # Verify call to method works
    str_0 = "g?/3u(SaCrBusNI8"
    var_0 = get_file_content(str_0, default="")
    assert var_0 == str_0

    # Verify call to method works
    str_0 = "g?03u(SaCrBusNI8"
    var_0 = get

# Generated at 2022-06-25 00:57:11.380362
# Unit test for function get_file_content
def test_get_file_content():
    try:
        assert get_file_content('/bin/true') == ''
        get_file_content('/bin/false')
    except Exception:
        assert False
    else:
        assert True


# Generated at 2022-06-25 00:57:19.047907
# Unit test for function get_file_content
def test_get_file_content():
    var_0 = get_file_content('/dev/null', '')
    var_0 = get_file_content('/dev/zero', '')
    var_0 = get_file_content('/dev/random', '')
    var_0 = get_file_content('/dev/urandom', '')
    var_0 = get_file_content('/dev/sda', '')
    var_0 = get_file_content('/dev/sdb', '')
    var_0 = get_file_content('/dev/sdc', '')
    var_0 = get_file_content('/dev/sdd', '')
    var_0 = get_file_content('/dev/sde', '')
    var_0 = get_file_content('/dev/sdf', '')
    var

# Generated at 2022-06-25 00:57:23.230265
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', 'vars/passwd') == '/etc/passwd'
    assert get_file_content('/etc/passwd', '') == '/etc/passwd'
    assert get_file_content('/etc/passwd', '/etc/passwd') == '/etc/passwd'
    assert get_file_content('/etc/passwd', '/etc/passwd', True) == '/etc/passwd'
    assert get_file_content('/etc/passwd', '/etc/passwd', False) == '/etc/passwd'


# Generated at 2022-06-25 00:57:27.146751
# Unit test for function get_file_content
def test_get_file_content():
    assert callable(get_file_content), "Function does not exist"



# Generated at 2022-06-25 00:57:30.411902
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'V7aU8~YKb`10>'
    str_1 = '2n(Z4E4f)R<s,_'
    str_2 = 'S{%cXg"n!3_=0H'
    var_0 = get_file_content(str_0, str_1, str_2)


# Generated at 2022-06-25 00:57:36.669855
# Unit test for function get_file_content
def test_get_file_content():
    path = '/etc/passwd'
    default = 'admin:x:0:0:root:/root:/bin/bash'
    default_stripped = default.strip()
    result = get_file_content(path)
    assert result is not None
    assert result != default
    assert result.strip() == result
    result = get_file_content(path, default)
    assert result is not None
    assert result != default
    assert result.strip() == result
    result = get_file_content(path, default, strip=False)
    assert result is not None
    assert result != default
    assert result.strip() == result
    result = get_file_content(path, default, strip=False)
    assert result is not None
    assert result != default
    assert result.strip() == result
    result = get_file_

# Generated at 2022-06-25 00:57:45.938439
# Unit test for function get_file_content
def test_get_file_content():
    # test 1
    str_0 = 'g?"3u(SaCrBusNI8'
    assert get_file_content(str_0, str_0) == 'g?"3u(SaCrBusNI8'

    # test 2
    str_0 = '<(CR!ku5G0HZ,A.'
    assert get_file_content(str_0, str_0, True) == '<(CR!ku5G0HZ,A.'

    # test 3
    str_0 = '[e"8<1XG"B[x#Q'
    assert get_file_content(str_0, str_0, True) == '[e"8<1XG"B[x#Q'

    # test 4
    str_0 = 'aLy?8Wbp9XASv0g'
   

# Generated at 2022-06-25 00:57:49.919352
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'x"x[lNuV(F/pW%cX7'
    var_0 = get_file_content(str_0, str_0)
    str_1 = 'M@X9E^c%}6S;+T|F%'
    var_1 = get_file_content(str_1, str_1)
    str_2 = '<$h\\rA%Zg(^sdFtW#'
    var_2 = get_file_content(str_2, str_2)
    str_3 = 'e=Or8*V7F5>5:uX7+'
    var_3 = get_file_content(str_3, str_3)

# Generated at 2022-06-25 00:57:55.253137
# Unit test for function get_file_content
def test_get_file_content():
    try:
        str_0 = 'g?"3u(SaCrBusNI8'
        var_0 = get_file_content(str_0, str_0)
    except Exception:
        var_0 = None
    assert var_0 == str_0

