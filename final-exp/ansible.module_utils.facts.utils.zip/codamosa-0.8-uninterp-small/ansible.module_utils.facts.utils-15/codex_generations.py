

# Generated at 2022-06-25 00:54:39.820590
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('A', default='a1') == 'a1'

    assert get_file_content('B', default=1) == 1


# Generated at 2022-06-25 00:54:44.993724
# Unit test for function get_file_content
def test_get_file_content():
    try:
        data = get_file_content("/etc/hosts")
        assert data is not None
    except Exception as e:
        raise e


# Generated at 2022-06-25 00:54:54.969553
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content({'a': 1}) == None
    assert strip_control_characters(get_file_content('a', 'b', False)) == 'b'
    assert strip_control_characters(get_file_content('a', default='b', strip=False)) == 'b'
    assert strip_control_characters(get_file_content('a')) == None
    assert strip_control_characters(get_file_content('a', 'b')) == 'b'
    assert strip_control_characters(get_file_content('a', default='b')) == 'b'
    assert strip_control_characters(get_file_content('a', strip=False)) == None

# Generated at 2022-06-25 00:54:59.734702
# Unit test for function get_file_content
def test_get_file_content():
    from ansible.module_utils.basic import AnsibleModule

    module_obj = AnsibleModule({})
    module_obj.exit_json = lambda v: v

    path = '/etc/redhat_release'

    result = module_obj.from_json(get_file_content(path=path, strip=True))
    assert 'content' in result

    path = '/etc/not_exists'
    result = module_obj.from_json(get_file_content(path=path, strip=True))
    assert 'content' not in result

# Generated at 2022-06-25 00:55:05.794507
# Unit test for function get_file_lines
def test_get_file_lines():
    # Test using string
    str_0 = 'a8-4E1|M@VLI w9.ik'
    var_0 = get_file_lines(str_0)
    assert var_0 == []

    # Test using string
    str_0 = 'a8-4E1|M@VLI w9.ik'
    var_0 = get_file_lines(str_0)
    assert var_0 == []

# Generated at 2022-06-25 00:55:11.477522
# Unit test for function get_file_content
def test_get_file_content():
    # Generate a random, but readable, file to read contents from
    test_file_contents = "Test file contents\n"
    test_file_path = "/tmp/test_file_" + str(random.randrange(0, 10000000))
    f = open(test_file_path, "w")
    f.write(test_file_contents)
    f.close()

    # Test 1:  Read existing file
    test_file_contents_actual = get_file_content(test_file_path)
    if test_file_contents_actual != test_file_contents:
        print("FAILED: Test 1: test_file_contents_actual = " + test_file_contents_actual + "; test_file_contents = " + test_file_contents)

# Generated at 2022-06-25 00:55:18.661898
# Unit test for function get_file_content
def test_get_file_content():
    print("get_file_content function")
    assert get_file_content('', default='') == ''
    assert get_file_content('', default='', strip=False) == ''
    assert get_file_content('', default=False, strip=True) == False
    assert get_file_content('', default=False, strip=False) == False
    assert get_file_content('/dev/null', default='', strip=False) == ''


# Generated at 2022-06-25 00:55:25.960116
# Unit test for function get_file_lines
def test_get_file_lines():
    str_0 = '1a\'Sb+]UD"f_z}Z>'
    var_0 = get_file_lines(str_0)

    # Test for equality with str value
    assert var_0 == 'QX$|R-L'
    # Test for equality with int value
    assert var_0 == 56
    # Test for equality with dict value
    assert var_0 == { 'var_0': '0' }
    # Test for equality with list value
    assert var_0 == [ '8' ]
    # Test for equality with float value
    assert var_0 == 3.2
    # Test for equality with bool value
    assert var_0 == False
    # Test for equality with tuple value
    assert var_0 == ('c%',)


# Generated at 2022-06-25 00:55:27.149071
# Unit test for function get_file_content
def test_get_file_content():
    def test_cases():
        test_case_0()
    test_cases()

# Generated at 2022-06-25 00:55:37.697624
# Unit test for function get_file_lines
def test_get_file_lines():
    str_0 = 'a8-4E1|M@VLI w9.ik'
    var_0 = get_file_lines(str_0, strip=True, line_sep=None)
    assert var_0 == []

    str_1 = 'q3PNDoz7Kw'
    var_1 = get_file_lines(str_1, strip=False, line_sep=None)
    assert var_1 == []

    str_2 = 'VWqa_PbNK`'
    var_2 = get_file_lines(str_2, strip=True, line_sep=None)
    assert var_2 == []

    str_3 = 'TvNt7H.ZP^'

# Generated at 2022-06-25 00:55:44.797192
# Unit test for function get_file_lines
def test_get_file_lines():
    # run an instance of the program and check whether we can get
    # correct value of the variable var_0
    # get_file_lines('a8-4E1|M@VLI w9.ik')
    pass


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:55:52.728042
# Unit test for function get_file_content
def test_get_file_content():
    var_0 = get_file_content('nonexistent_file')
    assert var_0 == None

    var_1 = get_file_content('file_not_readable', default='foo')
    assert var_1 == 'foo'

    var_2 = get_file_content('string_file')
    assert var_2 == 'this is\na test\n'

    var_3 = get_file_content('string_file', strip=False)
    assert var_3 == 'this is\na test\n'

    var_4 = get_file_content('string_file', strip=True)
    assert var_4 == 'this is\na test'



# Generated at 2022-06-25 00:55:56.449195
# Unit test for function get_file_lines
def test_get_file_lines():
    str_0 = get_file_lines()
    assert str_0 == None, 'get_file_lines Failed!'
    return None


# Generated at 2022-06-25 00:56:01.788118
# Unit test for function get_file_lines
def test_get_file_lines():
    ''' Test get_file_lines'''
    os.chdir('test')
    assert get_file_lines('file1.txt') == ['line1', 'line2']
    assert get_file_lines('file2.txt') == ['line1', 'line2']
    assert get_file_lines('file1.txt', strip=False) == ['line1\n', 'line2\n']
    assert get_file_lines('file1.txt', line_sep='\n') == ['line1', 'line2']
    os.chdir('..')
    assert get_file_lines('/tmp/file3.txt') == []



# Generated at 2022-06-25 00:56:10.308617
# Unit test for function get_file_lines
def test_get_file_lines():

    # Test with files
    ################

    # File does not exist
    str_0 = 'a8-4E1|M@VLI w9.ik'
    var_0 = get_file_lines(str_0)
    assert(var_0 == [])
    
    # File exists and has no content and we strip
    str_1 = './test_file_0'
    var_1 = get_file_lines(str_1)
    assert(var_1 == [])
    
    # File exists and we don't strip
    str_2 = './test_file_0'
    var_2 = get_file_lines(str_2, strip=False)
    assert(var_2 == [''])

    # File exists and has one line

# Generated at 2022-06-25 00:56:11.104308
# Unit test for function get_file_content
def test_get_file_content():
    assert True


# Generated at 2022-06-25 00:56:14.270924
# Unit test for function get_file_lines
def test_get_file_lines():
    str_0 = 'a8-4E1|M@VLI w9.ik'
    var_0 = get_file_lines(str_0)
    assert var_0 == ['test']
    var_1 = get_file_lines(str_0, strip=False)
    assert var_1 == ['test\n']



# Generated at 2022-06-25 00:56:16.700058
# Unit test for function get_file_lines
def test_get_file_lines():
    str_0 = 'a8-4E1|M@VLI w9.ik'
    var_0 = get_file_lines(str_0)


if __name__ == '__main__':

    test_case_0()
    test_get_file_lines()

# Generated at 2022-06-25 00:56:23.864569
# Unit test for function get_file_lines
def test_get_file_lines():
    str_0 = 'MP;A.nL-8\'/b Q"M5'
    bool_0 = os.path.exists(str_0)
    if bool_0:
        bool_1 = os.access(str_0, os.R_OK)
    else:
        bool_1 = bool_0

    if bool_1:
        var_0 = get_file_lines("")
        var_1 = get_file_lines("")
        var_2 = get_file_lines("")
        var_3 = get_file_lines("")
        var_4 = get_file_lines("")
        var_5 = get_file_lines("")
        var_6 = get_file_lines("")
        var_7 = get_file_lines("")
        var_8 = get_file

# Generated at 2022-06-25 00:56:24.955878
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('', default='') == ''



# Generated at 2022-06-25 00:56:30.282412
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'E9.ik'
    str_1 = 'oZu(M:|V7pG'
    var_0 = get_file_content(str_0, str_1)


# Generated at 2022-06-25 00:56:31.048245
# Unit test for function get_file_lines
def test_get_file_lines():
    test_case_0()

# Generated at 2022-06-25 00:56:32.473761
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('test_file.txt') == ['test1', 'test2']


# Generated at 2022-06-25 00:56:38.521014
# Unit test for function get_file_lines
def test_get_file_lines():
    assert get_file_lines('/dev/stdin') == []
    assert get_file_lines('/dev/stdin', strip=False) == ['']
    assert get_file_lines('/dev/stdin', line_sep='') == ['']
    assert get_file_lines('/dev/stdin', strip=False, line_sep='') == ['']
    assert get_file_lines('/dev/stdin', line_sep='|') == ['']
    assert get_file_lines('/dev/stdin', strip=False, line_sep='|') == ['']



# Generated at 2022-06-25 00:56:41.538954
# Unit test for function get_file_content
def test_get_file_content():
    # Test path
    file_path = os.path.join(os.path.dirname(os.path.realpath(__file__)),'..',
                   'test_data/test_file.txt')
    # Test case
    file_content = get_file_content(file_path)
    assert file_content == '"test_file.txt" file content'


# Generated at 2022-06-25 00:56:46.350884
# Unit test for function get_file_lines
def test_get_file_lines():
    str_0 = 'uWTZ}0W7:th=z'
    var_0 = get_file_lines(str_0)


# Generated at 2022-06-25 00:56:48.424874
# Unit test for function get_file_lines
def test_get_file_lines():
    str_0 = 'hvw-l?Z'
    var_0 = get_file_lines(str_0)



# Generated at 2022-06-25 00:56:49.495561
# Unit test for function get_file_lines
def test_get_file_lines():
    pass


# Generated at 2022-06-25 00:56:57.397677
# Unit test for function get_file_lines
def test_get_file_lines():
    ret = get_file_lines(
        '/proc/self/environ',
        strip=True,
        line_sep='\x00'
    )
    assert ret == []
    assert get_file_lines(
        '/proc/self/environ',
        strip=False,
        line_sep='\x00'
    ) == []

# Generated at 2022-06-25 00:57:02.956325
# Unit test for function get_file_content
def test_get_file_content():
    # w9.ik case 0
    str_0 = 'a8-4E1|M@VLI w9.ik'
    str_1 = 'test'
    str_2 = 'test'
    str_3 = 'test'
    str_4 = 'test'
    str_5 = 'test'
    str_6 = 'test'
    str_7 = 'test'
    str_8 = 'test'
    str_9 = 'test'
    str_10 = '!1'
    str_11 = '^LL'
    str_12 = '!'
    str_13 = '^L\0'
    str_14 = '^L\0'
    str_15 = '^L\0'
    str_16 = '^L\0'

# Generated at 2022-06-25 00:57:07.299206
# Unit test for function get_file_content
def test_get_file_content():
    test_file = 'tests/unit/module_utils/ansible_test_file'
    content = get_file_content(test_file)
    assert content == 'hello world'


# Generated at 2022-06-25 00:57:17.238238
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('run.sh', default=0, strip=False) == 34

    assert get_file_content('test.txt', default=0, strip=False) == 34

    assert get_file_content('test.yaml', default=0, strip=False) == 34

    assert get_file_content('credentials.yaml', default=0, strip=False) == 34

    assert get_file_content('credentials.yml', default=0, strip=False) == 34

    assert get_file_content('var/log', default=0, strip=False) == 34

    assert get_file_content('var/log/test.txt', default=0, strip=False) == 34

    assert get_file_content('var/log/test.yaml', default=0, strip=False) == 34

# Generated at 2022-06-25 00:57:25.659701
# Unit test for function get_file_content

# Generated at 2022-06-25 00:57:32.189788
# Unit test for function get_file_content
def test_get_file_content():
    # e1: Test non-existant file, get None, should succeed
    ret = get_file_content('1', default=None, strip=True)
    assert ret == None

    # e2: Test non-existant file, get default, should succeed
    ret = get_file_content('1', default='', strip=True)
    assert ret == ''

    # e3: Test non-readable file, should succeed
    with open('2', 'w') as f:
        f.write('not readable')

    ret = get_file_content('2', default=None, strip=True)
    assert ret == None

    os.chmod('2', 000)
    ret = get_file_content('2', default=None, strip=True)
    assert ret == None

    os.chmod('2', 644)
   

# Generated at 2022-06-25 00:57:37.232813
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'a8-4E1|M@VLI w9.ik'
    num_0 = 0
    long_0 = long(num_0)
    long_1 = long(2 ** 30)
    long_2 = long(142572563)
    long_3 = long(2 ** 30 + 1)
    num_1 = -1
    str_1 = 'a8-4E1|M@VLI w9.ik'
    str_2 = 'a8-4E1|M@VLI w9.ik'
    num_2 = 1
    str_3 = 'a8-4E1|M@VLI w9.ik'
    num_3 = -1
    str_4 = 'a8-4E1|M@VLI w9.ik'
    str_

# Generated at 2022-06-25 00:57:38.684117
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('foo', 'bar') == 'bar'


# Generated at 2022-06-25 00:57:40.032950
# Unit test for function get_file_content
def test_get_file_content():
    print('Testing get_file_content')
    var_0 = get_file_content('/etc/hosts')
    print('Testcase 0: Passed!')


# Generated at 2022-06-25 00:57:42.276879
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'a8-4E1|M@VLI w9.ik'
    var_0 = get_file_content(str_0)


# Generated at 2022-06-25 00:57:49.614192
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'a8-4E1|M@VLI w9.ik'
    var_0 = get_file_content(str_0)

    str_1 = 'Wl3q2vjGn*JB'
    var_1 = get_file_content(str_1, 'aL/jK5pr=vS')

    str_2 = 'ha4_lKc%4+J'
    var_2 = get_file_content(str_2, line_sep=':')

    str_3 = '|i=O9`d>0bq'
    var_3 = get_file_content(str_3, line_sep='\n')


# Generated at 2022-06-25 00:57:56.062721
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('test/tempfile.txt') == 'something'
    assert get_file_content('test/tempfile.txt', strip=False) == 'something\n'
    assert get_file_content('test/tempfile.txt', default='not found') == 'something'
    assert get_file_content('test/notexist.txt', default='not found') == 'not found'


# Generated at 2022-06-25 00:58:07.388987
# Unit test for function get_file_content
def test_get_file_content():

    # Case 1:
    # If path exists, file is readable and is not empty
    test_file = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'file_0')
    expected_result = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi non dui vitae elit malesuada tincidunt. Suspendisse potenti. Sed pharetra suscipit nisi, non congue erat lobortis non.\n'
    assert get_file_content(test_file) == expected_result

    # Case 2:
    # If path exists, file is readable and is not empty but strip argument is True

# Generated at 2022-06-25 00:58:09.828634
# Unit test for function get_file_content
def test_get_file_content():
    assert callable(get_file_content)



# Generated at 2022-06-25 00:58:17.446021
# Unit test for function get_file_content
def test_get_file_content():
    var_0 = b'0\x12\x06\x11\x14\x1C\n\x1C\x03\x16\x0B\x0C\x12\x17\x11N\x14\x12\x1B\x19'
    var_1 = get_file_content('/etc/mtab',False,False)
    var_0 = (var_1==var_0)
    var_0 = (var_0,var_1)
    return var_0


# Generated at 2022-06-25 00:58:18.714578
# Unit test for function get_file_content
def test_get_file_content():
    print('* Testing function get_file_content')
    test_case_0()



# Generated at 2022-06-25 00:58:20.264850
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', strip=True)


# Generated at 2022-06-25 00:58:27.980542
# Unit test for function get_file_content
def test_get_file_content():
    path = '/home/vagrant/packages/ansible/ansible/test/integration/targets/notify/default/group_vars/all/file_content'
    default = 'test not file content'
    strip = True
    ret = get_file_content(path, default, strip)

    assert ret == 'test file content'


# Generated at 2022-06-25 00:58:30.202568
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/var/tmp/var_tmp_test') == 'test_data'



# Generated at 2022-06-25 00:58:39.415213
# Unit test for function get_file_content
def test_get_file_content():
    try:
        assert str(get_file_content("/usr/local/bin/file", strip=False, default="hello")) == "hello"
    except AssertionError as e:
        print("Test 0 Failed: %s" % e)
    try:
        assert str(get_file_content("/usr/local/bin/file", strip=True, default="hello")) == "hello"
    except AssertionError as e:
        print("Test 1 Failed: %s" % e)
    try:
        assert str(get_file_content("/usr/local/bin/file", strip=False, default=False)) == "False"
    except AssertionError as e:
        print("Test 2 Failed: %s" % e)

# Generated at 2022-06-25 00:58:44.361461
# Unit test for function get_file_content
def test_get_file_content():
    path = 'b'
    default = 'a'
    strip = True
    assert get_file_content(path, default, strip) == [('a', 'a')]



# Generated at 2022-06-25 00:58:45.771452
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(path="path", default=None, strip=True) is None



# Generated at 2022-06-25 00:58:54.435329
# Unit test for function get_file_content
def test_get_file_content():
    assert 'a8-4E1|M@VLI w9.ik\n' == get_file_content('/etc/rc.conf')


# Generated at 2022-06-25 00:58:57.040643
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'jJf_W8l$#I '
    var_0 = get_file_content(str_0)
    assert var_0 == get_file_content(str_0), 'Failed to assert get_file_content'

# Generated at 2022-06-25 00:59:03.026943
# Unit test for function get_file_content
def test_get_file_content():
    test_case_0()
    test_case_1()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 00:59:05.228838
# Unit test for function get_file_content
def test_get_file_content():

    try:
        assert 'a' == get_file_content('/etc/ansible/hosts', default='a')
    except AssertionError:
        print('test assertion error')


# Generated at 2022-06-25 00:59:11.098723
# Unit test for function get_file_content
def test_get_file_content():
    data = '''this is a test'''
    open('/tmp/test_data', 'w').write(data)
    x = get_file_content('/tmp/test_data')
    assert x == data
    os.unlink('/tmp/test_data')


# Generated at 2022-06-25 00:59:12.579791
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') == 'get_file_content is not implemented'


# Generated at 2022-06-25 00:59:14.503741
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('some_file_path') == None


# Generated at 2022-06-25 00:59:20.318317
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/tmp/testme', 'default') is None
    assert get_file_content('/tmp/testme') == ''
    assert get_file_content('/tmp/testme', 'default', strip=False) == ''
    assert get_file_content('/tmp/testme', default='default') == 'default'
    assert get_file_content('/tmp/testme', default='default', strip=False) == 'default'
    assert get_file_content('/tmp/testme', default='default', strip=True) == 'default'


# Generated at 2022-06-25 00:59:30.273212
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'mGKV2m8|e'
    test_0 = get_file_content(str_0)
    assert test_0 == None, "'%s' does not match '%s'" % (test_0, None)
    str_1 = 'yKcUO'
    test_1 = get_file_content(str_1)
    assert test_1 == None, "'%s' does not match '%s'" % (test_1, None)
    str_2 = '1f!-1lO'
    test_2 = get_file_content(str_2)
    assert test_2 == None, "'%s' does not match '%s'" % (test_2, None)


# Generated at 2022-06-25 00:59:33.633512
# Unit test for function get_file_content
def test_get_file_content():
    res = get_file_content('test_get_file_content_file.txt', default='test_value')
    assert res == 'test_value'



# Generated at 2022-06-25 00:59:46.997420
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('aO_ZNwnfM,av.') == None
    assert get_file_content('i/,wA,2G', default='Kis|i,^') == 'Kis|i,^'
    assert get_file_content('g^1,WN') == 'i|<4Fq\nEiW`9\nk'
    assert get_file_content('W0*8Rm7') == 'G,Ks92s\n'


# Generated at 2022-06-25 00:59:56.352271
# Unit test for function get_file_content
def test_get_file_content():
    path_0 = 'A>GqL-Ds$xGG_G'
    result_0 = get_file_content(path_0)
    assert result_0 == 'l6xIz~d?K'
    path_1 = '6I;$6#NU6@Z'
    result_1 = get_file_content(path_1, line_sep='#')
    assert result_1 == '-b5m5|x*@E4'
    path_2 = 'gwW-D8SvFVu'
    result_2 = get_file_content(path_2, line_sep='#')
    assert result_2 == 'b1Y{Zs2bWO`'
    path_3 = 'KjNqh]E<%'
    result_3

# Generated at 2022-06-25 01:00:06.890948
# Unit test for function get_file_content
def test_get_file_content():
    # Test for contents that are found in the file
    str_0 = 'a8-4E1|M@VLI w9.ik'
    var_0 = get_file_content(str_0)
    assert var_0 == 'a8-4E1|M@VLI w9.ik'

    # Test for contents that are not found in the file
    str_0 = 'a8-4E1|M@VLI w9.ik'
    var_0 = get_file_content(str_0, 'F3qz')
    assert var_0 == 'F3qz'

    # Test for contents with stripped whitespace
    str_0 = 'a8-4E1|M@VLI w9.ik'

# Generated at 2022-06-25 01:00:10.201947
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'a8-4E1|M@VLI w9.ik'
    var_0 = get_file_content(str_0)
    assert True


# Generated at 2022-06-25 01:00:19.564749
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(str_0, default='dm_keys.post') == 'dm_keys.post'
    assert get_file_content(get_file_content('a8-4E1|M@VLI', default=str_0), strip=False) == 'a8-4E1|M@VLI'
    assert get_file_content(str_0, default='dm_keys.post') == 'dm_keys.post'
    assert get_file_content(var_0, default=True) == True
    assert get_file_content(get_file_content(get_file_lines('a8-4E1|M@VLI', default=str_0), default=var_0, line_sep='ik'), default=var_0) == var_0

# Generated at 2022-06-25 01:00:22.586285
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(path='/etc/ssh/moduli') == '# $OpenBSD: moduli,v 1.9 2016/10/16 18:13:43 markus Exp $'
    assert get_file_content(path='/nothing_here', default='no') == 'no'
    assert get_file_content(path='/no/thing/here', default='no') == 'no'


# Generated at 2022-06-25 01:00:33.093666
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('fake_file') == None

# Generated at 2022-06-25 01:00:40.014661
# Unit test for function get_file_content
def test_get_file_content():
    # Test variables
    str_0 = '/tmp/foo'
    str_1 = '/tmp/foo2'
    str_2 = '/tmp/foo3'
    str_3 = '/tmp/foo4'
    # Call function
    var_0 = get_file_content(str_0, '/tmp/foo5')
    var_1 = get_file_content(str_1, '/tmp/foo5', False)
    var_2 = get_file_content(str_2, default='/tmp/foo5')
    var_3 = get_file_content(str_3, default='/tmp/foo5', strip=False)
    # Test results
    assert var_0 == '/tmp/foo5'
    assert var_1 == '/tmp/foo5'
    assert var_2 == '/tmp/foo5'


# Generated at 2022-06-25 01:00:43.250421
# Unit test for function get_file_content
def test_get_file_content():
    """
    Test function get_file_content with int as argument
    """
    assert get_file_content(2, 'null') == 'null'


# Generated at 2022-06-25 01:00:53.491365
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('tests/unit/modules/utils/shell/test.sh') == '1\n2\n3\n4'
    assert get_file_content('tests/unit/modules/utils/shell/test.sh', strip=False) == '1\n2\n3\n4\n'
    assert get_file_content('tests/unit/modules/utils/shell/test.sh', strip=False, line_sep='\n') == '1\n2\n3\n4\n'
    assert get_file_content('tests/unit/modules/utils/shell/test.sh', strip=False, line_sep='\r') == '1\r2\r3\r4\r'

# Generated at 2022-06-25 01:01:13.073861
# Unit test for function get_file_content
def test_get_file_content():
    try:
        with open('/tmp/test_get_file_content', 'w') as f:
            f.write('this is a test')
        assert get_file_content('/tmp/test_get_file_content') == 'this is a test'
    finally:
        try:
            os.remove('/tmp/test_get_file_content')
        except OSError:
            pass


# Generated at 2022-06-25 01:01:17.404049
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(str_0) == None

if __name__ == "__main__":
    test_get_file_content()
    test_case_0()

# Generated at 2022-06-25 01:01:25.795411
# Unit test for function get_file_content
def test_get_file_content():
    # Test 1: Simple test with an existing file that should return the contents of the file
    str_0 = 'a8-4E1|M@VLI w9.ik'
    var_0 = get_file_content(str_0)
    assert var_0 == 'a8-4E1|M@VLI w9.ik'

    # Test 2: Simple test with a non existing file that should return the default value
    str_0 = 'a8-4E1|M@VLI w9.ik'
    var_0 = get_file_content(str_0, default=None)
    assert var_0 == None


# Generated at 2022-06-25 01:01:27.192720
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'a8-4E1|M@VLI w9.ik'
    var_0 = get_file_content(str_0)



# Generated at 2022-06-25 01:01:32.471034
# Unit test for function get_file_content
def test_get_file_content():
    test_file = 'test_file.txt'
    test_file_content = 'Test file content'
    with open(test_file, 'w') as f:
        f.write(test_file_content)
    assert get_file_content(test_file) == test_file_content
    assert get_file_content(test_file, default='default') == test_file_content
    assert get_file_content(test_file, default='default', strip=False) == test_file_content
    assert get_file_content('does_not_exist', default='default') == 'default'
    assert get_file_content('does_not_exist', default='default', strip=False) == 'default'



# Generated at 2022-06-25 01:01:41.895747
# Unit test for function get_file_content
def test_get_file_content():
    # test case 0
    str_0 = 'a8-4E1|M@VLI w9.ik'
    var_0 = get_file_content(str_0)
    assert var_0 == ""

    # test case 1
    str_1 = 'V7EHP0QJ-o9?{5%5}'
    var_1 = get_file_content(str_1)
    assert var_1 == ""

    # test case 2
    str_2 = 'wFV`}983qF1CL~FM'
    var_2 = get_file_content(str_2)
    assert var_2 == ""

    # test case 3
    str_3 = 'V7EHP0QJ-o9?{5%5}'

# Generated at 2022-06-25 01:01:47.247262
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('a8-4E1|M@VLI w9.ik') == None
    assert get_file_content('2nB/I1j>RC.FJ') == None


# Generated at 2022-06-25 01:01:51.002077
# Unit test for function get_file_content
def test_get_file_content():
    expected_result = '12345'
    result = get_file_content('inputfile', strip=False)
    assert result == expected_result


# Generated at 2022-06-25 01:01:54.666561
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/some/file/that/ill/never/exists', default='blah') == 'blah'


# Generated at 2022-06-25 01:01:55.823177
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(str_0, 'foo') == 'foo'


# Generated at 2022-06-25 01:02:29.923730
# Unit test for function get_file_content
def test_get_file_content():

    assert get_file_content("", default=True) == True

# Generated at 2022-06-25 01:02:33.570284
# Unit test for function get_file_content
def test_get_file_content():
    var_1 = get_file_content('/etc/passwd')
    assert var_1 is not None, 'Failed to get file content'


# Generated at 2022-06-25 01:02:34.856952
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd', default='') == ''
    assert get_file_content('/etc/shadow', default='') == ''

# Generated at 2022-06-25 01:02:43.143300
# Unit test for function get_file_content
def test_get_file_content():
    # Sample test data
    # Case 1: Normal case
    input_1 = '/a.txt'
    var_1 = get_file_content(input_1)
    assert var_1 is not None
    assert type(var_1) is str

    # Case 2: input does not exist
    input_2 = '/a.txt'
    var_2 = get_file_content(input_2)
    assert var_2 is None

    # Case 3: input is a dir
    input_3 = '/'
    var_3 = get_file_content(input_3, '', False)
    assert var_3 is None

    # Case 4: input is a dir
    input_4 = '/etc'
    var_4 = get_file_content(input_4, '', False)
    assert var_4 is None


# Generated at 2022-06-25 01:02:49.511553
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'a8-4E1|M@VLI w9.ik'

# Generated at 2022-06-25 01:02:59.480601
# Unit test for function get_file_content
def test_get_file_content():
    str_1 = 'E0kup^_lb[|ex,a&6'
    str_2 = get_file_content(str_1)
    assert str_2 == None
    str_3 = '>eXA4|p@#5#xwt!o'
    int_1 = -1
    str_4 = get_file_content(str_3, int_1)
    assert str_4 == -1
    str_5 = 'jG7&uT9f;}0(TQ0s'
    bool_1 = False
    str_6 = get_file_content(str_5, bool_1)
    assert str_6 == False
    str_7 = 'r|^C*P7(a@9XuT`V'

# Generated at 2022-06-25 01:03:01.707714
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('TEST_FILE_RESULT_FAIL', 'test_value') == 'test_value'
    assert get_file_content('TEST_FILE_RESULT_PASS', default='test_value') == 'PASS'


# Generated at 2022-06-25 01:03:10.998487
# Unit test for function get_file_content
def test_get_file_content():

    # Test case 0
    str_0 = 'a8-4E1|M@VLI w9.ik'
    var_0 = get_file_content(str_0)

    # Test case 1
    str_0 = 'H:uL71n%46&wK'
    var_0 = get_file_content(str_0)

    # Test case 2
    str_0 = '6W%U6xj/QPX9v'
    var_0 = get_file_content(str_0)

    # Test case 3
    str_0 = '4&4f$Q^ZjG"e<'
    var_0 = get_file_content(str_0)

    # Test case 4
    str_0 = '0c<h_^wLKjv)q3'

# Generated at 2022-06-25 01:03:17.991621
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/hosts') == '''#   <ip-address>   <hostname.domain.org>   <hostname>
127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6'''
    assert get_file_content("/etc/hosts", default="", strip=True) == '''#   <ip-address>   <hostname.domain.org>   <hostname>
127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6'''


# Generated at 2022-06-25 01:03:28.162196
# Unit test for function get_file_content
def test_get_file_content():
    # Test that the result of get_file_content() is correct when `strip` is set to `True`
    assert os.getcwd() == get_file_content(__file__, strip=True)

    # Test that the result of get_file_content() is correct when `strip` is set to `False`
    assert os.getcwd() + '\n' == get_file_content(__file__, strip=False)

    # Test that the result of get_file_content() is correct when the file does not exist
    assert get_file_content('nonexistent_file', default='test') == 'test'

    # Test that the result of get_file_content() is correct when the file is empty
    open('empty_file', 'w').close()

# Generated at 2022-06-25 01:04:04.009995
# Unit test for function get_file_content
def test_get_file_content():
    module = AnsibleModule(argument_spec=dict())
    assert os.path.exists('/tmp/get_file_content_test')
    assert os.access('/tmp/get_file_content_test', os.R_OK)
    assert not os.path.exists('/tmp/get_file_content_test_fail')
    result = get_file_content('/tmp/get_file_content_test')
    assert result == '123'

    result = get_file_content('/tmp/get_file_content_test_fail')
    assert result is None

    result = get_file_content('/tmp/get_file_content_test', default='foo')
    assert result == '123'


# Generated at 2022-06-25 01:04:09.705914
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'a8-4E1|M@VLI w9.ik'
    str_1 = 'EzB!C;@i4'
    str_2 = '69P?_L'
    str_3 = 'w2%Y;@#ecC4x4EvD/@'
    str_4 = '`G&S~'
    str_5 = 'g;&fQ=JM'
    str_6 = '%^i'
    str_7 = '$mzw'
    str_8 = 'C7b'
    str_9 = 'f:z2!V7sP'
    str_10 = '<'
    str_11 = 'Z2-C|]_M:%1'

# Generated at 2022-06-25 01:04:14.243188
# Unit test for function get_file_content
def test_get_file_content():

    str_0 = ']P<oI{'
    result_0 = get_file_content(str_0)
    assert type(result_0) == str


# Generated at 2022-06-25 01:04:15.311933
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content('/etc/passwd') is not None


# Generated at 2022-06-25 01:04:18.156433
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content("junk.test") == None

if __name__ == "__main__":
    test_case_0()
    test_get_file_content()

# Generated at 2022-06-25 01:04:22.302955
# Unit test for function get_file_content
def test_get_file_content():
    assert True
    assert get_file_content('INVALID_FILE_PATH', default='default', strip=True) == 'default'
    assert get_file_content('INVALID_FILE_PATH', default='default', strip=False) == 'default'
    assert get_file_content('INVALID_FILE_PATH', default='default', strip=False) == 'default'


# Generated at 2022-06-25 01:04:24.958902
# Unit test for function get_file_content
def test_get_file_content():
    assert not get_file_content('')
    assert not get_file_content('', default='', strip=False)
    assert get_file_content('', default='test', strip=False) == 'test'
    assert get_file_content('/tmp') is None
    assert get_file_content('/tmp', default='test') == 'test'



# Generated at 2022-06-25 01:04:26.148443
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = '/tmp'
    var_0 = get_file_content(str_0)
    print(var_0)



# Generated at 2022-06-25 01:04:27.467742
# Unit test for function get_file_content
def test_get_file_content():
    assert get_file_content(var_0) == var_0
    assert get_file_content(str_0) == str_0

# Generated at 2022-06-25 01:04:30.456139
# Unit test for function get_file_content
def test_get_file_content():
    str_0 = 'G#&>tEw`z`i0c0Fy'
    str_1 = 'R[O%c55YY<x4%?l]'
    var_0 = get_file_content(str_0, default=str_1)
