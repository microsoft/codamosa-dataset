

# Generated at 2022-06-24 11:21:22.767489
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken(["how","are","you"], 1, 5, 'I am fine, how are you')
    assert token is not None
    

# Generated at 2022-06-24 11:21:32.554266
# Unit test for method lookup of class Token
def test_Token_lookup():

    class TokenTest(Token):
        def __init__(self, test) -> "TokenTest":
            self.test = test
        def _get_value(self) -> typing.Any:
            return self.test
    class TokenTest2(TokenTest):
        def _get_child_token(self, key: typing.Any) -> TokenTest:
            return self.test[key]

    test1 = TokenTest(1)
    test2 = TokenTest(test1)
    test3 = TokenTest2([test2, test1])

    assert test1.value == 1
    assert test1.start_index == 0
    assert test2.value == test1
    assert test2.start_index == 1
    assert test3.value == [test2, test1]
    assert test3.start_index == 2

    assert test

# Generated at 2022-06-24 11:21:39.180648
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    this_token = Token
    # Create a dummy argument to test the following code:
    #   token = token.lookup(index[:-1])
    #   return token._get_key_token(index[-1])
    index = ['foo']
    actual_token = this_token._get_key_token('foo')
    assert actual_token is None, "Failed to lookup key"
    


# Generated at 2022-06-24 11:21:42.667638
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Tests that repr correctly returns the __class__.__name__ and the string
    # value of the token object
    token = Token('',0,0, 'a')
    expected = f"Token('a')"
    assert repr(token) == expected

# Generated at 2022-06-24 11:21:45.231818
# Unit test for constructor of class ListToken
def test_ListToken():
    b = ListToken(value = [], start_index = 1, end_index = 2)
    assert b.value == []
    
test_ListToken()


# Generated at 2022-06-24 11:21:49.229180
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    s = ScalarToken(value = 1, start_index = 0, end_index = 0, content = "a")
    # test the unique attribute of class ScalarToke
    assert s._value == 1
    assert s._start_index == 0
    assert s._end_index == 0
    assert s._content == "a"


# Generated at 2022-06-24 11:21:53.795206
# Unit test for constructor of class DictToken
def test_DictToken():
    test_token = DictToken({"a": 1}, 1, 12, "hello")
    assert test_token.value == test_token._get_value()
    assert test_token.end_index == test_token._end_index
    assert test_token.start_index == test_token._start_index
    assert test_token.content == test_token._content


# Generated at 2022-06-24 11:21:58.680243
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    value = object()
    start_index = object()
    end_index = object()
    content = object()
    t = ScalarToken(value, start_index, end_index, content)
    assert hash(t) == hash(value)


# Generated at 2022-06-24 11:22:01.570130
# Unit test for constructor of class DictToken
def test_DictToken():
    dic = DictToken([], 0, 0)
    assert (dic is not None)


# Generated at 2022-06-24 11:22:11.693977
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class TestListToken(Token):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)
            self._child_keys = {1:"test"}
        def _get_value(self) -> typing.Any:
            return 'test'
        def _get_child_token(self, key: typing.Any) -> Token:
            return self._child_keys[key]

    class TestDictToken(Token):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)

# Generated at 2022-06-24 11:22:19.034786
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    a = '{"a": 10, "b": 20}'
    b = '["a", "b"]'
    c = '"a"'

    a_token = DictToken({"a": 10, "b": 20}, 14, 14, content=a)
    b_token = ListToken(["a", "b"], 14, 14, content=b)
    c_token = ScalarToken("a", 14, 14, content=c)

    assert a_token.end == Position(1, 16, 15)
    assert b_token.end == Position(1, 6, 5)
    assert c_token.end == Position(1, 3, 2)

    assert a_token.lookup_key([0, 0]) == c_token
    assert b_token.lookup_key([0]) == c_token

# Generated at 2022-06-24 11:22:24.492077
# Unit test for method lookup of class Token
def test_Token_lookup():
    '''
    Test to see if the method lookup of class Token can return the right token.
    '''
    # test case 1
    dct = {'a': 1, 'b': 2}
    dic = {
        ScalarToken(1, 0, 0): ScalarToken(1, 0, 0),
        ScalarToken(2, 1, 1): ScalarToken(2, 1, 1),
        ScalarToken('a', 2, 2): ScalarToken('a', 2, 2),
        ScalarToken('b', 3, 3): ScalarToken('b', 3, 3)
    }
    token = DictToken(dct, 0, 3, 'ab')
    assert token.lookup([1]).string == 'b'
    assert token.lookup([2]).string == 'a'
    assert token.lookup

# Generated at 2022-06-24 11:22:31.676888
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(value=2, start_index=3, end_index=4, content="a")
    assert token.string == "a"
    assert token.value == 2


# Generated at 2022-06-24 11:22:34.489610
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken(value = [1,2,3], start_index = 0, end_index = 2, content = [1,2,3]).value == [1,2,3]

# Generated at 2022-06-24 11:22:35.729513
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({Token: Token}, 0, 1)

# Generated at 2022-06-24 11:22:42.750302
# Unit test for method lookup of class Token
def test_Token_lookup():
    from collections import OrderedDict
    d = OrderedDict([("note", "4"), ("rest", "")])
    token1 = DictToken(d, 0, 25)
    assert(token1.lookup([0, 0]).string == 'note: "4"')
    assert(token1.lookup([0, 0]).start.line == 1)
    assert(token1.lookup([0, 0]).start.column == 1)
    assert(token1.lookup([1, 0]).string == 'rest: ""')
    assert(token1.lookup([1, 0]).start.line == 2)
    assert(token1.lookup([1, 0]).start.column == 1)
    assert(token1.lookup([1, 0]).end.line == 2)

# Generated at 2022-06-24 11:22:44.281540
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(1, 0, 0)
    assert hash(token) == hash(1)


# Generated at 2022-06-24 11:22:49.108863
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    test_ScalarToken = ScalarToken(1, 2, 3)
    assert (test_ScalarToken._value == 1)
    assert (test_ScalarToken._start_index == 2)
    assert (test_ScalarToken._end_index == 3)


# Generated at 2022-06-24 11:22:59.227847
# Unit test for constructor of class DictToken
def test_DictToken():
    key_token_1 = ScalarToken(1, 1, 2)
    value_token_1 = ScalarToken('a', 3, 3)
    key_token_2 = ScalarToken(2, 4, 5)
    value_token_2 = ScalarToken('b', 6, 6)
    test_tokens_dict = {key_token_1: value_token_1, key_token_2: value_token_2}
    test_token = DictToken(test_tokens_dict, 1, 6)
    expected_str_repr = 'DictToken({ScalarToken(1): ScalarToken(a), ScalarToken(2): ScalarToken(b)})'
    assert test_token.__repr__() == expected_str_repr

# Generated at 2022-06-24 11:23:03.038343
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    schema = {
        "a": {"b": [{"c": 123}]}
    }
    token = _tokenize(schema)
    assert token.lookup_key([0, "a", 0, "b", 0, "c"]).string == "123"

# Generated at 2022-06-24 11:23:14.386794
# Unit test for constructor of class ListToken
def test_ListToken():
    listToken = ListToken([1, 2, 3], 0, 3, "123")
    assert listToken.string == "123"
    assert listToken.value == [1, 2, 3]
    assert listToken.start == Position(1, 1, 0)
    assert listToken.end == Position(1, 4, 3)
    assert listToken.lookup([0]) == 1
    assert listToken.lookup([1]) == 2
    assert listToken.lookup_key([0]) == 1
    assert listToken.lookup_key([1]) == 2
    assert listToken._get_position(0) == Position(1, 1, 0)
    assert listToken._get_position(1) == Position(1, 2, 1)
    assert listToken._get_position(2) == Position(1, 3, 2)
   

# Generated at 2022-06-24 11:23:18.525611
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken.__init__.__defaults__ == (None, ) # pragma: nocover


# Generated at 2022-06-24 11:23:22.350174
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    """Test method __repr__ of class Token"""
    token = Token('abc',1,2)
    assert token.__repr__() == "Token('abc')"


# Generated at 2022-06-24 11:23:27.273354
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem import String, Rational, Float

    a = String.load_token("a")
    b = String.load_token("a")
    assert a == b

    a = Rational.load_token("5")
    b = Rational.load_token("5")
    assert a == b

    a = Float.load_token("5.0")
    b = Float.load_token("5.0")
    assert a == b



# Generated at 2022-06-24 11:23:30.307338
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token(value='a', start_index=0, end_index=0, content='a')
    assert token.lookup([]) == token


# Generated at 2022-06-24 11:23:34.521483
# Unit test for constructor of class Token
def test_Token():
    t = Token(1, 2, 3, 4)
    assert t._value == 1
    assert t._start_index == 2
    assert t._end_index == 3
    assert t._content == 4

# Generated at 2022-06-24 11:23:41.916095
# Unit test for method lookup of class Token
def test_Token_lookup():
    d= {
        "level-1-1": {"level-2-1": "level-2-1"},
        "level-1-2": {"level-2-1": "level-2-1"},
    }
    token = DictToken(d, 0, 0, content="asasd")
    assert isinstance(token.lookup([0, 0]), ScalarToken)
    assert token.lookup_key([0, 0]) is None
    assert isinstance(token.lookup_key([0]), ScalarToken)
    assert isinstance(token.lookup([0, "level-2-1"]), ScalarToken)


# Generated at 2022-06-24 11:23:44.873448
# Unit test for method lookup of class Token
def test_Token_lookup():
    value = [1, 2, 3]
    content = ''
    token = ListToken(value, 0, 0, content)
    index = [0]
    assert token.lookup(index).string == '1'

# Generated at 2022-06-24 11:23:57.011452
# Unit test for constructor of class Token
def test_Token():
    token = Token(value = 1, start_index = 1, end_index = 2, content = "")
    assert token._value == 1
    assert token._start_index == 1
    assert token._end_index == 2
    assert token._content == ""
    assert token.string == ""
    assert token.value == 1
    assert token.start == Position(1, 1, 1)
    assert token.end == Position(1, 2, 2)
    assert token.lookup([]) == Token(value = 1, start_index = 1, end_index = 2, content = "")
    assert token.lookup_key([]) == Token(value = 1, start_index = 1, end_index = 2, content = "")
    assert repr(token) == "Token('')"

# Generated at 2022-06-24 11:24:02.413672
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    tok1 = Token(1, 2, 3, 'abc')
    tok2 = Token(1, 2, 3, 'abc')
    assert (tok1 == tok2)
    tok3 = Token(1, 2, 3, 'abcd')
    assert (not tok1 == tok3)
    tok4 = Token(10, 2, 3, 'abc')
    assert (not tok1 == tok4)
    tok5 = Token(1, 10, 3, 'abc')
    assert (not tok1 == tok5)
    tok6 = Token(1, 2, 10, 'abc')
    assert (not tok1 == tok6)


# Generated at 2022-06-24 11:24:04.763618
# Unit test for constructor of class ListToken
def test_ListToken():
    c = ListToken([1,2,3],0,2)
    assert isinstance(c,ListToken)



# Generated at 2022-06-24 11:24:08.327780
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token_1 = ScalarToken({}, 0, 0, "dummy")
    assert token_1
    assert token_1._end_index == 0
    assert token_1._start_index == 0
    assert token_1._value == {}
    assert token_1._content == "dummy"


# Generated at 2022-06-24 11:24:16.196108
# Unit test for constructor of class DictToken
def test_DictToken():
    content = "My string"
    start_index = 2
    end_index = 9
    args = (content, start_index, end_index)
    kwargs = {'content': content}
    d = DictToken(args, kwargs)
    assert d.value == args
    assert d.start == (1, 3, 2)
    assert d.end == (1, 10, 9)
    assert d.string == (content[start_index: end_index + 1])
    assert d.lookup([0]) == 'y'

# Generated at 2022-06-24 11:24:20.461527
# Unit test for constructor of class ListToken
def test_ListToken():
    from parse_lark_result import parse
    parsed_term = parse('  [  ] ')
    print(parsed_term)
    token_obj = ListToken(value=parsed_term)
    print(token_obj)
    assert token_obj.string == '[]'
    print('test_ListToken')



# Generated at 2022-06-24 11:24:30.641388
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem import types
    from typing import Any
    from typesystem.position import Position
    from typesystem.token import DictToken
    d = types.Dictionary({}, required=False, allow_null=True, allow_reuse=False, required_by_default=False,
                         name='', description='', error_messages={})
    value = {position: position for position in {Position(1, 2, 3),Position(2, 3, 4)}}
    dt = DictToken(value, 0, 0)
    assert dt._get_value() == {position._get_value():position._get_value() for position in {Position(1, 2, 3),Position(2, 3, 4)}}
    assert dt._get_child_token(Position(1, 2, 3)) == Position(1, 2, 3)

# Generated at 2022-06-24 11:24:37.360919
# Unit test for method lookup of class Token
def test_Token_lookup():
    module_token = ListToken([])
    function_token = ListToken([])
    module_token._value.append(function_token)

    assert module_token.lookup([0]) == function_token
    assert module_token.lookup_key([0]) is None

test_Token_lookup()

# Generated at 2022-06-24 11:24:41.482606
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    m1 = ScalarToken(value=1,start_index=0,end_index=0)
    assert m1._value == 1
    assert m1._start_index == 0
    assert m1._end_index == 0


# Generated at 2022-06-24 11:24:44.485317
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    start_index = 1
    end_index = 2
    string = "ab"
    token_a = ScalarToken(string, start_index, end_index)
    token_b = ScalarToken(string, start_index, end_index)
    assert token_a == token_b

# Generated at 2022-06-24 11:24:47.375103
# Unit test for constructor of class Token
def test_Token():
    token = Token(0, 1, 2)
    assert token.start == Position(1, 2, 1)
    assert token.end == Position(1, 3, 2)
    assert token.string == "1"
    assert repr(token) == "Token(1)"



# Generated at 2022-06-24 11:24:50.467934
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # FIXME: this test does not pass!
    #assert Token(12, 12, 12, "12").__repr__() == 'Token(12)'
    pass

# Generated at 2022-06-24 11:24:58.987998
# Unit test for constructor of class ListToken
def test_ListToken():
    content = '''hi
12
True
'''
    l = ListToken([ScalarToken("hi", 0, 1, content), ScalarToken(12, 3, 4, content), ScalarToken(True, 6, 9, content)], 0, 9, content)
    assert(l.string == "hi\n12\nTrue")
    assert(l.value == ["hi", 12, True])
    assert(l.start == Position(1, 1, 0))
    assert(l.end == Position(3, 4, 10))
    assert(l.lookup([0]) == ScalarToken("hi", 0, 1, content))
    assert(l.lookup([1]) == ScalarToken(12, 3, 4, content))

# Generated at 2022-06-24 11:25:04.490919
# Unit test for constructor of class ListToken
def test_ListToken():
    key = ["a", "b", 3]
    token = ListToken(key, 10, 20)
    assert token == token
    assert token.string == "['a', 'b', 3]"
    assert token.value == key
    assert token.start == Position(1, 11, 10)
    assert token.end == Position(1, 20, 20)
    assert token.lookup([3]) == key[3]
    assert token.lookup_key([3]) == None # The list has no key.
    assert token.__repr__() == "ListToken(['a', 'b', 3])"
    


# Generated at 2022-06-24 11:25:06.801785
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    # ScalarToken(value: typing.Any, start_index: int, end_index: int, content: str = ""):
    assert ScalarToken(3, 0, 0, "3")._value == 3
    assert ScalarToken("3", 0, 0, "3")._value == "3"



# Generated at 2022-06-24 11:25:17.856742
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    from typesystem.tokenizer import Tokenizer
    from typesystem.utils import print_code
    from typesystem.utils import print_json_ast
    from typesystem.utils import print_python_ast

# Generated at 2022-06-24 11:25:19.878724
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken(1, 2, 3, 4)
    assert dt._start_index == 2
    assert dt._end_index == 3
    assert dt.string == "3"


# Generated at 2022-06-24 11:25:28.362326
# Unit test for constructor of class Token
def test_Token():
    with open('test.txt', 'r') as f:
        content = f.read()
        f.close()
    start_index = 0
    end_index = 29
    value = 1
    token = Token(value, start_index, end_index, content)
    assert (token._value == 1) and (token._start_index == 0) and (token._end_index == 29) and (token._content == '{"key1": "string1", "key2": "string2", "key3": 123456789}')


# Generated at 2022-06-24 11:25:32.938585
# Unit test for constructor of class ListToken
def test_ListToken():
    tokens = ListToken(value = [], start_index = 0, end_index = 0) 
    assert tokens._get_value() == [] 
    tokens = ListToken(value = [1], start_index = 0, end_index = 0) 
    assert tokens._get_value() == [] 


# Generated at 2022-06-24 11:25:42.161265
# Unit test for constructor of class ListToken
def test_ListToken():
    token1 = ScalarToken("string", 0, 5, "03456789a")
    token2 = ScalarToken("string", 0, 5, "03456789a")
    token3 = ScalarToken("string", 0, 5, "03456789a")
    listToken = ListToken([token1, token2, token3], 0, 5, "03456789a")
    assert hash(listToken) == hash("03456789a")
    assert isinstance(listToken, Token)
    assert listToken._get_value() == [token1._get_value(), token2._get_value(), token3._get_value()]
    assert listToken._get_child_token(0) == token1
    assert listToken._get_child_token(1) == token2
    assert listToken._get_child_

# Generated at 2022-06-24 11:25:49.605471
# Unit test for constructor of class DictToken
def test_DictToken():
    a = {1 : 2}
    b = {2 : 3}
    c = {"a" : a, "b" : b}
    d = {3 : b}

    x = int(DictToken(c, start_index=1, end_index=5, content="abcde").value["a"][1])
    y = int(DictToken(d, start_index=2, end_index=6, content="bcdef").value[3][2])

    assert x == 2
    assert y == 3



# Generated at 2022-06-24 11:25:59.990421
# Unit test for constructor of class DictToken
def test_DictToken():
    # create two tokens with different length of str
    t1 = ScalarToken(1, 1, 1, 't1')
    t2 = ScalarToken(2, 2, 2, 't2')
    t3 = ScalarToken(3, 3, 3, 't3')
    d = {t1: t2, t3: t3}
    t = DictToken(d, 0, 0, '')
    if d != t._get_value():
        test_DictToken.failed = True

    # create two tokens with same str length
    t1 = ScalarToken(1, 0, 1, '1')
    t2 = ScalarToken(2, 1, 2, '2')
    d = {t1: t2}
    t = DictToken(d, 0, 0, '')

# Generated at 2022-06-24 11:26:04.604731
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    T = Token(None, 0, 0)
    assert T.__repr__() == 'Token(None)'
    T = Token('', 0, 0)
    assert T.__repr__() == "Token('')"
    T = Token('Hola', 1, 1)
    assert T.__repr__() == "Token('Hola')"


# Generated at 2022-06-24 11:26:12.562072
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    start_index = 0
    end_index = 2
    content = '{"a":1,"b":2,"c":{"d":"e"}}'
    tk = ScalarToken("a", start_index, end_index, content)
    assert tk.string ==  '"a"'
    assert tk.value == "a"
    assert tk.start == Position(1, 2, 1)
    assert tk.end == Position(1, 4, 3)
    assert tk.lookup("a")
    assert tk.lookup_key("a")


# Generated at 2022-06-24 11:26:18.605702
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    dict_test = {}
    dict_test["_value"] = {
        "k1": ScalarToken({"K1"}, 1, 2, "Test Content"),
        "k2": ScalarToken({"K2"}, 2, 3, "Test Content")
    }
    dict_test["_start_index"] = 1
    dict_test["_end_index"] = 2
    dict_test["_content"] = "Test Content"

    dict_test_obj = DictToken(dict_test["_value"], dict_test["_start_index"], dict_test["_end_index"], dict_test["_content"])

    assert dict_test_obj.lookup_key(["k1"])._value == {"K1"}

# Generated at 2022-06-24 11:26:24.281474
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from typesystem.base import Schema
    from typesystem.components import String

    class UserSchema(Schema):
        name = String()
        email = String()

    schema = UserSchema()
    token = schema.data.to_python({"name": "John", "email": "john@example.com"})
    # Lookup key token
    assert token.lookup_key([0]) == ScalarToken("name", 0, 3)
    assert token.lookup_key([1]) == ScalarToken("email", 18, 22)

# Generated at 2022-06-24 11:26:26.700816
# Unit test for constructor of class ListToken
def test_ListToken():
  new_ListToken = ListToken([], 0, 1)
  assert new_ListToken


# Generated at 2022-06-24 11:26:29.814490
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
  t = ScalarToken(1, 0, 1, "text")
  assert t._value == 1
  assert t._start_index == 0
  assert t._end_index == 1
  assert t._content == "text"


# Generated at 2022-06-24 11:26:36.663964
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    s_token = ScalarToken(1, 0, 10)
    assert s_token._value == 1
    assert s_token._start_index == 0
    assert s_token._end_index == 10
    assert s_token.string == ""


# Generated at 2022-06-24 11:26:37.777954
# Unit test for method lookup of class Token
def test_Token_lookup():
    assert Token.lookup("4") == 4


# Generated at 2022-06-24 11:26:38.523639
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    result = Token.lookup_key()
    assert result is None


# Generated at 2022-06-24 11:26:41.974384
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken({"a": 1}, 1, 2)

    assert t._get_value() == {"a": 1}
    #t._get_child_token(key=1)
    print("token:", t.lookup([1]))


# Generated at 2022-06-24 11:26:46.591415
# Unit test for constructor of class Token
def test_Token():
    token = Token(1, 2, 3, "abc")
    assert token.string == "abc"
    assert token.value == 1
    assert token.start.line == 1
    assert token.start.column == 1
    assert token.end.line == 1
    assert token.end.column == 3
    assert token._content == "abc"
    assert token._end_index == 3
    assert token._start_index == 2
    assert token._value == 1
    # Unit test for constructor of class ScalarToken
    def test_ScalarToken():
        scalarToken = ScalarToken(1, 2, 3, "abc")
        assert ScalarToken(1, 2, 3, "abc") == ScalarToken(1, 2, 3, "abc")

# Generated at 2022-06-24 11:26:49.922217
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(1, 0, 2, '12')
    actual = token.__hash__()
    expected = hash(1)
    assert actual == expected


# Generated at 2022-06-24 11:26:52.033142
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = ScalarToken(1, 0, 0)
    assert repr(token) == "ScalarToken('1')"

# Generated at 2022-06-24 11:27:00.201283
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # Cases under testing:
    # Case 1: given the index, it returns the key Token
    # Case 2: given an incorrect index, it raises ValueError
    
    # Case 1: given the index, it returns the key Token
    content = """{
        "test": ["Hello", "bonjour", {
            "test": 9
        }]
    }"""
    start = content.index('"test": ["Hello"')
    end = content.index('"test": ["Hello"') + len('"test": ["Hello"')

# Generated at 2022-06-24 11:27:03.804619
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    temp = Token(value=None,start_index=None,end_index=None,content=None)
    result = repr(temp)


# Generated at 2022-06-24 11:27:08.092375
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    st = ScalarToken(3,3,3)
    assert st.value == 3
    assert st.start == Position(1,1,3)
    assert st.end == Position(1,1,3)
    assert st.string == ""
    assert st.lookup([]) == st
    assert st.lookup_key([]) == st
    assert st == ScalarToken(3,3,3)


# Generated at 2022-06-24 11:27:16.504718
# Unit test for method lookup of class Token
def test_Token_lookup():
    '''
    Unit test for method lookup of class Token
    '''


# Generated at 2022-06-24 11:27:19.018148
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    string = "test_string"
    assert repr(Token(1, 2, 3, string)) == "Token('%s')" % string

# Generated at 2022-06-24 11:27:21.280153
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    test_Token = Token("1",0,1,"")
    assert test_Token.lookup_key("not_exists_index") == None

# Generated at 2022-06-24 11:27:27.669510
# Unit test for method lookup of class Token
def test_Token_lookup():
    example = '{ "name": {"first_name" : "first", "surname": "last"}, "age": 55 }'
    d_Token = json.loads(example, object_pairs_hook = lambda pairs: DictToken(pairs, example))
    assert d_Token.lookup([1]).string == '55'
    assert d_Token.lookup_key([1,2]).string == 'age'
    assert d_Token.lookup([0, 'name']).string == '{"first_name" : "first", "surname": "last"}'
    assert d_Token.lookup_key([0,'name',1]).string == 'surname'

# Generated at 2022-06-24 11:27:30.618558
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = Token(True, 0,0,0)
    result = token.lookup_key([0])
    # response.data["result"] = True
    # return response.data, 200

# Generated at 2022-06-24 11:27:32.212106
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(None, 0, 0, '') == Token(None, 0, 0, '')

# Generated at 2022-06-24 11:27:40.117059
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from typesystem.base.types import Array, String
    from typesystem.base.types import Object
    schema = Object(
        properties={"addresses": Array(items=Object(properties={"address": String()}))}
    )
    token_tree = schema.parse_token("{'addresses': [{'address': '1'}]}")
    token = token_tree.lookup(["addresses", 0, "address"])
    key = token_tree.lookup_key(["addresses", 0, "address"])
    assert key.string == "'address'"
    assert key._value == "address"

# Generated at 2022-06-24 11:27:50.394479
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 0, 0) == Token(1, 0, 0)
    assert Token(2, 1, 1) == Token(2, 1, 1)
    assert Token(2, 3, 1) == Token(2, 3, 1)
    assert Token('D', 0, 0) == Token('D', 0, 0)
    assert Token('N', 1, 1) == Token('N', 1, 1)
    assert Token('N', 3, 1) == Token('N', 3, 1)
    assert Token(True, 0, 0) == Token(True, 0, 0)
    assert Token(True, 1, 1) == Token(True, 1, 1)
    assert Token(True, 3, 1) == Token(True, 3, 1)
    assert Token(False, 0, 0) == Token(False, 0, 0)

# Generated at 2022-06-24 11:27:52.388784
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = Token(value = [0, 1, 2], start_index = 0, end_index = 1)
    assert token.lookup_key([1, 2]) == token

# Generated at 2022-06-24 11:27:54.248144
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({'a':1, 'b': 2}, 1, 2, "Given a string")
    assert token._child_keys == {'a': 'a', 'b': 'b'}
    assert token._child_tokens == {'a': 1, 'b': 2}

# Generated at 2022-06-24 11:27:55.536958
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    x = Token(None, 0, 0, "")
    assert repr(x) == "Token('')", "Test the method __repr__ of class Token failed."


# Generated at 2022-06-24 11:28:05.977963
# Unit test for method lookup of class Token
def test_Token_lookup():
    from typesystem.base import Token
    from typesystem.base import ArraySchema
    from typesystem.base import DictSchema
    from typesystem.base import IntegerSchema
    from typesystem.base import NumberSchema
    from typesystem.base import StringSchema
    from typesystem.base import MultiSchema
    
    d = DictSchema({"x":{"type":IntegerSchema()}})
    array = ArraySchema(StringSchema())
    m = MultiSchema([StringSchema(), NumberSchema()])
    d_token = Token(d.to_primitive(), 0, 1, content="")
    array_token = Token(array.to_primitive(), 0, 1, content="")
    m_token = Token(m.to_primitive(), 0, 1, content="")
    d_token_2

# Generated at 2022-06-24 11:28:08.976205
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    assert Token(value={1:"test"}, start_index=2, end_index=3).lookup_key([1]) == Token("test", 2,3)

# Generated at 2022-06-24 11:28:16.263466
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"hello": 5}, 0, 1, content="{}")
    assert repr(token) == "DictToken({})", "repr(token) = {}".format(repr(token)) 
    assert token._content == "{}", "token._content = {}".format(token._content)
    assert token._value == {"hello": 5}, "token._value = {}".format(token._value)
    assert token._start_index == 0, "token._start_index = {}".format(token._start_index)
    assert token._end_index == 1, "token._end_index = {}".format(token._end_index)
    assert token.start.line_number == 1, "token.start.line_number = {}".format(token.start.line_number)
    assert token.start.column

# Generated at 2022-06-24 11:28:20.383002
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken([1, 2, 3], 0, 3)
    assert token.string == "[1, 2, 3]"
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 9, 8)



# Generated at 2022-06-24 11:28:27.875318
# Unit test for method __repr__ of class Token
def test_Token___repr__():

    # Input data
    self_type = "class_name"
    self_string = "string"
    return_value = (
        self_type + "(" + self_string + ")"
    )

    # Expected output
    expected = return_value

    # Generating test object
    token = Token("value", 0, 0, self_string)
    token.__class__.__name__ = self_type

    # Executing method
    result = token.__repr__()

    # Checking result
    assert result == expected


# Generated at 2022-06-24 11:28:36.349561
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from typesystem.base import Token
    from typesystem.base import Position
    
    content = "abc\ndef\nghi\njkl"
    value = [1, 2, 3]
    start_index = 0
    end_index = 10
    token1 = Token(value=value, start_index=start_index, end_index=end_index, content = content)
    lookup_key = token1.lookup_key([1])
    assert lookup_key.value == 2
    assert lookup_key.start == Position(line_no=1, column_no=1, offset=4)
    assert lookup_key.end == Position(line_no=1, column_no=2, offset=5)



# Generated at 2022-06-24 11:28:39.370349
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(1, 1, 2)
    assert token.string == "1"

# Generated at 2022-06-24 11:28:48.629218
# Unit test for constructor of class Token
def test_Token():
    from unittest import TestCase
    from io import StringIO

    class Test(TestCase):
        def test_Token(self):
            value = 123
            start_index = 33
            end_index = 55
            content = "test_content"
            token = Token(value, start_index, end_index, content)
            self.assertEqual(token.value, value)
            self.assertEqual(token._start_index, start_index)
            self.assertEqual(token._end_index, end_index)
            self.assertEqual(token._content, content)
            self.assertEqual(token.string, content[start_index: end_index + 1])
            self.assertEqual(token.start, Position(1, 34, 33))

# Generated at 2022-06-24 11:28:52.691845
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = Token('a', 0, 1)
    assert token.lookup_key([0]) == Token('a', 0, 1)
    assert token.lookup_key([1]) == Token('a', 0, 1)


# Generated at 2022-06-24 11:28:53.229529
# Unit test for method lookup of class Token
def test_Token_lookup():
    pass

# Generated at 2022-06-24 11:29:00.333903
# Unit test for method lookup of class Token
def test_Token_lookup():
    class SimpleToken(Token):
        def __init__(self, value: typing.Any, start_index: int, end_index: int, content: str = ""):
            super().__init__(value, start_index, end_index, content)
            self._child_tokens = {}

        def _get_value(self) -> typing.Any:
            return self._value

        def _get_child_token(self, key):
            return self._child_tokens[key]

    token1 = SimpleToken("token1", 1, 3)
    token2 = SimpleToken("token2", 2, 4)
    token3 = SimpleToken("token3", 3, 5)
    token4 = SimpleToken("token4", 4, 6)
    token5 = SimpleToken("token5", 5, 7)

    token1._

# Generated at 2022-06-24 11:29:09.094893
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # test with empty Token
    tok1 = Token(None, 0, 0, '')
    assert tok1.lookup_key([0]) is None

    # test with non-empty Token
    non_empty_obj = {
        'a': 'a',
        'b': ['b', 'c'],
        'd': {
            'e': {
                'f': 'f',
                'g': ['h', 'i'],
            },
            'j': ['k', None, 'l'],
        },
        'm': None,
    }
    b = [['b', 'c'], [['b', 'c'], [['b', 'c']]]]
    tok2 = Token(non_empty_obj, 0, 0, '')

# Generated at 2022-06-24 11:29:12.999481
# Unit test for constructor of class ListToken
def test_ListToken():
	# ListToken(value, start_index, end_index, content)
	token = ListToken("value", 1, 2, "content")
	assert token._value == "value"
	assert token._start_index == 1
	assert token._end_index == 2
	assert token._content == "content"

if __name__ == "__main__":
	# test_ListToken()
	pass

# Generated at 2022-06-24 11:29:15.071089
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(1, 0, 0)
    expected_hash = hash(1)
    assert token.__hash__() == expected_hash

# Generated at 2022-06-24 11:29:18.053479
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t = Token(1, 2, 3)
    assert str(t) == "Token(1)"
    assert t == t
    assert t != None



# Generated at 2022-06-24 11:29:26.815752
# Unit test for method __repr__ of class Token

# Generated at 2022-06-24 11:29:31.290606
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    value = 1
    start_index = 0
    end_index = 1
    content = "1"
    _token = ScalarToken(value, start_index, end_index, content)
    assert _token.__hash__() == hash(1)


# Generated at 2022-06-24 11:29:38.465390
# Unit test for method lookup of class Token
def test_Token_lookup():
    from typesystem.base import FieldError, Integer as Int
    from typesystem.compat import hrange
    from typesystem.compat import str
    from typesystem.structures import Dict
    from typesystem.structures import List
    from typesystem.structures import String

    class MyDict(Dict):
        first = String()
        second = String()

    class MyList(List):
        child = MyDict()

    class MySchema(Dict):
        my_list = MyList()

    schema = MySchema()

    invalid_list = schema.validate({"my_list": ["badlist"]})

    error = invalid_list.get_errors()[0]
    assert isinstance(error, FieldError)
    assert error.field_name == "my_list"

# Generated at 2022-06-24 11:29:42.435796
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    import typesystem
    from typesystem.parser import Token
    token1 = Token(None, 0, 0)
    token2 = Token(None, 0, 0)
    assert (token1 == token2) == True
    assert (token1 == token1) == True



# Generated at 2022-06-24 11:29:46.098503
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    """Test for Token.__repr__"""
    a = Token(value='a', start_index=0, end_index=1, content='ab')
    assert a.__repr__() == "Token('a')"


# Generated at 2022-06-24 11:29:48.195121
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(1, 2, 3)
    assert hash(token) == hash(1)



# Generated at 2022-06-24 11:29:56.908518
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    start_index = int
    end_index = int
    content = str
    token1 = Token(value, start_index, end_index, content)
    value = object
    assert token1._get_value() == value
    assert token1._start_index == start_index
    assert token1._end_index == end_index
    start_index = None
    assert token1._start_index == start_index
    end_index = None
    assert token1._end_index == end_index
    content = None
    assert token1._content == content



# Generated at 2022-06-24 11:30:00.252214
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    class TestToken(Token):
        def __init__(self):
            super().__init__(None,0,0)
    t = TestToken()
    assert t.__repr__() == "TestToken('')"


# Generated at 2022-06-24 11:30:07.515985
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = ListToken(
        [
            ScalarToken(1, 0, 0),
            ScalarToken(2, 1, 1),
            ListToken(
                [
                    ScalarToken(10, 2, 2),
                    ScalarToken(20, 3, 3),
                    ScalarToken(30, 4, 4),
                ],
                2,
                4,
                content="123",
            ),
            ScalarToken(4, 5, 5),
        ],
        0,
        5,
        content="123",
    )
    assert token.lookup_key([3, 1]) == ScalarToken(30, 4, 4)



# Generated at 2022-06-24 11:30:22.539205
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = ScalarToken(7, 3, 5)
    assert token.lookup_key([]) == token
    token = ListToken([ScalarToken(6, 2, 4)], 1, 5)
    assert token.lookup_key([0]) == ScalarToken(6, 2, 4)
    token = DictToken({ScalarToken(1, 2, 4): ScalarToken(2, 6, 8)}, 1, 9)
    assert token.lookup_key([]) == token
    assert token.lookup_key([ScalarToken(1, 2, 4)]) == ScalarToken(2, 6, 8)
    assert token.lookup_key([1]) == ScalarToken(2, 6, 8)

# Generated at 2022-06-24 11:30:26.314944
# Unit test for method lookup of class Token
def test_Token_lookup():
    class TestToken(ScalarToken):
        _value = 1
    assert TestToken(TestToken(1, 2, 3)).lookup([0])

# Generated at 2022-06-24 11:30:30.260349
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken({"a": 2}, 0, 2)
    assert dt.value == {"a": 2}
    assert dt.start == Position(1, 3, 0)
    assert dt.end == Position(1, 3, 2)


# Generated at 2022-06-24 11:30:33.557020
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(
        value=1, start_index=0, end_index=1
    )
    assert token.__hash__() is not None

# Generated at 2022-06-24 11:30:36.042537
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({'a': 1, 'b': 2}, 0, 2, content="{ 'a': 1, 'b': 2}")


# Generated at 2022-06-24 11:30:42.198286
# Unit test for constructor of class DictToken
def test_DictToken():
    # Create a dictionary, a new object of class Token, and then create a new object of class DictToken
    test_dict = {"test1": "test2"}
    child_token = Token(test_dict, 1, 2, "test1")
    token_of_dict = DictToken(test_dict, 1, 2, "test1")
    print(token_of_dict)



# Generated at 2022-06-24 11:30:50.662358
# Unit test for method lookup_key of class Token

# Generated at 2022-06-24 11:30:59.028150
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken(["1", "2", "3"], 1, 1, "1\n2\n3")
    assert(token.string == "3")
    assert(token.value == ["1", "2", "3"])
    assert(token.start == Position(1, 1, 1))
    assert(token.end == Position(3, 1, 3))
    assert(token.lookup([1]).string == "2")
    assert(token.lookup_key([1]).string == "2")
    assert(token.__repr__() == "ListToken('3')")
    assert(token.__eq__(ListToken(["1", "2", "3"], 1, 1, "1\n2\n3")) == True)

# Generated at 2022-06-24 11:31:08.224556
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken(start_index = 0, end_index = 1, value = {}, content = "")
    assert(dt.start == dt.end)
    assert(dt.value == {})
    dt2 = DictToken(start_index = 0, end_index = 1, value = {'key': 'value'}, content = "")
    assert(dt2.start == dt2.end)
    assert(dt2.value == {'key': 'value'})

# Generated at 2022-06-24 11:31:19.928510
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from typesystem.token import ListToken, DictToken, ScalarToken
    d = {'name': 'test', 'value': [1, 2, 3]}
    dt = DictToken(d, 0, len(d) - 1)
    assert dt.lookup_key([0, 0]) == ScalarToken('name', 0, 3)
    assert dt.lookup_key([0, 1]) == ScalarToken('test', 7, 11)
    assert dt.lookup_key([1, 0]) == ScalarToken('value', 16, 20)
    assert dt.lookup_key([1, 1]) == ListToken([1, 2, 3], 24, 28)



# Generated at 2022-06-24 11:31:21.395565
# Unit test for method lookup of class Token
def test_Token_lookup():
    a = ScalarToken(None, 0, 2, "")
    assert a.lookup([0]) == a
