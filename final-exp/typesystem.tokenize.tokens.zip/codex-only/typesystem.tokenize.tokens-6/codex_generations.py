

# Generated at 2022-06-24 11:21:25.905728
# Unit test for method lookup of class Token
def test_Token_lookup():
    assert False

# Generated at 2022-06-24 11:21:28.094216
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    scalar_token = ScalarToken('', 0, 0)
    assert_equal(hash(scalar_token), hash(''))


# Generated at 2022-06-24 11:21:31.991286
# Unit test for constructor of class DictToken
def test_DictToken():
	dic = {"key": "value"}
	token = DictToken(dic, 0, 9)
	assert token._child_keys == {"key": "value"}
	assert token._child_tokens == {"key": "value"}


# Generated at 2022-06-24 11:21:40.837711
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert ScalarToken(value=0, start_index=1, end_index=2).__hash__() == ScalarToken(value=0, start_index=1, end_index=2).__hash__()
    assert ScalarToken(value=0.0, start_index=1, end_index=2).__hash__() == ScalarToken(value=0.0, start_index=1, end_index=2).__hash__()
    assert ScalarToken(value=0j, start_index=1, end_index=2).__hash__() == ScalarToken(value=0j, start_index=1, end_index=2).__hash__()

# Generated at 2022-06-24 11:21:50.188004
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert ScalarToken(1, 1, 2) == ScalarToken(1, 1, 2)
    assert ScalarToken(1, 1, 2) != ScalarToken(1, 1, 3)
    assert ScalarToken(1, 1, 2) != ScalarToken(2, 1, 2)
    assert ScalarToken(1, 1, 2) != ScalarToken("1", 1, 2)
    assert ListToken([], 1, 2) == ListToken([], 1, 2)
    assert ListToken([], 1, 2) != ListToken([], 1, 3)
    assert ListToken([], 1, 2) != ListToken([], 2, 2)
    assert ListToken([], 1, 2) != ListToken([], 1, 2, "foo")

# Generated at 2022-06-24 11:21:56.916796
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from typesystem import Array

    class ListOfStrings(Array):
        items: str = None

    class MyArray(Array):
        items: ListOfStrings = None

    val = ["abc", ["def", "ghi"]]
    token = MyArray(val).to_token(val)
    assert token.lookup_key([0, 0]) == ScalarToken(key="abc", start_index=0, end_index=2, content="abc")
    assert token.lookup_key([1, 0]) == ScalarToken(key="def", start_index=5, end_index=7, content="[\"abc\", [\"def\", \"ghi\"]]")

# Generated at 2022-06-24 11:21:59.529409
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    t = Token(value='Hello world', start_index=0, end_index=2, content='abc')
    r = repr(t)
    assert r == "Token('Hello world')"


# Generated at 2022-06-24 11:22:05.551980
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    string = "a"
    start_index = 1
    end_index = 2
    token = Token(value=string, start_index=start_index, end_index=end_index)

    expected = "Token(%s)" % repr(string)
    actual = token.__repr__()
    assert expected == actual


# Generated at 2022-06-24 11:22:17.127304
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class Object:
        def __init__(self, obj, start_index, end_index, content):
            self.value = obj
            self.start_index = start_index
            self.end_index = end_index
            self.content = content

        def get_child_token(self, key):
            return self.value._get_child_token(key)

        def get_key_token(self, key):
            return self.value._get_key_token(key)

        def lookup(self, index):
            return self.value.lookup(index)

        def lookup_key(self, index):
            return self.value.lookup_key(index)

    class Token:
        def __init__(self, value, start_index, end_index, content):
            self._value = value
            self

# Generated at 2022-06-24 11:22:21.045946
# Unit test for constructor of class Token
def test_Token():
    t = Token(12,0,10,"")
    assert t._value == 12
    assert t._start_index == 0
    assert t._end_index == 10
    assert t._content == ""
    assert t.string == ""
    assert t.value == 12


# Generated at 2022-06-24 11:22:28.457854
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(None, 0, 1)
    assert token.__hash__() is None
    token = ScalarToken(True, 0, 1)
    assert token.__hash__() is True
    token = ScalarToken(1, 0, 1)
    assert token.__hash__() is 1
    token = ScalarToken(1.0, 0, 1)
    assert token.__hash__() == 1.0
    token = ScalarToken("", 0, 1)
    assert token.__hash__() == ""
    token = ScalarToken("one", 0, 1)
    assert token.__hash__() == "one"


# Generated at 2022-06-24 11:22:31.570449
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token(123, 0, 10, "0123456789")
    assert repr(token) == 'Token(\'123\')'


# Generated at 2022-06-24 11:22:36.194488
# Unit test for constructor of class DictToken
def test_DictToken():
    test_dict = {
        ScalarToken(1, 0, 0): ScalarToken(2, 0, 0),
        ScalarToken(3, 0, 0): ScalarToken(4, 0, 0),
        ScalarToken(5, 0, 0): ScalarToken(6, 0, 0),
    }
    test_test_dict = DictToken(test_dict, 0, 0, "123456")
    assert test_dict == test_test_dict._value

# Generated at 2022-06-24 11:22:40.172946
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Init a Token
    token = Token(None, 0, 1, content="123")
    # Call method __repr__
    result = token.__repr__()

    assert result is not None


# Generated at 2022-06-24 11:22:46.805494
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_0 = Token(value=None, start_index=0, end_index=1)
    token_1 = Token(value=None, start_index=0, end_index=1)
    token_2 = Token(value=None, start_index=0, end_index=2)
    token_3 = Token(value=None, start_index=1, end_index=1)
    assert (token_0 == token_1) is True
    assert (token_0 == token_2) is False
    assert (token_0 == token_3) is False



# Generated at 2022-06-24 11:22:54.783832
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert ScalarToken("", 0, 0).__hash__() == hash("")
    assert ScalarToken("{", 0, 0).__hash__() == hash("{")
    assert ScalarToken("}", 0, 0).__hash__() == hash("}")
    assert ScalarToken("[", 0, 0).__hash__() == hash("[")
    assert ScalarToken("]", 0, 0).__hash__() == hash("]")
    assert ScalarToken("[4]", 0, 0).__hash__() == hash("[4]")
    assert ScalarToken("[4]", 0, 2).__hash__() == hash("[4]")
    assert ScalarToken("[4]", 1, 2).__hash__() == hash("4")

# Generated at 2022-06-24 11:22:55.958710
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken({1:2, 3:4})
    assert dt.__class__ == DictToken


# Generated at 2022-06-24 11:23:03.208679
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    """
    Calling __hash__ on ScalarToken should return hash(self._value)
    """
    m_self_value = None
    scalar_token = ScalarToken(m_self_value, None, None)
    m_hash = None
    expected = m_hash
    actual = scalar_token.__hash__()
    assert actual == expected, 'Test Failed'


# Generated at 2022-06-24 11:23:05.726524
# Unit test for method lookup of class Token
def test_Token_lookup():
    from typesystem.base import AnyToken
    test = AnyToken(start_index=0,end_index=4)
    assert test.lookup([0,0,0])._get_value() == 0

# Generated at 2022-06-24 11:23:09.001514
# Unit test for method lookup of class Token
def test_Token_lookup():
    t = ScalarToken("str", 0, 2, "str")
    assert t.lookup([]) == t


# Generated at 2022-06-24 11:23:17.621680
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.types.structures import Dict
    from typesystem.token import DictToken

    class Person(Dict):
        properties = {"first_names": String()}

        optional_properties = {"last_name": String()}

    class X(Dict):
        properties = {"people": [Person()]}

    result = X.validate({"people": [{"first_names": "John"}]})
    instance_x = result.value
    token_x = result.tokens
    assert isinstance(token_x, DictToken)
    assert isinstance(token_x._value, dict)

    person_token_john = token_x.lookup(["people", "0"])
    assert isinstance(person_token_john, DictToken)

# Generated at 2022-06-24 11:23:20.094489
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # Create a test Token and test
    test_token = ScalarToken(1, 1, 2)
    assert hash(test_token) == hash(1)



# Generated at 2022-06-24 11:23:22.043206
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert hash(ScalarToken(1, 0, 0)) == 1


# Generated at 2022-06-24 11:23:26.425694
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(
        value="123", start_index=0, end_index=2, content="123456"
    )
    assert token._value == "123"
    assert token._start_index == 0
    assert token._end_index == 2
    assert token._content == "123456"
    assert token._get_value() == "123"


# Generated at 2022-06-24 11:23:35.170694
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # test for a nested structure, ensure that last index is used as key
    class TestDictToken(DictToken):
        def __init__(self) -> None:
            TOKEN = Token("", 0, 1, "")
            self._value = {TOKEN: TOKEN}
            self._child_keys = {TOKEN._value: TOKEN}
            self._child_tokens = {TOKEN._value: TOKEN}
        def _get_value(self) -> typing.Any:
            return {"key": "value"}
    assert TestDictToken().lookup_key([0]) == TestDictToken()

    # test for a list, ensure that last index is used as key

# Generated at 2022-06-24 11:23:39.536767
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    tok = ScalarToken('value', 1, 2)
    expected_value = 'value'
    expected_start = 1
    expected_end = 2
    assert tok._value == expected_value
    assert tok._start_index == expected_start
    assert tok._end_index == expected_end


# Generated at 2022-06-24 11:23:51.348534
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class MockToken(Token):
        def __init__(self, value: typing.Any, start_index: int, end_index: int, content: str = ""):
            super(MockToken, self).__init__(value, start_index, end_index, content)
            self._value = value
        
        def _get_value(self) -> typing.Any:
            return self._value
        
        def _get_child_token(self, key: typing.Any) -> Token:
            return self._value[key]

        def _get_key_token(self, key: typing.Any) -> Token:
            return self._value[key]
        

# Generated at 2022-06-24 11:23:56.326679
# Unit test for constructor of class DictToken
def test_DictToken():
    value = DictToken({})
    assert value._child_tokens == {}
    assert value._child_keys == {}
    assert value._value == {}
    assert value._start_index == 0
    assert value._end_index == 0
    assert value._content == ''

# Generated at 2022-06-24 11:23:57.172531
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": "b"})

# Generated at 2022-06-24 11:24:05.497900
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    def run(d, key):
        parsed = parse(d)
        return parsed.lookup_key(key).string

    assert run("{}", [0]) == ""
    assert run("{ 1: '2' }", [0, 0]) == "1"
    assert run("{ 1: '2' }", [0, 1]) == "2"
    assert run("{ 1: '2' }", [1]) == ""
    assert run("{ 1: '2' }", [0, -1]) == ""
    assert run("[]", [0]) == ""
    assert run("[1, 2]", [0]) == "1"
    assert run("[1, 2]", [1]) == "2"
    assert run("[1, 2]", [2]) == ""

# Generated at 2022-06-24 11:24:07.724560
# Unit test for constructor of class Token
def test_Token():
    token = Token(value=12, start_index=0, end_index=10, content="a, b, c")
    assert(token._start_index == 0)

# Generated at 2022-06-24 11:24:15.100985
# Unit test for constructor of class Token
def test_Token():
    token = Token(value ="haha", start_index = 9, end_index = 10, content ="hello world") 
    assert token._value == "haha" 
    assert token._start_index == 9
    assert token._end_index == 10
    assert token._content == "hello world"
    assert token._get_value() == NotImplementedError
    assert token._get_child_token(5) == NotImplementedError
    assert token._get_key_token(5) == NotImplementedError
    assert token.string == 'w'
    assert token.value == NotImplementedError
    assert token.start == Position(2,2,10)
    assert token.end == Position(2,3,11)
    assert token.lookup([1]) == NotImplementedError 
    assert token

# Generated at 2022-06-24 11:24:23.925604
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    # Create a string test
    s = ScalarToken(value = "hello world", start_index = 0, end_index = 10, content = "hello world")
    assert s._value == "hello world"
    assert s._start_index == 0
    assert s._end_index == 10
    assert s._content == "hello world"

    # Create an integer test
    i = ScalarToken(value = 1, start_index = 0, end_index = 0, content = "1")
    assert i._value == 1
    assert i._start_index == 0
    assert i._end_index == 0
    assert i._content == "1"

    # Create a dictionary test
    d = ScalarToken(value = {}, start_index = 0, end_index = 1, content = "{}")
    assert d._value == {}


# Generated at 2022-06-24 11:24:34.134233
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from .parser import get_tokenizer, Tokenizer, TokenizerError

    tokenizer = get_tokenizer()  # type: Tokenizer
    t = tokenizer.parse("{a: {b: 3}}")  # type: Token

    # Valid keys
    assert t.lookup_key([0, 0]) == t.lookup([0, "a"])
    assert t.lookup_key([0, 1]) == t.lookup([0, "b"])

    # Invalid structure
    with pytest.raises(TokenizerError) as excinfo:
        t.lookup_key([0, 0, 0])
    assert excinfo.match("expected key")

    # Invalid key
    with pytest.raises(TokenizerError) as excinfo:
        t.lookup_key([0, 2])
    assert exc

# Generated at 2022-06-24 11:24:40.505650
# Unit test for method lookup of class Token
def test_Token_lookup():
    length = 10
    tokens = [
        ScalarToken(str(i), i, i, str(i))
        for i in range(length)
    ]
    tokens[0]._value = {
        ScalarToken(str(i), i, i, str(i)) for i in range(4)
    }
    tokens[1]._value = [tokens[7], ScalarToken(str(i), i, i, str(i))]
    assert tokens[0].lookup([1]).string == '1'
    assert tokens[1].lookup([0]).string == '7'

# Generated at 2022-06-24 11:24:48.055108
# Unit test for method lookup of class Token
def test_Token_lookup():
    # Token.lookup(index) -> Token
    # token.lookup(index) -> Token

    # Test with a ScalarToken
    t1 = ScalarToken(1, 0, 1, '"1"')
    assert t1 is t1.lookup([])

    # Test with a ListToken
    t2 = ListToken([], 0, 1, '"[]')
    t3 = ListToken([t1], 0, 2, '"[1")')
    assert t1 is t3.lookup([0])

    # Test with a DictToken
    t4 = DictToken({}, 0, 1, '"{}')
    t5 = DictToken({t1: t2}, 0, 3, '"{1:[]')
    assert t1 is t5.lookup([0])
    assert t2 is t

# Generated at 2022-06-24 11:24:51.792466
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    list_1 = ListToken([], 0, 0)
    list_2 = ListToken([], 0, 0)

    assert list_1.lookup_key([0, 0]) == list_2.lookup_key([0, 0])

# Generated at 2022-06-24 11:24:57.691081
# Unit test for constructor of class ListToken
def test_ListToken():
    content = None
    token = ListToken([[""], [""]], start_index=1, end_index=3, content=content)
    assert token.string == ","
    assert token.start == Position(1, 2, 1)
    assert token.end == Position(1, 4, 3)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 11:25:00.255052
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(value=5, start_index=0, end_index=10)
    assert hash(token) == hash(5)



# Generated at 2022-06-24 11:25:01.813470
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({'a':4},1,2).string == "{'a':4}"

# Generated at 2022-06-24 11:25:08.307197
# Unit test for constructor of class ListToken
def test_ListToken():
    x = [1, 2, 3]
    y = ListToken(x, 3, 2, "123")
    y._value[0]._value == 1


# Generated at 2022-06-24 11:25:18.597295
# Unit test for method lookup of class Token
def test_Token_lookup():
    # Not very much to test in this class, only method lookup
    # First, let's make a ListToken
    test_dict = {'a': {'aa': 12, 'ab': [2, 3, 4, 5, 6]}}
    list_tok = ListToken(test_dict['a']['ab'], 0, 10, content = "abcdefghij")
    assert list_tok.lookup([2]) == list_tok._get_child_token(2)
    assert list_tok.lookup([]) == list_tok
    assert list_tok.lookup([3, 2]) == list_tok._get_child_token(3)._get_child_token(2)
    # Test that a KeyError is thrown if we try to lookup outside the list

# Generated at 2022-06-24 11:25:21.136398
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    """
    Unit test for method __hash__ of class ScalarToken
    """
    token = ScalarToken(1, 0, 0, content="")
    assert token.__hash__() == 1



# Generated at 2022-06-24 11:25:27.627148
# Unit test for method lookup of class Token
def test_Token_lookup():
    # Case 1: lookup 'a'
    Token = ListToken("\na\n", 0, 2)
    index = [0]
    result = Token.lookup(index)
    assert result == "\na\n"


# Generated at 2022-06-24 11:25:37.949648
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from typesystem.base import Position
    from typesystem.base.string import String, StringType

    type_ = StringType()
    content = "a b c"  # No newline!
    tokens = type_.parse(content)
    assert tokens.lookup_key([0, 0]).string == "a"
    assert tokens.lookup_key([0, 0]).start == Position(1, 1, 0)
    assert tokens.lookup_key([0, 0]).end == Position(1, 1, 0)
    assert tokens.lookup_key([0, 1]).string == "b"
    assert tokens.lookup_key([0, 1]).start == Position(1, 2, 1)
    assert tokens.lookup_key([0, 1]).end == Position(1, 2, 1)

# Generated at 2022-06-24 11:25:43.405132
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = ScalarToken("A String", 0, 0, content = "ABCDEFG")
    index = [0]
    token_lookup = token.lookup(index)
    assert token_lookup == ScalarToken("A String", 0, 0, content = "ABCDEFG")

# Generated at 2022-06-24 11:25:48.793171
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert ScalarToken(1, 0, 0) == ScalarToken(1, 0, 0)
    assert not ScalarToken(1, 0, 0) == ScalarToken(1, 0, 1)
    assert not ScalarToken(1, 0, 0) == ScalarToken(2, 0, 0)
    assert not ScalarToken(1, 0, 0) == ScalarToken(2, 0, 1)

# Generated at 2022-06-24 11:25:52.703197
# Unit test for constructor of class ListToken
def test_ListToken():
    listToken = ListToken(["abc", 456], 1, 2, content="abc")
    assert listToken.value == ["abc", 456]
    assert listToken.start == Position(1, 1, 1)
    assert listToken.end == Position(1, 2, 2)


# Generated at 2022-06-24 11:25:54.473192
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(3, 0, 0)
    assert hash(token) == hash(3)


# Generated at 2022-06-24 11:25:59.500741
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    SUT = ScalarToken
    obj = ScalarToken(value=5, start_index=0, end_index=2)
    assert hash(obj) == hash(5)


# Generated at 2022-06-24 11:26:03.623985
# Unit test for constructor of class DictToken
def test_DictToken():
    a = ScalarToken("a", 0, 2)
    b = ScalarToken("b", 0, 2)
    d = DictToken({a: b}, 0, 30)
    assert d._child_keys[a._value] == a
    assert d._child_tokens[a._value] == b

# Generated at 2022-06-24 11:26:09.941187
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken({"a": 1}, 0, 10)
    assert dt._start_index == 0
    assert dt._end_index == 10
    assert dt._child_tokens == {"a": 1}
    assert dt._child_keys == {"a": 1}


# Generated at 2022-06-24 11:26:18.828314
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    """
    Test __repr__ method of class Token.
    """
    class T(Token):
        def __init__(self, value: typing.Any, start_index: int, end_index: int, content: str = ""):
            super().__init__(value, start_index, end_index, content)
    t = T(1, 2, 3, content="this is a content")
    assert "T(1)" == repr(t)


# Generated at 2022-06-24 11:26:19.245453
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    assert True

# Generated at 2022-06-24 11:26:20.914374
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(value = "hello", start_index = 0, end_index = 5)
    result = token.__hash__()
    assert result == hash("hello")



# Generated at 2022-06-24 11:26:29.308508
# Unit test for constructor of class Token
def test_Token():
    token_test = Token(1, 2, 3)
    assert token_test._value == 1
    assert token_test._start_index == 2
    assert token_test._end_index == 3
    assert token_test._content == ""

    token_test = Token(1, 2, 3, content = "")
    assert token_test._value == 1
    assert token_test._start_index == 2
    assert token_test._end_index == 3
    assert token_test._content == ""

    token_test = Token(2, 3, 4)
    assert token_test._value == 2
    assert token_test._start_index == 3
    assert token_test._end_index == 4
    assert token_test._content == ""

    token_test = Token(3, 4, 5, content = "")
    assert token

# Generated at 2022-06-24 11:26:34.810468
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken('value', 0, 4, "value")
    assert token.value == 'value'


# Generated at 2022-06-24 11:26:40.626197
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    # Test-1 => string, start_index, end_index, content
    token = ScalarToken(3, 0, 0, '[3, 6, 1]')
    assert token.value == 3
    assert token.string == '3'
    assert token.start == Position(line_no=1, column_no=1, index=0)
    assert token.end == Position(line_no=1, column_no=1, index=0)
    assert token.lookup([0]) == token
    assert token.lookup_key([0, 0]) == token


# Generated at 2022-06-24 11:26:42.236744
# Unit test for constructor of class Token
def test_Token():
    t = Token(0, 0, 0, "")
    assert t


# Generated at 2022-06-24 11:26:43.590367
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken([], 0, 1)._get_value() == []
    assert ListToken([0, 1], 0, 3)._get_value() == [0, 1]

# Generated at 2022-06-24 11:26:48.353258
# Unit test for constructor of class ListToken
def test_ListToken():
    try:
        ListToken(None, 0, 0)
    except NotImplementedError:
        print("NotImplementedError")
        return 0
    return 1


# Generated at 2022-06-24 11:26:49.993671
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    pass


# Generated at 2022-06-24 11:26:51.086634
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
  test_ListToken_lookup_key()
  test_DictToken_lookup_key()


# Generated at 2022-06-24 11:26:53.935879
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    int_token = ScalarToken(5,5,5)
    assert int_token.value == 5
    assert int_token.start == Position(1, 1, 5)


# Generated at 2022-06-24 11:26:55.395162
# Unit test for constructor of class ListToken
def test_ListToken():
  test_ListToken = ListToken([1,2,3])
  assert test_ListToken._value == [1,2,3]

# Generated at 2022-06-24 11:27:00.751369
# Unit test for method lookup of class Token
def test_Token_lookup():
    token_list = ListToken(
        [ScalarToken("a", 0, 0), ScalarToken("b", 1, 1), ScalarToken("c", 2, 2)],
        0, 2, "abc"
    )
    assert token_list.lookup([0]).string == "a"
    assert token_list.lookup([1]).string == "b"
    assert token_list.lookup([2]).string == "c"


# Generated at 2022-06-24 11:27:07.474451
# Unit test for method lookup of class Token
def test_Token_lookup():
    from typesystem import String 
    from typesystem.parser import parse
    parsed_token_string = parse('"mon string"')
    assert parsed_token_string._value == 'mon string'
    assert parsed_token_string.start.index == 0
    assert parsed_token_string.end.index == len('mon string')+1
    assert parsed_token_string.string == 'mon string'
    assert parsed_token_string.value == 'mon string'
    assert parsed_token_string.lookup([0]) == parsed_token_string

# Generated at 2022-06-24 11:27:17.785438
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    '''
    Unit test for method __hash__ of class ScalarToken
    '''
    scalar_token = ScalarToken(0, 0, 0)
    assert scalar_token.__hash__() == 0
    scalar_token = ScalarToken(1, 0, 0)
    assert scalar_token.__hash__() == 1
    scalar_token = ScalarToken(2, 0, 0)
    assert scalar_token.__hash__() == 2
    scalar_token = ScalarToken(3, 0, 0)
    assert scalar_token.__hash__() == 3
    scalar_token = ScalarToken(4, 0, 0)
    assert scalar_token.__hash__() == 4
    scalar_token = ScalarToken(5, 0, 0)
    assert scalar_

# Generated at 2022-06-24 11:27:19.555114
# Unit test for method lookup of class Token
def test_Token_lookup():
    a = ListToken(value=[], start_index = 0, end_index = 1, content = "123")
    assert a.lookup([0]) == a

# Generated at 2022-06-24 11:27:21.198275
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken(1, 2, 3, 4, 5, "")

# Generated at 2022-06-24 11:27:23.324410
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    assert True == False

# Generated at 2022-06-24 11:27:27.700081
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    if __name__ != "__main__":
        raise RuntimeError("only run this as a main")

    # Example data to test this method 
    token = ListToken([ScalarToken("a", 0, 0)], 0, 0, "a")
    key_token = token.lookup_key([0])

    # Print results 
    #   ("ScalarToken(\"a\")" if correct result, Error otherwise)
    print(key_token)

# Generated at 2022-06-24 11:27:34.145201
# Unit test for constructor of class DictToken
def test_DictToken():
    # Assume
    args = (1, 2, 3, 4)
    kwargs = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    kwargs_expected = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    # Action
    actual = DictToken(*args, **kwargs)
    # Assert
    assert actual is not None


# Generated at 2022-06-24 11:27:37.481479
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken(value=1, start_index=1, end_index=2, content=3)
    assert token._value == 1
    assert token._start_index == 1
    assert token._end_index == 2
    assert token._content == 3

# Generated at 2022-06-24 11:27:43.773572
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    test_object = Token(None, 0, 0)
    test_array = [1, 2, 3]
    test_index = [1, 2, 3]
    test_result = test_object.lookup_key(test_index)
    assert test_result != test_array



# Generated at 2022-06-24 11:27:48.476216
# Unit test for constructor of class Token
def test_Token():
    value_for_Token = "1"
    start_index_for_Token = 1
    end_index_for_Token = 2
    content_for_Token = ""
    token_result = Token(value_for_Token, start_index_for_Token, end_index_for_Token, content_for_Token)
    assert token_result


# Generated at 2022-06-24 11:27:56.916989
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    from typing import List, TypeVar
    from typesystem.token import Token, ScalarToken, DictToken, ListToken

    T = TypeVar('T')

    def get_type(token: Token, expected_type: type) -> None:
        assert isinstance(token, expected_type)
    
    class TestScalarToken(ScalarToken):
        def __init__(self, value: typing.Any, start_index: int, end_index: int) -> None:
            super().__init__(value, start_index, end_index)
    

# Generated at 2022-06-24 11:28:01.381728
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    a = ScalarToken(value='1',start_index=0,end_index=1,content='1')
    assert a._value == '1'
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == '1'


# Generated at 2022-06-24 11:28:08.857734
# Unit test for method lookup of class Token
def test_Token_lookup():
    # Be careful to change the index in this example!!!
    class ExampleToken(ListToken):
        def __init__(self, index = 0):
            self.index = index

        def _get_child_token(self, key):
            if self.index == 2:
                return Token(["1", "2", "3", "4", "5", "6"], 0, 0)
            elif self.index == 3:
                return Token(["1", "2", "3", "4", "5", "6"], 0, 0)
            elif self.index == 4:
                return Token(["1", "2", "3", "4", "5", "6"], 0, 0)

# Generated at 2022-06-24 11:28:11.930692
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    t = ListToken([], 0, 0)
    assert t.lookup_key([0]) == t
    assert t.lookup_key([0, 0]) == t

# Generated at 2022-06-24 11:28:18.094635
# Unit test for constructor of class DictToken
def test_DictToken():
    val1 = Token(value=3, start_index=0, end_index=2)
    val2 = Token(value=44, start_index=0, end_index=2)
    dict_ = {val1: val2}
    dict_token = DictToken(value=dict_, start_index=0, end_index=2)

    assert dict_token._get_value() == {3: 44}
    assert dict_token._get_child_token(3) == val2
    assert dict_token._get_key_token(3) == val1
    assert dict_token.lookup([]) == dict_token
    assert dict_token.lookup([3]) == val2
    assert dict_token.lookup_key([3]) == val1

# Generated at 2022-06-24 11:28:20.943607
# Unit test for constructor of class ListToken
def test_ListToken():
    from typesystem.typings import Array, Integer
    Array(Integer(), minimum=2).validate([2, 3, 4], resolve_references=True)
    print("test_ListToken() passed")


# Generated at 2022-06-24 11:28:23.757765
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert ScalarToken(b'\x00\x00\x00\x00', 0, 3).__hash__() == hash(bytes((0, 0, 0, 0)))

# Generated at 2022-06-24 11:28:28.436969
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    value = Token(1, 0, 0, '')
    start_index = 0
    end_index = 0
    content = ''
    token = Token(value, start_index, end_index, content)
    index = [0, 1]
    assert(token.lookup_key(index) == 1)


# Generated at 2022-06-24 11:28:37.153631
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    t1 = DictToken({'1':'2'}, 0, 0, '{"1": 2}')
    assert t1._get_value() == {'1': '2'}
    assert t1._get_value()['1'] == '2'
    assert t1.lookup_key([0])._get_value() == '1'
    assert t1.lookup_key([0]).lookup_key([0])._get_value() == '1'
    assert t1.lookup_key([0]).lookup([0])._get_value() == '1'

    t2 = ListToken(['1'], 0, 0, '["1"]')
    assert t2._get_value() == ['1']
    assert t2.lookup([0])._get_value() == '1'

test_

# Generated at 2022-06-24 11:28:42.990610
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Create tokens with different positions
    token1 = ScalarToken("test", 0, 0)
    token2 = ScalarToken("test", 0, 1)
    token3 = ScalarToken("test", 0, 1)

    # Test with the __eq__ function
    assert token1 == token1
    assert token1 != token2
    assert token2 == token3



# Generated at 2022-06-24 11:28:51.082046
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    body = None

    def _get_child_token(self, key: typing.Any) -> Token:
        return key

    def _get_key_token(self, key: typing.Any) -> Token:
        return key

    ScalarToken._get_child_token = _get_child_token
    ScalarToken._get_key_token = _get_key_token
    ScalarToken.__init__(
        body, value=None, start_index=None, end_index=None, content=None
    )
    assert body.__hash__() == None



# Generated at 2022-06-24 11:28:54.299540
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token: Token = Token(value=42, start_index=0, end_index=1, content='42')
    assert repr(token) == 'Token(\'42\')'


# Generated at 2022-06-24 11:28:59.791093
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.base import Token

    token_1 = Token(1, 0, 1)
    token_2 = Token(1, 0, 1)
    token_3 = Token(2, 0, 1)
    token_4 = Token(1, 1, 0)
    token_5 = Token(1, 0, 0)

    assert token_1 == token_1
    assert token_1 == token_2
    assert token_2 == token_1
    assert token_1 != token_3
    assert token_1 != token_4
    assert token_1 != token_5



# Generated at 2022-06-24 11:29:04.904524
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    start_index = 0
    end_index = 1
    value1 = 1
    value2 = 2
    content = "a"
    token1 = ScalarToken(value1, start_index, end_index, content)
    token2 = ScalarToken(value2, start_index, end_index, content)
    assert token1 == token1
    assert not (token1 == token2)


# Generated at 2022-06-24 11:29:12.775091
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # A set of values to use as the parameter for ScalarToken()
    vals = ['4.4', '7', '4.4']
    # A set of values to use as the parameter for content
    contents = ['"4.4"', '7', '"4.4"']
    # A set of values to use as the parameter for start_index
    start_indexs = [1, 0, 0]
    # A set of values to use as the parameter for end_index
    end_indexs = [3, 0, 3]
    # A set of values to use as the parameter for ScalarToken()
    vals2 = ['4.4', '7', '4.4']
    # A set of values to use as the parameter for content
    contents2 = ['4.4', '7', '4.4']
   

# Generated at 2022-06-24 11:29:16.205238
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    print('Test of method __repr__ in class Token.')
    token=Token(1,1,2,content='abcdefg')
    assert repr(token) == "Token('c')", '__repr__() failed.'
    print('Passed.')

# Generated at 2022-06-24 11:29:21.758078
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(1, 0, 2)
    assert token.value == 1
    assert token.string == "1"
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 2)


# Generated at 2022-06-24 11:29:26.451303
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    value = "value"
    start_index = 1
    end_index = 2
    content = "content"
    x = ScalarToken(value, start_index, end_index, content)
    hash_value = hash(value)
    assert x.__hash__() == hash_value


# Generated at 2022-06-24 11:29:36.169057
# Unit test for method lookup of class Token
def test_Token_lookup():
    from typesystem.types import String, Integer
    from typesystem.validators import Minimum, Maximum
    from typesystem.tools import get_tokens

    schema = [
        {
            "type": "string",
            "validators": [Minimum(1), Maximum(2)],
        },
        {
            "type": "dict",
            "properties": {
                "hello": {"type": "string"},
                "world": {"type": "string"},
            },
            "additionalProperties": True,
        },
        {
            "type": "list",
            "items": {"type": "integer", "validators": [Minimum(1), Maximum(2)]},
        },
    ]

    token_schema = get_tokens(schema)


# Generated at 2022-06-24 11:29:38.398772
# Unit test for constructor of class ListToken
def test_ListToken():
    listtoken = ListToken([], 0, 5)
    assert listtoken._value == []
    assert listtoken._start_index == 0
    assert listtoken._end_index == 5


# Generated at 2022-06-24 11:29:48.483810
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import Token, Position

    class ScalarToken(Token):
        def _get_value(self) -> typing.Any:
            return self._value
    
    class DictToken(Token):
        def _get_value(self) -> typing.Any:
            return {
                key_token._get_value(): value_token._get_value()
                for key_token, value_token in self._value.items()
            }
    

# Generated at 2022-06-24 11:29:59.989224
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    assert ScalarToken("test_value_0", 0, 3, "test") == ScalarToken("test_value_0", 0, 3, "test")
    assert ScalarToken("test_value_1", 0, 3, "test") == ScalarToken("test_value_1", 0, 3, "test")
    assert ScalarToken("test_value_0", 0, 4, "test1") == ScalarToken("test_value_0", 0, 4, "test1")
    assert ScalarToken("test_value_1", 0, 4, "test1") == ScalarToken("test_value_1", 0, 4, "test1")
    assert ScalarToken("test_value_0", 1, 3, "1test") == ScalarToken("test_value_0", 1, 3, "1test")
    assert Scal

# Generated at 2022-06-24 11:30:03.429544
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token= ScalarToken('hi', 1, 2)
    assert token._value == 'hi'
    assert token._start_index == 1
    assert token._end_index == 2
    assert token._content == ''



# Generated at 2022-06-24 11:30:11.768793
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # Unit: test_Token_lookup_key
    # Given: A Token object
    from typesystem.base import Schema
    from typesystem.parser import parse

    test_schema = """
    name: str
    members:
        - name: str
    """
    schema = parse(Schema, test_schema)

    root_token = schema.token()
    assert (root_token.lookup_key([0]).string == "name")
    assert (root_token.lookup_key([1, 0, 0]).string == "name")
    assert (root_token.lookup_key([1, 1]).string == "members")



# Generated at 2022-06-24 11:30:22.512982
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    a = Token({"a": 1, "b": 2}, 1, 5)
    assert a.lookup_key([0])._content == "{'a': 1, 'b': 2}"
    assert a.lookup_key([1])._content == "{'a': 1, 'b': 2}"
    a = Token([1, 2], 1, 5)
    assert a.lookup_key([0])._content == "[1, 2]"
    assert a.lookup_key([1])._content == "[1, 2]"
    assert a.lookup_key([0, 0])._content == "[1, 2]"
    assert a.lookup_key([1, 0])._content == "[1, 2]"
    assert a.lookup_key([0, 1])._content == "[1, 2]"
    assert a.lookup_

# Generated at 2022-06-24 11:30:32.326188
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    # create token object
    token_01 = ScalarToken(value = 100, start_index = 1, end_index = 9)
    # test object content
    assert token_01._value == 100
    assert token_01._start_index == 1
    assert token_01._end_index == 9
    # test object methods
    assert token_01.string == ""
    assert token_01.value == 100
    assert token_01.start == Position(1, 2, 1)
    assert token_01.end == Position(1, 10, 9)
    assert token_01.lookup([3, 4, 5]) == token_01
    assert token_01.lookup_key([1, 2, 3]) == token_01
    assert token_01.__repr__() == 'ScalarToken("")'
    assert token_

# Generated at 2022-06-24 11:30:34.891018
# Unit test for constructor of class DictToken
def test_DictToken():
    dic_tok = DictToken({},0,0,"")
    assert isinstance(dic_tok,DictToken)


# Generated at 2022-06-24 11:30:38.306685
# Unit test for constructor of class Token
def test_Token():
    token = Token(0, 0, 0, " ")
    assert token.start == Position(1, 1, 0)

    token = Token(0, 0, 1, "  ")
    assert token.end == Position(1, 2, 1)

# Generated at 2022-06-24 11:30:41.939702
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert hash(ScalarToken(value=None, start_index=0, end_index=0)) == hash(None)
    assert hash(ScalarToken(value=True, start_index=0, end_index=0)) == hash(True)

# Generated at 2022-06-24 11:30:50.414435
# Unit test for method lookup of class Token
def test_Token_lookup():
    class ListToken(Token):
        def _get_value(self) -> typing.Any:
            return [token._get_value() for token in self._value]

        def _get_child_token(self, key: typing.Any) -> Token:
            return self._value[key]
            
    content= '''
    [
        {
            "productCode": "AAA",
            "supplierCode": "ABC",
            "distributorCode": "DEF"
        },
        {
            "productCode": "BBB",
            "supplierCode": "ABC",
            "distributorCode": "DEF"
        }
    ]
    '''
    print(content)

# Generated at 2022-06-24 11:30:54.030812
# Unit test for constructor of class Token
def test_Token():
    token = Token(
        value=None, start_index=None, end_index=None, content=None
    )
    assert token.string == ""
    assert token.value is None
    assert token.start == token.end
    assert token.start.line == 1
    assert token.start.column == 1
    assert token.start.index == 0


# Generated at 2022-06-24 11:30:57.036996
# Unit test for method lookup of class Token
def test_Token_lookup():
    # use cases :
    # 1) lookup when the index is empty
    # 2) lookup when the index has items
    # 3) lookup when the index has empty items
    # 4) lookup when the index overflows
    pass


# Generated at 2022-06-24 11:31:02.543361
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(value=False, start_index=0, end_index=0, content="")
    assert token.value == False
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert token.string == ""


# Generated at 2022-06-24 11:31:06.043288
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class SubToken(Token):
        def _get_value(self):
            return self

    token = SubToken(None, 1, 1, "1")
    assert token == token
    assert token != SubToken(None, 1, 1, "1")
    assert token != "1"

# Generated at 2022-06-24 11:31:14.853492
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    first_line = 1
    first_column = 1
    last_line = 1
    last_column = 6
    value = "hello"
    st = ScalarToken(value, 0, 5, content="hello, world!")
    assert (st._value) == value
    assert (st._start_index, st._end_index) == (0, 5)
    assert (st.string) == "hello"
    assert (st.value) == value
    assert (st.start.line, st.start.column, st.start.index) == (first_line, first_column, 0)
    assert (st.end.line, st.end.column, st.end.index) == (last_line, last_column, 5)
    assert (st.lookup([])) == st

# Generated at 2022-06-24 11:31:18.650655
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert repr(Token(None, 0, 0, "")) == "Token('')"
    assert repr(ScalarToken('', 0, 0, "")) == "ScalarToken('')"
    assert repr(DictToken('', 0, 0, "")) == "DictToken('')"
    assert repr(ListToken('', 0, 0, "")) == "ListToken('')"

# Generated at 2022-06-24 11:31:21.815847
# Unit test for constructor of class ListToken
def test_ListToken():
    try:
        token = ListToken([1, 2], 0, 0)
    except Exception as e:
        print("ListToken:", e)

if __name__ == "__main__":
    test_ListToken()

# Generated at 2022-06-24 11:31:30.909525
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class Token(object):
        def __init__(self, string, start_index, end_index, content):
            self._value = string
            self._start_index = start_index
            self._end_index = end_index
            self._content = content

        def _get_key_token(self, key):
            return self

        def _get_child_token(self, key):
            return self

        def _get_value(self):
            return self._value

    from typesystem.base import Position

    # an example of Token and some tests