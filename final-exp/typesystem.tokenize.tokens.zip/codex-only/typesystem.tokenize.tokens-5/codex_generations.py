

# Generated at 2022-06-24 11:21:27.178230
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    dict_value = {"b": 2}
    dict_token = DictToken(dict_value, 0, 0)
    assert dict_token.lookup_key([0]) == dict_token


# Generated at 2022-06-24 11:21:31.721395
# Unit test for constructor of class Token
def test_Token():
    token = Token(value='value', start_index=1, end_index=2, content='content')
    assert token.string == 'value'
    assert token.value == 'value'
    assert token.start._index == 1
    assert token.end._index == 2
    assert repr(token) == "Token('value')"
    assert token == Token(value='value', start_index=1, end_index=2, content='content')

# Generated at 2022-06-24 11:21:34.986734
# Unit test for constructor of class Token
def test_Token():
    token = Token(value = 3, start_index = 1, end_index = 2, content = "123")
    assert token.string == "23"
    assert token.value == None
    assert token.start == None
    assert token.end == None



# Generated at 2022-06-24 11:21:37.856060
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    a = Token("a", 1, 2)
    b = Token("a", 1, 2)
    assert a == b

# Generated at 2022-06-24 11:21:43.021619
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # Check the hash of ScalarToken(0)
    _ScalarToken___hash__00 = ScalarToken(0, 0, 0).__hash__()
    assert _ScalarToken___hash__00 == 0
    # Check the hash of ScalarToken(1)
    _ScalarToken___hash__01 = ScalarToken(1, 0, 0).__hash__()
    assert _ScalarToken___hash__01 == 1

# Generated at 2022-06-24 11:21:51.680472
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test attribute value is not None
    token_value = '+'
    token_start_index = 0
    token_end_index = 0
    token_content = '1+2'
    # Define token_1
    token_1 = Token(token_value, token_start_index, token_end_index, token_content)
    # Define token_2
    token_2 = Token(token_value, token_start_index, token_end_index, token_content)
    # Test the attribute value of token_1 is equal to token_2
    assert token_1.__eq__(token_2)
    # Test attribute value is None
    token_value = None
    token_start_index = 0
    token_end_index = 0
    token_content = '1+2'
    # Define

# Generated at 2022-06-24 11:21:57.008302
# Unit test for constructor of class DictToken
def test_DictToken():
    token_value = "ala"
    start_index = 2
    end_index = 5
    content = "this is a test"
    child_keys = ["a", "b"]
    child_tokens = [1, 2]
    dtoken = DictToken(token_value, start_index, end_index, content)
    assert dtoken._value == token_value
    assert dtoken._start_index == start_index
    assert dtoken._end_index == end_index
    assert dtoken._content == content
    assert dtoken._child_keys == {}
    assert dtoken._child_tokens == {}

# test for _get_value method of class DictToken

# Generated at 2022-06-24 11:22:04.974009
# Unit test for method lookup of class Token
def test_Token_lookup():
    class TestToken(Token):
        def __init__(self, value):
            self.value = value
    test = TestToken(1)
    assert test.value == 1

    class TestToken2(Token):
        def __init__(self, value):
            self.value = value
        def _get_value(self):
            return self.value

    test2 = TestToken2(1)
    assert test2.value == 1

    class TestToken3(Token):
        def __init__(self, value):
            self.value = value
        def _get_value(self):
            return self.value
        def _get_child_token(self, key):
            return self.value[key]
    test3 = TestToken3([1, 2, 3, 4])
    assert test3[0] == 1


# Generated at 2022-06-24 11:22:10.194856
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.base import Scalar

    t1 = ScalarToken(
        Scalar(name='scalar', type=str),
        start_index=1,
        end_index=3,
        content='abc'
    )
    t2 = ScalarToken(
        Scalar(name='scalar', type=str),
        start_index=1,
        end_index=3,
        content='abc'
    )
    t3 = ScalarToken(
        Scalar(name='scalar', type=str),
        start_index=2,
        end_index=3,
        content='abc'
    )

# Generated at 2022-06-24 11:22:10.749697
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    pass

# Generated at 2022-06-24 11:22:23.248611
# Unit test for constructor of class ListToken
def test_ListToken():
    content = "[1, 2, 3, 4, 5]\n"
    tokens = [ScalarToken("1", 0, 1, content=content),
              ScalarToken("2", 3, 4, content=content),
              ScalarToken("3", 6, 7, content=content),
              ScalarToken("4", 9, 10, content=content),
              ScalarToken("5", 12, 13, content=content)]
    index_string_tuple_list = [(0, 1), (3, 4), (6, 7), (9, 10), (12, 13)]
    token = ListToken(tokens, 0, 12, content=content)
    assert token.string == "[1, 2, 3, 4, 5]"
    assert token.value == [1, 2, 3, 4, 5]

# Generated at 2022-06-24 11:22:25.350367
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    s = ScalarToken(1, 1, 1)
    assert hash(s) == hash(1)

# Generated at 2022-06-24 11:22:29.894696
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = Token(None,0,0)
    token.lookup_key([])

# Generated at 2022-06-24 11:22:40.951505
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    content = 'somestring'
    p = Token(None,0,0)
    assert isinstance(p, Token)
    content = 'somestring'
    p = Token(None,0,0)
    assert isinstance(p, Token)
    content = 'somestring'
    p = Token(None,0,0)
    assert isinstance(p, Token)
    content = 'somestring'
    p = Token(None,0,0)
    assert isinstance(p, Token)
    content = 'somestring'
    p = Token(None,0,0)
    assert isinstance(p, Token)
    content = 'somestring'
    p = Token(None,0,0)
    assert isinstance(p, Token)

# Generated at 2022-06-24 11:22:43.723343
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token(token, 1, 2)
    token1 = token.lookup([1])
    assert token1 == token._get_child_token()


# Generated at 2022-06-24 11:22:52.167990
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token("Token", 0, 1, "content")
    token_lookup_1 = token.lookup([0])
    assert isinstance(token_lookup_1, Token)
    assert token_lookup_1.string == "Token"
    assert token_lookup_1.start == Position(1, 1, 0)
    assert token_lookup_1.end == Position(1, 1, 1)

    token_lookup_2 = token.lookup_key([0])
    assert isinstance(token_lookup_2, Token)
    assert token_lookup_2.string == "Token"


# Generated at 2022-06-24 11:22:55.845594
# Unit test for method lookup of class Token
def test_Token_lookup():
    s = "abcd"
    t = ListToken([ScalarToken("a", 0, 0, s), ScalarToken("b", 1, 1, s), ScalarToken("c", 2, 2, s), ScalarToken("d", 3, 3, s)], 0, 3)
    assert t.lookup([3]).value == 'd'


# Generated at 2022-06-24 11:23:00.919389
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(value=42, start_index=0, end_index=1)
    assert hash(token) is not None
    assert isinstance(hash(token), int)


# Generated at 2022-06-24 11:23:05.246337
# Unit test for constructor of class Token
def test_Token():
    test_string = "This is a test"
    t = Token(None, 0, 10, test_string)
    assert t.string == test_string[0:11]
    assert t.start == Position(1, 1, 0)
    assert t.end == Position(1, 11, 10)
    assert repr(t) == "Token('This is a ')"


# Generated at 2022-06-24 11:23:13.330138
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(value=5.0, start_index=1, end_index=2)
    # Check the value of property string
    assert token.string == "5"
    # Check the value of property value
    assert token.value == 5.0
    # Check the value of property start
    assert token.start == Position(line_no=1, column_no=2, index=1)
    # Check the value of property end
    assert token.end == Position(line_no=1, column_no=3, index=2)


# Generated at 2022-06-24 11:23:14.497787
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken("value", 0, 4)
    assert hash(token) == hash("value")


# Generated at 2022-06-24 11:23:16.740198
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    pass

# Generated at 2022-06-24 11:23:17.237021
# Unit test for constructor of class DictToken
def test_DictToken():
    assert 0 == 1

# Generated at 2022-06-24 11:23:22.650284
# Unit test for constructor of class Token
def test_Token():
    function_token = Token('function',3,3)
    assert function_token.string == ''
    assert function_token.value == 'function'
    assert function_token.start.line == 1
    assert function_token.start.column == 1
    assert function_token.start.index == 3
    assert function_token.end.line == 1
    assert function_token.end.column == 1
    assert function_token.end.index == 3


# Generated at 2022-06-24 11:23:35.067901
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from json.decoder import JSONDecoder
    from json.encoder import JSONEncoder
    from json.scanner import py_make_scanner
    from json.scanner import py_scanstring
    from typesystem.base import _enum_value
    from typesystem.base import _get_token_class
    from typesystem.base import _get_type_class
    from typesystem.base import _is_dataclass
    from typesystem.base import _is_enum
    from tests.conftest import fake_decode_item
    from tests.conftest import fake_encode_item
    from tests.conftest import fake_scan_once

    assert fake_decode_item(Token, []) == ()
    assert fake_decode_item(Token, []) == ()

# Generated at 2022-06-24 11:23:37.266208
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token('value', 0, 1, 'content')
    assert token.__repr__() == "Token('content')"


# Generated at 2022-06-24 11:23:43.927532
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token('token1', 0, 1, "token1")
    token._get_value = lambda : 'token1'
    token._get_child_token = lambda key: "token1"
    token._get_key_token = lambda key: "token1"
    index = list()
    assert token.lookup(index) == "token1"
    assert token.lookup_key(index) == "token1"


# Generated at 2022-06-24 11:23:53.234612
# Unit test for constructor of class Token
def test_Token():
    # setup
    value = []
    start_index = 0
    end_index = 0
    content = ""
    token = Token(value, start_index, end_index, content)
    # asserts
    assert token._value == []
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""


# Generated at 2022-06-24 11:24:00.761868
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
   token = ScalarToken("This is a string", 0, len("This is a string"))
   assert isinstance(token, ScalarToken)
   assert token == ScalarToken("This is a string", 0, len("This is a string"))
   assert token.value == "This is a string"
   assert token._get_value() == "This is a string"
   assert token.start == Position(1, 1, 0)
   assert token.end == Position(1, 18, 17)
   assert token.string == "This is a string"

# Unit tests for constructor of class DictToken

# Generated at 2022-06-24 11:24:05.262289
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(
        "a",
        0,
        0,
        """{
        "a": 1,
        "b": 2,
        "c": 3
    }""",
    )
    assert hash(token) == hash("a")


# Generated at 2022-06-24 11:24:10.680642
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    '''
    Unit test for method __repr__ of class Token
    '''
    ctx = {'a':'a', 'a_b':'a_b', '_a_b':'_a_b', 'end_index':1, 'start_index':0, '_content':'a_b', '_value':'a_b'}
    t = Token(**ctx)
    assert t.__repr__() == "Token('a_b')"


# Generated at 2022-06-24 11:24:12.086300
# Unit test for constructor of class Token
def test_Token():
    assert Token('value', 1, 2, '')


# Generated at 2022-06-24 11:24:20.719235
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    t = DictToken({"a":[DictToken({0: ScalarToken(1, 0, 1), 1: ScalarToken(2, 0, 1)}, 0, 1)]}, 0, 1, "{\"a\":[{0:1,1:2}]}")
    print(t._get_value()["a"][0]._get_value()[0])
    print(t.lookup_key([0,'a',0,0]))
    print(t)
    print(t.lookup_key([0,'a',0,0]))
    print(t.lookup_key([0,'a',0,1]))
    print(t._get_key_token("a"))

# Generated at 2022-06-24 11:24:30.664592
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # !BEGIN!: Do not edit code between !BEGIN! and !END! tags.
    # pyre-strict-optional-whitelist
    from typesystem.types import Type
    from typesystem.validators import Enum
    from typesystem.validators import MinMax

    type_ = Type(
        validators=[Enum(["a", "b", "c"]), MinMax(min_value=0, max_value=100)]
    )
    input = {"a": 1, "b": "name", "c": ""}
    tokens = type_.validate(input)
    value = tokens[0]
    assert value.value == {"a": 1, "b": "name", "c": ""}
    assert value.start == 1
    assert value.end == 3

# Generated at 2022-06-24 11:24:33.882009
# Unit test for method lookup of class Token
def test_Token_lookup():
    input = "{}"
    parser = Parser()
    token, _ = parser.parse(input)
    assert token.lookup([]) == token
    assert token.lookup([]) != None


# Generated at 2022-06-24 11:24:35.537747
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a":"b"}, 0, 1)
    token._get_value()


# Generated at 2022-06-24 11:24:39.261966
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken([1,2,3], 3, 5)
    assert d._get_value() == [1,2,3]
    assert d._start_index == 3
    assert d._end_index == 5


# Generated at 2022-06-24 11:24:47.430116
# Unit test for method lookup of class Token
def test_Token_lookup():
    content = "hello world"
    token = ScalarToken(
        "hello world", start_index=0, end_index=len(content) - 1, content=content
    )
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    with pytest.raises(KeyError):
        token.lookup([0])
    with pytest.raises(KeyError):
        token.lookup_key([0])

    content = "hello world"
    token = ListToken(
        ["hello", "world"], start_index=0, end_index=len(content) - 1, content=content
    )
    assert token.lookup([]) == token
    with pytest.raises(KeyError):
        token.lookup_key([])

# Generated at 2022-06-24 11:24:52.151061
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token
    t1 = token(1, 2, 3)
    t2 = token(1, 2, 4)
    t3 = token(1, 2, 3)
    t4 = token(2, 2, 3)
    assert t1 == t2
    assert t1 == t3
    assert t1 != t4

# Generated at 2022-06-24 11:24:58.457705
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    d=DictToken({"key": "value"}, 0, 8)
    result=d.lookup_key(["key"])
    assert repr(result) == 'ScalarToken(\'value\')'

# Generated at 2022-06-24 11:25:03.263395
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    test = ScalarToken(10, 2, 5)
    assert test._value == 10
    assert test._start_index == 2
    assert test._end_index == 5
    assert test._content == ""
    assert test.value == 10
    assert test.start == Position(1, 3, 2)
    assert test.end == Position(1, 6, 5)
    assert test.string == "10"
    assert str(test) == "ScalarToken('10')"
    assert test == ScalarToken(10, 2, 5)
    assert test == ScalarToken(10, 2, 5, "")


# Generated at 2022-06-24 11:25:06.574815
# Unit test for constructor of class DictToken
def test_DictToken():
  token = DictToken(2, 3, 4, 5, 6)



# Generated at 2022-06-24 11:25:17.781729
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    content1 = "123"
    start_index1 = 1
    end_index1 = 3
    value1 = "2"
    tok_1 = ScalarToken(value1, start_index1, end_index1, content1)
    assert tok_1.string == "2"
    assert tok_1.value == "2"
    assert tok_1.start == Position(1, 2, 1)
    assert tok_1.end == Position(1, 3, 2)
    assert tok_1.__repr__() == "ScalarToken('2')"
    assert tok_1.__eq__(ScalarToken(value1, start_index1, end_index1, content1))
    assert tok_1.lookup([0]) == tok_1
    assert tok

# Generated at 2022-06-24 11:25:25.332810
# Unit test for constructor of class DictToken
def test_DictToken():
  st = DictToken({
    "test1": "test2"
  }, 1, 4)

  assert st._start_index == 1
  assert st._end_index == 4
  assert st._content == ""
  assert st._value == {
    "test1": "test2"
  }


# Generated at 2022-06-24 11:25:34.922839
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    content = "Abc"
    value = "Abc"
    start_index = 0
    end_index = 2
    token = ScalarToken(value, start_index, end_index, content)
    # Test for __init__
    assert token._value == value
    assert token._start_index == start_index
    assert token._end_index == end_index
    assert token._content == content
    assert token.value == value
    assert token.start.column == start_index + 1
    assert token.start.line == 1
    assert token.end.column == end_index + 1
    assert token.end.line == 1
    assert token.string == content
    assert token.lookup([]) == token
    # Test for __eq__

# Generated at 2022-06-24 11:25:36.292223
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Code to test __repr__ of class Token
    pass

# Generated at 2022-06-24 11:25:36.863238
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    return None

# Generated at 2022-06-24 11:25:42.980085
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test case : equality of two tokens
    token_1 = ScalarToken("My value", 1, 2, content="String content")
    token_2 = ScalarToken("My value", 1, 2, content="String content")
    assert token_1 == token_2
    # Test case : inequality of two tokens
    token_3 = ScalarToken("My value", 2, 3, content="String content")
    assert token_3 != token_2
    # Test case : inequality of token with other object
    assert token_3 != "My value"



# Generated at 2022-06-24 11:25:44.906727
# Unit test for constructor of class Token
def test_Token():
    t = Token(5,6,7,"Dhruv")
    assert t.value == 5
    assert t.start_index == 6
    assert t.end_index == 7
    assert t.content == "Dhruv"



# Generated at 2022-06-24 11:25:45.888549
# Unit test for constructor of class ListToken
def test_ListToken():
    pass


# Generated at 2022-06-24 11:25:54.813451
# Unit test for constructor of class Token
def test_Token():
    content = '{"a":1, "b":[1,2,3], "c":2}'
    start_index = len("{")
    end_index = len("{a:1, b:[1,2,3], c:2}") - 1
    value = {"a":1, "b":[1,2,3], "c":2}
    t = Token(value, start_index, end_index, content)
    assert t.value == value
    assert t.string == content[start_index:end_index+1]
    assert t.start == Position(line=1, column=1, offset=start_index)
    assert t.end == Position(line=1, column=end_index+1, offset=end_index)
    assert t.lookup([0]) == value["a"]


# Unit

# Generated at 2022-06-24 11:25:56.591665
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert ScalarToken('', 0, 0, '').__hash__() == hash('')


# Generated at 2022-06-24 11:26:05.066574
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    l1_l1 = ScalarToken("l1_l1", 0, 4)
    l1_l2 = ScalarToken("l1_l2", 5, 9)
    l1_l3 = ScalarToken("l1_l3", 10, 14)
    l1_l4 = ScalarToken("l1_l4", 15, 19)
    l1_l5 = ScalarToken("l1_l5", 20, 24)
    l1_l6 = ScalarToken("l1_l6", 25, 29)
    l1_l7 = ScalarToken("l1_l7", 30, 34)
    l1_l8 = ScalarToken("l1_l8", 35, 39)

# Generated at 2022-06-24 11:26:06.367267
# Unit test for constructor of class DictToken
def test_DictToken():
    assert True == True

# Generated at 2022-06-24 11:26:09.443378
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token(0.0,0,0,"")
    assert str(token) == "Token(0.0)"
    return


# Generated at 2022-06-24 11:26:16.785118
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    value = "is the value"
    start_index = 0
    end_index = 12
    content = "This is the value"
    scalartoken = ScalarToken(value, start_index, end_index, content)
    assert hash(scalartoken) == hash(value)

# Generated at 2022-06-24 11:26:25.293838
# Unit test for constructor of class ListToken
def test_ListToken():
    l = [1,2,3]
    p1 = Position(1,1,1)
    p2 = Position(1,1,2)
    p3 = Position(1,1,3)
    v1 = ScalarToken(1,1,2,'123')
    v2 = ScalarToken(2,2,3,'123')
    v3 = ScalarToken(3,3,3,'123')
    vl = [v1,v2,v3]
    lt = ListToken(l,1,3,'123')
    assert lt.value == [1,2,3]
    assert lt.start == p1
    assert lt.end == p3
    assert lt.string == '123'
    assert lt.lookup([1]) == v2
    assert lt._get_

# Generated at 2022-06-24 11:26:27.089890
# Unit test for constructor of class Token
def test_Token():
    token = Token("value", "start_index", "end_index", "content")



# Generated at 2022-06-24 11:26:28.563103
# Unit test for constructor of class ListToken
def test_ListToken():
    ListToken()._get_value()
    

# Generated at 2022-06-24 11:26:36.970650
# Unit test for method lookup of class Token
def test_Token_lookup():
    from .tokenizer import Tokenizer

    expr = "[1, 2]"
    tokens = [t._get_value() for t in Tokenizer(expr).tokenize()]
    assert tokens[0].lookup([0]) == tokens[1]
    assert tokens[0].lookup([1]) == tokens[2]

    expr = "[1, [2]]"
    tokens = [t._get_value() for t in Tokenizer(expr).tokenize()]
    assert tokens[0].lookup([1, 0]) == tokens[3]

    expr = '{"name": "foo"}'
    tokens = [t._get_value() for t in Tokenizer(expr).tokenize()]
    assert tokens[0].lookup(["name"]) == tokens[3]

    expr = '{"name": ["foo"]}'

# Generated at 2022-06-24 11:26:38.685078
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    obj = ScalarToken('')
    print(obj.__hash__())

# Generated at 2022-06-24 11:26:50.238614
# Unit test for constructor of class Token
def test_Token():
    value=1
    start_index=1
    end_index=2
    content=""
    token=Token(value,start_index,end_index,content)
    assert token.string == ""
    assert token.value == None
    assert token.start == Position(1,1,1)
    assert token.end == Position(1,1,2)
    assert token.lookup([]) == None
    assert token.lookup_key([]) == None
    assert token._get_value() == None
    assert token._get_child_token(None) == None
    assert token._get_key_token(None) == None
    assert token.__repr__() == "Token('')"
    assert token.__eq__(token) == True


# Generated at 2022-06-24 11:26:53.929777
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken([1, 2, 3], 0, 1)
    assert token._value == [1, 2, 3]
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == ""


# Generated at 2022-06-24 11:26:56.222926
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = ScalarToken("hello", 1, 2)
    t2 = ScalarToken("hello", 1, 2)
    assert t1 == t2



# Generated at 2022-06-24 11:27:01.191302
# Unit test for constructor of class ListToken
def test_ListToken():
  tk = ListToken(
    value=[1, 2],
    start_index=0,
    end_index=2,
    content="123456"
  )
  assert tk.string == "12"
  assert tk.value == [1, 2]
  assert tk.start == Position(1, 1, 0)
  assert tk.end == Position(1, 3, 2)

# Generated at 2022-06-24 11:27:14.858612
# Unit test for constructor of class ListToken
def test_ListToken():
    content = "some string"
    start_index = 2
    end_index = 5
    value = [
        ScalarToken(1, start_index, end_index, content),
        ScalarToken(2, start_index, end_index, content),
        ScalarToken(3, start_index, end_index, content),
    ]

    token = ListToken(value, start_index, end_index, content)
    assert token.string == "some string"[start_index: end_index+1]
    assert token.value == [1, 2, 3]
    assert token.start.column == 3
    assert token.start.line == 1
    assert token.start.index == start_index
    assert token.end.column == 6
    assert token.end.line == 1
    assert token.end.index == end

# Generated at 2022-06-24 11:27:24.867906
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, 1, 2)
    assert token == token
    assert not (token != token)
    assert not (None == token)
    assert None != token
    assert token.__eq__(None) is NotImplemented
    token1 = Token(1, 1, 2)
    token2 = Token(2, 1, 2)
    assert not (token1 == token2)
    assert token1 != token2
    assert token1.__eq__(token2) is NotImplemented
    token3 = Token(1, 2, 3)
    assert not (token1 == token3)
    assert token1 != token3
    token4 = Token(1, 1, 2, content="  ")
    assert not (token1 == token4)
    assert token1 != token4

# Generated at 2022-06-24 11:27:33.865435
# Unit test for constructor of class DictToken
def test_DictToken():
    from Tokenizer import DictToken
    from ScalarToken import ScalarToken
    # test empty dict
    value = {}
    start = 0
    end = 0
    content = ""
    exp_token = DictToken(value, start_index=start, end_index=end, content=content)
    assert(exp_token._value == value)
    assert(exp_token._start_index == start)
    assert(exp_token._end_index == end)
    assert(exp_token._content == content)
    # test normal dict
    value = {ScalarToken(0, 2, 5): ScalarToken(1, 12, 14)}
    start = 0
    end = 20
    content = "hello world, nice to meet you!"

# Generated at 2022-06-24 11:27:42.395899
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token("1", 1, 0, "1") == Token("1", 1, 0, "1")
    assert not Token("1", 1, 0, "1") == "1"
    assert not Token("1", 1, 0, "1") == Token("2", 1, 0, "2")
    assert not Token("1", 1, 0, "1") == Token("1", 2, 0, "1")
    assert not Token("1", 1, 0, "1") == Token("1", 1, 1, "1")
    assert Token("1", 1, 0, "1") != "1"
    assert Token("1", 1, 0, "1") != Token("2", 1, 0, "2")
    assert Token("1", 1, 0, "1") != Token("1", 2, 0, "1")
    assert Token

# Generated at 2022-06-24 11:27:48.137842
# Unit test for constructor of class Token
def test_Token():
    value = 1
    start_index = 5
    end_index = 10
    content = "asdfghijkl"
    token = Token(value, start_index, end_index, content)
    assert token._value == value
    assert token._start_index == start_index
    assert token._end_index == end_index
    assert token._content == content
    assert token.string == "fghij"


# Generated at 2022-06-24 11:27:56.826593
# Unit test for method lookup of class Token
def test_Token_lookup():
    from typesystem.tokenizer import Tokenizer

    def check(input, index, output):
        obj = Tokenizer(input).next()
        if isinstance(index, str):
            key = int(index) if index.isdigit() else index
            result = obj.lookup_key(["data", key])._value
        else:
            key = index
            result = obj.lookup(["data"] + index)._value
        assert result == output, f"{result} != {output}"

    check({"data": {"a": 1}}, "a", 1)
    check({"data": [1, 2, 3]}, 0, 1)
    check({"data": [{"a": 1}, {"a": 2}]}, 0, {"a": 1})

# Generated at 2022-06-24 11:28:05.001646
# Unit test for constructor of class DictToken
def test_DictToken():
    _dict = {'name':'dog','age':'5'}
    DictToken(_dict, 0, 2, '{"name": "dog", "age": "5"}')
    assert DictToken.value == {'name':'dog','age':'5'}
    assert DictToken.start.line == 1
    assert DictToken.start.column == 10
    assert DictToken.end.line == 2
    assert DictToken.end.column == 2
    assert DictToken.string == '{"name": "dog", "age": "5"}'


# Generated at 2022-06-24 11:28:16.164115
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    string = "{'a': int, 'b': int}"
    token = parse(string)
    assert token.lookup_key([2, 1]) == ListToken(
        int, 10, 11, string
    )
    assert token.lookup_key([3, 2]) == ListToken(
        str, 15, 16, string
    )
    assert token.lookup_key([4, 1]) == ListToken(
        int, 19, 20, string
    )
    assert token.lookup_key([0, 2]) == ListToken(
        str, 5, 6, string
    )
    assert token.lookup_key([1, 2]) == ListToken(
        str, 9, 10, string
    )

# Generated at 2022-06-24 11:28:18.473326
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken('1', '2', '3')
    assert token.value == '[1, 2, 3]'


# Generated at 2022-06-24 11:28:22.459024
# Unit test for constructor of class ListToken
def test_ListToken():
    test_list = ListToken(1,2,3)
    assert test_list.value == [1,2,3]
    assert test_list.start == Position(0,0,0)
    assert test_list.end == Position(0,0,0)



# Generated at 2022-06-24 11:28:30.910396
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # simple cases
    assert ScalarToken(1,0,0) == ScalarToken(1,0,0)
    assert ScalarToken('key',2,2) == ScalarToken('key',2,2)
    assert DictToken({},0,0) == DictToken({},0,0)
    assert ListToken([],0,0) == ListToken([],0,0)

    # we have an issue with None values.
    assert ScalarToken(None,0,0) != ScalarToken(None,0,0)
    # seems like python has an issue comparing instances with different execution enviroment.
    assert ScalarToken(None,0,0) == ScalarToken(None,0,0)

    assert ScalarToken(None,0,0) != ScalarToken(None,1,1)

    #

# Generated at 2022-06-24 11:28:35.582355
# Unit test for constructor of class Token
def test_Token():
    token = Token({"a":True}, 0, 1)
    assert token.start == Position(1,1,0)
    assert token.end == Position(1,2,1)
    assert token.string == "{"
    assert token.value == {"a":True}
    assert token.lookup([0]) == {"a":True}
    assert token.lookup_key([0,0]) == True


# Generated at 2022-06-24 11:28:42.864690
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    value = 'this_is_the_value_of_the_token'
    start_index = 0
    end_index = len(value)
    token1 = Token(value, start_index, end_index)
    token2 = Token(value, start_index, end_index)
    assert token1.__eq__(token2)
    assert token1.__eq__(token1)


# Generated at 2022-06-24 11:28:45.673858
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert Token(None, None, None, None).__repr__() == "Token(None)"

# Generated at 2022-06-24 11:28:57.872542
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # the class under testing
    class DictToken(Token):
        def _get_value(self) -> typing.Any:
            return 'this is the value'

        def _get_child_token(self, key: typing.Any) -> Token:
            return 'this is the child token'

        def _get_key_token(self, key: typing.Any) -> Token:
            return 'this is the key token'

    d = {'a': 1, 'b': 2}
    i = ['a']
    dt = DictToken(d, 12, 15, 'a=1;b=2')
    assert dt.lookup_key(i) == 'this is the key token'

## Unit test for method lookup of class Token

# Generated at 2022-06-24 11:28:59.622109
# Unit test for constructor of class Token
def test_Token():
    Token(1, 2, 3, 'test')

# Generated at 2022-06-24 11:29:04.460027
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(value=None, start_index=0, end_index=4)
    assert token.value == None
    assert token.string == "None"
    assert token.start.line_no == 1
    assert token.start.column_no == 1
    assert token.end.line_no == 1
    assert token.end.column_no == 5


# Generated at 2022-06-24 11:29:07.660129
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # arrange
    args = [1, 2, 3, ""]
    kwargs = {}

    # act
    token = ScalarToken(*args, **kwargs)

    # assert
    assert(token.__hash__() == hash(1))


# Generated at 2022-06-24 11:29:09.273916
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    test = ScalarToken("", 0, 0)
    result = test.__hash__()
    assert result == hash("")



# Generated at 2022-06-24 11:29:16.007405
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # Test for method __hash__ of class ScalarToken
    #
    # This test checks that the __hash__ method of ScalarToken returns a hash
    # value identical to other values that Python considers to be equal
    #
    # The ScalarToken has a __eq__ implementation that takes into account the
    # underlying value and the token itself. However it is common practice to
    # ignore the token information while hashing, as Python's default hash
    # implementation will only consider the underlying value.
    #
    # The test creates two identical Strings, each wrapped in a ScalarToken with
    # different positions, creating two different tokens. However, it's still
    # equal to the underlying Python object, and therefore the hash value
    # returned by the __hash__ method should be the same.
    a = ScalarToken("a", 0, 0)
    b = Scal

# Generated at 2022-06-24 11:29:19.020270
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # Given
    T = typing.TypeVar("T")
    token = ScalarToken(T, 0, 0)

    # When
    result = token.__hash__()

    # Then
    assert result == hash(token._value)


# Generated at 2022-06-24 11:29:22.896727
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    obj = ScalarToken(
        value=42,
        start_index=10,
        end_index=50,
        content="""This is a multi-line
content""",
    )
    assert hash(obj) == hash(42)

# Generated at 2022-06-24 11:29:28.384998
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = ScalarToken(123,1,3)
    token2 = ScalarToken(123,1,3)
    token3 = ScalarToken(123,2,3)
    assert token1 == token2
    assert not (token1 == token3)


# Generated at 2022-06-24 11:29:31.196699
# Unit test for constructor of class Token
def test_Token():
	a = Token(1, 2, 3)
	assert a._value == 1
	assert a._start_index == 2
	assert a._end_index == 3
	assert a._content == ""


# Generated at 2022-06-24 11:29:45.977836
# Unit test for constructor of class DictToken
def test_DictToken():
    def constructor(value: typing.Any, start_index: int, end_index: int, content: str = "") -> None:
        self._value = value
        self._start_index = start_index
        self._end_index = end_index
        self._content = content

    assert constructor({"a": 1, "b": 2, "c": 3}, 1, 2, "") == None
    assert constructor({"a": 1, "b": 2, "c": 3}, 1, 2, "") != 1
    assert constructor({"a": 1, "b": 2, "c": 3}, 1, 2, "") != "b"
    assert constructor({"a": 1, "b": 2, "c": 3}, 1, 2, "") != 2.0


# Generated at 2022-06-24 11:29:48.492455
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 1, 1)
    token2 = Token(token1, 1, 1)
    assert (token1 == token2)

# Generated at 2022-06-24 11:29:51.407834
# Unit test for constructor of class Token
def test_Token():
    a = Token(1, 2, 3, 'a')
    assert a._value == 1
    assert a._start_index == 2
    assert a._end_index == 3
    assert a._content == 'a'


# Generated at 2022-06-24 11:30:01.536963
# Unit test for constructor of class Token
def test_Token():
    token = Token(1, 1, 1, "test")
    assert token._value == 1 and token.start_index == 1 and token.end_index == 1
    assert token.content == "test" and token.string == "test" and token.value == token._value
    assert token.start.line_no == 1 and token.end.line_no == 1
    assert token.start.column_no == 1 and token.end.column_no == 1
    assert token.start.index == 1 and token.end.index == 1
    assert token.lookup([0]) and token.lookup_key([0])
    assert token.__repr__ and token.__eq__


# Generated at 2022-06-24 11:30:07.940876
# Unit test for constructor of class DictToken
def test_DictToken():
    t1 = {"a": "b"}
    t2 = {"a": "c"}
    t3 = {"a": "b", "b": "c"}
    assert(DictToken(t1,0,0) == DictToken(t1,0,0))
    assert(DictToken(t1,0,0) != DictToken(t2,0,0))
    assert(DictToken(t1,0,0) != DictToken(t3,0,0))
    # TODO: check _child_token and _child_key


# Generated at 2022-06-24 11:30:14.203957
# Unit test for constructor of class DictToken
def test_DictToken():
  # Set up some parameters
  start_index = 2
  end_index = 3
  content = ""

  a = ScalarToken(5, start_index, end_index, content)
  b = ScalarToken(6, start_index, end_index, content)
  c = ScalarToken(7, start_index, end_index, content)
  d = ScalarToken(8, start_index, end_index, content)
  my_dict = {a:b, c:d}

  test = DictToken(my_dict, start_index, end_index, content)
  return True

# Generated at 2022-06-24 11:30:17.000004
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken(value=[], start_index=0, end_index=0)
    assert(token)



# Generated at 2022-06-24 11:30:28.700691
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    content = ' some_content '
    start_index = 1
    end_index = len(content) - 2
    
    # Create two instances with different values and hash them
    my_instance_1 = Token(value='instance_1', start_index=start_index, end_index=end_index, content=content)    
    my_instance_2 = Token(value='instance_2', start_index=start_index, end_index=end_index, content=content)
    assert (my_instance_1.__eq__(my_instance_1) == True)
    assert (my_instance_1.__eq__(my_instance_2) == False)
    assert (my_instance_2.__eq__(my_instance_1) == False)

# Generated at 2022-06-24 11:30:31.210142
# Unit test for constructor of class DictToken
def test_DictToken():
    i = DictToken({}, 0, 1, "")

# Generated at 2022-06-24 11:30:33.950343
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    t = ScalarToken(1, 1, 1)
    assert hash(t) == 1

test_ScalarToken___hash__()


# Generated at 2022-06-24 11:30:39.923820
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    start_position = Position(1, 1, 1)
    end_position = Position(1, 6, 6)
    token = Token({"abc": 123}, 0, 5, content="{abc: 123}")
    # The first parameter of assertEqual is the actual value, the second parameter
    # is the expected value. You can also use assertNotEqual, assertTrue and 
    # assertFalse instead of assertEqual.
    assert token == token, 'actual value should be equal to expected value'


# Generated at 2022-06-24 11:30:44.397231
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    # Test with empty string
    token = ScalarToken(
        value="", start_index=0, end_index=0, content=""
    )
    assert token.string == ""
    assert token.value == ""
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)



# Generated at 2022-06-24 11:30:46.745932
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    assert Token(None, None, None, None).lookup_key(None) == None

# Generated at 2022-06-24 11:30:57.044141
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(
        value=20, start_index=3, end_index=3, content="Hello 20"
    )
    assert str(token.value) == "20"
    assert str(token.start) == "1:4"
    assert str(token.end) == "1:4"
    assert str(token) == "ScalarToken('20')"
    assert str(token) == repr(token)


# Generated at 2022-06-24 11:31:02.123055
# Unit test for constructor of class DictToken
def test_DictToken():
    class _Token(Token):
        pass
    dct = {
        _Token(1, 0, 0): _Token(2, 0, 0),
        _Token(3, 0, 0): _Token(4, 0, 0),
    }
    token = DictToken(dct, 0, 0, "")
    assert token._child_keys
    assert token._child_tokens

# Generated at 2022-06-24 11:31:11.873811
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from typesystem.base import Invalid

    class Token:
        def __init__(self, value, start, end, content=None):
            self.value = value
            self.start_index = start
            self.end_index = end
            self.content = content

        def lookup_key(self, index: list) -> "Token":
            return self

    class InvalidToken(Token):
        @property
        def value(self) -> typing.Any:
            raise Invalid(self.start, self.end, "not valid")

    def test_valid(tokens, token, index):
        assert token.lookup_key(index) is tokens[index]

    def test_invalid(tokens, token, index):
        from typesystem.base import Invalid, ValidationError


# Generated at 2022-06-24 11:31:14.452164
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert Token.__repr__(Token(42, 2, 5, "Hello World")) == "Token('llo')"



# Generated at 2022-06-24 11:31:18.475854
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    value = 'token'
    start_index = 0
    end_index = 3
    sub_token = Token(value, start_index, end_index)
    assert sub_token.__repr__() == 'Token(\'token\')'


# Generated at 2022-06-24 11:31:28.514433
# Unit test for constructor of class ListToken
def test_ListToken():
    class Tokenstub:
        def __init__(self, value: typing.Any, start_index: int, end_index: int, content: str = '') -> None:
            self._value = value
            self._start_index = start_index
            self._end_index = end_index
            self._content = content;
        def __eq__(self, other):
            return isinstance(other, Tokenstub) and (
                self._value == other._value and self._start_index == other._start_index and self._end_index == other._end_index
            )

    ListToken([Tokenstub(1, 0, 1, '[]'), Tokenstub(2, 0, 1, '[]')], 0, 1, '[]')
