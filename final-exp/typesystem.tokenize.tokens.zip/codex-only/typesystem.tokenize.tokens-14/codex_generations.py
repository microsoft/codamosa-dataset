

# Generated at 2022-06-24 11:21:26.172084
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.types import Dict

    dict_type = Dict({"a": int, "b": str})
    token = DictToken({"a": 3, "b": "b"}, 0, 100)
    assert isinstance(token._value["a"], ScalarToken)
    assert isinstance(token._value["b"], ScalarToken)
    # assert isinstance(token._child_keys["a"], ScalarToken)
    # assert isinstance(token._child_tokens["b"], ScalarToken)
    # assert token.value == {"a": 3, "b": "b"}


# Generated at 2022-06-24 11:21:27.317309
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert ScalarToken(
        1, 0, 0
    ).__hash__() == hash(1)


# Generated at 2022-06-24 11:21:37.096365
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    d = {1: {'two': "T", 'three': "T", 'four': "T"}}
    l = [{'one': "O", 'two': "T", 'three': "T", 'four': "T"}]
    index = [0, 1]
    assert {'one': "O", 'two': "T", 'three': "T", 'four': "T"} == l[index[0]][index[1]]
    assert index[1] == 1
    assert d == l[0] == {'one': "O", 'two': "T", 'three': "T", 'four': "T"}
    assert d[1] == {'two': "T", 'three': "T", 'four': "T"}
    assert index[:1] == [0]

# Generated at 2022-06-24 11:21:46.673986
# Unit test for method lookup of class Token
def test_Token_lookup():
    content = """
def_dict = {'a': 1, 'b': 2, 'c': 3}
def_list = [1, 2, 3]
"""
    parse_tree = """
(dict
   (def_dict = (dict (a: (int 1)) , (b: (int 2)) , (c: (int 3))))
   (def_list = (list (int 1) , (int 2) , (int 3))))
"""
    tree = ast.parse(parse_tree)
    value = conversion.convert(tree)
    start_index = content.find("def_dict")
    end_index = content.find("def_list")
    token = DictToken(value, start_index, end_index, content)

# Generated at 2022-06-24 11:21:48.763104
# Unit test for constructor of class DictToken
def test_DictToken():
  s=DictToken({1:2},0,1)
  assert(s._child_tokens=={1:2})


# Generated at 2022-06-24 11:21:56.365535
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    testDict = dict()
    testDict['a'] = 1
    testDict['b'] = dict()
    testDict['b']['c'] = 2
    testDict['b']['d'] = 3

    testToken = DictToken(testDict, 0, 0)
    # test for key of root dict
    assert testToken.lookup_key([0]).value == 1
    assert testToken.lookup_key([1]).value == {'c': 2, 'd': 3}
    # test for key of child dict
    assert testToken.lookup_key([1, 0]).value == 2
    assert testToken.lookup_key([1, 1]).value == 3

    testList = [1,'abc',dict()]
    testList[2]['a'] = 2

# Generated at 2022-06-24 11:21:59.516021
# Unit test for constructor of class Token
def test_Token():
    start_index = 2
    end_index = 10
    content = "This is a test"
    test = Token(None, start_index, end_index, content)
    assert test._start_index == start_index
    assert test._end_index == end_index
    assert test._content == content
    

# Generated at 2022-06-24 11:22:06.696844
# Unit test for method lookup of class Token
def test_Token_lookup():
    import json
    import unittest
    from tests.schema import test_schema
    s = test_schema()
    v = json.loads("""{
            "a": ["b", "c"],
            "b": "ok"
        }""")
    schema = s.schema

    b_idx = [("a", 0)]
    b_token = s.token.lookup(b_idx)
    assert b_token.value == "b"

    c_idx = [("a", 1)]
    c_token = s.token.lookup(c_idx)
    assert c_token.value == "c"

    b_str_idx = [("b",)]
    b_str_token = s.token.lookup(b_str_idx)
    assert b_

# Generated at 2022-06-24 11:22:17.888945
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Create a variable Token for for testing
    value = 'Foo'
    start_index = 1
    end_index = 3

    # Create a Token
    token = ScalarToken(value, start_index, end_index)

    # Create a variable scalar_token for for testing
    scalar_token = ScalarToken(value, start_index, end_index)

    # Create a variable printed_token for for testing
    printed_token = token

    # Create a variable printed_scalar_token for for testing
    printed_scalar_token = scalar_token

    # Check that token == scalar_token is True
    assert token == scalar_token

    # Check that printed_token == printed_scalar_token is True
    assert printed_token == printed_scalar_token


# Generated at 2022-06-24 11:22:25.479047
# Unit test for constructor of class Token
def test_Token():
    assert Token(
        value = None,
        start_index = 0,
        end_index = 0,
        content = ""
    )


# Generated at 2022-06-24 11:22:31.335152
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # Arrange
    value = ""
    start_index = 0
    end_index = 0
    content = ""
    scalar_token = ScalarToken(value, start_index, end_index, content)

    # Act
    result = scalar_token.__hash__()

    # Assert
    assert hash(value) == result

# Generated at 2022-06-24 11:22:40.391604
# Unit test for constructor of class Token
def test_Token():
    t = Token(2, 3, 5, "12345")
    assert t.string == "3"
    assert not hasattr(t, "value")
    assert t.start == Position(1, 2, 3)
    assert t.end == Position(1, 3, 4)
    assert t.lookup([]) == t
    assert t.lookup_key([]) == t
    assert repr(t) == "Token('3')"
    assert t == Token(2, 3, 5, "12345")
    assert not t == 3
    assert t == Token(2, 3, 5, "12345")
    assert not t == 3

# Generated at 2022-06-24 11:22:48.762649
# Unit test for constructor of class DictToken
def test_DictToken():
    # constructor for DictToken
    list_test_1 = [1, 2, 3]
    list_test_2 = [4, 5, 6]
    dict_test = {list_test_1: list_test_2}
    dict_token = DictToken(dict_test, 0, 1)
    # test method _get_value
    assert dict_token._get_value() == dict_test
    # test method _get_child_token
    assert dict_token._get_child_token(list_test_1) == list_test_2
    # test method _get_key_token
    assert dict_token._get_key_token(list_test_1) == list_test_1
    # test method __eq__
    assert dict_token == dict_token
    assert dict_token != None

#

# Generated at 2022-06-24 11:22:53.930167
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken([1, 2, 3], 0, 1, '12') == ListToken([1, 2, 3], 0, 1, '12')
    assert ListToken([1, 2, 3], 2, 3, '1,2,3') == ListToken([1, 2, 3], 2, 3, '1,2,3')
    assert ListToken([1, 2, 3], 4, 5, '3') != ListToken([1, 2, 3], 5, 6, '2')



# Generated at 2022-06-24 11:22:59.989539
# Unit test for constructor of class ListToken
def test_ListToken():
	lst = ListToken(
		[1, 2, 3],
		start_index=0,
		end_index=2,
		content="123"
	)
	assert lst._start_index == 0
	assert lst._end_index == 2
	assert lst._content == "123"
	assert lst._value == [1, 2, 3]

# Generated at 2022-06-24 11:23:02.357543
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = Token(1, 2, 51, 'a:b:c')
    index = [0, 'b']
    token.lookup_key(index)

# Generated at 2022-06-24 11:23:05.286384
# Unit test for constructor of class ListToken
def test_ListToken():
    a = ListToken(value = 1, start_index = 0, end_index = 1)
    assert a._value == 1
    assert a._start_index == 0
    assert a._end_index == 1



# Generated at 2022-06-24 11:23:08.422530
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert ScalarToken(0, 0, 0).__hash__() == hash(0)



# Generated at 2022-06-24 11:23:16.085909
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from unittest import mock
    from typesystem.base import Token as Token_base

    obj1 = Token_base([0, 1, 2], "")
    obj2 = Token_base([0, 1, 2], "")
    obj3 = Token_base([0, 1, 3], "")
    assert obj1 == obj1
    assert obj1 == obj2
    assert not obj1 == obj3

    class Foo:
        pass

    assert not obj1 == Foo()
    assert not obj1 == mock.Mock()
    assert not obj1 == Exception()
    assert not obj1 == KeyError()
    assert not obj1 == 1
    assert not obj1 == "0"


# Generated at 2022-06-24 11:23:25.480663
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken(["token1"],1,5,"token1token2")._value == ["token1"]
    assert ListToken(["token1"],1,5,"token1token2")._start_index == 1
    assert ListToken(["token1"],1,5,"token1token2")._end_index == 5
    assert ListToken(["token1"],1,5,"token1token2")._content == "token1token2"
    assert ListToken(["token1"],1,5,"token1token2").string == "token1"
    assert ListToken(["token1"],1,5,"token1token2").value == ["token1"]
    assert ListToken(["token1"],1,5,"token1token2").start == Position(1,1,1)

# Generated at 2022-06-24 11:23:30.754593
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    content = "hello"
    token = ScalarToken(content, 0, 4, content)
    assert token.string == content
    assert token.value == content
    assert token.start.line == 1
    assert token.start.column == 1
    assert token.start.index == 0
    assert token.end.line == 1
    assert token.end.column == 5
    assert token.end.index == 4
    assert repr(token) == "ScalarToken('hello')"



# Generated at 2022-06-24 11:23:36.667243
# Unit test for constructor of class ListToken
def test_ListToken():
    pos = Position(1,2,3)
    list = ListToken("val", 4, 5, "content")
    assert list.string == "val"
    assert list.value == "val"
    assert list.start == pos
    assert list.end == pos
    assert list.lookup(4) == list
    assert list.lookup(5) == list


# Generated at 2022-06-24 11:23:38.680114
# Unit test for constructor of class ListToken
def test_ListToken():
    a = ListToken(value = 1, start_index = 1, end_index = 2)
    assert a._value == 1


# Generated at 2022-06-24 11:23:46.101902
# Unit test for method lookup of class Token
def test_Token_lookup():
    from typesystem.base import String
    from typesystem.constructor import Constructor
    from typesystem.parser.parser import Parser

    schema = String(pattern="[0-9]*")
    c = Constructor(schema)
    p = Parser(c)
    expression = "12345"
    t = p.parse(expression)
    assert t.lookup([0, 0]).string == expression, (
        "lookup should return the scalar token, "
        "by walking across the tree structure to the "
        "scalar token, which is at the bottom of the tree"
    )

    # method lookup_key
    assert (
        t.lookup_key([0.0]) == t.lookup([0, 0])
    ), "lookup_key should return the same as lookup, except a scalar"

# Generated at 2022-06-24 11:23:48.404955
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"key1": "value1"}, 0, 5)
    assert d.string == "{'key1': 'value1'}"


# Generated at 2022-06-24 11:23:54.562633
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    stoken = ScalarToken('value', 0, 1)
    assert stoken.start == Position(1, 2, 1)


# Generated at 2022-06-24 11:23:57.797317
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token(None, 0, 0)
    # raise error
    try:
        token.lookup([])
    except NotImplementedError:
        assert True
    except:
        assert False


# Generated at 2022-06-24 11:24:05.469624
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    scalar_token = ScalarToken(123, 0, 2, "123")
    assert repr(scalar_token) == "ScalarToken('123')"

    dict_token = DictToken(
        {"key": ScalarToken(123, 0, 2, "123")},
        0,
        2,
        "{'key': ScalarToken(123)}",
    )
    assert repr(dict_token) == "DictToken({'key': ScalarToken('123')})"

    list_token = ListToken([ScalarToken(123, 0, 2, "123")], 0, 2, "[123]")
    assert repr(list_token) == "ListToken([ScalarToken('123')])"



# Generated at 2022-06-24 11:24:07.030050
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1, "b": 2}, 0, 1, "")



# Generated at 2022-06-24 11:24:18.508228
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
     # Test for constructor of ScalarToken
     from typesystem import String
     construct_token = "token"
     token = String(format='password')
     start_index = 3
     end_index = 6
     content = "token"
     token_test = ScalarToken(token, start_index, end_index, content)
     # Test if the two tokens are the same
     assert ScalarToken.__init__(token_test, token, start_index, end_index, content)
     # Test the __eq__ method
     assert ScalarToken.__eq__(token_test, token_test)
     # Test the __hash__ method
     assert ScalarToken.__hash__(token_test)
     # Test the __repr__ method
     assert "ScalarToken(%s)" % repr(token_test.string)

# Generated at 2022-06-24 11:24:21.719041
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # Unit test for method __hash__ of class ScalarToken
    # Make sure that two objects with the same value have the same hash
    assert ScalarToken("hello", 1, 2).__hash__() == ScalarToken("hello", 1, 2).__hash__()


# Generated at 2022-06-24 11:24:26.929769
# Unit test for method lookup of class Token
def test_Token_lookup():
    content = "abc\n" \
              "def"
    token = Token(None, 0, 4, content)

    assert [token.start, token.end] == [Position(1, 1, 0), Position(2, 3, 5)]


# Generated at 2022-06-24 11:24:31.895451
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("value", 10, 20)
    assert token._value == "value"
    assert token._start_index == 10
    assert token._end_index == 20
    assert token._content == ""



# Generated at 2022-06-24 11:24:34.134600
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken({(1,2):3}, 1, 2)
    assert dict_token._child_tokens == {(1,2):3}


# Generated at 2022-06-24 11:24:40.154767
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    a = ScalarToken("testValue", 0, 3)
    print("Value of ScalarToken is : ")
    print(a.value)
    print("Start and end of ScalarToken is : ")
    print(a.start)
    print(a.end)
    print("String value of ScalarToken is : ")
    print(a.string)

if __name__ == "__main__":
    test_ScalarToken()

# Generated at 2022-06-24 11:24:43.280193
# Unit test for constructor of class ListToken
def test_ListToken():
    # Test constructor of class ListToken
    token = ListToken([1,2,3], 5, 6, "hello")
    assert token.string == "hello"
    assert token.value == [1,2,3]


# Generated at 2022-06-24 11:24:48.511508
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    t = ScalarToken('stuff',0,4)
    assert t.string == 'stuff', 't.string must be stuff'
    assert t.value == 'stuff', 't.value must be stuff'
    assert t.start == Position(1,5,0), 'Start must be Position(1,5,0)'
    assert t.end == Position(1,9,0), 'End must be Position(1,9,0)'
    assert t.lookup([]) == t, 't.lookup([]) must be t'
    

# Generated at 2022-06-24 11:24:51.191193
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from Token import Token
    token = Token("abc", 0, 2)
    assert (token == Token("abc", 0, 2))


# Generated at 2022-06-24 11:24:57.122132
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(0, 0, 0)
    assert(token._value == 0)
    assert(token._start_index == 0)
    assert(token._end_index == 0)
    assert(token._content == "")

    with pytest.raises(NotImplementedError):
        assert(token.value == 0)


# Generated at 2022-06-24 11:25:05.492682
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    list_token = ListToken([ScalarToken(True, 0, 3, "true"), ScalarToken(1, 5, 5, "1")], 0, 5, "true 1")
    assert list_token.lookup([0]).string == "true"
    assert list_token.lookup([1]).string == "1"

    assert list_token.lookup_key([0]).string == "true"
    assert list_token.lookup_key([1]).string == "1"

    dict_token = DictToken({ScalarToken("key", 1, 3, '"key"'): ScalarToken(True, 5, 8, "true")}, 0, 8, '"key": true')
    assert dict_token.lookup([0]).string == '"key": true'

# Generated at 2022-06-24 11:25:17.138709
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    # create a fake start_index
    def make_start_index(start_index):
        start = Position(start_index, start_index, start_index)
        return start
    # create a fake end_index
    def make_end_index(end_index):
        end = Position(end_index, end_index, end_index)
        return end
    # create a fake value
    def make_value(value):
        value = value
        return value
    # create a fake content
    def make_content(content):
        content = content
        return content
    # create a fake lookup(index)
    def make_lookup_index(index):
        index = [index]
        return index

    # create a fake lookup_key(index)
    def make_lookup_key_index(index):
        index

# Generated at 2022-06-24 11:25:17.776321
# Unit test for constructor of class DictToken
def test_DictToken():
    pass

# Generated at 2022-06-24 11:25:20.267775
# Unit test for constructor of class Token
def test_Token():
    a = Token(1, '1', '2', '5123')
    assert a._value == 1
    assert a._start_index == '1'
    assert a._end_index == '2'
    assert a._content == '5123'


# Generated at 2022-06-24 11:25:25.208700
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert "Token(a)" == repr(Token("a", 0, 1, content="a"))



# Generated at 2022-06-24 11:25:30.355474
# Unit test for constructor of class ListToken
def test_ListToken():
    print("Test ListToken")
    token = ListToken([1,2,3], 1, 2, "123")
    value = token._get_value()
    print("value:", value)
    child = token._get_child_token(0)
    print("child:", child)

# Generated at 2022-06-24 11:25:31.860177
# Unit test for constructor of class Token
def test_Token():
    assert Token("test", 0, 1, "test")


# Generated at 2022-06-24 11:25:41.270364
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # Test with float
    token = ScalarToken(1.0, 0, 3)
    hash_value = token.__hash__()
    assert isinstance(hash_value, int)
    assert hash_value == hash(1.0)
    # Test with integer
    token = ScalarToken(1, 0, 3)
    hash_value = token.__hash__()
    assert isinstance(hash_value, int)
    assert hash_value == hash(1)
    # Test with string
    token = ScalarToken("a", 0, 3)
    hash_value = token.__hash__()
    assert isinstance(hash_value, int)
    assert hash_value == hash("a")
    # Test with boolean
    token = ScalarToken(True, 0, 3)
    hash_value = token.__hash__

# Generated at 2022-06-24 11:25:44.568095
# Unit test for method lookup of class Token
def test_Token_lookup():
    example_token = ListToken("Example", 0, 0, content="Example")
    token = example_token.lookup([]) == example_token
    assert token is True


# Generated at 2022-06-24 11:25:49.743589
# Unit test for method lookup of class Token
def test_Token_lookup():
    # test for ScalarToken
    token1 = ScalarToken("value", 0, 10, "value   ")
    assert token1.lookup([]) == token1, "Error: the method lookup() is wrong!"
    # test for DictToken
    token2 = DictToken({ScalarToken("key1", 0, 10, "key1"): ScalarToken("value1", 15, 25, "value1")}, 0, 25, "key1: value1")
    assert token2.lookup([]) == token2, "Error: the method lookup() is wrong!"
    assert token2.lookup(["key1"]) == ScalarToken("value1", 15, 25, "value1"), "Error: the method lookup() is wrong!"
    # test for ListToken

# Generated at 2022-06-24 11:25:51.743183
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    pass



# Generated at 2022-06-24 11:25:57.205767
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from typesystem.base import Position
    from typesystem.parser import Token
    my_token = Token(value= {'a':1}, start_index=0, end_index=7, content = '{"a":1}')
    assert my_token.lookup_key([0]) == my_token._get_key_token(0)
    assert my_token.lookup_key([0]).value == my_token.lookup_key([0])._get_value()

# Generated at 2022-06-24 11:26:00.978103
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(10, 0, 1)
    assert token.string == "10"
    assert token.value == 10
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 2, 1)


# Generated at 2022-06-24 11:26:04.442521
# Unit test for constructor of class DictToken
def test_DictToken():
    Dict = DictToken({"a": "b"}, 0, 1)
    assert Dict.start == Position(1,2,1)
    assert Dict.end == Position(1,2,1)
    assert Dict.string == '{"a":"b"}'
    assert Dict.value == {"a": "b"}


# Generated at 2022-06-24 11:26:10.254798
# Unit test for method lookup of class Token
def test_Token_lookup():
    from typesystem.base import Scalar
    from typing import List, Tuple
    import json

    class TestToken(Token):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._child_tokens = {k._value: v for k, v in self.items()}

        def __eq__(self, other):
            return all(
                self._value[key] == other._value[key]
                for key in self._value
                if key != "_content"
            )

        def __getitem__(self, key):
            return self._value[key]

        def keys(self):
            return self._value.keys()

        def items(self):
            return self._value.items()


# Generated at 2022-06-24 11:26:16.828803
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token1 = ScalarToken(1, 0, 2, "")
    token2 = ScalarToken(2, 3, 5, "")

    hash1 = hash(token1)
    hash2 = hash(token2)

    assert hash1 != hash2


# Generated at 2022-06-24 11:26:25.294164
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class DT(DictToken):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    class LT(ListToken):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    class ST(ScalarToken):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    dt = DT(
        {ST(1, 1, 1): ST(2, 2, 2)},
        0, 2, "a{b: c}",
    )
    assert dt.lookup_key([0]) == ST(1, 1, 1)


# Generated at 2022-06-24 11:26:33.172275
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(value = 1, start_index = 0, end_index = 0).__eq__(1) == False
    assert Token(value = 'a', start_index = 0, end_index = 1).__eq__(1) == False
    assert Token(value = 'a', start_index = 0, end_index = 0, content = 'a').__eq__(1) == False
    assert Token(value = 'a', start_index = 1, end_index = 1).__eq__(1) == False
    assert Token(value = 'a', start_index = 1, end_index = 2).__eq__(1) == False
    

# Generated at 2022-06-24 11:26:37.323616
# Unit test for method lookup of class Token
def test_Token_lookup():
    from json import loads
    read_json = lambda x: loads(x)
    token = Token(read_json('{"key": "value"}'), 0, 16)
    token_key = token.lookup([0])
    assert token_key.string == 'key'
    token_value = token.lookup([1])
    assert token_value.string == 'value'


# Generated at 2022-06-24 11:26:43.312201
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Token('')
    assert repr(Token('', 0, 0)) == "Token('')"
    # Token('')
    assert repr(Token('', 1, 5)) == "Token('')"
    # Token('a')
    assert repr(Token('a', 0, 0)) == "Token('a')"
    # Token('a')
    assert repr(Token('a', 1, 5)) == "Token('a')"
    # Token('abc')
    assert repr(Token('abc', 0, 2)) == "Token('abc')"
    # Token('abc')
    assert repr(Token('abc', 1, 5)) == "Token('abc')"


# Generated at 2022-06-24 11:26:45.097505
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token("some token",0,0)
    assert repr(token) == "Token('some token')"


# Generated at 2022-06-24 11:26:51.989641
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token('value', 1, 2, content='123')
    token2 = Token('value', 1, 2, content='123')
    token3 = Token('value', 3, 4, content='123')
    print(token1 == token2)
    print(token1 == token3)
    print(token1 == 1)


# Generated at 2022-06-24 11:26:58.824542
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    with open(os.path.join(os.path.dirname(__file__), "data/lexer_sample_1.json"), "r") as f:
        x = f.read()
    t = JSONLexer(x).lex()
    assert t.lookup_key([0,0]).end.index == 4
    assert t.lookup_key([0,2]).end.index == 23
    assert t.lookup_key([1,1]).end.index == 32
    assert t.lookup_key([1,1]).string == "\"number\": 2.5,"
    assert t.lookup_key([3]) == None

# Generated at 2022-06-24 11:27:04.279015
# Unit test for constructor of class Token
def test_Token():
  assert(
    Token(
      value=1,
      start_index=0,
      end_index=1,
      content="a"
    )
    ==
    Token(
      value=1,
      start_index=1,
      end_index=1,
      content="a"
    )
  )


# Generated at 2022-06-24 11:27:09.754275
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken('a', 0, 0)
    assert(token.string == 'a')
    assert(token.value == 'a')
    assert(token.start == Position(1, 1, 0))
    assert(token.end == Position(1, 1, 0))
    assert(token.lookup([]) == token)


# Generated at 2022-06-24 11:27:16.245028
# Unit test for constructor of class Token
def test_Token():
    test_Token = Token(value=1, start_index=0, end_index=1)
    assert repr(test_Token) == "Token('1')"
    assert test_Token.string == "1"
    assert test_Token.start == 1
    assert test_Token.end == 2
    assert test_Token.value == 1

# Generated at 2022-06-24 11:27:20.056663
# Unit test for constructor of class DictToken
def test_DictToken():
    start_index = 0
    end_index = 0
    content = ""
    value = {}
    new_DictToken = DictToken(value, start_index, end_index, content)
    assert new_DictToken is not None


# Generated at 2022-06-24 11:27:22.470859
# Unit test for constructor of class Token
def test_Token():
    try:
        token = Token("val", 1, 2)
    except NotImplementedError as e:
        print("Error : {}".format(e))

# Generated at 2022-06-24 11:27:24.945243
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    tok = ScalarToken(value=1, start_index=0, end_index=5, content="hi there")
    assert isinstance(tok.__hash__(), int) == True


# Generated at 2022-06-24 11:27:33.669497
# Unit test for constructor of class Token
def test_Token():
    s0 = '{ "key": ["value1", "value2"] }'
    def token_value(token):
        return token.value
    value = {
        "key": ["value1", "value2"]
    }
    token = Token(value, 0, len(s0) - 1, s0)
    assert token.string == s0
    assert token.value == value
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 31, 30)
    assert token.lookup([0]) == token_value(token.lookup([0]))
    assert token.lookup_key([0, 0]) == token_value(token.lookup_key([0, 0]))

# Generated at 2022-06-24 11:27:36.347481
# Unit test for constructor of class ListToken
def test_ListToken():
    _val = ['1', '2']
    lToken = ListToken(_val, 0, 1, 'str')
    assert lToken._value == _val


# Generated at 2022-06-24 11:27:41.490948
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    dict_token = DictToken({}, 1, 11, '{key: value}')
    assert(dict_token.lookup_key([0]) == dict_token)
    # EOF


# Generated at 2022-06-24 11:27:50.051335
# Unit test for constructor of class ListToken
def test_ListToken():
    a = ListToken(value = ["1", "2", "more"], start_index = 0, end_index = 7, content = "1 2 more")
    b = ListToken(value = ["1", "2", "more"], start_index = 0, end_index = 7, content = "1 2 more")
    c = ListToken(value = ["1", "2", "more"], start_index = 0, end_index = 6, content = "1 2 mor")
    d = ListToken(value = ["1", "2", "less"], start_index = 0, end_index = 7, content = "1 2 more")
    assert a == b
    assert a != c
    assert a != d



# Generated at 2022-06-24 11:27:55.485709
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    content = "this is a string"
    token = ScalarToken(123, 2, 3, content)
    assert token._start_index == 2
    assert token._end_index == 3
    assert token._value == 123
    assert token._content == "this is a string"


# Generated at 2022-06-24 11:28:01.019689
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    a = ScalarToken("a", 1, 2)
    assert a.string == 'a'
    assert a.value == 'a' 
    assert a.start.index == 1
    assert a.end.index == 2
    assert a.start.row == 1
    assert a.start.col == 1
    assert a.end.row == 1
    assert a.end.col == 2


# Generated at 2022-06-24 11:28:11.646557
# Unit test for constructor of class ListToken
def test_ListToken():
    list_token = ListToken(["a", "b", "c"], 0, 2, content="abc")
    assert list_token.string == "abc"
    assert list_token.start.line_no == 1
    assert list_token.start.column_no == 1
    assert list_token.start.byte_index == 0
    assert list_token.end.line_no == 1
    assert list_token.end.column_no == 3
    assert list_token.end.byte_index == 2
    assert list_token.value == ["a", "b", "c"]
    assert list_token.lookup([2]) == "c"
    assert list_token.lookup_key([1]) == "b"



# Generated at 2022-06-24 11:28:23.259675
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a':1,'b':2}
    token = DictToken(d,0,2)
    # verify value of token is {'a':1,'b':2}
    assert token.value == {'a':1,'b':2}
    # verify start index of token is 0
    assert token.start == 0
    # verify end index of token is 2
    assert token.end == 2
    # verify the lookup of token is the value at the given index
    assert token.lookup(['a']) == {'a':1,'b':2}


# Generated at 2022-06-24 11:28:23.889645
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    pass

# Generated at 2022-06-24 11:28:31.333835
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from typesystem.types import String, Integer
    from typesystem.types.compound import Structure

    from typesystem.types import String, Integer
    from typesystem.types.compound import Structure

    class Person(Structure):
        name = String()
        age = Integer()

    class Group(Structure):
        name = String()
        members = List(Person())

    root = Group()
    root.validate_and_return_token(
        {
            "name": "Test",
            "members": [
                {"name": "Test 1", "age": 10},
                {"name": "Test 2", "age": 15},
                {"name": "Test 3", "age": 16},
            ],
        }
    )
    assert root.lookup([0, "name"]).string == "Test 1"

# Generated at 2022-06-24 11:28:34.005255
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({}, 0, 0, "")
    assert a._value == {}
    assert a._start_index == 0
    assert a._end_index == 0
    assert a._content == ""

# Generated at 2022-06-24 11:28:45.517800
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # Simple test case
    # Token class is an abstract class, so we use ScalarToken as an example
    scalar_token = ScalarToken("test", 1, 5)
    assert scalar_token.lookup_key([0]) == scalar_token

    # list token for test
    list_token = ListToken(["test"], 0, 4)
    assert list_token.lookup_key([0]) == list_token

    # dict token for test
    str_token = ScalarToken("str", 1, 4)
    dict_token = DictToken({str_token: "test"}, 0, 9)
    assert dict_token.lookup_key([str_token]) == str_token


if __name__ == "__main__":
    test_Token_lookup_key()

# Generated at 2022-06-24 11:28:51.246296
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    assert ScalarToken("Value", 1, 4, content = "Value").string == "Value"


# Generated at 2022-06-24 11:29:00.617124
# Unit test for method lookup of class Token
def test_Token_lookup():
    def run(index):
        token = ListToken(
            [
                ScalarToken(1, 0, 0),
                ListToken([ScalarToken(2, 1, 1), ScalarToken(3, 2, 2)]),
                ScalarToken(4, 3, 3),
            ],
            0,
            3,
            content="1234",
        )
        return token.lookup(index)

    assert repr(run([0])) == "ScalarToken('1')"
    assert repr(run([1])) == "ListToken('23')"
    assert repr(run([1, 0])) == "ScalarToken('2')"
    assert repr(run([1, 1])) == "ScalarToken('3')"

# Generated at 2022-06-24 11:29:06.391424
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("hello", 0, 4, "hello")
    assert token.string == "hello"
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 6, 4)
    assert token.value == "hello"
    assert token.lookup([0]) == token
    assert token.lookup_key([0]) == token


# Generated at 2022-06-24 11:29:10.801142
# Unit test for constructor of class DictToken
def test_DictToken():
    # 1. Test Token's constructor
    token = DictToken({}, 0, 0)
    assert token._content == ""
    assert token._value == {}
    assert token._start_index == 0
    assert token._end_index == 0

    # 2. Test DictToken's constructor
    token = DictToken({}, 0, 0)
    assert len(token._child_keys) == 0
    assert len(token._child_tokens) == 0



# Generated at 2022-06-24 11:29:14.878112
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # The string representation of the object
    token_obj = Token(None, 0, 0, "")
    print(token_obj)


# Generated at 2022-06-24 11:29:19.744421
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("abc", 2, 1, "abc")
    
    assert repr(token) == "ScalarToken('bc')"
    assert token.value == "abc"
    assert token.start == Position(1,2,2)
    assert token.end == Position(1,3,1)
    assert token.string == "bc"


# Generated at 2022-06-24 11:29:23.574930
# Unit test for constructor of class DictToken
def test_DictToken():
    token1 = Token(value={"a": 1}, start_index=0, end_index=1)
    # get_child_token not return Token object
    # need to fix constructor of class DictToken
    # assert get_child_token(token1, 'a') == "1"

# Generated at 2022-06-24 11:29:27.311661
# Unit test for constructor of class ListToken
def test_ListToken():
    lt = ListToken(['abc', 'def'], 0, 1, "['abc', 'def']")
    assert lt._get_value() == ['abc', 'def']

# Generated at 2022-06-24 11:29:36.655138
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken('value', 0, 4)
    assert token.string == 'value'
    assert token.value == 'value'
    assert token.start.line_no == 1
    assert token.start.column_no == 1
    assert token.start.index == 0
    assert token.end.line_no == 1
    assert token.end.column_no == 5
    assert token.end.index == 4
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert token == ScalarToken('value', 0, 4)
    assert token != ScalarToken('other', 0, 4)
    assert token != ScalarToken('value', 1, 4)
    assert token != ScalarToken('value', 0, 5)

# Generated at 2022-06-24 11:29:47.545737
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    def check_cases(cases: typing.List[typing.Tuple[Token, Token, bool]]):
        for token1, token2, expected_result in cases:
            actual_result = token1 == token2

            assert actual_result == expected_result, "{} != {}".format(
                repr(token1), repr(token2)
            )

    # ScalarToken

# Generated at 2022-06-24 11:29:50.461939
# Unit test for constructor of class ListToken
def test_ListToken():
	t = ListToken([], 0, 0)
	assert t._value == []
	assert t._start_index == 0
	assert t._end_index == 0
	assert t.string == ''

# Generated at 2022-06-24 11:30:02.224546
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    start_index = 1
    end_index = 2
    content = "a"
    # ScalarToken
    value1 = Token(1, start_index, end_index, content)
    value2 = Token(1, start_index, end_index, content)
    assert value1 == value2
    value2 = Token(2, start_index, end_index, content)
    assert value1 != value2
    # DictToken
    value1 = Token({}, start_index, end_index, content)
    value2 = Token({}, start_index, end_index, content)
    assert value1 != value2
    # ListToken
    value1 = Token([1], start_index, end_index, content)
    value2 = Token([], start_index, end_index, content)
    assert value1 != value2

# Generated at 2022-06-24 11:30:09.991254
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    def check_with(value,content):
        t=Token(value,0,0,content)
        assert repr(t) == f"Token({repr(content)})"

    for tuple in [
        ("abc","abc"),
        (123,"123"),
        (False,"False"),
        (True,"True"),
        (["abc","def"], "['abc', 'def']"),
        ({'a': 1, 'b': 2},"{'a': 1, 'b': 2}")
    ]:
        yield check_with, tuple[0], tuple[1]



# Generated at 2022-06-24 11:30:10.870679
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken(None, 0, 1)

# Generated at 2022-06-24 11:30:13.212572
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({}, 0, 0)
    assert token is not None

# Generated at 2022-06-24 11:30:17.957566
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token("test", 0, 0, "test")
    assert isinstance(token, Token)
    assert token.lookup([0]) == token
    assert token.lookup([1]) == token
    assert token.lookup([]) == token


# Generated at 2022-06-24 11:30:29.281948
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    # "hello" string
    hello = "hello"
    token = ScalarToken(hello[0], 0, len(hello) - 1, hello) # test_ScalarToken("hello")
    assert isinstance(token, ScalarToken)
    assert isinstance(token, Token)
    # Content of the string is "hello"
    assert hello == token.string
    # Datatype of string is str
    assert str == type(token.value)
    # Start index of the string is (1, 1)
    assert token.start == Position(1, 1, 0)
    # End index of the string is (1, 5)
    assert token.end == Position(1, 5, len(hello) - 1)
    # Test the __repr__ method
    assert repr(hello) == repr(token)
    # "test"

# Generated at 2022-06-24 11:30:32.043452
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token(1, 0, 1, "abc")
    assert token.lookup([]) == token



# Generated at 2022-06-24 11:30:35.068915
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({'key': 'value'}, 0, 0)
    assert token.__class__.__name__ == 'DictToken'

# Generated at 2022-06-24 11:30:38.793683
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    print('Test of method __hash__ of class ScalarToken')
    s = ScalarToken(10, 0, 0)
    print(s.__hash__())
    # assert s.__hash__() == 10


# Generated at 2022-06-24 11:30:45.507047
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = Token(None, 0, 0)
    index_1 = [10]
    result_1 = token.lookup_key(index_1)
    assert result_1 == token.lookup(index_1[:-1])._get_key_token(index_1[-1])

    index_2 = [0, 1]
    result_2 = token.lookup_key(index_2)
    assert result_2 == token.lookup(index_2[:-1])._get_key_token(index_2[-1])


# Generated at 2022-06-24 11:30:53.600641
# Unit test for method lookup of class Token
def test_Token_lookup():
    class Token(Token):
        def __init__(self, string, *args, **kwargs):
            self.string = string
            self._value = string
        def _get_child_token(self, key):
            return self._value[key]
        def _get_key_token(self, key):
            return self._value
    node = Token("[1, 2]")
    assert node.lookup([0]).string == "1"
    assert node.lookup_key([0, 0]).string == "[1, 2]"
    assert node.lookup([1]).string == "2"
    assert node.lookup_key([1, 0]).string == "[1, 2]"

# Generated at 2022-06-24 11:30:56.258905
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    t = Token(None, 1, 2)
    assert str(t) == 'Token(\'?\')'



# Generated at 2022-06-24 11:30:58.461949
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken("5", 0, 1, "5.0")
    # Test for no exception
    hash(token)
    # Test for any type
    token = ScalarToken(None, 0, 1, "None")
    hash(token)


# Generated at 2022-06-24 11:31:00.957279
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(12, 0, 0, '12')
    result = token.__hash__()
    assert(result == hash(12))


# Generated at 2022-06-24 11:31:08.073841
# Unit test for constructor of class Token
def test_Token():
    from typesystem.exceptions import ValidationError
    from typesystem.types import String, Dict, List, Integer

    class Person(Dict):
        name = String()
        age = Integer()
        subscriptions = List[Person]()

    token = Person().validate({
        'name': 'Anna',
        'age': 32,
        'subscriptions': [{'name': 'Clara', 'age': 30}]
    })

    assert token.string == "{'name': 'Anna', 'age': 32, 'subscriptions': [{'name': 'Clara', 'age': 30}]}"



# Generated at 2022-06-24 11:31:12.017271
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    value = "testcontent"
    start_index = 0
    end_index = 10
    content = "testcontent"
    
    token = Token(value, start_index, end_index, content)
    
    assert repr(token) == "Token('testcontent')"

# Generated at 2022-06-24 11:31:14.137783
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    tok = ScalarToken(value = "",start_index = 1,end_index = 2)


# Generated at 2022-06-24 11:31:18.068085
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token("test_token", 0, 0, "test_content")
    try:
        _ = token.lookup([0])
    except NotImplementedError:
        pass
    else:
        assert False, "This should not be reached"


# Generated at 2022-06-24 11:31:19.929045
# Unit test for constructor of class DictToken
def test_DictToken():
    token_dict = DictToken("hello")
    assert token_dict is not None


# Generated at 2022-06-24 11:31:23.455078
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    class MockScalarToken(ScalarToken):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            pass

        def _get_value(self) -> typing.Any:
            return "test_ScalarToken___hash__"

    a = MockScalarToken(0, 0, 0)
    assert hash(a) == hash("test_ScalarToken___hash__")