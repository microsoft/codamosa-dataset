

# Generated at 2022-06-24 11:21:29.605436
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token
    token2 = Token
    assert token1 == token2
    assert token1 is not token2

if __name__ == '__main__':
    import sys
    import traceback
    import logging
    logging.basicConfig(stream=sys.stderr)
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    try:
        test_Token___eq__()
    except:
        traceback.print_exc()
        logger.critical("%-20s %s", "resource", "failed")
    else:
        logger.info("%-20s %s", "resource", "passed")

# Generated at 2022-06-24 11:21:31.826932
# Unit test for constructor of class ListToken
def test_ListToken():
  list_token = ListToken(
    [1, 2],
    start_index=0,
    end_index=3,
    content="12"
  )


# Generated at 2022-06-24 11:21:35.064913
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    t = Token("123.456", 1, 5)
    assert repr(t) == "Token('23.45')"
    t = Token("123.456", 2, 6)
    assert repr(t) == "Token('3.456')"


# Generated at 2022-06-24 11:21:37.540789
# Unit test for constructor of class DictToken
def test_DictToken():
    d=DictToken(None,None,None,None,None)


# Generated at 2022-06-24 11:21:47.233962
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    test_dict = {
        'id': "1",
        'name': 'admin',
        'age': 23,
        'balance': 987.65,
        'isActive': True,
        'skills': ['C', 'Java', 'Python'],
        'address': {
            'state': 'CA',
            'city': 'San Francisco',
            'pinCode': 1234
        },
        'phoneNumbers': [
            {'type': 'office', 'number': '010-1234-5678'},
            {'type': 'home', 'number': '010-1111-2222'}
        ]
    }
    indexed_dict = index_dict(test_dict)
    token = indexed_dict._get_child_token('skills')

# Generated at 2022-06-24 11:21:56.198872
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(3, 0, 2, "3")
    assert (
        str(token) == "ScalarToken('3')"
    )  # test that the output of str(token) is identical to the string "ScalarToken('3')"
    assert token.value == 3  # test that the instance attribute value of the token is identical to the integer 3
    assert token.string == "3"  # test that the instance attribute string of the token is identical to the string "3"
    assert token.start.index == 0  # test that the instance attribute start of the token is identical to the integer 0
    assert token.end.index == 2  # test that the instance attribute end of the token is identical to the integer 2
    assert token.lookup([]) == token  # test that the token is identical to itself
    assert token.look

# Generated at 2022-06-24 11:22:00.085103
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    value = 'lorem ipsum'
    start_index = 0
    end_index = 10
    content = 'lorem ipsum'
    token = ScalarToken(value, start_index, end_index, content)
    assert token._value == 'lorem ipsum'
    assert token._start_index == 0
    assert token._end_index == 10
    assert token._content == 'lorem ipsum'


# Generated at 2022-06-24 11:22:07.066989
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from typesystem.exceptions import TokenError

    class TestToken(Token):
        def _get_value(self) -> typing.Any:
            raise NotImplementedError  # pragma: nocover

        def _get_child_token(self, key: typing.Any) -> Token:
            raise NotImplementedError  # pragma: nocover

        def _get_key_token(self, key: typing.Any) -> Token:
            raise NotImplementedError  # pragma: nocover

    class TestListToken(Token):
        def _get_value(self) -> typing.Any:
            raise NotImplementedError  # pragma: nocover

        def _get_child_token(self, key: typing.Any) -> Token:
            raise NotImplementedError  # pragma: noc

# Generated at 2022-06-24 11:22:09.384689
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    a = "scalar"
    b = 0
    c = 1
    d = 1
    assert ScalarToken(a, b, c, d)



# Generated at 2022-06-24 11:22:20.653955
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from typesystem.parser import parse
    from typesystem.base import Text
    from typesystem.base import Dict
    from typesystem.base import List
    from typesystem.base import String

    text = Text("foo: bar\nbaz: true\nqux: [1,2,3]")
    parser = parse(
        """
schema:
  foo: String
  baz: String
  qux: List[String]
""",
        text,
    )
    token = parser.schema_token

    def as_token(schema: typing.Any) -> Token:
        if isinstance(schema, Dict):
            return DictToken(schema, 0, len(str(schema)), text=str(schema))

# Generated at 2022-06-24 11:22:23.728745
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    a = ScalarToken(None, 0, 0)
    assert a.string == ""

# Generated at 2022-06-24 11:22:28.437945
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    # set up
    value = 'test'
    start_index = 0
    end_index = len(value) - 1
    content = 'test'
    token = ScalarToken(value, start_index, end_index, content)
    # test
    assert token.value == value
    assert token.start == Position(1, 5, 4)
    assert token.end == Position(1, 5, 4)
    assert token.string == value


# Generated at 2022-06-24 11:22:32.564150
# Unit test for constructor of class ListToken
def test_ListToken():
    l = ListToken([0, 1, 2], 2, 6, content='[10, 20, 30]')
    assert l.start == Position(1, 1, 0)
    assert l.end == Position(1, 7, 6)


# Generated at 2022-06-24 11:22:34.833361
# Unit test for method lookup of class Token
def test_Token_lookup():
    t = ListToken(
        value=[], start_index=0, end_index=0, content="content"
    )
    assert t.lookup([]) == t

# Generated at 2022-06-24 11:22:40.689528
# Unit test for method lookup of class Token
def test_Token_lookup():
    item = {"a": {"b": {"c": 1}}}
    dict_token = DictToken(item, 0, 100)
    ret1 = dict_token.lookup([0, 0, 0])
    ret2 = dict_token._get_child_token("a")
    dict_token._start_index = 197
    ret3 = dict_token.lookup([0, 0, 0])
    assert ret1.string == "1"
    assert ret2.string == "{'b': {'c': 1}}"
    assert ret3.string == "1"

# Generated at 2022-06-24 11:22:45.062297
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = ScalarToken(3, 0, 2, '3.14')
    assert token.lookup([]) == token
    # The next line causes a runtime error:
    #   AttributeError: 'ScalarToken' object has no attribute '_get_child_token'
    # assert token.lookup([0]) == token

# Generated at 2022-06-24 11:22:46.614166
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken([], [], [])
    assert d


# Generated at 2022-06-24 11:22:49.453610
# Unit test for method __repr__ of class Token
def test_Token___repr__():
	text = "123.456"
	t = Token(num.__call__(text), 0, len(text) - 1, text)
	assert repr(t) == "Token('123.456')"

# Generated at 2022-06-24 11:22:55.296034
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = Token(value=None, start_index=0, end_index=1)
    t = token.lookup_key([1])
    assert t == token

# Generated at 2022-06-24 11:23:06.330993
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from typesystem.base import Number, String

    content = '{"a": 2, "b": 3}'
    schema = {"a": Number(), "b": Number()}

    token = schema.parse(content)
    assert isinstance(token.lookup_key((0, 0)), ScalarToken)
    assert isinstance(token.lookup((0, 0)), ScalarToken)
    assert isinstance(token.lookup_key((0, 1)), ScalarToken)
    assert isinstance(token.lookup((0, 1)), ScalarToken)
    assert isinstance(token.lookup_key((1, 0)), ScalarToken)
    assert isinstance(token.lookup((1, 0)), ScalarToken)
    assert isinstance(token.lookup_key((1, 1)), ScalarToken)

# Generated at 2022-06-24 11:23:07.332956
# Unit test for constructor of class ListToken
def test_ListToken():
    assert True

# Generated at 2022-06-24 11:23:10.135712
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token(value='foo', start_index=0, end_index=2, content='foo')
    assert repr(token) == "Token('foo')"



# Generated at 2022-06-24 11:23:11.304673
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert repr(Token('', 0, 0)) == "Token('')"


# Generated at 2022-06-24 11:23:16.822410
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert  ScalarToken(1, 1, 2, '').__hash__() == hash(1)
    assert  ScalarToken('asdf', 1, 2, 'asdf').__hash__() == hash('asdf')
    assert  ScalarToken('asdf', 1, 2, 'asdf').__hash__() != hash(2)
    assert  ScalarToken('asdf', 1, 2, 'asdf').__hash__() != hash('a')


# Generated at 2022-06-24 11:23:19.831507
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    obj1 = Token(1, 1, 2, "")
    obj2 = Token(2, 1, 2, "")
    result = obj1 == obj2

    assert result == False


# Generated at 2022-06-24 11:23:23.142607
# Unit test for constructor of class Token
def test_Token():
    token = Token(1, 2, 3, "content")
    assert token._value == 1
    assert token._start_index == 2
    assert token._end_index == 3
    assert token._content == "content"

# Generated at 2022-06-24 11:23:32.249911
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(1, 0, 5, "sval")
    assert token._get_value() == 1
    assert token.string == "sval"
    assert token.start == Position(1, 5, 0)
    assert token.end == Position(1, 5, 5)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert token == ScalarToken(1, 0, 5)
    assert hash(token) == 1



# Generated at 2022-06-24 11:23:34.298598
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert hash(ScalarToken('foo', 0, 2, content='foo')) == hash('foo')

# Generated at 2022-06-24 11:23:38.081128
# Unit test for constructor of class ListToken
def test_ListToken():
    t=ListToken(["a","b","c"],0,0)
    assert t.value==["a","b","c"]

if __name__ == "__main__":
    # Unit test for constructor of class ListToken
    test_ListToken()
    print("Everything passed")

# Generated at 2022-06-24 11:23:40.163458
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from .tokenutils import parse

    string = '{"name": "matt"}'
    tree = parse(string)
    lookup_result = tree.lookup_key([0, "name"])
    assert lookup_result.string == '"name"'

# Generated at 2022-06-24 11:23:51.660004
# Unit test for method lookup of class Token
def test_Token_lookup():
    t1 = ScalarToken(value=5, start_index=5, end_index=5)
    assert t1.lookup([]) == t1
    assert t1.lookup([0]) == t1
    assert t1.lookup([2, 2, 5]) == t1

    t1 = DictToken(
        value={
            ScalarToken(value=5, start_index=5, end_index=5): ScalarToken(
                value=5, start_index=5, end_index=5
            )
        },
        start_index=5,
        end_index=5,
    )
    assert t1.lookup([]) == t1
    assert isinstance(t1.lookup([0]), DictToken)

# Generated at 2022-06-24 11:23:57.117561
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    try:
        token = Token(
        value={"abc": "a", "def": "b"}, 
        start_index=None, 
        end_index=None, 
        content=None
        )
        token.lookup_key(None)
    except NotImplementedError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 11:24:01.657032
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    content = "abc"
    start_index = 1
    end_index = 2
    token = Token(None, start_index, end_index, content)
    assert token.lookup_key([]) == token
    assert token.lookup_key([0]) == token
    assert token.lookup_key([1]) == token
    assert token.lookup_key([2]) == token

# Generated at 2022-06-24 11:24:04.849385
# Unit test for method lookup of class Token
def test_Token_lookup():
    DictToken().lookup(index)
    DictToken().lookup_key(index)
    ListToken().lookup(index)
    ListToken().lookup_key(index)

# Generated at 2022-06-24 11:24:06.844249
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = ScalarToken(65, 0, 1, "hello")
    assert token == ScalarToken(65, 0, 1, "hello")
    assert token != ScalarToken(99, 0, 1, "hello")



# Generated at 2022-06-24 11:24:10.766725
# Unit test for method __repr__ of class Token
def test_Token___repr__():

    # Test with a valid argument
    token = Token("value", 0, 2, "content")
    assert token.__repr__() == "Token(\"value\")"



# Generated at 2022-06-24 11:24:16.642814
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    t = ScalarToken(12345, 0, 0)
    assert t.string == ""
    assert t.value == 12345
    assert t.start.line_no == 1
    assert t.start.column_no == 1
    assert t.start.index == 0
    assert t.end.line_no == 1
    assert t.end.column_no == 1
    assert t.start.index == 0


# Generated at 2022-06-24 11:24:18.421372
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({1:1})
    assert token._value == {1:1}

# Generated at 2022-06-24 11:24:25.888945
# Unit test for method lookup of class Token
def test_Token_lookup():
    from .tokenizer import Tokenizer

    def test_object_lookup(x):
        token_string = json.dumps(x)
        tokenizer = Tokenizer(token_string, start_position=0)
        token = tokenizer.tokenize_object()
        assert token.lookup([0]).value == x

    def test_dict_lookup(x):
        token_string = json.dumps(x)
        tokenizer = Tokenizer(token_string, start_position=0)
        token = tokenizer.tokenize_dict()
        assert token.lookup([0]).value == x[0]
        assert token.lookup([0, 0]).value == x[0][0]
        assert token.lookup([0, 1]).value == x[0][1]

# Generated at 2022-06-24 11:24:31.850977
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    tokens = {'foo': ScalarToken(value='foo', start_index=0, end_index=2), 'bar': ScalarToken(value='bar', start_index=3, end_index=5)}
    assert tokens['foo'] == tokens['foo']
    assert not tokens['foo'] == tokens['bar']

# Generated at 2022-06-24 11:24:40.939886
# Unit test for constructor of class Token
def test_Token():
    s = "Hello,{}world"
    t = Token(s, 2, 6, s)
    assert t.string == "{}"
    assert t.value == "{}"
    assert t.start == Position(1, 3, 2)
    assert t.end == Position(1, 7, 6)
    # __eq__
    assert t == t
    assert not t == Token(s, 2, 8, s)
    assert not t == Token(s, 3, 6, s)
    assert not t == Token(s, 2, 6, s + s)
    assert not t == Token(s + s, 2, 6, s)
    # test repr
    assert repr(t) == 'Token({})'

# Generated at 2022-06-24 11:24:42.127992
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken([], 0, 1, '')
    return token

# Generated at 2022-06-24 11:24:48.334555
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {
        'key1' : 1,
        'key2' : 'a',
        'key3' : ['a', 'b'],
        'key4' : {
            'sub_key1' : 1,
            'sub_key2' : 3,
            'sub_key3' : ['a','b','c','d'],
            'sub_key4' : {
                'sub_sub_key1' : 'a',
                'sub_sub_key2' : 'a',
                'sub_sub_key3' : 'a',
                'sub_sub_key4' : 'a'
            }
        }
    }
    print(type(d))


# Generated at 2022-06-24 11:24:52.385499
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = Token("a", 0, 0, "ab")
    exception_raised = False
    try:
        token.lookup_key([1])
    except NotImplementedError:
        exception_raised = True
    assert exception_raised


# Generated at 2022-06-24 11:24:59.788760
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(value = 'value', start_index = 'start_index', end_index = 'end_index', content = 'content')
    assert (token.value == 'value')
    assert (token.start_index == 'start_index')
    assert (token.end_index == 'end_index')
    assert (token.content == 'content')


# Generated at 2022-06-24 11:25:01.091181
# Unit test for constructor of class ListToken
def test_ListToken():
    l = ListToken()
    assert l is not None

test_ListToken()

# Generated at 2022-06-24 11:25:12.137203
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    tok = ScalarToken('aa', 0, 1)
    print(tok.value)
    print(tok.start)
    print(tok.end)
    print(tok.string)
    print(tok._value)
    print(tok._start_index)
    print(tok._end_index)
    print(tok._content)


# Generated at 2022-06-24 11:25:17.688280
# Unit test for constructor of class ListToken
def test_ListToken():

    # Testing constructor
    # This ok
    token = ListToken(None, 0, 0, None)
    assert(token.value == None)

    # This is not ok, no unit test created for this
    # token = ListToken(None, 0, 0)
    
if __name__ == "__main__":
    test_ListToken()

# Generated at 2022-06-24 11:25:23.221874
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert repr(ScalarToken(1, 2, 3, "abcd")) == "ScalarToken('a')"
    assert repr(ListToken([ScalarToken(1, 2, 3, "abcd")], 2, 9, "abcdefg")) == "ListToken('abcde')"
    assert repr(DictToken({ScalarToken(1, 2, 3, "abcd"): ScalarToken(4, 6, 8, "efg")}, 2, 12, "abcdefghij")) == "DictToken('abcdefghi')"

# Generated at 2022-06-24 11:25:27.576595
# Unit test for constructor of class ListToken
def test_ListToken():
    # listtoken = ListToken(1, 2, 3)
    # assert listtoken._get_value() == [1, 2, 3]
    print("Test passed")

test_ListToken()


# Generated at 2022-06-24 11:25:37.938146
# Unit test for constructor of class Token
def test_Token():
    # ScalarToken
    token_test_value = list("abcde")
    token_test_start_index = 1
    token_test_end_index = 3
    token_test_content = "testcontent"
    token = Token(
        token_test_value, token_test_start_index, token_test_end_index, token_test_content
    )
    assert token._value == token_test_value
    assert token._start_index == token_test_start_index
    assert token._end_index == token_test_end_index
    assert token._content == token_test_content
    assert token.value == token._value
    assert token.string == "abc"
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 4, 3)

# Generated at 2022-06-24 11:25:42.564323
# Unit test for constructor of class DictToken
def test_DictToken():
    a = {
        1: 2,
        2: 3
    }

    class TempToken(DictToken):
        pass

    b = TempToken(a, 0, 3)
    b._child_keys = {k._value: k for k in b._value.keys()}
    b._child_tokens = {k._value: v for k, v in b._value.items()}


# Generated at 2022-06-24 11:25:46.616931
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    aDictToken = DictToken({'a': ScalarToken(1)})
    assert aDictToken.lookup_key([0]) == ScalarToken('a')
    assert aDictToken.lookup_key([1]) == ScalarToken(1)



# Generated at 2022-06-24 11:25:58.759182
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert (
        Token(123, 1, 3, "abc")
        == Token(123, 1, 3, "abcd")
    ), "Method Token.__eq__ is not correct"

    assert (
        Token(123, 1, 3, "abc")
        != Token(124, 1, 3, "abc")
    ), "Method Token.__eq__ is not correct"

    assert (
        Token(123, 1, 4, "abc")
        != Token(123, 1, 3, "abc")
    ), "Method Token.__eq__ is not correct"

    assert (
        Token(123, 2, 3, "abc")
        != Token(123, 1, 3, "abc")
    ), "Method Token.__eq__ is not correct"



# Generated at 2022-06-24 11:26:01.705989
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken(value=[], start_index=1, end_index=2, content="23") ==\
        ListToken(value=[], start_index=1, end_index=2, content="23")


# Generated at 2022-06-24 11:26:08.488525
# Unit test for method lookup of class Token
def test_Token_lookup():
    # test for class ScalarToken
    token = ScalarToken(value=123, start_index=0, end_index=2)
    assert token.lookup([0]) == token
    assert token.lookup([]) == token
    # test for class DictToken
    token_scalar = ScalarToken(value=123, start_index=0, end_index=2)
    token_dict = DictToken(value={token_scalar: token_scalar}, start_index=0, end_index=2)
    assert token_dict.lookup([0]) == token_scalar
    assert token_dict.lookup([]) == token_dict
    # test for class ListToken
    token_list = ListToken(value=[token_scalar], start_index=0, end_index=2)


# Generated at 2022-06-24 11:26:14.675191
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token("foo", 0, 2, "foobar")
    assert repr(token) == "Token('foo')"



# Generated at 2022-06-24 11:26:18.257810
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken(["", 0, 1])
    assert token._value == ["", 0, 1]
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == ""

test_ListToken()

# Generated at 2022-06-24 11:26:26.265201
# Unit test for constructor of class Token
def test_Token():  # pragma: no cover
    string = '1234567'
    start_index = 2
    end_index = 4
    token1 = Token(None, start_index, end_index, string)
    expected_string = '34'
    assert token1.string == expected_string
    assert token1.value is None
    assert token1.start_index == start_index
    assert token1.end_index == end_index
    expected_position = Position(1, 2, 2)
    actual_position = token1.start
    assert actual_position == expected_position
    expected_position = Position(1, 4, 4)
    actual_position = token1.end
    assert actual_position == expected_position
    assert token1.lookup([]) == token1
    return token1



# Generated at 2022-06-24 11:26:33.145680
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert repr(ScalarToken(None, 0, 1, "abc")) == "ScalarToken('abc')"
    assert repr(DictToken({ScalarToken(None, 0, 1, "abc"): ScalarToken(None, 0, 1, "abc")}, 0, 1, "abc")) == 'DictToken({ScalarToken(\'abc\'): ScalarToken(\'abc\')})'
    assert repr(ListToken([ScalarToken(None, 0, 1, "abc")], 0, 1, "abc")) == 'ListToken([ScalarToken(\'abc\')])'


# Generated at 2022-06-24 11:26:43.350645
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class DictToken(Token):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)
            self._child_keys = {k._value: k for k in self._value.keys()}
            self._child_tokens = {k._value: v for k, v in self._value.items()}

        def _get_value(self) -> typing.Any:
            return {
                key_token._get_value(): value_token._get_value()
                for key_token, value_token in self._value.items()
            }

        def _get_child_token(self, key: typing.Any) -> Token:
            return self._child_tokens[key]


# Generated at 2022-06-24 11:26:50.033753
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token(value="", start_index=0, end_index=1, content="")
    assert token.__repr__() == "Token('')"

    token = Token(value=1, start_index=0, end_index=1, content="")
    assert token.__repr__() == "Token('1')"



# Generated at 2022-06-24 11:26:51.856220
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    try:
        raise NotImplementedError("No test cases defined yet")
    except Exception as e:
        print("Error: %s" % str(e))
        raise e


# Generated at 2022-06-24 11:26:54.947233
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    a = Token(1, 2, 3)
    b = Token(1, 2, 3)
    c = Token(1, 0, 2)
    assert (a==b)
    assert not (a==c)



# Generated at 2022-06-24 11:26:58.309469
# Unit test for constructor of class Token
def test_Token():
    start_index = 3
    end_index = 5
    content = ''
    token = Token(tuple(), start_index, end_index, content)

    assert token._start_index == start_index
    assert token._end_index == end_index
    assert token._content == content



# Generated at 2022-06-24 11:27:06.046521
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # create a Token for testing
    value = mock.Mock()
    start_index = mock.Mock()
    end_index = mock.Mock()
    content = mock.Mock()
    input_object = Token(value, start_index, end_index, content)
    # call method __repr__ of the Token object
    actual_result = input_object.__repr__()
    # assert
    assert actual_result == (
        "Token(%s)" % repr(content[start_index : end_index + 1])
    )


# Generated at 2022-06-24 11:27:13.445840
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({}, 0, 0)
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._value == {}


# Generated at 2022-06-24 11:27:24.681998
# Unit test for method lookup of class Token
def test_Token_lookup():
    class MyToken(Token):
        def __init__(self, value: typing.Any, start_index: int, end_index: int, content: str = "") -> None:
            super().__init__(value, start_index, end_index, content)

        def _get_value(self) -> typing.Any:
            raise NotImplementedError  # pragma: nocover

        def _get_child_token(self, key: typing.Any) -> "Token":
            raise NotImplementedError  # pragma: nocover

        def _get_key_token(self, key: typing.Any) -> "Token":
            raise NotImplementedError  # pragma: nocover

    import pytest
    from typesystem.base import Scalar


# Generated at 2022-06-24 11:27:27.455311
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    tok = ScalarToken(5, 0, 0)
    assert tok.value == 5
    assert tok.string == "5"
    assert tok.start == Position(1, 1, 0)
    assert tok.end == Position(1, 1, 0)


# Generated at 2022-06-24 11:27:28.628037
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken(["test"], 0, 3, "test")

# Generated at 2022-06-24 11:27:31.407392
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {"key": "value"}
    a = DictToken(d,0,3)
    assert a._value == d
    assert a._start_index == 0
    assert a._end_index == 3


# Generated at 2022-06-24 11:27:35.517234
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert ScalarToken(1, 0, 10) == ScalarToken(1, 0, 10)
    assert not ScalarToken(1, 0, 10) == ScalarToken(2, 0, 10)
    assert not ScalarToken(1, 0, 10) == ScalarToken(1, 1, 10)
    assert not ScalarToken(1, 0, 10) == ScalarToken(1, 0, 11)



# Generated at 2022-06-24 11:27:39.489742
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    class SimpleToken(Token):
        def __init__(*args: typing.Any, **kwargs: typing.Any) -> None:
            pass
    simple_token = SimpleToken(None, 0, 0)
    assert str(simple_token) == "SimpleToken('<>')"

# Generated at 2022-06-24 11:27:42.684462
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # assert False # TODO: implement your test here
    assert True # TODO: implement your test here


# Generated at 2022-06-24 11:27:44.178337
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(1, 0, 1)
    assert hash(token) == 1


# Generated at 2022-06-24 11:27:56.116858
# Unit test for method lookup of class Token
def test_Token_lookup():
    j = [{"key": "value"}, [{"key": "value"}, 1234]]
    token = ListToken([DictToken({ScalarToken("key", 0, 2, "key"): ScalarToken("value", 6, 10, "value")}),
                       ListToken([DictToken({ScalarToken("key", 0, 2, "key"): ScalarToken("value", 6, 10, "value")}),
                                  ScalarToken(1234, 20, 23, "1234")])
                       ], 0, 26, "[{'key': 'value'}, [{'key': 'value'}, 1234]]")
    assert token.lookup([1, 0]).string == "[{'key': 'value'}, 1234]"
    assert token.lookup([1, 0]).value == [{"key": "value"}, 1234]


# Generated at 2022-06-24 11:27:57.525975
# Unit test for method lookup of class Token
def test_Token_lookup():
    content = "content"
    token = Token(0, 0, 0, content)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert token.string == ""

# Generated at 2022-06-24 11:27:59.161159
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken('14', '20', 'sig')


# Generated at 2022-06-24 11:28:08.842347
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    original_string = "Hello World!"
    index = [0, 0, 0]
    # W = [1, 4]
    # e = [1, 1]
    # l = [0, 2]
    # l = [0, 3]
    # o = [0, 4]
    # _ = [0, 5]
    # W = [1, 0]
    # o = [1, 1]
    # r = [1, 2]
    # l = [1, 3]
    # d = [1, 4]
    # ! = [1, 5]
    # content = ['Hello ', 'World!']
    # _start_index = [0, 6]
    # _end_index = [5, 12]
    # Note: because of [0, 0, 0], start_index is 6, which

# Generated at 2022-06-24 11:28:20.355019
# Unit test for method __eq__ of class Token

# Generated at 2022-06-24 11:28:27.873547
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from random import randint
    from typesystem.base import String, Number

    s_list: list = ['Hello', 'world', '!', '', '']
    n_list: list = [randint(0, 100), randint(0, 100), randint(0, 100), randint(0, 100)]
    for s in s_list:
        for n in n_list:
            x1: ScalarToken = ScalarToken(String, s, n, s)
            assert x1.__eq__(x1) == True

# Generated at 2022-06-24 11:28:30.004400
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token("value", 0, 4, content="content")
    assert token.__repr__() == "Token(value)"



# Generated at 2022-06-24 11:28:34.996875
# Unit test for constructor of class Token
def test_Token():
    test_token = Token(
        value = "Hello world!",
        start_index = 0,
        end_index = 3,
        content = "Hello world!"
    )
    assert test_token._value == "Hello world!"
    assert test_token._start_index == 0
    assert test_token._end_index == 3
    assert test_token._content == "Hello world!"


# Generated at 2022-06-24 11:28:38.667937
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(1, 0, 1, "1")
    assert hash(token) == hash(1)

# Generated at 2022-06-24 11:28:47.373490
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import ScalarToken, Token, Position
    from typesystem.parser import Parser
    from typesystem.parser.dict import DictToken
    parser = Parser()
    value = {
        ScalarToken('first_name', 0, 9, "John Smith") : ScalarToken('John', 0, 3, "John Smith"),
        ScalarToken('last_name', 10, 19, "John Smith") : ScalarToken('Smith', 6, 11, "John Smith")
    }
    token = Token("John Smith", 0, 19, "John Smith")
    dict_token = DictToken(value, 0, 19, "John Smith")



# Generated at 2022-06-24 11:28:51.156019
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    _value = object()
    _start_index = int()
    _end_index = int()
    _content = str()
    token = Token(_value, _start_index, _end_index, _content)
    print(repr(token))


# Generated at 2022-06-24 11:28:55.104338
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    a = ScalarToken("value",1,2)
    assert (a.string=="value")
    assert (a.value=="value")
    assert (a.start.index==1)
    assert (a.end.index==2)


# Generated at 2022-06-24 11:29:02.130724
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # simple test
    res = repr(Token(1, 2, 3))
    assert res == "Token(1)"
    # more sophisticated test
    res = repr(Token(object(), 2, 3, "abc"))
    assert res == "Token('abc')"

# Generated at 2022-06-24 11:29:04.682768
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    a = ScalarToken("a", 1, 2)
    assert a.__hash__() == "a".__hash__()


# Generated at 2022-06-24 11:29:12.609094
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Test basic true case
    t = ScalarToken("string_value", 0, 2)
    assert t.__repr__() == "ScalarToken('str')"

    # Test basic false case
    t2 = ScalarToken("string_value", 0, 5)
    assert t2.__repr__() != "ScalarToken('str')"

    # Test if __repr__ does not crash if length of content is zero
    t2 = ScalarToken("string_value", 0, 4)
    assert t2.__repr__() == "ScalarToken('')"

    # Test if __repr__ does not create an Index Out of Range exception
    # if the string content is empty
    t2 = ScalarToken("string_value", 0, -1)

# Generated at 2022-06-24 11:29:21.276705
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    class A(Token):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)
    repr_ = A(1, 2, 3, content="").__repr__()
    assert repr_ == "A('1')"


# Generated at 2022-06-24 11:29:30.474993
# Unit test for method lookup of class Token
def test_Token_lookup():
    from typesystem.base import String

    token = String(name="test").validate("/some/path")
    assert token.lookup([0]).value == "/"
    assert token.lookup([1]).value == "s"
    assert token.lookup([2]).value == "o"
    assert token.lookup([3]).value == "m"
    assert token.lookup([4]).value == "e"
    assert token.lookup([5]).value == "/"
    assert token.lookup([6]).value == "p"
    assert token.lookup([7]).value == "a"
    assert token.lookup([8]).value == "t"
    assert token.lookup([9]).value == "h"



# Generated at 2022-06-24 11:29:35.470350
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("string", 1, 2, "string is a word")
    expected_value = "string"
    expected_start = Position(1, 1, 1)
    expected_end = Position(1, 2, 2)
    assert token._value == expected_value
    assert token.start == expected_start
    assert token.end == expected_end
    assert token.string == expected_value


# Generated at 2022-06-24 11:29:38.549073
# Unit test for constructor of class Token
def test_Token():
    token = Token(value = "Hello", start_index = 0, end_index = 2, content = "Hello")
    assert token.string == "Hel"
    assert token.start.index == 0
    assert token.end.index == 2



# Generated at 2022-06-24 11:29:41.734058
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(42, 0, 1)
    assert hash(token) == 42
    assert hash(42) == 42
    assert hash(token) == hash(42)


# Generated at 2022-06-24 11:29:51.181556
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert repr(Token(value='', start_index=0, end_index=(-1))) == "Token('', 0, -1)"
    assert repr(Token(value='fBAr', start_index=0, end_index=3, content='fBAr')) == "Token('fBAr', 0, 3, 'fBAr')"
    assert repr(Token(value='', start_index=0, end_index=1, content='')) == "Token('', 0, 1, '')"
    assert repr(Token(value='fBAr', start_index=1, end_index=3, content='fBAr')) == "Token('fBAr', 1, 3, 'fBAr')"

# Generated at 2022-06-24 11:29:54.537031
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = ListToken(["a", "b"], 0, 3, "string")
    assert(token.lookup([1]) == token._value[1])


# Generated at 2022-06-24 11:30:05.186547
# Unit test for constructor of class ListToken
def test_ListToken():
    test = ListToken([1, 2, 3, 4], 0, 10, "123456789")
    assert test._value == [1, 2, 3, 4]
    assert test._start_index == 0
    assert test._end_index == 10
    assert test._content == "123456789"
    assert test.string == "123456789"
    assert test.value == [1, 2, 3, 4]
    assert test.start == Position(1, 1, 0)
    assert test.end == Position(11, 1, 10)
    assert test.lookup([0]) == 1
    assert test.lookup([1]) == 2
    assert test.lookup([2]) == 3
    assert test.lookup([3]) == 4

# Generated at 2022-06-24 11:30:15.522910
# Unit test for method __eq__ of class Token
def test_Token___eq__():

    # __eq__ is implemented in the base class, so we test it via the ScalarToken.
    yaml_document = """
    1
    2
    3
    """
    yaml_content = yaml_document
    t1 = ScalarToken(value=1, start_index=0, end_index=0, content=yaml_content)
    t2 = ScalarToken(value=2, start_index=0, end_index=2, content=yaml_content)
    t3 = ScalarToken(value=3, start_index=0, end_index=4, content=yaml_content)
    assert t1 == t1
    assert not (t1 == t2)
    assert not (t1 == t3)
    assert t2 == t2
    assert not (t2 == t3)


# Generated at 2022-06-24 11:30:18.420392
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(True, 1, 5, "True")
    assert token.string == "True"
    assert token.value == True


# Generated at 2022-06-24 11:30:20.185395
# Unit test for constructor of class Token
def test_Token():
    tok = Token('abc', 1, 3)
    assert tok.string == 'bc'


# Generated at 2022-06-24 11:30:27.248622
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(4, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 4, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 5)
    assert Token(1, 2, 3) == ScalarToken(1, 2, 3)


# Generated at 2022-06-24 11:30:30.828515
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    ScalarToken(3, 0, 0)
    ScalarToken("foo", 0, 0)
    ScalarToken(["a", "b"], 0, 0)
    ScalarToken({"1": "2", "3": "4"}, 0, 0)


# Generated at 2022-06-24 11:30:32.923896
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    t = ListToken([], 0, 0, '[]')
    assert t.lookup_key([0]) == t

# Generated at 2022-06-24 11:30:43.728893
# Unit test for method lookup of class Token
def test_Token_lookup():
    lst_token = ListToken([1,2,3], 0, 10, '0123456789')
    dct_token = DictToken(
        {
            ScalarToken(1, 0, 1, '0123456789'):
            ScalarToken(2, 3, 4, '0123456789')
        },
        0,
        10,
        '0123456789'
    )

    assert lst_token.lookup([])._value == [1,2,3]
    assert lst_token.lookup([0]) == 1

    assert dct_token.lookup([])._value == {1: 2}
    assert dct_token.lookup([(1, 2)]) == 2
    assert dct_token.lookup([1]) == 2

# Unit

# Generated at 2022-06-24 11:30:47.662186
# Unit test for constructor of class ListToken
def test_ListToken():
    from .test_tokens import t
    tt = t.ListToken([t.SampleToken(1, 10, 15, "test")])



# Generated at 2022-06-24 11:30:51.261385
# Unit test for constructor of class ListToken
def test_ListToken():
    data = [4, 5, 6]
    token = ListToken(data, 1, 5)
    assert token._value == data
    assert token._start_index == 1
    assert token._end_index == 5
    assert token._content == ""



# Generated at 2022-06-24 11:30:58.750123
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    with_list = ScalarToken('list', 0, 0)
    with_list2 = ScalarToken('list', 0, 0)
    assert with_list.__hash__() == with_list2.__hash__()

    without_list = ScalarToken(list, 0, 0)
    without_list2 = ScalarToken(list, 0, 0)
    assert without_list.__hash__() == without_list2.__hash__()

test_ScalarToken___hash__()


# Generated at 2022-06-24 11:31:09.548374
# Unit test for constructor of class DictToken
def test_DictToken():
    pos1 = Position(1, 1, 0)
    pos2 = Position(1, 2, 1)
    start_index = 0
    end_index = 1
    token1 = ScalarToken(1, start_index, end_index)
    token2 = ScalarToken(2, start_index, end_index)
    value = {token1: token2}
    content = "abc"
    token = DictToken(value, start_index, end_index, content)
    assert token._value == value
    assert token.string == content[start_index: end_index+1]
    assert token.start == pos1
    assert token.end == pos2


# Generated at 2022-06-24 11:31:17.882571
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    value = "test"
    start_index = 0
    end_index = 3
    token = ScalarToken(value, start_index, end_index)
    assert token.string == "test"
    assert token.value == "test"
    assert token.start.index == 0
    assert token.start.line == 1
    assert token.start.column == 1
    assert token.end.index == 3
    assert token.end.line == 1
    assert token.end.column == 4
    assert token.lookup([]) == token


# Generated at 2022-06-24 11:31:19.473446
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token(1, 2, 4, 'a_content')
    assert(str(token) == "Token('_con')")



# Generated at 2022-06-24 11:31:26.370684
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    print("\nUnit test for constructor of class ScalarToken")
    try:
        ScalarToken(None, 0, 0)
    except NotImplementedError:
        print("Unit test for constructor of class ScalarToken: not implemented")
        return
    except Exception as exception:
        print("Unit test for constructor of class ScalarToken: unknown exception")
        return
    print("Unit test for constructor of class ScalarToken: normal execution")
    return
