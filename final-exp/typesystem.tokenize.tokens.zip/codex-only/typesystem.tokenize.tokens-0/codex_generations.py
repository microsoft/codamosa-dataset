

# Generated at 2022-06-24 11:21:28.454319
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    key_token = ScalarToken(value = True, start_index = None, end_index = None)
    value_token = ScalarToken(value = 1, start_index = None, end_index = None)
    dict_token = DictToken(value = {key_token : value_token}, start_index = None, end_index = None)
    list_token = ListToken(value = [dict_token], start_index = None, end_index = None)
    assert list_token.lookup_key([0 , True]) == key_token

# Generated at 2022-06-24 11:21:31.354808
# Unit test for constructor of class ListToken
def test_ListToken():
    list_token = ListToken(value = [1, 2, 3], start_index = 1, end_index = 5, content = "12345")
    assert list_token.start == Position(1, 2, 1)
    assert list_token.end == Position(1, 6, 5)


# Generated at 2022-06-24 11:21:33.937351
# Unit test for method lookup of class Token
def test_Token_lookup():
    assert Token
    try:
        Token.lookup([])
        assert False, "Should raise a NotImplementedError exception"
    except NotImplementedError:
        pass


# Generated at 2022-06-24 11:21:36.970672
# Unit test for constructor of class Token
def test_Token():
    token = Token('', 0, 0, content='')
    assert token.string == ''


# Generated at 2022-06-24 11:21:43.597997
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert Token(0, 0, 0, "").__repr__() == 'Token(0)'
    assert Token(1, 1, 1, "").__repr__() == 'Token(1)'
    assert ScalarToken(None, 2, 2, "").__repr__() == "ScalarToken('None')"
    assert ScalarToken(True, 3, 3, "").__repr__() == "ScalarToken('True')"
    assert ScalarToken(4, 4, 4, "").__repr__() == 'ScalarToken(4)'


# Generated at 2022-06-24 11:21:52.073975
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert repr(ScalarToken(1, 1, 1)) == "ScalarToken(1)"
    assert repr(ScalarToken('abcd', 1, 1)) == "ScalarToken('abcd')"
    assert repr(ScalarToken(True, 1, 1)) == "ScalarToken(True)"
    assert repr(ScalarToken(None, 1, 1)) == "ScalarToken(None)"
    assert repr(DictToken({1: 2}, 1, 1)) == "DictToken({1: 2})"
    assert repr(DictToken({1: 2, 3: 4}, 1, 1)) == "DictToken({1: 2, 3: 4})"
    assert repr(ListToken([1, 2, 3], 1, 1)) == "ListToken([1, 2, 3])"

# Generated at 2022-06-24 11:21:52.928644
# Unit test for method lookup of class Token
def test_Token_lookup():
    Token.lookup()


# Generated at 2022-06-24 11:21:58.500718
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    hash_instance1 = ScalarToken(10, 5, 10, content='abc')
    hash_instance2 = ScalarToken(10, 5, 10, content='abc')

    assert hash_instance1.__hash__() == hash_instance2.__hash__()


# Generated at 2022-06-24 11:22:00.386350
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token(1, 1, 2, 'abc')
    assert token.__repr__() == "Token(<abc>)"

# Generated at 2022-06-24 11:22:10.908801
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token1 = ScalarToken(
        value=0, start_index=0, end_index=0, content="abc"
    )

    assert repr(token1) == "ScalarToken('a')"

    token2 = ScalarToken(
        value=dict(), start_index=0, end_index=0, content="abc"
    )

    assert repr(token2) == "ScalarToken('a')"

    token3 = ScalarToken(
        value="a", start_index=0, end_index=0, content="abc"
    )

    assert repr(token3) == "ScalarToken('a')"

    token4 = ScalarToken(
        value=1, start_index=0, end_index=0, content="abc"
    )


# Generated at 2022-06-24 11:22:14.265978
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    test = ScalarToken('1', 0, 1,  'should be a number')
    if test != ScalarToken('1', 0, 1,  'should be a number'):
        raise AssertionError


# Generated at 2022-06-24 11:22:16.480483
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert repr(Token(1, 0, 1, 'a')) == "Token('a')"



# Generated at 2022-06-24 11:22:20.685335
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_one = Token(1, 0, 1, "1")
    token_two = Token(2, 1, 2, "2")
    assert (token_one == token_one) is True
    assert (token_one == token_two) is False



# Generated at 2022-06-24 11:22:22.650969
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken("foo", 0, 2, "foo")
    assert hash(token) == hash("foo")
    token = ScalarToken(None, 0, 2, "foo")
    assert hash(token) == hash(None)


# Generated at 2022-06-24 11:22:32.083137
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    dict_token = DictToken(
        {
            ScalarToken("foo", 1, 7, content="a={'foo':'bar'}\n"): ScalarToken(
                "bar", 9, 13, content="a={'foo':'bar'}\n"
            )
        },
        1,
        13,
        content="a={'foo':'bar'}\n",
    )
    assert dict_token.lookup_key([0]) == ScalarToken("foo", 1, 7, content="a={'foo':'bar'}\n")
    content = "a=['bar','baz']"

# Generated at 2022-06-24 11:22:35.257629
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    s = ScalarToken("a", 1, 1)
    assert s.value == "a"
    assert s.string == "a"
    assert s.start == Position(1, 1, 1)
    assert s.end == Position(2, 1, 2)


# Generated at 2022-06-24 11:22:37.610280
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {}
    a = DictToken(d, 0, 0, "")
    assert repr(a) == "DictToken({})", repr(a)


# Generated at 2022-06-24 11:22:38.810080
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    assert True


# Generated at 2022-06-24 11:22:40.902204
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = ScalarToken(None, 0, 0)
    other = ScalarToken(None, 1, 1)
    assert token == other

# Generated at 2022-06-24 11:22:45.253830
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken([1, 2], 0, 0, "\nabc")
    assert token._value == [1, 2]
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == "\nabc"
    assert token._get_position(0) == Position(1, 1, 0)


# Generated at 2022-06-24 11:22:53.967220
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Test for method __repr__ of class Token
    # Token.__repr__:
    # This method returns a representation of the token, like a Python literal.

    # scalar value
    token = ScalarToken(value="", start_index=0, end_index=1)
    assert repr(token) == "ScalarToken('')"

    token = ScalarToken(value="abc", start_index=0, end_index=2)
    assert repr(token) == "ScalarToken('ab')"

    token = ScalarToken(value=123, start_index=0, end_index=1)
    assert repr(token) == "ScalarToken('1')"

    token = ScalarToken(value=True, start_index=0, end_index=1)

# Generated at 2022-06-24 11:22:55.483567
# Unit test for method lookup of class Token
def test_Token_lookup():
    assert Token._get_position(1) == Position(1, 1, 1)
    assert Token._get_position(0) == Position(1, 1, 0)

# Generated at 2022-06-24 11:23:06.607946
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    st = ScalarToken(1,1,1)
    assert isinstance(st, ScalarToken)
    assert st._value == 1
    assert st._start_index == 1
    assert st._end_index == 1
    assert st._content == ""
    st = ScalarToken("abc",1,1)
    assert isinstance(st, ScalarToken)
    assert st._value == "abc"
    assert st._start_index == 1
    assert st._end_index == 1
    assert st._content == ""
    st = ScalarToken("abc",1,1,"abc")
    assert isinstance(st, ScalarToken)
    assert st._value == "abc"
    assert st._start_index == 1
    assert st._end_index == 1
    assert st._content == "abc"


# Generated at 2022-06-24 11:23:09.598765
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert ScalarToken(
        value="foo", start_index=0, end_index=2, content="foo bar"
    ).__hash__() == hash("foo")



# Generated at 2022-06-24 11:23:12.803782
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {1:"one"} 
    t = DictToken(d, 0, 1, content = "")
    assert t._get_value() == {1: "one"}
    assert t.start ==  Position(1, 1, 0)
    

# Generated at 2022-06-24 11:23:17.031510
# Unit test for constructor of class DictToken
def test_DictToken():
    """Unit test for constructor of class DictToken."""
    list_token = ListToken([0, 1, 2], 0, 2, "0\n1\n2")
    dict_token = DictToken({"key": list_token}, 0, 2, "key: 0\n1\n2")
    assert dict_token._value["key"] == list_token

test_DictToken()

# Generated at 2022-06-24 11:23:19.421061
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(
        1, 0, 0
    )
    assert isinstance(token.__hash__(), int)


# Generated at 2022-06-24 11:23:21.735680
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = ScalarToken("test", 0, 3)
    assert repr(token) == "ScalarToken('test')"

# Generated at 2022-06-24 11:23:25.748094
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Setup
    token = Token(
        value = 1,
        start_index = 1,
        end_index = 2,
        content = "abc"
    )
    # Exercise
    result = token.__repr__()
    # Verify
    assert result == "Token(bc)"
    # Cleanup - none necessary



# Generated at 2022-06-24 11:23:29.629516
# Unit test for method lookup of class Token
def test_Token_lookup():
    content = "123"
    start_index = -1
    end_index = -1
    value = "123"
    token = ScalarToken(value=value, start_index=start_index, end_index=end_index, content=content)
    assert token.lookup([]) == token


# Generated at 2022-06-24 11:23:39.493773
# Unit test for constructor of class DictToken
def test_DictToken():
    start_index = 0
    end_index = 3
    dict_token = DictToken({1:2, 3:4}, start_index, end_index)
    assert dict_token.value == {1:2, 3:4}
    assert dict_token.start == Position(line_no = 1, column_no = 1, index = 0)
    assert dict_token.end == Position(line_no = 1, column_no = 4, index = 3)

    # test lookup
    index = [1, 3]
    assert dict_token.lookup(index) == 4

    # test lookup_key
    assert dict_token.lookup_key(index) == 1


# Generated at 2022-06-24 11:23:47.236266
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # List token with one scalar token
    list_token = ListToken([ScalarToken(1, 0, 0, "1")], 0, 0, "1")

    # index = [0]
    index_first_child = [0]

    # key_token
    key_token = list_token.lookup_key(index_first_child)

    # actual result
    expected_result = ScalarToken(1, 0, 0, "1")

    # assertion
    assert(key_token == expected_result)

# Generated at 2022-06-24 11:23:58.315739
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from unittest import mock, TestCase

    class TestToken(Token):
        def _get_value(self):
            return self._value

    class TestScalarToken(ScalarToken):
        def _get_value(self):
            return self._value

    class TestDictToken(DictToken):
        def _get_value(self):
            return self._value

    class TestListToken(ListToken):
        def _get_value(self):
            return self._value

    class TestToken___eq__(TestCase):
        def test_ScalarToken(self):
            token = TestToken('value', 0, 1, content='content')
            scalar_token = TestScalarToken('value', 0, 1, content='content')
            assert token == token
            assert token == scalar_token
           

# Generated at 2022-06-24 11:24:06.316378
# Unit test for method lookup of class Token
def test_Token_lookup():
    # Test lookup on a scalar token
    token = ScalarToken('stringer', 1, 2, 'quoted')
    with pytest.raises(NotImplementedError):
        token.lookup([])
    
    # Test lookup on a dict token
    token = DictToken({'stringer': ScalarToken('stringer', 1, 2, 'quoted')}, 1, 2, 'quoted')
    assert token.lookup([]) == token
    assert token.lookup(['stringer']) == ScalarToken('stringer', 1, 2, 'quoted')
    with pytest.raises(KeyError):
        token.lookup(['stringer', 'stringer'])

    # Test lookup on a list token

# Generated at 2022-06-24 11:24:07.521144
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken([], 0, 0, "")



# Generated at 2022-06-24 11:24:18.337566
# Unit test for constructor of class Token
def test_Token():
    t1 = Token(1, 2, 3, "abc")
    assert t1.string == "b"
    assert t1.value == 1
    assert t1.start == Position(1, 2, 2)
    assert t1.end == Position(1, 3, 3)
    assert t1.lookup([1]).string == "c"
    assert t1.lookup_key([1]).string == "c"
    assert t1._get_position(0) == Position(1, 1, 0)
    assert t1.__repr__() == "Token(1)"
    # test __eq__()
    t2 = Token(1, 2, 3, "abc")
    assert (t1 == t2)



# Generated at 2022-06-24 11:24:25.834563
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    dict_token1 = DictToken(
        {}, 0, 0, content="{}"
    )
    dict_token2 = DictToken(
        {}, 0, 0, content="{}"
    )
    dict_token = DictToken(
        {
            dict_token1: dict_token2
        },
        0,
        0,
        content="{'key': 'value'}",
    )
    dict_token3 = DictToken(
        {}, 0, 0, content="{}"
    )
    dict_token4 = DictToken(
        {}, 0, 0, content="{}"
    )

# Generated at 2022-06-24 11:24:34.451506
# Unit test for constructor of class DictToken
def test_DictToken():
    # test for constructor
    start_index = 0
    end_index = 0
    # Parameters not in the func
    content = ""
    data = {'key': 'value'}
    token = DictToken(data, start_index, end_index, content)

    tokens_dict = {'key': 'value'}
    key_token = DictToken(data, start_index, end_index, content)
    assert token._value['key'] == value_token

    child_token = token._get_child_token('key')
    assert child_token == token


# Generated at 2022-06-24 11:24:43.085700
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(1, 2, 3)
    t2 = Token(1, 2, 3)

    assert t1.__eq__(t2) == True

    t1 = Token(1, 2, 3)
    t2 = Token(2, 2, 3)

    assert t1.__eq__(t2) == False

    t1 = Token(1, 2, 3)
    t2 = Token(1, 3, 3)

    assert t1.__eq__(t2) == False

    t1 = Token(1, 2, 3)
    t2 = Token(1, 2, 4)

    assert t1.__eq__(t2) == False

# Generated at 2022-06-24 11:24:50.292455
# Unit test for constructor of class Token
def test_Token():
    value = "example"
    t = Token(value, 0, 5)
    assert str(t.string) == "example"
    assert str(t.value) == "example"
    assert str(t.start.line_no) == "1"
    assert str(t.start.column_no) == "1"
    assert str(t.start.index) == "0"
    assert str(t.end.line_no) == "1"
    assert str(t.end.column_no) == "6"
    assert str(t.end.index) == "5"
    assert t.lookup([]) is t
    assert t.lookup_key([]) is t
    value = {"key":"value"}
    t = DictToken(value, 0, 5)

# Generated at 2022-06-24 11:24:55.114853
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    test = ScalarToken("test", 0, 3)
    assert test.string == "test"
    assert test.value == "test"
    assert test.start == Position(line_no=1, column_no=1, index=0)
    assert test.end == Position(line_no=1, column_no=4, index=3)


# Generated at 2022-06-24 11:25:00.901389
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    obj = ScalarToken(
        value="test value",
        start_index=0,
        end_index=12,
        content="test value string",
    )
    result = obj.__hash__()
    assert result == hash("test value")


# Generated at 2022-06-24 11:25:06.775254
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("test", 1, 3, content="test")
    assert(token.string == "test")
    assert(token.value == "test")
    assert(token.start == Position(1,1,1))
    assert(token.end == Position(1,3,3))
    assert(repr(token) == "ScalarToken('test')")
    assert(token == ScalarToken("test", 1, 3, content="test"))
    assert(not token == ScalarToken("test", 2, 3, content="test"))
    assert(not token == ScalarToken("test", 1, 4, content="test"))

if __name__ == '__main__':
    import pytest, sys
    sys.exit(pytest.main(["-qq", __file__]))

# Generated at 2022-06-24 11:25:08.307208
# Unit test for constructor of class Token
def test_Token():
    Token("value", 1, 2, "content")

# Generated at 2022-06-24 11:25:11.586125
# Unit test for constructor of class DictToken
def test_DictToken():
    x = DictToken(1, 2, 3, value={}, start_index=1, end_index=2, content="")


# Generated at 2022-06-24 11:25:15.147152
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken([1,2,4], 0, 2) == ListToken([1,2,4], 0, 2)


# Generated at 2022-06-24 11:25:15.725042
# Unit test for constructor of class Token
def test_Token():
    assert True

# Generated at 2022-06-24 11:25:20.823087
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    items = dict(key=1)
    list_token = ListToken(items, 1, 9)
    dict_token = DictToken(items, 0, 9)

    assert dict_token._get_key_token(1) is list_token
    assert dict_token.lookup_key([1]) is list_token
    with pytest.raises(KeyError):
        dict_token.lookup_key([4])



# Generated at 2022-06-24 11:25:29.886354
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    """
    Test for method __hash__ of class ScalarToken
    """
    string = "string"
    start_index = 1
    end_index = 2
    content = "content"
    scalartoken = ScalarToken(string, start_index, end_index, content)
    assert hash(string) == scalartoken.__hash__()



# Generated at 2022-06-24 11:25:32.692975
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    t = ScalarToken(value = '123', start_index = 0, end_index = 2)
    assert hash(t) == hash('123')


# Generated at 2022-06-24 11:25:37.030359
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token('value', 'start_index', 'end_index')
    assert token.__eq__(Token('value', 'start_index', 'end_index'))


# Generated at 2022-06-24 11:25:39.354725
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token._Token__eq__(None, None) == NotImplemented


# Generated at 2022-06-24 11:25:41.260427
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    assert Token._get_position(0,0)==Position(0,0,0)

# Generated at 2022-06-24 11:25:42.865880
# Unit test for constructor of class ListToken
def test_ListToken():
    a = ListToken()


# Generated at 2022-06-24 11:25:50.503687
# Unit test for method lookup of class Token
def test_Token_lookup():
    import pytest
    from typesystem import Array, Dict

    token = Dict().load({'artists':[{'name':'foo'},{'name':'bar'}]})
    assert type(token) is DictToken
    print(token)
    print(token.lookup([0,1]).string)
    assert token.lookup([0,0]).string == 'foo'
    assert token.lookup([0,1]).string == 'bar'

    #with pytest.raises(IndexError):
    #    token.lookup([1])

# Generated at 2022-06-24 11:26:00.170913
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    # Initialize a ScalarToken with value 'test' at position (1,1,1)
    # This will be useful in testing other functions later
    token = ScalarToken('test', 0, 3)
    # Check if it is a instance of ScalarToken
    assert isinstance(token, ScalarToken)
    # Check if value is correctly stored
    assert token._get_value() == 'test'
    # Check if start and end index are correctly stored
    assert token._start_index == 0
    assert token._end_index == 3
    # Check if start and end positions are correctly stored
    assert token.start == Position(1, 1, 1)
    assert token.end == Position(1, 5, 5)
    # Check if the string stored matches the value stored
    assert token.string == 'test'
    # Check if repr(token

# Generated at 2022-06-24 11:26:03.698245
# Unit test for constructor of class DictToken
def test_DictToken():
    dtk = DictToken(1, 2, 3)
    assert(dtk._start_index == 1)
    assert(dtk._end_index == 2)
    assert(dtk._content == 3)


# Generated at 2022-06-24 11:26:06.258973
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    scalartoken = ScalarToken('value', 1, 2, 'content')
    assert repr(scalartoken) == "ScalarToken('content')"
    scalartoken._content = ''
    assert repr(scalartoken) == "ScalarToken('')"


# Generated at 2022-06-24 11:26:14.807891
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    dict = {'name': 'foo', 
            'phone': '123', 
            'address': {'city': 'Shanghai', 'country': 'China'}, 
            'hobbies': ['football', 'playing']}
    name_index = ['name']
    phone_index = ['phone']
    hobbies_index = ['hobbies', 1]
    pos = Position(1, 1, 0)
    name_token = ScalarToken('foo', 0, 2, 'foo')
    phone_token = ScalarToken('123', 0, 2, '123')
    hobbies1_token = ScalarToken('playing', 0, 6, 'playing')
    hobbies2_token = ScalarToken('football', 0, 8, 'football')

# Generated at 2022-06-24 11:26:17.712229
# Unit test for method __repr__ of class Token
def test_Token___repr__():

    from typesystem.token import Token

    assert str(Token(value='', start_index=0, end_index=0, content='')) == "Token('')"


# Generated at 2022-06-24 11:26:24.737977
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert repr(ScalarToken(True, 0, 0)) == "ScalarToken('True')"
    assert repr(ScalarToken(False, 0, 0)) == "ScalarToken('False')"
    assert repr(ScalarToken(None, 0, 0)) == "ScalarToken('None')"
    assert repr(ScalarToken(123, 0, 0)) == "ScalarToken('123')"
    assert repr(ScalarToken(1.7, 0, 0)) == "ScalarToken('1.7')"
    assert repr(ScalarToken("foo", 0, 0)) == "ScalarToken('foo')"

# Generated at 2022-06-24 11:26:25.806015
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    assert ScalarToken("", 0, 0)


# Generated at 2022-06-24 11:26:27.032715
# Unit test for constructor of class ListToken
def test_ListToken():
    Token=ListToken
    assert Token.__doc__ is not None


# Generated at 2022-06-24 11:26:35.803681
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token=ScalarToken('value',2,4,'con')
    assert token.string=='con'
    assert token.value=='value'
    assert token.start==Position(1,1,2)
    assert token.end==Position(1,3,4)
    assert token.lookup([])==token
    assert(token.lookup_key([0])==token)
    assert token.__repr__()=='ScalarToken(\'con\')'
    assert token==ScalarToken('value',0,4,'con')
    assert token==ScalarToken('value',2,9,'concon')
    assert not(token==ScalarToken('value',2,5,'con'))
    assert not(token==ScalarToken('value',3,4,'con'))

# Generated at 2022-06-24 11:26:43.135342
# Unit test for constructor of class DictToken
def test_DictToken():
    # arg1
    arg1 = DictToken()
    assert arg1 is not None
    assert arg1._get_value() == {}
    # arg2
    arg2 = DictToken(start_index=1,end_index=2,content="")
    assert arg2 is not None
    assert arg2._get_value() == {}
    # arg3
    arg3 = DictToken(value={},start_index=1,end_index=2,content="")
    assert arg3 is not None
    assert isinstance(arg3, dict)
    assert arg3 == {}
    # arg4
    arg4 = DictToken(value=[],start_index=1,end_index=2,content="")
    assert arg4 is not None
    assert isinstance(arg4, list)
    assert arg4 == []


# Generated at 2022-06-24 11:26:45.311692
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    with pytest.raises(NotImplementedError):
        token = ScalarToken(None, 0, 0, content='')
        hash(token)


# Generated at 2022-06-24 11:26:52.698673
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token('a', 0, 0, content='abc')
    assert token.value == 'a'
    assert token.start.index == 0
    assert token.string == 'a'
    assert token.end.index == 0
    assert token.lookup([1]).start.index == 1
    assert token.lookup_key([1]).start.index == 1
    assert token
    assert token == token


# Generated at 2022-06-24 11:27:00.657532
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class DictToken_faked(DictToken):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(args, kwargs)
            self._child_keys = {k._value: k for k in self._value.keys()}
            self._child_tokens = {k._value: v for k, v in self._value.items()}
    
    a = {
        1: {
            2: 3
        }
    }

    t = DictToken_faked(a, 0, 0, content = "")
    assert(t.lookup_key([0, 1]) == t._child_keys[1])

# Generated at 2022-06-24 11:27:06.384395
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    fran = ScalarToken('fran', 1, 4)
    charlotte = ScalarToken('charlotte', 9, 18)
    token = DictToken([(fran, charlotte),], 0, 25)
    result = token.lookup_key([0])
    expected = fran
    assert result == expected

if __name__ == '__main__':
    test_Token_lookup_key()

# Generated at 2022-06-24 11:27:20.272317
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class TestToken(Token):
        def __init__(self, value, start_index, end_index, content) -> None:
            self._value = value
            self._start_index = start_index
            self._end_index = end_index
            self._content = content
        def _get_value(self):
            return self._value
        def _get_child_token(self, key):
            return self._value[key]
        def _get_key_token(self, key):
            return self._value.keys()[key]
    token = TestToken({"a": "b"}, 0, 4, '{"a":"b"}')
    assert(token.lookup_key([0,0]) == TestToken("a", 1, 2, '{"a":"b"}'))

# Generated at 2022-06-24 11:27:22.874056
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(value=None, start_index=None, end_index=None)
    value = token.__hash__()
    assert value is None


# Generated at 2022-06-24 11:27:32.032703
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    t = DictToken({"a": 1, "b": 2}, 0, 3, content="{'a': 1, 'b': 2}")
    assert t._get_value() == dict(a=1, b=2)
    assert t.start == Position(1, 2, 0)
    assert t.end == Position(1, 16, 3)
    assert t.string == "{'a': 1, 'b': 2}"
    assert t.lookup([]) is t
    assert t.lookup([0]) is t
    assert t.lookup([0, "a"]) == ScalarToken(1, 6, 7, content="{'a': 1, 'b': 2}")

# Generated at 2022-06-24 11:27:38.073270
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Init input and expected output
    value = "test_value"
    start_index = 1
    end_index = 2
    content = "test_content"

    # Call method under test
    token1 = Token(value, start_index, end_index, content)
    token2 = Token(value, start_index, end_index, content)

    # Check results
    assert token1 == token2


# Generated at 2022-06-24 11:27:42.686388
# Unit test for constructor of class Token
def test_Token():
    t = Token(value = 1, start_index = 234, end_index = 345)
    assert t._value == 1
    assert t._start_index == 234
    assert t._end_index == 345


# Generated at 2022-06-24 11:27:50.426421
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    t = ScalarToken(value=typing.Any, start_index=int, end_index=int, content=str)
    # def __init__(
    #     self, value: typing.Any, start_index: int, end_index: int, content: str = ""
    # ) -> None:
    #     self._value = value
    #     self._start_index = start_index
    #     self._end_index = end_index
    #     self._content = content
    assert t._value == typing.Any
    assert t._start_index == int
    assert t._end_index == int
    assert t._content == str


# Generated at 2022-06-24 11:27:52.108612
# Unit test for constructor of class DictToken
def test_DictToken():
	
	assert 1==1

# Generated at 2022-06-24 11:27:58.098240
# Unit test for constructor of class DictToken
def test_DictToken():
    pos_1 = Position(1,1,0)
    dictV = {ScalarToken("test",0,3, "test"): ScalarToken("test1",5,8, "test1")}
    dictT = DictToken(dictV,0,10,"test test1")
    assert dictT._start_index == 0
    assert dictT._end_index == 10
    assert dictT._content == "test test1"


# Generated at 2022-06-24 11:28:02.973620
# Unit test for constructor of class Token
def test_Token():
    start_index = 0
    end_index = 1
    value = start_index
    content = end_index
    tok = Token(value, start_index, end_index, content)
    assert tok._start_index == start_index
    assert tok._end_index == end_index
    assert tok._value == value
    assert tok._content == content

# Generated at 2022-06-24 11:28:12.042486
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    obj = ScalarToken("hello",0,4)
    assert obj.string == "hello"
    assert obj._value == "hello"
    assert obj.start == obj.end
    assert obj.value == "hello"
    assert (
        repr(obj) ==
        "ScalarToken('hello')"
    )
    assert (obj == ScalarToken("hello",0,4)) == True
    assert hash(obj) == hash("hello")
    assert (
        obj.lookup([]) ==
        ScalarToken("hello",0,4)
    )
    assert (
        obj.lookup_key([]) ==
        ScalarToken("hello",0,4)
    )
    assert (
        obj._get_position(2) ==
        Position(1,3,2)
    )

# Generated at 2022-06-24 11:28:15.667078
# Unit test for method lookup of class Token
def test_Token_lookup():
    data = { "a": {"b": [1, 2, 3] }}
    token = data
    assert_equal(token, { "a": { "b": [1, 2, 3]} })
    token = token["a"]
    assert_equal(token, { "b": [1, 2, 3]} )
    token = token["b"]
    assert_equal(token, [1, 2, 3])

# Generated at 2022-06-24 11:28:24.634622
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    """
    Tests that checking for scalar token equality works properly
    """
    token1 = ScalarToken(1, 0, 2)
    token2 = ScalarToken(2, 0, 2)
    token3 = ScalarToken(3, 0, 2)

    tokens = {token1, token2, token3}

    assert token1 in tokens
    assert token2 in tokens
    assert token3 in tokens
    assert ScalarToken(1, 0, 2) in tokens
    assert ScalarToken(2, 0, 2) in tokens
    assert ScalarToken(3, 0, 2) in tokens


# Generated at 2022-06-24 11:28:27.022487
# Unit test for constructor of class ListToken
def test_ListToken():
    l = ListToken([1, 2, 3], 0, 2)
    assert l.start == Position(1, 1, 0)
    assert l.end == Position(1, 4, 2)

# Generated at 2022-06-24 11:28:30.376184
# Unit test for constructor of class ListToken
def test_ListToken():
  content = "[1, 2, 3]"
  t = list(content).index('[')
  y = list(content).index(']')
  value = [1, 2, 3]
  test = ListToken(value, t, y, content)

# Generated at 2022-06-24 11:28:33.858010
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    for cls in [ScalarToken, DictToken, ListToken]:
        token = cls(value="Example", start_index=1, end_index=3, content="abc")
        assert repr(token) == "{}(Example)".format(cls.__name__)

# Generated at 2022-06-24 11:28:36.275370
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    dummysrc = 'a'
    dummytoken = Token(dummysrc, 0, 1, 2)
    assert dummytoken.__repr__() == f"Token({dummysrc})"

# Generated at 2022-06-24 11:28:47.683381
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    stk = ScalarToken(1, 0, 1)
    assert stk.string == "1"
    assert stk.start == Position(1, 1, 0)
    assert stk.end == Position(1, 2, 1)
    assert repr(stk) == "ScalarToken('1')"
    assert stk._get_value() == 1
    assert stk.value == 1
    stk1 = ScalarToken(1, 0, 2)
    assert stk1.string == "10"
    assert stk1.start == Position(1, 1, 0)
    assert stk1.end == Position(1, 3, 2)
    assert repr(stk) == "ScalarToken('1')"
    assert stk1._get_value() == 10
    assert stk1.value == 10

# Generated at 2022-06-24 11:28:50.376174
# Unit test for constructor of class DictToken
def test_DictToken():
    dtoken = DictToken({"key1":"value1","key2":"value2"},1,6,"key1 : value1, key2 : value2")
    assert dtoken._start_index==1
    assert dtoken._end_index==6
    assert dtoken._content =="key1 : value1, key2 : value2"


# Generated at 2022-06-24 11:28:53.105991
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("value", 1, 2)
    assert token._value =="value"
    assert token._start_index == 1
    assert token._end_index == 2


# Generated at 2022-06-24 11:28:55.473637
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = ScalarToken('red', 5, 8)
    assert token.lookup([1]) == token.lookup([2])
    assert token.lookup([3]) != token.lookup([6])

# Generated at 2022-06-24 11:28:57.421578
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    expected = 'DictToken("{0}")'
    assert expected == repr(DictToken(0, 0, 1, "{0}"))

# Generated at 2022-06-24 11:28:59.820418
# Unit test for constructor of class ListToken
def test_ListToken():
    given = ListToken([],0,2)
    expected = [0,2]
    assert given._start_index == expected[0]
    assert given._end_index == expected[1]
    assert given._value == []


# Generated at 2022-06-24 11:29:08.909996
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class DummyObj:
        pass
    obj1 = DummyObj()
    obj2 = DummyObj()
    obj3 = DummyObj()
    obj1.__dict__["_value"] = "Value1"
    obj1.__dict__["_start_index"] = 0
    obj1.__dict__["_end_index"] = 100
    obj2.__dict__["_value"] = "Value1"
    obj2.__dict__["_start_index"] = 0
    obj2.__dict__["_end_index"] = 100
    obj3.__dict__["_value"] = "Value1"
    obj3.__dict__["_start_index"] = 0
    obj3.__dict__["_end_index"] = 100
    assert obj1 == obj2
    assert obj2 == obj3

# Generated at 2022-06-24 11:29:14.360001
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    a = Token("value", 1, 1)
    b = Token("value", 1, 1)
    assert(a == b)

    a = Token("value", 1, 1)
    b = Token("value", 2, 1)
    assert(not (a == b))

    a = Token("value", 1, 1)
    b = Token("value", 1, 2)
    assert(not (a == b))

    a = Token("value", 1, 1)
    b = Token("value2", 1, 1)
    assert(not (a == b))

    a = Token("value", 1, 1, "abc")
    b = Token("value", 1, 1, "def")
    assert(a == b)

    a = Token("value", 1, 1)
    b = 1
    assert(not (a == b))

# Generated at 2022-06-24 11:29:18.475429
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token("value", 1, 2)
    with pytest.raises(NotImplementedError):
        token.lookup(None)


# Generated at 2022-06-24 11:29:26.549996
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("Test", 0, 0)
    assert token.string == "Test"
    assert token.value == "Test"
    assert token.start.line_no == 1
    assert token.start.column_no == 1
    assert token.start.index == 0
    assert token.end.line_no == 1
    assert token.end.column_no == 4
    assert token.end.index == 3
    assert token == ScalarToken("Test", 0, 0)
    assert hash(token) == hash("Test")
    assert token.lookup([]) == token
    assert token.lookup_key([0]) == token
    assert repr(token) == "ScalarToken('Tes')"


# Generated at 2022-06-24 11:29:36.229633
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(None, 0, 1, content='a').__eq__(Token(None, 0, 1, content='a')) == True
    assert Token(None, 0, 1, content='a').__eq__(Token(None, 0, 2, content='a')) == False
    assert Token(None, 0, 1, content='a').__eq__(Token(None, 1, 1, content='a')) == False
    assert Token(None, 0, 1, content='a').__eq__(Token(None, 1, 2, content='a')) == False
    assert Token(None, 0, 1, content='a').__eq__(Token(None, 0, 1, content='b')) == False
    assert Token(None, 0, 1, content='a').__eq__(0) == False


# Generated at 2022-06-24 11:29:37.689883
# Unit test for method lookup of class Token
def test_Token_lookup():
    # Unit test for method lookup of class Token
    t = Token
    print(t)



# Generated at 2022-06-24 11:29:43.806663
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    assert 0
    # code from https://github.com/python/mypy/blob/c7fae45ca8e1c78d34e6c9ae4b4bf8ef4fbb4b4d/mypy/types/dict.py
    def _make_normal_dict_token(token: Token) -> DictToken:
        return DictToken(
            {},
            token._start_index,
            token._end_index,
            token._content,
        )
    token = DictToken(
        {},
        # the following will be arguments to Token
        0,
        0,
        "",
    )
    t = _make_normal_dict_token(token)
    assert t is not None

# Generated at 2022-06-24 11:29:50.666667
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken(1, 2, 3, start_index = 4, end_index = 5, content = "")
    assert t._start_index == 4
    assert t._end_index == 5
    assert t._content == ""
    assert t.string == ""
    assert t.value == 1
    assert t.start == Position(1, 1, 4)
    assert t.end == Position(1, 1, 5)


# Generated at 2022-06-24 11:29:57.772623
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    t = ScalarToken('a', 0, 1, 'b')
    assert t.string == 'b'
    assert t.value == 'a'
    assert t.start == Position(1, 1, 0)
    assert t.end == Position(1, 2, 1)
    assert t.lookup([]) == t
    assert t.lookup_key([]) == t



# Generated at 2022-06-24 11:30:02.126875
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Setup
    value = "value"
    start_index = 1
    end_index = 1
    content = "content"
    token = Token(value, start_index, end_index, content)
    # Exercise
    actual = token.__repr__()
    # Verify
    assert actual == "Token(value)"


# Generated at 2022-06-24 11:30:03.683081
# Unit test for constructor of class Token
def test_Token():
    assert Token(None, 0, 1, "abc")


# Generated at 2022-06-24 11:30:06.096966
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    repr(Token(value="A", start_index=0, end_index=1, content="AB")) == "Token('A')"


# Generated at 2022-06-24 11:30:07.448876
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = ""
    token = token.lookup_key([])
    assert token == token

# Generated at 2022-06-24 11:30:21.214705
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = DictToken({
        ScalarToken(1, 0, 1): ScalarToken(2, 0, 1),
        ScalarToken(3, 0, 1): ScalarToken(4, 0, 1),
    }, 0, 6, "1234")
    assert token.lookup_key((0,)) == ScalarToken(1, 0, 1)
    assert token.lookup_key((1,)) == ScalarToken(3, 2, 3)
    assert token.lookup_key((0, 0)) == ScalarToken(2, 1, 2)
    assert token.lookup_key((1, 0)) == ScalarToken(4, 3, 4)

# Generated at 2022-06-24 11:30:26.616482
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = ScalarToken("", 0, 0)
    assert repr(token) == "ScalarToken('')"
    token = ScalarToken('', 0, 1)
    assert repr(token) == "ScalarToken('+')"


# Generated at 2022-06-24 11:30:30.491176
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    my_token = ScalarToken("scalar", 1, 2)
    assert my_token.value == "scalar"
    assert my_token.start == Position(1, 2, 1)
    assert my_token.end == Position(1, 3, 2)


# Generated at 2022-06-24 11:30:38.643361
# Unit test for constructor of class Token
def test_Token():
    class_name = "Test_Class"
    value = "Test_Value"
    start_index = 0
    end_index = 10
    content = "Test_Content"
    t = Token(value, start_index, end_index, content)
    assert t.string == content[start_index: end_index + 1]
    assert t._start_index == start_index
    assert t._end_index == end_index
    assert t._content == content
    str(t) == "Token(%s)" % repr(content[start_index: end_index + 1])
    assert t.__eq__(t)


# Generated at 2022-06-24 11:30:43.846761
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken(value = [1, 2, 3], start_index = 0, end_index = 1)
    assert token._get_value() == [1, 2, 3]
    assert token.string == ''
    assert token.value == [1, 2, 3]
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 2, 1)



# Generated at 2022-06-24 11:30:48.399769
# Unit test for constructor of class DictToken
def test_DictToken():
    Token_1 = {'x': 1}
    Token_1_obj = DictToken(Token_1, 3, 6, content="{'x': 1}")
    assert Token_1_obj.string == "{'x': 1}"


# Generated at 2022-06-24 11:30:56.800252
# Unit test for constructor of class ListToken
def test_ListToken():
    from typesystem.base import String

    schema = String()
    input = "a"
    token = ListToken([], 0, 1, content=input)
    print(token)
    assert token != None
    assert token.value != None
    assert token.start != None
    assert token.end != None
    assert token.lookup([0]) != None
    assert token.lookup_key([0]) != None
    assert token.__repr__() != None
    assert token.__eq__(None) == False
    assert token._get_value() == None
    assert token._get_position(1) != None
    assert token._get_child_token(0) == None
    assert token._get_key_token(0) == None


# Generated at 2022-06-24 11:31:03.123298
# Unit test for constructor of class DictToken
def test_DictToken():
    class A:
        def __init__(self, value):
            self._value = value
        def _get_value(self):
            return self._value
    # test 1
    a = A(1)
    b = A(2)
    data = {a:b}
    result = DictToken(data, 1, 1, "hello")
    assert result._child_keys == {1:a}
    assert result._child_tokens == {1:b}

# Generated at 2022-06-24 11:31:12.577983
# Unit test for method lookup of class Token
def test_Token_lookup():
    # Create a dictionary
    scalar_token1 = ScalarToken("a", 0, 0)
    scalar_token2 = ScalarToken("b", 1, 1)
    scalar_token3 = ScalarToken("c", 2, 2)
    scalar_token4 = ScalarToken("d", 3, 3)
    list_token1 = ListToken([scalar_token1, scalar_token2], 0, 1, "abc")
    list_token2 = ListToken([scalar_token3, scalar_token4], 2, 3, "abc")
    dict_token = DictToken(
        {list_token1: list_token2}, 0, 3, "abc"
    )
    assert dict_token.lookup_key([0, 0]) == scalar_token1

# Generated at 2022-06-24 11:31:14.306197
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    t = ScalarToken(1, 0, 1, "1")

# Generated at 2022-06-24 11:31:21.972714
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # default
    scalar_token = ScalarToken(value=None, start_index=0, end_index=0)
    assert scalar_token.__hash__() == None

    # custom
    scalar_token = ScalarToken(value=0, start_index=0, end_index=0)
    assert scalar_token.__hash__() == 0

    # custom
    scalar_token = ScalarToken(value="", start_index=0, end_index=0)
    assert scalar_token.__hash__() == ""


# Generated at 2022-06-24 11:31:23.066785
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(0, 0, 0) == Token(0, 0, 0)


# Generated at 2022-06-24 11:31:27.247101
# Unit test for constructor of class ListToken
def test_ListToken():
    import typesystem

    schema = typesystem.Schema(properties={
        'title': typesystem.String(),
    })
    v = schema.load({'title': 'hello world'})
    assert v.errors == []
    assert isinstance(v, ListToken)