

# Generated at 2022-06-24 11:21:27.025903
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token(1, 1, 2, "12")
    assert token.lookup == token.lookup

# Generated at 2022-06-24 11:21:28.446403
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(1, 0, 23)
    assert token._value == 1
    assert token._start_index == 0
    assert token._end_index == 23
    assert token._content == ""



# Generated at 2022-06-24 11:21:29.451676
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(2, 3, 4, "hey")
    assert hash(token) == hash(token._value)



# Generated at 2022-06-24 11:21:31.668640
# Unit test for constructor of class Token
def test_Token():
    token = Token("", 0, 0)
    assert token._value == ""
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""

# Generated at 2022-06-24 11:21:37.922415
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    v = ScalarToken(value = 'alma', start_index = 12, end_index = 15, content = 'hello there alma')
    # test for value
    assert v._value == 'alma'
    # test for start_index
    assert v._start_index == 12
    # test for end_index
    assert v._end_index == 15
    # test for content
    assert v._content == 'hello there alma'
    # test for string
    assert v.string == 'alma'


# Generated at 2022-06-24 11:21:39.800500
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    listToken = ListToken([1,2],0,1,"")
    assert listToken.lookup_key([0]) == listToken



# Generated at 2022-06-24 11:21:42.201609
# Unit test for constructor of class ListToken
def test_ListToken():
    t=ListToken("abc",1,2)
    t.__init__("abc",1,2)
    a = t._get_value
    assert 1 == 1

# Generated at 2022-06-24 11:21:45.083266
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_1 = ScalarToken("foo", 0, 2, content="123")
    token_2 = ScalarToken("foo", 0, 2, content="123")
    assert token_1 == token_2



# Generated at 2022-06-24 11:21:49.930040
# Unit test for constructor of class Token
def test_Token():
    '''
    Testing with a class method which will test if the desired values are returned by methods
    like value, start, end, string using a token object.
    '''
    a = ScalarToken('99', 10, 12)
    assert a.value == '99'
    assert a.start == Position(11, 1, 10)
    assert a.end == Position(11, 3, 12)
    assert a.string == '99'


# Generated at 2022-06-24 11:21:51.325374
# Unit test for method lookup of class Token
def test_Token_lookup():
    assert Token(None, 0, 0).lookup([0]) == None

# Generated at 2022-06-24 11:21:53.968805
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Setup
    token = Token(None, 0, 0)

    # Exercise
    actual = repr(token)

    # Verify
    assert actual == 'Token(None)', actual


# Generated at 2022-06-24 11:22:04.003679
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class ScalarToken_test(ScalarToken):
        def _get_value(self):
            return 0
        def _get_child_token(self, key):
            return 0
        def _get_key_token(self, key):
           return self

    class ListToken_test(ListToken):
        def _get_value(self):
            return range(3)
        def _get_child_token(self, key):
            return 0
    class DictToken_test(DictToken):
        def _get_value(self):
            return {'0':1}
        def _get_child_token(self, key):
            return 0
        def _get_key_token(self, key):
           return self

# Generated at 2022-06-24 11:22:04.939887
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(None, 0, 0)
    assert hash(token) == hash(None)


# Generated at 2022-06-24 11:22:08.788686
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    t1 = ScalarToken(123, 0, 0)
    t2 = ScalarToken(123, 0, 0)
    t3 = ScalarToken(456, 0, 0)
    assert hash(t1) == hash(t2)
    assert hash(t1) != hash(t3)


# Generated at 2022-06-24 11:22:19.486644
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class TokenStub(Token):
        _content = "{\"a\": 1, \"b\": 2}"
        _keys = {
            ("a",): ('"', 1, 2),
            ("b",): ('"', 5, 6),
        }
        _values = {
            ("a",): ('1', 4, 5),
            ("b",): ('2', 9, 10),
        }
        def __init__(self, value: typing.Any, start_index: int, end_index: int) -> None:
            self._value = self._values[value]
            self._start_index = self._value[1]
            self._end_index = self._value[2]
        def _get_value(self) -> typing.Any:
            return self._value[0]

# Generated at 2022-06-24 11:22:24.499109
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    s = ScalarToken(1,2,3, "")
    s.string



# Generated at 2022-06-24 11:22:32.931853
# Unit test for constructor of class DictToken
def test_DictToken():

    tok = DictToken(value={},start_index=0,end_index=3,content="")
    print(tok._value)
    if isinstance(tok,DictToken):
        print("Passed")
    else:
        print("Failed")


# Generated at 2022-06-24 11:22:39.907684
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    tok1 = ScalarToken('foo', 0, 2, 'foo')
    tok2 = ScalarToken('foo', 0, 2, 'foo')
    tok3 = ScalarToken('foo', 0, 2, 'bar')

    assert tok1 == tok2
    assert tok1 != tok3
    assert hash(tok1) == hash(tok2)
    assert hash(tok1) != hash(tok3)


# Generated at 2022-06-24 11:22:46.011787
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    def test_ScalarToken_get_value():
        token = ScalarToken("test", 0, 0)
        assert token._get_value() == "test"

    def test_ScalarToken_start_index():
        token = ScalarToken("test", 1, 0)
        assert token._start_index == 1

    def test_ScalarToken_end_index():
        token = ScalarToken("test", 0, 1)
        assert token._end_index == 1


# Generated at 2022-06-24 11:22:48.475817
# Unit test for constructor of class ListToken
def test_ListToken():
    a = ListToken([Token(1, 0, 1), Token(2, 2, 3), Token(3, 4, 5)], 0, 5)


# Generated at 2022-06-24 11:22:56.168342
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    key_token_string = '"hello"'
    key_token_start_index = 0
    key_token_end_index = len(key_token_string) - 1
    key_token = ScalarToken(
        value = "hello",
        start_index = key_token_start_index,
        end_index = key_token_end_index,
        content = key_token_string,
    )

    value_token_string = '"world"'
    value_token_start_index = key_token_start_index
    value_token_end_index = len(value_token_string) - 1

# Generated at 2022-06-24 11:22:57.653070
# Unit test for constructor of class DictToken
def test_DictToken():
    pass


# Generated at 2022-06-24 11:23:01.440881
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    value = ScalarToken('', 0, 0)
    assert value.__repr__() == "ScalarToken('')"


# Generated at 2022-06-24 11:23:03.493717
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(1, 0, 0)
    assert hash(token) == 1
    token = ScalarToken("abc", 0, 2)
    assert hash(token) == hash("abc")


# Generated at 2022-06-24 11:23:08.504124
# Unit test for method lookup of class Token
def test_Token_lookup():
    assert 'abc' == 'abc'
    assert 'abc' == eval('abc')
    assert 'abc' == eval('a' + 'b' + 'c')

test_Token_lookup()

# Generated at 2022-06-24 11:23:13.792843
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(value='', start_index=0, end_index=0)
    assert token._value == ''
    assert token._start_index == 0
    assert token._end_index == 0
    # using doctest
    # >>> token = DictToken(value="", start_index=0, end_index=0)
    # >>> token._value == ""
    # True
    # >>> token._start_index == 0
    # True
    # >>> token._end_index == 0
    # True
    # >>> token._child_keys
    # {}
    # >>> token._child_tokens
    # {}


# Generated at 2022-06-24 11:23:18.448291
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert ScalarToken(
        value=None, start_index=0, end_index=0, content=""
    ).__hash__() == hash(None)



# Generated at 2022-06-24 11:23:22.978497
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    import typesystem
    json_token = typesystem.parse_string("1", typesystem.Integer())
    assert json_token == typesystem.Integer(1)
    assert hash(json_token) == hash(typesystem.Integer(1))

# Generated at 2022-06-24 11:23:25.633261
# Unit test for constructor of class Token
def test_Token():
    t = Token(1,2,3)
    assert t._value == 1
    assert t._start_index == 2
    assert t._end_index == 3
    assert t._content == ""


# Generated at 2022-06-24 11:23:32.519114
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    test_instance = Token(value=None, start_index=None, end_index=None, content=None)

    with raises(NotImplementedError):
        test_instance._get_value()
    with raises(NotImplementedError):
        test_instance._get_child_token(key=None)
    with raises(NotImplementedError):
        test_instance._get_key_token(key=None)
    assert test_instance.value == None
    assert test_instance.start == None
    assert test_instance.end == None
    with raises(NotImplementedError):
        test_instance.lookup(index=None)
    with raises(NotImplementedError):
        test_instance.lookup_key(index=None)
    assert repr(test_instance) == "Token(None)"
   

# Generated at 2022-06-24 11:23:40.161642
# Unit test for constructor of class Token
def test_Token():
	token = Token(["a", "b"], 0, 1, "abc")
	assert token.string == "ab"
	assert token.value == ["a", "b"]
	assert token.start == Position(1, 1, 0)
	assert token.end == Position(1, 2, 1)
	assert isinstance(token.lookup([0]), Token)
	assert token.lookup_key([0, 0]) == token
	assert token.__repr__() == "Token(ab)"
	assert not (token == "ab")
	assert token == token
	assert token.__hash__() is None


# Generated at 2022-06-24 11:23:43.538908
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    obj = ScalarToken()

    import pytest
    with pytest.raises(NotImplementedError):
        hash(obj)



# Generated at 2022-06-24 11:23:50.374762
# Unit test for constructor of class ScalarToken

# Generated at 2022-06-24 11:23:58.406800
# Unit test for constructor of class DictToken
def test_DictToken():
    # Constructure of DictToken
    dict_token = DictToken(True, 0, 0, content = "{}")
    dict_token._value = {key_token._value: value_token._value for key_token, value_token in self._value.items()}
    dict_token._child_keys = {k._value: k for k in dict_token._value.keys()}
    dict_token._child_tokens = {k._value: v for k, v in dict_token._value.items()}
    assert dict_token._value[1] == value_token


# Generated at 2022-06-24 11:24:01.655501
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    import typing
    import typesystem

    token = typesystem.parser.tokens.ScalarToken(
        "some value", start_index=8, end_index=18, content="some value"
    )



# Generated at 2022-06-24 11:24:11.043555
# Unit test for constructor of class Token
def test_Token():
    print("Unit test for constructor of class Token")
    t1 = Token('a', 0, 1, 'a')
    assert t1.string == 'a'
    assert t1.start.line_no == 1
    assert t1.start.column_no == 1
    assert t1.start.index == 0
    assert t1.end.line_no == 1
    assert t1.end.column_no == 1
    assert t1.end.index == 0
    X = ['a']
    assert t1.lookup(X) == t1
    assert t1.lookup_key(X) == t1
    assert t1 == t1
    assert t1.value == 'a'
    assert t1._get_position(0) == (1, 1, 0)
    assert t1.__repr__()

# Generated at 2022-06-24 11:24:12.789192
# Unit test for constructor of class ListToken
def test_ListToken():
    l = ListToken(value=[1,2,3,4], start_index=0, end_index=6)
    assert "ListToken([1, 2, 3, 4])" == repr(l)

# Generated at 2022-06-24 11:24:21.918988
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    s = "abc"
    tok = ScalarToken(s, 0, 2)
    assert len(tok.string) == len(s)
    assert tok.value == s
    assert tok.start.line_no == 1
    assert tok.start.column_no == 1
    assert tok.start.byte_no == 0
    assert tok.end.line_no == 1
    assert tok.end.column_no == 3
    assert tok.end.byte_no == 2
    assert tok.value == s
    assert str(tok) == "ScalarToken('abc')"
    assert hash(tok) == hash(s)
    assert tok == ScalarToken(s, 0, 2)


# Generated at 2022-06-24 11:24:24.146618
# Unit test for constructor of class Token
def test_Token():
    with pytest.raises(NotImplementedError):
        t = Token(3,[],[])
        t._get_value()

# Generated at 2022-06-24 11:24:26.023345
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token(value="value", start_index=0, end_index=4, content="value")
    assert repr(token) == "Token('value')"

# Generated at 2022-06-24 11:24:31.677749
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():

    # Call method __hash__ of class ScalarToken with correct args
    result = ScalarToken(None, 0, 0).__hash__()
    assert type(result) == int

    # Call method __hash__ of class ScalarToken with incorrect args



# Generated at 2022-06-24 11:24:32.586556
# Unit test for constructor of class Token
def test_Token():
    Token(12, 2,3, "abcd")

# Generated at 2022-06-24 11:24:42.529572
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {
        ScalarToken(1, 2, 3): ScalarToken(4, 5, 6),
        ScalarToken(7, 8, 9): ScalarToken(10, 11, 12)
    }
    dt = DictToken(d, 20, 30, 'one two three four five six seven eight nine ten eleven twelve')
    assert dt._child_tokens[1].start.character == 3
    assert dt._child_tokens[1].end.character == 6
    assert dt._child_tokens[7].start.character == 9
    assert dt._child_tokens[7].end.character == 12
    assert dt._child_keys[1].start.character == 2
    assert dt._child_keys[1].end.character == 3
    assert dt._child_keys

# Generated at 2022-06-24 11:24:50.036210
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.base import Scalar, Dict, List, ScalarType

    class IntegerType(ScalarType):
        def check(self, value):
            return isinstance(value, int)

    class TestToken(Token):
        def _get_value(self):
            return self._value

    class TestScalarToken(ScalarToken):
        def _get_value(self):
            return self._value

    class TestDictToken(DictToken):
        def _get_value(self):
            return self._value

    class TestListToken(ListToken):
        def _get_value(self):
            return self._value

    integer_type = IntegerType()


# Generated at 2022-06-24 11:24:58.652997
# Unit test for constructor of class ListToken
def test_ListToken():
    from typesystem.utils import index_tokens
    from typesystem.utils import value_tokens

    test_index_tokens = {
        "0": ScalarToken(0, 0, 1, content="[0]"),
        "1": ScalarToken(1, 3, 4, content="[0,1]"),
        "2": ScalarToken(2, 6, 7, content="[0,1,2]"),
    }


# Generated at 2022-06-24 11:25:04.282577
# Unit test for constructor of class DictToken
def test_DictToken():
    # Both have attribute content, start_index and end_index
    assert hasattr(DictToken, "_content")
    assert hasattr(DictToken, "_start_index")
    assert hasattr(DictToken, "_end_index")
    # Both have attribute _value
    assert hasattr(DictToken, "_value")
    # Both have attribute _child_keys
    assert hasattr(DictToken, "_child_keys")
    # Both have attribute _child_tokens
    assert hasattr(DictToken, "_child_tokens")
    return DictToken


# Generated at 2022-06-24 11:25:07.658695
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({}, 0, 1)
    assert token.string == "", "The string is not initialized correctly"
    assert token._value == {}
    assert token.value == {}
    assert token.start.column == 0
    assert token.end.column == 1
    assert token.start_index == 0
    assert token.end_index == 1
    assert token.lookup([]) == token
    assert token.lookup_key([0]) == token



# Generated at 2022-06-24 11:25:13.135858
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Here, we assign 'obj' our own object of Token.
    obj = Token(value=0, start_index=0, end_index=0, content='')
    # Now, we assume that the function we are testing behaves correctly.
    # Then, we verify that this assumption is true by using a 'assert' statement.
    assert True

# Generated at 2022-06-24 11:25:21.994039
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_1 = ScalarToken('hello',0,4,'hello',)
    token_2 = ScalarToken('hello',0,4,'hello',)
    assert token_1 == token_2
    token_1 = ScalarToken('hello',3,9,'hello',)
    assert not (token_1 == token_2)
    token_2 = ScalarToken('hello',3,9,'hello',)
    assert token_1 == token_2
    token_1 = ScalarToken('world',3,9,'world',)
    assert not (token_1 == token_2)
    token_2 = ScalarToken('world',3,9,'world',)
    assert token_1 == token_2
    


# Generated at 2022-06-24 11:25:27.204637
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    expected_token = Token(1, 0, 1, content=' ')
    actual_token = Token(1, 0, 1, content=' ')
    assert actual_token.lookup_key([0]) == expected_token

# Generated at 2022-06-24 11:25:31.714775
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert (Token(None, 1, 2) == Token(None, 1, 2)) == True
    assert (Token(None, 1, 2) == None) == False
    assert (None == Token(None, 1, 2)) == False


# Generated at 2022-06-24 11:25:34.261844
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token(value = 1, start_index = 2, end_index = 3, content = "")
    assert(token.__repr__() == 'Token(1)')



# Generated at 2022-06-24 11:25:37.064022
# Unit test for constructor of class Token
def test_Token():
    result = Token(1, 2, 3, 4)
    assert result._value == 1
    assert result._start_index == 2
    assert result._end_index == 3
    assert result._content == 4


# Generated at 2022-06-24 11:25:41.793201
# Unit test for constructor of class Token
def test_Token():
    token = Token("test", 0, 3, "teststring")
    token.value
    token.end
    token.start
    token.string
    token.lookup([0])
    token.lookup_key([0,1])
    token.__repr__()
    token.__eq__("test")

# Test for property string of class Token

# Generated at 2022-06-24 11:25:49.697813
# Unit test for method lookup of class Token
def test_Token_lookup():
    from kotori.io.tokens import ScalarToken
    from kotori.io.tokens import DictToken
    from kotori.io.tokens import ListToken

    list_token = ListToken([ScalarToken(1, 0, 1, "1")])
    dict_token = DictToken({ScalarToken(1, 1, 2, "1"): list_token})

    assert dict_token.lookup([1]).start == dict_token.start

    assert dict_token.lookup_key([1, 1]).string == "1"

# Generated at 2022-06-24 11:25:54.141106
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token(2, 3, 7, "{\n    foo: bar\n}")
    assert token != None
    assert token.lookup(["foo"]) == Token("bar", 15, 18, "{\n    foo: bar\n}")



# Generated at 2022-06-24 11:25:59.772724
# Unit test for constructor of class ListToken
def test_ListToken():
    a = ListToken(['x','y','z'], 1, 2, 'abc')
    token = a._get_child_token(0)
    assert isinstance(token,str)
    assert token == 'x'

# Generated at 2022-06-24 11:26:01.293745
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # TODO: implement this unit test
    raise NotImplementedError()


# Generated at 2022-06-24 11:26:02.691611
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(1, 0, 1)
    assert hash(token) == hash(1)


# Generated at 2022-06-24 11:26:04.664602
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    t = Token(value="t", start_index=1, end_index=2, content="abcd")
    assert repr(t) == "Token('b')"


# Generated at 2022-06-24 11:26:05.202030
# Unit test for constructor of class ListToken
def test_ListToken():
    assert isinstance(None, object)


# Generated at 2022-06-24 11:26:14.394859
# Unit test for method lookup of class Token
def test_Token_lookup():
    from typesystem.parser import ScalarToken, DictToken, ListToken

    def check_lookup(token, index, expected_token):
        assert(token.lookup(index) == expected_token)

    def check_lookup_key(token, index, expected_token):
        assert(token.lookup_key(index) == expected_token)

    # Scalar token
    token = ScalarToken(1, 0, 0)
    check_lookup(token, [], token)

    # List token
    token = ListToken([], 0, 0)
    check_lookup(token, [], token)

    token1 = ScalarToken(1, 0, 0)
    token2 = ScalarToken(2, 1, 1)
    token = ListToken([token1, token2], 0, 1)
    check_

# Generated at 2022-06-24 11:26:21.820701
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    start_index_1 = 1
    end_index_1 = 5
    content_1 = "abcde"
    s = ScalarToken("abcde", start_index_1, end_index_1, content_1)
    
    assert s.string == "abcde"
    assert s.value == "abcde"
    assert s.start.line == 1
    assert s.start.column == 1
    assert s.start.index == 1
    assert s.end.line == 1
    assert s.end.column == 5
    assert s.end.index == 5


# Generated at 2022-06-24 11:26:31.142111
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test type
    token = Token(0, 0, 0)
    assert token == token

    # Test attribute _value of type ScalarToken
    t1 = ScalarToken(0, 0, 0)
    t2 = ScalarToken(0, 0, 0)
    assert t1 == t2

    t1 = ScalarToken(0, 0, 0)
    t2 = ScalarToken(1, 0, 0)
    assert t1 != t2

    # Test attribute _value of type DictToken
    t1 = DictToken({}, 0, 0, "")
    t1._value = {ScalarToken(0, 0, 0): ScalarToken(1, 0, 0)}
    t2 = DictToken({}, 0, 0, "")

# Generated at 2022-06-24 11:26:38.265967
# Unit test for constructor of class DictToken
def test_DictToken():
	token_dict = {"key": Token(value = 111, start_index = 0, end_index = 0, content = "")}
	dict_token = DictToken(value = token_dict, start_index = 0, end_index = 1, content = "")
	assert dict_token._value == token_dict and \
	dict_token._child_keys == {"key": Token(value = 111, start_index = 0, end_index = 0, content = "")} and \
	dict_token._child_tokens == {"key": Token(value = 111, start_index = 0, end_index = 0, content = "")}


# Generated at 2022-06-24 11:26:40.040473
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken('A', 0, 0)
    assert hash(token) == hash('A')


# Generated at 2022-06-24 11:26:49.182685
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    string = 'This is a string.'
    value = "This is a string."
    start_index = 0
    end_index = 19
    content = "This is a string."
    t = ScalarToken(value, start_index, end_index, content)
    assert t.__eq__(ScalarToken(value, start_index, end_index, content))
    assert not t.__eq__(ScalarToken(string, start_index, end_index, content))
    assert str(t) == "ScalarToken('This is a string.')"


# Generated at 2022-06-24 11:26:51.478305
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    t = ScalarToken(123, 0, 1)
    assert hash(t) == hash(123)



# Generated at 2022-06-24 11:26:59.927581
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = Token(None, 0, 0, "")

    # test with a dict
    dict_token = DictToken(
        {"a": ScalarToken(1, 1, 1, ""), "b": ScalarToken(2, 2, 2, "")},
        0,
        2,
        "a1b2",
    )
    assert dict_token.lookup_key([0]) == dict_token._value.keys()[0]

    # test with a list
    list_token = ListToken(
        [ScalarToken(1, 1, 1, ""), ScalarToken(2, 2, 2, "")], 0, 2, "12"
    )
    assert list_token.lookup_key([0]) == list_token._value[0]



# Generated at 2022-06-24 11:27:09.322655
# Unit test for constructor of class Token
def test_Token():
    token = Token('a', 0, 1, 'a')
    assert token._value == 'a'
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == 'a'
    assert token.string == 'a'
    assert token.value == 'a'
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 1)
    assert token == Token('a', 0, 1, 'a')
    assert token != Token('b', 0, 1, 'a')
    assert isinstance(token, Token)
    with pytest.raises(NotImplementedError):
        token._get_value()
    with pytest.raises(NotImplementedError):
        token._get_child_token()

# Generated at 2022-06-24 11:27:15.507681
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(value = "test", start_index = 0, end_index = 3)
    assert token.string == "test" and token.start.line == 1 and token.start.column == 1 and token.end.line == 1 and token.end.column == 4


# Generated at 2022-06-24 11:27:20.376459
# Unit test for constructor of class Token
def test_Token():

    a = Token(value = 1, start_index = 0, end_index = 1, content = "Hello")
    assert a.string == "He"
    assert a.value == None
    assert a.start == Position(1, 2, 1)
    assert a.end == Position(1, 3, 2)


# Generated at 2022-06-24 11:27:21.571392
# Unit test for constructor of class ListToken
def test_ListToken():
    ListToken


# Generated at 2022-06-24 11:27:24.187810
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken(x, a, b, c)


# Generated at 2022-06-24 11:27:26.639568
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # concrete_token = Token()
    # assert concrete_token.__repr__() == "expected output"
    raise NotImplementedError # TODO: implement test



# Generated at 2022-06-24 11:27:28.388058
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(1, 0, 1)
    assert token._get_value() == 1


# Generated at 2022-06-24 11:27:29.897024
# Unit test for method __repr__ of class Token
def test_Token___repr__():
  t = Token("k", 1)
  assert text("__repr__") in text(t)
 

# Generated at 2022-06-24 11:27:33.410551
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token(
        1, 0, 10, content="Some content"
    )  # What is the type of 'token'? What is the value of 'token'?
    assert token.__repr__() == "Token(1)"


# Generated at 2022-06-24 11:27:36.198822
# Unit test for method __repr__ of class Token
def test_Token___repr__():

    token = Token("test_value", "test_start_index", "test_end_index", "test_content")

    assert repr(token) == "Token(test_value)"

# Generated at 2022-06-24 11:27:41.779319
# Unit test for constructor of class Token
def test_Token():
    t = Token(1, 2, 3, content = "abcd")
    assert t._value == 1
    assert t._start_index == 2
    assert t._end_index == 3
    assert t._content == "abcd"


# Generated at 2022-06-24 11:27:43.867442
# Unit test for constructor of class DictToken
def test_DictToken():
    dic = {"A": "a", "B": "b"}
    dic_token = DictToken(dic)

# Generated at 2022-06-24 11:27:46.585340
# Unit test for method lookup of class Token
def test_Token_lookup():
    content = "Hello world"

    token = Token(
        value="Hello world", start_index=0, end_index=1, content=content
    )

    assert token.lookup([0]) == token

# Generated at 2022-06-24 11:27:49.345134
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    obj = Token("value", -1, -1, "")
    assert repr(obj) == "Token('value')"



# Generated at 2022-06-24 11:27:51.510399
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(None, 0, 0)
    token2 = Token(None, 0, 0)
    assert(token1 == token2)


# Generated at 2022-06-24 11:27:55.263969
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from typesystem.base import Number, String

    type = Number()
    token = Token('s',0,0,'s')
    t = token.lookup_key([0])
    assert t.__eq__(token)


# Generated at 2022-06-24 11:27:56.917892
# Unit test for constructor of class Token
def test_Token():
    assert Token(value=2, start_index=0, end_index=1, content=2)



# Generated at 2022-06-24 11:28:00.640288
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token(None, 0, 0, "test")
    assert token.lookup([]) == token
    assert token.lookup([1]) == token
    assert token.lookup_key([1]) == token


# Generated at 2022-06-24 11:28:05.707354
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken("<value>", -1, -2)
    value = token.__hash__()
    assert value == hash("<value>")



# Generated at 2022-06-24 11:28:10.376696
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # method call
    token = ScalarToken("a", 100, 200)
    value = token.__hash__()
    # checks
    assert isinstance(value, int)
    assert value == hash("a")


# Generated at 2022-06-24 11:28:15.548186
# Unit test for constructor of class DictToken
def test_DictToken():
    d = dict()
    dict_token = DictToken(d,1,1,"1")
    assert dict_token._value == d
    assert dict_token._start_index == 1
    assert dict_token._end_index == 1
    assert dict_token._content == "1"



# Generated at 2022-06-24 11:28:18.139297
# Unit test for method lookup of class Token
def test_Token_lookup():
    t = Token(None, 0,0, '')
    with pytest.raises(NotImplementedError) as e_info:
        t.lookup(())


# Generated at 2022-06-24 11:28:28.181982
# Unit test for constructor of class Token
def test_Token():
    token = Token(
        value=2.0,
        start_index=0,
        end_index=1,
        content="2.0"
    )
    assert token.string == "2.0"
    assert token.value == 2.0
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 3, 2)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert repr(token) == "Token(2.0)"
    assert str(token) == "2.0"
    assert token == Token(
        value=2.0,
        start_index=0,
        end_index=1,
        content="2.0"
    )

# Generated at 2022-06-24 11:28:30.411027
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    assert "foo" == Token(["foo", "bar"], 0, 1, "foo\nbar").lookup_key([0]).value

# Generated at 2022-06-24 11:28:37.850353
# Unit test for method lookup of class Token
def test_Token_lookup():
    class test(Token):
        def _get_value(self):
            return 1
        def _get_child_token(self, key):
            return 1
        def _get_key_token(self, key):
            return 1
    
    test_obj = test(1,1,1,"")
    assert test_obj.lookup([1]) == 1
    assert test_obj.lookup_key([1,2]) == 1
    assert test_obj.start == Position(1,1,1)
    assert test_obj.end == Position(1,1,1)
    assert test_obj._get_value() == 1
    assert test_obj.string == ""
    assert test_obj.value == 1


# Generated at 2022-06-24 11:28:47.196625
# Unit test for method lookup of class Token
def test_Token_lookup():
    class TokenStub:
        def __init__(self, value, start, end, content=""):
            self._value = value
            self._start_index = start
            self._end_index = end
            self._content = content
    d = TokenStub({'a':'b', 'c':'d'}, 1, 5, "123456")
    assert 'a' == d.lookup([])._value[0]._get_value()
    assert 'b' == d.lookup([0])._get_value()
    assert 'c' == d.lookup([1])._get_value()
    assert 'd' == d.lookup([1, 1])._get_value()

# Generated at 2022-06-24 11:28:51.986894
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = ListToken([], 0, 0, content="")
    assert token.lookup([0]) == ScalarToken(None, 0, 0, content="")



# Generated at 2022-06-24 11:28:59.219048
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from typesystem.base import Position
    from typesystem.compat import Literal
    from typesystem.parser import parse
    from typesystem.types import String

    schema = String(name="foo")
    tree = parse(schema, "hello")
    index = [0]
    key_token = tree.lookup_key(index)
    assert key_token.start == Position(1, 1, 0)
    assert key_token.string == "foo"

    schema = Literal("foo", "bar")
    tree = parse(schema, "foo")
    index = [0]
    key_token = tree.lookup_key(index)
    assert key_token.start == Position(1, 1, 0)
    assert key_token.string == "foo"



# Generated at 2022-06-24 11:29:08.053281
# Unit test for method lookup of class Token
def test_Token_lookup():
    # Setup
    def _get_value():
        return 1

    def _get_child_token(key):
        raise NotImplementedError

    def _get_key_token(key):
        raise NotImplementedError

    token_1 = Token(value=None, start_index=0, end_index=0)
    token_1._get_value = _get_value
    token_1._get_child_token = _get_child_token
    token_1._get_key_token = _get_key_token
    index = [0]
    expected = 1

    # Exercise
    actual = token_1.lookup(index)

    # Verify
    assert actual == expected



# Generated at 2022-06-24 11:29:15.124850
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # Test 1
    input_content = '{"key": "value", "a": {"b": "c"}}'
    input_index = [0, 1]
    expected_output = '"b":'
    input_token = DictToken({}, 0, 22, content=input_content)
    output_token = input_token.lookup_key(input_index)
    assert output_token.string == expected_output

    # Test 2
    input_content = '["apple", "banana", "orange"]'
    input_index = [1]
    expected_output = '"banana"'
    input_token = ListToken([], 0, 22, content=input_content)
    output_token = input_token.lookup_key(input_index)
    assert output_token.string == expected_output

#

# Generated at 2022-06-24 11:29:23.576338
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(0, 10, 20)
    t2 = Token(0, 10, 20)
    assert t1 == t2
    t1 = Token(0, 10, 20)
    t2 = Token(1, 10, 20)
    assert t1 != t2
    t1 = Token(0, 10, 20)
    t2 = Token(0, 11, 20)
    assert t1 != t2
    t1 = Token(0, 10, 20)
    t2 = Token(0, 10, 21)
    assert t1 != t2
    t1 = Token(0, 10, 20)
    t2 = 42
    assert t1 != t2

# Generated at 2022-06-24 11:29:29.585400
# Unit test for constructor of class ListToken
def test_ListToken():
    myListToken = ListToken('value', 'start_index', 'end_index')
    assert myListToken._value == 'value'
    assert myListToken._start_index == 'start_index'
    assert myListToken._end_index == 'end_index'
    assert myListToken._content == ""


# Generated at 2022-06-24 11:29:37.298966
# Unit test for constructor of class Token
def test_Token():
    t = Token(value=None, start_index=None, end_index=None, content=None)
    assert(t.string == "")
    assert(t.value == None)
    assert(t.start == Position(1, 1, 0))
    assert(t.end == Position(1, 1, 0))
    assert(t.lookup(index=None) == None)
    assert(t.lookup_key(index=None) == None)
    assert(t._get_position(index=None) == Position(1, 1, 0))
    assert(repr(t) == "Token('')")
    assert(t == True)
    assert(hash(t) == -593153386)


# Generated at 2022-06-24 11:29:40.314778
# Unit test for constructor of class ListToken
def test_ListToken():
    a = Token(1,2,3)
    ls = ListToken([a], 0, 3, "")


# Generated at 2022-06-24 11:29:49.707912
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # ScalarToken, value = 'hello'
    s1 = ScalarToken(value = 'hello', start_index = 10, end_index = 20)
    assert s1.__repr__() == "ScalarToken('hello')"

    # list value = [1, 2, 3]
    l1 = ListToken(value = [Token(1, 10, 20), Token(2, 30, 40), Token(3, 50, 60)], start_index = 10, end_index = 65)
    assert l1.__repr__() == "ListToken('1,2,3')"

    # dict value = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-24 11:30:01.323584
# Unit test for method lookup of class Token
def test_Token_lookup():
    # create a list with 4 Token objects
    token_list = [{'name': 'foo', 'version': 2.0}, 'bar', 1, {'foo': {'bar': '1.0'}}]
    j = 0
    for i in token_list:
        if type(i) is dict:
            for key, value in i.items():
                if j == 0:
                    t = DictToken({'name': ScalarToken('foo', 2, 4), 'version': ScalarToken(2.0, 13, 15)}, 2, 15, content='{name: foo, version: 2.0}')
                    assert t.lookup([key]) == value
                    assert t.lookup_key([key, 'version']) == key

# Generated at 2022-06-24 11:30:04.577803
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(None, 0, 0)
    assert (
        hash(token) != None
    ), (
        "__hash__() returned unexpected result: '%s'"
        % repr(hash(token))
    )



# Generated at 2022-06-24 11:30:09.520732
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(None, 0, 1, content = "word")
    assert token.string == "word" and token.value is None
    assert token.start.line_no == 1 and token.start.column_no == 1 and token.start.index == 0
    assert token.end.line_no == 1 and token.end.column_no == 4 and token.end.index == 3


# Generated at 2022-06-24 11:30:14.848846
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    t = Token(5,1,5,"\n")
    assert str(t)=="Token('\\n')"
    # print(t)
    t = Token(5,1,5,"\n\n")
    assert str(t)=="Token('\\n\\n')"
    # print(t)
    t = Token(5,1,5,"\n\n\n")
    assert str(t)=="Token('\\n\\n\\n')"


# Generated at 2022-06-24 11:30:16.459884
# Unit test for constructor of class DictToken
def test_DictToken():
    a = Token("test", 0, 0)
    b = Token("test", 0, 0)
    assert a == b

test_DictToken()

# Generated at 2022-06-24 11:30:18.007880
# Unit test for constructor of class Token
def test_Token():
    assert Token("a",1,2)


# Generated at 2022-06-24 11:30:29.322843
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.base import Schema, Error
    from typesystem.fields import String, Integer
    from typesystem.types import Object, Array

    class TestSchema(Schema):
        name = String()
        age = Integer()

    class TestTypes(Schema):
        person = Object(properties={"name": String(), "age": Integer()})
        index = Array(items=Integer())

    schema = TestSchema({"name": "John", "age": 42})
    data = {"name": "John", "age": 42}
    assert schema.validate(data) == data

    string = "whatever"
    string_token = ScalarToken(value=string, start_index=1, end_index=11)
    assert string_token == string_token


# Generated at 2022-06-24 11:30:34.137631
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    """unit test for Token.__repr__"""
    assert repr(Token(None,0,0)) == 'Token(None)'
    assert repr(Token(None,1,1)) == 'Token(None)'


# Generated at 2022-06-24 11:30:36.916910
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    v1 = ScalarToken("value1", 1, 2)
    v2 = ScalarToken("value1", 1, 2)
    assert v1 == v2
    assert v2 == v1

# Generated at 2022-06-24 11:30:44.564265
# Unit test for constructor of class Token
def test_Token():
    #Test ScalarToken
    assert ScalarToken(1,1,1, "1")._value == 1
    assert ScalarToken(1.1,1,1, "1.1")._value == 1.1
    assert ScalarToken("1",1,1, "1")._value == "1"
    assert ScalarToken(True,1,1, "True")._value == True
    assert ScalarToken(False,1,1, "False")._value == False
    #Test DictToken
    d = {"1":1}
    dict_tok = DictToken(d, 1, 1, "1:1")
    assert dict_tok._get_value() == d
    assert dict_tok._child_keys["1"].string == "1"
    assert dict_tok._child_tokens

# Generated at 2022-06-24 11:30:54.121718
# Unit test for method lookup of class Token
def test_Token_lookup():
    from typesystem.base import Scalar, Dictionary, List
    from typesystem.base import INFINITY, ZERO
    def to_token(value):
        if isinstance(value, list):
            return ListToken(
                [to_token(subvalue) for subvalue in value],
                0,
                INFINITY,
                value
            )
        elif isinstance(value, dict):
            return DictToken(
                {
                    to_token(subkey): to_token(subvalue)
                    for subkey, subvalue in value.items()
                },
                ZERO,
                INFINITY,
                value
            )
        else:
            return ScalarToken(
                value, ZERO, INFINITY, value
            )

# Generated at 2022-06-24 11:30:57.760312
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token(value='value', start_index='start_index', end_index='end_index', content='content')
    expected = "Token(content)"
    actual = repr(token)
    assert actual == expected


# Generated at 2022-06-24 11:31:07.389991
# Unit test for constructor of class DictToken
def test_DictToken():
    c = DictToken({"a": 1, "b": 2}, 0, 1, "ab")
    assert c._value == {"a": 1, "b": 2}
    assert c._get_value() == {"a": 1, "b": 2}
    assert c._child_keys == {1: 'a', 2: 'b'}
    assert c._child_tokens == {'a': 1, 'b': 2}
    assert c.string == "a"
    assert c.value == {"a": 1, "b": 2}
    assert c.lookup([1]) == 1
    assert c.lookup_key([1]) == 'a'
    assert c.__repr__() == "DictToken({'a': 1, 'b': 2})"

# Generated at 2022-06-24 11:31:20.973182
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.compat import unicode
    from typesystem.compat import STRING_TYPE
    from typesystem.compat import TEXT_TYPE

    t1 = Token(value=STRING_TYPE(), start_index=-2, end_index=-1, content='test')

    t2 = Token(value=STRING_TYPE(), start_index=-1, end_index=0, content='test')
    assert t1 != t2

    t3 = Token(value=STRING_TYPE(), start_index=0, end_index=1, content='test')
    assert t1 != t3

    t4 = Token(value=TEXT_TYPE(), start_index=0, end_index=1, content='test')
    assert t1 != t4


# Generated at 2022-06-24 11:31:26.370595
# Unit test for constructor of class DictToken
def test_DictToken():
    class DictTokenMock(DictToken):
        pass
    DictTokenMock(
        {
            3: ScalarToken(3, 0, 0, content=""),
            6: ScalarToken(6, 0, 0, content=""),
        },
        0,
        0,
        content="",
    )
