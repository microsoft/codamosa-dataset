

# Generated at 2022-06-24 11:21:26.231979
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    a = ScalarToken('a', 0, 0, 'a')
    assert a.string == 'a'


# Generated at 2022-06-24 11:21:27.614488
# Unit test for constructor of class ListToken
def test_ListToken():
	pass


# Generated at 2022-06-24 11:21:31.588498
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken(1, 1, 2, "1")
    assert DictToken(1, 1, 2, "1", value=2)
    assert DictToken(1, 1, 2, {"a":1})

# Generated at 2022-06-24 11:21:34.565960
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token('x', 1, 2)
    assert token.lookup([1,2]) == Token('x', 1, 2)
    assert token.lookup_key([1,2]) == Token('x', 1, 2)


# Generated at 2022-06-24 11:21:42.712595
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(
        value='abc', start_index=1, end_index=2, content='abcdef'
    )
    assert token.string == 'bc'
    assert token.value == 'abc'
    assert token.start == Position(1, 2, 1)
    assert token.end == Position(1, 3, 2)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert repr(token) == 'ScalarToken(\'bc\')'
    assert hash(token) == hash('abc')


# Generated at 2022-06-24 11:21:43.639177
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert repr(Token()) == "Token('')"
pass

# Generated at 2022-06-24 11:21:47.942733
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
  t = Token(["a",{"b":"c"}],0,11,"a\n{\nb:c\n}\n")

  assert t.lookup_key([1,"b"]) == Token("b",3,3,"a\n{\nb:c\n}\n")


# Generated at 2022-06-24 11:21:49.206841
# Unit test for constructor of class ListToken
def test_ListToken():
    assert repr(ListToken([])) == "ListToken([])"


# Generated at 2022-06-24 11:21:52.938962
# Unit test for constructor of class Token
def test_Token():
    value = 'hi'
    token = Token(str,1,2,content=value)
    assert token._content is value
    assert token._end_index is 2
    assert token._start_index is 1
    assert token._value is str



# Generated at 2022-06-24 11:22:03.571281
# Unit test for method lookup of class Token
def test_Token_lookup():
    from unitsystem.lexer import lex
    from unitsystem.parser import parse
    from typesystem.parser import parse as p

    s = lex("km/s", "expr")
    t = parse(s)
    f = t._get_value()
    n = p(f)

    assert n.lookup((0, 0, 1, 1)) == ScalarToken(1, 13, 13, content=f)
    assert n.lookup((0, 0, 1, 1)).string == "1"
    assert n.lookup((0, 0, 1, 1)).start == Position(3, 3, 13)
    assert n.lookup((0, 0, 1, 1)).end == Position(3, 3, 13)
    assert n.lookup((0, 1, 0, 1)).string == "s"
    assert n.look

# Generated at 2022-06-24 11:22:09.330054
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """__eq__(self, other: typing.Any) -> bool"""
    # Case: scalar token
    token = ScalarToken(42, 0, 0)
    assert token == ScalarToken(42, 0, 0)
    assert token != ScalarToken(42, 0, 1)
    assert token != ScalarToken(43, 0, 0)
    # Case: dict token
    token = DictToken(
        {ScalarToken(42, 0, 0): ScalarToken(123, 2, 4)}, 0, 4, "42: 123"
    )
    assert token == DictToken({ScalarToken(42, 0, 0): ScalarToken(123, 2, 4)}, 0, 4, "42: 123")

# Generated at 2022-06-24 11:22:13.291283
# Unit test for constructor of class ListToken
def test_ListToken():
    a = ListToken([1, 2, 3], 0, 9, content=('[1, 2, 3]'))
    assert a._value == [1, 2, 3]
    assert a._start_index == 0
    assert a._end_index == 9
    assert a._content == '[1, 2, 3]'


# Generated at 2022-06-24 11:22:20.733466
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    a = [{"c": "two"}, {"d": "three"}]
    token = ListToken(value=a, start_index=0, end_index=0)

    assert token.lookup_key([0, "c"]) == DictToken(value={"c": "two"}, start_index=0, end_index=0)
    assert token.lookup_key([1, "d"]) == DictToken(value={"d": "three"}, start_index=0, end_index=0)
    assert token.lookup_key([2, "d"]) == None

# Generated at 2022-06-24 11:22:22.140903
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    print('Method __repr__ is ', repr(Token(None, 1, 2)))

test_Token___repr__()


# Generated at 2022-06-24 11:22:26.152437
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    s = ScalarToken("str", 0, 2)
    assert s.value == "str"
    assert s.string == "str"
    assert s.start == Position(1, 1, 0)
    assert s.end == Position(1, 4, 2)


# Generated at 2022-06-24 11:22:33.106677
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    t = ScalarToken("value", 0, 1)
    assert hash("value") == t.__hash__()


# Generated at 2022-06-24 11:22:38.161421
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = Token(
        value={0: "a", 1: "b"},
        start_index=0,
        end_index=3,
        content="{0: 'a', 1: 'b'}"
    )
    assert token.lookup_key([0]) == token.lookup_key([1])


# Generated at 2022-06-24 11:22:45.103219
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from typesystem.base import Type, String
    from typesystem.integer import Integer
    from typesystem.error import Error, ValidationError

    # Create a type
    class SchemaType(Type):
        attribute1 = String()
        attribute2 = Integer(gte=0)

    # Validate the type
    try:
        schema = SchemaType(
            attribute1='attribute1', attribute2=-1
        )
    except ValidationError as e:
        myerror: Error = e.errors[0]
        print(myerror.error_list)

# Generated at 2022-06-24 11:22:51.477934
# Unit test for constructor of class DictToken
def test_DictToken():
    content = "<<>>"
    value = {0: 1, 1: 2}
    start_index = 0
    end_index = 2
    token = DictToken(value, start_index, end_index, content)
    assert token._value == value
    assert token._start_index == start_index
    assert token._end_index == end_index
    assert token._content == content
    child_tokens = [token]
    child_keys = [0, 1]
    for key, value in zip(child_keys, child_tokens):
        token = DictToken(value, start_index, end_index, content)
        assert hasattr(token, "_child_tokens")
        assert hasattr(token, "_child_keys")

# Generated at 2022-06-24 11:22:55.588460
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    x = Token(0, 0, 1, 'foo')
    assert repr(x) == 'Token(\'f\')'
    x = Token(1, 1, 1, 'foo')
    assert repr(x) == 'Token(\'o\')'
    x = Token(2, 2, 2, 'foo')
    assert repr(x) == 'Token(\'o\')'


# Generated at 2022-06-24 11:22:57.165009
# Unit test for method lookup of class Token
def test_Token_lookup():
    assert ('1','2','3','4') == ('1','2','3','4')

# Generated at 2022-06-24 11:23:02.824880
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    """
    Tests the method __repr__ of class Token
    """
    print("Testing __repr__")

    t = Token(1, 0, 2, content="abc")
    assert repr(t) == "Token('abc')"
    return



# Generated at 2022-06-24 11:23:05.365619
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Create instance of class Token
    token = Token("value", 0, 1, "content")
    # Verify __repr__ is as expected
    assert str(token) == "Token('v')"



# Generated at 2022-06-24 11:23:12.030500
# Unit test for method lookup of class Token
def test_Token_lookup():
    a={'b': 3, 'c': 4}
    b=[0, 1, 2, a]
    c=a
    d=c
    e=b[3]['b']
    f=c['b']
    l=[0, 1]
    l.append(a)
    l.append(b)
    l.append(c)
    l.append(d)
    l.append(e)
    l.append(f)
    l.append(a['b'])
    l.append(b[3]['b'])
    l.append(c['b'])
    l.append(d['b'])
    l.append(e)
    l.append(f)
    s="abc"
    t=Token(b, 0, 0, s)

# Generated at 2022-06-24 11:23:13.840300
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(None, 0, 1)
    hash_value = hash(None)
    assert token.__hash__() == hash_value

# Generated at 2022-06-24 11:23:23.987407
# Unit test for constructor of class DictToken
def test_DictToken():
    # given
    key_token = ScalarToken(1, 0, 0)
    value_token = ScalarToken("test", 0, 4)
    input = {key_token: value_token}

    # when
    token = DictToken(value=input, start_index=0, end_index=4, content="")
    # then
    # assert (token._child_keys == {};
    # assert not(token._child_keys == {1: ScalarToken});
    # assert token._child_keys == {1: key_token};
    assert token._child_keys[1] == key_token
    # assert token._child_tokens == {}
    # assert token._child_tokens == {1: value_token}
    assert token._child_tokens[1] == value_token

# Generated at 2022-06-24 11:23:29.907907
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken_c = DictToken({'a':10},0,0)
    assert str(DictToken_c) == "DictToken({'a': 10})"


# Generated at 2022-06-24 11:23:33.435305
# Unit test for constructor of class Token
def test_Token():
    try:
        Token()._get_value()
    except NotImplementedError:
        print("Success: Cannot call abstract method")


# Generated at 2022-06-24 11:23:38.977073
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t = ScalarToken(1, 0, 2)
    assert t == ScalarToken(1, 0, 2)
    assert t != ScalarToken(2, 0, 2)
    assert t != ScalarToken(1, 1, 2)
    assert t != ScalarToken(1, 0, 3)

    assert ScalarToken(1, 0, 2) != 1
    assert ScalarToken(1, 0, 2) != []



# Generated at 2022-06-24 11:23:46.336192
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """Test method __eq__ of class Token."""
    # No parameters.
    test_tk = Token("", 0, 0)
    # Compare with Token
    other_tk = Token("", 10, 10)
    result = test_tk.__eq__(other_tk)
    assert result == True
    other_tk = Token("", 0, 0)
    result = test_tk.__eq__(other_tk)
    assert result == True
    other_tk = Token("", 0, 10)
    result = test_tk.__eq__(other_tk)
    assert result == False
    other_tk = Token("1", 0, 10)
    result = test_tk.__eq__(other_tk)
    assert result == False
    # Compare with other classes
    other_tk = 2
    result = test_tk

# Generated at 2022-06-24 11:23:47.366261
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({'a': 1}, 0, 11, '{ "a": 1 }').string == '{ "a": 1 }'

# Generated at 2022-06-24 11:23:56.309709
# Unit test for constructor of class Token
def test_Token():
    token_1 = ScalarToken(1, 0, 1, "test")
    token_2 = ScalarToken(2, 1, 2, "test")
    assert token_1.start == Position(1, 1, 0)
    assert token_1.end == Position(1, 2, 1)
    assert token_2.start == Position(1, 2, 1)
    assert token_2.end == Position(1, 3, 2)
    assert token_1.value == 1
    assert token_2.value == 2
    assert token_1 == token_1
    assert token_2 == token_2
    assert token_1 != token_2
    assert token_2 != token_1

# Generated at 2022-06-24 11:24:02.174487
# Unit test for constructor of class Token
def test_Token():
    string = "hello, world!"
    start_index = 1
    end_index = 5
    token = Token(string, start_index, end_index)
    assert str(token) == "Token('ello')"
    assert token.start == Position(1, 2, 1)
    assert token.end == Position(1, 6, 5)
    assert token.string == string[start_index : end_index + 1]
    assert token.value == string[start_index : end_index + 1]


# Generated at 2022-06-24 11:24:04.969615
# Unit test for method lookup of class Token
def test_Token_lookup():
    assert Token( value = 1, start_index = 1, end_index = 2).lookup([1,2,3]) is None


# Generated at 2022-06-24 11:24:12.950993
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from datetime import datetime
    from typesystem.types import Date, DateTime
    from typesystem.timezones import UTC

    tzinfo = UTC()
    token_1 = ScalarToken(datetime(2018, 10, 4, 14, 56, 59, 123000, tzinfo), 0, 0)
    token_2 = ScalarToken(datetime(2018, 10, 4, 14, 56, 59, 123000, tzinfo), 0, 0)

    assert(token_1 == token_2)

    token_3 = ScalarToken(
        Date(format="%Y-%m-%d", location="start", strict=False).value, 0, 0
    )

# Generated at 2022-06-24 11:24:22.372116
# Unit test for constructor of class DictToken
def test_DictToken():
    # test case 1
    # Input:
    # self = {'a': 1, 'b': 2, 'c': 3}
    # Output:
    # self = {'a': 1, 'b': 2, 'c': 3}
    # self._child_keys = {'a': 1, 'b': 2, 'c': 3}
    # self._child_tokens = {'a': 1, 'b': 2, 'c': 3}
    d = DictToken({'a': 1, 'b': 2, 'c': 3})
    assert isinstance(d, DictToken)
    assert d._child_keys == {'a': 1, 'b': 2, 'c': 3}
    assert d._child_tokens == {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-24 11:24:28.249432
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    t1 = DictToken(
        {
            ScalarToken(5, 0, 0): ScalarToken(6, 1, 1),
            ScalarToken(7, 2, 2): ScalarToken(8, 3, 3),
        },
        0,
        3,
        content="567",
    )
    assert t1.lookup([1]).string == "8"
    assert t1.lookup_key([0, 1]).string == "7"

# Generated at 2022-06-24 11:24:31.843822
# Unit test for constructor of class Token
def test_Token():
    token = Token("Hello", 3, 5)
    assert token.string == "lo"
    # assert token.value == "Hello"
    assert token.start == Position(1, 4, 3)
    assert token.end == Position(1, 6, 5)
    assert repr(token) == "Token('lo')"
    # assert token == token
    # assert token != None


# Generated at 2022-06-24 11:24:32.782628
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken([])


# Generated at 2022-06-24 11:24:34.945944
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(value=5, start_index=5, end_index=5, content="")
    assert hash(token) == hash(5)



# Generated at 2022-06-24 11:24:42.137774
# Unit test for constructor of class Token
def test_Token():
    s = "a simple string" 
    t = Token(True, 3, 5, s)
    assert t.string == "sim"
    assert t.start == Position(1, 4, 3)
    assert t.end == Position(1, 6, 5)
    assert repr(t) == "Token('sim')"
    assert t == t
    assert t != "sim"
    t2 = Token(True, 3, 5, s)
    assert t == t2
    t3 = Token(False, 3, 5, s)
    assert t != t3
    t4 = Token(True, 4, 5, s)
    assert t != t4
    t5 = Token(True, 3, 6, s)
    assert t != t5
    assert t.lookup([1]) == t.lookup([1])
   

# Generated at 2022-06-24 11:24:49.463636
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    from kpython.klib import ksorted
    token = Token(None, 0, 1, content='abcd')
    assert token.__repr__() == "Token('a')"
    dict_token = DictToken({'a': Token('a', 0, 1, content='abcd'), 'b': Token('b', 2, 3, content='abcd')}, 0, 3, 'abcd')
    assert dict_token.__repr__() == "DictToken('ab')"
    # list_token = ListToken([Token('a', 0, 1, content='abcd'), Token('b', 2, 3, content='abcd')], 0, 3, 'abcd')
    # assert list_token.__repr__() == "DictToken('ab')"



# Generated at 2022-06-24 11:24:54.071366
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    t1 = ScalarToken('a',0,0,'a')
    t2 = ScalarToken('c',0,0,'c')
    assert t1 != t2
    t3 = ScalarToken('b', 0,0,'b')
    assert t3 == t3


# Generated at 2022-06-24 11:24:58.898533
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token(1,2,3)
    assert token.__repr__() == "Token(1)"


# Generated at 2022-06-24 11:25:01.090956
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken(value={}, start_index=0, end_index=0, content="")


# Generated at 2022-06-24 11:25:08.306939
# Unit test for constructor of class DictToken
def test_DictToken():
    dictToken = DictToken(4,4,4,4)
    assert dictToken._value==4
    assert dictToken._end_index==4


# Generated at 2022-06-24 11:25:16.090785
# Unit test for constructor of class ListToken
def test_ListToken():
    t = ListToken([1, 2, 3], 0, 5)
    assert t.value == [1, 2, 3]
    assert t.start.line == 1
    assert t.start.column == 1
    assert t.start.index == 0
    assert t.end.line == 1
    assert t.end.column == 6
    assert t.end.index == 5
    assert t.string == "[1, 2, 3]"
    with pytest.raises(NotImplementedError):
        t._get_key_token(1)

# Generated at 2022-06-24 11:25:20.265423
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken({"a": 2, "b": 3}, 0, 5)
    assert isinstance(t, DictToken)
    assert t.start.column == 1
    assert t.end.column == 6
    assert t.value == {"a": 2, "b": 3}

test_DictToken()

# Generated at 2022-06-24 11:25:33.836983
# Unit test for constructor of class Token
def test_Token():
    from typesystem.fields import Text

    class TextListToken(ListToken):

        def set_string(self, string):
            self._content = string

    text = Text()
    text_tokens = [
        ScalarToken("At the start", 0, 1, content=string),
        ScalarToken("middle", 3, 4, content=string),
        ScalarToken("end.", 5, 6, content=string),
    ]
    string = "At the start middle end."
    text_list_token = TextListToken(text_tokens, 0, 6, content=string)
    text_list_token.set_string(string)
    assert text_list_token.lookup_key([0]).end.line_no == 1
    assert text_list_token.lookup_key([1]).end.line_no

# Generated at 2022-06-24 11:25:35.939267
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    inst = ScalarToken('str', 1, 2, content='3')
    assert inst.__hash__() == hash('str')



# Generated at 2022-06-24 11:25:38.471713
# Unit test for constructor of class Token
def test_Token():
    instance = Token(None, 0, None)
    assert instance.__class__.__name__ == "Token"
    assert isinstance(instance, Token)
    assert instance._value == None
    assert instance._start_index == 0
    assert instance._end_index == None
    assert instance._content == ""


# Generated at 2022-06-24 11:25:44.813884
# Unit test for constructor of class ListToken
def test_ListToken():
    try:
        token = ListToken(value = [], start_index = 0, end_index = 0)
        assert token.string == ""
        assert token._content == ""
        assert token.value == []
        assert token.start == Position(1, 1, 0)
        assert token.end == Position(1, 1, 0)
    except NotImplementedError as err:
        assert True


# Generated at 2022-06-24 11:25:54.125656
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # Test Token.lookup_key method with token type DictToken
    d = DictToken({"foo": "bar"}, start_index=0, end_index=3, content="foo: bar")
    assert d.lookup_key([0]) == ScalarToken(
        key="foo", start_index=1, end_index=2, content="foo: bar"
    )
    # Test Token.lookup_key method with token type ListToken
    l = ListToken(["foo", {"bar": "baz"}], start_index=0, end_index=6, content="foo, bar: baz")
    assert l.lookup_key([1, 0]) == ScalarToken(
        key="bar", start_index=5, end_index=5, content="foo, bar: baz"
    )
    #

# Generated at 2022-06-24 11:26:03.698001
# Unit test for constructor of class ListToken
def test_ListToken():
 
    # happy path
    start_index = 45
    end_index = 50
    value = [
        "This",
        "is",
        "a",
        "test",
    ]
    content = "This is a test"
    ListToken(value,start_index,end_index,content)
    
    # fail path : Token is not a list or tuple
    value = "This is a test"
    with pytest.raises(ValueError):
        ListToken(value,start_index,end_index,content)


# Generated at 2022-06-24 11:26:09.772778
# Unit test for method lookup of class Token
def test_Token_lookup():
    # arr_token.lookup([0])
    assert(arr_token.lookup([0]) == payload_token)
    assert(arr_token.lookup([0,0]) == payload_token)
    assert(arr_token.lookup([0,0,0]) == payload_token)
    # arr_token.lookup([1])
    assert(arr_token.lookup([1]) == payload_token)
    assert(arr_token.lookup([1,0]) == payload_token)
    assert(arr_token.lookup([1,0,0]) == payload_token)
    # dict_token.lookup([2])
    assert(dict_token.lookup([2]) == payload_token)
    assert(dict_token.lookup([2,0]) == payload_token)

# Generated at 2022-06-24 11:26:17.401832
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    import json
    from unit_test_common import execute_csv2_request, initialize_csv2_request, ut_id, sanity_requests
    from sys import argv
    sanity_requests('/logout/', ut_id(argv), 'unittest')
    initialize_csv2_request(ut_id(argv), 'unittest')
    execute_csv2_request('/system/version/', ut_id(argv), 'unittest')


# Generated at 2022-06-24 11:26:23.319936
# Unit test for method lookup of class Token
def test_Token_lookup():
    from typesystem.token import ListToken, ScalarToken
    tokens = [
        ScalarToken("a", 0, 0),
        ScalarToken("b", 1, 1),
        ScalarToken("c", 2, 2),
    ]
    list_token = ListToken(tokens, 0, 2)
    assert list_token.lookup([0]) == tokens[0]
    assert list_token.lookup([1]) == tokens[1]
    assert list_token.lookup([2]) == tokens[2]



# Generated at 2022-06-24 11:26:28.026808
# Unit test for constructor of class ListToken
def test_ListToken():
    t = ListToken([1, 2, 3], 0, 2, "1, 2, 3")
    assert t._get_value() == [1, 2, 3]
    t = ListToken([1, 2, 3], 0, 2)
    assert t._get_value() == [1, 2, 3]

# Generated at 2022-06-24 11:26:29.266085
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken(None, 0, 0, content='') != None

# Generated at 2022-06-24 11:26:34.804253
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert ScalarToken(0, 0, 0).__hash__() == ScalarToken(1, 0, 0).__hash__()


# Generated at 2022-06-24 11:26:39.474762
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    content = "abcde"
    token1 = ScalarToken("abc", 1, 3, content)
    token2 = ScalarToken("abc", 1, 3, content)
    assert token1 == token2
    token3 = ScalarToken("ab", 1, 2, content)
    assert token1 != token3
    token4 = ListToken(["abc"], 0, 3, content)
    assert token4 != token1


# Generated at 2022-06-24 11:26:42.806575
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    _value = object()
    _start_index = object()
    _end_index = object()
    _content = object()

    Token(_value, _start_index, _end_index, _content)


# Generated at 2022-06-24 11:26:53.589810
# Unit test for method lookup of class Token
def test_Token_lookup(): # pragma: nocover
    """
    Tests the method lookup of class Token
    """
    def __init__(self, value, start_index, end_index, content = ""):
        self._value = value
        self._start_index = start_index
        self._end_index = end_index
        self._content = content

    def _get_value(self):
        raise NotImplementedError  # pragma: nocover

    def _get_child_token(self, key):
        raise NotImplementedError  # pragma: nocover

    def _get_key_token(self, key):
        raise NotImplementedError  # pragma: nocover

    string = ""    
    content = ""
    assert (Token.lookup(content, string) == content)

# Generated at 2022-06-24 11:26:55.574002
# Unit test for method lookup of class Token
def test_Token_lookup():
    t = Token(None, 0, 5, content="123456")
    
    t.lookup([1,2])



# Generated at 2022-06-24 11:27:05.932899
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    start_index = 1
    end_index = 3
    content = "abc"
    value = "ab"
    st = ScalarToken(value, start_index, end_index, content)

    assert st._value == value
    assert st._start_index == start_index
    assert st._end_index == end_index
    assert st.string == value
    assert st.value == value
    assert st.start == Position(1, 2, 1)
    assert st.end == Position(1, 1, 3)
    assert st.lookup(()) == st
    assert st.lookup_key(()) == st
    assert repr(st) == "ScalarToken('ab')"
    assert st == ScalarToken(value, start_index, end_index, content)
    assert hash(st) == hash(value)

# Generated at 2022-06-24 11:27:12.145308
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__(): # real signature unknown; restored from __doc__
    """
    Unit test for method __hash__ of class ScalarToken
    """
    pass


# Generated at 2022-06-24 11:27:23.296372
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # object of base class Token cannot be instantiated
    # TypeError: Can't instantiate abstract class Token with abstract methods _get_value
    # token = Token()

    obj1 = ListToken([1, 2], 0, 3, "[1, 2]")
    obj2 = ListToken([1, 2], 0, 3, "[1, 2]")
    obj3 = ScalarToken(1, 0, 0, "1")
    obj4 = ScalarToken(2, 0, 0, "2")
    # test eq
    assert obj1 == obj1
    assert obj1 == obj2
    # test not eq
    assert obj1 != obj3
    assert obj1 != obj4



# Generated at 2022-06-24 11:27:27.747622
# Unit test for constructor of class Token
def test_Token():
    token = Token(
        value=[],
        start_index=0,
        end_index=1,
        content='{"key":"value"}'
    )
    assert token._value == []
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == '{"key":"value"}'


# Generated at 2022-06-24 11:27:30.319037
# Unit test for constructor of class DictToken
def test_DictToken():
    # Given
    token = DictToken(dict(a=1), 0, 1)

    # Then
    assert token.value == {'a': 1}

# Generated at 2022-06-24 11:27:36.831083
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    content= "!S(:test:test:test:test)test"
    from typesystem.parser import Parser
    token = Parser(content).parse()
    assert token.lookup_key([0]).string == ":test"
    assert token.lookup_key([1]).string == ":test"
    assert token.lookup_key([2]).string == ":test"
    assert token.lookup_key([3]).string == ":test"


# Generated at 2022-06-24 11:27:49.128192
# Unit test for constructor of class Token
def test_Token():
    t1 = Token(
        value={"date": "2018-01-01"},
        start_index=0,
        end_index=10,
        content="{'date': '2018-01-01'}"
    )
    assert t1.string == "{'date': '2018-01-01'}"
    assert t1.value == {"date": "2018-01-01"}
    assert t1.start == Position(1, 1, 0)
    assert t1.end == Position(1, 14, 13)

    t2 = Token(
        value="2018-01-01",
        start_index=2,
        end_index=11,
        content="{'date': '2018-01-01'}"
    )
    assert t2.string == "'2018-01-01'"
    assert t2.value

# Generated at 2022-06-24 11:27:55.003394
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken(["a","b"],0,0)
    assert token.value == ["a","b"]
    try:
        token.lookup_key(0)
        assert False
    except NotImplementedError:
        assert True


# Generated at 2022-06-24 11:27:59.208524
# Unit test for constructor of class ListToken
def test_ListToken():
    t = ListToken(['a', 'b', 'c'], 0, 1)
    assert t._get_value()[0] == 'a'
    assert t._get_value()[1] == 'b'
    assert t._get_value()[2] == 'c'


# Generated at 2022-06-24 11:28:08.870541
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class TestToken(Token):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)

        def _get_value(self) -> typing.Any:
            return self._value

        def _get_child_token(self, key: typing.Any) -> Token:
            return self._value[key]

        def _get_key_token(self, key: typing.Any) -> Token:
            return self._value[key]

    value = {"a": "b"}
    token = TestToken(value, 0, 10)
    token1 = TestToken(value, 0, 10)
    token2 = TestToken(value, 1, 10)
    assert token == token1
    assert token1 != token2
    assert token

# Generated at 2022-06-24 11:28:19.584228
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    start_index = 0
    end_index = 5
    content = "hello"
    value = "world"
    st = ScalarToken(value, start_index, end_index, content)
    assert st.string == "hello"
    assert st.value == "world"
    assert st.start.line_no == 1
    assert st.start.column_no == 1
    assert st.start.index == 0
    assert st.end.line_no == 1
    assert st.end.column_no == 6
    assert st.end.index == 5
    assert str(st) == "ScalarToken('hello')"
    assert st == st
    assert st.__hash__() == hash("world")


# Generated at 2022-06-24 11:28:28.912233
# Unit test for constructor of class DictToken
def test_DictToken():
    a = Position(1, 1, 1)
    b = Position(2, 2, 2)
    c = Position(3, 3, 3)
    d = Position(4, 4, 4)

    scalar_a = ScalarToken(Position, 1, 3, '123')
    scalar_b = ScalarToken(Position, 4, 6, '456')
    scalar_c = ScalarToken(Position, 7, 9, '789')

    dict_a = DictToken({scalar_a: scalar_b}, None, None, '123456')

    assert dict_a.start == a
    assert dict_a.end == b
    assert dict_a.value == {Position(1, 1, 1): Position(2, 2, 2)}

# Generated at 2022-06-24 11:28:34.004938
# Unit test for constructor of class Token
def test_Token():
    with pytest.raises(NotImplementedError):
        Token('', 0, 0)._get_value()
    with pytest.raises(NotImplementedError):
        Token('', 0, 0)._get_child_token(0)
    with pytest.raises(NotImplementedError):
        Token('', 0, 0)._get_key_token(0)


# Generated at 2022-06-24 11:28:44.445831
# Unit test for constructor of class DictToken
def test_DictToken():
    import sys
    
    # initialize
    test_obj = DictToken(dict(), 0, 0, "")
    assert test_obj is not None
    # assert type(test_obj) == DictToken
    # assert test_obj._value == dict()
    # assert test_obj._start_index == 0
    # assert test_obj._end_index == 0
    # assert test_obj._content == ""
    # assert test_obj._child_keys == {k._value: k for k in test_obj._value.keys()}
    # assert test_obj._child_tokens == {k._value: v for k, v in test_obj._value.items()}



# Generated at 2022-06-24 11:28:48.365660
# Unit test for constructor of class Token
def test_Token():
    """
    >>> token = Token("value", 0, 0)
    >>> assert token._value == "value"
    >>> assert token._start_index == 0
    >>> assert token._end_index == 0
    """



# Generated at 2022-06-24 11:28:50.708874
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token(None, 1, 1, "")
    assert repr(token) == "Token('None')"


# Generated at 2022-06-24 11:28:55.382924
# Unit test for constructor of class ListToken
def test_ListToken():
    test_value = "abcdef"
    test_start_idx = 2
    test_end_idx = 5
    test_content = "abcdefghij"
    test_token = ListToken(test_value, test_start_idx, test_end_idx, test_content)
    assert test_token is not None

# Generated at 2022-06-24 11:29:02.518832
# Unit test for constructor of class DictToken
def test_DictToken():
    def _test_constructor():
        d_obj = {"key1": 1, "key2": 2}
        d_obj_token = DictToken(
            d_obj, 10, 16, "{'key1': 1, 'key2': 2}"
        )
        assert (d_obj_token.string == "{'key1': 1, 'key2': 2}")
        assert (d_obj_token.value == {"key1": 1, "key2": 2})
        # assert (d_obj_token.start == 0)
        # assert (d_obj_token.end == 15)
        # assert (d_obj_token._get_value() == {"key1": 1, "key2": 2})
        # assert (d_obj_token.lookup([0]) == 1)
        # assert (d_obj

# Generated at 2022-06-24 11:29:04.055697
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    assert ScalarToken("test", 0, 4, content="test")



# Generated at 2022-06-24 11:29:05.206661
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(0, 0, 0) == Token(0, 0, 0)

# Generated at 2022-06-24 11:29:09.341055
# Unit test for constructor of class ListToken
def test_ListToken():
    input = "hello world"
    start_index = 0
    end_index = 1
    content = "hello world"
    token = ListToken(input, start_index, end_index, content)
    assert token._value == input
    assert token._start_index == start_index
    assert token._end_index == end_index
    assert token._content == content

# Generated at 2022-06-24 11:29:13.340369
# Unit test for method lookup of class Token
def test_Token_lookup():
    value = ['foo', 'bar', 'baz']
    start_index = 12
    end_index = 25
    content = "this is a test"
    T = Token(value, start_index, end_index, content)
    assert T.lookup([0]) == ['foo', 'bar', 'baz'][0]
    assert T.lookup_key([0]) == ['foo', 'bar', 'baz'][0]
    return

# Generated at 2022-06-24 11:29:23.662713
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken(["IBM", 3], 0, 1, content="IBM")
    assert token.string == "IBM"
    assert token.lookup([0]).string == "IBM"
    assert token.lookup([1]).string == "3"
    assert token.start.line_no == 1
    assert token.start.column_no == 1
    assert token.start.index == 0
    assert token.end.line_no == 1
    assert token.end.column_no == 3
    assert token.end.index == 2


# Generated at 2022-06-24 11:29:29.946699
# Unit test for constructor of class ListToken
def test_ListToken():
    listToken = ListToken([1, 2], 1, 2)
    assert listToken._value == [1, 2]
    assert listToken._start_index == 1
    assert listToken._end_index == 2
    assert listToken._content == ""
    assert listToken.start == Position(1, 1, 1)
    assert listToken.end == Position(1, 1, 2)
    assert listToken.string == ""
    assert listToken.lookup([0]) == 1

# Generated at 2022-06-24 11:29:37.892025
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert ScalarToken(value="", start_index=0, end_index=0).__hash__() == hash("")
    assert ScalarToken(value=True, start_index=0, end_index=0).__hash__() == hash(True)
    assert ScalarToken(value=False, start_index=0, end_index=0).__hash__() == hash(False)
    assert ScalarToken(value=None, start_index=0, end_index=0).__hash__() == hash(None)
    assert ScalarToken(value=1, start_index=0, end_index=0).__hash__() == hash(1)
    assert ScalarToken(value=-.1, start_index=0, end_index=0).__hash__() == hash(-.1)

# Generated at 2022-06-24 11:29:43.146692
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    scalarValue = "example"
    startI = 0
    endI = 10
    content = "example"
    a = ScalarToken(scalarValue,
                    startI,
                    endI,
                    content)
    assert a._value == "example"
    assert a._start_index == 0
    assert a._end_index == 10
    assert a._content == "example"

# Generated at 2022-06-24 11:29:46.841912
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert ScalarToken(
        value="string", start_index=0, end_index=5, content="string"
    ).__hash__() == hash("string")

# Generated at 2022-06-24 11:29:49.273273
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken([1,2,3], 0, 0)
    assert token._value == [1,2,3]
    

# Generated at 2022-06-24 11:29:51.445366
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    scalar_token = ScalarToken(123, 4, 75, '"test"')
    assert hash(scalar_token) == hash(123)


# Generated at 2022-06-24 11:29:59.773165
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    length = 4
    name = 'string'
    value = 'abc'
    args = []
    kwargs = {'length': length, 'name': name}
    content = value*length
    start_index = 0
    end_index = 0 + length - 1
    s = ScalarToken(value, start_index, end_index, content, *args, **kwargs)
    result = s.__hash__()
    expected = hash(value)
    assert result == expected


# Generated at 2022-06-24 11:30:02.343223
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # Create an instance of the class under test
    scalar_token = ScalarToken("abc", 0, 2, "abc")

    # Call the method under test
    hash_value = scalar_token.__hash__()

    # Check the result
    assert hash_value == hash("abc")

# Generated at 2022-06-24 11:30:04.690994
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken({"a": 1, "b": 2})


# Generated at 2022-06-24 11:30:07.668053
# Unit test for constructor of class Token
def test_Token():
    a = Token("x", "1", "2")
    assert a._value == "x"
    assert a._start_index == "1"
    assert a._end_index == "2"



# Generated at 2022-06-24 11:30:09.332372
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    obj = ScalarToken("foo", 0, 2)
    # This should not raise an exception
    hash(obj)


# Generated at 2022-06-24 11:30:17.544919
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # Object under test
    scalar_token = ScalarToken("", 0, 0)

    # Invoke the method under test
    result = scalar_token.__hash__()

    # Check the result
    assert isinstance(result, int)
    # Check the value
    assert result == hash(scalar_token._value)


# Generated at 2022-06-24 11:30:29.042179
# Unit test for method lookup of class Token

# Generated at 2022-06-24 11:30:30.893122
# Unit test for constructor of class DictToken
def test_DictToken():
    pass

# Generated at 2022-06-24 11:30:33.602450
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, 0, 0)
    token2 = token
    assert (token == token2)



# Generated at 2022-06-24 11:30:41.610168
# Unit test for constructor of class Token
def test_Token():
    value = "hello world"
    start_index = 0
    end_index = 10
    content = "hello world\n"
    token = Token(value, start_index, end_index, content)
    assert token.string == "hello world"
    assert token.value == "hello world"
    assert token.start == Position(1, 11, 10)
    assert token.end == Position(1, 11, 10)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token


# Generated at 2022-06-24 11:30:44.708659
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_1 = ScalarToken("Value", 0, 5)
    token_2 = ScalarToken("Value", 0, 5)
    assert token_1 == token_2
    token_1 = ScalarToken("Value", 1, 5)
    assert token_1 != token_2


# Generated at 2022-06-24 11:30:48.679853
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Set up variables for test
    value = None
    start_index = 0
    end_index = None
    content = ""
    token = Token(value, start_index, end_index, content)

    # Call function to be tested
    result = repr(token)

    # Assert expected outputs against actual outputs
    assert result == "<Token('')>"


# Generated at 2022-06-24 11:30:57.277739
# Unit test for constructor of class DictToken
def test_DictToken():
    config = {'token': 'value', 'token2': 'value2'}
    start_index = 0
    end_index = 100
    content = "this is the content"
    dict_tok = DictToken(value=config, start_index=start_index, end_index=end_index, content=content)
    if not hasattr(dict_tok, '_child_keys'):
        raise AssertionError
    if not hasattr(dict_tok, '_child_tokens'):
        raise AssertionError
    if dict_tok._child_keys != {'token': 'value', 'token2': 'value2'}:
        raise AssertionError

# Generated at 2022-06-24 11:31:01.979733
# Unit test for method lookup of class Token
def test_Token_lookup():
    # test_Token_lookup_01:
    token = ScalarToken({"test": 1}, 0, 3, "test")
    # lookup into scalar token
    assert token.lookup([0]) is None
    # lookup into not existing index
    assert token.lookup([1, 1]) is None
    # test_Token_lookup_02:
    token = DictToken({"test": 1}, 0, 3, "test")
    # lookup into dict token
    assert token.lookup([0]) is None
    # lookup into not existing index
    assert token.lookup([1, 1]) is None
    # test_Token_lookup_03:
    token = ListToken([{"test": 1}, {"test": 2}], 0, 3, "test")
    # lookup into list token

# Generated at 2022-06-24 11:31:02.684183
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    pass

# Generated at 2022-06-24 11:31:12.219749
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    dic_t = {'k1': 5, 'k2': 'y', 'k3': {'a': 'b'}}
    lst_t = [1, 'x', {'a': 'b'}]
    dic_token = DictToken(dic_t, 0, 0, '{"k1":5,"k2":"y","k3":{"a":"b"}}')
    lst_token = ListToken(lst_t, 0, 0, '[1,"x", {"a":"b"}]')
    import pytest

    pytest.raises(Exception, lambda: lst_token.lookup_key([0]))
    pytest.raises(Exception, lambda: dic_token.lookup_key([0, 'a']))

# Generated at 2022-06-24 11:31:16.131960
# Unit test for constructor of class ListToken
def test_ListToken():
    from pyrsistent import pvector
    x = ListToken(pvector([]), 0, 2, "123")
    x.value == []
    assert isinstance(x.value, list)
    assert isinstance(x.start, Position)
    assert isinstance(x.end, Position)
    assert x.string == "123"

# Generated at 2022-06-24 11:31:23.094859
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from typesystem.base import Position
    from typesystem.parser.tokens import ScalarToken
    # create a token with the content '12345'
    token = ScalarToken(12, 0, 4, '12345')
    assert token.lookup_key([]) == token
    assert token.lookup_key([0]) == token
    assert token.lookup_key([0, 0]) == token
    assert token.lookup_key([0, 1]) == token
    assert token.lookup_key([1]) == token
    assert token.lookup_key([1, 0]) == token
    assert token.lookup_key([1, 1]) == token
    assert token.lookup_key([2]) == token
    assert token.lookup_key([2, 0]) == token

# Generated at 2022-06-24 11:31:31.452456
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Test if the '__repr__' method of class 'Token' works as expected
    
    from typesystem.token import Token
    from typesystem.token import ScalarToken
    from typesystem.token import DictToken
    from typesystem.token import ListToken

    assert repr(ScalarToken({}, 0, 0, '')) == "ScalarToken({})"
    assert repr(DictToken({}, 0, 0, '')) == "DictToken({})"
    assert repr(ListToken([], 0, 0, '')) == "ListToken([])"

    assert repr(ScalarToken(1, 0, 0, '')) == "ScalarToken(1)"
    assert repr(ScalarToken('String', 0, 0, '')) == "ScalarToken('String')"