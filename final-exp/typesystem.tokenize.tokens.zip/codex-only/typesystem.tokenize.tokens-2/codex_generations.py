

# Generated at 2022-06-24 11:21:27.393594
# Unit test for method lookup of class Token
def test_Token_lookup():
    # TODO Write test
    pass

# Generated at 2022-06-24 11:21:32.861884
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = ListToken(
        [
            DictToken(
                {
                    ScalarToken("a", 0, 0): ScalarToken("v1", 0, 0),
                    ScalarToken("b", 0, 0): ScalarToken("v2", 0, 0),
                },
                0,
                0,
            )
        ],
        0,
        0,
    )
    assert token.lookup([0]).string == '{"a": "v1", "b": "v2"}'
    assert token.lookup([0, "a"]).string == '"v1"'
    assert token.lookup([0, "b"]).string == '"v2"'
    assert token.lookup_key([0, "a"]).string == '"a"'

# Generated at 2022-06-24 11:21:35.103739
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    t1=ScalarToken(4,0,0)
    assert(t1.string=="4")
    assert(t1.value==4)


# Generated at 2022-06-24 11:21:39.598207
# Unit test for constructor of class ListToken
def test_ListToken():
    a_list=ListToken(['a', 'b', 'c'], 1, 2)
    assert a_list._value == ['a', 'b', 'c']
    assert a_list._start_index == 1
    assert a_list._end_index == 2



# Generated at 2022-06-24 11:21:49.280420
# Unit test for method lookup of class Token
def test_Token_lookup():
    # Stub values
    value1 = None
    start_index1 = 1
    end_index1 = 2
    content1 = None
    value2 = None
    start_index2 = None
    end_index2 = None
    content2 = None
    value3 = None
    start_index3 = None
    end_index3 = None
    content3 = None
    value4 = None
    start_index4 = None
    end_index4 = None
    content4 = None
    index = None

    # Stub variables
    class StubToken():
        def __init__(self, value, start_index, end_index, content):
            self._value = value
            self._start_index = start_index
            self._end_index = end_index
            self._content = content
            self.string = None
            self

# Generated at 2022-06-24 11:21:52.335421
# Unit test for constructor of class ListToken
def test_ListToken():
	s = "Hello world!"
	l = list(s)
	t = ListToken(l, 0, 11, content = s)
	s2 = t._get_value()
	assert s2 == list(s)

# Generated at 2022-06-24 11:21:53.721672
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert ScalarToken(1, 1, 1) == ScalarToken(1, 0, 0)

# Generated at 2022-06-24 11:22:00.904638
# Unit test for constructor of class Token
def test_Token():
    t = Token(1,0,1)
    assert t.string == ""
    assert t.value == ""
    assert t.start.line_no == 1
    assert t.start.column_no == 1
    assert t.start.index == 0
    assert t.end.line_no == 1
    assert t.end.column_no == 1
    assert t.end.index == 0
    assert repr(t) == "Token('')"
    assert hash(t) == 0



# Generated at 2022-06-24 11:22:11.104889
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # Test1 : assert value of token key at given index is same as expected value
    json = '[{"a": 1}]'
    expected_value = 1
    tokens = TokenDict.from_json(json)
    token = tokens[0].lookup_key([0, "a"])
    assert token.value == expected_value

    # Test2 : assert value of token key at given index is same as expected value
    json = '[{"a": 1}, {"b": 2}]'
    expected_value = 2
    tokens = TokenDict.from_json(json)
    token = tokens[0].lookup_key([1, "b"])
    assert token.value == expected_value

    # Test3 : assert value of token key at given index is same as expected value

# Generated at 2022-06-24 11:22:18.129613
# Unit test for constructor of class ListToken
def test_ListToken():
    # get value of ListToken
    list_token = ListToken(value = [], start_index = 0, end_index = 5)
    assert list_token._get_value() == []
    # get child token of ListToken
    try:
        list_token = ListToken(value = [], start_index = 0, end_index = 5)
        list_token._get_child_token("string")
    except NotImplementedError:
        assert True
    # get key token of ListToken
    try:
        list_token = ListToken(value = [], start_index = 0, end_index = 5)
        list_token._get_key_token("string")
    except NotImplementedError:
        assert True


# Generated at 2022-06-24 11:22:22.743817
# Unit test for method lookup of class Token
def test_Token_lookup():
    assert True

# Generated at 2022-06-24 11:22:28.428609
# Unit test for constructor of class DictToken
def test_DictToken():
    name = 'pete'
    start_index = 100
    end_index = 200
    content = 'Peter'
    args = (name, start_index, end_index, content)
    token = DictToken(*args)
    assert token._content == content and token._start_index == start_index and token._end_index == end_index and token._value == name
    return token


# Generated at 2022-06-24 11:22:32.563552
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    value = True
    start_index = 0
    end_index = 0
    token = ScalarToken(value, start_index, end_index)
    expected = hash(value)
    actual = token.__hash__()
    assert actual == expected

# Generated at 2022-06-24 11:22:34.490350
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    t = Token('1', 0, 1)
    assert repr(t) == "Token('1')"


# Generated at 2022-06-24 11:22:40.136121
# Unit test for constructor of class Token
def test_Token():
    a = Token(value = 1, start_index = 2, end_index = 3)
    assert a._value == 1
    assert a._start_index == 2
    assert a._end_index == 3
    assert a._content == ""
    b = Token(value = 1, start_index = 2, end_index = 3, content = "asd")
    assert b._value == 1
    assert b._start_index == 2
    assert b._end_index == 3
    assert b._content == "asd"


# Generated at 2022-06-24 11:22:43.926049
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    st = ScalarToken(1, 0, 1)
    assert repr(st) == "ScalarToken('1')"
    st2 = ScalarToken(1, 0, 1)
    assert st == st2
    assert hash(st) == hash(st2)


# Generated at 2022-06-24 11:22:48.317743
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    content = """
    foo:
    - bar:
    """

    token = parse(content, ["foo", 0, "bar"])
    assert token.start.character == 7
    assert token.end.character == 10
    

# Generated at 2022-06-24 11:22:49.515363
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken(["a", "b"], 4, 7, 'xyz')


# Generated at 2022-06-24 11:22:57.157347
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    t = ScalarToken("1", 0, 1)
    assert t.string == "1"
    assert t.value == "1"
    assert t.start.line_no == 1
    assert t.start.column_no == 1
    assert t.start.index == 0
    assert t.end.line_no == 1
    assert t.end.column_no == 2
    assert t.end.index == 1


# Generated at 2022-06-24 11:23:00.642874
# Unit test for constructor of class ListToken
def test_ListToken():
    # Test cases:
    assert ListToken([], 0, 0) is not None

# Generated at 2022-06-24 11:23:03.038275
# Unit test for constructor of class Token
def test_Token():
    obj = Token(value=None, start_index=1, end_index=1, content=None)
    assert(obj is not None)


# Generated at 2022-06-24 11:23:10.763210
# Unit test for constructor of class ListToken
def test_ListToken():
    tokens = [0, 1, 2]
    start_index = 0
    end_index = 2
    content = "012"

    token = ListToken(tokens, start_index, end_index, content)
    assert token.string == "012"
    assert token.value == [0, 1, 2]
    assert token.start.line_no == 1
    assert token.start.column_no == 1
    assert token.start.index == 0
    assert token.end.line_no == 1
    assert token.end.column_no == 4
    assert token.end.index == 3
    assert token.lookup([0]).value == 0
    assert token.lookup([1]).value == 1
    assert token.lookup([2]).value == 2

# Generated at 2022-06-24 11:23:14.153511
# Unit test for method lookup of class Token
def test_Token_lookup():
    value = [1,2,3]
    start_index = 2
    end_index = 3
    content = "abc"
    obj = Token(value, start_index, end_index, content)
    result = obj.lookup([0])
    assert result.value == value[0]

# Generated at 2022-06-24 11:23:24.077270
# Unit test for method __repr__ of class Token
def test_Token___repr__():
  # Test object instantiation
  try:
    token_instance = Token(
        value=None, 
        start_index=0, 
        end_index=1, 
        content=str()
    )
  except Exception as e:
    print("\nException thrown during object instantiation:\n{}".format(e))
  else:
    assert token_instance is not None, (
        "Could not instantiate object"
    )
    print("\nObject instantiated successfully:\n{}".format(token_instance))
  # Test method __repr__
  try:
    assert not hasattr(token_instance, "__repr__")
    token_instance.__repr__()
  except Exception as e:
    print("\nException thrown during method call:\n{}".format(e))

# Generated at 2022-06-24 11:23:26.085174
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    scalar = ScalarToken(None, None, None)
    assert hash(scalar) == hash(None)


# Generated at 2022-06-24 11:23:32.650000
# Unit test for constructor of class Token
def test_Token():
    from typesystem.base.typing import List, Mapping, String

    txt = """
    {
        "a": {
            "b": [1, 2],
            "c": 3
        }
    }
    """
    schema = Mapping(String(), Mapping(String(), List(Integer())))
    parsed = schema.loads(txt)
    assert parsed.errors == []
    assert parsed.data == {"a": {"b": [1, 2], "c": 3}}
    assert parsed.cursor
    token = parsed.cursor
    assert token.string == "{'a': {'b': [1, 2], 'c': 3}}"
    assert token.start == Position(2, 2, 1)
    assert token.end == Position(6, 17, 35)

# Generated at 2022-06-24 11:23:42.101954
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class DictToken(dict):
        def __init__(self, *args, **kwargs):
            self._value = args[0]
            self._content = args[1]
            self._start_index = args[2]
            self._end_index = args[3]

    class DictKeys(dict):
        def __init__(self, *args, **kwargs):
            self._value = {}
            self._content = []

        def _get_key_token(self, key):
            return key

    class ListToken(list):
        def __init__(self, *args, **kwargs):
            self._value = args[0]
            self._content = args[1]
            self._start_index = args[2]
            self._end_index = args[3]


# Generated at 2022-06-24 11:23:43.631474
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # TODO: write unit test for method __eq__ of class Token
    pass

# Generated at 2022-06-24 11:23:48.002753
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken()

# Generated at 2022-06-24 11:23:48.929768
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    assert(True)

# Generated at 2022-06-24 11:23:55.945256
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # Define arguments
    value = "hello"

    # Evaluate operation
    result = ScalarToken(value, 0, 0).__hash__()

    # Verify the result
    assert result == hash(value)

# Generated at 2022-06-24 11:24:02.793250
# Unit test for constructor of class ListToken
def test_ListToken():
    from typesystem import types
    from typesystem.types import String
    string_type = String()
    test = String("test")
    token = ListToken(value=[test], start_index=0, end_index=4, content="test")
    assert token._get_value() == ["test"]
    assert token.string == "test"
    assert token.value == ["test"]
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 5, 4)
    assert token.lookup([0]) == token._value[0]


# Generated at 2022-06-24 11:24:10.108999
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    start_index = 0
    end_index = 0
    content = ""
    value = 0
    scalar_token = ScalarToken(value, start_index, end_index, content)
    assert scalar_token._value == 0
    assert scalar_token._start_index == 0
    assert scalar_token._end_index == 0
    assert scalar_token._content == ""
    assert scalar_token.value == 0
    assert scalar_token.string == ""
    assert scalar_token.start == Position(1, 1, 0)
    assert scalar_token.end == Position(1, 1, 0)


# Generated at 2022-06-24 11:24:18.550767
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    t1 = ScalarToken('value', 1, 2, content='value')
    assert t1._value == 'value'
    assert t1._start_index == 1
    assert t1._end_index == 2
    assert t1._content == 'value'
    try:
        token = t1._get_value()
        assert False, 'should not reach here.'
    except NotImplementedError as e:
        assert str(e) == 'No implementation provided.'

    t2 = ScalarToken('value', 1, 2, content='value')
    assert t1 == t2
    assert t1 != 4



# Generated at 2022-06-24 11:24:24.091067
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    string = 'rvk'
    start_index = 'rvk'
    end_index = 'rvk'
    content = 'rvk'
    obj = Token(string, start_index, end_index, content)
    # string = 'rvk'
    start_index = 'rvk'
    end_index = 'rvk'
    content = 'rvk'


    assert repr(obj) == "%s(%s)" % (obj.__class__.__name__, repr(obj.string))

# Generated at 2022-06-24 11:24:26.213320
# Unit test for method __repr__ of class Token
def test_Token___repr__():
  assert Token(1, 2, 3).__repr__() == "Token('')"
  assert Token(1, 2, 3, 'some string').__repr__() == "Token('some string')"


# Generated at 2022-06-24 11:24:29.298238
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(None, 0, 0)
    print('ok')


# Generated at 2022-06-24 11:24:39.998750
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    from typesystem.parser.tokens import Token, ScalarToken, DictToken, ListToken
    from operator import pos
    from collections import Counter
    from typesystem import Number
    import pytest
    import json

    content = """
    {
      "name": "root",
      "children": [
        {
          "name": "A"
        },
        {
          "name": "B"
        }
      ]
    }
    """
    tokens = json.loads(content, cls=Tokenizer)
    assert repr(tokens) == "DictToken({'children': ListToken([DictToken({'name': ScalarToken('A')}), DictToken({'name': ScalarToken('B')})])})"

# Generated at 2022-06-24 11:24:43.737271
# Unit test for constructor of class Token
def test_Token():
    assert Token(value, start_index, end_index, content) == \
        Token(value, start_index, end_index, content)
    assert Token(value, start_index, end_index, content) != \
        Token(value, start_index, end_index, content)


# Generated at 2022-06-24 11:24:46.641831
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken("",0,0)
    assert ListToken("",0,0,"")
    assert ListToken("a",0,0)
    assert ListToken("a",0,0,"")
    assert ListToken("a",0,0,"a",1,2)

# Generated at 2022-06-24 11:24:56.269918
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.parser import parse
    token = parse('{"a": 1}')
    assert isinstance(token, DictToken)
    assert token.value == {"a": 1}
    assert token.string == '{"a": 1}'
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 9, 8)
    assert token.lookup([0]) == token._get_child_token("a")
    assert token.lookup_key([0]) == token._get_key_token("a")
    assert token.lookup([0, 0]) == token._get_child_token("a")._get_child_token(0)



# Generated at 2022-06-24 11:24:58.006915
# Unit test for constructor of class DictToken
def test_DictToken():
    pass


# Generated at 2022-06-24 11:25:00.821894
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {"a": "b", "c": "d"}
    token = DictToken(d, 0, 2, "content")
    assert d == token.value

# Generated at 2022-06-24 11:25:04.469929
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("something", 0, 9)
    assert token.string == "something"
    assert token.value == "something"
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 10, 9)
    assert repr(token) == "ScalarToken('something')"


# Generated at 2022-06-24 11:25:16.597268
# Unit test for constructor of class Token
def test_Token():
    assert Token(value = "scalar_token", start_index = 9, end_index = 18, content = "A String").string == "String"
    assert Token(value = 1, start_index = 2, end_index = 3, content = "123456").string == "3"
    assert Token(value = "array_token", start_index = 5, end_index = 14, content = "Hello World").string == "World"
    assert Token(value = "object_token", start_index = 1, end_index = 10, content = "A String Test").string == "A String"
    assert Token(value = "dictionary_token", start_index = 2, end_index = 11, content = "Hello World").string == "ello Wo"

# Generated at 2022-06-24 11:25:17.248201
# Unit test for method lookup of class Token
def test_Token_lookup():
	assert True

# Generated at 2022-06-24 11:25:18.641068
# Unit test for constructor of class Token
def test_Token():
    t = Token(None, 10, 15)
    assert t._start_index == 10
    assert t._end_index == 15


# Generated at 2022-06-24 11:25:22.108837
# Unit test for constructor of class DictToken
def test_DictToken():
    d1 = DictToken({'id': 3}, 0, 2, 'id:3')
    assert d1._value == {'id': 3}
    assert d1._start_index == 0
    assert d1._end_index == 2
    assert d1._content == "id:3"



# Generated at 2022-06-24 11:25:33.088772
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    content = "content"
    start_index = 5
    end_index = 10
    value = "value" 
    t1 = Token(value, start_index, end_index,content)
    t2 = Token(value, start_index, end_index,content)
    assert(t1 == t2)
    assert(not(t1 == "value"))
    value = ["value1","value2","value3","value4"]
    start_index = [0,6,11,17]
    end_index = [5,10,16,21]
    t2 = ListToken(value, start_index, end_index,content)
    assert(not(t2 == "value"))

# Generated at 2022-06-24 11:25:42.724858
# Unit test for method __repr__ of class Token
def test_Token___repr__():
   def test():
       assert StringToken("hi", 0, 1, "hi") == StringToken("hi", 0, 1, "hi")
   # test()
   #
   # def test_contrast():
   #     assert StringToken("hi", 0, 1, "hi") != StringToken("hi", 0, 1, "hello")
   #
   # test_contrast()
   #
   # def test_contrast2():
   #     assert StringToken("hi", 0, 1, "hi") != StringToken("hi", 1, 1, "hi")
   #
   # test_contrast2()
   #
   # def test_contrast3():
   #     assert StringToken("hi", 0, 1, "hi") != StringToken("hi", 0, 2, "hi")
   #
   # test_contrast3

# Generated at 2022-06-24 11:25:44.082683
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"key": "value"}, 0, 4, "key: value")
    assert d.start.column == 1


# Generated at 2022-06-24 11:25:50.056216
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    print("Test ScalarToken.__hash__")
    token_0 = ScalarToken(value=None, start_index=None, end_index=None, content=None)
    token_1 = ScalarToken(value=None, start_index=None, end_index=None, content=None)
    # Check if the __hash__ of the objects is equal.
    assert hash(token_0) == hash(token_1)


# Generated at 2022-06-24 11:25:51.778562
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    __test__ = {}



# Generated at 2022-06-24 11:26:01.123636
# Unit test for method lookup of class Token
def test_Token_lookup():
    assert Token(123, 0, 2, "abc").lookup([]).value == 123
    assert Token([1, 2, 3], 0, 2, "abc").lookup([0]).value == 2
    assert Token({"b": [1, 2, 3]}, 0, 2, "abc").lookup(["b", 1]).value == 2
    assert Token({"b": {"c": 3}}, 0, 2, "abc").lookup(["b", "c"]).value == 3
    assert Token({1: "a", 2: "b"}, 0, 2, "abc").lookup([2]).value == "b"
    assert Token({"a": "b"}, 0, 2, "abc").lookup(["b"]).value == "b"

# Generated at 2022-06-24 11:26:06.658118
# Unit test for constructor of class Token
def test_Token():
    s = 'This is a scalar token'
    t = Token(s, 0, len(s) - 1)
    assert(t.string == s)
    assert(t.value == s)
    assert(t.start == Position(line_no = 1, column_no = 1, index = 0))
    assert(t.end == Position(line_no = 1, column_no = len(s) + 1, index = len(s) - 1))
    assert(t.lookup([])._get_value() == s)
    assert(t.lookup_key([]) == None)


# Generated at 2022-06-24 11:26:10.547166
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Create an instance of Token
    token = Token("5", 1, 2, "1 2 3 4 5 6 7 8 9")

    # Check that token's string is "5"
    assert token.string == "5"



# Generated at 2022-06-24 11:26:17.743493
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem import Schema, fields
    from typesystem.parser import get_schema_tokens
    import yaml

    class Pet(Schema):
        name = fields.String()
        type = fields.String()
        owner = fields.String()

    class Person(Schema):
        name = fields.String()
        age = fields.Number()
        pets = fields.Array(fields.Instance(Pet), min_length=1)


# Generated at 2022-06-24 11:26:19.689427
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    expected = 1
    actual = ScalarToken(1, 1, 1).__hash__()
    assert expected == actual


# Generated at 2022-06-24 11:26:20.715591
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # FIXME: implement this test
    assert True  # pragma: no cover


# Generated at 2022-06-24 11:26:23.474127
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(value="abc", start_index=1, end_index=3, content="abcd")
    expected = hash("abc")
    actual = token.__hash__()
    assert actual == expected


# Generated at 2022-06-24 11:26:32.533205
# Unit test for method lookup of class Token
def test_Token_lookup():
    name = 'tanyuan'
    age = 31
    address = {'home': 'China', 'company': 'United States'}
    hobbies = ['coding', 'music']
    tmp = {name: {age: {address: {hobbies}}}}
    
    assert tmp[name][age][address][hobbies] == hobbies
    # print(tmp[name][age][address][hobbies])
    
    key = [name, age, address, hobbies]
    
    assert [tmp[name][age][address][hobbies][0]] == key[hobbies:hobbies+1]
    # print(key[hobbies:hobbies+1])

# The above unit test is a demo.
# Actually, the Token class is used for error handling.

# For example, when the parsing comes across an error, it can return 
#

# Generated at 2022-06-24 11:26:34.804558
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    ast = ScalarToken('99', 0, 0)
    assert hash(ast) == hash('99')

# Generated at 2022-06-24 11:26:37.702604
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test Token __eq__
    token1 = ScalarToken(1, 0, 3)
    token2 = ScalarToken(2, 0, 3)
    assert not (token1 == token2)



# Generated at 2022-06-24 11:26:40.040049
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    tok = Token("some value", 1234, 4321)
    assert str(tok) == "Token('some value')"


# Generated at 2022-06-24 11:26:42.954886
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    obj = ScalarToken(value=None, start_index=0, end_index=0)
    result_ = hash(obj)
    assert True  # truthy expression for backward-compatibility reasons



# Generated at 2022-06-24 11:26:45.240951
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({'a':1, 'b':2}, 0, 0)
    assert(token.value == {'a':1, 'b':2})



# Generated at 2022-06-24 11:26:56.803930
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken(value=[], start_index=0, end_index=1, content='[]') == ListToken(value=[], start_index=0, end_index=1, content='[]')
    assert ListToken(value=[], start_index=2, end_index=3, content='[]') != ListToken(value=[], start_index=0, end_index=1, content='[]')
    assert ListToken(value=[], start_index=0, end_index=1, content='[]') != ListToken(value=[], start_index=0, end_index=1, content='{}')
    assert ListToken(value=[], start_index=0, end_index=1, content='[]') != ListToken(value=[], start_index=0, end_index=1, content='%')


# Generated at 2022-06-24 11:27:02.813618
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(value=1, start_index=0, end_index=0, content="1")
    assert token.value == 1
    assert token.start.line == 1
    assert token.start.column == 1
    assert token.end.line == 1
    assert token.end.column == 1
    assert token.start.index == 0
    assert token.end.index == 0
    assert token.string == "1"


# Generated at 2022-06-24 11:27:07.198314
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    from typesystem import String
    from typesystem.base import Token as BaseToken
    from typesystem.base import list_tokens
    from typesystem.base import ScalarToken as BaseScalarToken
    from typesystem.base import DictToken as BaseDictToken
    from typesystem.base import ListToken as BaseListToken
    from typesystem.fields import Dict

    class Token(BaseToken):
        pass

    class ScalarToken(BaseScalarToken):
        pass

    class DictToken(BaseDictToken):
        pass

    class ListToken(BaseListToken):
        pass


# Generated at 2022-06-24 11:27:11.524699
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken('test', 100, 200, 'Testing')
    assert token.string == 'test'
    assert token.value == 'test'
    assert token.start.line_no == 2
    assert token.start.column_no == 100
    assert token.end.line_no == 2
    assert token.end.column_no == 200
    assert token.__repr__() == "ScalarToken('test')"
    assert token == ScalarToken('test', 100, 200, 'Testing')


# Generated at 2022-06-24 11:27:23.829379
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken(value = "test_value", start_index = 1, end_index = 6, content = "btet_value")
    assert(token.string == "test_value")
    assert(token.value == "test_value")
    assert(token.start == Position(1, 6, 1))
    assert(token.end == Position(1, 7, 6))
    token = ListToken(value = "test_value", start_index = 1, end_index = 6, content = "")
    assert(token.string == "test_value")
    assert(token.value == "test_value")
    assert(token.start == Position(1, 6, 1))
    assert(token.end == Position(1, 7, 6))


# Generated at 2022-06-24 11:27:25.274156
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token('token', 0, 10)
    assert repr(token) == "Token(token)"


# Generated at 2022-06-24 11:27:28.834601
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, None, None)
    token2 = Token(None, None, None)
    assert token == token2
    token = Token(1, None, None)
    token2 = Token(None, None, None)
    assert token != token2


# Generated at 2022-06-24 11:27:33.213528
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    # creating the token
    token1 = ScalarToken(None, 0, 0)
    token2 = ScalarToken(None, 1, 1)

    # test the lookup function
    assert token1.lookup([]) == token1
    assert token2.lookup([]) == token2

    assert token1.lookup_key([]) == None
    assert token2.lookup_key([]) == None


# Generated at 2022-06-24 11:27:38.846702
# Unit test for method lookup of class Token
def test_Token_lookup():
    dict = {
        'id': {
            'type': 'string',
            'description': 'The identifier',
            'example': 'abc123'
        }
    }
    list = [
        'id',
        [
            'type',
            'string'
        ],
        [
            'description',
            'The identifier'
        ]
    ]

    if __name__ == '__main__':
        pass

# Generated at 2022-06-24 11:27:43.099051
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    obj = ScalarToken(value=None, start_index=1, end_index=1)
    assert obj.__hash__() == hash(None)

# Generated at 2022-06-24 11:27:52.356661
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token("value", "start_index", "end_index")
    assert isinstance(token, Token) is True, "Class Token not initialized"
    class_name = token.__class__.__name__
    token_value = repr(token.string)
    assert token.__repr__() == (
        '"%s(%s)"' % (class_name, token_value)
    ), "__repr__() method returns wrong value"


# Generated at 2022-06-24 11:27:56.887335
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = ListToken(None, 0, 0)
    # token = ListToken([], 0, 0)
    # token = ListToken([], 0, 0)
    # token = ListToken([], 0, 0)
    # token = ListToken([], 0, 0)
    # token = ListToken([], 0, 0)
    # token = ListToken([], 0, 0)
    # token = ListToken([], 0, 0)
    # token = ListToken([], 0, 0)
    # token = ListToken([], 0, 0)
    # token = ListToken([], 0, 0)
    # token = ListToken([], 0, 0)
    # token = ListToken([], 0, 0)
    # token = ListToken([], 0, 0)
    # token = ListToken([], 0, 0)
    # token =

# Generated at 2022-06-24 11:28:02.654170
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(0, 0, 0)
    assert token.string == "0"
    assert token.value == 0
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert repr(token) == "ScalarToken(0)"



# Generated at 2022-06-24 11:28:11.845607
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    s = ScalarToken(None, 10, 20)
    assert(s._value == None)
    assert(s._start_index == 10)
    assert(s._end_index == 20)
    assert(s.string == '')
    assert(s.value == None)
    assert(s.start == Position(1, 1, 10))
    assert(s.end == Position(1, 1, 20))
    assert(s.lookup([]) == s)      # lookup() is the same at this point
    try:
        s.lookup_key([1])
    except NotImplementedError:
        pass
    except:
        raise AssertionError     # lookup_key() should only throw NotImplementedError
    assert(s._get_position(10) == Position(1, 1, 10))

# Generated at 2022-06-24 11:28:18.429025
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    t_5_1 = Token(5, 1, 5, "")
    assert repr(t_5_1) == "Token(5)"


# Generated at 2022-06-24 11:28:19.716418
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # Arrange
    # Act
    assert True
    # Assert

# Generated at 2022-06-24 11:28:24.634487
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    TokenTest = Token("value", "start_index", "end_index")
    res1 = repr(TokenTest)
    assert repr(TokenTest) == "Token(\"value\")"
    print("Test of method __repr__ of class Token - succesful.")


# Generated at 2022-06-24 11:28:28.767091
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert ScalarToken(1, 0, 0).__hash__() == ScalarToken(1, 0, 0).__hash__()
    assert not ScalarToken(1, 0, 0).__hash__() == ScalarToken(2, 0, 1).__hash__()

# Generated at 2022-06-24 11:28:35.768739
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    print("Test class ScalarToken")
    print("Test method __hash__")
    x = ScalarToken("hello", 0, 4)
    print("Object x=")
    print(x)
    y=hash(x)
    print("Object obtained by invoking the method __hash__ of x=")
    print(y)
    print("We obtain the same result by using the hash() function")
    print("x.__hash__()==hash(x)?")
    print(x.__hash__()==hash(x))
    print("End of test method __hash__")


# Generated at 2022-06-24 11:28:47.647246
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({' x': ScalarToken('x', 0, 2), ' y': ScalarToken('y', 3, 5), ' z': ScalarToken('z', 6, 8)}, 0, 8, " x,y,z")
    assert token.string == " x,y,z"
    assert token.value == {' x': 'x', ' y': 'y', ' z': 'z'}
    assert token.start == (1, 1, 0)
    assert token.end == (1, 9, 8)
    assert token.lookup([0]).string == " x"
    assert token.lookup([1]).string == " y"
    assert token.lookup([2]).string == " z"
    assert token.lookup_key([0]).string == " x"

# Generated at 2022-06-24 11:28:52.672337
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    import pytest

    # Test for class ListToken
    x_0 = ListToken(["a"], 0, 2)
    x_1 = ListToken([x_0], 0, 3)
    assert repr(x_0) == "ListToken('a')"
    assert repr(x_1) == "ListToken(['a'])"

    # Test for class DictToken
    x_0 = ScalarToken(1, 3, 3)
    x_1 = ScalarToken("a", 0, 0)
    x_2 = DictToken({x_1: x_0}, 0, 3)
    x_3 = ScalarToken(2, 3, 3)
    x_4 = ScalarToken("b", 0, 0)
    x_5 = DictToken({x_4: x_3}, 0, 3)


# Generated at 2022-06-24 11:28:55.060207
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token(
        value=None,
        start_index=None,
        end_index=None,
        content=None,
    )
    assert repr(token) == 'Token(None)'


# Generated at 2022-06-24 11:29:00.609345
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(3, 0, 0)
    assert hash(token) == hash(3)



# Generated at 2022-06-24 11:29:05.828640
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({
        ScalarToken("text", 0, 4): ScalarToken("Hello, world!", 5, 18),
        ScalarToken("another key", 19, 29): ScalarToken("Testing 123", 30, 41)
    }, 0, 41, "text: Hello, world!\nanother key: Testing 123")
    d._get_value()



# Generated at 2022-06-24 11:29:09.226334
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    value = 'foo'
    start_index = 2
    end_index = 5
    content = 'bar'
    token = ScalarToken(value, start_index, end_index, content)
    assert repr(token) == 'ScalarToken(\'foo\')'



# Generated at 2022-06-24 11:29:10.169801
# Unit test for method lookup of class Token
def test_Token_lookup():
    assert Token.lookup(1) == 1


# Generated at 2022-06-24 11:29:17.011426
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    content = """
    {
      "foo": [
        {
          "bar": 1
        }
      ]
    }
    """
    token = json.loads(content)
    found_token = token.lookup_key([0, "foo", 0, "bar"])
    assert found_token.string == '"bar"'


test_Token_lookup_key()

# Generated at 2022-06-24 11:29:24.470079
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    output = Token(1, 2, 3) == Token(1, 2, 3)
    assert output == True

    output = Token(1, 2, 3) == 1
    assert output == False

    output = Token(1, 2, 3) == Token(2, 2, 3)
    assert output == False

    output = Token(1, 2, 3) == Token(1, 3, 3)
    assert output == False

    output = Token(1, 2, 3) == Token(1, 2, 4)
    assert output == False


# Generated at 2022-06-24 11:29:28.235278
# Unit test for constructor of class Token
def test_Token():
    t = Token("test",0,3)
    assert t.value == None
    assert t.start == Position(1, 1, 0)
    assert t.end == Position(1, 4, 3)
    assert t.string == "test"


# Generated at 2022-06-24 11:29:32.931829
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class A(Token):
        def __init__(self):
            super().__init__(None, 0, 0)
        def _get_child_token(self, key):
            return "Token"
    
    a = A()
    assert a.lookup_key([]) == "Token"


# Generated at 2022-06-24 11:29:34.560377
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token("value", 0, 1, "content")
    expected = "Token('value')"
    assert repr(token) == expected


# Generated at 2022-06-24 11:29:41.459127
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    a = 1
    b = 2
    c = [a, b]
    d = {"token1": a, "token2": b}
    list_token = ListToken(c, 0, 5, "token")
    dict_token = DictToken(d, 1, 10, "token")
    assert list_token.lookup_key([0]) == ScalarToken(1, 2, 2, "token")
    assert list_token.lookup_key([1]) == ScalarToken(2, 4, 4, "token")
    assert dict_token.lookup_key([1, "token1"]) == ScalarToken(1, 1, 1, "token")
    assert dict_token.lookup_key([1, "token2"]) == ScalarToken(2, 3, 3, "token")

# Generated at 2022-06-24 11:29:47.175335
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    a = ScalarToken(1,0,0)
    assert a._start_index == 0
    assert a._end_index == 0
    assert a.string == ''
    assert a.value == 1
    assert a.start == Position(1,1,0)
    assert a.end == Position(1,1,0)
    assert a.lookup([]) == a
    assert a.lookup_key([]) == a

# Generated at 2022-06-24 11:29:55.106060
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    value_list = []
    start_index_list = []
    end_index_list = []
    content_list = []
    token_list = []

    value_list.append(0)
    start_index_list.append(0)
    end_index_list.append(0)
    content_list.append("")
    token_list.append(Token(value_list[-1], start_index_list[-1], end_index_list[-1], content_list[-1]))

    value_list.append(1)
    start_index_list.append(1)
    end_index_list.append(1)
    content_list.append("")

# Generated at 2022-06-24 11:30:01.291339
# Unit test for method lookup of class Token
def test_Token_lookup():
    parent_token = DictToken(1,2,3,4,5,6)
    child_token = ScalarToken(1,2,3,4,5,"")
    assert parent_token._get_child_token(1) == child_token

# Generated at 2022-06-24 11:30:03.641183
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken([1, 2, 3], 0, 1, "1")._get_value() == [1, 2, 3]



# Generated at 2022-06-24 11:30:09.799014
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    t = DictToken({'a':1, 'b':2}, 0, 10, '{"a":1,"b":2}')
    key_token = t.lookup_key([1])
    assert key_token == ScalarToken('b', 8, 9, '{"a":1,"b":2}')
    key_token = t.lookup_key([1,1])
    assert key_token == ScalarToken(2, 10, 10, '{"a":1,"b":2}')

# Generated at 2022-06-24 11:30:12.241609
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token(
        value=["a","b","c"],
        start_index=0,
        end_index=0)
    assert token.lookup([0]) == token



# Generated at 2022-06-24 11:30:14.068989
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken.__init__ != None



# Generated at 2022-06-24 11:30:24.805832
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    import random
    import string
    import pytest
    import re

    @pytest.fixture
    def scalar_token_class(request):
        return eval(request.param)

    def test_ScalarToken___hash__0(scalar_token_class):
        from typesystem.base import Token
        from numbers import Real

        obj = scalar_token_class(random.choice([random.uniform(-1e9, 1e9), True, False, None]), random.randint(-1e9, 1e9), random.randint(-1e9, 1e9), ''.join(random.sample(string.printable, random.randint(0, 1e9))))
        res = hash(obj)
        assert isinstance(res, int)
        assert res == hash(obj._value)


# Generated at 2022-06-24 11:30:34.634019
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """
    This is a unit test for a function test_Token___eq__ of a class Token.
    """
    # Input arguments
    scalarToken1 = ScalarToken(1,1,2)
    scalarToken2 = ScalarToken(2,2,3)
    scalarToken3 = ScalarToken(3,3,4)
    dictToken1 = DictToken({scalarToken1:scalarToken2},0,4,"{1:2}")
    dictToken2 = DictToken({scalarToken1:scalarToken2},0,4,"{1:2}")
    dictToken3 = DictToken({scalarToken1:scalarToken3},0,4,"{1:3}")

# Generated at 2022-06-24 11:30:37.702821
# Unit test for constructor of class Token
def test_Token():
    asd = Token('asd', 1, 1)

    assert asd.value == None
    assert asd.start.column == 1 
    assert asd.end.column == 1
    assert asd.string == ''


# Generated at 2022-06-24 11:30:43.004809
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    t = ListToken((), 0, 0, [])
    assert str(t) == "ListToken('')"
    t = DictToken((), 0, 0, {})
    assert str(t) == "DictToken('')"
    t = ScalarToken('a', 0, 0)
    assert str(t) == "ScalarToken('a')"

# Generated at 2022-06-24 11:30:49.237300
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # Test the method Token._get_position
    content = "abc\ndef"
    token1 = ScalarToken("abc", 0, 2, content)
    token2 = ScalarToken("def", 5, 7, content)
    token3 = DictToken({token1: token2}, 0, 7, content)
    token4 = ScalarToken("def", 5, 7, content)
    token5 = DictToken({token1: token4}, 0, 7, content)
    assert(token3.lookup_key([0]) == token1)
    assert(token3.lookup_key([1]) == token2)
    assert(token4.lookup_key([0]) == token1)
    assert(token4.lookup_key([1]) == token4)

# Generated at 2022-06-24 11:30:52.011071
# Unit test for constructor of class ListToken
def test_ListToken():
    import json
    json_str = '{"test": {"list": []}}'
    json_dict = json.loads(json_str)
    json_tokenizer = Tokenizer(json_dict)
    assert(isinstance(json_tokenizer._value, Token))
    json_token = json_tokenizer._value
    assert(isinstance(json_token, DictToken))
    test_token = json_token._value["test"]
    assert(isinstance(test_token, DictToken))
    list_token = test_token._value["list"]
    assert(isinstance(list_token, ListToken))


# Generated at 2022-06-24 11:30:58.565716
# Unit test for constructor of class DictToken
def test_DictToken():
    a = Token(1, 2, 3)
    b = Token(2, 2, 3)
    d = {a: b}
    dict_token = DictToken(d, 2, 3)
    assert dict_token._get_value() == {1: 2}
    assert dict_token._get_child_token(1) == b
    assert dict_token._get_key_token(1) == a


# Generated at 2022-06-24 11:31:02.917089
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken('value', 1, 2)
    assert token.string == 'value'
    assert token.value == 'value'
    assert token.start.line_no == 1
    assert token.start.column_no == 1
    assert token.start.byte_no == 1
    assert token.end.line_no == 1
    assert token.end.column_no == 2
    assert token.end.byte_no == 2


# Generated at 2022-06-24 11:31:09.641492
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # Arrange
    token_1 = ScalarToken('foo', 0, 2, 'foo')
    token_2 = ScalarToken('foo', 0, 2, 'foo')
    token_3 = ScalarToken('bar', 0, 2, 'bar')
    token_4 = ScalarToken('bar', 0, 2, 'foo')

    # Act
    hash_1 = token_1.__hash__()
    hash_2 = token_2.__hash__()
    hash_3 = token_3.__hash__()
    hash_4 = token_4.__hash__()

    # Assert
    assert hash_1 == hash_2
    assert hash_2 != hash_3
    assert hash_3 != hash_4


# Generated at 2022-06-24 11:31:13.523568
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    assert ScalarToken("Hello", 0, 5, "'Hello'")


# Generated at 2022-06-24 11:31:18.740192
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class ListToken(Token):
        def _get_child_token(self, key: typing.Any) -> Token:
            return self._value[key]
    token = ListToken([[1, 2]], 0, 1)
    token = token.lookup_key([0])
    assert token._start_index == 1
    assert token._end_index == 2

# Generated at 2022-06-24 11:31:24.081914
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    t = DictToken({
        ScalarToken('a',1,1): ScalarToken('b',1,1),
        ScalarToken('c',1,1): ScalarToken('d',1,1)
        },0,0,'')
    tl = t.lookup_key([1])
    assert tl == ScalarToken('c',1,1)


# Generated at 2022-06-24 11:31:26.131386
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    o = Token(value=1, start_index=2, end_index=3, content="sample_content")
    assert repr(o) == "Token('ple_conte')"



# Generated at 2022-06-24 11:31:32.764394
# Unit test for constructor of class DictToken
def test_DictToken():
    obj = DictToken(1,1,1,content="content")
    assert isinstance(obj, DictToken)
    assert obj.start is None
    assert obj.end is None
    assert obj.lookup(1) is None
    assert obj.lookup_key(1) is None