

# Generated at 2022-06-24 11:21:30.167005
# Unit test for constructor of class Token
def test_Token():
    token = Token(1, 2, 3, 4)
    assert token._value == 1
    assert token._start_index == 2
    assert token._end_index == 3
    assert token._content == 4
    assert token.string == ''
    assert token.start == None
    assert token.end == None
    try:
        token.value
    except NotImplementedError as e:
        assert str(e) == '_get_value'


# Generated at 2022-06-24 11:21:30.996989
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert ScalarToken(1, 0, 0).__hash__() == hash(1)


# Generated at 2022-06-24 11:21:32.848848
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    json_token = DictToken({}, 0, 0)
    string_token = ScalarToken("", 0, 0)
    json_token_2 = DictToken({}, 0, 0)
       
    assert json_token != string_token #__ne__
    assert json_token == json_token_2 #__eq__

# Generated at 2022-06-24 11:21:36.855171
# Unit test for method lookup of class Token
def test_Token_lookup():
    token=ListToken(['1','2','3'],0, 2)
    assert token.lookup([1]).string == '2'
    token=DictToken({'a':'b','c':'d'},0, 3)
    assert token.lookup([0]).string == 'b'


# Generated at 2022-06-24 11:21:46.410552
# Unit test for constructor of class Token
def test_Token():
    from typesystem.base import String
    from typesystem.base import Integer
    from typesystem.base import Float
    from typesystem.base import Boolean
    from typesystem.base import Array
    from typesystem.base import Object
    from test_schema import test_schema
    from token import Token

    # Test ScalarToken
    str_type = String()
    int_type = Integer()
    float_type = Float()
    bool_type = Boolean()

    # String
    token = Token(
        String, 10, 17, content=test_schema
    )
    current_token = ScalarToken(String, 10, 17, test_schema)
    assert token == current_token
    assert token.string == 'String'
    assert token.value == String
    assert token.start == Position(1, 9, 10)

# Generated at 2022-06-24 11:21:49.443715
# Unit test for constructor of class Token
def test_Token():
    token = Token(1, 1, 2, "")
    assert(token._value == 1)
    assert(token._start_index == 1)
    assert(token._end_index == 2)
    assert(token._content == "")


# Generated at 2022-06-24 11:21:51.171312
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(None, 0, 0)
    result = hash(token)
    assert result is None

# Generated at 2022-06-24 11:21:57.308844
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    index = []
    start_index = 10
    end_index = 0
    value = None
    content = None
    T = Token(value, start_index, end_index, content)
    assert T.__repr__() == "Token(None)"
    assert T
    assert not T

    index = []
    start_index = 10
    end_index = 0
    value = 10
    content = None
    T = ScalarToken(value, start_index, end_index, content)
    assert T.__repr__() == "ScalarToken('10')"

    index = []
    start_index = 10
    end_index = 0
    value = 10
    content = None
    T = ListToken(value, start_index, end_index, content)

# Generated at 2022-06-24 11:22:01.526327
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    sc = ScalarToken(1,1,1)
    assert sc.lookup([])
    assert sc.lookup_key([1])
    assert sc.start
    assert sc.end
    assert sc == ScalarToken(1,1,1)
    assert sc != ScalarToken(2,1,1)
    assert sc._get_value() == 1


# Generated at 2022-06-24 11:22:11.703669
# Unit test for method lookup of class Token

# Generated at 2022-06-24 11:22:19.063178
# Unit test for method lookup of class Token
def test_Token_lookup():
    # import typesystem
    # import unittest
    from typesystem.lexer import LiteralToken, Token

    class TokenTest(unittest.TestCase):
        def test_lookup_ScalarToken(self):
            token = Token(value="some_value", start_index=1, end_index=10)
            self.assertEqual(repr(token.lookup([0])), repr(token))

        def test_lookup_ListToken_of_ScalarTokens(self):
            list_token = ListToken(
                value=[ScalarToken(value=0, start_index=1, end_index=1)],
                start_index=0,
                end_index=1,
                content="[0]",
            )

# Generated at 2022-06-24 11:22:29.617635
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    content = '{"a": 1, "b": 2, "c": 3}'
    value = json.loads(content)
    # 0. for a dictionary
    token = DictToken(value, 0, len(content) - 1, content)
    assert token._get_position(0) == Position(1, 1, 0)
    assert token._get_position(4) == Position(1, 5, 4)
    key = token._get_key_token("a")
    assert key._value == 1
    assert key._start_index == 2
    assert key._end_index == 3
    assert key.start == Position(1, 3, 2)
    assert key.end == Position(1, 4, 3)
    assert token.lookup_key([0]) == key
    assert token.lookup_key([1]) != key

# Generated at 2022-06-24 11:22:36.354769
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken('literal', 1, 2, 'string')
    assert token.string == 'literal'
    assert token.value == 'literal'
    assert token.start.line == 1
    assert token.start.column == 0
    assert token.start.offset == 0
    assert token.end.line == 1
    assert token.end.column == 7
    assert token.end.offset == 7
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token

# Generated at 2022-06-24 11:22:40.367484
# Unit test for constructor of class ListToken
def test_ListToken():
    # Setup
    value = [1,2,3]
    start_index = 0
    end_index = 4
    content = "1,2,3"
    results = ListToken(value, start_index, end_index, content)

    # Test
    assert results._value == value
    assert results._start_index == start_index
    assert results._end_index == end_index
    assert results._content == content

# Generated at 2022-06-24 11:22:48.729762
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import ScalarToken, DictToken, Position

    args = (1, 2, 3, "abc")
    kwargs = {}

    # Create a token
    token = DictToken(*args, **kwargs)

    # Check token is created properly
    assert token._value == 1
    assert token._start_index == 2
    assert token._end_index == 3
    assert token._content == "abc"

    value = token.value

    # Check value is returned properly
    assert value == 1

    start = token.start

    # Check start is returned properly
    assert start == Position(1, 1, 2)

    end = token.end

    # Check end is returned properly
    assert end == Position(1, 1, 3)

    # Test lookup

# Generated at 2022-06-24 11:22:55.735888
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for Class Token
    foo_token = Token(None,0,0)
    bar_token = Token(None,0,0)
    assert foo_token == bar_token
    assert foo_token is not bar_token


# Generated at 2022-06-24 11:22:57.058943
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken([1, 2, 3])


# Generated at 2022-06-24 11:23:06.877071
# Unit test for method lookup of class Token
def test_Token_lookup():
    t1 = DictToken(
            {
                "a": ScalarToken(1, 1, 1),
                "b": DictToken({"c": ScalarToken(2, 1, 1)}),
            },
            1,
            2
    )
    assert(t1.value == {'a': 1, 'b': {'c': 2}})
    assert(t1.lookup([0]) == ScalarToken(1, 1, 1))
    assert(t1.lookup([0, 0]) == ScalarToken(2, 1, 1))
    assert(t1.lookup_key([0, 0]) == ScalarToken('c', 0, 0))

# Generated at 2022-06-24 11:23:15.624545
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = Token(["a", "b"], 1, 3, content = "")
    assert token._get_child_token(0) == ["a", "b"]
    assert token._get_child_token(1) == ["a", "b"]
    assert token._get_key_token(0) == ["a", "b"]
    assert token._get_key_token(1) == ["a", "b"]
    assert token.value == ["a", "b"]
    assert token.lookup([0]) == ["a", "b"]
    assert token.lookup([1]) == ["a", "b"]
    assert token.lookup_key([0, 0]) == ["a", "b"]
    assert token.lookup_key([1, 0]) == ["a", "b"]

# Generated at 2022-06-24 11:23:17.443506
# Unit test for constructor of class DictToken
def test_DictToken():
    props = {
        'likes': 'horses'
    }

    # Create it, no need to do anything else
    DictToken(props, 1, 20)


# Unit test constructor of class ListToken

# Generated at 2022-06-24 11:23:24.476132
# Unit test for method lookup of class Token
def test_Token_lookup():
    class DictToken(Token):
        def _get_child_token(self, key: typing.Any) -> Token:
            dic = {
                'one' : 1,
                'two' : 2,
                'three' : 3,
                'four' : 4,
                'five' : 5,
            }
            print(dic)
            return dic[key]

    token = DictToken(1,1,1,'')
    assert token.lookup('one') == 1
    assert token.lookup('two') == 2
    assert token.lookup('three') == 3
    assert token.lookup('four') == 4
    assert token.lookup('five') == 5


# Generated at 2022-06-24 11:23:28.736482
# Unit test for constructor of class ListToken
def test_ListToken():
    TestListToken = ListToken('[', 0, 1, '[')
    assert TestListToken._value == '['
    assert TestListToken._start_index == 0
    assert TestListToken._end_index == 1
    assert TestListToken._content == '['



# Generated at 2022-06-24 11:23:29.448113
# Unit test for constructor of class DictToken
def test_DictToken():
    print("test_DictToken")


# Generated at 2022-06-24 11:23:33.612594
# Unit test for constructor of class Token
def test_Token():
    t = Token(3, 5, 10)
    assert t._value == 3
    assert t._start_index == 5
    assert t._end_index == 10
    assert t._content == ""


# Generated at 2022-06-24 11:23:37.036427
# Unit test for constructor of class ListToken
def test_ListToken():
    l = ListToken(value=[], start_index=0, end_index=5)
    assert l._get_value() == []
    assert l.start == Position(1, 1, 0)
    assert l.end == Position(1, 6, 5)

# Generated at 2022-06-24 11:23:44.949028
# Unit test for constructor of class ListToken
def test_ListToken():
    expected_value = ['x', 'y', 'z']
    expected_start_index = 1
    expected_end_index = 10
    expected_content = '["x", "y", "z"]'
    token = ListToken(expected_value, expected_start_index, expected_end_index, expected_content)
    assert type(token) == ListToken
    assert token._get_value() == expected_value
    assert token._start_index == expected_start_index
    assert token._end_index == expected_end_index
    assert token._content == expected_content
    assert token.string == expected_value
    assert token.value == expected_value
    assert token.start == Position(1, 1, 1)
    assert token.end == Position(1, 1, 10)
    assert token.lookup([0]) == token

# Generated at 2022-06-24 11:23:53.972242
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    from .parser import parse_path
    parser = Parser()
    result = parse_path("/a/b/c", parser=parser)

# Generated at 2022-06-24 11:23:56.318206
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    assert Token.lookup_key('aaa', [1, 2, 'bbb']) == 'aaa'

# Generated at 2022-06-24 11:24:04.815750
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken(["a", "b", "c"], 0, 20)
    assert token.string == ""
    assert token.value == ["a", "b", "c"]
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 20)
    assert token.lookup([0]).string == ""
    assert token.lookup([0]).value == "a"
    assert token.lookup([2]).string == ""
    assert token.lookup([2]).value == "c"
    assert token.lookup_key([0, 0]) is None
    assert token.lookup_key([0, 1]) is None
    assert token.lookup_key([2, 0]) is None
    assert token.lookup_key([2, 1]) is None
    assert token._get

# Generated at 2022-06-24 11:24:12.891451
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test the equality of two different token instances that have the same value
    token1 = ScalarToken('value', 0, 5, 'value\n')
    token2 = ScalarToken('value', 0, 5, 'value\n')
    assert token1 == token2

    # Test the equality of two different token instances that have different values
    token1 = ScalarToken('value', 0, 5, 'value\n')
    token2 = ScalarToken('value2', 0, 5, 'value\n')
    assert not token1 == token2

    # Test the equality of two different token instances that have the same value with different start indices
    token1 = ScalarToken('value', 0, 5, 'value\n')
    token2 = ScalarToken('value', 1, 5, 'value\n')
    assert not token1 == token2

   

# Generated at 2022-06-24 11:24:15.572661
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, 0, 0)
    assert token == token
    fake_token = object()
    assert not (token == fake_token)


# Generated at 2022-06-24 11:24:24.187744
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    from json import dumps
    from jsontokens.parser import parse
    from jsontokens.parser.tokens import ScalarToken, DictToken, ListToken
    from jsontokens.parser.tokens import Position
    import json
    import os, sys
    import types_system
    # 
    path_this_file = os.path.abspath(__file__)
    path_this_dir = os.path.dirname(path_this_file)
    path_dir_up1 = os.path.dirname(path_this_dir)
    path_dir_up2 = os.path.dirname(path_dir_up1)
    pkg_root_dir = os.path.dirname(path_dir_up2)

# Generated at 2022-06-24 11:24:32.247925
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # This is a non-regression test for https://github.com/samuelcolvin/pytypesystem/issues/15
    assert repr(Token('abc',0,2,content='abc')) == 'Token(\'abc\')'
    assert repr(Token('abc',0,1,content='abc')) == 'Token(\'ab\')'
    # This is a non-regression test for https://github.com/samuelcolvin/pytypesystem/issues/11
    assert repr(Token('abc',1,1,content='abc')) == 'Token(\'\')'

# Generated at 2022-06-24 11:24:41.770430
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():		
    import ast
    
    class UnitTestToken(Token):
        def __init__(self, value: typing.Any, start_index: int, end_index: int, content: str = ""):
            Token.__init__(self, value, start_index, end_index, content)
        def _get_value(self) -> typing.Any:
            return self._value
        def _get_child_token(self, key: typing.Any) -> Token:
            return self._value
        def _get_key_token(self, key: typing.Any) -> Token:
            return Token(key, 1, 1)

    node = ast.parse('def test(x): return x + x')
    node_token = UnitTestToken(node, 1, 1)


# Generated at 2022-06-24 11:24:48.744634
# Unit test for constructor of class ListToken
def test_ListToken():
    my_ListToken = ListToken('value',0,1)
    assert isinstance(my_ListToken,ListToken)
    assert hasattr(my_ListToken,'_value')
    assert hasattr(my_ListToken,'_start_index')
    assert hasattr(my_ListToken,'_end_index')
    assert hasattr(my_ListToken,'_content')
    assert hasattr(my_ListToken,'string')
    assert hasattr(my_ListToken,'value')
    assert hasattr(my_ListToken,'start')
    assert hasattr(my_ListToken,'end')
    assert hasattr(my_ListToken,'lookup')
    assert hasattr(my_ListToken,'lookup_key')
    assert hasattr(my_ListToken,'_get_position')

# Generated at 2022-06-24 11:24:50.904398
# Unit test for constructor of class ListToken
def test_ListToken():
    a = [1,2,3]

    b = ListToken(a, 1, 2)


# Generated at 2022-06-24 11:24:55.702604
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    value="a"
    start_index=1
    end_index=2
    content="ab"
    assert ScalarToken(value,start_index,end_index,content)


# Generated at 2022-06-24 11:24:58.058077
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    assert ScalarToken(0,0,0,0) == ScalarToken(0,0,0,0)


# Generated at 2022-06-24 11:25:03.253154
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    t1 = ScalarToken(value=["a"], start_index=0, end_index=1)
    assert t1._value == ["a"]
    assert t1._start_index == 0
    assert t1._end_index == 1
    assert t1._content == "" 
    assert t1._get_value() == ["a"]
    assert t1.string == "a"
    


# Generated at 2022-06-24 11:25:15.700854
# Unit test for constructor of class ListToken
def test_ListToken():
    from unittest.mock import call
    with mock.patch('quark.token.Token.__init__') as mock_super:
        instance = ListToken('arg_value', 'arg_start_index', 'arg_end_index')
        # Check for calls of __init__ of parent class
        assert mock_super.call_args_list == [
            call('arg_value', 'arg_start_index', 'arg_end_index')
        ]
        # Check instance attributes
        assert instance._value == 'arg_value'
        assert instance._start_index == 'arg_start_index'
        assert instance._end_index == 'arg_end_index'
        assert instance._content == ''



# Generated at 2022-06-24 11:25:18.120053
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    try:
        assert ScalarToken(1,1,1)
    except:
        print("\nError while initializing ScalarToken")


# Generated at 2022-06-24 11:25:24.218060
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Implementation of the test
    object1 = Token(0,0,0)
    # object1 = <class '__main__.Token'>(0)
    object2 = Token(1,1,1)
    # object2 = <class '__main__.Token'>(1)
    result1 = object1 == object2
    # result1 = False
    assert result1 == False

    object3 = Token(1,1,1)
    # object3 = <class '__main__.Token'>(1)
    result2 = object2 == object3
    # result2 = True
    assert result2 == True


# Generated at 2022-06-24 11:25:34.488863
# Unit test for method __eq__ of class Token

# Generated at 2022-06-24 11:25:41.233321
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    tok = ScalarToken('tok', 0, 1)
    assert tok.string == 'tok'
    assert tok.value == 'tok'
    assert tok == ScalarToken('tok', 0, 1)
    assert tok != ScalarToken('tok', 0, 2)
    assert tok != ScalarToken('tok', 0, 2)
    assert tok != ScalarToken('tok', 0, 1, 'something')
    assert tok != 123

# Test if equal to ScalarToken

# Generated at 2022-06-24 11:25:45.402066
# Unit test for constructor of class Token
def test_Token():
    _token = Token('value', 2, 4)
    assert _token._value == 'value'
    assert _token._start_index == 2
    assert _token._end_index == 4
    assert _token._content == ''


# Generated at 2022-06-24 11:25:46.372855
# Unit test for constructor of class Token
def test_Token():
  assert Token(1,1,1, "test")

# Generated at 2022-06-24 11:25:48.157473
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1}, 0, 1, "something")


# Generated at 2022-06-24 11:25:57.054218
# Unit test for constructor of class DictToken
def test_DictToken():
    def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
        super().__init__(*args, **kwargs)
        self._child_keys = {k._value: k for k in self._value.keys()}
        self._child_tokens = {k._value: v for k, v in self._value.items()}
if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 11:26:05.544570
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = ListToken([], 0, 0)
    try:
        token.lookup([])
        assert 0
    except:
        pass
    try:
        token.lookup([1])
        assert 0
    except:
        pass
    try:
        token.lookup([1, 1])
        assert 0
    except:
        pass
    try:
        token.lookup([1.0])
        assert 0
    except:
        pass
    try:
        token.lookup([1.0, 1.0])
        assert 0
    except:
        pass
    try:
        token.lookup([None])
        assert 0
    except:
        pass
    try:
        token.lookup([None, None])
        assert 0
    except:
        pass


# Generated at 2022-06-24 11:26:09.314465
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(1, 0, 1, "hello")
    assert token.value == 1
    assert token.string == "hello"
    return



# Generated at 2022-06-24 11:26:15.879093
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("",0,0)
    assert token._value == ""
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""
    

# Generated at 2022-06-24 11:26:25.454187
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class TestToken(Token):

        def _get_value(self) -> typing.Any:
            return self._value

        def _get_child_token(self, key: typing.Any) -> Token:
            return self._value[key]

        def _get_key_token(self, key: typing.Any) -> Token:
            return self._child_keys[key]


# Generated at 2022-06-24 11:26:27.585905
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # TODO: rewrite comment when the implementation is completed.
    # When the implementation is completed, the tests will be rewritten.
    pass


# Generated at 2022-06-24 11:26:28.958139
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    # TODO: Add code for unit test here.
    pass



# Generated at 2022-06-24 11:26:42.649914
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    ScalarToken(1, 0, 1).__hash__()
    ScalarToken(1, 0, 2).__hash__()
    ScalarToken(1.0, 0, 1).__hash__()
    ScalarToken(1.0, 0, 2).__hash__()
    ScalarToken('a', 0, 1).__hash__()
    ScalarToken('a', 0, 2).__hash__()
    ScalarToken(True, 0, 1).__hash__()
    ScalarToken(True, 0, 2).__hash__()
    ScalarToken(False, 0, 1).__hash__()
    ScalarToken(False, 0, 2).__hash__()
    ScalarToken(None, 0, 1).__hash__()
    ScalarToken(None, 0, 2).__hash__()
# Coverage test

# Generated at 2022-06-24 11:26:45.245483
# Unit test for constructor of class Token
def test_Token():
    t = Token(3, 4, 5, 6)
    assert t
    assert t.value == 3
    assert t.start == 4
    assert t.end == 5
    assert t.string == 6


# Generated at 2022-06-24 11:26:50.680669
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token(None, None, None, "")
    if str(token) == "<class 'type_system.token.Token'>(None)":
        return True
    else:
        return False

test_Token___repr__()

# Generated at 2022-06-24 11:26:53.973257
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    #arrange
    test_token = ScalarToken("test_value", 1, 10)
    expected = hash("test_value")

    #act
    actual = test_token.__hash__()

    #assert
    assert actual == expected

# Generated at 2022-06-24 11:27:04.597267
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class ScalarToken_test(ScalarToken):
        def _get_value(self) -> typing.Any:
            return self._content[self._start_index : self._end_index + 1]
    class DictToken_test(DictToken):
        def _get_value(self) -> typing.Any:
            return {
                key_token._get_value(): value_token._get_value()
                for key_token, value_token in self._value.items()
            }
    class ListToken_test(ListToken):
        def _get_value(self) -> typing.Any:
            return [token._get_value() for token in self._value]

    t0 = ScalarToken_test("b", 1, 2, "abc")

# Generated at 2022-06-24 11:27:08.611549
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    from typesystem.base import Context

    from .grammar import parse

    tokens = parse("null", context=Context())
    assert "<NullToken(null)>" == repr(tokens[0])

# Generated at 2022-06-24 11:27:17.559694
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    src = "abcd"
    x = ScalarToken(3, 1, 2, src)
    y = ScalarToken(3, 1, 2, src)
    z = ScalarToken(5, 1, 2, src)
    assert x == x
    assert y == y
    assert not (x == y)
    assert not (y == x)
    assert not (x == z)
    assert not (z == x)
    assert not (y == z)
    assert not (z == y)

# Generated at 2022-06-24 11:27:19.941241
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    from typesystem import String
    from typesystem.compat import str

    token_cls = ScalarToken

    assert hash(token_cls(String(), 0, 5, content="hello")) == hash(str("hello"))

# Generated at 2022-06-24 11:27:22.393526
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken(value = 'test', start_index = 0, end_index = 3, content = '')



# Generated at 2022-06-24 11:27:26.156875
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    dict_token = dict(a=1, b=2)
    dt = DictToken(value=dict_token, start_index=0, end_index=0)
    assert dt.lookup_key([1]) == dict_token[1]

# Generated at 2022-06-24 11:27:33.065153
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class CustomToken(Token):
        def _get_value(self):
            return self.string
        
        def _get_child_token(self, key):
            return self

    token = CustomToken("test_test", 0, 9, "test_test")
    assert token.lookup_key([0]) == token
    assert token.lookup_key([0, 0]) == token
    assert token.lookup_key([0, 0, 0]) == token
    assert token.lookup_key([0, 0, 0, 0]) == token
    assert token.lookup_key([0, 0, 0, 0, 0]) == token

# Generated at 2022-06-24 11:27:38.416383
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_1 = ScalarToken('a', 0, 1, content='Test String')
    token_2 = ScalarToken('a', 0, 1, content='Test String')
    assert token_1 == token_2
    assert token_1 != 'a'
    assert token_2 != 'a'
    assert token_1 != token_2.string
    assert token_2 != token_1.string

# Generated at 2022-06-24 11:27:49.325878
# Unit test for method lookup of class Token
def test_Token_lookup():
    class TestToken(Token):
        def _get_value(self) -> typing.Any:
            return self.value

        def _get_child_token(self, key: typing.Any) -> Token:
            return self.child_token

        def _get_key_token(self, key: typing.Any) -> Token:
            return self.key_token

    index = [1, 2]
    index_key  = [1, 'key']
    token = TestToken(
        value= 'value',
        start_index = 0,
        end_index = 5,
        content = 'content'
    )
    assert token.lookup(index) == token.child_token
    assert token.lookup_key(index_key) == token.key_token

# Generated at 2022-06-24 11:27:51.791550
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    instance = ScalarToken(None, None, None, "_content")
    expected = hash(None)
    assert(instance.__hash__() == expected)
    return True


# Generated at 2022-06-24 11:27:55.091027
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    '''
    Test for method lookup_key of class Token
    '''
    index = []
    token = Token(index, 0,0)
    token.lookup_key(index)





# Generated at 2022-06-24 11:28:05.662993
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.integer import Integer
    from typesystem.string import String

    assert (
        DictToken({"a": Integer.parse("4")}, start_index=0, end_index=6)
        == DictToken({"a": Integer.parse("4")}, start_index=0, end_index=6)
    )

    assert (
        DictToken({"a": Integer.parse("4")}, start_index=0, end_index=6)
        != DictToken({"a": Integer.parse("5")}, start_index=0, end_index=6)
    )


# Generated at 2022-06-24 11:28:17.053032
# Unit test for method lookup of class Token
def test_Token_lookup():
    lt = ListToken([ScalarToken("a",0,1), ScalarToken("b",0,1)], 0, 1, "ab")
    assert lt.lookup([0])._value == "a"
    assert lt.lookup([1])._value == "b"

    dt = DictToken({ScalarToken("a",0,1): ScalarToken("a",0,1),
                    ScalarToken("b",0,1): ScalarToken("b",0,1)},
                   0, 1, "ab")
    assert dt.lookup(["a"])._value == "a"
    assert dt.lookup(["b"])._value == "b"



# Generated at 2022-06-24 11:28:20.461074
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    """
    Unit test for method lookup_key of class Token
    """
    token = ScalarToken("/run/user/1001/gvfs/")
    assert token == token.lookup_key([0])



# Generated at 2022-06-24 11:28:22.735423
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(1,2,3)
    assert hash(token) == 1


# Generated at 2022-06-24 11:28:32.855359
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():

    t_scalar = ScalarToken(None, 0, 0)
    t_dict = DictToken({}, 0, 0)
    t_list = ListToken([], 0, 0)

    assert t_scalar.lookup_key([]).string == ''
    assert t_scalar.lookup_key([0]).string == ''
    assert t_scalar.lookup_key([0,0]).string == ''

    assert t_dict.lookup_key([]).string == ''
    assert t_dict.lookup_key([0]).string == ''

    assert t_list.lookup_key([]).string == ''
    assert t_list.lookup_key([0]).string == ''
    assert t_list.lookup_key([0,0]).string == ''

    t_dict = D

# Generated at 2022-06-24 11:28:38.643482
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({'d': '22'}, 0, 5, '{"d": 22}')
    assert a._value == {'d': '22'}, 'tokenizer.py DictToken _value error'
    assert a._content == '{"d": 22}', 'tokenizer.py DictToken _content error'
    assert a._child_keys == {'d': 'd'}, "tokenizer.py DictToken _child_keys error"
    assert (
        a._child_tokens == {'d': '22'}, "tokenizer.py DictToken _child_tokens error"
    )



# Generated at 2022-06-24 11:28:47.681562
# Unit test for method lookup of class Token
def test_Token_lookup():
    line_no = 2
    column_no = 2
    token1 = ScalarToken('hello', 2, 3, """
    hello xxx
    """)
    token2 = ListToken([token1], 2, 3, """
    hello xxx
    """)
    token3 = ListToken([token1, token2], 2, 3, """
    hello xxx
    """)

    assert token1.lookup([]) == token1
    assert token2.lookup([0]) == token1
    assert token3.lookup([1, 0]) == token1
    assert token1.end.line_no == line_no
    assert token1.end.column_no == column_no



# Generated at 2022-06-24 11:28:52.690818
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # 1. Setup
    # 1.1. Set up intial instance of Token class
    some_string = '{"key1":1,"key3":3}'
    some_start_index = 0
    some_end_index = len(some_string)-1
    some_content = some_string
    token = DictToken(ast.literal_eval(some_string), some_start_index, some_end_index, content=some_content)

    # 1.2. Set up a dictionary of expected results
    expected_dict = {"key1":0, "key3":1}

    # 2. Exercise
    for expected_key, expected_value in expected_dict.items():
        # 2.1. Exercise SUT
        actual_token = token.lookup_key([expected_key])

        # 2.2. Verify

# Generated at 2022-06-24 11:28:59.283290
# Unit test for constructor of class DictToken
def test_DictToken():
    value = {1: 2}
    start_index = 2
    end_index = 4
    content = "abc"
    assert DictToken(value, start_index, end_index, content)._child_tokens == {1: 2}
    assert DictToken(value, start_index, end_index, content)._child_keys == {1: 1}
    assert DictToken(value, start_index, end_index, content).start_index == 2
    assert DictToken(value, start_index, end_index, content).end_index == 4
    assert DictToken(value, start_index, end_index, content).content == "abc"
    

# Generated at 2022-06-24 11:29:03.416024
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    value = 'one'
    start_index = 0
    end_index = 3
    content = 'one-two-three'
    token = Token(value, start_index, end_index, content)

    assert repr(token) == "Token('one')"

test_Token___repr__()



# Generated at 2022-06-24 11:29:04.637725
# Unit test for constructor of class Token
def test_Token():
    token = Token(1, 0, 0)
    assert token


# Generated at 2022-06-24 11:29:07.504575
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(1, 2, content="test")
    assert token.string == "test"
    assert token._start_index == 0
    assert token._end_index == 3
    assert token._value == 1


# Generated at 2022-06-24 11:29:09.527802
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    t = ScalarToken(['scalar'], 345, 355, content = "scalar")
    assert hash(t) == hash(['scalar'])


# Generated at 2022-06-24 11:29:11.580464
# Unit test for constructor of class ListToken
def test_ListToken():
    value = ["a", "b", "c"]
    start_index = 0
    end_index = 3
    content = "abc"
    t = ListToken(value, start_index, end_index, content)

# Generated at 2022-06-24 11:29:20.315117
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class TokenStub(Token):
        def __init__(self, value: typing.Any, start_index: int, end_index: int, content: str = "") -> None:
            self._value = value
            self._start_index = start_index
            self._end_index = end_index
            self._content = content
        def _get_value(self) -> typing.Any:
            raise NotImplementedError  # pragma: nocover
        def _get_child_token(self, key: typing.Any) -> "Token":
            raise NotImplementedError  # pragma: nocover
        def _get_key_token(self, key: typing.Any) -> "Token":
            raise NotImplementedError  # pragma: nocover
        

# Generated at 2022-06-24 11:29:30.564892
# Unit test for constructor of class DictToken
def test_DictToken():
    #content = '{"a": ["b", 1]}'
    #key_tokens = [1, 2]
    #value_tokens = [3, 4]
    #content = '{"a": ["b", 1]}'
    #key_tokens = [1, 2]
    #value_tokens = [3, 4]
    key_tokens = {1: 2, 3: 4}
    value_tokens = {1: 3, 3: 5}

    x = DictToken(key_tokens, 1, 2, value_tokens)
    assert x._value == key_tokens
    assert x._start_index == 1
    assert x._end_index == 2
    assert x._content == value_tokens

# Generated at 2022-06-24 11:29:34.217293
# Unit test for constructor of class DictToken
def test_DictToken():
    #test_1
    DictToken(value = {"a":1,"b":2,"c":3}, start_index=0, end_index=2, content="abc")

    #test_2
    DictToken(value = {"a":1,"b":2,"c":3}, start_index=0, end_index=2, content="abc")


# Generated at 2022-06-24 11:29:37.335969
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = Token(1,0,0)
    with pytest.raises(NotImplementedError):
        token.lookup_key(1)

# Generated at 2022-06-24 11:29:38.659575
# Unit test for constructor of class Token
def test_Token():
    assert Token(1, 2, 3, 4)


# Generated at 2022-06-24 11:29:41.301224
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 1, 1)
    token2 = Token(1, 1, 1)
    token3 = Token(3, 1, 3)
    assert token1.__eq__(token2)
    assert not token1.__eq__(token3)

# Generated at 2022-06-24 11:29:50.741721
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from typesystem.exceptions import TokenLookupError
    from typesystem.types import String, Integer, List, Dictionary
    from typesystem.schemas import Schema
    from typesystem.positions import Position

    class Dict(Dictionary):
        foo = Integer
        bar = List(String)

    class Schema(Schema):
        data = Dict

    content = """{
        "data": {
            "foo": 100,
            "bar": ["abc", "def", "ghi"]
        }
    }"""

    schema = Schema()
    tokens = schema.tokenize(content)
    token = tokens.lookup(["data", "bar", 1])

    assert token.string == '"def"'
    assert token.value == "def"
    assert token.start == Position(4, 20, 42)


# Generated at 2022-06-24 11:30:02.692075
# Unit test for constructor of class ListToken
def test_ListToken():
    class FakeToken:
        def __init__(self, value, start_index, end_index, content=''):
            self._value = value
            self._start_index = start_index
            self._end_index = end_index
            self._content = content

    fake_token_1 = FakeToken(1, 1, 2)
    fake_token_2 = FakeToken(2, 1, 3)
    fake_token_list = [fake_token_1, fake_token_2]
    fake_list_token = ListToken(fake_token_list, 1, 4, '123')
    assert fake_list_token._value == fake_token_list
    assert fake_list_token._start_index == 1
    assert fake_list_token._end_index == 4

# Generated at 2022-06-24 11:30:07.219298
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value = None, start_index = 0, end_index = 0)
    assert token.__eq__(token) == True

    assert token.__eq__(None) == False

    assert token.__eq__(0) == False

# Generated at 2022-06-24 11:30:15.130543
# Unit test for method lookup of class Token
def test_Token_lookup():
    # setup
    dic1 = dict()
    dic1['a'] = 1
    dic2 = dict()
    dic2['b'] = 2
    list1 = list()
    list1.append(dic1)
    list1.append(dic2)
    dic3 = dict()
    dic3['c'] = list1
    # test
    token1 = DictToken(dic1, 0, 0)
    token2 = DictToken(dic2, 0, 0)
    token3 = ListToken(list1, 0, 0)
    token4 = DictToken(dic3, 0, 0)
    assert lookup(token1) == dic1
    assert lookup(token2) == dic2
    assert lookup(token3) == list1

# Generated at 2022-06-24 11:30:22.092350
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(value="hello", start_index=0, end_index=4, content="hello")
    assert token.string == "hello"
    assert token.value == "hello"
    assert token.start == Position(line_no=1, column_no=1, byte_index=0)
    assert token.end == Position(line_no=1, column_no=1, byte_index=4)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token


# Generated at 2022-06-24 11:30:26.181729
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    class_ = ScalarToken
    scalar_token = class_(2, 0, 5)
    assert hash(scalar_token) is not None



# Generated at 2022-06-24 11:30:34.963099
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # test that lookup_key works for scalar token
    scalar_token = ScalarToken(123, 10, 13)
    assert scalar_token.lookup_key([0, 1, 2]) == scalar_token

    # test that lookup_key works for dict token
    dict_token = DictToken({
        ScalarToken(1, 10, 11): ScalarToken(2, 12, 13),
        ScalarToken(3, 14, 15): ScalarToken(4, 16, 17)
    }, 0, 17)
    assert dict_token.lookup_key([0, 1]) == ScalarToken(3, 14, 15)

    # test that lookup_key works for list token

# Generated at 2022-06-24 11:30:44.631828
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t = Token(value=None, start_index=None, end_index=None)
    assert t.__eq__(None) == False

    t = Token(value="Hello", start_index=1, end_index=5)
    assert t.__eq__("Hello") == False
    assert t.__eq__(Token(value="Hello", start_index=1, end_index=5)) == True
    assert t.__eq__(Token(value="World", start_index=1, end_index=5)) == False
    assert t.__eq__(Token(value="Hello", start_index=0, end_index=5)) == False
    assert t.__eq__(Token(value="Hello", start_index=1, end_index=4)) == False


# Generated at 2022-06-24 11:30:46.746084
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    val = ScalarToken(1, 3, 4)
    asser

# Generated at 2022-06-24 11:30:53.430302
# Unit test for constructor of class DictToken
def test_DictToken():
    x = {}
    x = {x:x}
    x = {(x,x):x}
    x = {(x,x):(x,x)}


# Generated at 2022-06-24 11:31:01.115629
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    import json
    json_str = '{"users": [{"name": "vshn", "groups": ["ops", "dev"]}, {"name": "foo", "groups": ["admin"]}]}'
    ast = json.loads(json_str, object_pairs_hook=DictToken)
    assert isinstance(ast, DictToken)
    groups_key = ast.lookup_key([0, 1])
    assert groups_key.string == "groups"
    users = ast.lookup([0])
    assert isinstance(users, ListToken)
    assert isinstance(groups_key, ScalarToken)

# Generated at 2022-06-24 11:31:04.411252
# Unit test for constructor of class ListToken
def test_ListToken():
    lst = ListToken([1,2,3], 0, 4)
    assert lst._get_value() == [1,2,3]

# Unit test to check value of token returned by _get_child_token()

# Generated at 2022-06-24 11:31:09.149937
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("value", 0, 1, "")
    assert isinstance(token, Token)
    assert token.string == ""
    assert token.value == "value"
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 1)
    with pytest.raises(TypeError):
        token.lookup([])



# Generated at 2022-06-24 11:31:12.596652
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token1 = Token()
    token1._content = "hello world"
    token1._start_index = 6
    token1._end_index = 10

    assert token1.lookup_key(['world']) == token1

# Generated at 2022-06-24 11:31:16.902083
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({'hi': 'hi'}, 0, 4, content='hi=hi')
    assert d._start_index == 0
    assert d._end_index == 4
    assert d._content == 'hi=hi'
    assert d._value == {'hi': 'hi'}


# Generated at 2022-06-24 11:31:23.455283
# Unit test for constructor of class Token
def test_Token():
    start_index = 3
    end_index = 5
    content = "hello world"
    token = Token(value='', start_index=start_index, end_index=end_index, content=content)
    assert token.value is '', 'not correct value'
    assert token._start_index == start_index, 'not correct start index'
    assert token._end_index == end_index, 'not correct end index'
    assert token._content == content, 'not correct content'
    assert token.string == content[start_index:end_index+1], 'not correct string'
    assert token._get_value() == '', 'not correct value'
    assert token.start.line == 1, 'not correct line'
    assert token.start.column == 4, 'not correct column'
    assert token.start.index == start

# Generated at 2022-06-24 11:31:24.182467
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken.__init__