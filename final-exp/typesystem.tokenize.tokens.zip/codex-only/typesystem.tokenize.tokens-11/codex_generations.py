

# Generated at 2022-06-24 11:21:31.217066
# Unit test for method lookup of class Token
def test_Token_lookup():
    class TestToken(Token):
        def __init__(self, value, index):
            self._value = value
            self._index = index
        def _get_child_token(self, key):
            value, index = self._value[key]
            return TestToken(value, index)
    content = "first\nsecond\nthird\nfourth"
    first = TestToken([['one', 'two', 'three'], ['four'], ['five', 'six']], 0)
    index = [0, 2]
    assert(first.lookup(index)._value == 'three')
    assert(first.lookup(index).start._index == 6)
    assert(first.lookup(index).end._index == 10)
    index = [1, 0]

# Generated at 2022-06-24 11:21:33.455286
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = ScalarToken("abc", 1, 4)
    token2 = ScalarToken("abc", 1, 4)
    assert token1 == token2


# Generated at 2022-06-24 11:21:37.645837
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken([1, 2, 3], 0, 10, content='[1, 2, 3]')
    assert token._value == [1, 2, 3]
    assert token._start_index == 0
    assert token._end_index == 10
    assert token._content == '[1, 2, 3]'


# Generated at 2022-06-24 11:21:45.483544
# Unit test for constructor of class Token
def test_Token():
    import typesystem
    # Test for class 'Token' in general
    t = Token(1, 2, 3)
    assert t.start == Position(1, 1, 2)
    assert t.end == Position(1, 1, 3)
    # Test for class 'ScalarToken'
    s = ScalarToken(1, 2, 3)
    assert s.string == ''
    assert s.start == Position(1, 1, 2)
    assert s.end == Position(1, 1, 3)
    assert s.value == 1
    assert s.lookup([0]) == s
    assert s.lookup_key([0, 1]) == s
    assert s.lookup([1]) == s
    assert s.lookup_key([0, 2]) == s
    # Test for class 'DictToken'
    d

# Generated at 2022-06-24 11:21:47.444118
# Unit test for constructor of class Token
def test_Token():
    a = Token(None,0,0)
    assert(a.string == '')


# Generated at 2022-06-24 11:21:56.221122
# Unit test for method lookup of class Token
def test_Token_lookup():
    from tokenizer import tokenize
    from generator import generate
    from schemas import DATA_SCHEMA, DATASET_SCHEMA, DATASET_SCHEMA_JSON
    from schemas import ENCODING_SCHEMA, MARK_SCHEMA, MARK_SCHEMA_JSON
    from schemas import PRIMARY_KEYS_SCHEMA, PRIMARY_KEY_SCHEMA, WINDOW_SCHEMA
    from coreschema.exceptions import ValidationError
    from typesystem.base import Position
    from dictdiffer import diff, patch
    from dictdiffer.merge import merge


# Generated at 2022-06-24 11:21:58.346444
# Unit test for constructor of class DictToken
def test_DictToken():
    test_dict = {'abc':123}
    test_token = DictToken(test_dict, 0, 3)
    assert test_token._get_value() == test_dict


# Generated at 2022-06-24 11:22:10.036088
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Test for a scalar token
    scalarToken = ScalarToken("string", 0, 4, "string")
    assert(repr(scalarToken) == "ScalarToken('string')")

    # Test for a dictionary token
    keyToken = ScalarToken("key", 0, 2, "key")
    valueToken = ScalarToken("value", 3, 6, "value")
    dictToken = DictToken({keyToken: valueToken}, 0, 6, "key: value")
    assert(repr(dictToken) == "DictToken({key: value})")

    # Test for a list token
    listToken = ListToken([scalarToken], 0, 6, "[string]")
    assert(repr(listToken) == "ListToken(['string'])")


# Generated at 2022-06-24 11:22:11.843912
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token(1, 2, 3)
    assert repr(token) == '''Token('1')'''


# Generated at 2022-06-24 11:22:13.595577
# Unit test for constructor of class Token
def test_Token():
    token = Token(1, 2, 3)
    assert isinstance(token, Token)
    assert token._content == ""


# Generated at 2022-06-24 11:22:18.744483
# Unit test for constructor of class Token
def test_Token():
    t = Token(0, 0, 0, "")
    assert t.string == ""
    assert t.value == 0
    assert t.start.line == 1
    assert t.start.column == 1
    assert t.start.index == 0
    assert t.end.line == 1
    assert t.end.column == 1
    assert t.end.index == 0
    

# Generated at 2022-06-24 11:22:29.175558
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class MyListToken(ListToken):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)
            self._value = [ScalarToken(0, 0, 1, content), ScalarToken(1, 3, 4, content)]
    content = "000"
    token = MyListToken(["0", "1"], 0, 4, content)
    assert token.lookup_key([0]) == ScalarToken(0, 0, 0, content)
    assert token.lookup_key([1]) == ScalarToken(1, 2, 2, content)


# Generated at 2022-06-24 11:22:33.069260
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken([], 0, 1, content = "")
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)
    assert token.string == ""
    assert token._value == []

# Generated at 2022-06-24 11:22:33.640065
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken

# Generated at 2022-06-24 11:22:37.556916
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    test_case = Token(value=None, start_index=1, end_index=2)
    result = test_case.__repr__()
    expected_result = 'Token(None)'
    assert result == expected_result



# Generated at 2022-06-24 11:22:39.691378
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = ListToken([],0,0,'')
    assert token.lookup_key([0]) == None

# Generated at 2022-06-24 11:22:46.973970
# Unit test for constructor of class Token
def test_Token():
    token = Token(
        value = 0, start_index = 0, end_index = 0, content = "Test content"
    )
    assert token.string == "T"
    assert token.start.line_no == 1
    assert token.start.column_no == 1
    assert token.start.offset == 0
    assert token.end.line_no == 1
    assert token.end.column_no == 1
    assert token.end.offset == 0
    assert token._value == 0
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == "Test content"



# Generated at 2022-06-24 11:22:52.973801
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = ScalarToken('123', 1, 4)
    token2 = ScalarToken('123', 1, 4)
    token3 = ScalarToken('321', 4, 1)
    token4 = {1: 1}
    assert isinstance(token1, Token)
    assert isinstance(token2, Token)
    assert isinstance(token3, Token)
    assert isinstance(token4, dict)
    assert token1 == token2
    assert not(token1 == token3)
    assert not(token1 == token4)


# Generated at 2022-06-24 11:22:59.283954
# Unit test for method lookup of class Token
def test_Token_lookup():
    class TestToken(Token):
        """
        Test class for Token.lookup
        """

        def __init__(self, *args: typing.Any) -> None:
            super().__init__(*args)
            self._child_tokens = [self._create_token(1),
                                  self._create_token(2),
                                  self._create_token(3)]

        def _create_token(self, x: int) -> "Token":
            """
            Create a new token with the given x as value.
            """
            return TestToken(x, self._start_index, self._end_index)

        def _get_child_token(self, key: typing.Any) -> Token:
            """
            Get a child token
            """
            return self._child_tokens[key]

    # Test

# Generated at 2022-06-24 11:23:01.572163
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    value = "String"
    start_index = 2
    end_index = 6
    content = "A String"
    token = ScalarToken(value, start_index, end_index, content = content)
    assert repr(token) == "ScalarToken('String')"
    return token

# Generated at 2022-06-24 11:23:04.878472
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    dict_token = DictToken({}, 0, 0, "")
    list_token = ListToken([dict_token], 0, 0, "")
    new_dict_token = list_token.lookup_key([0, 0])
    assert new_dict_token == dict_token

# Generated at 2022-06-24 11:23:09.261331
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert eval(repr(Token(1, 2, 3))).__class__ == Token
    assert eval(repr(Token(1, 2, 3))).string == "1"



# Generated at 2022-06-24 11:23:12.321588
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Test the Token.__repr__ method
    #
    # Setup
    token = Token(1, 1, 2, "abc")
    # Exercise
    result = token.__repr__()
    # Verify
    assert result == "Token('b')"
    # Cleanup - none necessary



# Generated at 2022-06-24 11:23:14.425347
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    content = "age: number"
    token = parse_token(content)
    assert token.lookup_key([0, "age"]).string == "age:"


# Generated at 2022-06-24 11:23:19.756727
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = ScalarToken("value1", 0, 4)
    t2 = ScalarToken("value1", 0, 4)
    assert t1==t2
    assert not t1!=t2
    assert not t1=="value1"
    assert t1!="value1"

# Generated at 2022-06-24 11:23:22.733443
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    t = ScalarToken(value="foo", start_index=0, end_index=2)
    assert hash(t) == hash("foo")


# Generated at 2022-06-24 11:23:29.597638
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    ScalarToken('a', 0, 0)
    DictToken({'a':1}, 0, 0)
    ListToken([1,2], 0, 0)

# Generated at 2022-06-24 11:23:34.864680
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    v = ScalarToken(123, 0, 3)
    assert v.start.line == 1
    assert v.start.column == 1
    assert v.end.line == 1
    assert v.end.column == 4
    assert v.string == "123"
    assert v.value == 123


# Generated at 2022-06-24 11:23:37.540243
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(value='', start_index=0, end_index=1)
    print(hash(token))
    print(type(hash(token)))


# Generated at 2022-06-24 11:23:45.288427
# Unit test for constructor of class DictToken
def test_DictToken():
    # create a dummy TestObject
    obj1 = TestObject('apple')
    obj2 = TestObject('orange')
    obj3 = TestObject('kiwifruit')

    # create a dummy dictionary of TestObject
    dict_test_dict = {obj1: 'red', obj2: 'orange', obj3: 'green'}

    # create a DictToken with the given dict
    dict_token = DictToken(dict_test_dict, 0, 0, '')
    # do the assertion for the _get_value() method of DictToken
    assert dict_token._get_value == dict_test_dict
    assert dict_token._get_value != {obj1: 'red', obj2: 'orange', obj3: 'green'}
    # do the assertion for the _get_child_token() method of DictToken
   

# Generated at 2022-06-24 11:23:46.968237
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token("foo", 1, 2)
    assert token.lookup([]) == token


# Generated at 2022-06-24 11:23:56.375526
# Unit test for constructor of class ListToken
def test_ListToken():
    a = ListToken(["Onion", "Tomato"], 1, 7)
    b = ListToken(["Potato", "Carrot"], 1, 7)

    if a._get_value() == ["Onion", "Tomato"]:
        print("Test Successful")
    else:
        print("Test Failed")

    if a.lookup([1]) == "Tomato":
        print("Test Successful")
    else:
        print("Test Failed")

    if a == b:
        print("Test Failed")
    else:
        print("Test Successful")


test_ListToken()



# Generated at 2022-06-24 11:24:04.856298
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    _aToken = Token(None, None, None)
    assert repr(_aToken) == 'Token(None)'
    _aString = _aToken.string
    _aValue = _aToken.value
    _aStart = _aToken.start
    _aEnd = _aToken.end
    _aIndex = None
    _aToken = _aToken.lookup(_aIndex)
    _aIndex = None
    _aToken = _aToken.lookup_key(_aIndex)
    _aIndex = None
    _aPosition = _aToken._get_position(_aIndex)
    assert str(_aPosition) == 'Position(1, 1, -1)'
    assert not (_aToken != _aToken)
    assert str(_aToken) == 'Token(None)'

# Generated at 2022-06-24 11:24:11.842861
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.types import Dictionary
    from typesystem.base import ID
    from typesystem.base import Struct
    class Person(Struct):
        id = ID()
        name = String()
    person = Person(id=1, name="person1")
    person_token = DictToken({},0,0)
    assert person_token.__dict__ == person.__dict__


# Generated at 2022-06-24 11:24:14.911664
# Unit test for constructor of class DictToken
def test_DictToken():
    # Constructor
    d1 = DictToken({}, 0, 1, '{"a": 1}')
    assert d1 != None
    d1._value = {"a": 1}
    assert d1._value != None

# Generated at 2022-06-24 11:24:19.403122
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("", 0, 0, "")
    assert token.string == ""
    assert token.value == ""
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)
    assert len(token.lookup([1, 2])) == 0

# Generated at 2022-06-24 11:24:21.599372
# Unit test for constructor of class ListToken
def test_ListToken():
    t = ListToken(1, 2, 3, 4, 5)
    assert t._get_value() == [1, 2, 3, 4, 5]
    

# Generated at 2022-06-24 11:24:26.119873
# Unit test for method lookup of class Token
def test_Token_lookup():
    print("Testing Token.lookup method of class Token")
    token_1 = Token(value, start_index, end_index, content)
    index_1 = index
    result1 = token_1.lookup(index_1)
    print("A token after lookup is: " + result1)
    assert result1 == token_1._get_child_token(key)
    print("")


# Generated at 2022-06-24 11:24:30.728180
# Unit test for constructor of class Token
def test_Token():
    t = Token(5, 2, 4)

    assert t._value == 5
    assert t._start_index == 2
    assert t._end_index == 4
    assert t._content == ''


# Generated at 2022-06-24 11:24:41.377307
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # The child token for the index [1,4,3] of the list token.
    child_token = ListToken([0, 1, 2, 3, 4], 0, 0)
    child_token_2 = ListToken([0, 1, 2], 0, 0)
    child_token_2.extend([
        ListToken([0, 1, 2, 3], 0, 0),
        ListToken([0, 1, 2, 4], 0, 0),
        ListToken([0, 1, 2, 5], 0, 0)
    ])
    child_token.extend([child_token_2])
    # The key token for the index [1,4,3] of the list token.
    key_token = ScalarToken(3, 0, 0)
    # The list token to be tested.
    list_token = ListToken

# Generated at 2022-06-24 11:24:45.144846
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    print('Test constructor of class ScalarToken')
    a = ScalarToken(1, 0,1)
    print(a)
    b = ScalarToken(2, 3,4)
    print(b)
    print(a._get_value())
    print(b._get_value())
    
    

# Generated at 2022-06-24 11:24:49.322333
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken({"key": "key", "value": "value"}, start_index = 0, end_index = 1, content = "")
    print(dt)

if __name__ == '__main__':
    test_DictToken()

# Generated at 2022-06-24 11:24:55.732117
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken([1,2,3], 1, 2, "abcd")
    assert token.string == "cd"
    assert token.value == [1,2,3]
    assert token.start == Position(1, 3, 2)
    assert token.end == Position(1, 4, 3)
    assert token.lookup([0]) == 1
    assert token.lookup([2]) == 3
    # assert token.lookup_key([0]) == 1


# Generated at 2022-06-24 11:25:04.920449
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    def check_Token___eq__(expected, instance1, instance2):
        actual = instance1 == instance2
        assert actual == expected, "Expected %s, got %s" % (expected, actual)

    check_Token___eq__(False, ScalarToken(1, 0, 0), ScalarToken(2, 1, 1))
    check_Token___eq__(True, ScalarToken(1, 0, 0), ScalarToken(1, 0, 0))

    check_Token___eq__(False, ListToken([ScalarToken(1, 0, 0)], 0, 0), ListToken([ScalarToken(2, 1, 1)], 0, 0))

# Generated at 2022-06-24 11:25:12.355376
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    a = ScalarToken(value=5, start_index=0, end_index=0, content="5")
    assert(a.value == 5)
    assert(a.start == Position(1, 1, 0))
    assert(a.end == Position(1, 1, 0))
    assert(a.string == "5")
    assert(a.lookup([]) == a)


# Generated at 2022-06-24 11:25:16.654117
# Unit test for constructor of class ListToken
def test_ListToken():
    # test for constructor
    test = ListToken([], 0, 5)
    assert test._value == []
    assert test._start_index == 0
    assert test._end_index == 5
    assert test._content == ""



# Generated at 2022-06-24 11:25:18.777797
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert '%s(%s)' % (Token.__name__, repr("Hello, world!")) == Token("Hello, world!", 0, 13, 'Hello, world!').__repr__()

# Generated at 2022-06-24 11:25:20.053189
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert repr(Token(value=None, start_index=None, end_index=None, content=None)) == "Token(None)"

# Generated at 2022-06-24 11:25:28.942622
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token1 = ScalarToken('hello world a string', 1, 21)
    # print(token1)
    assert token1.string == 'hello world a string'
    assert token1.value == 'hello world a string'
    assert token1.start == Position(1, 1, 1)
    assert token1.end == Position(1, 22, 21)
    token2 = ScalarToken('hello world a string', 1, 21)
    assert token1 == token2
    assert hash(token1) == hash(token2)
    token3 = ScalarToken('hello world a string', 20, 30)
    assert token1 != token3


# Generated at 2022-06-24 11:25:31.375014
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken("foo", 0, 2)
    assert hash(token) == hash("foo")

# Generated at 2022-06-24 11:25:33.971884
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token_obj = Token("foo", 0, 0, content="")
    call_method = token_obj.__repr__()
    assert call_method == "Token(foo)"


# Generated at 2022-06-24 11:25:36.421325
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Enhance: Add more unit tests.
    t = Token(1, 2, 3)
    assert t.__repr__() == "Token('')"



# Generated at 2022-06-24 11:25:44.488992
# Unit test for method lookup of class Token
def test_Token_lookup():
    config_file = open("tests/lexer/test_file.txt", "r")
    content = config_file.read() + "\n"
    
    lexer = Lexer(content)
    lexer.lex()
    
    from typesystem.types import String, Dictionary, List
    from typesystem.parser import Parser
    parser = Parser()
    schema = Dictionary(
        name="root",
        properties={"header": String(), "body": List(String())},
        required=["header", "body"],
    )
    root_token = parser.parse(lexer, schema)
    
    assert isinstance(root_token, DictToken)
    assert root_token.lookup([]) == root_token
    assert root_token.lookup([0]) == root_token._get_key_token(0)

# Generated at 2022-06-24 11:25:51.776955
# Unit test for constructor of class ListToken
def test_ListToken():
    Type_Value = ["1", "2"]
    Start_Index = 0
    End_Index = 2
    Type_Content = "1,2,3"
    new_ListToken = ListToken(Type_Value, Start_Index, End_Index, Type_Content)
    assert new_ListToken.value == ["1", "2"]
    assert new_ListToken.string == "1,2"
    assert new_ListToken.start == Position(1, 1, 0)
    assert new_ListToken.end == Position(1, 4, 2)


# Generated at 2022-06-24 11:25:52.571223
# Unit test for method __repr__ of class Token
def test_Token___repr__():
	assert True


# Generated at 2022-06-24 11:25:57.739345
# Unit test for constructor of class Token
def test_Token():
    token = Token('hello', 0, 5)
    assert token.string == 'hello'
    assert token.value == 'hello'
    assert token.start.line_no == 1
    assert token.start.column_no == 1
    assert token.start.index == 0
    assert token.end.line_no == 1
    assert token.end.column_no == 6
    assert token.end.index == 5
    

# Generated at 2022-06-24 11:26:04.315990
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    Token_0 = Token()
    Token_2 = ScalarToken("0", 0, 1, "01")
    Token_3 = ListToken([Token_2], 0, 1, "01")
    Token_4 = ListToken([Token_3], 0, 1, "01")
    Token_7 = ListToken([Token_4], 0, 1, "01")

    token = Token_7.lookup_key([0, 0, 0])
    value = token._get_value()
    assert value == "0"


# Generated at 2022-06-24 11:26:13.117251
# Unit test for constructor of class Token
def test_Token():
    test_toke = Token("hello", 0, 4)
    assert test_toke._value == "hello"
    assert test_toke._start_index == 0
    assert test_toke._end_index == 4
    assert test_toke._content == ""
    assert test_toke.string == "hello"
    assert test_toke.value == "hello"
    assert test_toke.start == Position(1, 5, 4)
    assert test_toke.end == Position(1, 5, 4)
    assert repr(test_toke) == "Token('hello')"
    assert test_toke == Token("hello", 0, 4)

# Generated at 2022-06-24 11:26:17.672047
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(5,0,1,content="5")
    assert token.string == "5"
    assert token.value == 5
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 2, 1)

# Generated at 2022-06-24 11:26:19.605392
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(
        12,
        123,
        124,
        content=''
    )


# Generated at 2022-06-24 11:26:22.086619
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token("value1", 1, 2, "string1")
    token2 = Token("value2", 3, 4, "string2")
    assert token1 == token1
    assert not token1 == token2

# Generated at 2022-06-24 11:26:28.562092
# Unit test for constructor of class ListToken
def test_ListToken():
    class MyToken(ListToken):
        def __init__(self, value, start_index, end_index, content):
            return super().__init__(value, start_index, end_index, content)

    token = MyToken([MyToken([], 0, 1, 'A'), MyToken([], 2, 5, 'BCDEF')], 0, 5, 'ABCDEF')
    value = token.value
    assert(len(value) == 2)
    assert(value[0] == [])
    assert(value[1] == [])
    assert(token.string == 'ABCDEF')



# Generated at 2022-06-24 11:26:29.691185
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    assert ScalarToken('Value', 1, 2, 'content') # Pass



# Generated at 2022-06-24 11:26:36.660852
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # Given
    root = {"x": "foo", "y": {"z": "baz"}}
    # When
    lookup_key = tokens._build_token(root).lookup_key([0, 1, 1])
    # Then
    assert lookup_key == "z"

# Generated at 2022-06-24 11:26:48.396872
# Unit test for constructor of class ListToken
def test_ListToken():
    test_value = []
    test_start_index = 0
    test_end_index = 0
    test_content = ""
    test_ListToken = ListToken(test_value, test_start_index, test_end_index, test_content)
    assert test_ListToken.value == [], "value should be []"
    assert test_ListToken.string == "", "string should be ''"
    assert test_ListToken.start.line_no == 1, "line_no should be 1"
    assert test_ListToken.start.column_no == 1, "column_no should be 1"
    assert test_ListToken.start.index == 0, "index should be 0"
    assert test_ListToken.end.line_no == 1, "line_no should be 1"

# Generated at 2022-06-24 11:26:51.039923
# Unit test for constructor of class ListToken
def test_ListToken():
    t = ListToken(None, 0, 0, content="")
    assert (t)


# Generated at 2022-06-24 11:26:59.609767
# Unit test for method lookup of class Token

# Generated at 2022-06-24 11:27:02.204823
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken([])
    assert token is not None


# Generated at 2022-06-24 11:27:09.973450
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import String
    from typesystem.base import Array
    from typesystem.base import Dict as DictType
    from typesystem.base import fields
    from typesystem.types import Dict
    from json import loads

    class Address(fields.Dict):
        street = String(required=True)
        zip_code = String(required=True)
        city = String(required=True)
        country = String(required=True)

    class Person(fields.Dict):
        name = String(required=True)
        addresses = Array(items=Address(), required=True)

    class Root(fields.Dict):
        person = Person(required=True)

    root_schema = Root()
    person_schema = Person()
    address_schema = Address()

# Generated at 2022-06-24 11:27:20.665003
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test when self._get_value() == other._get_value() and self._start_index == other._start_index and self._end_index == other._end_index:
    _value = 1
    _start_index = 1
    _end_index = 1
    content = ""
    token = Token(_value, _start_index, _end_index, content)
    _value = 1
    _start_index = 1
    _end_index = 1
    content = ""
    other = Token(_value, _start_index, _end_index, content)
    assert token == other
    # Test when self._get_value() != other._get_value() and self._start_index == other._start_index and self._end_index == other._end_index:
    _value = 1
    _start_index = 1

# Generated at 2022-06-24 11:27:24.669695
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    obj = Token(value="", start_index=0, end_index=0)
    assert repr(obj) == "Token('')"


# Generated at 2022-06-24 11:27:30.213886
# Unit test for constructor of class Token
def test_Token():
    t = Token(1,2,3)
    assert t.string == ''
    assert t.value is None
    assert t.start == Position(1, 1, 2)
    assert t.end == Position(1, 1, 3)
    assert t.lookup([]) is None
    assert t.lookup_key([]) is None
    assert repr(t) == 'Token(None)'
    assert t == Token(1,2,3)



# Generated at 2022-06-24 11:27:40.116710
# Unit test for method lookup_key of class Token

# Generated at 2022-06-24 11:27:50.394406
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.exceptions import SchemaError
    from typesystem.schema import Schema
    from typesystem.schema import Array, Boolean, Integer, Number, Object, String

    schema = Schema(
        properties={
            "a": Array(items=String()),
            "b": Boolean(),
            "c": Integer(),
            "d": Number(),
            "e": Object(properties={}),
            "f": Object(properties={"g": Integer()}),
            "h": Object(properties={"i": Object(properties={"j": Integer()})}),
            "k": Object(properties={"l": Array(items=Number())}),
        }
    )

    errors = schema.validate({})

    assert len(errors) == 7

    assert errors[0].path == ["a"]


# Generated at 2022-06-24 11:28:01.560316
# Unit test for method lookup_key of class Token

# Generated at 2022-06-24 11:28:09.356054
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    import sys
    import os
    import unittest
    import typesystem.token as token
    print("test_ScalarToken:", "\n.test __init__")

    token1 = token.ScalarToken(value=1, start_index=20, end_index=25)
    assert token1._value == 1
    assert token1._start_index == 20
    assert token1._end_index == 25
    assert token1._content == ""
    assert token1._get_value() == 1


# Generated at 2022-06-24 11:28:20.720229
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():

    class TestDictToken(DictToken):
        pass

    class TestListToken(ListToken):
        pass

    class TestScalarToken(ScalarToken):
        pass

    class TestToken(Token):
        DictToken = TestDictToken
        ListToken = TestListToken
        ScalarToken = TestScalarToken

    def test():
        scalar_token = Token.ScalarToken(0, 9, 13)
        list_token = Token.ListToken([scalar_token], 3, 15)
        dict_token = Token.DictToken({scalar_token: list_token}, 0, 16)
        token = Token(dict_token, 0, 16)
        key_token = token.lookup_key([0, 0])
        assert key_token == scalar_token
        return key

# Generated at 2022-06-24 11:28:26.038878
# Unit test for constructor of class DictToken
def test_DictToken():
  assert DictToken("foo", 0, 1)._value=="foo"
  assert DictToken("foo", 0, 1, "bar")._content=="bar"
  

# Generated at 2022-06-24 11:28:35.767790
# Unit test for constructor of class Token
def test_Token():
    #Test normal constructor with value, start_index, end_index
    t = Token(1,2,3)
    assert t.value is None
    assert t.string == ""
    assert t.start.index == 2
    assert t.end.index == 3
    
    #Test normal constructor with value, start_index, end_index, content
    t = Token(1,2,3, "I am a string")
    assert t.value is None
    assert t.string == "I"
    assert t.start.index == 2
    assert t.end.index == 3

    #Test exception constructor with value, start_index, end_index, content
    with pytest.raises(NotImplementedError):
        t._get_value()
    with pytest.raises(NotImplementedError):
        t._

# Generated at 2022-06-24 11:28:41.828323
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    a = Token(42, 3, 5, 'cat')
    b = Token(42, 3, 5, 'dog')
    c = Token(43, 3, 5, 'cat')
    assert a == b
    assert not a == c
    assert not a == 42
    assert not a == 'cat'

# Generated at 2022-06-24 11:28:49.641305
# Unit test for constructor of class DictToken
def test_DictToken():
    start_index = 1
    end_index = 2
    content = "content"
    value = {1: "1", 2: "2"}

    test_token = DictToken(value, start_index, end_index, content)
    assert test_token._get_value() == value
    assert test_token._start_index == start_index
    assert test_token._end_index == end_index
    assert test_token._content == content


# Generated at 2022-06-24 11:28:51.352898
# Unit test for constructor of class ListToken
def test_ListToken():
  assert ListToken(1) is not None


# Generated at 2022-06-24 11:28:54.572346
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # Setup
    token = ScalarToken('foo', 0, 2)

    # Exercise & Verify
    expected = hash('foo')
    assert token.__hash__() == expected


# Generated at 2022-06-24 11:28:57.111202
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    msg = "ScalarToken is not constructor"
    assert ScalarToken(1, 1, 2, "content") is not None, msg



# Generated at 2022-06-24 11:28:59.015770
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    t = ListToken([1, 2, 3], 2, 5, "abcde")
    t.lookup_key([0]) == 2

test_Token_lookup_key()

# Generated at 2022-06-24 11:29:02.780571
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Set up test objects
    test_Token = Token(1,1,1)
    test_Token2 = Token(1,1,1)

    # Assert function returns expected result
    assert test_Token == test_Token2


# Generated at 2022-06-24 11:29:10.830081
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # Purpose:
    #   Tests Token.lookup_key method
    #   Tests to see if the last key in a given list is located correctly.
    #   Tests it by comparing it to a known value.
    # Preconditions:
    #   None
    # Test Steps:
    #   1. Create dictionary of tokens with known keys and values
    #   2. Create token from dictionary
    #   3. Lookup the last key and compare with the known value
    # Postconditions:
    #   The returned value from lookup_key should be equal to the known value

    dictionary_token = DictToken(
        {ScalarToken(1, 0, 0): ScalarToken('a', 0, 0)}, 0, 0)

# Generated at 2022-06-24 11:29:14.444707
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test that __eq__ method of class Token raises NotImplementedError
    
    token1 = Token('value', 0, 0)
    token2 = Token('value', 0, 0)
    assert token1 == token2
    
    # Test that __eq__ method of class Token raises NotImplementedError
    
    token1 = Token('value1', 0, 0)
    token2 = Token('value2', 0, 0)
    assert token1 != token2
    

# Generated at 2022-06-24 11:29:25.861957
# Unit test for method lookup of class Token

# Generated at 2022-06-24 11:29:34.651079
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    tok_key = ScalarToken(value="key",start_index=1,end_index=1)
    tok_value = ScalarToken(value="value",start_index=2,end_index=2)
    tok_dict = DictToken(value={"key":tok_value},start_index=0,end_index=1)
    assert tok_dict.lookup_key([0]) == tok_key
    assert tok_dict.lookup_key([0]) != tok_value
    assert tok_dict.lookup_key([0]) != tok_dict
    assert tok_dict.lookup_key([0]) != "key"

# Generated at 2022-06-24 11:29:39.274436
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    classToken = ClassToken(
        value='value', start_index='start_index', end_index='end_index', content='content'
    )
    otherToken = ClassToken(
        value='value', start_index='start_index', end_index='end_index', content='content'
    )
    # assert
    assert classToken.__eq__(otherToken) == True


# Generated at 2022-06-24 11:29:44.387955
# Unit test for method lookup of class Token
def test_Token_lookup():
    a = ScalarToken(value="a", start_index=0, end_index=1, content="ab")
    b = ScalarToken(value="b", start_index=2, end_index=3, content="ab")
    t = ListToken(value=[a,b], start_index=0, end_index=3, content="ab")
    assert t.lookup([0])._value == 'a'

# Generated at 2022-06-24 11:29:52.523176
# Unit test for constructor of class ListToken
def test_ListToken():
    tok = ListToken(['a', 'b', 'c'], 0, 2, '')
    assert(tok.end.index == 2)
    assert(tok.lookup([0]).value == 'a')
    assert(tok.lookup([1]).value == 'b')
    assert(tok.lookup([2]).value == 'c')
    assert(tok._get_child_token(2) == tok.lookup([2]))
    assert(tok._get_child_token(1) == tok.lookup([1]))
# End of unit test

# Generated at 2022-06-24 11:29:54.265129
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    assert 1 == 1


# Generated at 2022-06-24 11:30:01.978366
# Unit test for constructor of class DictToken
def test_DictToken():
    # initialize dictionary
    dictionary = {
        'aaa': {'bbb': 'ccc'},
    }
    # initialize keys and tokens
    child_keys = {'aaa': 'aaa'}
    child_tokens = {'aaa': {'bbb': 'ccc'}}
    # initialize token
    token = DictToken(dictionary, 0, 10, content = "")
    # test keys and tokens
    assert token._child_keys == child_keys
    assert token._child_tokens == child_tokens


# Generated at 2022-06-24 11:30:04.248183
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    instance = Token(None, None, None, "test")
    assert repr(instance) == "Token('test')"


# Generated at 2022-06-24 11:30:06.497463
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
  token = ScalarToken('"test"', 0, 5, 'test')
  assert token.string == 'test'


# Generated at 2022-06-24 11:30:11.528843
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from .parser import parse
    from .tokenizer import tokenize

    for s in ('null', 'false', 'true', '1', '2.0', 'a', '"foo"', '[]', '{}'):
        t = parse(tokenize(s))
        assert t == parse(tokenize(s))
        assert t != parse(tokenize(s + " "))


# Generated at 2022-06-24 11:30:14.508834
# Unit test for method lookup of class Token
def test_Token_lookup():
    '''
    Test for method lookup of class Token
    '''
    #TODO: Test for method lookup of class Token
    pass


# Generated at 2022-06-24 11:30:18.102034
# Unit test for method lookup of class Token
def test_Token_lookup():
    raw = {"a": {"b": [{"c": "d"}]}}
    tok = DictToken(raw, 0, 0, content="d")
    assert tok.lookup([0]).string == "d"

# Generated at 2022-06-24 11:30:29.400582
# Unit test for method lookup of class Token
def test_Token_lookup():
    start_index = 0 
    end_index = 9
    token1 = ScalarToken('abcd', start_index, end_index, content = 'abcd')
    token2 = ScalarToken('efg', start_index, end_index, content = 'efg')
    token3 = ScalarToken('hijk', start_index, end_index, content = 'hijk')
    token4 = ScalarToken('l', start_index, end_index, content = 'l')
    token5 = ScalarToken('mnop', start_index, end_index, content = 'mnop')
    token6 = ScalarToken('q', start_index, end_index, content = 'q')

# Generated at 2022-06-24 11:30:33.475490
# Unit test for constructor of class DictToken
def test_DictToken():
	token = DictToken({'a':1}, 0, 0, "")
	print(token)
	print(token.start)
	print(token.end)
	print(token._value)
	print(token.value)
	print(token._child_keys)
	print(token._child_tokens)
	print(token.lookup([0]))
	print(token.lookup_key([0]))




# Generated at 2022-06-24 11:30:35.593620
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    assert repr(ScalarToken("a", 0, 2)) == 'ScalarToken(\'a\')'


# Generated at 2022-06-24 11:30:39.724928
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    content = '{"payload": "test", "type": "test2"}'
    token = Token("test", 1, 1, content)
    assert token.lookup_key([0, "payload"]).string == '"payload"'
    assert token.lookup_key([1, "type"]).string == '"type"'

# Generated at 2022-06-24 11:30:48.234106
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    st1 = ScalarToken("hello", 0, 4)
    st2 = ScalarToken(5, 1, 2)
    # get string value
    assert st1.string == "hello"
    assert st2.string == "5"
    # get value
    assert st1.value == "hello"
    assert st2.value == 5
    # test get position
    assert st1.start == Position(1, 1, 0)
    assert st2.start == Position(1, 2, 1)
    assert st1.end == Position(1, 5, 4)
    assert st2.end == Position(1, 3, 2)
    # test repr
    assert repr(st1) == "ScalarToken('hello')"
    assert repr(st2) == "ScalarToken('5')"
    # test equality


# Generated at 2022-06-24 11:30:51.323858
# Unit test for constructor of class ListToken
def test_ListToken():
    print("Testing... ")
    print("ListToken")
    token = ListToken([1, 2, 3])
    assert isinstance(token, Token)
    print("SUCCESS")



# Generated at 2022-06-24 11:30:53.652943
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken(value=[], start_index=0, end_index=0, content='')


# Generated at 2022-06-24 11:31:02.832670
# Unit test for constructor of class DictToken
def test_DictToken():
    st = ScalarToken(1,1,1,1)
    kt = ScalarToken(2,2,2,2)
    vt = ScalarToken(3,3,3,3)

    tk = DictToken({st:kt}, {st, vt}, 1, 1, "") # Type 1, a dict
    assert tk._start_index == {st, vt}
    assert tk._end_index == 1
    assert tk._content == ""
    assert tk._value == {st, vt}
    assert tk._child_tokens == {st, vt}
    assert tk._child_keys == {st, vt}

    tk = DictToken({st:kt}, {st, vt}, 1, 1, "") # Type 2, a dict
    assert t

# Generated at 2022-06-24 11:31:12.351203
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token._Token__eq__(Token(None, None, None), ScalarToken(None)) == False
    assert Token._Token__eq__(Token(None, None, None), ScalarToken(5)) == False
    assert Token._Token__eq__(Token(None, None, None), ScalarToken([])) == False
    assert Token._Token__eq__(Token(None, None, None), ScalarToken({})) == False
    assert Token._Token__eq__(Token(0, None, None), ScalarToken(0)) == True
    assert Token._Token__eq__(Token(0, 1, 2), ScalarToken(0)) == False
    assert Token._Token__eq__(Token(0, 1, 2), ScalarToken(1)) == False

# Generated at 2022-06-24 11:31:14.611900
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    try:
        assert True == False
    except AssertionError:
        return
    raise AssertionError



# Generated at 2022-06-24 11:31:18.721886
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(None, None, None) == Token(None, None, None)
    assert Token(1, None, None) == Token(1, None, None)
    assert not Token(1, None, None) == Token(None, None, None)
    assert not Token(1, None, None) == Token(1, None, None, None)
    assert not Token(1, None, None) == None

# Generated at 2022-06-24 11:31:29.055340
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():

    # create test_token
    dict_tok = DictToken(
        {
            ScalarToken(1, 0, 0): ScalarToken(10, 0, 0),
            ScalarToken(2, 0, 0): ScalarToken(20, 0, 0),
            ScalarToken(3, 0, 0): ScalarToken(30, 0, 0),
        },
        0,
        0,
        "123"
    )
    
    # check if returns the expected result
    assert dict_tok.lookup_key([0, 1]) == ScalarToken(2, 0, 0)
    assert dict_tok.lookup_key([0, 4]) == None
    assert dict_tok.lookup_key([1]) == ScalarToken(10, 0, 0)
    assert dict_tok.lookup