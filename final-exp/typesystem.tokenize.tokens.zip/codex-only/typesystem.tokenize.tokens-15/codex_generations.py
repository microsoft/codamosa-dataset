

# Generated at 2022-06-24 11:21:26.563353
# Unit test for constructor of class Token
def test_Token():
    token = Token(value = 1, start_index = 2, end_index = 3, content = "")


# Generated at 2022-06-24 11:21:34.739078
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    s = ScalarToken(1, 0, 1)
    assert s._value == 1
    assert s._start_index == 0
    assert s._end_index == 1
    assert s._get_value() == 1
    assert s.string == ""
    assert s.value == 1
    assert s.start == Position(1, 1, 0)
    assert s.end == Position(1, 1, 1)
    assert s.lookup([]) == s
    assert s.lookup_key([]) == s
    assert not (s == 1)
    assert s == ScalarToken(1, 0, 1)
    assert hash(s) == hash(1)
    assert repr(s) == "ScalarToken(" + repr("") + ")"


# Generated at 2022-06-24 11:21:39.307679
# Unit test for constructor of class Token
def test_Token():
    print(Token(2,0,1))
    print(Token(2,0,0))
    print(Token(2,0,2))
    print(Token('asd',0,3))
    print(Token('asdfg',0,3))

# Generated at 2022-06-24 11:21:40.980027
# Unit test for constructor of class DictToken
def test_DictToken():
    tok = DictToken()
    print(tok)

test_DictToken()

# Generated at 2022-06-24 11:21:50.271880
# Unit test for constructor of class Token
def test_Token():
    t=Token(value="", start_index=0, end_index=1)
    assert t.value==""
    assert t.string==""
    assert t.start==(0,0,0)
    assert t.end==(1,0,1)

# def test_ScalarToken():
#    st=ScalarToken('',0,1)
#    assert st.value==''
#    assert st.string==''
#    assert st.start==(0,0,0)
#    assert st.end==(1,0,1)
#
# def test_DictToken():
#    dt=DictToken('',0,1)
#    assert dt.value==''
#    assert dt.string==''
#    assert dt.start==(0,0,0

# Generated at 2022-06-24 11:21:53.879422
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Case #1:
    #   - input: 
    #   - output:
    #   - reason:
    #   - solution:
    value = ""
    start_index = 0
    end_index = 0
    content = ""
    obj = Token(value, start_index, end_index, content)
    # obj.__repr__()
    assert True



# Generated at 2022-06-24 11:22:03.534926
# Unit test for method lookup of class Token
def test_Token_lookup():
    class MyToken(Token):
        def _get_value(self):
            return self._value
        def _get_child_token(self, key):
            return self._value[key]

    token = MyToken(value=[[[[0], 4, [8, 12]]], 16, 20, 24], start_index=0, end_index=26)
    assert token.lookup([0, 0, 0, 0]) == MyToken(value=[0], start_index=1, end_index=2)
    assert token.lookup([0, 1]) == MyToken(value=4, start_index=8, end_index=9)
    assert token.lookup([1]) == MyToken(value=16, start_index=20, end_index=21)


# Generated at 2022-06-24 11:22:06.694964
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    datum = {'foo': 1}
    start_idx = 0
    end_idx = 10
    content = "name='foo'\nage=1\n"
    token = DictToken(datum, start_idx, end_idx, content)
    assert(repr(token)) == "DictToken({'foo': 1})"

# Generated at 2022-06-24 11:22:10.905842
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    from typesystem.types import String
    string = String()
    json_string = '{"name":"' +"Andrey"+'"}'
    parsed_token = string.parse_value(json_string, "")

    assert repr(parsed_token) == 'DictToken({"name":"'+"Andrey"+'"})'

# Generated at 2022-06-24 11:22:12.982536
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Test for name __repr__ of class Token
    token = Token(1, 2, 3)
    assert token.__repr__() == "Token(1)"


# Generated at 2022-06-24 11:22:22.189822
# Unit test for method lookup of class Token
def test_Token_lookup():
    t = ListToken(
        [ScalarToken('foo', 0, 2, 'foo\nbar'), ScalarToken('bar', 5, 7, 'foo\nbar')],
        0, 7, 'foo\nbar'
    )
    assert t.lookup([0]).value == 'foo'
    assert t.lookup([1]).value == 'bar'
    # the code below should raise an error, but this raises another error instead
    # assert t.lookup([2]).value == ''
    # assert t.lookup([3]).value == ''
    # so to make the test correct, the code is written below
    with pytest.raises(IndexError):
        t.lookup([2])
    with pytest.raises(IndexError):
        t.lookup([3])

# Generated at 2022-06-24 11:22:30.045571
# Unit test for method lookup of class Token
def test_Token_lookup():
  a = ScalarToken(value=7, start_index=0, end_index=1, content='7')
  b = ListToken(value=[ScalarToken(value=7, start_index=1, end_index=2, content='7'), ScalarToken(value=2, start_index=3, end_index=4, content='2')], start_index=0, end_index=4, content='72')

# Generated at 2022-06-24 11:22:30.717006
# Unit test for method lookup of class Token
def test_Token_lookup():
    assert 1 == 1

# Generated at 2022-06-24 11:22:38.369056
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    content = "абвгд"
    token = Token(None, 2, 3, content)
    assert token != None and token != 1

    token2 = Token(None, 2, 3, content)
    assert token == token2

    token3 = Token(None, 1, 3, content)
    assert token != token3

    token4 = Token(None, 2, 2, content)
    assert token != token4

    token5 = Token("a", 2, 3, content)
    assert token != token5


# Generated at 2022-06-24 11:22:41.929821
# Unit test for constructor of class DictToken
def test_DictToken():
    start = Position(1,1,0)
    end = Position(2,2,10)
    dicttok = DictToken({}, 1, 10, "abc")
    assert dicttok._start_index == 1
    assert dicttok._end_index == 10
    assert dicttok._content == "abc"
    assert dicttok.start == start
    assert dicttok.end == end

# Generated at 2022-06-24 11:22:48.811044
# Unit test for constructor of class ListToken
def test_ListToken():
    start_index = 21
    end_index = 23
    token = ListToken([], start_index, end_index)
    assert token.__repr__() == 'ListToken([])'
    assert token.start.line == 6
    assert token.start.column == 6
    assert token.start.index == 21


# Generated at 2022-06-24 11:22:56.365302
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    print('test_Token_lookup_key')
    dict1 = {}
    dict1["a"] = {}
    dict1["a"]["b"] = {}
    dict1["a"]["b"]["c"] = "abc"
    dict1["a"]["b"]["d"] = "abd"
    dict1["a"]["e"] = "ae"
    dict1["f"] = "f"

    # Token of dict1
    dt = DictToken(dict1, 0, 0)

    # Token of dict1["a"]
    dt_a = dt._get_child_token("a")

    # Token of dict1["a"]["b"]
    dt_a_b = dt_a._get_child_token("b")

    # Token of dict1

# Generated at 2022-06-24 11:23:01.441183
# Unit test for method __repr__ of class Token
def test_Token___repr__():

    # Create instance of class Token with input arguments.
    token = Token('value', 'start_index', 'end_index')

    # Check the class string representation.
    assert str(token) == '''Token('value')'''

# Generated at 2022-06-24 11:23:04.425168
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    i = 1
    token = ListToken(value =[1, 2, 3], start_index = 0, end_index = 2, content = [1, 2, 3])
    assert(token.lookup_key(i) == i)

# Generated at 2022-06-24 11:23:10.981987
# Unit test for constructor of class DictToken
def test_DictToken():
    t=DictToken(value={}, start_index=0, end_index=0, content="")
    print(t._get_value())
    print(t.start)
    print(t.end)
    print(t.lookup(0))
    print(t.lookup_key(0))


# Generated at 2022-06-24 11:23:14.413011
# Unit test for constructor of class ListToken
def test_ListToken():
    token_instance1 = ListToken([])
    assert isinstance(token_instance1, ListToken)
    token_instance1.lookup_key([0])
    token_instance2 = ListToken([1, 2, 3])
    assert isinstance(token_instance2, ListToken)
    token_instance2.lookup_key([0])
    token_instance2.lookup_key([1])
    token_instance2.lookup_key([2])

# Generated at 2022-06-24 11:23:22.260744
# Unit test for constructor of class Token
def test_Token():
    token = Token(value='value', start_index=4, end_index=8, content='contents')
    assert token.value is None
    assert token._get_value() is None
    assert token.start is None
    assert token.end is None
    assert token.lookup([]) is None
    assert token.lookup_key([]) is None
    assert token._get_position(2) is None
    assert isinstance(repr(token), str)
    assert isinstance(token.__eq__(token), bool)


# Generated at 2022-06-24 11:23:24.967033
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    from typesystem.base import Scalar

    value = Scalar(5)
    token = ScalarToken(value, 0, 0)
    assert hash(token) == hash(value)


# Generated at 2022-06-24 11:23:32.540569
# Unit test for constructor of class Token
def test_Token():
    # First type of Token
    t1 = Token(1, 0, 1)
    assert t1._value == 1
    assert t1._start_index == 0
    assert t1._end_index == 1
    assert t1._content == ""
    # Second type of Token
    t2 = Token(2, 1, 2, "abc")
    assert t2._value == 2
    assert t2._start_index == 1
    assert t2._end_index == 2
    assert t2._content == "abc"


# Generated at 2022-06-24 11:23:42.024840
# Unit test for constructor of class DictToken
def test_DictToken():
    def _test_ok(s, msg):
        if len(s) > 0 :
            print("[%s], test OK" % msg)
        else:
            print("[%s], test FAILED" % msg)
    def _test_fail(s, msg):
        if len(s) == 0 :
            print("[%s], test OK" % msg)
        else:
            print("[%s], test FAILED" % msg)

    dt = DictToken([[ScalarToken(1, 0, 1)], [ScalarToken(2, 0, 1)]], 0, 1, "")
    _test_ok(["1"] == dt._child_keys.keys(), 'DictToken: test _child_keys')

# Generated at 2022-06-24 11:23:44.639599
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    src = 'pos = (42, 24)'
    lexer = Lexer(src)
    tokens = lexer.lex()
    assert hash(tokens[3]) == hash(42)

# Generated at 2022-06-24 11:23:57.011398
# Unit test for constructor of class DictToken
def test_DictToken():
    dic = {
        "name":"Zed",
        "age":39,
        "height":6*12+2,
        "weight":180-40
    }
    s = "Zed"
    pos = Position(1,1,1)
    s_pos = pos
    e_pos = pos
    start_idx = 0
    end_idx = 10
    v = {
        "name": ScalarToken(s, start_idx, end_idx, s_pos, e_pos),
        "age": ScalarToken(39, start_idx, end_idx, s_pos, e_pos)
    }
    test_tok = DictToken(v, start_idx, end_idx)
    assert test_tok._value[0][0]._get_value

# Generated at 2022-06-24 11:24:05.373050
# Unit test for constructor of class Token
def test_Token():
    token1 = Token(
        value="", start_index=0, end_index=0, content=""
    )
    assert token1.string == ""
    assert token1.value == ""
    assert token1.start == Position(1, 1, 0)
    assert token1.end == Position(1, 1, 0)
    token2 = Token(
        value="", start_index=1, end_index=1, content="A"
    )
    assert token2.string == ""
    assert token2.value == ""
    assert token2.start == Position(2, 1, 1)
    assert token2.end == Position(2, 1, 1)
    token3 = Token(
        value="A", start_index=1, end_index=1, content="A"
    )

# Generated at 2022-06-24 11:24:06.602721
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    return ScalarToken(str,"1","1")


# Generated at 2022-06-24 11:24:11.257630
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    a = ScalarToken(123456, 100, 102)
    assert str(a.string) == "123"
    assert str(a.value) == "123"
    assert a.start.line == 3
    assert a.start.column == 4
    assert a.start.index == 101
    assert a.end.line == 3
    assert a.end.column == 6
    assert a.end.index == 102


# Generated at 2022-06-24 11:24:15.468177
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(None, 0, 0, "")
    t2 = Token(None, 0, 0, "")
    t3 = Token("abc", 0, 2, "abc")

    assert t1 == t2
    assert t1 != t3
    assert t2 != t3



# Generated at 2022-06-24 11:24:19.831576
# Unit test for constructor of class ListToken
def test_ListToken():
    content = "c"
    start_index = 0
    end_index = 0
    value = "ab"
    token = ListToken(value, start_index, end_index, content)
    assert token.value == value
    assert token.start == start_index
    assert token.end == end_index
    assert token._content == content

# Generated at 2022-06-24 11:24:26.416177
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    d1 = {"a":1, "b":2, "c":3}
    d2 = {"e":1, "f":2, "g":3}
    d3 = {"h":1, "i":2, "j":3}
    d = {"d1": d1, "d2": d2, "d3": d3}
    t = Token(d, 0, 0, "")
    t.lookup_key([0,0])

# Generated at 2022-06-24 11:24:31.450184
# Unit test for method lookup of class Token
def test_Token_lookup():
    assert Token.lookup("1") == "1"
    assert Token.lookup("[1]") == "[1]"
    assert Token.lookup("[1,2]") == "[1,2]"

# Generated at 2022-06-24 11:24:35.981570
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(5, 4, 8)
    assert hash(token) == hash(5)


# Generated at 2022-06-24 11:24:36.873812
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    pass


# Generated at 2022-06-24 11:24:45.878579
# Unit test for method lookup of class Token
def test_Token_lookup():
    content = '''
    {
        "key1": "value1",
        "key2": {
            "key3": [
                "value3"
            ]
        }
    }
    '''

    token = Token(
        {
            "key1": "value1",
            "key2": {
                "key3": [
                    "value3"
                ]
            }
        },
        start_index=1,
        end_index=len(content) - 2,
        content=content
    )

    assert token.lookup([0,0]).string == '"key1"'
    assert token.lookup([1,0,0]).string == '"key3"'
    assert token.lookup([1,1,0]).string == '"value3"'

# Generated at 2022-06-24 11:24:48.296011
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    obj = ScalarToken('', 0, 0)
    assert hash(obj) == hash('')



# Generated at 2022-06-24 11:24:50.735773
# Unit test for constructor of class Token
def test_Token():
    token = Token(1, 0, 0)
    assert token.value == 1


# Generated at 2022-06-24 11:24:52.243677
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    _test_Token___repr__()


# Generated at 2022-06-24 11:25:01.027731
# Unit test for constructor of class ListToken
def test_ListToken():
    value = ["a","b"]
    start_index = 0
    end_index = 20
    content = "abcdefghijklmnopqrstuvwxyz"
    token = ListToken(value, start_index, end_index, content)
    assert token._value == value
    assert token._start_index == start_index
    assert token._end_index == end_index
    assert token._content == content
    assert token.string == "abcdefghijklmnopqrstuvwxyz"


# Generated at 2022-06-24 11:25:07.196262
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    inner_dict = DictToken({'inner_key': ScalarToken('inner_value', 0, 0)}, 0, 0)
    inner_list = ListToken([ScalarToken([1, 2, 3], 0, 0)], 0, 0)
    root_dict = DictToken({'dict_key': inner_dict, 'list_key': inner_list}, 0, 0)

    assert root_dict.lookup_key(['dict_key', 'inner_key']).value == 'inner_value'
    assert root_dict.lookup_key(['list_key', 0]).value == [1, 2, 3]

if __name__ == '__main__':
    test_Token_lookup_key()

# Generated at 2022-06-24 11:25:08.437223
# Unit test for constructor of class ListToken
def test_ListToken():
  list_token = ListToken(1,2,3,4,5,6)
  print(list_token)


# Generated at 2022-06-24 11:25:12.052680
# Unit test for constructor of class ListToken
def test_ListToken():
    testInput = Token([0, 2, 4], 0, 4, "test")
    assert testInput._value == [0, 2, 4]
    assert testInput._start_index == 0
    assert testInput._end_index == 4
    assert testInput._content == "test"
    assert testInput._get_value() == [0, 2, 4]
    assert testInput._get_child_token(0) == 0
    assert testInput._get_child_token(1) == 2
    assert testInput._get_child_token(2) == 4

# Generated at 2022-06-24 11:25:15.022244
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = ScalarToken(42, 0, 1)
    assert token.lookup([]) == token


# Generated at 2022-06-24 11:25:16.254885
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken(["foo","bar"], 0, 0)

# Generated at 2022-06-24 11:25:24.217491
# Unit test for method lookup of class Token
def test_Token_lookup():
    token_0 = ScalarToken('a', 0, 2, 'abcdef')
    assert token_0.lookup([]) == token_0
    assert token_0.lookup_key([]) == token_0
    token_1 = ScalarToken('b', 0, 2, 'efg')
    token_2 = ScalarToken('c', 0, 2, 'hij')
    token_3 = ScalarToken('d', 0, 2, 'klm')
    token_4 = ScalarToken('e', 0, 2, 'nop')
    token_5 = ListToken([token_2, token_3], 0, 4, 'lmnop')
    token_6 = DictToken({token_1:token_4, token_5:token_4}, 0, 10, 'efghijklmnop')
    token_

# Generated at 2022-06-24 11:25:29.225795
# Unit test for method lookup of class Token
def test_Token_lookup():
    # Should fail because it is an abstract class
    try:
        token = Token(typing.Any, 1, 2)
        token.lookup([])
    except NotImplementedError:
        pass
    else:
        # FIXME: add assert()
        pass

    # Should fail because it is an abstract class
    try:
        token = Token(typing.Any, 1, 2)
        token.lookup_key([])
    except NotImplementedError:
        pass
    else:
        # FIXME: add assert()
        pass


# Generated at 2022-06-24 11:25:39.747971
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = ListToken(
        [
            ScalarToken("string", 0, 5),
            ListToken(
                [
                    ScalarToken("number", 7, 12),
                    ListToken([ScalarToken("string", 14, 19)]),
                    DictToken(
                        {
                            ScalarToken("key", 21, 23): ScalarToken("value", 25, 30)
                        }
                    ),
                ],
                7,
                31,
                "['number', ['string'], {'key': 'value'}]",
            ),
        ],
        0,
        32,
        "['string', ['number', ['string'], {'key': 'value'}]]",
    )

    assert token.lookup([0]).string == "'string'"

# Generated at 2022-06-24 11:25:44.567736
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # Setup
    token = ScalarToken(str(42), 0, 3)
    expected = hash(token._value)

    # Exercise
    actual = hash(token)

    # Verify
    assert actual == expected


# Generated at 2022-06-24 11:25:48.741646
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    dict_token = {'a': 3}
    token = Token(value = dict_token, start_index = 0, end_index = len(dict_token))
    assert token.lookup_key([0]) == dict_token
    # assert token.lookup_key([dict_token]) == dict_token

# Generated at 2022-06-24 11:25:56.479458
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # case 1
    t = Token(value="", start_index=1, end_index=2, content="content")
    assert t.__repr__() == "Token('nt')"
    # case 2
    t = Token(value="", start_index=1, end_index=1, content="content")
    assert t.__repr__() == "Token('n')"
    # case 3
    t = Token(value="", start_index=1, end_index=0, content="content")
    assert t.__repr__() == "Token('')"
    # case 4
    t = Token(value="", start_index=0, end_index=2, content="content")
    assert t.__repr__() == "Token('con')"
    # case 5

# Generated at 2022-06-24 11:26:02.354572
# Unit test for constructor of class DictToken
def test_DictToken():

	# Set values for test
	value = {'_value': 'value'}
	start_index = 0
	end_index = 0
	content = ''
	
	# Call function to test
	token = DictToken(value, start_index, end_index, content)

	# Assert result
	assert token._value == value
	assert token._start_index == start_index
	assert token._end_index == end_index
	assert token._content == content
	

# Generated at 2022-06-24 11:26:10.769746
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token(value = '0 1 2 3 4', start_index = 0, end_index = 10, content = '0 1 2 3 4')
    expected = '1'
    result = token.lookup([1])
    assert result._value == expected
    assert result._start_index == 2
    assert result._end_index == 2
    assert result._content == '0 1 2 3 4'


# Generated at 2022-06-24 11:26:22.245693
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class MyListToken(ListToken):
        def __init__(self, value: list, start_index: int, end_index: int, content: str = "") -> None:
            self._value = value
            self._start_index = start_index
            self._end_index = end_index
            self._content = content
        
        def _get_position(self, index: int) -> Position:
            content = self._content[: index + 1]
            lines = content.splitlines()
            line_no = max(len(lines), 1)
            column_no = 1 if not lines else max(len(lines[-1]), 1)
            return Position(line_no, column_no, index)
    

# Generated at 2022-06-24 11:26:31.536378
# Unit test for constructor of class ListToken
def test_ListToken():
    # Simple case
    ltk = ListToken([ScalarToken("hello", 0, 1, "hello")], 0, 2, "hello")
    assert ltk._value[0]._value == "hello"
    assert ltk._start_index == 0
    assert ltk._end_index == 2
    assert ltk._content == "hello"
    # Index case
    ltk = ListToken([ScalarToken("hello", 0, 1, "hello")], 0, 2, "hello")
    assert ltk._value[0]._value == "hello"
    assert ltk._start_index == 0
    assert ltk._end_index == 2
    assert ltk._content == "hello"
    # Important case of Non-List tokens

# Generated at 2022-06-24 11:26:37.400818
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("test", 1, 2, "test")
    assert token.string == "t"
    assert token.value == "test"
    assert token.start == Position(1, 1, 1)
    assert token.end == Position(1, 1, 2)
    assert token.lookup([0]) == token
    assert token.lookup_key([0]) == None

    token2 = ScalarToken("test", 1, 2, "test")
    assert token == token2


# Generated at 2022-06-24 11:26:42.768278
# Unit test for constructor of class DictToken
def test_DictToken():
    # definition of the token key-value
    input1 = ["test1", "test2"]
    input2 = ["hello", "world"]
    value = {"test1": "hello", "test2": "world"}
    content = ""
    # instance of token Value
    token = DictToken(value, 0, 2, content)
    assert str(token._get_value()) == str(input2)


# Generated at 2022-06-24 11:26:47.542268
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class SampleToken(Token):

        def _get_value(self):
            return self.string

        def _get_child_token(self, key):
            raise NotImplementedError

        def _get_key_token(self, key):
            raise NotImplementedError

    obj = SampleToken("123", 1, 3)
    obj2 = SampleToken("456", 4, 6)
    obj3 = SampleToken("789", 7, 9, content="123 456 789")
    assert obj3.lookup_key([]) == obj3



# Generated at 2022-06-24 11:26:48.227256
# Unit test for constructor of class DictToken
def test_DictToken():
    assert True

# Generated at 2022-06-24 11:26:51.296193
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token("some value", 0, 1, "some value")
    assert repr(token) == "Token('some value')"


# Generated at 2022-06-24 11:26:53.795831
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """Test for Token.__eq__."""
    assert Token(None, 0, 1, "") == Token(None, 0, 1, "")


# Generated at 2022-06-24 11:26:55.305131
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    inst = ScalarToken(0, 0, 0)
    assert inst == ScalarToken(0, 0, 0)



# Generated at 2022-06-24 11:26:57.379900
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    from typesystem.parser import tokenize

    t = tokenize('{"a": [1]}')
    assert repr(t) == "ListToken([DictToken({'a': ListToken([ScalarToken(1)])})])"

# Generated at 2022-06-24 11:26:59.835042
# Unit test for constructor of class Token
def test_Token():
    tok = Token('X', 2, 3)
    assert(tok.string == 'X')
    assert(tok.value == 'X')
    assert(tok.start == Position(1, 2, 2))
    assert(tok.end == Position(1, 3, 3))


# Generated at 2022-06-24 11:27:02.604042
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("hello", 0, 4, "hello there")


# Generated at 2022-06-24 11:27:10.166382
# Unit test for constructor of class Token
def test_Token():
    tok = Token(0, 0, 0)
    assert tok._value is 0
    assert tok._start_index is 0
    assert tok._end_index is 0
    assert tok._content == ''
    assert tok._get_value() == 0
    assert tok._get_child_token(0) == NotImplementedError
    assert tok._get_key_token(0) == NotImplementedError
    assert tok.lookup(0) == NotImplementedError
    assert tok.lookup_key(0) == NotImplementedError
    assert tok._get_position(0) == Position(1, 1, 0)
    assert tok.start == Position(1, 1, 0)
    assert tok.end == Position(1, 1, 0)

# Generated at 2022-06-24 11:27:13.501378
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(1, 0, 0)
    assert hash(token) == hash(1)


# Generated at 2022-06-24 11:27:23.515277
# Unit test for method lookup of class Token
def test_Token_lookup():
    a = ScalarToken(20, 18, 19, "     'foo'")
    b = ListToken([a], 20, 22, "     'foo'")
    c = ScalarToken('foo', 25, 29, "     'foo'")
    d = DictToken({c: b}, 30, 36, "     'foo'")

    assert d.lookup([]) == d
    assert d.lookup([0]) == b
    assert d.lookup([1]) == d.lookup([0])
    assert d.lookup([0,0]) == a
    assert d.lookup([0,0])._value == 20
    assert d.end.line_no == 3
    assert d.end.column_no == 4

# Generated at 2022-06-24 11:27:25.056737
# Unit test for constructor of class Token
def test_Token():
    t = Token(0,0,1)
    assert isinstance(t, Token)
    assert t.string == ""

# Generated at 2022-06-24 11:27:33.861027
# Unit test for method lookup of class Token
def test_Token_lookup():
    # init value
    index = [2, 3]
    start_index = 12
    end_index = 20
    content = "aaa\nbbb\nccc"
    Token_test = Token(None, start_index, end_index, content)
    # test
    class DictToken_test(DictToken):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)
            self._child_keys = {k._value: k for k in self._value.keys()}
            self._child_tokens = {k._value: v for k, v in self._value.items()}
        def _get_child_token(self, key: typing.Any) -> Token:
            return self._child

# Generated at 2022-06-24 11:27:36.927240
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    obj = ScalarToken({}, 0, 0)
    # Type error
    try:
        hash(obj)
    except TypeError:
        pass
    else:
        assert False



# Generated at 2022-06-24 11:27:38.878790
# Unit test for constructor of class Token
def test_Token():
    assert Token(1, 2, 3)

# Generated at 2022-06-24 11:27:45.409918
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert (
        ScalarToken(10, 0, 2, "10, 20, 30") == ScalarToken(10, 0, 2, "10, 20, 30")
    )  # True
    assert (
        ScalarToken(10, 0, 2, "10, 20, 30") == ScalarToken(20, 0, 2, "10, 20, 30")
    )  # False

# Generated at 2022-06-24 11:27:53.223818
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    value = ScalarToken(42,0,2)
    start_index = 0
    end_index = 2
    content = "42"
    t = ScalarToken(value, start_index, end_index, content)
    value1 = ScalarToken(42,0,3)
    value2 = ScalarToken(42,1,3)
    value3 = ScalarToken(42,0,2)
    assert t == value3
    assert not (t == value1)
    assert not (t == value2)



# Generated at 2022-06-24 11:28:04.403128
# Unit test for constructor of class Token
def test_Token():
    # test ScalarToken
    integer_token = ScalarToken(3, 10, 11)
    assert (integer_token._get_value()) == 3
    assert (integer_token.start.line) == 1
    assert (integer_token.start.column) == 1
    assert (integer_token.start.index) == 10
    assert (integer_token.end.line) == 1
    assert (integer_token.end.column) == 2
    assert (integer_token.end.index) == 11
    # test DictToken
    dict_token = DictToken({ScalarToken(1, 10, 11): ScalarToken(2, 12, 13)}, 10, 13)
    assert (dict_token._get_value() == {1: 2})

# Generated at 2022-06-24 11:28:05.875445
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token("", 0, 0)
    assert repr(token) == "Token('')"


# Generated at 2022-06-24 11:28:08.562014
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert (ListToken([], 0, 1) == ListToken([], 0, 1)) == True



# Generated at 2022-06-24 11:28:13.053128
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({1:2}, 0, 0, "")
    assert isinstance(a, DictToken)
    assert a._value == {1: 2}
    assert a._start_index == 0
    assert a._end_index == 0
    assert a._content == ""



# Generated at 2022-06-24 11:28:16.808770
# Unit test for method lookup of class Token
def test_Token_lookup():
    t = ScalarToken(1, 1, 1, "content")
    with pytest.raises(NotImplementedError):
        t.lookup([])



# Generated at 2022-06-24 11:28:22.179940
# Unit test for constructor of class ListToken
def test_ListToken():
    l = ListToken([1,2,3,4], 0, 4,"[1,2,3,4]")
    assert vars(l) == {'_value': [1, 2, 3, 4], '_start_index': 0, '_end_index': 4, '_content': '[1,2,3,4]'}

# Generated at 2022-06-24 11:28:30.376629
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    tok = ScalarToken("value", 0, 1)
    assert tok.string == "v"
    assert repr(tok) == "ScalarToken('v')"
    assert tok.start == Position(1, 1, 0)
    assert tok.end == Position(1, 2, 1)
    assert tok.value == "value"
    assert hash(tok) == hash("value")
    assert tok == ScalarToken("value", 0, 1)
    assert tok != ScalarToken("value", 0, 2)
    assert tok != ScalarToken("value2", 0, 1)
    assert tok != ScalarToken("value", 0, 2, "abc")
    assert tok != "value"


# Generated at 2022-06-24 11:28:31.383244
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    from Token import Token


# Generated at 2022-06-24 11:28:37.020012
# Unit test for method __eq__ of class Token

# Generated at 2022-06-24 11:28:41.246415
# Unit test for constructor of class Token
def test_Token():
    token = Token("value", 0, 2)
    assert token._value == "value"
    assert token._start_index == 0
    assert token._end_index == 2
    assert token._content == ""


# Generated at 2022-06-24 11:28:43.906642
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # Actually, it's tested by the `test_Token__eq__` method above
    pass


# Generated at 2022-06-24 11:28:46.453329
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    t = Token(1, 2, 3, "abc")
    assert t.__repr__() == "Token(abc)"

# Generated at 2022-06-24 11:28:51.153609
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {}
    t = DictToken(d, 0, 0, "")
    return True



# Generated at 2022-06-24 11:28:52.641153
# Unit test for constructor of class Token
def test_Token():
    assert Token(5, 10, 15, content="123")


# Generated at 2022-06-24 11:28:54.714543
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    obj = ScalarToken('hello world', 0, 11)
    result = obj.__hash__()
    assert result == hash('hello world')


# Generated at 2022-06-24 11:29:00.199908
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(5,6,5,"5")
    assert isinstance(token, Token)
    assert isinstance(token, ScalarToken)
    assert token.string == "5"
    assert token.start == Position(1,2,1)
    assert token.end == Position(1,2,1)
    assert token.value == 5
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token


# Generated at 2022-06-24 11:29:06.201013
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    obj = ScalarToken(0, 0, 0, "")
    # The __hash__ method should return the same value for two equal objects.
    assert hash(obj) == hash(ScalarToken(0, 0, 0, ""))
    # The __hash__ method should return different values for unequal objects.
    assert hash(obj) != hash(ScalarToken(1, 0, 0, ""))

# Generated at 2022-06-24 11:29:08.806983
# Unit test for constructor of class Token
def test_Token():
    token = Token(1, 2, 3, "456")
    assert token._value == 1
    assert token._start_index == 2
    assert token._end_index == 3
    assert token._content == "456"


# Generated at 2022-06-24 11:29:10.739529
# Unit test for constructor of class Token
def test_Token():
    assert Token(10,0,0)._value == 10
    assert Token(10,0,0)._start_index == 0
    assert Token(10,0,0)._end_index == 0



# Generated at 2022-06-24 11:29:20.268984
# Unit test for constructor of class ListToken
def test_ListToken():
    # print("Hello ListToken")

    # Test _get_value() and _get_child_token()
    l1 = ListToken([1,2,3], 0, 5)
    assert l1._get_value() == [1,2,3]
    l2 = ListToken([1,l1,3], 0, 7)
    assert l1._get_child_token(1) == l2

    # Test _get_position()
    assert l1._get_position(0) == Position(1,1,0)
    assert l1._get_position(5) == Position(1,6,5)

    # Test __repr__()
    assert repr(l1) == f"ListToken([1, 2, 3])"

    # Test __eq__()
    assert l1 == l1
    assert l2

# Generated at 2022-06-24 11:29:22.746602
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert (Token(1, 2, 3, "abc") == Token(1, 2, 3, "def"))
    

# Generated at 2022-06-24 11:29:31.290481
# Unit test for constructor of class ListToken
def test_ListToken():
    lt = ListToken(value = [1, 2, 3], start_index = 0, end_index = 2)
    assert lt._get_value() == [1, 2, 3]
    assert lt.start.line == 1
    assert lt.start.column == 1
    assert lt.start.index == 0
    assert lt.end.line == 1
    assert lt.end.column == 4
    assert lt.end.index == 2



# Generated at 2022-06-24 11:29:34.612357
# Unit test for constructor of class DictToken
def test_DictToken():
    new_token = DictToken(value = {}   , start_index = 1  , end_index = 2  , content = '',)
    assert new_token._child_keys == {}
    assert new_token._child_tokens == {}


# Generated at 2022-06-24 11:29:39.853196
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(3.14, 0, 2)
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 3, 2)
    assert token.string == "3.1"
    assert token.value == 3.14
    assert token.lookup([]) == token
    assert token.lookup([0]) == token
    assert token.lookup([0, 1]) == token
    assert token.lookup_key([0]) == token


# Generated at 2022-06-24 11:29:44.300237
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {
        "a": 1,
        "b": 2
    }
    t = DictToken(d, 0, 0, "")
    assert t._get_value() == d
    assert t._get_child_token("a") == ScalarToken(1, 0, 0, "")
    assert t._get_child_token("b") == ScalarToken(2, 0, 0, "")
    assert t._get_key_token("a") == ScalarToken("a", 0, 0, "")

test_DictToken()

# Generated at 2022-06-24 11:29:54.043298
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    try :
        token = ScalarToken(value = int(0), start_index = int(0), end_index = int(0), content = str(''))
        assert hash(token) == hash(int(0))

    except Exception as e:
        print('Exception: ' + str(e))

    try :
        token = ScalarToken(value = int(0), start_index = int(0), end_index = int(0), content = str(''))
        assert hash(token) == hash(0)

    except Exception as e:
        print('Exception: ' + str(e))


# Generated at 2022-06-24 11:30:04.795016
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    
    class unitTestToken(Token):
        def __init__(self, value: typing.Any, start_index: int, end_index: int, content: str = ""):
            self._value = value
            self._start_index = start_index
            self._end_index = end_index
            self._content = content
            self._child_tokens = []
            self._key_tokens = []
            self._number_of_keys = 0
        def _get_value(self) -> typing.Any:
            raise NotImplementedError  # pragma: nocover
        def _get_child_token(self, key: typing.Any) -> "Token":
            return self._child_tokens[key]

# Generated at 2022-06-24 11:30:09.722969
# Unit test for constructor of class Token
def test_Token():
    t = Token(1, 0, 0)
    assert t.string == None
    assert t.value == 1
    assert t.start._index == None
    assert t.end._index == None
    assert t.start._colno == None
    assert t.end._colno == None
    assert t.start._lineno == None
    assert t.end._lineno == None


# Generated at 2022-06-24 11:30:22.577771
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(value=True, start_index=4, end_index=4)
    assert token.string == ""
    assert token.value == True
    assert token.start == Position(line_no=1, column_no=1, index=0)
    assert token.end == Position(line_no=1, column_no=1, index=0)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert token == ScalarToken(value=True, start_index=4, end_index=4)
    assert token != ScalarToken(value=True, start_index=5, end_index=5)
    assert token != ScalarToken(value=False, start_index=4, end_index=4)

# Generated at 2022-06-24 11:30:25.994012
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({}, 0, 0)
    assert repr(token) == "DictToken({})"

# Generated at 2022-06-24 11:30:34.411611
# Unit test for constructor of class Token
def test_Token():
    # Token(self, value, start_index, end_index, content = "")
    # Create a token for a dictionary
    token = DictToken(
        {
            ScalarToken(True, 0, 3, "True"): ScalarToken(True, 6, 9, "True"),
            ScalarToken(False, 11, 15, "False"): ScalarToken(False, 18, 22, "False"),
        },
        0,
        22,
        "True : True\nFalse : False",
    )
    token = DictToken(
        {ScalarToken(1, 0, 0, "True"): ScalarToken(2, 2, 2, "True")},
        0,
        2,
        "1 : 2",
    )

# Generated at 2022-06-24 11:30:42.992691
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Set up variables for the test
    Token_1 = Token(1, 2, 3, 4)
    Token_2 = Token(1, 2, 3, 4)
    Token_3 = Token(1, 2, 3, 4)
    Token_4 = Token(1, 2, 3, 4)
    Token_5 = Token(1, 2, 3, 4)
    Token_6 = Token(1, 2, 3, 4)
    Token_7 = Token(1, 2, 3, 4)
    Token_8 = Token(1, 2, 3, 4)
    Token_9 = Token(1, 2, 3, 4)

    # Run the tests
    assert Token_1 == Token_2
    assert Token_1 == Token_3
    assert Token_1 == Token_4
    assert Token_1 == Token_5


# Generated at 2022-06-24 11:30:48.211988
# Unit test for method lookup of class Token
def test_Token_lookup():
    t = ScalarToken("a", 1, 2, content="a")

    # Ideally, we should also check that the bounding
    # position of the returned token is correct, but
    # that would be too brittle to unit test against
    # the "global" content string.
    assert t.lookup([]) is t

# Generated at 2022-06-24 11:30:49.148760
# Unit test for constructor of class Token
def test_Token():
    assert Token.__init__()


# Generated at 2022-06-24 11:30:57.589629
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    value = 3
    start = 0
    finish = 1
    token = ScalarToken(value, start, finish)
    assert hash(token) == hash(value)
    finish = 3
    token = ScalarToken(value, start, finish)
    assert hash(token) == hash(value)
    value = 2
    token = ScalarToken(value, start, finish)
    assert hash(token) == hash(value)
    start = 1
    token = ScalarToken(value, start, finish)
    assert hash(token) == hash(value)
    start = 0
    finish = 2
    token = ScalarToken(value, start, finish)
    assert hash(token) == hash(value)
    value = "string"
    token = ScalarToken(value, start, finish)
    assert hash(token) == hash

# Generated at 2022-06-24 11:31:02.126973
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    string = "foo = [1, 2, 3]"
    token = Parser(string)._parse_expr()
    token = token.lookup_key([0,2])
    #print(token.string)
    assert token.string == '3'
    assert token.lookup_key([3]) is None


# Generated at 2022-06-24 11:31:11.910813
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class IntToken(ScalarToken):
        pass
    class DictToken(Token):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)
            self._child_keys = {k._value: k for k in self._value.keys()}
            self._child_tokens = {k._value: v for k, v in self._value.items()}

        def _get_value(self) -> typing.Any:
            return {
                key_token._get_value(): value_token._get_value()
                for key_token, value_token in self._value.items()
            }

        def _get_child_token(self, key: typing.Any) -> Token:
            return self._child

# Generated at 2022-06-24 11:31:16.616892
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    obj = ScalarToken(value=object(), start_index=object(), end_index=object())
    # The code below is expected to raise an exception, since this class is
    # abstract and the implementation of __hash__ is not provided.
    with pytest.raises(NotImplementedError):
        hash(obj)


# Generated at 2022-06-24 11:31:27.125857
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # Invalid input
    data = [
        "abc",
        {
            "abc": "abc",
            "def": "def",
            "ghi": [1, 2, 3],
        },
    ]
    tree = parse_json(data)
    try:
        tree.lookup_key([])
        assert False
    except:
        assert True
    # Basic test
    tree = parse_json(data)
    result = tree.lookup_key([1])
    assert result.string == "ghi"
    result = tree.lookup_key([1, 1])
    assert result.string == "2"
    result = tree.lookup_key([1, 2])
    assert result.string == "3"