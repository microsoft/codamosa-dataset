

# Generated at 2022-06-24 11:21:28.129138
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    d = {'a': 1, 'b': 2}
    t = DictToken(d, 0, 0)
    assert t.lookup_key([0]) == t.lookup_key([0])



# Generated at 2022-06-24 11:21:38.039680
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # Arrange
    s0 = '{"key": 1}'
    s1 = '{"key": 1}'
    d0 = {'key' : 1}
    d1 = {'key' : 1}
    res0 = '"key"'
    res1 = '1'
    token = DictToken(d0, 0, len(s0) - 1, content=s0)
    # Act
    res = token.lookup_key([0])
    # Assert
    assert repr(res) == repr(res0)

    # Arrange
    token0 = DictToken(d0, 0, len(s0) - 1, content=s0)
    # Act
    res = token0.lookup_key([0])
    # Assert
    assert repr(res) == repr(res0)



# Generated at 2022-06-24 11:21:42.245421
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken(
        {"a": 1, "b": 2}, 0, 4, content="{'a': 1, 'b': 2}"
    )
    assert t.value == {"a": 1, "b": 2}
    assert t.start == Position(1, 1, 0)
    assert t.end == Position(1, 18, 17)
    assert t.string == "{'a': 1, 'b': 2}"



# Generated at 2022-06-24 11:21:51.121520
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    import json
    import inspect

    class Token:
        def __init__(self, value, start_index, end_index, content = ""):
            self._value = value
            self._start_index = start_index
            self._end_index = end_index
            self._content = content

        def _get_value(self):
            raise NotImplementedError  # pragma: nocover

        def _get_child_token(self, key):
            raise NotImplementedError  # pragma: nocover

        def _get_key_token(self, key):
            raise NotImplementedError  # pragma: nocover

        @property
        def string(self):
            return self._content[self._start_index: self._end_index + 1]


# Generated at 2022-06-24 11:21:56.057612
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    i1 = Token(1, 0, 0)
    i2 = Token(1, 0, 0)
    i3 = Token(2, 0, 0)
    s1 = Token('abc', 0, 2)
    s2 = Token('abc', 0, 2)
    s3 = Token('xyz', 0, 2)
    assert (i1 == i2) == True
    assert (i1 == i3) == False
    assert (s1 == s2) == True
    assert (s1 == s3) == False


# Generated at 2022-06-24 11:21:57.293070
# Unit test for method lookup of class Token
def test_Token_lookup():
    assert Token(1, 0, 0, "").lookup([1, 2]) == None


# Generated at 2022-06-24 11:22:01.793555
# Unit test for constructor of class Token
def test_Token():
  s = "12"
  v = 12
  start_index = 0
  end_index = 1
  content = "1234"
  t = Token(v, start_index, end_index, content)
  assert t.string == s
  assert t.value == v
  assert t.start == Position(1, 2, 0)
  assert t.end == Position(1, 3, 1)


# Generated at 2022-06-24 11:22:11.844748
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # ScalarToken
    scalarToken = ScalarToken(value=3, start_index=0, end_index=1)
    assert(scalarToken.lookup_key([0]) == scalarToken)
    # ListToken
    listToken = ListToken(value=[ScalarToken(1, 0, 1), ScalarToken(2, 0, 1), ScalarToken(3, 0, 1)], start_index=0, end_index=3, content='123')
    assert(listToken.lookup_key([1]) == ScalarToken(2, 0, 1))
    assert(listToken.lookup_key([2]) == ScalarToken(3, 0, 1))
    # DictToken
    key0 = ScalarToken(0, 0, 1)

# Generated at 2022-06-24 11:22:13.886673
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {1: 2}
    dt = DictToken(d, 0, 1)
    assert isinstance(dt, DictToken)


# Generated at 2022-06-24 11:22:22.942975
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # Token
    cmm = []
    cmm.append("""
    {
      "foo": "bar",
      "num": 123
    }
    """)
    cmm.append("""
    {
      "foo": "bar",
      "num": 123
    }
    """)
    cmm.append("""
    {
      "foo": "bar",
      "num": 123
    }
    """)
    cmm.append("""
    {
      "bar": {
        "moo": "blah"
      }
    }
    """)
    # test
    for i in range(4):
        token = Token(cmm[i],i,i)
        token.string("abc")
        token.value("abc")
        token.start("abc")
        token.end

# Generated at 2022-06-24 11:22:27.709383
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    value_1 = "value_1"
    start_index_1 = 5
    end_index_1 = 10
    st_1 = ScalarToken(value_1, start_index_1, end_index_1)
    assert st_1.__hash__() == hash(value_1)


# Generated at 2022-06-24 11:22:30.446880
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token("value", 0, 1)
    assert repr(token) == "Token('v')"

# Generated at 2022-06-24 11:22:34.620509
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    value = None
    start_index = 0
    end_index = 1
    token1 = Token(value, start_index, end_index)
    token2 = Token(value, start_index, end_index)
    assert token1 == token2


# Generated at 2022-06-24 11:22:37.002251
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    t = ScalarToken(None, None, None)
    assert hash(t) == hash(None) , 'ScalarToken.__hash__() gives wrong result !'


# Generated at 2022-06-24 11:22:39.050154
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token(
        "value", 1, 2, content="content"
    )
    assert(token.__repr__() == "Token('value')")

# Generated at 2022-06-24 11:22:41.033714
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token.__eq__(1, 1) == True
    assert Token.__eq__(1, 2) == False



# Generated at 2022-06-24 11:22:43.808809
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken('',1,1)
    expected = hash(token._value)
    result = hash(token)
    assert result == expected


# Generated at 2022-06-24 11:22:48.729671
# Unit test for constructor of class Token
def test_Token():
    token = Token(value=0, start_index=1, end_index=2, content="123")
    assert token._value == 0
    assert token._start_index == 1
    assert token._end_index == 2
    assert token._content == "123"



# Generated at 2022-06-24 11:22:49.288754
# Unit test for constructor of class ListToken
def test_ListToken():
    assert True

# Generated at 2022-06-24 11:22:59.228488
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    ts_assert(ScalarToken(1, 0, 1, "").__hash__() == ScalarToken(1, 0, 1, "").__hash__())
    ts_assert(ScalarToken(1, 0, 1, "").__hash__() == ScalarToken(1, 0, 1, "").__hash__())
    ts_assert(ScalarToken(1, 0, 1, "").__hash__() != ScalarToken(2, 0, 1, "").__hash__())
    ts_assert(ScalarToken(1, 0, 1, "").__hash__() != ScalarToken(2, 0, 1, "").__hash__())
    ts_assert(ScalarToken(1, 0, 1, "").__hash__() == ScalarToken(1, 0, 1, "").__hash__())

# Generated at 2022-06-24 11:23:00.512307
# Unit test for constructor of class Token
def test_Token():
    Token(1, 2, 3)
    assert True

# Generated at 2022-06-24 11:23:08.176769
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(1, 2, 4)
    token4 = Token(2, 2, 3)
    token5 = Token(1, 3, 3)
    token6 = Token(1, 2, 2)
    token7 = Token(1, 2, 5)
    assert (token1 == token2) == True
    assert (token1 == token3) == False
    assert (token1 == token4) == False
    assert (token1 == token5) == False
    assert (token1 == token6) == False
    assert (token1 == token7) == False


# Generated at 2022-06-24 11:23:11.383263
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    instance = Token(value=object(), start_index=object(), end_index=object())
    assert instance.__repr__() == "%s(%s)" % (instance.__class__.__name__, repr(instance.string))

# Generated at 2022-06-24 11:23:20.613305
# Unit test for constructor of class Token
def test_Token():
    from io import StringIO
    from typesystem import Structure, Field
    from typesystem.parser import Parser

    schema = Structure(
        fields=[
            Field(name="foo", type="integer", required=True),
            Field(name="bar", type="string"),
        ]
    )

    parser = Parser(schema)
    data = {
        "foo": 42,
        "bar": "hello",
    }

    token = parser.parse(data)

    assert token.lookup(["foo"]).string == "42"
    assert token.lookup(["foo"]).value == 42
    assert token.lookup(["foo"]).start == Position(1, 6, 5)
    assert token.lookup(["foo"]).end == Position(1, 7, 6)


# Generated at 2022-06-24 11:23:29.508229
# Unit test for constructor of class Token
def test_Token():
    token = Token("a", 0, 1)
    assert token.string == "a"
    assert token.value == "a"
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 2, 1)
    assert repr(token) == "Token('a')"
    assert token == Token("a", 0, 1)

    

# Generated at 2022-06-24 11:23:34.737477
# Unit test for constructor of class Token
def test_Token():
    token = Token(1, 1, 1, "a")
    assert token.string == "a"
    assert token.value == 1
    assert token.start == Position(1, 1, 1)
    assert token.end == Position(1, 1, 1)
    assert token.lookup([]) is token


# Generated at 2022-06-24 11:23:40.243292
# Unit test for constructor of class ListToken
def test_ListToken():
    test_value = [1, 2]
    test_start_index = 1
    test_end_index = 5
    test_content = "tesing listtoken"
    test_listtoken = ListToken(test_value, test_start_index, test_end_index, test_content)
    assert test_listtoken._value == [1, 2]
    assert isinstance(test_listtoken._value, list)


# Generated at 2022-06-24 11:23:49.712002
# Unit test for constructor of class Token
def test_Token():
    from hemlock.base import Token
    token = Token(1, 2, 3, 'a')
    assert token._value == 1
    assert token._start_index == 2
    assert token._end_index == 3
    assert token._content == 'a'
    assert token.string == 'a'
    assert token.start == Position(1, 1, 2)
    assert token.end == Position(1, 2, 3)
    assert token._get_position(2) == Position(1, 1, 2)
    assert token._get_position(3) == Position(1, 2, 3)
    assert token.value == 1

# Generated at 2022-06-24 11:23:57.956024
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    ST = ScalarToken(123, 1, 2)
    assert str(ST) == "ScalarToken(123)"
    assert ST.value == 123
    assert ST.start.line == 2
    assert ST.start.column == 2
    assert ST.start.index == 1
    assert ST.end.line == 2
    assert ST.end.column == 3
    assert ST.end.index == 2


# Generated at 2022-06-24 11:24:03.391439
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    content = "hello"
    start_index = 0
    end_index = 4
    value = "hello"
    token = ScalarToken(value, start_index, end_index, content)
    assert token._get_position(0) == Position(1, 1, 0)
    assert token._get_position(4) == Position(1, 5, 4)


if __name__ == '__main__':
    test_ScalarToken()

# Generated at 2022-06-24 11:24:09.475244
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    st = ScalarToken("value", 1, 2)
    assert st.string == "value"
    assert st.value == "value"
    assert st.start == Position(1, 1, 1)
    assert st.end == Position(1, 2, 2)
    assert st.lookup(['indices']) == st
    assert st.lookup_key(['indices', 'keys']) == st
    assert st.__repr__() == "ScalarToken('value')"
    assert st.__eq__(st)


# Generated at 2022-06-24 11:24:10.818722
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken.__init__

# Generated at 2022-06-24 11:24:11.837384
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # This is a stub.
    assert True


# Generated at 2022-06-24 11:24:21.480030
# Unit test for method lookup of class Token
def test_Token_lookup():
    # Non-Nested
    token = ScalarToken(value="test-value", start_index=5, 
                        end_index=12, content="content")
    assert token.string == "test-value"
    assert token.value == "test-value"
    assert token.start == Position(1, 6, 5)
    assert token.end == Position(1, 13, 12)
    assert token.lookup([]) == token

    # Nested
    token = ListToken(value=[ScalarToken(value=1, start_index=10, 
        end_index=10, content="content")], start_index=5, end_index=20, 
                        content="content")
    assert token.string == "[1]"
    assert token.value == [1]

# Generated at 2022-06-24 11:24:26.898101
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken("", 1, 2, "bla")
    assert token.value == []
    assert token.start == Position(1, 4, 1)
    assert token.end == Position(1, 5, 2)
    assert token.string == "bla"


# Generated at 2022-06-24 11:24:28.374478
# Unit test for constructor of class ListToken
def test_ListToken():
	token = ListToken()

# Generated at 2022-06-24 11:24:31.190177
# Unit test for constructor of class ListToken
def test_ListToken():
    f = ListToken(1, 2, 3, 4, 5, 6)
    assert f._value[0] == 1



# Generated at 2022-06-24 11:24:33.561926
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token("", start_index=0, end_index=1, content="")
    assert repr(token) == 'Token(\'\')'



# Generated at 2022-06-24 11:24:42.859767
# Unit test for constructor of class ListToken
def test_ListToken():
    # Initialize input values
    value = Token(0, 0, 0, content="content")
    start_index = 0
    end_index = 0
    # Initialize arguments
    args = (value, start_index, end_index)
    # Initialize keyword arguments
    kwargs = {
        "content": "content"
    }
    # Construct struct
    struct = ListToken(*args, **kwargs)

    # Check source_code
    assert "content" == struct._content
    # Check value
    assert value == struct._get_value()[0]
    # Check start_index
    assert 0 == struct._start_index
    # Check end_index
    assert 0 == struct._end_index


# Generated at 2022-06-24 11:24:46.197315
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    # test for null value
    t = ScalarToken(None, 0, 0, None)
    assert t is not None
    assert t.string == ""
    assert str(t.start) == "(1, 1, 0)"
    assert str(t.end) == "(1, 1, 0)"


# Generated at 2022-06-24 11:24:51.434108
# Unit test for method lookup of class Token
def test_Token_lookup():
    class TestToken(Token):
        def _get_value(self):
            return 'value'
        def _get_child_token(self, key):
            return key
    t = TestToken('value', 0, 0)
    assert t.lookup([]).value == 'value'


# Generated at 2022-06-24 11:25:01.052806
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class ObjToken(Token):
        def _get_value(self):
            return self._value

        def _get_child_token(self, key):
            return self._value

        def _get_key_token(self, key):
            return self._value

    token1 = ObjToken(1, 1, 10)
    token2 = ObjToken(1, 1, 10)
    token3 = ObjToken(2, 1, 10)
    token4 = ObjToken(1, 1, 11)
    token5 = ObjToken(1, 2, 10)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5
    assert token1 != object()

# Generated at 2022-06-24 11:25:05.051980
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    tk = ScalarToken(10, 10, 10)
    assert tk.__hash__() == hash(10)
    tk = ScalarToken('hello', 10, 10)
    assert tk.__hash__() == hash('hello')



# Generated at 2022-06-24 11:25:16.205678
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    start_token = ScalarToken(
        value=3, start_index=0, end_index=0, content="123"
    )
    assert isinstance(start_token, ScalarToken)
    assert start_token._value == 3
    assert start_token._start_index == 0
    assert start_token._end_index == 0
    assert start_token._content == "123"
    assert start_token.string == '3'
    assert start_token.value == 3
    assert start_token.start == Position(1,1,0)
    assert start_token.end == Position(1,1,0)
    assert start_token.lookup_key([0, 0]) == start_token



# Generated at 2022-06-24 11:25:20.349229
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_1 = Token("value_1", 0, 0)
    token_2 = Token("value_2", 0, 0)
    token_3 = Token("value_1", 1, 1)
    assert token_1 == token_1
    assert token_1 != token_2
    assert token_1 != token_3


# Generated at 2022-06-24 11:25:24.654496
# Unit test for constructor of class ListToken
def test_ListToken():
    ListToken(1,1,1)


# Generated at 2022-06-24 11:25:33.414957
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    s = """{
        "toto": 4,
        "tata": {
            "titi": 5,
            "tutu": 6
        }
    }"""

    d = json.loads(s)
    t = json_token.loads(s)

    assert t.lookup_key([0, 0]) == t.lookup([0])._get_key_token(0)
    assert t.lookup_key([1, 0]) == t.lookup([1])._get_key_token(0)
    assert t.lookup_key([1, 1]) == t.lookup([1])._get_key_token(1)

# Generated at 2022-06-24 11:25:35.568790
# Unit test for constructor of class Token
def test_Token():
    assert Token(1, 2, 3)

# Generated at 2022-06-24 11:25:43.863990
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    import builtins
    from typesystem.base import Scalar
    from typesystem.decorators import accept_scalars

    # prepare a class object to instantiate
    class MyScalar(Scalar):

        # initialize a instance of MyScalar
        def __init__(self, value: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(value, **kwargs)

        # convert the value of a instance of MyScalar to string
        def display(self) -> str:
            return str(self.value)

        # convert the string to the value of a instance of MyScalar
        @classmethod
        def loads(cls, value: str) -> typing.Any:
            return builtins.float(value)

        # convert the value of a instance of MyScal

# Generated at 2022-06-24 11:25:46.959576
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    t = ScalarToken(value='a', start_index=0, end_index=0)
    print('hash(t):', hash(t))
    assert hash(t) == hash('a')



# Generated at 2022-06-24 11:25:54.225438
# Unit test for method lookup of class Token
def test_Token_lookup():
    source = '{"key_1": "value_1", "key_2": "value_2"}'
    tokens = json.loads(source)
    assert tokens.lookup([0, 0]).string == tokens['key_1'].string == 'key_1'
    assert tokens.lookup([0, 1]).string == tokens['key_1'].string == 'value_1'
    assert tokens.lookup([1, 0]).string == tokens['key_2'].string == 'key_2'
    assert tokens.lookup([1, 1]).string == tokens['key_2'].string == 'value_2'


# Generated at 2022-06-24 11:26:03.698882
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(value=None, start_index=0, end_index=0, content="")
    assert token.string == ""
    assert token.value == None
    assert token.start.line_no == 1
    assert token.start.column_no == 1
    assert token.start.index == 0
    assert token.end.line_no == 1
    assert token.end.column_no == 1
    assert token.end.index == 0
    print("Test success")

test_ScalarToken()


# Generated at 2022-06-24 11:26:13.335915
# Unit test for method lookup of class Token
def test_Token_lookup():
    content = "foo"
    token = ScalarToken("foo", 0, 2, content)
    #Test a lookup to a child of a ScalarToken
    test_token = token.lookup([0])
    assert(test_token == token)

    token = DictToken({"key1": "value1"}, 0, 9, content)
    #Test a lookup to a child of a DictToken
    test_token = token.lookup(["key1"])
    assert(test_token == token)

    token = ListToken([token], 0, 1, content)
    #Test a lookup to a child of a ListToken
    test_token = token.lookup([0])
    assert(test_token == token)

# Generated at 2022-06-24 11:26:22.560858
# Unit test for constructor of class Token
def test_Token():
    a = Token("a", 0, 1)
    b = Token("b", 0, 1)
    assert a._start_index == 0
    assert a._end_index == 1
    assert a.string == "a"

    assert a._value == "a"
    assert a.value == "a"
    assert a.start == Position(1, 1, 0)
    assert a.end == Position(1, 2, 1)
    assert a.lookup([]) == a
    assert a.lookup_key([0]) == a
    assert a._get_position(0) == Position(1, 1, 0)
    assert repr(a) == "Token(%s)" % repr("a")
    assert a == b

test_Token()

# Generated at 2022-06-24 11:26:29.157598
# Unit test for constructor of class Token
def test_Token():
    token = Token(5, 1, 2)
    assert token.start == Position(1,1,1)
    assert token.end == Position(1,2,2)
    assert token.value == 5
    assert token._value == 5
    assert token._get_value() == 5
    assert token.string == '5'
    assert token._start_index == 1
    assert token._end_index == 2
    assert token._content == ''
    assert token.start == Position(1, 1, 1)


# Generated at 2022-06-24 11:26:42.652093
# Unit test for constructor of class ListToken

# Generated at 2022-06-24 11:26:45.483576
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    from pytest import raises
    # ValueError: Token is an abstract class, cannot create instances
    with raises(ValueError):
        Token(None,None,None)
    assert "Token" == str(Token(None,None,None))


# Generated at 2022-06-24 11:26:54.441522
# Unit test for constructor of class DictToken
def test_DictToken():
    import pytest
    from typesystem.exceptions import TypeSystemError
    from typesystem.string import String
    from typesystem.integer import Integer
    t = String()
    token = DictToken({t: 1})
    with pytest.raises(TypeSystemError):
        token = DictToken({t: 2})
    token = DictToken({Integer(): 2})
    token = DictToken({Integer(): "hello"})
    with pytest.raises(TypeSystemError):
        token = DictToken({t: "hello"})
        

# Generated at 2022-06-24 11:26:59.673967
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(
        "hello",
        start_index = 0,
        end_index = 4,
        content = "hello world"
    )
    if not(token == token):
        raise RuntimeError("token is equal to itself")
    token_other = Token(
        "world",
        start_index = 0,
        end_index = 4,
        content = "hello world"
    )
    if token == token_other:
        raise RuntimeError("token is not equal to another token")


# Generated at 2022-06-24 11:27:04.662728
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    """
    repr() returns a string containing a printable representation of an object.
    This is the same as for class <object>.
    """
    token = Token(1, 2, 3)
    assert repr(token) == "Token(...)", "Test expected to fail."


# Generated at 2022-06-24 11:27:09.362145
# Unit test for method lookup of class Token
def test_Token_lookup():
    assert Token("value", 0, 4, "value").lookup([]) == Token("value", 0, 4, "value")
    assert Token("value", 0, 4, "value").lookup([1]) == Token("value", 0, 4, "value")


# Generated at 2022-06-24 11:27:15.015243
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({'k': 123}, 0, 3, 'k=123')
    assert token._child_keys == {'k': 'k'}
    assert token._child_tokens == {'k': 123}
    assert token._content == 'k=123'

# Generated at 2022-06-24 11:27:18.940559
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    value = "hello"
    start_index = 0
    end_index = 4
    content = "hello"
    st = ScalarToken(value, start_index, end_index, content)
    print(st)


# Generated at 2022-06-24 11:27:24.572141
# Unit test for constructor of class DictToken
def test_DictToken():
    import typesystem
    from typesystem.base import types

    assert issubclass(DictToken, Token)
    assert isinstance(DictToken, type)

    dict_token = DictToken(
        value =  {"key1": 1},
        start_index=0,
        end_index=2,
        content="{'key1': 1}"
    )
    # print(dict_token._value)
    assert isinstance(dict_token, Token)


# Generated at 2022-06-24 11:27:31.815420
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    a = ScalarToken(2, 3, 4)
    assert a.string == ''
    assert a.value == 2
    assert a.start == Position(1, 1, 3)
    assert a.end == Position(1, 1, 4)
    assert a.lookup([]) == 2
    assert a.lookup_key([]) == 2
    assert a._get_position(4) == Position(1, 1, 4)
    assert repr(a) == 'ScalarToken(2)'
    assert a == ScalarToken(2, 3, 4)
    assert hash(a) == hash(2)


# Generated at 2022-06-24 11:27:34.244830
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert Token(0, 0, 0, '').__repr__() == 'Token(0)'


# Generated at 2022-06-24 11:27:36.542412
# Unit test for constructor of class Token
def test_Token():
    from typesystem.parser import Token
    t = Token('class',0,4)
    assert t.string == 'class'



# Generated at 2022-06-24 11:27:44.426535
# Unit test for constructor of class DictToken
def test_DictToken():
    a = {"a":0}
    dict_token = DictToken(a, 1, 2, "3")
    assert dict_token.__dict__ == {"_value": {"a":0}, "_start_index": 1, "_end_index": 2, "_content": "3", "_child_keys": {'a': {'a':0}}, "_child_tokens": {'a': 0}}


# Generated at 2022-06-24 11:27:48.392289
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token(value="foo", start_index=1, end_index=2)
    assert repr(token) == "Token('oo')"
    token = Token(value="foo", start_index=0, end_index=2)
    assert repr(token) == "Token('foo')"



# Generated at 2022-06-24 11:27:56.904516
# Unit test for constructor of class DictToken
def test_DictToken():
    d1 = {"a": 1, "b": 2}
    t1 = type(d1)
    t1_instance = t1()
    print(t1)
    print(t1_instance)
    t1_constructor = t1.__init__
    print(t1_constructor)
    t1_constructor.__annotations__
    t1_constructor.__code__
    t1_constructor.__code__.co_argcount
    t1_constructor.__code__.co_varnames
    t1_constructor.__code__.co_varnames[1:]
    print(t1_constructor.__code__.co_varnames[1:])

# Generated at 2022-06-24 11:28:06.978602
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test 1
    dict_token = DictToken(
        value = {}, start_index = 0, end_index = 0, content = ""
    )
    assert dict_token._child_keys == {}
    assert dict_token._child_tokens == {}
    # Test 2
    dict_token = DictToken(
        value = {'a':2, 'b':3}, start_index = 1, end_index = 2, content = "abc"
    )
    assert dict_token._child_keys == {'a':1, 'b':2}
    assert dict_token._child_tokens == {'a':2, 'b':3}
    # Test 3

# Generated at 2022-06-24 11:28:08.875224
# Unit test for method lookup of class Token
def test_Token_lookup():
    a= [1,2]
    assert a == a


# Generated at 2022-06-24 11:28:13.013104
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = ScalarToken(
        value=None, start_index=1, end_index=2, content="test"
    )
    assert isinstance(token, Token)

    # confirm the behavior of __eq__
    assert token == None
    assert token != None



# Generated at 2022-06-24 11:28:14.573405
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    assert 1 == 2

# Generated at 2022-06-24 11:28:16.603799
# Unit test for method lookup of class Token
def test_Token_lookup():
    """
    Test the method Token.lookup
    """
    assert 1 == 1


# Generated at 2022-06-24 11:28:20.577915
# Unit test for constructor of class DictToken
def test_DictToken():
    value = {"name": "test"}
    start_index = 0
    end_index = 3
    content = "test"
    d = DictToken(value, start_index, end_index, content)
    assert d.value["name"] == "test"

# Generated at 2022-06-24 11:28:23.510751
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    assert ScalarToken(1, 0, 3)._start_index == 0 and ScalarToken(1, 0, 3)._end_index == 3


# Generated at 2022-06-24 11:28:25.423573
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert repr(Token(1, 2, 3)) == "Token(1)"

# Generated at 2022-06-24 11:28:27.303595
# Unit test for constructor of class Token
def test_Token():
    with pytest.raises(NotImplementedError):
        Token("mocked_value", 0, 0, "mocked_content")._get_value()



# Generated at 2022-06-24 11:28:36.418337
# Unit test for constructor of class DictToken
def test_DictToken():
    import typesystem
    position1 = Position(1, 1, 1)
    position2 = Position(1, 2, 2)
    position3 = Position(1, 3, 3)
    position4 = Position(1, 4, 4)
    position5 = Position(1, 5, 5)
    position6 = Position(1, 6, 6)
    position7 = Position(1, 7, 7)
    position8 = Position(1, 8, 8)
    token1 = ScalarToken(1, 1, 1)
    token2 = ScalarToken(2, 2, 2)
    token3 = ScalarToken(3, 3, 3)
    token4 = ScalarToken(4, 4, 4)
    token5 = ScalarToken(5, 5, 5)
    token6 = ScalarToken(6, 6, 6)


# Generated at 2022-06-24 11:28:40.464663
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    expected = "\n    Token('4', 0, 0)\n    "
    actual = repr(ScalarToken(4, 0, 0))
    assert actual == expected


# Generated at 2022-06-24 11:28:44.374491
# Unit test for constructor of class DictToken
def test_DictToken():
    testToken = DictToken(value = {}, start_index = 1, end_index = 2)
    testValue = {'_child_keys': {}, '_child_tokens': {}}
    testExpected = True
    # run test
    assert testToken._value == testValue
    assert testExpected == True


# Generated at 2022-06-24 11:28:54.377336
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    scalar_token = ScalarToken("", 0, 1, "abcd")
    assert scalar_token._get_value() == ""
    assert scalar_token._value == ""
    assert scalar_token._start_index == 0
    assert scalar_token._end_index == 1
    assert scalar_token._content == "abcd"
    assert scalar_token.string == "a"
    assert scalar_token.value == ""
    assert scalar_token.start == Position(1, 1, 0)
    assert scalar_token.end == Position(1, 2, 1)
    assert scalar_token.__repr__() == "ScalarToken('a')"
    assert scalar_token.__eq__(ScalarToken("", 0, 1)) is False

# Generated at 2022-06-24 11:28:55.511039
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({})
    assert not d



# Generated at 2022-06-24 11:29:01.278583
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token1 = DictToken({'name': ScalarToken('A',0,1,{'name': 'A', 'age': 18})}, 0, 3, {'name': 'A', 'age': 18})
    token2 = DictToken({'age': ScalarToken(18,2,3,{'name': 'A', 'age': 18})}, 0, 3, {'name': 'A', 'age': 18})
    token = DictToken({'student': token1}, 0, 7, {'student': {'name': 'A', 'age': 18}})
    keytoken = token2
    token.lookup_key([0])
    assert token.lookup_key([0]) == keytoken

# Generated at 2022-06-24 11:29:05.056584
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    dt = DictToken({"a": 1, "b": 2})
    lt = ListToken([dt])
    assert Token.lookup_key(lt, [0, "a"]) == dt._child_keys["a"]

# Generated at 2022-06-24 11:29:10.709356
# Unit test for constructor of class Token
def test_Token():
    token = Token(value = 5, start_index = 0, end_index = 1)
    assert token.string == ""
    assert token.value == 5
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 1)

    token = Token(value = 5, start_index = 0, end_index = 1, content = "ab")
    assert token.string == "a"
    assert token.value == 5
    assert token.start == Position(1, 1, 0)
    assert tok

# Generated at 2022-06-24 11:29:19.349520
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    import sys
    import io

    # Capture the output.
    capturedOutput = io.StringIO()                  # Create StringIO object
    sys.stdout = capturedOutput                     # and redirect stdout.
    # Call the function.
    item = ScalarToken(value='true', start_index=1, end_index=1, content='')
    item2 = ScalarToken(value='true', start_index=1, end_index=1, content='')
    item==item2
    # Restore stdout.
    sys.stdout = sys.__stdout__
    # Compare `output` and `expected_output`.
    assert capturedOutput.getvalue() == 'True\n'

# Generated at 2022-06-24 11:29:23.280971
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(
        1.3, start_index=0, end_index=1, content="1.23"
    )
    if token.value != 1.3:
        raise Exception("token.value != 1.3")
    if token.string != "1.3":
        raise Exception("token.string != \"1.3\"")
    if token.start.index != 0:
        raise Exception("token.start.index != 0")
    if token.end.index != 1:
        raise Exception("token.end.index != 1")

# Generated at 2022-06-24 11:29:27.704398
# Unit test for constructor of class Token
def test_Token():
    token = Token(1,1,1)
    assert token._value == 1
    assert token._start_index == 1
    assert token._end_index == 1
    assert token._content == ""


# Generated at 2022-06-24 11:29:32.798940
# Unit test for constructor of class ListToken
def test_ListToken():
    lt = ListToken(["string", 42, 3.14, True, False, [1, 2, 3], {"key": "value"}], 0, 6, "['string', 42, 3.14, True, False, [1, 2, 3], {'key': 'value'}]")
    assert lt


# Generated at 2022-06-24 11:29:40.155071
# Unit test for constructor of class ListToken
def test_ListToken():
    tok = ListToken(["1", "2"], 2, 4, content = "123")
    assert tok._get_value() == ["1", "2"]
    assert tok.string == "12"
    assert tok.value == ["1", "2"]
    assert tok.start == Position(1,1,2)
    assert tok.end == Position(1,3,4)
    assert tok.lookup([0]) == "1"
    #assert tok.lookup_key([0,0]) == "1"
    assert tok._get_position(2) == Position(1,1,2)
    tok2 = ListToken(["1", "2"], 2, 4, content = "123")
    assert tok == tok2
    assert not (tok == "1")

# Generated at 2022-06-24 11:29:41.305741
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = Token(None, 0, 0)
    assert token.lookup_key([0, 1, 2]) == token

# Generated at 2022-06-24 11:29:49.301781
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(
        value="testValue",
        start_index=0,
        end_index=9,
        content="testValue",
    )
    assert token._value == "testValue"
    assert token._start_index == 0
    assert token._end_index == 9
    assert token._content == "testValue"
    assert token.string == "testValue"
    assert token.value == "testValue"
    assert token.start == Position(1, 11, 0)
    assert token.end == Position(1, 11, 9)
    assert repr(token) == "ScalarToken('testValue')"
    assert token != token


# Generated at 2022-06-24 11:29:51.483819
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token1 = ScalarToken(value="2", start_index=0, end_index=1)
    assert repr(token1) == "ScalarToken('2')"

# Generated at 2022-06-24 11:29:57.005043
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    value = 'abc'
    s_index = 1
    e_index = 2
    token1 = Token(value, s_index, e_index)
    token2 = Token(value, s_index, e_index)

    assert(token1 == token2)


# Generated at 2022-06-24 11:30:06.571728
# Unit test for constructor of class Token
def test_Token():
    with pytest.raises(NotImplementedError):
        Token(None, 0, 0, "")._get_value()

    with pytest.raises(NotImplementedError):
        Token(None, 0, 0, "")._get_child_token(None)

    with pytest.raises(NotImplementedError):
        Token(None, 0, 0, "")._get_key_token(None)

    with pytest.raises(TypeError):
        Token("", 0, 0, "") == None

    assert Token("", 0, 0, "").start == Position(1, 1, 0)
    assert Token("", 0, 0, "").lookup([]) == Token("", 0, 0, "")


# Generated at 2022-06-24 11:30:08.478413
# Unit test for constructor of class DictToken
def test_DictToken():
    token1=DictToken({'foo': 'bar'})
    assert token1._child_tokens=={'foo': 'bar'}


# Generated at 2022-06-24 11:30:15.813376
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(
        value="test", start_index=0, end_index=0, content="test"
    )
    assert hash(token) == hash("test")


# Generated at 2022-06-24 11:30:24.362803
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    
    t = Token("test",0,3)

    # Test1
    result = t.lookup_key("test")
    expected = "test"
    
    assert result == expected
    
    # Test2
    result = t.lookup_key("test1")
    expected = "test1"
    
    assert result == expected
    
    # Test3
    result = t.lookup_key("test2")
    expected = "test2"
    
    assert result == expected
    
    # Test4
    result = t.lookup_key("test3")
    expected = "test3"
    
    assert result == expected

# Generated at 2022-06-24 11:30:29.287494
# Unit test for constructor of class ListToken
def test_ListToken():
    l = ListToken([1,2,3], 0, 6, content="1234,45,67")
    assert l._get_value() == [1,2,3] and l.string == "1234,45,67" and l._start_index == 0 and l._end_index == 6 and l._content == "1234,45,67" and l._value == [1,2,3]
    #return

test_ListToken()

# Generated at 2022-06-24 11:30:32.655190
# Unit test for constructor of class Token
def test_Token():
    test_Token = Token(1, 2, 3)
    assert repr(test_Token) == "Token(1)"


# Generated at 2022-06-24 11:30:36.140814
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    from json import loads
    from typesystem.parser import Parser
    parser = Parser()
    token = parser.parse(loads('{"a":1}'))
    assert repr(token) == 'Token({"a": 1})'


# Generated at 2022-06-24 11:30:41.374548
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # arrange
    value = 'value'
    start_index = 8
    end_index = 10
    content = 'content'

    # act
    token = Token(value, start_index, end_index, content)

    # assert
    assert token.__repr__() == "Token(%s)" % repr(token.string)


# Generated at 2022-06-24 11:30:47.212943
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken(value = {KeyToken(value = 'a', start_index = 1, end_index = 1, content = 'asdf'): ValueToken(value = 'a', start_index = 1, end_index = 1, content = 'asdf')}, start_index = 1, end_index = 1, content = 'asdf')
    assert t._value == {KeyToken(value = 'a', start_index = 1, end_index = 1, content = 'asdf'): ValueToken(value = 'a', start_index = 1, end_index = 1, content = 'asdf')}
    assert t._start_index == 1
    assert t._end_index == 1
    assert t._content == 'asdf'

# Generated at 2022-06-24 11:30:54.549363
# Unit test for constructor of class Token
def test_Token():
    t = Token("value", 0, 4, "value")
    assert t._value == "value"
    assert t._start_index == 0
    assert t._end_index == 4
    assert t._content == "value"

# Generated at 2022-06-24 11:31:01.443692
# Unit test for constructor of class Token
def test_Token():
    token = Token('x', 0, 0, "")
    assert token.string == 'x'
    assert token.value == 'x'
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)
    assert str(token) == "Token('x')"
    assert token == Token('x', 0, 0, "")
    assert token != Token('y', 0, 0, "")
    assert token != Token('x', 1, 0, "")
    assert token != Token('x', 0, 1, "")

# Generated at 2022-06-24 11:31:03.342756
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("", 0, 1, "")
    assert token._value == ""


# Generated at 2022-06-24 11:31:04.681748
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken(1,2,3,4)


# Generated at 2022-06-24 11:31:09.075948
# Unit test for constructor of class Token
def test_Token():
    start_index = 1
    end_index = 10
    content = "content"
    test_1 = Token(None, start_index, end_index, content)
    assert test_1._value == None
    assert test_1._start_index == start_index
    assert test_1._end_index == end_index
    assert test_1._content == content



# Generated at 2022-06-24 11:31:11.558297
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    t = ScalarToken("value", 0, 2, "content")
    assert t.string == "con"
    assert t.value == "value"
    assert t.start == Position(1, 1, 0)
    assert t.end == Position(1, 4, 2)


# Generated at 2022-06-24 11:31:15.294602
# Unit test for constructor of class DictToken
def test_DictToken():
    a=DictToken('start_index','end_index','content')
    assert a._start_index=='start_index'
    assert a._end_index=='end_index'
    assert a._content=='content'


# Generated at 2022-06-24 11:31:18.293188
# Unit test for constructor of class DictToken
def test_DictToken():
    import ast
    d = {}
    d1 = DictToken(d, 0, 0)
    assert(d1._child_tokens == {}), "Test for DictToken constructor failed"
    print("Test for DictToken constructor passed")


# Generated at 2022-06-24 11:31:21.826499
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    x_value = "dummy"
    x_start_index = 0
    x_end_index = 2
    x_content = ""
    x = Token(x_value, x_start_index, x_end_index, x_content)
    clone = Token(x_value, x_start_index, x_end_index, x_content)
    assert x == clone
    assert not x != clone

# Generated at 2022-06-24 11:31:30.936215
# Unit test for constructor of class DictToken
def test_DictToken():
    # Create empty DictToken with value {} and content ""
    tmp = DictToken({}, 0, 0, "")
    # 'value' of tmp equals {}, 'start_index' of tmp equals 0, and 'content' of tmp equals ""
    assert tmp._value == {}
    assert tmp._start_index == 0
    assert tmp._content == ""
    # Create empty DictToken with value {}, start_index 1, and content abc
    tmp = DictToken({}, 1, 1, "abc")
    # 'value' of tmp equals {}, and 'content' of tmp equals "abc"
    assert tmp._value == {}
    assert tmp._content == "abc"
    # Create DictToken with value {'a': 1, 'b': 2} and content "ab"
    # Note that 'start_index' and 'end_index