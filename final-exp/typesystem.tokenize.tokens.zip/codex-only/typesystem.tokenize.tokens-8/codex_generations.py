

# Generated at 2022-06-24 11:21:26.381667
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(1, 2, 3)
    assert hash(token) == hash(1)

# Generated at 2022-06-24 11:21:29.515106
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    # Case 1
    token = ScalarToken(None, 0, 0)
    assert token._value == None
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""


# Generated at 2022-06-24 11:21:34.472850
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    content = "{\"a\":{\"b\":\"c\"},\"d\":{\"e\":\"f\"}}"
    sample = Token({"a": {"b": "c"}, "d": {"e": "f"}}, 0, len(content) - 1, content)
    token = sample.lookup_key([0, ("a", "b")])
    assert token.__repr__() == "ScalarToken('\"b\"')"



# Generated at 2022-06-24 11:21:37.580690
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({}).value == {}
    assert DictToken({1: '1'}).value == {1: '1'}

# Generated at 2022-06-24 11:21:45.917570
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken(1,2,3, None) == DictToken(1,2,3, None)
    assert DictToken(1,2,3, None) != DictToken(2,2,3, None)
    assert DictToken(1,2,3, None) != DictToken(1,3,3, None)
    assert DictToken(1,2,3, None) != DictToken(1,2,4, None)
    assert DictToken(1,2,3, None) != DictToken(1,2,3, True)
    assert DictToken(1,2,3, None) != ScalarToken(1,2,3, None)

# Generated at 2022-06-24 11:21:49.170213
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    class TestToken(Token):
        def __eq__(self, other):
            return isinstance(other, TestToken)

    instance = TestToken(None, 0, 0)
    assert repr(instance) == "TestToken('{}')"

# Generated at 2022-06-24 11:21:55.861928
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert hash(ScalarToken(0, 0, 0)) == hash(0)
    assert hash(ScalarToken(1, 0, 0)) == hash(1)
    assert hash(ScalarToken(2, 0, 0)) == hash(2)
    assert hash(ScalarToken(3, 0, 0)) == hash(3)
    assert hash(ScalarToken(4, 0, 0)) == hash(4)
    assert hash(ScalarToken(5, 0, 0)) == hash(5)
    assert hash(ScalarToken(6, 0, 0)) == hash(6)
    assert hash(ScalarToken(7, 0, 0)) == hash(7)
    assert hash(ScalarToken(8, 0, 0)) == hash(8)

# Generated at 2022-06-24 11:21:57.041131
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    '''
    test method __hash__ of class ScalarToken
    '''
    assert True


# Generated at 2022-06-24 11:22:05.006449
# Unit test for constructor of class ListToken
def test_ListToken():
    assert type(EmissionRateToken) == type(ListToken)
    assert type(EmissionRateToken) == ListToken or type(EmissionRateToken) == ListToken
    assert type(EmissionRateToken) == ListToken or type(EmissionRateToken) == ListToken
    assert type(AmountToken) == type(ListToken)
    assert type(AmountToken) == ListToken or type(AmountToken) == ListToken
    assert type(AmountToken) == ListToken or type(AmountToken) == ListToken
    assert type(DensityToken) == type(ListToken)
    assert type(DensityToken) == ListToken or type(DensityToken) == ListToken
    assert type(DensityToken) == ListToken or type(DensityToken) == ListToken
    assert type(EmissionRateToken) != type(AmountToken)

# Generated at 2022-06-24 11:22:13.557495
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    import typesystem
    from typesystem import types

    token = Token(
        value="example", start_index=0, end_index=1, content="example content"
    )
    assert not token == types.String("example")
    assert token == token
    assert not token == "example"
    token2 = Token(
        value="example", start_index=1, end_index=1, content="example content"
    )
    assert not token == token2
    token3 = Token(
        value="example", start_index=0, end_index=2, content="example content"
    )
    assert not token == token3
    assert token == Token(
        value="example", start_index=0, end_index=1, content="example content"
    )

# Generated at 2022-06-24 11:22:22.744676
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    # constructor
    token = ScalarToken("foo", 0, 2, content = "foobar")
    assert token is not None
    assert token._value == "foo"
    assert token._start_index == 0
    assert token._end_index == 2
    assert token._content == "foobar"
    assert token.string == "foo"
    assert token.value == "foo"
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 4, 2)

    # __repr__
    assert repr(token) == "ScalarToken('foo')"

    # override __eq__
    assert token == ScalarToken("foo", 0, 2, content = "foobar")
    assert token != ScalarToken("bar", 0, 2, content = "foobar")

# Generated at 2022-06-24 11:22:30.365204
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert hash(ScalarToken(1, 0, 0)) == hash(1)
    assert hash(ScalarToken([], 0, 0)) == hash([])
    assert hash(ScalarToken({}, 0, 0)) == hash({})
    assert hash(ScalarToken(ScalarToken(1, 0, 0), 0, 0)) == hash(1)
    assert hash(ScalarToken(DictToken({}, 0, 0), 0, 0)) == hash({})
    assert hash(ScalarToken(ListToken([], 0, 0), 0, 0)) == hash([])

# Generated at 2022-06-24 11:22:37.603728
# Unit test for constructor of class Token
def test_Token():
    token = Token(10, 10, 15)
    assert token.start.line_no == 1
    assert token.start.column_no == 11
    assert token.start.index == 10
    assert token.end.line_no == 1
    assert token.end.column_no == 16
    assert token.end.index == 15
    assert token.string == ""
    assert token.value == None
    assert token.lookup([]) == None
    assert token.lookup_key([]) == None


# Generated at 2022-06-24 11:22:44.281904
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    content = """
This is the sentence.
This is the second sentence.
    """
    token = ScalarToken("sentence.", 6, 14, content)
    check = "sentence."
    check_start = (2, 3)
    check_end = (2, 11)
    assert token.string == check
    assert token.value == check
    assert token.start == check_start
    assert token.end == check_end
    assert token.lookup([]) == token


# Generated at 2022-06-24 11:22:46.820498
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert ScalarToken(1, 0, 0).__hash__() == 1


# Generated at 2022-06-24 11:22:49.659267
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
  token = ScalarToken(value=123,start_index=1,end_index=2)
  assert token.__repr__() == "ScalarToken('12')"


# Generated at 2022-06-24 11:22:59.249199
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    test = {}
    test["data"] = []
    test["data"].append({
        "id": 1,
        "source": {
            "id": 1,
            "name": "test1"
        },
        "target": {
            "id": 2,
            "name": "test2"
        }
    })
    test["data"].append({
        "id": 2,
        "source": {
            "id": 2,
            "name": "test3"
        },
        "target": {
            "id": 3,
            "name": "test4"
        }
    })
    token = DictToken(test, 0, 0)
    result_token = token.lookup_key(["data", 0, "source", "id"])
    assert result_token.value == 1

# Generated at 2022-06-24 11:23:00.696710
# Unit test for constructor of class Token
def test_Token():
    token = Token(10, 10, 10)
    try:
        token._get_value()
    except NotImplementedError:
        pass
    except:
        assert False


# Generated at 2022-06-24 11:23:01.867556
# Unit test for constructor of class ListToken
def test_ListToken():
    object = ListToken(["1", "2"], 0, 1)
    assert object._get_value() == ["1", "2"]


# Generated at 2022-06-24 11:23:04.510230
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test with Token instance
    assert Token("", 1, 2) == Token("", 1, 2)

    # Test with not Token instance
    assert Token("", 1, 2) != 1



# Generated at 2022-06-24 11:23:15.402294
# Unit test for method lookup of class Token
def test_Token_lookup():
    class ExampleToken(Token):
        def __init__(self, value, start_index, end_index):
            super().__init__(
                value, start_index, end_index, content="hello world!\nGood bye world!"
            )

    tokens = [
        ExampleToken(value="hello", start_index=0, end_index=5),
        ExampleToken(value="world!", start_index=6, end_index=11),
        ExampleToken(value="Good", start_index=13, end_index=17),
        ExampleToken(value="bye", start_index=18, end_index=21),
        ExampleToken(value="world!", start_index=22, end_index=27),
    ]

# Generated at 2022-06-24 11:23:16.998114
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(42, 0, 1, "42")
    assert hash(token) == hash(42), "hash(token) == hash(42)"


# Generated at 2022-06-24 11:23:21.664493
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("str", 0, 2)
    assert_equal(token.string, "str")
    assert_equal(token.start.line, 1)
    assert_equal(token.start.column, 1)
    assert_equal(token.end.line, 1)
    assert_equal(token.end.column, 4)


# Generated at 2022-06-24 11:23:29.870677
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken([], 0, 0, "").end == Position(1, 1, 0)
    assert ListToken([], 0, 0, "").start == Position(1, 1, 0)
    assert ListToken([], 0, 0, "")._end_index == 0
    assert ListToken([], 0, 0, "")._start_index == 0
    assert ListToken([], 0, 0, "")._value == []
    # assert ListToken([], 0, 0, "").string == ""
    assert ListToken([Token("", Position(1, 1, 0), Position(1, 1, 0))], 0, 0, "").end == Position(1, 1, 0)

# Generated at 2022-06-24 11:23:40.762281
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    from typesystem._token import Token
    from typesystem._token import ScalarToken
    from typesystem._token import ListToken
    from typesystem._token import DictToken
    from typesystem.base import Position
    t = Token(['foo', ScalarToken('bar', 0,0, 'bar')], 0, 0, '')
    assert str(t) == "Token(['foo', ScalarToken('bar')])"
    t = Token({}, 0, 0, '')
    assert str(t) == "Token({})"
    t = Token('', 0, 0, '')
    assert str(t) == "Token('')"
    t = Token(None, 0, 0, '')
    assert str(t) == "Token(None)"
    t = Token(Position(1, 1, 1), 0, 0, '')

# Generated at 2022-06-24 11:23:45.894404
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    """Test __repr__
    """
    # Construct a sample Token object
    token = Token(None, 0, 1, content='abc')
    # Construct a sample string object
    expected_result = "Token('a')"

    actual_result = repr(token)

    assert actual_result == expected_result


# Generated at 2022-06-24 11:23:51.520585
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = ListToken([1, 2, 3], 0, 1, [1, 2, 3])

    assert token.lookup_key([0]) == token.lookup([0])

# Generated at 2022-06-24 11:23:56.134769
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Setup
    tok = Token(b"", 0, 1, content=b"a")

    # Exercise
    s = repr(tok)

    # Verify
    assert s == "Token('a')"



# Generated at 2022-06-24 11:24:01.045245
# Unit test for constructor of class ListToken
def test_ListToken():
    s = "['elem1', 'elem2']"
    start = 0
    end = len(s) - 1

    # ***** Given *****
    # ******************

    # ***** When *****
    token = ListToken([], start, end)

    # ***** Then *****
    assert token._start_index == start
    assert token._end_index == end


# Generated at 2022-06-24 11:24:04.850432
# Unit test for method lookup of class Token
def test_Token_lookup():
    # Given
    token_test = Token(1,1,1,"test")
    token_test_test = Token(1,1,1,"test")
    assert token_test.end.index == 1
    # When
    token_test_test = token_test.lookup(1)
    # Then
    assert token_test.end.index == 1



# Generated at 2022-06-24 11:24:06.258860
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {"a": 1, "b": 2}
    token = DictToken(d, 0, 2, "a 1 b 2")


# Generated at 2022-06-24 11:24:07.479565
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    print(repr(Token(None, 0, 0)))

# Generated at 2022-06-24 11:24:14.963880
# Unit test for method lookup of class Token
def test_Token_lookup():
    assert Token(1, 1, 2).lookup([]) == Token(1, 1, 2)
    assert Token({'foo': Token(1, 1, 2)}, 1, 2).lookup([]) == Token({'foo': Token(1, 1, 2)}, 1, 2)
    assert Token({'foo': Token(1, 1, 2)}, 1, 2).lookup(['foo']) == Token(1, 1, 2)
    assert Token([Token(1, 1, 2)], 1, 2).lookup([]) == Token([Token(1, 1, 2)], 1, 2)
    assert Token([Token(1, 1, 2)], 1, 2).lookup([0]) == Token(1, 1, 2)
    print("Function test_Token_lookup passes successfully!")


# Generated at 2022-06-24 11:24:23.822182
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    content = '{"day": {"one": 1}, "month": {"two": 2}, "year": {"three": 3}}'
    _dict_ = json.loads(content)
    _tokens_ = {k: ScalarToken(v, len(content), len(content)) for k, v in _dict_.items()}
    assert isinstance(_tokens_, dict)
    # print(repr(_tokens_))
    _dict_tokens_ = DictToken(_tokens_, 0, len(content), content=content)
    # print(repr(_dict_tokens_))
    x = _dict_tokens_.lookup_key([0])
    # print(repr(x))
    assert isinstance(x, Token)

# Generated at 2022-06-24 11:24:26.546977
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    a = Token(1, 2, 3, "abc")
    assert a == Token(1, 2, 3, "abc")
    assert not a == Token(1, 2, 4, "abc")


# Generated at 2022-06-24 11:24:30.728488
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(value=123, start_index=0, end_index=2)
    assert token.__repr__() == "ScalarToken('123')"

# Generated at 2022-06-24 11:24:32.709869
# Unit test for constructor of class DictToken
def test_DictToken():
    v = DictToken({'a':1},1,1,'abc')
    assert v._value == {'a':1}
    assert v._start_index == 1
    assert v._end_index == 1
    assert v._content == "abc"


# Generated at 2022-06-24 11:24:37.124470
# Unit test for constructor of class ListToken
def test_ListToken():
    t = ListToken(
            [ScalarToken(1,1,1), ScalarToken(2,2,2)],
            0, 1
            )
    assert t.lookup_key([]) == ListToken(
            [ScalarToken(1,1,1), ScalarToken(2,2,2)],
            0, 1
            )

# Generated at 2022-06-24 11:24:38.639908
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken([1, 2, 3], 0, 0)
    assert token.lookup([0]) == ScalarToken(1, 0, 0)

# Generated at 2022-06-24 11:24:41.192029
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    x = Token("", 0, 0)
    assert x.__repr__() == "Token('')"


# Generated at 2022-06-24 11:24:48.963204
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.exceptions import ValidationError

    from .helpers import assert_no_validation_errors

    token1 = Token(None, 0, 1, "")
    assert not (token1 == None)
    assert token1 == token1
    token2 = Token(None, 1, 0, "")
    token3 = Token(None, 1, 0, "")
    assert not (token2 == token3)
    token2 = Token(None, 0, 1, "")
    assert token1 == token2
    token1 = Token(0, 0, 0, "")
    token2 = Token(1, 0, 0, "")
    assert not (token1 == token2)
    token2 = Token(0, 0, 0, "")
    assert token1 == token2

# Generated at 2022-06-24 11:24:58.043687
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    class sToken(Token):
        def _get_value(self):
            return self._value
    class dToken(Token):
        def _get_value(self):
            return {key_token._get_value(): value_token._get_value() for key_token, value_token in self._value.items()}
    class lToken(Token):
        def _get_value(self):
            return [token._get_value() for token in self._value]
    s = sToken('a', 0, 5, 'abcde')
    d = dToken({'a':'b'}, 0, 5, 'abcde')
    l = lToken(['a', 'b'], 0, 5, 'abcde')
    assert repr(s) == "ScalarToken('a')"

# Generated at 2022-06-24 11:25:06.597999
# Unit test for constructor of class ListToken
def test_ListToken():
    str1 = b'[1,2,3]'
    token1 = ListToken([ScalarToken(1,0,0),ScalarToken(2,3,3),ScalarToken(3,6,6)],0,8,str1)
    ret_value = token1._get_value()
    assert ret_value == [1,2,3]

    # test for _get_child_token
    ret_token = token1._get_child_token(0)
    assert ret_token._value == 1
    assert ret_token.string == b'1'
    assert ret_token._start_index == 0
    assert ret_token._end_index == 0


# Generated at 2022-06-24 11:25:11.734078
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(value=None, start_index=0, end_index=0)
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)
    

# Generated at 2022-06-24 11:25:22.161548
# Unit test for method lookup of class Token
def test_Token_lookup():
    class TestToken(Token):
        def __init__(self, value: typing.Any, start_index: int, end_index: int, content: str = "") -> None:
            super().__init__(value, start_index, end_index, content)
            self._child_tokens = {k: v for k, v in self._value.items()}

        def _get_value(self) -> typing.Any:
            return self._value

        def _get_child_token(self, key: typing.Any) -> Token:
            return self._child_tokens[key]

        def _get_key_token(self, key: typing.Any) -> Token:
            return None

# Generated at 2022-06-24 11:25:29.973488
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """Test __eq__ method of Token"""
    token_inst = Token(value="val",start_index= 0,end_index= 0,content="str")
    other = ""

    ret_value = token_inst.__eq__(other) # __eq__ method return type is bool
    assert type(ret_value) is bool
    assert ret_value == False


# Generated at 2022-06-24 11:25:31.761175
# Unit test for constructor of class Token
def test_Token():
    t = Token()
    assert t is not None



# Generated at 2022-06-24 11:25:38.776895
# Unit test for method lookup of class Token
def test_Token_lookup():
    import json
    string = json.dumps({"hello": [1, 2, 3]})
    dict_token = DictToken({}, 0, 0, string)
    assert dict_token.lookup([0]) == dict_token._value[0]
    assert dict_token.lookup([0, 1]) == dict_token._value[0]._value[1]


# Generated at 2022-06-24 11:25:49.880911
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # Initialize a class instance of Token
    t = Token
    t._content = '{"a":["b", "c"]}'
    t._child_keys = {k._value: k for k in t._value.keys()}
    t._child_tokens = {k._value: v for k, v in t._value.items()}

    # Call the method lookup_key of class Token
    t.lookup_key([0])
    assert t._content == '{"a":["b", "c"]}'
    assert t._child_keys == {k._value: k for k in t._value.keys()}
    assert t._child_tokens == {k._value: v for k, v in t._value.items()}


# Generated at 2022-06-24 11:25:53.847067
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
  # Create the object
  obj = ScalarToken(None, 0, 0)
  
  # Run the method
  result = obj.__hash__()
  
  # Compare the results
  assert result == hash(obj._value)

# Generated at 2022-06-24 11:25:55.342038
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token(123, 4, 7, "abcd")
    assert repr(token) == "Token(123)"

# Generated at 2022-06-24 11:25:59.184285
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    assert ScalarToken(2, 3, 4, content="aabbbccccc").string == "ccc"


# Generated at 2022-06-24 11:26:05.136704
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    print("test_ScalarToken___hash__")
    token1 = ScalarToken(1, 1, 1)
    token2 = ScalarToken(1, 1, 1)
    token3 = token1
    assert token1.__hash__() == hash(1)
    assert token2.__hash__() == hash(1)
    assert token1.__hash__() == token2.__hash__()
    assert token1.__hash__() == token3.__hash__()
    # assert token1.__hash__() == token3._get_value().__hash__() # this test fails


# Generated at 2022-06-24 11:26:10.021299
# Unit test for constructor of class ListToken
def test_ListToken():
    l = ListToken(value=[], start_index=0, end_index=0, content="")
    assert l._value == []
    assert l._start_index == 0
    assert l._end_index == 0
    assert l._content == ""


# Generated at 2022-06-24 11:26:14.584005
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = Token('3', 1, 2, '1,2,3')
    assert token.lookup_key([0,1]) == token
    assert token.lookup_key([0]) == token
    assert token.lookup_key([1]) == token
    assert token.lookup_key([2]) == token
    assert token.lookup_key([]) == token

# Generated at 2022-06-24 11:26:17.255466
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken()
    print(token)

# Unit Test for function _get_value of class DictToken

# Generated at 2022-06-24 11:26:22.764738
# Unit test for method lookup of class Token
def test_Token_lookup():
    # Given a list Token, when I lookup a child token with an index, then I should
    # receive the child token corresponding to the index

    # Setup
    child_token = ScalarToken(value='a', start_index=0, end_index=0)
    list_token = ListToken(value=[child_token], start_index=0, end_index=0)

    # Exercise
    token = list_token.lookup([0])

    # Verify
    assert(token == child_token)


# Generated at 2022-06-24 11:26:28.105092
# Unit test for constructor of class Token
def test_Token():
    print("Testing constructor for Token class")
    t = Token('Value', 1, 2, 'Content')
    assert(t._value == 'Value')
    assert(t._start_index == 1)
    assert(t._end_index == 2)
    assert(t._content == 'Content')
    print("Testing constructor for Token class: Passed!")


# Generated at 2022-06-24 11:26:30.146072
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    def _test():
        token = ScalarToken(3, 0, 0)
        assert hash(token) == hash(3)
    _test()



# Generated at 2022-06-24 11:26:38.784500
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # generate an instance of class Token with content 
    # "Some new content"
    token = Token("Some new content", 0, 15, "Some new content")
    # call method lookup_key on instance token with parameter
    # [0, 0] to get a token with string "Some"
    token1 = token.lookup_key([0,0])
    # check the string in token1 is "Some"
    assert token1.string == "Some"



# Generated at 2022-06-24 11:26:41.896120
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token("", 0, 0)
    t2 = Token("", 0, 0)
    assert t1 == t2
    t3 = Token("", 5, 10, "abcde")
    assert t1 != t3


# Generated at 2022-06-24 11:26:45.726049
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("test", 1, 8, content="test_test")
    assert token.string == "test"
    assert token.value == "test"
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 4, 3)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert token.__repr__() == "ScalarToken('test')"
    assert token.__eq__(token) == True
    assert token.__eq__(ScalarToken("test_test", 1, 9, content="test_test")) == False

# Generated at 2022-06-24 11:26:51.526302
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    # test for a constructor that take in a single value
    t1 = ScalarToken(1, 0, 1)
    assert t1._value == 1
    assert t1._start_index == 0
    assert t1._end_index == 1
    assert t1._content == ""


# Generated at 2022-06-24 11:26:58.567496
# Unit test for constructor of class ListToken
def test_ListToken():
    l = ListToken(
        [
            ScalarToken("Bob", 0, 2),
            ScalarToken("Alice", 3, 7),
        ],
        0,
        7,
        "['Bob','Alice']"
    )
    assert l._value[0]._value == "Bob"
    assert l._value[0]._start_index == 0
    assert l._value[0]._end_index == 2

    assert l._value[1]._value == "Alice"
    assert l._value[1]._start_index == 3
    assert l._value[1]._end_index == 7



# Generated at 2022-06-24 11:27:01.905284
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    tok = Token("value", 12, 17, content="abcdefghijklmnopqrstuvwxyz")
    assert repr(tok) == "Token('fghij')"

# Generated at 2022-06-24 11:27:07.061965
# Unit test for method lookup of class Token
def test_Token_lookup():
    dt = DictToken()
    assert dt.lookup([0]) == dt._child_tokens[0]


# Generated at 2022-06-24 11:27:12.194308
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(12345, 0, 1)
    assert token.__hash__() == 12345


# Generated at 2022-06-24 11:27:19.214668
# Unit test for method lookup of class Token
def test_Token_lookup():
    # Setup fixture
    token_child = ScalarToken("child", 0, 0)
    token_parent = ListToken([token_child], 0, 0)

    # Exercise SUT
    result = token_parent.lookup([0])
    # Verify outcome
    assert result == token_child


# Generated at 2022-06-24 11:27:25.166551
# Unit test for constructor of class Token
def test_Token():
    # Given
    start_index = 0
    end_index = 10
    content = "hello world"
    token = Token(None, start_index, end_index, content)

    # When
    actual = token.string
    actual_start = token.start
    actual_end = token.end

    # Then
    assert actual == "hello world"
    assert actual_start == Position(1, 1, 0)
    assert actual_end == Position(1, 11, 10)


# Generated at 2022-06-24 11:27:33.884983
# Unit test for constructor of class DictToken
def test_DictToken():
    x = {'a': 2, 'b': 3}
    x_token = DictToken(x, 0, 0, "a: 2\nb: 3")
    assert x_token._child_keys == {'a': 'a', 'b': 'b'}
    assert x_token._child_tokens == {'a': 2, 'b': 3}
    assert x_token._value == {'a': 2, 'b': 3}
    assert x_token._start_index == 0
    assert x_token._end_index == 0
    assert x_token._content == "a: 2\nb: 3"
    # test __repr__
    assert repr(x_token) == "DictToken({'a': 2, 'b': 3})"

# Generated at 2022-06-24 11:27:35.653809
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    t = ScalarToken('a', 0, 1)
    assert repr(t) == "ScalarToken('a')"
    assert t.string == 'a'
    assert t.value == 'a'


# Generated at 2022-06-24 11:27:43.867063
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    start_index = 0
    end_index = 0
    content = "content"
    value = 'value'
    
    token1 = Token(value, start_index, end_index, content)
    token2 = Token(value, start_index, end_index, content)
    assert(token1 == token2)
    
    token2._end_index = 1
    assert(token1 != token2)


# Generated at 2022-06-24 11:27:50.100496
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    x = Token(
        value='value',
        start_index=0,
        end_index=0,
        content='content'
    )
    assert repr(x) == "Token('content')"

# Generated at 2022-06-24 11:27:54.085263
# Unit test for method lookup of class Token
def test_Token_lookup():
    string = "Hello, world!"
    token = ListToken(["Hello", ",", "world!"], 0, 13, string)
    assert token.lookup([0, 2]).string == "l"


# Generated at 2022-06-24 11:27:58.610917
# Unit test for constructor of class ListToken
def test_ListToken():
    a = Token(5, 2, 3, "a")
    b = Token(7, 4, 5, "b")
    listToken = ListToken([a, b], 1, 6, "a,b")
    assert listToken.string == "a,b"
    assert listToken.value == [5, 7]
    assert listToken.start == Position(1, 1, 1)
    assert listToken.end == Position(1, 4, 6)
    assert listToken.lookup([1]) == b
    assert listToken.lookup([-1]) == b
    assert listToken.lookup([-2]) == a
    assert listToken.lookup([-3]) == a
    assert listToken.lookup_key([0]) == a
    assert listToken.lookup_key([1]) == b

# Generated at 2022-06-24 11:28:02.334758
# Unit test for constructor of class ListToken
def test_ListToken():
    a = ListToken([1, 2, 3], 0, 1, "")
    assert a._value == [1, 2, 3]
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == ""


# Generated at 2022-06-24 11:28:06.780402
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(dict(a = 1, b = 2), 0, 10, 'abc')
    assert token._get_value() == dict(a = 1, b = 2)
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 10, 10)
    assert token.string == 'abc'


# Generated at 2022-06-24 11:28:09.254570
# Unit test for constructor of class DictToken
def test_DictToken():
	assert DictToken(value = {0:'aa', 1:'bb'}, start_index=0, end_index=2)

# Generated at 2022-06-24 11:28:11.884362
# Unit test for constructor of class Token
def test_Token():
	t = Token("test", 0, 3)
	s = t.string
	assert s == "test"


# Generated at 2022-06-24 11:28:12.590998
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
  pass


# Generated at 2022-06-24 11:28:25.666234
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = ListToken(
        [
            DictToken({ScalarToken(0, 0, 0): ScalarToken(1, 0, 0)}),
            DictToken({ScalarToken(0, 0, 0): ScalarToken(2, 0, 0)}),
        ],
        0,
        0,
        "",
    )
    assert token.lookup_key([0]) == ScalarToken(0, 0, 0)
    assert token.lookup_key([0, 0]) == DictToken(
        {ScalarToken(0, 0, 0): ScalarToken(1, 0, 0)}, 0, 0, ""
    )
    assert token.lookup_key([0, 0, 0]) == ScalarToken(0, 0, 0)

# Generated at 2022-06-24 11:28:32.010700
# Unit test for method lookup of class Token
def test_Token_lookup():
    # Setup
    string = "ab"
    char1 = ScalarToken(string[0], 0, 0, string)
    char2 = ScalarToken(string[1], 1, 1, string)
    token = ListToken([char1, char2], 0, 1, string)

    index = [0]

    # Test
    result = token.lookup(index)

    # Verify
    assert result == ScalarToken(string[0], 0, 0, string)


# Generated at 2022-06-24 11:28:39.218845
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    value1 = 1.0
    start_index1 = 0
    end_index1 = 1
    content1 = '1.0'

    token = ScalarToken(value1, start_index1, end_index1, content1)
    assert(token._value == value1)
    assert(token._start_index == start_index1)
    assert(token._end_index == end_index1)
    assert(token._content == content1)
    assert(token.string == value1)
    assert(token.value == value1)

    value2 = '1.0'
    start_index2 = 0
    end_index2 = 1
    content2 = '1.0'

    token = ScalarToken(value2, start_index2, end_index2, content2)

# Generated at 2022-06-24 11:28:41.603489
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken({"obj1":dict1, "obj2":dict2}, 0, 1)


# Generated at 2022-06-24 11:28:52.910615
# Unit test for method __repr__ of class Token

# Generated at 2022-06-24 11:28:58.629435
# Unit test for method lookup of class Token
def test_Token_lookup():
    from function.parse_yaml import ParsedYaml
    from function.tokenize import tokenize
    a = ParsedYaml([])
    yaml_string = """
    key: value
    key2:
        key2.1: 1
        key2.2: 2
    """
    token = tokenize(yaml_string)
    result = a.assign(token, 'key','key2','key2.1','key2.2','key3')
    assert result == {'key': 'value', 'key2': {'key2.1': 1, 'key2.2': 2}}

# Generated at 2022-06-24 11:29:02.250051
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = ListToken(value=None, start_index=0, end_index=0, content=None)
    assert token.lookup([0]) == None
    assert token.lookup([]) == token


# Generated at 2022-06-24 11:29:06.040061
# Unit test for constructor of class DictToken
def test_DictToken():
    # Token(self, value: typing.Any, start_index: int, end_index: int, content: str = "")
    tok = Token('a', 0, 1)
    # 
    tok_dict = DictToken({tok: tok}, 0, 2, 'content')
    print(tok_dict)


# Generated at 2022-06-24 11:29:08.156307
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("foo", 0, 2)
    assert str(token) == "ScalarToken('foo')"
    assert token.value == "foo"



# Generated at 2022-06-24 11:29:11.070947
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
  '''
  Description: Testing Token lookup_key
  '''
  # create token
  token = Token(1, 2, 3, '123')
  print(token.lookup_key([0]))
  assert token.lookup_key([0]) == token
  assert token.start.index == 2
  assert token.end.index == 3

# Generated at 2022-06-24 11:29:16.057629
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken('a', 'b', 'c', key='v')
    assert token._value == 'a'
    assert token._start_index == 'b'
    assert token._end_index == 'c'
    assert token._content == 'v'

# Generated at 2022-06-24 11:29:25.782686
# Unit test for method __eq__ of class Token
def test_Token___eq__():  
    value = "abcd"
    start_index = 0
    end_index = 3
    content = "abcd"
    token = Token(value, start_index, end_index, content)

    assert token._value == value and token._start_index == start_index and token._end_index == end_index and token._content == content and token._get_value() == None and token.string == "abcd" and token.value == None and token.start == Position(1, 5, 3) and token.end == Position(1, 5, 3) and token.lookup(index, 0) == None and token.lookup_key(index, 0) == None
    
if __name__ == '__main__':
    test_Token___eq__()

# Generated at 2022-06-24 11:29:35.747475
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("a", 0, 0, "b")
    assert token.string == "b"
    assert token.value == "a"
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert token == ScalarToken("a", 0, 0, "b")
    assert token != ScalarToken("a", 0, 0, "c")
    assert token != ScalarToken("b", 0, 0, "b")
    assert token != ScalarToken("b", 0, 0, "c")
    assert token != ScalarToken("b", 1, 0, "c")
    assert token != ScalarToken("b", 0, 1, "c")


# Generated at 2022-06-24 11:29:38.060098
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    a = ScalarToken(1,2,3)
    assert a._start_index == 2
    assert a._end_index == 3
    assert a._value == 1


# Generated at 2022-06-24 11:29:44.541514
# Unit test for constructor of class Token
def test_Token():
    token = Token(2, 3, 4)
    assert token._value == 2
    assert token._start_index == 3
    assert token._end_index == 4
    assert token._content == ""

    token = Token('asdsa', 3, 4, 'Skjnjn')
    assert token._value == 'asdsa'
    assert token._start_index == 3
    assert token._end_index == 4
    assert token._content == 'Skjnjn'



# Generated at 2022-06-24 11:29:50.420449
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert repr(ScalarToken(1, 1, 5, content="12345")) == "ScalarToken('12345')"
    assert repr(DictToken({}, 1, 5, content="12345")) == "DictToken('12345')"
    assert repr(ListToken([], 1, 5, content="12345")) == "ListToken('12345')"


# Generated at 2022-06-24 11:30:02.125608
# Unit test for constructor of class Token
def test_Token():
    value = 1
    content = ""
    start_index = 0
    end_index = 0
    token = Token(value, start_index, end_index, content)
    assert token.string == ""
    assert str(token) == "Token('')"
    assert token.value == token._get_value()
    assert token.start == token._get_position(start_index)
    assert token.end == token._get_position(end_index)
    assert token.lookup(index=[]) == token
    assert token.lookup_key(index=[]) == token
    assert token.lookup(index=[1]) == token._get_child_token(key=1)
    assert token.lookup_key(index=[1]) == token._get_key_token(key=1)

# Generated at 2022-06-24 11:30:06.384144
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    
    key_list = [1, 2, 3]
    content = "this is key 3"
    start_index = 11
    end_index = 13
    _value = "this is key 3"
    token = Token(_value, start_index, end_index, content)

    assert token.lookup_key(key_list) == token

# Generated at 2022-06-24 11:30:15.523255
# Unit test for method lookup of class Token
def test_Token_lookup():
    value = ['a', 'b', 'c']
    token = ListToken(value, 0, 0)
    assert(token.value == ['a', 'b', 'c'])
    token_0 = token.lookup([0])
    assert(token_0.value == 'a')
    token_1 = token.lookup([1])
    assert(token_1.value == 'b')
    token_2 = token.lookup([2])
    assert(token_2.value == 'c')
    assert(token_0.lookup([]) == token_0)
    assert(token_1.lookup([]) == token_1)
    assert(token_2.lookup([]) == token_2)

# Generated at 2022-06-24 11:30:17.501943
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    print(Token(None, 0, 0) == Token(None, 0, 0))


# Generated at 2022-06-24 11:30:28.998313
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class ListToken(Token):
        def _get_value(self) -> typing.Any:
            return [token._get_value() for token in self._value]

        def _get_child_token(self, key: typing.Any) -> Token:
            return self._value[key]

    class DictToken(Token):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)
            self._child_keys = {k._value: k for k in self._value.keys()}
            self._child_tokens = {k._value: v for k, v in self._value.items()}


# Generated at 2022-06-24 11:30:34.452625
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("hello world", 0, 10, "hello world")
    assert token._value == "hello world"
    assert token._start_index == 0
    assert token._end_index == 10
    assert token._content == "hello world"



# Generated at 2022-06-24 11:30:42.996123
# Unit test for method lookup of class Token
def test_Token_lookup():
    # test for ListToken
    l1 = ListToken(
        value=[ScalarToken(value=1, start_index=0, end_index=0, content="1")],
        start_index=0,
        end_index=0,
        content="[1]",
    )
    l2 = ListToken(
        value=[l1],
        start_index=0,
        end_index=0,
        content="[[1]]",
    )
    assert l2.lookup(index=[0, 0]) == l1
    # test for DictToken

# Generated at 2022-06-24 11:30:48.564469
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token("value", 1, 2, content="string") != "value"
    assert Token("value", 1, 2, content="string") == Token("value", 1, 2, content="string")
    assert Token("value", 1, 2, content="string") != Token("other_value", 1, 2, content="string")
    assert Token("value", 1, 2, content="string") != Token("value", 2, 3, content="string")
    assert Token("value", 1, 2, content="string") != Token("other_value", 2, 3, content="string")

# Generated at 2022-06-24 11:30:49.066952
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    pass

# Generated at 2022-06-24 11:30:57.564685
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_string = ScalarToken(value='', start_index=0, end_index=0)
    token_string_2 = ScalarToken(value='', start_index=0, end_index=0)
    token_string_3 = ScalarToken(value='', start_index=0, end_index=1)
    token_string_4 = ScalarToken(value='', start_index=1, end_index=1)
    token_string_5 = ScalarToken(value='b', start_index=0, end_index=1)
    token_string_6 = ScalarToken(value='b', start_index=0, end_index=1)
    token_string_7 = ScalarToken(value='b', start_index=0, end_index=1)
    token_string_8 = Scalar

# Generated at 2022-06-24 11:30:59.608801
# Unit test for method lookup of class Token
def test_Token_lookup():
    assert Token(1,1,1).lookup(1) == NotImplementedError


# Generated at 2022-06-24 11:31:01.149965
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert repr(Token(1, 2, 3)) == "Token(1)"



# Generated at 2022-06-24 11:31:07.961412
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert ScalarToken(True, 1, 2).__hash__() == hash(True)
    assert ScalarToken(False, 1, 2).__hash__() == hash(False)
    assert ScalarToken(1, 1, 2).__hash__() == hash(1)
    assert ScalarToken(32.0, 1, 2).__hash__() == hash(32.0)
    assert ScalarToken("A", 1, 2).__hash__() == hash("A")
    assert ScalarToken(None, 1, 2).__hash__() == hash(None)


# Generated at 2022-06-24 11:31:13.141845
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from typesystem import String
    from tests.parser.parser import parse
    schema = parse("field: [{a: String(max_length=3), b: String(max_length=3)}]")
    token = schema.token.lookup_key([0, 0, "a"])
    assert token.start.line == schema.field.child_schema.items.child_schema.a.schema.token.start.line


# Generated at 2022-06-24 11:31:15.355133
# Unit test for constructor of class Token
def test_Token():
    assert Token(value=None, start_index=1, end_index=2, content="abc").string == "b"


# Generated at 2022-06-24 11:31:20.449390
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    input_start_index: int = 0
    input_end_index: int = 1
    input_content: str = "input_content"
    input_value: int = 10
    input_token: Token = ScalarToken(value=input_value, start_index=input_start_index, end_index=input_end_index, content=input_content)
    assert(str(input_token) == "ScalarToken('input_content')")
    print("Test __repr__ of class Token has PASSED!")



# Generated at 2022-06-24 11:31:21.888672
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken([],0,1,"")
    assert ListToken(1,2,3,"a")
  

# Generated at 2022-06-24 11:31:25.255041
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("a", 0, 1, "a b")
    assert token.string == "a"


test_ScalarToken()
