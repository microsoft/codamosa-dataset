

# Generated at 2022-06-18 12:45:26.470873
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ''
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:45:30.846215
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 1)
    assert d._value == {"a": 1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""


# Generated at 2022-06-18 12:45:41.106681
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test case 1
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ''
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}
    assert dt.string == ''
    assert dt.value == {'a': 1, 'b': 2}
    assert dt.start == Position(1, 1, 0)
    assert dt.end == Position(1, 1, 0)
    assert dt.lookup(['a']) == 1
   

# Generated at 2022-06-18 12:45:44.926587
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a":1, "b":2}, 0, 0)
    assert d._child_keys == {"a":1, "b":2}
    assert d._child_tokens == {"a":1, "b":2}


# Generated at 2022-06-18 12:45:52.327598
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ab")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcd")

# Generated at 2022-06-18 12:46:03.073005
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:46:08.869887
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcd")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcde")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcdef")

# Generated at 2022-06-18 12:46:11.153235
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1}, 0, 1, "a: 1")


# Generated at 2022-06-18 12:46:14.086157
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:46:25.409119
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 1)
    assert d._value == {"a": 1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""
    assert d.string == ""
    assert d.value == {"a": 1}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 1)
    assert d.lookup([]) == d
    assert d.lookup_key([0]) == d
    assert d.__repr__() == "DictToken('')"
    assert d.__eq__(d) == True
    assert d.__hash__() == hash({"a": 1})


# Generated at 2022-06-18 12:46:40.512709
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:46:51.162146
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, 0, 0)
    assert token == token
    assert token != None
    assert token != 1
    assert token != "foo"
    assert token != []
    assert token != {}
    assert token != Token(None, 0, 0)
    assert token != Token(None, 1, 0)
    assert token != Token(None, 0, 1)
    assert token != Token(None, 1, 1)
    assert token != Token(None, 0, 0, "foo")
    assert token != Token(None, 0, 0, "bar")
    assert token != Token(1, 0, 0)
    assert token != Token(1, 1, 0)
    assert token != Token(1, 0, 1)
    assert token != Token(1, 1, 1)

# Generated at 2022-06-18 12:47:02.443616
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test with a ScalarToken
    token1 = ScalarToken(value=1, start_index=0, end_index=0)
    token2 = ScalarToken(value=1, start_index=0, end_index=0)
    assert token1 == token2
    token3 = ScalarToken(value=2, start_index=0, end_index=0)
    assert not token1 == token3
    token4 = ScalarToken(value=1, start_index=1, end_index=0)
    assert not token1 == token4
    token5 = ScalarToken(value=1, start_index=0, end_index=1)
    assert not token1 == token5
    # Test with a DictToken

# Generated at 2022-06-18 12:47:07.501549
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:47:13.785855
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(None, 0, 0) == Token(None, 0, 0)
    assert not Token(None, 0, 0) == Token(None, 0, 1)
    assert not Token(None, 0, 0) == Token(None, 1, 0)
    assert not Token(None, 0, 0) == Token(None, 1, 1)
    assert not Token(None, 0, 0) == None
    assert not Token(None, 0, 0) == "foo"


# Generated at 2022-06-18 12:47:20.597922
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "a")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "ab")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "abc")

# Generated at 2022-06-18 12:47:31.007088
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:47:32.777925
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 1, 2)
    token2 = Token(1, 1, 2)
    assert token == token2


# Generated at 2022-06-18 12:47:38.392603
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:47:50.177363
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, 0, 0, "")
    assert token == token
    assert not (token != token)
    assert not (token == None)
    assert token != None
    assert not (token == "")
    assert token != ""
    assert not (token == 0)
    assert token != 0
    assert not (token == 0.0)
    assert token != 0.0
    assert not (token == [])
    assert token != []
    assert not (token == {})
    assert token != {}
    assert not (token == ())
    assert token != ()
    assert not (token == set())
    assert token != set()
    assert not (token == frozenset())
    assert token != frozenset()
    assert not (token == True)
    assert token != True
    assert not (token == False)

# Generated at 2022-06-18 12:48:05.860199
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(1, 2, 4)
    assert token1 != token3
    token4 = Token(2, 2, 3)
    assert token1 != token4
    token5 = Token(1, 3, 3)
    assert token1 != token5
    token6 = Token(1, 2, 2)
    assert token1 != token6


# Generated at 2022-06-18 12:48:13.297708
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not (Token(1, 2, 3) == Token(1, 2, 4))
    assert not (Token(1, 2, 3) == Token(1, 3, 3))
    assert not (Token(1, 2, 3) == Token(2, 2, 3))
    assert not (Token(1, 2, 3) == 1)
    assert not (Token(1, 2, 3) == None)


# Generated at 2022-06-18 12:48:23.605761
# Unit test for constructor of class DictToken
def test_DictToken():
    # Arrange
    start_index = 0
    end_index = 1
    content = "content"
    value = {
        ScalarToken(1, 0, 1): ScalarToken(2, 0, 1),
        ScalarToken(3, 0, 1): ScalarToken(4, 0, 1),
    }
    # Act
    token = DictToken(value, start_index, end_index, content)
    # Assert
    assert token._child_keys == {1: ScalarToken(1, 0, 1), 3: ScalarToken(3, 0, 1)}
    assert token._child_tokens == {1: ScalarToken(2, 0, 1), 3: ScalarToken(4, 0, 1)}


# Generated at 2022-06-18 12:48:32.452324
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3, "abc")
    token2 = Token(1, 2, 3, "abc")
    token3 = Token(1, 2, 3, "abcd")
    token4 = Token(1, 2, 4, "abc")
    token5 = Token(1, 3, 3, "abc")
    token6 = Token(2, 2, 3, "abc")
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5
    assert token1 != token6
    assert token1 != 1
    assert token1 != "abc"


# Generated at 2022-06-18 12:48:37.980425
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == "foo"


# Generated at 2022-06-18 12:48:44.302263
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(2, 2, 3)
    assert token1 != token3
    token4 = Token(1, 3, 3)
    assert token1 != token4
    token5 = Token(1, 2, 4)
    assert token1 != token5


# Generated at 2022-06-18 12:48:46.642200
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:48:56.760580
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.base import Position
    from typesystem.parser import ScalarToken
    from typesystem.parser import DictToken
    from typesystem.parser import ListToken
    from typesystem.parser import Token
    t1 = Token(1, 2, 3)
    t2 = Token(1, 2, 3)
    t3 = Token(2, 2, 3)
    t4 = Token(1, 3, 3)
    t5 = Token(1, 2, 4)
    t6 = ScalarToken(1, 2, 3)
    t7 = DictToken({}, 2, 3)
    t8 = ListToken([], 2, 3)
    assert t1 == t2
    assert not t1 == t3
    assert not t1 == t4
    assert not t1 == t5
    assert not t1 == t

# Generated at 2022-06-18 12:49:00.391106
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": "b"}, 0, 1)
    assert d._value == {"a": "b"}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""


# Generated at 2022-06-18 12:49:11.529715
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3, 4) == Token(1, 2, 3, 4)
    assert not Token(1, 2, 3, 4) == Token(1, 2, 3, 5)
    assert not Token(1, 2, 3, 4) == Token(1, 2, 4, 4)
    assert not Token(1, 2, 3, 4) == Token(1, 3, 3, 4)
    assert not Token(1, 2, 3, 4) == Token(2, 2, 3, 4)
    assert not Token(1, 2, 3, 4) == Token(1, 2, 3, 4, 5)
    assert not Token(1, 2, 3, 4) == Token(1, 2, 3)
    assert not Token(1, 2, 3, 4) == Token(1, 2)
    assert not Token

# Generated at 2022-06-18 12:49:37.316351
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    assert token1 != 1
    assert token1 != Token(2, 2, 3)
    assert token1 != Token(1, 3, 3)
    assert token1 != Token(1, 2, 4)


# Generated at 2022-06-18 12:49:46.821057
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for method __eq__ of class Token
    # Setup
    token1 = ScalarToken(1, 0, 0)
    token2 = ScalarToken(1, 0, 0)
    token3 = ScalarToken(2, 0, 0)
    token4 = ScalarToken(1, 1, 1)
    token5 = ScalarToken(1, 0, 1)
    token6 = ScalarToken(1, 0, 0, "a")
    # Exercise
    # Verify
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5
    assert token1 != token6
    assert token1 != 1

# Generated at 2022-06-18 12:49:52.574735
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(2, 2, 3)
    token4 = Token(1, 3, 3)
    token5 = Token(1, 2, 4)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5


# Generated at 2022-06-18 12:49:57.483552
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(1, 2, 4)
    assert token1 != token3
    token4 = Token(2, 2, 3)
    assert token1 != token4


# Generated at 2022-06-18 12:50:05.068650
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != None


# Generated at 2022-06-18 12:50:13.307053
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for class ScalarToken
    token1 = ScalarToken(1, 1, 1)
    token2 = ScalarToken(1, 1, 1)
    token3 = ScalarToken(2, 1, 1)
    assert token1 == token2
    assert token1 != token3

    # Test for class DictToken
    token1 = DictToken({}, 1, 1, "")
    token2 = DictToken({}, 1, 1, "")
    token3 = DictToken({}, 2, 1, "")
    assert token1 == token2
    assert token1 != token3

    # Test for class ListToken
    token1 = ListToken([], 1, 1, "")
    token2 = ListToken([], 1, 1, "")
    token3 = ListToken([], 2, 1, "")
    assert token

# Generated at 2022-06-18 12:50:17.178091
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for method __eq__ of class Token
    #
    # This test is not really useful, but it is here to make sure that
    # the method is implemented.
    assert Token(1, 2, 3) == Token(1, 2, 3)

# Generated at 2022-06-18 12:50:26.876317
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(2, 3, 4)
    assert Token(1, 2, 3) != Token(2, 3, 4)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != "1"
    assert Token(1, 2, 3) != None
    assert Token(1, 2, 3) != [1, 2, 3]
    assert Token(1, 2, 3) != (1, 2, 3)


# Generated at 2022-06-18 12:50:33.262217
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1
    assert not Token(1, 2, 3) == None
    assert not Token(1, 2, 3) == "1"


# Generated at 2022-06-18 12:50:43.854273
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1, "b": 2}, 0, 3, "abc")
    assert token.value == {"a": 1, "b": 2}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 4, 3)
    assert token.string == "abc"
    assert token.lookup([0]) == token._child_tokens["a"]
    assert token.lookup_key([0]) == token._child_keys["a"]
    assert token.lookup([1]) == token._child_tokens["b"]
    assert token.lookup_key([1]) == token._child_keys["b"]
    assert token == DictToken({"a": 1, "b": 2}, 0, 3, "abc")
    assert token != DictToken

# Generated at 2022-06-18 12:51:30.405036
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test that two tokens are equal if they have the same value, start index and end index
    token1 = ScalarToken(value = "test", start_index = 0, end_index = 3)
    token2 = ScalarToken(value = "test", start_index = 0, end_index = 3)
    assert token1 == token2
    # Test that two tokens are not equal if they have different values
    token1 = ScalarToken(value = "test", start_index = 0, end_index = 3)
    token2 = ScalarToken(value = "test2", start_index = 0, end_index = 3)
    assert not token1 == token2
    # Test that two tokens are not equal if they have different start indices
    token1 = ScalarToken(value = "test", start_index = 0, end_index = 3)

# Generated at 2022-06-18 12:51:39.181374
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3, "abc")
    token2 = Token(1, 2, 3, "abc")
    token3 = Token(1, 2, 3, "abcd")
    token4 = Token(1, 2, 4, "abc")
    token5 = Token(1, 3, 3, "abc")
    token6 = Token(1, 2, 3, "ab")
    token7 = Token(2, 2, 3, "abc")
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5
    assert token1 != token6
    assert token1 != token7


# Generated at 2022-06-18 12:51:46.635216
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token1 = Token(1, 2, 3)
    token2 = Token(2, 2, 3)
    assert token1 != token2
    token1 = Token(1, 2, 3)
    token2 = Token(1, 3, 3)
    assert token1 != token2
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 4)
    assert token1 != token2


# Generated at 2022-06-18 12:51:53.812579
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.base import Position
    from typesystem.base import Token
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import Token
    from typesystem.base import Position
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import Token
    from typesystem.base import Position
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import Token
    from typesystem.base import Position
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken

# Generated at 2022-06-18 12:52:03.728104
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a": "b"}, 0, 1)
    assert a._value == {"a": "b"}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == ""
    assert a.string == ""
    assert a.value == {"a": "b"}
    assert a.start == Position(1, 1, 0)
    assert a.end == Position(1, 1, 1)
    assert a.lookup([]) == a
    assert a.lookup_key([]) == a
    assert a._get_position(0) == Position(1, 1, 0)
    assert repr(a) == "DictToken({'a': 'b'})"
    assert a == DictToken({"a": "b"}, 0, 1)

# Generated at 2022-06-18 12:52:08.216460
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(2, 2, 3)
    token4 = Token(1, 3, 3)
    token5 = Token(1, 2, 4)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5


# Generated at 2022-06-18 12:52:17.104259
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:52:27.569161
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.base import Scalar, Dict, List
    from typesystem.parser import parse

    # Test for class ScalarToken
    token1 = ScalarToken(Scalar(1), 0, 0)
    token2 = ScalarToken(Scalar(1), 0, 0)
    assert token1 == token2

    token1 = ScalarToken(Scalar(1), 0, 0)
    token2 = ScalarToken(Scalar(2), 0, 0)
    assert token1 != token2

    token1 = ScalarToken(Scalar(1), 0, 0)
    token2 = ScalarToken(Scalar(1), 1, 0)
    assert token1 != token2

    token1 = ScalarToken(Scalar(1), 0, 0)

# Generated at 2022-06-18 12:52:33.101715
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, 0, 0, "")
    assert token == token
    assert token == Token(None, 0, 0, "")
    assert token != Token(None, 1, 0, "")
    assert token != Token(None, 0, 1, "")
    assert token != Token(None, 0, 0, "a")
    assert token != None


# Generated at 2022-06-18 12:52:35.925435
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:53:21.998216
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(0, 0, 0)
    assert token == token
    assert token == Token(0, 0, 0)
    assert token != Token(1, 0, 0)
    assert token != Token(0, 1, 0)
    assert token != Token(0, 0, 1)
    assert token != Token(0, 0, 0, "")
    assert token != Token(0, 0, 0, "a")
    assert token != None
    assert token != 0


# Generated at 2022-06-18 12:53:30.853882
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert token == Token(1, 2, 3)
    assert token != Token(2, 2, 3)
    assert token != Token(1, 3, 3)
    assert token != Token(1, 2, 4)
    assert token != Token(1, 2, 3, "")
    assert token != Token(1, 2, 3, "a")
    assert token != Token(1, 2, 3, "ab")
    assert token != Token(1, 2, 3, "abc")
    assert token != Token(1, 2, 3, "abcd")
    assert token != Token(1, 2, 3, "abcde")
    assert token != Token(1, 2, 3, "abcdef")

# Generated at 2022-06-18 12:53:38.448889
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 4)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != None


# Generated at 2022-06-18 12:53:43.846991
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({'a': 1}, 0, 1, '{a: 1}')
    assert a._value == {'a': 1}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == '{a: 1}'
    assert a._child_keys == {'a': 'a'}
    assert a._child_tokens == {'a': 1}


# Generated at 2022-06-18 12:53:51.720914
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 3, "a: 1, b: 2")
    assert d._child_keys == {"a": "a", "b": "b"}
    assert d._child_tokens == {"a": 1, "b": 2}
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 3
    assert d._content == "a: 1, b: 2"


# Generated at 2022-06-18 12:54:01.555094
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for class Token
    token = Token(1, 2, 3)
    assert token == token
    assert token == Token(1, 2, 3)
    assert token != Token(1, 2, 4)
    assert token != Token(1, 3, 3)
    assert token != Token(2, 2, 3)
    assert token != 1
    assert token != "1"
    assert token != None
    assert token != []
    assert token != {}
    assert token != ()
    assert token != object()
    assert token != object
    assert token != type
    assert token != type(None)
    assert token != type(1)
    assert token != type("1")
    assert token != type([])
    assert token != type({})
    assert token != type(())
    assert token != type(object())
    assert token != type

# Generated at 2022-06-18 12:54:11.657531
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "a")
    assert not Token(1, 2, 3) == 1
    assert not Token(1, 2, 3) == "a"
    assert not Token(1, 2, 3) == None


# Generated at 2022-06-18 12:54:21.536164
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "foo")
    assert not Token(1, 2, 3) == Token(1, 2, 4, "foo")
    assert not Token(1, 2, 3) == Token(1, 3, 3, "foo")
    assert not Token(1, 2, 3) == Token(2, 2, 3, "foo")
    assert not Token(1, 2, 3) == Token(2, 3, 3, "foo")

# Generated at 2022-06-18 12:54:32.396903
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=None, end_index=None)
    assert token == token
    assert token == Token(value=None, start_index=None, end_index=None)
    assert token != Token(value=None, start_index=None, end_index=None, content=None)
    assert token != Token(value=None, start_index=None, end_index=None, content=None)
    assert token != Token(value=None, start_index=None, end_index=None, content=None)
    assert token != Token(value=None, start_index=None, end_index=None, content=None)
    assert token != Token(value=None, start_index=None, end_index=None, content=None)

# Generated at 2022-06-18 12:54:42.902759
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "a")
    assert not Token(1, 2, 3) == 1
    assert not Token(1, 2, 3) == "1"
    assert not Token(1, 2, 3) == None
