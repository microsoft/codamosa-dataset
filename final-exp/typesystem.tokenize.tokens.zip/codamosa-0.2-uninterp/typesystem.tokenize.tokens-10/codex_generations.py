

# Generated at 2022-06-18 12:45:20.649244
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a":1}, 0, 1)
    assert d._child_keys == {"a":1}
    assert d._child_tokens == {"a":1}


# Generated at 2022-06-18 12:45:24.850505
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for class ScalarToken
    token1 = ScalarToken(1, 0, 0)
    token2 = ScalarToken(1, 0, 0)
    assert token1 == token2
    token3 = ScalarToken(2, 0, 0)
    assert token1 != token3
    # Test for class DictToken
    token4 = DictToken(
        {ScalarToken(1, 0, 0): ScalarToken(2, 0, 0)}, 0, 0
    )
    token5 = DictToken(
        {ScalarToken(1, 0, 0): ScalarToken(2, 0, 0)}, 0, 0
    )
    assert token4 == token5

# Generated at 2022-06-18 12:45:36.218497
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:45:42.818023
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(
        {
            ScalarToken("a", 0, 1): ScalarToken(1, 2, 3),
            ScalarToken("b", 4, 5): ScalarToken(2, 6, 7),
        },
        0,
        7,
        "a1b2",
    )
    assert token.lookup([0]).value == "a"
    assert token.lookup([1]).value == 2
    assert token.lookup_key([0, 0]).value == "a"
    assert token.lookup_key([1, 0]).value == "b"

# Generated at 2022-06-18 12:45:44.844845
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:45:49.462642
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test for constructor of class DictToken
    d = DictToken({'a':1}, 0, 1)
    assert d._value == {'a':1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""
    assert d._child_keys == {'a': 'a'}
    assert d._child_tokens == {'a': 1}


# Generated at 2022-06-18 12:45:51.596041
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1, "b": 2}, 0, 0, "")

# Generated at 2022-06-18 12:45:57.787626
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:46:00.772632
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({}, 0, 0)
    assert token._value == {}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""


# Generated at 2022-06-18 12:46:03.373376
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({}, 0, 0)
    assert d._value == {}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""


# Generated at 2022-06-18 12:46:20.289604
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert (
        ScalarToken(1, 0, 0) == ScalarToken(1, 0, 0)
    ), "ScalarToken(1, 0, 0) == ScalarToken(1, 0, 0)"
    assert (
        ScalarToken(1, 0, 0) != ScalarToken(2, 0, 0)
    ), "ScalarToken(1, 0, 0) != ScalarToken(2, 0, 0)"
    assert (
        ScalarToken(1, 0, 0) != ScalarToken(1, 1, 0)
    ), "ScalarToken(1, 0, 0) != ScalarToken(1, 1, 0)"

# Generated at 2022-06-18 12:46:26.779048
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(2, 2, 3)
    assert token1 != token3
    token4 = Token(1, 3, 3)
    assert token1 != token4
    token5 = Token(1, 2, 4)
    assert token1 != token5


# Generated at 2022-06-18 12:46:32.306170
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a": 1}, 0, 1, "a")
    assert a._value == {"a": 1}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == "a"
    assert a._child_keys == {"a": 1}
    assert a._child_tokens == {"a": 1}


# Generated at 2022-06-18 12:46:38.117062
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:46:40.156688
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 1, "a: 1\nb: 2")
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == "a: 1\nb: 2"


# Generated at 2022-06-18 12:46:49.928883
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1}, 0, 0)
    assert token._value == {"a": 1}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""
    assert token.string == ""
    assert token.value == {"a": 1}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert token.__repr__() == "DictToken({'a': 1})"
    assert token.__eq__(token) == True
    assert token.__hash__() == hash({"a": 1})


# Generated at 2022-06-18 12:47:01.706181
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=None, end_index=None, content=None)
    assert token.__eq__(None) == False
    assert token.__eq__(token) == True
    assert token.__eq__(Token(value=None, start_index=None, end_index=None, content=None)) == True
    assert token.__eq__(Token(value=None, start_index=None, end_index=None, content=None)) == True
    assert token.__eq__(Token(value=None, start_index=None, end_index=None, content=None)) == True
    assert token.__eq__(Token(value=None, start_index=None, end_index=None, content=None)) == True

# Generated at 2022-06-18 12:47:11.541085
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert ScalarToken(1, 0, 0) == ScalarToken(1, 0, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(2, 0, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 1, 1)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 0, 1)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 1, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 1, 1)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 1, 1)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 1, 1)

# Generated at 2022-06-18 12:47:19.520878
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=None, end_index=None)
    assert token == token
    assert token != None
    assert token != 1
    assert token != "1"
    assert token != []
    assert token != {}
    assert token != ()
    assert token != object()
    assert token != Token(value=None, start_index=None, end_index=None)
    assert token != Token(value=None, start_index=None, end_index=None, content="")
    assert token != Token(value=1, start_index=None, end_index=None)
    assert token != Token(value=None, start_index=1, end_index=None)
    assert token != Token(value=None, start_index=None, end_index=1)

# Generated at 2022-06-18 12:47:30.041846
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:47:38.567036
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(value={}, start_index=0, end_index=0)
    assert token._value == {}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""


# Generated at 2022-06-18 12:47:42.988659
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(1, 2, 4)
    assert token1 != token3
    token4 = Token(2, 2, 3)
    assert token1 != token4


# Generated at 2022-06-18 12:47:54.265357
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:48:00.554818
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1
    assert not Token(1, 2, 3) == None

# Generated at 2022-06-18 12:48:05.779628
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1
    assert not Token(1, 2, 3) == None


# Generated at 2022-06-18 12:48:12.116976
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:48:18.969410
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ''
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:48:30.678181
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert token == Token(1, 2, 3)
    assert token != Token(2, 2, 3)
    assert token != Token(1, 3, 3)
    assert token != Token(1, 2, 4)
    assert token != Token(1, 2, 3, "")
    assert token != Token(1, 2, 3, "abc")
    assert token != Token(1, 2, 3, "abcd")
    assert token != Token(1, 2, 3, "abcde")
    assert token != Token(1, 2, 3, "abcdef")
    assert token != Token(1, 2, 3, "abcdefg")
    assert token != Token(1, 2, 3, "abcdefgh")

# Generated at 2022-06-18 12:48:41.528764
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 1, 'a: 1, b: 2')
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 1
    assert dt._content == 'a: 1, b: 2'
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}
    assert dt.string == 'a: 1, b: 2'
    assert dt.value == {'a': 1, 'b': 2}
    assert dt.start == Position(1, 1, 0)

# Generated at 2022-06-18 12:48:48.148450
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a':1, 'b':2}
    dt = DictToken(d, 0, 0)
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ''
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:49:13.196932
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:49:24.340638
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ab")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcd")

# Generated at 2022-06-18 12:49:32.327496
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0)
    assert token == token
    assert token == Token(value=None, start_index=0, end_index=0)
    assert token != Token(value=None, start_index=1, end_index=0)
    assert token != Token(value=None, start_index=0, end_index=1)
    assert token != Token(value=None, start_index=1, end_index=1)
    assert token != Token(value=None, start_index=0, end_index=0, content="")
    assert token != Token(value=None, start_index=0, end_index=0, content="a")
    assert token != Token(value=None, start_index=0, end_index=0, content="b")

# Generated at 2022-06-18 12:49:37.221804
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a':1, 'b':2}
    dt = DictToken(d, 0, 1)
    assert dt._value == {'a':1, 'b':2}
    assert dt._start_index == 0
    assert dt._end_index == 1
    assert dt._content == ""


# Generated at 2022-06-18 12:49:43.198232
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a":1}, 1, 2, "a")
    assert a._value == {"a":1}
    assert a._start_index == 1
    assert a._end_index == 2
    assert a._content == "a"
    assert a._child_keys == {"a":1}
    assert a._child_tokens == {"a":1}


# Generated at 2022-06-18 12:49:53.715875
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(None, 0, 0) == Token(None, 0, 0)
    assert not Token(None, 0, 0) == Token(None, 0, 1)
    assert not Token(None, 0, 0) == Token(None, 1, 0)
    assert not Token(None, 0, 0) == Token(None, 1, 1)
    assert not Token(None, 0, 0) == Token(1, 0, 0)
    assert not Token(None, 0, 0) == Token(1, 0, 1)
    assert not Token(None, 0, 0) == Token(1, 1, 0)
    assert not Token(None, 0, 0) == Token(1, 1, 1)
    assert not Token(None, 0, 0) == None
    assert not Token(None, 0, 0) == "foo"

# Generated at 2022-06-18 12:49:54.999266
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a":1, "b":2}, 0, 0, "")

# Generated at 2022-06-18 12:49:57.637329
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:50:08.983502
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:50:14.769930
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ''
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:50:46.793805
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == "foo"

# Generated at 2022-06-18 12:50:56.923439
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for method __eq__ of class Token
    # __eq__ should return True if the values, start_index and end_index are the same
    token1 = ScalarToken(1, 0, 0)
    token2 = ScalarToken(1, 0, 0)
    assert token1 == token2
    token1 = ScalarToken(1, 0, 0)
    token2 = ScalarToken(2, 0, 0)
    assert not token1 == token2
    token1 = ScalarToken(1, 0, 0)
    token2 = ScalarToken(1, 1, 0)
    assert not token1 == token2
    token1 = ScalarToken(1, 0, 0)
    token2 = ScalarToken(1, 0, 1)
    assert not token1 == token2

# Generated at 2022-06-18 12:50:59.819935
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0)
    other = Token(value=None, start_index=0, end_index=0)
    assert token == other


# Generated at 2022-06-18 12:51:04.373096
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, 0, 0, "")
    assert token == token
    assert token == Token(None, 0, 0, "")
    assert token != Token(None, 1, 0, "")
    assert token != Token(None, 0, 1, "")
    assert token != Token(None, 0, 0, "a")
    assert token != None

# Generated at 2022-06-18 12:51:13.845362
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:51:18.695072
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(2, 2, 3)
    assert token1 != token3
    token4 = Token(1, 3, 3)
    assert token1 != token4
    token5 = Token(1, 2, 4)
    assert token1 != token5


# Generated at 2022-06-18 12:51:24.762050
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != None
    assert Token(1, 2, 3) != "1"


# Generated at 2022-06-18 12:51:28.184810
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Setup
    value = None
    start_index = 0
    end_index = 0
    content = ""
    token = Token(value, start_index, end_index, content)
    other = None

    # Exercise
    result = token.__eq__(other)

    # Verify
    assert result == False


# Generated at 2022-06-18 12:51:33.550443
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(2, 2, 3)
    assert token1 != token3
    token4 = Token(1, 3, 3)
    assert token1 != token4
    token5 = Token(1, 2, 4)
    assert token1 != token5


# Generated at 2022-06-18 12:51:43.789720
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0)
    assert token == token
    assert token == Token(value=None, start_index=0, end_index=0)
    assert token != Token(value=None, start_index=0, end_index=1)
    assert token != Token(value=None, start_index=1, end_index=0)
    assert token != Token(value=None, start_index=1, end_index=1)
    assert token != Token(value=None, start_index=0, end_index=0, content="foo")
    assert token != Token(value=None, start_index=0, end_index=0, content="")
    assert token != Token(value=None, start_index=0, end_index=0, content=None)

# Generated at 2022-06-18 12:52:32.300839
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1}, 0, 0)
    assert token.value == {"a": 1}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)
    assert token.string == ""
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert token.lookup([0]) == token
    assert token.lookup_key([0]) == token


# Generated at 2022-06-18 12:52:41.034716
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0)
    assert token == token
    assert token == Token(value=None, start_index=0, end_index=0)
    assert token != Token(value=None, start_index=1, end_index=0)
    assert token != Token(value=None, start_index=0, end_index=1)
    assert token != Token(value=None, start_index=0, end_index=0, content="")
    assert token != Token(value=None, start_index=0, end_index=0, content="a")
    assert token != None
    assert token != "a"
    assert token != 1


# Generated at 2022-06-18 12:52:46.542548
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a":1}, 0, 1)
    assert d._value == {"a":1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""
    assert d._child_keys == {"a":1}
    assert d._child_tokens == {"a":1}


# Generated at 2022-06-18 12:52:53.362280
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(2, 2, 3)
    token4 = Token(1, 3, 3)
    token5 = Token(1, 2, 4)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5


# Generated at 2022-06-18 12:53:03.538044
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, 0, 0)
    assert token == token
    assert token != None
    assert token != 1
    assert token != "1"
    assert token != []
    assert token != {}
    assert token != ()
    assert token != set()
    assert token != frozenset()
    assert token != b"1"
    assert token != bytearray(b"1")
    assert token != memoryview(b"1")
    assert token != range(0)
    assert token != NotImplemented
    assert token != Ellipsis
    assert token != ...
    assert token != False
    assert token != True
    assert token != Token(None, 0, 0)
    assert token != ScalarToken(None, 0, 0)
    assert token != DictToken(None, 0, 0)
    assert token != List

# Generated at 2022-06-18 12:53:10.992955
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(2, 2, 3)
    token4 = Token(1, 3, 3)
    token5 = Token(1, 2, 4)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5

# Generated at 2022-06-18 12:53:16.538494
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != 1


# Generated at 2022-06-18 12:53:18.916035
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken(value = {}, start_index = 0, end_index = 0, content = "")


# Generated at 2022-06-18 12:53:22.917528
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1}, 0, 1, "a")
    assert token._value == {"a": 1}
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == "a"


# Generated at 2022-06-18 12:53:28.201071
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test constructor
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ""
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:54:54.982452
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a':1, 'b':2}
    dt = DictToken(d, 0, 0)
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:55:03.119799
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(
        {
            ScalarToken(1, 0, 0): ScalarToken(2, 0, 0),
            ScalarToken(3, 0, 0): ScalarToken(4, 0, 0),
        },
        0,
        0,
    )
    assert token._child_keys == {1: ScalarToken(1, 0, 0), 3: ScalarToken(3, 0, 0)}
    assert token._child_tokens == {
        1: ScalarToken(2, 0, 0),
        3: ScalarToken(4, 0, 0),
    }


# Generated at 2022-06-18 12:55:08.537078
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:55:15.851129
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 2, 3, "foo")
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != object()
