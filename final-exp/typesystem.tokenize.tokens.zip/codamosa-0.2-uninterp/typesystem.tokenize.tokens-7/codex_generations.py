

# Generated at 2022-06-18 12:45:23.297264
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({'a':1}, 0, 1)
    assert a._value == {'a':1}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._child_keys == {'a': 'a'}
    assert a._child_tokens == {'a': 1}


# Generated at 2022-06-18 12:45:29.626548
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1
    assert not Token(1, 2, 3) == None


# Generated at 2022-06-18 12:45:35.602853
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(value = {}, start_index = 0, end_index = 0, content = "")
    assert token._value == {}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""
    assert token._child_keys == {}
    assert token._child_tokens == {}


# Generated at 2022-06-18 12:45:37.384227
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1, "b": 2}, 0, 0, "")


# Generated at 2022-06-18 12:45:45.895938
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a":1, "b":2}, 0, 1, "a:1\nb:2") == DictToken({"a":1, "b":2}, 0, 1, "a:1\nb:2")
    assert DictToken({"a":1, "b":2}, 0, 1, "a:1\nb:2") != DictToken({"a":1, "b":2}, 0, 1, "a:1\nb:3")
    assert DictToken({"a":1, "b":2}, 0, 1, "a:1\nb:2") != DictToken({"a":1, "b":2}, 0, 1, "a:1\nb:2\nc:3")

# Generated at 2022-06-18 12:45:56.415449
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, 0, 0)
    assert token == token
    assert token == Token(None, 0, 0)
    assert token != Token(None, 1, 0)
    assert token != Token(None, 0, 1)
    assert token != Token(None, 0, 0, "")
    assert token != Token(None, 0, 0, "a")
    assert token != Token(None, 0, 0, "ab")
    assert token != Token(None, 0, 0, "abc")
    assert token != Token(None, 0, 0, "abcd")
    assert token != Token(None, 0, 0, "abcde")
    assert token != Token(None, 0, 0, "abcdef")
    assert token != Token(None, 0, 0, "abcdefg")

# Generated at 2022-06-18 12:46:02.508097
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 1, "")
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:46:05.473314
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=1, start_index=0, end_index=0, content="")
    other = Token(value=1, start_index=0, end_index=0, content="")
    assert token == other


# Generated at 2022-06-18 12:46:11.868739
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(1, 2, 4)
    assert token1 != token3
    token4 = Token(1, 3, 4)
    assert token1 != token4
    token5 = Token(2, 2, 3)
    assert token1 != token5


# Generated at 2022-06-18 12:46:20.028134
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({'a': 1, 'b': 2}, 0, 1, 'a: 1\nb: 2')
    assert a._value == {'a': 1, 'b': 2}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == 'a: 1\nb: 2'
    assert a._child_keys == {'a': 'a', 'b': 'b'}
    assert a._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:46:36.919680
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import Token
    from typesystem.base import Position
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import ScalarToken
    from typesystem.base import Position
    from typesystem.base import Token
    from typesystem.base import Position
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import ScalarToken
    from typesystem.base import Position
    from typesystem.base import Token
    from typesystem.base import Position

# Generated at 2022-06-18 12:46:40.593046
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({'a': 1, 'b': 2}, 0, 1)
    assert d._child_keys == {'a': 'a', 'b': 'b'}
    assert d._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:46:44.239125
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(value=None, start_index=0, end_index=0)
    token2 = Token(value=None, start_index=0, end_index=0)
    assert token1 == token2


# Generated at 2022-06-18 12:46:55.498267
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test with ScalarToken
    token1 = ScalarToken(1, 0, 0)
    token2 = ScalarToken(1, 0, 0)
    assert token1 == token2
    token3 = ScalarToken(2, 0, 0)
    assert token1 != token3
    # Test with DictToken
    token1 = DictToken({}, 0, 0)
    token2 = DictToken({}, 0, 0)
    assert token1 == token2
    token3 = DictToken({ScalarToken(1, 0, 0): ScalarToken(2, 0, 0)}, 0, 0)
    assert token1 != token3
    # Test with ListToken
    token1 = ListToken([], 0, 0)
    token2 = ListToken([], 0, 0)
    assert token1 == token2
    token

# Generated at 2022-06-18 12:47:05.853776
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import Token
    from typesystem.base import Position
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import DictToken

    token = DictToken(
        {
            ScalarToken("a", 0, 0): ScalarToken(1, 1, 1),
            ScalarToken("b", 2, 2): ScalarToken(2, 3, 3),
        },
        0,
        3,
        "a1b2",
    )
    assert token.value == {"a": 1, "b": 2}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 4, 3)
    assert token.string == "a1b2"
   

# Generated at 2022-06-18 12:47:10.239289
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 1, "")
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""


# Generated at 2022-06-18 12:47:16.797389
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3, "abc")
    token2 = Token(1, 2, 3, "abc")
    token3 = Token(1, 2, 3, "abcd")
    token4 = Token(2, 2, 3, "abc")
    token5 = Token(1, 3, 3, "abc")
    token6 = Token(1, 2, 4, "abc")
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5
    assert token1 != token6


# Generated at 2022-06-18 12:47:22.117494
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0)
    assert d._child_keys == {"a": "a", "b": "b"}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:47:31.561436
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(None, 0, 0) == Token(None, 0, 0)
    assert not Token(None, 0, 0) == Token(None, 0, 1)
    assert not Token(None, 0, 0) == Token(None, 1, 0)
    assert not Token(None, 0, 0) == Token(None, 1, 1)
    assert not Token(None, 0, 0) == Token(None, 0, 0, "")
    assert not Token(None, 0, 0) == Token(None, 0, 0, "a")
    assert not Token(None, 0, 0) == Token(None, 0, 0, "ab")
    assert not Token(None, 0, 0) == Token(None, 0, 0, "abc")

# Generated at 2022-06-18 12:47:35.061001
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(1, 2, 4)
    assert token1 != token3
    token4 = Token(2, 2, 3)
    assert token1 != token4


# Generated at 2022-06-18 12:47:52.847177
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "abc")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "abc")
    assert not Token(1, 2, 3) == 1
    assert not Token(1, 2, 3) == "abc"
    assert not Token(1, 2, 3) == None



# Generated at 2022-06-18 12:48:02.744254
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ab")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcd")

# Generated at 2022-06-18 12:48:07.601552
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(2, 2, 3)
    assert token1 != token3
    token4 = Token(1, 1, 3)
    assert token1 != token4
    token5 = Token(1, 2, 4)
    assert token1 != token5


# Generated at 2022-06-18 12:48:14.723710
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:48:24.886810
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({'a': 1}, 0, 1)
    assert d._value == {'a': 1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ''
    assert d.string == ''
    assert d.value == {'a': 1}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 1)
    assert d.lookup([]) == d
    assert d.lookup_key([]) == d
    assert d.__repr__() == 'DictToken({})'
    assert d.__eq__(d) == True
    assert d.__hash__() == hash({'a': 1})


# Generated at 2022-06-18 12:48:35.576134
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}
    assert dt._value == {'a': 1, 'b': 2}
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ""
    assert dt.string == ""
    assert dt.value == {'a': 1, 'b': 2}
    assert dt.start == Position(1, 1, 0)
    assert dt.end == Position(1, 1, 0)
    assert dt.lookup(['a'])

# Generated at 2022-06-18 12:48:46.588335
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": "b"}, 0, 1)
    assert token._value == {"a": "b"}
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == ""
    assert token.string == ""
    assert token.value == {"a": "b"}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 1)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert token._get_position(0) == Position(1, 1, 0)
    assert repr(token) == "DictToken({'a': 'b'})"
    assert token == DictToken({"a": "b"}, 0, 1)

# Generated at 2022-06-18 12:48:51.737357
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:48:54.617772
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_1 = Token(1, 2, 3)
    token_2 = Token(1, 2, 3)
    assert token_1 == token_2


# Generated at 2022-06-18 12:49:06.245434
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0)
    assert token == token
    assert token != None
    assert token != 1
    assert token != "1"
    assert token != []
    assert token != ()
    assert token != {}
    assert token != set()
    assert token != frozenset()
    assert token != Token(value=None, start_index=0, end_index=0)
    assert token != Token(value=None, start_index=1, end_index=0)
    assert token != Token(value=None, start_index=0, end_index=1)
    assert token != Token(value=None, start_index=0, end_index=0, content="")

# Generated at 2022-06-18 12:49:25.234793
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != None


# Generated at 2022-06-18 12:49:30.377420
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:49:36.859849
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(value=1, start_index=0, end_index=1, content="")
    token2 = Token(value=1, start_index=0, end_index=1, content="")
    token3 = Token(value=2, start_index=0, end_index=1, content="")
    assert token1 == token2
    assert token1 != token3


# Generated at 2022-06-18 12:49:42.923224
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:49:53.501121
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for method __eq__ of class Token
    # Case 1:
    #   Input:
    #       token1 = Token(value=1, start_index=0, end_index=1)
    #       token2 = Token(value=1, start_index=0, end_index=1)
    #   Expected:
    #       token1 == token2
    token1 = Token(value=1, start_index=0, end_index=1)
    token2 = Token(value=1, start_index=0, end_index=1)
    assert token1 == token2

    # Case 2:
    #   Input:
    #       token1 = Token(value=1, start_index=0, end_index=1)
    #       token2 = Token(value=2, start_index=0,

# Generated at 2022-06-18 12:49:59.606160
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != 1


# Generated at 2022-06-18 12:50:10.375700
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(2, 3, 4)
    assert Token(1, 2, 3) != Token(2, 3, 4)
    assert Token(1, 2, 3) != Token(2, 3, 4)
    assert Token(1, 2, 3) != Token(2, 3, 4)
    assert Token(1, 2, 3) != Token(2, 3, 4)
    assert Token(1, 2, 3) != Token(2, 3, 4)

# Generated at 2022-06-18 12:50:14.574189
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(value=1, start_index=0, end_index=1)
    token2 = Token(value=1, start_index=0, end_index=1)
    token3 = Token(value=2, start_index=0, end_index=1)
    assert token1 == token2
    assert token1 != token3


# Generated at 2022-06-18 12:50:24.416435
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for class ScalarToken
    token1 = ScalarToken(1, 0, 0)
    token2 = ScalarToken(1, 0, 0)
    token3 = ScalarToken(2, 0, 0)
    assert token1 == token2
    assert token1 != token3
    # Test for class DictToken
    token1 = DictToken({ScalarToken(1, 0, 0): ScalarToken(2, 0, 0)}, 0, 0)
    token2 = DictToken({ScalarToken(1, 0, 0): ScalarToken(2, 0, 0)}, 0, 0)
    token3 = DictToken({ScalarToken(2, 0, 0): ScalarToken(2, 0, 0)}, 0, 0)
    assert token1 == token2
    assert token1 != token3

# Generated at 2022-06-18 12:50:30.461829
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 1, 2, "abc")
    token2 = Token(1, 1, 2, "abc")
    token3 = Token(2, 1, 2, "abc")
    token4 = Token(1, 2, 3, "abc")
    token5 = Token(1, 1, 2, "abcd")
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5


# Generated at 2022-06-18 12:51:00.500966
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(2, 3, 4)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(2, 3, 4)
    assert Token(1, 2, 3) != Token(1, 2, 4)

# Generated at 2022-06-18 12:51:04.090896
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({'a': 'b'}, 0, 1)
    assert token._value == {'a': 'b'}
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == ""


# Generated at 2022-06-18 12:51:07.980299
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken(value = {}, start_index = 0, end_index = 0, content = "")
    assert d._value == {}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""


# Generated at 2022-06-18 12:51:13.764897
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ''
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:51:17.949656
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert token == Token(1, 2, 3)
    assert token != Token(2, 2, 3)
    assert token != Token(1, 3, 3)
    assert token != Token(1, 2, 4)
    assert token != 1


# Generated at 2022-06-18 12:51:20.452131
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3, "abc")
    token2 = Token(1, 2, 3, "abc")
    assert token1 == token2


# Generated at 2022-06-18 12:51:26.084339
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "foo")
    assert not Token(1, 2, 3) == object()

# Generated at 2022-06-18 12:51:29.675187
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 1, "a: 1, b: 2")
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == "a: 1, b: 2"


# Generated at 2022-06-18 12:51:31.200290
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": "b"}, 0, 1)


# Generated at 2022-06-18 12:51:36.708951
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1

# Generated at 2022-06-18 12:52:40.262004
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test Token.__eq__()
    assert ScalarToken(1, 0, 0) == ScalarToken(1, 0, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(2, 0, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 1, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 0, 1)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 1, 1)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 1, 1)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 1, 1)

# Generated at 2022-06-18 12:52:46.195462
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(1, 2, 4)
    token4 = Token(1, 3, 3)
    token5 = Token(2, 2, 3)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5


# Generated at 2022-06-18 12:52:51.623879
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({'a': 1, 'b': 2}, 0, 3, '{"a": 1, "b": 2}')
    assert d._child_keys == {'a': 'a', 'b': 'b'}
    assert d._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:53:02.548688
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 1, 1) == Token(1, 1, 1)
    assert Token(1, 1, 1) != Token(2, 1, 1)
    assert Token(1, 1, 1) != Token(1, 2, 1)
    assert Token(1, 1, 1) != Token(1, 1, 2)
    assert Token(1, 1, 1) != Token(1, 1, 1, "")
    assert Token(1, 1, 1) != Token(1, 1, 1, "a")
    assert Token(1, 1, 1) != Token(1, 1, 1, "b")
    assert Token(1, 1, 1) != Token(1, 1, 1, "ab")
    assert Token(1, 1, 1) != Token(1, 1, 1, "ba")

# Generated at 2022-06-18 12:53:10.518605
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1
    assert not Token(1, 2, 3) == None


# Generated at 2022-06-18 12:53:16.183760
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:53:21.949704
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == "foo"


# Generated at 2022-06-18 12:53:30.816279
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(1, 2, 3)
    t2 = Token(1, 2, 3)
    assert t1 == t2
    t3 = Token(2, 2, 3)
    assert t1 != t3
    t4 = Token(1, 3, 3)
    assert t1 != t4
    t5 = Token(1, 2, 4)
    assert t1 != t5
    t6 = Token(1, 2, 3, "abc")
    assert t1 == t6
    t7 = Token(1, 2, 3, "abcd")
    assert t1 != t7
    t8 = Token(1, 2, 3, "ab")
    assert t1 != t8
    t9 = Token(1, 2, 3, "ab")
    assert t8 == t9
    t10 = Token

# Generated at 2022-06-18 12:53:42.399867
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0)
    assert token == token
    assert token == Token(value=None, start_index=0, end_index=0)
    assert token != Token(value=None, start_index=1, end_index=0)
    assert token != Token(value=None, start_index=0, end_index=1)
    assert token != Token(value=None, start_index=0, end_index=0, content="")
    assert token != Token(value=None, start_index=0, end_index=0, content="a")
    assert token != Token(value=None, start_index=0, end_index=0, content="b")
    assert token != None


# Generated at 2022-06-18 12:53:48.987713
# Unit test for method __eq__ of class Token