

# Generated at 2022-06-18 12:45:26.958587
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, None, None)
    assert token == token
    assert token != None
    assert token != "foo"
    assert token != Token(None, None, None)
    assert token != Token(None, None, None, "foo")
    assert token != Token(None, None, None, "bar")
    assert token != Token(None, 1, None)
    assert token != Token(None, None, 1)
    assert token != Token(None, 1, 1)
    assert token != Token(None, 1, 1, "foo")
    assert token != Token(None, 1, 1, "bar")
    assert token != Token(None, None, None, "foo")
    assert token != Token(None, None, None, "bar")
    assert token != Token(None, 1, None, "foo")
    assert token

# Generated at 2022-06-18 12:45:34.863464
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ''
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:45:37.081481
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:45:45.604763
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0)
    assert token == token
    assert token == Token(value=None, start_index=0, end_index=0)
    assert token != Token(value=None, start_index=1, end_index=0)
    assert token != Token(value=None, start_index=0, end_index=1)
    assert token != Token(value=None, start_index=1, end_index=1)
    assert token != Token(value=None, start_index=0, end_index=0, content="")
    assert token != Token(value=None, start_index=0, end_index=0, content="a")
    assert token != Token(value=None, start_index=0, end_index=0, content="b")

# Generated at 2022-06-18 12:45:50.917771
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1}, 0, 1)
    assert token._value == {"a": 1}
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == ""
    assert token.string == ""
    assert token.value == {"a": 1}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 1)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert token._get_position(0) == Position(1, 1, 0)
    assert repr(token) == "DictToken({'a': 1})"
    assert token == DictToken({"a": 1}, 0, 1)

# Generated at 2022-06-18 12:45:54.237616
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = ScalarToken(value=1, start_index=0, end_index=0)
    token2 = ScalarToken(value=1, start_index=0, end_index=0)
    assert token1 == token2


# Generated at 2022-06-18 12:46:04.423069
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}
    assert dt._value == {'a': 1, 'b': 2}
    assert dt.value == {'a': 1, 'b': 2}
    assert dt.start == Position(1, 1, 0)
    assert dt.end == Position(1, 1, 0)
    assert dt.string == ''
    assert dt.lookup([]) == dt
    assert dt.lookup_key([]) == dt

# Generated at 2022-06-18 12:46:16.615429
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 3, "a:1,b:2")
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 3
    assert d._content == "a:1,b:2"
    assert d.string == "a:1,b:2"
    assert d.value == {"a": 1, "b": 2}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 5, 3)
    assert d.lookup([]) == d
    assert d.lookup_key([]) == d
    assert d._get_position(0) == Position(1, 1, 0)
    assert d.__repr__

# Generated at 2022-06-18 12:46:24.192444
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    t = DictToken(d, 0, 0)
    assert t._value == d
    assert t._start_index == 0
    assert t._end_index == 0
    assert t._content == ''
    assert t._child_keys == {'a': 'a', 'b': 'b'}
    assert t._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:46:28.704051
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:46:38.105291
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0)
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:46:43.164351
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({'a':1}, 0, 1)
    assert d._value == {'a':1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""
    assert d.string == ""
    assert d.value == {'a':1}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 1)


# Generated at 2022-06-18 12:46:49.055818
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test with ScalarToken
    token1 = ScalarToken(1, 0, 0)
    token2 = ScalarToken(1, 0, 0)
    assert token1 == token2
    token3 = ScalarToken(2, 0, 0)
    assert token1 != token3
    # Test with ListToken
    token4 = ListToken([token1], 0, 0)
    token5 = ListToken([token2], 0, 0)
    assert token4 == token5
    token6 = ListToken([token3], 0, 0)
    assert token4 != token6
    # Test with DictToken
    token7 = DictToken({token1: token1}, 0, 0)
    token8 = DictToken({token2: token2}, 0, 0)
    assert token7 == token8

# Generated at 2022-06-18 12:47:00.039391
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(2, 3, 4)
    assert not Token(1, 2, 3) == Token(2, 3, 4)
    assert not Token(1, 2, 3) == Token(2, 3, 4)
    assert not Token(1, 2, 3) == Token(2, 3, 4)
    assert not Token(1, 2, 3) == Token(2, 3, 4)
    assert not Token(1, 2, 3)

# Generated at 2022-06-18 12:47:10.659609
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 0)
    assert d._value == {"a": 1}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""
    assert d.string == ""
    assert d.value == {"a": 1}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 0)
    assert d.lookup([]) == d
    assert d.lookup_key([]) == d
    assert d._get_position(0) == Position(1, 1, 0)
    assert repr(d) == "DictToken('')"
    assert d == DictToken({"a": 1}, 0, 0)
    assert hash(d) == hash({"a": 1})


# Generated at 2022-06-18 12:47:19.050057
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import Token
    from typesystem.base import Position
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken

# Generated at 2022-06-18 12:47:29.658464
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 1)
    assert d._value == {"a": 1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""
    assert d.string == ""
    assert d.value == {"a": 1}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 1)
    assert d.lookup([]) == d
    assert d.lookup_key([]) == d
    assert d._get_position(0) == Position(1, 1, 0)
    assert repr(d) == "DictToken('')"
    assert d == DictToken({"a": 1}, 0, 1)
    assert hash(d) == hash({"a": 1})


# Generated at 2022-06-18 12:47:37.357404
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 4)
    assert not Token(1, 2, 3) == Token(2, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 3, 4)
    assert not Token(1, 2, 3) == Token(2, 4, 4)
    assert not Token(1, 2, 3) == Token(2, 4, 5)
    assert not Token(1, 2, 3)

# Generated at 2022-06-18 12:47:49.065297
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "a")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "ab")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "abc")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "abcd")

# Generated at 2022-06-18 12:47:54.356301
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1
    assert not Token(1, 2, 3) == None


# Generated at 2022-06-18 12:48:02.139206
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:48:04.866151
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 1)
    assert d._value == {"a": 1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""


# Generated at 2022-06-18 12:48:06.992666
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:48:13.242431
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:48:18.928164
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:48:30.642579
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 3, "a: 1, b: 2")
    assert d.string == "a: 1, b: 2"
    assert d.value == {"a": 1, "b": 2}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 13, 3)
    assert d.lookup([]) == d
    assert d.lookup_key([]) == d
    assert d.lookup([0]) == d._child_tokens["a"]
    assert d.lookup_key([0]) == d._child_keys["a"]
    assert d.lookup([1]) == d._child_tokens["b"]

# Generated at 2022-06-18 12:48:34.477543
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0)
    assert d._child_keys == {"a": "a", "b": "b"}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:48:45.062121
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:48:51.656749
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ""
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:48:58.805878
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 10, "a: 1\nb: 2")
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 10
    assert d._content == "a: 1\nb: 2"
    assert d._child_keys == {"a": "a", "b": "b"}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:49:21.178855
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, 0, 0)
    assert token == token
    assert token == Token(None, 0, 0)
    assert not token == Token(None, 1, 0)
    assert not token == Token(None, 0, 1)
    assert not token == Token(None, 1, 1)
    assert not token == Token(None, 0, 0, "")
    assert not token == Token(None, 0, 0, "a")
    assert not token == Token(None, 0, 0, "ab")
    assert not token == Token(None, 0, 0, "abc")
    assert not token == Token(None, 0, 0, "abcd")
    assert not token == Token(None, 0, 0, "abcde")
    assert not token == Token(None, 0, 0, "abcdef")

# Generated at 2022-06-18 12:49:24.022351
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test for constructor of class DictToken
    assert DictToken(value = {}, start_index = 0, end_index = 0, content = "")


# Generated at 2022-06-18 12:49:32.144020
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a": "b"}, 0, 1)
    assert a._value == {"a": "b"}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == ""
    assert a.string == ""
    assert a.value == {"a": "b"}
    assert a.start == Position(1, 1, 0)
    assert a.end == Position(1, 1, 1)
    assert a.lookup([]) == a
    assert a.lookup_key([]) == a
    assert a._get_position(0) == Position(1, 1, 0)
    assert repr(a) == "DictToken({'a': 'b'})"
    assert a == DictToken({"a": "b"}, 0, 1)

# Generated at 2022-06-18 12:49:35.407392
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0)
    other = Token(value=None, start_index=0, end_index=0)
    assert token == other


# Generated at 2022-06-18 12:49:45.485432
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test 1
    token = Token(1, 2, 3)
    other = Token(1, 2, 3)
    assert token == other

    # Test 2
    token = Token(1, 2, 3)
    other = Token(2, 2, 3)
    assert not token == other

    # Test 3
    token = Token(1, 2, 3)
    other = Token(1, 3, 3)
    assert not token == other

    # Test 4
    token = Token(1, 2, 3)
    other = Token(1, 2, 4)
    assert not token == other

    # Test 5
    token = Token(1, 2, 3)
    other = "1"
    assert not token == other



# Generated at 2022-06-18 12:49:54.816723
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1}, 0, 0, "")
    assert token._value == {"a": 1}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""
    assert token.string == ""
    assert token.value == {"a": 1}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert token.__repr__() == "DictToken({'a': 1})"
    assert token.__eq__(token) == True
    assert token.__hash__() == hash({"a": 1})


# Generated at 2022-06-18 12:50:07.090434
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:50:12.141852
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1
    assert not Token(1, 2, 3) == None


# Generated at 2022-06-18 12:50:18.071357
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0)
    assert token == token
    assert token != None
    assert token != 1
    assert token != "foo"
    assert token != []
    assert token != {}
    assert token != (1, 2, 3)
    assert token != (1, 2, 3, 4)
    assert token != (1, 2, 3, 4, 5)
    assert token != (1, 2, 3, 4, 5, 6)
    assert token != (1, 2, 3, 4, 5, 6, 7)
    assert token != (1, 2, 3, 4, 5, 6, 7, 8)
    assert token != (1, 2, 3, 4, 5, 6, 7, 8, 9)

# Generated at 2022-06-18 12:50:27.599029
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=None, end_index=None, content=None)
    assert token == token
    assert not token == None
    assert not token == 1
    assert not token == "1"
    assert not token == []
    assert not token == {}
    assert not token == ()
    assert not token == object()
    assert not token == object
    assert not token == ScalarToken(value=None, start_index=None, end_index=None, content=None)
    assert not token == DictToken(value=None, start_index=None, end_index=None, content=None)
    assert not token == ListToken(value=None, start_index=None, end_index=None, content=None)


# Generated at 2022-06-18 12:50:50.691998
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken(value = {}, start_index = 0, end_index = 0, content = "")
    assert d._value == {}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""


# Generated at 2022-06-18 12:50:59.320528
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test for constructor of class DictToken
    # Arrange
    value = {'a': 1, 'b': 2}
    start_index = 0
    end_index = 1
    content = "ab"
    # Act
    token = DictToken(value, start_index, end_index, content)
    # Assert
    assert token._value == value
    assert token._start_index == start_index
    assert token._end_index == end_index
    assert token._content == content
    assert token._child_keys == {'a': 'a', 'b': 'b'}
    assert token._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:51:09.427937
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 10)
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 10
    assert d._content == ""
    assert d.string == ""
    assert d.value == {"a": 1, "b": 2}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 10)
    assert d.lookup([]) == d
    assert d.lookup_key([]) == d
    assert d._get_position(0) == Position(1, 1, 0)
    assert repr(d) == "DictToken('')"

# Generated at 2022-06-18 12:51:14.522612
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken({"a": 1}, 0, 1)
    assert dict_token._value == {"a": 1}
    assert dict_token._start_index == 0
    assert dict_token._end_index == 1
    assert dict_token._content == ""
    assert dict_token._child_keys == {"a": "a"}
    assert dict_token._child_tokens == {"a": 1}


# Generated at 2022-06-18 12:51:20.922221
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": "b"}, 0, 1, "a")
    assert token.value == {"a": "b"}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 1)
    assert token.string == "a"
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert token.lookup([0]) == token
    assert token.lookup_key([0]) == token


# Generated at 2022-06-18 12:51:28.871456
# Unit test for constructor of class DictToken

# Generated at 2022-06-18 12:51:32.141054
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({'a':1}, 0, 1)
    assert a._child_keys == {'a':1}
    assert a._child_tokens == {'a':1}


# Generated at 2022-06-18 12:51:37.741524
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a":1,"b":2},0,0)
    assert a._child_keys == {"a":1,"b":2}
    assert a._child_tokens == {"a":1,"b":2}
    assert a._value == {"a":1,"b":2}
    assert a._start_index == 0
    assert a._end_index == 0
    assert a._content == ""


# Generated at 2022-06-18 12:51:47.841932
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ''
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}
    assert dt.string == ''
    assert dt.value == {'a': 1, 'b': 2}
    assert dt.start == Position(1, 1, 0)
    assert dt.end == Position(1, 1, 0)
    assert dt.lookup(['a']) == 1
    assert dt.lookup

# Generated at 2022-06-18 12:51:53.290289
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 1, "ab")
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == "ab"
    assert d._child_keys == {"a": "a", "b": "b"}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:52:13.903534
# Unit test for constructor of class DictToken
def test_DictToken():
    class DictToken(Token):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)
            self._child_keys = {k._value: k for k in self._value.keys()}
            self._child_tokens = {k._value: v for k, v in self._value.items()}

        def _get_value(self) -> typing.Any:
            return {
                key_token._get_value(): value_token._get_value()
                for key_token, value_token in self._value.items()
            }

        def _get_child_token(self, key: typing.Any) -> Token:
            return self._child_tokens[key]


# Generated at 2022-06-18 12:52:24.398587
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a':1, 'b':2}
    dt = DictToken(d, 0, 0, 'a:1,b:2')
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == 'a:1,b:2'
    assert dt.string == 'a:1,b:2'
    assert dt.value == {'a':1, 'b':2}
    assert dt.start == Position(1, 1, 0)
    assert dt.end == Position(1, 1, 0)
    assert dt.lookup([]) == dt
    assert dt.lookup_key([]) == dt

# Generated at 2022-06-18 12:52:27.017577
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)


# Generated at 2022-06-18 12:52:30.260202
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({}, 0, 0)
    assert a._value == {}
    assert a._start_index == 0
    assert a._end_index == 0
    assert a._content == ""


# Generated at 2022-06-18 12:52:40.297898
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 1)
    assert d._value == {"a": 1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""
    assert d.string == ""
    assert d.value == {"a": 1}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 1)
    assert d.lookup([]) == d
    assert d.lookup_key([]) == d
    assert d._get_position(0) == Position(1, 1, 0)
    assert d.__repr__() == "DictToken({'a': 1})"
    assert d.__eq__(d) == True

# Generated at 2022-06-18 12:52:44.321390
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a": 1}, 0, 1)
    assert a._value == {"a": 1}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == ""


# Generated at 2022-06-18 12:52:55.576663
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test for constructor of class DictToken
    # Case 1:
    #   value = {'a': 'b'}
    #   start_index = 0
    #   end_index = 1
    #   content = 'ab'
    #   Expected result:
    #       _value = {'a': 'b'}
    #       _start_index = 0
    #       _end_index = 1
    #       _content = 'ab'
    #       _child_keys = {'a': 'a'}
    #       _child_tokens = {'a': 'b'}
    value = {'a': 'b'}
    start_index = 0
    end_index = 1
    content = 'ab'

# Generated at 2022-06-18 12:53:00.745717
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:53:04.586267
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(value = {}, start_index = 0, end_index = 0)
    assert token._value == {}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""


# Generated at 2022-06-18 12:53:06.201349
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1}, 0, 0, content="{}")


# Generated at 2022-06-18 12:53:43.214233
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({'a': 1}, 0, 1)
    assert a._value == {'a': 1}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == ""
    assert a.string == ""
    assert a.value == {'a': 1}
    assert a.start == Position(1, 1, 0)
    assert a.end == Position(1, 1, 1)
    assert a.lookup([]) == a
    assert a.lookup_key([]) == a
    assert a.__repr__() == "DictToken('')"
    assert a.__eq__(a) == True
    assert a.__hash__() == hash({'a': 1})


# Generated at 2022-06-18 12:53:49.417551
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 10, "a: 1\nb: 2")
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 10
    assert d._content == "a: 1\nb: 2"
    assert d.string == "a: 1\nb: 2"
    assert d.value == {"a": 1, "b": 2}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(2, 4, 10)
    assert d.lookup([]) == d
    assert d.lookup_key([]) == d
    assert d.lookup([0]) == 1
    assert d.lookup_key([0]) == "a"


# Generated at 2022-06-18 12:53:59.973550
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test case 1
    token = DictToken(
        {
            ScalarToken("a", 0, 0): ScalarToken(1, 0, 0),
            ScalarToken("b", 0, 0): ScalarToken(2, 0, 0),
        },
        0,
        0,
        "",
    )
    assert token._child_keys == {
        "a": ScalarToken("a", 0, 0),
        "b": ScalarToken("b", 0, 0),
    }
    assert token._child_tokens == {
        "a": ScalarToken(1, 0, 0),
        "b": ScalarToken(2, 0, 0),
    }
    # Test case 2

# Generated at 2022-06-18 12:54:02.960891
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({'a':1}, 0, 1)
    assert token._child_keys == {'a': 'a'}
    assert token._child_tokens == {'a': 1}


# Generated at 2022-06-18 12:54:09.001134
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 1, "a")
    assert d._value == {"a": 1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == "a"
    assert d._child_keys == {"a": "a"}
    assert d._child_tokens == {"a": 1}


# Generated at 2022-06-18 12:54:13.592763
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0)
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:54:16.514101
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken(value = {}, start_index = 0, end_index = 0, content = "")
    assert d._value == {}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""


# Generated at 2022-06-18 12:54:17.303520
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1}, 0, 1)

# Generated at 2022-06-18 12:54:21.202435
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(value={}, start_index=0, end_index=0, content="")
    assert token._value == {}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""


# Generated at 2022-06-18 12:54:26.613654
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}
