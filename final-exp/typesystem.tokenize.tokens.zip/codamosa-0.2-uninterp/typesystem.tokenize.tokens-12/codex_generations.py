

# Generated at 2022-06-18 12:45:15.989056
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != None
    assert Token(1, 2, 3) != "foo"
    assert Token(1, 2, 3) != object()


# Generated at 2022-06-18 12:45:26.383618
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0)
    assert token == token
    assert token != None
    assert token != 1
    assert token != "1"
    assert token != []
    assert token != {}
    assert token != ()
    assert token != (1,)
    assert token != (1, 2)
    assert token != [1]
    assert token != [1, 2]
    assert token != {"1": 1}
    assert token != {"1": 1, "2": 2}
    assert token != {"1": 1, "2": 2, "3": 3}
    assert token != {"1": 1, "2": 2, "3": 3, "4": 4}

# Generated at 2022-06-18 12:45:32.751096
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(2, 2, 3)
    token4 = Token(1, 3, 3)
    token5 = Token(1, 2, 4)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5


# Generated at 2022-06-18 12:45:42.566560
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ab")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcd")

# Generated at 2022-06-18 12:45:50.810278
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 4)
    assert Token(1, 2, 3) != Token(2, 3, 3)
    assert Token(1, 2, 3) != Token(2, 3, 4)
    assert Token(1, 2, 3) != Token(2, 4, 4)
    assert Token(1, 2, 3) != Token(2, 5, 5)
    assert Token(1, 2, 3) != Token(2, 6, 6)

# Generated at 2022-06-18 12:45:58.223975
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != None
    assert Token(1, 2, 3) != "1"


# Generated at 2022-06-18 12:46:07.584340
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ab")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcd")

# Generated at 2022-06-18 12:46:12.170247
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1}, 0, 1)
    assert token._value == {"a": 1}
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == ""


# Generated at 2022-06-18 12:46:24.514649
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:46:35.245638
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, 0, 0)
    assert token == token
    assert not (token != token)
    assert token != None
    assert not (token == None)
    assert token != 0
    assert not (token == 0)
    assert token != ""
    assert not (token == "")
    assert token != []
    assert not (token == [])
    assert token != {}
    assert not (token == {})
    assert token != ()
    assert not (token == ())
    assert token != set()
    assert not (token == set())
    assert token != frozenset()
    assert not (token == frozenset())
    assert token != object()
    assert not (token == object())
    assert token != object
    assert not (token == object)
    assert token != type
    assert not (token == type)
   

# Generated at 2022-06-18 12:46:41.042226
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken(value = {}, start_index = 0, end_index = 0, content = "")


# Generated at 2022-06-18 12:46:51.555675
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:46:57.351724
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(2, 2, 3)
    assert not (token1 == token3)
    token4 = Token(1, 3, 3)
    assert not (token1 == token4)
    token5 = Token(1, 2, 4)
    assert not (token1 == token5)


# Generated at 2022-06-18 12:47:03.310944
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(2, 2, 3)
    assert token1 != token3
    token4 = Token(1, 3, 3)
    assert token1 != token4
    token5 = Token(1, 2, 4)
    assert token1 != token5

# Generated at 2022-06-18 12:47:10.061664
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not (Token(1, 2, 3) == Token(1, 2, 4))
    assert not (Token(1, 2, 3) == Token(1, 3, 3))
    assert not (Token(1, 2, 3) == Token(2, 2, 3))
    assert not (Token(1, 2, 3) == 1)
    assert not (Token(1, 2, 3) == None)


# Generated at 2022-06-18 12:47:14.081484
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1, "b": 2}, 0, 0)
    assert token._value == {"a": 1, "b": 2}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""


# Generated at 2022-06-18 12:47:18.727985
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0)
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""


# Generated at 2022-06-18 12:47:25.665373
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == "foo"


# Generated at 2022-06-18 12:47:35.204745
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0)
    assert token == token
    assert token == Token(value=None, start_index=0, end_index=0)
    assert token != Token(value=None, start_index=1, end_index=0)
    assert token != Token(value=None, start_index=0, end_index=1)
    assert token != Token(value=None, start_index=0, end_index=0, content="")
    assert token != Token(value=None, start_index=0, end_index=0, content="a")
    assert token != Token(value=None, start_index=0, end_index=0, content="ab")

# Generated at 2022-06-18 12:47:42.118150
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken(
        {
            ScalarToken(1, 0, 0): ScalarToken(2, 0, 0),
            ScalarToken(3, 0, 0): ScalarToken(4, 0, 0),
        },
        0,
        0,
    )
    assert d._child_keys == {1: ScalarToken(1, 0, 0), 3: ScalarToken(3, 0, 0)}
    assert d._child_tokens == {1: ScalarToken(2, 0, 0), 3: ScalarToken(4, 0, 0)}


# Generated at 2022-06-18 12:47:51.929973
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(1, 2, 3)
    t2 = Token(1, 2, 3)
    assert t1 == t2
    t3 = Token(2, 2, 3)
    assert t1 != t3
    t4 = Token(1, 3, 3)
    assert t1 != t4
    t5 = Token(1, 2, 4)
    assert t1 != t5


# Generated at 2022-06-18 12:48:01.888806
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1}, 0, 0)
    assert token._get_value() == {"a": 1}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token.string == ""
    assert token.value == {"a": 1}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert token._get_position(0) == Position(1, 1, 0)
    assert repr(token) == "DictToken({'a': 1})"
    assert token == DictToken({"a": 1}, 0, 0)
    assert hash(token) == hash({"a": 1})



# Generated at 2022-06-18 12:48:06.570648
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(2, 2, 3)
    token4 = Token(1, 3, 3)
    token5 = Token(1, 2, 4)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5


# Generated at 2022-06-18 12:48:18.087594
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, 0, 0)
    assert token == token
    assert token == Token(None, 0, 0)
    assert not token == Token(None, 1, 0)
    assert not token == Token(None, 0, 1)
    assert not token == Token(None, 0, 0, "")
    assert not token == Token(None, 0, 0, "a")
    assert not token == Token(None, 0, 0, "ab")
    assert not token == Token(None, 0, 0, "abc")
    assert not token == Token(None, 0, 0, "abcd")
    assert not token == Token(None, 0, 0, "abcde")
    assert not token == Token(None, 0, 0, "abcdef")
    assert not token == Token(None, 0, 0, "abcdefg")


# Generated at 2022-06-18 12:48:25.026790
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0, "")
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""


# Generated at 2022-06-18 12:48:28.847582
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test for constructor of class DictToken
    # Arrange
    # Act
    # Assert
    assert DictToken({"a": 1}, 0, 1, "a")


# Generated at 2022-06-18 12:48:31.640928
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test for constructor of class DictToken
    # Arrange
    # Act
    # Assert
    assert DictToken({"a": 1}, 0, 1, "a")


# Generated at 2022-06-18 12:48:42.522901
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 3, 4)
    assert not Token(1, 2, 3) == Token(2, 4, 4)
    assert not Token(1, 2, 3) == Token(2, 4, 5)
    assert not Token(1, 2, 3) == Token(2, 5, 5)
    assert not Token(1, 2, 3)

# Generated at 2022-06-18 12:48:48.673709
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert token == Token(1, 2, 3)
    assert token != Token(2, 2, 3)
    assert token != Token(1, 3, 3)
    assert token != Token(1, 2, 4)
    assert token != Token(1, 2, 3, "foo")
    assert token != Token(1, 2, 3, "bar")
    assert token != "foo"


# Generated at 2022-06-18 12:48:50.679562
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:49:04.743881
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(value = {}, start_index = 0, end_index = 0, content = "")
    assert token._value == {}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""


# Generated at 2022-06-18 12:49:10.051660
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == None


# Generated at 2022-06-18 12:49:21.787445
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "a")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "ab")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "abc")

# Generated at 2022-06-18 12:49:30.655756
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(None, 0, 0) == Token(None, 0, 0)
    assert not Token(None, 0, 0) == Token(None, 0, 1)
    assert not Token(None, 0, 0) == Token(None, 1, 0)
    assert not Token(None, 0, 0) == Token(None, 1, 1)
    assert not Token(None, 0, 0) == Token(None, 0, 0, "")
    assert not Token(None, 0, 0) == Token(None, 0, 0, "a")
    assert not Token(None, 0, 0) == Token(None, 0, 0, "b")
    assert not Token(None, 0, 0) == Token(None, 0, 0, "ab")

# Generated at 2022-06-18 12:49:35.079369
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(value=1, start_index=2, end_index=3)
    token2 = Token(value=1, start_index=2, end_index=3)
    assert token1 == token2


# Generated at 2022-06-18 12:49:45.921297
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test constructor of class DictToken
    # Test case 1
    token = DictToken(
        {
            ScalarToken(1, 0, 0): ScalarToken(2, 1, 1),
            ScalarToken(3, 2, 2): ScalarToken(4, 3, 3),
        },
        0,
        3,
        content="1234",
    )
    assert token._value == {
        ScalarToken(1, 0, 0): ScalarToken(2, 1, 1),
        ScalarToken(3, 2, 2): ScalarToken(4, 3, 3),
    }
    assert token._start_index == 0
    assert token._end_index == 3
    assert token._content == "1234"

# Generated at 2022-06-18 12:49:54.384275
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "a")
    assert not Token(1, 2, 3) == 1
    assert not Token(1, 2, 3) == "a"


# Generated at 2022-06-18 12:50:00.273166
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0)
    assert d._child_keys["a"] == "a"
    assert d._child_keys["b"] == "b"
    assert d._child_tokens["a"] == 1
    assert d._child_tokens["b"] == 2


# Generated at 2022-06-18 12:50:06.541532
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a":1}, 0, 1, "a")
    assert d._value == {"a":1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == "a"
    assert d._child_keys == {"a":1}
    assert d._child_tokens == {"a":1}


# Generated at 2022-06-18 12:50:12.839831
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for method __eq__ of class Token
    # Setup
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(2, 2, 3)
    token4 = Token(1, 3, 3)
    token5 = Token(1, 2, 4)
    # Test
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5
    assert token1 != 1
    assert token1 != "1"
    assert token1 != None
    # Teardown


# Generated at 2022-06-18 12:50:36.111992
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3, "abc")
    token2 = Token(1, 2, 3, "abc")
    token3 = Token(1, 2, 3, "abc")
    assert token1 == token2
    assert token2 == token3
    assert token1 == token3
    assert token1 == token1
    assert token2 == token2
    assert token3 == token3
    assert token1 != token2
    assert token2 != token3
    assert token1 != token3
    assert token1 != token1
    assert token2 != token2
    assert token3 != token3
    assert token1 != token2
    assert token2 != token3
    assert token1 != token3
    assert token1 != token1
    assert token2 != token2
    assert token3 != token3
    assert token1 != token2

# Generated at 2022-06-18 12:50:45.807063
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0, content="")
    assert token == token
    assert token == Token(value=None, start_index=0, end_index=0, content="")
    assert token != Token(value=None, start_index=1, end_index=0, content="")
    assert token != Token(value=None, start_index=0, end_index=1, content="")
    assert token != Token(value=None, start_index=0, end_index=0, content="a")
    assert token != Token(value=1, start_index=0, end_index=0, content="")
    assert token != None


# Generated at 2022-06-18 12:50:55.948863
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "foo")
    assert Token(1, 2, 3) != Token(1, 2, 3, "bar")
    assert Token(1, 2, 3) != Token(1, 2, 3, "foo", "bar")
    assert Token(1, 2, 3) != Token(1, 2, 3, "bar", "foo")

# Generated at 2022-06-18 12:51:01.328762
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert token == Token(1, 2, 3)
    assert token != Token(1, 2, 4)
    assert token != Token(1, 3, 3)
    assert token != Token(2, 2, 3)
    assert token != 1
    assert token != None
    assert token != "1"


# Generated at 2022-06-18 12:51:10.971979
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class TokenSubclass(Token):
        def __init__(self, value: typing.Any, start_index: int, end_index: int, content: str = ""):
            super().__init__(value, start_index, end_index, content)
        def _get_value(self) -> typing.Any:
            return self._value
        def _get_child_token(self, key: typing.Any) -> "Token":
            raise NotImplementedError  # pragma: nocover
        def _get_key_token(self, key: typing.Any) -> "Token":
            raise NotImplementedError  # pragma: nocover
    token1 = TokenSubclass(1, 0, 0)
    token2 = TokenSubclass(1, 0, 0)

# Generated at 2022-06-18 12:51:20.336391
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a":1, "b":2}, 0, 1, "a:1, b:2")
    assert d._value == {"a":1, "b":2}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == "a:1, b:2"
    assert d.string == "a:1, b:2"
    assert d.value == {"a":1, "b":2}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 1)
    assert d.lookup([0]) == 1
    assert d.lookup_key([0]) == "a"
    assert d._get_position(1) == Position(1, 1, 1)

# Generated at 2022-06-18 12:51:25.043063
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(2, 2, 3)
    token4 = Token(1, 3, 3)
    token5 = Token(1, 2, 4)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5


# Generated at 2022-06-18 12:51:28.510179
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != None


# Generated at 2022-06-18 12:51:34.047325
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(2, 2, 3)
    assert token1 != token3
    token4 = Token(1, 3, 3)
    assert token1 != token4
    token5 = Token(1, 2, 4)
    assert token1 != token5


# Generated at 2022-06-18 12:51:37.364670
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=None, end_index=None, content=None)
    other = Token(value=None, start_index=None, end_index=None, content=None)
    assert token == other


# Generated at 2022-06-18 12:52:20.824112
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, 0, 0)
    assert token == token
    assert token != None
    assert token != 1
    assert token != "1"
    assert token != []
    assert token != {}
    assert token != ()
    assert token != Token(None, 0, 0)
    assert token != Token(None, 1, 0)
    assert token != Token(None, 0, 1)
    assert token != Token(None, 1, 1)
    assert token != Token(None, 0, 0, "")
    assert token != Token(None, 0, 0, "1")
    assert token != Token(None, 0, 0, "12")
    assert token != Token(None, 0, 0, "123")
    assert token != Token(None, 0, 0, "1234")

# Generated at 2022-06-18 12:52:26.501678
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(2, 2, 3)
    assert token1 != token3
    token4 = Token(1, 3, 3)
    assert token1 != token4
    token5 = Token(1, 2, 4)
    assert token1 != token5


# Generated at 2022-06-18 12:52:37.496478
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for class Token
    token = Token(None, 0, 0)
    assert token == token
    assert not token == None
    assert not token == "foo"
    assert not token == Token(None, 0, 1)
    assert not token == Token(None, 1, 0)
    assert not token == Token(None, 1, 1)
    assert not token == Token(None, 0, 0, "foo")
    assert not token == Token(None, 0, 0, "bar")
    assert not token == Token(None, 0, 0, "foobar")
    assert not token == Token(None, 0, 0, "barfoo")
    assert not token == Token(None, 0, 0, "foo")
    assert not token == Token(None, 0, 0, "bar")

# Generated at 2022-06-18 12:52:43.786692
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": "b"}, 0, 1)
    assert d._value == {"a": "b"}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""
    assert d.string == ""
    assert d.value == {"a": "b"}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 1)
    assert d.lookup([]) == d
    assert d.lookup_key([]) == d
    assert d._get_position(0) == Position(1, 1, 0)
    assert repr(d) == "DictToken({'a': 'b'})"
    assert d == DictToken({"a": "b"}, 0, 1)
    assert d != D

# Generated at 2022-06-18 12:52:49.730895
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == object()


# Generated at 2022-06-18 12:52:55.615016
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(1, 2, 4)
    token4 = Token(1, 3, 3)
    token5 = Token(2, 2, 3)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5


# Generated at 2022-06-18 12:53:06.163576
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ab")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcd")

# Generated at 2022-06-18 12:53:14.202975
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(2, 2, 3)
    token4 = Token(1, 3, 3)
    token5 = Token(1, 2, 4)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5


# Generated at 2022-06-18 12:53:23.941343
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, 0, 0)
    assert token == token
    assert token != None
    assert token != 1
    assert token != "foo"
    assert token != []
    assert token != {}
    assert token != type(token)
    assert token != type(token)()
    assert token != type(token)(None, 0, 0)
    assert token != type(token)(None, 0, 1)
    assert token != type(token)(None, 1, 0)
    assert token != type(token)(None, 1, 1)
    assert token != type(token)(1, 0, 0)
    assert token != type(token)(1, 0, 1)
    assert token != type(token)(1, 1, 0)
    assert token != type(token)(1, 1, 1)

# Generated at 2022-06-18 12:53:25.738132
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:54:17.683960
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ab")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcd")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcde")

# Generated at 2022-06-18 12:54:24.303569
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != "abc"


# Generated at 2022-06-18 12:54:31.430317
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ''
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:54:38.896223
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1
    assert not Token(1, 2, 3) == None
    assert not Token(1, 2, 3) == "1"


# Generated at 2022-06-18 12:54:44.581706
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:54:54.520769
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test 1
    token = DictToken({'a': 1, 'b': 2}, 0, 0, '{a:1,b:2}')
    assert token._child_keys == {'a': 'a', 'b': 'b'}
    assert token._child_tokens == {'a': 1, 'b': 2}
    assert token._value == {'a': 1, 'b': 2}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == '{a:1,b:2}'
    assert token.string == '{a:1,b:2}'
    assert token.value == {'a': 1, 'b': 2}
    assert token.start == Position(1, 1, 0)

# Generated at 2022-06-18 12:55:05.661640
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ab")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcd")