

# Generated at 2022-06-18 12:45:17.103610
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": "b"}, 0, 1)
    assert d._value == {"a": "b"}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""


# Generated at 2022-06-18 12:45:27.531908
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({'a': 'b'}, 0, 1)
    assert token._value == {'a': 'b'}
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == ""
    assert token.string == ""
    assert token.value == {'a': 'b'}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 1)
    assert token.lookup(['a']) == 'b'
    assert token.lookup_key(['a']) == 'a'
    assert token._get_position(1) == Position(1, 1, 1)
    assert repr(token) == "DictToken('')"

# Generated at 2022-06-18 12:45:32.354189
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0)
    assert d._child_keys == {"a": "a", "b": "b"}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:45:36.079205
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({'a': 1}, 0, 1, 'a')
    assert token._child_keys == {'a': 'a'}
    assert token._child_tokens == {'a': 1}


# Generated at 2022-06-18 12:45:44.710781
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({'a': 1}, 0, 1)
    assert a._value == {'a': 1}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == ""
    assert a.string == ""
    assert a.value == {'a': 1}
    assert a.start == Position(1, 1, 0)
    assert a.end == Position(1, 1, 1)
    assert a.lookup([]) == a
    assert a.lookup_key([]) == a
    assert a.__repr__() == "DictToken('')"
    assert a.__eq__(a) == True
    assert a.__hash__() == hash({'a': 1})


# Generated at 2022-06-18 12:45:50.336663
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.base import Position
    from typesystem.base import Token
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import Token
    from typesystem.base import Position
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import Token
    from typesystem.base import Position
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import Token
    from typesystem.base import Position
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken

# Generated at 2022-06-18 12:46:01.485663
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ab")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcd")

# Generated at 2022-06-18 12:46:06.925867
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 1, "a")
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == "a"
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:46:09.769142
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:46:21.350904
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 4)
    assert not Token(1, 2, 3) == Token(2, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 3, 4)
    assert not Token(1, 2, 3) == Token(3, 2, 3)
    assert not Token(1, 2, 3) == Token(3, 2, 4)
    assert not Token(1, 2, 3)

# Generated at 2022-06-18 12:46:35.897235
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, 0, 0)
    assert token == token
    assert token == Token(None, 0, 0)
    assert token != Token(None, 0, 1)
    assert token != Token(None, 1, 0)
    assert token != Token(None, 1, 1)
    assert token != Token(None, 0, 0, "a")
    assert token != Token(None, 0, 0, "b")
    assert token != Token(None, 0, 0, "a", "b")
    assert token != Token(None, 0, 0, "b", "a")
    assert token != Token(None, 0, 0, "a", "a")
    assert token != Token(None, 0, 0, "b", "b")
    assert token != Token(None, 0, 0, "a", "b", "c")

# Generated at 2022-06-18 12:46:44.515249
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test case 1
    token1 = Token(1, 2, 3, "abc")
    token2 = Token(1, 2, 3, "abc")
    assert token1 == token2
    # Test case 2
    token1 = Token(1, 2, 3, "abc")
    token2 = Token(2, 2, 3, "abc")
    assert not token1 == token2
    # Test case 3
    token1 = Token(1, 2, 3, "abc")
    token2 = Token(1, 3, 3, "abc")
    assert not token1 == token2
    # Test case 4
    token1 = Token(1, 2, 3, "abc")
    token2 = Token(1, 2, 4, "abc")
    assert not token1 == token2
    # Test case 5

# Generated at 2022-06-18 12:46:47.488455
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3, "abc")
    token2 = Token(1, 2, 3, "abc")
    assert token1 == token2


# Generated at 2022-06-18 12:46:58.281671
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, 0, 0)
    assert token == token
    assert token == Token(None, 0, 0)
    assert token != Token(None, 0, 1)
    assert token != Token(None, 1, 0)
    assert token != Token(None, 1, 1)
    assert token != Token(None, 0, 0, "foo")
    assert token != Token(None, 0, 0, "bar")
    assert token != Token(1, 0, 0)
    assert token != Token(1, 0, 0, "foo")
    assert token != Token(1, 0, 0, "bar")
    assert token != Token(1, 0, 1)
    assert token != Token(1, 1, 0)
    assert token != Token(1, 1, 1)

# Generated at 2022-06-18 12:47:09.058473
# Unit test for constructor of class DictToken

# Generated at 2022-06-18 12:47:14.984931
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:47:27.811997
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test case 1
    token = DictToken(
        {
            ScalarToken(1, 0, 0): ScalarToken(2, 0, 0),
            ScalarToken(3, 0, 0): ScalarToken(4, 0, 0),
        },
        0,
        0,
    )
    assert token._child_keys == {1: ScalarToken(1, 0, 0), 3: ScalarToken(3, 0, 0)}
    assert token._child_tokens == {
        1: ScalarToken(2, 0, 0),
        3: ScalarToken(4, 0, 0),
    }
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""

# Generated at 2022-06-18 12:47:33.070767
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1
    assert not Token(1, 2, 3) == None


# Generated at 2022-06-18 12:47:43.377758
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import Token
    from typesystem.base import Position
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import Position
    from typesystem.base import Token
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import Position
    from typesystem.base import Token
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import Position
    from typesystem.base import Token
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken

# Generated at 2022-06-18 12:47:50.463198
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(2, 2, 3)
    assert token1 != token3
    token4 = Token(1, 3, 3)
    assert token1 != token4
    token5 = Token(1, 2, 4)
    assert token1 != token5


# Generated at 2022-06-18 12:48:07.344519
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(value=1, start_index=2, end_index=3, content="")
    token2 = Token(value=1, start_index=2, end_index=3, content="")
    assert token1 == token2


# Generated at 2022-06-18 12:48:15.778508
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != object()


# Generated at 2022-06-18 12:48:21.010702
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(2, 2, 3)
    assert not token1 == token3
    token4 = Token(1, 3, 3)
    assert not token1 == token4
    token5 = Token(1, 2, 4)
    assert not token1 == token5


# Generated at 2022-06-18 12:48:25.271339
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0, content="")
    other = Token(value=None, start_index=0, end_index=0, content="")
    assert token == other


# Generated at 2022-06-18 12:48:30.953062
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken({"a": 1, "b": 2}, 0, 5)
    assert t._child_keys["a"]._value == "a"
    assert t._child_keys["b"]._value == "b"
    assert t._child_tokens["a"]._value == 1
    assert t._child_tokens["b"]._value == 2

# Generated at 2022-06-18 12:48:41.813422
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ab")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcd")

# Generated at 2022-06-18 12:48:51.738006
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:49:03.176421
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=None, end_index=None)
    assert token == token
    assert token == Token(value=None, start_index=None, end_index=None)
    assert not token == None
    assert not token == Token(value=None, start_index=None, end_index=None, content=None)
    assert not token == Token(value=None, start_index=None, end_index=None, content=None)
    assert not token == Token(value=None, start_index=None, end_index=None, content=None)
    assert not token == Token(value=None, start_index=None, end_index=None, content=None)
    assert not token == Token(value=None, start_index=None, end_index=None, content=None)
   

# Generated at 2022-06-18 12:49:10.123148
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != None
    assert Token(1, 2, 3) != "1"


# Generated at 2022-06-18 12:49:17.693483
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "abc")
    assert not Token(1, 2, 3) == object()


# Generated at 2022-06-18 12:49:31.875780
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == 1

# Generated at 2022-06-18 12:49:43.108154
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 4)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "b")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ab")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ba")

# Generated at 2022-06-18 12:49:53.645512
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "a")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "ab")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "abc")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "abcd")

# Generated at 2022-06-18 12:50:00.914357
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != None


# Generated at 2022-06-18 12:50:10.800042
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3, "") == Token(1, 2, 3, "")
    assert Token(1, 2, 3, "") != Token(1, 2, 3, "a")
    assert Token(1, 2, 3, "a") != Token(1, 2, 3, "b")

# Generated at 2022-06-18 12:50:17.155665
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(2, 3, 3)
    assert Token(1, 2, 3) != Token(2, 3, 4)
    assert Token(1, 2, 3) != Token(2, 4, 3)
    assert Token(1, 2, 3) != Token(2, 4, 4)
    assert Token(1, 2, 3) != Token(2, 5, 3)
    assert Token(1, 2, 3) != Token(2, 5, 4)

# Generated at 2022-06-18 12:50:20.210587
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(value=1, start_index=1, end_index=1)
    token2 = Token(value=1, start_index=1, end_index=1)
    assert token1 == token2


# Generated at 2022-06-18 12:50:25.571724
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == object()


# Generated at 2022-06-18 12:50:35.324880
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 4)
    assert not Token(1, 2, 3) == Token(2, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 3, 4)
    assert not Token(1, 2, 3) == Token(2, 4, 4)
    assert not Token(1, 2, 3) == Token(2, 4, 5)
    assert not Token(1, 2, 3)

# Generated at 2022-06-18 12:50:46.043911
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ab")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcd")

# Generated at 2022-06-18 12:51:25.281624
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:51:33.550650
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:51:36.803884
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(1, 2, 4)
    assert token1 != token3


# Generated at 2022-06-18 12:51:47.016881
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0)
    assert token == token
    assert token == Token(value=None, start_index=0, end_index=0)
    assert token != Token(value=None, start_index=1, end_index=0)
    assert token != Token(value=None, start_index=0, end_index=1)
    assert token != Token(value=None, start_index=0, end_index=0, content="")
    assert token != Token(value=None, start_index=0, end_index=0, content="a")
    assert token != Token(value=None, start_index=0, end_index=0, content="ab")

# Generated at 2022-06-18 12:51:56.744209
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=None, end_index=None, content=None)
    assert token == token
    assert not (token != token)
    assert token == Token(value=None, start_index=None, end_index=None, content=None)
    assert not (token != Token(value=None, start_index=None, end_index=None, content=None))
    assert token != Token(value=None, start_index=None, end_index=None, content=None)
    assert not (token == Token(value=None, start_index=None, end_index=None, content=None))
    assert token != Token(value=None, start_index=None, end_index=None, content=None)

# Generated at 2022-06-18 12:52:06.354604
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:52:09.923632
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:52:16.029027
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "a")
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:52:19.661591
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0)
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:52:30.313602
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {
        "a": 1,
        "b": 2,
        "c": 3,
    }
    d_token = DictToken(d, 0, 0, "")
    assert d_token._child_keys == {
        "a": ScalarToken("a", 0, 0, ""),
        "b": ScalarToken("b", 0, 0, ""),
        "c": ScalarToken("c", 0, 0, ""),
    }
    assert d_token._child_tokens == {
        "a": ScalarToken(1, 0, 0, ""),
        "b": ScalarToken(2, 0, 0, ""),
        "c": ScalarToken(3, 0, 0, ""),
    }


# Generated at 2022-06-18 12:53:42.943870
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ""
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:53:49.286587
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ab")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcd")

# Generated at 2022-06-18 12:53:57.359890
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "abc")
    assert not Token(1, 2, 3) == None
    assert not Token(1, 2, 3) == "abc"


# Generated at 2022-06-18 12:54:05.250395
# Unit test for constructor of class DictToken

# Generated at 2022-06-18 12:54:16.841414
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ab")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcd")

# Generated at 2022-06-18 12:54:27.656218
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ab")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcd")

# Generated at 2022-06-18 12:54:38.286064
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for class ScalarToken
    token1 = ScalarToken(1, 0, 1)
    token2 = ScalarToken(1, 0, 1)
    token3 = ScalarToken(2, 0, 1)
    assert token1 == token2
    assert token1 != token3
    # Test for class DictToken
    token1 = DictToken({ScalarToken(1, 0, 1): ScalarToken(2, 0, 1)}, 0, 1)
    token2 = DictToken({ScalarToken(1, 0, 1): ScalarToken(2, 0, 1)}, 0, 1)
    token3 = DictToken({ScalarToken(2, 0, 1): ScalarToken(2, 0, 1)}, 0, 1)
    assert token1 == token2
    assert token1 != token3

# Generated at 2022-06-18 12:54:48.985592
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 4)
    assert Token(1, 2, 3) != Token(2, 3, 3)
    assert Token(1, 2, 3) != Token(2, 3, 4)
    assert Token(1, 2, 3) != Token(2, 4, 3)
    assert Token(1, 2, 3) != Token(2, 4, 4)
    assert Token(1, 2, 3) != Token(2, 5, 3)

# Generated at 2022-06-18 12:54:55.087895
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test that two tokens are equal if their values, start indices and end indices are equal
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(2, 2, 3)
    assert token1 != token3
    token4 = Token(1, 3, 3)
    assert token1 != token4
    token5 = Token(1, 2, 4)
    assert token1 != token5


# Generated at 2022-06-18 12:54:59.381007
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(value=None, start_index=0, end_index=0, content="")
    token2 = Token(value=None, start_index=0, end_index=0, content="")
    assert token1 == token2
