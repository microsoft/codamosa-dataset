

# Generated at 2022-06-18 12:45:23.337523
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(None, 0, 0) == Token(None, 0, 0)
    assert not Token(None, 0, 0) == Token(None, 0, 1)
    assert not Token(None, 0, 0) == Token(None, 1, 0)
    assert not Token(None, 0, 0) == Token(None, 1, 1)
    assert not Token(None, 0, 0) == Token(None, 0, 0, "")
    assert not Token(None, 0, 0) == Token(None, 0, 0, "a")
    assert not Token(None, 0, 0) == Token(None, 0, 0, "ab")
    assert not Token(None, 0, 0) == Token(None, 0, 0, "abc")

# Generated at 2022-06-18 12:45:34.437524
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ab")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcd")

# Generated at 2022-06-18 12:45:43.905166
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test 1
    dict_token = DictToken(
        {
            ScalarToken(1, 0, 0): ScalarToken(2, 0, 0),
            ScalarToken(3, 0, 0): ScalarToken(4, 0, 0),
        },
        0,
        0,
    )
    assert dict_token._value == {
        ScalarToken(1, 0, 0): ScalarToken(2, 0, 0),
        ScalarToken(3, 0, 0): ScalarToken(4, 0, 0),
    }
    assert dict_token._start_index == 0
    assert dict_token._end_index == 0
    assert dict_token._content == ""

# Generated at 2022-06-18 12:45:51.505652
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test with two equal tokens
    token1 = ScalarToken(1, 0, 0)
    token2 = ScalarToken(1, 0, 0)
    assert token1 == token2

    # Test with two unequal tokens
    token1 = ScalarToken(1, 0, 0)
    token2 = ScalarToken(2, 0, 0)
    assert not token1 == token2

    # Test with a token and a non-token
    token1 = ScalarToken(1, 0, 0)
    assert not token1 == 1


# Generated at 2022-06-18 12:45:57.673566
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != 1


# Generated at 2022-06-18 12:46:07.068312
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test 1
    token = DictToken(value = {}, start_index = 0, end_index = 0, content = "")
    assert token._value == {}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""
    assert token.string == ""
    assert token.value == {}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert token._get_position(0) == Position(1, 1, 0)
    assert repr(token) == "DictToken('')"

# Generated at 2022-06-18 12:46:15.221311
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1
    assert not Token(1, 2, 3) == None


# Generated at 2022-06-18 12:46:19.040700
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 1)
    assert d._value == {"a": 1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""


# Generated at 2022-06-18 12:46:30.029990
# Unit test for constructor of class DictToken

# Generated at 2022-06-18 12:46:31.790969
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1}, 0, 1, "a")


# Generated at 2022-06-18 12:46:49.248695
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0, "")
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}
    assert d._get_value() == {"a": 1, "b": 2}
    assert d._get_child_token("a") == 1
    assert d._get_key_token("a") == 1


# Generated at 2022-06-18 12:46:56.669713
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != "abc"


# Generated at 2022-06-18 12:47:00.828168
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a":1, "b":2}, 0, 1, "a:1, b:2") == DictToken({"a":1, "b":2}, 0, 1, "a:1, b:2")
    assert DictToken({"a":1, "b":2}, 0, 1, "a:1, b:2") != DictToken({"a":1, "b":2}, 0, 2, "a:1, b:2")
    assert DictToken({"a":1, "b":2}, 0, 1, "a:1, b:2") != DictToken({"a":1, "b":3}, 0, 1, "a:1, b:2")

# Generated at 2022-06-18 12:47:02.196119
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1}, 0, 1)
    assert token._value == {"a": 1}
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == ""


# Generated at 2022-06-18 12:47:12.090680
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a":1, "b":2}, 0, 1, "a:1, b:2")
    assert d._value == {"a":1, "b":2}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == "a:1, b:2"
    assert d.string == "a:1, b:2"
    assert d.value == {"a":1, "b":2}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 1)
    assert d.lookup([]) == d
    assert d.lookup_key([]) == d
    assert d._get_position(0) == Position(1, 1, 0)

# Generated at 2022-06-18 12:47:13.562632
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1}, 0, 1)


# Generated at 2022-06-18 12:47:20.495511
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:47:28.203709
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    t = DictToken(d, 0, 0, 'a: 1\nb: 2')
    assert t._value == d
    assert t._child_keys == {'a': 'a', 'b': 'b'}
    assert t._child_tokens == {'a': 1, 'b': 2}
    assert t._start_index == 0
    assert t._end_index == 0
    assert t._content == 'a: 1\nb: 2'


# Generated at 2022-06-18 12:47:32.744340
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:47:36.746741
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({'a':1}, 0, 1)
    assert d._child_keys == {'a': 'a'}
    assert d._child_tokens == {'a': 1}


# Generated at 2022-06-18 12:48:12.759311
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0)
    assert token == token
    assert token == Token(value=None, start_index=0, end_index=0)
    assert not token == Token(value=None, start_index=1, end_index=0)
    assert not token == Token(value=None, start_index=0, end_index=1)
    assert not token == Token(value=None, start_index=0, end_index=0, content="")
    assert not token == Token(value=None, start_index=0, end_index=0, content="a")
    assert not token == Token(value=None, start_index=0, end_index=0, content="b")

# Generated at 2022-06-18 12:48:19.769809
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(1, 2, 3)
    t2 = Token(1, 2, 3)
    t3 = Token(1, 2, 4)
    t4 = Token(2, 2, 3)
    t5 = Token(1, 3, 3)
    t6 = Token(1, 2, 2)
    assert t1 == t2
    assert t1 != t3
    assert t1 != t4
    assert t1 != t5
    assert t1 != t6


# Generated at 2022-06-18 12:48:25.873017
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(1, 2, 3)
    t2 = Token(1, 2, 3)
    t3 = Token(2, 2, 3)
    t4 = Token(1, 3, 3)
    t5 = Token(1, 2, 4)
    assert t1 == t2
    assert t1 != t3
    assert t1 != t4
    assert t1 != t5


# Generated at 2022-06-18 12:48:36.466959
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0, content="")
    assert token == token
    assert not (token != token)
    assert not (token == None)
    assert token != None
    assert not (token == 0)
    assert token != 0
    assert not (token == "")
    assert token != ""
    assert not (token == [])
    assert token != []
    assert not (token == {})
    assert token != {}
    assert not (token == ())
    assert token != ()
    assert not (token == [0])
    assert token != [0]
    assert not (token == (0,))
    assert token != (0,)
    assert not (token == {"a": 0})
    assert token != {"a": 0}
    assert not (token == "0")
   

# Generated at 2022-06-18 12:48:47.634634
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for class ScalarToken
    assert ScalarToken(1, 0, 0) == ScalarToken(1, 0, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(2, 0, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 1, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 0, 1)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 0, 0, "1")
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 0, 0, "12")
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 0, 0, "123")

# Generated at 2022-06-18 12:48:57.701747
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ab")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcd")

# Generated at 2022-06-18 12:49:04.840237
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(2, 2, 3)
    token4 = Token(1, 3, 3)
    token5 = Token(1, 2, 4)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5


# Generated at 2022-06-18 12:49:13.066092
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for class ScalarToken
    assert ScalarToken(1, 0, 0) == ScalarToken(1, 0, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(2, 0, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 1, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 0, 1)
    # Test for class DictToken
    assert DictToken({}, 0, 0) == DictToken({}, 0, 0)
    assert DictToken({}, 0, 0) != DictToken({1: 1}, 0, 0)
    assert DictToken({1: 1}, 0, 0) != DictToken({2: 1}, 0, 0)

# Generated at 2022-06-18 12:49:19.102271
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(2, 2, 3)
    assert token1 != token3
    token4 = Token(1, 3, 3)
    assert token1 != token4
    token5 = Token(1, 2, 4)
    assert token1 != token5


# Generated at 2022-06-18 12:49:24.785575
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(2, 2, 3)
    token4 = Token(1, 3, 3)
    token5 = Token(1, 2, 4)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5


# Generated at 2022-06-18 12:50:01.539238
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(1, 2, 4)
    assert token1 == token2
    assert token1 != token3


# Generated at 2022-06-18 12:50:08.277773
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(1, 2, 4)
    token4 = Token(2, 2, 3)
    token5 = Token(1, 3, 3)
    token6 = Token(1, 2, 2)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5
    assert token1 != token6


# Generated at 2022-06-18 12:50:13.129481
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(1, 2, 4)
    token4 = Token(1, 3, 3)
    token5 = Token(2, 2, 3)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5


# Generated at 2022-06-18 12:50:23.204494
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(2, 3, 4)
    assert not Token(1, 2, 3) == Token(2, 3, 4)
    assert not Token(1, 2, 3) == Token(2, 3, 4)
    assert not Token(1, 2, 3) == Token(2, 3, 4)
    assert not Token(1, 2, 3) == Token(2, 3, 4)
    assert not Token(1, 2, 3)

# Generated at 2022-06-18 12:50:28.384943
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == None

# Generated at 2022-06-18 12:50:38.126333
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ab")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcd")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcde")

# Generated at 2022-06-18 12:50:44.304323
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a": 1}, 0, 1, "a")
    assert a._value == {"a": 1}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == "a"
    assert a._child_keys == {"a": 1}
    assert a._child_tokens == {"a": 1}


# Generated at 2022-06-18 12:50:50.125050
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(2, 2, 3)
    token4 = Token(1, 3, 3)
    token5 = Token(1, 2, 4)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5


# Generated at 2022-06-18 12:50:58.141339
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=None, end_index=None, content=None)
    assert token == token
    assert not (token != token)
    assert token == Token(value=None, start_index=None, end_index=None, content=None)
    assert not (token != Token(value=None, start_index=None, end_index=None, content=None))
    assert token != Token(value=None, start_index=None, end_index=None, content=None)
    assert not (token == Token(value=None, start_index=None, end_index=None, content=None))


# Generated at 2022-06-18 12:51:04.008678
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != None


# Generated at 2022-06-18 12:52:04.277505
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(value=1, start_index=1, end_index=2, content="")
    token2 = Token(value=1, start_index=1, end_index=2, content="")
    token3 = Token(value=2, start_index=1, end_index=2, content="")
    token4 = Token(value=1, start_index=2, end_index=2, content="")
    token5 = Token(value=1, start_index=1, end_index=3, content="")
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5


# Generated at 2022-06-18 12:52:08.633634
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:52:13.320300
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3, 4)
    token2 = Token(1, 2, 3, 4)
    token3 = Token(1, 2, 3, 5)
    token4 = Token(1, 2, 4, 4)
    token5 = Token(1, 3, 3, 4)
    token6 = Token(2, 2, 3, 4)
    assert token1 == token2
    assert not token1 == token3
    assert not token1 == token4
    assert not token1 == token5
    assert not token1 == token6


# Generated at 2022-06-18 12:52:14.537966
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:52:25.443689
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 4)
    assert not Token(1, 2, 3) == Token(2, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 4)
    assert not Token(1, 2, 3)

# Generated at 2022-06-18 12:52:27.489662
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:52:35.926731
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3, "abc")
    token2 = Token(1, 2, 3, "abc")
    token3 = Token(2, 2, 3, "abc")
    token4 = Token(1, 3, 3, "abc")
    token5 = Token(1, 2, 4, "abc")
    token6 = Token(1, 2, 3, "abcd")
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5
    assert token1 != token6


# Generated at 2022-06-18 12:52:45.809018
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0, content="")
    assert token == token
    assert token == Token(value=None, start_index=0, end_index=0, content="")
    assert token != Token(value=None, start_index=1, end_index=0, content="")
    assert token != Token(value=None, start_index=0, end_index=1, content="")
    assert token != Token(value=None, start_index=0, end_index=0, content="a")
    assert token != Token(value=1, start_index=0, end_index=0, content="")
    assert token != Token(value=None, start_index=0, end_index=0, content="")
    assert token != None

# Generated at 2022-06-18 12:52:51.993403
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:52:56.664156
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(value = 1, start_index = 0, end_index = 0, content = "")
    token2 = Token(value = 1, start_index = 0, end_index = 0, content = "")
    assert token1 == token2


# Generated at 2022-06-18 12:54:21.577036
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:54:32.385048
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ab")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcd")

# Generated at 2022-06-18 12:54:43.675668
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "a")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "ab")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "abc")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "abcd")

# Generated at 2022-06-18 12:54:53.729093
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "foo")
    assert Token(1, 2, 3) != Token(1, 2, 3, "bar")
    assert Token(1, 2, 3) != Token(1, 2, 3, "foobar")
    assert Token(1, 2, 3) != Token(1, 2, 3, "barfoo")
    assert Token

# Generated at 2022-06-18 12:54:59.540252
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != None


# Generated at 2022-06-18 12:55:11.453838
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3, "abc") == Token(1, 2, 3, "abc")
    assert not Token(1, 2, 3, "abc") == Token(1, 2, 3, "abcd")
    assert not Token(1, 2, 3, "abc") == Token(1, 2, 4, "abc")
    assert not Token(1, 2, 3, "abc") == Token(1, 3, 3, "abc")
    assert not Token(1, 2, 3, "abc") == Token(2, 2, 3, "abc")
    assert not Token(1, 2, 3, "abc") == Token(1, 2, 3, "abcd")
    assert not Token(1, 2, 3, "abc") == Token(1, 2, 4, "abc")