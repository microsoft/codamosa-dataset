

# Generated at 2022-06-18 12:45:27.765655
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1}, 0, 0)
    assert token._value == {"a": 1}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""
    assert token.string == ""
    assert token.value == {"a": 1}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)
    assert token.lookup(["a"]) == 1
    assert token.lookup_key(["a"]) == "a"
    assert token.__repr__() == "DictToken('')"
    assert token.__eq__(token) == True
    assert token.__hash__() == hash({"a": 1})


# Generated at 2022-06-18 12:45:39.357216
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for class Token
    # Test for method __eq__
    # Test for class ScalarToken
    # Test for method __eq__
    assert ScalarToken(1, 0, 0).__eq__(ScalarToken(1, 0, 0))
    assert ScalarToken(1, 0, 0).__eq__(ScalarToken(1, 0, 1))
    assert ScalarToken(1, 0, 0).__eq__(ScalarToken(1, 1, 0))
    assert ScalarToken(1, 0, 0).__eq__(ScalarToken(1, 1, 1))
    assert ScalarToken(1, 0, 0).__eq__(ScalarToken(2, 0, 0))

# Generated at 2022-06-18 12:45:43.904737
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(1, 2, 3)
    t2 = Token(1, 2, 3)
    t3 = Token(2, 2, 3)
    t4 = Token(1, 3, 3)
    t5 = Token(1, 2, 4)
    assert t1 == t2
    assert t1 != t3
    assert t1 != t4
    assert t1 != t5


# Generated at 2022-06-18 12:45:49.200414
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 3, 4)
    assert not Token(1, 2, 3) == 1
    assert not Token(1, 2, 3) == "1"
    assert not Token(1, 2, 3) == None


# Generated at 2022-06-18 12:45:52.276486
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:45:58.993501
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != None


# Generated at 2022-06-18 12:46:09.026013
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(
        value=None,
        start_index=0,
        end_index=0,
        content="",
    )
    assert token == token
    assert token == Token(
        value=None,
        start_index=0,
        end_index=0,
        content="",
    )
    assert token != Token(
        value=None,
        start_index=1,
        end_index=0,
        content="",
    )
    assert token != Token(
        value=None,
        start_index=0,
        end_index=1,
        content="",
    )
    assert token != Token(
        value=None,
        start_index=0,
        end_index=0,
        content="a",
    )
    assert token != None

#

# Generated at 2022-06-18 12:46:14.584703
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({1:2}, 0, 1, content="{1:2}")
    assert token._value == {1:2}
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == "{1:2}"


# Generated at 2022-06-18 12:46:26.058185
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:46:34.403349
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(
        {
            ScalarToken(1, 0, 0): ScalarToken(2, 0, 0),
            ScalarToken(3, 0, 0): ScalarToken(4, 0, 0),
        },
        0,
        0,
    )
    assert token._child_keys == {1: ScalarToken(1, 0, 0), 3: ScalarToken(3, 0, 0)}
    assert token._child_tokens == {
        1: ScalarToken(2, 0, 0),
        3: ScalarToken(4, 0, 0),
    }


# Generated at 2022-06-18 12:46:53.892334
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 1, "")
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 1
    assert dt._content == ""
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:47:03.953285
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 1)
    assert d._value == {"a": 1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""
    assert d.string == ""
    assert d.value == {"a": 1}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 1)
    assert d.lookup([]) == d
    assert d.lookup_key([]) == d
    assert d._get_position(0) == Position(1, 1, 0)
    assert d.__repr__() == "DictToken({'a': 1})"
    assert d.__eq__(d) == True

# Generated at 2022-06-18 12:47:09.258453
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(value = {}, start_index = 0, end_index = 0, content = "")
    assert token._value == {}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""
    assert token._child_keys == {}
    assert token._child_tokens == {}


# Generated at 2022-06-18 12:47:13.007363
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a":1}, 0, 1, "a")
    assert token._value == {"a":1}
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == "a"


# Generated at 2022-06-18 12:47:14.357074
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1}, 0, 1)


# Generated at 2022-06-18 12:47:18.174292
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(value={}, start_index=0, end_index=0, content="")
    assert token._value == {}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""
    assert token._child_keys == {}
    assert token._child_tokens == {}


# Generated at 2022-06-18 12:47:25.666201
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0)
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""


# Generated at 2022-06-18 12:47:26.992802
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1, "b": 2}, 0, 0, "")

# Generated at 2022-06-18 12:47:35.319776
# Unit test for constructor of class DictToken

# Generated at 2022-06-18 12:47:41.206648
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    d_token = DictToken(d, 0, 0)
    assert d_token._value == d
    assert d_token._start_index == 0
    assert d_token._end_index == 0
    assert d_token._content == ''
    assert d_token._child_keys == {'a': 'a', 'b': 'b'}
    assert d_token._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:48:02.317197
# Unit test for constructor of class DictToken

# Generated at 2022-06-18 12:48:07.084420
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 0)
    assert d._child_keys == {"a": 1}
    assert d._child_tokens == {"a": 1}
    assert d._get_value() == {"a": 1}
    assert d._get_child_token("a") == 1
    assert d._get_key_token("a") == 1


# Generated at 2022-06-18 12:48:15.823283
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({'a': 1, 'b': 2}, 0, 1, 'a: 1\nb: 2')
    assert a._value == {'a': 1, 'b': 2}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == 'a: 1\nb: 2'
    assert a._child_keys == {'a': 'a', 'b': 'b'}
    assert a._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:48:18.764082
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({'a': 1}, 0, 1)
    assert token._value == {'a': 1}
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == ""


# Generated at 2022-06-18 12:48:30.445491
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import Token
    from typesystem.base import Position
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import ScalarToken
    from typesystem.base import Position
    from typesystem.base import Token
    from typesystem.base import Position
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import ScalarToken
    from typesystem.base import Position
    from typesystem.base import Token
    from typesystem.base import Position

# Generated at 2022-06-18 12:48:41.240335
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken({"a": 1}, 0, 1)
    assert dt.string == "{'a': 1}"
    assert dt.value == {"a": 1}
    assert dt.start == Position(1, 1, 0)
    assert dt.end == Position(1, 10, 9)
    assert dt.lookup([0]) == dt._child_tokens["a"]
    assert dt.lookup_key([0]) == dt._child_keys["a"]
    assert dt._get_position(0) == Position(1, 1, 0)
    assert repr(dt) == "DictToken({'a': 1})"
    assert dt == DictToken({"a": 1}, 0, 1)
    assert hash(dt) == hash({"a": 1})

#

# Generated at 2022-06-18 12:48:44.855563
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken(value = {}, start_index = 0, end_index = 0, content = "")
    assert d._value == {}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""


# Generated at 2022-06-18 12:48:55.133566
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import Token
    from typesystem.base import Position
    d = DictToken({},0,0)
    assert d._value == {}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""
    assert d.string == ""
    assert d.value == {}
    assert d.start == Position(1,1,0)
    assert d.end == Position(1,1,0)
    assert d.lookup([]) == d
    assert d.lookup_key([]) == d
    assert d._get_position(0) == Position(1,1,0)
    assert repr(d) == "DictToken({})"
    assert d == DictToken({},0,0)
    assert hash(d) == hash({})

#

# Generated at 2022-06-18 12:48:58.881339
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a":1, "b":2}, 0, 0)
    assert d._child_keys == {"a":1, "b":2}
    assert d._child_tokens == {"a":1, "b":2}


# Generated at 2022-06-18 12:49:10.085447
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({'a':1}, 0, 1)
    assert token._value == {'a':1}
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == ""
    assert token.string == ""
    assert token.value == {'a':1}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 1)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert token._get_position(0) == Position(1, 1, 0)
    assert token.__repr__() == "DictToken('')"
    assert token.__eq__(token) == True


# Generated at 2022-06-18 12:49:27.393742
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a":1}, 0, 0)
    assert d._value == {"a":1}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""
    assert d.string == ""
    assert d.value == {"a":1}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 0)
    assert d.lookup([]) == d
    assert d.lookup_key([]) == d
    assert d._get_position(0) == Position(1, 1, 0)
    assert repr(d) == "DictToken({'a': 1})"
    assert d == DictToken({"a":1}, 0, 0)

# Generated at 2022-06-18 12:49:28.619873
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1, "b": 2}, 0, 1, "a: 1\nb: 2")


# Generated at 2022-06-18 12:49:31.420390
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken(value = {}, start_index = 0, end_index = 0, content = "")
    assert d._value == {}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""
    assert d._child_keys == {}
    assert d._child_tokens == {}


# Generated at 2022-06-18 12:49:33.535552
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1}, 0, 0, "")

# Generated at 2022-06-18 12:49:38.792274
# Unit test for constructor of class DictToken
def test_DictToken():
    start_index = 0
    end_index = 0
    content = ""
    value = {'a': 'b'}
    token = DictToken(value, start_index, end_index, content)
    assert token._value == value
    assert token._start_index == start_index
    assert token._end_index == end_index
    assert token._content == content


# Generated at 2022-06-18 12:49:50.540959
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import String
    from typesystem.base import Integer
    from typesystem.base import Dict
    from typesystem.base import List
    from typesystem.base import Object
    from typesystem.base import Union
    from typesystem.base import Enum
    from typesystem.base import Boolean
    from typesystem.base import Any
    from typesystem.base import DateTime
    from typesystem.base import Date
    from typesystem.base import Time
    from typesystem.base import Decimal
    from typesystem.base import Float
    from typesystem.base import UUID
    from typesystem.base import URL
    from typesystem.base import Email
    from typesystem.base import File
    from typesystem.base import Binary
    from typesystem.base import Array
    from typesystem.base import Tuple

# Generated at 2022-06-18 12:49:57.263993
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test case 1
    token = DictToken(
        {
            ScalarToken("a", 0, 0): ScalarToken(1, 0, 0),
            ScalarToken("b", 0, 0): ScalarToken(2, 0, 0),
        },
        0,
        0,
    )
    assert token._child_keys == {
        "a": ScalarToken("a", 0, 0),
        "b": ScalarToken("b", 0, 0),
    }
    assert token._child_tokens == {
        "a": ScalarToken(1, 0, 0),
        "b": ScalarToken(2, 0, 0),
    }
    # Test case 2

# Generated at 2022-06-18 12:50:05.262043
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0)
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:50:07.436008
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1, "b": 2}, 0, 0)
    assert token._child_keys["a"] == "a"
    assert token._child_keys["b"] == "b"
    assert token._child_tokens["a"] == 1
    assert token._child_tokens["b"] == 2


# Generated at 2022-06-18 12:50:10.615028
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0, "")
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:50:34.339822
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ''
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}
    assert dt.string == ''
    assert dt.value == {'a': 1, 'b': 2}
    assert dt.start == Position(1, 1, 0)
    assert dt.end == Position(1, 1, 0)
    assert dt.lookup([]) == dt
    assert dt.lookup_key

# Generated at 2022-06-18 12:50:37.961930
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a":1, "b":2}, 0, 10)
    assert d._child_keys == {"a":1, "b":2}
    assert d._child_tokens == {"a":1, "b":2}


# Generated at 2022-06-18 12:50:45.370813
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ''
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:50:55.592896
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test that the constructor of class DictToken works as expected
    # Create a dictionary
    d = {'a': 1, 'b': 2, 'c': 3}
    # Create a DictToken
    dt = DictToken(d, 0, 0)
    # Test that the value of the DictToken is the same as the dictionary
    assert dt.value == d
    # Test that the start of the DictToken is the same as the start of the dictionary
    assert dt.start == Position(1, 1, 0)
    # Test that the end of the DictToken is the same as the end of the dictionary
    assert dt.end == Position(1, 1, 0)
    # Test that the string of the DictToken is the same as the string of the dictionary
    assert dt.string == d
    # Test that

# Generated at 2022-06-18 12:51:02.273286
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0, "")
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ""


# Generated at 2022-06-18 12:51:12.243578
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({'a': 1, 'b': 2}, 0, 10, '{"a": 1, "b": 2}')
    assert token._child_keys == {'a': 'a', 'b': 'b'}
    assert token._child_tokens == {'a': 1, 'b': 2}
    assert token._value == {'a': 1, 'b': 2}
    assert token._start_index == 0
    assert token._end_index == 10
    assert token._content == '{"a": 1, "b": 2}'
    assert token.string == '{"a": 1, "b": 2}'
    assert token.value == {'a': 1, 'b': 2}
    assert token.start == Position(1, 1, 0)

# Generated at 2022-06-18 12:51:20.957003
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a": 1}, 0, 1)
    assert a._value == {"a": 1}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == ""
    assert a.string == ""
    assert a.value == {"a": 1}
    assert a.start == Position(1, 1, 0)
    assert a.end == Position(1, 1, 1)
    assert a.lookup([]) == a
    assert a.lookup_key([]) == a
    assert a.__repr__() == "DictToken({'a': 1})"
    assert a.__eq__(a) == True
    assert a.__hash__() == hash({"a": 1})


# Generated at 2022-06-18 12:51:27.367944
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0, '{"a": 1, "b": 2}')
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == '{"a": 1, "b": 2}'
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:51:34.271002
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 10, "a=1,b=2")
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 10
    assert d._content == "a=1,b=2"
    assert d._child_keys == {"a": "a", "b": "b"}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:51:41.638732
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0, 'a=1, b=2')
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == 'a=1, b=2'
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:52:13.077145
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 1, "a")
    assert d._value == {"a": 1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == "a"


# Generated at 2022-06-18 12:52:18.700821
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken({"a": 1, "b": 2}, 0, 10, "a: 1\nb: 2")
    assert dict_token.value == {"a": 1, "b": 2}
    assert dict_token.start == Position(1, 1, 0)
    assert dict_token.end == Position(1, 10, 10)
    assert dict_token.string == "a: 1\nb: 2"


# Generated at 2022-06-18 12:52:23.096053
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 1)
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:52:34.320006
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test for constructor of class DictToken
    d = {'a': 1, 'b': 2}
    d_token = DictToken(d, 0, 0)
    assert d_token._value == d
    assert d_token._start_index == 0
    assert d_token._end_index == 0
    assert d_token._content == ''
    assert d_token.string == ''
    assert d_token.value == {'a': 1, 'b': 2}
    assert d_token.start == Position(1, 1, 0)
    assert d_token.end == Position(1, 1, 0)
    assert d_token.lookup([]) == d_token
    assert d_token.lookup_key([]) == d_token

# Generated at 2022-06-18 12:52:40.192396
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ''
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:52:44.505476
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1, "b": 2}, 0, 0, "")
    assert token._child_keys == {"a": 1, "b": 2}
    assert token._child_tokens == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:52:55.742094
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 1, "a: 1\nb: 2")
    assert d.value == {"a": 1, "b": 2}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(2, 4, 1)
    assert d.string == "a: 1\nb: 2"
    assert d.lookup([0]) == d._child_tokens["a"]
    assert d.lookup_key([0]) == d._child_keys["a"]
    assert d == DictToken({"a": 1, "b": 2}, 0, 1, "a: 1\nb: 2")
    assert d != DictToken({"a": 1, "b": 2}, 0, 1, "a: 1\nb: 3")

# Generated at 2022-06-18 12:53:06.237926
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a": 1, "b": 2}, 0, 1, "a: 1\nb: 2")
    assert a._value == {"a": 1, "b": 2}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == "a: 1\nb: 2"
    assert a.string == "a: 1\nb: 2"
    assert a.value == {"a": 1, "b": 2}
    assert a.start == Position(1, 1, 0)
    assert a.end == Position(2, 3, 1)
    assert a.lookup([0]) == 1
    assert a.lookup_key([0]) == "a"
    assert a.__repr__() == "DictToken('a: 1\\nb: 2')"

# Generated at 2022-06-18 12:53:18.696138
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 10)
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 10
    assert d._content == ""
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}
    assert d.string == ""
    assert d.value == {"a": 1, "b": 2}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 10)
    assert d.lookup(["a"]) == 1
    assert d.lookup_key(["a"]) == 1
    assert d._get_position

# Generated at 2022-06-18 12:53:27.782905
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 1)
    assert d._get_value() == {"a": 1}
    assert d._get_child_token("a") == 1
    assert d._get_key_token("a") == "a"
    assert d.string == ""
    assert d.value == {"a": 1}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 0)
    assert d.lookup(["a"]) == 1
    assert d.lookup_key(["a"]) == "a"
    assert d._get_position(0) == Position(1, 1, 0)
    assert repr(d) == "DictToken({'a': 1})"

# Generated at 2022-06-18 12:54:30.026753
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1}, 0, 1, "a")
    assert token.value == {"a": 1}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 1)
    assert token.string == "a"
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert token.lookup([0]) == token
    assert token.lookup_key([0]) == token


# Generated at 2022-06-18 12:54:32.814753
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a": 1}, 0, 1)
    assert a._value == {"a": 1}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == ""


# Generated at 2022-06-18 12:54:38.405411
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(value={}, start_index=0, end_index=0, content="")
    assert token._value == {}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""
    assert token._child_keys == {}
    assert token._child_tokens == {}


# Generated at 2022-06-18 12:54:42.177568
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 10)
    assert d._child_keys == {"a": "a", "b": "b"}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:54:52.908600
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({'a':'b'}, 0, 1)
    assert a._value == {'a':'b'}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == ""
    assert a.string == ""
    assert a.value == {'a':'b'}
    assert a.start == Position(1, 1, 0)
    assert a.end == Position(1, 1, 1)
    assert a.lookup(['a']) == 'b'
    assert a.lookup_key(['a']) == 'a'
    assert a._get_position(0) == Position(1, 1, 0)
    assert repr(a) == "DictToken({'a': 'b'})"

# Generated at 2022-06-18 12:54:53.842413
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1, "b": 2}, 0, 0, "")

# Generated at 2022-06-18 12:55:00.291982
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ''
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:55:03.657059
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({1:2}, 0, 1)
    assert a._value == {1:2}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == ""


# Generated at 2022-06-18 12:55:10.082550
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}
