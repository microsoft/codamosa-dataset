

# Generated at 2022-06-18 12:45:27.250694
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test with ScalarToken
    token1 = ScalarToken(value=1, start_index=0, end_index=0)
    token2 = ScalarToken(value=1, start_index=0, end_index=0)
    assert token1 == token2
    token3 = ScalarToken(value=2, start_index=0, end_index=0)
    assert token1 != token3
    token4 = ScalarToken(value=1, start_index=1, end_index=0)
    assert token1 != token4
    token5 = ScalarToken(value=1, start_index=0, end_index=1)
    assert token1 != token5

    # Test with DictToken
    token6 = DictToken(value={}, start_index=0, end_index=0)
    token

# Generated at 2022-06-18 12:45:33.650403
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(1, 2, 3)
    t2 = Token(1, 2, 3)
    t3 = Token(2, 2, 3)
    t4 = Token(1, 3, 3)
    t5 = Token(1, 2, 4)
    assert t1 == t2
    assert t1 != t3
    assert t1 != t4
    assert t1 != t5


# Generated at 2022-06-18 12:45:39.476947
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:45:44.593039
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1
    assert not Token(1, 2, 3) == None


# Generated at 2022-06-18 12:45:49.696183
# Unit test for constructor of class DictToken
def test_DictToken():
    # test constructor
    d = DictToken({"a": 1, "b": 2}, 0, 10)
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 10
    assert d._content == ""
    assert d.string == ""
    assert d.value == {"a": 1, "b": 2}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 10)
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:46:01.110647
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:46:05.745378
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(2, 2, 3)
    token4 = Token(1, 3, 3)
    token5 = Token(1, 2, 4)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5


# Generated at 2022-06-18 12:46:11.771958
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1, "b": 2}, 0, 1, "a: 1\nb: 2")
    assert token._value == {"a": 1, "b": 2}
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == "a: 1\nb: 2"


# Generated at 2022-06-18 12:46:17.836132
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test for constructor of class DictToken
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:46:21.078440
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a":1}, 0, 1)
    assert d._value == {"a":1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""


# Generated at 2022-06-18 12:46:41.736450
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert ScalarToken(1, 0, 0) == ScalarToken(1, 0, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(2, 0, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 1, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 0, 1)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 1, 1)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 1, 1)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 1, 1)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 1, 1)

# Generated at 2022-06-18 12:46:48.118199
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:46:53.427624
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0)
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""


# Generated at 2022-06-18 12:47:00.094977
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({'a': 1, 'b': 2}, 0, 1, 'a: 1, b: 2')
    assert a._value == {'a': 1, 'b': 2}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == 'a: 1, b: 2'
    assert a._child_keys == {'a': 'a', 'b': 'b'}
    assert a._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:47:08.093689
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(1, 2, 4)
    assert token1 != token3
    token4 = Token(2, 2, 3)
    assert token1 != token4
    token5 = Token(1, 3, 3)
    assert token1 != token5
    token6 = Token(1, 2, 2)
    assert token1 != token6
    token7 = Token(1, 2, 3, "abc")
    assert token1 != token7


# Generated at 2022-06-18 12:47:13.656891
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:47:20.215441
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    assert not (token1 != token2)
    token3 = Token(1, 2, 4)
    assert not (token1 == token3)
    assert token1 != token3
    token4 = Token(2, 2, 3)
    assert not (token1 == token4)
    assert token1 != token4
    token5 = Token(1, 1, 3)
    assert not (token1 == token5)
    assert token1 != token5
    token6 = Token(1, 2, 2)
    assert not (token1 == token6)
    assert token1 != token6


# Generated at 2022-06-18 12:47:28.031260
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._value == {'a': 1, 'b': 2}
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ""
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:47:29.431263
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1,2,3)
    token2 = Token(1,2,3)
    assert token1 == token2


# Generated at 2022-06-18 12:47:34.759221
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(1, 2, 4)
    assert token1 != token3
    token4 = Token(2, 2, 3)
    assert token1 != token4
    token5 = Token(1, 3, 3)
    assert token1 != token5
    token6 = Token(1, 2, 2)
    assert token1 != token6


# Generated at 2022-06-18 12:47:57.061667
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1, "b": 2}, 0, 0)
    assert token._child_keys == {"a": 1, "b": 2}
    assert token._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:48:01.888819
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:48:03.950363
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1}, 0, 1, "a: 1") == DictToken({"a": 1}, 0, 1, "a: 1")


# Generated at 2022-06-18 12:48:07.514633
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0)
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:48:18.970291
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a": 1}, 0, 1)
    assert a._value == {"a": 1}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == ""
    assert a.string == ""
    assert a.value == {"a": 1}
    assert a.start == Position(1, 1, 0)
    assert a.end == Position(1, 1, 1)
    assert a.lookup([]) == a
    assert a.lookup_key([]) == a
    assert a._get_position(0) == Position(1, 1, 0)
    assert repr(a) == "DictToken({'a': 1})"
    assert a == DictToken({"a": 1}, 0, 1)

# Generated at 2022-06-18 12:48:20.795249
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1, "b": 2}, 0, 3, "abc")


# Generated at 2022-06-18 12:48:32.416275
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test case 1
    token = DictToken(
        {
            ScalarToken("a", 0, 0): ScalarToken(1, 1, 1),
            ScalarToken("b", 2, 2): ScalarToken(2, 3, 3),
        },
        0,
        3,
        content="ab",
    )
    assert token._child_keys == {
        "a": ScalarToken("a", 0, 0),
        "b": ScalarToken("b", 2, 2),
    }
    assert token._child_tokens == {
        "a": ScalarToken(1, 1, 1),
        "b": ScalarToken(2, 3, 3),
    }

# Generated at 2022-06-18 12:48:43.389513
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(2, 3, 3)
    assert Token(1, 2, 3) != Token(2, 3, 4)
    assert Token(1, 2, 3) != Token(2, 4, 4)
    assert Token(1, 2, 3) != Token(2, 4, 5)
    assert Token(1, 2, 3) != Token(2, 5, 5)
    assert Token(1, 2, 3) != Token(2, 5, 6)

# Generated at 2022-06-18 12:48:53.555721
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a": 1}, 0, 1)
    assert a._value == {"a": 1}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == ""
    assert a.string == ""
    assert a.value == {"a": 1}
    assert a.start == Position(1, 1, 0)
    assert a.end == Position(1, 1, 1)
    assert a.lookup([]) == a
    assert a.lookup_key([]) == a
    assert a._get_position(0) == Position(1, 1, 0)
    assert a.__repr__() == "DictToken({'a': 1})"
    assert a.__eq__(a) == True

# Generated at 2022-06-18 12:49:05.209473
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(None, 0, 0) == Token(None, 0, 0)
    assert not Token(None, 0, 0) == Token(None, 0, 1)
    assert not Token(None, 0, 0) == Token(None, 1, 0)
    assert not Token(None, 0, 0) == Token(None, 1, 1)
    assert not Token(None, 0, 0) == Token(None, 0, 0, "")
    assert not Token(None, 0, 0) == Token(None, 0, 0, "a")
    assert not Token(None, 0, 0) == Token(None, 0, 0, "ab")
    assert not Token(None, 0, 0) == Token(None, 0, 0, "abc")

# Generated at 2022-06-18 12:50:24.330113
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for class ScalarToken
    token1 = ScalarToken(1, 0, 0)
    token2 = ScalarToken(1, 0, 0)
    assert token1 == token2
    token3 = ScalarToken(2, 0, 0)
    assert token1 != token3
    # Test for class DictToken
    token4 = DictToken({}, 0, 0)
    token5 = DictToken({}, 0, 0)
    assert token4 == token5
    token6 = DictToken({ScalarToken(1, 0, 0): ScalarToken(2, 0, 0)}, 0, 0)
    assert token4 != token6
    token7 = DictToken({ScalarToken(1, 0, 0): ScalarToken(2, 0, 0)}, 0, 0)
    assert token6 == token

# Generated at 2022-06-18 12:50:28.709220
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(1, 2, 4)
    assert token1 != token3
    token4 = Token(2, 2, 3)
    assert token1 != token4


# Generated at 2022-06-18 12:50:31.362795
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3, "")
    token2 = Token(1, 2, 3, "")
    assert token1 == token2


# Generated at 2022-06-18 12:50:36.394627
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != 1


# Generated at 2022-06-18 12:50:39.587338
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 1)
    assert d._value == {"a": 1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""


# Generated at 2022-06-18 12:50:49.717110
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3, "abc")
    token2 = Token(1, 2, 3, "abc")
    token3 = Token(1, 2, 3, "abcd")
    token4 = Token(1, 2, 4, "abc")
    token5 = Token(1, 3, 3, "abc")
    token6 = Token(1, 2, 3, "ab")
    token7 = Token(2, 2, 3, "abc")
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5
    assert token1 != token6
    assert token1 != token7


# Generated at 2022-06-18 12:50:54.546346
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:51:01.488614
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 2, 3, "foo")
    assert Token(1, 2, 3) != object()


# Generated at 2022-06-18 12:51:06.778927
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(2, 2, 3)
    assert token1 != token3
    token4 = Token(1, 3, 3)
    assert token1 != token4
    token5 = Token(1, 2, 4)
    assert token1 != token5


# Generated at 2022-06-18 12:51:12.039568
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:52:12.927762
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != "1"
    assert Token(1, 2, 3) != None
    assert Token(1, 2, 3) != []
    assert Token(1, 2, 3) != {}
    assert Token(1, 2, 3) != ()
    assert Token(1, 2, 3) != object()
    assert Token(1, 2, 3) != object
    assert Token(1, 2, 3) != type

# Generated at 2022-06-18 12:52:17.561252
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert token != 1
    assert token != Token(1, 2, 4)
    assert token != Token(1, 3, 3)
    assert token != Token(2, 2, 3)
    assert token != Token(1, 2, 3, "abc")


# Generated at 2022-06-18 12:52:24.253873
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != None
    assert Token(1, 2, 3) != "1"


# Generated at 2022-06-18 12:52:35.757485
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert not (token != token)
    assert token == Token(1, 2, 3)
    assert not (token != Token(1, 2, 3))
    assert not (token == Token(1, 2, 4))
    assert token != Token(1, 2, 4)
    assert not (token == Token(1, 3, 3))
    assert token != Token(1, 3, 3)
    assert not (token == Token(2, 2, 3))
    assert token != Token(2, 2, 3)
    assert not (token == Token(1, 2, 3, "abc"))
    assert token != Token(1, 2, 3, "abc")
    assert not (token == Token(1, 2, 3, "abcd"))

# Generated at 2022-06-18 12:52:40.331719
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:52:46.292935
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == object()


# Generated at 2022-06-18 12:52:58.189466
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0)
    assert token == token
    assert token == Token(value=None, start_index=0, end_index=0)
    assert not token == Token(value=None, start_index=0, end_index=1)
    assert not token == Token(value=None, start_index=1, end_index=0)
    assert not token == Token(value=None, start_index=1, end_index=1)
    assert not token == Token(value=None, start_index=0, end_index=0, content="")
    assert not token == Token(value=None, start_index=0, end_index=0, content="a")

# Generated at 2022-06-18 12:53:09.599527
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3, "abc") == Token(1, 2, 3, "abc")
    assert not Token(1, 2, 3, "abc") == Token(1, 2, 3, "abcd")
    assert not Token(1, 2, 3, "abc") == Token(1, 2, 4, "abc")
    assert not Token(1, 2, 3, "abc") == Token(1, 3, 3, "abc")
    assert not Token(1, 2, 3, "abc") == Token(2, 2, 3, "abc")
    assert not Token(1, 2, 3, "abc") == Token(1, 2, 3, "abcd")
    assert not Token(1, 2, 3, "abc") == Token(1, 2, 4, "abc")

# Generated at 2022-06-18 12:53:15.700427
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != "foo"


# Generated at 2022-06-18 12:53:25.458074
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert token == Token(1, 2, 3)
    assert token != Token(1, 2, 4)
    assert token != Token(1, 3, 3)
    assert token != Token(2, 2, 3)
    assert token != Token(1, 2, 3, "")
    assert token != Token(1, 2, 3, "abc")
    assert token != Token(1, 2, 3, "abcd")
    assert token != Token(1, 2, 3, "abcd")
    assert token != Token(1, 2, 3, "abcd")
    assert token != Token(1, 2, 3, "abcd")
    assert token != Token(1, 2, 3, "abcd")