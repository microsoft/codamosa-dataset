

# Generated at 2022-06-18 12:45:27.621887
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 1)
    assert d._value == {"a": 1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""
    assert d.string == ""
    assert d.value == {"a": 1}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 1)
    assert d.lookup([]) == d
    assert d.lookup_key([0]) == d
    assert d._get_position(0) == Position(1, 1, 0)
    assert repr(d) == "DictToken({'a': 1})"
    assert d == DictToken({"a": 1}, 0, 1)

# Generated at 2022-06-18 12:45:33.954099
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != 1


# Generated at 2022-06-18 12:45:40.412301
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 1)
    assert d.value == {"a": 1}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 1)
    assert d.string == ""
    assert d.lookup([]) == d
    assert d.lookup_key([]) == d
    assert d.lookup([0]) == d
    assert d.lookup_key([0]) == d


# Generated at 2022-06-18 12:45:49.655985
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "a")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "ab")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "abc")

# Generated at 2022-06-18 12:46:01.110981
# Unit test for constructor of class DictToken

# Generated at 2022-06-18 12:46:06.362976
# Unit test for constructor of class DictToken
def test_DictToken():
    # test constructor
    d = DictToken({"a": 1, "b": 2}, 0, 0, "")
    assert d._child_keys == {"a": "a", "b": "b"}
    assert d._child_tokens == {"a": 1, "b": 2}
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""


# Generated at 2022-06-18 12:46:18.825897
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, 0, 0)
    assert token == token
    assert token != None
    assert token != "test"
    assert token != Token(None, 0, 0)
    assert token != Token(None, 0, 1)
    assert token != Token(None, 1, 0)
    assert token != Token(None, 1, 1)
    assert token != Token(None, 0, 0, "test")
    assert token != Token("test", 0, 0)
    assert token != Token("test", 0, 1)
    assert token != Token("test", 1, 0)
    assert token != Token("test", 1, 1)
    assert token != Token("test", 0, 0, "test")
    assert token != Token(None, 0, 0, "test")
    assert token != Token("test", 0, 0, "test")

# Generated at 2022-06-18 12:46:29.150153
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0, content="")
    assert token == token
    assert token == Token(value=None, start_index=0, end_index=0, content="")
    assert token != Token(value=None, start_index=1, end_index=0, content="")
    assert token != Token(value=None, start_index=0, end_index=1, content="")
    assert token != Token(value="", start_index=0, end_index=0, content="")
    assert token != Token(value=None, start_index=0, end_index=0, content="a")
    assert token != None
    assert token != "a"


# Generated at 2022-06-18 12:46:33.659550
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(value = "value", start_index = 0, end_index = 0, content = "")
    token2 = Token(value = "value", start_index = 0, end_index = 0, content = "")
    assert token1 == token2


# Generated at 2022-06-18 12:46:42.885732
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({'a': 1, 'b': 2}, 0, 0)
    assert d._child_keys == {'a': 'a', 'b': 'b'}
    assert d._child_tokens == {'a': 1, 'b': 2}
    assert d._value == {'a': 1, 'b': 2}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ''
    assert d.string == ''
    assert d.value == {'a': 1, 'b': 2}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 0)
    assert d.lookup([]) == d
    assert d.lookup_key([]) == d
    assert d.lookup

# Generated at 2022-06-18 12:47:02.077152
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 1)
    assert d._value == {"a": 1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""
    assert d.string == ""
    assert d.value == {"a": 1}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 1)
    assert d.lookup([]) == d
    assert d.lookup_key([0]) == d
    assert d.__repr__() == "DictToken('')"
    assert d.__eq__(d) == True
    assert d.__hash__() == hash({"a": 1})


# Generated at 2022-06-18 12:47:12.006817
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ab")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcd")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcde")

# Generated at 2022-06-18 12:47:16.461070
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert token == Token(1, 2, 3)
    assert token != Token(2, 2, 3)
    assert token != Token(1, 3, 3)
    assert token != Token(1, 2, 4)
    assert token != Token(1, 2, 3, "abc")
    assert token != object()

# Generated at 2022-06-18 12:47:22.637269
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(1, 2, 4)
    assert token1 != token3
    token4 = Token(2, 2, 3)
    assert token1 != token4


# Generated at 2022-06-18 12:47:31.939061
# Unit test for constructor of class DictToken

# Generated at 2022-06-18 12:47:38.776893
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1}, 0, 1, "a: 1") == DictToken({"a": 1}, 0, 1, "a: 1")
    assert DictToken({"a": 1}, 0, 1, "a: 1") != DictToken({"a": 1}, 0, 2, "a: 1")
    assert DictToken({"a": 1}, 0, 1, "a: 1") != DictToken({"a": 2}, 0, 1, "a: 1")
    assert DictToken({"a": 1}, 0, 1, "a: 1") != DictToken({"b": 1}, 0, 1, "a: 1")
    assert DictToken({"a": 1}, 0, 1, "a: 1") != DictToken({"a": 1}, 0, 1, "a: 2")

# Generated at 2022-06-18 12:47:40.690537
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:47:43.305365
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:47:54.472868
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1, "b": 2}, 0, 0, "") == DictToken({"a": 1, "b": 2}, 0, 0, "")
    assert DictToken({"a": 1, "b": 2}, 0, 0, "") != DictToken({"a": 1, "b": 2}, 0, 1, "")
    assert DictToken({"a": 1, "b": 2}, 0, 0, "") != DictToken({"a": 1, "b": 2}, 1, 0, "")
    assert DictToken({"a": 1, "b": 2}, 0, 0, "") != DictToken({"a": 1, "b": 2}, 1, 1, "")

# Generated at 2022-06-18 12:47:58.994479
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 1, "abc")
    assert d._value == {"a": 1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == "abc"


# Generated at 2022-06-18 12:48:29.238139
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == object()


# Generated at 2022-06-18 12:48:35.906606
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken({"a": 1, "b": 2}, 0, 1, "")
    assert dict_token._value == {"a": 1, "b": 2}
    assert dict_token._start_index == 0
    assert dict_token._end_index == 1
    assert dict_token._content == ""
    assert dict_token._child_keys == {"a": 1, "b": 2}
    assert dict_token._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:48:46.957219
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:48:52.258628
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:48:57.661006
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:49:09.590653
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import Token
    from typesystem.base import Position
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import String
    from typesystem.base import Integer
    from typesystem.base import Array
    from typesystem.base import Object
    from typesystem.base import Boolean
    from typesystem.base import Number
    from typesystem.base import Any
    from typesystem.base import Enum
    from typesystem.base import Union
    from typesystem.base import Reference
    from typesystem.base import Link
    from typesystem.base import Meta
    from typesystem.base import Field
    from typesystem.base import Schema
    from typesystem.base import Root
    from typesystem.base import Type

# Generated at 2022-06-18 12:49:15.114652
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:49:19.540199
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(value=1, start_index=2, end_index=3)
    token2 = Token(value=1, start_index=2, end_index=3)
    assert token1 == token2


# Generated at 2022-06-18 12:49:26.143250
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ''
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:49:31.463777
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:49:47.771840
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 1)
    assert d._child_keys == {"a": 1}
    assert d._child_tokens == {"a": 1}


# Generated at 2022-06-18 12:49:54.317916
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 3, "a: 1\nb: 2")
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 3
    assert d._content == "a: 1\nb: 2"
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:50:06.624167
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for method __eq__ of class Token
    # Tests that two tokens are equal if they have the same value, start index, and end index.
    token1 = ScalarToken(1, 0, 0)
    token2 = ScalarToken(1, 0, 0)
    assert token1 == token2
    token1 = ScalarToken(1, 0, 1)
    token2 = ScalarToken(1, 0, 1)
    assert token1 == token2
    token1 = ScalarToken(1, 1, 1)
    token2 = ScalarToken(1, 1, 1)
    assert token1 == token2
    token1 = ScalarToken(1, 1, 2)
    token2 = ScalarToken(1, 1, 2)
    assert token1 == token2

# Generated at 2022-06-18 12:50:07.720952
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:50:13.494013
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3, "") == Token(1, 2, 3, "")
    assert Token(1, 2, 3, "") != Token(2, 2, 3, "")
    assert Token(1, 2, 3, "") != Token(1, 3, 3, "")
    assert Token(1, 2, 3, "") != Token(1, 2, 4, "")
    assert Token(1, 2, 3, "") != Token(1, 2, 3, "a")
    assert Token(1, 2, 3, "") != 1


# Generated at 2022-06-18 12:50:19.148531
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a": 1}, 0, 1, "a")
    assert a._value == {"a": 1}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == "a"
    assert a._child_keys == {"a": "a"}
    assert a._child_tokens == {"a": 1}


# Generated at 2022-06-18 12:50:25.329083
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a":1, "b":2}, 0, 0)
    assert d._child_keys == {"a":1, "b":2}
    assert d._child_tokens == {"a":1, "b":2}
    assert d._value == {"a":1, "b":2}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""


# Generated at 2022-06-18 12:50:35.055020
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for class ScalarToken
    token1 = ScalarToken(value=1, start_index=0, end_index=0)
    token2 = ScalarToken(value=1, start_index=0, end_index=0)
    assert token1 == token2
    token3 = ScalarToken(value=2, start_index=0, end_index=0)
    assert token1 != token3
    token4 = ScalarToken(value=1, start_index=1, end_index=0)
    assert token1 != token4
    token5 = ScalarToken(value=1, start_index=0, end_index=1)
    assert token1 != token5
    # Test for class DictToken
    token6 = DictToken(value={}, start_index=0, end_index=0)


# Generated at 2022-06-18 12:50:40.079075
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == None


# Generated at 2022-06-18 12:50:46.503753
# Unit test for constructor of class DictToken
def test_DictToken():
    # test constructor
    d = DictToken({"a": 1}, 0, 1)
    assert d._value == {"a": 1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""
    assert d._child_keys == {"a": 1}
    assert d._child_tokens == {"a": 1}


# Generated at 2022-06-18 12:51:20.709055
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(1, 2, 3)
    t2 = Token(1, 2, 3)
    t3 = Token(2, 2, 3)
    t4 = Token(1, 3, 3)
    t5 = Token(1, 2, 4)
    assert t1 == t1
    assert t1 == t2
    assert t1 != t3
    assert t1 != t4
    assert t1 != t5


# Generated at 2022-06-18 12:51:23.761778
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(value = {}, start_index = 0, end_index = 0)
    assert token._value == {}
    assert token._start_index == 0
    assert token._end_index == 0


# Generated at 2022-06-18 12:51:30.386977
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:51:35.948855
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:51:46.295369
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 1)
    assert d._value == {"a": 1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""
    assert d.string == ""
    assert d.value == {"a": 1}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 1)
    assert d.lookup([]) == d
    assert d.lookup_key([]) == d
    assert d.lookup([0]) == d
    assert d.lookup_key([0]) == d
    assert d.lookup([1]) == d
    assert d.lookup_key([1]) == d
    assert d.lookup([2]) == d

# Generated at 2022-06-18 12:51:53.658022
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "b")
    assert Token(1, 2, 3) != Token(1, 2, 3, "c")
    assert Token(1, 2, 3) != Token(1, 2, 3, "d")
    assert Token(1, 2, 3) != Token(1, 2, 3, "e")

# Generated at 2022-06-18 12:51:58.369734
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0, '')
    assert dt._get_value() == d
    assert dt._get_child_token('a') == dt._value['a']
    assert dt._get_key_token('a') == dt._value['a']


# Generated at 2022-06-18 12:52:01.048053
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3, "abc")
    token2 = Token(1, 2, 3, "abc")
    assert token1 == token2


# Generated at 2022-06-18 12:52:07.748367
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert not (token == 1)
    assert not (token == None)
    assert not (token == Token(1, 2, 3))
    assert not (token == Token(1, 2, 4))
    assert not (token == Token(1, 3, 3))
    assert not (token == Token(2, 2, 3))
    assert not (token == Token(1, 2, 3, "abc"))
    assert not (token == Token(1, 2, 3, "def"))


# Generated at 2022-06-18 12:52:16.283249
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ab")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcd")

# Generated at 2022-06-18 12:53:19.181232
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ab")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcd")

# Generated at 2022-06-18 12:53:27.706350
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0, content="")
    assert token == token
    assert token == Token(value=None, start_index=0, end_index=0, content="")
    assert not token == Token(value=None, start_index=1, end_index=0, content="")
    assert not token == Token(value=None, start_index=0, end_index=1, content="")
    assert not token == Token(value=None, start_index=0, end_index=0, content="a")
    assert not token == Token(value=None, start_index=0, end_index=0, content="")
    assert not token == None


# Generated at 2022-06-18 12:53:30.699672
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({'a': 1}, 0, 0, '')
    assert token._child_keys == {'a': 'a'}
    assert token._child_tokens == {'a': 1}


# Generated at 2022-06-18 12:53:39.270406
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=1, start_index=2, end_index=3)
    assert token == token
    assert token == Token(value=1, start_index=2, end_index=3)
    assert token != Token(value=2, start_index=2, end_index=3)
    assert token != Token(value=1, start_index=3, end_index=3)
    assert token != Token(value=1, start_index=2, end_index=4)
    assert token != 1


# Generated at 2022-06-18 12:53:47.426256
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:53:52.396710
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken({'a':1, 'b':2}, 0, 0, 'abc')
    assert dict_token._child_keys == {'a': 'a', 'b': 'b'}
    assert dict_token._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:54:02.114466
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a":1, "b":2}, 0, 1, "a:1,b:2")
    assert d._value == {"a":1, "b":2}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == "a:1,b:2"
    assert d.string == "a:1,b:2"
    assert d.value == {"a":1, "b":2}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 5, 1)
    assert d.lookup([]) == d
    assert d.lookup_key([]) == d
    assert d.lookup([0]) == 1
    assert d.lookup_key([0]) == "a"


# Generated at 2022-06-18 12:54:13.231118
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:54:16.477746
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert token != 1
    assert token != Token(2, 2, 3)
    assert token != Token(1, 3, 3)
    assert token != Token(1, 2, 4)
    assert token == Token(1, 2, 3)

# Generated at 2022-06-18 12:54:27.386690
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0)
    assert token == token
    assert token == Token(value=None, start_index=0, end_index=0)
    assert token != Token(value=None, start_index=1, end_index=0)
    assert token != Token(value=None, start_index=0, end_index=1)
    assert token != Token(value=None, start_index=0, end_index=0, content="")
    assert token != Token(value=None, start_index=0, end_index=0, content="a")
    assert token != Token(value=None, start_index=0, end_index=0, content="b")