

# Generated at 2022-06-18 12:45:18.133102
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1, "b": 2}, 0, 0)
    assert token._child_keys == {"a": 1, "b": 2}
    assert token._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:45:28.265964
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0, content="")
    assert token == token
    assert token == Token(value=None, start_index=0, end_index=0, content="")
    assert not token == Token(value=None, start_index=1, end_index=0, content="")
    assert not token == Token(value=None, start_index=0, end_index=1, content="")
    assert not token == Token(value=None, start_index=0, end_index=0, content="a")
    assert not token == Token(value=1, start_index=0, end_index=0, content="")
    assert not token == None
    assert not token == "a"


# Generated at 2022-06-18 12:45:37.468591
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0, 'a: 1, b: 2')
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}
    assert dt._get_value() == {'a': 1, 'b': 2}
    assert dt._get_child_token('a') == 1
    assert dt._get_key_token('a') == 'a'


# Generated at 2022-06-18 12:45:42.309942
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(1, 2, 3)
    t2 = Token(1, 2, 3)
    t3 = Token(2, 2, 3)
    t4 = Token(1, 3, 3)
    t5 = Token(1, 2, 4)
    assert t1 == t2
    assert t1 != t3
    assert t1 != t4
    assert t1 != t5


# Generated at 2022-06-18 12:45:47.007382
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:45:49.614729
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(1, 2, 4)
    assert token1 == token2
    assert token1 != token3


# Generated at 2022-06-18 12:45:55.254172
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, 0, 0)
    assert token == token
    assert not (token != token)

    token2 = Token(None, 0, 0)
    assert token == token2
    assert not (token != token2)

    token3 = Token(None, 1, 0)
    assert token != token3
    assert not (token == token3)

    token4 = Token(None, 0, 1)
    assert token != token4
    assert not (token == token4)

    token5 = Token(None, 0, 0, "a")
    assert token != token5
    assert not (token == token5)

    token6 = Token(None, 0, 0, "b")
    assert token != token6
    assert not (token == token6)

    token7 = Token(None, 0, 0, "a")


# Generated at 2022-06-18 12:46:04.138663
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0, content="")
    assert token == token
    assert token == Token(value=None, start_index=0, end_index=0, content="")
    assert token != Token(value=None, start_index=1, end_index=0, content="")
    assert token != Token(value=None, start_index=0, end_index=1, content="")
    assert token != Token(value=None, start_index=0, end_index=0, content="a")
    assert token != Token(value=None, start_index=0, end_index=0, content="")
    assert token != None
    assert token != "a"


# Generated at 2022-06-18 12:46:09.373720
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(1, 2, 4)
    assert token1 != token3
    token4 = Token(2, 2, 3)
    assert token1 != token4


# Generated at 2022-06-18 12:46:12.839195
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({}, 0, 0)
    assert a._value == {}
    assert a._start_index == 0
    assert a._end_index == 0
    assert a._content == ""


# Generated at 2022-06-18 12:46:19.231376
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(1, 2, 3)
    t2 = Token(1, 2, 3)
    assert t1 == t2


# Generated at 2022-06-18 12:46:25.095221
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert token == Token(1, 2, 3)
    assert not token == Token(2, 2, 3)
    assert not token == Token(1, 3, 3)
    assert not token == Token(1, 2, 4)
    assert not token == None
    assert not token == 1


# Generated at 2022-06-18 12:46:28.258026
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert token == Token(1, 2, 3)
    assert not token == Token(2, 2, 3)
    assert not token == Token(1, 3, 3)
    assert not token == Token(1, 2, 4)
    assert not token == Token(2, 3, 4)
    assert not token == Token(2, 3, 4)
    assert not token == None
    assert not token == "foo"
    assert not token == 1
    assert not token == 1.0
    assert not token == []
    assert not token == {}


# Generated at 2022-06-18 12:46:36.757750
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, 0, 0)
    assert token == token
    assert token != None
    assert token != 1
    assert token != "1"
    assert token != Token(None, 0, 0)
    assert token != Token(None, 0, 1)
    assert token != Token(None, 1, 0)
    assert token != Token(None, 1, 1)
    assert token != Token(1, 0, 0)
    assert token != Token(1, 0, 1)
    assert token != Token(1, 1, 0)
    assert token != Token(1, 1, 1)


# Generated at 2022-06-18 12:46:42.849659
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({'a': 1, 'b': 2}, 0, 1, 'a: 1, b: 2')
    assert token._child_keys == {'a': 'a', 'b': 'b'}
    assert token._child_tokens == {'a': 1, 'b': 2}
    assert token._value == {'a': 1, 'b': 2}
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == 'a: 1, b: 2'


# Generated at 2022-06-18 12:46:46.874048
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 5, "abcde")
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 5
    assert d._content == "abcde"
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:46:49.703039
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == "foo"


# Generated at 2022-06-18 12:47:01.457196
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not (Token(1, 2, 3) == Token(2, 2, 3))
    assert not (Token(1, 2, 3) == Token(1, 3, 3))
    assert not (Token(1, 2, 3) == Token(1, 2, 4))
    assert not (Token(1, 2, 3) == Token(2, 3, 4))
    assert not (Token(1, 2, 3) == Token(2, 3, 4))
    assert not (Token(1, 2, 3) == Token(2, 3, 4))
    assert not (Token(1, 2, 3) == Token(2, 3, 4))
    assert not (Token(1, 2, 3) == Token(2, 3, 4))

# Generated at 2022-06-18 12:47:10.613206
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 1, 1) == Token(1, 1, 1)
    assert Token(1, 1, 1) != Token(2, 1, 1)
    assert Token(1, 1, 1) != Token(1, 2, 1)
    assert Token(1, 1, 1) != Token(1, 1, 2)
    assert Token(1, 1, 1) != 1
    assert Token(1, 1, 1) != "1"
    assert Token(1, 1, 1) != None
    assert Token(1, 1, 1) != []
    assert Token(1, 1, 1) != {}
    assert Token(1, 1, 1) != ()
    assert Token(1, 1, 1) != object()


# Generated at 2022-06-18 12:47:18.994378
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for class ScalarToken
    token1 = ScalarToken(value=1, start_index=0, end_index=0)
    token2 = ScalarToken(value=1, start_index=0, end_index=0)
    assert token1 == token2
    token3 = ScalarToken(value=2, start_index=0, end_index=0)
    assert token1 != token3
    token4 = ScalarToken(value=1, start_index=1, end_index=0)
    assert token1 != token4
    token5 = ScalarToken(value=1, start_index=0, end_index=1)
    assert token1 != token5
    # Test for class DictToken

# Generated at 2022-06-18 12:47:34.352473
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "a")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "ab")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "abc")

# Generated at 2022-06-18 12:47:39.472697
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(1, 2, 3)
    t2 = Token(1, 2, 3)
    t3 = Token(2, 2, 3)
    t4 = Token(1, 3, 3)
    t5 = Token(1, 2, 4)
    assert t1 == t2
    assert t1 != t3
    assert t1 != t4
    assert t1 != t5


# Generated at 2022-06-18 12:47:45.277618
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == object()

# Generated at 2022-06-18 12:47:51.189676
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1, "b": 2}, 0, 0, "")
    assert token._child_keys == {"a": 1, "b": 2}
    assert token._child_tokens == {"a": 1, "b": 2}
    assert token._value == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:47:56.037145
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert token == Token(1, 2, 3)
    assert token != Token(1, 2, 4)
    assert token != Token(1, 3, 3)
    assert token != Token(2, 2, 3)
    assert token != Token(1, 2, 3, "foo")
    assert token != "foo"


# Generated at 2022-06-18 12:48:05.673788
# Unit test for constructor of class DictToken
def test_DictToken():
    import json
    from typesystem.base import Position
    from typesystem.parser import DictToken
    from typesystem.parser import ScalarToken
    from typesystem.parser import ListToken
    from typesystem.parser import Token
    from typesystem.parser import Position
    from typesystem.parser import Position
    from typesystem.parser import Position
    from typesystem.parser import Position
    from typesystem.parser import Position
    from typesystem.parser import Position
    from typesystem.parser import Position
    from typesystem.parser import Position
    from typesystem.parser import Position
    from typesystem.parser import Position
    from typesystem.parser import Position
    from typesystem.parser import Position
    from typesystem.parser import Position
    from typesystem.parser import Position
    from typesystem.parser import Position
    from typesystem.parser import Position
   

# Generated at 2022-06-18 12:48:17.352809
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert token == Token(1, 2, 3)
    assert token != Token(2, 2, 3)
    assert token != Token(1, 3, 3)
    assert token != Token(1, 2, 4)
    assert token != Token(1, 2, 3, "")
    assert token != Token(1, 2, 3, "a")
    assert token != Token(1, 2, 3, "ab")
    assert token != Token(1, 2, 3, "abc")
    assert token != Token(1, 2, 3, "abcd")
    assert token != Token(1, 2, 3, "abcde")
    assert token != Token(1, 2, 3, "abcdef")

# Generated at 2022-06-18 12:48:25.272025
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test with two equal tokens
    token1 = ScalarToken(value=1, start_index=0, end_index=1)
    token2 = ScalarToken(value=1, start_index=0, end_index=1)
    assert token1 == token2

    # Test with two unequal tokens
    token1 = ScalarToken(value=1, start_index=0, end_index=1)
    token2 = ScalarToken(value=2, start_index=0, end_index=1)
    assert not (token1 == token2)


# Generated at 2022-06-18 12:48:35.894645
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({'a': 'b'}, 0, 1)
    assert a._value == {'a': 'b'}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == ''
    assert a.string == ''
    assert a.value == {'a': 'b'}
    assert a.start == Position(1, 1, 0)
    assert a.end == Position(1, 1, 1)
    assert a.lookup([]) == a
    assert a.lookup_key([]) == a
    assert a.__repr__() == 'DictToken({})'
    assert a.__eq__(a) == True
    assert a.__hash__() == hash({'a': 'b'})


# Generated at 2022-06-18 12:48:46.958104
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0, content='')
    assert token == token
    assert token == Token(value=None, start_index=0, end_index=0, content='')
    assert token != Token(value=None, start_index=1, end_index=0, content='')
    assert token != Token(value=None, start_index=0, end_index=1, content='')
    assert token != Token(value=None, start_index=0, end_index=0, content='a')
    assert token != Token(value=None, start_index=0, end_index=0, content='')
    assert token != Token(value=None, start_index=0, end_index=0, content='')
    assert token != Token

# Generated at 2022-06-18 12:49:06.117938
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")

# Generated at 2022-06-18 12:49:13.760432
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(
        value=None,
        start_index=0,
        end_index=0,
        content="",
    )
    assert token == token
    assert token == Token(
        value=None,
        start_index=0,
        end_index=0,
        content="",
    )
    assert token != Token(
        value=None,
        start_index=1,
        end_index=0,
        content="",
    )
    assert token != Token(
        value=None,
        start_index=0,
        end_index=1,
        content="",
    )
    assert token != Token(
        value=None,
        start_index=0,
        end_index=0,
        content="a",
    )

# Generated at 2022-06-18 12:49:21.929317
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 3, "a: 1\nb: 2")
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 3
    assert d._content == "a: 1\nb: 2"
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:49:28.250959
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    d_token = DictToken(d, 0, 0)
    assert d_token._value == d
    assert d_token._start_index == 0
    assert d_token._end_index == 0
    assert d_token._content == ''
    assert d_token._child_keys == {'a': 'a', 'b': 'b'}
    assert d_token._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:49:31.183527
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({'a': 'b'}, 0, 1)
    assert a._value == {'a': 'b'}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == ""


# Generated at 2022-06-18 12:49:38.576286
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ""
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:49:50.293654
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1, "b": 2}, 0, 10, "a=1,b=2")
    assert token.string == "a=1,b=2"
    assert token.value == {"a": 1, "b": 2}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 10, 9)
    assert token.lookup([0]) == token._child_tokens["a"]
    assert token.lookup([1]) == token._child_tokens["b"]
    assert token.lookup_key([0]) == token._child_keys["a"]
    assert token.lookup_key([1]) == token._child_keys["b"]
    assert repr(token) == "DictToken('a=1,b=2')"

# Generated at 2022-06-18 12:50:00.966787
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:50:05.114619
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(value=1, start_index=0, end_index=1)
    token2 = Token(value=1, start_index=0, end_index=1)
    assert token1 == token2


# Generated at 2022-06-18 12:50:13.081194
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test the case where the other is not an instance of Token
    token = Token(None, 0, 0)
    assert token.__eq__(None) == False
    # Test the case where the other is an instance of Token
    token = Token(None, 0, 0)
    token_other = Token(None, 0, 0)
    assert token.__eq__(token_other) == True
    token_other = Token(None, 1, 0)
    assert token.__eq__(token_other) == False
    token_other = Token(None, 0, 1)
    assert token.__eq__(token_other) == False
    token_other = Token(None, 1, 1)
    assert token.__eq__(token_other) == False


# Generated at 2022-06-18 12:50:24.116185
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({'a': 1}, 0, 1)
    assert token._value == {'a': 1}
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == ''


# Generated at 2022-06-18 12:50:33.809550
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = ScalarToken(1, 0, 0)
    token2 = ScalarToken(1, 0, 0)
    assert token1 == token2
    assert token1 == token1
    token3 = ScalarToken(2, 0, 0)
    assert token1 != token3
    token4 = ScalarToken(1, 1, 0)
    assert token1 != token4
    token5 = ScalarToken(1, 0, 1)
    assert token1 != token5
    token6 = DictToken({token1: token1}, 0, 0)
    assert token6 == token6
    assert token6 != token1
    token7 = DictToken({token1: token1}, 0, 0)
    assert token6 == token7
    token8 = DictToken({token1: token3}, 0, 0)
    assert token

# Generated at 2022-06-18 12:50:44.656201
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:50:54.824254
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert ScalarToken(1, 0, 0) == ScalarToken(1, 0, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(2, 0, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 1, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 0, 1)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 1, 1)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 0, 0, "")
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 0, 0, "1")
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 0, 0, "2")

# Generated at 2022-06-18 12:51:03.423329
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=1, start_index=1, end_index=2)
    assert token == token
    assert token == Token(value=1, start_index=1, end_index=2)
    assert token != Token(value=2, start_index=1, end_index=2)
    assert token != Token(value=1, start_index=2, end_index=2)
    assert token != Token(value=1, start_index=1, end_index=3)
    assert token != 1
    assert token != "1"
    assert token != None
    assert token != []
    assert token != {}


# Generated at 2022-06-18 12:51:05.961353
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({}, 0, 0)
    assert token._child_keys == {}
    assert token._child_tokens == {}


# Generated at 2022-06-18 12:51:15.300119
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test with two equal tokens
    token1 = ScalarToken(value=1, start_index=0, end_index=0)
    token2 = ScalarToken(value=1, start_index=0, end_index=0)
    assert token1 == token2
    # Test with two different tokens
    token1 = ScalarToken(value=1, start_index=0, end_index=0)
    token2 = ScalarToken(value=2, start_index=0, end_index=0)
    assert not token1 == token2
    # Test with two different tokens
    token1 = ScalarToken(value=1, start_index=0, end_index=0)
    token2 = ScalarToken(value=1, start_index=1, end_index=0)
    assert not token1 == token2

# Generated at 2022-06-18 12:51:17.623774
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3, "abc")
    token2 = Token(1, 2, 3, "abc")
    assert token1 == token2


# Generated at 2022-06-18 12:51:21.117244
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(value=1, start_index=0, end_index=1, content="")
    token2 = Token(value=1, start_index=0, end_index=1, content="")
    assert token1 == token2


# Generated at 2022-06-18 12:51:25.779993
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:52:00.071661
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(None, 0, 0) == Token(None, 0, 0)
    assert Token(None, 0, 0) != Token(None, 1, 0)
    assert Token(None, 0, 0) != Token(None, 0, 1)
    assert Token(None, 0, 0) != Token(None, 1, 1)
    assert Token(None, 0, 0) != Token(None, 0, 0, "")
    assert Token(None, 0, 0) != Token(None, 0, 0, "a")
    assert Token(None, 0, 0) != Token(None, 0, 0, "ab")
    assert Token(None, 0, 0) != Token(None, 0, 0, "abc")
    assert Token(None, 0, 0) != Token(None, 0, 0, "abcd")

# Generated at 2022-06-18 12:52:08.998239
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "a")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "ab")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "abc")

# Generated at 2022-06-18 12:52:14.730118
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not (Token(1, 2, 3) == Token(1, 2, 4))
    assert not (Token(1, 2, 3) == Token(1, 3, 3))
    assert not (Token(1, 2, 3) == Token(2, 2, 3))
    assert not (Token(1, 2, 3) == 1)
    assert not (Token(1, 2, 3) == None)


# Generated at 2022-06-18 12:52:18.289559
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(value=1, start_index=0, end_index=1)
    token2 = Token(value=1, start_index=0, end_index=1)
    assert token1 == token2


# Generated at 2022-06-18 12:52:23.339228
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(
        value=None,
        start_index=0,
        end_index=0,
        content="",
    )
    other = Token(
        value=None,
        start_index=0,
        end_index=0,
        content="",
    )
    assert token == other


# Generated at 2022-06-18 12:52:29.045409
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != None


# Generated at 2022-06-18 12:52:39.727210
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.base import Position
    from typesystem.base import Token
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import Token
    from typesystem.base import Position
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import Token
    from typesystem.base import Position
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import Token
    from typesystem.base import Position
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken

# Generated at 2022-06-18 12:52:45.457000
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:52:47.365050
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:52:54.580257
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(1, 2, 3)
    t2 = Token(1, 2, 3)
    assert t1 == t2
    t3 = Token(2, 2, 3)
    assert not (t1 == t3)
    t4 = Token(1, 3, 3)
    assert not (t1 == t4)
    t5 = Token(1, 2, 4)
    assert not (t1 == t5)


# Generated at 2022-06-18 12:53:26.974718
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1
    assert not Token(1, 2, 3) == None


# Generated at 2022-06-18 12:53:31.874136
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(2, 2, 3)
    assert token1 != token3
    token4 = Token(1, 3, 3)
    assert token1 != token4
    token5 = Token(1, 2, 4)
    assert token1 != token5


# Generated at 2022-06-18 12:53:38.071065
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert token != 1
    assert token != Token(2, 2, 3)
    assert token != Token(1, 3, 3)
    assert token != Token(1, 2, 4)
    assert token == Token(1, 2, 3)


# Generated at 2022-06-18 12:53:46.542857
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:53:57.267150
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 1)
    assert d._value == {"a": 1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""
    assert d.string == ""
    assert d.value == {"a": 1}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 1)
    assert d.lookup([]) == d
    assert d.lookup_key([]) == d
    assert d.__repr__() == "DictToken({'a': 1})"
    assert d.__eq__(d) == True
    assert d.__hash__() == hash({"a": 1})


# Generated at 2022-06-18 12:54:01.965608
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(2, 2, 3)
    token4 = Token(1, 3, 3)
    token5 = Token(1, 2, 4)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5


# Generated at 2022-06-18 12:54:06.187601
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != None
    assert Token(1, 2, 3) != "1"


# Generated at 2022-06-18 12:54:08.624561
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a":1}, 0, 1)


# Generated at 2022-06-18 12:54:18.643038
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ab")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcd")

# Generated at 2022-06-18 12:54:25.193058
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != None
