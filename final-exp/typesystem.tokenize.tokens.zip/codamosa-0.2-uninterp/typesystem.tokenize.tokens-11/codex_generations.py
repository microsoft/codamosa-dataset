

# Generated at 2022-06-18 12:45:23.298094
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 1, 2)
    token2 = Token(1, 1, 2)
    assert token1 == token2
    token3 = Token(2, 1, 2)
    assert token1 != token3
    token4 = Token(1, 2, 3)
    assert token1 != token4
    token5 = Token(1, 1, 3)
    assert token1 != token5


# Generated at 2022-06-18 12:45:31.138778
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "foo")
    assert not Token(1, 2, 3) == "foo"


# Generated at 2022-06-18 12:45:38.455462
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._value == {'a': 1, 'b': 2}
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ''


# Generated at 2022-06-18 12:45:45.487032
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a":1}, 0, 1, "a")
    assert a._value == {"a":1}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == "a"
    assert a._child_keys == {"a":1}
    assert a._child_tokens == {"a":1}


# Generated at 2022-06-18 12:45:47.346647
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a":1}, 0, 1)
    assert d._child_keys == {"a":1}
    assert d._child_tokens == {"a":1}


# Generated at 2022-06-18 12:45:53.886332
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:46:04.245640
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.base import Position
    from typesystem.base import Token
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import Position
    from typesystem.base import Token
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import Position
    from typesystem.base import Token
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import Position
    from typesystem.base import Token
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken

# Generated at 2022-06-18 12:46:16.281520
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1}, 0, 1, "a: 1") == DictToken({"a": 1}, 0, 1, "a: 1")
    assert DictToken({"a": 1}, 0, 1, "a: 1") != DictToken({"a": 2}, 0, 1, "a: 1")
    assert DictToken({"a": 1}, 0, 1, "a: 1") != DictToken({"b": 1}, 0, 1, "a: 1")
    assert DictToken({"a": 1}, 0, 1, "a: 1") != DictToken({"a": 1}, 1, 1, "a: 1")
    assert DictToken({"a": 1}, 0, 1, "a: 1") != DictToken({"a": 1}, 0, 2, "a: 1")

# Generated at 2022-06-18 12:46:27.314067
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({}, 0, 0)
    assert token._value == {}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""
    assert token.string == ""
    assert token.value == {}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert token._get_position(0) == Position(1, 1, 0)
    assert repr(token) == "DictToken({})"
    assert token == DictToken({}, 0, 0)
    assert hash(token) == hash({})


# Generated at 2022-06-18 12:46:35.016240
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 1, "a:1,b:2")
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == "a:1,b:2"
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:46:51.783936
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 5, "a: 1\nb: 2")
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 5
    assert d._content == "a: 1\nb: 2"
    assert d.string == "a: 1\nb: 2"
    assert d.value == {"a": 1, "b": 2}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(2, 4, 5)
    assert d.lookup([]) == d
    assert d.lookup_key([]) == d
    assert d.lookup([0]) == 1
    assert d.lookup_key([0]) == "a"


# Generated at 2022-06-18 12:46:57.363807
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != None


# Generated at 2022-06-18 12:47:02.076551
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1}, 0, 1)
    assert token._get_value() == {"a": 1}
    assert token._get_child_token("a") == 1
    assert token._get_key_token("a") == "a"


# Generated at 2022-06-18 12:47:11.949893
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, 0, 0)
    assert token == token
    assert token == Token(None, 0, 0)
    assert token != Token(None, 1, 0)
    assert token != Token(None, 0, 1)
    assert token != Token(None, 1, 1)
    assert token != Token(None, 0, 0, "")
    assert token != Token(None, 0, 0, "a")
    assert token != Token(None, 0, 0, "ab")
    assert token != Token(None, 0, 0, "abc")
    assert token != Token(None, 0, 0, "abcd")
    assert token != Token(None, 0, 0, "abcde")
    assert token != Token(None, 0, 0, "abcdef")

# Generated at 2022-06-18 12:47:18.140002
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = ScalarToken(1, 0, 0)
    token2 = ScalarToken(1, 0, 0)
    assert token1 == token2
    token3 = ScalarToken(2, 0, 0)
    assert token1 != token3
    token4 = ScalarToken(1, 1, 1)
    assert token1 != token4
    token5 = ScalarToken(1, 0, 1)
    assert token1 != token5
    token6 = DictToken({token1: token2}, 0, 0)
    assert token1 != token6


# Generated at 2022-06-18 12:47:29.177754
# Unit test for constructor of class DictToken

# Generated at 2022-06-18 12:47:35.203937
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == "foo"


# Generated at 2022-06-18 12:47:39.925623
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert token == Token(1, 2, 3)
    assert token != Token(2, 2, 3)
    assert token != Token(1, 3, 3)
    assert token != Token(1, 2, 4)
    assert token != Token(1, 2, 3, "abc")
    assert token != "abc"
    assert token != None

# Generated at 2022-06-18 12:47:47.354121
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(2, 2, 3)
    assert token1 != token3
    token4 = Token(1, 3, 3)
    assert token1 != token4
    token5 = Token(1, 2, 4)
    assert token1 != token5


# Generated at 2022-06-18 12:47:56.597815
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(0, 0, 0)
    assert token == token
    assert token == Token(0, 0, 0)
    assert not token == Token(1, 0, 0)
    assert not token == Token(0, 1, 0)
    assert not token == Token(0, 0, 1)
    assert not token == Token(0, 0, 0, "")
    assert not token == Token(0, 0, 0, "a")
    assert not token == Token(0, 0, 0, "b")
    assert not token == Token(0, 0, 0, "ab")
    assert not token == Token(0, 0, 0, "ba")
    assert not token == Token(0, 0, 0, "abc")
    assert not token == Token(0, 0, 0, "bac")

# Generated at 2022-06-18 12:48:09.738198
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "foo")
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:48:20.123455
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert token == Token(1, 2, 3)
    assert token != Token(2, 2, 3)
    assert token != Token(1, 3, 3)
    assert token != Token(1, 2, 4)
    assert token != Token(1, 2, 3, "abc")
    assert token != Token(1, 2, 3, "abcd")
    assert token != Token(1, 2, 3, "abcde")
    assert token != Token(1, 2, 3, "abcdef")
    assert token != Token(1, 2, 3, "abcdefg")
    assert token != Token(1, 2, 3, "abcdefgh")
    assert token != Token(1, 2, 3, "abcdefghi")

# Generated at 2022-06-18 12:48:31.720706
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test if two tokens are equal
    token1 = ScalarToken(value=1, start_index=0, end_index=0)
    token2 = ScalarToken(value=1, start_index=0, end_index=0)
    assert token1 == token2

    # Test if two tokens are not equal
    token1 = ScalarToken(value=1, start_index=0, end_index=0)
    token2 = ScalarToken(value=2, start_index=0, end_index=0)
    assert not token1 == token2

    # Test if two tokens are not equal
    token1 = ScalarToken(value=1, start_index=0, end_index=0)
    token2 = ScalarToken(value=1, start_index=1, end_index=0)

# Generated at 2022-06-18 12:48:37.598406
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0, "")
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:48:40.315988
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1, "b": 2}, 0, 1, "abc")

# Generated at 2022-06-18 12:48:45.614606
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:48:51.207027
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert not (token == None)
    assert not (token == 1)
    assert not (token == Token(2, 2, 3))
    assert not (token == Token(1, 3, 3))
    assert not (token == Token(1, 2, 4))
    assert token == Token(1, 2, 3)


# Generated at 2022-06-18 12:49:02.307283
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({'a':1}, 0, 1)
    assert a._value == {'a':1}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == ""
    assert a.string == ""
    assert a.value == {'a':1}
    assert a.start == Position(1, 1, 0)
    assert a.end == Position(1, 1, 1)
    assert a.lookup([]) == a
    assert a.lookup_key([]) == a
    assert a.__repr__() == "DictToken({'a': 1})"
    assert a == DictToken({'a':1}, 0, 1)
    assert a != DictToken({'a':2}, 0, 1)

# Generated at 2022-06-18 12:49:08.276282
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 5, "a: 1, b: 2")
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 5
    assert d._content == "a: 1, b: 2"


# Generated at 2022-06-18 12:49:12.793140
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert token == Token(1, 2, 3)
    assert token != Token(2, 2, 3)
    assert token != Token(1, 3, 3)
    assert token != Token(1, 2, 4)
    assert token != Token(1, 2, 3, "")
    assert token != Token(1, 2, 3, "abc")
    assert token != "abc"
    assert token != None


# Generated at 2022-06-18 12:49:32.605723
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.base import Position
    from typesystem.parser import Token
    from typesystem.parser import ScalarToken
    from typesystem.parser import DictToken
    from typesystem.parser import ListToken
    from typesystem.parser import Token
    from typesystem.parser import ScalarToken
    from typesystem.parser import DictToken
    from typesystem.parser import ListToken
    from typesystem.parser import Token
    from typesystem.parser import ScalarToken
    from typesystem.parser import DictToken
    from typesystem.parser import ListToken
    from typesystem.parser import Token
    from typesystem.parser import ScalarToken
    from typesystem.parser import DictToken
    from typesystem.parser import ListToken
    from typesystem.parser import Token
    from typesystem.parser import ScalarToken

# Generated at 2022-06-18 12:49:37.451014
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test for constructor of class DictToken
    token = DictToken(value = {}, start_index = 0, end_index = 0, content = "")
    assert token._value == {}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""


# Generated at 2022-06-18 12:49:45.579191
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for method __eq__ of class Token
    # Test for equality of two tokens
    assert Token(1, 0, 0) == Token(1, 0, 0)
    # Test for inequality of two tokens
    assert not Token(1, 0, 0) == Token(2, 0, 0)
    assert not Token(1, 0, 0) == Token(1, 1, 0)
    assert not Token(1, 0, 0) == Token(1, 0, 1)
    assert not Token(1, 0, 0) == Token(1, 1, 1)


# Generated at 2022-06-18 12:49:51.234834
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(value={}, start_index=0, end_index=0, content="")
    assert token._value == {}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""
    assert token._child_keys == {}
    assert token._child_tokens == {}


# Generated at 2022-06-18 12:49:57.531086
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import Token
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position

# Generated at 2022-06-18 12:50:03.857161
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert token == Token(1, 2, 3)
    assert token != Token(2, 2, 3)
    assert token != Token(1, 3, 3)
    assert token != Token(1, 2, 4)
    assert token != 1
    assert token != None


# Generated at 2022-06-18 12:50:12.504755
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import ScalarToken, DictToken
    from typesystem.base import Position
    from typesystem.base import Token
    from typesystem.base import ListToken
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import Position
    from typesystem.base import Token
    from typesystem.base import ListToken
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import Position
    from typesystem.base import Token
    from typesystem.base import ListToken
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import Position
    from typesystem.base import Token
    from typesystem.base import ListToken

# Generated at 2022-06-18 12:50:17.821956
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(2, 2, 3)
    assert token1 != token3
    token4 = Token(1, 3, 3)
    assert token1 != token4
    token5 = Token(1, 2, 4)
    assert token1 != token5


# Generated at 2022-06-18 12:50:27.680047
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0)
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""
    assert d.string == ""
    assert d.value == {"a": 1, "b": 2}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 0)
    assert d.lookup([]) == d
    assert d.lookup_key([]) == d
    assert d.lookup([0]) == 1
    assert d.lookup_key([0]) == "a"
    assert d.lookup([1]) == 2

# Generated at 2022-06-18 12:50:31.245517
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(value=1, start_index=1, end_index=2, content="")
    token2 = Token(value=1, start_index=1, end_index=2, content="")
    assert token1 == token2


# Generated at 2022-06-18 12:51:07.739281
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for class Token
    token = Token(value=None, start_index=0, end_index=0)
    assert token == token
    assert token == Token(value=None, start_index=0, end_index=0)
    assert token != Token(value=None, start_index=1, end_index=0)
    assert token != Token(value=None, start_index=0, end_index=1)
    assert token != Token(value=None, start_index=0, end_index=0, content="")
    assert token != Token(value=None, start_index=0, end_index=0, content="a")
    assert token != Token(value=None, start_index=0, end_index=0, content="b")
    assert token != None
    assert token != "a"
   

# Generated at 2022-06-18 12:51:10.655061
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a": 1}, 0, 0)
    assert a._child_keys["a"]._value == "a"
    assert a._child_tokens["a"]._value == 1


# Generated at 2022-06-18 12:51:14.103347
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a":1}, 1, 2, "a")
    assert a._value == {"a":1}
    assert a._start_index == 1
    assert a._end_index == 2
    assert a._content == "a"


# Generated at 2022-06-18 12:51:23.362050
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ab")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcd")

# Generated at 2022-06-18 12:51:27.547840
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == None

# Generated at 2022-06-18 12:51:33.913004
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "foo")
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:51:44.092966
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:51:52.372204
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for class ScalarToken
    token1 = ScalarToken(value=1, start_index=0, end_index=0)
    token2 = ScalarToken(value=1, start_index=0, end_index=0)
    assert token1 == token2
    token3 = ScalarToken(value=2, start_index=0, end_index=0)
    assert token1 != token3
    token4 = ScalarToken(value=1, start_index=1, end_index=0)
    assert token1 != token4
    token5 = ScalarToken(value=1, start_index=0, end_index=1)
    assert token1 != token5

    # Test for class DictToken

# Generated at 2022-06-18 12:51:58.068552
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0)
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""


# Generated at 2022-06-18 12:52:03.470775
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(2, 2, 3)
    assert token1 != token3
    token4 = Token(1, 3, 3)
    assert token1 != token4
    token5 = Token(1, 2, 4)
    assert token1 != token5


# Generated at 2022-06-18 12:53:27.431480
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(value={}, start_index=0, end_index=0, content="")
    assert token._value == {}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""
    assert token._child_keys == {}
    assert token._child_tokens == {}


# Generated at 2022-06-18 12:53:31.624493
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({'a': 1, 'b': 2}, 0, 1, '{"a": 1, "b": 2}')
    assert token._child_keys == {'a': 'a', 'b': 'b'}
    assert token._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:53:43.253531
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 1)
    assert d._value == {"a": 1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""
    assert d.string == ""
    assert d.value == {"a": 1}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 1)
    assert d.lookup([]) == d
    assert d.lookup_key([]) == d
    assert d._get_position(0) == Position(1, 1, 0)
    assert repr(d) == "DictToken({'a': 1})"
    assert d == DictToken({"a": 1}, 0, 1)

# Generated at 2022-06-18 12:53:54.370889
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 1)
    assert d._value == {"a": 1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""
    assert d.string == ""
    assert d.value == {"a": 1}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 1)
    assert d.lookup([]) == d
    assert d.lookup_key([0]) == d
    assert d.__repr__() == "DictToken('')"
    assert d.__eq__(d) == True
    assert d.__hash__() == hash({"a": 1})


# Generated at 2022-06-18 12:54:00.538629
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 1, "a")
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == "a"
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:54:03.859351
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(value = {}, start_index = 0, end_index = 0, content = "")
    assert token._value == {}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""


# Generated at 2022-06-18 12:54:09.156110
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({}, 0, 0)
    assert token._child_keys == {}
    assert token._child_tokens == {}
    assert token._value == {}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""
    assert token.string == ""
    assert token.value == {}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert token._get_position(0) == Position(1, 1, 0)
    assert repr(token) == "DictToken({})"
    assert token == DictToken({}, 0, 0)

# Generated at 2022-06-18 12:54:15.567730
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a": 1, "b": 2}, 0, 0, "")
    assert a._value == {"a": 1, "b": 2}
    assert a._start_index == 0
    assert a._end_index == 0
    assert a._content == ""
    assert a._child_keys == {"a": 1, "b": 2}
    assert a._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:54:18.123102
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 0)
    assert d._child_keys == {"a": 1}
    assert d._child_tokens == {"a": 1}
    assert d._value == {"a": 1}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""


# Generated at 2022-06-18 12:54:29.320517
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken(
        {
            ScalarToken("a", 1, 2): ScalarToken(1, 3, 4),
            ScalarToken("b", 5, 6): ScalarToken(2, 7, 8),
        },
        1,
        8,
        "a1b2",
    )
    assert d._child_keys == {
        "a": ScalarToken("a", 1, 2),
        "b": ScalarToken("b", 5, 6),
    }
    assert d._child_tokens == {
        "a": ScalarToken(1, 3, 4),
        "b": ScalarToken(2, 7, 8),
    }