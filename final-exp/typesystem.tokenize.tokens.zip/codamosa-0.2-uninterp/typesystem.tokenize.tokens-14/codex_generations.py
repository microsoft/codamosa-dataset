

# Generated at 2022-06-18 12:45:25.786486
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != None

# Generated at 2022-06-18 12:45:33.264352
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ''


# Generated at 2022-06-18 12:45:39.104779
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({'a':1},0,1)
    assert d._value == {'a':1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""
    assert d._child_keys == {'a': 'a'}
    assert d._child_tokens == {'a': 1}


# Generated at 2022-06-18 12:45:49.386066
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(1, 2, 3)
    t2 = Token(1, 2, 3)
    assert t1 == t2
    assert not (t1 != t2)
    t3 = Token(2, 2, 3)
    assert not (t1 == t3)
    assert t1 != t3
    t4 = Token(1, 3, 3)
    assert not (t1 == t4)
    assert t1 != t4
    t5 = Token(1, 2, 4)
    assert not (t1 == t5)
    assert t1 != t5
    t6 = Token(1, 2, 3, "abc")
    assert t1 == t6
    assert not (t1 != t6)
    t7 = Token(1, 2, 3, "abcd")

# Generated at 2022-06-18 12:45:57.525939
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(1, 2, 4)
    token4 = Token(2, 2, 3)
    token5 = Token(1, 3, 3)
    token6 = Token(1, 2, 2)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5
    assert token1 != token6


# Generated at 2022-06-18 12:46:02.983669
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({'a':1}, 0, 1, '{a:1}')
    assert d._value == {'a':1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == '{a:1}'
    assert d._child_keys == {'a': 'a'}
    assert d._child_tokens == {'a': 1}


# Generated at 2022-06-18 12:46:06.397424
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken(value = {}, start_index = 0, end_index = 0, content = "")
    assert d._value == {}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""


# Generated at 2022-06-18 12:46:14.914321
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a':1, 'b':2}
    dt = DictToken(d, 0, 0)
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ''
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:46:16.716295
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1}, 0, 1, "a: 1")


# Generated at 2022-06-18 12:46:28.121981
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 2)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "a")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "b")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "ab")


# Generated at 2022-06-18 12:46:37.178390
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:46:40.304485
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "foo")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "bar")
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:46:45.486580
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:46:50.545753
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert token == Token(1, 2, 3)
    assert token != Token(2, 2, 3)
    assert token != Token(1, 3, 3)
    assert token != Token(1, 2, 4)
    assert token != 1
    assert token != None


# Generated at 2022-06-18 12:46:54.048935
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:46:59.512933
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a": 1, "b": 2}, 0, 5)
    assert a._value == {"a": 1, "b": 2}
    assert a._start_index == 0
    assert a._end_index == 5
    assert a._child_keys == {"a": 1, "b": 2}
    assert a._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:47:10.239772
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:47:14.275227
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0, "")
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""


# Generated at 2022-06-18 12:47:20.779324
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": "b"}, 0, 1)
    assert d._value == {"a": "b"}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""
    assert d.string == ""
    assert d.value == {"a": "b"}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 1)
    assert d.lookup([]) == d
    assert d.lookup_key([]) == d
    assert d._get_position(0) == Position(1, 1, 0)
    assert d.__repr__() == "DictToken('')"
    assert d.__eq__(d) == True

# Generated at 2022-06-18 12:47:23.423126
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test for constructor of class DictToken
    # Arrange
    value = {'a': 'b'}
    start_index = 1
    end_index = 2
    content = "abc"
    # Act
    token = DictToken(value, start_index, end_index, content)
    # Assert
    assert token._value == value
    assert token._start_index == start_index
    assert token._end_index == end_index
    assert token._content == content


# Generated at 2022-06-18 12:47:40.492691
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 1)
    assert d._value == {"a": 1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""
    assert d.string == ""
    assert d.value == {"a": 1}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 1)
    assert d.lookup([]) == d
    assert d.lookup_key([]) == d
    assert d._get_position(0) == Position(1, 1, 0)
    assert d.__repr__() == "DictToken('')"
    assert d.__eq__(d) == True
    assert d.__hash__() == hash({"a": 1})


# Generated at 2022-06-18 12:47:48.506960
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 4)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != None

# Generated at 2022-06-18 12:47:58.516717
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0)
    assert token == token
    assert not (token != token)
    assert token == Token(value=None, start_index=0, end_index=0)
    assert not (token != Token(value=None, start_index=0, end_index=0))
    assert token != Token(value=None, start_index=1, end_index=0)
    assert not (token == Token(value=None, start_index=1, end_index=0))
    assert token != Token(value=None, start_index=0, end_index=1)
    assert not (token == Token(value=None, start_index=0, end_index=1))

# Generated at 2022-06-18 12:48:01.421771
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({'a': 1}, 0, 1, "a")
    assert a._value == {'a': 1}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == "a"
    assert a._child_keys == {'a': 'a'}
    assert a._child_tokens == {'a': 1}


# Generated at 2022-06-18 12:48:11.692401
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test with two equal tokens
    token1 = ScalarToken(value=1, start_index=0, end_index=1)
    token2 = ScalarToken(value=1, start_index=0, end_index=1)
    assert token1 == token2

    # Test with two unequal tokens
    token1 = ScalarToken(value=1, start_index=0, end_index=1)
    token2 = ScalarToken(value=2, start_index=0, end_index=1)
    assert token1 != token2

    # Test with two unequal tokens
    token1 = ScalarToken(value=1, start_index=0, end_index=1)
    token2 = ScalarToken(value=1, start_index=0, end_index=2)
    assert token1 != token2

   

# Generated at 2022-06-18 12:48:21.937590
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for class ScalarToken
    token1 = ScalarToken(1, 0, 0)
    token2 = ScalarToken(1, 0, 0)
    token3 = ScalarToken(2, 0, 0)
    assert token1 == token2
    assert token1 != token3
    # Test for class DictToken
    token4 = DictToken({}, 0, 0)
    token5 = DictToken({}, 0, 0)
    token6 = DictToken({}, 0, 1)
    assert token4 == token5
    assert token4 != token6
    # Test for class ListToken
    token7 = ListToken([], 0, 0)
    token8 = ListToken([], 0, 0)
    token9 = ListToken([], 0, 1)
    assert token7 == token8
    assert token7 != token9

# Generated at 2022-06-18 12:48:26.625512
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1, "b": 2}, 0, 0)
    assert token._child_keys == {"a": "a", "b": "b"}
    assert token._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:48:32.595981
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:48:35.932340
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken({'a': 1}, 0, 1)
    assert dict_token._child_keys == {'a': 'a'}
    assert dict_token._child_tokens == {'a': 1}


# Generated at 2022-06-18 12:48:47.003949
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, 0, 0)
    assert token == token
    assert token != None
    assert token != 1
    assert token != "1"
    assert token != Token(None, 0, 1)
    assert token != Token(None, 1, 0)
    assert token != Token(None, 1, 1)
    assert token != Token(1, 0, 0)
    assert token != Token(1, 0, 1)
    assert token != Token(1, 1, 0)
    assert token != Token(1, 1, 1)
    assert token != Token(None, 0, 0, "1")
    assert token != Token(None, 0, 0, "1")
    assert token != Token(None, 0, 0, "1")
    assert token != Token(None, 0, 0, "1")

# Generated at 2022-06-18 12:49:11.496889
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "a")
    assert not Token(1, 2, 3) == 1
    assert not Token(1, 2, 3) == "a"
    assert not Token(1, 2, 3) == None


# Generated at 2022-06-18 12:49:15.201391
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0)
    assert d._child_keys == {"a": "a", "b": "b"}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:49:26.390636
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken({"a": 1, "b": 2}, 0, 0, "")
    assert dict_token.value == {"a": 1, "b": 2}
    assert dict_token.start == Position(1, 1, 0)
    assert dict_token.end == Position(1, 1, 0)
    assert dict_token.string == ""
    assert dict_token.lookup([]) == dict_token
    assert dict_token.lookup_key([]) == dict_token
    assert dict_token.lookup([0]) == dict_token
    assert dict_token.lookup_key([0]) == dict_token
    assert dict_token.lookup([1]) == dict_token
    assert dict_token.lookup_key([1]) == dict_token

# Generated at 2022-06-18 12:49:31.753854
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test with two equal tokens
    token1 = ScalarToken(value=1, start_index=0, end_index=0)
    token2 = ScalarToken(value=1, start_index=0, end_index=0)
    assert token1 == token2

    # Test with two unequal tokens
    token1 = ScalarToken(value=1, start_index=0, end_index=0)
    token2 = ScalarToken(value=2, start_index=0, end_index=0)
    assert token1 != token2

    # Test with two unequal tokens
    token1 = ScalarToken(value=1, start_index=0, end_index=0)
    token2 = ScalarToken(value=1, start_index=1, end_index=0)
    assert token1 != token2

   

# Generated at 2022-06-18 12:49:43.063617
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:49:45.436391
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:49:51.477562
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 1, "a")
    assert d._value == {"a": 1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == "a"
    assert d._child_keys == {"a": 1}
    assert d._child_tokens == {"a": 1}


# Generated at 2022-06-18 12:49:53.608396
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken(value = {'a': 1, 'b': 2}, start_index = 0, end_index = 1, content = "")


# Generated at 2022-06-18 12:50:02.173480
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({'a': 1, 'b': 2}, 0, 0, 'a:1,b:2')
    assert d._value == {'a': 1, 'b': 2}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == 'a:1,b:2'
    assert d._child_keys == {'a': 'a', 'b': 'b'}
    assert d._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:50:08.780833
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ""
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:50:47.362054
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0, content="")
    assert token == token
    assert token != None
    assert token != ""
    assert token != 0
    assert token != []
    assert token != {}
    assert token != ()
    assert token != False
    assert token != True
    assert token != ScalarToken(value=None, start_index=0, end_index=0, content="")
    assert token != DictToken(value=None, start_index=0, end_index=0, content="")
    assert token != ListToken(value=None, start_index=0, end_index=0, content="")


# Generated at 2022-06-18 12:50:57.451901
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test for constructor of class DictToken
    # Create a DictToken object
    dt = DictToken(
        {
            "key1": "value1",
            "key2": "value2",
            "key3": "value3",
        },
        0,
        10,
        "key1:value1,key2:value2,key3:value3",
    )
    # Test for the value of the object
    assert dt._value == {
        "key1": "value1",
        "key2": "value2",
        "key3": "value3",
    }
    # Test for the start index of the object
    assert dt._start_index == 0
    # Test for the end index of the object
    assert dt._end_index == 10
    # Test for the content

# Generated at 2022-06-18 12:50:59.663529
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:51:03.634373
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0)
    assert d._child_keys == {"a": "a", "b": "b"}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:51:08.973252
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == object()


# Generated at 2022-06-18 12:51:16.589748
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(value = "value", start_index = 1, end_index = 2, content = "content")
    token2 = Token(value = "value", start_index = 1, end_index = 2, content = "content")
    token3 = Token(value = "value", start_index = 1, end_index = 2, content = "content")
    assert token1 == token2
    assert token2 == token1
    assert token1 == token3
    assert token3 == token1
    assert token2 == token3
    assert token3 == token2
    assert token1 == token1
    assert token2 == token2
    assert token3 == token3


# Generated at 2022-06-18 12:51:20.126366
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0)
    assert d._child_keys == {"a": "a", "b": "b"}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:51:24.843120
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != 1


# Generated at 2022-06-18 12:51:28.446675
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a": 1, "b": 2}, 0, 0, "")
    assert a._value == {"a": 1, "b": 2}
    assert a._start_index == 0
    assert a._end_index == 0
    assert a._content == ""
    assert a._child_keys == {"a": 1, "b": 2}
    assert a._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:51:35.057729
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0, '{"a": 1, "b": 2}')
    assert dt._child_keys['a']._value == 'a'
    assert dt._child_keys['b']._value == 'b'
    assert dt._child_tokens['a']._value == 1
    assert dt._child_tokens['b']._value == 2


# Generated at 2022-06-18 12:52:35.516975
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0)
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""
    assert d.string == ""
    assert d.value == {"a": 1, "b": 2}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 0)
    assert d.lookup(["a"]) == 1
    assert d.lookup_key(["a"]) == 1
    assert d._get_position

# Generated at 2022-06-18 12:52:45.339470
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:52:54.198537
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(
        {
            ScalarToken(1, 0, 0): ScalarToken(2, 0, 0),
            ScalarToken(3, 0, 0): ScalarToken(4, 0, 0),
        },
        0,
        0,
    )
    assert token._child_keys == {1: ScalarToken(1, 0, 0), 3: ScalarToken(3, 0, 0)}
    assert token._child_tokens == {
        1: ScalarToken(2, 0, 0),
        3: ScalarToken(4, 0, 0),
    }


# Generated at 2022-06-18 12:53:04.929742
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1}, 0, 1)
    assert token._value == {"a": 1}
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == ""
    assert token.string == ""
    assert token.value == {"a": 1}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 1)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert token._get_position(0) == Position(1, 1, 0)
    assert repr(token) == "DictToken({'a': 1})"
    assert token == DictToken({"a": 1}, 0, 1)

# Generated at 2022-06-18 12:53:17.408730
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for class ScalarToken
    assert ScalarToken(1, 0, 0) == ScalarToken(1, 0, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(2, 0, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 1, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 0, 1)
    # Test for class DictToken
    assert DictToken({}, 0, 0) == DictToken({}, 0, 0)
    assert DictToken({}, 0, 0) != DictToken({1: 2}, 0, 0)
    assert DictToken({1: 2}, 0, 0) != DictToken({1: 3}, 0, 0)

# Generated at 2022-06-18 12:53:23.122984
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == "foo"



# Generated at 2022-06-18 12:53:26.544147
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({'a':1, 'b':2}, 0, 0, "")
    assert token._child_keys == {'a': 'a', 'b': 'b'}
    assert token._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:53:27.706330
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1}, 0, 0)


# Generated at 2022-06-18 12:53:29.730887
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:53:33.997735
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0, "")
    assert d._child_keys == {"a": "a", "b": "b"}
    assert d._child_tokens == {"a": 1, "b": 2}
