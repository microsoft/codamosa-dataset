

# Generated at 2022-06-18 12:45:22.605989
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a": 1}, 0, 1)
    assert a._value == {"a": 1}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == ""
    assert a.string == ""
    assert a.value == {"a": 1}
    assert a.start == Position(1, 1, 0)
    assert a.end == Position(1, 1, 1)
    assert a.lookup([]) == a
    assert a.lookup_key([]) == a
    assert a._get_position(0) == Position(1, 1, 0)
    assert repr(a) == "DictToken('')"
    assert a == DictToken({"a": 1}, 0, 1)
    assert hash(a) == hash({"a": 1})


# Generated at 2022-06-18 12:45:28.404689
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0, "")
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}
    assert d._get_value() == {"a": 1, "b": 2}
    assert d._get_child_token("a") == 1
    assert d._get_key_token("a") == 1


# Generated at 2022-06-18 12:45:31.396448
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1}, 0, 1, "a: 1")


# Generated at 2022-06-18 12:45:41.483831
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:45:50.145876
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ab")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcd")

# Generated at 2022-06-18 12:45:56.922099
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken(value={"a": 1}, start_index=0, end_index=1, content="a")
    assert d._value == {"a": 1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == "a"
    assert d._child_keys == {"a": "a"}
    assert d._child_tokens == {"a": 1}


# Generated at 2022-06-18 12:46:06.350141
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(None, 0, 0) == Token(None, 0, 0)
    assert not Token(None, 0, 0) == Token(None, 0, 1)
    assert not Token(None, 0, 0) == Token(None, 1, 0)
    assert not Token(None, 0, 0) == Token(None, 1, 1)
    assert not Token(None, 0, 0) == Token(None, 0, 0, "")
    assert not Token(None, 0, 0) == Token(None, 0, 0, "a")
    assert not Token(None, 0, 0) == Token(None, 0, 0, "ab")
    assert not Token(None, 0, 0) == Token(None, 0, 0, "abc")

# Generated at 2022-06-18 12:46:18.826055
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "a")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "ab")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "abc")

# Generated at 2022-06-18 12:46:29.861030
# Unit test for constructor of class DictToken

# Generated at 2022-06-18 12:46:40.443557
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import Position
    from typesystem.base import Token
    from typesystem.base import Token
    from typesystem.base import Token
    from typesystem.base import Token
    from typesystem.base import Token
    from typesystem.base import Token
    from typesystem.base import Token
    from typesystem.base import Token
    from typesystem.base import Token
    from typesystem.base import Token
    from typesystem.base import Token
    from typesystem.base import Token
    from typesystem.base import Token
    from typesystem.base import Token
    from typesystem.base import Token
    from typesystem.base import Token
    from typesystem.base import Token

# Generated at 2022-06-18 12:46:47.491532
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0, "")
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}
    assert d._get_value() == {"a": 1, "b": 2}
    assert d._get_child_token("a") == 1
    assert d._get_key_token("a") == 1


# Generated at 2022-06-18 12:46:55.265183
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "a")
    assert not Token(1, 2, 3) == "a"


# Generated at 2022-06-18 12:47:03.272304
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    assert not (token1 != token2)
    token3 = Token(2, 2, 3)
    assert not (token1 == token3)
    assert token1 != token3
    token4 = Token(1, 3, 3)
    assert not (token1 == token4)
    assert token1 != token4
    token5 = Token(1, 2, 4)
    assert not (token1 == token5)
    assert token1 != token5


# Generated at 2022-06-18 12:47:13.467701
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(2, 3, 4)
    assert Token(1, 2, 3) != Token(2, 3, 4)
    assert Token(1, 2, 3) != "foo"
    assert Token(1, 2, 3) != None
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != 2
    assert Token(1, 2, 3) != 3
    assert Token(1, 2, 3) != 4

# Generated at 2022-06-18 12:47:17.800955
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1



# Generated at 2022-06-18 12:47:25.347152
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    t = DictToken(d, 0, 0)
    assert t._value == d
    assert t._start_index == 0
    assert t._end_index == 0
    assert t._content == ""
    assert t._child_keys == {'a': 'a', 'b': 'b'}
    assert t._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:47:30.602435
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != None


# Generated at 2022-06-18 12:47:34.758794
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == object()


# Generated at 2022-06-18 12:47:44.579008
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({}, 0, 0)
    assert a._value == {}
    assert a._start_index == 0
    assert a._end_index == 0
    assert a._content == ""
    assert a.string == ""
    assert a.value == {}
    assert a.start == Position(1, 1, 0)
    assert a.end == Position(1, 1, 0)
    assert a.lookup([]) == a
    assert a.lookup_key([]) == a
    assert a._get_position(0) == Position(1, 1, 0)
    assert repr(a) == "DictToken({})"
    assert a == DictToken({}, 0, 0)
    assert hash(a) == hash({})


# Generated at 2022-06-18 12:47:48.092691
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1}, 0, 1, "a")


# Generated at 2022-06-18 12:48:00.348663
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0)
    assert d._child_keys["a"]._value == "a"
    assert d._child_keys["b"]._value == "b"
    assert d._child_tokens["a"]._value == 1
    assert d._child_tokens["b"]._value == 2


# Generated at 2022-06-18 12:48:05.168979
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({'a': 1}, 0, 1, '{a: 1}')
    assert token._value == {'a': 1}
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == '{a: 1}'
    assert token._child_keys == {'a': 'a'}
    assert token._child_tokens == {'a': 1}


# Generated at 2022-06-18 12:48:16.899223
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.base import Position
    from typesystem.base import Token
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import Token
    from typesystem.base import Position
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import Token
    from typesystem.base import Position
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import Token
    from typesystem.base import Position
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken

# Generated at 2022-06-18 12:48:18.763630
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:48:25.355628
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken({"a": 1}, 0, 1)
    assert dict_token._value == {"a": 1}
    assert dict_token._start_index == 0
    assert dict_token._end_index == 1
    assert dict_token._content == ""
    assert dict_token._child_keys == {"a": "a"}
    assert dict_token._child_tokens == {"a": 1}


# Generated at 2022-06-18 12:48:31.399190
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == None


# Generated at 2022-06-18 12:48:42.289836
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({'a': 1, 'b': 2}, 0, 1, 'a: 1\nb: 2')
    assert a.value == {'a': 1, 'b': 2}
    assert a.start == Position(1, 1, 0)
    assert a.end == Position(2, 4, 1)
    assert a.string == 'a: 1\nb: 2'
    assert a.lookup([0]) == a._child_tokens['a']
    assert a.lookup_key([0]) == a._child_keys['a']
    assert a.lookup([1]) == a._child_tokens['b']
    assert a.lookup_key([1]) == a._child_keys['b']

# Generated at 2022-06-18 12:48:49.503894
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test 1
    token = DictToken(value = {}, start_index = 0, end_index = 0)
    assert token._value == {}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""

    # Test 2
    token = DictToken(value = {}, start_index = 1, end_index = 1, content = "abc")
    assert token._value == {}
    assert token._start_index == 1
    assert token._end_index == 1
    assert token._content == "abc"


# Generated at 2022-06-18 12:48:51.697021
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:48:58.367901
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ""
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:49:22.479329
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:49:27.341778
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(1, 2, 3)
    t2 = Token(1, 2, 3)
    assert t1 == t2
    t3 = Token(2, 2, 3)
    assert t1 != t3
    t4 = Token(1, 3, 3)
    assert t1 != t4
    t5 = Token(1, 2, 4)
    assert t1 != t5


# Generated at 2022-06-18 12:49:29.195660
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:49:32.633789
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=1, start_index=2, end_index=3)
    assert token == token
    assert token == Token(value=1, start_index=2, end_index=3)
    assert token != Token(value=2, start_index=2, end_index=3)
    assert token != Token(value=1, start_index=3, end_index=3)
    assert token != Token(value=1, start_index=2, end_index=4)
    assert token != 1

# Generated at 2022-06-18 12:49:38.229336
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:49:49.936546
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0)
    assert token == token
    assert token == Token(value=None, start_index=0, end_index=0)
    assert token != Token(value=None, start_index=1, end_index=0)
    assert token != Token(value=None, start_index=0, end_index=1)
    assert token != Token(value=None, start_index=1, end_index=1)
    assert token != Token(value=None, start_index=0, end_index=0, content="")
    assert token != Token(value=None, start_index=0, end_index=0, content="a")
    assert token != Token(value=None, start_index=0, end_index=0, content="ab")

# Generated at 2022-06-18 12:49:54.447449
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1}, 0, 1, "a")
    assert token._value == {"a": 1}
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == "a"
    assert token._child_keys == {"a": 1}
    assert token._child_tokens == {"a": 1}


# Generated at 2022-06-18 12:50:02.800666
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 3, "foo")
    assert Token(1, 2, 3) != 1


# Generated at 2022-06-18 12:50:10.161528
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    assert not (token1 != token2)
    token3 = Token(2, 2, 3)
    assert not (token1 == token3)
    assert token1 != token3
    token4 = Token(1, 3, 3)
    assert not (token1 == token4)
    assert token1 != token4
    token5 = Token(1, 2, 4)
    assert not (token1 == token5)
    assert token1 != token5


# Generated at 2022-06-18 12:50:13.764811
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(value={}, start_index=0, end_index=0, content="")
    assert token._value == {}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""
    assert token._child_keys == {}
    assert token._child_tokens == {}


# Generated at 2022-06-18 12:51:02.473455
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 2, 3, "foo")
    assert Token(1, 2, 3) != "foo"

# Generated at 2022-06-18 12:51:12.440357
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test with a ScalarToken
    token1 = ScalarToken(1, 0, 0)
    token2 = ScalarToken(1, 0, 0)
    assert token1 == token2
    token2 = ScalarToken(2, 0, 0)
    assert token1 != token2
    token2 = ScalarToken(1, 1, 0)
    assert token1 != token2
    token2 = ScalarToken(1, 0, 1)
    assert token1 != token2
    # Test with a DictToken
    token1 = DictToken({}, 0, 0)
    token2 = DictToken({}, 0, 0)
    assert token1 == token2
    token2 = DictToken({ScalarToken(1, 0, 0): ScalarToken(2, 0, 0)}, 0, 0)
    assert token

# Generated at 2022-06-18 12:51:15.031604
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3, "") == Token(1, 2, 3, "")
    assert Token(1, 2, 3, "") != Token(1, 2, 3, "")


# Generated at 2022-06-18 12:51:20.004504
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:51:24.722041
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(1, 2, 4)
    token4 = Token(1, 3, 3)
    token5 = Token(2, 2, 3)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5


# Generated at 2022-06-18 12:51:30.769314
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, 0, 0)
    assert token == token
    assert token == Token(None, 0, 0)
    assert not (token == Token(None, 1, 0))
    assert not (token == Token(None, 0, 1))
    assert not (token == Token(None, 0, 0, "a"))
    assert not (token == Token(None, 0, 0, "b"))
    assert not (token == Token(None, 0, 0, "a", "b"))
    assert not (token == Token(None, 0, 0, "b", "a"))
    assert not (token == Token(None, 0, 0, "a", "a"))
    assert not (token == Token(None, 0, 0, "b", "b"))

# Generated at 2022-06-18 12:51:41.123135
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0)
    assert token == token
    assert token != None
    assert token != 1
    assert token != "1"
    assert token != []
    assert token != {}
    assert token != ()
    assert token != (1, 2)
    assert token != [1, 2]
    assert token != {"a": 1}
    assert token != {"a": 1, "b": 2}
    assert token != {"a": 1, "b": 2, "c": 3}
    assert token != {"a": 1, "b": 2, "c": 3, "d": 4}
    assert token != {"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}

# Generated at 2022-06-18 12:51:46.594334
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:51:50.816296
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(2, 2, 3)
    assert token1 != token3
    token4 = Token(1, 3, 3)
    assert token1 != token4
    token5 = Token(1, 2, 4)
    assert token1 != token5


# Generated at 2022-06-18 12:51:53.763960
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0, content="")
    other = Token(value=None, start_index=0, end_index=0, content="")
    assert token == other


# Generated at 2022-06-18 12:52:59.083428
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 1)
    assert d._value == {"a": 1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""
    assert d._child_keys == {"a": "a"}
    assert d._child_tokens == {"a": 1}


# Generated at 2022-06-18 12:53:10.060118
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(2, 3, 4)
    assert Token(1, 2, 3) != Token(2, 3, 4)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != "1"
    assert Token(1, 2, 3) != None
    assert Token(1, 2, 3) != object()


# Generated at 2022-06-18 12:53:20.230930
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "a")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "ab")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "abc")

# Generated at 2022-06-18 12:53:29.640133
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:53:41.310584
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test with ScalarToken
    token1 = ScalarToken(value=1, start_index=0, end_index=0, content="1")
    token2 = ScalarToken(value=1, start_index=0, end_index=0, content="1")
    assert token1 == token2
    token3 = ScalarToken(value=2, start_index=0, end_index=0, content="2")
    assert token1 != token3
    # Test with DictToken
    token4 = DictToken(value={}, start_index=0, end_index=0, content="{}")
    token5 = DictToken(value={}, start_index=0, end_index=0, content="{}")
    assert token4 == token5

# Generated at 2022-06-18 12:53:48.503959
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0)
    assert token == token
    assert token == Token(value=None, start_index=0, end_index=0)
    assert token != Token(value=None, start_index=1, end_index=0)
    assert token != Token(value=None, start_index=0, end_index=1)
    assert token != Token(value=None, start_index=0, end_index=0, content="")
    assert token != Token(value=None, start_index=0, end_index=0, content="a")
    assert token != Token(value=None, start_index=0, end_index=0, content="ab")

# Generated at 2022-06-18 12:53:59.332827
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:54:04.032428
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1
    assert not Token(1, 2, 3) == None


# Generated at 2022-06-18 12:54:15.569140
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 3, "")
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != Token(1, 2, 3, "ab")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != Token(1, 2, 3, "abcd")

# Generated at 2022-06-18 12:54:26.342460
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.base import Position
    from typesystem.parser import ScalarToken, DictToken, ListToken
    token1 = ScalarToken(1, 0, 0)
    token2 = ScalarToken(1, 0, 0)
    token3 = ScalarToken(2, 0, 0)
    token4 = ScalarToken(1, 1, 0)
    token5 = ScalarToken(1, 0, 1)
    token6 = DictToken({token1: token2}, 0, 0)
    token7 = DictToken({token1: token2}, 0, 0)
    token8 = DictToken({token1: token3}, 0, 0)
    token9 = DictToken({token1: token2}, 1, 0)
    token10 = DictToken({token1: token2}, 0, 1)
    token