

# Generated at 2022-06-18 12:45:08.579043
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1}, 0, 1)


# Generated at 2022-06-18 12:45:09.564922
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1}, 0, 1)


# Generated at 2022-06-18 12:45:15.974512
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 2, "a: 1, b: 2")
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 2
    assert d._content == "a: 1, b: 2"


# Generated at 2022-06-18 12:45:18.630728
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a":1}, 0, 1)
    assert a._child_keys == {"a":1}
    assert a._child_tokens == {"a":1}


# Generated at 2022-06-18 12:45:25.570538
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0)
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:45:37.034291
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": "b"}, 0, 1)
    assert d._value == {"a": "b"}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""
    assert d.string == ""
    assert d.value == {"a": "b"}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 1)
    assert d.lookup([]) == d
    assert d.lookup_key([]) == d
    assert d._get_position(0) == Position(1, 1, 0)
    assert repr(d) == "DictToken({'a': 'b'})"
    assert d == DictToken({"a": "b"}, 0, 1)

# Generated at 2022-06-18 12:45:43.414626
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 5, "a: 1\nb: 2")
    assert d._value == {"a": 1, "b": 2}
    assert d._start_index == 0
    assert d._end_index == 5
    assert d._content == "a: 1\nb: 2"
    assert d._child_keys == {"a": "a", "b": "b"}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:45:51.355541
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:45:53.765737
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(1, 2, 3, "abc")
    t2 = Token(1, 2, 3, "abc")
    assert t1 == t2


# Generated at 2022-06-18 12:45:58.498912
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(value = {}, start_index = 0, end_index = 0, content = "")
    assert token._value == {}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""


# Generated at 2022-06-18 12:46:07.019107
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0, content="")
    assert token == token


# Generated at 2022-06-18 12:46:12.313657
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({'a': 1, 'b': 2}, 0, 3)
    assert token._child_keys == {'a': 'a', 'b': 'b'}
    assert token._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:46:19.656295
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1
    assert not Token(1, 2, 3) == None


# Generated at 2022-06-18 12:46:30.738355
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0)
    assert token == token
    assert token == Token(value=None, start_index=0, end_index=0)
    assert token != Token(value=None, start_index=1, end_index=0)
    assert token != Token(value=None, start_index=0, end_index=1)
    assert token != Token(value=None, start_index=1, end_index=1)
    assert token != Token(value=None, start_index=0, end_index=0, content="")
    assert token != Token(value=None, start_index=0, end_index=0, content="a")
    assert token != Token(value=None, start_index=0, end_index=0, content="b")

# Generated at 2022-06-18 12:46:35.244859
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0)
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:46:44.059100
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert token == Token(1, 2, 3)
    assert token != Token(2, 2, 3)
    assert token != Token(1, 3, 3)
    assert token != Token(1, 2, 4)
    assert token != Token(1, 2, 3, "")
    assert token != Token(1, 2, 3, "abc")
    assert token != Token(1, 2, 3, "abcd")
    assert token != Token(1, 2, 3, "abcde")
    assert token != Token(1, 2, 3, "abcdef")
    assert token != Token(1, 2, 3, "abcdefg")
    assert token != Token(1, 2, 3, "abcdefgh")

# Generated at 2022-06-18 12:46:46.953621
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert token == Token(1, 2, 3)
    assert token != Token(2, 2, 3)
    assert token != Token(1, 3, 3)
    assert token != Token(1, 2, 4)
    assert token != None


# Generated at 2022-06-18 12:46:57.502788
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:46:59.524877
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": "b"}, 0, 1, "a: b")


# Generated at 2022-06-18 12:47:05.762570
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != None


# Generated at 2022-06-18 12:47:34.674914
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "a")
    assert not Token(1, 2, 3) == "a"

# Generated at 2022-06-18 12:47:38.196361
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:47:40.728937
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 0)
    assert d._child_keys == {"a": 1}
    assert d._child_tokens == {"a": 1}


# Generated at 2022-06-18 12:47:52.551734
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:48:02.474005
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for method __eq__ of class Token
    # Tests for equality of tokens
    assert ScalarToken(1, 0, 0) == ScalarToken(1, 0, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 0, 1)
    assert ScalarToken(1, 0, 0) != ScalarToken(2, 0, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 1, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 0, 1)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 1, 1)
    assert ScalarToken(1, 0, 0) != ScalarToken(2, 1, 1)

# Generated at 2022-06-18 12:48:07.254726
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == None

# Generated at 2022-06-18 12:48:14.323322
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0, "")
    assert d._child_keys["a"]._value == "a"
    assert d._child_keys["b"]._value == "b"
    assert d._child_tokens["a"]._value == 1
    assert d._child_tokens["b"]._value == 2


# Generated at 2022-06-18 12:48:24.887374
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(
        {}, 0, 0, content="{}"
    )
    assert token._value == {}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == "{}"
    assert token.string == "{}"
    assert token.value == {}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert token._get_position(0) == Position(1, 1, 0)

# Generated at 2022-06-18 12:48:30.953464
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != 1


# Generated at 2022-06-18 12:48:36.111789
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:49:29.681137
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == object()


# Generated at 2022-06-18 12:49:33.314747
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != None


# Generated at 2022-06-18 12:49:44.098597
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a":1}, 0, 1)
    assert d._value == {"a":1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""
    assert d.string == ""
    assert d.value == {"a":1}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 1)
    assert d.lookup([]) == d
    assert d.lookup_key([]) == d
    assert d._get_position(0) == Position(1, 1, 0)
    assert repr(d) == "DictToken({'a': 1})"
    assert d == DictToken({"a":1}, 0, 1)

# Generated at 2022-06-18 12:49:54.352164
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(None, 0, 0) == Token(None, 0, 0)
    assert not Token(None, 0, 0) == Token(None, 0, 1)
    assert not Token(None, 0, 0) == Token(None, 1, 0)
    assert not Token(None, 0, 0) == Token(None, 1, 1)
    assert not Token(None, 0, 0) == Token(None, 0, 0, "")
    assert not Token(None, 0, 0) == Token(None, 0, 0, "a")
    assert not Token(None, 0, 0) == Token(None, 0, 0, "b")
    assert not Token(None, 0, 0) == Token(None, 0, 0, "ab")

# Generated at 2022-06-18 12:50:06.665712
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test with ScalarToken
    token1 = ScalarToken(1, 0, 0)
    token2 = ScalarToken(1, 0, 0)
    assert token1 == token2
    token3 = ScalarToken(2, 0, 0)
    assert token1 != token3
    token4 = ScalarToken(1, 1, 1)
    assert token1 != token4
    token5 = ScalarToken(1, 0, 1)
    assert token1 != token5
    # Test with DictToken
    token6 = DictToken({token1: token2}, 0, 0)
    token7 = DictToken({token1: token2}, 0, 0)
    assert token6 == token7
    token8 = DictToken({token1: token3}, 0, 0)
    assert token6 != token8
    token9

# Generated at 2022-06-18 12:50:09.567347
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a":1}, 0, 1)
    assert d._value == {"a":1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""


# Generated at 2022-06-18 12:50:11.651327
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3, "abc")
    token2 = Token(1, 2, 3, "abc")
    assert token1 == token2


# Generated at 2022-06-18 12:50:17.706949
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert token == Token(1, 2, 3)
    assert token != Token(2, 2, 3)
    assert token != Token(1, 3, 3)
    assert token != Token(1, 2, 4)
    assert token != Token(1, 2, 3, "")
    assert token != Token(1, 2, 3, "abc")
    assert token != 1
    assert token != object()


# Generated at 2022-06-18 12:50:19.800891
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 1, 2)
    token2 = Token(1, 1, 2)
    assert token1 == token2


# Generated at 2022-06-18 12:50:25.492343
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(1, 2, 3)
    t2 = Token(1, 2, 3)
    assert t1 == t2
    t3 = Token(2, 2, 3)
    assert not t1 == t3
    t4 = Token(1, 3, 3)
    assert not t1 == t4
    t5 = Token(1, 2, 4)
    assert not t1 == t5


# Generated at 2022-06-18 12:51:36.912702
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != 1


# Generated at 2022-06-18 12:51:43.290952
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(1, 2, 4)
    token4 = Token(1, 3, 3)
    token5 = Token(2, 2, 3)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5
    assert token1 != 1
    assert token1 != "1"


# Generated at 2022-06-18 12:51:51.779756
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:51:57.982852
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 3, "a")
    assert Token(1, 2, 3) != 1


# Generated at 2022-06-18 12:52:01.347756
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0, content="")
    other = Token(value=None, start_index=0, end_index=0, content="")
    assert token == other


# Generated at 2022-06-18 12:52:06.434879
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(2, 2, 3)
    token4 = Token(1, 3, 3)
    token5 = Token(1, 2, 4)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5


# Generated at 2022-06-18 12:52:10.298697
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:52:19.906233
# Unit test for method __eq__ of class Token

# Generated at 2022-06-18 12:52:26.539574
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != None


# Generated at 2022-06-18 12:52:37.543370
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1, "b": 2}, 0, 1, "a: 1, b: 2")
    assert token.value == {"a": 1, "b": 2}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 11, 1)
    assert token.string == "a: 1, b: 2"
    assert token.lookup([0]) == ScalarToken(1, 3, 3, "a: 1, b: 2")
    assert token.lookup([1]) == ScalarToken(2, 9, 9, "a: 1, b: 2")
    assert token.lookup_key([0]) == ScalarToken("a", 1, 1, "a: 1, b: 2")
    assert token.lookup_key([1]) == Scal

# Generated at 2022-06-18 12:54:54.726567
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0)
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:55:04.782094
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 2, 3, "")
    assert not Token(1, 2, 3) == Token(1, 2, 3, "a")
    assert not Token(1, 2, 3) == 1
    assert not Token(1, 2, 3) == "1"
    assert not Token(1, 2, 3) == None
