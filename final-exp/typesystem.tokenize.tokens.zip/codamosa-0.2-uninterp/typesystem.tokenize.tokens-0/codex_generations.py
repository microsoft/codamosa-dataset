

# Generated at 2022-06-18 12:45:22.649542
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != 1


# Generated at 2022-06-18 12:45:28.799960
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a":1,"b":2}, 0, 1, "a:1,b:2")
    assert d._value == {"a":1,"b":2}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == "a:1,b:2"
    assert d._child_keys == {"a":1,"b":2}
    assert d._child_tokens == {"a":1,"b":2}


# Generated at 2022-06-18 12:45:40.359879
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test with ScalarToken
    token1 = ScalarToken(value=1, start_index=0, end_index=0)
    token2 = ScalarToken(value=1, start_index=0, end_index=0)
    assert token1 == token2
    token3 = ScalarToken(value=2, start_index=0, end_index=0)
    assert not (token1 == token3)
    token4 = ScalarToken(value=1, start_index=1, end_index=1)
    assert not (token1 == token4)
    token5 = ScalarToken(value=1, start_index=0, end_index=1)
    assert not (token1 == token5)

    # Test with DictToken

# Generated at 2022-06-18 12:45:44.567234
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a": 1}, 0, 1, "a")
    assert a._value == {"a": 1}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == "a"


# Generated at 2022-06-18 12:45:47.662962
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken(value = {}, start_index = 0, end_index = 0, content = "")
    assert d._value == {}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""
    assert d._child_keys == {}
    assert d._child_tokens == {}


# Generated at 2022-06-18 12:45:53.140392
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:45:59.944932
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != None


# Generated at 2022-06-18 12:46:03.373604
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1, "b": 2}, 0, 0, "")
    assert d._child_keys == {"a": 1, "b": 2}
    assert d._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:46:06.877980
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a": "b"}, 0, 1, "a")
    assert a._value == {"a": "b"}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == "a"


# Generated at 2022-06-18 12:46:14.036585
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == None

# Generated at 2022-06-18 12:46:30.492413
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1
    assert not Token(1, 2, 3) == None


# Generated at 2022-06-18 12:46:34.652035
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a":1}, 0, 1)
    assert d._value == {"a":1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""


# Generated at 2022-06-18 12:46:39.850692
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(1, 2, 3)
    t2 = Token(1, 2, 3)
    assert t1 == t2
    t3 = Token(2, 2, 3)
    assert t1 != t3
    t4 = Token(1, 3, 3)
    assert t1 != t4
    t5 = Token(1, 2, 4)
    assert t1 != t5


# Generated at 2022-06-18 12:46:47.007441
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0)
    assert token == token
    assert token == Token(value=None, start_index=0, end_index=0)
    assert token != Token(value=None, start_index=1, end_index=0)
    assert token != Token(value=None, start_index=0, end_index=1)
    assert token != Token(value=None, start_index=0, end_index=0, content="")
    assert token != Token(value=None, start_index=0, end_index=0, content="a")
    assert token != Token(value=None, start_index=0, end_index=0, content="b")

# Generated at 2022-06-18 12:46:53.380722
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 1, 2)
    token2 = Token(1, 1, 2)
    token3 = Token(2, 1, 2)
    token4 = Token(1, 2, 3)
    token5 = Token(1, 1, 3)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5


# Generated at 2022-06-18 12:47:03.520848
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert token == Token(1, 2, 3)
    assert token != Token(2, 2, 3)
    assert token != Token(1, 3, 3)
    assert token != Token(1, 2, 4)
    assert token != Token(1, 2, 3, "")
    assert token != Token(1, 2, 3, "abc")
    assert token != Token(1, 2, 3, "abcd")
    assert token != Token(1, 2, 3, "ab")
    assert token != Token(1, 2, 3, "a")
    assert token != Token(1, 2, 3, "b")
    assert token != Token(1, 2, 3, "c")
    assert token != Token(1, 2, 3, "d")
   

# Generated at 2022-06-18 12:47:09.115041
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(2, 2, 3)
    token4 = Token(1, 3, 3)
    token5 = Token(1, 2, 4)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5


# Generated at 2022-06-18 12:47:15.701668
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=0, end_index=0, content="")
    assert token == token
    assert not (token != token)
    assert token == Token(value=None, start_index=0, end_index=0, content="")
    assert not (token != Token(value=None, start_index=0, end_index=0, content=""))
    assert not (token == None)
    assert token != None
    assert not (token == 0)
    assert token != 0


# Generated at 2022-06-18 12:47:23.343707
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:47:26.721774
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a": 1}, 0, 1)
    assert a._value == {"a": 1}
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == ""


# Generated at 2022-06-18 12:47:53.222171
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a':1, 'b':2}
    dt = DictToken(d, 0, 0, content = "")
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ""
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:47:55.397532
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:48:01.037167
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(2, 2, 3)
    token4 = Token(1, 3, 3)
    token5 = Token(1, 2, 4)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5


# Generated at 2022-06-18 12:48:05.582550
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 3, '{"a": 1, "b": 2}')
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 3
    assert dt._content == '{"a": 1, "b": 2}'


# Generated at 2022-06-18 12:48:14.571925
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(value = 1, start_index = 1, end_index = 2, content = "")
    token2 = Token(value = 1, start_index = 1, end_index = 2, content = "")
    assert token1 == token2
    token3 = Token(value = 1, start_index = 1, end_index = 3, content = "")
    assert token1 != token3
    token4 = Token(value = 2, start_index = 1, end_index = 2, content = "")
    assert token1 != token4


# Generated at 2022-06-18 12:48:23.850976
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1, "b": 2}, 0, 10, "a=1,b=2")
    assert token.string == "a=1,b=2"
    assert token.value == {"a": 1, "b": 2}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 10, 9)
    assert token.lookup([0]).string == "a=1"
    assert token.lookup([1]).string == "b=2"
    assert token.lookup_key([0, 0]).string == "a"
    assert token.lookup_key([1, 0]).string == "b"


# Generated at 2022-06-18 12:48:30.825255
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1
    assert not Token(1, 2, 3) == None


# Generated at 2022-06-18 12:48:35.971298
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1


# Generated at 2022-06-18 12:48:43.029366
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a": 1, "b": 2}, 0, 0, "")
    assert a._value == {"a": 1, "b": 2}
    assert a._start_index == 0
    assert a._end_index == 0
    assert a._content == ""
    assert a._child_keys == {"a": 1, "b": 2}
    assert a._child_tokens == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:48:49.917032
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)
    assert Token(1, 2, 3) != Token(1, 2, 3, "abc")
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) != object()


# Generated at 2022-06-18 12:49:42.356157
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {}
    d[1] = 2
    d[3] = 4
    d[5] = 6
    d[7] = 8
    d[9] = 10
    d[11] = 12
    d[13] = 14
    d[15] = 16
    d[17] = 18
    d[19] = 20
    d[21] = 22
    d[23] = 24
    d[25] = 26
    d[27] = 28
    d[29] = 30
    d[31] = 32
    d[33] = 34
    d[35] = 36
    d[37] = 38
    d[39] = 40
    d[41] = 42
    d[43] = 44
    d[45] = 46
    d[47] = 48
    d

# Generated at 2022-06-18 12:49:49.636164
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(1, 2, 4)
    token4 = Token(2, 2, 3)
    token5 = Token(1, 3, 3)
    token6 = Token(1, 2, 2)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5
    assert token1 != token6


# Generated at 2022-06-18 12:49:56.880469
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1, "b": 2}, 0, 10, "a: 1, b: 2")
    assert token._value == {"a": 1, "b": 2}
    assert token._start_index == 0
    assert token._end_index == 10
    assert token._content == "a: 1, b: 2"
    assert token.string == "a: 1, b: 2"
    assert token.value == {"a": 1, "b": 2}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 11, 10)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert token.lookup([0]) == 1
    assert token.lookup_key([0]) == "a"


# Generated at 2022-06-18 12:50:04.964027
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == 1
    assert not Token(1, 2, 3) == None


# Generated at 2022-06-18 12:50:13.242716
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 1)
    assert d._value == {"a": 1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == ""
    assert d.string == ""
    assert d.value == {"a": 1}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 1)
    assert d.lookup([]) == d
    assert d.lookup_key([]) == d
    assert d._get_position(0) == Position(1, 1, 0)
    assert repr(d) == "DictToken('')"
    assert d == DictToken({"a": 1}, 0, 1)
    assert hash(d) == hash({"a": 1})


# Generated at 2022-06-18 12:50:20.923560
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3, "abc")
    token2 = Token(1, 2, 3, "abc")
    token3 = Token(2, 2, 3, "abc")
    token4 = Token(1, 1, 3, "abc")
    token5 = Token(1, 2, 4, "abc")
    token6 = Token(1, 2, 3, "abcd")
    assert token1 == token2
    assert not token1 == token3
    assert not token1 == token4
    assert not token1 == token5
    assert not token1 == token6


# Generated at 2022-06-18 12:50:24.676639
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({1:2, 3:4}, 0, 0, "")
    assert a._child_keys == {1:1, 3:3}
    assert a._child_tokens == {1:2, 3:4}


# Generated at 2022-06-18 12:50:31.093979
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 0)
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 0
    assert dt._content == ''
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:50:33.068698
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2


# Generated at 2022-06-18 12:50:34.602435
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1, "b": 2}, 0, 0, "")

# Generated at 2022-06-18 12:52:04.771079
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3)
    assert token == token
    assert token == Token(1, 2, 3)
    assert token != Token(2, 2, 3)
    assert token != Token(1, 3, 3)
    assert token != Token(1, 2, 4)
    assert token != Token(1, 2, 3, "abc")
    assert token != 1
    assert token != None
    assert token != "abc"
    assert token != [1, 2, 3]
    assert token != {"a": 1, "b": 2}


# Generated at 2022-06-18 12:52:08.653565
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    dt = DictToken(d, 0, 10)
    assert dt._value == d
    assert dt._start_index == 0
    assert dt._end_index == 10
    assert dt._content == ''
    assert dt._child_keys == {'a': 'a', 'b': 'b'}
    assert dt._child_tokens == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:52:09.942459
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1, "b": 2}, 0, 0, "")


# Generated at 2022-06-18 12:52:19.517816
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, 0, 0)
    assert token == token
    assert token != None
    assert token != "test"
    assert token != Token(None, 0, 0)
    assert token != Token(None, 1, 0)
    assert token != Token(None, 0, 1)
    assert token != Token(None, 0, 0, "test")
    assert token != Token(None, 0, 0, "test")
    assert token != Token(None, 1, 0, "test")
    assert token != Token(None, 0, 1, "test")
    assert token != Token(None, 0, 0, "test")
    assert token != Token(None, 1, 0, "test")
    assert token != Token(None, 0, 1, "test")
    assert token != Token(None, 0, 0, "test")


# Generated at 2022-06-18 12:52:30.602592
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({'a': 1, 'b': 2}, 0, 10)
    assert token._value == {'a': 1, 'b': 2}
    assert token._start_index == 0
    assert token._end_index == 10
    assert token._content == ''
    assert token.string == ''
    assert token.value == {'a': 1, 'b': 2}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 10)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert token._get_position(0) == Position(1, 1, 0)
    assert token.__repr__() == "DictToken('')"
    assert token.__eq__(token) == True


# Generated at 2022-06-18 12:52:38.803488
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(
        {
            ScalarToken(1, 0, 0): ScalarToken(2, 0, 0),
            ScalarToken(3, 0, 0): ScalarToken(4, 0, 0),
        },
        0,
        0,
    )
    assert token._child_keys == {1: ScalarToken(1, 0, 0), 3: ScalarToken(3, 0, 0)}
    assert token._child_tokens == {1: ScalarToken(2, 0, 0), 3: ScalarToken(4, 0, 0)}


# Generated at 2022-06-18 12:52:41.805677
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({"a": 1}, 0, 1, "a")
    assert d._value == {"a": 1}
    assert d._start_index == 0
    assert d._end_index == 1
    assert d._content == "a"


# Generated at 2022-06-18 12:52:53.643097
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1}, 0, 1)
    assert token._value == {"a": 1}
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == ""
    assert token.string == ""
    assert token.value == {"a": 1}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 1)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert token.__repr__() == "DictToken('')"
    assert token.__eq__(token) == True
    assert token.__hash__() == hash({"a": 1})


# Generated at 2022-06-18 12:52:56.223669
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(1, 2, 4)
    assert token1 != token3
    token4 = Token(2, 2, 3)
    assert token1 != token4
    token5 = Token(1, 3, 3)
    assert token1 != token5


# Generated at 2022-06-18 12:53:06.311314
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test 1
    token = DictToken({}, 0, 0, "")
    assert token._value == {}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""
    assert token.string == ""
    assert token.value == {}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert token._get_position(0) == Position(1, 1, 0)
    assert repr(token) == "DictToken({})"
    assert token == DictToken({}, 0, 0, "")
    assert hash(token) == hash({})
    # Test 2
    token = DictToken

# Generated at 2022-06-18 12:55:12.492765
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test if the method __eq__ of class Token works correctly
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(2, 2, 3)
    token4 = Token(1, 3, 3)
    token5 = Token(1, 2, 4)
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5
