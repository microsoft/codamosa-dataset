

# Generated at 2022-06-12 16:12:25.884794
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value = None,start_index = 0,end_index = 0)
    other = Token(value = None,start_index = 0,end_index = 0)
    assert token == other
    assert token == token
    assert not (token is None)


# Generated at 2022-06-12 16:12:30.698667
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1,2,3) == Token(1,2,3)
    assert Token(1,2,3) != Token(1,1,3)
    assert Token(1,2,3) != Token(2,2,3)
    assert Token(1,2,3) != Token(1,2,4)



# Generated at 2022-06-12 16:12:32.772883
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(value = {}, start_index = 0, end_index = 0, content = "")


# Generated at 2022-06-12 16:12:34.638118
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"test_key": "test_value"})

# Generated at 2022-06-12 16:12:42.671344
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_0 = Mock(spec=ScalarToken)
    token_1 = Mock(spec=ScalarToken)
    token_2 = Mock(spec=ScalarToken)
    token_3 = Mock(spec=ScalarToken)
    token_4 = Mock(spec=ScalarToken)
    token_5 = Mock(spec=ScalarToken)
    token_6 = Mock(spec=ScalarToken)
    token_7 = Mock(spec=ScalarToken)
    token_8 = Mock(spec=ScalarToken)
    token_9 = Mock(spec=ScalarToken)
    token_10 = Mock(spec=ScalarToken)
    token_0._get_value.return_value = 10
    token_1._get_value.return_value = 10
    token_2

# Generated at 2022-06-12 16:12:43.988879
# Unit test for constructor of class DictToken
def test_DictToken():
    x = DictToken({})
    assert x is not None
    assert isinstance(x,DictToken)


# Generated at 2022-06-12 16:12:46.423582
# Unit test for constructor of class DictToken
def test_DictToken():
    my_dict = {'hello': 'world'}
    my_token = DictToken(my_dict, 0, 0, 'hello world')


# Generated at 2022-06-12 16:12:46.917538
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    pass

# Generated at 2022-06-12 16:12:59.186707
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    value_token_1 = ScalarToken(value=1, start_index=1, end_index=1, content="content")
    value_token_2 = ScalarToken(value=1, start_index=1, end_index=1, content="content")
    assert value_token_1.__eq__(value_token_2)
    assert not value_token_1.__eq__(2)

    value_token_1 = DictToken(value='{"a": 1, "b": 1}', start_index=1, end_index=1, content="content")
    value_token_2 = DictToken(value='{"a": 1, "b": 1}', start_index=1, end_index=1, content="content")
    assert value_token_1.__eq__(value_token_2)

# Generated at 2022-06-12 16:13:04.950948
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test 1
    t1 = Token(1,1,2)
    t2 = Token(1,1,2)
    if t1 == t2: print("Success test 1.1")
    else: print("Fail test 1.1")

    t2._end_index = 3
    if t1 == t2: print("Fail test 1.2")
    else: print("Success test 1.2")

    t2._end_index = 2
    t2._value = 3
    if t1 == t2: print("Fail test 1.3")
    else: print("Success test 1.3")

    t2 = 2
    if t1 == t2: print("Fail test 1.4")
    else: print("Success test 1.4")

    # Test 2

# Generated at 2022-06-12 16:13:11.588160
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({}, 0, 0)
    assert DictToken()


# Generated at 2022-06-12 16:13:13.483491
# Unit test for constructor of class DictToken
def test_DictToken():
    test = {"test": "test"}
    token = DictToken(test, 0, 1)
    assert token._value == test

# Generated at 2022-06-12 16:13:21.232414
# Unit test for constructor of class DictToken
def test_DictToken():
    # Arrange
    start_index = 0
    end_index = 12
    content = "{'a': 1, 'b': 2}"
    dict_token_value = {'a': 1, 'b': 2}
    # Act
    dict_token = DictToken(dict_token_value, start_index, end_index, content)
    # Assert
    assert dict_token.start == Position(1, 1, 0)
    assert dict_token.end == Position(1, 13, 12)
    assert dict_token.string == "{'a': 1, 'b': 2}"


# Generated at 2022-06-12 16:13:23.074269
# Unit test for constructor of class DictToken
def test_DictToken():
  token = DictToken({"name":"DictToken","age":10},1,2)
  assert(token != None)


# Generated at 2022-06-12 16:13:26.854014
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken({'abc':''},1,2,3)
    DictToken({'abc':''},4,5,6)

# Generated at 2022-06-12 16:13:35.827747
# Unit test for constructor of class DictToken
def test_DictToken():
    start_index = 1
    end_index = 3
    child_start_index = 2
    child_end_index = 5
    child_key_indexes = [child_start_index, child_end_index]
    child_value_indexes = [child_start_index, child_end_index]
    child_key = "key_token"
    child_value = "value_token"
    d = DictToken({child_key: child_value}, start_index, end_index)
    
    # Test for _get_value(self)
    assert d._get_value() == {child_key: child_value}

    # Test for _get_child_token(self, key)
    assert d._get_child_token(child_key) == child_value

    # Test for _get_key_

# Generated at 2022-06-12 16:13:47.674817
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken(
        {
            ScalarToken(1, 0, 0): ListToken(
                [ScalarToken(2, 1, 1), ScalarToken(3, 3, 3)], 0, 4, "12\n3"
            ),
            ScalarToken(2, 5, 5): ScalarToken(3, 6, 6),
        },
        0,
        7,
        "1:12\n3\n2:3",
    )
    assert t._value == {ScalarToken(1, 0, 0): ListToken([ScalarToken(2, 1, 1), ScalarToken(3, 3, 3)], 0, 4, "12\n3"), ScalarToken(2, 5, 5): ScalarToken(3, 6, 6)}

# Generated at 2022-06-12 16:13:59.258084
# Unit test for constructor of class DictToken

# Generated at 2022-06-12 16:14:09.290285
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken(
        {"test": ScalarToken(12, 0, 0, content="test")},
        0,
        0,
        content={"test": 12},
    )
    assert t._get_value() == {"test": 12}
    assert t.start == Position(1, 1, 0)
    assert t.end == Position(1, 1, 0)
    assert t._value == {"test": ScalarToken(12, 0, 0, content="test")}
    assert t._child_tokens == {"test": ScalarToken(12, 0, 0, content="test")}
    assert t._child_keys == {"test": ScalarToken(12, 0, 0, content="test")}

# Generated at 2022-06-12 16:14:19.632743
# Unit test for constructor of class DictToken
def test_DictToken():
    T1 = DictToken(value = {Token(value = 1, start_index = 1, end_index = 2, content = ""): Token(value = 1, start_index = 1, end_index = 2, content = "")},
                    start_index = 1,
                    end_index = 2,
                    content = "")
    T2 = DictToken(value = {Token(value = "a", start_index = 1, end_index = 2, content = ""): Token(value = "b", start_index = 1, end_index = 2, content = "")},
                    start_index = 1,
                    end_index = 2,
                    content = "")
    assert T1._child_tokens == T2._child_tokens
    assert T1._child_keys == T2._child_keys
    assert T

# Generated at 2022-06-12 16:14:33.856069
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(
        {'a': 1, 'b': 2},
        0,
        10,
        content='{\\n  \\\'a\\\' : 1,\\n  \\\'b\\\' : 2\\n}',
    )
    assert token.string == '{\\n  \\\'a\\\' : 1,\\n  \\\'b\\\' : 2\\n}'
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(3, 11, 10)
    assert token.value == {'a': 1, 'b': 2}

# Generated at 2022-06-12 16:14:35.890709
# Unit test for constructor of class DictToken
def test_DictToken():
    assert(True == True)

test_DictToken()

# Generated at 2022-06-12 16:14:37.657045
# Unit test for constructor of class DictToken
def test_DictToken():
    assert '_value' in DictToken.__init__.__code__.co_varnames


# Generated at 2022-06-12 16:14:43.515895
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.lexer import _Token
    from typesystem.tokenizer import tokenize

    ds = tokenize(
        """
    {
        "name": "Alex",
        "age": 27,
        "address": {
            "city": "New York"
        }
    }
    """,
        "json",
    )
    ds = _Token.parse(ds)
    assert ds

# Generated at 2022-06-12 16:14:51.154807
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken({}, 4, 5)
    assert (dt.__dict__["_value"] == {})
    assert(dt.__dict__["_start_index"] == 4)
    assert(dt.__dict__["_end_index"] == 5)
    assert(dt.__dict__["_content"] == "")
    assert(dt.value == {})
    assert(dt.start == Position(1, 1, 4))
    assert(dt.end == Position(1, 1, 5))


# Generated at 2022-06-12 16:14:59.471990
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken({'a':1, 'b':2, 'c':3}, start_index=0, end_index=5, content="")
    assert t._child_keys['a']._value == 'a'
    assert t._child_keys['b']._value == 'b'
    assert t._child_keys['c']._value == 'c'
    assert t._child_tokens['a']._value == 1
    assert t._child_tokens['b']._value == 2
    assert t._child_tokens['c']._value == 3


# Generated at 2022-06-12 16:15:10.594301
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import String, Integer
    from . import TokenIndex

    schema = {"foo": String, "bar": Integer}
    token = DictToken(
        value={
            "foo": ScalarToken(value="foo", start_index=1, end_index=2, content="foo"),
            "bar": ScalarToken(value=42, start_index=1, end_index=2, content="42"),
        },
        start_index=1,
        end_index=2,
        content="foo\n42",
    )
    foo_index = TokenIndex(["foo"])
    bar_index = TokenIndex(["bar"])
    assert token.value == {"foo": "foo", "bar": 42}

# Generated at 2022-06-12 16:15:20.053958
# Unit test for constructor of class DictToken
def test_DictToken():
    content = "hello"
    start_index = 0
    end_index = 5
    input1={}
    input1['1'] = 1
    input1['2'] = 2
    input1['3'] = 3
    dict_token = DictToken(input1, start_index, end_index, content)
    assert dict_token
    assert dict_token._get_child_token('1') == '1'
    assert dict_token._get_child_token('2') == '2'
    assert dict_token._get_child_token('3') == '3'



# Generated at 2022-06-12 16:15:21.845277
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken(value=None, start_index=-1, end_index=-1)


# Generated at 2022-06-12 16:15:32.655388
# Unit test for constructor of class DictToken
def test_DictToken():
    class StartIndex:
        def __init__(self, val):
            self.val = val
    class EndIndex:
        def __init__(self, val):
            self.val = val
    class Value:
        def __init__(self, val):
            self.val = val
    x = {'a':1, 'b': 2, 'c': 3}
    y = DictToken(x, StartIndex(0), EndIndex(1), 'InputString')
    if y._child_keys['a'] == 1 and y._child_keys['b'] == 2 and y._child_keys['c'] == 3 and y.start == Position(0, 0, 0) and y.end == Position(1, 0, 1) and y.string == 'InputString':
        print('test_DictToken succeeded')

# Unit

# Generated at 2022-06-12 16:16:06.412919
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {"x": "y"}
    k = Token(1, 1, 2)
    v = Token(2, 3, 4)
    test_obj = DictToken(d, 0, 1, content="d")
    assert test_obj._value == d
    assert test_obj._start_index == 0
    assert test_obj._end_index == 1
    assert test_obj._child_keys == {1: k}
    assert test_obj._child_tokens == {1: v}



# Generated at 2022-06-12 16:16:07.993977
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({})
    assert(isinstance(d, DictToken))



# Generated at 2022-06-12 16:16:14.459817
# Unit test for constructor of class DictToken
def test_DictToken():
    import json
    input_string = json.dumps({'a': 'fe', 'b': 'wq'})
    print(input_string)
    print(type(input_string))
    # print(type(Token(typing.Any, 0, 10)))
    # print(type(ListToken(typing.Any, 0, 10)))
    print(type(DictToken(typing.Any, 0, 10)))



# Generated at 2022-06-12 16:16:25.836060
# Unit test for constructor of class DictToken
def test_DictToken():
    a = ScalarToken(1, 0, 1, 'a')
    b = ScalarToken(2, 0, 1, 'b')
    c = ScalarToken(3, 0, 1, 'c')
    d = ScalarToken(4, 0, 1, 'd')
    # test for proper values
    dict_token = DictToken({a: b, c: d}, 0, 1, 'a')
    assert dict_token._child_keys == {1: a, 3: c}
    assert dict_token._child_tokens == {1: b, 3: d}
    # test for proper types
    dict_token = DictToken({a: b, c: d}, 0, 1, 'a')
    assert isinstance(dict_token._child_keys, dict)

# Generated at 2022-06-12 16:16:35.125117
# Unit test for constructor of class DictToken
def test_DictToken():
    string = "x=1"
    content = string
    start_index = 0
    end_index = 0
    Pos_token = Position(0,0,0)
    Start_token = Position(0,0,0)
    End_token = Position(0,0,0)
    # print(DictToken("1=2", 0, 0, "x=1"))
    assert DictToken("1=2", 0, 0, "x=1") == DictToken("1=2", 0, 0, "x=1") # will return "True"
    assert DictToken("1=2", 0, 0, "x=1") == Token("1=2", 0, 0, "x=1") # will return "False"
    assert DictToken("1=2", 0, 0, "x=1") == 1

# Generated at 2022-06-12 16:16:39.089733
# Unit test for constructor of class DictToken
def test_DictToken():
    expected = {
        'a': 1,
        'b': 2,
        'c': 3,
    }
    actual = DictToken(expected, 0, 0, '').value
    assert expected == actual

# Generated at 2022-06-12 16:16:47.302579
# Unit test for constructor of class DictToken
def test_DictToken():
    Token.__init__()
    Token._get_value()
    Token._get_child_token()
    Token._get_key_token()
    Token.start
    Token.end
    Token.lookup()
    Token.lookup_key()
    Token._get_position()
    Token.__repr__()
    Token.__eq__()
    Token.__hash__()
    Token.__init__()
    Token._get_value()
    Token._get_child_token()
    Token._get_key_token()
    Token.start
    Token.end
    Token.lookup()
    Token.lookup_key()
    Token._get_position()
    Token.__repr__()
    Token.__eq__()
    Token._get_value()
    Token.start 

# Generated at 2022-06-12 16:16:49.815931
# Unit test for constructor of class DictToken
def test_DictToken():
    ret = {}
    assert isinstance(ret, dict)
# Function test_DictToken End


# Generated at 2022-06-12 16:16:51.724221
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken({"a": 1},1,2, "abc")


# Generated at 2022-06-12 16:17:03.158501
# Unit test for constructor of class DictToken
def test_DictToken():
    args = []
    kwargs = {}
    def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
        super().__init__(*args, **kwargs)
        self._child_keys = {k._value: k for k in self._value.keys()}
        self._child_tokens = {k._value: v for k, v in self._value.items()}

    def _get_value(self) -> typing.Any:
        return {
            key_token._get_value(): value_token._get_value()
            for key_token, value_token in self._value.items()
        }

    def _get_child_token(self, key: typing.Any) -> Token:
        return self._child_tokens[key]


# Generated at 2022-06-12 16:17:40.147496
# Unit test for constructor of class DictToken
def test_DictToken():
    d1 = DictToken({"a": 2, "b": 3}, 0, 1, "abc")


# Generated at 2022-06-12 16:17:44.715952
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({1: 3, 5: 7}, 1, 5, "hello")
    assert a.value == {1:3, 5:7}
    assert a.start.index == 1
    assert a.end.index == 5
    assert a.string == "hello"


# Generated at 2022-06-12 16:17:47.223051
# Unit test for constructor of class DictToken
def test_DictToken():
    dict = {'a':'b'}
    token = DictToken(dict, 0, 1)
    assert isinstance(token, DictToken)


# Generated at 2022-06-12 16:17:57.545494
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({'a':1, 'b':2}, 1, 2)
    assert d.string == 'a: 1\nb: 2'
    assert d.value == {'a': 1, 'b': 2}
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(2, 2, 4)
    assert d.lookup([0]) == 'a: 1'
    assert d.lookup_key([0]) == 'a'
    assert d.__repr__() == 'DictToken({\'a\': 1, \'b\': 2})'
    assert d.__eq__(DictToken({'a':1, 'b':2}, 1, 2)) == True


# Generated at 2022-06-12 16:17:59.975335
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"hello": "world"}, 0, 5).string == '{"hello": "world"}'


# Generated at 2022-06-12 16:18:11.414562
# Unit test for constructor of class DictToken
def test_DictToken():
    assert False # TODO: implement your test here
    # Make the following assertions on the constructor of class DictToken
    # self.assertIsInstance(DictToken(0,0,0,0,0,0),DictToken)
    # self.assertIsInstance(DictToken(0,0,0,0,0,1),DictToken)
    # self.assertIsInstance(DictToken(0,0,0,0,1,0),DictToken)
    # self.assertIsInstance(DictToken(0,0,0,0,1,1),DictToken)
    # self.assertIsInstance(DictToken(0,0,0,1,0,0),DictToken)
    # self.assertIsInstance(DictToken(0,0,0,1,0,1),DictToken

# Generated at 2022-06-12 16:18:17.476255
# Unit test for constructor of class DictToken
def test_DictToken():
    class NewToken(DictToken):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)

    a = NewToken({"A": "B"}, 1, 2)
    b = NewToken({"C": "D"}, 1, 2)
    # Test __eq__
    assert a == b
    # Test __hash__
    dict = {a: 1}
    dict[b] = 2
    assert dict[a] == 2

# Generated at 2022-06-12 16:18:29.098540
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem import Scalar
    from typesystem.base import Missing, Empty
    from typesystem.exceptions import ValidationError

    class Type(Scalar):
        primitive = typing.Any

    data = {"alias_of": "user", "name": None, "count": "1"}
    t = Type(data)
    t._validate(data)
    assert isinstance(t, DictToken)
    assert hasattr(t, "_child_keys")
    assert hasattr(t, "_child_tokens")
    assert isinstance(t._child_tokens["name"], ScalarToken)
    assert isinstance(t._child_tokens["count"], ScalarToken)
    assert isinstance(t._child_keys["name"], ScalarToken)

# Generated at 2022-06-12 16:18:37.041584
# Unit test for constructor of class DictToken
def test_DictToken():

    # Return true if the constructor is working properly
    def test0(start_index, end_index, content):
        token = DictToken(value = {}, start_index = start_index, end_index = end_index, content = content)
        return token._start_index == start_index and token._end_index == end_index and token._content == content

    # Return true if the constructor is working properly
    def test1(value, start_index, end_index, content):
        token = DictToken(value = value, start_index = start_index, end_index = end_index, content = content)
        return token._value == value and token._start_index == start_index and token._end_index == end_index and \
                token._content == content

    # Return true if the constructor is working properly

# Generated at 2022-06-12 16:18:44.359782
# Unit test for constructor of class DictToken
def test_DictToken():
    s = """
    {
        "key1": "value1",
        "key2": "value2"
    }
    """
    testDictToken = DictToken({"key1": "value1", "key2": "value2"}, 0, 33, s)
    assert testDictToken._child_keys == {"key1": "value1", "key2": "value2"}
    assert testDictToken._child_tokens == {"key1": "value1", "key2": "value2"}


# Generated at 2022-06-12 16:20:09.187889
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(list(), 0, 4, content = "abcdef")
    assert token != None


# Generated at 2022-06-12 16:20:16.540321
# Unit test for constructor of class DictToken
def test_DictToken():
    from pytypesystem.keywords import Keyword

    token = DictToken({Keyword("key1"): Keyword("key2")}, 1, 9, "key1: key2")
    assert token._value == {Keyword("key1"): Keyword("key2")}
    assert token._start_index == 1
    assert token._end_index == 9
    assert token._content == "key1: key2"

test_DictToken()

# Generated at 2022-06-12 16:20:19.933167
# Unit test for constructor of class DictToken
def test_DictToken():
  dict_token = DictToken({'1':2,'2':3}, 2, 3, 'test')
  assert(str(dict_token) == 'DictToken(\'test\')')


# Generated at 2022-06-12 16:20:24.070990
# Unit test for constructor of class DictToken
def test_DictToken():
    dict1 = {1:1, 2:2}
    dict_token = DictToken(dict1, 0, 1, "1:1, 2:2")
    assert dict_token._child_keys == {1:1, 2:2}
    assert dict_token._child_tokens == {1:1, 2:2}


# Generated at 2022-06-12 16:20:29.748914
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken(1, 2, 3, 4, 5)
    print(a)
    b = DictToken(1, 2, 3, 4, 5, start_index=1)
    print(b)
    c = DictToken(1, 2, 3, 4, 5, start_index=1, end_index=5)
    print(c)
    d = DictToken(1, 2, 3, 4, 5, start_index=1, end_index=5, content="abcd")
    print(d)
    assert a != b
    assert a != c
    assert a != d
    assert b != c
    assert b != d
    assert c != d
    return



# Generated at 2022-06-12 16:20:38.155547
# Unit test for constructor of class DictToken
def test_DictToken():
    a = {"key1": 1, "key2": 2}
    token = DictToken(a, 0, 0)
    assert token._content == ""
    assert token._value == a
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._child_keys == {'key1': 1, 'key2': 2}
    assert token._child_tokens == {'key1': 1, 'key2': 2}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token



# Generated at 2022-06-12 16:20:48.116881
# Unit test for constructor of class DictToken
def test_DictToken():
    d = "{'a': 'b', 'c': 'd'}"
    assert len(d) == len(d)  # test length
    assert len(d) == len(d)  # test length
    assert len(d) == len(d)  # test length
    assert len(d) == len(d)  # test length
    assert len(d) == len(d)  # test length
    assert len(d) == len(d)  # test length
    assert len(d) == len(d)  # test length
    assert len(d) == len(d)  # test length
    assert len(d) == len(d)  # test length
    assert len(d) == len(d)  # test length
    assert len(d) == len(d)  # test length

# Generated at 2022-06-12 16:20:59.500616
# Unit test for constructor of class DictToken
def test_DictToken():
    # first Token
    value = {'a': 1, 'b': 2, 'c': 3}
    start_index = 0
    end_index = 3
    content = ''
    # set up the test
    token1 = DictToken(value, start_index, end_index, content)
    # check the test result
    assert value == token1._value
    assert start_index == token1._start_index
    assert end_index == token1._end_index
    assert content == token1._content

    # second Token
    value = {'d': 4, 'e': 5, 'f': 6}
    start_index = 4
    end_index = 7
    content = ''
    # set up the test
    token2 = DictToken(value, start_index, end_index, content)
    # check the

# Generated at 2022-06-12 16:21:00.583581
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken()
    assert a is not None

# Generated at 2022-06-12 16:21:01.799625
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken(None, None, None)