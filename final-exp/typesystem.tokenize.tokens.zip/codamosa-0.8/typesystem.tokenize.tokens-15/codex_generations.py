

# Generated at 2022-06-12 16:12:20.422221
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t = ScalarToken(value=1, start_index=0, end_index=2)
    assert t == ScalarToken(value=1, start_index=0, end_index=2)
    assert t != ScalarToken(value=2, start_index=0, end_index=2)
    assert t != ScalarToken(value=1, start_index=1, end_index=2)
    assert t != ScalarToken(value=1, start_index=0, end_index=3)



# Generated at 2022-06-12 16:12:31.862882
# Unit test for constructor of class DictToken
def test_DictToken():
    class Token:
        def __init__(
            self, value: typing.Any, start_index: int, end_index: int, content: str = ""
        ) -> None:
            self._value = value
            self._start_index = start_index
            self._end_index = end_index
            self._content = content

    # Create input object
    @dataclass(frozen=True)
    class _Token:
        value: typing.Any
        start_index: int
        end_index: int
        content: str = ""

    # Create input object
    @dataclass(frozen=True)
    class _DictToken:
        key: str
        value: Token


# Generated at 2022-06-12 16:12:35.644216
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(None, None, None)
    token2 = Token(None, None, None)
    assert token1 == token2
    assert token1.__eq__(token2) == True


# Generated at 2022-06-12 16:12:46.662878
# Unit test for constructor of class DictToken
def test_DictToken():
    x = DictToken({"a":1,"b":2}, 0, 0, "ab")
    assert(x.value == {"a": 1, "b": 2})
    assert(x.start == Position(1, 1, 0))
    assert(x.end == Position(1, 2, 0))
    assert(x.string == "ab")
    assert(x.lookup(["a"]).value == 1)
    assert(x.lookup_key(["a", "b"]).value == 1)
    assert(x.__repr__() == "DictToken('ab')")
    assert(x.__eq__(DictToken({"a":1,"b":2}, 0, 0, "ab")))
    assert(x.__hash__() == hash({"a": 1, "b": 2}))

# Generated at 2022-06-12 16:12:51.185557
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    foo=Token(value=1, start_index=2, end_index=3)
    bar=Token(value=2, start_index=4, end_index=5)
    baz=Token(value=1, start_index=2, end_index=3)
    assert foo!=bar
    assert foo==baz


# Generated at 2022-06-12 16:12:53.839592
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken(value={}, start_index=0, end_index=3, content="")


# Generated at 2022-06-12 16:13:05.334915
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    def _eq(a, b):
        return a == b
    import pytest
    with pytest.raises(NotImplementedError):
        Token(1, 0, 1)._get_value()
    with pytest.raises(NotImplementedError):
        Token(1, 0, 1)._get_child_token(1)
    with pytest.raises(NotImplementedError):
        Token(1, 0, 1)._get_key_token(1)
    with pytest.raises(NotImplementedError):
        ScalarToken(1, 1, 1)._get_value()
    with pytest.raises(NotImplementedError):
        DictToken({}, 1, 1, '')._get_value()

# Generated at 2022-06-12 16:13:16.230025
# Unit test for constructor of class DictToken
def test_DictToken():
    class Stuffs():
        def _get_value(self):
            return 'value'
    class Keys():
        def _get_value(self):
            return 'keys'
    class Values():
        def _get_value(self):
            return 'value'
    key = Keys()
    value = Values()
    token = DictToken(Stuffs(), 0, 0, '')
    assert(token._value.keys() == [])
    assert(token._value.items() ==[])
    token._child_keys = {key._value: key}
    token._child_tokens = {key._value: value}
    token1 = DictToken(Stuffs(), 0, 0, '')
    assert(token1._value.keys() == [key._value])

# Generated at 2022-06-12 16:13:19.794151
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken(1, 2, 3, content="first_value")
    assert dt.value == 1
    assert dt.start_index == 2
    assert dt.end_index == 3
    assert dt.content == "first_value"


# Generated at 2022-06-12 16:13:21.021379
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken == DictToken(True, 1, 2, "3")

# Generated at 2022-06-12 16:13:31.103704
# Unit test for constructor of class DictToken
def test_DictToken():
    string = "my_string"
    start_index = 0
    end_index = 15
    content = "my_string my_content"
    token = DictToken(string, start_index, end_index, content)
    assert token.string == "my_string"
    assert token.value == "my_string"
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 10, 9)


# Generated at 2022-06-12 16:13:39.342153
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken([],1,2,"")
    token = DictToken(object,1,2,"")
    token = DictToken(dict,1,2,"")
    token = DictToken(set,1,2,"")
    token = DictToken(None,1,2,"")
    token = DictToken(ScalarToken,1,2,"")
    token = DictToken(DictToken,1,2,"")
    token = DictToken(ListToken,1,2,"")

if __name__ == "__main__":
    test_DictToken()

# Generated at 2022-06-12 16:13:46.366784
# Unit test for constructor of class DictToken
def test_DictToken():
    start_index = 0
    end_index = 5
    content = "a: 5"
    scalar_token = ScalarToken(5, start_index, end_index, content)
    key_token = ScalarToken('a', start_index, end_index, content)
    d = {key_token: scalar_token}
    test_d = DictToken(d, start_index, end_index, content)
    assert test_d is not None


# Generated at 2022-06-12 16:13:58.173798
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # __eq__ where self and argument have same value for _value
    c1 = ScalarToken(0, 0, 0)
    c2 = ScalarToken(0, 0, 0)
    assert c1 == c2
    # __eq__ where self and argument have different value for _value
    c3 = ScalarToken(1, 0, 0)
    assert not c1 == c3
    # __eq__ where self and argument have same value for _start_index
    c4 = ScalarToken(0, 0, 1)
    assert not c1 == c4
    # __eq__ where self and argument have same value for _end_index
    c5 = ScalarToken(0, 1, 0)
    assert not c1 == c5
    # __eq__ where self and argument are of different class
    c6 = object()


# Generated at 2022-06-12 16:14:03.405165
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken({"key":"value"}, 0, 1)
    assert dt.__dict__['_value'] == {"key":"value"}
    assert dt.__dict__['_start_index'] == 0
    assert dt.__dict__['_end_index'] == 1
    assert dt.__dict__['_content'] == ""


# Generated at 2022-06-12 16:14:12.088895
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2}
    t = DictToken(d, 0, 1, '{a: 1, b: 2}')
    assert isinstance(t, DictToken)
    assert t._value == d
    assert t._start_index == 0
    assert t._end_index == 1
    assert t._content == '{a: 1, b: 2}'
    assert t._child_keys == t._value.keys()
    assert t._child_tokens == t._value.items()
    assert t.string == '{a: 1, b: 2}'
    assert t.start == Position(1, 1, 0)
    assert t.end == Position(1, 1, 1)

# Generated at 2022-06-12 16:14:13.811311
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 0, 0) == Token(1, 0, 0)

# Generated at 2022-06-12 16:14:24.756738
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    scalar_token_01 = ScalarToken('test_01',1,5)
    scalar_token_02 = ScalarToken('test_02',1,5)
    scalar_token_03 = ScalarToken('test_01',1,5)
    list_token_01 = ListToken(['test_01','test_02'],1,5)
    list_token_02 = ListToken(['test_01','test_02'],1,5)
    list_token_03 = ListToken(['test_01','test_03'],1,5)
    dict_token_01 = DictToken({'key_01':'test_01'},1,5)
    dict_token_02 = DictToken({'key_01':'test_01'},1,5)

# Generated at 2022-06-12 16:14:26.576862
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": {"b": {"c": 1}}}, 0, 2, "")

# Generated at 2022-06-12 16:14:28.376875
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({1:2, 3:4})
    assert a


# Generated at 2022-06-12 16:14:41.225444
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(
    "value",
    "start_index",
    "end_index",
    "content",
    ) == Token(
    "value",
    "start_index",
    "end_index",
    "content",
    )
    assert not Token(
    "value",
    "start_index",
    "end_index",
    "content",
    ) == object()

# Generated at 2022-06-12 16:14:48.421436
# Unit test for constructor of class DictToken
def test_DictToken():
    # constructor
    key = 0
    value = 1
    start_index = 2
    end_index = 3
    content = 4
    dt = DictToken(key, value, start_index, end_index, content)
    assert dt._value == key
    assert dt._start_index == start_index
    assert dt._end_index == end_index
    assert dt._content == content
    assert dt.string == content[start_index : end_index + 1]
    assert dt.value == {}
    assert dt.start == Position(1, 1, 2)
    assert dt.end == Position(1, 1, 3)
    assert dt.lookup([]) == dt
    assert dt.lookup_key([]) == dt


# Generated at 2022-06-12 16:14:49.049806
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    pass

# Generated at 2022-06-12 16:14:53.421248
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Set up variables
    t = Token(1, 2, 3)
    token = t
    other = 1

    # Exercise SUT
    result = token.__eq__(other)

    # Verify results
    assert type(result) is bool

# Generated at 2022-06-12 16:15:04.453431
# Unit test for constructor of class DictToken
def test_DictToken():
    from array import array
    from typesystem.types import Dict
    from Token import Token
    # key = Token('this is a test', 0, 4)
    # value = Token('this is a test', 0, 4)
    # temp = DictToken(Dict({key : value}), 0, 0, 'content')
    # assert temp._child_keys == {key._value : key}
    # assert temp._child_tokens == {key._value : value}

    key = Token('this is a test', 0, 300)
    value = Token('this is a test', 0, 300)
    temp = DictToken(Dict({key : value}), 0, 0, 'content')
    assert temp._child_keys == {key._value : key}

# Generated at 2022-06-12 16:15:09.047070
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(dict(), 0, 0)
    assert repr(token) == "DictToken({})"
    assert token.value == dict()
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)


# Generated at 2022-06-12 16:15:11.517963
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken(
        {
            "a": 1,
            "b": 2,
        }
    )
    print(dict_token)


test_DictToken()

# Generated at 2022-06-12 16:15:21.187425
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(object(), 0, 0)
    t2 = Token(object(), 0, 0)
    assert not t1 == t2
    assert not t2 == t1
    t3 = Token(object(), 1, 1)
    assert not t1 == t3
    assert not t3 == t1
    t4 = Token(object(), 0, 1)
    assert not t1 == t4
    assert not t4 == t1
    t5 = Token(object(), 0, 0, "content")
    assert t1 == t5
    assert t5 == t1

# Generated at 2022-06-12 16:15:29.878217
# Unit test for constructor of class DictToken
def test_DictToken():
    print("testing DictToken")
    assert DictToken.__init__.__doc__ == "A class that initialize a new dictionary token.\n      \n      Args:\n          *args (:obj:`tuple` of :obj:`list`):  a tuple of arbitrary length.\n          **kwargs (:obj:`list`):  a list of arbitary length.\n      """
    # TODO: make example of valid input to test against
    # assert DictToken("foo") == None  # TODO: update this test
    print("passed tests for DictToken")


# Generated at 2022-06-12 16:15:37.951995
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'key_1': 'value_1', 'key_2': 'value_2'}
    token = DictToken(d, 0, 1, content="")
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == ""

    assert token._get_value() == d
    assert token._get_child_token('key_1') == token._value['key_1']
    assert token._get_key_token('key_1') == token._child_keys['key_1']



# Generated at 2022-06-12 16:15:58.257207
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """
    Test Token.__eq__()
    """
    # Setup
    token1 = ScalarToken(value=1, start_index=0, end_index=5, content="hello")
    token2 = ScalarToken(value=2, start_index=1, end_index=5, content="hello")
    token3 = ScalarToken(value=1, start_index=0, end_index=5, content="hello")

    # Exercise
    result1 = token1 == token2
    result2 = token1 == token3

    # Verify
    assert result1 == False
    assert result2 == True

# Generated at 2022-06-12 16:16:09.679853
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_1 = ScalarToken(True, 0, 4)
    token_2 = ScalarToken(True, 0, 4)
    token_3 = ScalarToken(False, 0, 5)
    token_4 = ScalarToken(True, 1, 4)
    token_5 = ScalarToken(True, 0, 5)
    token_6 = ScalarToken(3, 0, 2)
    token_7 = ScalarToken(3.0, 0, 3)
    token_8 = ScalarToken(3.0, 1, 3)
    token_9 = ScalarToken(3, 0, 3)

    assert token_1 == token_2
    assert token_1 != token_3
    assert token_1 != token_4
    assert token_1 != token_5
    assert token_6 == token_7
   

# Generated at 2022-06-12 16:16:21.598897
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    x = Token("value", 0, 1, "content")
    x1 = Token("value", 0, 1, "content")
    x2 = Token("value", 0, 2, "content")
    x3 = Token("value1", 0, 1, "content")
    x4 = Token("value", 1, 1, "content")
    x5 = Token("value", 0, 1, "content1")
    assert x1 == x, 'x1 == x'
    assert not x2 == x, 'not x2 == x'
    assert not x3 == x, 'not x3 == x'
    assert not x4 == x, 'not x4 == x'
    assert not x5 == x, 'not x5 == x'
    assert not x == None, 'not x == None'


# Generated at 2022-06-12 16:16:25.657677
# Unit test for constructor of class DictToken
def test_DictToken():
  d = {"A":"a", "B":"b"}
  d = DictToken(d, 0, 1, "abc")
  d._child_tokens
  d._child_keys
  d.start
  d.end
  test_DictToken()
  

# Generated at 2022-06-12 16:16:34.988642
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    print("test_Token___eq__()")

    json1 = {"FOO": True, "BAR": 42, "BAZ": ["spam", "eggs"], "QUX": {"corge": "grault", "garply": "waldo"}}
    json2 = {"FOO": True, "BAR": 41, "BAZ": ["spam", "eggs"], "QUX": {"corge": "grault", "garply": "waldo"}}

    context = {}
    system = parse_schema(context, json1)
    t1 = system.load(json1)
    t2 = system.load(json2)

    assert t1 == t1
    assert not t1 == 42
    assert not t1 == t2

    print("test_Token___eq__() passed.")


# Generated at 2022-06-12 16:16:36.925851
# Unit test for constructor of class DictToken
def test_DictToken():
    # fill the code here
    pass


# Generated at 2022-06-12 16:16:46.064128
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == Token(2, 2, 3)
    assert not Token(1, 2, 3) == Token(1, 3, 3)
    assert not Token(1, 2, 3) == Token(1, 2, 4)


if __name__ == "__main__":
    import json
    import sys

    print(json.dumps(ScalarToken(12, 0, 1).value))
    print(json.dumps(ListToken([ScalarToken(12, 0, 1)], 0, 1).value))
    print(json.dumps(DictToken({ScalarToken(12, 0, 1): ScalarToken(12, 0, 1)}, 0, 1).value))


# Generated at 2022-06-12 16:16:49.216716
# Unit test for constructor of class DictToken
def test_DictToken():
    Token1 = DictToken({},0,0)
    assert isinstance(Token1, DictToken) == True


# Generated at 2022-06-12 16:16:50.350349
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken


# Generated at 2022-06-12 16:16:52.718304
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(content="test", start_index=0, end_index=0)
    assert token.string == "test"


# Generated at 2022-06-12 16:17:49.975893
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken(value = "red", start_index = 1, end_index = 2, content = "red")
    assert isinstance(d, DictToken)
    assert d.value == "red"
    assert d._get_value() == "red"
    assert d.start_index == 1
    assert d.end_index == 2
    assert d.content == "red"
    assert d.string == "red"


# Generated at 2022-06-12 16:17:58.753385
# Unit test for constructor of class DictToken
def test_DictToken():
    value = {
        'a': 1,
        'b': 2,
        'c': 3
    }
    start_index = 0
    end_index = 13
    content = "This is a test"
    token = DictToken(
        value, start_index, end_index, content
    )
    assert token._child_keys == {
        'a': 'a',
        'b': 'b',
        'c': 'c'
    }
    assert token._child_tokens == {
        'a': 1,
        'b': 2,
        'c': 3
    }


# Generated at 2022-06-12 16:18:01.274790
# Unit test for constructor of class DictToken
def test_DictToken():
    token = Token(
        value={}, start_index=0, end_index=1, content="{}"
    )
    # Test that the value is equal to itself
    assert token.valu

# Generated at 2022-06-12 16:18:05.768766
# Unit test for constructor of class DictToken
def test_DictToken():
    asser_token = DictToken({"foo": ScalarToken(1, 0, 0)})
    assert DictToken({"foo": ScalarToken(1, 0, 0)}) == asser_token


# Generated at 2022-06-12 16:18:07.963800
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1}, 1, 2, "")

# Generated at 2022-06-12 16:18:17.172148
# Unit test for constructor of class DictToken
def test_DictToken():
    start_index = 0
    end_index = 10
    content = "abcdefghij"
    value = {
        ScalarToken(1, 0, 0, content): ScalarToken(2, 0, 0, content),
        ScalarToken(3, 0, 0, content): ScalarToken(4, 0, 0, content),
    }
    token = DictToken(value, start_index, end_index, content)
    assert token._child_keys == {1: ScalarToken(1, 0, 0, content), 3: ScalarToken(3, 0, 0, content)}
    assert token._child_tokens == {1: ScalarToken(2, 0, 0, content), 3: ScalarToken(4, 0, 0, content)}


# Generated at 2022-06-12 16:18:23.067930
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken({"a": 3, "b": 5}, 4, 7, "abcdefghijklmnop")
    assert t.value == {"a": 3, "b": 5}
    assert t.start == Position(1, 1, 0)
    assert t.end == Position(1, 20, 19)


# Generated at 2022-06-12 16:18:26.052362
# Unit test for constructor of class DictToken
def test_DictToken():
    a = {'a': 1}
    b = {'b': 2}
    result = DictToken(a)
    assert isinstance(result, DictToken) is True


# Generated at 2022-06-12 16:18:31.657617
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {"a": "A"}
    dt = DictToken(d)
    assert dt._value == d
    assert dt._child_keys["a"] == dt._value.keys()
    assert dt._child_tokens["a"] == dt._value.items()

# A unit test for constructor of class ListToken

# Generated at 2022-06-12 16:18:36.804785
# Unit test for constructor of class DictToken
def test_DictToken():
    dic = {"a":1, "b":2}
    dic_token = DictToken(dic, 1, 2)
    assert dic_token.value == {"a":1, "b":2}
    assert dic_token._value == {"a":1, "b":2}


# Generated at 2022-06-12 16:19:37.526772
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken({}, 0, 0)
    assert isinstance(t, DictToken) == True
    assert t._start_index == 0
    assert t._end_index == 0
    assert t.string == ''
    assert t._child_tokens == {}
    assert t._child_keys == {}


# Generated at 2022-06-12 16:19:41.101371
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken(1,0,1,{"a":2,"b":3})
    assert d._child_keys == {"a":2,"b":3}
    assert d._child_tokens == {"a":2,"b":3}
    assert d._start_index == 0
    assert d._end_index == 1


# Generated at 2022-06-12 16:19:47.826933
# Unit test for constructor of class DictToken
def test_DictToken():
    start_index = 0
    end_index = 100
    test_content = "This is a test string"
    test_token_instance = DictToken({}, start_index, end_index, test_content)
    assert isinstance(test_token_instance, DictToken)
    assert isinstance(test_token_instance, Token)


# Generated at 2022-06-12 16:19:49.104661
# Unit test for constructor of class DictToken
def test_DictToken():
    def _test():
        assert 1 == 1
    # call the function
    _test()

# Generated at 2022-06-12 16:19:52.130813
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken(value = {'a': 1, 'b': 2}, start_index = 1, end_index = 5, content = 'abcdefg')


# Generated at 2022-06-12 16:19:57.153338
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken(
        {"1": "2", "2": "2"},
        start_index=0,
        end_index=5,
        content="abc123",
    )
    assert t._get_value() == {"1": "2", "2": "2"}


# Generated at 2022-06-12 16:20:01.460832
# Unit test for constructor of class DictToken
def test_DictToken():
    def constructor():
        DictToken(1,2,3,4,5)
    exception_message = None
    try:
        constructor()
    except Exception as e:
        exception_message = str(e)
    assert exception_message == 'Unsupported operand types for -: \'tuple\' and \'tuple\''


# Generated at 2022-06-12 16:20:02.001633
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken

# Generated at 2022-06-12 16:20:02.813869
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken()


# Generated at 2022-06-12 16:20:03.917243
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken({1: 1}, 0, 1, "")



# Generated at 2022-06-12 16:22:03.956614
# Unit test for constructor of class DictToken
def test_DictToken():
    content = "test"
    global token1
    token1 = ScalarToken(1, 1, 1, content = content)
    token2 = ScalarToken(2, 2, 2, content = content)
    token3 = ScalarToken(3, 3, 3, content = content)
    token4 = ScalarToken(4, 4, 4, content = content)
    global diketoken
    diketoken = DictToken({token1: token2, token3: token4}, 0, 4, content = content)


# Generated at 2022-06-12 16:22:07.549559
# Unit test for constructor of class DictToken
def test_DictToken():
    # Instance of class Token
    exampleToken = Token(value=3,start_index=1,end_index=1,content="")
    # Instance of class DictToken
    exampleDictToken = DictToken(value={exampleToken: exampleToken},start_index=0,end_index=0,content="")
    # Testing if 20 is the correct value for the instance of DictToken
    assert exampleDictToken._get_value()==3

# Generated at 2022-06-12 16:22:11.930806
# Unit test for constructor of class DictToken
def test_DictToken():
    obj = DictToken({"a": 1, "b": 2}, "ab", 3, content="ab")
    assert obj._child_keys == {"a": "a", "b": "b"}
    assert obj._child_tokens == {"a": 1, "b": 2}
