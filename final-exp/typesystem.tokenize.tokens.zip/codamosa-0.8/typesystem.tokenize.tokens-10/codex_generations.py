

# Generated at 2022-06-12 16:12:19.572733
# Unit test for constructor of class DictToken
def test_DictToken():
    value = {ScalarToken(1, 1, 1, "a"): ScalarToken(2, 2, 2, "b")}
    token = DictToken(value, 1, 1, "a")
    assert token._child_keys == {1: ScalarToken(1, 1, 1, "a")}
    assert token._child_tokens == {1: ScalarToken(2, 2, 2, "b")}

# Generated at 2022-06-12 16:12:31.749756
# Unit test for constructor of class DictToken
def test_DictToken():
    b_token = ScalarToken(None, 2, 3)
    b_token._value = 2

    d_token = ScalarToken(None, 4, 5)
    d_token._value = 4

    ft_token = ScalarToken(None, 7, 8)
    ft_token._value = 7

    t_token = ScalarToken(None, 9, 10)
    t_token._value = 9

    a_token = ListToken({b_token: [d_token], c_token: [ft_token], e_token: [t_token]}, 5, 6)

    assert a_token._value == {b_token: [d_token], c_token: [ft_token], e_token: [t_token]}

# Generated at 2022-06-12 16:12:38.035748
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    type_params = [
        (True, True, True),
    ]
    arg_params = [
        (
            ScalarToken(None, None, None),
            None,
            None,
        ),
    ]
    for type_param, arg_param, ret_param in zip(type_params, arg_params, ret_params):
        obj = Token(*type_param)
        assert obj.__eq__(*arg_param) == ret_param

# Generated at 2022-06-12 16:12:44.726613
# Unit test for constructor of class DictToken
def test_DictToken():
    keys = [ScalarToken(1, 0, 1), ScalarToken(2, 2, 3)]
    values = [ScalarToken(3, 4, 5), ScalarToken(4, 6, 7)]
    s = DictToken({k: v for k, v in zip(keys, values)}, 0, 7)
    assert s.value == dict(zip([1, 2], [3, 4]))
    assert s.start == Position(1, 1, 0)
    assert s.end == Position(1, 8, 7)


# Generated at 2022-06-12 16:12:50.729269
# Unit test for constructor of class DictToken
def test_DictToken():
    # no error should be raised
    token = DictToken(value = {}, start_index = 0, end_index = 1)
    # error should be raised as no key exist with value 10
    with pytest.raises(KeyError):
        token._get_child_token(10)
    # error should be raised as no key exist with value 10
    with pytest.raises(KeyError):
        token._get_key_token(10)


# Generated at 2022-06-12 16:12:55.335400
# Unit test for constructor of class DictToken
def test_DictToken():
    # Create valid values for the __init__ parameters
    value = {1:"a", 2:"b", 3:"c"}
    start_index = 4
    end_index = 9
    content = "felipe"
    # Create instance of DictToken with the created values
    instance = DictToken(value, start_index, end_index, content)
    assert(instance._value == value)
    assert(instance._start_index == start_index)
    assert(instance._end_index == end_index)
    assert(instance._content == content)


# Generated at 2022-06-12 16:13:00.052115
# Unit test for constructor of class DictToken
def test_DictToken():
    token1 = Token({"a": "b"}, 0, 1, "")
    token2 = DictToken({"a": "b"}, 0, 1, "")
    assert token1 == token2
    assert hash(token1) == hash(token2)



# Generated at 2022-06-12 16:13:08.752433
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token("v", 0, 10, content="content")
    t2 = Token("v", 0, 10, content="content")
    assert t1 == t2
    assert t1 == t2
    assert t1 == t2
    assert t1 == t2
    t1 = Token("v", 0, 10, content="content")
    t2 = Token("v", 0, 10, content="c")
    assert t1 == t2
    assert t1 == t2
    assert t1 == t2
    assert t1 == t2
    t1 = Token("v", 0, 10, content="content")
    t2 = Token("v", 0, 10, content="c")
    assert t1 == t2
    assert t1 == t2
    assert t1 == t2
    assert t1 == t2
   

# Generated at 2022-06-12 16:13:11.429938
# Unit test for constructor of class DictToken
def test_DictToken():
    pos = Position(1,1,1)
    dicttest = DictToken({ScalarToken(4, pos, pos): ScalarToken(5, pos, pos)}, pos, pos)
    assert dicttest is not None


# Generated at 2022-06-12 16:13:14.123845
# Unit test for constructor of class DictToken
def test_DictToken():
    x = DictToken(value={}, start_index=0, end_index=0)
    assert x.value == {}
    assert x.start == Position(1,1,0)
    assert x.end == Position(1,1,0)
    assert x.string == ""


# Generated at 2022-06-12 16:13:32.161335
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({'a':1}, 1, 2, content='{"a":1}')
    assert a.lookup([]) == a
    assert a.lookup_key([]) == a
    assert a.lookup([0]) == 1


# Generated at 2022-06-12 16:13:36.693781
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token([1], [1], [2], [3])
    t2 = Token([2], [2], [3], [4])
    t3 = Token([1], [1], [2], [3])
    t4 = Token([1], [1], [2], [4])
    assert t1 == t3
    assert t1 != t2
    assert t1 != t4


# Generated at 2022-06-12 16:13:47.932353
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class Instance:
        def __init__(self, value, start_index, end_index, content):
            self._value = value
            self._start_index = start_index
            self._end_index = end_index
            self._content = content

    class Instance2:
        def __init__(self, value, start_index, end_index, content):
            self._value = value
            self._start_index = start_index
            self._end_index = end_index
            self._content = content

    token = Instance(1, 2, 3, '_content')
    another_token = Instance(1, 2, 3, '_content')
    assert token == another_token

    class Instance3(Instance):
        pass


# Generated at 2022-06-12 16:13:53.006805
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({1:2,3:4},0,6)
    assert(token._child_keys == {1:1,3:3})
    assert(token._child_tokens == {1:2,3:4})


# Generated at 2022-06-12 16:13:59.923903
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Simple Tests
    assert Token("some value", 1, 2, "some content") == Token("some value", 1, 2, "some content")
    assert Token("value1", 1, 2, "some content") != Token("value2", 1, 2, "some content")
    assert Token("some value", 2, 2, "some content") != Token("some value", 1, 2, "some content")
    assert Token("some value", 1, 3, "some content") != Token("some value", 1, 2, "some content")
test_Token___eq__()

# Generated at 2022-06-12 16:14:02.285920
# Unit test for constructor of class DictToken
def test_DictToken():
    print("DictToken start!!!")
    # example test
    print("Example:")
    assert DictToken({"a": "b"})



# Generated at 2022-06-12 16:14:11.860658
# Unit test for constructor of class DictToken
def test_DictToken():
    class mydict(dict):
        def __init__(self):
            super().__init__()
        def __eq__(self, other):
            return isinstance(other, mydict) and (
                self.__key() == other.__key()
                and self.__value() == other.__value()
            )
        def __key(self):
            return [k.__key() for k in self.keys()]
        def __value(self):
            return [v.__value() for k,v in self.items()]
        def __repr__(self):
            return "%s(%s)" % (self.__class__.__name__, repr(self.__key()))

    a = mydict()
    a[0] = 0
    a[1] = 1

# Generated at 2022-06-12 16:14:22.424156
# Unit test for constructor of class DictToken

# Generated at 2022-06-12 16:14:28.470946
# Unit test for constructor of class DictToken
def test_DictToken():
    # Arrange
    start_index = 3
    end_index = 5
    content = "this is the content"
    # Act
    test_DictToken = DictToken(start_index, end_index, content)
    # Assert
    assert test_DictToken._start_index == 3
    assert test_DictToken._end_index == 5
    assert test_DictToken._content == "this is the content"


# Generated at 2022-06-12 16:14:35.009853
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.primitives import String
    from typesystem.structures import Dict
    
    dict_schema = Dict(
        properties={
            "name": String(),
            "bio": String(),
        }
    )
    data = {
        "name": "Koszulka", 
        "bio": "Koszulka is a student of UW.",
    }
    dict1 = dict_schema.validate(data)
    dict2 = dict_schema.validate(data)
    
    # Test the class of dict1 and dict2
    assert isinstance(dict1, DictToken)
    assert isinstance(dict2, DictToken)
    # Test the value of dict1 and dict2
    assert dict1._get_value() == dict2._get_value()
    #

# Generated at 2022-06-12 16:14:49.753959
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = ScalarToken('5', 2, 3)
    t2 = ScalarToken('5', 2, 3)
    assert t1 == t2

# Generated at 2022-06-12 16:14:54.409851
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    foo1 = ScalarToken('foo', 0, 0)
    foo2 = ScalarToken('foo', 0, 0)
    assert(foo1 == foo2)
    assert(not foo1 == 'foo')
    assert(not foo1 == Token('foo', 0, 0))


# Generated at 2022-06-12 16:15:05.364481
# Unit test for constructor of class DictToken
def test_DictToken():
    class MagicMock:
        def __init__(self, value, start_index, end_index, content = ""):
            self._value = value
            self._start_index = start_index
            self._end_index = end_index
            self._content = content
        def _get_value(self):
            return self._value
        def __eq__(self, other):
            return isinstance(other, MagicMock) and (
                self._value == other._value
                and self._start_index == other._start_index
                and self._end_index == other._end_index
            )
    a = MagicMock(1, 2, 3)
    b = MagicMock(4, 5, 6)
    c = MagicMock(7, 8, 9)

# Generated at 2022-06-12 16:15:14.193420
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    value_ = 1
    start_index_ = 0
    end_index_ = 1
    content_ = "2"
    tok = Token(None, None, None, None)
    token_ = Token(value_, start_index_, end_index_, content_)
    token_1 = Token(2, start_index_, end_index_, content_)
    token_2 = Token(value_, 2, end_index_, content_)
    token_3 = Token(value_, start_index_, 3, content_)
    token_4 = Token(value_, start_index_, end_index_, "3")

    assert token_ == token_
    assert not token_ == token_1
    assert not token_ == token_2
    assert not token_ == token_3
    assert not token

# Generated at 2022-06-12 16:15:25.318141
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem import types

    number_type = types.Number()
    string_type = types.String()

    number_1 = ScalarToken(value=number_type, start_index=6, end_index=9, content="abcd1234")
    number_2 = ScalarToken(value=number_type, start_index=10, end_index=13, content="abcd1234")

    list_1 = ListToken(value=[number_1, number_1], start_index=0, end_index=7, content="[1234,1234]")
    list_1_a = ListToken(value=[number_1, number_1], start_index=0, end_index=7, content="[1234,1234]")

# Generated at 2022-06-12 16:15:35.759301
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1=ScalarToken(42, 10, 20, "hello\nworld\ntesting\n")
    t2=ScalarToken(42, 10, 20, "hello\nworld\ntesting\n")
    assert t1 == t2
    t1=ScalarToken(42, 11, 20, "hello\nworld\ntesting\n")
    t2=ScalarToken(42, 10, 20, "hello\nworld\ntesting\n")
    assert t1 != t2
    t1=ScalarToken(42, 10, 21, "hello\nworld\ntesting\n")
    t2=ScalarToken(42, 10, 20, "hello\nworld\ntesting\n")
    assert t1 != t2

# Generated at 2022-06-12 16:15:42.596369
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test if equality operation works as expected
    token1 = Token(1, 0, 1, "")
    token2 = Token(2, 0, 1, "")
    assert not (token1 == token2)
    assert token1 != token2
    token3 = Token(1, 0, 1, "")
    assert token1 == token3

# Generated at 2022-06-12 16:15:46.195484
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import Number, String

    dt=DictToken("", 0, 1, content={"a":1,"b":2,"c":3})
    print("DictToken constructor test passed")



# Generated at 2022-06-12 16:15:49.489824
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    content = "abc"
    inst01 = Token("a", 1, 2, content="")
    inst02 = Token("a", 1, 2, content="")
    assert inst01 == inst02
    
    

# Generated at 2022-06-12 16:15:51.119428
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    for i in range(1,10):
        if i == 5:
            print(i)


# Generated at 2022-06-12 16:16:44.244878
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    def _test(
        value: typing.Any,
        start_index: int,
        end_index: int,
        content: str = "",
    ):
        _Token = Token(
            value, start_index, end_index, content
        )
        assert _Token == _Token
        assert not _Token != _Token

    _test(
        value=[],
        start_index=0,
        end_index=0,
        content="",
    )


# Generated at 2022-06-12 16:16:57.010151
# Unit test for constructor of class DictToken
def test_DictToken(): 
    d = {'hi': 'there'}
    dt = DictToken(d, 1, 4)
    assert dt._value == {'hi': 'there'}
    assert dt._start_index == 1
    assert dt._end_index == 4
    assert len(dt._child_keys) == 1
    assert dt._child_keys['hi']._value == 'hi'
    assert len(dt._child_tokens) == 1
    assert dt._child_tokens['hi']._value == 'there'
    assert dt.start._line_number == 1
    assert dt.start._column_number == 1
    assert dt.start._absolute_position == 1
    assert dt.end._line_number == 1
    assert dt.end._column_number == 4


# Generated at 2022-06-12 16:17:05.059381
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert (Token("foo", 1, 2, content=None) == Token("foo", 1, 2, content=None)) is True
    assert (Token("foo", 1, 2, content=None) == Token("bar", 1, 2, content=None)) is False
    assert (Token("foo", 2, 3, content=None) == Token("foo", 1, 2, content=None)) is False
    assert (Token("foo", 2, 3, content=None) == Token("bar", 1, 2, content=None)) is False
    assert (Token("foo", 1, 2, content=None) == object()) is False


# Generated at 2022-06-12 16:17:07.837818
# Unit test for constructor of class DictToken
def test_DictToken():
    x = DictToken({"a":1}, 0, 1, "abc")
    assert x._value == {"a":1}
    assert x._start_index == 0
    assert x._end_index == 1
    assert x._content == "abc"


# Generated at 2022-06-12 16:17:14.442695
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(None, 0, 0)
    t2 = Token(None, 0, 0)
    assert t1 == t2
    assert t1 == t1
    assert not (t1 != t2)
    assert not (t2 != t1)
    assert t1 != None


# Generated at 2022-06-12 16:17:24.656585
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    start = Position(1,1,1)
    end = Position(1,1,1)
    content = "content"
    token = Token('value', start, end, content)
    assert (token._start_index == start)
    assert (token._end_index == end)
    assert (token._content == content)
    assert (token._value == 'value')
    assert (token.value == 'value')
    assert (token.string == 'value')
    start2 = Position(2,2,2)
    end2 = Position(2,2,2)
    content2 = "content2"
    token2 = Token('value2', start2, end2, content2)
    assert (token._start_index != start2)
    assert (token._end_index != end2)

# Generated at 2022-06-12 16:17:31.859594
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """
    Unit test for method __eq__ of class Token
    """
    import typesystem

    # Arrange
    x = Token(value = 1, start_index = 0, end_index = 1)
    y = Token(value = 2, start_index = 3, end_index = 4)
    z = Token(value = 3, start_index = 0, end_index = 1)

    # Act
    assert x == z

    # Assert
    assert x != y



# Generated at 2022-06-12 16:17:44.092467
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """
    Test method __eq__ of class Token
    """
    
    # Test without input argument
    a = Token(None, 0, 0)
    b = Token(None, 0, 0)
    assert a == b
    b = Token(None, 1, 0)
    assert not a == b
    b = Token(None, 0, 1)
    assert not a == b
    b = Token("value", 0, 0)
    assert not a == b
    a = Token("value", 0, 0)
    b = Token("value", 0, 0)
    assert a == b
    b = Token("value", 1, 0)
    assert not a == b
    b = Token("value", 0, 1)
    assert not a == b
    b = Token(None, 0, 0)
    assert not a == b


# Generated at 2022-06-12 16:17:46.348660
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    Token(None, None, None, None)
    # TODO: implement this test
    raise NotImplementedError


# Generated at 2022-06-12 16:17:49.804850
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    #Test the equality of tokens of type ScalarToken
    token1 = ScalarToken(value=3,start_index=3,end_index=3)
    token2 = ScalarToken(value=3,start_index=3,end_index=3)
    assert token1 == token2


# Generated at 2022-06-12 16:19:07.454873
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    a = Token(1, 2, 3, 4)
    assert a == a

    b = Token(1, 2, 3, 4)
    assert a == b

    c = Token(1, 2, 7, 4)
    assert not a == c

    d = Token(1, 2, 3, 9)
    assert not a == d

    e = Token(1, 2, 3)
    assert a == e

    f = Token(1, 2, 3, None)
    assert a == f

    g = Token(1, 2, 7, 4)
    assert not a == g

# Generated at 2022-06-12 16:19:12.909736
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    start_index = 0
    end_index = 0
    content = ""
    token1 = Token(value = "", start_index = start_index, end_index = end_index, content = content)
    token2 = Token(value = "", start_index = start_index, end_index = end_index, content = content)
    assert token1 == token2


# Generated at 2022-06-12 16:19:17.011834
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    start = Position(90, 54, 0) # unit test
    end = Position(90, 54, 0) # unit test
    test_instance = Token((), start, end)
    other = 67
    output = test_instance.__eq__(other)
    assert output is NotImplemented


# Generated at 2022-06-12 16:19:23.411632
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class SubToken(Token):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)
            self._value = str(self._value)
    assert SubToken(12, 15, 23) == SubToken(12, 15, 23)
    assert not SubToken(12, 16, 23) == SubToken(12, 15, 23)
    assert not SubToken(114, 15, 23) == SubToken(12, 15, 23)
    assert not SubToken(12, 15, 23) == object()

# Generated at 2022-06-12 16:19:24.852612
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    q=Token( "{", 0, 0, "{")
    e=Token( "{", 0, 0, "{")
    assert q==e



# Generated at 2022-06-12 16:19:36.152071
# Unit test for method __eq__ of class Token
def test_Token___eq__():
 
    import json
    import typesystem
    from typesystem.base import Undefined

    from typesystem.base.scalars import String
    from typesystem.base.scalars import Boolean
    from typesystem.base.scalars import Integer
    from typesystem.base.scalars import Float
    from typesystem.base.scalars import Date
    from typesystem.base.scalars import Time
    from typesystem.base.scalars import DateTime

    from typesystem.base.schemas import Schema
    from typesystem.base.schemas import Array
    from typesystem.base.schemas import Dictionary

    from typesystem.base.tokens import ScalarToken
    from typesystem.base.tokens import DictToken
    from typesystem.base.tokens import ListToken

    schema

# Generated at 2022-06-12 16:19:42.224437
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken('abc', 2,3, 'abcdefg')
    print(dict_token.string)
    print(dict_token.value)
    print(dict_token.start)
    print(dict_token.end)
    print(dict_token._value)
    print(dict_token._content)
    print(dict_token._start_index)
    print(dict_token._end_index)
test_DictToken()

# Generated at 2022-06-12 16:19:48.756119
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    s1 = ScalarToken(10, 0, 2, "10")
    s2 = ScalarToken(10, 0, 2, "10")
    s3 = ScalarToken(20, 0, 2, "10")
    assert s1 == s2
    assert s1 != s3
    assert s2 == s1
    assert s2 != s3
    assert s3 != s1
    assert s3 != s2

# Generated at 2022-06-12 16:20:00.113696
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test constructor
    dic = {"Hello": "World"}
    t = DictToken(dic, 0, 5, "Hello World")
    # Test basic properties
    assert t.string == "Hello"
    assert t.value == dic
    assert t.start.line == 1
    assert t.start.column == 1
    assert t.start.index == 0
    assert t.end.line == 1
    assert t.end.column == 5
    assert t.end.index == 4
    assert repr(t) == "DictToken({'Hello': 'World'})"
    dic2 = {"Hello": "World"}
    t2 = DictToken(dic2, 0, 5, "Hello World")
    assert t == t2
    dic3 = {"Hi": "World"}
    t3 = Dict

# Generated at 2022-06-12 16:20:02.009537
# Unit test for constructor of class DictToken
def test_DictToken():
    """
    This is the unit test for the constructor of class DictToken
    """
    assert DictToken("a", 1, 2)