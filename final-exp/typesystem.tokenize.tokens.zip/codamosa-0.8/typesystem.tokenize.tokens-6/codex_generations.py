

# Generated at 2022-06-12 16:12:16.497737
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken = DictToken(object(), 0, 1, '')


# Generated at 2022-06-12 16:12:20.999949
# Unit test for constructor of class DictToken
def test_DictToken():
    value_token_1 = ScalarToken(5, 0, 1)
    value_token_2 = ScalarToken(3, 2, 3)
    key_token_1 = ScalarToken(1, 0, 1)
    key_token_2 = ScalarToken(2, 2, 3)
    value = {key_token_1: value_token_1, key_token_2: value_token_2}
    try:
        DictToken(value, 0, 3, content='123')
    except NotImplementedError:
        assert False
    assert True

# Generated at 2022-06-12 16:12:24.218102
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.base import Token
    # Test __eq__ when self.value == other.value
    # Test __eq__ when self.value != other.value
    pass


# Generated at 2022-06-12 16:12:29.364667
# Unit test for constructor of class DictToken
def test_DictToken():
    map_expectation = {'A': 1, 'B': 2}
    DictToken_init_value = DictToken(map_expectation, 0, 0).value
    map_actual = {'A': 1, 'B': 2}
    assert DictToken_init_value == map_actual



# Generated at 2022-06-12 16:12:35.061689
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    tok1 = ScalarToken("foo", 1, 4)
    tok2 = ScalarToken("foo", 1, 5)
    assert tok1 == tok1
    assert not tok1 == tok2
    assert not tok1 == ""
    assert tok1 != ""
    assert not tok1 != tok1
    assert tok1 != tok2




# Generated at 2022-06-12 16:12:42.873366
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class TokenStub:
        def __init__(self, value, start_index, end_index, content = ""):
            self._value = value
            self._start_index = start_index
            self._end_index = end_index
            self._content = content
        def __eq__(self, other: typing.Any) -> bool:
            return isinstance(other, Token) and (
                self._value == other._value
                and self._start_index == other._start_index
                and self._end_index == other._end_index
            )
    # call function
    assert TokenStub(value = "a", start_index = 0, end_index = 0) == TokenStub(value = "a", start_index = 0, end_index = 0)


# Generated at 2022-06-12 16:12:48.755018
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 1, 2, "") == Token(1, 1, 2, "")
    assert not (Token(1, 1, 2, "") == Token(1, 1, 2, "abc"))
    assert not (Token(1, 1, 2, "") == Token(2, 1, 2, ""))
    assert not (Token(1, 1, 2, "") == Token(1, 2, 2, ""))  # type: ignore
    assert not (Token(1, 1, 2, "") == Token(1, 1, 3, ""))



# Generated at 2022-06-12 16:12:51.053110
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    instance = Token(None, None, None, None)
    assert instance.__eq__(instance) == True # [True]
    assert instance.__eq__(None) == False # [False]


# Generated at 2022-06-12 16:12:54.329605
# Unit test for constructor of class DictToken
def test_DictToken():
  token = DictToken({1:1},0,0)
  token._get_value()
  token._get_child_token(1)
  token._get_key_token(1)
  token.__repr__()
  # todo __eq__ is a abstract method. So this assert cause an error
  # assert(token.__eq__(token))


# Generated at 2022-06-12 16:12:56.516339
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token('a', 1, 2) == Token('a', 1, 2)


# Generated at 2022-06-12 16:13:08.144690
# Unit test for constructor of class DictToken
def test_DictToken():
    start_index = 0
    end_index = 100
    content = "python"
    value = {
        key_token: value_token
        for key_token, value_token in (("value1", "value2"), ("value3", "value4"))
    }
    mytoken = DictToken(value, start_index, end_index, content)
    assert mytoken._value == value
    assert mytoken._start_index == start_index
    assert mytoken._end_index == end_index
    assert mytoken._content == content



# Generated at 2022-06-12 16:13:17.664651
# Unit test for constructor of class DictToken
def test_DictToken():
    # value is not a dict -> raise TypeError
    with pytest.raises(TypeError):
        DictToken(None, None, None)
    with pytest.raises(TypeError):
        DictToken(None, 0, 1, None)
    with pytest.raises(TypeError):
        DictToken({1: "abc", 2: "def"}, 0, 1, None)
    # child_keys and child_tokens are not dict
    with pytest.raises(TypeError):
        DictToken({"abc": "def"}, 0, 1, None)
    with pytest.raises(TypeError):
        DictToken({"abc": "def"}, 0, 1, None, ["def"])

# Generated at 2022-06-12 16:13:19.934538
# Unit test for constructor of class DictToken
def test_DictToken():
    dictToken = DictToken(value=None, start_index=1, end_index=2, content=None)
    assert dictToken._value is None
    assert dictToken.start._line_no is 1
    assert dictToken.end._line_no is 2
    assert dictToken._content is None


# Generated at 2022-06-12 16:13:27.318992
# Unit test for constructor of class DictToken
def test_DictToken():
    a = ScalarToken("a",0,0)
    b = ScalarToken("b",0,0)
    d =  DictToken({"a":a,"b":b},0,0)
    assert d._child_keys == {"a":a,"b":b}
    assert d._child_tokens == {"a":a,"b":b}
    assert d._start_index == 0
    assert d._end_index == 0
    assert d._content == ""
    assert d.string == ""
    assert d.value == {"a":a._get_value(),"b":b._get_value()}
    assert d.start == Position(1,1,0)
    assert d.end == Position(1,1,0)
    assert d.lookup([a]) == a
    assert d.lookup_

# Generated at 2022-06-12 16:13:28.621685
# Unit test for constructor of class DictToken
def test_DictToken():
  	d = DictToken()
  	assert(isinstance(d, DictToken))

# Generated at 2022-06-12 16:13:34.360730
# Unit test for constructor of class DictToken
def test_DictToken():
    # Arrange
    kwargs: Dict[str, int] = {'kwargs': 1}
    # Act
    t = DictToken(0, 1, 2, args=1, **kwargs)
    # Assert
    assert t._value == 0
    assert t._start_index == 1
    assert t._end_index == 2
    assert t._content == 'args=1'
    assert t._child_keys == {}



# Generated at 2022-06-12 16:13:43.327632
# Unit test for method __eq__ of class Token
def test_Token___eq__():
	# HACK: Add the type of value when the __eq__ method is called
    from typesystem.parser import parse_to_tokens
    class _ScalarToken(ScalarToken):
        def __eq__(self, other):
            assert isinstance(self._value, bool)
            assert isinstance(other._value, bool)
            return True
    class _Parser(Parser):
        types = {
            bool: _ScalarToken,
        }
    parse_to_tokens({"a": True}, _Parser())

# Generated at 2022-06-12 16:13:51.788337
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == scalar(1, 2, 3)
    assert Token(1, 2, 3) != scalar(1, 2, 2)
    assert Token(1, 2, 3) != scalar(1, 2, 4)
    assert Token(1, 2, 3) != scalar(0, 2, 3)
    assert Token(1, 2, 3) != scalar(2, 2, 3)
    assert Token(1, 2, 3) != lst([scalar(1, 2, 3), scalar(2, 2, 3)], 2, 3)


# Generated at 2022-06-12 16:13:55.725821
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {
    "key1" : "string",
    "key2" : 2,
    "key3" : True,
    }
    DictToken(d, 1, 0, True)


# Generated at 2022-06-12 16:13:58.658444
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.base import Position

    t1 = Token(1, 0, 1, "a")
    t2 = Token(1, 0, 1, "a")
    assert t1 == t2



# Generated at 2022-06-12 16:14:33.003991
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test with ScalarToken
    a_token_1 = ScalarToken(5, 2, 3)
    a_token_2 = ScalarToken(5, 2, 3)
    assert a_token_1 == a_token_2
    a_token_3 = ScalarToken(4, 2, 3)
    assert not a_token_1 == a_token_3
    a_token_4 = ScalarToken(5, 1, 3)
    assert not a_token_1 == a_token_4
    a_token_5 = ScalarToken(5, 2, 2)
    assert not a_token_1 == a_token_5

    # Test with ListToken
    a_token_1 = ListToken([ScalarToken(2, 3, 4)], 2, 8, "[2]")
    a_token

# Generated at 2022-06-12 16:14:43.638867
# Unit test for constructor of class DictToken
def test_DictToken():
    token1 = ScalarToken(1, 0, 2, "123")
    token2 = ScalarToken(2, 2, 4, "123")
    dic1 = {token1: token2}
    token3 = DictToken(dic1, 0, 4, "123")
    assert token3._value == dic1
    assert token3._start_index == 0
    assert token3._end_index == 4
    assert token3._content == "123"
    assert token3.string == "123"
    assert token3.value == {1: 2}
    assert token3.start == Position(1, 1, 0)
    assert token3.end == Position(1, 5, 4)
    

# Generated at 2022-06-12 16:14:54.021593
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert ScalarToken(None, 0, 2, content='{}') == ScalarToken(None, 0, 2, content='{}')
    assert ScalarToken(None, 0, 2, content='{}') not in [None, None, None]

    assert DictToken({}, 0, 2, content='{}') == DictToken({}, 0, 2, content='{}')
    assert DictToken({}, 0, 2, content='{}') not in [None, None, None]

    assert ListToken([], 0, 2, content='{}') == ListToken([], 0, 2, content='{}')
    assert ListToken([], 0, 2, content='{}') not in [None, None, None]



# Generated at 2022-06-12 16:15:00.921408
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 1, 1) == Token(1, 1, 1)
    assert Token(2, 1, 1) != Token(1, 1, 1)
    assert Token(1, 2, 1) != Token(1, 1, 1)
    assert Token(1, 1, 2) != Token(1, 1, 1)
    assert Token(1, 1, 1, "") == Token(1, 1, 1, "")
    assert Token(1, 1, 1, "1") != Token(1, 1, 1, "")

# Generated at 2022-06-12 16:15:04.547747
# Unit test for method __eq__ of class Token
def test_Token___eq__():
  token1 = Token(None, None, None, None)

  token2 = Token(token1, token1, token1, None)

  assert (token1==token2)

# Generated at 2022-06-12 16:15:11.104340
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    '''
    Task: 
        Verify if Token.__eq__() return result as expected.
    Expected Result:
        Return result as expected
    '''
    print('Test if Token.__eq__() return result as expected')
    a = ScalarToken(None, 1, 2, "abc")
    b = ScalarToken(None, 1, 2, "abc")
    assert a == b
    c = ScalarToken(None, 2, 1, "abc")
    assert a != c


# Generated at 2022-06-12 16:15:15.129151
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    string = '''
    {
        "a": 1,
        "b": [
            "a",
            true,
            [1, 2, 3],
            {
                "c": "d"
            }
        ]
    }
    '''
    token = json.loads(string, object_pairs_hook=DictToken)
    token2 = json.loads(string, object_pairs_hook=DictToken)
    assert token == token2



# Generated at 2022-06-12 16:15:17.427260
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({'k':'a'}) == {'k':'a'}

# Generated at 2022-06-12 16:15:20.761372
# Unit test for method __eq__ of class Token
def test_Token___eq__():
  token_ = Token(value="value", start_index=1, end_index=2)
  other = Token(value="value_other", start_index=1, end_index=2)
  assert token_ != other


# Generated at 2022-06-12 16:15:21.843402
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # TODO: add tests
    pass

# Generated at 2022-06-12 16:15:55.030223
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert ScalarToken(1, 0, 10, "1") == ScalarToken(1, 0, 10, "1")
    assert ScalarToken(1, 0, 10, "1") != ScalarToken(2, 0, 10, "1")
    assert ScalarToken(1, 0, 10, "1") != ScalarToken(1, 0, 11, "1")
    assert ScalarToken(1, 0, 10, "1") != ScalarToken(1, 1, 10, "1")

    # ListToken
    assert ListToken(
        [
            ScalarToken(0, 0, 10, "1"),
            ScalarToken(1, 1, 10, "2"),
            ScalarToken(2, 2, 10, "3"),
        ],
        0,
        10,
        "123",
    ) == List

# Generated at 2022-06-12 16:16:00.968390
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from polytropos.ontology.variable import VariableId
    from polytropos.ontology.composite import Composite
    from polytropos.ontology.schema import Schema
    from polytropos.ontology.context import Context
    from polytropos.tools.qc import Nullable
    
    context: Context = Context(path_root="/tmp")
    schema: Schema = Schema.build(source_dir="test", context=context)
    composite: Composite = schema.build_empty(ImmutableMap)
    assert composite.get_token(VariableId("var_text"))==composite.get_token(VariableId("var_text"))
    
    

# Generated at 2022-06-12 16:16:10.316214
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(0, 0, 0)
    token_0 = token
    assert token == token_0
    assert not (token != token_0)
    token_1 = Token(0, 0, 0)
    assert token == token_1
    token_2 = Token(1, 0, 0)
    assert not (token == token_2)
    token_3 = Token(0, 1, 0)
    assert not (token == token_3)
    token_4 = Token(0, 0, 1)
    assert not (token == token_4)
    token_5 = Token(1, 1, 1)
    assert not (token == token_5)


# Generated at 2022-06-12 16:16:16.327871
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """Test method __eq__ of class Token"""

    # Create an instance
    token_instance = Token("value_0", 0, 0, "content_0")
    # Create another instance
    another_token_instance = Token("value_0", 0, 0, "content_0")
    # Check if the two instances are equal
    assert token_instance == another_token_instance



# Generated at 2022-06-12 16:16:17.756331
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token._eq_() == 0
    assert Token._eq_() == 0

# Generated at 2022-06-12 16:16:20.837638
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, None, None, None)
    other = Token(None, None, None, None)
    assert token == other

# Generated at 2022-06-12 16:16:31.368486
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    T = Token
    s = ScalarToken
    d = DictToken
    l = ListToken

    # equal
    assert s('a', 0, 0) == s('a', 0, 0)
    assert d(dict(), 0, 0) == d(dict(), 0, 0)
    assert l(list(), 0, 0) == l(list(), 0, 0)

    assert d({'a': s('1', 0, 0)}, 0, 0) == d({'a': s('1', 0, 0)}, 0, 0)
    assert d({'a': s('1', 0, 0)}, 0, 0) == d({s('a', 0, 0): s('1', 0, 0)}, 0, 0)

# Generated at 2022-06-12 16:16:32.527341
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(0, 1, 2, 'str')
    other_token = Token(0, 1, 2, 'str')
    assert token == other_token


# Generated at 2022-06-12 16:16:43.807474
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    try:
        index = [0, 3]
        token1 = Token(0, 0, 0, "")
        token2 = token1.lookup(index)
        assert token2 == Token(0, 0, 0, "")
        assert token2 != Token(1, 0, 0, "")
        assert token2 != Token(0, 1, 0, "")
        assert token2 != Token(0, 0, 1, "")
        assert token2 != ScalarToken(1, 0, 0, "")
        assert token2 != DictToken(1, 0, 0, "")
        assert token2 != ListToken(1, 0, 0, "")
        assert token2 != None
    except AttributeError:
        assert False


# Generated at 2022-06-12 16:16:52.666971
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    s = Token(1, 1, 2)
    a = ScalarToken(1, 1, 2)
    b = ScalarToken(2, 3, 4)
    c = ScalarToken(1, 1, 2, "hehe")
    d = ScalarToken(1, 3, 4, "hehe")
    e = ScalarToken(1, 1, 2, "hehe")
    assert a == s == e
    assert a != b
    assert a != c != d
    assert c == e
    

# Generated at 2022-06-12 16:17:41.959001
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Init objects
    token_a = Token("value 1", 0, 2, "value 1")
    token_b = Token("value 2", 0, 2, "value 1")
    token_c = Token("value 1", 1, 2, "value 1")
    token_d = Token("value 1", 0, 3, "value 1")
    token_e = Token("value 1", 0, 2, "value 1")

    # Check result
    assert token_a != token_b
    assert token_a != token_c
    assert token_a != token_d
    assert token_a == token_e

# Generated at 2022-06-12 16:17:43.851809
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    Token.__eq__(Token(True, 2, 4), Token(False, 2, 4))



# Generated at 2022-06-12 16:17:50.008454
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    __tracebackhide__ = True

    m = Token(0, 1, 2)
    m2 = m
    assert m == m2

    m3 = Token(0, 1, 2)
    assert m == m3

    m4 = Token(0, 1, 3)
    assert m != m4

    m5 = Token(0, 2, 3)
    assert m != m5

    m6 = Token(1, 2, 3)
    assert m != m6

    m7 = Token(1, 2, 3)
    assert m7 != m6

# Generated at 2022-06-12 16:17:55.033090
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class Token_test___eq__(Token):
        def __init__(self):
            self._value = None
            self._start_index = None
            self._end_index = None
        def _get_value(self):
            return None
    Token_test___eq__().__eq__(object())


# Generated at 2022-06-12 16:17:55.917004
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    pass #FIXME
    

# Generated at 2022-06-12 16:18:00.215747
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(
        "value",
        start_index=1,
        end_index=3,
        content="content"
    )
    assert token == token
    assert token != Token(
        "value",
        start_index=1,
        end_index=3,
        content="content"
    )

# Generated at 2022-06-12 16:18:01.125082
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Tested in class ScalarToken
    ...


# Generated at 2022-06-12 16:18:06.756372
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    print('Test for method __eq__ of class Token...')

    token = Token(None, 0, 4)
    assert token == token
    assert not token == None
    assert not token == str
    assert not token == Token(None, 0, 3)
    assert not token == Token(None, 1, 4)
    assert not token == Token(None, 0, 4, 'a')
    assert not token == Token(None, 0, 4, 'ab')
    assert not token == Token('a', 0, 4)
    assert not token == Token(True, 0, 4)
    assert not token == Token(False, 0, 4)
    assert not token == Token({}, 0, 4)
    assert not token == Token([], 0, 4)
    assert not token == ScalarToken('a', 0, 4)
    assert not token == D

# Generated at 2022-06-12 16:18:08.874961
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """
    Token.__eq__()
    """
    pass

# Generated at 2022-06-12 16:18:12.823132
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert len((Token((), 0, 0, ""))) == 3
    assert len(ScalarToken((), 0, 0, "")) == 3
    assert len(DictToken((), 0, 0, "")) == 3
    assert len(ListToken((), 0, 0, "")) == 3

# Generated at 2022-06-12 16:19:34.316162
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = ScalarToken("abc", 0, 2)
    token2 = ScalarToken("abc", 0, 2)
    assert token == token2
    assert not (token != token2)


# Generated at 2022-06-12 16:19:40.047454
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = ScalarToken(1, 2, 3)
    token2 = ScalarToken(1, 2, 3)
    token3 = ScalarToken(1, 4, 5)
    token4 = ScalarToken(1, 2, 6)

    assert(token1 == token2)
    assert(token1 != token3)
    assert(token1 != token4)


# Generated at 2022-06-12 16:19:52.523697
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from functools import reduce


    class Token:
        def __init__(self, value: typing.Any, start_index: int, end_index: int, content: str = "") -> None:
            self._value = value
            self._start_index = start_index
            self._end_index = end_index
            self._content = content

        def __eq__(self, other: typing.Any) -> bool:
            return isinstance(other, Token) and (
                self._value == other._value
                and self._start_index == other._start_index
                and self._end_index == other._end_index
            )



# Generated at 2022-06-12 16:20:00.757201
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert ScalarToken("a", 0, 0, "a") == ScalarToken("a", 0, 0, "a")
    assert not ScalarToken("a", 0, 0, "a") == ScalarToken("a", 0, 0, "b")
    assert not ScalarToken("a", 1, 1, "a") == ScalarToken("a", 0, 0, "a")
    assert not ScalarToken("a", 0, 0, "a") == DictToken(
        {"a": ScalarToken("a", 0, 0, "a")}, 0, 2, "a"
    )

# Generated at 2022-06-12 16:20:04.879164
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token('value', 1, 2)
    assert(token.__eq__(token))
    assert(not token.__eq__(1))
    assert(not token.__eq__(Token('', 1, 2)))
    assert(not token.__eq__(Token('value', 2, 2)))
    assert(not token.__eq__(Token('value', 1, 3)))


# Generated at 2022-06-12 16:20:15.097730
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Setup
    t1 = ScalarToken("", 2, 5, "one two")
    t2 = ScalarToken("", 2, 5, "one two")
    t3 = ScalarToken("", 2, 4, "one two")
    t4 = ScalarToken("", 3, 5, "one two")

    # Exercise
    result1 = t1.__eq__(t2)
    result2 = t1.__eq__(t3)
    result3 = t1.__eq__(t4)

    # Verify
    assert result1 == True
    assert result2 == False
    assert result3 == False

# Generated at 2022-06-12 16:20:17.267256
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    obj = Token(None, 0, 0)
    other = Token(None, 1, 1)
    assert not(obj == other)

# Generated at 2022-06-12 16:20:23.366837
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token("a", 0, 3)
    t2 = Token("a", 0, 3)
    t3 = Token("a", 3, 3)
    t4 = Token("b", 0, 3)

    assert t1 == t1
    assert t1 == t2
    assert t2 == t1
    assert t3 != t1
    assert t1 != t3
    assert t1 != t4
    assert t4 != t1



# Generated at 2022-06-12 16:20:24.402037
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    pass



# Generated at 2022-06-12 16:20:27.608211
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(value = '', start_index = 0, end_index = 1)
    token2 = Token(value = '', start_index = 0, end_index = 1)
    token3 = Token('', 2, 3)

    assert token1 == token2
    assert token1 != token3


# Generated at 2022-06-12 16:21:39.715587
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    my_Token = Token(1, 2, 3, "")
    # should output the name of the class and the content of the string attribute
    assert my_Token.__repr__() == "Token(1)"


# Generated at 2022-06-12 16:21:45.648523
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
  st = ScalarToken(10, 0, 2, 'abc')
  assert st.string == 'abc'
  assert st.value == 10
  assert st.start._line_no == 1
  assert st.start._column_no == 1
  assert st.start._index == 0
  assert st.end._line_no == 1
  assert st.end._column_no == 3
  assert st.end._index == 2


# Generated at 2022-06-12 16:21:48.437716
# Unit test for constructor of class DictToken
def test_DictToken():
    result = DictToken({},0,0)
    assert result._get_value() == {}
    result = DictToken({},0,0,content = "hello")
    assert result._content == "hello"
test_DictToken()

#Unit test for constructor of class ListToken

# Generated at 2022-06-12 16:21:54.079574
# Unit test for method lookup of class Token
def test_Token_lookup():
    dic = {'a':1,'b':2}
    list = [1,2,3]
    token = DictToken(dic,0,2,'')
    print(token.lookup([0]).value)
    token = DictToken(dic,0,1,'')
    print(token.lookup([0]))
    token = ListToken(list,0,2)
    print(token.lookup([1]))

# Generated at 2022-06-12 16:22:01.359815
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    input_str = "str"
    child_str = "child"

    input_token = Token(input_str, 1, 2)
    child_token = Token(child_str, 1, 2)
    input_dict = {input_token: {input_token: child_token}}
    input_token.value = input_dict

    expected_result = input_token
    result = input_token.lookup_key([0, 0, "str"])

    assert result == expected_result


# Generated at 2022-06-12 16:22:08.060470
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.base import Token, Position
    from unittest.mock import Mock
    class mock_ScalarToken(Token):
        def _get_value(self):
            return 1
    class mock_DictToken(Token):
        def _get_value(self):
            return {}
        def _get_child_token(self, key):
            return token
        def _get_key_token(self, key):
            return token
    class mock_ListToken(Token):
        def _get_value(self):
            return []
        def _get_child_token(self, key):
            return token
    mock_ScalarToken_1 = mock_ScalarToken(
        1, 0, 0
    )