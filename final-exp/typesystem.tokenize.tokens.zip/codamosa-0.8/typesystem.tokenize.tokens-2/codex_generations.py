

# Generated at 2022-06-12 16:12:23.659895
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    d1 = {'a':1,'b':2}
    d2 = {'a':3,'b':4}
    assert d1 != d2

# Generated at 2022-06-12 16:12:26.109616
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(None, 0, 1, content = '') == Token(None, 0, 1, content = '')


# Generated at 2022-06-12 16:12:30.897647
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Setup
    pos_0 = Position(0, 0, 0)
    pos_1 = Position(0, 1, 1)
    pos_2 = Position(0, 2, 2)
    pos_3 = Position(0, 3, 3)
    token_0 = ScalarToken("a", 0, 0)
    token_1 = DictToken(
        {token_0: ScalarToken("b", 1, 1)},
        0,
        3,
        "a\nb",
    )
    token_2 = ScalarToken("b", 1, 1)
    token_3 = ScalarToken("a", 0, 0, raw=True)
    token_4 = ListToken([ScalarToken("a", 0, 0)], 0, 1)

# Generated at 2022-06-12 16:12:32.258219
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(None, 1, 2) == Token(None, 1, 2)

# Generated at 2022-06-12 16:12:36.644330
# Unit test for constructor of class DictToken
def test_DictToken():
    value = "what"
    start_index = 0
    end_index = 1
    content = "a"
    tokens = DictToken(value, start_index, end_index, content)
    assert isinstance(tokens, DictToken)


# Generated at 2022-06-12 16:12:39.595696
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken._get_value('{}') == '{}'


# Generated at 2022-06-12 16:12:45.169685
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class t:
        def __init__(self, value, start_index, end_index, content):
            self._value = value
            self._start_index = start_index
            self._end_index = end_index
            self._content = content
    t._get_value = lambda self: self._value
    T = t('a', 0, 2, 'abc')
    assert(T == T)
    assert(not T == t('a', 0, 2, 'abd'))
    assert(not T == t('a', 1, 2, 'abc'))
    assert(not T == t('a', 0, 3, 'abc'))
    assert(not T == t('b', 0, 2, 'abc'))


# Generated at 2022-06-12 16:12:47.778640
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(0, 0, 0) != 0
Token.__eq__((Token(0, 0, 0), 0))

# Generated at 2022-06-12 16:12:48.891621
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # TODO
    pass


# Generated at 2022-06-12 16:12:57.110092
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class Token1(Token):
        pass
    token1 = Token1(1,2,3)
    token2 = getattr(token1,"_value")
    token3 = getattr(token1,"_start_index")
    token4 = getattr(token1,"_end_index")
    assert token1.__eq__(token2) == True
    assert token1.__eq__(token3) == False
    assert token1.__eq__(token4) == False


# Generated at 2022-06-12 16:13:06.947406
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    token3 = Token(2, 2, 3)
    token4 = Token(1, 4, 3)
    token5 = Token(1, 2, 5)
    assert(token1 == token2)
    assert(not(token1 == token3))
    assert(not(token1 == token4))
    assert(not(token1 == token5))



# Generated at 2022-06-12 16:13:11.798115
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = ScalarToken(
        value=1, start_index=0, end_index=1, content='a'
    )
    other = ScalarToken(
        value=2, start_index=0, end_index=1, content='a'
    )

    assert isinstance(token, Token)
    assert isinstance(other, Token)

    assert token != other


# Generated at 2022-06-12 16:13:21.564980
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.base import Lexer
    from typesystem.parser import Parser

    parser = Parser(Lexer())
    assert parser.parse("null") == parser.parse("null")

    assert parser.parse("false") != None
    assert parser.parse("false") == parser.parse("false")

    assert parser.parse("true") != None
    assert parser.parse("true") == parser.parse("true")

    assert parser.parse("1234567890") != None
    assert parser.parse("1234567890") == parser.parse("1234567890")

    assert parser.parse("-1234567890") != None
    assert parser.parse("-1234567890") == parser.parse("-1234567890")

    assert parser.parse("12345.6789") != None

# Generated at 2022-06-12 16:13:28.199272
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert ScalarToken(1, 0, 2, 'abc') == ScalarToken(1, 0, 2, 'abc')
    assert ScalarToken(1, 0, 2, 'abc') != ScalarToken(1, 0, 2, '1bc')
    assert ScalarToken(1, 0, 2, 'abc') != ScalarToken(3, 0, 2, 'abc')
    assert ScalarToken(1, 0, 2, 'abc') != ScalarToken(1, 0, 3, 'abc')
    assert ScalarToken(1, 0, 2, 'abc') != ScalarToken(1, 1, 2, 'abc')
    assert ScalarToken(1, 0, 2, 'abc') != ScalarToken(1, 0, 2, '123')
    assert ScalarToken(1, 0, 2, 'abc') != 1


# Generated at 2022-06-12 16:13:33.673696
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    content = "1234"
    value = 1234
    start_index = 0
    end_index = 3
    token = Token(value, start_index, end_index, content)
    content_ = "123456789"
    value_ = 123
    start_index_ = 1
    end_index_ = 3
    token_ = Token(value_, start_index_, end_index_, content_)
    assert token == token
    assert token == token_

# Generated at 2022-06-12 16:13:38.398781
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = ScalarToken(value = 1, start_index = 0, end_index = 1)
    t2 = ScalarToken(value = 1, start_index = 0, end_index = 1)

    assert(t1 == t2)


# Generated at 2022-06-12 16:13:50.010255
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # token1 and token2 have the same value start_index and end_index, so they are equal
    token1 = Token(1, 2, 3)
    token2 = Token(1, 2, 3)
    assert token1 == token2
    # token1 and token2 have the same value, but different start_index, so they are not equal
    token1 = Token(1, 1, 2)
    token2 = Token(1, 2, 3)
    assert token1 != token2
    # token1 and token2 have the same value, but different end_index, so they are not equal
    token1 = Token(1, 1, 2)
    token2 = Token(1, 1, 3)
    assert token1 != token2
    # token1 and token2 have the different values, so they are not equal

# Generated at 2022-06-12 16:13:54.499616
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": "b"}, 0, 1, "content")
    assert token._value == {"a": "b"}
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == "content"


# Generated at 2022-06-12 16:13:57.492299
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {}
    dt = DictToken(d, 0, 0)
    assert isinstance(dt, Token)
    assert dt._value == {}


# Generated at 2022-06-12 16:14:06.293323
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class A(Token):
        def __init__(self, value, start_index, end_index, content):
            self._value = value
            self._start_index = start_index
            self._end_index = end_index
            self._content = content
        def _get_value(self):
            return self._value
        def _get_child_token(self, key):
            return self
        def _get_key_token(self, key):
            return self

    assert A(10,0,0,'FakeContent')==A(10,0,0,'DiffContent')



# Generated at 2022-06-12 16:14:25.405802
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # The value is a scalar
    value = "foo"
    start_index = 0
    end_index = len(value) - 1
    # The start index is different in the first token
    first_token = ScalarToken(value, start_index+1, end_index)
    # The end index is different in the second token
    second_token = ScalarToken(value, start_index, end_index+1)
    # The value is different in the third token
    third_token = ScalarToken(value+"s", start_index, end_index)
    # The value is a dictionary
    value = {"a": "b"}
    start_index = 0
    end_index = len(str(value)) - 1
    # The start index is different in the first token

# Generated at 2022-06-12 16:14:30.404283
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_a = ScalarToken(2, 0, 2, '12')
    token_b = ScalarToken('3', 1, 2, '12')
    token_c = ScalarToken(2, 0, 2, '12')
    assert token_a.__eq__(token_b) == False
    assert token_a.__eq__(token_c) == True


# Generated at 2022-06-12 16:14:37.896604
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    position_1 = Position(1,1,1)
    position_1_1 = Position(1,1,2)
    
    token_1 = Token(1, position_1, position_1_1)
    assert token_1.__eq__(token_1) == True

    token_2 = Token(2, position_1, position_1_1)
    assert token_1.__eq__(token_2) == False


# Generated at 2022-06-12 16:14:42.963657
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1,1,1) == Token(1,1,1)
    assert not (Token(1,1,1) == Token(1,2,2))
    assert not (Token(1,1,1) == Token(2,1,1))
    assert not (Token(1,1,1) == list())

# Generated at 2022-06-12 16:14:54.114790
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert ScalarToken(None, 1, 1, "") == ScalarToken(None, 1, 1, "")
    assert DictToken({}, 1, 1, "") == DictToken({}, 1, 1, "")
    assert ListToken([], 1, 1, "") == ListToken([], 1, 1, "")

    assert ScalarToken(1, 1, 1, "") == ScalarToken(1, 1, 1, "")
    assert DictToken({1: 1}, 1, 1, "") == DictToken({1: 1}, 1, 1, "")
    assert ListToken([1], 1, 1, "") == ListToken([1], 1, 1, "")

    assert ScalarToken(1, 2, 2, "") == ScalarToken(1, 2, 2, "")

# Generated at 2022-06-12 16:14:56.096290
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken({"a": 1, "b": 2}, 0, 3, "a1b2")

# Generated at 2022-06-12 16:15:06.793236
# Unit test for method __eq__ of class Token

# Generated at 2022-06-12 16:15:15.006428
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class ConcreteToken(Token):
        def __init__(self, value, start_index, end_index, content=''):
            super().__init__(value, start_index, end_index, content)
        def _get_value(self):
            return self._value
    token1 = ConcreteToken(1, 2, 3)
    token2 = ConcreteToken(1, 2, 3)
    token3 = ConcreteToken(2, 2, 3)
    token4 = ConcreteToken(1, 3, 3)
    token5 = ConcreteToken(1, 2, 4)
    assert token1 == token2
    assert not token1 == token3
    assert not token1 == token4
    assert not token1 == token5
    assert not token1 == 2
    assert not token1 == None


# Generated at 2022-06-12 16:15:18.134812
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token('1111', 1, 2)
    assert token == token
    assert token == Token('1111', 1, 2)

# Generated at 2022-06-12 16:15:20.368355
# Unit test for constructor of class DictToken
def test_DictToken():
  t = DictToken(value={}, start_index=0, end_index=0)
  return t


# Generated at 2022-06-12 16:15:35.605120
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {Token(1, 1, 2): Token(2, 1, 2)}
    assert DictToken(d, 1, 2)._value == d


# Generated at 2022-06-12 16:15:38.197019
# Unit test for constructor of class DictToken
def test_DictToken():  # pragma: nocover
    # TODO: Implement
    pass


# Generated at 2022-06-12 16:15:39.732977
# Unit test for constructor of class DictToken
def test_DictToken():
    a=DictToken()
    assert a != None


# Generated at 2022-06-12 16:15:46.835625
# Unit test for constructor of class DictToken
def test_DictToken():
    def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
        super().__init__(*args, **kwargs)
        self._child_keys = {k._value: k for k in self._value.keys()}
        self._child_tokens = {k._value: v for k, v in self._value.items()}
    assert(__init__==DictToken.__init__)

# Generated at 2022-06-12 16:15:50.025447
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken("a",1,1,content="a");
    # test return value of method __init__
    assert repr(a) == "DictToken('a')"

# Generated at 2022-06-12 16:15:58.178097
# Unit test for constructor of class DictToken
def test_DictToken():
    expected_child_keys = {1: None, 2: None}
    expected_child_tokens = {1: None, 2: None}
    expected_value = {1: None, 2: None}

    token = DictToken(
        1, 2, 3, value={1: None, 2: None}, content="[1, 2, 3]"
    )

    print(token)
    print(token._child_keys)
    print(token._child_tokens)
    print(token._value)

    # AssertionError
    assert token._child_keys == expected_child_keys
    assert token._child_tokens == expected_child_tokens
    assert token._value == expected_value


# Generated at 2022-06-12 16:16:09.586460
# Unit test for constructor of class DictToken
def test_DictToken():
    key1 = ScalarToken('key1', 0, 3, "key1")
    token1 = ScalarToken('value1', 4, 8, "value1")
    key2 = ScalarToken('key2', 9, 12, "key2")
    token2 = ScalarToken('value2', 13, 17, "value2")

    dict1 = {key1: token1, key2: token2}
    dictToken = DictToken(dict1, 0, 17, "key1value1key2value2")

    assert dictToken._get_value() == {'key1': 'value1', 'key2': 'value2'}
    assert dictToken._get_child_token('key1') == token1
    assert dictToken._get_child_token('key2') == token2


# Generated at 2022-06-12 16:16:19.394645
# Unit test for constructor of class DictToken
def test_DictToken():
    tok = DictToken({'a':1, 'b':2}, 1, 3)
    assert tok.start == Position(1, 1, 1)
    assert tok.end == Position(1, 3, 3)
    assert tok.value == {'a': 1, 'b': 2}
    assert tok.string == '{"a": 1, "b": 2}'
    assert tok.lookup('a') == 1
    assert tok.lookup('b') == 2
    assert tok.lookup_key('a') == 1
    assert tok.lookup_key('b') == 2


# Generated at 2022-06-12 16:16:22.397068
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(
        {"a": 1, "b": 2},
        10,
        20,
        content="""{"a": 1, "b": 2}""",
    )
    print(token)

# Generated at 2022-06-12 16:16:29.080963
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken(
        {"a": 1, "b": 2},
        1,
        6,
        content="{'a': 1, 'b': 2}",
    )
    assert t.string == "{'a': 1, 'b': 2}"
    assert t.value == {"a": 1, "b": 2}
    assert t.start == Position(1, 1, 0)
    assert t.end == Position(1, 17, 16)

# Generated at 2022-06-12 16:16:57.110504
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"key": "value"}, 1, 2)._value == {"key": "value"}


# Generated at 2022-06-12 16:17:02.880452
# Unit test for constructor of class DictToken
def test_DictToken():
    obj = DictToken(value={"key": "value"}, start_index=1, end_index=2, content="content")
    assert obj._value == {"key": "value"}, "Test 1 failed"
    assert obj._start_index == 1, "Test 2 failed"
    assert obj._end_index == 2, "Test 3 failed"
    assert obj._content == "content", "Test 4 failed"



# Generated at 2022-06-12 16:17:05.312248
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken(value={"1":"1", "2":"2"}, start_index=1, end_index=2, content="test") != None


# Generated at 2022-06-12 16:17:15.790405
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test constructor of class DictToken
    a = DictToken({}, 0, 2, content = "")
    if not a :
        print("test_DictToken 1 passed")
    else:
        print("test_DictToken 1 failed")
    b = DictToken({}, 0, 2, content = "")
    if not b :
        print("test_DictToken 2 passed")
    else:
        print("test_DictToken 2 failed")
    c = DictToken({}, 0, 2, content = "")
    if not c :
        print("test_DictToken 3 passed")
    else:
        print("test_DictToken 3 failed")


# Generated at 2022-06-12 16:17:25.424024
# Unit test for constructor of class DictToken
def test_DictToken():
    args = (1, 2, 3)
    kwargs = {'key1' : 'value1', 'key2' : 'value2'}
    dt = DictToken(*args, **kwargs)
    assert(dt._value == kwargs)
    assert(dt._start_index == args[0])
    assert(dt._end_index == args[1])
    assert(dt._content == args[2])
    assert(dt._child_keys == {'key1' : kwargs['key1'], 'key2' : kwargs['key2']})
    assert(dt._child_tokens == {'key1' : kwargs['key1'], 'key2' : kwargs['key2']})


# Generated at 2022-06-12 16:17:31.524811
# Unit test for constructor of class DictToken
def test_DictToken():
    start_index = 0
    end_index = 11
    content = "{'a': 1}"
    value = {1:1}
    dict_token = DictToken(value, start_index, end_index, content)

    assert dict_token.value == value
    assert dict_token.value[1] == 1
    assert dict_token.string == "{'a': 1}"



# Generated at 2022-06-12 16:17:41.600476
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({(1,2) : 2},0,20)
    print(a)
    print(a._child_keys)
    print(a._child_keys[(1,2)])
    print(a.end)
    print(a.start)
    print(a.string)
    print(a.value)
    print(a.lookup([(1,2)]))
    print(a.lookup_key([(1,2)]))
    #print(a._get_position(20))
    print(a.__eq__(a))
    print(a.__hash__())
    print(a.__repr__())


# Generated at 2022-06-12 16:17:43.926031
# Unit test for constructor of class DictToken
def test_DictToken():
  dt = DictToken()
  assert dt._child_keys == {}
  assert dt._child_tokens == {}

# Generated at 2022-06-12 16:17:47.614158
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken(
        value={}, start_index=0, end_index=0, content=""
    )
    assert (isinstance(dict_token, DictToken))
    assert (isinstance(dict_token, Token))


# Generated at 2022-06-12 16:17:53.467338
# Unit test for constructor of class DictToken
def test_DictToken():
    tk = DictToken({"a": 1, "b": 2},0,0,"ab")
    assert tk._child_keys == {"a": "a", "b": "b"}

    assert str(tk._child_tokens) == "{'a': a, 'b': b}"

# Generated at 2022-06-12 16:18:37.510055
# Unit test for constructor of class DictToken
def test_DictToken():
    print(DictToken({"a": 1, "b": 2}, 0, 10, "DictToken"))


# Generated at 2022-06-12 16:18:48.405448
# Unit test for constructor of class DictToken
def test_DictToken():
    from json import loads
    from typesystem.base.string_format import loads as deserialize
    from typesystem.base.string_format import dumps as serialize
    from typesystem.base.string_format import tokenize_content as tokenize
    from typesystem.base.string_format import dump_tokens as detokenize

    def assertEqual(a, b):
        assert a == b

    def assertTrue(a):
        assert a

    def assertDictEqual(a, b):
        assert a == b

    def assertListEqual(a, b):
        assert a == b


# Generated at 2022-06-12 16:18:58.364026
# Unit test for constructor of class DictToken
def test_DictToken():
    # Initial test
    print("\n" + "Initial Test: ")
    global Dictionary_token
    Dictionary_token = DictToken({"a": 1, "b": 2}, 1, 13)
    print(Dictionary_token._get_value())
    print(Dictionary_token.start)
    print(Dictionary_token.end)
    print(Dictionary_token.string)
    print(Dictionary_token._get_child_token("b"))
    print(Dictionary_token._get_key_token("b"))
    print(Dictionary_token.lookup([0]))
    print(Dictionary_token.lookup_key([0]))

    # Second test
    print("\n" + "Second Test: ")
    print(Dictionary_token._get_value())

# Generated at 2022-06-12 16:19:01.421040
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({}, 0, 0)
    assert isinstance(token, Token)
    assert token._value == {}


# Generated at 2022-06-12 16:19:02.346625
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken([],[]) is None

# Generated at 2022-06-12 16:19:14.131373
# Unit test for constructor of class DictToken
def test_DictToken():
    a = 'a'
    b = 'b'
    c = 'c'
    a_token = ScalarToken(a, 0, 0)
    b_token = ScalarToken(b, 0, 0)
    c_token = ScalarToken(c, 0, 0)
    value = {a_token: b_token, c_token: c_token}
    d_token = DictToken(value, 0, 0, '')
    assert d_token._child_keys == {a_token._value: a_token,
                                   c_token._value: c_token}
    assert d_token._child_tokens == {a_token._value: b_token,
                                     c_token._value: c_token}
    assert d_token._value == value


# Generated at 2022-06-12 16:19:17.485036
# Unit test for constructor of class DictToken
def test_DictToken():
    assert_that(DictToken({}, 0, 1, "abc")._child_tokens, equal_to({}))
    assert_that(DictToken({}, 0, 1, "abc")._child_keys, equal_to({}))
    assert_that(DictToken({}, 0, 1, "abc")._content, equal_to("abc"))


# Generated at 2022-06-12 16:19:18.797694
# Unit test for constructor of class DictToken
def test_DictToken():
    test = DictToken()
    assert test['a'] == 1

# Generated at 2022-06-12 16:19:23.340034
# Unit test for constructor of class DictToken
def test_DictToken():
  dt = DictToken("a","1","3","content")
  assert dt._value == "a"
  assert dt._start_index =="1"
  assert dt._end_index == "3"
  assert dt._content == "content"


# Generated at 2022-06-12 16:19:35.061110
# Unit test for constructor of class DictToken
def test_DictToken():
    import ast
    import os
    import typesystem
    
    directory = os.path.dirname(os.path.relpath(__file__)).replace('\\','/') + '/'
    filename = 'example_schema.py'
    filepath = directory + filename
    
    # Open the file and parse it
    with open(filepath) as file:
        input = file.read()
        parsed = ast.parse(input, filename)
        
    # Extract the schema object    
    for node in ast.walk(parsed):
        if isinstance(node, ast.Assign):
            for target in node.targets:  
                if isinstance(target, ast.Name):
                    if target.id == 'schema':
                        # This is the AST node of the schema object
                        schema_node = node.value

# Generated at 2022-06-12 16:20:55.934519
# Unit test for constructor of class DictToken
def test_DictToken():
    assert True # constructed a dict token

# Generated at 2022-06-12 16:20:57.488705
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken(dict())
    assert(dt is not None)


# Generated at 2022-06-12 16:21:01.354665
# Unit test for constructor of class DictToken
def test_DictToken():
    start_index = 0
    end_index = 1
    content = "hello world"
    token1 = ScalarToken(1, start_index, end_index, content)
    token2 = ScalarToken(2, start_index, end_index, content)
    d = DictToken({token1: token2}, start_index, end_index, content)
    return True



# Generated at 2022-06-12 16:21:06.623145
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(value={}, start_index=0, end_index=0)
    assert token._value == {}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""


# Generated at 2022-06-12 16:21:09.767725
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken({})
    assert dict_token._get_value() == {}
    assert dict_token._get_child_token(0) == None


# Generated at 2022-06-12 16:21:13.228960
# Unit test for constructor of class DictToken
def test_DictToken():
  try:
    token = DictToken(
      {"key": ScalarToken("value", 0, 0)},
      0,
      4,
      content="content",
    )
  except:
    return False
  return True


# Generated at 2022-06-12 16:21:14.624670
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken


# Generated at 2022-06-12 16:21:21.124666
# Unit test for constructor of class DictToken
def test_DictToken():
    expected_value = {'one': 'two'}
    token_obj = DictToken(expected_value, 1, 2, "test")
    assert token_obj._value == expected_value
    assert token_obj.string == 'test'
    assert token_obj._start_index == 1
    assert token_obj._end_index == 2
    assert token_obj.start == (1, 2, 1)
    assert token_obj.end == (1, 2, 2)
    assert token_obj.value == expected_value


# Generated at 2022-06-12 16:21:25.253449
# Unit test for constructor of class DictToken
def test_DictToken():
    testDictToken = DictToken(value={"a":5,"b":6}, start_index=1, end_index=2, content="asdf")
    assert testDictToken._value == {"a":5,"b":6}
    assert testDictToken._start_index == 1
    assert testDictToken._end_index == 2
    assert testDictToken._content == "asdf"


# Generated at 2022-06-12 16:21:28.431602
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(content='{ "mrna_id": "XLOC_009123", "gene_id": "XLOC_009123"...}', start_index=0, end_index=19, value={"mrna_id": "XLOC_009123", "gene_id": "XLOC_009123"})