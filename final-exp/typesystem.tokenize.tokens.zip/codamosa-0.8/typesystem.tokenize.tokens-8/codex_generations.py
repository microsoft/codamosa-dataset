

# Generated at 2022-06-12 16:12:21.906813
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken(value=dict(), start_index=2, end_index=3, content='xxx')
    assert t._child_keys == {}, 'failed constructor'
    assert t._child_tokens == {}, 'failed constructor'
    assert t.start == Position(1, 1, 2), 'failed constructor'
    assert t.end == Position(1, 1, 3), 'failed constructor'
    assert t.string == 'x', 'failed constructor'
    assert t.value == dict(), 'failed constructor'
    assert t._get_value() == dict(), 'failed constructor'
    assert t._get_child_token('x') == None, 'failed constructor'
    assert t._get_key_token('x') == None, 'failed constructor'
    assert t.lookup('x') == None, 'failed constructor'
   

# Generated at 2022-06-12 16:12:32.730844
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test with None as expected value
    assert Token(None, None, None) == None
    # Test with Token as expected value
    assert Token(None, None, None) == Token(None, None, None)
    # Test with a different Token as expected value
    assert not Token(None, None, None) == Token(None, 0, None)
    assert not Token(None, None, None) == Token(0, None, None)
    assert not Token(None, None, None) == Token(None, None, 0)
    # Test with some other value as expected value
    assert not Token(None, None, None) == 0
    assert not Token(None, None, None) == ()
    assert not Token(None, None, None) == []
    assert not Token(None, None, None) == {}

# Generated at 2022-06-12 16:12:33.721846
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({})



# Generated at 2022-06-12 16:12:36.596516
# Unit test for constructor of class DictToken
def test_DictToken():
  d = DictToken({}, 1, 2, "")
  assert (d.start == Position(1, 1, 1))
  

# Generated at 2022-06-12 16:12:39.596248
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken(value = "", start_index = "", end_index = "", content = "")

# Generated at 2022-06-12 16:12:42.276074
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token("value", 0, 2, content = "foo")
    other = Token("value", 0, 2, content = "foo")
    print(f'{token==other}')

# Generated at 2022-06-12 16:12:46.806273
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token('1', 0, 1, '123')
    token11 = Token('1', 0, 1, '123')
    token2 = Token('2', 0, 1, '123')
    token3 = Token('1', 0, 2, '123')
    token4 = Token('1', 1, 2, '123')
    assert token1 == token2
    assert token1 == token11
    assert token1 != token3
    assert token1 != token4

# Generated at 2022-06-12 16:12:50.765309
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_1 = Token(1, 2, 3)
    token_2 = Token(1, 2, 3)
    assert token_1 == token_2
    token_2_2 = Token(2, 2, 3)
    assert token_1 != token_2_2


# Generated at 2022-06-12 16:12:53.221382
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # FIXME: someday, recreate the test from the actual Token
    assert False



# Generated at 2022-06-12 16:12:57.205996
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert (
        Token(value="", start_index=0, end_index=0)
        == Token(value="", start_index=0, end_index=0)
    )


# Generated at 2022-06-12 16:13:09.448268
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    start_index = 0
    end_index = 1
    content = ""
    token = Token(10, start_index, end_index, content)
    assert token == token
    assert not (token != token)
    # __eq__ is reflexive
    assert token == token
    assert not (token != token)
    # __eq__ is symmetric
    other = Token(10, start_index, end_index, content)
    assert token == other
    assert other == token
    assert not (token != other)
    assert not (other != token)
    # __eq__ is transitive
    another = Token(10, start_index, end_index, content)
    assert token == another
    assert another == other
    assert token == other
    assert not (token != another)
    assert not (another != other)

# Generated at 2022-06-12 16:13:13.774030
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = ScalarToken(1, 2, 3)
    t2 = ScalarToken(1, 2, 3)
    t3 = ScalarToken('a', 2, 3)
    t4 = ScalarToken(1, 1, 3)

    assert t1 == t2
    assert t1 != t3
    assert t1 != t4


# Generated at 2022-06-12 16:13:18.685315
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """
    Test method __eq__ of class Token
    """
    # Case 1
    token1 = Token(1, 1, 1)
    token2 = Token(2, 2, 2)
    assert token1 == token1
    assert not (token1 == token2)
    assert not (token1 == None)


# Generated at 2022-06-12 16:13:24.488022
# Unit test for constructor of class DictToken
def test_DictToken():
    a = dict()
    a['a'] = 'a'
    # Test if the constructor of class DictToken is correct
    assert isinstance(DictToken(a, 0, 3, 'a'), DictToken)
    # Test the return type of the constructor 
    assert isinstance(DictToken(a, 0, 3, 'a'), DictToken)
    # Test if the constructor correctly takes arguments
    assert DictToken(a, 0, 3, 'a')._value == {'a':'a'}


# Generated at 2022-06-12 16:13:27.169548
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert ScalarToken(10, 0, 0) == ScalarToken(10, 0, 0)

# Generated at 2022-06-12 16:13:32.213953
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(2, 3, 4) == Token(1, 2, 3)
    assert not Token(1, 1, 2) == Token(1, 2, 3)
    assert not Token(1, 2, 2) == Token(1, 2, 3)
    assert not Token(1, 2, 3) == None
    assert not Token(1, 2, 3) == 2

# Generated at 2022-06-12 16:13:39.304354
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a":ScalarToken("a", 1, 2)}, 0, 2)
    b = DictToken({"b":ScalarToken("b", 2, 3)}, 1, 3)
    assert a._child_tokens == {"a": ScalarToken("a", 1, 2)}
    assert b._child_tokens == {"b": ScalarToken("b", 2, 3)}
    assert a._child_keys == {}
    assert b._child_keys == {}
    assert a._value == {"a": ScalarToken("a", 1, 2)}
    assert b._value == {"b": ScalarToken("b", 2, 3)}
    assert a._start_index == 0
    assert b._start_index == 1
    assert a._end_index == 2
    assert b._end_index

# Generated at 2022-06-12 16:13:51.023401
# Unit test for constructor of class DictToken
def test_DictToken():
    _content = "content"
    _value = {"key": "value"}
    dt = DictToken(_value, 0, 1, _content)
    assert dt.string == ""
    assert dt._value == {"key": "value"}
    assert dt.value == {"key": "value"}
    assert dt.start == Position(1, 1, 0)
    assert dt.end == Position(1, 1, 0)
    assert dt.lookup([0]) == "value"
    assert dt.lookup_key([0,0]) == "key"
    assert dt.__repr__() == "DictToken('')"
    assert dt.__eq__(dt)
    assert dt.__hash__() == "content".__hash__()


# Generated at 2022-06-12 16:13:55.725536
# Unit test for constructor of class DictToken
def test_DictToken():
    value_dict_token = {'a':'a'}
    start_index = 0
    end_index = 2
    content = 'DictToken'
    DictToken(value_dict_token, start_index, end_index, content)


# Generated at 2022-06-12 16:13:56.930491
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(0, 0, 0, '***') == Token(0, 0, 0, '***')



# Generated at 2022-06-12 16:14:08.396518
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_1 = ScalarToken(None, None, None)
    token_2 = ScalarToken(None, None, None)
    assert token_1 == token_2

# Generated at 2022-06-12 16:14:12.206713
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(None, None, None) == Token(None, None, None)
    assert not Token(None, None, None) == ScalarToken(None, None, None)


# Generated at 2022-06-12 16:14:15.978567
# Unit test for constructor of class DictToken
def test_DictToken():
    try:
        __DictToken = DictToken({}, 1, 2)
    except Exception as __e:
        __exception = __e
    else:
        __exception = None
    assert type(__exception) is TypeError


# Generated at 2022-06-12 16:14:20.300512
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Create an instance of class Token
    token = Token(1, 2, 3)

    # Call method __eq__
    assert(token == ScalarToken(1, 2, 3))
    assert(token != ScalarToken(1, 2, 4))
    assert(token != ScalarToken(2, 2, 3))

# Generated at 2022-06-12 16:14:30.596161
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.types import Dict
    from typesystem.types import String
    token = DictToken({
        ScalarToken("a", 0, 1): ScalarToken("b", 2, 3),
        ScalarToken("c", 4, 5): ScalarToken("d", 6, 7)
    }, 1, 8, "abcdefg")
    assert token._get_value() == {"a": "b", "c": "d"}
    assert token._start_index == 1
    assert token._end_index == 8
    assert token._content == "abcdefg"
    assert token._child_tokens == {
        "a": ScalarToken("b", 2, 3),
        "c": ScalarToken("d", 6, 7)
    }

# Generated at 2022-06-12 16:14:33.394795
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, 0, 2, 'OK')
    assert token.__eq__('OK') == False, "Method Token.__eq__ don't work"
    assert token.__eq__(token) == True, "Method Token.__eq__ don't work"
    
    

# Generated at 2022-06-12 16:14:41.131831
# Unit test for constructor of class DictToken
def test_DictToken():
	position = Position(1, 2, 3)
	
	dict_token = DictToken({"a": ScalarToken(1, position, position)}, 4, 5, content = "abc")
	
	assert dict_token._value == {"a": ScalarToken(1, position, position)}
	assert dict_token._start_index == 4
	assert dict_token._end_index == 5
	assert dict_token._content == "abc"
	

# Generated at 2022-06-12 16:14:43.006350
# Unit test for method __eq__ of class Token
def test_Token___eq__():
  assert ScalarToken(1, 0, 2) == ScalarToken(1, 0, 2)

# Generated at 2022-06-12 16:14:46.378024
# Unit test for constructor of class DictToken
def test_DictToken():
    from .. import Parser
    from .compiler import Compiler

    parser = Parser()
    compiler = Compiler()
    content = """
    "A" : "a",
    "B" : "b"
    """
    token = parser.compile(content)
    assert isinstance(token, DictToken)



# Generated at 2022-06-12 16:14:49.558871
# Unit test for constructor of class DictToken
def test_DictToken():
    # TODO: can't use assert with mypy
    dict1 = {"a": 1,"b": 2}
    dict2 = {"a": 1,"b": 2}
    assert dict1 == dict2


# Generated at 2022-06-12 16:15:04.504998
# Unit test for method __eq__ of class Token
def test_Token___eq__():
	pass

# Generated at 2022-06-12 16:15:13.676711
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    start_index = 1
    end_index = 10
    content = "1234567890"
    value_1 = 432
    value_2 = 765
    scalarToken_1 = ScalarToken(value_1, start_index, end_index, content)
    scalarToken_2 = ScalarToken(value_1, start_index, end_index, content)
    scalarToken_3 = ScalarToken(value_2, start_index, end_index, content)
    scalarToken_4 = ScalarToken(value_1, 11, end_index, content)
    scalarToken_5 = ScalarToken(value_1, start_index, 9, content)
    scalarToken_6 = ScalarToken(value_1, start_index, end_index, "123456789")
    scalarToken

# Generated at 2022-06-12 16:15:20.462718
# Unit test for constructor of class DictToken
def test_DictToken():
    with pytest.raises(NotImplementedError):
        p = Token(1,2,3,"123")
        q = DictToken({},start_index = 1, end_index = 2, content = "test")
        p._get_value()
        p._get_child_token(1)
        p._get_key_token(1)


# Generated at 2022-06-12 16:15:31.312668
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    import json
    import typesystem
    a = typesystem.String()
    content = json.dumps({"a": "hello"})
    index = {"a": [0]}
    i = 0
    start_index = 0
    end_index = 11
    token_a = ScalarToken(a, start_index, end_index, content)
    len_value = 12
    value = json.loads(content)
    token_b = ScalarToken(value, start_index, end_index, content)
    index[a] = [0]
    assert token_a != token_b
    assert token_a.__eq__(token_b) == False
    assert token_b.__eq__(token_a) == False
    token_b._value = token_a._value
    assert token_a != token_

# Generated at 2022-06-12 16:15:33.761040
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.parser import Token
    token1 = Token("", 0, 0)
    token2 = Token("", 0, 0)
    assert token1 == token2


# Generated at 2022-06-12 16:15:35.446977
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    x = Token(1, 2, 3, content="test")
    y = Token(1, 2, 3, content="test")
    assert x == y

# Generated at 2022-06-12 16:15:39.726310
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    expected = True
    actual = False
    try:
        Token.__eq__(object)
    except NotImplementedError:
        actual = True
    assert expected == actual

# Generated at 2022-06-12 16:15:45.274791
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    x=Token(None, 1, 1)
    y=Token(None, 1, 1)
    assert x.__eq__(y) == True
    x=Token(None, 1, 1)
    y=0
    assert x.__eq__(y) == False


# Generated at 2022-06-12 16:15:49.294272
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = ScalarToken(123, 0, 3, "123")
    t2 = ScalarToken(123, 0, 3, "123")
    assert t1 == t2
    assert not (t1 != t2) #pylint: disable=unneeded-not



# Generated at 2022-06-12 16:15:52.659186
# Unit test for constructor of class DictToken
def test_DictToken():
    dic = {'name': 'Paul', 'age': '27'}
    dic_val = dic.values
    dic_key = dic.keys
    assert(dic_val == 'Paul')
    assert(dic_key == 'name')



# Generated at 2022-06-12 16:16:04.983948
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    start_index = 0
    end_index = 5
    content = ''
    a = Token(True, start_index, end_index, content)
    b = Token(True, start_index, end_index, content)

    assert a == b


# Generated at 2022-06-12 16:16:15.558640
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert ScalarToken(10, 0, 2) == ScalarToken(10, 0, 2)
    assert ScalarToken(10, 0, 2) != ScalarToken(11, 0, 2)
    assert ScalarToken(10, 0, 2) != ScalarToken(10, 0, 3)
    assert ScalarToken(10, 0, 2) != ScalarToken(10, 0, 1)
    assert ScalarToken(10, 0, 2) != ScalarToken(10, 1, 2)
    assert ScalarToken(10, 0, 2) != ScalarToken(11, 1, 2)
    assert ScalarToken(10, 0, 2) != ScalarToken(10, 1, 3)
    assert ScalarToken(10, 0, 2) != ScalarToken(10, 1, 1)

# Generated at 2022-06-12 16:16:20.749075
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_1 = Token(1, 2, 3)
    token_2 = Token(1, 2, 3)
    assert token_1 == token_2
    token_3 = Token(2, 3, 4)
    assert token_1 != token_3
    assert token_2 != token_3



# Generated at 2022-06-12 16:16:25.142432
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = ScalarToken(1, 2, 3)
    t2 = ScalarToken(1, 2, 3)
    t3 = ScalarToken(1, 4, 5)
    t4 = ScalarToken(1, 4, 5)
    assert t1 == t2
    assert t3 == t4

# Generated at 2022-06-12 16:16:27.033342
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken({}, 0, 0)
    assert dict_token is not None


# Generated at 2022-06-12 16:16:31.022494
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    obj = Token((), 0, 0)
    assert obj == Token(
        (), 0, 0
    ), "Expected Token(()), 0, 0, to equal Token(()), 0, 0"


scalar = ScalarToken
dict = DictToken
list = ListToken

# Generated at 2022-06-12 16:16:36.198392
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(3, 1, 5) == Token(3, 1, 5)
    assert Token(3, 1, 5) != Token(5, 1, 5)
    assert Token(3, 1, 5) != Token(3, 5, 5)
    assert Token(3, 1, 5) != Token(3, 1, 7)
    assert Token(3, 1, 5) != Token(5, 5, 7)
    assert Token(3, 1, 5) != 5
    assert Token(3, 1, 5) != "3"

# Generated at 2022-06-12 16:16:45.674423
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    def function_for_test_Token___eq__(arg):
        assert isinstance(arg, Token)
        assert type(arg) == ScalarToken
        assert arg.string == "token"
        assert arg.value == "token"
        assert arg.start.line_no == 0
        assert arg.start.column_no == 0
        assert arg.end.line_no == 0
        assert arg.end.column_no == 5
        assert arg.lookup([0]) == ScalarToken("token", 0, 5)
        assert arg.lookup([0]).value == "token"
        assert arg.lookup_key([0, 0]) == ScalarToken("key", 0, 2)
        assert arg.lookup_key([0, 0]).value == "key"
        assert arg == ScalarToken("token", 0, 5)

# Generated at 2022-06-12 16:16:52.303330
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem import Float, Integer
    from typesystem.components import Dict, List

    class DictSchema(Dict):
        foo = Float()
        bar = List(Integer())

    schema = DictSchema()
    tokens = schema.parse("""
    foo: 15.4
    bar:
      - 123
      - 456
    """)
    assert tokens == tokens



# Generated at 2022-06-12 16:16:57.826903
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 1, 1) == Token(1, 1, 1)
    assert Token(1, 1, 1) != Token(2, 1, 1)
    assert Token(1, 1, 1) != Token(1, 2, 1)
    assert Token(1, 1, 1) != Token(1, 1, 2)

# Generated at 2022-06-12 16:17:30.915596
# Unit test for constructor of class DictToken
def test_DictToken():
    x = DictToken(dict(), 0, 10, "{\n abc:123\n}")
    assert(str(x) == "DictToken('{\n abc:123\n}')")
    assert(x.value == {})
    assert(x.string == "{abc:123}")
    assert(x.start.line == 1)
    assert(x.start.column == 1)
    assert(x.start.content_offset == 0)
    assert(x.end.line == 2)
    assert(x.end.column == 2)
    assert(x.end.content_offset == 10)
    assert(x.lookup([]) == x)
    return x

# Generated at 2022-06-12 16:17:32.874145
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {1:2, 3:4}
    assert DictToken(d, 0, 0, "")._value == d


# Generated at 2022-06-12 16:17:33.530282
# Unit test for constructor of class DictToken
def test_DictToken():
    pass

# Generated at 2022-06-12 16:17:36.844298
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {"This": "is", "a": "test"}
    v = DictToken(d, 0, 0)
    assert v



# Generated at 2022-06-12 16:17:44.531515
# Unit test for constructor of class DictToken
def test_DictToken():
    a = {
        ScalarToken(1,2, 3): ScalarToken(2,3, 4)
    }
    dt = DictToken(a, 2, 4)
    assert dt._get_value() == {1:2}
    assert dt._get_child_token(1) == ScalarToken(2,3, 4)
    assert dt._get_key_token(1) == ScalarToken(1,2, 3)


# Generated at 2022-06-12 16:17:46.727921
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken({"a":1},1,2)
    assert dict_token._child_keys == {"a":1}

# Generated at 2022-06-12 16:17:53.688458
# Unit test for constructor of class DictToken
def test_DictToken():
  # test
  assert DictToken(value={}, start_index=0, end_index=0, content='') is not None
  assert DictToken(value={}, start_index=0, end_index=1,content='w') is not None
  assert DictToken(value={}, start_index=1, end_index=1,content='w') is not None
  assert DictToken(value={}, start_index=-1, end_index=1,content='w') is not None
  assert DictToken(value={}, start_index=1, end_index=-1,content='w') is not None
  assert DictToken(value={}, start_index=0, end_index=0,content="") is not None


# Generated at 2022-06-12 16:18:02.761071
# Unit test for constructor of class DictToken
def test_DictToken():
    k1 = ScalarToken(1, 10, 15, "abc")
    k2 = ScalarToken(2, 15, 20, "efg")
    v1 = ScalarToken(3, 15, 20, "efg")
    v2 = ScalarToken(4, 15, 20, "efg")
    t = DictToken({k1: v1, k2: v2}, 10, 20, "abc")
    assert [k1, k2] == t._value.keys()
    assert [v1, v2] == t._value.values()
    assert k1 == t._get_child_token(1)
    assert k2 == t._get_child_token(2)
    assert v1 == t._get_child_token(3)
    assert v2 == t._get_child_token(4)

# Generated at 2022-06-12 16:18:14.030427
# Unit test for constructor of class DictToken
def test_DictToken():

    # Constuctor test 1
    try: 
        d = DictToken()
    except:
        assert False
    else:
        assert True
    
    # Constuctor test 2
    try: 
        t = DictToken(1.2, 3, 5, 8)
    except:
        assert False
    else:
        assert True
        
    # Constuctor test 3 
    try: 
        t = DictToken(1.2, 3, 5, 8, foo='bar')
    except:
        assert False
    else:
        assert True
        
    # Constuctor test 4

# Generated at 2022-06-12 16:18:18.950985
# Unit test for constructor of class DictToken
def test_DictToken():
    a = '{"key1":"val1", "key2":"val2"}'
    b = DictToken({'key1': 'val1', 'key2': 'val2'}, 0, 14)
    if a == repr(b):
        print("test_DictToken test passed!")
        print(a)
        print(repr(b))
    else:
        print("test_DictToken test failed!")
        print(a)
        print(repr(b))


# Generated at 2022-06-12 16:18:39.760638
# Unit test for constructor of class DictToken
def test_DictToken():
    # Case where key is a primitive type
    dict_value = {"key" : "1"}
    dict_token = DictToken(dict_value, 0, 4, "test")
    assert dict_token._value == dict_value


# Generated at 2022-06-12 16:18:43.604731
# Unit test for constructor of class DictToken
def test_DictToken():
    test = '{"test":2}'
    start_index = 0
    end_index = len(test) - 1
    content = None
    offset = 7
    length = 1
    DictToken(test, start_index, end_index, content, offset, length)
    return None

# Generated at 2022-06-12 16:18:44.732317
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({}, 0, 0)
    assert token


# Generated at 2022-06-12 16:18:45.710540
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken()


# Generated at 2022-06-12 16:18:56.859207
# Unit test for constructor of class DictToken
def test_DictToken():
    content = "project:"
    start_index = 0
    end_index = len(content) - 1

    # case1
    token = DictToken(dict(), start_index, end_index, content)
    assert(token.value == dict())

    # case2
    token = DictToken(dict(), start_index, end_index, content)
    assert(token.start == Position(1, 9, 8))
    assert(token.end == Position(1, 9, 8))

    # case3
    token = DictToken(dict(), start_index, end_index, content)
    assert (token.string == "project:")

    # case4
    token = DictToken(dict(), start_index, end_index, content)
    assert (str(token) == "DictToken('project:')")




# Generated at 2022-06-12 16:19:08.594451
# Unit test for constructor of class DictToken
def test_DictToken():
    tokenA = DictToken(ScalarToken(None,1,5),1,5,content='{}')
    tokenB = DictToken(ScalarToken(None,2,4),2,4,content='{1}')
    tokenC = DictToken(ScalarToken(None,3,3),3,3,content='{12}')
    print(tokenA._child_keys) # it is empty
    print(tokenB._child_keys) # it has one key: tokenA
    print(tokenC._child_keys) # it has one key: tokenB
    print(tokenA._child_tokens) # it is empty
    print(tokenB._child_tokens) # it has one value of tokenB
    print(tokenC._child_tokens) # it has one value of token

# Generated at 2022-06-12 16:19:10.032884
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken({"a":1})
    return t


# Generated at 2022-06-12 16:19:11.623043
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken({"a": 1}, 0, 10)


# Generated at 2022-06-12 16:19:16.875751
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 1, 'b': 2, 'c': 3}
    token = DictToken(d, 1, 2, content="abcd")
    assert token._value == d
    assert token._start_index == 1
    assert token._end_index == 2
    assert token._content == "abcd"
    return

test_DictToken()

# Generated at 2022-06-12 16:19:18.666533
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken(value = {}, start_index = 0, end_index = 0)


# Generated at 2022-06-12 16:19:57.717849
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {Token('a', 0, 0): Token('b', 0, 0)}
    t = DictToken(d, 0, 0)
    assert t._value == d
    assert t._child_tokens == {'a': Token('b', 0, 0)}
    assert t._child_keys == {'a': Token('a', 0, 0)}


# Generated at 2022-06-12 16:20:05.793668
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import Tokenizer
    from typesystem.base import Position
    from typesystem.base import Token

    tokenizer = Tokenizer({"a": 1})
    assert tokenizer._tokenize() == DictToken(
        value=
        {
            ScalarToken(value="a", start_index=2, end_index=2, content={"a": 1}):
            ScalarToken(value=1, start_index=5, end_index=5, content={"a": 1})
        },
        start_index=1,
        end_index=6,
        content={"a": 1},
    )

    tokenizer = Tokenizer({"a": 1, "b": 2})

# Generated at 2022-06-12 16:20:08.683283
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken.__init__(DictToken, value ="value", start_index = 1, end_index = 2, content = "") == None

# Generated at 2022-06-12 16:20:20.400675
# Unit test for constructor of class DictToken
def test_DictToken():
    source = '"a": { "b": 1, "d": 2 }, "c": 3'
    token = scalar_token(source, None)
    assert token.string == source
    assert token.start == Position(line_no=1, column_no=1, index=1)
    assert token.end == Position(line_no=1, column_no=9, index=9)
    assert token.value == None
    # Unit test for method lookup_key of class DictToken
    def test_DictToken_lookup_key():
        assert token.lookup_key([0]).string == '"a"'
        assert token.lookup_key([0]).value == 'a'
        assert token.lookup_key([1]).string == '"c"'

# Generated at 2022-06-12 16:20:28.388377
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test 1
    token = DictToken(None, None, None, content=None)

    assert(token._value == None)
    assert(token._start_index == None)
    assert(token._end_index == None)
    assert(token._content == None)
    assert(token._child_keys == {})
    assert(token._child_tokens == {})

    # Test 2
    token = DictToken(None, None, None, content={'a': 1})

    assert(token._value == None)
    assert(token._start_index == None)
    assert(token._end_index == None)
    assert(token._content == {'a': 1})
    assert(token._child_keys == {})
    assert(token._child_tokens == {})

    # Test 3
   

# Generated at 2022-06-12 16:20:34.230981
# Unit test for constructor of class DictToken
def test_DictToken():
    k = ScalarToken(value = 1, start_index = 0, end_index = 1)
    d = ScalarToken(value = 2, start_index = 1, end_index = 2)
    a = DictToken(value = {k: d}, start_index = 0, end_index = 2, content = "12")
    assert a


# Generated at 2022-06-12 16:20:37.207483
# Unit test for constructor of class DictToken
def test_DictToken():
    print("Test: test_DictToken")
    value = {"a": "b"}
    start_index = 1
    end_index = 2
    content = "a"
    assert DictToken(value, start_index, end_index, content) != None


# Generated at 2022-06-12 16:20:37.912427
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken()

# Generated at 2022-06-12 16:20:39.516854
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken({"a":1}, 1,1,"ab")


# Generated at 2022-06-12 16:20:41.624632
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken(None,3,2,content="test")


# Generated at 2022-06-12 16:21:52.683769
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken( {}, 0 , 1, 'abc')


# Generated at 2022-06-12 16:21:56.087133
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken(None, None, None)
    DictToken(None, None, None, None)
    DictToken(None, None, None, None, None)


# Generated at 2022-06-12 16:22:05.087965
# Unit test for constructor of class DictToken
def test_DictToken():  
    myDict = {}
    myDict[1] = 1
    myDict[2] = 2
    myDict["3"] = 3
    myDict["4"] = 4
    myToken = DictToken(myDict,start_index=0, end_index=1, content="abcderr")
    assert myToken._child_keys[1] == 1
    assert myToken._child_keys[2] == 2
    assert myToken._child_keys["3"] == 3
    assert myToken._child_keys["4"] == 4
    assert myToken._child_tokens[1] == 1
    assert myToken._child_tokens[2] == 2
    assert myToken._child_tokens["3"] == 3
    assert myToken._child_tokens["4"] == 4


# Generated at 2022-06-12 16:22:15.226395
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.builders import JsonTokenBuilder

    json_token_builder = JsonTokenBuilder()
    data = {
        "people": {
            "Angel": {
                "age": 25,
                "location": "San Francisco, California",
                "skills": ["Python", "Javascript"],
            },
            "John": {
                "age": 32,
                "location": "New York, New York",
                "skills": ["Python", "Java"],
            },
        }
    }
    tokens = json_token_builder.build(data)
    assert tokens.string == json.dumps(data)
    assert tokens.value == data
    assert tokens.start == Position(1, 1, 0)
    assert tokens.end == Position(18, 1, 17)
    assert tokens.lookup(["people"])