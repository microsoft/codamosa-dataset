

# Generated at 2022-06-12 16:12:19.937102
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 10, 12) == Token(1, 10, 12)
    assert Token(1, 10, 12) != Token(1, 11, 12)
    assert Token(1, 10, 12) != Token(2, 10, 12)
    assert Token(1, 10, 12) != Token(1, 10, 13)
    assert Token(1, 10, 12) != Token(2, 10, 13)

# Generated at 2022-06-12 16:12:29.723394
# Unit test for constructor of class DictToken
def test_DictToken():
    value = {
        ScalarToken("foo", 1, 3): ScalarToken("bar", 5, 7),
        ScalarToken("hello", 10, 14): ScalarToken("world", 16, 20),
    }
    start_index = 0
    end_index = 20
    content = ""
    temp = DictToken(value, start_index, end_index, content)
    # expected output: {'foo': 'bar', 'hello': 'world'}
    print(temp._get_value())
    assert(temp._get_value() == {'foo': 'bar', 'hello': 'world'})


# Generated at 2022-06-12 16:12:30.310164
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken("", 0, 0, "")._value == {}


# Generated at 2022-06-12 16:12:33.418156
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = ScalarToken(1, 0, 2)
    t2 = ScalarToken(2, 0, 2)
    assert not (t1 == t2)
    t2._value = 1
    assert t1 == t2


test_Token___eq__()

# Generated at 2022-06-12 16:12:35.413008
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 1, 2) == Token(1, 1, 2)

# Generated at 2022-06-12 16:12:43.042889
# Unit test for method __eq__ of class Token
def test_Token___eq__():

    class FakeToken:
        def __init__(self, value, start_index, end_index) -> None:
            self._value = value
            self._start_index = start_index
            self._end_index = end_index
        def __eq__(self, other: typing.Any) -> bool:
            return isinstance(other, self.__class__) and (
                    self._value == other._value
                    and self._start_index == other._start_index
                    and self._end_index == other._end_index
                )

    token_true = FakeToken("a", 2, 3)
    token_false = FakeToken("a", 2, 4)

    assert token_true == token_true
    assert not token_true == token_false
    assert not token_false == token_true

# Generated at 2022-06-12 16:12:51.550388
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t = Token(value = '', start_index = 0, end_index = 0, content = '')
    # Test when the types are different
    other = ''
    assert not t.__eq__(other)
    other = Token(value = '', start_index = 0, end_index = 0, content = '')
    # Test when the values are different
    other._value = 'value'
    assert not t.__eq__(other)
    other = Token(value = '', start_index = 0, end_index = 0, content = '')
    # Test when the start_indexes are different
    other._start_index = 1
    assert not t.__eq__(other)
    other = Token(value = '', start_index = 0, end_index = 0, content = '')
    # Test when the end

# Generated at 2022-06-12 16:12:54.499243
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(
        None, None, None
    )  # this definition of the Token object is only for the unit test

    # type of the return value is bool
    assert_equal(
        type(token.__eq__),
        bool
    )

    # return True
    assert_true(
        token.__eq__(token)
    )

# Generated at 2022-06-12 16:13:05.653912
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert (Token(value=0, start_index=0, end_index=0) == Token(value=0, start_index=0, end_index=0))
    assert not (Token(value=0, start_index=1, end_index=0) == Token(value=0, start_index=0, end_index=0))
    assert not (ScalarToken(value=0, start_index=0, end_index=0) == ScalarToken(value=1, start_index=0, end_index=0))
    assert not (ScalarToken(value=0, start_index=1, end_index=0) == ScalarToken(value=0, start_index=0, end_index=0))

# Generated at 2022-06-12 16:13:16.229321
# Unit test for constructor of class DictToken
def test_DictToken():
    x = DictToken({"en": "Hal"}, 0, 2, "enHal")
    assert x._start_index == 0
    assert x._end_index == 2
    assert x._content == "enHal"
    assert x._child_keys["en"]._value == "en"
    assert x._child_tokens["en"]._value == "Hal"
    assert x._value.keys() == {ScalarToken("en", 0, 1), ScalarToken("Hal", 0, 2)}
    assert x._value.items() == {
        (ScalarToken("en", 0, 1), ScalarToken("Hal", 0, 2))
    }
    y = {ScalarToken("en", 0, 1): ScalarToken("Hal", 0, 2)}
    assert x._value == y
    # Confirm

# Generated at 2022-06-12 16:13:33.626345
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    _arg_value = typing.Any()
    _arg_start_index = int()
    _arg_end_index = int()
    _arg_content = str()
    _arg_key = typing.Any()
    _arg_self = Token(_arg_value, _arg_start_index, _arg_end_index, _arg_content)
    def _mock_Token__get_value(*_, **__):
        return _arg_value
    _arg_other = Token(_arg_value, _arg_start_index, _arg_end_index, _arg_content)
    _mock_Token__get_value.side_effect = _mock_Token__get_value
    _arg_other._get_value = _mock_Token__get_value

# Generated at 2022-06-12 16:13:37.372016
# Unit test for method __eq__ of class Token
def test_Token___eq__():
	t1 = Token(2, 3, 0)
	t2 = Token(2, 3, 0)
	assert (t1 == t2) == True
	t3 = Token(2, 5, 0)
	assert (t1 == t3) == False
	t4 = Token(2, 3, 6)
	assert (t1 == t4) == False

# Generated at 2022-06-12 16:13:41.027634
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = ScalarToken(123, 0, 1)
    t2 = ScalarToken(123, 0, 1)
    assert t1 == t2
    assert not t1 == ScalarToken(123, 1, 2)


# Generated at 2022-06-12 16:13:53.006555
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class Token:
        def __init__(self, value, start_index, end_index, content = ""):
            self._value = value
            self._start_index = start_index
            self._end_index = end_index
            self._content = content

    class ScalarToken(Token):
        pass

    class DictToken(Token):
        tokens = []
        keys = []

    class ListToken(Token):
        pass

    token1 = ScalarToken(1, 1, 1)
    token2 = ScalarToken(1, 2, 2)
    token3 = ScalarToken(1, 1, 1)
    token4 = ListToken([1, 2], 1, 1)
    token5 = ListToken([1, 2], 1, 1)
    token6 = ListToken([1, 2], 1, 1)



# Generated at 2022-06-12 16:13:59.889549
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Construct parameters for Token
    value = None
    start_index = None
    end_index = None
    content = None
    # Call Token and set return value to variable t1
    t1 = Token(value, start_index, end_index, content)

    # Call Token and set return value to variable t2
    t2 = Token(value, start_index, end_index, content)

    # Compare t1 to t2 and set return value to variable equal
    equal = t1 == t2
    assert equal



# Generated at 2022-06-12 16:14:06.715962
# Unit test for method __eq__ of class Token
def test_Token___eq__():

    # Create instances
    TOKEN_0 = Token('value', 0, 15, 'content')
    TOKEN_1 = Token('value', 0, 15, 'content')
    TOKEN_2 = Token('value', 11, 2, 'content')

    # Call method
    EQ = TOKEN_0 == TOKEN_1
    EQ_0 = TOKEN_0 == TOKEN_2

    # Check results
    assert EQ
    assert not EQ_0


# Generated at 2022-06-12 16:14:13.800722
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    start_index = 0
    end_index = 10
    string = "abcdefghij"
    token1 = Token(
        typing.Any,
        start_index,
        end_index,
        content=string
    )
    token2 = Token(
        typing.Any,
        start_index,
        end_index,
        content=string
    )
    assert(token1 == token2)

    token3 = Token(
        typing.Any,
        start_index + 1,
        end_index,
        content=string
    )
    assert(not(token1 == token3))

    token4 = Token(
        typing.Any,
        start_index,
        end_index - 1,
        content=string
    )
    assert(not(token1 == token4))

    token5 = Token

# Generated at 2022-06-12 16:14:17.553461
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({1: 1}, 0, 4)
    assert d._value == {1: 1}
    assert d._child_tokens == {1: 1}
    assert d._child_keys == {1: 1}
    return True



# Generated at 2022-06-12 16:14:21.145871
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_1_1 = Token(0, 0, 0) # token_1_1 is an instance of class Token.
    token_1_2 = Token(0, 0, 0) # token_1_2 is an instance of class Token.
    token_1_3 = Token(0, 1, 2) # token_1_3 is an instance of class Token.
    assert token_1_1 == token_1_2
    assert (token_1_1 != token_1_3) == True


# Generated at 2022-06-12 16:14:31.050760
# Unit test for method __eq__ of class Token
def test_Token___eq__():
	# Constructor 1
	Token_inst1 = Token(value = None,
				start_index = None,
				end_index = None)
	assert Token_inst1._value == None
	assert Token_inst1._start_index == None
	assert Token_inst1._end_index == None
	# Constructor 2
	Token_inst2 = Token(value = 1,
				start_index = None,
				end_index = None)
	assert Token_inst2._value == 1
	assert Token_inst2._start_index == None
	assert Token_inst2._end_index == None
	# Constructor 3
	Token_inst3 = Token(value = None,
				start_index = 2,
				end_index = None)

# Generated at 2022-06-12 16:14:56.779051
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    _start_index = 0
    _end_index = 0
    _content = ""

    # Try first scalar-type tokens: string, integer, float and boolean
    _A = ScalarToken('string', _start_index, _end_index, _content)
    _B = ScalarToken('string', _start_index, _end_index, _content)
    assert _A == _B

    _A = ScalarToken(1, _start_index, _end_index, _content)
    _B = ScalarToken(1, _start_index, _end_index, _content)
    assert _A == _B

    _A = ScalarToken(1.0, _start_index, _end_index, _content)

# Generated at 2022-06-12 16:15:03.257434
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    tok1 = Token(1, 1, 2, 'abc')
    tok2 = Token(2, 1, 2, 'abc')
    tok3 = Token(1, 1, 2, 'abd')
    tok4 = Token(1, 1, 2, 'abc')
    assert tok1 == tok2 == tok3 == tok4
    assert tok1 == tok1
    assert not tok1 == tok4


# Generated at 2022-06-12 16:15:13.068977
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert ScalarToken(123, 0, 2, "123") == ScalarToken(123, 0, 2, "123")
    assert ScalarToken(123, 0, 2, "123") != ScalarToken(456, 1, 3, "456")
    assert ScalarToken(123, 0, 2, "123") != ScalarToken(123, 1, 3, "123")
    assert ScalarToken(123, 0, 2, "123") != ScalarToken(123, 0, 3, "123")
    assert ScalarToken(123, 0, 2, "123") != ScalarToken(123, 0, 2, "12")
    assert ScalarToken(123, 0, 2, "123") != ScalarToken(123, 0, 2, "1234")
    assert ScalarToken(123, 0, 2, "123") != Scalar

# Generated at 2022-06-12 16:15:23.388359
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.parser.lexer import Lexer
    from typesystem.parser.parser import Parser
    from typesystem.parser.tree import TreeBuilder
    
    s = "10.0"
    lexer = Lexer.from_string(s)
    tokens = lexer.tokenize()
    parser = Parser(tokens)
    tree = parser.parse()
    builder = TreeBuilder.from_json_tree(tree, s)
    token = builder.build()
    
    assert token == token
    assert token == token.lookup([0])
    assert token.lookup([0]) == token


# Generated at 2022-06-12 16:15:24.297130
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    pass


# Generated at 2022-06-12 16:15:27.435035
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    a = Token(1, 2, 3)
    b = Token(1, 2, 3)
    assert a == b



# Generated at 2022-06-12 16:15:36.575405
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Instance creation
    instance_1 = Token(value="abcd", start_index=1, end_index=3)
    instance_2 = Token(value="abcd", start_index=1, end_index=3)
    instance_3 = Token(value="abc", start_index=1, end_index=3)
    instance_4 = Token(value="abcd", start_index=2, end_index=3)
    instance_5 = Token(value="abcd", start_index=1, end_index=4)
    instance_6 = Token(value="abcd", start_index=2, end_index=4)
    # unit test
    assert (instance_1 == instance_2) is True
    assert (instance_1 == instance_3) is False
    assert (instance_1 == instance_4)

# Generated at 2022-06-12 16:15:40.300403
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token("test",0,1)
    token2 = Token("test",0,1)
    token3 = Token("test1",0,1)
    token4 = Token("test",0,2)
    token5 = Token("test",0,1, "test")
    token6 = Token("test",0,1, "test1")
    assert (token1.__eq__(token2))
    assert not (token1.__eq__(token3))
    assert not (token1.__eq__(token4))
    assert not (token1.__eq__(token5))
    assert not (token1.__eq__(token6))

# Generated at 2022-06-12 16:15:50.427136
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Tests the __eq__ method of the Token class
    # Currently only tests a case in the positive.
    # TODO: Add a negative test case to this.
    # Arrange
    p = Position(1, 1, 1)
    ts = Token({"a": "b"}, p, p)
    ts2 = Token({"a": "b"}, p, p)
    # Act
    # Assert
    assert ts.__eq__(ts2) == True

# Generated at 2022-06-12 16:15:59.062714
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Confirm that equality test returns True if two tokens have equal positions and values
    assert Token(value='', start_index=0, end_index=0) == Token(value='', start_index=0, end_index=0)
    # Confirm that equality test returns False if two tokens have unequal positions
    assert Token(value='', start_index=0, end_index=0) != Token(value='', start_index=1, end_index=1)
    assert Token(value='', start_index=0, end_index=0) != Token(value='', start_index=0, end_index=1)
    # Confirm that equality test returns False if two tokens have unequal values

# Generated at 2022-06-12 16:16:07.952051
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert (Token('',0,0,'')) == (Token('',0,0,''))



# Generated at 2022-06-12 16:16:17.470229
# Unit test for method __eq__ of class Token
def test_Token___eq__():
	print("testing method __eq__ of class Token")
	t1 = Token("value_1", 1, 1)
	t2 = Token("value_2", 1, 2)
	t3 = Token("value_1", 1, 1)
	t4 = Token("value_1", 1, 1)
	if not (t1 == t3 and t3 == t4 and not (t2 == t1 or t1 == t2 or t2 == t3 or t2 == t4 or t3 == t2 or t4 == t2)):
		raise Exception("__eq__ method fails test")
	print("     method __eq__ of class Token tested successfully")


# Generated at 2022-06-12 16:16:22.079448
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    a = Token(value=3, start_index=1, end_index=1, content="t")
    b = Token(value=3, start_index=1, end_index=1, content="t")

    assert a.__eq__(b) == True

# Generated at 2022-06-12 16:16:24.077144
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    a = Token(1, 2, 3)
    b = Token(1, 2, 3)
    assert a == b


# Generated at 2022-06-12 16:16:34.253627
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    import typesystem
    from typesystem import validators as v
    from typesystem import structures
    from typesystem import fields
    from typesystem import content
    integer = fields.Integer(name="integer", validators=[v.Minimum(10)])
    string = fields.String(name="string", validators=[v.Pattern(r"^[a-z]+$")])
    schema = structures.Schema(
        name="person",
        fields={
            "age": integer,
            "name": string,
            "children": fields.Array(items=fields.Integer(name="children")),
        },
    )

# Generated at 2022-06-12 16:16:45.354757
# Unit test for constructor of class DictToken
def test_DictToken():
    d1 = DictToken({"a": 1, "b": 2, "c": 3}, 0, 3, content="{a: 1, b: 2, c: 3}")
    assert d1._value == {"a": 1, "b": 2, "c": 3}
    assert d1._start_index == 0
    assert d1._end_index == 3
    assert d1._content == "{a: 1, b: 2, c: 3}"

    d2 = DictToken({"a": 1, "b": 2}, 0, 2, content="{a: 1, b: 2}")
    assert d2._value == {"a": 1, "b": 2}
    assert d2._start_index == 0
    assert d2._end_index == 2

# Generated at 2022-06-12 16:16:47.602065
# Unit test for constructor of class DictToken
def test_DictToken():
    d={"foo":"bar"}
    dt=DictToken(d, 2,3)


# Generated at 2022-06-12 16:16:59.724625
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(value=1, start_index=1, end_index=3, content="xml").__eq__(Token(value=1, start_index=1, end_index=3, content="xml")) == True
    assert Token(value=1, start_index=1, end_index=3, content="xml").__eq__(Token(value=1, start_index=2, end_index=3, content="xml")) == False
    assert Token(value=1, start_index=1, end_index=3, content="xml").__eq__(Token(value=2, start_index=1, end_index=3, content="xml")) == False

# Generated at 2022-06-12 16:17:08.600571
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # T1
    t = Token(value='', start_index=0, end_index=0)
    assert t == t

    # T2
    t = Token(value='', start_index=0, end_index=0)
    assert not (t == None)

    # T3
    t = Token(value='', start_index=0, end_index=0)
    assert not (t == '')

    # T4
    t = Token(value='', start_index=0, end_index=0)
    assert t == Token(value='', start_index=0, end_index=0)

    # T5
    t = Token(value='', start_index=0, end_index=0)
    assert not (t == Token(value='', start_index=0, end_index=1))

# Generated at 2022-06-12 16:17:09.304931
# Unit test for constructor of class DictToken
def test_DictToken():
    assert(True)


# Generated at 2022-06-12 16:17:25.678472
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token=Token(None,None,None)
    assert (token==token)
    assert (token==token)

# Generated at 2022-06-12 16:17:35.381679
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    string = "abc"
    content = "abc"
    start_index = 0
    end_index = 2

    token1 = ScalarToken(string, start_index, end_index, content=content)
    token2 = ScalarToken(string, start_index, end_index, content=content)
    token3 = ScalarToken(string, start_index, end_index, content=content)
    token4 = ScalarToken(string, start_index, end_index, content=content)

    assert token1 == token1
    assert not (token1 == token2)
    assert not (token1 == token3)
    assert not (token1 == token4)
    assert not (token2 == token3)
    assert not (token2 == token4)
    assert not (token3 == token4)


# Generated at 2022-06-12 16:17:47.178724
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert not Token(value=None, start_index=None, end_index=None, content=None).__eq__(None)
    assert ScalarToken(value=None, start_index=None, end_index=None, content=None).__eq__(ScalarToken(value=None, start_index=None, end_index=None, content=None))
    assert not ScalarToken(value=None, start_index=None, end_index=None, content=None).__eq__(Token(value=None, start_index=None, end_index=None, content=None))
    assert not ScalarToken(value=None, start_index=None, end_index=None, content=None).__eq__(DictToken(value=None, start_index=None, end_index=None, content=None))
   

# Generated at 2022-06-12 16:17:52.770683
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    s = ScalarToken(1, 0, 0)
    assert s == ScalarToken(1, 0, 0) # matches
    assert s != ScalarToken(2, 0, 0) # doesn't match
    assert s == ScalarToken(1, 0, 0, ' ') # matches (content ignored)

# Generated at 2022-06-12 16:17:56.956228
# Unit test for constructor of class DictToken
def test_DictToken():
    from unittest import TestCase
    
    class DictTokenTest(TestCase):
        def test_constuctor(self):
            testDict = DictToken()
            self.assertEqual(testDict._value,{})
    
    test = DictTokenTest()
    test.test_constuctor()


# Generated at 2022-06-12 16:18:00.730112
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    v1 = ScalarToken(1, 0, 0)
    v2 = ScalarToken(2, 0, 0)
    assert v1 == v1
    assert v2 == v2
    assert not v1 == v2
    assert not v2 == v1


# Generated at 2022-06-12 16:18:03.212531
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    start_index = 0
    end_index = 0
    content = ""
    value = ""
    tok = Token(value, start_index, end_index, content)
    assert tok.__eq__(tok) == True



# Generated at 2022-06-12 16:18:05.561637
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token("", 0, 0)
    token2 = Token("", 0, 0)
    assert token1 == token2


# Generated at 2022-06-12 16:18:08.515590
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_1 = Token(1, 2, 3)
    token_2 = Token(1, 2, 3)
    assert token_1 == token_2

# Generated at 2022-06-12 16:18:15.189254
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """
    It should compare two Token objects by "value", "start_index", "end_index" attributes.
    """
    value = [1, 2, 3, 4]
    tok1 = ListToken(value, 0, 4, content="12345")
    tok2 = ListToken(value, 0, 4, "12345")
    tok3 = ListToken(value, 0, 5, "12345")
    assert (tok1 == tok2) and not (tok2 == tok3)

# Generated at 2022-06-12 16:18:40.110552
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({}, 0, 0, "") is not None


# Generated at 2022-06-12 16:18:50.803081
# Unit test for constructor of class DictToken
def test_DictToken():
    a = Position(1, 1, 1)
    d = DictToken(
        value={a: a}, start_index=100, end_index=200, content='test_content'
    )
    # test constructor
    try:
        assert d
    except:
        raise AssertionError("test_dict_token: constructor test")
    # test output
    try:
        assert d.string == 'test_content' and d.value == {a: a}
    except:
        raise AssertionError("test_dict_token: string and value test")
    # test output of start and end
    try:
        assert d.start == a and d.end == a
    except:
        raise AssertionError("test_dict_token: start and end test")
    # test lookup

# Generated at 2022-06-12 16:18:53.192062
# Unit test for constructor of class DictToken
def test_DictToken():
    args = [1, 2, 3, 4, 5]
    kwargs = {'content': "asdf"}
    dt = DictToken(*args, **kwargs)
    assert dt._value == 1
    assert dt._start_index == 2
    assert dt._end_index == 3
    assert dt._content == "asdf"


# Generated at 2022-06-12 16:18:58.686072
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a': 10, 'b': 15}
    dToken = DictToken(d, 0, 0, '')
    value = dToken.value
    assert value == d
    assert dToken._start_index == 0
    assert dToken._end_index == 0
    assert dToken._content == ''
    assert dToken.string == ''
    assert dToken.start == Position(1, 1, 0)
    assert dToken.end == Position(1, 1, 0)


# Generated at 2022-06-12 16:19:10.644477
# Unit test for constructor of class DictToken
def test_DictToken():
    class TestDictToken(DictToken):
        def __init__(self):
            self._child_keys = {1: 'str', 2:'str2'}
            self._child_tokens = {1: 'int', 2:'int2'}
            self._start_index = 1
            self._end_index = 2
            self._content = 'content'
            super().__init__('TestDictToken', 1, 2, 'content')

    test = TestDictToken()
    assert test._child_keys[1] == 'str'
    assert test._child_tokens[1] == 'int'
    assert test._child_tokens[2] == 'int2'
    assert test._child_keys[2] == 'str2'
    assert test._start_index == 1
    assert test._

# Generated at 2022-06-12 16:19:15.463387
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"hello": 1, "world": 2}, 1, 10, "hello 123 world 456")
    assert (token._child_keys == {'hello': 1, 'world': 2})
    assert (token._child_tokens == {'hello': 1, 'world': 2})

# Generated at 2022-06-12 16:19:23.852329
# Unit test for constructor of class DictToken
def test_DictToken():
    # test 1
    content = "[{\"a\":\"b\"}]"
    start_index = 0
    end_index = 0
    value = {"a": "b"}
    token = DictToken(value, start_index, end_index, content)
    assert token
    # test 2
    content = "[{\"a\":\"b\"}]"
    start_index = 0
    end_index = 0
    value = {"a": "b"}
    token = DictToken(value, start_index, end_index, content)
    assert token
    # test 3
    content = "[{\"a\":\"b\"}]"
    start_index = 0
    end_index = 0
    value = {"a": "b"}
    token = DictToken(value, start_index, end_index, content)

# Generated at 2022-06-12 16:19:27.024094
# Unit test for constructor of class DictToken
def test_DictToken():
    # Unit test for constructor of class DictToken()
    assert DictToken(3, 4, 5, 6, 7)
    assert DictToken(3, 4, 5, 6, 7, a=1, b=2)

# Generated at 2022-06-12 16:19:38.932597
# Unit test for constructor of class DictToken
def test_DictToken():
    import re
    import json
    obj = {
        "token": "string",
        "start_index": "int",
        "end_index": "int",
        "content": "string (optional)",
    }
    name_pattern = "[a-zA-Z_]+([a-zA-Z_0-9])*"
    number_pattern = "\\d+\\.\\d+"
    string_pattern = "'[a-z]+'"

# Generated at 2022-06-12 16:19:43.598224
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken(value = {
        ScalarToken(key, 3, 5): ScalarToken(value, 5, 6)
    }, start_index = 0, end_index = 10, content = "")
    assert t.lookup([0])._get_value() == value


# Generated at 2022-06-12 16:20:07.855195
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({}, 0, 0, "")._get_value() == {}


# Generated at 2022-06-12 16:20:17.876326
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken(value = {}, start_index = 1000, end_index = 2000)
    assert dict_token._value == {}
    assert dict_token._start_index == 1000
    assert dict_token._end_index == 2000
    assert dict_token._content == ""
    assert dict_token.string == ""
    assert dict_token.value == {}
    assert dict_token.start.line_no == 1
    assert dict_token.start.column_no == 1
    assert dict_token.start.index == 1000
    assert dict_token.end.line_no == 1
    assert dict_token.end.column_no == 1
    assert dict_token.end.index == 2000


# Generated at 2022-06-12 16:20:27.260169
# Unit test for constructor of class DictToken
def test_DictToken():
    dic = {"a" : 1, "b" : 2}
    dic_token = DictToken(dic, 0, 1, "abc")
    assert(dic_token._value == dic)
    assert(dic_token._start_index == 0)
    assert(dic_token._end_index == 1)
    assert(dic_token._content == "abc")
    assert(type(dic_token) == DictToken)
    assert(type(dic_token.lookup([0])) == ScalarToken)
    assert(type(dic_token.lookup_key([0,1])) == ScalarToken)
    assert(dic_token.lookup_key([0,1]) == dic_token._child_keys[1])


# Generated at 2022-06-12 16:20:33.882574
# Unit test for constructor of class DictToken
def test_DictToken():
    start_index = 0
    end_index = 0
    content = ""
    t = DictToken({1:2},start_index,end_index,content)
    assert t._value == {1:2}
    assert t._start_index == start_index
    assert t._end_index == end_index
    assert t._content == content



# Generated at 2022-06-12 16:20:38.573427
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.tokens import _DictToken, Token
    _dictToken = _DictToken({'a': 'b', 'c': 'd'},0,1,'a')
    assert type(_dictToken) == DictToken
    assert _dictToken.start == Position(1, 1, 0)
    assert _dictToken.end == Position(1, 1, 1)
    assert _dictToken.value == {'a': 'b', 'c': 'd'}


# Generated at 2022-06-12 16:20:48.451025
# Unit test for constructor of class DictToken
def test_DictToken():
    from .parser_helper import (
        dict_token,
        dict_token_with_content,
        str_token_with_content,
        int_token_with_content,
        list_token_with_content,
    )

    test_input_1 = dict_token(
        {
            dict_token_with_content("a", "a1"): str_token_with_content("a", "a2"),
            list_token_with_content("a", "a1"): int_token_with_content("a", "a2"),
        },
        "a1",
        "a2",
    )

# Generated at 2022-06-12 16:20:59.572410
# Unit test for constructor of class DictToken
def test_DictToken():
    dict1 = {1:'a', 2:'b'}
    dict2 = {3:'c', 4:'d'}
    asso1 = {1:'a'}
    asso2 = {2:'b'}
    a = DictToken(dict1, 1, 2, content='content')
    assert a._value == dict1
    assert a._start_index == 1
    assert a._end_index == 2
    assert a._content == 'content'
    assert a._get_value() == dict1
    assert a._child_keys == {1:'a', 2:'b'}
    assert a._child_tokens == {'a':1, 'b':2}
    a = DictToken(dict2, 3, 4, content='content')
    assert a._value == dict2
    assert a._start_

# Generated at 2022-06-12 16:21:03.703765
# Unit test for constructor of class DictToken
def test_DictToken():
    if __name__ == "__main__":
        print("Running unit tests on class DictToken")
        args = "hello"
        kwargs = dict()
        d = DictToken(args, **kwargs)
        assert d.__init__() == None


# Generated at 2022-06-12 16:21:15.450056
# Unit test for constructor of class DictToken
def test_DictToken():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    import json_parser
    import typesystem
    import typing

    i = 0

    foo_type = typesystem.Dict({
        "a": typesystem.Integer,
        "b": typesystem.String,
    })

    foo_type_with_none = typesystem.Dict({
        "a": typesystem.Integer,
        "b": typesystem.String,
    }, allow_none=True)

    test_cases = [
        ("foo", i, i, json_parser.STRING, foo_type),
        ("null", i, i, json_parser.NULL, foo_type_with_none),
    ]


# Generated at 2022-06-12 16:21:20.407024
# Unit test for constructor of class DictToken
def test_DictToken():
    content = "A string"
    value = {1: 2, 3: 4}
    start_index = 0
    end_index = 5
    token = DictToken(value, start_index, end_index, content)
    assert token._child_tokens == value
    assert token._child_keys[1] == 1
    assert token._child_keys[3] == 3



# Generated at 2022-06-12 16:22:04.909844
# Unit test for constructor of class DictToken
def test_DictToken():
    string = "abc"
    start_index = 0
    end_index = 3
    content = "abc"
    dt = DictToken(string, start_index, end_index, content)
    assert dt._child_keys == {(string): string}
    assert dt._child_tokens == {(string): string}

# Generated at 2022-06-12 16:22:06.139516
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken


# Generated at 2022-06-12 16:22:14.565970
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import Token
    dictionary = {
        'one': 1,
        'two': 2,
        'three': 3,
        'four': 4,
        'five': 5
    }
    value = dictionary
    start_index = 0
    end_index = 5
    content = "{'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5}"
    # Create an instance of class DictToken
    test = DictToken(value=value, start_index=start_index, end_index=end_index, content=content)
    assert test is not None
