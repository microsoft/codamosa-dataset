

# Generated at 2022-06-12 16:12:21.461986
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test the Token class and all its subclasses.
    import io
    import unittest

    def make_token_class(Tokens: typing.Callable) -> typing.Callable:
        class TokenTest(unittest.TestCase):
            def test__eq__(self) -> None:
                tokens = Tokens()
                format_stream = io.StringIO()
                tokens.format(format_stream)
                format_contents = format_stream.getvalue()
                parse_stream = io.StringIO(format_contents)
                same_tokens = tokens.parse(parse_stream)
                self.assertEqual(tokens, same_tokens)

        return TokenTest

    TokenTest1 = make_token_class(Tokens1)
    TokenTest2 = make_token_class(Tokens2)
    Token

# Generated at 2022-06-12 16:12:32.473335
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """
    Test Token.__eq__ method
    """
    tokens1 = []
    tokens1.append( ScalarToken(value = "string", start_index = 0, end_index = 4, content = "string") )
    tokens1.append( ScalarToken(value = 5, start_index = 0, end_index = 1, content = "5") )
    tokens1.append( ScalarToken(value = 5.0, start_index = 0, end_index = 2, content = "5.0") )
    tokens1.append( ScalarToken(value = True, start_index = 0, end_index = 3, content = "True") )
    tokens1.append( ScalarToken(value = False, start_index = 0, end_index = 4, content = "False") )

# Generated at 2022-06-12 16:12:36.877112
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(
        value={},
        start_index=0,
        end_index=0,
        content=""
    )
    assert token.start == Position(1, 0, 0)
    assert token.end == Position(1, 0, 0)

# Generated at 2022-06-12 16:12:41.722311
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    _1 = ScalarToken(1, 0, 0)
    assert _1 == ScalarToken(1, 0, 0)
    assert _1 != ScalarToken(2, 0, 0)
    assert _1 != ScalarToken(1, 1, 1)
    assert _1 != ScalarToken(1, 1, 0)

# Generated at 2022-06-12 16:12:49.285183
# Unit test for constructor of class DictToken
def test_DictToken():
    print("Testing constructor of class DictToken")
    dt = DictToken(value={"name":"David"}, start_index=1, end_index=3, content="David")
    assert(dt._value=={"name":"David"})
    assert(dt._start_index==1)
    assert(dt._end_index==3)
    assert(dt._content=="David")
    assert(dt._child_keys["name"]== dt._value.keys())
    assert(dt._child_tokens["name"]== dt._value.items())
    print("Test passed")


# Generated at 2022-06-12 16:12:50.565279
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({}, 0, 1)

# Generated at 2022-06-12 16:12:51.741399
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_test = DictToken("token")


# Generated at 2022-06-12 16:13:04.275661
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_1 = ScalarToken('test_1', 1, 4, 'test_1')
    token_2 = ScalarToken('test_1', 1, 4, 'test_1')
    token_3 = ScalarToken('test_2', 2, 5, 'test_2')
    token_4 = ScalarToken('test_1', 1, 6, 'test_1')
    token_5 = ScalarToken('test_1', 1, 4, 'test_1')
    token_6 = ScalarToken('test_1', 2, 4, 'test_1')

    assert token_1 == token_1
    assert token_1 == token_2
    assert token_1 == token_5
    assert token_1 != token_3
    assert token_1 != token_4
    assert token_1 != token_6

# Generated at 2022-06-12 16:13:07.059786
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {}
    t = DictToken(d, 0, 0)
    assert(t._value == d)
    assert(t._start_index == 0)
    assert(t._end_index == 0)


# Generated at 2022-06-12 16:13:09.414755
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(value=1, start_index=1, end_index=2, content="") == Token(value=1, start_index=1, end_index=2, content="")

# Generated at 2022-06-12 16:13:15.990590
# Unit test for constructor of class DictToken
def test_DictToken():
    a = {1: 2}
    value = {1: 2}
    start_index = 1
    end_index = 2
    content = "content"
    dt = DictToken(a, start_index, end_index, content)
    assert content == dt._content and start_index == dt._start_index and end_index == dt._end_index


# Generated at 2022-06-12 16:13:21.935851
# Unit test for constructor of class DictToken
def test_DictToken():
    # token = DictToken('value', 'start_index', 'end_index', 'content')
    content = '''
    {
        "abc": 123
    }
    '''
    token = DictToken({}, 0, 19, content)

    assert token._content == content
    assert token._start_index == 0
    assert token._end_index == 19
    assert token._value == {}
    assert token._child_keys == {}
    assert token._child_tokens == {}


# Generated at 2022-06-12 16:13:24.636677
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    the_input = "\"hello\""
    import typesystem.types
    the_tokens = typesystem.types.string.parse_string(the_input)
    assert the_tokens[0] == the_tokens[0]

# Generated at 2022-06-12 16:13:26.899770
# Unit test for constructor of class DictToken
def test_DictToken():
    assert True, "Not implemeneted"


# Generated at 2022-06-12 16:13:29.625389
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert ScalarToken(1, 2, 3) == ScalarToken(1, 2, 3)
    assert ScalarToken(1, 2, 3) != ScalarToken(2, 3, 4)


# Generated at 2022-06-12 16:13:37.280124
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = ScalarToken(value = 5, start_index = 0, end_index = 0, content = "")
    t2 = ScalarToken(value = 5, start_index = 0, end_index = 0, content = "")
    t3 = ScalarToken(value = 7, start_index = 0, end_index = 0, content = "")
    t4 = ScalarToken(value = 5, start_index = 1, end_index = 0, content = "")
    t5 = ScalarToken(value = 5, start_index = 0, end_index = 1, content = "")
    assert t1 == t2
    assert t1 != t3
    assert t1 != t4
    assert t1 != t5

# Generated at 2022-06-12 16:13:39.573542
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert ScalarToken(1,0,2,"123") == ScalarToken(1,0,2,"123")


# Generated at 2022-06-12 16:13:44.884893
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert not Token(1, 2, 3) != Token(1, 2, 3)
    assert Token(1, 2, 4) != Token(1, 2, 3)
    assert not Token(1, 2, 4) == Token(1, 2, 3)


# Generated at 2022-06-12 16:13:51.353660
# Unit test for constructor of class DictToken
def test_DictToken():
    text = '{\n  "g": {\n    "id": "123",\n    "name": "Foo"\n  },\n  "a": 1\n}'
    token = DictToken({'g': {'id': '123', 'name': 'Foo'}, 'a': 1}, 0, 0, text)
    assert str(token) == 'DictToken({\n  "g": {\n    "id": "123",\n    "name": "Foo"\n  },\n  "a": 1\n})'


# Generated at 2022-06-12 16:13:54.997079
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token('value1', 1, 2, 'content')
    token2 = Token('value1', 1, 2, 'content')
    assert token1 == token2
    assert token2 == token1


# Generated at 2022-06-12 16:14:01.823620
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = ScalarToken(1, 0, 2, "name1")
    t2 = ScalarToken(2, 0, 2, "name2")
    assert t2 is not t1
    assert t1 == t1
    assert t1 != t2


# Generated at 2022-06-12 16:14:07.200493
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    test_self = ScalarToken(
        None,
        start_index=0,
        end_index=0,
        content="",
    )
    ###########################################################################
    # Write your code here:
    ###########################################################################
    # Replace 'assert False' with the code you want to test
    assert True



# Generated at 2022-06-12 16:14:13.679701
# Unit test for constructor of class DictToken
def test_DictToken():
    test_token = DictToken(
        value = {'key': 'value'},
        start_index = 1,
        end_index = 2,
        content = 'None'
        )
    assert test_token.value == {'key': 'value'}
    assert test_token.start == Position(line_no = 2, column_no = 2, index = 2)
    assert test_token.end == Position(line_no = 3, column_no = 3, index = 3)
    assert test_token.string == "e"
    assert test_token._child_tokens == {'key': 'value'}
    assert test_token._child_keys == {'key': 'value'}


# Generated at 2022-06-12 16:14:16.308920
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"key": "value"}, 0, 1)
    assert token.value == {"key": "value"}
    # Unit test for constructor of class ListToken

# Generated at 2022-06-12 16:14:27.243694
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_self = Token(value=None, start_index=None, end_index=None, content=None)
    class Token_other:
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            self._value = args[0]
            self._start_index = args[1]
            self._end_index = args[2]
            self._content = args[3]
        def _get_value(self) -> typing.Any:
            return self._value
        def _get_child_token(self, key: typing.Any) -> Token:
            return self._value[key]
        def _get_key_token(self, key: typing.Any) -> Token:
            return self._value[key]

# Generated at 2022-06-12 16:14:31.489085
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Given
    token1 = Token(
        0,
        0,
        0,
    )
    # When
    equal = token1.__eq__(Token(0, 0, 0))
    not_equal = token1.__eq__(Token(1, 0, 0))
    # Then
    assert equal == True
    assert not_equal == False


# Generated at 2022-06-12 16:14:33.245582
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    pass


# Generated at 2022-06-12 16:14:39.574603
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {
        "a": 1,
        "b": 2,
        "c": 3
    }
    d_token = DictToken(d, 0, 2)
    assert d_token._get_value() == {
        "a":1,
        "b":2,
        "c":3
    }


# Generated at 2022-06-12 16:14:40.153832
# Unit test for constructor of class DictToken
def test_DictToken():
    assert 1 == 1

# Generated at 2022-06-12 16:14:47.865565
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class DummyContent(str):
        pass

    class DummyToken(Token):
        @property
        def value(self) -> typing.Any:
            return self._value

        @property
        def string(self) -> str:
            return self._content[self._start_index : self._end_index + 1]

        def _get_value(self) -> typing.Any:
            return self._value

        def _get_child_token(self, key: typing.Any) -> Token:
            raise NotImplementedError  # pragma: nocover

        def _get_key_token(self, key: typing.Any) -> Token:
            raise NotImplementedError  # pragma: nocover


# Generated at 2022-06-12 16:15:05.622798
# Unit test for constructor of class DictToken
def test_DictToken():
    value = {ScalarToken('a', 5, 6): ScalarToken(1, 8, 9)}
    # Dictionary, by calling constructor of class DictToken
    token = DictToken(value, 0, 10, "test_DictToken")
    assert token.string == "test_DictToken"
    assert token.value == {'a': 1}
    assert token.start == Position(1, 1, 0)
    assert token.end   == Position(1, 12, 11)
    assert token.lookup([0]).string == 'a'
    assert token.lookup([0]).value  == 'a'
    assert token.lookup([0]).start  == Position(1, 2, 1)
    assert token.lookup([0]).end    == Position(1, 3, 2)
    assert token.lookup_key

# Generated at 2022-06-12 16:15:09.732441
# Unit test for constructor of class DictToken
def test_DictToken():
    value = {}
    start_index = 0
    end_index = 1
    content = ""
    try:
        token = DictToken(value, start_index, end_index, content)
        assert token != None
    except Exception:
        assert False


# Generated at 2022-06-12 16:15:19.864139
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    import json
    import typesystem.tokenizer as tokenizer
    a = json.loads('{"a":1}')
    b = json.loads('{"a":1}')
    c = json.loads('{"a":2}')
    tokens_a = tokenizer.tokenize(a)
    tokens_b = tokenizer.tokenize(b)
    tokens_c = tokenizer.tokenize(c)
    for i in range(len(tokens_a)):
        assert tokens_a[i] == tokens_b[i]
        assert tokens_a[i] != tokens_c[i]
    assert tokens_a == tokens_b
    assert tokens_a != tokens_c

# Generated at 2022-06-12 16:15:30.706153
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(
        {
            ScalarToken(0, 0, 1, "0"): ScalarToken(1, 2, 3, "1"),
            ScalarToken(2, 2, 5, "2"): ScalarToken(3, 6, 7, "3"),
        },
        0,
        7,
        "0:1,2:3",
    )
    tokens = [
        ScalarToken(0, 0, 1, "0"),
        ScalarToken(2, 2, 5, "2"),
    ]
    assert token._child_keys == {0: tokens[0], 2: tokens[1]}
    tokens = [
        ScalarToken(1, 2, 3, "1"),
        ScalarToken(3, 6, 7, "3"),
    ]
    assert token._child_t

# Generated at 2022-06-12 16:15:32.465593
# Unit test for method __eq__ of class Token
def test_Token___eq__():
	assert not ScalarToken(None, start_index=None, end_index=None, content=None) == None

# Generated at 2022-06-12 16:15:37.132272
# Unit test for constructor of class DictToken
def test_DictToken():
    child_tokens = {}
    child_keys = {}
    assert(child_tokens == {})
    assert(child_keys == {})
    assert(DictToken(0,0,0, {})._value == {})
    assert(DictToken(0,0,0, {})._child_tokens == child_tokens)
    assert(DictToken(0,0,0, {})._child_keys == child_keys)


# Generated at 2022-06-12 16:15:48.701243
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class FooToken(Token):
        # Unit test for method __eq__ of class Token
        def __eq__(self, other):
            return isinstance(other, FooToken) and (
                self._get_value() == other._get_value()
                and self._start_index == other._start_index
                and self._end_index == other._end_index
            ) 
    token_1 = FooToken("value1", 1, 1, "content1")
    token_2 = FooToken("value1", 1, 1, "content1")
    token_3 = FooToken("value2", 1, 1, "content1")
    token_4 = Token("value1", 1, 1, "content1")
    token_5 = 0
    assert token_1 == token_1
    assert token_1 == token_2
   

# Generated at 2022-06-12 16:15:57.992970
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem import types
    from typesystem.values import Value

    assert not Token(None, 0, 0) == 1

    assert Token(Value("hi"), 0, 2, "hi") == Token(Value("hi"), 0, 2, "hi")

    assert Token(Value("hi"), 0, 2, "hi") != Token(Value("hi"), 0, 2, "ho")
    assert Token(Value("hi"), 0, 2, "hi") != Token(Value("ho"), 0, 2, "hi")
    assert Token(Value("hi"), 0, 2, "hi") != Token(Value("ho"), 0, 2, "ho")

    assert Token(Value("hi"), 0, 2, "hi") != Token(Value(1), 0, 2, "hi")

# Generated at 2022-06-12 16:16:02.052891
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert (Token(None, 1, 2, None) == Token(None, 1, 2, None))
    assert not (Token(None, 1, 2, None) == Token(None, 1, 3, None))
    assert not (Token(None, 1, 2, None) == Token(None, 1, 2, "abc"))
    assert not (Token(None, 1, 2, None) == Token(None, 2, 3, "abc"))
    assert not (Token(None, 1, 2, None) == Token(None, 3, 4, "abc"))


# Generated at 2022-06-12 16:16:09.352367
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken({"foo":1}, 0, 1)
    t2 = DictToken({"foo":1,"bar":2}, 0, 2)
    print (t)
    print (t2)
    print (t._get_value())
    print (t2._get_value())
    print (t._get_child_token("foo"))
    print (t2._get_child_token("foo"))
    print (t._get_key_token("foo"))
    print (t2._get_key_token("foo"))


test_DictToken()

# Generated at 2022-06-12 16:16:39.746871
# Unit test for constructor of class DictToken
def test_DictToken():
    class MockDictToken(DictToken):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            self._value = {}
            self._child_keys = {}
            self._child_tokens = {}

    mock_dict = MockDictToken()
    assert isinstance(mock_dict, DictToken) == True

# Generated at 2022-06-12 16:16:41.585111
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken([1, 2, 3], 0, 3, content="abc")


# Generated at 2022-06-12 16:16:50.353308
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    value = None
    start_index = 1
    end_index = 20
    content = ""
    obj = Token(
        value=value, start_index=start_index, end_index=end_index, content=content
    )

    assert isinstance(obj, Token)
    if isinstance(obj, Token):
        assert obj._start_index == start_index
        assert obj._end_index == end_index
        assert obj._content == content

    assert obj.string == ""
    assert obj.value is None
    assert isinstance(obj.start, Position)
    assert isinstance(obj.end, Position)
    assert obj.start == Position(1, 1, 1)
    assert obj.end == Position(1, 2, 20)
    assert obj.lookup([]) is obj

# Generated at 2022-06-12 16:16:56.322926
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token('a', 0, 1)
    other = Token('a', 0, 1)
    assert token == other

    token = Token('a', 0, 1)
    other = Token('a', 1, 1)
    assert token != other

    token = Token('a', 0, 1)
    other = Token('b', 0, 1)
    assert token != other



# Generated at 2022-06-12 16:17:00.340139
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    print("Test Token.__eq__()")

    import typesystem.base as base
    token1 = Token(base.String(), 0, 1)
    token2 = Token(base.String(), 1, 2)
    assert(token1 == token2)
    print("Pass")



# Generated at 2022-06-12 16:17:03.099899
# Unit test for constructor of class DictToken
def test_DictToken():
    dict = {"a":1, "b": 2}
    t = DictToken(dict,0,50)
    assert t.start == (1, 1, 0)

# Generated at 2022-06-12 16:17:06.660185
# Unit test for constructor of class DictToken
def test_DictToken():
    import typesystem.base as base
    token = DictToken({"name": base.Token(254, 4, 4, "lucas")}, 4, 4)

    assert token.string == "lucas"
    assert token.value == {"name": "lucas"}


# Generated at 2022-06-12 16:17:10.506880
# Unit test for constructor of class DictToken
def test_DictToken():
    # Initialize a new DictToken object
    token = DictToken({'key': 'value'}, 2, 3)
    assert isinstance(token, DictToken)


# Generated at 2022-06-12 16:17:14.364333
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(value='', start_index=0, end_index=1)
    token2 = Token(value='', start_index=0, end_index=1)
    assert token1 == token2



# Generated at 2022-06-12 16:17:24.573736
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test when value is a dict containing two elements
    dictToken1_value = {'value1': 'value2', 'value3': 'value4'}
    dictToken1 = DictToken(dictToken1_value, 0, 1)
    assert dictToken1._child_keys == {'value1': 'value2', 'value3': 'value4'}
    
    # Test when value is a dict containing one element
    dictToken2_value = {'value1': 'value2'}
    dictToken2 = DictToken(dictToken2_value, 0, 1)
    assert dictToken2._child_keys == {'value1': 'value2'}
    
    # Test when value is a dict containing zero element
    dictToken3_value = {}

# Generated at 2022-06-12 16:17:55.454277
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class MockToken(Token):
        def _get_value(self) -> int:
            return 0
    token_1 = MockToken(0, 0, 0)
    token_2 = MockToken(0, 0, 0)
    assert token_1 == token_2


# Generated at 2022-06-12 16:18:00.094053
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({},3,5,"this is a test")
    assert token._child_keys == {}
    assert token._child_tokens == {}
    assert token._content == "this is a test"
    assert token._end_index == 5
    assert token._start_index == 3
    assert token._value == {}


# Generated at 2022-06-12 16:18:02.690132
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    Token(1, 2, 3, "4") == Token(1, 2, 3, "4")
    Token(1, 2, 3, "4") != Token(2, 2, 3, "4")

test_Token___eq__()

# Generated at 2022-06-12 16:18:11.508654
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_1 = Token(value=1, start_index=0, end_index=1)
    token_2 = Token(value=2, start_index=0, end_index=1)
    token_3 = Token(value=1, start_index=1, end_index=1)
    assert token_1.__eq__(token_2) == False
    assert token_2.__eq__(token_3) == False
    assert token_1.__eq__(token_3) == False
    assert token_1.__eq__(token_1) == True

# Generated at 2022-06-12 16:18:15.487878
# Unit test for constructor of class DictToken
def test_DictToken():
    test_value= {"key1": Token("value1",1,2),
                 "key2":Token("value2",3,4)}
    test_start_index=1
    test_end_index=4
    DictToken(test_value,test_start_index,test_end_index)



# Generated at 2022-06-12 16:18:17.943801
# Unit test for constructor of class DictToken
def test_DictToken():
    index = 0
    key = 0
    value = 1
    start_index = 0
    end_index = 10
    content = "abcdefghij"
    test = DictToken((key, value), index, index, content)


# Generated at 2022-06-12 16:18:22.711040
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_1 = Token(1, 2, 3)
    token_2 = Token(2, 3, 4)
    assert(token_1.__eq__(token_1))
    assert(not token_1.__eq__(token_2))


# Generated at 2022-06-12 16:18:26.053878
# Unit test for constructor of class DictToken
def test_DictToken():
    A = {}
    B = DictToken.__init__(A, *args, **kwargs)
    assert DictToken.__init__(A) == DictToken.__init__(A, *args, **kwargs)


# Generated at 2022-06-12 16:18:29.885711
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    #Pass
    assert Token(1,1,1,2) == Token(1,1,1,2)
    #Pass
    assert not Token(1,1,1,2) == Token(1,1,1,2)


# Generated at 2022-06-12 16:18:38.615844
# Unit test for method __eq__ of class Token
def test_Token___eq__():
	args = {'start_index': 0, 'end_index': 1, 'content': 'test'}
	token1 = Token(42, **args)
	token2 = Token(42, **args)
	assert token1 == token2
	assert token1 != token1._get_value()

	token3 = Token(43, **args)
	assert token1 != token3
	assert token3 != token2

	args2 = {'start_index': 0, 'end_index': 2, 'content': 'test'}
	token4 = Token(42, **args2)
	assert token1 != token4

	args3 = {'start_index': 1, 'end_index': 2, 'content': 'test'}
	token5 = Token(42, **args3)
	assert token2 != token5


# Generated at 2022-06-12 16:19:20.123483
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test when lesser than 2 parameters are passed
    # Expected value: "Exception raised"
    with pytest.raises(TypeError) as type_error:
        Token(1, 1, 1) == 1
    assert str(type_error.value) == "__eq__() takes 1 positional argument but 2 were given"
    # Test when "self" is not of Token instance
    # Expected value: False
    assert Token(1, 1, 1) != 1
    # Test when "other" is not of Token instance
    # Expected value: False
    assert Token(1, 1, 1) != "other"
    # Test when self._end_index is not equal to other._end_index
    # Expected value: False
    assert Token(1, 1, 1) != Token(1, 1, 2)
    # Test when self

# Generated at 2022-06-12 16:19:23.323887
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    a = Token(0, 2, 3)
    b = Token(0, 2, 4)
    c = Token(0, 2, 3)
    d = Token(1, 2, 3)
    assert a == a
    assert a == c
    assert a != b
    assert a != d


# Generated at 2022-06-12 16:19:35.065426
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    v_value = "foo"
    v_start_index = 0
    v_end_index = 3
    v_content = "abcfoodef"
    token = Token(v_value, v_start_index, v_end_index, v_content)
    v_value = "foo"
    v_start_index = 0
    v_end_index = 3
    v_content = "abcfoodef"
    other = Token(v_value, v_start_index, v_end_index, v_content)
    assert token == other
    v_value = "foo"
    v_start_index = 0
    v_end_index = 3
    v_content = "abcfoodef"

# Generated at 2022-06-12 16:19:36.201360
# Unit test for method __eq__ of class Token
def test_Token___eq__():
  assert True


# Generated at 2022-06-12 16:19:43.399088
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class MockToken(Token):
        def _get_value(self) -> str:
            return self._value
        def _get_child_token(self, key: typing.Any) -> Token:
            pass
        def _get_key_token(self, key: typing.Any) -> Token:
            pass
    token_1 = MockToken(value = "Hello World", start_index = 5, end_index = 11)
    token_2 = MockToken(value = "Hello World", start_index = 5, end_index = 11)
    assert token_1 == token_2


# Generated at 2022-06-12 16:19:53.219026
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(3, 1, 2)
    t2 = Token(3, 1, 2)
    assert t1 == t2
    assert not (t1 != t2)
    t2._value = 4
    assert t1 != t2
    t2._value = 3
    t2._start_index = 2
    assert t1 != t2
    t2._start_index = 1
    t2._end_index = 3
    assert t1 != t2
    t2._end_index = 2
    assert t1 == t2
    t2._content = "ab"
    assert t1 == t2
    t2._content = "abc"
    assert t1 == t2


# Generated at 2022-06-12 16:19:54.489715
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken(None, None, None)


# Generated at 2022-06-12 16:19:58.822626
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(10, 10, 20, "content")
    other = Token(20, 20, 30, "content")
    assert(token.__eq__(other) == False)


# Generated at 2022-06-12 16:20:06.429686
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    x1 = Token(value = "", start_index = 0, end_index = 0)
    x2 = Token(value = "", start_index = 0, end_index = 0)
    x3 = Token(value = "", start_index = 1, end_index = 0)
    x4 = Token(value = "", start_index = 0, end_index = 1)
    x5 = Token(value = "x", start_index = 0, end_index = 0)
    x6 = Token(value = "", start_index = 0, end_index = 0, content = "x")

    assert x1 == x1
    assert x1 == x2
    assert not (x1 == x3)
    assert not (x1 == x4)
    assert not (x1 == x5)
    assert x1 == x

# Generated at 2022-06-12 16:20:13.172506
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert ScalarToken(1, 2, 3) == ScalarToken(1, 2, 3)
    assert ScalarToken(1, 2, 3) != ScalarToken(2, 2, 3)
    assert ScalarToken(1, 2, 3) != ScalarToken(1, 1, 3)
    assert ScalarToken(1, 2, 3) != ScalarToken(1, 2, 4)



# Generated at 2022-06-12 16:21:07.432524
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    obj = Token('foo', 0, 3)
    another_obj = Token('foo', 4, 6)
    assert obj == obj
    assert obj == another_obj
    assert type(obj) == type(another_obj)

# Generated at 2022-06-12 16:21:13.781912
# Unit test for method __eq__ of class Token
def test_Token___eq__():
  assert Token(value = "value", start_index = 0, end_index = 1, content = "") == Token(value = "value", start_index = 0, end_index = 1, content = "")
  assert not (Token(value = "value", start_index = 0, end_index = 1, content = "") != Token(value = "value", start_index = 0, end_index = 1, content = ""))


# Generated at 2022-06-12 16:21:18.841647
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    key = ScalarToken(0, 0, 0)
    value = ScalarToken(1, 1, 1)
    dictionary = DictToken({key: value}, 0, 1)
    assert dictionary.lookup([]) == dictionary
    assert dictionary.lookup([0]) == value
    assert dictionary.lookup_key([0]) == key

# Generated at 2022-06-12 16:21:22.071914
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    value = (1, 2, 3)
    token_1 = Token(value, start_index=0, end_index=5)
    token_2 = Token(value, start_index=0, end_index=5)

    assert token_1 == token_2



# Generated at 2022-06-12 16:21:25.626219
# Unit test for constructor of class DictToken
def test_DictToken():
    with pytest.raises(NotImplementedError):
        test_dict_token = DictToken(5, 5, 10, "abc\ndef\nghi")
        test_dict_token._get_value()
        test_dict_token._get_child_token(5)
        test_dict_token._get_key_token(5)


# Generated at 2022-06-12 16:21:35.764194
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(None, 0, 0)
    token2 = Token(None, 0, 0)
    assert token1 == token2
    assert not (token1 != token2)

    token1 = Token(True, 0, 0)
    token2 = Token(False, 0, 0)
    assert not (token1 == token2)
    assert token1 != token2

    token1 = Token(None, 0, 0)
    token2 = Token(None, 0, 1)
    assert not (token1 == token2)
    assert token1 != token2

    token2 = Token(None, 1, 0)
    assert not (token1 == token2)
    assert token1 != token2

    token2 = Token(True, 0, 0)
    assert not (token1 == token2)
    assert token1 != token2

# Generated at 2022-06-12 16:21:46.398371
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # test ScalarToken
    token1 = ScalarToken(1, 0, 0)
    token2 = ScalarToken(2, 0, 0)
    token3 = ScalarToken(1, 0, 0)
    assert token1 == token3 and token1 != token2
    # test DictToken
    token4 = DictToken({token1: token1}, 0, 0)
    token5 = DictToken({token1: token2}, 0, 0)
    token6 = DictToken({token1: token1}, 0, 0)
    assert token4 == token6 and token4 != token5
    # test ListToken
    token7 = ListToken([], 0, 0)
    token8 = ListToken([token1], 0, 0)
    token9 = ListToken([token2], 0, 0)
    token10 = ListToken

# Generated at 2022-06-12 16:21:54.037763
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    test_string = "test"

    token1 = Token(1, 1, 4)
    token2 = ScalarToken(1, 1, 4)
    token3 = ScalarToken(2, 1, 4)
    token4 = ScalarToken(1, 2, 4)
    token5 = ScalarToken(1, 1, 3)
    token6 = ScalarToken(1, 1, 4, test_string)

    assert token1 == token2
    assert not token2 == token3
    assert not token2 == token4
    assert not token2 == token5
    assert not token2 == token6



# Generated at 2022-06-12 16:21:59.470919
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t = Token(None,0,0, "")
    assert isinstance(t, Token)
    assert not t == ((), [], {}, None)
    assert not t == (1, 2, 3, 4)
    assert not t == ("", "", "", "")
    assert not t == (True, False)


# Generated at 2022-06-12 16:22:01.241486
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {}
    assert isinstance(d, dict)
    assert isinstance(DictToken(d), DictToken)