

# Generated at 2022-06-12 16:12:19.154911
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    a = Token(value=None, start_index=0, end_index=5, content="")
    assert a, "fail to init class Token"
    assert a == a, "Token equal method is not equal"



# Generated at 2022-06-12 16:12:24.170431
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {0: 0, 1: 1}
    dt = DictToken(d, 0, 1)
    assert dt._get_value() == {0: 0, 1: 1}



# Generated at 2022-06-12 16:12:35.180809
# Unit test for constructor of class DictToken
def test_DictToken():
    class A:
        pass
    a1 = A()
    a1.start_index = 1
    a1.end_index = 2
    a1.content = "a1"
    a1._value = 1

    class B:
        pass
    b1 = B()
    b1.start_index = 3
    b1.end_index = 4
    b1.content = "b1"
    b1._value = 2

    class C:
        pass
    c1 = C()
    c1.start_index = 3
    c1.end_index = 4
    c1.content = "c1"
    c1._value = 3

    class D:
        pass
    d1 = D()
    d1.start_index = 0
    d1.end_index = 4
    d

# Generated at 2022-06-12 16:12:39.830169
# Unit test for method __eq__ of class Token
def test_Token___eq__():
	assert Token(1,2,3) == Token(1,2,3)
	assert not Token(1,2,3) == Token(1,2,4)


# Generated at 2022-06-12 16:12:40.805793
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken.__init__()

# Generated at 2022-06-12 16:12:46.320667
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """
    Method ``__eq__`` of class ``Token``
    """
    # Test the scalar token
    ScalarToken(value='name', start_index=0, end_index=4) == ScalarToken(value='name', start_index=0, end_index=4)
    ScalarToken(value='first', start_index=0, end_index=5) != ScalarToken(value='name', start_index=0, end_index=4)
    ScalarToken(value='name', start_index=0, end_index=4) != ScalarToken(value='name', start_index=0, end_index=5)
    ScalarToken(value='name', start_index=0, end_index=4) != ScalarToken(value='name', start_index=1, end_index=4)


# Generated at 2022-06-12 16:12:54.008764
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import String, Integer

    token = DictToken({String("name"): String("Joe"), Integer("age"): Integer(12)}, 0, 3)

    assert token.value == {"name": "Joe", "age": 12}
    assert token.start.line_no == 1 and token.start.column_no == 1 and token.start.index == 0
    assert token.end.line_no == 1 and token.end.column_no == 5 and token.end.index == 4


# Generated at 2022-06-12 16:13:02.005144
# Unit test for constructor of class DictToken
def test_DictToken():

    # Token 1: a,0:0
    # Token 2: b,0:0
    # Token 3: c,0:0
    token1, token2, token3 = ScalarToken("a", 0, 0), ScalarToken("b", 0, 0), ScalarToken("c", 0, 0)

    # Token 4: {a: b, c: d},0:0
    token4 = DictToken({token1: token2, token3: token2}, 0, 0)

    return token4


# Generated at 2022-06-12 16:13:04.231069
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(0, 0, 0, '') != Token(0, 0, 0, '')
    assert Token(0, 0, 0, '') != None

# Generated at 2022-06-12 16:13:04.831843
# Unit test for constructor of class DictToken
def test_DictToken():
    assert 1 == 1

# Generated at 2022-06-12 16:13:12.800841
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(0, 0, 0) == Token(0, 0, 0)
    assert not (Token(0, 0, 0) == Token(1, 0, 0))
    assert not (Token(0, 0, 0) == Token(0, 1, 0))
    assert not (Token(0, 0, 0) == Token(0, 0, 1))
    assert not (Token(0, 0, 0) == "")
    return None


# Generated at 2022-06-12 16:13:13.959852
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(None,None,None)
    token2 = Token(None,None,None)
    assert token1 == token2
    assert not (token1 != token2)


# Generated at 2022-06-12 16:13:21.936416
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(None, 0, 0)
    assert t1 == t1
    t2 = Token(None, 1, 1)
    assert not (t1 == t2)
    t3 = Token(None, 1, 1)
    assert t2 == t3
    t4 = Token([], 1, 1)
    assert not (t2 == t4)
    t5 = Token([], 1, 1)
    assert t4 == t5
    t6 = Token({}, 1, 1)
    assert not (t4 == t6)
    t7 = Token({}, 1, 1)
    assert t6 == t7

# Generated at 2022-06-12 16:13:24.122540
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    typesystem.test.test_token.test_Token___eq__()

# Generated at 2022-06-12 16:13:34.598111
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.scalars import String
    from typesystem.types import Dict, List
    from typesystem.validators import Length
    from typesystem.compat import text_type

    String = String(validators=[Length(1)])
    types = {
        "name": String,
        "age": String,
    }
    Person = Dict(types, validators=[Length(2)])
    Group = List(types=[Person], validators=[Length(2)])

    value = Group([
        {
            "name": "John Doe",
            "age": "32",
        },
        {
            "name": "John Smith",
            "age": "42",
        },
    ])
    t = Group.validate(value)

# Generated at 2022-06-12 16:13:46.737490
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    start_index = 1
    end_index   = 2
    content     = "content"
    value1      = "value1"
    value2      = "value2"

    token1 = Token(value1, start_index, end_index, content)
    assert token1
    assert repr(token1) == "Token('v')"

    # test __eq__ of class Token with itself
    assert token1 == token1

    # test __eq__ of class Token with same values
    token2 = Token(value1, start_index, end_index, content)
    assert token1 == token2

    # test __eq__ of class Token with different values
    token2 = Token(value2, start_index, end_index, content)
    assert not token1 == token2

    # test __eq__ of class Token with different start index

# Generated at 2022-06-12 16:13:53.673127
# Unit test for constructor of class DictToken
def test_DictToken():
    content = '''
    {
        "name": "John",
        "age": 37,
        "interests": ["Python", "Coding"],
        "address": {
            "street": "1st Avenue",
            "city": "New York",
            "country": "USA"
        }
    }
    '''
    DictToken(value="", start_index=0, end_index=0, content=content)


# Generated at 2022-06-12 16:13:56.727625
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token('value1', 1, 2, 'content1')
    token2 = Token('value2', 2, 3, 'content2')
    assert token1 == token2

# Generated at 2022-06-12 16:13:58.775156
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    try:
        Token(None, None, None)
    except NotImplementedError:
        return
    assert False, "Expected exception was not raised"

# Generated at 2022-06-12 16:14:00.875571
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken(1, 2, 3, 4, 5).__init__(1, 2, 3, 4, 5) is None # pragma: no cover



# Generated at 2022-06-12 16:14:10.317726
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken(value = dict(), start_index = 1, end_index = 2, content = "abc")
    return dt


# Generated at 2022-06-12 16:14:13.869274
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken({1:"xx", 2:"yy"}, 0, 0)
    if t._child_keys != {1: 1, 2: 2}:
        print("Error: " + t._child_keys)


# Generated at 2022-06-12 16:14:16.879373
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {1:2}
    t = DictToken(d,0,0,"")
    # print(t._child_keys)
    # print(t._child_tokens)


# Generated at 2022-06-12 16:14:18.076771
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    pass


# Generated at 2022-06-12 16:14:28.811188
# Unit test for constructor of class DictToken
def test_DictToken():
    import sys
    from typesystem.parser import BaseParser, visit_sequence
    from typesystem.base import Position
    
    a = Element(token_value="a", start_index=0, end_index=0, content="a", start=Position(1,1,0), end=Position(1,1,0))
    b = Element(token_value="b", start_index=1, end_index=1, content="a", start=Position(1,2,1), end=Position(1,2,1))
    c = Element(token_value="c", start_index=2, end_index=2, content="a", start=Position(1,3,2), end=Position(1,3,2))

# Generated at 2022-06-12 16:14:40.766358
# Unit test for constructor of class DictToken
def test_DictToken():
    dic = dict()
    dic['0'] = 'alice'
    dic['1'] = 'bob'
    tok = DictToken(dic,0,3)
    assert tok._start_index == 0
    assert tok._end_index == 3
    assert tok._content == ""
    assert tok._child_tokens['0'] == 'alice'
    assert tok._child_tokens['1'] == 'bob'
    assert tok._child_keys['0'] == '0'
    assert tok._child_keys['1'] == '1'
    tok._value = 'alice'
    assert tok._get_value() == 'alice'
    assert tok.string == ""
    assert tok.value == 'alice'

    # Test if

# Generated at 2022-06-12 16:14:48.196257
# Unit test for constructor of class DictToken
def test_DictToken():
  from typesystem.token import ScalarToken
  dict_1 = DictToken({  
    ScalarToken('a',0,0):ScalarToken('b',0,0),  
    ScalarToken('c',0,0):ScalarToken('d',0,0)
  },0,0,content='{a:b, c:d}')
  dict_2 = DictToken({
    ScalarToken('x',0,0):ScalarToken('y',0,0),  
    ScalarToken('z',0,0):ScalarToken('t',0,0)
  },0,0,content='{x:y, z:t}')

# Generated at 2022-06-12 16:14:49.753854
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken()
    assert d


# Generated at 2022-06-12 16:14:53.567449
# Unit test for constructor of class DictToken
def test_DictToken():
    dictTest = DictToken({"key1":"value1"}, 0,1, "key1=value1")
    assert dictTest.value == {"key1":"value1"}, "DictToken didn't return expected value."


# Generated at 2022-06-12 16:14:56.724534
# Unit test for constructor of class DictToken
def test_DictToken():
    test_Dict_Token = DictToken({'a':1}, 1, 3, content='{a:1}')
    assert test_Dict_Token._value == {'a':1}


# Generated at 2022-06-12 16:15:17.992050
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(None, 0, 0)
    token2 = Token(None, 0, 0)
    assert token1 == token2

# Generated at 2022-06-12 16:15:24.646299
# Unit test for constructor of class DictToken
def test_DictToken():
    class A:
        def _get_value(self):
           return self
    d = A()
    d.items = [Token(1, 2, 3), Token(2, 2, 3)]
    d.items[0]._value = 'key'
    d.items[1]._value = 'value'
    token = DictToken(d, 1, 2)
    assert token._child_tokens == {'key': 'value'}
    assert token._child_keys == {'key': 'key'}

# Generated at 2022-06-12 16:15:34.342039
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken(
        {"hello": 1, "world": 2}, start_index=0, end_index=1, content="hello world"
    )
    # Nested dictionary
    b = DictToken(
        {a: 3},
        start_index=0,
        end_index=1,
        content="hello world"
    )
    c = DictToken(
        {b: 4},
        start_index=0,
        end_index=1,
        content="hello world"
    )
    d = DictToken(
        {c: 5},
        start_index=0,
        end_index=1,
        content="hello world"
    )


# Generated at 2022-06-12 16:15:45.915988
# Unit test for constructor of class DictToken
def test_DictToken():
    tok = {
      'id':0,
      'name':"",
      'description':"",
      'story':"",
      'questions':[
      ],
      "questionType":"multipleChoice"
    }
    dt = DictToken(tok, 0, 0, content="")
    assert dt.value == {
          'id':0,
          'name':"",
          'description':"",
          'story':"",
          'questions':[
          ],
          "questionType":"multipleChoice"
        }
    assert dt.lookup([0]) == {
        "questions":[]
    }
    assert dt.lookup_key([3]) == {
        "questions"
    }

# Generated at 2022-06-12 16:15:46.934476
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(None, 0, 0)

# Generated at 2022-06-12 16:15:51.894507
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = ScalarToken(1, 1, 2)
    token2 = ScalarToken(1, 1, 2)
    assert token1 == token2
    token3 = ScalarToken(1, 2, 3)
    assert token1 != token3
    token4 = ScalarToken(2, 1, 2)
    assert token1 != token4


# Generated at 2022-06-12 16:16:00.035246
# Unit test for constructor of class DictToken
def test_DictToken():
    # Arrange
    t_key_1 = ScalarToken(5, 0, 2, content="5")
    t_value_1 = ScalarToken(3, 3, 5, content="3")
    t_child_1 = DictToken({t_key_1: t_value_1}, 0, 5, content="5:3")

    t_key_2 = ScalarToken(10, 6, 8, content="10")
    t_value_2 = ScalarToken(7, 9, 11, content="7")
    t_child_2 = DictToken({t_key_2: t_value_2}, 6, 11, content="10:7")
    expected = {5:3, 10:7}

    # Act

# Generated at 2022-06-12 16:16:07.222087
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.base import Token
    from datatest import validate

    source = "a string"

    token = Token("bar", 0, 3, source)
    other = Token("bar", 0, 3, source)

    validate(token.__eq__(other)) == True
    validate(token.__eq__("bar")) == False

    token = Token("foo", 0, 3, source)
    validate(token.__eq__("foo")) == False

# Generated at 2022-06-12 16:16:13.121104
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Setup
    token_1 = ListToken([1,2,3], 1, 6)
    token_2 = ListToken([1,2,3], 1, 6)

    # Run
    r_1 = token_1.__eq__(token_2)
    r_2 = token_2.__eq__(token_1)

    # Assertions
    assert r_1 == r_2
    assert r_1 == True
    assert isinstance(r_1, bool)

# Generated at 2022-06-12 16:16:14.516565
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    Token()

# Generated at 2022-06-12 16:16:45.640848
# Unit test for constructor of class DictToken
def test_DictToken():
    inner_tokens = {"1": ScalarToken("12", 0, 0, "2")}
    dt = DictToken(inner_tokens, 0, 0, "2")
    assert dt._child_keys["1"] == ScalarToken("1", 0, 0, "2")
    assert dt._child_tokens["1"] == ScalarToken("12", 0, 0, "2")


# Generated at 2022-06-12 16:16:48.000677
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken({"a": 1, "b": 2}, 0,0)


# Generated at 2022-06-12 16:16:53.305462
# Unit test for constructor of class DictToken
def test_DictToken():
    # Statement to initialize variables
    value = {'a': 1, 'b': 2}
    start_index = 0
    end_index = 1
    content = 'abc'
    dictToken = DictToken(value, start_index, end_index, content)
    # Test to check if the initialized object is not None
    assert dictToken is not None

# Generated at 2022-06-12 16:16:59.372108
# Unit test for constructor of class DictToken
def test_DictToken():
    # Create a list of tuples to be used as arguments
    args = [("hello", "world"), ("another", "example")]
    # Create the DictToken object
    a = DictToken(args)
    # Check the output
    # It should print: DictToken({'hello': 'world', 'another': 'example'})
    print(a)


# Generated at 2022-06-12 16:17:08.067884
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a':1, 'b':2}
    tokens = dict()
    for k, v in d.items():
        tokens[k] = ScalarToken(v, 1, 2)
    tok = DictToken(tokens, 0, 3, '')
    # Test constructor
    assert tok._start_index == 0
    assert tok._end_index == 3
    # Test _get_value()
    assert tok._get_value() == {'a':1, 'b':2}
    # Test _get_child_token()
    assert tok._get_child_token('a')._value == 1
    # Test _get_key_token()
    assert tok._get_key_token('a')._value == 'a'


# Generated at 2022-06-12 16:17:19.896990
# Unit test for constructor of class DictToken
def test_DictToken():
    _value = {
        "key": 123
    }
    _start_index = 0
    _end_index = 3
    _content = "123"
    a = DictToken(_value, _start_index, _end_index, _content)
    assert isinstance(a, Token)
    assert a.value == {
        "key": 123
    }
    assert a.start == Position(1,1,0)
    assert a.end == Position(1,4,3)
    assert a.string == "123"
    assert a.lookup([0, 0]) == _value[0][0]
    assert a.lookup_key([0, 0]) == _value[0][0]

    _value2 = {
        "key2": {}
    }
    _content2 = "?"

# Generated at 2022-06-12 16:17:23.591097
# Unit test for constructor of class DictToken
def test_DictToken():
    v = DictToken({'foo': 'bar'}, 0, 1, content='{"foo":"bar"}')
    assert v._get_value() == {'foo': 'bar'}


# Generated at 2022-06-12 16:17:27.071231
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken({"a":1, "b":2}, 0, 20)
    assert dt._value == {"a":1, "b":2}
    assert dt._start_index == 0
    assert dt._end_index == 20 


# Generated at 2022-06-12 16:17:33.696050
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.tokenizer import DictToken
    from typesystem.tokenizer import ScalarToken
    value = {ScalarToken("key1", 0, 0) : ScalarToken("value1", 0, 0), ScalarToken("key2", 0, 0) : ScalarToken("value2", 0, 0)}
    start_index = 0
    end_index = 0
    content = "content"
    token = DictToken(value, start_index, end_index, content)

# Generated at 2022-06-12 16:17:41.012653
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken({}, 0, 1)
    assert t._child_keys == dict()
    assert t._child_tokens == dict()
    with raises(AttributeError):
        t._get_value()
    with raises(AttributeError):
        t._get_child_token()
    with raises(AttributeError):
        t._get_key_token()


# Generated at 2022-06-12 16:18:16.313283
# Unit test for constructor of class DictToken
def test_DictToken():
    value_1 = ScalarToken(1,1 ,1,"")
    value_2 = ScalarToken(2,2 ,2,"")

    value = {
        ScalarToken(1,1 ,1,""): ScalarToken(2,2 ,2,"")
    }

    dict_token = DictToken(value,1,1,"")
    assert dict_token._child_keys == {value_1._value : value_1}
    assert dict_token._child_tokens == {value_1._value: value_2}


# Generated at 2022-06-12 16:18:28.752557
# Unit test for constructor of class DictToken
def test_DictToken():
    test_key = "hello"
    test_value = "world"
    test_content = test_key + ":" + test_value
    dict_token = DictToken(
        value={test_key: test_value},
        start_index=0,
        end_index=len(test_content) - 1,
        content=test_content)
    assert dict_token._value == {test_key: test_value}
    assert dict_token._start_index == 0
    assert dict_token._end_index == len(test_content) - 1
    assert dict_token._content == test_content
    assert dict_token._get_value() == {test_key: test_value}
    assert dict_token.start == Position(line_no=1, column_no=1, index=0)
    assert dict

# Generated at 2022-06-12 16:18:36.866987
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken("value", "start", "end", "content")
    assert repr(token) == 'DictToken("value")'
    assert token.string == '"value"'
    assert token.value == 'value'
    assert token.start == "start"
    assert token.end == "end"
    assert token.lookup("index") == 'DictToken("value").lookup("index")'
    assert token.lookup_key("index") == 'DictToken("value").lookup_key("index")'
    assert token._get_position("index") == "DictToken('value')._get_position('index')"
    assert token._get_value() == "DictToken('value')._get_value()"

# Generated at 2022-06-12 16:18:47.779406
# Unit test for constructor of class DictToken
def test_DictToken():
    _dict = {
        'foo': 'bar',
        'baz': 'bat'
    }
    start_index = 2
    end_index = 5
    _content = '12\n3456\n'
    _value = {
        'foo': 'bar',
        'baz': 'bat'
    }
    _child_keys = {k._value: k for k in _value.keys()}
    _child_tokens = {k._value: v for k, v in _value.items()}

    _dictToken = DictToken(_value, start_index, end_index,_content)

    assert _dictToken._value == _value
    assert _dictToken._start_index == start_index
    assert _dictToken._end_index == end_index
    assert _dictToken._content == _

# Generated at 2022-06-12 16:18:52.906460
# Unit test for constructor of class DictToken
def test_DictToken():
    a = {1: 2, 3: 4}
    dt = DictToken(a, 0, 1)
    assert dt._value==a
    assert dt._start_index==0
    assert dt._end_index==1
    assert dt._content==""


# Generated at 2022-06-12 16:18:59.244674
# Unit test for constructor of class DictToken
def test_DictToken():
    # arrange
    token = DictToken(
        {1:1, 2:2}, 1, 3, content="{'a': 1, 'b' 2}"
    )
    
    # act
    
    # assert
    assert token._value == {1:1, 2:2}
    assert token._start_index == 1
    assert token._end_index == 3
    assert token._content == "{'a': 1, 'b' 2}"
    assert token._child_keys == {1:1, 2:2}
    assert token._child_tokens == {1:1, 2:2}


# Generated at 2022-06-12 16:19:11.294577
# Unit test for constructor of class DictToken
def test_DictToken():
    # TODO: use pytest
    from typesystem.parser import Parser
    from typesystem.types import Dict, Array
    from typesystem.types import Integer as IntegerType
    from typesystem.types import String as StringType

    person = Dict(
        {
            "age": IntegerType(required=True),
            "name": StringType(min_length=1, max_length=10),
        },
        required=True,
    )
    person_parser = Parser(person)
    person_token = person_parser.parse('{"age": 18, "name": "x"}')
    print(person_token)
    print(person_token.value)
    assert person_token._value[0]._value == "age"
    assert person_token._value[0]._get_value() == "age"


# Generated at 2022-06-12 16:19:13.982097
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({'a': 1, 'b': 2})
    print(token._get_value())


# Generated at 2022-06-12 16:19:16.784322
# Unit test for constructor of class DictToken
def test_DictToken():
    source = "a: 1\nb: 2"
    
    assert DictToken(value, 0, len(source) - 1, source) == DictToken(value, 0, len(source) - 1, source)

# Generated at 2022-06-12 16:19:20.005281
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken('a', 1, 1, 'b')
    assert a._content == 'b'
    assert a._start_index == 1
    assert a._end_index == 1
    assert a._value == 'a'


# Generated at 2022-06-12 16:20:26.898646
# Unit test for constructor of class DictToken
def test_DictToken():
    print("test_DictToken")
    k = ScalarToken(0, 5, 6, content = "a:1")
    v = ScalarToken(1, 5, 6, content = "a:1")
    d = DictToken({k: v}, 0, 5, 6, content = "a:1")
    assert(isinstance(d, Token))
    assert(d._value == {k: v})
    assert(d._start_index == 0)
    assert(d._end_index == 5)
    assert(d._content == "a:1")
    assert(d._child_keys == {k._value: k})
    assert(d._child_tokens == {k._value: v})
    assert(d.string == "a:1")

# Generated at 2022-06-12 16:20:30.773112
# Unit test for constructor of class DictToken
def test_DictToken():
    obj = DictToken(0, "aa", "bb")
    assert (obj._value, obj._start_index, obj._end_index, obj._content) == (0, "aa", "bb", "")

# Generated at 2022-06-12 16:20:35.370547
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({1:2})
    assert token._start_index == None
    assert token._end_index == None
    assert token._content == ""
    assert token._child_keys == {1:1}
    assert token._child_tokens == {1:2}
    
    

# Generated at 2022-06-12 16:20:39.397645
# Unit test for constructor of class DictToken
def test_DictToken():
    # test_value = [{}]
    # test_start_index = 0
    # test_end_index = 0
    # test_init = DictToken(test_value, test_start_index, test_end_index)
    # assert test_init._child_keys == {k._value: k for k in self._value.keys()}
    # assert test_init._child_tokens == {k._value: v for k, v in self._value.items()}
    pass


# Generated at 2022-06-12 16:20:47.656989
# Unit test for constructor of class DictToken
def test_DictToken():
    import typesystem
    doc = {
        "a": [1, 2, 3],
        "b": [],
        "c": {
            "c1": [1, 2, 3],
            "c2": [1, 2, 3]
        }
    }

    for i in range(4):
        new_doc = doc.copy()
        for k in doc.keys():
            if len(doc[k]) != 0:
                new_doc[k] = doc[k][:i]
        schema = typesystem.Schema(new_doc)
        assert schema.validate(doc)



# Generated at 2022-06-12 16:20:54.180348
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({'a': 1}, 0, 1, 'a:1')
    assert (token._child_keys) == {'a': Token('a', 0, 1, 'a:1')}
    assert (token._child_tokens) == {'a': Token(1, 2, 3, 'a:1')}


# Generated at 2022-06-12 16:21:02.068231
# Unit test for constructor of class DictToken
def test_DictToken():
    content = '{"key": "value"}'
    start_index = 0
    end_index = 13
    d = {"key": "value"}
    d = {k: ScalarToken(v, start_index, end_index, content) for k, v in d.items()}
    x = DictToken(d, start_index, end_index)
    assert x.value == d
    assert x.start.line_no == 1
    assert x.start.column_no == 1
    assert x.start.index == 0
    assert x.end.line_no == 1
    assert x.end.column_no == 14
    assert x.end.index == 13
    assert x.string == content
    assert x._child_keys == d.keys()
    assert x._child_tokens == d.values()


# Generated at 2022-06-12 16:21:03.658661
# Unit test for constructor of class DictToken
def test_DictToken():
    pass


# Generated at 2022-06-12 16:21:05.820827
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a": "b"}, 0, 1, "aaa")


# Generated at 2022-06-12 16:21:12.121838
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1, "b": 2}, 0, 4, "a: 1")
    assert token._child_keys["a"].string == "a"
    assert token._child_keys["a"]._value == "a"
    assert token._child_tokens["a"].string == "1"
    assert token._child_tokens["a"]._value == 1