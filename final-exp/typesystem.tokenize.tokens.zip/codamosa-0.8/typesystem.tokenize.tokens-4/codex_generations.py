

# Generated at 2022-06-12 16:12:26.254182
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token('a', 1, 2)
    token2 = Token('b', 1, 2)
    token3 = Token('a', 2, 3)
    token4 = Token('a', 1, 2)
    assert token1 == token1
    assert token1 != token2
    assert token1 != token3
    assert token1 == token4


# Generated at 2022-06-12 16:12:33.957186
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for same value and position
    token1 = ScalarToken(1000,0,0)
    token2 = ScalarToken(1000,0,0)
    assert token1 == token2
    # Test for different values
    token1 = ScalarToken(1000,0,0)
    token2 = ScalarToken(2000,0,0)
    assert not (token1 == token2)
    # Test for different positions
    token1 = ScalarToken(1000,0,0)
    token2 = ScalarToken(1000,1,1)
    assert not (token1 == token2)



# Generated at 2022-06-12 16:12:44.046686
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert ScalarToken(1, 0, 0, content='test').__eq__(ScalarToken(1, 0, 0, content='test'))
    assert not (ScalarToken(1, 0, 0, content='test').__eq__(ScalarToken(2, 0, 0, content='test')))
    assert not (ScalarToken(1, 0, 0, content='test').__eq__(ScalarToken(1, 1, 0, content='test')))
    assert not (ScalarToken(1, 0, 0, content='test').__eq__(ScalarToken(1, 0, 1, content='test')))

# Generated at 2022-06-12 16:12:51.185453
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(value=0, start_index=1, end_index=2, content="example")
    t2 = Token(value=1, start_index=1, end_index=2, content="example")
    t3 = Token(value=0, start_index=1, end_index=2, content="example")
    if (not (t1 == t1)):
        raise RuntimeError
    if ((t1 == t2) or (t2 == t3) or (t3 == t1)):
        raise RuntimeError


# Generated at 2022-06-12 16:13:03.756366
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    jsonstr = '{"a": 1, "b": 2}'
    t = Token(
        value={"a": 1, "b": 2},
        start_index=0,
        end_index=len(jsonstr) - 1,
        content=jsonstr,
    )
    t2 = Token(
        value={"a": 1, "b": 2},
        start_index=0,
        end_index=len(jsonstr) - 1,
        content=jsonstr,
    )
    t3 = Token(
        value={"a": 1, "b": 3},
        start_index=0,
        end_index=len(jsonstr) - 1,
        content=jsonstr,
    )
    assert t == t2
    assert t != t3

# Generated at 2022-06-12 16:13:08.076613
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = ScalarToken(1, 2, 3)
    token2 = ScalarToken(1, 2, 3)
    token3 = ScalarToken(1, 4, 5)
    assert token1 == token1
    assert token1 == token2
    assert token2 == token1
    assert token2 == token2
    assert token1 != token3
    assert token3 != token1
    return


# Generated at 2022-06-12 16:13:10.305047
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.token import Token
    x = Token(None, None, None)
    x_eq = Token(None, None, None)
    x_not_eq = Token(1, None, None)
    assert x == x_eq and x != x_not_eq


# Generated at 2022-06-12 16:13:20.095439
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    import typesystem
    import typesystem.exceptions
    import pytest
    token1 = typesystem.exceptions.TypeSystemError.failure_token(
        {
            "a": {
                "b": "c",
                "d": "e"
            }
        }
        ,
        {
            (): {
                "a": "test",
                "c": "test"
            },
            ("a",): {
                "b": "test",
                "d": "test"
            },
            ("a", "b"): "test",
            ("a", "d"): "test"
        }
        ,
        "test"
    )

# Generated at 2022-06-12 16:13:22.957684
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    value = "value"
    start_index = 1
    end_index = 5
    content = "content"
    token = Token(value, start_index, end_index, content)
    assert(token == token)


# Generated at 2022-06-12 16:13:26.781595
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_one = Token(value="To change this template file, choose Tools | Templates and open the template in the editor.", start_index=104, end_index=244)
    token_two = Token(value="To change this template file, choose Tools | Templates and open the template in the editor.", start_index=104, end_index=244)
    assert token_one == token_two


# Generated at 2022-06-12 16:13:34.733480
# Unit test for constructor of class DictToken
def test_DictToken():
    k = ScalarToken(None)
    v = ListToken([],0,0)
    a = {}
    a[k] = v
    d = DictToken(a, 0, 0)
    print(d._child_keys)
    print(d._child_tokens)


# Generated at 2022-06-12 16:13:41.072244
# Unit test for constructor of class DictToken
def test_DictToken():
	d = {1 : 2 , 'two' : 'three', 4 : 5 }
	f = DictToken(d, 0 , 100, content="")
	g = f._get_value()
	if (g == d):
		print("test_DictToken: Test passed")
	else:
		print("test_DictToken: Test failed")


# Generated at 2022-06-12 16:13:49.808489
# Unit test for constructor of class DictToken
def test_DictToken():
    # test Token.__init__
    # initialize some arguments
    value = {1:2}
    start_index = 3
    end_index = 5
    content = "abc"
    dt = DictToken(value, start_index, end_index, content)
    # check that _value, _start_index, _end_index and _content are
    # stored correctly
    assert dt._value == value
    assert dt._start_index == start_index
    assert dt._end_index == end_index
    assert dt._content == content


# Generated at 2022-06-12 16:13:52.870266
# Unit test for constructor of class DictToken
def test_DictToken():
    data = b"{\"field_a\": 123}"
    parser = JsonParser(data)
    token = parser.parse()
    assert token


# Generated at 2022-06-12 16:13:53.489811
# Unit test for constructor of class DictToken
def test_DictToken():
    assert True

# Generated at 2022-06-12 16:13:54.694020
# Unit test for constructor of class DictToken
def test_DictToken():
    pass


# Generated at 2022-06-12 16:13:58.659903
# Unit test for constructor of class DictToken
def test_DictToken():
    c = DictToken('key1', start_index=0, end_index=10, content='content')
    assert c._child_keys == 'key1'
    assert c._child_tokens == 'key1'
# test_DictToken()


# Generated at 2022-06-12 16:14:08.710492
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken(value={"key": "value"}, start_index=5, end_index=7)
    assert(isinstance(d, Token))
    assert(set(d._child_keys) == set(["key"]))
    assert(set(d._child_tokens) == set(["key"]))
    assert(d._child_tokens["key"] == "value")
    assert(d._child_keys["key"] == "key")
    assert(d.value == {"key": "value"})
    assert(d.string == "value")
    assert(d.start == Position(1, 8, 7))
    assert(d.end == Position(1, 11, 10))
    assert(d.lookup(["key"]) == "value")

# Generated at 2022-06-12 16:14:15.352269
# Unit test for constructor of class DictToken
def test_DictToken():
    key_token = ScalarToken("key", 1, 1, "content")
    value_token = ScalarToken("value", 2, 2, "content")
    token = DictToken({key_token: value_token}, 3, 3, "content")
    assert token.value == "value"
    assert token._child_tokens[key_token._value] is value_token
    assert token._child_keys[key_token._value] is key_token



# Generated at 2022-06-12 16:14:16.209760
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({},start_index=0,end_index=0,content='')

# Generated at 2022-06-12 16:14:30.365160
# Unit test for constructor of class DictToken
def test_DictToken():
    doc = yaml.load("""
        a: 1
        b: 2
    """)
    assert isinstance(doc, dict)
    assert isinstance(doc['a'], int)
    assert isinstance(doc['b'], int)

    tokens = yaml.YAML(typ='rt', pure=True).compose_all("""
        a: 1
        b: 2
    """)
    assert isinstance(tokens[0], yaml.DictToken)
    assert isinstance(tokens[0].value['a'], yaml.ScalarToken)
    assert isinstance(tokens[0].value['b'], yaml.ScalarToken)
    assert tokens[0].value['a'].value == '1'

# Generated at 2022-06-12 16:14:31.769254
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken()
    assert token._get_value() == {}


# Generated at 2022-06-12 16:14:39.963287
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(value={'a': 1}, start_index=1, end_index=2, content="aa")
    assert token.value == {'a': 1}
    assert token.start == Position(1, 1, 1)
    assert token.end == Position(2, 2, 2)
    assert token.string == "a"
    assert token.lookup([1, 2]).value == 1


# Generated at 2022-06-12 16:14:45.928200
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken({1: 11, 2: 22}, 0, 5, "hello")
    assert dt._start_index == 0
    assert dt._end_index == 5
    assert dt._content == "hello"
    dt._get_value() == {1: 11, 2: 22}
    dt._get_child_token(2) == 22
    dt._child_keys == {1: 11, 2: 22}
    dt._child_tokens == {1: 11, 2: 22}


# Generated at 2022-06-12 16:14:47.389158
# Unit test for constructor of class DictToken
def test_DictToken():
    c = DictToken({"A": 1, "B": 2})

# Generated at 2022-06-12 16:14:54.564009
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {"a":1, "b":2}
    d2 = {"c":3, "d":4}
    b = {"e":d, "f":d2}
    t = DictToken(b, 0, 5)
    assert t._child_keys == {"e":DictToken(d, 0, 1), "f":DictToken(d2, 0, 1)}
    assert t._child_tokens == {"e":1, "f":2}


# Generated at 2022-06-12 16:15:02.787564
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken(value={"a": ["b"]}, start_index=1, end_index=2, content="abc")
    assert repr(d) == "DictToken(%s)" % (repr("{"))
    assert d.start == Position(1, 1, 1)
    assert d.end == Position(1, 2, 2)
    assert d.string == "{"
    assert d.value == {"a": ["b"]}
    assert d.lookup([0]) == "a"
    assert d.lookup_key([0, 0]) == "a"


# Generated at 2022-06-12 16:15:09.727327
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken("value", "start_index", "end_index", "content")
    # Assert the attribute exists to be used in next 3 assertions
    assert d._child_keys
    assert d._child_tokens
    assert d._value
    d.__init__("value", "start_index", "end_index", "content")
    assert d._child_keys
    assert d._child_tokens
    assert d._value


# Generated at 2022-06-12 16:15:10.593500
# Unit test for constructor of class DictToken
def test_DictToken():
    pass


# Generated at 2022-06-12 16:15:12.002887
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken(1,2,3,4, [1,2,3])
    assert d

# Generated at 2022-06-12 16:15:30.120042
# Unit test for constructor of class DictToken
def test_DictToken():

	args = {}
	kwargs = [
		{'value': {'foo': 0, 'bar':1}, 'start_index':0, 'end_index':23, 'content': '{"foo": 1, "bar": 2}'},
		{'value': {'foo': 0, 'bar':1}, 'start_index':0, 'end_index':23, 'content': '{"foo": 1, "bar": 2}'},
		{'value': {'foo': 0, 'bar':1}, 'start_index':0, 'end_index':23, 'content': '{"foo": 1, "bar": 2}'}
	]

	for kwarg in kwargs:
		test_token = DictToken(**kwarg)
		assert test_token._value == kwarg['value']

# Generated at 2022-06-12 16:15:36.135418
# Unit test for constructor of class DictToken
def test_DictToken():
    def test_init(case):
        args = case[0]
        kwargs = case[1]
        expected = case[2]
        result = DictToken(*args, **kwargs)
        assert result._value == expected

    test_init([[], {}, ()])
    test_init([[1], {}, (1)])
    test_init([[1,2], {}, (1,2)])
    test_init([[1,2], {'a':1}, (1,2)])


# Generated at 2022-06-12 16:15:48.412262
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken("a", 1, 2).value == "a"
    assert DictToken("a", 1, 2, content="abc").value == "a"
    assert DictToken("a", 1, 2).string == "a"
    assert DictToken("a", 1, 2, content="abc").string == "a"
    assert DictToken("a", 1, 2).start == Position(1, 1, 1)
    assert DictToken("a", 1, 2, content="abc").start == Position(1, 1, 1)
    assert DictToken("a", 1, 2).end == Position(1, 2, 2)
    assert DictToken("a", 1, 2, content="abc").end == Position(1, 2, 2)

# Generated at 2022-06-12 16:15:55.863753
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.structures import Dict
    
    try:
        d = Dict()
        d.add_property("a", int)
        d.add_property("b", int)
        
        d.validate({"a": 6, "b": 7})
        d.validate({"a": 8, "b": 9})
        
        token = DictToken(d.value, 1, 2)
        assert(str(token) != "<class '__main__.DictToken'>" or token._value != None)
    except NotImplementedError:
        assert False


# Generated at 2022-06-12 16:16:07.606918
# Unit test for constructor of class DictToken

# Generated at 2022-06-12 16:16:10.875603
# Unit test for constructor of class DictToken
def test_DictToken():
    #dummy = DictToken()
    token = DictToken(value = {}, start_index = 10, end_index = 10)
    assert token._child_tokens == {}
    assert token._child_keys == {}


# Generated at 2022-06-12 16:16:22.845379
# Unit test for constructor of class DictToken
def test_DictToken():
    dict={
        1:1,
        2:2,
        3:3
    }
    dicttoken=DictToken(dict, 3, 3, "123")
    d={
        1:1,
        2:2,
        3:3
    }
    assert dicttoken._get_value()==d
    assert dicttoken.string=="123"
    assert dicttoken.start==Position(1, 1, 3)
    assert dicttoken.end==Position(1, 3, 3)
    assert dicttoken.lookup([1])._get_value()==1
    assert dicttoken.lookup([2])._get_value()==2
    assert dicttoken.lookup([3])._get_value()==3
    assert dicttoken.lookup_key([1])._get_value()==1
    assert dicttoken

# Generated at 2022-06-12 16:16:33.173317
# Unit test for constructor of class DictToken
def test_DictToken():
    token_test = DictToken(
        {'Hello': (2, 3)},
        2,
        3,
        'Hello'
    )
    assert token_test != DictToken(
        {'Hello': 4},
        2,
        3,
        'Hello'
    )
    assert token_test == DictToken(
        {'Hello': (2, 3)},
        2,
        3,
        'Hello'
    )
    assert token_test._start_index == 2
    assert token_test._end_index == 3
    assert token_test._get_value() == {'Hello': (2,3)}
    assert token_test._child_keys == {'Hello': {'Hello': (2, 3)}}

# Generated at 2022-06-12 16:16:40.989809
# Unit test for constructor of class DictToken
def test_DictToken():
	start = 0
	end = 0
	content = "1"
	value = {ScalarToken(1, 0, 1)}
	token1 = DictToken(value, start, end, content)
	assert token1._value == value
	assert token1._start_index == start
	assert token1._end_index == end
	assert token1._content == content


# Generated at 2022-06-12 16:16:46.735614
# Unit test for constructor of class DictToken
def test_DictToken():
    '''
    This function tests if the constructor of class DictToken works.
    :return: None
    '''
    token = DictToken(
        {1: 1},
        0,
        0,
        content="",
    )
    assert token._value == {1: 1}
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""



# Generated at 2022-06-12 16:17:05.379418
# Unit test for constructor of class DictToken
def test_DictToken():
    dic = {'foo':1,'bar':2,'baz':3}
    start_index = 0
    end_index = 2
    assert DictToken(dic,start_index,end_index) is not None
    assert DictToken(dic,start_index,end_index)._child_tokens is not None
    assert DictToken(dic,start_index,end_index)._child_keys is not None

# Generated at 2022-06-12 16:17:06.814591
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a":1,"b":2},0,0)



# Generated at 2022-06-12 16:17:12.860064
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a':1, 'b':3, 'c':3}
    token = DictToken(d, 0, 10, 'a:1, b:2, c:3')
    assert token._child_tokens == {'a':1, 'b':2, 'c':3}

# Generated at 2022-06-12 16:17:16.663915
# Unit test for constructor of class DictToken
def test_DictToken(): 
    d = {'name': 'hong', 'age': 17, 'hobby': ['fishing', 'reading'], 'buddy': [{'name': 'may', 'age': 17}]}
    dict_token = DictToken(d)


# Generated at 2022-06-12 16:17:18.126185
# Unit test for constructor of class DictToken
def test_DictToken():
    _x = DictToken([1,2,3],2,3,"",) # noqa: F821
    _x = DictToken((1,2,3),2,3,"",) # noqa: F821

# Generated at 2022-06-12 16:17:27.104533
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_obj = {
        ScalarToken('key1', 100, 105): ScalarToken('value1', 106, 114),
        ScalarToken('key2', 115, 119): ScalarToken('value2', 120, 128)
    }
    token = DictToken(dict_obj, 0, 128, 'key1=value1, key2=value2')
    assert token._child_keys == {'key1': ScalarToken('key1', 100, 105), 'key2': ScalarToken('key2', 115, 119)}
    assert token._child_tokens == {'key1': ScalarToken('value1', 106, 114), 'key2': ScalarToken('value2', 120, 128)}


# Generated at 2022-06-12 16:17:36.447280
# Unit test for constructor of class DictToken
def test_DictToken():
    dic = {'a':'b', 'c':'d'}
    token = DictToken(dic,0,2,'a=b\nc=d')
    assert (token.__dict__['_value']) == {'a':'b', 'c':'d'}
    assert (token.__dict__['_child_keys']) == {'a':'b', 'c':'d'}
    assert (token.__dict__['_child_tokens']) == {'a':'b', 'c':'d'}
    assert (token.__dict__['_start_index']) == 0
    assert (token.__dict__['_end_index']) == 2
    assert (token.__dict__['_content']) == 'a=b\nc=d'

# Generated at 2022-06-12 16:17:48.033794
# Unit test for constructor of class DictToken
def test_DictToken():
    length = 10
    content = ""
    for i in range(length):
        content += "line %s\n" % i

    def get_token(start: int) -> Token:
        end = start + 2
        index = content[start : end + 1]
        return ScalarToken(index, start, end, content)

    def get_dict(start: int) -> typing.Dict[Token, Token]:
        end = start + 2
        index = content[start : end + 1]
        return {get_token(start): get_token(end)}

    def get_dict_token(start: int, end: int) -> DictToken:
        return DictToken(get_dict(start), start, end, content=content)


# Generated at 2022-06-12 16:17:59.722802
# Unit test for constructor of class DictToken
def test_DictToken():
    token_key = ScalarToken(value=1, start_index=1, end_index=1)
    token_value = ScalarToken(value=2, start_index=2, end_index=2)
    token = DictToken(value={token_key: token_value}, start_index=1, end_index=2)
    assert token.string == "token_key: token_value"
    assert token.value == {1:2}
    assert token.start == Position(line_no=1, column_no=1, index=1)
    assert token.end == Position(line_no=1, column_no=2, index=2)
    assert token._get_child_token(key=1) == token_value
    assert token._get_key_token(key=1) == token_key
#

# Generated at 2022-06-12 16:18:00.360464
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken is not None

# Generated at 2022-06-12 16:18:33.315174
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem import error, types

    data = {"a": 0.1, "b": 0.2}
    string = '{"a": 0.1, "b": 0.2}'
    parser = types.Dict()
    schema_token = parser.get_schema_token()
    # constructor of class DictToken
    dict_token = DictToken(value={}, start_index=0, end_index=6, content=string)
    assert dict_token._get_value() == {}
    assert dict_token.string == '{"a": 0.1, "b": 0.2}'
    assert dict_token.value == {}
    assert dict_token.start == Position(1, 1, 0)
    assert dict_token.end == Position(1, 24, 23)
    dict_token_2 = dict

# Generated at 2022-06-12 16:18:34.235053
# Unit test for constructor of class DictToken
def test_DictToken():
    a = 1

# Generated at 2022-06-12 16:18:36.916113
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import Integer, String

    token = DictToken(
        {"key": String()}, 0, 10, content="{ 'key': 'value' }"
    )

# Generated at 2022-06-12 16:18:39.611242
# Unit test for constructor of class DictToken
def test_DictToken():
  d = DictToken(1,2,'test')
  assert d.value == 2


# Generated at 2022-06-12 16:18:40.629426
# Unit test for constructor of class DictToken
def test_DictToken():
    Token = DictToken()


# Generated at 2022-06-12 16:18:41.840239
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"key":"value"},"0","5")
    assert token != None

# Generated at 2022-06-12 16:18:52.824629
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import type_definition
    from typesystem.base import types
    from typesystem.base import ValidationError

    @type_definition("address")
    class AddressType:
        street = types.String(max_length=30)
        zip_code = types.Integer(max_value=10000)

    @type_definition
    class UserType:
        name = types.String(max_length=30)
        address = AddressType()
        extra_data = types.Dict(types.String(max_length=30))

    user = UserType(
        name="Cercei Lannister",
        address=AddressType(street="Red Keep", zip_code=10000),
        extra_data={"key1": "value1", "key2": "value2"},
    )


# Generated at 2022-06-12 16:18:56.435579
# Unit test for constructor of class DictToken
def test_DictToken():
    _dict_token = DictToken(value={},start_index=0,end_index=0)
    assert _dict_token._value == {}
    assert _dict_token._start_index == 0
    assert _dict_token._end_index == 0
    assert _dict_token._content == ""


# Generated at 2022-06-12 16:19:07.933841
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_value = dict()
    dict_value['foo'] = '12345'
    dict_value['bar'] = 'helloworld'
    dict_value['baz'] = 'science'
    dict_token = DictToken(dict_value, 0, 0, '[{"foo":"1","bar":"2","baz":"3"}]')
    assert dict_token.start == Position(1, 1, 0)
    assert dict_token.end == Position(1, 1, 0)
    assert dict_token.string == ''
    
    dict_token2 = DictToken(dict_value, 2, 2, 'haha')
    assert dict_token2.start == Position(1, 1, 2)
    assert dict_token2.end == Position(1, 1, 2)
    assert dict_token2.string == ''


# Generated at 2022-06-12 16:19:18.488307
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem import Schema
    from typesystem.types import String

    # initialize a dictionary
    dictionary = {
        "Key1": "Value1", 
        "Key2": "Value2",
        "Key3": "Value3"
    }

    # initialize a schema, for testing purposes we consider a string schema
    schema = Schema(Key1=String(),
                Key2=String(),
                Key3=String())
    
    # initialize a token
    token = DictToken(value=dictionary, start_index=0, end_index=0, content="")
    
    # check if the value of the token is the value of the dictionary
    assert token.value == dictionary
    
    # check if start and end indices are equal to zero
    assert token.start.line_number == 0
    assert token.start.column

# Generated at 2022-06-12 16:20:09.801352
# Unit test for constructor of class DictToken
def test_DictToken():
  dict_token = DictToken({"token_key":"token_value"}, 0, 4, "dict_token_string")
  assert dict_token._child_keys["token_key"] == "token_value"
  assert dict_token._child_tokens["token_key"] == "token_value"

# Generated at 2022-06-12 16:20:12.625171
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"key": "value"}, 0, 0, content="content").__class__.__name__ == "DictToken"


# Generated at 2022-06-12 16:20:17.466771
# Unit test for constructor of class DictToken
def test_DictToken():
    key = ScalarToken(value=1, start_index=0, end_index=0)
    value = ScalarToken(value=2, start_index=1, end_index=1)
    dt = DictToken(value={key: value}, start_index=0, end_index=1, content="12")
    assert dt._value == {key: value}
    assert dt._start_index == 0
    assert dt._end_index == 1
    assert dt._content == "12"
    dt1 = DictToken(value={}, start_index=0, end_index=0, content="")
    assert dt1._value == {}
    assert dt1._start_index == 0
    assert dt1._end_index == 0
    assert dt1._content == ""
    key

# Generated at 2022-06-12 16:20:26.450644
# Unit test for constructor of class DictToken
def test_DictToken():
    t1 = DictToken({{1,2}: {3:2}}, 0, 4, '{1,2:3}')
    assert t1._child_keys.keys() == {1,2}
    assert t1._child_tokens.keys() == {1,2}
    assert t1._child_tokens[1].string == '2'
    assert t1._child_tokens[2].string == '3'
    assert t1._value == {1:2, 2:3}
    assert t1.lookup([0]).string == '2'
    assert t1.lookup([1]).string == '3'
    assert t1.lookup_key([1]).string == '2'

# Generated at 2022-06-12 16:20:32.659395
# Unit test for constructor of class DictToken
def test_DictToken():
    di={"a":1,"b":2} # "a":1
    kwargs={"value":di,"start_index":0,"end_index":1,"content":"a"} # Add all the arguments
    d=(DictToken(**kwargs))
    assert(d)


# Generated at 2022-06-12 16:20:34.565295
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(1,2,3,4)
    print(token)
    print(token.value)


# Generated at 2022-06-12 16:20:40.003881
# Unit test for constructor of class DictToken
def test_DictToken():
    print("Test DictToken")
    # Example of DictToken usage
    t1 = DictToken({"1": 10, "2": 20}, 0, 100, "{")
    # Unit test for DictToken
    assert t1._start_index == 0
    assert t1._end_index == 100
    assert t1._content == "{"
    assert t1._value == {"1": 10, "2": 20}
    assert t1._child_keys == {"1": "1", "2": "2"}
    assert t1._child_tokens == {"1": 10, "2": 20}
    assert t1.value == {"1": 10, "2": 20}


# Generated at 2022-06-12 16:20:42.350073
# Unit test for constructor of class DictToken
def test_DictToken():
    result = DictToken({}, 0, 1, content = "")
    assert isinstance(result, DictToken)


# Generated at 2022-06-12 16:20:49.915013
# Unit test for constructor of class DictToken
def test_DictToken():
    a = 2
    b = 3
    c = 4
    # assert(a == b)
    d = DictToken(a, b, c, content="{}")
    assert d.string == "{}"
    assert d.value == 2
    assert d.start == Position(1, 1, 0)
    assert d.end == Position(1, 1, 0)
    assert d == DictToken(a, b, c, content="{}")
    assert not d == ScalarToken(None, 0, 0, "")
    assert not d == ListToken(None, 0, 0, "")
    assert not d == DictToken(None, 0, 0, "")

test_DictToken()

# Generated at 2022-06-12 16:21:00.796296
# Unit test for constructor of class DictToken
def test_DictToken():

    # Unit test for constructor of class Token
    def test_Token():
        _value = 1
        _start_index = 2
        _end_index = 3
        _content = ""
        token = Token(_value, _start_index, _end_index, _content)
        assert token._value == _value
        assert token._start_index == _start_index
        assert token._end_index == _end_index
        assert token._content == _content

    test_Token()

    # Unit test for constructor of class Token
    def test_Token():
        _value = 1
        _start_index = 2
        _end_index = 3
        _content = ""
        token = Token(_value, _start_index, _end_index, _content)
        assert token._value == _value