

# Generated at 2022-06-12 16:12:25.163669
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(
        "test_value",
        12,
        13,
        "content",
    ) == Token(
        "test_value",
        12,
        13,
        "content",
    )


# Generated at 2022-06-12 16:12:29.503689
# Unit test for constructor of class DictToken
def test_DictToken():
	token=DictToken(value= {'test_key':5, 'test_key2':6}, start_index=0, end_index=0, content= "")
	assert(token.value == {'test_key':5, 'test_key2':6})


# Generated at 2022-06-12 16:12:32.916670
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'key1': 'value1', 'key2': 'value2'}
    token = DictToken(d, 0, len(d), 'key1 = value1, key2 = value2')
    assert token.value == {'key1': 'value1', 'key2': 'value2'}
    assert token.start.column == 0
    assert token.end.column == len(d)
    assert token.string == d
    assert token.lookup([0]) == 'value1'
    assert token.lookup_key([0]) == 'key1'

# Generated at 2022-06-12 16:12:38.799702
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    Token(value=typing.Any, start_index=int, end_index=int, content=str) == NotImplementedError
    Token(value=typing.Any, start_index=int, end_index=int, content=str) == isinstance(other, Token) and (self._get_value() == other._get_value() and self._start_index == other._start_index and self._end_index == other._end_index)

# Generated at 2022-06-12 16:12:40.764523
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {"hello":"world"}
    token = DictToken(d)
    assert token.value


# Generated at 2022-06-12 16:12:50.188815
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test Token.__eq__()
    token1 = Token("", 0, 0)
    token2 = Token("", 0, 0)
    assert(token1 == token2)

    token1 = Token("", 0, 0)
    token2 = Token("", 0, 1)
    assert(not (token1 == token2))

    token1 = Token("", 0, 0)
    token2 = Token("", 1, 0)
    assert(not (token1 == token2))

    token1 = Token("", 0, 0)
    token2 = Token("a", 0, 0)
    assert(not (token1 == token2))

    token1 = Token("", 0, 0)
    token2 = Token("", 1, 0, "a")
    assert(not (token1 == token2))


# Generated at 2022-06-12 16:12:51.044633
# Unit test for constructor of class DictToken
def test_DictToken():
    raise NotImplementedError


# Generated at 2022-06-12 16:12:59.622058
# Unit test for constructor of class DictToken
def test_DictToken():
    content = "test"
    start_index = 0
    end_index = 3
    value = {ScalarToken("test1", content): ScalarToken("test2", content)}
    token = DictToken(value, start_index, end_index, content)
    assert token.value == {"test1": "test2"}
    assert token.string == "test"
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 4, 3)



# Generated at 2022-06-12 16:13:05.494725
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {"1": 1, "2": 2}
    t1 = Token("1", 0, 0)
    t2 = Token("2", 0, 0)
    t3 = Token("1", 0, 0)
    t4 = Token("2", 0, 0)
    token = DictToken({t1: t3, t2: t4}, 0, 0, content = "")
    assert token.value == d


# Generated at 2022-06-12 16:13:10.372830
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken(
        {0: ScalarToken(0, 0, 0), 1: ScalarToken(1, 0, 0)},
        0,
        1,
        content="[0, 1]"
    )
    assert isinstance(dict_token, DictToken)



# Generated at 2022-06-12 16:13:18.423812
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken(value={'key':'value'}, start_index=0, end_index=5, content='{key:value}')



# Generated at 2022-06-12 16:13:26.434254
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = ScalarToken(1, 0, 5, content='abcdef')
    token2 = ScalarToken(2, 0, 5, content='abcdef')
    token3 = ScalarToken(1, 2, 5, content='abcdef')
    token4 = ScalarToken(1, 0, 3, content='abcdef')
    token5 = ScalarToken(1, 0, 5, content='abcde')
    token6 = ScalarToken(1, 0, 5, content='abcdef')

    assert token1 == token6
    assert token1 != token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5
    # assert token2 != token3
    # assert token2 != token4
    # assert token2 != token5
    # assert token3 != token4
    # assert

# Generated at 2022-06-12 16:13:28.829360
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken([1,2,3,4], 1, 2, [1,2,3,4])
    DictToken([1,2,3,4], 1, 2)

# Generated at 2022-06-12 16:13:34.214728
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # test for Token
    assert Token(None, 0, 0) == Token(None, 0, 0)
    assert not Token(None, 0, 0) == Token(None, 0, 1)
    assert not Token(None, 0, 0, "a") == Token(None, 0, 0, "b")
    assert not Token(0, 0, 0) == 1
    assert not Token(0, 0, 1) == "0"


# Generated at 2022-06-12 16:13:38.289233
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    a = ScalarToken("value1", 0, 10, content="content1")
    b = ScalarToken("value1", 0, 10, content="content1")
    assert a == b



# Generated at 2022-06-12 16:13:44.361197
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """
    It should correctly compare two tokens.
    """
    token1 = Token("a", 1, 2)
    token2 = Token("a", 1, 2)
    assert token1 == token2
    token3 = Token("b", 1, 2)
    assert token1 != token3
    token4 = Token("a", 2, 3)
    assert token1 != token4



# Generated at 2022-06-12 16:13:53.340903
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    obj = Token(value=typing.Any, start_index=int, end_index=int, content=str)
    other = Token(value=typing.Any, start_index=int, end_index=int, content=str)
    if not isinstance(other, Token):
        raise RuntimeError("Expected type 'Token'")
    if not obj._get_value() == other._get_value() and not obj._start_index == other._start_index and not obj._end_index == other._end_index:
        raise RuntimeError("Expected result to be True")
    
    

# Generated at 2022-06-12 16:13:55.326838
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    T = Token(None, None, None)
    assert not T.__eq__(None)

# Generated at 2022-06-12 16:13:57.812367
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    result = Token(None, None, None).__eq__(Token(None, None, None))
    assert result is True


# Generated at 2022-06-12 16:14:01.116176
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({'a':2}, 1, 3, "Hallo")
    print(a._child_tokens[a._value.keys()])
    print(a._child_keys[a._value.keys()])


# Generated at 2022-06-12 16:14:12.506561
# Unit test for constructor of class DictToken
def test_DictToken():
    print('test_DictToken')
    

# Generated at 2022-06-12 16:14:22.875044
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem import String
    from typesystem.types import Schema

    class Domain(Schema):
        name = String()
        age = String()

    d = dict(
        name="John",
        age=40,
    )

    content = "Domain(name='John', age=40)"
    start_index = 0
    end_index = 10
    value = d
    _token = DictToken(
        value, start_index, end_index, content
    )
    assert _token._value == value
    assert _token._start_index == start_index
    assert _token._end_index == end_index
    assert repr(_token) == repr(content)
    assert isinstance(_token, Token)
    assert isinstance(_token, DictToken)


# Generated at 2022-06-12 16:14:23.914111
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    pass


# Generated at 2022-06-12 16:14:25.107737
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    pass



# Generated at 2022-06-12 16:14:33.169240
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import Dict, String
    d = Dict(
        name=String(default='test'),
        email=String(),
    ).bind()
    #
    # Key: test, string: "name"
    # Key: email, string: "email"
    assert d.keys()[0].string == 'name'
    assert d.keys()[1].string == 'email'
    #
    #
    assert d.values()[0].string == 'test'
    assert d.values()[1].string == ''
    #
    # Key: test, string: "test"
    # Key: "", string: ""
    assert d.values()[0].string == 'test'
    assert d.values()[1].string == ''

# Generated at 2022-06-12 16:14:44.594616
# Unit test for method __eq__ of class Token

# Generated at 2022-06-12 16:14:49.044943
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=None, start_index=None, end_index=None, content=None)
    other = Token(value=None, start_index=None, end_index=None, content=None)
    assert token.__eq__(other)


# Generated at 2022-06-12 16:14:55.184162
# Unit test for constructor of class DictToken
def test_DictToken():
    _value = {'key': 'value'}
    token = DictToken(_value, 0, 1)
    assert token._value == _value           # dict is saved
    assert token._child_keys == {'key': 'key'}      # key is added to _child_keys
    assert token._child_tokens == {'value': 'value'}    # value is added to _child tokens

# Generated at 2022-06-12 16:15:03.206948
# Unit test for constructor of class DictToken
def test_DictToken():
  assert DictToken
  #test child_keys and child_tokens are generated correctly
  token = DictToken({"a":5,"b":8,},start_index=0,end_index=1,content="content")
  assert token._child_keys["a"] == "a"
  assert token._child_keys["b"] == "b"
  assert token._child_tokens["a"] == 5
  assert token._child_tokens["b"] == 8
  #test value function for DictToken
  assert token._get_value() == {"a": 5, "b": 8}


# Generated at 2022-06-12 16:15:13.069114
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert ScalarToken(1, 0, 0) == ScalarToken(1, 0, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(2, 0, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 1, 1)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 2, 0)
    assert ScalarToken(1, 0, 0) != ScalarToken(1, 0, 1)
    assert ScalarToken(1, 0, 1) == ScalarToken(1, 0, 1)
    assert ScalarToken(1, 0, 1) != ScalarToken(2, 0, 1)
    assert ScalarToken(1, 0, 1) != ScalarToken(1, 1, 1)

# Generated at 2022-06-12 16:15:28.199536
# Unit test for constructor of class DictToken
def test_DictToken():
    pass

# Generated at 2022-06-12 16:15:37.023355
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # case 1
    t1 = Token("value_1", "start_index_1", "end_index_1", "content_1")
    t2 = Token("value_2", "start_index_2", "end_index_2", "content_2")
    result = t1.__eq__(t2)
    assert result == False
    # case 2
    t1 = Token("value_1", "start_index_1", "end_index_1", "content_1")
    t2 = Token("value_1", "start_index_1", "end_index_1", "content_1")
    result = t1.__eq__(t2)
    assert result == True
    # case 3

# Generated at 2022-06-12 16:15:38.967872
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(0,0,0) == Token(0,0,0)
    assert Token(0,1,1) != Token(0,0,1)
    assert Token(0,0,0) != 0
    assert Token(1,0,0) != 1

# Generated at 2022-06-12 16:15:43.504933
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem import Token
    t1 = Token(3445, 0, 4, content="3445")
    t2 = Token(3445, 0, 4, content="3445")
    assert t1 == t2


# Generated at 2022-06-12 16:15:49.298146
# Unit test for constructor of class DictToken
def test_DictToken():

    DictToken(start_index=3, end_index=4, value={"a":1, "b":2})
    DictToken(start_index=3, end_index=4, value={"a":1}, content="asdf")
    DictToken(start_index=3, end_index=4, value={"a":1}, content="asdf", **{"a":1})



# Generated at 2022-06-12 16:15:55.284555
# Unit test for constructor of class DictToken
def test_DictToken():
    t1 = Token(1, 1, 2)
    t2 = Token(2, 2, 3)
    test_dict = {
        t1: t1,
        t2: t2,
    }
    test_token = DictToken(test_dict, 1, 3)
    assert test_token._value == test_dict
    assert test_token._start_index == 1
    assert test_token._end_index == 3
    assert test_token._content == ""


# Generated at 2022-06-12 16:15:57.231406
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    start_index = 0
    end_index = 3
    content = "fffg"
    value = "fffg"
    token1 = ScalarToken(value, start_index, end_index, content)
    token2 = ScalarToken(value, start_index, end_index, content)
    assert token1 == token2


# Generated at 2022-06-12 16:15:58.066319
# Unit test for constructor of class DictToken
def test_DictToken():
    dict = DictToken()
    assert dict

# Generated at 2022-06-12 16:16:05.908867
# Unit test for constructor of class DictToken
def test_DictToken():
    input_1 = "hello"
    input_2 = 1
    input_3 = 1
    input_4 = ""
    test_object = DictToken(input_1, input_2, input_3, content = input_4)
    assert test_object._value == input_1
    assert test_object._start_index == input_2
    assert test_object._end_index == input_3
    assert test_object._content == input_4


# Generated at 2022-06-12 16:16:07.168116
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Create an instance of Token
    token = Token("", "", "")
    # Compare token and token
    assert token == token



# Generated at 2022-06-12 16:17:01.408509
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    a = ScalarToken(1, 1, 2, "[1,2]")
    b = ScalarToken(1, 1, 2, "[1,2]")
    assert a == b
    c = ScalarToken(1, 2, 3, "[1,2]")
    assert a != c


# Generated at 2022-06-12 16:17:03.395822
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {}
    kt = DictToken(d, 10, 10)


# Generated at 2022-06-12 16:17:08.476154
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_1 = ScalarToken(1, 0, 2, "abc")
    token_2 = ScalarToken(1, 0, 2, "abc")
    token_3 = ScalarToken(2, 0, 2, "abc")
    assert token_1 == token_2
    assert token_2 == token_1
    assert token_1 != token_3
    assert token_3 != token_1

# Generated at 2022-06-12 16:17:13.889610
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    try:
        class FooToken(Token): pass
        FooToken("foo", 0, 2) == FooToken("foo", 0, 2)
    except NotImplementedError:
        pass
    else:
        fail_test()


# Generated at 2022-06-12 16:17:17.457850
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(None, 0, 0, content='') == Token(None, 0, 0, content='')

    assert ScalarToken(0, 0, 0, content='') == ScalarToken(0, 0, 0, content='')


# Generated at 2022-06-12 16:17:19.986504
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """test if object is equal to other object, if they are both of same class and if they have same value"""
    assert Token("",0,0) == Token("",0,0)


# Generated at 2022-06-12 16:17:30.411974
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    line_no = 4
    column_no = 10
    index = 20
    start = Position(line_no, column_no, index)
    type_ = 2
    value = 3
    content = '{"a": {"b": 1, "c": 2}}'
    token = Token(value, type_, start, content)
    line_no = 4
    column_no = 10
    index = 20
    start = Position(line_no, column_no, index)
    type_ = 2
    value = 3
    content = '{"a": {"b": 1, "c": 2}}'
    other = Token(value, type_, start, content)
    assert token == other


# Generated at 2022-06-12 16:17:32.068838
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken({}, 0, 2, "")
    assert repr(t) == "DictToken({})"

# Generated at 2022-06-12 16:17:36.024737
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_a = ScalarToken(value=True, start_index=0, end_index=1)
    token_b = ScalarToken(value=True, start_index=0, end_index=1)
    token_c = ScalarToken(value=False, start_index=0, end_index=1)
    assert token_a == token_b
    assert token_a != token_c



# Generated at 2022-06-12 16:17:43.321200
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({'a':1},1,2,content='abcabc')
    b = DictToken({'a':1},1,2,content='abcabc')
    assert a == b
    assert a.string == 'abcabc'
    assert a.value == {'a':1}
    assert a.start == Position(1, 1, 1)
    assert a.end == Position(1, 1, 2)


# Generated at 2022-06-12 16:18:34.842334
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = ScalarToken(
        value=1,
        start_index=1,
        end_index=2,
        content="content_test"
    )
    token2 = DictToken(
        value={},
        start_index=1,
        end_index=2,
        content="content_test"
    )
    assert token1.__eq__(token2) == False


# Generated at 2022-06-12 16:18:44.949666
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class Token0(Token):
        def __init__(self, value: typing.Any, start_index: int, end_index: int, content: str = "") -> None:
            self._value = value
            self._start_index = start_index
            self._end_index = end_index
            self._content = content
            self.token0 = None
            self.token1 = None
        
        def _get_value(self) -> typing.Any:
            return self._value
        
        def _get_child_token(self, key: typing.Any) -> "Token":
            raise NotImplementedError  # pragma: nocover
        
        def _get_key_token(self, key: typing.Any) -> "Token":
            raise NotImplementedError  # pragma: nocover



# Generated at 2022-06-12 16:18:50.605701
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(_value=None, _start_index=None, _end_index=None) == \
           Token(_value=None, _start_index=None, _end_index=None)
    assert not Token(_value=None, _start_index=None, _end_index=None) == \
            Token(_value=None, _start_index=1, _end_index=None)
    assert not Token(_value=None, _start_index=None, _end_index=None) == \
            Token(_value=None, _start_index=None, _end_index=1)
    assert not Token(_value=None, _start_index=None, _end_index=None) == \
            Token(_value=True, _start_index=None, _end_index=None)

# Generated at 2022-06-12 16:18:56.005154
# Unit test for constructor of class DictToken
def test_DictToken():
    a1 = Token(3,0,0,"")
    a2 = Token("a",0,0,"")
    dict1 = {a2: a1}
    dict_token = DictToken(dict1,0,0,"")
    assert dict_token._child_tokens[a2._value] == a1
    assert dict_token._child_keys[a2._value] == a2
    

# Generated at 2022-06-12 16:18:58.553966
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken('[{}]')
    assert token._value == '[{}]'
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == ''


# Generated at 2022-06-12 16:19:10.465934
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Setup
    mocker = Mocker()
    mock_security_token = mocker.mock()
    mock_security_token._get_value = mocker.Mock()
    mock_security_token._start_index = mocker.Mock()
    mock_security_token._end_index = mocker.Mock()
    security_token = Token(mock_security_token._get_value, mock_security_token._start_index, mock_security_token._end_index)
    mock_other = mocker.mock()
    other = mock_other
    mock_security_token._get_value.return_value = "mock_security_token._get_value"
    mock_security_token._start_index.return_value = "mock_security_token._start_index"
    mock_security_

# Generated at 2022-06-12 16:19:13.789913
# Unit test for method __eq__ of class Token
def test_Token___eq__():
	token_a = ScalarToken(12, 1, 3)
	token_b = ScalarToken(1, 2, 4)
	assert token_a == token_b


# Generated at 2022-06-12 16:19:22.794643
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from pytype import fixture
    start_index = -6
    end_index = 3
    value = "abc"
    content = "ttt"
    index = []
    key = index
    token = Token(value, start_index, end_index, content)
    other = ScalarToken(value, start_index, end_index, content)
    assert token._get_value() == other._get_value()
    assert token._get_value() == value
    assert token._start_index == start_index
    assert token._end_index == end_index
    assert token.string == content[start_index : end_index + 1]
    assert token.start == Position(1, 4, start_index)
    assert token.end == Position(1, 7, end_index)

# Generated at 2022-06-12 16:19:34.755562
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class TokenA(Token):
        def _get_value(self):
            return self._value
    class TokenB(TokenA):
        def _get_value(self):
            return self._value
    assert TokenA(0, 0, 0) == TokenA(0, 0, 0)
    assert TokenA(1, 1, 1) == TokenA(1, 1, 1)
    assert TokenA(0, 0, 0) != TokenA(0, 0, 1)
    assert TokenA(0, 0, 0) != TokenA(0, 1, 1)
    assert TokenA(0, 0, 0) != TokenA(1, 1, 1)
    assert TokenA(0, 0, 0) != TokenB(0, 0, 0)
    assert TokenA(0, 0, 0) != 1
    assert TokenA

# Generated at 2022-06-12 16:19:43.542946
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test when arg other is not an instance of class Token
    token = Token(0, 0, 0)
    x = token.__eq__(0)
    assert x == False

    # Test when arg other is an instance of class Token
    token = Token(0, 0, 0)
    token_ = Token(0, 0, 0)
    x = token.__eq__(token_)
    assert x == True

    # Test when arg other is an instance of class Token, but the arguments' values are different from token
    token = Token(0, 0, 0)
    token_ = Token(1, 1, 1)
    x = token.__eq__(token_)
    assert x == False
# test ends


# Generated at 2022-06-12 16:20:57.690132
# Unit test for constructor of class DictToken
def test_DictToken():
    input_dict = {'a' : 2, 'b': [1, 2, 3]}
    DictToken('a', 2, 'b', [1, 2, 3])
    assert input_dict == DictToken('a', 2, 'b', [1, 2, 3])


# Generated at 2022-06-12 16:21:03.214100
# Unit test for constructor of class DictToken
def test_DictToken():
    pass

    #test_dict = {'1': 1, '2': 2, '3': 3}
    #test_dict_token = DictToken(test_dict, 0, 0)
    #print(test_dict_token)

    #print(test_dict_token.start)
    #print(test_dict_token.end)

    #print(test_dict_token._child_keys)
    #print(test_dict_token._child_tokens)

    #print(test_dict_token.lookup([0]))
    #print(test_dict_token.lookup_key([0]))
    #print(test_dict_token._get_value())


# Generated at 2022-06-12 16:21:06.203395
# Unit test for constructor of class DictToken
def test_DictToken():
    
    assert DictToken('value','start_index','end_index', 'content') == Token('value','start_index','end_index', 'content')
    

# Generated at 2022-06-12 16:21:12.367498
# Unit test for constructor of class DictToken
def test_DictToken():
    a = ScalarToken(1, 0, 0)
    b = ScalarToken(2, 1, 1)
    c = DictToken({a: b}, 0, 0, "\n")
    print(c._child_keys)
    print(c._child_tokens)
    # {1: ScalarToken(1)}
    # {1: ScalarToken(2)}


# Generated at 2022-06-12 16:21:22.034343
# Unit test for constructor of class DictToken
def test_DictToken():
    # test basic constructor
    token = DictToken(value = {'a':1, 'b':2}, start_index = 0, end_index = 3, content = 'test')
    assert token.lookup([1]) == ScalarToken(value = 2, start_index = 2, end_index = 2)
    assert token.lookup_key([1]) == ScalarToken(value = 'b', start_index = 3, end_index = 3)
    assert token.value == {'a':1, 'b':2}
    assert token.string == ''
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)
    assert str(token) == "DictToken({'a': 1, 'b': 2})"

# Generated at 2022-06-12 16:21:24.101639
# Unit test for constructor of class DictToken
def test_DictToken():
    key = 5
    value = 6
    token = DictToken({key: value}, 0, 0)
    assert token.string ==  "{5: 6}"


# Generated at 2022-06-12 16:21:27.387282
# Unit test for constructor of class DictToken
def test_DictToken():
    dic = {'a': 1, 'b': 2}
    kvtokens = {'a': ScalarToken(1, 0, 0), 'b': ScalarToken(2, 1, 1)}
    t = DictToken(kvtokens, 0, 1, 'ab')
    assert dic == t.value


# Generated at 2022-06-12 16:21:33.729988
# Unit test for constructor of class DictToken
def test_DictToken():
    value = {'a': 1}
    start_index = 3
    end_index = 5
    content = "a=3"
    dictToken = DictToken(value, start_index, end_index, content)
    assert dictToken._value == value
    assert dictToken.start == Position(1,1,3)
    assert dictToken.end == Position(1,3,5)


# Generated at 2022-06-12 16:21:45.875019
# Unit test for constructor of class DictToken
def test_DictToken():
    d_token = DictToken(
        {
            ScalarToken("a", 0, 1, "a"): ScalarToken(1, 0, 1, "a"),
            ScalarToken("b", 0, 1, "b"): ScalarToken(1, 0, 1, "b"),
        },
        0,
        1,
        "a",
    )
    assert d_token.value == {"a": 1, "b": 1}
    assert d_token.start == Position(1, 1, 0)
    assert d_token.end == Position(1, 1, 0)
    assert d_token.string == "a"
    assert d_token.lookup_key([0, "b"]) == ScalarToken("b", 0, 1, "b")

# Generated at 2022-06-12 16:21:49.868934
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken(value = {}, start_index = 0, end_index = 2)
    expected = {'_value': {}, '_start_index': 0, '_end_index': 2, '_content': ''}
    assert t.__dict__ == expected
