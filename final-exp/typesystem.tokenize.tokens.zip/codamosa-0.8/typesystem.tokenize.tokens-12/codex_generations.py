

# Generated at 2022-06-12 16:12:21.725624
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """
    Test the method Token.__eq__
    """
    token_1 = ScalarToken('value', 0, 1, '')
    token_2 = ScalarToken('value', 0, 1, '')
    assert token_1 == token_2
    token_1 = ScalarToken('value', 0, 1, 'value')
    token_2 = ScalarToken('value', 0, 1, 'value')
    assert token_1 == token_2
    token_1 = ScalarToken('value', 0, 1, 'value ')
    token_2 = ScalarToken('value', 0, 1, 'value')
    assert token_1 != token_2
    token_1 = ScalarToken('value', 0, 1, 'value ')
    token_2 = ScalarToken('value', 0, 2, 'value')
   

# Generated at 2022-06-12 16:12:27.682869
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken(
        value=[1, 2, 3], start_index=0, end_index=0, content="abc"
    )
    DictToken(
        value={"a": 1, "b": 2}, start_index=0, end_index=0, content="abc"
    )
    # TODO: Test if error occurs when passing in invalid value


# Generated at 2022-06-12 16:12:31.903046
# Unit test for constructor of class DictToken
def test_DictToken():
    a=DictToken('a','b','c')
    assert a._value=='a'
    assert a._start_index=='b'
    assert a._end_index=='c'
    assert a._child_keys=={}
    assert a._child_tokens=={}
    b=DictToken('a','b','c','d','e','f','g')
    assert b._content=='g'
    assert b._value=='a'
    assert b._start_index=='b'
    assert b._end_index=='c'
    assert b._child_keys=={}
    assert b._child_tokens=={}


# Generated at 2022-06-12 16:12:39.917340
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    abc = ScalarToken('abc', start_index=3, end_index=5, content='abc')
    abc2 = ScalarToken('abc', start_index=3, end_index=5, content='abc')
    abcd = ScalarToken('abcd', start_index=3, end_index=8, content='abc')
    abcde = ScalarToken('abcde', start_index=3, end_index=9, content='abc')
    assert abc != 123
    assert abc == abc2
    assert abc != abcd
    assert abc != abcde


test_Token___eq__()

# Generated at 2022-06-12 16:12:49.514014
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    value = ScalarToken(3, 1, 5) # Assign
    assert value == value # __eq__
    assert value != 3 # __eq__
    assert value.__eq__(3) # __eq__
    assert value != "fixme" # __eq__
    assert value.__eq__("fixme") # __eq__
    assert value == ScalarToken(3, 1, 5) # __eq__
    assert value != ScalarToken(3, 1, 4) # __eq__
    assert value != ScalarToken(4, 1, 5) # __eq__
    assert value == DictToken({value: value}, 1, 5) # __eq__
    assert value != DictToken({}, 1, 5) # __eq__
    assert value != ListToken([value], 1, 5) # __eq__

# Generated at 2022-06-12 16:13:02.048170
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test a number
    number = ScalarToken(123, 0, 3, "123")
    assert number == ScalarToken(123, 0, 3, "123")
    # Test a string
    string = ScalarToken("hej", 0, 3, '"hej')
    assert string == ScalarToken("hej", 0, 3, '"hej')
    # Test a dict
    dict = DictToken({"1": ScalarToken("hej", 0, 3, '"hej'), "2": ScalarToken("hej", 0, 3, '"hej')}, 0, 3, '{"1": "hej", "2": "hej"')

# Generated at 2022-06-12 16:13:03.701562
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": "b"}, 1, 3, "a = b")
    assert token._value == "b"
    assert token._start_index == 1
    assert token._end_index == 3


# Generated at 2022-06-12 16:13:04.999946
# Unit test for constructor of class DictToken
def test_DictToken():
    a = Token
    b = DictToken
    c = ListToken

# Generated at 2022-06-12 16:13:11.673330
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 1, 1, "") == Token(1, 1, 1, "")
    assert not Token(1, 1, 1, "") == Token(1, 2, 3, "")
    assert not Token(1, 1, 1, "") == Token("", 1, 1, "")
    assert not Token(1, 1, 1, "") == ""
    assert not Token(1, 1, 1, "") == None


# Generated at 2022-06-12 16:13:19.746022
# Unit test for constructor of class DictToken
def test_DictToken():
    DT_Content = "content"
    DT_Start_Index = 12
    DT_End_Index = 20
    DT_Value = {"a":1}
    a = DictToken(DT_Value, DT_Start_Index, DT_End_Index, DT_Content)
    assert (a._value == {"a":1})
    assert (a._start_index == 12)
    assert (a._end_index == 20)
    assert (a._content == "content")
    assert (a._child_tokens == {"a": 1})
    assert (a._child_keys == {"a": "a"})


# Generated at 2022-06-12 16:13:39.389256
# Unit test for method __eq__ of class Token
def test_Token___eq__():
	# arrange
	pos = Position(1, 2, 3)
	testobj1 = Token({pos: 'value'}, 'start_index', 'end_index', 'content')
	testobj2 = Token({pos: 'value'}, 'start_index', 'end_index', 'content')
	expectedResult = True
	
	# act
	actualResult1 = testobj1 == testobj2
	actualResult2 = testobj1.__eq__(testobj2)

	# assert
	assert actualResult1 == expectedResult
	assert actualResult2 == expectedResult



# Generated at 2022-06-12 16:13:47.164609
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_test=DictToken({"key1":1,"key2":2},0,3,"{")
    try:
        assert dict_token_test._value["key1"]==1 and dict_token_test._value["key2"]==2
    except KeyError:
        print("Key error in DictToken.")
        assert False
    assert dict_token_test._start_index==0
    assert dict_token_test._end_index==3
    assert dict_token_test._content=="{"


# Generated at 2022-06-12 16:13:58.850989
# Unit test for constructor of class DictToken
def test_DictToken():
    dic_key_1 = ScalarToken(1, 100, 110, "dummy")
    dic_value_1 = ScalarToken(2, 100, 110, "dummy")
    dic_key_2 = ScalarToken(3, 100, 110, "dummy")
    dic_value_2 = ScalarToken(4, 100, 110, "dummy")
    dic_key_3 = ScalarToken(5, 100, 110, "dummy")
    dic_value_3 = ScalarToken(6, 100, 110, "dummy")
    dic_value = {dic_key_1: dic_value_1, dic_key_2: dic_value_2, dic_key_3: dic_value_3}
    dic_value_token = DictToken

# Generated at 2022-06-12 16:14:06.895710
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken('a', 1, 2) == DictToken('a', 1, 2)
    assert DictToken(3, 'a', 1, 2) == DictToken('a', 1, 2)
    assert DictToken(4, 'a', 1, 2, 'd') == DictToken('a', 1, 2)
    assert DictToken('a', 1, 2, 'd', 'e') != DictToken('a', 1, 2)
    assert DictToken(4, 'a', 1, 2, 'd', 'e') != DictToken('a', 1, 2)


# Generated at 2022-06-12 16:14:11.963249
# Unit test for constructor of class DictToken
def test_DictToken():
    d = dict(a=1, b=2)
    dt = DictToken(d, 0, 0, "")
    assert dt._child_keys['a'].value == 1
    assert dt._child_keys['b'].value == 2
    assert dt._child_tokens['a'].value == 1
    assert dt._child_tokens['b'].value == 2
    assert dt._value == {'a': 1, 'b': 2}


# Generated at 2022-06-12 16:14:13.662158
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken("", 0, 0)
    assert isinstance(dt, DictToken)

# Generated at 2022-06-12 16:14:18.700400
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(
        {"a":1,"b":2,"c":3},
        0,
        1,
        content = "",
    )
    assert token._child_keys == {"a": 1, "b": 2, "c": 3}
    assert token._child_tokens == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-12 16:14:26.037421
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a':1, 'c':3, 'b':2}
    dt = DictToken(d, 0, 3, "abc")
    assert dt._child_keys == {'a': 1, 'c': 3, 'b': 2}
    assert dt._child_tokens == {'a': 1, 'c': 3, 'b': 2}
    assert dt._value == {'a': 1, 'c': 3, 'b': 2}


# Generated at 2022-06-12 16:14:32.581035
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(
        value = {'a': {}, 'b': {}},
        start_index = 0,
        end_index = 0,
        content = ""
    )
    assert(token._get_value() == {'a': {}, 'b': {}})
    assert(token._get_child_token({'a': {}, 'b': {}}) == {'a': {}, 'b': {}})
    assert(token._get_key_token({'a': {}, 'b': {}}) == {'a': {}, 'b': {}})


# Generated at 2022-06-12 16:14:44.521747
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken(None, 0, 0, '').string == ''
    assert DictToken(None, 0, 8, '').string == ''
    assert DictToken(None, 0, 9, '{}').string == '{}'
    assert DictToken(None, 0, 9, '{}')._child_keys == {}
    assert DictToken(None, 0, 9, '{}')._child_tokens == {}
    assert DictToken({'a': 'b'}, 0, 9, '{}')._child_tokens == {'a': 'b'}
    assert DictToken(None, 0, 9, '')._get_value() == {}

# Generated at 2022-06-12 16:15:02.546830
# Unit test for constructor of class DictToken
def test_DictToken():
    sample_token = DictToken({"a":1,"b":2}, 0, 0)
    assert sample_token._child_keys == {"a":1,"b":2}
    assert sample_token._child_tokens == {"a":1, "b":2}

# Generated at 2022-06-12 16:15:04.403112
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({1:1, 2:2}, 0, 1)

# Generated at 2022-06-12 16:15:08.608513
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'1': 1, "2": 2}
    d_token = DictToken(d, 0, 0, '{1:1,2:2}')
    assert str(d_token) == 'DictToken({1:1,2:2})'


# Generated at 2022-06-12 16:15:15.604765
# Unit test for constructor of class DictToken
def test_DictToken():
    # Case 1
    d1 = {}
    d2 = {}
    assert isinstance(DictToken(d1, 1, 2, {}), DictToken)
    assert type(DictToken(d2, 1, 2, {})._child_keys) == dict
    assert type(DictToken(d2, 1, 2, {})._child_tokens) == dict
    assert type(DictToken(d2, 1, 2, {})._start_index) == int
    assert type(DictToken(d2, 1, 2, {})._end_index) == int
    assert type(DictToken(d2, 1, 2, {})._content) == str
    assert type(DictToken(d2, 1, 2, {})._get_value()) == dict

# Generated at 2022-06-12 16:15:27.038725
# Unit test for constructor of class DictToken
def test_DictToken():
        # case 1
        token = DictToken({"a": 1, "b": 2}, 0, 2, content="abc")
        assert token._child_keys == {'b': 2, 'a': 1}
        assert token._child_tokens == {'b': 2, 'a': 1}
        # case 2
        token = DictToken({"b": 2, "a": 1}, 0, 2, content="abc")
        assert token._child_keys == {'b': 2, 'a': 1}
        assert token._child_tokens == {'b': 2, 'a': 1}
        # case 3
        token = DictToken({"b": 2}, 0, 2, content="abc")
        assert token._child_keys == {'b': 2}

# Generated at 2022-06-12 16:15:36.305266
# Unit test for constructor of class DictToken
def test_DictToken():
    # setup
    class NestedToken(Token):
        def __init__(self, value, start_index, end_index, content=""):
            Token.__init__(self, value, start_index, end_index, content)

        def _get_value(self):
            return self._value

        def _get_child_token(self, key):
            return self._value[key]

        def _get_key_token(self, key):
            return self._child_keys[key]

        def __hash__(self):
            return hash(self._value)

    # test
    d = DictToken({ScalarToken("a", 0, 0): ScalarToken("b", 0, 0)}, 0, 0, "")

    # check

# Generated at 2022-06-12 16:15:39.861018
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a": 1, "b": 2}, 0, 3, "something")
    assert token._get_value() == {}



# Generated at 2022-06-12 16:15:42.813355
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken("a string", 1, 5) == DictToken("a string", 1, 5)


# Generated at 2022-06-12 16:15:52.612934
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import Token, DictToken
    from typesystem.types import Dict, String

    token = DictToken(
        {
            Token(String.validate(0, "a"), 0, 0, "a"): Token(String.validate(0, "b"), 0, 0, "b"),
            Token(String.validate(1, "c"), 0, 0, "c"): Token(String.validate(1, "d"), 0, 0, "d"),
        },
        0,
        0,
        "",
    )
    assert isinstance(token, Token)
    assert isinstance(token, DictToken)
    assert token.string == ""
    assert token.start == token.end == Position(1, 1, 0)


# Generated at 2022-06-12 16:15:58.858663
# Unit test for constructor of class DictToken
def test_DictToken():
    import ast
    a = ast.parse('mydict = {"key1" : 1, "2" : 2}')
    b = DictToken(a, 0, len(a), 'mydict = {"key1" : 1, "2" : 2}')
    assert str(b) == 'DictToken(mydict = {"key1" : 1, "2" : 2}'
    assert b._get_position(0) == Position(1, 1, 0)
    assert b._get_position(7) == Position(1, 8, 7)


# Generated at 2022-06-12 16:16:11.151538
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken(value=1, start_index=0, end_index=1, content="")
    assert isinstance(t, Token)
    assert t._value == 1
    assert t._start_index == 0
    assert t._end_index == 1
    assert t._content == ""


# Generated at 2022-06-12 16:16:23.110757
# Unit test for constructor of class DictToken
def test_DictToken():
    content = "something"
    key_token = ScalarToken(key, 0, 5, content)
    value_token = ScalarToken(value, 6, 11, content)
    start_index = 0
    end_index = 11
    item = {key_token: value_token}
    token = DictToken(item, start_index, end_index, content)
    assert token._get_value() == {key: value}
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 12, 11)
    assert token.string == "something"
    assert token._child_tokens == {key: value_token}
    assert token._child_keys == {key: key_token}
    assert token._token_type == "dict"
    assert token._get_child_

# Generated at 2022-06-12 16:16:25.660977
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken(value={"key_token":"value_token"}, start_index=10, end_index=20, content="content")



# Generated at 2022-06-12 16:16:30.989347
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken(value={}, start_index=0, end_index=0)
    assert isinstance(t, Token)
    assert isinstance(t, DictToken)
    assert t._value == {}
    assert t._start_index == 0
    assert t._end_index == 0
    assert t._child_keys == {}
    assert t._child_tokens == {}

# Generated at 2022-06-12 16:16:34.109987
# Unit test for constructor of class DictToken
def test_DictToken():
    a = 10
    b = 20
    c = Token(dict({'a' : a, 'b' : b}), 1, 10)
    assert type(c) == DictToken
    assert c._value == dict({'a' : a, 'b' : b})

# Generated at 2022-06-12 16:16:36.870273
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": "b" })

# Generated at 2022-06-12 16:16:39.185940
# Unit test for constructor of class DictToken
def test_DictToken():
  new_dict_token = DictToken([], [])
  assert type(new_dict_token) == DictToken

# Generated at 2022-06-12 16:16:42.160241
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken({'a':1,'b':2}, 0, 3)
    assert t._child_tokens['b'] == 2
    assert t._child_keys['a'] == 1



# Generated at 2022-06-12 16:16:46.063804
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a":1, "b":2},0, 100, "this is DictToken")
    assert(token._value == {"a":1, "b":2})
    assert(token._content =="this is DictToken")
    assert(token._start_index == 0)
    assert(token._end_index == 100)


# Generated at 2022-06-12 16:16:50.627733
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken({}, 0, 2, content='{}')
    assert dict_token._get_value() == {}
    assert dict_token._start_index == 0
    assert dict_token._end_index == 2

# Generated at 2022-06-12 16:17:36.693111
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken(value={"a": 1}, start_index=0, end_index=1, content="abc")


# Generated at 2022-06-12 16:17:46.777402
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken(value = {}, start_index = 0, end_index = 0)._value == {}
    assert DictToken(value = {}, start_index = 0, end_index = 0, content = "")._value == {}
    assert DictToken(value = {}, start_index = 0, end_index = 0, content = "")._start_index == 0
    assert DictToken(value = {}, start_index = 0, end_index = 0, content = "")._end_index == 0
    assert DictToken(value = {}, start_index = 0, end_index = 0, content = "")._content == ""
#Unit test for constructor of class ListToken

# Generated at 2022-06-12 16:17:47.358308
# Unit test for constructor of class DictToken
def test_DictToken():
    pass

# Generated at 2022-06-12 16:17:58.938238
# Unit test for constructor of class DictToken
def test_DictToken():
    test = DictToken({"key1":"value1"},3,5,content="")
    assert test._value == {"key1":"value1"}
    assert test._start_index == 3
    assert test._end_index == 5
    assert test._content == ""
    assert test.string == ""
    assert test.value == {"key1":"value1"}
    assert test.start == Position(1,1,3)
    assert test.end == Position(1,1,5)
    assert test._get_position(1) == Position(1,1,1)
    assert test._get_position(0) == Position(1,1,0)
    assert test.lookup("key1") == "value1"
    assert test.lookup("key2") == None

# Generated at 2022-06-12 16:18:00.807802
# Unit test for constructor of class DictToken
def test_DictToken():
    test_dict = {"apple": 1, "banana": 2}
    DictToken(test_dict, 0, 8)



# Generated at 2022-06-12 16:18:01.924710
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a":1})


# Generated at 2022-06-12 16:18:04.562135
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({'a': 1, 'b': 2}, 0, 0)
    assert a._value == {'a': 1, 'b': 2}
    assert a._start_index == 0
    assert a._end_index == 0
    assert a._content == ""


# Generated at 2022-06-12 16:18:15.567034
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"a": 1}, 1, 4, "{}")._value == {"a": 1}
    assert DictToken({"a": 1}, 1, 4, "{}")._start_index == 1
    assert DictToken({"a": 1}, 1, 4, "{}")._end_index == 4
    assert DictToken({"a": 1}, 1, 4, "{}")._content == "{}"
    assert DictToken({"a": 1}, 1, 4, "{}").string == "{}"
    assert DictToken({"a": 1}, 1, 4, "{}").value == {"a": 1}
    assert DictToken({"a": 1}, 1, 4, "{}").start == Position(1, 2, 1)

# Generated at 2022-06-12 16:18:25.323543
# Unit test for constructor of class DictToken
def test_DictToken():
    dictToken = DictToken({"one":1, "two":2}, 0, 4, "one: 1, two: 2")
    assert dictToken._get_value() == {"one":1, "two":2}
    assert dictToken.value == {"one":1, "two":2}
    assert dictToken.start == Position(1, 1, 0)
    assert dictToken.end == Position(1, 12, 4)
    assert dictToken.string == "one: 1, two: 2"
    assert dictToken.lookup([0]).value == 1
    assert dictToken.lookup_key([0]).value == "one"

# Generated at 2022-06-12 16:18:30.912714
# Unit test for constructor of class DictToken
def test_DictToken():
    a = {"name" : "qurbonov", "age" : 20}
    token = DictToken(a, 1, 5, content = "qurbonov, 20")
    a1 = token._get_value()
    assert a == a1


if __name__ == "__main__":
    test_DictToken()

# Generated at 2022-06-12 16:18:55.592520
# Unit test for constructor of class DictToken
def test_DictToken():
    tokens = {'a': 1, 'b': 2}
    dt = DictToken(tokens, 0, 10)
    assert dt._value.items() == dt._child_tokens.items()
    for k, v in tokens.items():
        assert dt._get_key_token(k)._value == k
        assert dt._get_child_token(k)._value == v
    assert dt._get_value() == tokens


# Generated at 2022-06-12 16:18:58.797664
# Unit test for constructor of class DictToken
def test_DictToken():
    test_obj = DictToken(
        {}, 0, 0
    )
    # test __init__()
    assert test_obj._value == {}
    assert test_obj._start_index == 0
    assert test_obj._end_index == 0
    assert test_obj._content == ""


# Generated at 2022-06-12 16:19:07.259970
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(start_index = 1, end_index = 5, value = {'a':1, 'b':2})
    assert token.value == {'a':1, 'b':2}
    assert token.start.line_no == 1
    assert token.start.column_no == 1
    assert token.start.index == 1
    assert token.end.line_no == 5
    assert token.end.column_no == 1
    assert token.end.index == 5


# Generated at 2022-06-12 16:19:17.834723
# Unit test for constructor of class DictToken
def test_DictToken():
    # test as a base class
    token = DictToken(value= {}, start_index= 0, end_index= 1)
    assert token.value == {}

    # test as a subclass
    test_value = {'a': 0, 'b': 1, 'c': 2}
    token_1 = ScalarToken(value= 1, start_index= 0, end_index= 1, content= '1')
    token_2 = ScalarToken(value= 5, start_index= 2, end_index= 3, content= '5')
    token_3 = ScalarToken(value= 3, start_index= 4, end_index= 5, content= '3')

# Generated at 2022-06-12 16:19:20.810280
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"hello": "world"}, 0, 1)
    assert(token.value == {"hello": "world"})
    assert(str(token) == "DictToken({'hello': 'world'})")


# Generated at 2022-06-12 16:19:24.900448
# Unit test for constructor of class DictToken
def test_DictToken():
    print(DictToken({0: 1}))


if __name__ == "__main__":
    test_DictToken()

# Generated at 2022-06-12 16:19:27.211362
# Unit test for constructor of class DictToken
def test_DictToken():
    dic_token = DictToken({'a':1}, 0, 1)
    assert dic_token.lookup([0]) == 1

# Generated at 2022-06-12 16:19:36.842782
# Unit test for constructor of class DictToken
def test_DictToken():
    test_dict = {
        1: True,
        2: False
    }
    test_token = DictToken(test_dict, 0, 1, "test")
    assert test_token.start == Position(1, 1, 0)
    assert test_token.end == Position(1, 1, 1)
    assert test_token.string == 'test'
    assert str(test_token) == 'DictToken(\'test\')'
    assert test_token.value == {1: True, 2: False}
    assert test_token.lookup([1]) == True
    assert test_token.lookup_key([1]) == 1
    

# Generated at 2022-06-12 16:19:44.782186
# Unit test for constructor of class DictToken
def test_DictToken():
    key1 = ScalarToken("key1", 0, 3)
    token1 = ScalarToken("token1", 4, 9)
    key2 = ScalarToken("key2", 10, 13)
    token2 = ScalarToken("token2", 14, 19)
    token = DictToken({"key1": token1, "key2": token2}, 0, 19)
    assert token._get_value() == {"key1": "token1", "key2": "token2"}
    assert token._get_child_token("key1") is token1
    assert token._get_key_token("key1") is key1
    assert token._get_child_token("key2") is token2
    assert token._get_key_token("key2") is key2


# Generated at 2022-06-12 16:19:49.225603
# Unit test for constructor of class DictToken
def test_DictToken():
    TestDictToken = DictToken("name", 1, 3)
    assert TestDictToken._value == "name"
    assert TestDictToken._start_index == 1
    assert TestDictToken._end_index == 3
    assert TestDictToken._content == ""



# Generated at 2022-06-12 16:20:29.885779
# Unit test for constructor of class DictToken
def test_DictToken():
    # TODO: Add a unit test for the constructor of DictToken
    assert False


# Generated at 2022-06-12 16:20:35.610278
# Unit test for constructor of class DictToken
def test_DictToken():
    # Unit test for constructor of class DictToken
    from typesystem.base import Integer
    from typesystem.base import String
    from typesystem.base import Dict
    from typesystem.base import Instance
    string = Instance(String())
    integer = Instance(Integer())
    assert DictToken( {string: integer}, 0, 0)



# Generated at 2022-06-12 16:20:42.263301
# Unit test for constructor of class DictToken
def test_DictToken():
    test_input = {"A": "1", "B": "2"}
    a = DictToken(test_input, 0, 0, test_input)
    b = DictToken(test_input, 0, 0, test_input)
    assert(a == b)
    assert({"A","B"} == a._child_keys)
    assert({"1","2"} == a._child_tokens)

# Generated at 2022-06-12 16:20:44.912703
# Unit test for constructor of class DictToken
def test_DictToken():
	print("test_DictToken():")
	dict_token = DictToken({})
	assert dict_token
	print("test_DictToken() successful!")


# Generated at 2022-06-12 16:20:46.764820
# Unit test for constructor of class DictToken
def test_DictToken():
    d_token = DictToken(value="Dictionary", start_index=1, end_index=2)
    assert d_token



# Generated at 2022-06-12 16:20:48.523795
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken({1: 2})
    assert dict_token._value == {1: 2}


# Generated at 2022-06-12 16:20:56.807772
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {}
    d["a"] = "b"
    t = DictToken(d, 0, 0, "")
    # print(t.string)
    # print(t.value)
    # print(t.start)
    # print(t.end)
    assert(t.string == "")
    assert(t.value == {"a": "b"})
    assert(t.start == Position(1, 1, 0))
    assert(t.end == Position(1, 1, 0))

# Generated at 2022-06-12 16:21:07.689716
# Unit test for constructor of class DictToken

# Generated at 2022-06-12 16:21:13.429747
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken(
        {1: 2, 3: 4}, start_index=10, end_index=20, content="Hello, world!"
    )
    assert t._value == {1: 2, 3: 4}
    assert t._start_index == 10
    assert t._end_index == 20
    assert t._content == "Hello, world!"


# Generated at 2022-06-12 16:21:20.203801
# Unit test for constructor of class DictToken
def test_DictToken():
    # Constructor
    dt = DictToken({"a":1}, 0, 1, content="a")
    # We should get the same token back when we look up the value 'a'
    assert(dt._child_tokens['a'] == dt.lookup(['a']))
    # We should get the same token back when we look up the key 'a'
    assert(dt._child_keys['a'] == dt.lookup_key(['a']))

