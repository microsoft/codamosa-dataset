

# Generated at 2022-06-12 16:12:28.071957
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({"test": 10}, 0, 1)
    assert DictToken({"test": 10}, 0, 1, "")
    assert DictToken({"test": 10}, 0, 1, "")._value == {"test": 10}
    assert DictToken({"test": 10}, 0, 1, "").child_keys == {"test": 10}
    assert DictToken({"test": 10}, 0, 1, "").child_tokens == {"test": 10}


# Generated at 2022-06-12 16:12:32.875206
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    T = typing.TypeVar("T", bound=Token)
    def _test_Token___eq__(token: T) -> None:
        assert token == token, "Expected equality of a Token to itself."
        same_value = token.__class__(
            token._value, token._start_index, token._end_index, token._content
        )
        assert token == same_value, (
            "Expected equality of a Token instance to another Token instance "
            "with the same properties."
        )

    # Create a collection of Token instances that can be compared.
    _test_Token___eq__(ScalarToken(None, 0, 0))
    _test_Token___eq__(ScalarToken(True, 0, 0))
    _test_Token___eq__(ScalarToken(False, 0, 0))


# Generated at 2022-06-12 16:12:41.897027
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    cls = Token
    assert cls.__eq__ == Token.__eq__
    cls._value = False
    cls._start_index = True
    cls._end_index = True
    cls._content = True
    obj = cls(False, True, True, True)
    assert obj == obj
    assert not obj != obj
    assert not obj == None
    assert obj != None
    assert obj == cls(False, True, True, True)
    assert not obj != cls(False, True, True, True)
    assert not obj == cls(False, True, True, None)
    assert obj != cls(False, True, True, None)
    assert not obj == cls(None, True, True, True)
    assert obj != cls(None, True, True, True)

# Generated at 2022-06-12 16:12:48.793808
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    a = Token(value='a', start_index=0, end_index=0, content='a')
    b = Token(value='a', start_index=0, end_index=0, content='a')
    assert a == b
    assert a != 'a'
    assert a != Token(value='b', start_index=0, end_index=0, content='a')
    assert a != Token(value='a', start_index=1, end_index=1, content='a')
    assert a != Token(value='a', start_index=0, end_index=1, content='a')

# Generated at 2022-06-12 16:12:55.455016
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token = {'start_index': 1, 'end_index': 1, 'content': ''}
    token1 = Token(dict_token['content'], dict_token['start_index'], dict_token['end_index'])
    token2 = Token(dict_token['content'], dict_token['start_index'], dict_token['end_index'])
    token3 = Token(dict_token['content'] + "a", dict_token['start_index'], dict_token['end_index'])
    token4 = Token(dict_token['content'], dict_token['start_index'], dict_token['end_index'] + 1)
    return [token1 == token1, token1 == token2, token1 != token3, token1 != token4]



# Generated at 2022-06-12 16:13:04.605994
# Unit test for constructor of class DictToken
def test_DictToken():
    parent_token = {"key": "value"} #  Type of parent_token is dict, while can't pass in
    child_tokens = {"key": "value_token"}
    child_keys = {"key": "key_token"}
    t = DictToken(parent_token, 0, 0, "")
    assert isinstance(t, Token)
    assert t._value == child_tokens
    assert t._child_keys == child_keys
    assert t._child_tokens == child_tokens
    assert t._start_index == 0
    assert t._end_index == 0
    assert t._content == ""


# Generated at 2022-06-12 16:13:16.041408
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test where self._get_value() == other._get_value() and self._start_index == other._start_index and self._end_index == other._end_index
    # test for where _get_value() == other._get_value()
    class DummyToken(Token):
        def _get_value(self):
            return 'a'
    dummy_token_a = DummyToken('a', 0, 0, '')
    dummy_token_b = DummyToken('a', 0, 0, '')
    assert dummy_token_a == dummy_token_b
    # test for where _start_index == other._start_index
    class DummyToken(Token):
        def _get_value(self):
            return 'a'
    dummy_token_a = DummyToken('a', 0, 0, '')

# Generated at 2022-06-12 16:13:18.948691
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token("", 0, 1)
    other = Token("", 0, 1)
    assert token == other
    token = Token("", 1, 2)
    assert token != other
    

# Generated at 2022-06-12 16:13:26.770468
# Unit test for constructor of class DictToken
def test_DictToken():
    print("Testing DictToken()")
    result = DictToken(value=dict(), start_index=0, end_index=10)
    assert(result.string=='', "Should be ''")
    assert(result.value==dict(), "Should be dict()")
    assert(result.start.line_no==1, "Should be 1")
    assert(result.start.column_no==1, "Should be 1")
    assert(result.start.index==0, "Should be 0")
    assert(result.end.line_no==1, "Should be 1")
    assert(result.end.column_no==1, "Should be 1")
    assert(result.end.index==10, "Should be 10")
    assert(result == result, "Should be True")

# Generated at 2022-06-12 16:13:34.636708
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    print("test_Token___eq__()")
    left_token = ScalarToken(0, 0, 0)
    right_token1 = ScalarToken(1, 0, 0)
    right_token2 = ScalarToken(0, 1, 0)
    right_token3 = ScalarToken(0, 0, 1)
    assert left_token == left_token
    assert left_token != right_token1
    assert left_token != right_token2
    assert left_token != right_token3
    assert right_token1 != right_token2
    assert right_token1 != right_token3
    assert right_token2 != right_token3


test_Token___eq__()

# Generated at 2022-06-12 16:13:43.418027
# Unit test for constructor of class DictToken
def test_DictToken():
    my_token = DictToken("obj", 10, 11, content = "")
    assert my_token.start is None
    assert my_token.end is None
    assert my_token.string == ""



# Generated at 2022-06-12 16:13:46.787689
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = ScalarToken('value1', 1, 2, 'content1')
    token2 = ScalarToken('value2', 3, 4, 'content2')
    assert token1 == token1
    assert token1 != token2



# Generated at 2022-06-12 16:13:49.646462
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken("aa",0,0)
    assert token._get_value() == token._get_value()


# Generated at 2022-06-12 16:13:56.775298
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from pytest import raises

    value = None
    start_index = None
    end_index = None
    content = None
    token = Token(value, start_index, end_index, content)

    with raises(NotImplementedError):
        token._get_value()

    with raises(NotImplementedError):
        token._get_child_token(None)

    with raises(NotImplementedError):
        token._get_key_token(None)



# Generated at 2022-06-12 16:14:08.235890
# Unit test for constructor of class DictToken
def test_DictToken():
    tokenA = Token(value = 10, start_index = 0, end_index = 10)
    tokenB = Token(value = 20, start_index = 0, end_index = 10)
    tokenC = DictToken(value = {"A": tokenA, "B": tokenB}, start_index = 0, end_index = 1)
    assert tokenC.string == ""
    assert tokenC.value == {"A": 10, "B": 20}
    assert tokenC.start == Position(line_no = 1, column_no = 1, index = 0)
    assert tokenC.end == Position(line_no = 1, column_no = 2, index = 1)
    assert tokenC.lookup([]) == tokenC
    assert tokenC.lookup_key([]) == tokenC

# Generated at 2022-06-12 16:14:10.840988
# Unit test for constructor of class DictToken
def test_DictToken():
    # test for constructor
    assert DictToken(5,5,5,5) is not None



# Generated at 2022-06-12 16:14:13.816403
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """
    Token.__eq__(self, other)


    """
    obj = Token("value", 1, 2, "content")
    Token("value", 1, 2, "content")
    pass

# Generated at 2022-06-12 16:14:24.756554
# Unit test for constructor of class DictToken

# Generated at 2022-06-12 16:14:33.169303
# Unit test for constructor of class DictToken
def test_DictToken():
    from unittest.mock import Mock
    key_token = Mock()
    key_token._get_value.return_value = 1
    key_token._value = 1
    key_token._start_index = 0
    key_token._end_index = 0
    key_token._content = ""
    value_token = Mock()
    value_token._get_value.return_value = 2
    value_token._value = 2
    value_token._start_index = 0
    value_token._end_index = 0
    value_token._content = ""
    dict_token = DictToken(
        {
            key_token: value_token,
        },
        0,
        0,
        "",
    )
    dict_token._get_value()

# Generated at 2022-06-12 16:14:44.595471
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.base import Position
    from typesystem.parser import Token
    from typesystem.parser import DictToken
    from typesystem.parser import DictKeyToken
    from typesystem.parser import DictValueToken
    from typesystem.parser import ListToken
    from typesystem.parser import ScalarToken
    token_0 = DictToken({DictKeyToken(DictValueToken(ScalarToken(3, 42, 45)), 48, 58, "dict_key"): DictValueToken(ListToken([ScalarToken(3.14, 58, 66), ScalarToken(2.18, 66, 74), ScalarToken(1.414, 74, 82), ScalarToken(13, 82, 85)], 58, 84))}, 42, 84, "scalar")

# Generated at 2022-06-12 16:14:54.511058
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken(value = {}, start_index = 10, end_index = 10, content = 'content')
    assert dt._value == {}
    assert dt._start_index == 10
    assert dt._end_index == 10
    assert dt._content == 'content'


# Generated at 2022-06-12 16:15:02.693737
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token('value1', 1, 10)
    assert t1._get_value() == 'value1'
    assert t1._start_index == 1
    assert t1._end_index == 10
    t2 = Token('value2', 2, 20)
    assert t2._get_value() == 'value2'
    assert t2._start_index == 2
    assert t2._end_index == 20
    assert t1.__eq__(t1)
    assert not t1.__eq__(t2)
    assert not t2.__eq__(t1)


# Generated at 2022-06-12 16:15:12.755341
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Declare variables
    value1 = ScalarToken(1.0, 0, 0)
    value2 = ScalarToken(2.0, 3, 3)
    value3 = ScalarToken(3.0, 3, 3)
    value4 = ScalarToken(1.0, 6, 6)
    token1 = Token(value1, 0, 0)
    token1.value = value1
    token1.start = Position(0, 0, 0)
    token1.end = Position(0, 0, 0)
    token1.string = '1.0'
    token2 = Token(value2, 0, 0)
    token2.value = value2
    token2.start = Position(0, 0, 0)
    token2.end = Position(0, 0, 0)

# Generated at 2022-06-12 16:15:16.259373
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken(3, 16, 38, "hello{world}")

# Generated at 2022-06-12 16:15:19.722969
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    expected = True
    actual = Token(0, 0, 0, '') == Token(0, 0, 0, '')
    assert expected == actual, 'Expected different value %s but got %s' % (expected, actual)

# Generated at 2022-06-12 16:15:21.887280
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    DictToken(dict(a=1, b=2, c=3)) == DictToken(dict(a=1, b=2, c=3))

# Generated at 2022-06-12 16:15:24.940265
# Unit test for constructor of class DictToken
def test_DictToken():
    test_key = ScalarToken(1, 1, 2)
    test_value = ScalarToken(1, 1, 2)
    DictToken({test_key: test_value}, 1, 3, "test content")
    return True


# Generated at 2022-06-12 16:15:35.538457
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.base import ScalarField
    from typesystem.compat import str_type

    class TestToken(Token):
        def __init__(self, *args, **kwargs):
            self.value = None
            self.start_index = None
            self.end_index = None
            self.content = None
            self._value = None
            self._start_index = None
            self._end_index = None
            self._content = None

        def _get_value(self):
            return self.value

        def _get_child_token(self, key):
            pass

        def _get_key_token(self, key):
            pass

    field = ScalarField(name="test")
    field.name = "test"

    token1 = TestToken(field, 0, 1, "test")


# Generated at 2022-06-12 16:15:38.978485
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 1, 2, '') == Token(1, 1, 2, '')

test_Token___eq__()

# Generated at 2022-06-12 16:15:47.212403
# Unit test for constructor of class DictToken
def test_DictToken():
    d = dict(age = 33, name = "Samuel")
    d1 = DictToken(d, 0,2)
    assert d1._end_index == 2
    assert d1._start_index == 0
    assert d1._content == ""
    assert d1._value == dict(age = 33, name = "Samuel")
    assert d1._child_keys == {'age': 33, 'name': 'Samuel'}
    assert d1._child_tokens == {'age': 33, 'name': 'Samuel'}


# Generated at 2022-06-12 16:16:11.246970
# Unit test for constructor of class DictToken
def test_DictToken():
    key1 = ScalarToken("key1", 0, 3, "abc")
    dict1 = DictToken({key1: ScalarToken("123", 4, 5, "abc")}, 0, 5, "abc")
    assert dict1._child_keys == {'key1': key1}
    assert dict1._child_tokens == {'key1': ScalarToken("123", 4, 5, "abc")}


# Generated at 2022-06-12 16:16:16.133455
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({'a':1},0,1,content="abc")
    assert a._value=={'a':1}
    assert a._start_index==0
    assert a._end_index==1
    assert a._content=="abc"


# Generated at 2022-06-12 16:16:17.899115
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({}, 0, 1)
    assert a is not None


# Generated at 2022-06-12 16:16:25.916185
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken(value = {}, start_index = 0, end_index = 0, content = "")
    KeyToken(value = "key1", start_index = 0, end_index = 0, content = "")
    KeyToken(value = "key2", start_index = 0, end_index = 0, content = "")
    ValueToken(value = 1, start_index = 0, end_index = 0, content = "")
    ValueToken(value = 2, start_index = 0, end_index = 0, content = "")


# Generated at 2022-06-12 16:16:29.650822
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    obj = Token(value=None, start_index=1, end_index=3, content="abc")
    obj2 = Token(value=None, start_index=1, end_index=3, content="abc")
    assert obj == obj2

# Generated at 2022-06-12 16:16:37.104833
# Unit test for constructor of class DictToken
def test_DictToken():
    from .lexer import Lexer
    assert DictToken(
        {}, 0, 5, "{" "}"
    ) == DictToken(
        {}, 0, 5, "{" "}"
    )
    assert DictToken(
        {"A": 1}, 0, 5, "{" "}"
    ) != DictToken(
        {"B": 1}, 0, 5, "{" "}"
    )
    assert DictToken(
        {"A": 1}, 0, 5, "{" "}"
    ) != DictToken(
        {"A": 2}, 0, 5, "{" "}"
    )
    assert DictToken(
        {"A": 1}, 0, 5, "{" "}"
    ) != DictToken(
        {"A": 1}, 1, 5, "{" "}"
    )
    assert Dict

# Generated at 2022-06-12 16:16:41.162921
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken(value = {ScalarToken(value="something", start_index=1, end_index=2): ScalarToken(value="something", start_index=1, end_index=2)}, start_index=1, end_index=2)

# Generated at 2022-06-12 16:16:47.301856
# Unit test for constructor of class DictToken
def test_DictToken():
    start_index = 0
    end_index = 0
    content = ""
    myDictToken = DictToken({"a" : 1}, start_index, end_index, content)
    assert(myDictToken.start_index == 0)
    assert(myDictToken.end_index== 0)
    assert(myDictToken.content == "")
    assert(myDictToken._get_value() == {"a" : 1})
    assert(myDictToken._get_child_token("a") == 1)
    assert(myDictToken._get_key_token("a") == "a")



# Generated at 2022-06-12 16:16:53.601661
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken(
        value={
            ScalarToken(value=1, start_index=1, end_index=2, content="abc"): ScalarToken(
                value=2, start_index=1, end_index=2, content="abc"
            )
        },
        start_index=1,
        end_index=2,
        content="abc",
    )


# Generated at 2022-06-12 16:16:56.617393
# Unit test for constructor of class DictToken
def test_DictToken():
    print(DictToken.__init__(Token,*(1, 2, 3, 4)))
    return

test_DictToken()

# Generated at 2022-06-12 16:17:20.272877
# Unit test for constructor of class DictToken
def test_DictToken():
    test = DictToken({'test':'1'}, 1, 2, 'awfawf')
    if type(test) != DictToken:
        return False
    if test._start_index != 1:
        return False
    if test._end_index != 2:
        return False
    if test._content != 'awfawf':
        return False
    return True

# Generated at 2022-06-12 16:17:25.182716
# Unit test for constructor of class DictToken
def test_DictToken():
    dic = {
        "a": 1,
        "b": 2,
    }

# Generated at 2022-06-12 16:17:32.897272
# Unit test for constructor of class DictToken
def test_DictToken():
    key = ScalarToken("name", 0, 3, "name")
    value = ScalarToken("Vicky", 5, 9, "Vicky")
    dict = DictToken({key:value}, 0, 9, "nameVicky")
    assert dict.end.index == 9
    assert dict.value == {"name": "Vicky"}
    dict_token = dict.lookup([0])
    assert dict_token.end.index == 3
    assert dict_token.value == "name"
    assert dict.lookup_key([0, 0]) == key


# Generated at 2022-06-12 16:17:38.479374
# Unit test for constructor of class DictToken
def test_DictToken():
	d = DictToken({'abc':123, 'cde':234}, 1, 5, 'abc: 123\ncde: 234')
	assert(d._child_tokens == {'abc':123, 'cde':234})
	assert(d._child_keys == {'abc':123, 'cde':234})

# Generated at 2022-06-12 16:17:43.321088
# Unit test for constructor of class DictToken
def test_DictToken():
    dictToken = DictToken({})
    assert dictToken._start_index == 0
    assert dictToken._end_index == 0
    assert dictToken._content == ""
    assert dictToken.string == ""
    assert dictToken.value == {}



# Generated at 2022-06-12 16:17:49.124193
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken(
        {
            ScalarToken('value', 0, 1, 'content'): ScalarToken('value', 0, 1, 'content'),
            ScalarToken('value', 0, 1, 'content'): ScalarToken('value', 0, 1, 'content'),
            ScalarToken('value', 0, 1, 'content'): ScalarToken('value', 0, 1, 'content'),
        },
        0,
        1,
        'content'
    )

# Generated at 2022-06-12 16:17:54.244526
# Unit test for constructor of class DictToken
def test_DictToken():
    dict = {"a": "a", "b": "b", "c": "c"}
    dict_token = DictToken(dict)
    assert dict_token.value == dict
    assert dict_token._start_index == 0
    assert dict_token._end_index == len(str(dict))


# Generated at 2022-06-12 16:17:57.052951
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken({'a':1},0,1)
    assert d.value == {'a': 1} and d.start == 0 and d.end == 1 and d.string == ''


# Generated at 2022-06-12 16:17:58.129277
# Unit test for constructor of class DictToken
def test_DictToken():
	assert DictToken({"hello" : 3, "world" : 4}, 0, 0, "") is not None

# Generated at 2022-06-12 16:18:01.046391
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken("content", "start", "end", token="token")
    assert token._start_index == "start"
    assert token._end_index == "end"
    assert token._content == "content"


# Generated at 2022-06-12 16:18:11.955392
# Unit test for constructor of class DictToken
def test_DictToken():
    assert (DictToken(None, None, None, None).__init__(None, None, None, None))


# Generated at 2022-06-12 16:18:13.987169
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken(value = 5, start_index = 2, end_index = 3)
    assert a is not None


# Generated at 2022-06-12 16:18:16.082518
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken({'aa':1},0,0,content="aa")
    assert dt


# Generated at 2022-06-12 16:18:24.980844
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({0: 1}, 0, 1, content="{0:1}")
    assert(token.string == "{0:1}")
    assert(token.value == {0:1})
    assert(token.start == Position(1, 4, 1))
    assert(token.end == Position(1, 5, 2))
    assert(token.lookup([0]) == token._get_child_token(0))
    assert(token.lookup_key([0]) == token._get_key_token(0))


# Generated at 2022-06-12 16:18:32.301172
# Unit test for constructor of class DictToken
def test_DictToken():
    # Setup
    value = {'Test': 'test'}
    start_index = 0
    end_index = 4
    content = "test"
    expected = {'Test': 'test'}
    # Exercise
    actual = DictToken(value, start_index, end_index, content)
    # Verify
    assert actual._value == expected
    assert actual._start_index == expected
    assert actual._end_index == expected
    assert actual._content == expected
    # Cleanup - none necessary



# Generated at 2022-06-12 16:18:33.126962
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken("foo", 1, 2)

# Generated at 2022-06-12 16:18:42.154305
# Unit test for constructor of class DictToken
def test_DictToken():
    key = "a"
    value = 2
    content = key + str(value)
    o = DictToken({1:2}, 0, 1, content)
    assert o._value == {1:2}
    assert o.string == content
    assert o.value == {1:2}
    assert o.start == Position(1, 1, 0)
    assert o.end == Position(1, 2, 1)
    assert o.lookup([]) == o
    assert o.lookup_key([]) == o
    assert o._get_position(0) == Position(1, 1, 0)


# Generated at 2022-06-12 16:18:53.118284
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.literals import String
    from typesystem.tokenizer import StringTokenizer
    tokenizer = StringTokenizer(String())
    value = {'a': 1, 'b': 2}
    tokens = tokenizer(value)
    token = DictToken(tokens, 0, 7, content='{"a": 1, "b": 2}')
    assert isinstance(token, Token)
    assert not isinstance(token, ListToken)
    assert not isinstance(token, ScalarToken)
    assert token.value == tokens.value
    assert token.value == value
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 13, 7)
    assert token.string == '{"a": 1, "b": 2}'


# Generated at 2022-06-12 16:18:55.714829
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(value=None, start_index=None, end_index=None)
    assert isinstance(token, DictToken) is True
    assert isinstance(token, Token) is True


# Generated at 2022-06-12 16:19:01.622119
# Unit test for constructor of class DictToken
def test_DictToken():
# Test 1
    if(DictToken({"A":1, "B":2, "C":3},0,0) != DictToken({"A":1, "B":2, "C":3},0,0)):
        raise RuntimeError("Error1")
# Test 2
    if(DictToken({"A":1, "B":2, "C":3},0,0)._value != {"A":1, "B":2, "C":3}):
        raise RuntimeError("Error2")
# Test 3
    if(DictToken({"A":1, "B":2, "C":3},0,0)._child_keys != {"A":1, "B":2, "C":3}):
        raise RuntimeError("Error3")
# Test 4

# Generated at 2022-06-12 16:19:12.802006
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken(1, 2, 3, 4, 5, 6, a = 1, b = 2)
    assert dt.value == 1


# Generated at 2022-06-12 16:19:22.133232
# Unit test for constructor of class DictToken
def test_DictToken():
    # Arrange
    start_index = 1
    end_index = 2
    content = "abc"
    # Act
    my_token = DictToken({}, start_index, end_index, content)
    # Assert
    assert my_token.string == "bc"
    assert my_token._get_value() == {}
    assert my_token.start.line_no == 2
    assert my_token.start.column_no == 2
    assert my_token.start.index == 1
    assert my_token.end.line_no == 2
    assert my_token.end.column_no == 2
    assert my_token.end.index == 2
    assert my_token.lookup([]) == my_token
    assert my_token.lookup_key([]) == my_token

# Generated at 2022-06-12 16:19:26.581491
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken({'a': 1, 'b': 2}, 0, 1, "a=1,b=2")
    try:
        assert t
    except:
        print('Constructor of a DictToken fails.')


# Generated at 2022-06-12 16:19:29.662869
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken(dict(), 0, 0)

    # def __init__(self, value: typing.Any, start_index: int, end_index: int,
    #              content: str = "") -> None:


# Generated at 2022-06-12 16:19:33.572181
# Unit test for constructor of class DictToken
def test_DictToken():
    t1 = {'1':'a','2':'b','3':'c'}
    assert t1 == {'1':'a','2':'b','3':'c'}


# Generated at 2022-06-12 16:19:35.393763
# Unit test for constructor of class DictToken
def test_DictToken():
    import sys
    print(sys.version)
    print(type(dict()))

# Generated at 2022-06-12 16:19:44.259047
# Unit test for constructor of class DictToken
def test_DictToken():
    # Given
    token1 = ScalarToken("a", 0, 1, content="a")
    token2 = ScalarToken("b", 2, 3, content="b")
    key_token = DictToken({token1: token2}, 0, 3, content="ab")
    token3 = ScalarToken("c", 4, 5, content="c")
    token4 = ScalarToken("d", 6, 7, content="d")
    value_token = DictToken({token3: token4}, 4, 7, content="cd")
    # When
    kt = key = value = None

# Generated at 2022-06-12 16:19:54.052025
# Unit test for constructor of class DictToken
def test_DictToken():
    dictToken = DictToken({1: ScalarToken(2, 3, 4)}, 0, 1, 'abc')
    assert dictToken.__eq__(DictToken({1: ScalarToken(2, 3, 4)}, 0, 1, 'abc'))
    assert dictToken.string == ''
    assert dictToken.start == Position(1, 1, 0)
    assert dictToken.end == Position(1, 1, 1)
    assert dictToken.value == {1: 2}
    assert dictToken.lookup([1]).__eq__(ScalarToken(2, 3, 4))
    assert dictToken.lookup_key([1, 1]).__eq__(ScalarToken(1, 3, 4))


# Generated at 2022-06-12 16:19:57.554750
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken(1, 2, 3, content="abc")
    DictToken(1, 2, 3, content="abc", start_index=1)

# Generated at 2022-06-12 16:20:01.412798
# Unit test for constructor of class DictToken
def test_DictToken():
    a = "abcd"
    strToken = ScalarToken(a,0,3,"abc xyz")
    dictToken = DictToken({"abc" : strToken},0,3,"abc xyz")
    assert dictToken.end == Position(1, 4, 3)
    

# Generated at 2022-06-12 16:20:14.393160
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({}, 0, 0)
    if token is None:
        print("DictToken has initilized!")
    else:
        raise Exception("DictToken not initilized!")


# Generated at 2022-06-12 16:20:22.154687
# Unit test for constructor of class DictToken
def test_DictToken():
    string_list = ["key1", "key2", "key3"]
    value_list = ["value1", "value2", "value3"]
    child_keys_expected = {'key3':['key3']}
    child_tokens_expected = {'key3':Token(value_list[2], 0, 3, "key3")}
    token_dict = DictToken(string_list, 0, 3, "key3")
    assert token_dict._child_keys == child_keys_expected
    assert token_dict._child_tokens == child_tokens_expected

# Generated at 2022-06-12 16:20:25.444815
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken([], [], "")
    assert isinstance(dict_token, Token)
    assert isinstance(dict_token, DictToken)
    assert not issubclass(DictToken, ListToken)



# Generated at 2022-06-12 16:20:36.230265
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import String
    string = String()
    a = ScalarToken(string, 1, 4, 'test')
    a = DictToken(2, 3, string, 'test')
    assert a.__dict__.has_key('_start_index')
    assert a.__dict__.has_key('_end_index')
    assert a.__dict__.has_key('_content')
    assert a.__dict__.has_key('_child_keys')
    assert a.__dict__.has_key('_child_tokens')
    assert a.__dict__.has_key('_value')


# Generated at 2022-06-12 16:20:42.921556
# Unit test for constructor of class DictToken
def test_DictToken():
        t = DictToken(value = {}, start_index = 0, end_index = 1, content = "test")
        assert(t._child_keys == {})
        assert(t._child_tokens == {})
        assert(t._value == {})
        assert(t._start_index == 0)
        assert(t._end_index == 1)
        assert(t._content == "test")


# Generated at 2022-06-12 16:20:50.304196
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({'aaa': {'bbb': 'ccc'}})
    # test hash
    assert token.__hash__() == -4102203045
    # test _get_value
    assert token._get_value() == {'aaa': {'bbb': 'ccc'}}
    # test _get_child_token
    assert token._get_child_token('aaa')._get_value() == {'bbb': 'ccc'}
    # test _get_key_token
    assert token._get_key_token('bbb') == None
    # test value
    assert token.value == {'aaa': {'bbb': 'ccc'}}


# Generated at 2022-06-12 16:20:57.449656
# Unit test for constructor of class DictToken
def test_DictToken():
    fields = {'fields': 'hello'}
    key_token = Token("fields", 0, 4)
    value_token = Token("hello", 6, 10)
    d = DictToken(fields,0,10,content = 'fields : hello')
    assert d._child_keys['fields'] == key_token
    assert d._child_tokens['fields'] == value_token


# Generated at 2022-06-12 16:20:59.007480
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken(5,"hello", 0, 1)


# Generated at 2022-06-12 16:21:01.306023
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {'a':1, 'b':2}
    d_t = DictToken(d,0,0,d)
    assert(d == d_t.value)


# Generated at 2022-06-12 16:21:13.472986
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {
        "a": ScalarToken("one", 0, 3, content="one"),
        "b": ScalarToken("two", 4, 7, content="two"),
    }
    # d_token = DictToken(d, 0, 3, content="one\ttwo")
    d_token = DictToken(d, 0, 3, content="one\ttwo")
    assert d_token._child_keys == {
        "a": ScalarToken("a", 0, 1, content="a"),
        "b": ScalarToken("b", 2, 3, content="b"),
    }

# Generated at 2022-06-12 16:21:33.126510
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken({'a':1},1,3)
    assert dt._start_index == 1
    assert dt._end_index == 3



# Generated at 2022-06-12 16:21:38.469847
# Unit test for constructor of class DictToken
def test_DictToken():
    test = {"a" : 1}
    token = DictToken(test, 1, 3)
    assert token._child_keys["a"] == test["a"]
    assert token._child_tokens["a"] == test["a"]


# Generated at 2022-06-12 16:21:41.694900
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {b'key1': b'value1', b'key2': b'value2'}
    v = DictToken(d, 0, 0)
    assert dict(v) == d


# Generated at 2022-06-12 16:21:43.845557
# Unit test for constructor of class DictToken
def test_DictToken():
   a = DictToken({}, 0, 100)
   assert a._value == {}
   

# Generated at 2022-06-12 16:21:45.648115
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {}
    t = DictToken(d, 0, 0)
    assert t.value == {}


# Generated at 2022-06-12 16:21:46.988831
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken()
    assert dt.__hash__() == None

# Generated at 2022-06-12 16:21:51.831431
# Unit test for constructor of class DictToken
def test_DictToken():
    test_dict = {
        'a': 'test',
        'b': 'test2'
    }
    assert DictToken(test_dict, 1, 3, 'a: test, b: test2')._get_value() == test_dict

if __name__=="__main__":
    test_DictToken()

# Generated at 2022-06-12 16:21:53.159305
# Unit test for constructor of class DictToken
def test_DictToken():
	DictToken({"a": "b"}, 0, 1, "")

# Generated at 2022-06-12 16:21:57.139163
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken([], 0, 5)
    assert t._child_keys == {}
    assert t._child_tokens == {}
    assert t._value == {}



# Generated at 2022-06-12 16:22:04.266263
# Unit test for constructor of class DictToken
def test_DictToken():
    value = {"a": "A", "b": "B"}
    start_index = 10
    end_index = 15
    content = "value"
    token = DictToken(value, start_index, end_index, content)
    assert token.string == "value"
    assert token._value == value
    assert token.value == {"a": "A", "b": "B"}
    assert token.start.line == 1
    assert token.start.column == 11
    assert token.start.index == 10
    assert token.end.line == 1
    assert token.end.column == 16
    assert token.end.index == 15

