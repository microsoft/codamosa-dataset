

# Generated at 2022-06-12 16:12:29.940834
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(value=1, start_index=0, end_index=1) == Token(value=1, start_index=0, end_index=1)
    assert Token(value=1, start_index=0, end_index=1) != Token(value=1, start_index=0, end_index=2)
    assert Token(value=1, start_index=0, end_index=1) != Token(value=1, start_index=1, end_index=1)
    assert Token(value=1, start_index=0, end_index=1) != Token(value=2, start_index=0, end_index=1)


# Generated at 2022-06-12 16:12:39.740776
# Unit test for constructor of class DictToken
def test_DictToken():
    class Token1(Token):
        def __init__(self, value: typing.Any, start_index: int, end_index: int, content: str = "") -> None:
            self.value = value
            self.start_index = start_index
            self.end_index = end_index
            self.content = content
        def _get_value(self) -> typing.Any: 
            return self.value
        def _get_child_token(self, key: typing.Any) -> Token: 
            return self.content
        def _get_key_token(self, key: typing.Any) -> Token:
            return self.content
    a = Token1("a", 1, 1, "a")
    b = Token1("b", 2, 2, "ab")

# Generated at 2022-06-12 16:12:49.363976
# Unit test for constructor of class DictToken
def test_DictToken():
    content = '{"a": 1, "b": 2}'
    token = DictToken({ScalarToken('a', 2, 3): ScalarToken(1, 6, 6), ScalarToken('b', 9, 10): ScalarToken(2, 13, 13)}, 0, 15, content=content)
    assert token.string == content
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 16, 15)
    assert token.value == {'a': 1, 'b': 2}
    assert token.lookup([]) == token
    assert token.lookup([0]) == ScalarToken('a', 2, 3)
    assert token.lookup([1]) == ScalarToken('b', 9, 10)

# Generated at 2022-06-12 16:12:56.946661
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_test = Token(value="test",start_index=10,end_index=20,content="test_content")
    token_test2 = Token(value="test_2",start_index=10,end_index=20,content="test_content")
    assert(token_test==token_test)
    assert(token_test!=token_test2)
#Unit test for method __repr__ of class Token

# Generated at 2022-06-12 16:12:58.716957
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 1, 1, "")
    assert token._get_value() == 1
    assert token._start_index == 1
    assert token._end_index == 1
    assert isinstance(token, Token)
    assert token == token
    assert token == token


test_Token___eq__()

# Generated at 2022-06-12 16:13:03.192645
# Unit test for constructor of class DictToken
def test_DictToken():
    import pytest

    d = DictToken(
        {1: "a", 2: "b"}, start_index=0, end_index=0, content=""
    )

    assert d._get_value() == {1: "a", 2: "b"}



# Generated at 2022-06-12 16:13:08.204539
# Unit test for constructor of class DictToken
def test_DictToken():
    token1 = DictToken(3,1,2, content="hello")
    token2 = DictToken(5,5,5, content="hello")
    assert isinstance(token1, Token)
    assert isinstance(token2, Token)
    assert token1._value != token2._value
    assert token1._start_index != token2._start_index
    assert token1._end_index != token2._end_index
    assert token1._content == token2._content

# Generated at 2022-06-12 16:13:11.457951
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """Test whether the method Token.__eq__ works correctly."""
    tt = ScalarToken(True, 0, 3)
    tf = ScalarToken(False, 0, 4)
    assert tt != tf
    assert not (tt == tf)



# Generated at 2022-06-12 16:13:15.181213
# Unit test for constructor of class DictToken
def test_DictToken():
    content = "hi"
    start_index = 0
    end_index = 0
    value = {"hello": "world"}
    DictToken(value=value, start_index=start_index, end_index=end_index, content=content)


# Generated at 2022-06-12 16:13:24.227439
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # TEST CASE: Instances of a scalar token are equal if and only if their
    # values, start_indices and end_indices are equal
    token1 = ScalarToken(1, 0, 1, content = "token1")
    token2 = ScalarToken(1, 0, 1, content = "token2")
    token3 = ScalarToken(2, 0, 1, content = "token3")
    token4 = ScalarToken(1, 1, 1, content = "token4")
    token5 = ScalarToken(1, 0, 2, content = "token5")
    assert token1 == token2
    assert token1 != token3
    assert token1 != token4
    assert token1 != token5
    # TEST CASE: Instances of a list token are equal if and only if their
    # values, start_ind

# Generated at 2022-06-12 16:13:32.292216
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t = Token( 10, 1, 5, content="Dummy Content" )
    t2 = Token( 10, 1, 5, content="Dummy Content" )
    assert t == t2

    t = Token( 10, 1, 5, content="Dummy Content" )
    t2 = Token( 10, 1, 4, content="Dummy Content" )
    assert not( t == t2 )


# Generated at 2022-06-12 16:13:35.227710
# Unit test for constructor of class DictToken
def test_DictToken(): # pragma: no cover
    token = DictToken({}, 1, 2, "")
    assert token._child_keys == {}
    assert token._child_tokens == {}


# Generated at 2022-06-12 16:13:43.598657
# Unit test for constructor of class DictToken
def test_DictToken():
    tokens = {'token1': 'token1', 'token2': 'token2'}
    new_dict_token = DictToken(values=tokens, start_index=1, end_index=6)
    assert new_dict_token._value == {'token1': 'token1', 'token2': 'token2'}
    assert new_dict_token._start_index == 1
    assert new_dict_token._end_index == 6


# Generated at 2022-06-12 16:13:52.452266
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({}, 0, 1).value == {}
    assert DictToken({}, 0, 95).value == {}
    assert DictToken({}, 0, 1)._get_value() == {}
    assert DictToken({}, 0, 95)._get_value() == {}
    assert DictToken({}, 0, 1)._get_value() == {}
    assert DictToken({}, 0, 95)._get_value() == {}
    assert DictToken({}, 0, 1)._get_value() == {}
    assert DictToken({}, 0, 95)._get_value() == {}


# Generated at 2022-06-12 16:13:55.915777
# Unit test for constructor of class DictToken
def test_DictToken():
    test = DictToken({"TEST": "TEST"}, 0, 0)
    check = DictToken({"TEST": "TEST"}, 0, 0)
    assert test == check


# Generated at 2022-06-12 16:14:02.836164
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Testing Token.__eq__
    # Setup
    param0 = 7
    param1 = 8
    param2 = 9
    param3 = 10
    param4 = 11
    TokenType = None
    if True:
        # Testing Token.__eq__ via Token(param0, param1, param2, param3)
        # Setup
        class TempClass(Token):
            def __init__(self, param0, param1, param2, param3):
                self._value = param0
                self._start_index = param1
                self._end_index = param2
                self._content = param3
            def _get_value(self):
                return self._value
            def _get_child_token(self,param0):
                pass
            def _get_key_token(self,param0):
                pass


# Generated at 2022-06-12 16:14:11.928319
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    content = '["abc", "\u00ff"]'
    # [start:end:step]
    tokens = [
        Token("a", 0, 0),
        Token("b", 1, 1),
        Token("c", 2, 2),
        Token("\u00ff", 4, 6),
    ]
    assert tokens[0] == tokens[0]
    assert tokens[1] == tokens[1]
    assert tokens[2] == tokens[2]
    assert tokens[3] == tokens[3]
    assert tokens[0] != tokens[1]
    assert tokens[0] != tokens[2]
    assert tokens[0] != tokens[3]
    assert tokens[1] != tokens[2]
    assert tokens[1] != tokens[3]
    assert tokens[2] != tokens[3]

# Generated at 2022-06-12 16:14:19.750925
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(value={}, start_index=0, end_index=0, content="Hello World")
    assert token.string == "Hello World"
    assert token.value == {}
    assert token.start == Position(line_no=1, column_no=1, index=0)
    assert token.end == Position(line_no=1, column_no=1, index=0)
    assert token.lookup([0]) == None
    assert token.lookup_key([0]) == None
    #assert repr(token) == "DictToken({})"
    assert token == token



# Generated at 2022-06-12 16:14:30.245774
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {1: 1}
    assert type(d).__name__ == "dict"
    dt = DictToken(d, 1, 1, "d")
    assert type(dt).__name__ == "DictToken"
    assert dt._value == d
    assert dt._start_index == 1
    assert dt._end_index == 1
    assert dt._content == "d"
    assert dt._child_keys == {1: 1}
    assert dt._child_tokens == {1: 1}
    assert dt.value == {1: 1}
    assert dt.start == Position(1, 1, 1)
    assert dt.end == Position(1, 1, 1)
    assert dt.string == "d"
    assert dt.lookup([]) == dt

# Generated at 2022-06-12 16:14:41.314939
# Unit test for method __eq__ of class Token
def test_Token___eq__():
  obj = Token(1,2,3)
  assert obj._start_index == 2
  assert obj._end_index == 3
  assert obj._get_value() == 1
  assert obj.start == Position(1, 3, 2)
  assert obj.end == Position(1, 4, 3)
  assert obj.string == ''
  assert obj.__repr__() == "Token('')"
  assert obj == Token(1,2,3)
  assert obj != Token(4,2,3)
  assert obj != Token(1,4,3)
  assert obj != Token(1,2,4)
  assert obj != '1'
test_Token___eq__()


# Generated at 2022-06-12 16:14:48.701068
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    pass


# Generated at 2022-06-12 16:14:59.514426
# Unit test for constructor of class DictToken
def test_DictToken():
    class Test1Token(DictToken):
        def __init__(self, value: typing.Any, start_index: int, end_index: int, content: str = "") -> None:
            super().__init__(value, start_index, end_index, content)

    class Test2Token(DictToken):
        def __init__(self, value: typing.Any, start_index: int, end_index: int, content: str = "") -> None:
            super().__init__(value, start_index, end_index, content)

    a = Test1Token({1:1, 2:2}, 0, 3, "")
    assert(a._child_keys == {1:1, 2:2})
    assert(a._child_tokens == {1:1, 2:2})


# Generated at 2022-06-12 16:15:03.523564
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({}, 0, 1, "hello")
    assert token.string == "hello"
    assert token.start== Position(1,6,1)
    assert token.end== Position(1,6,1)

# Generated at 2022-06-12 16:15:09.816663
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 3, 4)
    assert Token(1, 2, 3) != ScalarToken(1, 2, 3)
    assert Token(1, 2, 3) != DictToken(None, 2, 3)
    assert Token(1, 2, 3) != ListToken(None, 2, 3)


# Generated at 2022-06-12 16:15:13.069000
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """Test that the Token.__eq__ method returns a bool."""
    # Initialize args with dummy values.
    args = [1,2,3,"str"]
    # Call the method to test
    result = Token.__eq__(*args)
    assert isinstance(result, bool)



# Generated at 2022-06-12 16:15:21.399129
# Unit test for constructor of class DictToken
def test_DictToken():
    _value = {'key1': 'value1', 'key2': 'value2'}
    _start_index = 0
    _end_index = 2
    _content = "content"
    token = DictToken(_value, _start_index, _end_index, _content)
    assert token._value == _value
    assert token._start_index == _start_index
    assert token._end_index == _end_index
    assert token._content == _content


# Generated at 2022-06-12 16:15:22.933854
# Unit test for constructor of class DictToken
def test_DictToken():
    assert "_value" in DictToken.__init__.__code__.co_varnames
    assert "_child_keys" in DictToken.__dict__
    assert "_child_tokens" in DictToken.__dict__


# Generated at 2022-06-12 16:15:33.760756
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    json_info = {
        "some_string": "abc",
        "s": "ab\\\"c",
        "some_int": 5,
        "some_float": 3.1415926,
        "some_bool": True,
        "some_null": None,
        "aaa": {
            "bbb": [
                {"ccc": {"ddd": {"eee": {"fff": "ggg"}}, "hhh": {"iii": "jjj"}}},
                {"ccc": {"ddd": "eee"}},
            ]
        },
        "jkl": {"mmm": [{"nnn": "ooo"}, {"nnn": "ppp"}, {"nnn": {"qqq": "rrr"}}]},
    }
    m = MagicMock()
    m.json_info = json_info
   

# Generated at 2022-06-12 16:15:45.963679
# Unit test for constructor of class DictToken
def test_DictToken():
    # Constructor of class Token
    start_index = 0
    end_index = 3
    content = "hello"
    value = "hello"
    token = Token(value, start_index, end_index, content)
    assert token._value == value
    assert token._start_index == start_index
    assert token._end_index == end_index
    assert token._content == content
    assert token.string == "hello"
    assert token.value == "hello"
    assert token.start.line_no == 1
    assert token.start.column_no == 5
    assert token.start.index == 0
    assert token.end.line_no == 1
    assert token.end.column_no == 5
    assert token.end.index == 3
    assert token.lookup(index = [0]) == token

# Generated at 2022-06-12 16:15:55.660951
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(0, 0, 0) == Token(0, 0, 0)
    assert ScalarToken(0, 0, 0) == ScalarToken(0, 0, 0)
    assert DictToken({ScalarToken(0, 0, 0): ScalarToken(0, 0, 0)}, 0, 0) == DictToken({ScalarToken(0, 0, 0): ScalarToken(0, 0, 0)}, 0, 0)
    assert ListToken([ScalarToken(0, 0, 0)], 0, 0) == ListToken([ScalarToken(0, 0, 0)], 0, 0)
    assert not Token(0, 0, 0) == Token(1, 0, 0)
    assert not ScalarToken(0, 0, 0) == ScalarToken(1, 0, 0)

# Generated at 2022-06-12 16:16:05.440740
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Setup
    v1 = 'a'
    v2 = 0
    v3 = 2
    v4 = 'a'
    v5 = 0
    v6 = 2

    # Exercise
    test_cases = []
    test_cases.append(Token(v1,v2,v3) == Token(v4,v5,v6))
    test_cases.append(Token(v1,v2,v3) == None)
    test_cases.append(Token(v1,v2,v3) == (1,2,3))
    test_cases.append(Token(v1,v2,v3) == [1,2,3])
    test_cases.append(Token(v1,v2,v3) == {1:2})

    # Verify

# Generated at 2022-06-12 16:16:10.830431
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(0, 0, 0) == Token(0, 0, 0)
    assert Token(0, 0, 0) != Token(1, 0, 0)
    assert Token(0, 0, 0) != Token(0, 1, 0)
    assert Token(0, 0, 0) != Token(0, 0, 1)
    assert Token(0, 0, 0) != 0
    assert Token(0, 0, 0) != object()

# Generated at 2022-06-12 16:16:22.739730
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from sources.token import Token

    assert Token(None, None, None) == Token(None, None, None)
    assert Token(1, 1, 1) == Token(1, 1, 1)
    assert Token('', 1, 1) == Token('', 1, 1)
    assert Token(1, 1, 1) != Token(2, 1, 1)
    assert Token('1', 1, 1) == Token('1', 1, 1)
    assert Token(1, 1, 1) != Token('1', 1, 1)
    assert Token(1, 1, 1) != Token(1, 2, 1)
    assert Token(1, 1, 1) != Token(1, 1, 2)
    assert Token([1], 1, 1) == Token([1], 1, 1)

# Generated at 2022-06-12 16:16:25.227014
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(value={}, start_index = 0, end_index = 0, content = "")


# Generated at 2022-06-12 16:16:26.727944
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({}, 0, 0, content='')



# Generated at 2022-06-12 16:16:29.464487
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(1, 2, 3)
    t2 = Token(2, 3, 4)
    assert not (t1 == t2)


# Generated at 2022-06-12 16:16:37.032997
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken(value= {'a': 'b'}, start_index=0, end_index=4, content= 'a=b').lookup([]) == DictToken(value= {'a': 'b'}, start_index=0, end_index=4, content= 'a=b')
    assert DictToken(value= {'a': 'b'}, start_index=0, end_index=4, content= 'a=b').lookup_key([0]) == DictToken(value= {'a': 'b'}, start_index=0, end_index=4, content= 'a=b')
    assert DictToken(value= {'a': 'b'}, start_index=0, end_index=4, content= 'a=b')._get_child_token('a') == 'b'

# Generated at 2022-06-12 16:16:43.131470
# Unit test for constructor of class DictToken
def test_DictToken():
    # Initialize dictionary
    value = {}
    value['key1'] = ValueToken
    value['key2'] = ValueToken
    value['key3'] = ValueToken
    
    # Create a DictToken object 
    test_DictToken = DictToken(value, 0, 10, content = "test_content")
    # Checks if the value of the object is the same as the one created
    assert test_DictToken._value == value


# Generated at 2022-06-12 16:16:56.176313
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token("", "", "")
    t2 = Token("", "", "")
    assert(t1 == t2)

    # Different value
    t1 = Token("a", "", "")
    t2 = Token("b", "", "")
    assert(not (t1 == t2))
    
    # Different start_index
    t1 = Token("", "a", "")
    t2 = Token("", "b", "")
    assert(not (t1 == t2))

    # Different end_index
    t1 = Token("", "", "a")
    t2 = Token("", "", "b")
    assert(not (t1 == t2))

    # Different content
    t1 = Token("", "", "", content = "test")

# Generated at 2022-06-12 16:16:57.667319
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({}, 0, 0, content="")


# Generated at 2022-06-12 16:17:18.700950
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    import builtins

    # Create an instance of type Token, with _value set to a number
    _value = 1

    # Call method __eq__ on class Token with _value set to a number
    assert Token._Token__eq__(Token, _value) == NotImplemented

    # Create an instance of type Token, with _value set to a string
    _value = ""

    # Call method __eq__ on class Token with _value set to a string
    assert Token._Token__eq__(Token, _value) == NotImplemented

    # Create an instance of type Token, with _value set to an empty list
    _value = []

    # Call method __eq__ on class Token with _value set to an empty list
    assert Token._Token__eq__(Token, _value) == NotImplemented

    # Create an instance of type Token,

# Generated at 2022-06-12 16:17:23.883455
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class MyClass(Token):
        def _get_value(self) -> typing.Any:
            pass

        def _get_child_token(self, key: typing.Any) -> "Token":
            pass

        def _get_key_token(self, key: typing.Any) -> "Token":
            pass

    obj1 = MyClass(None, 0, 0, "")
    obj2 = MyClass(None, 0, 0, "")
    assert obj1 == obj2
    obj3 = MyClass(None, 0, 0, "")
    obj4 = MyClass(None, 0, 0, "")
    assert obj3 == obj4
    obj5 = MyClass(None, 1, 0, "")
    obj6 = MyClass(None, 0, 0, "")
    assert not (obj5 == obj6)


# Generated at 2022-06-12 16:17:26.316271
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = ScalarToken("test", 0, 3, "test")
    assert token == ScalarToken("test", 0, 3, "test")


# Generated at 2022-06-12 16:17:31.734633
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(1, 2, 3, "abc")
    t2 = Token(1, 3, 4, "abcd")
    t3 = Token(2, 2, 3, "abc")
    assert t1 == t1
    assert not (t1 == t2)
    assert not (t1 == t3)


# Generated at 2022-06-12 16:17:35.778610
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test Instantiate of DictToken
    dict_token = DictToken(value={'one': 'two'}, start_index=1, end_index=2, content='dict')
    assert dict_token._value['one'] == 'two'
    assert dict_token._start_index == 1
    assert dict_token._end_index == 2
    assert dict_token._content == 'dict'


# Generated at 2022-06-12 16:17:41.497089
# Unit test for constructor of class DictToken
def test_DictToken():
    x = {
        "name": "Charly",
        "age": 450,
        "languages": ["Python", "Java", "C++", "JavaScript"],
        "favourite_language": "Python",
    }
    assert isinstance(DictToken, object)


# Generated at 2022-06-12 16:17:43.805227
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken(value = {}, start_index = 0, end_index = 1, content = '')


# Generated at 2022-06-12 16:17:47.178279
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(1, 2, 3)
    t2 = Token(1, 2, 3)
    t3 = Token(2, 2, 3)
    assert t1 == t2
    assert t1 != t3


# Generated at 2022-06-12 16:17:53.544380
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    import json
    from typesystem.token import DictToken
    from typesystem.token import ScalarToken
    from typesystem.token import StringToken
    content = """
    [{"field": "name", "type": "string"}]
    """
    index = json.loads(content)
    token = DictToken(
        {ScalarToken("field", 0, 5): StringToken("name", 6, 10, content),
         ScalarToken("type", 11, 15): StringToken("string", 16, 22, content)},
        0,
        22,
        content
    )
    token_2 = token.lookup(index)
    assert token_2 == token


# Generated at 2022-06-12 16:17:54.117856
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken()

# Generated at 2022-06-12 16:18:37.319850
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token("value", 0, 0, "content") == Token("value", 0, 0, "content")


# Generated at 2022-06-12 16:18:40.492115
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token(1,1,2,"hello world")
    assert(token.lookup(1) == 0)


# Generated at 2022-06-12 16:18:51.408892
# Unit test for method lookup of class Token

# Generated at 2022-06-12 16:18:58.721885
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
  a = ScalarToken(True,0,4,"True")
  assert (a.string == "True")
  assert (a.value == True)
  assert (a.start.line_no == 1)
  assert (a.start.column_no == 1)
  assert (a.start.index == 0)
  assert (a.end.line_no == 1)
  assert (a.end.column_no == 5)
  assert (a.end.index == 4)
  assert (repr(a) == 'ScalarToken(\'True\')')
  assert (a.lookup([]) == a)
  assert (a.lookup_key([]) == a)
  


# Generated at 2022-06-12 16:19:01.849106
# Unit test for method lookup of class Token
def test_Token_lookup():
    # new object of class Token
    token = Token(None, 0, 0)

    assert token.lookup(0) == 'T'

# Generated at 2022-06-12 16:19:08.195580
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    value = "hello"
    start_index = 0
    end_index = 4
    content = "hello world"
    t = ScalarToken(value, start_index, end_index, content)
    assert t.string == value
    assert t.value == value
    assert t.start == Position(1, 1, 0)
    assert t.end == Position(1, 5, 4)


# Generated at 2022-06-12 16:19:09.218745
# Unit test for constructor of class ListToken
def test_ListToken():
	t = ListToken([], 0, 0)
	assert t.value == [], "t is not equal to the expected value."



# Generated at 2022-06-12 16:19:19.810494
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(value=1, start_index=2, end_index=3)
    assert token._value == 1
    assert token._start_index == 2
    assert token._end_index == 3
    assert token.__repr__() == "ScalarToken(1)"
    assert token._get_value() == 1
    # Test __eq__
    assert ScalarToken(value=1, start_index=2, end_index=3) == ScalarToken(
        value=1, start_index=2, end_index=3
    )
    assert ScalarToken(value=1, start_index=2, end_index=3) != ScalarToken(
        value=1, start_index=2, end_index=4
    )

# Generated at 2022-06-12 16:19:22.544668
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(value = {'keyword': 'value'},
                     start_index = 0,
                     end_index = 23,
                     content = '{\'keyword\': \'value\'}')



# Generated at 2022-06-12 16:19:26.268048
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # Setup
    # Exercise
    obj = ScalarToken(42, 0, 1, "42")
    result = obj.__hash__()

    # Verify
    assert result == 42

# Generated at 2022-06-12 16:20:25.172652
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token(
        {
            ScalarToken(1, 0, 0, content="{1: 1}"),
            ScalarToken(2, 1, 1, content="{1: 1}"),
            ScalarToken(2, 1, 1, content="{1: 1}")
        },
        0,
        1,
        content="{1: 1}",
    )
    token.lookup([1])



# Generated at 2022-06-12 16:20:31.168390
# Unit test for method lookup of class Token
def test_Token_lookup():
    # Setup
    token = None
    index = None
    expected_child_token = None
    # Exercise and Verify
    # Nothing to exercise
    if expected_child_token:
        assert token.lookup(index) == expected_child_token


# Generated at 2022-06-12 16:20:35.411718
# Unit test for constructor of class Token
def test_Token():
    test = Token(value=123, start_index=0, end_index=1, content="1")
    assert test.string == "1"
    assert test.value == 123
    assert test.start == Position(1,2,0)
    assert test.end == Position(1,2,1)


# Generated at 2022-06-12 16:20:36.264638
# Unit test for constructor of class Token
def test_Token():
    Token


# Generated at 2022-06-12 16:20:42.914937
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    """Unit test for method __hash__ of class ScalarToken"""
    assert ScalarToken(10, 0, 0).__hash__() == hash(10)
    assert ScalarToken('foo', 0, 0).__hash__() == hash('foo')
    assert ScalarToken(True, 0, 0).__hash__() == hash(True)
    assert ScalarToken(None, 0, 0).__hash__() == hash(None)

# Generated at 2022-06-12 16:20:45.161458
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token(['foo', 'bar'], 0, 5)
    assert token.lookup([1]).string == 'bar'


# Generated at 2022-06-12 16:20:52.100913
# Unit test for constructor of class Token
def test_Token():
    # check initialization
    token = Token(1, 2, 3, "abcde")
    assert (token._start_index == 2)
    assert (token._end_index == 3)
    assert (token._content == "abcde")
    assert (token._value == 1)
    # check property string
    assert (token.string == "c")
    # check property value
    assert (token.value == NotImplemented)
    # check property start
    assert (token.start.line == 1)
    assert (token.start.column == 3)
    assert (token.start.index == 2)
    # check property end
    assert (token.end.line == 1)
    assert (token.end.column == 4)
    assert (token.end.index == 3)
    # check lookup(index)

# Generated at 2022-06-12 16:20:58.912262
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from unittest import TestCase
    from unittest.mock import Mock

    # Create mock objects
    value = Mock()
    start_index = Mock()
    end_index = Mock()
    content = Mock()

    # Construct token
    token = Token(value, start_index, end_index, content)

    # Token should be equal to itself
    assert token.__eq__(token)

    # Token should not be equal to anything else
    assert not token.__eq__(Mock())



# Generated at 2022-06-12 16:21:10.457731
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken('a', 1, 3)
    assert token._value == 'a'
    assert token._start_index == 1
    assert token._end_index == 3
    assert token.string == 'a'
    assert token.value == 'a'
    assert token.start == Position(1, 2, 1)
    assert token.end == Position(1, 2, 1)
    assert token.lookup([0]) == None
    assert token.lookup_key([0, 0]) == None
    # test __repr__
    assert repr(token) == "ScalarToken('a')"
    # test __eq__
    another_token = ScalarToken('a', 1, 3)
    assert token == another_token
    assert not (token == 'a')
    # test __hash__

# Generated at 2022-06-12 16:21:12.326876
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert hash(0) == ScalarToken(0, 0, 0).__hash__()