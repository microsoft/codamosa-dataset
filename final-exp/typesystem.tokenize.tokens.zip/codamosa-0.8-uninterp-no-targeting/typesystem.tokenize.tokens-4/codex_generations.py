

# Generated at 2022-06-22 06:29:04.703109
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token(value=None, start_index=None, end_index=None, content=None)
    assert repr(token) == "Token(None)"



# Generated at 2022-06-22 06:29:06.500538
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("a", 1, 2)
    assert token.string == "a"


# Generated at 2022-06-22 06:29:09.412996
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token(0, 10, 20)
    assert token.lookup([]) == token

    with pytest.raises(AttributeError):
        token._get_child_token(0)


# Generated at 2022-06-22 06:29:18.472245
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    assert ScalarToken("toto", 1, 2, "toto").value == "toto"
    assert ScalarToken("toto", 1, 2, "toto").start_index == 1
    assert ScalarToken("toto", 1, 2, "toto").end_index == 2
    assert ScalarToken("toto", 1, 2, "toto").string == "toto"
    assert ScalarToken("toto", 1, 2, "toto").start == Position(1, 1, 1)
    assert ScalarToken("toto", 1, 2, "toto").end == Position(1, 1, 2)

    assert ScalarToken("toto", 1, 2, "toto") == ScalarToken("toto", 1, 2, "toto")


# Generated at 2022-06-22 06:29:19.628653
# Unit test for method lookup of class Token
def test_Token_lookup():
    index = [1,2]
    print('hello')

# Generated at 2022-06-22 06:29:26.268362
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    # test all branches
    value = 1337
    start_index = 13
    end_index = 37
    content = "foobar"
    token = ScalarToken(value, start_index, end_index, content)
    assert token.string == "foobar"
    assert token.value == 1337
    assert token.start == Position(1, 14, 13)
    assert token.end == Position(1, 38, 37)
    assert token.lookup([]) == token


# Generated at 2022-06-22 06:29:29.999908
# Unit test for constructor of class Token
def test_Token():
    a = Token(1, 2, 3)
    assert a._value == 1
    assert a._start_index == 2
    assert a._end_index == 3


# Generated at 2022-06-22 06:29:32.123737
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    # test if default values exist
    assert ScalarToken("a", 1, 2, "abc").__dict__ == {"_value": "a", "_start_index": 1, "_end_index": 2, "_content": "abc"}


# Generated at 2022-06-22 06:29:36.811065
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"hello": "world"}, 0, 12, "hello {\"world\"}")
    assert token.value == {"hello": "world"}


# Generated at 2022-06-22 06:29:47.769000
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token1 = ScalarToken(value=None, start_index=0, end_index=1, content="")
    assert repr(token1) == 'ScalarToken(\'\')'

    token2 = ScalarToken(value=1.5, start_index=0, end_index=1, content="")
    assert repr(token2) == 'ScalarToken(\'\')'

    token3 = ScalarToken(value="1.5", start_index=0, end_index=1, content="")
    assert repr(token3) == 'ScalarToken(\'\')'

    token4 = ScalarToken(value="true", start_index=0, end_index=1, content="")
    assert repr(token4) == 'ScalarToken(\'\')'

    token5 = ScalarToken

# Generated at 2022-06-22 06:29:54.173905
# Unit test for constructor of class Token
def test_Token():
  token = Token(value = 2, start_index = 0, end_index = 0, content = "x")
  assert token.value == 2
  assert token.start.line == 1
  assert token.start.column == 1
  assert token.start.index == 0
  assert token.end.line == 1
  assert token.end.column == 1
  assert token.end.index == 0
  assert token.string == "x"


# Generated at 2022-06-22 06:29:56.277368
# Unit test for constructor of class Token
def test_Token():
    token = Token(None, 0, 1)
    token = Token(None, 0, 1, "")


# Generated at 2022-06-22 06:30:02.326126
# Unit test for method lookup of class Token
def test_Token_lookup():
    # given
    token = ScalarToken(123, 0, 2, "123")
    # when
    index1 = []
    index2 = [0]
    index3 = [0, 0]
    # then
    assert token.lookup(index1) == token
    assert token.lookup(index2) == token
    assert token.lookup(index3) == token

# Generated at 2022-06-22 06:30:12.345751
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    """
    @test {"name": "Token.__repr__()"}
    """
    assert repr(ScalarToken('test_value', 0, 9, 'test_content')) == "ScalarToken('test_value')"
    assert repr(DictToken({'test_value': 'test_value'}, 0, 9, 'test_content')) == "DictToken({'test_value': 'test_value'})"
    assert repr(ListToken(['test_value', 'test_value'], 0, 9, 'test_content')) == "ListToken(['test_value', 'test_value'])"


# Generated at 2022-06-22 06:30:15.580980
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # Create an instance of ScalarToken
    scalar_token_instance = ScalarToken(1, 1, 1)
    # Call method __hash__ on the instance
    scalar_token_instance.__hash__()

# Generated at 2022-06-22 06:30:21.038574
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("frodo", 0, 5)
    assert token.string == "frodo"
    assert token.value == "frodo"
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 6, 5)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token


# Generated at 2022-06-22 06:30:24.946757
# Unit test for constructor of class Token
def test_Token():
    from typesystem.base import create_type
    from typesystem.parser import Parser

    class RootType(create_type("RootType", [], {"child_types": {}})):
        pass

    class ChildType(create_type("ChildType", [], {"child_types": {}})):
        pass

    parser = Parser(
        ChildType({}),
        RootType({"child_types": {"key": ChildType}}),
        {},
        {},
        {},
    )

    assert (
        ScalarToken(parser.parse("a").value, 0, 0, "a")._value
        == parser.parse("a").value
    )
    assert ScalarToken(parser.parse("a").value, 0, 0, "a")._start_index == 0

# Generated at 2022-06-22 06:30:35.867602
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token1 = ScalarToken("item1",0,3,"item1")
    assert(isinstance(token1, ScalarToken))
    assert(token1._value == "item1")
    assert(token1._start_index == 0)
    assert(token1._end_index == 3)
    assert(token1._content == "item1")
    assert(token1.string == "item1")
    assert(token1.value == "item1")
    assert(token1.start.index == 0)
    assert(token1.start.line == 1)
    assert(token1.start.column == 1)
    assert(token1.end.index == 3)
    assert(token1.end.line == 1)
    assert(token1.end.column == 4)

# Generated at 2022-06-22 06:30:43.206687
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    string = "foo"
    token1 = Token(string, 0, 1)
    token2 = Token(string, 0, 1)
    token3 = Token("bar", 0, 1)
    assert token1 == token2
    assert token1 != token3

    token1 = Token(None, 0, 1)
    token2 = Token(None, 0, 1)
    token3 = Token(1, 0, 1)
    assert token1 == token2
    assert token1 != token3

# Generated at 2022-06-22 06:30:54.553989
# Unit test for constructor of class ListToken
def test_ListToken():
    from typesystem.token import ListToken
    from typesystem.token import Token
    from typesystem.token import ScalarToken
    token_1 = ScalarToken("scalar1", 0 , 3)
    token_2 = ScalarToken("scalar2", 4 , 7)
    token_3 = ScalarToken("scalar3", 8 , 11)
    token_4 = ScalarToken("scalar4", 12 , 15)
    list = [token_1, token_2, token_3, token_4]
    token = ListToken(list, 0, 15)
    print (token)
    print (token._value)
    print (token_1)
    print (token_2)
    print (token_3)
    print (token_4)
    print (token.string)

# Generated at 2022-06-22 06:31:08.126745
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    content = "my_content"
    start_index = 0
    end_index = -1
    my_scalar_token = ScalarToken("my_value", start_index, end_index, content)
    output = my_scalar_token.__repr__()
    assert output == "ScalarToken('my_value')"
    my_dict_token = DictToken({}, start_index, end_index, content)
    output = my_dict_token.__repr__()
    assert output == "DictToken('{}')"
    my_list_token = ListToken([], start_index, end_index, content)
    output = my_list_token.__repr__()
    assert output == "ListToken('[]')"

# Generated at 2022-06-22 06:31:18.905747
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token1 = ScalarToken(1, 2, 3);
    assert token1._value == 1
    assert token1._start_index == 2
    assert token1._end_index == 3
    assert token1.string == ""
    assert token1.value == 1
    assert token1.start == Position(1, 1, 2)
    assert token1.end == Position(1, 1, 3)
    assert token1.lookup([]) == token1
    assert token1.lookup_key([]) == token1
    assert str(token1) == "ScalarToken(' ')"
    token1_copy = ScalarToken(1, 2, 3);
    assert token1 == token1_copy
    assert hash(token1) == hash(token1_copy)


# Generated at 2022-06-22 06:31:20.678756
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(123, 0, 9)

    assert token is not None

# Generated at 2022-06-22 06:31:26.080274
# Unit test for constructor of class Token
def test_Token():
    test = Token(1, 1, 2)
    assert test._value == 1
    assert test._start_index == 1
    assert test._end_index == 2
    assert test._content == ""


# Generated at 2022-06-22 06:31:28.345341
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken(value=[1,2,3], start_index=0, end_index=2, content=None) != None


# Generated at 2022-06-22 06:31:31.294411
# Unit test for method lookup of class Token
def test_Token_lookup():
    obj = ListToken([1,2,3],0,2)
    assert obj.lookup([0]) == 1
    assert obj.lookup([2]) == 3
    assert obj.lookup([1]) == 2
    assert obj.lookup_key([1]) == '1'

# Generated at 2022-06-22 06:31:36.803875
# Unit test for constructor of class Token
def test_Token():
    token = Token(True, 0, 2)
    # print(token)
    assert token.string == 'foo'
    assert token.start == Position(1, 1, 0)
    assert token.value == 'foo'


# Generated at 2022-06-22 06:31:43.854610
# Unit test for constructor of class Token
def test_Token():
    tok = Token(
        value = "str",
        start_index = 1,
        end_index = 3,
        content = "rt"
    )
    assert tok.string == "rt"
    assert tok.value == "str"
    assert tok.start.index ==  1
    assert tok.end.index ==  3
    assert tok.__repr__() == "Token('rt')"
    assert tok.__eq__(tok) == True
    assert tok.lookup([2]) == tok
    assert tok.lookup_key([2, 2]) == tok


# Generated at 2022-06-22 06:31:48.250327
# Unit test for constructor of class ListToken
def test_ListToken():
  # Comparing value
  assert ListToken((), 0, 0).value == ()
  assert ListToken([], 0, 0).value == []
  assert ListToken(["abc"], 0, 0).value == ["abc"]

# Generated at 2022-06-22 06:31:50.451621
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(1, 0, 0, "")
    assert hash(token) == 1

# Generated at 2022-06-22 06:31:57.739050
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    value = object()
    start_index = object()
    end_index = object()
    content = object()
    ret = ScalarToken(value, start_index, end_index, content)
    assert hash(ret) == hash(ret._value)


# Generated at 2022-06-22 06:32:03.659514
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    import json

    json_string = r'{"a": [{"b": [1]}]}'
    token_value = json.loads(json_string)
    token = ScalarToken(token_value, 1, 1, json_string)
    assert token.string == r'"b"'
    assert token.value is None


# Generated at 2022-06-22 06:32:07.922756
# Unit test for constructor of class ListToken
def test_ListToken():
    t = ListToken([1,2,3], 0, 100, "1234\n")
    assert t.start.line == 1
    assert t.end.line == 2
    assert t.start.column == 1
    assert t.end.column == 1


# Generated at 2022-06-22 06:32:14.297529
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    x = Token("t", 5, 10)
    y = Token("t", 5, 10)
    assert x == y
    y = Token("t", 1, 10)
    assert not x == y
    y = Token("t", 5, 15)
    assert not x == y
    y = Token("t2", 5, 10)
    assert not x == y

# Generated at 2022-06-22 06:32:17.666465
# Unit test for method __eq__ of class Token
def test_Token___eq__():
  instance = Token(None, None, None, None)
  assert instance == instance
  assert not (instance != instance)
  # __eq__ is implemented in terms of __hash__
  assert instance.__hash__() == object.__hash__(instance)


# Generated at 2022-06-22 06:32:27.748791
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t = Token(value=None, start_index=1, end_index=10, content='')
    assert t.__eq__(None) == False, 'Expected False, but got: ' + str(t.__eq__(None))

    expected_result = NotImplemented
    result = t.__eq__(NotImplemented)
    assert result is expected_result, 'Expected {} but got: {}'.format(expected_result, result)
    
    s = list()
    expected_result = False
    result = t.__eq__(s)
    assert result is expected_result, 'Expected {} but got: {}'.format(expected_result, result)
    
    u = Token(value=None, start_index=1, end_index=10, content='')
    expected_result = True


# Generated at 2022-06-22 06:32:35.106750
# Unit test for method lookup of class Token
def test_Token_lookup():
    def test_1():
        print("Begin test_Token_lookup().test_1()")
        a = Token("token_a", 0, 0)
        assert a.lookup([]) is a
        print("Finish test_Token_lookup().test_1()")

    def test_2():
        print("Begin test_Token_lookup().test_2()")
        a = Token("token_a", 0, 0)
        assert a.lookup([0]) is a
        print("Finish test_Token_lookup().test_2()")

    test_1()
    test_2()


# Generated at 2022-06-22 06:32:40.900036
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({'1':'hi','2':'bye','6':'hello'}, 1, 20,content="")
    assert (token._start_index,token._end_index,token._child_keys,token._child_tokens) == (1, 20, {'1': 1, '2': 2, '6': 6}, {'1': 'hi', '2': 'bye', '6': 'hello'})


# Generated at 2022-06-22 06:32:47.577854
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # Note: we cannot use doctests because it seems impossible to create a
    # custom Token class that is recognised as a Token when used in a doctest.
    token = DictToken({'key': ScalarToken('value', 0, 0)}, 0, 0, '{key: value}')
    assert token.lookup_key([0]) == ScalarToken('key', 0, 0)

# Generated at 2022-06-22 06:32:49.635575
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    a = ScalarToken(42, 0, 1)
    assert a._value == 42


# Generated at 2022-06-22 06:32:56.532327
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token_a = ScalarToken(value = 1, start_index = 2, end_index = 3)
    assert hash(token_a) == hash(1)


# Generated at 2022-06-22 06:33:00.636966
# Unit test for constructor of class Token
def test_Token():
    t = Token(2, 2, 4, content='abcd')
    assert t.string == 'cd'
    assert t.value == 2
    assert t.start == Position(1,1,2)
    assert t.end == Position(1,3,4)


# Generated at 2022-06-22 06:33:03.386542
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Test for Token.__repr__
    assert str(Token(1, 2, 3, "This is a test")) == "Token(1)"



# Generated at 2022-06-22 06:33:05.892224
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken()
    assert isinstance(t, DictToken)
    assert isinstance(t, Token)


# Generated at 2022-06-22 06:33:09.318230
# Unit test for constructor of class Token
def test_Token():
    token = Token("", 0, 0, "")
    assert token.start.line == 1
    assert token.start.column == 1
    assert token.end.line == 1
    assert token.end.column == 1



# Generated at 2022-06-22 06:33:15.876426
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    """
    test method lookup_key of class Token
    """
    print("test method lookup_key of class Token")
    # input data
    token = ListToken([], 0, 0)
    idx = [0]
    # expected output
    expected_token = ScalarToken('', 0, 0)
    # real output
    real_token = token.lookup_key(idx)
    # assert equal for expected output and real output
    assert expected_token == real_token, 'expected_token == real_token'


# Generated at 2022-06-22 06:33:25.496708
# Unit test for method lookup of class Token
def test_Token_lookup():
    from typesystem.types import String
    from typesystem import Error
    from typesystem.lexer import Lexer, Tokenizer

    source = "true"
    l = Lexer(String, source=source)
    tokens = l.tokenize(source)
    token = tokens[0]
    assert token.value == True
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 5, 4)

    # test lookup method of class Token
    # return the child token in tokens if the index is a list
    assert token.lookup([]) == token

    # raise error if the index is not a list
    with pytest.raises(Error):
        token.lookup(3)


# test for method look_key for class Token

# Generated at 2022-06-22 06:33:29.474091
# Unit test for constructor of class ListToken
def test_ListToken():
    global_token = ListToken()
    assert type(global_token) == ListToken
    assert global_token._value == [token._get_value() for token in global_token._value]


# Generated at 2022-06-22 06:33:39.281097
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    from typesystem.base import Position
    from parse.tokenizer import Tokenizer
    
    tok = Token([], 0, 0, "")
    assert str(tok) == "Token([])"
    
    tok = Token([], 0, 0, "")
    assert repr(tok) == "Token([])"
    
    tok = Token([1, 2, 3], 0, 0, "")
    assert str(tok) == "Token([1, 2, 3])"
    
    tok = Token([1, 2, 3], 0, 0, "")
    assert repr(tok) == "Token([1, 2, 3])"
    
    tok = Token([1, 2, 3], 0, 0, "")
    assert str(tok) == "Token([1, 2, 3])"


# Generated at 2022-06-22 06:33:51.502884
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem import Scalar

    def CheckData(arg1, arg2, arg3, msg=''):
        try:
            assert arg1 == arg2 and arg2 == arg3
        except AssertionError:
            print(msg)

    t1 = DictToken(
        {Scalar(0): ScalarToken(2)}
        , 0, 0
    )
    CheckData(t1._value, {Scalar(0): ScalarToken(2)}, {0: ScalarToken(2)}, 'DictToken value test failed')
    CheckData(t1._child_keys, {0: Scalar(0)}, {0: Scalar(0)}, 'DictToken _child_keys test failed')

# Generated at 2022-06-22 06:34:08.136488
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)



# Generated at 2022-06-22 06:34:11.775161
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(_value=7, start_index=1, end_index=2, content="")
    assert token.__hash__() == hash(7)
    



# Generated at 2022-06-22 06:34:20.391524
# Unit test for constructor of class ListToken
def test_ListToken():
    # Test 1: Pass in empty list
    tkn = ListToken(value=[], start_index=0, end_index=0, content="")
    assert(tkn._get_value() == [])

    # Test 2: Pass in non empty list
    tkn = ListToken(value=[ScalarToken(value = "Hola", start_index = 0, end_index = 0, content = "")], start_index=0, end_index=0, content="")
    assert(tkn._get_value() == ["Hola"])

    # Test 3: Pass in multiple elements

# Generated at 2022-06-22 06:34:32.099462
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert ScalarToken(1, 1, 2) == ScalarToken(1, 1, 2)
    assert ScalarToken(1, 1, 2) != ScalarToken(2, 1, 2)
    assert ScalarToken(1, 1, 2) != ScalarToken(1, 2, 2)
    assert ScalarToken(1, 1, 2) != ScalarToken(1, 1, 3)
    assert DictToken({ScalarToken(1, 1, 1): ScalarToken(1, 2, 2)}, 1, 2) == DictToken({ScalarToken(1, 1, 1): ScalarToken(1, 2, 2)}, 1, 2)

# Generated at 2022-06-22 06:34:44.234607
# Unit test for constructor of class ListToken
def test_ListToken():
    var = ListToken(5,5,5,"5")
    assert (var.string == "5")
    assert (var.start.column_no == 1)
    assert (var.end.column_no == 1)
    assert (var.end.index == 5)
    assert (var.lookup([4]) != None)
    assert (var.lookup_key([4]) != None)
    assert (var.end.line_no == 1)
    assert (var.start.line_no == 1)
    assert (var.start.index == 5)
    assert (var.end.index == 5)
    #assert (var.string == "1")
    assert (var.string == "5")
    assert (var.value == 5)
    assert (var.value == 5)

# Generated at 2022-06-22 06:34:46.477342
# Unit test for constructor of class ListToken
def test_ListToken():
    # Test for constructor
    t = ListToken([], 0, 0)
    assert t._get_value() == []

# Generated at 2022-06-22 06:34:57.182627
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class Token(object):
        def __init__(self, value: object, start: object, end: object, content: object) -> None:
            self._value = value
            self._start_index = start
            self._end_index = end
            self._content = content
        
        def _get_value(self):
            raise NotImplementedError  # pragma: nocover
        
        def _get_child_token(self, key: typing.Any):
            raise NotImplementedError  # pragma: nocover
        
        def _get_key_token(self, key):
            raise NotImplementedError  # pragma: nocover
        
        @property
        def string(self) -> str:
            return self._content[self._start_index : self._end_index + 1]

# Generated at 2022-06-22 06:35:05.937895
# Unit test for constructor of class Token
def test_Token():
  token = Token(1,2,3,"")
  assert(token.end.column_no == 1)
  assert(token.start.column_no == 1)
  assert(token.start.line_no == 1)
  assert(token.end.line_no == 1)
  assert(token.end.index == 2)
  assert(token.start.index == 2)
  assert(token.start.line_no == 1)
  assert(token.end.line_no == 1)
  assert(str(token) == "Token(1)")
  assert(token._get_value() == 1)


# Generated at 2022-06-22 06:35:11.163992
# Unit test for constructor of class Token
def test_Token():
    start_index = 1
    end_index = 10
    content = "123456789"
    token = Token(None, start_index, end_index, content)
    assert token.start == Position(1, 1, 1)
    assert token.end == Position(1, 10, 10)
    assert token.string == "123456789"


# Generated at 2022-06-22 06:35:15.049734
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = Token("","","")
    token._get_child_token = MagicMock()
    token._get_child_token(2)._get_key_token = MagicMock()
    token.lookup_key(["a","b","c"])
    token._get_child_token.assert_called_with("a")
    token._get_child_token(2)._get_key_token.assert_called_with("c")

# Generated at 2022-06-22 06:35:33.854309
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    t = Token(
        {},
        0,
        1,
        "{}",
    )
    assert t.__repr__() == "Token(\"{}\")"


# Generated at 2022-06-22 06:35:36.747018
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    assert ScalarToken(
        1, 0, 0,
    ).value == 1



# Generated at 2022-06-22 06:35:41.722094
# Unit test for constructor of class ListToken
def test_ListToken():
    token1 = Token(1, 0, 1)
    token2 = Token(2, 2, 3)
    listToken = ListToken([token1, token2], 0, 3)
    assert listToken._get_value() == [1, 2]
    assert listToken._get_child_token(0) == token1



# Generated at 2022-06-22 06:35:47.444320
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(value = {"1": "2", "3": "4"}, start_index = 1, end_index = 10, content = "")
    assert token.string == ""
    assert token.value == {"1": "2", "3": "4"}
    assert token.start.line == 1
    assert token.start.column == 1
    assert token.start.index == 1
    assert token.end.line == 1
    assert token.end.column == 1
    assert token.end.index == 10

# Generated at 2022-06-22 06:35:51.769761
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    n = ScalarToken(3,4,5)
    assert n.value == 3
    assert n._value == 3
    assert n._start_index == 4
    assert n._end_index == 5
    assert n._content == ""
    assert n.string == ""

# Generated at 2022-06-22 06:35:55.479421
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    t = Token(
        value=None, 
        start_index=None, 
        end_index=None, 
        content=None
    )
    assert t.__repr__() == "Token(None)"


# Generated at 2022-06-22 06:36:07.921601
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # Create a Token (token)
    token = ScalarToken("hello", 1, 2, "hello")
    token = ListToken([token], 0, 4, "hello")
    token = DictToken({token: token, token: token}, 0, 8, "hello")
    token = DictToken({token: token, token: token}, 0, 10, "hello")
    print("token", repr(token))

# Generated at 2022-06-22 06:36:12.765590
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # The method __repr__ is instance method, should have an instance to call the method.
    # __repr__() takes no arguments.
    # Call __repr__ of class Token.
    token = Token(1, 2, 3)
    assert repr(token) == 'Token(1)'


# Generated at 2022-06-22 06:36:18.942020
# Unit test for constructor of class ListToken
def test_ListToken():
    # First test case
    some_token = ListToken([1, 2, 3], 2, 3)
    assert some_token.value == [1, 2, 3] and some_token.start == 2 and some_token.end == 3


# Generated at 2022-06-22 06:36:21.723709
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = ListToken(["a", ["b"], "c"], 0, 10, content='["a", ["b"], "c"]')
    token2 = token.lookup_key([1,0])
    assert token2.start.index == 6

# Generated at 2022-06-22 06:36:55.224816
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = ScalarToken(12.34, 12, 19)
    equal_token = ScalarToken(12.34, 12, 19)
    assert token == equal_token
    different_value_token = ScalarToken(56.78, 12, 19)
    assert token != different_value_token
    different_start_index_token = ScalarToken(12.34, 13, 19)
    assert token != different_start_index_token
    different_end_index_token = ScalarToken(12.34, 12, 18)
    assert token != different_end_index_token


# Generated at 2022-06-22 06:37:08.094267
# Unit test for method lookup of class Token
def test_Token_lookup():
    class TestToken(Token):
        def __init__(self):
            super().__init__(33, 0, 1, "hello")
        
        def _get_value(self) -> typing.Any:
            return self._value
        
        def _get_child_token(self, key: typing.Any) -> Token:
            return TestToken()
        
        def _get_key_token(self, key: typing.Any) -> Token:
            return TestToken()
    
    token = TestToken()
    assert token.lookup([])._value == 33
    assert token.lookup([0])._value == 33
    assert token.lookup([0, 1])._value == 33
    assert token.lookup_key([0, 1])._value == 33
    assert token.lookup([]) == token
    assert token

# Generated at 2022-06-22 06:37:11.279257
# Unit test for constructor of class ListToken
def test_ListToken():
    t = ListToken([],0,0)
    assert t._value == []

# Generated at 2022-06-22 06:37:15.979085
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Token
    token = Token(value='', start_index=3, end_index=10, content='dasdasd')

    # Token
    token1 = Token(value='', start_index=3, end_index=10, content='dasdasd')

    assert token == token1


# Generated at 2022-06-22 06:37:18.547924
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    t = Token('', 0, 0)
    assert t.__repr__() == "Token('')"


# Generated at 2022-06-22 06:37:19.959886
# Unit test for constructor of class Token
def test_Token():
    token = Token(0, 0, 0)
    assert token

# Generated at 2022-06-22 06:37:22.657126
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = ListToken([2, 3, 4], 0, 0)
    token_key = token.lookup_key([0])
    assert token_key._value == 2


# Generated at 2022-06-22 06:37:34.293477
# Unit test for method lookup of class Token
def test_Token_lookup():
    # DictToken
    assert DictToken(
        {
            ScalarToken(1, 0, 2, "test"): ScalarToken(True, 4, 7, "test"),
            ScalarToken(2, 10, 12, "test"): ScalarToken(False, 14, 18, "test"),
        },
        0,
        25,
        "test",
    )\
        .lookup([
            ScalarToken(1, 0, 2, "test"),
        ])\
        ._get_value() == True
    # ListToken

# Generated at 2022-06-22 06:37:40.893894
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    t = ScalarToken(123, 100, 200)
    assert repr(t) == "ScalarToken('123')"

    t = DictToken({'a': 'b'}, 100, 200)
    assert repr(t) == "DictToken({'a': 'b'})"

    t = ListToken(["hello", "world"], 100, 200)
    assert repr(t) == "ListToken(['hello', 'world'])"


# Generated at 2022-06-22 06:37:46.115092
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    start_index = 0 
    end_index = 1
    content=""
    value=""
    st = ScalarToken(value, start_index, end_index, content)
    assert st._value==""
    assert st._start_index==0
    assert st._end_index==1
    assert st._content==""


# Generated at 2022-06-22 06:38:24.241191
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken(
        {"a":1,"b":2},
        0,
        10,
        content="{'a': 1, 'b': 2}",
    )
    assert dict_token._child_keys == {'a': Token, 'b': Token}
    assert dict_token._child_tokens == {'a': Token, 'b': Token}
    assert dict_token._value == {'a': Token, 'b': Token}
    assert dict_token.string == "{'a': 1, 'b': 2}"
    assert dict_token.value == {'a': 1, 'b': 2}
    assert dict_token.start == Position(1, 13, 10)
    assert dict_token.end == Position(1, 13, 10)

# Generated at 2022-06-22 06:38:31.193786
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Set up variables
    s = ScalarToken(value="", start_index=1, end_index=2, content="ThisIsAContent")

    # Test if the type of the returned value is str
    assert isinstance(s.__repr__(), str) == True
    # Test if the returned value is equal to the expected result
    assert s.__repr__() == "ScalarToken('')"



# Generated at 2022-06-22 06:38:35.658279
# Unit test for constructor of class Token
def test_Token():
    t = Token(value = "Hello World", start_index = 0, end_index = 10, content = "Hello World")
    assert t.string == "Hello World"
    assert t.value == None
    assert t.start == Position(1, len("Hello World"), 10)
    assert t.end == Position(1, len("Hello World"), 10)


# Generated at 2022-06-22 06:38:41.148642
# Unit test for constructor of class Token
def test_Token():
    assert Token("2",0,0,"2")._value == "2"
    assert Token("2",1,2,"2")._start_index == 1
    assert Token("2",0,3,"2")._end_index == 3
    assert Token("2",0,0,"2")._content == "2"

# Generated at 2022-06-22 06:38:52.827682
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Token([], 0, 1) => Token([])
    assert Token([], 0, 1).__repr__() == "Token([])"
    # Token(['item'], 0, 3) => Token(['item'])
    assert Token(['item'], 0, 3).__repr__() == "Token(['item'])"
    # Token(['item', 'item', 'item'], 0, 11) => Token(['item', 'item', 'item'])
    assert Token(['item', 'item', 'item'], 0, 11).__repr__() == "Token(['item', 'item', 'item'])"
    # Token({}, 0, 1) => Token({})
    assert Token({}, 0, 1).__repr__() == "Token({})"
    # Token({'key': 'value'},

# Generated at 2022-06-22 06:38:58.491052
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    a=ScalarToken('item1',0,1)
    assert a.value == 'item1'
    assert a.start == Position(1,2,0)
    assert a.end == Position(1,3,1)
    assert a.string == 'item1'
    assert a.lookup([]) == a
    assert a.lookup_key([]) == a

#Unit test for constructor of class DictToken