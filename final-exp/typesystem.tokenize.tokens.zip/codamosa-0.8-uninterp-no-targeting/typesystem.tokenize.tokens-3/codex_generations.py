

# Generated at 2022-06-22 06:29:07.176076
# Unit test for constructor of class DictToken
def test_DictToken():
    dictToken = DictToken({"test": 1}, 0, 0, "")

# Generated at 2022-06-22 06:29:13.933970
# Unit test for constructor of class Token
def test_Token():
    s = ""
    t = Token(None, 0, 0, s)
    assert t.string == ""
    assert t.value == None
    assert t.start == Position(1, 1, 0)
    assert t.end == Position(1, 1, 0)
    assert t.lookup([]) == None
    assert t.lookup_key([0, 0]) == None
    assert t._get_position(0) == None
    assert str(t) == "Token('')"
    assert t == None


# Generated at 2022-06-22 06:29:19.777069
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Setup
    value = 'value'
    start_index = 0
    end_index = 0
    content = ''
    obj = Token(value, start_index, end_index, content)
    other = ScalarToken('value', 0, 0, '')

    # Act
    result = obj == other

    # Verify
    assert result



# Generated at 2022-06-22 06:29:24.847812
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert repr(ScalarToken(1, 0, 1, "Test")) == "ScalarToken('Test')"
    assert repr(DictToken({}, 0, 1, "dictionaryTest")) == "DictToken('dictionaryTest')"
    assert repr(ListToken([], 0, 1, "listTest")).startswith("ListToken")


# Generated at 2022-06-22 06:29:27.096563
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken('test', 0, 0)
    assert token.__hash__() == hash('test')


# Generated at 2022-06-22 06:29:38.646221
# Unit test for constructor of class ListToken
def test_ListToken():
    def test_ListToken_input(a,b,c,d):
        x = ListToken(a,b,c,d)
        return x

    def expected_result():
        return "ListToken([])"

    assert test_ListToken_input(None,1,2,3) == expected_result()
    assert test_ListToken_input(None,None,None,None) == expected_result()
    assert test_ListToken_input(None) != expected_result()
    assert test_ListToken_input(1,2,3,4) != expected_result()
    assert test_ListToken_input(a=1,b=2,c=3,d=4) != expected_result()
    assert test_ListToken_input(2) != expected_result()

# Generated at 2022-06-22 06:29:42.939186
# Unit test for method lookup of class Token
def test_Token_lookup():
    _s = '''{
        "one": [
            "a",
            "b",
            "c"
        ]
    }'''
    assert Token(_s, 0, 0).lookup([0, 1, 0]).value == "a"

# Generated at 2022-06-22 06:29:48.880184
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    scalar_token = ScalarToken(5, 0, 2)
    assert scalar_token.string == "5"
    assert scalar_token.value == 5
    assert scalar_token.start.line_no == 1
    assert scalar_token.start.column_no == 1
    assert scalar_token.start.index == 0
    assert scalar_token.end.line_no == 1
    assert scalar_token.end.column_no == 2
    assert scalar_token.end.index == 2



# Generated at 2022-06-22 06:30:01.050204
# Unit test for constructor of class ListToken
def test_ListToken():
    test1 = ListToken(value=[ScalarToken(1, 0, 1, "1")], start_index=0, end_index=1, content="1")
    assert test1._value == [ScalarToken(1, 0, 1, "1")]
    assert test1._start_index == 0
    assert test1._end_index == 1
    assert test1._content == "1"
    assert test1.string == "1"
    assert test1.value == [1]
    assert test1.start == Position(1, 1, 0)
    assert test1.end == Position(1, 1, 1)
    assert test1.lookup([0])._value == ScalarToken(1, 0, 1, "1")
    with pytest.raises(NotImplementedError):
        test1.look

# Generated at 2022-06-22 06:30:05.817897
# Unit test for constructor of class ListToken
def test_ListToken():
  """Test method ListToken's constructor."""
  t = ListToken([1,2,3], 0, 3)
  assert t._start_index == 0
  assert t._end_index == 3
  assert t._content == ""
  assert t._value == [1,2,3]
  assert t.value == [1,2,3]

# Generated at 2022-06-22 06:30:16.597469
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # test_case_1
    value = ScalarToken(1, 0, 0)
    start_index = 0
    end_index = 0
    token = ListToken([value], start_index, end_index)
    index = [0]
    assert token.lookup_key(index) == value


# Generated at 2022-06-22 06:30:21.723447
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    content = "foo:\n  bar:\n    baz: null"
    token = Token.lookup_key([0, 1, "baz"])
    assert token._get_value() is None
    assert token._get_position(token._start_index) == Position(3, 7, 16)

# Generated at 2022-06-22 06:30:29.996298
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
  # Test 1 for constructor of ScalarToken
  print("Test 1 for constructor of ScalarToken")
  newToken = ScalarToken(1, 0, 2)
  # Unit test for method string()
  print("Test for method string()")
  assert(newToken.string == "1\n")
  # Unit test for method value()
  print("Test for method value()")
  assert(newToken.value == 1)
  # Unit test for method start()
  print("Test for method start()")
  assert(newToken.start == Position(1, 1, 0))
  # Unit test for method end()
  print("Test for method end()")
  assert(newToken.end == Position(1, 1, 2))
  # Unit test for method lookup()
  print("Test for method lookup()")

# Generated at 2022-06-22 06:30:40.376497
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class DummyToken(Token):
        def _get_value(self) -> typing.Any:
            raise NotImplementedError  # pragma: nocover

        def _get_child_token(self, key: typing.Any) -> Token:
            raise NotImplementedError  # pragma: nocover

        def _get_key_token(self, key: typing.Any) -> Token:
            raise NotImplementedError  # pragma: nocover
    index = [0, 'a']
    key_token1 = DummyToken(0, 0, 0)
    key_token2 = DummyToken('a', 0, 0)
    token1 = DummyToken(key_token1, 0, 0)
    token2 = DummyToken(key_token2, 0, 0)

# Generated at 2022-06-22 06:30:45.898037
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    a = Token('Hello' , 1, 10)
    b = Token('Hello' , 1, 10)
    c = Token('Hello' , 0, 10)
    d = Token('Hello' , 1, 5)
    e = Token('Hello' , 1, 10, 'World')
    assert a == b
    assert not a == c
    assert not a == d
    assert not a == e

# Generated at 2022-06-22 06:30:56.937160
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    t = {"a": 1, "b": 2, "c": 3}
    t = DictToken(t, 0, 9, '{"a":1,"b":2,"c":3}')
    t["a"] = ScalarToken(1, 4, 4, '{"a":1,"b":2,"c":3}')
    t["b"] = ScalarToken(2, 9, 9, '{"a":1,"b":2,"c":3}')
    t["c"] = ScalarToken(3, 14, 14, '{"a":1,"b":2,"c":3}')
    t["a"]._value = t["b"]._value = t["c"]._value = None

# Generated at 2022-06-22 06:31:05.484855
# Unit test for constructor of class DictToken
def test_DictToken():
    inp1 = {'name':'Kevin', 'age':19}
    inp2 = [1,3,4]
    inp3 = 'Kevin'
    assert DictToken(inp1,0,2,inp2) == DictToken(inp1,0,2,inp2)
    assert DictToken(inp1,0,2,inp2) == DictToken(inp1,0,2,inp2)
    assert DictToken(inp1,0,2,inp2) != DictToken(inp1,0,3,inp2)
    assert DictToken(inp1,0,2,inp2) != DictToken(inp1,1,2,inp2)

# Generated at 2022-06-22 06:31:07.958160
# Unit test for constructor of class ListToken
def test_ListToken():
    assert not isinstance(ListToken, Token)
    assert isinstance(ListToken, object)


# Generated at 2022-06-22 06:31:11.755540
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
  val = ''
  idx_start = 0
  idx_end = 1
  t = ScalarToken(val, idx_start, idx_end)
  assert t.__hash__() == hash(val)


# Generated at 2022-06-22 06:31:13.622853
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    t = Token("something", 0, 50)
    assert repr(t) == "Token('something')"



# Generated at 2022-06-22 06:31:25.409720
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(1, 0, 0)
    assert hash(token) == hash(1)


# Generated at 2022-06-22 06:31:35.230176
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token_1 = ScalarToken(value=1, start_index=0, end_index=2)
    token_2 = ScalarToken(value=2, start_index=5, end_index=7)
    token_3 = ScalarToken(value=3, start_index=10, end_index=12)

    # list
    token_list = ListToken(
        value=[token_1, token_2, token_3],
        start_index=0,
        end_index=12,
        content="[1, 2, 3]",
    )
    assert token_list.lookup_key([0]).string == "1"
    assert token_list.lookup_key([1]).string == "2"
    assert token_list.lookup_key([2]).string == "3"

    # dict


# Generated at 2022-06-22 06:31:37.056417
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken('str', 0, 5, content='string')
    assert hash(token) == hash('str')


# Generated at 2022-06-22 06:31:41.566546
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    print("Unit test for class ScalarToken")
    T = ScalarToken(value = 1, start_index = 0, end_index = 1)
    assert repr(T) == "ScalarToken('1')"
    assert T.value == 1
    assert T.start.index == 0
    assert T.end.index == 1
test_ScalarToken()

# Generated at 2022-06-22 06:31:46.127608
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # Setup
    tok = ScalarToken('a', 0, 0, '')

    # Exercise
    output = tok.__hash__()

    # Verify
    assert output == hash(tok._value)


# Generated at 2022-06-22 06:31:54.066396
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # __eq__(self, other: typing.Any) -> bool
    assert Token._get_position(None, None) == Token._get_position(None, None)
    assert not Token._get_position(None, None) == Token._get_position(None, None)
    assert not Token._get_position(None, None) != Token._get_position(None, None)
    pass


# Generated at 2022-06-22 06:32:03.524621
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken(str,0,0,"")
    assert t.__dict__ == {"_value": str, "_start_index": 0, "_end_index": 0, "_content": "", "_child_keys": {"_value": "", "_start_index": 0, "_end_index": 0, "_content": "", "_child_keys": {}, "_child_tokens": {}}, "_child_tokens": {"_value": "", "_start_index": 0, "_end_index": 0, "_content": "", "_child_keys": {}, "_child_tokens": {}}}
    t = DictToken(list,1,1,"")

# Generated at 2022-06-22 06:32:08.229195
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({'key': ScalarToken('value', 1, 5)}, 0, 9)
    # Test getters
    assert token._get_value() == {'key': 'value'}
    assert token._get_child_token('key') == ScalarToken('value', 1, 5)


# Generated at 2022-06-22 06:32:19.113798
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken([0,1,2,3,4], 0, 4)
    assert token._start_index == 0
    assert token._end_index == 4
    assert token.string == '01234'
    assert token.value == [0,1,2,3,4]
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 5, 4)
    assert token.lookup([0]) == 0
    assert repr(token) == 'ListToken([0, 1, 2, 3, 4])'
    assert (ListToken([0,1,2,3,4], 0, 5) == ListToken([0,1,2,3,4], 0, 5)) == False
    assert hash(ListToken([0,1,2,3,4], 0, 5)) == hash

# Generated at 2022-06-22 06:32:21.302840
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    ScalarToken(value='a',start_index='b',end_index='c',content='d')


# Generated at 2022-06-22 06:32:29.623622
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) != 1
    assert Token(1, 2, 3) == Token(1, 2, 3)


# Generated at 2022-06-22 06:32:40.853803
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    list_token = ListToken([1, 2], 0, 3, "[1,2]")
    key_token = list_token.lookup_key([0])
    assert key_token.string == "0"
    assert key_token.start.index == 1
    assert key_token.end.index == 1
    assert key_token.start.line_no == 1
    assert key_token.end.line_no == 1
    assert key_token.start.column_no == 2
    assert key_token.end.column_no == 2

    dict_token = DictToken({"a": list_token}, 0, 10, "{'a':[1,2]}")
    key_token = dict_token.lookup_key([0, 0])
    assert key_token.string == "'a'"
    assert key_token

# Generated at 2022-06-22 06:32:44.981794
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    value = 'test'
    start_index = 0
    end_index = 3
    token = ScalarToken(value, start_index, end_index)
    assert token.string == 'test'


# Generated at 2022-06-22 06:32:48.888335
# Unit test for constructor of class DictToken
def test_DictToken():
    dictToken = DictToken()
    assert dictToken.__class__.__name__ == "DictToken"
    assert dictToken.__hash__ == dictToken.__hash__
    assert dictToken._get_value() == {}


# Generated at 2022-06-22 06:32:57.186265
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    start_index = 0
    end_index = 1
    value = 0
    t = ScalarToken(value, start_index, end_index)
    assert t.string == '0'
    assert t.value == 0
    assert t.start == Position(1, 2, 0)
    assert t.end == Position(1, 2, 1)
    assert repr(t) == 'ScalarToken(0)'
    assert t == ScalarToken(value, start_index, end_index)
    assert t != ScalarToken(1, start_index, end_index)
    assert t != ScalarToken(value, start_index, end_index + 1)
    assert t != 0


# Generated at 2022-06-22 06:33:02.670164
# Unit test for constructor of class Token
def test_Token():
    with pytest.raises(NotImplementedError):
        token = Token('value', 'start_index', 'end_index', 'content')
        token._get_value()


# Generated at 2022-06-22 06:33:05.380753
# Unit test for constructor of class Token
def test_Token():
    s = Token(5,5,5)
    assert (isinstance(s, Token))


# Generated at 2022-06-22 06:33:09.019945
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken(value=None, start_index=1, end_index=2)
    expected = ListToken(value=None, start_index=1, end_index=2)
    assert token == expected

# Generated at 2022-06-22 06:33:13.206591
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    string = "a"
    value = "a"
    start_index = 0
    end_index = 0
    content = "a"
    
    # call the method
    token = ScalarToken(value, start_index, end_index, content)
    token.__hash__()


# Generated at 2022-06-22 06:33:15.537180
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(0, 0, 0)
    assert isinstance(token.__hash__(), int)

# Generated at 2022-06-22 06:33:33.916447
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    t = ScalarToken(1, 0, 0)
    assert t.__hash__() == hash(1)


# Generated at 2022-06-22 06:33:36.087199
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Assert format of __repr__
    assert repr(Token("a", 0, 2, "content")) == "Token('a')"

# Generated at 2022-06-22 06:33:44.734671
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    content = "abc\ndef\nghi"
    token_1 = ScalarToken("abc", 0, 2, content)
    token_2 = ScalarToken("def", 4, 6, content)
    token_3 = ScalarToken("ghi", 8, 10, content)

    token_1_2_3 = ListToken([token_1, token_2, token_3], 0, 10, content)

    token_a = ScalarToken("a", 0, 0, content)
    token_b = ScalarToken("b", 2, 2, content)
    token_c = ScalarToken("c", 4, 4, content)

    token_a_b_c = ListToken([token_a, token_b, token_c], 0, 4, content)

    # Structure:
    # {
    #   "a

# Generated at 2022-06-22 06:33:55.947451
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    from typing import List
    from typesystem.base import BaseType
    from typesystem.schema import Schema

    class TestType(BaseType):
        pass

    class TestSchema(Schema):
        test_type = TestType()

    schema = TestSchema()
    t = Token(
        {
            Token(1, 1, 3): Token(2, 5, 7),
            Token(3, 9, 10): Token(4, 12, 14),
        },
        0,
        20,
    )
    assert repr(t) == "DictToken({1: 2, 3: 4})"
    t = Token([Token(1, 1, 3), Token(2, 5, 7)], 0, 10)
    assert repr(t) == "ListToken([1, 2])"

# Generated at 2022-06-22 06:34:05.674019
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from fstring import fstring
    from json import loads
    from sys import executable
    from unittest import main
    from typesystem import Collection
    from typesystem import Enum
    from typesystem import Integer
    from typesystem import Number
    from typesystem import String
    from typesystem.serializers.json_schema import to_json_schema
    from typesystem.types import Object
    from typesystem.types import Union

    def assert_Tokens_are_equal(Token1: Token, Token2: Token) -> None:
        assert Token1 == Token2, fstring(
            'assert Tokens are equal\n\n{Token1}\n\n{Token2}'
        )

    def assert_Tokens_are_not_equal(Token1: Token, Token2: Token) -> None:
        assert Token1 != Token2, f

# Generated at 2022-06-22 06:34:08.234617
# Unit test for constructor of class DictToken
def test_DictToken():
    instance = DictToken('a', 0, 1)
    assert instance.start == Position(1, 1, 0)
    assert instance.end == Position(1, 1, 1)
    assert instance._content == "a"


# Generated at 2022-06-22 06:34:11.084389
# Unit test for constructor of class DictToken
def test_DictToken():
    print(DictToken.__init__.__doc__)
    print(DictToken.__init__.__annotations__)

# Generated at 2022-06-22 06:34:15.997011
# Unit test for constructor of class Token
def test_Token():
  newToken = Token(1, 0, 10, "This is the content")
  assert newToken._value == 1
  assert newToken._start_index == 0
  assert newToken._end_index == 10
  assert newToken._content == "This is the content"


# Generated at 2022-06-22 06:34:20.083456
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert hash(ScalarToken(1,0,0)) == 1
    assert hash(ScalarToken("a",0,0)) == hash("a")
    assert hash(ScalarToken(1.0,0,0)) == hash(1.0)


# Generated at 2022-06-22 06:34:27.943292
# Unit test for method lookup of class Token
def test_Token_lookup():
    test_case = ListToken(
        value=[ScalarToken(value=1, start_index=1, end_index=1)],
        start_index=0,
        end_index=1,
        content='[1]',
    )
    test_result = test_case.lookup([0])
    assert test_result == ScalarToken(
        value=1, start_index=1, end_index=1
    ), 'Test that child token can be retrived by giving an index'


# Generated at 2022-06-22 06:34:41.944388
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # No test for abstract class
    pass


# Generated at 2022-06-22 06:34:42.750104
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    assert True == False

# Generated at 2022-06-22 06:34:48.944154
# Unit test for constructor of class Token
def test_Token():
    assert Token(10, 1, 4).__eq__(Token(10, 1, 4)) == True
    assert Token(10, 2, 6) == Token(5, 2, 6) == True
    assert Token(10, 3, 6, "Hello world!") == Token(5, 2, 6, "Hello world!") == True
    assert Token(10, 3, 6, "Hello world!") != Token(5, 2, 6, "Hello world!") == False


# Generated at 2022-06-22 06:34:59.645264
# Unit test for method lookup of class Token
def test_Token_lookup():
    # Create a list of dictionaries
    data = [
        {
            "name": "Parsa",
            "animal": "cat",
            "age": 4.5,
        },
        {
            "name": "Olesya",
            "animal": "dog",
            "age": 14,
        },
    ]

    # Create an instance of ListToken with value converted to list of dicts
    tok = ListToken(
        value=data, start_index=0, end_index=len(str(data))
    )

    # Create a list of indices that corresponds to a key in a dict
    index = [0, "animal"]

    # Test lookup in class Token
    assert tok.lookup(index).string == "cat"

# Generated at 2022-06-22 06:35:03.891208
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    a = ScalarToken(7, 0, 2, '7 ')
    b = ScalarToken(7, 0, 2, '7 ')
    assert a==b, 'Test failed'

# Generated at 2022-06-22 06:35:05.291407
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert repr(Token(None, 0, 0, "")) == "Token('None')"


# Generated at 2022-06-22 06:35:07.735728
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert ScalarToken(value="foo", start_index=0, end_index=2).__hash__() == hash("foo")


# Generated at 2022-06-22 06:35:10.168815
# Unit test for constructor of class DictToken
def test_DictToken():
    s = DictToken()
    for arg in s._value:
        assert isinstance(arg, Token)


# Generated at 2022-06-22 06:35:17.131847
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    from typesystem.parser import ScalarToken
    token = ScalarToken(
        "abc", start_index=0, end_index=2, content="abc"
    )
    assert token.string == "abc"
    assert token.value == "abc"
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 4, 2)



# Generated at 2022-06-22 06:35:29.312566
# Unit test for constructor of class Token
def test_Token():
    # test constructor
    token = Token("1", 1, 2)
    assert token.string == "1"
    assert token.value == "1"
    assert token.start == Position(1, 2, 1)
    assert token.end == Position(1, 2, 2)
    # test lookup
    token = DictToken({ScalarToken("a", 1, 2): ScalarToken("1", 3, 4)}, 1, 4)
    assert token.value == {"a": "1"}
    assert token.lookup(["a"]).value == "1"
    # test repr
    assert repr(token) == "DictToken({'a': '1'})"
    assert repr(ScalarToken("1", 1, 2)) == "ScalarToken('1')"
    # test eq
    assert token == token


# Generated at 2022-06-22 06:36:00.408668
# Unit test for constructor of class ScalarToken
def test_ScalarToken():

    token = ScalarToken('1',0,1)
    return token

if __name__ == "__main__":
    test_ScalarToken()
    print('pass')

# Generated at 2022-06-22 06:36:01.897958
# Unit test for method lookup of class Token
def test_Token_lookup():
    t = Token("",0,0)
    t.lookup("")
    return True

# Generated at 2022-06-22 06:36:02.977693
# Unit test for constructor of class Token
def test_Token():
    assert Token(1, 2, 3)



# Generated at 2022-06-22 06:36:14.629924
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token(value = 42, start_index = 0, end_index = 0, content = "")
    assert type(token.lookup(index = [0])) is ScalarToken
    assert token.lookup(index = [0]) == token
    token = Token(value = [42], start_index = 0, end_index = 0, content = "")
    assert type(token.lookup(index = [0])) is ScalarToken
    assert token.lookup(index = [0]).string == "42"
    assert token.lookup(index = [0]) != token
    token = Token(value = {42: True}, start_index = 0, end_index = 0, content = "")
    assert type(token.lookup(index = [0])) is ScalarToken

# Generated at 2022-06-22 06:36:23.951639
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    t = Token(['a', 'b', 'c'], 0, 3)
    # test tuple accessing
    assert t.lookup_key((1,)) == t.lookup((1,))

    t = Token([['a', 'b'], ['c', 'd']], 0, 7)
    assert t.lookup_key((0, 1,)) == t.lookup((0, 1,))
    assert t.lookup_key((1, 0,)) == t.lookup((1, 0,))

    t = Token([[['a', 'b'], ['c', 'd']], [['e', 'f'], ['g', 'h']]], 0, 15)
    assert t.lookup_key((0, 1,)) == t.lookup((0, 1,))
    assert t.lookup_key

# Generated at 2022-06-22 06:36:34.597439
# Unit test for method lookup of class Token
def test_Token_lookup():
    s = '{"a": 1, "b": [1, "a", 2]}'
    print(s)

# Generated at 2022-06-22 06:36:44.942346
# Unit test for method lookup of class Token
def test_Token_lookup():
    assert Token(5, 2, 4).lookup([0])==5
    assert Token([5,6], 2, 4).lookup([0])==5
    assert Token([5,6], 2, 4).lookup([1])==6
    assert Token([5,[6,7]], 2, 4).lookup([1])==[6,7]
    assert Token({5:5,6:6}, 2, 4).lookup([1])==6
    assert Token({5:5,6:6}, 2, 4).lookup([0,1])==5
    assert Token(6, 2, 4).lookup([0])==6
    assert Token(["a","b"],2,4).lookup([1])=="b"



# Generated at 2022-06-22 06:36:48.569778
# Unit test for constructor of class Token
def test_Token():
    token = Token(1,2,3,4)
    assert(token._value == 1)
    assert(token._start_index == 2)
    assert(token._end_index == 3)
    assert(token._content == 4)


# Generated at 2022-06-22 06:37:00.019118
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.base import INFINITY
    from typesystem.base import Position
    from typesystem.base import Undefined
    from typesystem.base import UndefinedType
    from typesystem.base import UndefinedValue
    assert Token(UndefinedType(), Position(1, 1, 0), Position(1, 1, 0)) == Token(UndefinedType(), Position(1, 1, 0), Position(1, 1, 0))
    assert Token(UndefinedValue(), Position(1, 1, 0), Position(1, 1, 0)) == Token(UndefinedValue(), Position(1, 1, 0), Position(1, 1, 0))
    assert Token(Undefined(), Position(1, 1, 0), Position(1, 1, 0)) == Token(Undefined(), Position(1, 1, 0), Position(1, 1, 0))

# Generated at 2022-06-22 06:37:10.688824
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from io import StringIO
    from typesystem.parser import parse

    content = """
    {
        "a": {},
        "b": true,
        "c": [1, 2],
        "d": 3,
        "e": [
            {"a": 4},
            {"b": 5},
            1
        ]
    }
    """
    stream = StringIO(content)
    tokens = parse(stream, schema={}, path="")
    assert tokens == {
        "a": {},
        "b": True,
        "c": [1, 2],
        "d": 3,
        "e": [
            {"a": 4},
            {"b": 5},
            1,
        ]
    }
    assert tokens.lookup_key(["e", 1, "b"]) == 5
   