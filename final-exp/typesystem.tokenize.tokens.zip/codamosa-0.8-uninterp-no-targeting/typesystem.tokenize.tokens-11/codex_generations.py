

# Generated at 2022-06-22 06:29:02.909167
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = DictToken({'a': 1}, 0, 4, '{"a": 1}')

    assert token.lookup_key([0, 'a']).value is 1

# Generated at 2022-06-22 06:29:08.915342
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken(1,2,3,4,5,6,7,8,9)
    assert dict_token.string == ''
    assert dict_token.value == 1
    assert dict_token.start == Position(0,0,0)
    assert dict_token.end == Position(0,0,0)
    assert dict_token.lookup([]) == dict_token


# Generated at 2022-06-22 06:29:14.715222
# Unit test for constructor of class Token
def test_Token():
    global_start_index = 0
    global_end_index = 4
    global_content = ""
    global_value = 31
    token = Token(global_value, global_start_index, global_end_index, content=global_content)
    assert token._value == global_value
    assert token._start_index == 0
    assert token._end_index == 4
    assert token._content == global_content



# Generated at 2022-06-22 06:29:25.774785
# Unit test for method lookup of class Token
def test_Token_lookup():
    # Test case 1
    # Create a Token
    token1 = Token("a", 0, 0)
    # Test if the token is an instance of Token
    assert isinstance(token1, Token)
    # Test if the token of Token is successfully created.
    assert token1._get_value() == "a"
    assert token1._start_index == 0
    assert token1._end_index == 0

    # Test if the lookup function works correctly.
    # Test case 2
    # Test if the lookup function can return a token for a value which is a scalar.
    # Create a Value.
    class Value():
        def __init__(self, value: typing.Any = None) -> None:
            # The value of the value.
            self._value = value

# Generated at 2022-06-22 06:29:33.038806
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("abc", 0, 2)
    assert token.string == "abc"
    assert token.value == "abc"
    assert token.start.line_no == 1
    assert token.start.column_no == 1
    assert token.start.index == 0
    assert token.end.line_no == 1
    assert token.end.column_no == 4
    assert token.end.index == 2



# Generated at 2022-06-22 06:29:37.312207
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    value = 'hello'
    start_index = 1
    end_index = 5
    content = ''
    token1 = ScalarToken(value, start_index, end_index, content)
    test_result = isinstance(token1, Token)
    assert test_result == True


# Generated at 2022-06-22 06:29:47.934557
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    assert Token._get_position(0) == Position(1, 1, 0)
    assert Token._get_position(4) == Position(1, 5, 4)
    assert Token._get_position(5) == Position(2, 1, 5)
    assert Token._get_position(12) == Position(2, 8, 12)
    assert Token._get_position(13) == Position(3, 1, 13)
    assert Token._get_position(21) == Position(3, 9, 21)
    assert Token._get_position(22) == Position(4, 1, 22)
    assert Token._get_position(32) == Position(4, 11, 32)

    content = "one\ntwo\nthree\nfour\nfive\n"

    token = Token("test", 0, 3, content=content)

# Generated at 2022-06-22 06:29:51.987056
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken([1,2,3], 0, 5, "a b c")
    assert token._value == [1,2,3]
    assert token._start_index == 0
    assert token._end_index == 5
    assert token._content == "a b c"


# Generated at 2022-06-22 06:30:03.704784
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
	t1 = ScalarToken(1, 2, 3, 4)
	
	#check start, end and content
	assert t1.start == Position(1, 1, 2)
	assert t1.end == Position(1, 1, 3)
	assert t1.string == ''
	#check value
	assert t1._get_value() == 1
	
	#check repr
	assert t1.__repr__() == 'ScalarToken(1)'
	
	#check eq
	assert (t1 == ScalarToken(1, 2, 3, 4)) == True
	assert (t1 == ScalarToken(1, 2, 4, 4)) == False
	assert (t1 == ScalarToken(2, 2, 3, 4)) == False


# Generated at 2022-06-22 06:30:11.962877
# Unit test for constructor of class ListToken
def test_ListToken():
    
    def assert_conditions(token):
        assert isinstance(token,ListToken)
        assert token._value == ['one','two','three']
        assert token._start_index == 0
        assert token._end_index == 8
        assert token._content == ''
    
    def test():
        try:
            token = ListToken(['one','two','three'], 0, 8)
            assert_conditions(token)
        except:
            raise
        else:
            print(f'Test passed')
    test()



# Generated at 2022-06-22 06:30:19.391528
# Unit test for constructor of class ListToken
def test_ListToken():
    test_token = ListToken([1,2,3], 1, 2, "abc")
    assert test_token._get_value() == [1, 2, 3]
    assert test_token._get_child_token(1) == 2

# Generated at 2022-06-22 06:30:21.933584
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(value=None, start_index=0, end_index=0, content="")
    assert hash(token) == hash(token._value)


# Generated at 2022-06-22 06:30:26.404361
# Unit test for constructor of class ListToken
def test_ListToken():
    """
    Create a ListToken with a list of values
    """
    token = ListToken([1, 2, 3])
    assert token.value == [1, 2, 3]


if __name__ == '__main__':
    test_ListToken()

# Generated at 2022-06-22 06:30:37.249870
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    this_dict_token = {'key_token': 'value_token'}
    this_list_token = ['value_token']
    this_token = {'key_token': this_dict_token, 'list_token': this_list_token}
    this_token_index = {'index_token': this_dict_token}

    assert_equals(this_token.lookup_key(this_list_token), 'value_token')
    assert_equals(this_token.lookup_key(this_dict_token), 'key_token')
    assert_equals(this_token_index.lookup_key(this_list_token), 'value_token')
    assert_equals(this_token_index.lookup_key(this_dict_token), 'index_token')

# Generated at 2022-06-22 06:30:45.495949
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert (
        Token(
            1, 0, 3, "foo"
        ) == Token(1, 0, 3, "foo")
    ), "__eq__ 1"
    assert (
        Token(
            1, 0, 3, "foo"
        ) != Token(1, 0, 4, "foo")
    ), "__eq__ 2"
    assert (
        Token(
            1, 0, 3, "foo"
        ) != Token(2, 0, 3, "foo")
    ), "__eq__ 3"

# Generated at 2022-06-22 06:30:55.690221
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class DictToken(Token):
        def _get_value(self):
            return {"a": "b"}

        def _get_child_token(self, key):
            return Token("d", 0, 0)

        def _get_key_token(self, key):
            return Token("e", 0, 0)

    class ListToken(Token):
        def _get_value(self):
            return [Token("c", 0, 0)]

        def _get_child_token(self, key):
            return Token("f", 0, 0)

    t = ListToken(0, 0, 0, content="a")
    t1 = t.lookup_key([0])
    assert t1._get_value() == 0

# Generated at 2022-06-22 06:31:00.950107
# Unit test for constructor of class DictToken
def test_DictToken():
    content = "[1,2]"
    start_index = 0
    end_index = len(content) - 1
    token = DictToken({}, start_index, end_index, content)
    assert token is not None
    assert token.string == "[1,2]"
    assert token.value == {}
    assert token.start is not None
    assert token.end is not None

# Generated at 2022-06-22 06:31:04.615172
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken("test_value", 0, 10)
    check_hash = hash(token)
    correct_hash = hash("test_value")
    assert check_hash is correct_hash

# Generated at 2022-06-22 06:31:07.375207
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_instance = Token(None,1,1)
    result = token_instance == 1

    assert(result == False)


# Generated at 2022-06-22 06:31:13.103698
# Unit test for constructor of class Token
def test_Token():
    from typesystem.ast import Number
    value = Number(5)
    start_index = 2
    end_index = 5
    token = Token(value, start_index, end_index)
    assert token.value == 5
    assert token.start.line == token.start.column == 1
    assert token.end.line == token.end.column == 6
    

# Generated at 2022-06-22 06:31:21.639935
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token(0, 0, 0, "hello,world")
    assert token.__repr__() == "Token('hello,world')"
    assert str(token) == "Token('hello,world')"



# Generated at 2022-06-22 06:31:29.073616
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken([0, 1, 2], start_index=0, end_index=2, content="[0, 1, 2]")
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 5, 2)
    assert token.string == "[0, 1, 2]"
    assert token.value == [0, 1, 2]


# Generated at 2022-06-22 06:31:34.665587
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_o = ScalarToken(
        value="1", start_index=0, end_index=1, content="1",
    )
    token_f = ScalarToken(
        value="1", start_index=0, end_index=1, content="1",
    )
    assert token_o.__eq__(token_f)

# Generated at 2022-06-22 06:31:44.336345
# Unit test for method lookup of class Token
def test_Token_lookup():
    a = ListToken(value=[1, 2, 3], start_index=0, end_index=6, content="[1, 2, 3]")
    assert(a.lookup([0]).value == 1)
    assert(a.lookup([1]).value == 2)

    b = DictToken(value={}, start_index=0, end_index=0, content="{}")
    assert(b.lookup([0]).value == {})

    c = DictToken(value={"a": 1, "b": 2}, start_index=0, end_index=10, content="{'a': 1, 'b': 2}")    
    assert(c.lookup([0]).value == {"a": 1, "b": 2})

# Generated at 2022-06-22 06:31:49.942060
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # x = Token(1, 2, 3, 'abc')
    x = Token(value=1, start_index=2, end_index=3, content='abc')
    assert x.__repr__() == "Token('b')"



# Generated at 2022-06-22 06:31:56.302842
# Unit test for constructor of class ListToken
def test_ListToken():
    lt = ListToken([1,2,3], 0 ,4, 'ts[1,2,3]')
    value = []
    for token in lt._value:
        value.append(token._get_value())
    assert lt._get_value() == value
    token = lt._get_child_token(1)
    assert token._get_value() == 2


# Generated at 2022-06-22 06:32:01.260042
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    content = '{"a":1,"b":[1,2],"c":{"c1":"v1"}}'
    token = ScalarToken(
        value=None, start_index=0, end_index=0, content=None
    )


# Generated at 2022-06-22 06:32:04.337757
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    num = ScalarToken(100, 6, 8, "100L")
    assert hash(num) == hash(100)


# Generated at 2022-06-22 06:32:09.225649
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    x = ScalarToken(
        value=1, start_index=0, end_index=0, content="hello world"
    )
    # print(x)
    assert type(x) is ScalarToken
    assert x.start.line == 1
    assert x.start.column == 1
    assert x.start.offset == 0
    

# Generated at 2022-06-22 06:32:12.703622
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_ = Token(value = typing.Any, start_index = int, end_index = int, content = str)
    assert token_ == token_


# Generated at 2022-06-22 06:32:33.762909
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    t = ScalarToken(12, 2, 1, "Hello World!")
    assert repr(t) == "ScalarToken('ld')"
    t = DictToken({1: 2}, 0, 2, "Hello World!")
    assert repr(t) == "DictToken('lo World!')"
    t = ListToken([1, 2, 3], 0, 2, "Hello World!")
    assert repr(t) == "ListToken('lo World!')"


# Generated at 2022-06-22 06:32:38.482197
# Unit test for constructor of class Token
def test_Token():
    token = Token('value', 0, 0, 'content')
    assert isinstance(token, Token)
    assert token.string == ''
    assert token.value == 'value'
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)


# Generated at 2022-06-22 06:32:44.533473
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token_1 = ListToken(
        [1, 2, 3], start_index=0, end_index=8, content="[1, 2, 3]\n"
    )
    assert token_1.lookup_key([0]) == ScalarToken(1, start_index=1, end_index=1, content="1\n")


# Generated at 2022-06-22 06:32:49.801858
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken(["hello", "world"], 0, 11, "hello world")
    assert token._value == ["hello", "world"]
    assert token._start_index == 0
    assert token._end_index == 11
    assert token._content == "hello world"
    assert token._get_value() == ["hello", "world"]

# Generated at 2022-06-22 06:32:59.050383
# Unit test for constructor of class Token
def test_Token():
    t = Token(5, 0, 2, 'abc')
    assert t.string == 'abc'
    assert t._get_value() == 5
    assert t._get_position(0) == Position(1, 1, 0)
    assert t._get_position(1) == Position(1, 2, 1)
    assert t._get_position(2) == Position(1, 3, 2)
    assert t.start == Position(1, 1, 0)
    assert t.end == Position(1, 3, 2)
    assert t == Token(5, 0, 2, 'abc')


# Generated at 2022-06-22 06:33:02.266135
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    Token("a",0,0) == Token("b",0,0)


# Generated at 2022-06-22 06:33:06.250334
# Unit test for constructor of class Token
def test_Token():
    token = Token(1,1,1)
    assert token._value == 1
    assert token._start_index == 1
    assert token._end_index == 1
    return token


# Generated at 2022-06-22 06:33:16.482766
# Unit test for constructor of class ListToken
def test_ListToken():
    from typesystem.errors import Error

    # Setup
    refJsonData = [1,2,3]
    errorToken = Error(
        message="Error message.",
        pointer=(0,),
        start=Position(line=1, column=1, character=0),
        end=Position(line=1, column=5, character=4),
    )

# Generated at 2022-06-22 06:33:20.398537
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("value", 1, 2, "content")
    assert token._value == "value"
    assert token._start_index == 1
    assert token._end_index == 2
    assert token._content == "content"
test_ScalarToken()


# Generated at 2022-06-22 06:33:23.992785
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    class_ = ScalarToken
    token = ScalarToken("test", 0, 0)
    hash_ = token.__hash__()
    assert hash_ == hash(token)


# Generated at 2022-06-22 06:33:31.298058
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken(value = {}, start_index = 12, end_index = 21,
                     content = 'content of dict')

# unit test for constructor of class ListToken

# Generated at 2022-06-22 06:33:35.269206
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token(1, 1, 1, content='abcd')
    assert token.lookup(1) == 'a'
    assert token.lookup([1]) == 'a'
    assert token.lookup([1, 2]) == 'b'

# Generated at 2022-06-22 06:33:42.412340
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    input_var = "123"
    input_var_1 = 0
    input_var_2 = 1
    input_var_3 = 1
    input_var_4 = "123"
    class_name = "ScalarToken"

    instance_obj = ScalarToken(input_var, input_var_1, input_var_2, input_var_3, input_var_4)
    assert getattr(instance_obj, "_value") == input_var
    assert getattr(instance_obj, "_start_index") == input_var_1
    assert getattr(instance_obj, "_end_index") == input_var_2
    assert getattr(instance_obj, "_content") == input_var_3
    assert getattr(instance_obj, "_get_value")() == input_var_4

# Generated at 2022-06-22 06:33:48.428794
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("123",1,2)
    assert token.value == "123"
    assert token.start == Position(1,1,1)
    assert token.end == Position(1,2,2)
    assert token.string == "1"
    assert token.lookup([1]) == None
    assert token.lookup_key([1]) == None
    assert token.__repr__() == "ScalarToken('1')"
    assert token.__eq__(ScalarToken("123",1,2)) == True
    assert hash(token) == hash("123")


# Generated at 2022-06-22 06:33:51.325911
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    t = DictToken({}, 0, 3)
    t._value={ScalarToken(1, 0, 0): DictToken({}, 1, 3), ScalarToken(2, 3, 3): DictToken({}, 4, 2)}
    index=[0, 1]
    assert t.lookup_key(index)==ScalarToken(1, 0, 0)

# Generated at 2022-06-22 06:33:59.783699
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken([1,2], 0, 4, "12345")
    assert token.string == "12345"
    assert repr(token) == 'ListToken([1, 2])'
    assert token.value == [1,2]
    assert token.start == Position(1,1,0)
    assert token.end == Position(1,5,4)
    assert token._get_child_token(0) == 1
    assert token._get_child_token(1) == 2

# Generated at 2022-06-22 06:34:04.587941
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    s = ScalarToken(1, 1, 2)
    assert s.value == 1
    assert s.string == "1"
    assert s.start == (1, 1, 1)
    assert s.end == (1, 2, 2)
    

# Generated at 2022-06-22 06:34:05.982456
# Unit test for constructor of class DictToken
def test_DictToken():
    test_DictToken = DictToken({}, 1, 2)


# Generated at 2022-06-22 06:34:09.772605
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.utils import get_context

    validator = Token(['a'], 0, 0, content=None)
    context = get_context([1, 2, 3], 'data')
    assert validator.lookup(context.index) == validator.lookup(context.index)

# Generated at 2022-06-22 06:34:12.015802
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(None, 0, 0)
    token2 = Token(None, 0, 0)
    assert token1 == token2



# Generated at 2022-06-22 06:34:21.990078
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    import json
    v1 = Token(value=None, start_index=0, end_index=0, content=None)
    assert v1.__eq__(v1) == True
    assert v1.__eq__(None) == False
    v1_json = json.dumps(v1)
    v2 = json.loads(v1_json)
    assert v1.__eq__(v2) == True
    assert v2.__eq__(v1) == True
test_Token___eq__()

# Generated at 2022-06-22 06:34:25.406905
# Unit test for constructor of class ListToken
def test_ListToken():
    lt = ListToken([1,2,3],start_index=0,end_index=0,content="abc")
    print(lt)
    #print(lt._get_value())
    print(lt.lookup([0]))
    print(lt.lookup_key([0]))

# Generated at 2022-06-22 06:34:36.488859
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 1, 2) == Token(1, 1, 2)
    assert not Token(1, 1, 2) == Token(2, 1, 2)
    assert not Token(1, 1, 2) == Token(1, 2, 2)
    assert not Token(1, 1, 2) == Token(1, 1, 3)
    assert not Token(1, 1, 2) == Token(2, 1, 3)
    assert not Token(1, 1, 2) == ScalarToken(1, 1, 2)
    assert not Token(1, 1, 2) == DictToken({}, 1, 2)
    assert not Token(1, 1, 2) == ListToken([], 1, 2)
    assert not Token(1, 1, 2) == "1"


# Generated at 2022-06-22 06:34:43.451354
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.validators import String

    validator = String()

    from typesystem.parser import Parser

    parser = Parser(validator)

    content = "1"
    tokens = parser.parse(content)
    token = tokens[0]

    assert token == token

    content = "1"
    tokens = parser.parse(content)
    token1 = tokens[0]
    token2 = tokens[0]

    assert token1 == token2



# Generated at 2022-06-22 06:34:44.983198
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken([1,2,3])
    assert token.value == [1,2,3]



# Generated at 2022-06-22 06:34:51.860182
# Unit test for constructor of class Token
def test_Token():
    obj = Token(1,2,3,content = "content")
    assert obj.string == "content"
    assert obj.value == None
    assert obj.start == Position(line_no = None,column_no = None,index = 2)
    assert obj.end == Position(line_no = None,column_no = None,index = 3)
    assert obj.lookup(index = []) == None
    assert obj.lookup_key(index = []) == None
    assert obj.__repr__() == "Token(content)"
#test_Token()


# Generated at 2022-06-22 06:35:03.707372
# Unit test for constructor of class ListToken
def test_ListToken():
    print("Unit test for constructor of class ListToken")
    list1 = [1, 2, 3, 4]
    assert list1 == [1, 2, 3, 4]
    assert [1, 2, 3, 4] == [1, 2, 3, 4]
    assert list1[0] == 1
    token = ListToken(list1, 0, 4)
    assert token == token  # Call __eq__
    assert token._get_value() == list1
    assert token.lookup(1) == token
    assert token.lookup_key(1).start == token.start
    assert token._get_child_token(0) == token
    assert token._get_key_token(0).end == token.end
    assert token.string == "[1, 2, 3, 4]"


# Generated at 2022-06-22 06:35:11.638839
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    b1 = ScalarToken(value = 5, start_index = 0, end_index = 0, content = "")
    b2 = ScalarToken(value = 5, start_index = 0, end_index = 0, content = "")
    b3 = ScalarToken(value = 6, start_index = 0, end_index = 0, content = "")
    # check that atomic tokens are equal iff their values are equal
    assert b1 == b2
    assert b1 != b3
    assert b2 == b3


# Generated at 2022-06-22 06:35:16.132785
# Unit test for constructor of class ListToken
def test_ListToken():
    start_index = 0
    end_index = 0
    content = ""
    value = []
    token = ListToken(value, start_index, end_index, content)
    assert token.string == ""
    assert token.value == []
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)


# Generated at 2022-06-22 06:35:27.033619
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    print('test_ScalarToken___hash__')
    token_0 = ScalarToken(
        value=1, start_index=0, end_index=0, content="content_0"
    )
    try:
        assert hash(token_0) == hash(1)
    except AssertionError as e:
        # Unit test for method __eq__ of class ScalarToken
        print('test_ScalarToken___eq__')
        assert token_0 == ScalarToken(
            value=1, start_index=0, end_index=0, content="content_0"
        )
        assert token_0 != ScalarToken(
            value=2, start_index=0, end_index=0, content="content_0"
        )

# Generated at 2022-06-22 06:35:34.009065
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token("", 0 , 0)
    token.lookup


# Generated at 2022-06-22 06:35:45.424866
# Unit test for constructor of class Token
def test_Token():
    tok = Token(0, 0, 0)
    assert tok._value == 0
    assert tok._start_index == 0
    assert tok._end_index == 0
    assert tok._content == ""
    assert tok.value == 0
    assert tok.string == ""
    assert tok.start.line == 1
    assert tok.start.column == 1
    assert tok.start.index == 0
    assert tok.end.line == 1
    assert tok.end.column == 1
    assert tok.end.index == 0
    try:
        tok.lookup("")
    except Exception as e:
        assert isinstance(e, NotImplementedError)

# Generated at 2022-06-22 06:35:54.736331
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test case for a scalar token
    token1 = ScalarToken(value=123, start_index=0, end_index=3)
    assert (token1 == ScalarToken(value=123, start_index=0, end_index=3)) is True
    assert (token1 == ScalarToken(value=123, start_index=0, end_index=4)) is False
    assert (token1 == ScalarToken(value=456, start_index=0, end_index=3)) is False
    token2 = ScalarToken(value=123, start_index=0, end_index=3, content="123a")
    assert (token2 == ScalarToken(value=123, start_index=0, end_index=3, content="123a")) is True

# Generated at 2022-06-22 06:35:59.858256
# Unit test for constructor of class ListToken
def test_ListToken():
    value = [1,2,3]
    start_index = 1
    end_index = 100
    content = "hello, world!"
    l = ListToken(value, start_index, end_index, content)
    assert l._value == value
    assert l._start_index == start_index
    assert l._end_index == end_index
    assert l._content == content



# Generated at 2022-06-22 06:36:02.253449
# Unit test for constructor of class Token
def test_Token():
    t = Token(1, 2, 3)
    assert t._value == 1
    assert t._start_index == 2
    assert t._end_index == 3
    assert t._content == ""

# Generated at 2022-06-22 06:36:06.194756
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken('dict', 0, 4, {'key':'value'})
    assert t.string == 'dict'
    assert t.value == {'key': 'value'}
    assert t.start == Position(1, 1, 0)
    assert t.end == Position(1, 5, 4)

# Generated at 2022-06-22 06:36:06.937480
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    pass



# Generated at 2022-06-22 06:36:17.966947
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from typesystem.parser import tokenize
    from typesystem.compiler import compile_type
    from typesystem.json import JSONSchema

    schema = JSONSchema(
        {
            "type": "object",
            "properties": {
                "a": {"type": "integer"},
                "b": {
                    "type": "object",
                    "properties": {
                        "c": {"type": "integer"},
                        "d": {
                            "type": "object",
                            "properties": {"e": {"type": "integer"}},
                        },
                    },
                },
            },
        }
    )
    node = compile_type(schema)
    token = tokenize(data_to_parse)
    lookup = token.lookup_key([0, 1, 1, 0])


# Generated at 2022-06-22 06:36:20.460293
# Unit test for constructor of class ListToken
def test_ListToken():
  ListToken(["c","acc"], 5, 10)
  ListToken(["c","acc"], 0, 5)
  ListToken(["c","acc"], 10, 20)


# Generated at 2022-06-22 06:36:27.468114
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken([1,2,3],0,0,'')
    assert token.value == [1,2,3]
    assert token.start.column == 1
    assert token.start.index == 1
    assert token.end.column == 1
    assert token.end.index == 1
    assert token.string == ''
    assert token.lookup([0]) == 1
    assert token.lookup_key([0]) == 1

# Generated at 2022-06-22 06:36:38.434456
# Unit test for constructor of class ListToken
def test_ListToken():
    content = "list"
    start_index = 0
    end_index = 0
    value = []
    token = ListToken(content, start_index, end_index, value)
    assert (token._content == content)
    assert (token._value == value)
    assert (token._start_index == start_index)
    assert (token._end_index == end_index)


# Generated at 2022-06-22 06:36:43.219660
# Unit test for constructor of class ListToken
def test_ListToken():
    value = [1, 2, 3, 4]
    start_index = 1
    end_index = 4
    content = "something"
    token = ListToken(value, start_index, end_index, content)
    assert token._value == value
    assert token._start_index == start_index
    assert token._end_index == end_index


# Generated at 2022-06-22 06:36:53.849722
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test scalar value
    token1 = ScalarToken(1, 0, 5, content="Hello")
    token2 = ScalarToken(2, 6, 10, content="World")
    assert(token1 != token2)

    # Test dict value
    dict1 = DictToken(
        dict(a=ScalarToken(1, 0, 5, content="Hello"),), 0, 15, content="dict(a=Hello)"
    )
    dict2 = DictToken(
        dict(a=ScalarToken(1, 0, 5, content="Hello"),), 0, 15, content="dict(a=Hello)"
    )
    assert(dict1 == dict2)

    # Test list value

# Generated at 2022-06-22 06:36:58.456699
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 1, 3) == Token(1, 1, 3)
    assert not (Token(1, 1, 4) == Token(1, 1, 3))  # pragma: nocover


# Generated at 2022-06-22 06:37:05.659048
# Unit test for constructor of class Token
def test_Token():
    start_index = 0
    end_index = 10
    value = 5
    token = Token(
        value, start_index, end_index,
    )
    # Test attributes
    assert isinstance(token, Token)
    assert token.value == value
    assert token.start_index == start_index
    assert token.end_index == end_index
    assert token.string



# Generated at 2022-06-22 06:37:09.125621
# Unit test for constructor of class Token
def test_Token():
    test_token = Token("value", 1, 2, "content")
    assert test_token._value == "value"
    assert test_token._start_index == 1
    assert test_token._end_index == 2
    assert test_token._content == "content"



# Generated at 2022-06-22 06:37:19.949259
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from collections import OrderedDict

    class TestListToken(ListToken):
        pass

    class TestDictToken(DictToken):
        pass

    class TestScalarToken(ScalarToken):
        pass


# Generated at 2022-06-22 06:37:29.687742
# Unit test for constructor of class Token
def test_Token():
    # Case: Standard
    token1 = Token(1, 0, 0)

    # Case: Assertion
    try:
        # noinspection PyTypeChecker
        wrong_token1 = Token("a", "b", "c")
        return False
    except TypeError:
        pass

    try:
        # noinspection PyTypeChecker
        wrong_token2 = Token("a", 1, "c")
        return False
    except TypeError:
        pass

    try:
        # noinspection PyTypeChecker
        wrong_token3 = Token("a", 1, 1)
        return False
    except TypeError:
        pass

    return True


# Generated at 2022-06-22 06:37:37.263187
# Unit test for constructor of class Token
def test_Token():
    token1 = Token("abc", 0, 2)
    assert token1.string == "abc"
    assert token1._value == "abc"
    assert token1.value == "abc"
    assert str(token1) == 'Token(\'abc\')'
    assert token1.start == Position(1, 4, 2)
    assert token1.end == Position(1, 4, 2)
    assert token1.lookup([]) == token1
    assert repr(token1) == "Token('abc')"
    assert token1 == Token("abc", 0, 2)
    


# Generated at 2022-06-22 06:37:39.430710
# Unit test for constructor of class Token
def test_Token():
    t = Token(None, 0, 0, "")
    assert t.string == ""
    assert t.value is None



# Generated at 2022-06-22 06:37:58.353952
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("foo", 1, 3, "foobar")
    assert token._get_value() == "foo"
    assert token.string == "foo"
    assert token.value == "foo"
    assert token.start == Position(1, 1, 1)
    assert token.end == Position(1, 3, 3)
    assert token.lookup([]) == token
    assert token.lookup_key([0]) == token
    assert repr(token) == "ScalarToken('foo')"
    assert token == ScalarToken("foo", 1, 3, "foobar")
    assert hash(token) == hash("foo")


# Generated at 2022-06-22 06:38:10.673985
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    from hypothesis import given
    from hypothesis.strategies import integers, text
    from tests.conftest import custom_strategy

    @given(custom_strategy(text()))
    def test_ScalarToken___hash__1(
        test_input_1: typing.Any,
    ) -> typing.Callable[
        [
            typing.Any,
            typing.Any,
            typing.Any,
            typing.Any,
            typing.Any,
            typing.Any,
            typing.Any,
            typing.Any,
            typing.Any,
            typing.Any,
        ],
        int,
    ]:
        def wrapper(*args: typing.Any, **kwargs: typing.Any) -> ScalarToken:
            return ScalarToken(*args, **kwargs)


# Generated at 2022-06-22 06:38:12.494639
# Unit test for constructor of class ListToken
def test_ListToken():
    t=Token(1, 1, 2)
    print(t)
    assert ListToken(1,1,2) == 1


test_ListToken()

# Generated at 2022-06-22 06:38:17.036519
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(10, start_index=0, end_index=0)
    assert token.value == 10
    assert token.string == ""
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)


# Generated at 2022-06-22 06:38:18.472331
# Unit test for constructor of class Token
def test_Token():
    assert Token(11, 2, 3, 'abc')


# Generated at 2022-06-22 06:38:21.221828
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(value=1, start_index=1, end_index=1)
    assert hash(token) == hash(1)


# Generated at 2022-06-22 06:38:27.249627
# Unit test for method lookup of class Token
def test_Token_lookup():
    t = ListToken(
        value=[
            ScalarToken(value=1, start_index=0, end_index=0, content="1"),
            ScalarToken(value=2, start_index=1, end_index=1, content="2"),
            ScalarToken(value=3, start_index=2, end_index=2, content="3"),
            ScalarToken(value=4, start_index=3, end_index=3, content="4"),
            ScalarToken(value=5, start_index=4, end_index=4, content="5")
        ],
        start_index=0,
        end_index=4,
        content="12345"
    )
    assert t.lookup([0]).value == 1
    assert t.lookup([1]).value == 2
    assert t

# Generated at 2022-06-22 06:38:33.153012
# Unit test for method lookup of class Token
def test_Token_lookup():
    index = [3, 1, 2]
    value = [1, 2, 3, [4, 5, 6, [7, 8, 9, [10, 11, 12]]]]
    content = '{"test": ["x", {"test2": [1, 2, 3, {"a": "b"}]}]}'
    token = Token(value, 0, len(content))
    assert token.lookup(index).value == 9


# Generated at 2022-06-22 06:38:42.728400
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    ScalarToken(value=1, start_index=2, end_index=4).__repr__()
    ScalarToken(value=1, start_index=2, end_index=4).__repr__()
    ScalarToken(value=1.5, start_index=2, end_index=5).__repr__()
    ScalarToken(value="hello", start_index=2, end_index=7).__repr__()
    ScalarToken(value=True, start_index=2, end_index=5).__repr__()
    ScalarToken(value=None, start_index=2, end_index=5).__repr__()


# Generated at 2022-06-22 06:38:51.396433
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    str_1 = "aAaA"
    str_2 = "bBbB"
    str_3 = "cCcC"
    start_1 = 10
    end_1 = 20
    start_2 = 15
    end_2 = 19
    start_3 = 1
    end_3 = 1
    tmp_1 = Token(str_1, start_1, end_1)
    tmp_2 = Token(str_2, start_2, end_2)
    tmp_3 = Token(str_3, start_3, end_3)
    tmp_4 = Token(str_1, start_1, end_1)
    tmp_assert_1 = tmp_1.__eq__(tmp_2)
    tmp_assert_2 = tmp_1.__eq__(tmp_3)
   