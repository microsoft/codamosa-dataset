

# Generated at 2022-06-22 06:29:09.310733
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert Token(None, 0, 1, "").__repr__() == "Token('',)"
    assert Token([], 0, 1, "").__repr__() == "Token('',)"
    assert Token([], 0, 1, "").__repr__() == "Token('',)"


# Generated at 2022-06-22 06:29:13.180800
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Testing for class Token
    t1 = Token("", 0, 0)
    assert t1.__eq__("") == False
    assert t1.__eq__(Token("", 0, 0)) == True


# Generated at 2022-06-22 06:29:24.218452
# Unit test for method lookup of class Token
def test_Token_lookup():
    from typesystem.base import get_annotation_info
    from typesystem.base import StructureType
    from typesystem.base import Schema, String, List, Integer, Literal

    class Person(StructureType):
        name = String()
        age = Integer()

    class Team(StructureType):
        name = String()
        members = List(Person)

    class Root(StructureType):
        team_a = Team()
        team_b = Team()

    schema = Schema(Root)
    info = get_annotation_info(schema)
    annotation = info["annotation"]
    content = info["content"]

    root_token = annotation
    team_a_token = annotation.lookup([0])
    name_a_token = annotation.lookup([0, 0])


# Generated at 2022-06-22 06:29:26.285388
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    # Instantiate class ScalarToken
    x: ScalarToken = ScalarToken ("hello", 0, 4, content="hello")
    assert(x)



# Generated at 2022-06-22 06:29:29.164678
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    obj = ScalarToken(1, 2, 3)
    assert hash(obj) == hash(1)

# Generated at 2022-06-22 06:29:32.212849
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    d = DictToken(
        {'k': 'v'}, 0, 4, content='{k: v}'
    )
    assert d.lookup_key([0]) == d

# Generated at 2022-06-22 06:29:35.405344
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # this class is abstract and cannot be tested
    pass


# Generated at 2022-06-22 06:29:38.917023
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t = Token(1, 1, 2)
    t2 = Token(2, 1, 2)
    assert t == t
    assert t != t2


# Generated at 2022-06-22 06:29:44.008517
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    arguments = {
        'content': "abcdefghij",
        'value': "ab",
        'start_index': 0,
        'end_index': 1
    }
    token_instance = Token(**arguments)
    assert token_instance.__repr__() == "Token('ab')"

# Generated at 2022-06-22 06:29:52.461065
# Unit test for constructor of class Token
def test_Token():
    # Given
    start_index = 0
    end_index = 0
    content = ""
    value = 1

    # When
    token = Token(value, start_index, end_index, content)

    # Then
    assert token._value == value
    assert token._start_index == start_index
    assert token._end_index == end_index
    assert token._content == content
    assert token.value == value
    assert token.start == Position(1,1,0)
    assert token.end == Position(1,1,0)
    assert token.lookup(()) == token
    assert token.lookup_key(()) == token
    assert token.string == ""
    assert repr(token) == "Token('')"
    assert hash(token) == hash(repr(token))

# Generated at 2022-06-22 06:30:02.802405
# Unit test for method __eq__ of class Token
def test_Token___eq__():
  t1 = Token('', 0, 0)
  t2 = Token('', 0, 0)
  assert t1 == t2
  t3 = Token('', 0, 1)
  t4 = Token('', 0, 2)
  assert not t3 == t4
  assert t3 != t4

# Generated at 2022-06-22 06:30:07.556749
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    actual_result = ScalarToken(None, 0, 0).__hash__()
    expected_result = hash(None)
    assert actual_result == expected_result



# Generated at 2022-06-22 06:30:10.187501
# Unit test for constructor of class Token
def test_Token():
    try:
        tok = Token(1, 0, 1, "abc")
    except NotImplementedError:
        assert True
    else:
        assert False


# Generated at 2022-06-22 06:30:18.858922
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    """
    It should return the hash of its value
    """

    class StubToken(ScalarToken):
        def __init__(self, value, start_index, end_index):
            super().__init__(value, start_index, end_index, "")

    assert StubToken("a", 0, 0).__hash__() == hash("a")
    assert StubToken("1", 0, 0).__hash__() == hash("1")
    assert StubToken(1, 0, 0).__hash__() == hash(1)
    assert StubToken(1.0, 0, 0).__hash__() == hash(1.0)


# Generated at 2022-06-22 06:30:28.248957
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    arr = [True, 0, 'a', 3, 4]
    arr_tokens = []
    for i in range(5):
        arr_tokens.append(ScalarToken(arr[i], i, i))
    assert arr_tokens[0]._value == True
    assert arr_tokens[0]._start_index == 0
    assert arr_tokens[0]._end_index == 0
    assert arr_tokens[0]._content == ''
    assert arr_tokens[1]._value == 0
    assert arr_tokens[1]._start_index == 1
    assert arr_tokens[1]._end_index == 1
    assert arr_tokens[1]._content == ''

# Generated at 2022-06-22 06:30:30.149524
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    obj = ScalarToken(123, 0, 2, "abc")
    assert hash(obj) == hash(123)

# Generated at 2022-06-22 06:30:32.175177
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    t = ScalarToken('hello',0,4)
    assert t.value == 'hello'


# Generated at 2022-06-22 06:30:38.482455
# Unit test for constructor of class ListToken
def test_ListToken():
    list_token = ListToken([], 0, 0)
    assert list_token.string == ""
    assert list_token.value == []

    assert list_token.start.line_no == 1
    assert list_token.start.column_no == 1
    assert list_token.start.index == 0

    assert list_token.end.line_no == 1
    assert list_token.end.column_no == 1
    assert list_token.end.index == 0



# Generated at 2022-06-22 06:30:40.746849
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_1 = list(range(10))
    token_2 = list(range(10))
    assert token_1 == token_2


# Generated at 2022-06-22 06:30:52.223515
# Unit test for method lookup of class Token
def test_Token_lookup():
    from typesystem.base import parse as parseType
    from typesystem.base import Schema
    from typesystem.base import Validator
    from typesystem.base import Int, String
    from typesystem.base import Optional
    from typesystem.base import AnyOf, OneOf
    from typesystem.base import BaseSchemaError
    from typesystem.schema_classes import (
        ArraySchema,
        MapSchema,
        Error,
    )

    schema = parseType(
        """
    type: object
    properties:
      name:
        type: string
      age:
        type: integer
      children:
        type: array
        items:
          type:
          - object
          - string
    required:
    - name
    - age
    """
    )


# Generated at 2022-06-22 06:31:04.118967
# Unit test for constructor of class Token
def test_Token():
    token = Token('$', 0, 2)
    assert token._value == '$'
    assert token._start_index == 0
    assert token._end_index == 2
    assert token._content == ''


# Generated at 2022-06-22 06:31:08.018127
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # Creating a Token object
    TokenObj = Token(1, 1, 1)
    # Testing whether the lookup_key method returns the appropriate value
    assert TokenObj.lookup_key([1]) == TokenObj

# Generated at 2022-06-22 06:31:10.428274
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    r'''It should return a string representation of the token.'''

    t = Token(None, 0, 0)
    assert repr(t) == 'Token(None)'


# Generated at 2022-06-22 06:31:16.705991
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = ScalarToken(1, 1, 2, content="1")
    t2 = ScalarToken(1, 1, 2, content="1")
    t3 = ScalarToken(1, 1, 3, content="1")
    t4 = ScalarToken(2, 1, 2, content="1")
    t5 = ScalarToken(1, 1, 2, content=None)
    return True



# Generated at 2022-06-22 06:31:18.305517
# Unit test for constructor of class DictToken
def test_DictToken():
    DT = DictToken({0: 1, 1: 2}, 0, 1, content="")

# Generated at 2022-06-22 06:31:22.856725
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    """
    Tests that lookup_key returns the correct token for a dictionary key.
    """
    d = {'a':'1'}
    tk = DictToken(d,0,3)
    result = tk.lookup_key([0])
    assert isinstance(result, ScalarToken)
    assert result.start.column == 2

# Generated at 2022-06-22 06:31:32.518042
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # Test regular case
    token = ScalarToken(
        value=10, start_index=0, end_index=0, content="10"
    )
    assert hash(token) == hash(10)

    # Test value is None
    token = ScalarToken(
        value=None, start_index=0, end_index=0, content="10"
    )
    assert hash(token) == hash(None)

    # Test value is str
    token = ScalarToken(
        value="str", start_index=0, end_index=0, content="10"
    )
    assert hash(token) == hash("str")

    # Test value is bool
    token = ScalarToken(
        value=True, start_index=0, end_index=0, content="10"
    )

# Generated at 2022-06-22 06:31:36.044081
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    instance = ScalarToken('100', 100, 100)
    assert hash(instance) == hash('100')

# Generated at 2022-06-22 06:31:44.944155
# Unit test for method lookup of class Token
def test_Token_lookup():
    class dict_token(DictToken):
        def __init__(self, *args, **kwargs):
            return DictToken.__init__(self, *args, **kwargs)

    class list_token(ListToken):
        def __init__(self, *args, **kwargs):
            return ListToken.__init__(self, *args, **kwargs)

    d1 = dict_token({'a': 1, 'b': 2, 'c': ["a", "b", "c"]}, 0, 0, "a")
    d2 = dict_token({'a': 1, 'b': 2, 'c': ["a", "b", "c"]}, 0, 0, "a")
    l1 = list_token(['a', 'b', 'c'], 0, 0, 'a')
    l2

# Generated at 2022-06-22 06:31:50.012551
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    test = ScalarToken(value = 3, start_index = 0, end_index = 0)
    assert test._get_value() == 3
    assert test.start.column_no == 1
    assert test.start.index == 0
    assert test.start.line_no == 1
    assert test.end.column_no == 1
    assert test.end.index == 0
    assert test.end.line_no == 1



# Generated at 2022-06-22 06:32:22.227985
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # Set up the input arguments
    # index = []   # type: list[str]
    # index = ['1']
    index = ['1','1']
    # Create an instance of the class
    # token = Token()
    token = DictToken()
    # Run the method
    output = token.lookup_key(index)
    # Check the results
    assert isinstance(output, Token)


# Generated at 2022-06-22 06:32:32.137403
# Unit test for constructor of class DictToken
def test_DictToken():
    assert repr(DictToken({}, 0, 1, content='something')) == "DictToken({}, 0, 1)"
    assert repr(DictToken(None, 0, 1, content='something')) == "DictToken(None, 0, 1)"
    assert repr(DictToken(3, 0, 1, content='something')) == "DictToken(3, 0, 1)"
    assert repr(DictToken('l', 0, 1, content='something')) == "DictToken('l', 0, 1)"

# Generated at 2022-06-22 06:32:36.480499
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    json_value = {
        'clientVersion': {
            'major': 3,
            'minor': 20,
            'patch': 0
        }
    }
    content = json.dumps(json_value)

    tokens, _ = tokenize(json_value, content)

    index = tokens.lookup_key([("clientVersion",)])
    assert index.string == '"clientVersion"'



# Generated at 2022-06-22 06:32:42.434143
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert ScalarToken(1, 0, 1).__repr__() == "ScalarToken('1')"
    assert ScalarToken("foo", 0, 2).__repr__() == "ScalarToken('foo')"
    assert ScalarToken(True, 0, 3).__repr__() == "ScalarToken('True')"


# Generated at 2022-06-22 06:32:46.470861
# Unit test for constructor of class DictToken
def test_DictToken():
    content = """
        key1: value1
        key2: value2
    """
    token = DictToken({0: 0}, 0, 18, content)
    assert token._start_index == 0
    assert token._end_index == 18
    assert token._content == content


# Generated at 2022-06-22 06:32:50.256085
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(value=12345, start_index=1, end_index=2)
    assert hash(token) == hash(12345)


# Generated at 2022-06-22 06:32:52.520774
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    instance = Token()
    other = Token()
    assert instance.__eq__(other) == (False)

# Generated at 2022-06-22 06:32:59.960996
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    t = ScalarToken('a',0,0, 'a')
    print(str(t))
    print(str(t.value))
    print(str(t.start))
    print(str(t.end))
    assert(t.start == t.end)
    assert(t.string == 'a')
    assert(t.value == 'a')
    assert(repr(t) == "ScalarToken('a')")
#Unit test for constructor of class DictToken

# Generated at 2022-06-22 06:33:09.670289
# Unit test for constructor of class ListToken
def test_ListToken():
    from typesystem.base import Position
    from typesystem.lexer import Token
    from typesystem.lexer import ListToken

    class Token_test(Token):
        def __init__(self, value: list, start_index: int, end_index: int, content: str = "") -> None:
            super().__init__(value, start_index, end_index)

    start_index = 1
    end_index = 10
    value = list()
    a = Token_test(value, start_index, end_index)
    b = Token_test(value, start_index, end_index)
    c = Token_test(value, start_index, end_index)
    d = Token_test(value, start_index, end_index)

# Generated at 2022-06-22 06:33:12.195105
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    ScalarToken_obj = ScalarToken(1,1,1)
    assert hash(ScalarToken_obj) == hash(1)



# Generated at 2022-06-22 06:33:44.983556
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    # Test 1
    t = ScalarToken(1, 1, 1, content='a')
    assert t.string == 'a'
    assert t.start.line == 1
    assert t.start.column == 1
    assert t.value == 1


# Unit tests for eq()

# Generated at 2022-06-22 06:33:49.450764
# Unit test for constructor of class DictToken
def test_DictToken():
    value = {'a':'b'}
    start_index = 0
    end_index = 1
    content = ""
    test_token = DictToken(value, start_index, end_index, content)
    assert test_token.__repr__() == "DictToken({'a': 'b'})"


# Generated at 2022-06-22 06:33:55.000656
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    value = "jfkdslfjdskf"
    start_index = 6
    end_index = 11
    content = "fkdslfjdskf"
    t = Token(value, start_index, end_index, content)
    assert t.__repr__() == "Token('fjdsk')"


# Generated at 2022-06-22 06:33:58.501994
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(value=None, start_index=0, end_index=1, content=None)
    result = token.__hash__()
    assert result == hash(None)


# Generated at 2022-06-22 06:34:05.288393
# Unit test for constructor of class Token
def test_Token():
    token = Token(1, 0, 1)
    assert token._value == 1
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == ""
    token = Token(1, 0, 1, "1")
    assert token._value == 1
    assert token._start_index == 0
    assert token._end_index == 1
    assert token._content == "1"


# Generated at 2022-06-22 06:34:16.366142
# Unit test for constructor of class DictToken
def test_DictToken():
    import typesystem
    import random
    import string

    def random_string(string_lenght=10):
        """Generate a random string of fixed length """
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(string_lenght))

    def random_float():
        return random.randrange(1,12)/random.randrange(1,12);

    types = ['str', 'int', 'bool', 'float', 'dict', 'list']
    key_value_pairs = {
        'str': {},
        'int': {},
        'bool': {},
        'float': {},
        'dict': {},
        'list': {}
    }

    # dict 1 - dict 2 : dict<str:int, str:int>


# Generated at 2022-06-22 06:34:17.807071
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    dict_token = DictToken()
    dict_token.lookup_key((0,1))

# Generated at 2022-06-22 06:34:20.657328
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert repr(Token(value=None,start_index=0,end_index=0,content="")) == "Token(None)" 


# Generated at 2022-06-22 06:34:27.415068
# Unit test for constructor of class ListToken
def test_ListToken():
    with open("tests/test1.yml") as f:
        content = f.read()
    tokens = Tokenizer(content)
    token = ListToken(tokens[0], 0, 0, content)
    assert token.string == "[]"
    assert token.value == []
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)

# Generated at 2022-06-22 06:34:29.820093
# Unit test for constructor of class DictToken
def test_DictToken():
    a=DictToken({"a":1},{"a":2},{"a":3})
    assert a._value["a"] == 1


# Generated at 2022-06-22 06:35:13.731116
# Unit test for constructor of class ListToken
def test_ListToken():

    list_token = ListToken([1, 2, 3], 0, 4)
    assert list_token.start.line == 1 and list_token.start.column == 1 and list_token.start.index == 0
    assert list_token.end.line == 1 and list_token.end.column == 5 and list_token.end.index == 4
    assert list_token.string == '[1, 2, 3]' and list_token.value == [1, 2, 3]
    assert list_token.lookup([0]).string == '1' and list_token.lookup([0]).value == 1 and list_token.lookup([0]).start.line == 1 and list_token.lookup([0]).start.column == 2 and list_token.lookup([0]).start.index == 1

# Generated at 2022-06-22 06:35:21.571682
# Unit test for constructor of class Token
def test_Token():
    # test constructor of Token
    start_index =0
    end_index = 100
    content = "It is a token test."
    token = Token(1, start_index, end_index, content)
    assert token.start == Position(content[:start_index].count("\n") + 1, 1, 0)
    assert token.end == Position(content[:end_index].count("\n") + 1, 3, 2)
    assert token.string == "It"
    assert token.value == 1


# Generated at 2022-06-22 06:35:28.952889
# Unit test for method lookup of class Token
def test_Token_lookup():
    class Token:
        _value = [1,2,3]
        _start_index = 0
        _end_index = 6
        def _get_value(self) -> typing.Any:
            return self._value
        def _get_child_token(self, key: typing.Any) -> 'Token':
            return self._value[key]
        def _get_key_token(self, key: typing.Any) -> 'Token':
            return self._value[key]
    token = Token()
    assert token.lookup([0]) == 1

# Generated at 2022-06-22 06:35:30.039188
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken


# Generated at 2022-06-22 06:35:40.272226
# Unit test for method lookup of class Token
def test_Token_lookup():
    import tokens
    import typesystem
    schema = typesystem.Schema(
        {"type": [str], "length": int, "properties": {"name": str, "age": int}})
    document = {"type": ["string"], "length": 10, "properties": {"name": "Jack", "age": 12}}
    token_struc = tokens.create(schema, document)
    assert (token_struc.lookup([0, "length"]).string == "10")
    assert (token_struc.lookup([0, "properties"]).string == '{"name": "Jack", "age": 12}')


# Generated at 2022-06-22 06:35:47.671027
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    string = "hello world!"
    token = Token(None, 5, 11, string)
    assert token == token
    assert token == Token(None, 5, 11, string)
    assert not token == Token(None, 6, 12, string)
    assert not token == Token(None, 4, 10, string)
    assert not token == Token(None, 4, 11, string)
    assert not token == Token(None, 5, 12, string)
    assert not token == Token(None, 4, 10, string)
    assert not token == Token(None, 5, 13, string)
    assert not token == None

# Generated at 2022-06-22 06:35:52.301219
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Set up test data
    class TestToken(Token):
        def __init__(self):
            self._value = None
    expected = "TestToken('None')"

    # Perform the test
    actual = repr(TestToken())

    # Verify the results
    assert actual == expected


# Generated at 2022-06-22 06:35:55.530928
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken(value= {'a':1}, start_index=0, end_index=1, content=1)
    assert d._value == {'a':1}

# Generated at 2022-06-22 06:36:03.712994
# Unit test for method lookup of class Token
def test_Token_lookup():
    bar = ScalarToken(value="bar", start_index=3, end_index=5, content="foo bar")
    baz = ScalarToken(value="baz", start_index=10, end_index=12, content="foo bar")
    foo = DictToken(
        {bar: baz},
        start_index=0,
        end_index=12,
        content="foo bar",
    )
    assert foo.lookup([0]).value == "baz"

test_Token_lookup()

# Generated at 2022-06-22 06:36:06.886515
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    o = Token(value=None, start_index=None, end_index=None, content=None)
    assert repr(o) == 'Token(None)'


# Generated at 2022-06-22 06:36:30.239181
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3, "foo")
    assert token == token
    assert token != "bar"
    assert token != Token(
        None, 2, 3, ""
    )
    assert token != Token(
        1, 0, 3, ""
    )
    assert token != Token(
        1, 2, 5, ""
    )

# Generated at 2022-06-22 06:36:38.660502
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from typesystem import Composite
    token = Composite()
    token2 = Composite()
    token3 = Composite()
    token4 = Composite()
    token5 = Composite()
    token.add_token("a", token2)
    token2.add_token("b", token3)
    token3.add_token("c", token4)
    token4.add_token("d", token5)
    assert isinstance(token.lookup_key("a.b.c.d"), Composite)
    #assert token.lookup_key("a.b.c.d") == token5

# Generated at 2022-06-22 06:36:45.920467
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    a = ScalarToken("a", 1, 2)
    b = ScalarToken("b", 2, 3)
    assert a != b
    a = ScalarToken("a", 1, 2)
    b = ScalarToken("a", 1, 2)
    assert a == b
    a = ScalarToken("a", 1, 2)
    b = ScalarToken("b", 1, 2)
    assert a != b
    a = ScalarToken("a", 1, 2)
    b = ScalarToken("a", 0, 2)
    assert a != b
    a = ScalarToken("a", 1, 2)
    b = ScalarToken("a", 1, 1)
    assert a != b
    a = ScalarToken("a", 1, 2)
    b = ScalarToken("a", 1, 2)
   

# Generated at 2022-06-22 06:36:55.579273
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import Position
    from typesystem.typing import Dict
    from typesystem.types import String
    from typing import Any
    import sys
    print(sys.path)
    dictionary_type = Dict({String(): String()})
    token = DictToken({
        ScalarToken('a', 0, 0, 'a'): ScalarToken('a', 0, 0, 'a'),
        ScalarToken('b', 0, 0, 'a'): ScalarToken('b', 0, 0, 'a')
    }, 0, 0, 'a')
    a = token._get_value()
    print(token.lookup_key(['a']).string)

if __name__ == "__main__":
    test_DictToken()

# Generated at 2022-06-22 06:36:58.183043
# Unit test for method __eq__ of class Token
def test_Token___eq__():

    token1 = Token( '', 1, 1, '')
    token2 = Token('', 1, 1, '')

    assert token1 == token2


# Generated at 2022-06-22 06:37:02.885541
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = ScalarToken(value = 'bar', start_index = 0, end_index = 3, content = 'bar')
    index = [0]
    assert token.lookup_key(index) == token


# Generated at 2022-06-22 06:37:03.525397
# Unit test for constructor of class Token
def test_Token():
    assert Token('value', 0, 10)

# Generated at 2022-06-22 06:37:05.995359
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token(None, 0, 0)
    assert token.lookup([]) is token
test_Token_lookup()


# Generated at 2022-06-22 06:37:08.760068
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({"a":1}, 1, 5)
    assert token._value == {"a":1}
    assert token._start_index == 1
    assert token._end_index == 5


# Generated at 2022-06-22 06:37:10.626246
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken()

# Generated at 2022-06-22 06:38:18.110404
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("value", 0, 4)
    assert token._value == "value"
    assert token._start_index == 0
    assert token._end_index == 4
    assert token._content == ""
    assert repr(token) == "ScalarToken('value')"
    assert token.start == Position(1, 6, 0)
    assert token.end == Position(1, 6, 4)

# Generated at 2022-06-22 06:38:29.771265
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    ScalarToken(None, 0, 3, content="").__hash__()
    ScalarToken(True, 0, 4, content="").__hash__()
    ScalarToken(False, 0, 5, content="").__hash__()
    ScalarToken(0, 0, 1, content="").__hash__()
    ScalarToken(-1.2, 0, 4, content="").__hash__()
    ScalarToken(1, 0, 1, content="").__hash__()
    ScalarToken(1.0, 0, 3, content="").__hash__()
    ScalarToken(1.2, 0, 3, content="").__hash__()
    ScalarToken(-1, 0, 2, content="").__hash__()
    ScalarToken(-1.0, 0, 4, content="").__hash__()
   

# Generated at 2022-06-22 06:38:31.244826
# Unit test for constructor of class Token
def test_Token():
    DictToken(1, 2, 3, 4)


# Generated at 2022-06-22 06:38:37.081627
# Unit test for constructor of class DictToken
def test_DictToken():
    content = '"name": "Alex", "age": 20, "single": true'
    result = DictToken({
        'name' : ScalarToken('Alex', 5, 10),
        'age' : ScalarToken(20, 18, 20),
        'single' : ScalarToken(True, 29, 33),
    }, 0, 33, content=content)

    assert(result._get_value() == {
        'name' : 'Alex',
        'age' : 20,
        'single' : True
    })

# Generated at 2022-06-22 06:38:38.371747
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    pass

# Generated at 2022-06-22 06:38:43.896306
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Simple tests
    t0 = Token(None, None, None, None)
    t1 = Token(1, 2, 3, "12345")
    assert(t0.__repr__() == "Token('')")
    assert(t1.__repr__() == "Token('1')")


# Generated at 2022-06-22 06:38:55.430579
# Unit test for method lookup of class Token
def test_Token_lookup():
    # Given
    class Value:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    start_index = 1
    end_index = 2
    value = Value(
        ScalarToken('a-value', start_index, end_index),
        ScalarToken('b-value', start_index, end_index),
    )
    content = ""

    # When
    token = Token(value, start_index, end_index, content)

    # Then
    assert token.lookup(['a']).string == 'a-value'
    assert token.lookup(['b']).string == 'b-value'
    assert token.lookup(['a']).start.line_number == 1
    assert token.lookup(['b']).start.line_number

# Generated at 2022-06-22 06:38:57.255215
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(1, 1, 2, "")
    assert token
