

# Generated at 2022-06-22 06:29:11.852240
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Case 1: Token(b'\n')
    v = Token(b'\n', start_index=0, end_index=0, content=b'.\n')
    assert v.__repr__() == "Token('\\\\n')"
    # Case 2: Token(None)
    v = Token(None, start_index=0, end_index=0, content=b'.\n')
    assert v.__repr__() == "Token('None')"
    # Case 3: Token(['\n'])
    v = Token([b'\n'], start_index=0, end_index=0, content=b'.\n')
    assert v.__repr__() == "Token('[\\\\\\\\n]')"
    # Case 4: Token({b'\n': '\n'})
    v

# Generated at 2022-06-22 06:29:23.472045
# Unit test for constructor of class ListToken
def test_ListToken():
    # The simple case
    test_0 = ListToken(1, 0, 0)
    assert test_0._value == 1
    assert test_0._start_index == 0
    assert test_0._end_index == 0

    # The harder case
    test_1 = ListToken(1, 2, 3, content="Hello World")
    assert test_1._value == 1
    assert test_1._start_index == 2
    assert test_1._end_index == 3
    assert test_1.string == "l"

    # The harder case
    test_2 = ListToken(1, 2, 5, content="Hello World")
    assert test_2._value == 1
    assert test_2._start_index == 2
    assert test_2._end_index == 5
    assert test_2.string == "llo"



# Generated at 2022-06-22 06:29:27.340040
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # Test code here
    # For example:
    token = Token("value", 0, 1)
    token["key"] = Token("value", 0, 1)
    assert token.lookup_key("key")["key"].value == "value"


# Generated at 2022-06-22 06:29:29.838557
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
  st = ScalarToken("value", 1, 2)
  assert st.__str__() == "ScalarToken(value)"


# Generated at 2022-06-22 06:29:39.613513
# Unit test for constructor of class DictToken
def test_DictToken():
    d =  {
            ScalarToken("a",1,1):ScalarToken("b",2,2),
            ScalarToken("c",3,3):ScalarToken("d",4,4),
            ScalarToken("e",5,5):ScalarToken("f",6,6)
        }
    dt = DictToken(d,1,6,"abcedf")
    assert dt._child_keys == {
                                "a": ScalarToken("a",1,1),
                                "c": ScalarToken("c",3,3),
                                "e": ScalarToken("e",5,5)
                            }


if __name__ == "__main__":
    test_DictToken()

# Generated at 2022-06-22 06:29:42.470071
# Unit test for constructor of class DictToken
def test_DictToken():
    value = {'a': 2}
    start_index = 2
    end_index = 4
    content = "abcd"
    test = DictToken(value, start_index, end_index, content)
    assert isinstance(test, DictToken)


# Generated at 2022-06-22 06:29:43.864078
# Unit test for constructor of class ListToken
def test_ListToken():
    assert(ListToken(["",""],"","","") == ListToken(["",""],"","",""))

# Generated at 2022-06-22 06:29:51.227354
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    my_token = ScalarToken("foo", 1, 2, "foobar")
    assert my_token._start_index == 1
    assert my_token._end_index == 2
    assert my_token._content == "foobar"
    assert my_token.string == "fo"
    assert my_token.value == "foo"
    assert my_token.start == Position(1, 1, 1)
    assert my_token.end == Position(1, 2, 1)


# Generated at 2022-06-22 06:29:52.830111
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # TODO: IMPLEMENT
    raise NotImplementedError


# Generated at 2022-06-22 06:30:04.765734
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken(["abc", "def"], 0, 5).string == '["abc", "def"]'
    assert ListToken(["abc", "def"], 0, 5).start == Position(1, 0, 0)
    assert ListToken(["abc", "def"], 0, 5).end == Position(1, 14, 14)
    assert ListToken(["abc", "def"], 0, 5).lookup([0]).start == Position(1, 2, 1)
    assert ListToken(["abc", "def"], 0, 5).lookup([1]).end == Position(1, 11, 10)
    assert ListToken(["abc", "def"], 0, 5).lookup_key([0]) == None
    assert ListToken(["abc", "def"], 0, 5)._get_child_token(0)._get_value() == "abc"


# Generated at 2022-06-22 06:30:21.036588
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert ScalarToken("foo", 1, 2) == ScalarToken("foo", 1, 2)
    #
    # assert ListToken(
    #     ["foo"],
    #     1,
    #     5,
    #     content='["foo"]') == ListToken(
    #     ["foo"],
    #     1,
    #     5,
    #     content='["foo"]')
    #
    # assert ListToken(
    #     ["bar"],
    #     1,
    #     5,
    #     content='["bar"]') != ListToken(
    #     ["foo"],
    #     1,
    #     5,
    #     content='["foo"]')
    #
    # assert ListToken(
    #     ["foo"],
    #     1,
    #     5,
    #

# Generated at 2022-06-22 06:30:22.657627
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = ListToken([], 0, 0)
    res = token.lookup_key([0])
    assert res == token

# Generated at 2022-06-22 06:30:24.616578
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert Token(value=None, start_index=None, end_index=None,
                 content='').__repr__() == "Token('')"


# Generated at 2022-06-22 06:30:27.307345
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    t = ScalarToken(False, 0, 0)
    hash(t)



# Generated at 2022-06-22 06:30:37.066060
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    print("Test __repr__")
    token = Token(5, 1, 2)
    assert token.__repr__() == "Token('5')"

    token = Token(5, 1, 2, "Hello")
    assert token.__repr__() == "Token('5')"

    token = Token(5, 1, 2, "Hello", "")
    assert token.__repr__() == "Token('5')"

    token = Token(5, 1, 2, "Hello", "")
    assert token.__repr__() == "Token('5')"

    token = Token({'a': 1, 'b': 2}.items(), 1, 2, "Hello", "")
    assert token.__repr__() == "Token('[(\\'a\\', 1), (\\'b\\', 2)]')"


# Generated at 2022-06-22 06:30:40.422745
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    try:
        ScalarToken(None, 1, 2, "").__hash__()
    except NotImplementedError:
        pass
    else:
        assert False


# Generated at 2022-06-22 06:30:51.849551
# Unit test for constructor of class ListToken
def test_ListToken():
    listToken1 = ListToken(
                    [1, 2, 3],
                    1,
                    4,
                    content="1,2,3"
                  )
    assert isinstance(listToken1, ListToken)
    assert listToken1._value == [1, 2, 3]
    assert listToken1._start_index == 1
    assert listToken1._end_index == 4
    assert listToken1._content == "1,2,3"
    assert listToken1.string == "1,2,3"
    assert listToken1.value == [1, 2, 3]
    assert listToken1.start.line == 1
    assert listToken1.start.column == 1
    assert listToken1.start.index == 1
    assert listToken1.end.line == 1
    assert listToken1.end.column == 6

# Generated at 2022-06-22 06:30:54.011762
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = Token(1, 1, 1)
    assert token.lookup_key([0]) == token


# Generated at 2022-06-22 06:31:06.131630
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # Index list is empty
    assert Token(None, 0, 0).lookup_key([]) == None
    # Index list has one element
    assert Token(None, 0, 0).lookup_key([0]) == None
    # Index list has more than one element and is valid
    # Note: Tokens do not have the attribute value and children, only elements of the dictionary _value have them.
    # Thus, we will use this dictionary to simulate a structure with key and children.

# Generated at 2022-06-22 06:31:17.963119
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = ScalarToken(value=1, start_index=0, end_index=10)
    assert repr(token) == "ScalarToken('1')"
    token = ScalarToken(value=1.3, start_index=0, end_index=10)
    assert repr(token) == "ScalarToken('1.3')"
    token = ScalarToken(value=None, start_index=0, end_index=10)
    assert repr(token) == "ScalarToken('None')"
    token = ScalarToken(value=True, start_index=0, end_index=10)
    assert repr(token) == "ScalarToken('True')"
    token = ScalarToken(value=False, start_index=0, end_index=10)

# Generated at 2022-06-22 06:31:29.485045
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken('foo', 0, 2)
    assert hash('foo') == token.__hash__()



# Generated at 2022-06-22 06:31:37.954506
# Unit test for constructor of class Token
def test_Token():
    # Create a Token object
    token = Token(value=None, start_index=0, end_index=0)

    # Test _get_value function
    def _get_value() -> typing.Any:
        raise NotImplementedError  # pragma: nocover

    try:
        token._get_value()  # pragma: nocover
    except NotImplementedError:
        pass
    else:  # pragma: nocover
        assert False

    # Test _get_child_token function
    def _get_child_token(self, key: typing.Any) -> "Token":
        raise NotImplementedError  # pragma: nocover


# Generated at 2022-06-22 06:31:46.037793
# Unit test for constructor of class Token
def test_Token():
    from unittest import TestCase
    import io

    class TestToken(TestCase):
        def test_init(self):
            with io.StringIO("This line is for token") as stream:
                token1 = Token("", 5, 8, stream.read())
                self.assertEqual(
                    repr(token1), "Token('line')", "Unexpected constructor output"
                )
                token2 = Token("", 0, 1, stream.read())
                self.assertEqual(
                    repr(token2), "Token('T')", "Unexpected constructor output"
                )

    test = TestToken()
    test.test_init()
    print("Testing class Token: PASSED")


# Generated at 2022-06-22 06:31:49.371217
# Unit test for constructor of class Token
def test_Token():
    t = Token("test", 0, 4)
    assert t.string == "test"
    assert t.value == "test"
    assert t.start == Position(1, 1, 0)
    assert t.end == Position(1, 5, 4)


# Generated at 2022-06-22 06:31:56.614874
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(value=1, start_index=0, end_index=2, content="1")
    assert token.value == 1
    assert token._value == 1
    assert token.string == "1"
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 2, 2)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token



# Generated at 2022-06-22 06:32:00.437324
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(7, 1, 2) == Token(7, 1, 2)
    assert Token(7, 1, 2) != Token(7, 1, 3)
    assert Token(7, 1, 2) != Token(8, 1, 2)
    assert Token(7, 1, 2) != Token(7, 1, 2, "")


# Generated at 2022-06-22 06:32:04.282489
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    t = ScalarToken(value="abc", start_index=1, end_index=2, content="abc")
    assert hash(t) == hash("abc")


# Generated at 2022-06-22 06:32:06.284265
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken('token', 0, 1)
    assert hash(token) == hash('token')


# Generated at 2022-06-22 06:32:13.482423
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token_1 = ScalarToken(5, 0, 0, "5")
    assertion_type_1 = isinstance(repr(token_1), str)
    assertion_value_1 = str(token_1)
    assert assertion_type_1 and assertion_value_1 is "ScalarToken('5')"


# Generated at 2022-06-22 06:32:14.928632
# Unit test for constructor of class Token
def test_Token():
    assert (Token(1, 5, 8, "") is not None)


# Generated at 2022-06-22 06:32:38.956676
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # type: () -> None

    pass #FIXME


# Generated at 2022-06-22 06:32:48.835021
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_value = """
    @x"zutrif"
    """
    token_start_index = 0
    token_end_index = 0
    token_content = """
    @x"zutrif"
    """
    token = Token(
        token_value,
        token_start_index,
        token_end_index,
        token_content,
    )
    token_value_0 = """
    @x"zutrif"
    """
    token_start_index_0 = 0
    token_end_index_0 = 0
    token_content_0 = """
    @x"zutrif"
    """

# Generated at 2022-06-22 06:32:54.584658
# Unit test for constructor of class Token
def test_Token():
    token = Token(1,1,1)
    assert token.string == ''
    assert token.value == None
    assert token.start == (1,1,1)
    assert token.end == (1,1,1)
    assert token.lookup([]) == None
    assert token.lookup_key([]) == None
    assert token._get_position(1) == (1,1,1)


# Generated at 2022-06-22 06:32:59.230295
# Unit test for constructor of class ListToken
def test_ListToken():
    p = Position(1, 2, 3)
    t = ListToken(None, p, p, content = 'content')
    assert t.start == p
    assert t.end == p
    # This assert statement is not true.
    # assert t.value == None
    assert t.string == 'content'

# Generated at 2022-06-22 06:33:08.887511
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    with pytest.raises(NotImplementedError):
        repr(Token(0, 0, 0))
    assert repr(ScalarToken(1, 0, 0)) == 'ScalarToken(1)'
    assert repr(DictToken({ScalarToken(1, 0, 0): ListToken([ScalarToken(1, 0, 0)], 0, 0)}, 0, 0)) == 'DictToken({1: [1]})'
    assert repr(ListToken([ScalarToken(1, 0, 0)], 0, 0)) == 'ListToken([1])'


# Generated at 2022-06-22 06:33:20.026536
# Unit test for constructor of class ListToken
def test_ListToken():
    from typesystem.tokenization import ListToken
    from typesystem.tokenization import ScalarToken
    list_token = ListToken(
        value = [ScalarToken(0, 0, 1), ScalarToken(1, 2, 3)], 
        start_index = 0, 
        end_index = 3, 
        content = "0123"
    )
    assert isinstance(list_token, ListToken)
    assert list_token.string == "0123"
    assert list_token.value == [0, 1]
    assert list_token.start == Position(1, 1, 0)
    assert list_token.end == Position(1, 4, 3)
    assert list_token.lookup([0]) == ScalarToken(0, 0, 1)

# Generated at 2022-06-22 06:33:24.487077
# Unit test for constructor of class ListToken
def test_ListToken():
    lToken = ListToken([1,2,3,4], 0, 4)
    assert(lToken._value == [1,2,3,4])
    assert(lToken._start_index == 0)
    assert(lToken._end_index == 4)

# Generated at 2022-06-22 06:33:26.351703
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert Token("a",1,2,"").__repr__() == "Token('a')"


# Generated at 2022-06-22 06:33:30.828925
# Unit test for constructor of class Token
def test_Token():
    t = Token(1, 0, 1)
    assert t.string == "1"
    assert t.value == 1
    assert t.start == Position(1, 1, 0)
    assert t.end == Position(1, 2, 1)


# Generated at 2022-06-22 06:33:34.376143
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    start_index = 1
    end_index = 2
    value = "value"
    t = Token(value, start_index, end_index)
    assert str(t) == "Token(value)"


# Generated at 2022-06-22 06:34:28.139258
# Unit test for constructor of class Token
def test_Token():
    # Test constructor
    token = Token(0, 0, 3, content="Test")
    assert(repr(token) == "Token('Test')")
    # Test property string
    assert(token.string == "Test")
    # Test property start
    assert(token.start == Position(1, 4, 0))
    # Test property end
    assert(token.end == Position(1, 4, 3))
    # Test method lookup()
    assert(token.lookup([]) == token)
    # Test method lookup_key()
    assert(token.lookup_key([]) == token)
    assert(token == token)

# Generated at 2022-06-22 06:34:40.165762
# Unit test for constructor of class DictToken
def test_DictToken():
    content = '{"a": 3, "b": true, "c": "4"}'
    dict_token = DictToken(
        value={'a': ScalarToken(value=3, start_index=3, end_index=3, content=content),
               'b': ScalarToken(value=True, start_index=9, end_index=13, content=content),
               'c': ScalarToken(value='4', start_index=19, end_index=21, content=content)},
        start_index=0,
        end_index=21,
        content=content)
    assert dict_token.__class__.__name__ == 'DictToken'
    assert dict_token._child_keys == {'a': 'a', 'b': 'b', 'c': 'c'}
    assert dict_

# Generated at 2022-06-22 06:34:49.351695
# Unit test for method lookup of class Token
def test_Token_lookup():
    foo_token = ScalarToken(value=["foo"], start_index=0, end_index=2)
    bar_token = ScalarToken(value=["bar"], start_index=3, end_index=5)
    foo_bar_token = ListToken(value=[foo_token, bar_token], start_index=0, end_index=5)
    foo_bar_token_pos = foo_bar_token.lookup([0])
    bar_token_pos = foo_bar_token.lookup([1])
    assert foo_bar_token_pos._value == ["foo"]
    assert bar_token_pos._value == ["bar"]
    assert foo_bar_token_pos._start_index == 0
    assert foo_bar_token_pos._end_index == 2
    assert bar_token_pos._start_

# Generated at 2022-06-22 06:34:52.654229
# Unit test for method lookup of class Token
def test_Token_lookup():
    assert Token(value = value, start_index = start_index_num, end_index = end_index_num, content=content).lookup(index) == result


# Generated at 2022-06-22 06:34:58.184859
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    value = 2
    start_index = 7
    end_index = 9
    content = "hello"

    scalar_token = ScalarToken(value, start_index, end_index, content)
    assert scalar_token._value == value
    assert scalar_token._start_index == start_index
    assert scalar_token._end_index == end_index


# Generated at 2022-06-22 06:34:59.164253
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({}, 0, 0, content="")

# Generated at 2022-06-22 06:35:11.488691
# Unit test for constructor of class DictToken
def test_DictToken():

    pos1 = Position(1, 1, 1)
    pos2 = Position(1, 2, 2)
    pos3 = Position(2, 3, 5)
    pos4 = Position(3, 4, 8)

    token1 = ScalarToken(1, 1, 2, "")
    token2 = ScalarToken(2, 4, 5, "")

    token3 = DictToken({token1: token2}, 3, 8, "")

    def assert_pos(pos1, pos2):
        assert pos1.line == pos2.line
        assert pos1.column == pos2.column
        assert pos1.offset == pos2.offset

    assert_pos(token3.start, pos3)
    assert_pos(token3.end, pos4)
    assert token3.string == ""
    assert token3.value

# Generated at 2022-06-22 06:35:12.478460
# Unit test for constructor of class Token
def test_Token():
    pass


# Generated at 2022-06-22 06:35:19.640979
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    from typesystem import Any, Integer

    assert str(Any()) == "Any[T]"
    assert str(Integer()) == "Integer[T]"
    assert str(Integer(minimum=1)) == "Integer[T]<min: 1>"
    assert str(Integer(maximum=2)) == "Integer[T]<max: 2>"
    assert str(Integer(minimum=1, maximum=2)) == "Integer[T]<min: 1, max: 2>"



# Generated at 2022-06-22 06:35:25.450367
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # string = "hello" # See definition of function test_Token__get_value()
    # start_index = 0 # See definition of function test_Token__get_value()
    # end_index = 4 # See definition of function test_Token__get_value()
    token = Token(None, 0, 4)
    assert repr(token) == "Token('hello')"

# Generated at 2022-06-22 06:36:12.707938
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    content = "{\n  'a': 1\n}"
    token = {"a": 1}
    assert token.lookup_key((0,)) == token['a']

# Generated at 2022-06-22 06:36:14.977690
# Unit test for constructor of class DictToken
def test_DictToken():
    dictToken = DictToken()
    assert dictToken._value == dictToken._child_keys == dictToken._child_tokens == {}


# Generated at 2022-06-22 06:36:21.014430
# Unit test for method lookup of class Token
def test_Token_lookup():
    class A(Token):
        def _get_value(self):
            return 0
        def _get_child_token(self, key):
            return self
        def _get_key_token(self, key):
            return self
    a = A(0, 0, 0)
    assert a.lookup([0]) == a
    assert a.lookup([1]) == a


# Generated at 2022-06-22 06:36:28.290165
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from bs4 import BeautifulSoup

    # check for two tokens with same value, start index, end index
    token1 = Token(1,0,0,"")
    token2 = Token(1,0,0,"")
    assert token1 == token2

    # check for two tokens with different values
    token1 = Token(1,0,0,"")
    token2 = Token(2,0,0,"")
    assert not token1 == token2

    # check for two tokens with different start indices
    token1 = Tok

# Generated at 2022-06-22 06:36:39.633957
# Unit test for method lookup of class Token
def test_Token_lookup():
    key1 = ScalarToken("key1", 0, 4, "key1")
    key2 = ScalarToken("key2", 6, 10, "key2")
    key3 = ScalarToken("key3", 12, 16, "key3")
    key4 = ScalarToken("key4", 18, 22, "key4")
    key5 = ScalarToken("key5", 24, 28, "key5")
    
    # dict = {"key1": {"key2": {"key3": {"key4": {"key5": "value"}}}}}
    child_token_dict = {"key1": key1, "key2": key2, "key3": key3, "key4": key4, "key5": key5}
    child_token_list = [key1, key2, key3, key4, key5]


# Generated at 2022-06-22 06:36:42.484394
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Setup
    self = Token(None, None, None)
    # Exercise
    actual = self.__repr__()
    # Verify
    assert actual == 'Token(None)'


# Generated at 2022-06-22 06:36:49.218428
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    from typesystem.token import Token
    from typesystem.token import Position
    from typesystem.token import ListToken
    from typesystem.token import DictToken
    from typesystem.token import ScalarToken
    token = Token(
        value = 'value',
        start_index = 1,
        end_index = 2,
        content = "content"
    )
    assert 'Token(content)' == token.__repr__()

# Generated at 2022-06-22 06:36:51.370188
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert(isinstance(ScalarToken("X",1,2).__hash__(), type(hash(""))))


# Generated at 2022-06-22 06:36:55.414175
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    value = 'hello'
    start_index = 'world'
    end_index = 'my'
    content = 'darling'
    obj = Token(value, start_index, end_index, content)
    method = obj._Token__eq__
    # TODO: test method



# Generated at 2022-06-22 06:36:56.515715
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken({"a":"a"}, 1, 2)

# Generated at 2022-06-22 06:38:05.494298
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    assert ScalarToken("abcd", 0, 3, "abcd") != None
    assert ScalarToken("abcd", 0, 3, "abcd").__repr__() == "ScalarToken('abcd')"
    assert ScalarToken("abcd", 0, 3, "abcd").__eq__("a") == False
    assert ScalarToken("abcd", 0, 3, "abcd").__eq__(ScalarToken("a", 0, 0, "a")) == False
    assert ScalarToken("abcd", 0, 3, "abcd").__eq__(ScalarToken("abcd", 0, 3, "abcd")) == True
    assert ScalarToken("abcd", 0, 3, "abcd").__hash__() == hash("abcd")


# Generated at 2022-06-22 06:38:10.245182
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("value", 0, 3)
    assert token._value == "value"
    assert token._start_index == 0
    assert token._end_index == 3
    assert token.string == "val"
    assert token.value == "value"
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 4, 3)



# Generated at 2022-06-22 06:38:21.928588
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    import collections
    import hashlib
    import io
    import json
    import os
    import sys
    import yaml

    from typesystem import parse_type

    from . import _parse


# Generated at 2022-06-22 06:38:26.017938
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token('value', 'start_index', 'end_index', 'content')
    expected = "Token('value', 'start_index', 'end_index')"
    assert repr(token) == expected

# Generated at 2022-06-22 06:38:34.892631
# Unit test for constructor of class Token
def test_Token():
    content = '{"key": "value"}'
    start_index = content.index('{"key": "value"}')
    end_index = content.index('}')
    value = {"key": "value"}
    a_Token = Token(value, start_index, end_index, content)
    assert a_Token._value == {"key": "value"}
    assert a_Token._start_index == content.index('{"key": "value"}')
    assert a_Token._end_index == content.index('}')
    assert a_Token._content == '{"key": "value"}'


# Generated at 2022-06-22 06:38:37.591039
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    with pytest.raises(NotImplementedError):
        token = Token(1, 2, 3)
        token.__eq__(None)


# Generated at 2022-06-22 06:38:40.260625
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    t = ScalarToken(1, 0, 0)
    assert hash(t) == hash(1)

# Generated at 2022-06-22 06:38:45.721444
# Unit test for constructor of class Token
def test_Token():
    assert Token(1, 1, 1, 'test_case')._value == 1
    assert Token(1, 1, 1, 'test_case')._start_index == 1
    assert Token(1, 1, 1, 'test_case')._end_index == 1
    assert Token(1, 1, 1, 'test_case')._content == 'test_case'


# Generated at 2022-06-22 06:38:50.253740
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 2, 3)
    assert repr(token1) == "Token(1)"
    token2 = Token(1, 2, 3)
    assert token1 == token2
    token3 = Token(2, 2, 3)
    assert token1 != token3


# Generated at 2022-06-22 06:38:55.141571
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token_1 = Token(value, start_index, end_index, content)
    str_repr = "%s(%s)" % (value, repr(content[start_index:end_index + 1]))
    assert token_1.__repr__() == str_repr