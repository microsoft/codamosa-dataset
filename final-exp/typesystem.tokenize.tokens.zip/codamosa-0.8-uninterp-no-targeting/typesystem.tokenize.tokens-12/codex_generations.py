

# Generated at 2022-06-22 06:29:06.619434
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = T

# Generated at 2022-06-22 06:29:13.384993
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("abc",0,2,content="abc")
    assert token.value == "abc"
    assert token.string == "abc"
    assert token.start.line_no == 1
    assert token.start.column_no == 1
    assert token.end.line_no == 1
    assert token.end.column_no == 3
    assert repr(token) == "ScalarToken('abc')"
    assert hash(token) == hash("abc")



# Generated at 2022-06-22 06:29:24.464522
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    dt1 = DictToken({}, 0, 5, content='''{}''')
    dt2 = DictToken({}, 0, 7, content='''{"key1": ["foo", "bar"]}''')
    dt3 = DictToken({}, 0, 9, content='''{"key1": {"key2": 3.2}}''')

    lt2 = dt2._child_tokens["key1"]
    lt3 = dt3._child_tokens["key1"]

    st21 = lt2._value[0]
    st22 = lt2._value[1]

    dt31 = lt3._value
    st32 = dt31._child_tokens["key2"]

    assert dt2._get_key_token("key1") == dt

# Generated at 2022-06-22 06:29:29.516474
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("token", 1, 2, content="a token")
    assert token.value == "token"
    assert token.start == Position(1, 2, 2)
    assert token.end == Position(1, 2, 2)
    assert token.string == "t"
    assert token == ScalarToken("token", 1, 2)
    assert token._get_value() == "token"



# Generated at 2022-06-22 06:29:31.693727
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken(value=[], start_index=0, end_index=0)._value == []


# Generated at 2022-06-22 06:29:36.148505
# Unit test for constructor of class ListToken
def test_ListToken():
    start_index = 0
    end_index = 0
    content = ""
    value = 0

# Generated at 2022-06-22 06:29:43.990613
# Unit test for constructor of class DictToken
def test_DictToken():
    a = {'a': 1, 'b': 2, 'c': 3}
    token = DictToken(a, 0, 10, 'abc')
    assert token._child_keys == {'a': 'a', 'b': 'b', 'c': 'c'}
    assert token._child_tokens == {'a': 1, 'b': 2, 'c': 3}
    assert token._content == 'abc'


# Generated at 2022-06-22 06:29:47.928134
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    scalar_token = ScalarToken(value = None, start_index = int(), end_index = int(), content = str())
    expected = int()
    actual = scalar_token.__hash__()
    assert expected == actual


# Generated at 2022-06-22 06:29:49.846701
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken("a", 0, 0)
    assert hash(token) == hash("a")


# Generated at 2022-06-22 06:30:01.596082
# Unit test for constructor of class Token
def test_Token():
    # Given
    string = """{
      'a' : 'b',
      'c' : 'd'
    }"""
    # When
    listToken = ListToken(['a', "'", 'b', "'", ','], 1, 2, string)
    # Then
    assert listToken.string == "'"
    assert listToken.value == "'"
    assert listToken.start.line == 1
    assert listToken.start.column == 2
    assert listToken.start.index == 1
    assert listToken.end.line == 1
    assert listToken.end.column == 3
    assert listToken.end.index == 2
    assert repr(listToken) == "ListToken('a', \"'\", 'b', \"'\", ',')"
    assert listToken is not None

# Generated at 2022-06-22 06:30:13.419579
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(1, 0, 0)
    assert token.__hash__() == hash(token._value)


# Generated at 2022-06-22 06:30:16.598192
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # ScalarToken.__hash__
    # self.assertEqual(expected, ScalarToken.__hash__(self))
    assert True # TODO: implement your test here


# Generated at 2022-06-22 06:30:18.858862
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    #default constructor for Token
    t = Token(10, 20, 30)
    assert t.lookup(1) == 2



# Generated at 2022-06-22 06:30:30.149358
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    from typesystem.aliases import String  # from typesystem.base import Scalar

    def _create_StringType():
        return String()

    def _create_ScalarToken():
        _StringType = _create_StringType()
        return ScalarToken(_StringType, "hello", 0, 4)

    _ScalarToken = _create_ScalarToken()
    assert repr(_ScalarToken) == "ScalarToken('hello')"
    assert str(_ScalarToken) == "hello"
    assert _ScalarToken.string == "hello"
    assert _ScalarToken.value == "hello"
    assert _ScalarToken.start.line == 1
    assert _ScalarToken.start.column == 1
    assert _ScalarToken.start.index == 0
    assert _Scal

# Generated at 2022-06-22 06:30:32.542108
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    start_index = 0
    end_index = 2
    content = "abc"
    Token("a", start_index, end_index, content)

# Generated at 2022-06-22 06:30:39.959869
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    key = 42
    print('Test #1')
    print(ScalarToken(key, 0, 0))
    print(ScalarToken(key, 0, 0))
    print(id(ScalarToken(key, 0, 0)), id(ScalarToken(key, 0, 0)))
    print(ScalarToken(key, 0, 0).__hash__(), ScalarToken(key, 0, 0).__hash__())
    assert ScalarToken(key, 0, 0).__hash__() == ScalarToken(key, 0, 0).__hash__()



# Generated at 2022-06-22 06:30:45.405580
# Unit test for constructor of class Token
def test_Token():
    t = Token(1, 1, 1)
    assert repr(t) == "Token(1)"
    assert t == Token(1, 1, 1)
    assert t.value == 1
    assert hash(t) == hash(1)
    assert t.start == Position(1, 1, 1)
    assert t.end == Position(1, 1, 1)


# Generated at 2022-06-22 06:30:52.382578
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    a = ScalarToken("a", 1, 2)
    assert a.start._line_no == 2
    assert a.start._column_no == 2
    assert a.end._line_no == 2
    assert a.end._column_no == 2
    assert type(a.string) == str
    assert type(a.value) == str
    assert a.start._index == 1
    assert a.end._index == 2


test_ScalarToken()



# Generated at 2022-06-22 06:30:53.876892
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token
    assert repr(token) == 'Token'

# Generated at 2022-06-22 06:31:01.865803
# Unit test for constructor of class ListToken
def test_ListToken():
    t1 = ListToken([1, 2, 3], 0, 2, "1 2 3")
    assert isinstance(t1, ListToken)
    assert t1 == ListToken([1, 2, 3], 0, 2, "1 2 3")
    assert t1.value == [1, 2, 3]
    assert t1.start == Position(1, 1, 0)
    assert t1.end == Position(1, 3, 2)
    assert t1.string == "[1, 2, 3]"


# Generated at 2022-06-22 06:31:20.045711
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = ListToken([[{"a": 1}]],1,1)
    print(token.lookup_key([0,0,"a"]))

# Generated at 2022-06-22 06:31:26.160075
# Unit test for constructor of class Token
def test_Token():
    try:
        Token(value=5, start_index=0, end_index=5, content="hello")
    except NotImplementedError:
        pass
    else:
        assert False  # pragma: nocover


# Generated at 2022-06-22 06:31:29.033529
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(
        42, 1, 2, content="42"
    ) == Token(
        42, 1, 2, content="42"
    )


# Generated at 2022-06-22 06:31:30.454775
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    t = ScalarToken('',0,0)
    assert t.__hash__() == hash(t._value)

# Generated at 2022-06-22 06:31:40.227300
# Unit test for constructor of class Token
def test_Token():
    token = Token(1, 2, 3, 'hello')
    assert token._value == 1
    assert token._start_index == 2
    assert token._end_index == 3
    assert token._content == 'hello'
    assert token.string == 'o'
    assert token.start.line_no == 1
    assert token.end.line_no == 1
    assert token.start.column_no == 3
    assert token.end.column_no == 3
    assert token.start.index == 2
    assert token.end.index == 3
    assert token.value == 1


# Generated at 2022-06-22 06:31:47.845130
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # simply use the code below to generate test code; codes generated by this feature is not covered by coverage tool
    # print(repr(Token('value',123,123, content="content")))

    # the code below is auto-generated by CodeSample extension, below is the sample code

    # create a Token object
    obj = Token('value',123,123, content="content")

    # compare the result with the expectation
    assert repr(obj) == "Token('value')"



# Generated at 2022-06-22 06:31:52.486182
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    obj = ScalarToken(value=1, start_index=0, end_index=1)
    assert obj.__hash__() == hash(1)
# ######### End of test for method __hash__ of class ScalarToken ########## #



# Generated at 2022-06-22 06:31:55.934209
# Unit test for constructor of class ListToken
def test_ListToken():
    class MyToken(ListToken):
        pass
    list_token = MyToken([1,2,3], 0, 2)
    assert list_token._value == [1,2,3]


# Generated at 2022-06-22 06:31:58.002041
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # TODO: Should we implement this unit test?
    pass


# Generated at 2022-06-22 06:32:05.210169
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    a = Token(0, 1, 2)
    b = Token(0, 1, 2)
    c = Token(1, 1, 2)
    d = Token(0, 2, 2)
    e = Token(0, 1, 3)

    assert a == a
    assert a == b
    assert b == a
    assert a != c
    assert a != d
    assert a != e

# Generated at 2022-06-22 06:32:20.222944
# Unit test for constructor of class ListToken
def test_ListToken():
    l = []
    l.append(1)
    l.append(4)
    l.append(6)
    lt = ListToken(value=l, start_index=0, end_index=2, content='')
    assert lt._get_value() == [1,4,6]

# Generated at 2022-06-22 06:32:24.462407
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(value = 1,start_index = 0, end_index = 0, content = None)
    assert type(token) is ScalarToken
    assert token._value == 1
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == None


# Generated at 2022-06-22 06:32:29.856186
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    x = Token(1, 1, 2)
    y = Token(2, 3, 4)
    z = Token(2, 3, 4)
    assert x != y
    assert y == z
# /Unit test for method __eq__ of class Token

# Generated at 2022-06-22 06:32:36.166166
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    from datetime import datetime
    from pytest import approx

    assert repr(Token(datetime(year=2019, month=4, day=4, hour=3, minute=2, second=1), 1, 2)) == "Token('2019-04-04T03:02:01')"
    assert repr(Token(1.2, 1, 2)) == "Token(1.2)"
    assert repr(Token(1, 1, 2)) == "Token(1)"
    assert repr(Token('a', 1, 2)) == "Token('a')"


# Generated at 2022-06-22 06:32:37.594532
# Unit test for constructor of class Token
def test_Token():
    # TODO: Add tests for this
    assert False


# Generated at 2022-06-22 06:32:38.611307
# Unit test for constructor of class Token
def test_Token():
    assert Token(0, 0, 0)

# Generated at 2022-06-22 06:32:48.798636
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    from typesystem.token import Token
    from typesystem.base import Position
    from typesystem.elements.scalars import String

    a = String()
    a._value = '"hello"'
    a._start_index = 0
    a._end_index = 5
    a._content = '"hello"'
    assert a.__repr__() == 'String("hello")'

    b = String()
    b._value = '"world"'
    b._start_index = 6
    b._end_index = 11
    b._content = '"hello" "world"'
    assert b.__repr__() == 'String("world")'



# Generated at 2022-06-22 06:32:50.680241
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken("value", 0, 0, "")
    assert hash(token) == hash("value")


# Generated at 2022-06-22 06:32:59.071541
# Unit test for constructor of class ListToken
def test_ListToken():
    from typesystem import String

    token_string = String('abc', position=Position(1, 1))

    # test that we can create a ListToken
    listToken_string = ListToken(value=[token_string], start_index=0, end_index=2)
    assert listToken_string.__repr__() == "ListToken([String('abc', position=(1, 1))])"

    # test that the ListToken is equal to a ListToken with the same value and position
    listToken_string_ = ListToken(value=[token_string], start_index=0, end_index=2)
    assert listToken_string == listToken_string_

    # test that the ListToken is not equal to a ListToken with a different value or position
    token_string = String('abc', position=Position(1, 1))
    listToken_

# Generated at 2022-06-22 06:33:11.174228
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token._Token__eq__(Token("", 0, 0), Token("", 0, 0)) == True
    assert Token._Token__eq__(Token("", 0, 1), Token("", 0, 0)) == False
    assert Token._Token__eq__(Token("", 0, 0), Token("", 1, 0)) == False
    assert Token._Token__eq__(Token("", 0, 0), Token("", 0, 1)) == False
    assert Token._Token__eq__(Token("", 1, 0), Token("", 0, 0)) == False
    assert Token._Token__eq__(Token("", 0, 0), Token("", 1, 1)) == False
    assert Token._Token__eq__(Token("", 0, 0), Token("", 1, 0)) == False

# Generated at 2022-06-22 06:33:31.156201
# Unit test for constructor of class ListToken
def test_ListToken():
    x = [1, '2', 3, 4]
    t = ListToken(x, 1,10)
    assert t._start_index == 1
    assert t._end_index == 10
    assert t._content == ''

# Generated at 2022-06-22 06:33:35.122020
# Unit test for constructor of class ListToken
def test_ListToken():
    l=[1,2,3,4,5]
    def token(value, start_index, end_index, content):
        return ListToken(value,start_index, end_index, content)
    assert token(l, 1, 1, "abc")

# Generated at 2022-06-22 06:33:37.945105
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """Test that the == operator works as expected."""
    str1 = '"go"'
    str2 = '"go"'
    assert str1 == str2


# Generated at 2022-06-22 06:33:46.458794
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken([ScalarToken(1, 0, 0), ScalarToken(2, 1, 1)], 0, 1)
    assert token.value == [1, 2]
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 2, 1)
    assert token.string == "[1,2]"
    assert token.lookup([0]) == ScalarToken(1, 0, 0)



# Generated at 2022-06-22 06:33:55.076647
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Test invalid types and values
    try:
        t = Token("test", 0, 0, "test").__repr__()
        assert False, "expected TypeError, but no exception was raised"
    except TypeError as e:
        assert "super-init" in str(e), "expected TypeError: super-init not called"
    except Exception as e:
        assert False, "expected TypeError, but received %s" % (str(e))
    else:
        assert False, "expected TypeError, but no exception was raised"

    # Test correct types/values
    t = ScalarToken("test", 0, 0, "test").__repr__()
    assert t == "ScalarToken('test')", "expected ScalarToken('test'), but received %s" % (t)


# Generated at 2022-06-22 06:34:06.741634
# Unit test for constructor of class Token
def test_Token():
    token = Token('', 1, 2, '')
    assert token._start_index == 1
    assert token._end_index == 2
    assert token._value == ''
    assert repr(token) == "Token('', 1, 2)"
    assert (token == Token('', 1, 2, '')) is True
    assert token.__hash__() == hash(token._value)
    with pytest.raises(NotImplementedError):
        token._get_value()
    with pytest.raises(NotImplementedError):
        token._get_child_token('')
    with pytest.raises(NotImplementedError):
        token._get_key_token('')
    assert token.string == ''
    assert token.value == ''
    assert token.start.line_no == 1

# Generated at 2022-06-22 06:34:13.593578
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert ScalarToken('a', 0, 1).__hash__() == hash('a')
    assert ScalarToken(100, 0, 2).__hash__() == hash(100)
    assert ScalarToken(None, 0, 1).__hash__() == hash(None)
    assert ScalarToken(True, 0, 4).__hash__() == hash(True)
    assert ScalarToken(False, 0, 5).__hash__() == hash(False)


# Generated at 2022-06-22 06:34:21.277336
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # Given an index, lookup a token for a dictionary key within this structure.
    # It returns a token for the key within the list
    token = ListToken([1, 2, 3, 4], 0, 5, content="[1, 2, 3, 4]")
    token1 = token.lookup_key([2])
    assert token1.string == "3"
    # It returns a token for the key within the dictionary
    token = DictToken({1: 1, 2: 2}, 0, 5, content='{"1": 1, 2: 2}')
    token1 = token.lookup_key([2])
    assert token1.string == '2: 2'
    # It returns a token for the key within the nested lists

# Generated at 2022-06-22 06:34:22.484349
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    pass

# Generated at 2022-06-22 06:34:34.018666
# Unit test for constructor of class Token
def test_Token():
    from typesystem import Token as Token_t
    t = Token_t
    t = Token_t()
    assert t.string == ""
    assert t.value == None
    t = Token_t(value=1, start_index=0, end_index=2)
    assert t.string == ""
    assert t.value == 1
    t = Token_t(value=1, start_index=0, end_index=2, content = "abc")
    assert t.string == "abc"
    assert t.value == 1
    t = Token_t(value=1, start_index=0, end_index=2, content="abc\n")
    assert t.string == "abc"
    assert t.value == 1

# Generated at 2022-06-22 06:36:24.724888
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    t = ScalarToken(str, 0, 1, content="a")
    assert hash(t) == hash(str)


# Generated at 2022-06-22 06:36:29.481896
# Unit test for constructor of class ListToken
def test_ListToken():

    list_token = ListToken(value=["list"], start_index=0, 
                           end_index=4, content="list")

    assert list_token.value == ["list"]
    assert list_token.start == Position(1, 1, 0)
    assert list_token.end == Position(1, 5, 4)
    assert list_token.string == 'list'

# Generated at 2022-06-22 06:36:31.727964
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken({}, 0, 0, "")
    assert t.string == ""
    assert t.value == {}



# Generated at 2022-06-22 06:36:33.620268
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    pass


# Generated at 2022-06-22 06:36:37.555262
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert "a" == "a"
    assert "a" != "b"
    assert "a" != 1
    assert "a" != object()
    assert "a" != 'a'
    assert "a" != b'a'

# Generated at 2022-06-22 06:36:39.432116
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    r = ScalarToken(1, 0, 0).__hash__()
    pass



# Generated at 2022-06-22 06:36:44.567668
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    s = "'this is a string' : 123"
    t1 = ScalarToken(value = 'this is a string', start_index = 0, end_index = 17)
    t2 = ScalarToken(value = 123, start_index = 19, end_index = 21)
    t3 = DictToken(value = {t1: t2})
    assert t3.lookup_key([0]) == t1
    return True



# Generated at 2022-06-22 06:36:54.805604
# Unit test for constructor of class Token
def test_Token():
    class TestClass(Token):
        def __init__(self, *args):
            super().__init__(*args)
    token = TestClass(value = 1, start_index = 2, end_index = 3, content = "abc")

    assert token.start == Position(line_no = 1, column_no = 1, index = 2)
    assert token.end == Position(line_no = 1, column_no = 1, index = 3)
    assert token.string == "c"
    assert token.value == 1

    # Test lookup function
    dic_token = DictToken(value = {'a': 1}, start_index = 0, end_index = 5, content = "a=1")

# Generated at 2022-06-22 06:36:57.191779
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    t = ScalarToken("test_value", 11, 14, "test_content")
    assert t.string == "val"
    assert t.value == "test_value"
    assert t.start == Position(1, 5, 11)
    assert t.end == Position(1, 8, 14)


# Generated at 2022-06-22 06:37:00.353242
# Unit test for constructor of class Token
def test_Token():
    t = Token(
        value = "",
        start_index = 0,
        end_index = 5,
        content = "First"
    )

# Generated at 2022-06-22 06:38:20.743146
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token(a, b, c, d)
    assert repr(token) == '%s(%s)' % (token.__class__.__name__, repr(token.string))


# Generated at 2022-06-22 06:38:23.394149
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    tok = Token(0, 0, 2, "abc")
    index = [1]
    assert tok.lookup_key(index) == tok



# Generated at 2022-06-22 06:38:27.591857
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    t = ListToken([ScalarToken(0, 0, 1, "0")], 0, 1, "0")
    assert t.lookup_key([0]) == t._value[0]

# Generated at 2022-06-22 06:38:29.516026
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token("value", 0, 1, "content")

    assert token.__eq__(token)



# Generated at 2022-06-22 06:38:32.909476
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    t = Token("", 1, 8, "rk")
    try:
        t.lookup_key("")
    except Exception as e:
        assert("NotImplementedError" in str(e))
    None


# Generated at 2022-06-22 06:38:35.035256
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    obj = ScalarToken(42, 0, 0)
    assert hash(obj) == hash(42)


# Generated at 2022-06-22 06:38:40.306524
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken({1:2, 3:4}, 0, 10, content="{1:2, 3:4}")
    assert dt._value == {1:2, 3:4}
    assert dt._child_keys == {1: 1, 3: 3}

#Unit test for constructor of class ListToken

# Generated at 2022-06-22 06:38:43.742878
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    value = 1
    start_index = 10
    end_index = 30
    content = ""
    token = Token(value, start_index, end_index, content)
    token.lookup_key([])

# Generated at 2022-06-22 06:38:55.289587
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class MyDictToken(DictToken):
        def _get_child_token(self, key: typing.Any) -> Token:
            return MyToken(key, 0, 0)

    class MyToken(ScalarToken):
        def _get_value(self) -> typing.Any:
            return self._content[self._start_index : self._end_index + 1]

    d = {
        MyToken("a", 0, 0): MyToken("b", 1, 1),
        MyToken("c", 2, 2): MyToken("d", 3, 3),
    }
    token = MyDictToken(d, 0, 3, content="abcd")
    assert token.lookup_key([0]) == MyToken("a", 0, 0)

# Generated at 2022-06-22 06:39:03.470218
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class DictToken(Token):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)
            self._child_keys = {k._value: k for k in self._value.keys()}
            self._child_tokens = {k._value: v for k, v in self._value.items()}

        def _get_value(self) -> typing.Any:
            return {
                key_token._get_value(): value_token._get_value()
                for key_token, value_token in self._value.items()
            }

        def _get_child_token(self, key: typing.Any) -> Token:
            return self._child_tokens[key]
