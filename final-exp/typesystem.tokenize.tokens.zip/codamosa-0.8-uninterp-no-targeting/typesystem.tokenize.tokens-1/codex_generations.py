

# Generated at 2022-06-22 06:29:10.173501
# Unit test for constructor of class Token
def test_Token():
    t=Token(0,0,0)
    assert t.string == ''

    t=Token(0,0,2,'123')
    assert t.string == '12'

    t=Token(0,0,3,'123')
    assert t.string == '123'

    t=Token(0,0,0,'')
    assert t.string == ''

    t=Token(0,0,1,'a')
    assert t.string == 'a'

    t=Token(0,1,1,'a')
    assert t.string == ''


# Generated at 2022-06-22 06:29:18.841792
# Unit test for method lookup of class Token
def test_Token_lookup():
    # Example
    scalar_token = ScalarToken(value='', start_index=0, end_index=0, content='')
    print(scalar_token)
    # Example
    scalar_token = ScalarToken(value='', start_index=0, end_index=0, content='')
    scalar_token.lookup(list())
    # Example
    scalar_token = ScalarToken(value='', start_index=0, end_index=0, content='')
    scalar_token.lookup(list())
    # Example
    scalar_token = ScalarToken(value='', start_index=0, end_index=0, content='')
    scalar_token.value
    # Example

# Generated at 2022-06-22 06:29:23.276921
# Unit test for method lookup of class Token
def test_Token_lookup():
    content = "a = 1\nb = 2\n"
    tokens = Tokenizer(content).parse()
    assert tokens.lookup([0]).value == "a"
    assert tokens.lookup([1]).value == "="
    assert tokens.lookup([2]).value == 1


# Generated at 2022-06-22 06:29:25.875815
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    t = Token(value = 42, start_index = 0, end_index = 1, content = "ab")
    assert repr(t) == "Token(\"a\")"

# Generated at 2022-06-22 06:29:33.145122
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken({"a": 1}, 0, 10)
    token = dict_token._get_child_token("a")
    assert isinstance(token, ScalarToken)

    dict_token2 = DictToken({"b": 2, "c": 3}, 0, 10)
    token2 = dict_token2._get_child_token("c")
    assert isinstance(token2, ScalarToken)


# Generated at 2022-06-22 06:29:41.298108
# Unit test for constructor of class DictToken
def test_DictToken():
    import sys
    import os
    import json

    # Get the absoulte path of the current working directory
    # abs_file_path = os.path.abspath(os.path.dirname('./tests/'))

    # Add the directory containing your module to the Python path (wants absolute paths)
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), os.path.pardir)))

    from tokens import DictToken
    DictToken_instance = DictToken()
    assert DictToken_instance



# Generated at 2022-06-22 06:29:44.834046
# Unit test for constructor of class DictToken
def test_DictToken():
    a = {"id": "omg", "o": "wow"}
    b = ["1"]
    c = DictToken(a, 0, 4, b)
    assert c._start_index == 0 and c._end_index == 4 and c._value == a


# Generated at 2022-06-22 06:29:51.905347
# Unit test for method lookup of class Token
def test_Token_lookup():
    class MockToken(Token):
        def _get_value(self) -> typing.Any: pass
        def _get_child_token(self, key: typing.Any) -> "Token": pass
        def _get_key_token(self, key: typing.Any) -> "Token": pass

    from typing import List
    #1.test lookup check if it return a child token
    token = MockToken(0,0,0)

# Generated at 2022-06-22 06:29:55.158088
# Unit test for constructor of class Token
def test_Token():
    token = Token(1, 1, 2)
    assert token._value == 1
    assert token._start_index == 1
    assert token._end_index == 2 


# Generated at 2022-06-22 06:30:02.964185
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token("value", 0, 1, content = "content")
    token2 = Token("value", 0, 1, content = "content")
    token3 = Token("value", 1, 2, content = "content")
    token4 = Token("value", 1, 2, content = "different")
    assert (token1 == token1) is True
    assert (token1 == token2) is True
    assert (token1 == token3) is False
    assert (token1 == token4) is False


# Generated at 2022-06-22 06:30:17.534363
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    t = Token("42", 10, 20)
    s = repr(t)
    assert s == "Token('42')"


# Generated at 2022-06-22 06:30:23.200309
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Default args
    token = Token("value", "start_index", "end_index")
    assert token.__repr__() == "Token('value')"
    # Non-default args
    token = Token("value", "start_index", "end_index", "content")
    assert token.__repr__() == "Token('value')"



# Generated at 2022-06-22 06:30:26.099913
# Unit test for constructor of class ListToken
def test_ListToken():
    l = [1, 2, 3]
    t = ListToken(l, 0, 0)


# Generated at 2022-06-22 06:30:28.449580
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    hashed = ScalarToken(123, 0, 0).__hash__()
    assert hashed is not None


# Generated at 2022-06-22 06:30:31.587241
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    t= ScalarToken(None, 1, 2)
    key = t.lookup_key([1,2,3])
    print(key)
# test_Token_lookup_key()


# Generated at 2022-06-22 06:30:39.497571
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    # Test type and all values of ScalarToken are correct
    token = ScalarToken(value = 10, start_index = 0, end_index = 3, content = "abc")
    assert isinstance(token, ScalarToken)
    assert token.value == 10
    assert token.string == "abc"
    assert token.start.line_no == 1
    assert token.start.column_no == 1
    assert token.start.index == 0
    assert token.end.line_no == 1
    assert token.end.column_no == 4
    assert token.end.index == 3


# Generated at 2022-06-22 06:30:45.745295
# Unit test for constructor of class DictToken
def test_DictToken():
    import typesystem
    import sys

    try:
        a = Token('hello',1,2,'hi my name is')
        t = a.__init__('hello',1,2,'hi my name is')

    except TypeError:
        print(sys.exc_info()[0])
        print('Function test_DictToken executed with error')

    else:
        print('Function test_DictToken executed with no error')


# Generated at 2022-06-22 06:30:56.319502
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = ListToken(
        [{"a" : "foo"}],
        start_index=0,
        end_index=13,
        content="[{'a': 'foo'}]",
    )

    assert token.lookup([0]) == DictToken(
        {"a": ScalarToken("foo", start_index=3, end_index=7, content="['a': 'foo']")},
        start_index=1,
        end_index=11,
        content="[{'a': 'foo'}]",
    )

    assert token.lookup([0, "a"]) == ScalarToken(
        "foo", start_index=3, end_index=7, content="['a': 'foo']"
    )


# Generated at 2022-06-22 06:31:02.017943
# Unit test for constructor of class Token
def test_Token():
    t = Token(value = None, start_index = 1, end_index = 2, content = "")
    assert t.string == ""
    assert t.value == None
    assert t.start.line_no == 1
    assert t.start.column_no == 1
    assert t.end.line_no == 1
    assert t.end.column_no == 2


# Generated at 2022-06-22 06:31:03.095862
# Unit test for method lookup of class Token
def test_Token_lookup():
    assert 1 == 1

# Generated at 2022-06-22 06:31:09.610715
# Unit test for constructor of class ListToken
def test_ListToken():
    t = ListToken()
    assert(t==None)
    
    
    
    


# Generated at 2022-06-22 06:31:20.688486
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    _start_index = 0
    _end_index = 1
    _content = "ciao"
    _content = "ciao"
    _content = "ciao"
    _content = "ciao"
    _content = "ciao"
    _content = "ciao"
    _content = "ciao"
    _content = "ciao"
    _content = "ciao"
    _content = "ciao"
    _content = "ciao"
    _content = "ciao"
    _content = "ciao"
    _content = "ciao"
    _content = "ciao"
    _content = "ciao"
    _content = "ciao"
    _content = "ciao"
    _content = "ciao"
    _content = "ciao"
    _content

# Generated at 2022-06-22 06:31:25.466080
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token("value", 0, 0)
    with pytest.raises(NotImplementedError):
        token.lookup("index")


# Generated at 2022-06-22 06:31:29.535756
# Unit test for constructor of class Token
def test_Token():
    token = Token(42, 5, 15, "55555555556666")
    assert token._value == 42
    assert token._start_index == 5
    assert token._end_index == 15
    assert token._content == "55555555556666"
    

# Generated at 2022-06-22 06:31:41.056801
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    s = "value"
    t1 = ScalarToken(s, 0, len(s))
    t2 = ScalarToken(s, 0, len(s))
    assert t1 == t2

    l1 = [ScalarToken(s, 0, len(s))]
    l2 = [ScalarToken(s, 0, len(s))]
    t1 = ListToken(l1, 0, 0)
    t2 = ListToken(l2, 0, 0)
    assert t1 == t2

    d1 = {ScalarToken(s, 0, len(s)): ScalarToken(s, 0, len(s))}
    d2 = {ScalarToken(s, 0, len(s)): ScalarToken(s, 0, len(s))}
    t1 = Dict

# Generated at 2022-06-22 06:31:44.493181
# Unit test for constructor of class DictToken
def test_DictToken():
    x = DictToken({'name': 'Joe'}, 0, 1)
    assert x.value == {'name': 'Joe'}

# Generated at 2022-06-22 06:31:48.054028
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    test = ScalarToken(value = None, start_index = 0, end_index = 0, content = "0")
    assert test._value == None
    assert test._start_index == 0
    assert test._end_index == 0
    assert test._content == "0"

# Generated at 2022-06-22 06:31:59.118964
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from antlr4 import CommonToken
    from typesystem.parser import lexer

    tokens = [
        (lexer.OBJECT_START, "{"),
        (lexer.STRING, '"foo"'),
        (lexer.COLON, ":"),
        (lexer.INTEGER, "1"),
        (lexer.OBJECT_END, "}"),
    ]
    token_stream = [CommonToken(tok_type, tok_text) for tok_type, tok_text in tokens]
    token = DictToken({token_stream[1]: token_stream[3]}, 0, 4, "".join(tok.text for tok in token_stream))
    assert token.value == {"foo": 1}
    assert token.start.index == 0

# Generated at 2022-06-22 06:32:10.527156
# Unit test for method lookup of class Token
def test_Token_lookup():
	token1 = 1
	token2 = 1
	token3 = 0	
	token4 = 1
	token5 = 1
	token6 = 1
	token7 = 1
	input_index1 = [0,0,0]
	input_index2 = [0,0,1]
	input_index3 = [0,0,2]
	input_index4 = [0,0,3]
	input_index5 = [1,0,0]
	input_index6 = [1,0,1]
	input_index7 = [1,0,2]
	assert (token1 == token2 and token2 == token4 and token4 == token5 and token5 == token6 and token6 == token7 )
	assert (token1 != token3)

# Generated at 2022-06-22 06:32:21.017489
# Unit test for constructor of class ListToken
def test_ListToken():
    from collections import OrderedDict
    from typing import Any, Dict
    from typesystem.types import (
        Array,
        Boolean,
        Dict,
        Integer,
        Object,
        String,
    )

    # Create a new OrderedDict for test case
    data = OrderedDict()
    # Sample data
    data["a"] = 1
    data["b"] = "abc"
    data["c"] = {"a": 1, "b": 2}
    data["d"] = [1, 2, 3]
    # Create typesystem schema

# Generated at 2022-06-22 06:32:30.828983
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert repr(Token()) == "Token()"


# Generated at 2022-06-22 06:32:36.357541
# Unit test for constructor of class ListToken
def test_ListToken():
    token1 = ScalarToken(value = 1, start_index = 0, end_index = 0, content = "")
    token2 = ScalarToken(value = 2, start_index = 0, end_index = 0, content = "")
    token3 = ScalarToken(value = 3, start_index = 0, end_index = 0, content = "")
    ListToken(value = [token1, token2, token3], start_index = 0, end_index = 0, content = "")


# Generated at 2022-06-22 06:32:43.504950
# Unit test for method lookup of class Token
def test_Token_lookup():
    content = "1234567890"
    token = ScalarToken(1, 0, 0, content=content)
    assert token.lookup([]) == token
    assert token.lookup([0]) == token
    assert token.lookup_key([]) == token
    assert token.lookup_key([0]) == token
    assert token.lookup_key([0, 0]) == token
    assert token.lookup_key([0, 0, 0]) == token



# Generated at 2022-06-22 06:32:48.118767
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken({1:2}, 3, 4, content="aaaaa")
    assert dict_token.start._index == 3
    assert dict_token.end._index == 4
    assert dict_token.string == "aaaaa"[3:5]

# Generated at 2022-06-22 06:32:55.424726
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    object_id_1 = object()
    token_1 = Token(object_id_1, 0, 1)

    object_id_2 = object()
    token_2 = Token(object_id_2, 2, 3)

    assert token_1 != token_2

    object_id_1 = object_id_2
    token_1 = Token(object_id_1, 0, 1)

    assert token_1 == token_2

    object_id_1 = object()
    token_1 = Token(object_id_1, 0, 1)

    assert token_1 != token_2


# Generated at 2022-06-22 06:32:59.880057
# Unit test for method lookup of class Token
def test_Token_lookup():
    assert Token(value="d1", start_index=1, end_index=1, content="d1").lookup([]) == Token(value="d1", start_index=1, end_index=1, content="d1")
    assert Token(value="d1", start_index=1, end_index=1, content="d1").lookup_key([0]) == Token(value="d1", start_index=1, end_index=1, content="d1")
    assert ScalarToken(value="d1", start_index=1, end_index=1, content="d1").lookup([]) == ScalarToken(value="d1", start_index=1, end_index=1, content="d1")

# Generated at 2022-06-22 06:33:03.647813
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(1, 1, 1, 'a')
    assert token._value == 1
    assert token._start_index == 1
    assert token._end_index == 1
    assert token._content == 'a'


# Generated at 2022-06-22 06:33:06.794010
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    s = ScalarToken(1, 0, 3)
    assert s._value == 1
    assert s._start_index == 0
    assert s._end_index == 3
    assert s._content == ""


# Generated at 2022-06-22 06:33:09.000584
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    obj = ScalarToken('a', 1, 2)
    assert isinstance(obj.__hash__(), int)



# Generated at 2022-06-22 06:33:17.000362
# Unit test for constructor of class Token
def test_Token():
    from typesystem.base import Position

    token = Token(1, 2, 3, "test")
    assert token.string == "test"
    assert token.value == 1
    assert token.start == Position(line_no=1, column_no=1, index=2)
    assert token.end == Position(line_no=1, column_no=1, index=3)
    assert token.lookup([]) == token
    assert token.lookup_key(["a"]) == token
    assert token.__repr__() == "Token(%s)" % repr("test")
    assert token == token


# Generated at 2022-06-22 06:33:30.545183
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    t = ScalarToken(3, 0, 1, content='3')
    assert t.string == '3'
    assert t.value == 3



# Generated at 2022-06-22 06:33:36.789004
# Unit test for constructor of class Token
def test_Token():
    token = Token('value', 1, 2, 'this')
    assert token._value == 'value'
    assert token._start_index == 1
    assert token._end_index == 2
    assert token._content == 'this'
    assert token.string == 'h'
    assert token.start.index == 1
    assert token.end.index == 2
    assert repr(token) == "Token('h')"


# Generated at 2022-06-22 06:33:38.842937
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token(value=1, start_index=0, end_index=1)
    assert repr(token) == "Token(1)"


# Generated at 2022-06-22 06:33:41.773627
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert repr(Token("", "", "", "")) == "Token('', '', '')"


# Generated at 2022-06-22 06:33:52.738959
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem import types, Schema

    class PersonSchema(Schema):
        first_name = types.String()
        last_name = types.String()

    class UserSchema(Schema):
        username = types.String()
        password = types.String()

    class ChildUserSchema(UserSchema):
        pass

    # Tests for DictToken
    assert DictToken({}, 0, 1)._value == {}
    assert DictToken({}, 0, 1, "")._value == {}
    assert DictToken({1: 2}, 0, 1)._value == {1: 2}
    assert DictToken({1: 2}, 0, 1, "")._value == {1: 2}
    assert DictToken({(1, 2): 3}, 0, 1)._value == {(1, 2): 3}

# Generated at 2022-06-22 06:33:59.078135
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    #setup
    listToken = [ScalarToken(1,1,1)]
    listToken.append(ScalarToken(2,2,2))
    listToken.append(ScalarToken(3,3,3))
    token = ListToken(listToken,0,2)
    #test
    assert token.lookup_key([0]) == ScalarToken(1,1,1)


# Generated at 2022-06-22 06:34:10.937945
# Unit test for constructor of class Token
def test_Token():
    t_object=Token(1,2,3)
    assert t_object.start.line_no == 1
    assert t_object.start.column_no == 2
    assert t_object.end.line_no == 1
    assert t_object.end.column_no == 3
    assert str(t_object) == "Token(1)"
    dictionary = {'a':1,'b':2,'c':3}
    dict_t = DictToken(dictionary,0,8,"{'a':1,'b':2,'c':3}")
    assert dict_t.string == "{'a':1,'b':2,'c':3}"
    assert dict_t.value == {'a':1,'b':2,'c':3}
    assert dict_t.start.line_no == 1
    assert dict_

# Generated at 2022-06-22 06:34:17.146071
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    v = "test"
    t = ScalarToken(v, 0, 0)
    assert t.string == v
    assert t.value == v
    assert t.start.line == 1
    assert t.start.column == 1
    assert t.start.index == 0
    assert t.end.line == 1
    assert t.end.column == 1
    assert t.end.index == 0

# Generated at 2022-06-22 06:34:18.178639
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(2, 3, 4)
    hash_token = hash(token)


# Generated at 2022-06-22 06:34:19.709464
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    assert True

# Generated at 2022-06-22 06:35:13.730993
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    is_instance = isinstance
    scalar_token = ScalarToken
    value = 'aaa'
    start_index = 1
    end_index = 3
    content = 'bbb'
    t = scalar_token(value, start_index, end_index, content)
    assert is_instance(t, scalar_token)
    assert t.string == 'aaa'
    assert t.value == 'aaa'
    assert t.start == Position(1, 1, 1)
    assert t.end == Position(1, 4, 3)
    assert t.__repr__() == "ScalarToken('aaa')"


# Generated at 2022-06-22 06:35:21.832036
# Unit test for constructor of class ListToken
def test_ListToken():
    from typesystem.base import PositionalToken
    from typesystem.base import StringToken
    s = StringToken('x', 0, 2, '100')
    l = ListToken([s], 0, 2, '100')

    assert(s._start_index == 0)
    assert(s._end_index == 2)
    assert(s._content == '100')
    assert(l._start_index == 0)
    assert(l._end_index == 2)
    assert(l._content == '100')


# Generated at 2022-06-22 06:35:32.950794
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class TestToken(Token):
        def _get_value(self) -> typing.Any:
            return 0
        def _get_child_token(self, key: typing.Any) -> Token:
            return TestToken(0, *self.start, self.string)
        def _get_key_token(self, key: typing.Any) -> Token:
            return TestToken(0, *self.start, self.string)
    test_token = TestToken(0, 1, 2, "test")
    assert test_token.value == 0
    assert test_token.string == "test"
    assert test_token.start == Position(1, 1, 1)
    assert test_token.end == Position(1, 2, 2)


# Generated at 2022-06-22 06:35:38.112978
# Unit test for constructor of class DictToken
def test_DictToken():
    value = {0: 1, 1: 2}
    dt = DictToken(value, 0, 10)
    assert dt._get_value() == value
    assert dt._start_index == 0
    assert dt._end_index == 10


# Generated at 2022-06-22 06:35:40.484969
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert Token(None, 0, 0) == Token(None, 0, 0)
test_Token___repr__()


# Generated at 2022-06-22 06:35:48.372378
# Unit test for constructor of class Token
def test_Token():
    int_5 = ScalarToken(5, 5, 0, content="5")
    assert(type(int_5._value) == type(5))
    assert(int_5._start_index == 5)
    assert(int_5._end_index == 0)
    assert(int_5._content == "5")
    assert(int_5._get_position(0) == Position(1, 1, 0))
    assert(int_5._get_position(1) == Position(1, 2, 1))
    assert(int_5._get_position(2) == Position(1, 3, 2))
    assert(int_5._get_position(3) == Position(2, 1, 3))
    assert(int_5._get_position(4) == Position(3, 1, 4))


# Generated at 2022-06-22 06:35:53.822078
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(
        {'key': 'value'},
        start_index=0, end_index=5, content="key: value"
    )
    assert token._value == {'key': 'value'}
    assert token._start_index == 0
    assert token._end_index == 5
    assert token._content == "key: value"


# Generated at 2022-06-22 06:35:55.741679
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    t = Token('t',5,5)
    assert t.lookup_key() == t

# Generated at 2022-06-22 06:36:08.187180
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class DictObject:
        def __init__(self, value: typing.Dict):
            self._value = value

        @classmethod
        def _get_token(cls, start_index: int, end_index: int) -> typing.Any:
            return DictToken(
                {
                    ScalarToken(str(_key), start_index, end_index): ScalarToken(
                        _value, start_index, end_index
                    )
                    for _key, _value in self._value.items()
                },
                start_index,
                end_index,
            )

    # Returns a token for the key
    d = DictObject({"a": 0, "b": 1})
    assert d.lookup_key([]) == d

# Generated at 2022-06-22 06:36:18.305891
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Create a valid object of class Token
    # which does not have any attributes
    token = Token(
        value = "",
        start_index = 0,
        end_index = 0,
        content = ""
    )
    # Call function __repr__
    # and compare the result with the expected one
    assert(token.__repr__() == "Token('')")
    # Check the validity of the object
    assert(token.value == "")
    assert(token.start == Position(1, 1, 0))
    assert(token.end == Position(1, 1, 0))
    assert(token.lookup([]) == token)
    assert(token.lookup_key([]) == token)


# Generated at 2022-06-22 06:37:07.103790
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    repr_ = repr(Token(42, 1, 2))
    assert repr_ == "Token(42)"


# Generated at 2022-06-22 06:37:16.494137
# Unit test for method lookup of class Token
def test_Token_lookup():
    import collections
    import typesystem
    schema = typesystem.Schema(
        {"name": typesystem.String(), "age": typesystem.Integer()}
    )
    parsed_data = schema.parse({"name": "John Doe", "age": "42"})
    errors = schema.validate(parsed_data)
    assert len(errors) == 1
    error = errors[0]
    assert isinstance(error["token"], Token)
    assert error["token"].string == "42"
    assert error["token"].start.line == 1
    assert error["token"].start.column == 14
    assert error["token"].start.index == 13
    assert error["token"].end.line == 1
    assert error["token"].end.column == 16
    assert error["token"].end.index == 15

# Generated at 2022-06-22 06:37:27.894126
# Unit test for constructor of class DictToken
def test_DictToken():
	import typesystem.token
	class Token:
		def __init__(self, *args, **kwargs) -> None:
			self._value = '1'
			self._start_index = 1
			self._end_index = 1
			self._content = '1'
		@property
		def value(self):
			return self._value
		def _get_value(self) -> typing.Any:
			raise NotImplementedError # pragma: nocover
		def _get_child_token(self, key: typing.Any) -> Token:
			raise NotImplementedError # pragma: nocover
		def _get_key_token(self, key: typing.Any) -> Token:
			raise NotImplemented

# Generated at 2022-06-22 06:37:30.902508
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = Token(str, 0, 2, "hello")
    assert token.lookup_key([]) == token
    assert token.lookup_key([0]) == token


# Generated at 2022-06-22 06:37:37.430453
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert repr(ScalarToken("foo", 0, 2)) == "ScalarToken('foo')"
    assert repr(ListToken([ScalarToken("foo", 0, 2), ScalarToken("bar", 4, 6)], 0, 6)) == "ListToken(['foo', 'bar'])"
    assert repr(DictToken({ScalarToken("foo", 0, 2): ScalarToken("bar", 4, 6)}, 0, 6)) == "DictToken({'foo': 'bar'})"


# Generated at 2022-06-22 06:37:42.770016
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    from typesystem.base import ScalarType
    st = ScalarToken(ScalarType(int),0,0)
    assert st.string == ""
    assert st.value == None
    assert st.start == Position(1,1,0)
    assert st.end == Position(1,1,0)

# Generated at 2022-06-22 06:37:51.569908
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = ListToken(
        [
            DictToken(
                {
                    ScalarToken("x", 0, 0): ScalarToken(1, 3, 3),
                    ScalarToken("y", 7, 7): ScalarToken(2, 10, 10),
                },
                0,
                15,
                content="{'x': 1, 'y': 2}",
            )
        ],
        0,
        16,
        content="[{'x': 1, 'y': 2}]",
    )
    assert token.lookup([0, 0])._get_value() == {"x": 1, "y": 2}


# Generated at 2022-06-22 06:37:55.185347
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    input_token = Token('value', 0, 1, content='')
    expected_output = "Token('value', 0, 1, content='')"
    actual_output = repr(input_token)
    assert actual_output == expected_output


# Generated at 2022-06-22 06:38:02.114947
# Unit test for method lookup of class Token
def test_Token_lookup():
    from io import StringIO
    from typesystem.parsers import parse_string

    token = parse_string(
        StringIO(
            """
        {
            "foo": [
                123,
                {
                    "bar": [456, 789]
                }
            ]
        }
        """
        )
    )
    assert token.lookup([0, 0]).value == 123
    assert token.lookup([0, 1, 0]).value == 456

# Generated at 2022-06-22 06:38:04.428610
# Unit test for constructor of class DictToken
def test_DictToken():
    d_t = DictToken({}, 1, 2, "")
    assert d_t is not None
