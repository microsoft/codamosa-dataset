

# Generated at 2022-06-22 06:29:09.263191
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token("test", 10, 20)
    assert token.__repr__() == "Token(\"test\")"


# Generated at 2022-06-22 06:29:12.513311
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
  assert ScalarToken(None, 0, 0).__hash__() == hash(None)
  assert ScalarToken("foo", 0, 3).__hash__() == hash("foo")


# Generated at 2022-06-22 06:29:23.621437
# Unit test for constructor of class Token
def test_Token():
    value = "f"
    start_index = 1
    end_index = 1
    content = "f"
    token = Token(value, start_index, end_index)
    assert token.string == "f"
    assert token.value == "f"
    assert token.start == Position(1, 1, 1)
    assert token.end == Position(1, 1, 1)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert token._get_position(start_index) == Position(1, 1, 1)
    assert token == ScalarToken("f", 1, 1)
    assert isinstance(token, Token)
    assert repr(token) == "Token('f')"
    assert token._get_value() == "f"



# Generated at 2022-06-22 06:29:30.450982
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    obj = ScalarToken('', 0, 0)
    obj1 = ScalarToken('', 0, 0)
    assert obj == obj1, "must be equal"
    assert hash(obj) == hash(obj1), "hash must be equal"
    assert hash(obj) == hash(''), "hash must be equal"
    obj2 = ScalarToken('', 1, 1)
    assert obj != obj2, "must be not equal"
    assert hash(obj) != hash(obj2), "hash must be not equal"

# Generated at 2022-06-22 06:29:33.414832
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    print("test_ScalarToken___hash__")
    instance = ScalarToken("hello", 0, 4)
    assert hash(instance) == hash("hello")



# Generated at 2022-06-22 06:29:38.404023
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    from typesystem.base import String

    string = String(name="string")
    token = ScalarToken(string.decode("foo"), 0, 2, "foo")
    assert hash(token) == -8957016885447544245



# Generated at 2022-06-22 06:29:42.892804
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    start_index = 0
    end_index = 0
    value = None
    token = Token(value, start_index, end_index)

    assert "Token" in repr(token)
    assert "None" in repr(token)


# Generated at 2022-06-22 06:29:46.558174
# Unit test for constructor of class ListToken
def test_ListToken():
    l = ListToken(
        [1, 2, 3, 4],
        start_index = 0,
        end_index = 3,
        content = "[1,2,3,4]"
    )


# Generated at 2022-06-22 06:29:51.227658
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    st = ScalarToken(1, 2, 3)
    assert st._value == 1
    assert st._start_index == 2
    assert st._end_index == 3
    assert st.start.index == 2
    assert st.end.index == 3
    assert st.string == ''


# Generated at 2022-06-22 06:30:03.441293
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    a = ScalarToken(value=1, start_index=0, end_index=1)
    assert a._value == 1
    assert a._start_index == 0
    assert a._end_index == 1
    assert a._content == ""
    assert a.string == ""
    assert a.value == a._get_value()
    assert a.start == Position(1, 1, 0)
    assert a.end == Position(1, 1, 1)
    assert a.lookup(index=[]) == a
    assert a.lookup_key(index=[]) == a
    assert a.__repr__() == "ScalarToken('', 1)"
    assert a.__eq__(a) == True

    b = ScalarToken(value="A", start_index=0, end_index=1, content="AB")

# Generated at 2022-06-22 06:30:08.527517
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken([],0,0)


# Generated at 2022-06-22 06:30:20.465954
# Unit test for constructor of class Token
def test_Token():
    # Test normal cases
    t_1 = Token(value="a", start_index=0, end_index=2)
    t_2 = Token(value=1, start_index=0, end_index=2)
    t_3 = Token(value=1.1, start_index=0, end_index=2)
    t_4 = Token(value=True, start_index=0, end_index=2)
    t_5 = Token(value=[1], start_index=0, end_index=2)
    t_6 = Token(value={1:"a"}, start_index=0, end_index=2)
    assert t_1.value == "a"
    assert t_2.value == 1
    assert t_3.value == 1.1
    assert t_4.value == True
   

# Generated at 2022-06-22 06:30:31.928771
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert ScalarToken(1, 0, 1, "12") == ScalarToken(1, 0, 1, "12")
    assert ScalarToken(1, 0, 1, "12") != ScalarToken(2, 0, 1, "12")
    assert ScalarToken(1, 0, 1, "12") != ScalarToken(2, 0, 2, "12")
    assert ScalarToken(1, 0, 1, "12") != ScalarToken(2, 0, 1, "12")
    assert ScalarToken(1, 0, 1, "12") != ScalarToken(2, 1, 0, "12")
    assert ScalarToken(1, 0, 1, "12") != ScalarToken(2, 0, 1, "123")
    assert ScalarToken(1, 0, 1, "12") != ScalarToken

# Generated at 2022-06-22 06:30:36.934917
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = DictToken({'a': 1, 'b':2, 3: 'c'})
    token2 = DictToken({'a': 1, 'b':2, 3: 'c'})
    assert (token1 == token2)
    assert (token1 == token1)

# Generated at 2022-06-22 06:30:41.711616
# Unit test for method lookup of class Token
def test_Token_lookup():
    start_index = 0
    end_index = 0
    child_token = ScalarToken("b", start_index, end_index)
    token = DictToken({"a": child_token}, start_index, end_index)
    assert token.lookup([0]) is child_token



# Generated at 2022-06-22 06:30:43.376009
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken({})


# Generated at 2022-06-22 06:30:45.400336
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token('', 1, 2, '')
    assert repr(token) == "Token('')"

# Generated at 2022-06-22 06:30:56.418351
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    """Unit test for method __hash__ of class ScalarToken"""
    from typing import List, Dict
    from collections import Counter
    from random import randint, random
    from hakaton.types import Token

    # we are going to test the hash value of ScalarTokens of different types
    # construct a list of ScalarTokens for each type
    scalar_tokens_list_int = [randint(0, 10000) for i in range(100)]
    scalar_tokens_list_float = [random() for i in range(100)]
    scalar_tokens_list_bool = [bool(randint(0, 1)) for i in range(100)]

# Generated at 2022-06-22 06:31:04.095253
# Unit test for method lookup of class Token
def test_Token_lookup():
    input_value = [
        {
            "a": {
                "b": {
                    "c": {"d": 4},
                    "e": [{"f": 5}, {"g": 6}],
                    "h": [1, 2, 3],
                },
                "i": 7,
            }
        }
    ]
    content = "hello world"
    start_index = 0
    end_index = 11
    token = ListToken(input_value, start_index, end_index, content)
    assert [token.lookup([0, "a", "i"]).value] == [7]



# Generated at 2022-06-22 06:31:12.440582
# Unit test for constructor of class Token
def test_Token():
    # Token(self, value: typing.Any, start_index: int, end_index: int, content: str = "")
    # -> None
    token = Token("1", 0, 2)
    assert token.value == "1"
    assert token.start.line_no == 1
    assert token.start.column_no == 1
    assert token.start.index == 0
    assert token.end.line_no == 1
    assert token.end.column_no == 3
    assert token.end.index == 2


# Generated at 2022-06-22 06:31:38.403284
# Unit test for constructor of class Token
def test_Token():
    value = "mock"
    start_index = 3
    end_index = 4
    content = "mock_content"
    token = Token(value, start_index, end_index, content)
    value_ret = token._get_value()
    assert value == value_ret
    start_ret = token.start
    assert start_ret.line == 1
    assert start_ret.column == 4
    assert start_ret.index == 3
    end_ret = token.end
    assert end_ret.line == 1
    assert end_ret.column == 5
    assert end_ret.index == 4


# Generated at 2022-06-22 06:31:48.566046
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    a = 123
    b = '3.14'
    c = 'foo'
    token_a = ScalarToken(a, 0, 2)
    token_b = ScalarToken(b, 0, 2)
    token_c = ScalarToken(c, 0, 2)
    token_d = ScalarToken(a, 0, 2)
    assert hash(token_a) == hash(a)
    assert hash(token_b) == hash(b)
    assert hash(token_c) == hash(c)
    assert hash(token_a) == hash(token_d)
    assert hash(token_a) != hash(token_b)
    assert hash(token_a) != hash(token_c)
    assert hash(token_b) != hash(token_c)

# Generated at 2022-06-22 06:31:50.812716
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = ScalarToken(2, 3, 5)
    assert token.lookup_key([0]) == token

# Generated at 2022-06-22 06:31:58.468258
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.base import Position
    from typesystem.base import Token
    import typing

    class TestToken(Token):

        ...

    test_token = TestToken(
        value=typing.Any(),
        start_index=int(),
        end_index=int(),
        content="",
    )
    other = TestToken(
        value=typing.Any(),
        start_index=int(),
        end_index=int(),
        content="",
    )

    assert test_token == other



# Generated at 2022-06-22 06:32:06.235451
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert not (Token(None, 0, 0) == None)
    assert Token(None, 0, 0) == Token(None, 0, 0)
    assert not (Token(None, 0, 0) == Token(None, 1, 0))
    assert not (Token(None, 0, 0) == Token(None, 0, 1))
    assert not (Token(None, 0, 0) == Token(None, 1, 1))



# Generated at 2022-06-22 06:32:08.360508
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = ScalarToken("test", 0, 3, "test")
    assert token.lookup_key([]) == token



# Generated at 2022-06-22 06:32:16.075858
# Unit test for method __eq__ of class Token
def test_Token___eq__():

    token1 = ScalarToken(1, 0, 1)
    token2 = ScalarToken(2, 2, 3)
    assert (not (token1 == token2))

    token1 = ScalarToken(1, 0, 1)
    token2 = ScalarToken(1, 0, 2)
    assert (not (token1 == token2))

    token1 = ScalarToken(1, 0, 1)
    token2 = ScalarToken(1, 0, 1)
    assert (token1 == token2)


# Generated at 2022-06-22 06:32:17.824219
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken()
    assert dict_token


# Generated at 2022-06-22 06:32:27.283325
# Unit test for constructor of class Token
def test_Token():
    test_token = Token("1", 2, 3, "123")
    assert test_token.string == "2"
    assert test_token.value == "1"
    assert test_token.start.line_no == 1
    assert test_token.start.column_no == 2
    assert test_token.start.index == 1
    assert test_token.end.line_no == 1
    assert test_token.end.column_no == 3
    assert test_token.end.index == 2
    assert test_token.lookup([2]) == test_token._get_child_token(2)
    assert test_token.lookup_key([2, 1]) == test_token._get_key_token(1)



# Generated at 2022-06-22 06:32:36.541212
# Unit test for constructor of class DictToken
def test_DictToken():
    token_1 = ScalarToken(value="one", start_index=0, end_index=3)
    expected_child_tokens = {token_1._value: token_1}
    token_2 = ScalarToken(value="two", start_index=5, end_index=8)
    expected_child_tokens[token_2._value] = token_2
    expected_child_keys = {k._value: k for k in expected_child_tokens.keys()}
    expected_value = {token_1: token_2}
    expected_start_index = token_1._start_index
    expected_end_index = token_2._end_index
    expected_content = ""

# Generated at 2022-06-22 06:32:42.123709
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    c = Token(123,0,4,content="test")
    assert repr(c) == "Token('test')"


# Generated at 2022-06-22 06:32:54.033746
# Unit test for constructor of class ListToken
def test_ListToken():
    class FooToken(Token):
        def __init__(self, value: typing.Any, start_index: int, end_index: int, content: str = ""):
            super().__init__(value, start_index, end_index, content)
    foo_token1 = FooToken('foo1', 1, 2, 'abc')
    foo_token2 = FooToken('foo2', 1, 2, 'abc')
    foo_token3 = FooToken('foo3', 1, 2, 'abc')
    list_token = ListToken([foo_token1, foo_token2, foo_token3], 1, 4, 'abc')
    assert list_token._get_child_token(0).__eq__(foo_token1)
    assert list_token._get_child_token(1).__eq__(foo_token2)

# Generated at 2022-06-22 06:32:57.797061
# Unit test for constructor of class ListToken
def test_ListToken():
    l = [1, 2, 3]
    try:
        t = ListToken(l, 0, 10, '123')
        print(t)
    except Exception as e:
        print(e)


test_ListToken()

# Generated at 2022-06-22 06:33:01.375777
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("test", 1, 4)
    print("test_ScalarToken:")
    print("Token:", token)
    print("Value:", token.value)
    print("String:", token.string)


# Generated at 2022-06-22 06:33:03.039231
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    val_1: Token = Token(1, 1, 2)
    assert repr(val_1) == "Token('1')"



# Generated at 2022-06-22 06:33:06.250482
# Unit test for constructor of class ListToken
def test_ListToken():
    listt = ListToken(["abc"], 0, 0, "")
    expected = ["abc"]
    actual = listt.value
    assert (actual == expected)


# Generated at 2022-06-22 06:33:12.135997
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(value = 1, start_index = 5, end_index = 9)
    assert token.value == 1, "False value"
    assert token.start == Position(6, 0, 5), "False start"
    assert token.end == Position(6, 0, 9), "False end"
    assert token.string == '', "False string"


# Generated at 2022-06-22 06:33:13.623923
# Unit test for method __repr__ of class Token
def test_Token___repr__(): # noqa
    assert repr(Token("", 0, 0)) == "Token('')"


# Generated at 2022-06-22 06:33:16.739717
# Unit test for constructor of class DictToken
def test_DictToken():
    try:
        _ = DictToken("value", "start_index", "end_index", "content")
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-22 06:33:20.221294
# Unit test for constructor of class ListToken
def test_ListToken():
    test_tokens = ListToken('a', 1, 3, 'abc')
    assert test_tokens._get_value() == ['a']


# Generated at 2022-06-22 06:33:26.502918
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(1, 0, 0)

    assert hash(token) == 1



# Generated at 2022-06-22 06:33:34.676094
# Unit test for constructor of class ListToken
def test_ListToken():
    value = ['Hello', 'World']
    start_index = 0
    end_index = 10
    content = 'Hello World'
    a = ListToken(value, start_index, end_index, content)
    assert a._value == ['Hello', 'World']
    assert a._start_index == 0
    assert a._end_index == 10
    assert a._content == 'Hello World'
    assert not hasattr(a, "_child_keys")
    assert not hasattr(a, "_child_tokens")


# Generated at 2022-06-22 06:33:39.213512
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    my_token = ScalarToken(value = "fsf", start_index = 0, end_index = 1)
    assert my_token.string == 'f'
    assert my_token.value == 'f'
    assert my_token.start == Position(1, 1, 0)
    assert my_token.end == Position(1, 2, 1)


# Generated at 2022-06-22 06:33:47.388549
# Unit test for constructor of class ListToken
def test_ListToken():
    args = ('value', 4, 17)
    kwargs = {'content':'A string'}
    token = ListToken(*args, **kwargs)
    assert len(args) == 3
    assert len(kwargs) == 1
    assert token._value == 'value'
    assert token._start_index == 4
    assert token._end_index == 17
    assert token._content == 'A string'
    assert token.string == 'ing'
    assert token.value == ['value']
    assert token.start.line_no == 1
    assert token.start.column_no == 5
    assert token.start.index == 4
    assert token.end.line_no == 1
    assert token.end.column_no == 8
    assert token.end.index == 17

# Generated at 2022-06-22 06:33:53.688740
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
  t = ScalarToken(value=1, start_index=0, end_index=1)
  t.__repr__() == "ScalarToken('1')"
  t._get_value() == 1
  t.__eq__(1) == False
  t.__eq__(ScalarToken(value=1, start_index=0, end_index=1)) == True
  t.__eq__(ScalarToken(value=2, start_index=0, end_index=1)) == False
  t.__hash__() == hash(1)


# Generated at 2022-06-22 06:34:02.735814
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3, "content") == Token(1, 2, 3, "content")
    assert not (Token(1, 2, 3, "content") == Token(2, 2, 3, "content"))
    assert not (Token(1, 2, 3, "content") == Token(1, 3, 3, "content"))
    assert not (Token(1, 2, 3, "content") == Token(1, 2, 4, "content"))
    assert not (Token(1, 2, 3, "content") == ScalarToken(1, 2, 3, "content"))
    

# Generated at 2022-06-22 06:34:13.686389
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(0, 0, 0) == Token(0, 0, 0)
    assert Token(20, 1, 5) == Token(20, 1, 5)
    assert Token(21, 11, 17) == Token(21, 11, 17)
    assert Token(22, 21, 27) == Token(22, 21, 27)
    assert Token(23, 31, 37) == Token(23, 31, 37)
    assert Token(24, 41, 47) == Token(24, 41, 47)
    assert Token(25, 51, 57) == Token(25, 51, 57)
    assert Token(26, 61, 67) == Token(26, 61, 67)
    assert Token(27, 71, 77) == Token(27, 71, 77)
    assert Token(28, 81, 87) == Token(28, 81, 87)

# Generated at 2022-06-22 06:34:16.036550
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert Token(None, 0, None).__repr__() == "Token('None')"

# Generated at 2022-06-22 06:34:20.781905
# Unit test for constructor of class Token
def test_Token():
    assert Token(1, 1, 3, "content")._value == 1
    assert Token(1, 1, 3, "content")._start_index == 1
    assert Token(1, 1, 3, "content")._end_index == 3
    assert Token(1, 1, 3, "content")._content == "content"


# Generated at 2022-06-22 06:34:27.901380
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken(
        value=[],
        start_index=0,
        end_index=1,
        content="[{}"
    )
    
    assert hasattr(token, 'string')
    assert hasattr(token, 'value')
    assert hasattr(token, 'start')
    assert hasattr(token, 'end')
    assert token.string == "[{}"
    assert token.value == []



# Generated at 2022-06-22 06:34:34.607923
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
  pass



# Generated at 2022-06-22 06:34:38.917027
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    s = Token(None, 0, 4, "\n  \tAaBb\n  ")
    assert repr(s) == "Token('\n  \tAaBb\n  ')"



# Generated at 2022-06-22 06:34:41.399626
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    a = ScalarToken(3, 0, 0)
    assert a._value == 3
    assert a.value == 3


# Generated at 2022-06-22 06:34:45.051503
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Setup
    value = __
    start_index = 0
    end_index = 3
    # Exercise
    actual = Token.__repr__(value, start_index, end_index)
    # Verify
    expected = "Token('')"
    assert actual == expected

# Generated at 2022-06-22 06:34:51.395022
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken(
        [1, 2, 3], start_index=0, end_index=2, content=''
    )
    assert token._value == [1, 2, 3]
    assert token._start_index == 0
    assert token._end_index == 2
    assert token._content == ''
    assert token.string == ''
    assert token.value == [1, 2, 3]
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 4, 2)



# Generated at 2022-06-22 06:34:55.665015
# Unit test for constructor of class Token
def test_Token():
    from typesystem import String, Number, Boolean, Array

    token = Token(String, 0, 2)

    assert token._value == String
    assert token._start_index == 0
    assert token._end_index == 2
    assert token._content == ""


# Generated at 2022-06-22 06:35:04.630673
# Unit test for constructor of class DictToken
def test_DictToken():
    a = ScalarToken(1,0,0)
    b = ScalarToken(2,0,0)
    c = ScalarToken(3,0,0)
    d = DictToken({a:b, b:c},0,0)
    assert d._child_keys =={1:a, 2:b}
    assert d._child_tokens == {1: b, 2: c}
    assert d.lookup_key([1,2]) == a
    assert d.lookup([1]) == b
    assert d.lookup([2]) == c

# Generated at 2022-06-22 06:35:12.225454
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class TokenSubclass(Token):
        pass
    a = TokenSubclass('value', 0, 2)
    b = TokenSubclass('value', 0, 2)
    assert a.__eq__(b.__eq__(b))
    assert a.__eq__(TokenSubclass('value2', 0, 2)) is False
    assert a.__eq__(TokenSubclass('value', 1, 2)) is False
    assert a.__eq__(TokenSubclass('value', 0, 3)) is False



# Generated at 2022-06-22 06:35:14.151336
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert hash(ScalarToken(1, 0, 0, content='abc')) == hash(1)



# Generated at 2022-06-22 06:35:20.925426
# Unit test for constructor of class ListToken
def test_ListToken():
    # Dummy arguments
    value = ["test"]
    start_index = 10
    end_index = 100
    content = "dummy"
    # Assert that no exception is raised when a new ListToke instance is created
    l = ListToken(value, start_index, end_index, content)
    # Assert that the ListToke instance is not None
    assert l


# Generated at 2022-06-22 06:35:31.878033
# Unit test for constructor of class Token
def test_Token():
    a = Token(1,1,1)
    b = Token(2,2,2)
    assert a._get_value() == 1
    assert a._start_index == 1
    assert a._end_index == 1
    assert b._get_value() == 2
    assert b._start_index == 2
    assert b._end_index == 2


# Generated at 2022-06-22 06:35:36.002286
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    st = ScalarToken(value='foo', start_index=0, end_index=2)
    assert st.string == 'foo'
    assert st.value == 'foo'


# Generated at 2022-06-22 06:35:43.089922
# Unit test for constructor of class Token
def test_Token(): # type: ignore
    token = Token(
        value=0,
        start_index=0,
        end_index=1,
        content="test"
    )
    assert token.string == "t"
    assert token.value == 0
    assert token.start.line_no == 1
    assert token.start.column_no == 1
    assert token.start.offset == 0
    assert token.end.line_no == 1
    assert token.end.column_no == 2
    assert token.end.offset == 1

# Generated at 2022-06-22 06:35:47.305110
# Unit test for constructor of class Token
def test_Token():
    token = Token("a", 0, 0, "a")
    assert token.string == "a"
    assert token.value == "a"
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token


# Generated at 2022-06-22 06:35:49.331001
# Unit test for constructor of class ListToken
def test_ListToken():
    assert token._get_value() == [token._get_value() for token in self._value]

# Generated at 2022-06-22 06:35:52.249168
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(value={}, start_index=0, end_index=1, content="")
    assert isinstance(token, Token)


# Generated at 2022-06-22 06:35:58.203558
# Unit test for constructor of class DictToken
def test_DictToken():
    """
    >>> t = DictToken({'a': ScalarToken(12, 100, 101)}, 0, 100)
    >>> assert t._child_keys == {'a': ScalarToken('a', 100, 101)}
    >>> assert t._child_tokens == {'a': ScalarToken(12, 100, 101)}
    """



# Generated at 2022-06-22 06:36:10.363359
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    code = "abc"
    start_index = 0
    end_index = 2
    t = Token(start_index, end_index, code)
    assert t._content == code, "Fail to create Token"
    assert t._start_index == start_index, "Fail to create Token"
    assert t._end_index == end_index, "Fail to create Token"
    assert t.start.index == start_index, "Fail to create Token"
    assert t.end.index == end_index, "Fail to create Token"
    assert t.string == code, "Fail to create Token"
    t2 = ScalarToken(12, 1, 3, code)
    assert t2._get_value() == 12, "Fail to create ScalarToken"
    assert t2._content == code, "Fail to create ScalarToken"


# Generated at 2022-06-22 06:36:15.028722
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.base import Position
    from typesystem.structures import DictToken
    from typesystem.structures import ListToken
    from typesystem.structures import ScalarToken
    
    assert isinstance(Token(None, None, None).__eq__(Token(None, None, None)), bool)


# Generated at 2022-06-22 06:36:24.121066
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token(value="my string value", start_index=1, end_index=10, content="My content")
    print("\nToken object")
    print("token._value: " + str(token._value))
    print("token._start_index: " + str(token._start_index))
    print("token._end_index: " + str(token._end_index))
    print("token._content: " + str(token._content))
    print("token.string: " + str(token.string))
    print("token.value: " + str(token.value))
    print("token.start: " + str(token.start))
    print("token.end: " + str(token.end))
    print("token.lookup(4): " + str(token.lookup(4)))

# Generated at 2022-06-22 06:36:36.503482
# Unit test for constructor of class Token
def test_Token():
    token = Token("testing", 0, 3)
    assert token.string == "test"


# Generated at 2022-06-22 06:36:43.655078
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(value = 'a', start_index = 1, end_index = 2)
    string = token.string
    assert string == 'a'
    value = token.value
    assert value == 'a'
    start = token.start
    assert start == Position(1, 2, 1)
    end = token.end
    assert end == Position(1, 2, 2)
    reprtxt = repr(token)
    assert reprtxt == "ScalarToken('a')"


# Generated at 2022-06-22 06:36:49.849595
# Unit test for constructor of class ListToken
def test_ListToken():
    content1 = ""
    value1 = []
    start_index1 = 0
    end_index1 = 0
    token1 = ListToken(value1, start_index1, end_index1, content1)
    assert token1._start_index == start_index1
    assert token1._end_index == end_index1
    assert token1._content == content1
    assert token1._value == value1


# Generated at 2022-06-22 06:36:51.616593
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(10, 5, 9)
    assert token._value == 10


# Generated at 2022-06-22 06:36:57.530152
# Unit test for method lookup of class Token
def test_Token_lookup():
    content = "hello"
    token = ScalarToken("hello", 0, 4, content)
    assert token.lookup([]) == token
    assert token.lookup_key([[]]) == token
    assert token.start.index is 0
    assert token.end.index is 4

# Generated at 2022-06-22 06:37:06.002897
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    assert repr(ScalarToken("a123", 0, 3)) == "ScalarToken('a123')"
    assert repr(ScalarToken(1, 0, 0)) == "ScalarToken('1')"
    assert repr(ScalarToken(123, 0, 2)) == "ScalarToken('123')"
    assert ScalarToken("a123", 0, 3) == ScalarToken("a123", 0, 3)
    assert ScalarToken("a123", 0, 3) != ScalarToken("a12", 0, 2)
    assert ScalarToken("123", 0, 2) == ScalarToken(123, 0, 2)
    assert ScalarToken("123", 0, 2) != ScalarToken(456, 0, 2)

# Generated at 2022-06-22 06:37:17.711708
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from typesystem import String

    content = '"0", "1", "2"'
    token = String.parse(content)
    assert type(token.value) == list
    assert type(token.lookup_key([0]).value) == str
    assert token.lookup_key([0]).value == "0"
    assert token.lookup_key([2]).value == "2"

    # Check exception
    try:
        assert token.lookup_key([3])
    except:
        pass

    content = '"0": "1", "1": "2"'
    token = String.parse(content)
    assert type(token.value) == dict
    assert type(token.lookup_key([0]).value) == str
    assert token.lookup_key([0]).value == "0"

# Generated at 2022-06-22 06:37:28.074046
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    start_index = 0
    end_index = 1
    content = "abc"
    s = ScalarToken(1, start_index, end_index, content)
    assert s._content == content
    assert s._start_index == start_index
    assert s._end_index == end_index
    assert s._value == 1
    assert s.string == 'a'
    assert s.value == 1
    assert s.start == Position(1, 1, 0)
    assert s.end == Position(1, 2, 1)
    assert s.lookup([1]) == s
    assert s.lookup_key([1, 1]) == s
    assert s == s
    assert s != 'a'
    # assert hash(s) == hash(1)

# Generated at 2022-06-22 06:37:31.176211
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    t = Token(None, 0, 0, "")
    assert repr(t) == "Token('')"


# Generated at 2022-06-22 06:37:34.630076
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    a = Token(None, None, None)
    b = Token(None, None, None)
    assert a == b
    assert a == a
    assert not (a != b)
    assert not (a != a)



# Generated at 2022-06-22 06:38:06.501331
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    # JSON_Integer
    i = ScalarToken(123, 0, 2)
    print(i.start)
    print(i.end)
    print(i.string)
    print(i.value)
    '''
    Position(1, 1, 0)
    Position(1, 3, 2)
    123
    123
    '''

    # JSON_Float
    f = ScalarToken(1.23, 0, 4)
    print(f.start)
    print(f.end)
    print(f.string)
    print(f.value)
    '''
    Position(1, 1, 0)
    Position(1, 5, 4)
    1.23
    1.23
    '''

    # JSON_String
    s = ScalarToken('123', 1, 3)
   

# Generated at 2022-06-22 06:38:10.108942
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    t1 = ScalarToken(None, None, None, None)
    assert t1.__hash__() == hash(None)
    t2 = ScalarToken("", None, None, None)
    assert t2.__hash__() == hash("")

# Generated at 2022-06-22 06:38:14.383353
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # TODO: implement
    # assert False, f"Not implemented method 'test_Token___eq__'"
    raise NotImplementedError(f"Not implemented method 'test_Token___eq__'")
    

# Generated at 2022-06-22 06:38:26.006295
# Unit test for method lookup of class Token
def test_Token_lookup():
    from unittest import TestCase, main
    from unittest.mock import MagicMock
    from typesystem.base import String
    from typing import Any
    from .tokenize import tokenize
    from .types import Token, ScalarToken, DictToken, ListToken

    class Tests(TestCase):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

            # Setup a mock
            self.mock_string = MagicMock(spec=String)
            self.mock_token = MagicMock(spec=Token)
            self.mock_scalar_token = MagicMock(spec=ScalarToken)
            self.mock_dict_token = MagicMock(spec=DictToken)

# Generated at 2022-06-22 06:38:29.108616
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Test with _value = "xyz"
    t = Token("xyz", 0, 2, content = "123")
    assert t.__repr__() == "Token(\"xyz\")"


# Generated at 2022-06-22 06:38:36.990028
# Unit test for constructor of class ListToken
def test_ListToken():
    list_tok = ListToken([1,2,3], 1, 5)
    assert list_tok.string == "[1,2,3]"
    assert list_tok.value == [1,2,3]
    assert list_tok.start.index == 1
    assert list_tok.end.index == 5
    assert list_tok.lookup([1]).value == 2
    assert list_tok.start.index == 1
    assert list_tok.end.index == 5
    assert list_tok.lookup([1]).value == 2
    assert list_tok.lookup_key([0]).value == 1


# Generated at 2022-06-22 06:38:39.853676
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    x = Token(1, 2, 3)
    assert repr(x) == "Token(1)"



# Generated at 2022-06-22 06:38:44.199318
# Unit test for constructor of class Token
def test_Token():
    assert Token((), 1, 3, "foo").string == "foo"
    assert Token((), 1, 3, "foo").start == Position(1, 4, 1)
    assert Token((), 1, 3, "foo").end == Position(1, 4, 3)

# Generated at 2022-06-22 06:38:49.490636
# Unit test for constructor of class Token
def test_Token():
    token = Token(42, 15, 20)
    assert isinstance(token, Token)
    assert token.string == ""
    assert token.start == Position(1, 16, 15)
    assert token.end == Position(1, 21, 20)
    assert token.value == 42
    assert token.__repr__() == "Token('')"


# Generated at 2022-06-22 06:38:55.191013
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    obj = ScalarToken("test", 0, 0)
    assert isinstance(
        ScalarToken("test", 0, 0).__hash__(), int
    ), "__hash__ method returns the type int"
    assert ScalarToken("test", 0, 0).__hash__() == hash("test"), "__hash__ method returns a correct value"

