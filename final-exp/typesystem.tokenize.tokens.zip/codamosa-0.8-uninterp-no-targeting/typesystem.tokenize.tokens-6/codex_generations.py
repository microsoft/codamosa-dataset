

# Generated at 2022-06-22 06:29:22.806396
# Unit test for method lookup of class Token
def test_Token_lookup():
    # dictionary
    a = DictToken({
        ScalarToken(1, 0, 0): ScalarToken(2, 1, 1),
        ScalarToken(3, 2, 2): ScalarToken(4, 3, 3),
    }, 0, 3, "1234")
    
    # list
    b = ListToken([
        ScalarToken(5, 0, 0),
        ScalarToken(6, 1, 1),
    ], 0, 1, "56")

    assert a.lookup([]) == a
    assert a.lookup([0]) == ScalarToken(2, 1, 1)
    assert a.lookup([1]) == ScalarToken(4, 3, 3)
    
    assert b.lookup([]) == b

# Generated at 2022-06-22 06:29:30.156581
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
	dummy = ScalarToken(value = 'value out', start_index = 1, end_index = 2, content = 'content out')
	dummy_key = ScalarToken(value = 'value out', start_index = 1, end_index = 2, content = 'content out')
	assert hash(dummy_key) == hash(dummy), f'Expected testing__hash__ to return {hash(dummy)}, but got {hash(dummy_key)}'


# Generated at 2022-06-22 06:29:32.726436
# Unit test for constructor of class DictToken
def test_DictToken():
    a = {"a": "a", "b": "b"}
    assert DictToken(a)._get_value() == a

# Generated at 2022-06-22 06:29:34.179161
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # TODO: Implement this test
    pass


# Generated at 2022-06-22 06:29:39.517831
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    content = "a=A, b=B"
    token = DictToken({ScalarToken("a", 2, 2, content): ScalarToken("A", 0, 0, content)}, \
            content, 2, 1)
    assert token.lookup([0]).string == "a=A"
    assert token.lookup_key([0]).string == "a"
    return 1



# Generated at 2022-06-22 06:29:44.237499
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(value=None, start_index=None, end_index=None, content=None)
    token2 = Token(value=None, start_index=None, end_index=None, content=None)
    assert token1 == token2



# Generated at 2022-06-22 06:29:46.718093
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = None # type: Token
    t2 = None # type: Token
    assert not t1 == t2


# Generated at 2022-06-22 06:29:58.390229
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert ScalarToken(value=1, start_index=1, end_index=2, content="123") == ScalarToken(value=1, start_index=1, end_index=2, content="123")
    assert ScalarToken(value=1, start_index=1, end_index=2, content="123") != ScalarToken(value=2, start_index=1, end_index=2, content="123")
    assert ScalarToken(value=1, start_index=1, end_index=2, content="123") != ScalarToken(value=1, start_index=2, end_index=2, content="123")

# Generated at 2022-06-22 06:30:07.351227
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test cases
    tokens = [
        Token(
            True,
            0,
            4,
            content="""
            true
            """
        ),
        Token(
            '"hello world"',
            2,
            15,
            content="""
            "hello world"
            """
        ),
        Token(
            float(1),
            0,
            1,
            content="""
            1
            """
        )
    ]

    for token in tokens:
        token2 = copy.deepcopy(token)
        # The token and token2 are equal
        assert(token == token2)


# Generated at 2022-06-22 06:30:13.923023
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(
        value = 'hello',
        start_index = 1,
        end_index = 5,
        content = 'hello world',
    )
    assert token.value == 'hello'
    assert token.string == 'hello'
    assert token.start.line_no == 1
    assert token.start.column_no == 1
    assert token.start.index == 1
    assert token.end.line_no == 1
    assert token.end.column_no == 6
    assert token.end.index == 6


# Generated at 2022-06-22 06:30:25.806583
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    obj = Token(value='abcd', start_index=2, end_index=4, content='a1b2c3d4e5')
    expected_output = "Token('cd')"
    actual_output = obj.__repr__()
    assert actual_output == expected_output


# Generated at 2022-06-22 06:30:36.807506
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Test case 1: create a Token object
    a_Token = Token(1,0,1,"a")
    # Test case 1: check that __repr__ function works correctly
    assert a_Token.__repr__() == "Token(1)"

    # Test case 2: create a ScalarToken object
    a_ScalarToken = ScalarToken(1,0,1,"a")
    # Test case 2: check that __repr__ function works correctly
    assert a_ScalarToken.__repr__() == "ScalarToken(1)"

    # Test case 3: create a DictToken object
    a_DictToken = DictToken({},0,1,"a")
    # Test case 3: check that __repr__ function works correctly

# Generated at 2022-06-22 06:30:40.470392
# Unit test for constructor of class ListToken
def test_ListToken():
    from typesystem.types import String

    token = ListToken(value = [String()], start_index = 0, end_index = 4, content = "abcde")
    assert token.string == "abcde"

# Generated at 2022-06-22 06:30:46.458595
# Unit test for constructor of class ListToken
def test_ListToken():
    #test = ListToken(1, 2, 3, 4, 5, 6)
    #print(test.value)
    #print(test.start)
    #print(test.end)
    #print(test.lookup(1))
    #print(test.lookup_key(3))
    print(test.__repr__())
    print(test.__eq__(test))


# Generated at 2022-06-22 06:30:57.643943
# Unit test for method lookup of class Token
def test_Token_lookup():
    import typesystem
    import typesystem.types
    # Tests
    # 1. initialization of a Token object
    # 2. test that an error is thrown when one looks up a child token
    # 3. test that an error is thrown when one looks up a key token
    # 4. test that a list is extended correctly when one looks up a child/key token
    # 5. test that a dictionary is extended correctly when one looks up a child/key token
    # 6. test that a non-list/dictionary is passed correctly when one looks up a child/key token
    dict_ = {'b': {'c': 1}}
    string = ''
    for key, value in dict_.items():
        string += key + ':'
        if isinstance(value, (dict, list)):
            string += ' {} '.format(type(value).__name__)

# Generated at 2022-06-22 06:31:01.919242
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token(
        value='value',
        start_index=2,
        end_index=7,
        content='content'
    )
    assert str(token) == "Token('value')"
    assert repr(token) == "Token('value')"


# Generated at 2022-06-22 06:31:05.887997
# Unit test for method lookup of class Token
def test_Token_lookup():
    a = Token("hello", 0, 4)
    assert a._get_value() == "hello"
    b = "nothing"
    assert b.startswith("") == True
    assert b.startswith("nothing") == True


# Generated at 2022-06-22 06:31:16.706011
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # test __eq__ with same instance
    instance = Token(value=None, start_index=None, end_index=None)
    assert instance.__eq__(instance)
    # test __eq__ with other type
    other = None
    with pytest.raises(NotImplementedError):
        instance.__eq__(other)
    # test __eq__ with Token, not equal
    other = Token(value=[1, 2, 3], start_index=1, end_index=4)
    assert not instance.__eq__(other)
    # test __eq__ with Token, equal
    other = Token(value=None, start_index=None, end_index=None)
    assert instance.__eq__(other)



# Generated at 2022-06-22 06:31:18.808555
# Unit test for constructor of class Token
def test_Token():
    try:
        Token(value=None, start_index=0, end_index=1, content=None)
    except Exception as e:
        print(e)


# Generated at 2022-06-22 06:31:21.309981
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token(None, None, None)
    assert(token.__repr__() == "Token(None)")


# Generated at 2022-06-22 06:31:37.158409
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    obj = ScalarToken(1, 2, 3, 4)
    assert obj._value == 1
    assert obj._start_index == 2
    assert obj._end_index == 3
    assert obj._content == 4


# Generated at 2022-06-22 06:31:38.870660
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(None, None, None) == Token(None, None, None)



# Generated at 2022-06-22 06:31:50.821337
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    result = ScalarToken('12', 0, 1, '12')
    assert result
    assert result.value == '12'
    assert result.string == '12'
    assert result.start == Position(1, 1, 0)
    assert result.end == Position(1, 2, 1)
    assert result == ScalarToken('12', 0, 1, '12')
    assert isinstance(result, Token)
    assert not isinstance(result, DictToken)
    assert not isinstance(result, ListToken)
    with pytest.raises(NotImplementedError):
        result._get_child_token('key')
    with pytest.raises(NotImplementedError):
        result._get_key_token('key')

# Generated at 2022-06-22 06:31:55.072036
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # Input
    s = ScalarToken("a", 1, 2, content="banana")

    # Output
    out = s.__hash__()
    assert isinstance(out, int)
    assert out == hash("a")


# Generated at 2022-06-22 06:31:56.943923
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(1, 0, 1)
    assert hash(token) == hash(1)


# Generated at 2022-06-22 06:32:08.941160
# Unit test for method lookup of class Token
def test_Token_lookup():
    from pylex.token import DictToken, ListToken, ScalarToken
    # Test a scalar token
    t = ScalarToken(42, 1, 3, "42")
    assert t.lookup([]) == t
    # Test a dict token
    t = DictToken(
        {
            ScalarToken("name", 1, 4): ScalarToken("value1", 1, 4),
            ScalarToken("age", 1, 4): ScalarToken("value2", 1, 4),
        },
        1,
        4,
    )
    assert t.lookup(["name"]).value == "value1"
    assert t.lookup(["age"]).value == "value2"
    assert t.lookup_key(["name", "name"]).value == "name"
    assert t.lookup_key

# Generated at 2022-06-22 06:32:12.492451
# Unit test for constructor of class Token
def test_Token():
    assert Token(
        value = '',
        start_index = 0,
        end_index = 0,
        content = ''
    ) != None


# Generated at 2022-06-22 06:32:18.400368
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    assert ScalarToken(10, 0, 0, "10").value == 10
    assert ScalarToken(10, 0, 0, "10").start == Position(1, 1, 0)
    assert ScalarToken(10, 0, 0, "10").end == Position(1, 1, 0)
    assert ScalarToken(10, 0, 0, "10").string == "10"
    assert ScalarToken(10, 0, 0, "10") == ScalarToken(10, 0, 0, "10")


# Generated at 2022-06-22 06:32:23.652729
# Unit test for constructor of class ListToken
def test_ListToken():
    content = '{"test":"test_get_value","test_get_key":"","test_get_child_token":"test_get_child_token"}'
    d = json.loads(content)
    d = dict([(k, v) for (k, v) in d.items()])
    ListToken(d, 1, 4, content)
    assert True

# Generated at 2022-06-22 06:32:28.006335
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken.__init__({"a": "b"}) == None


# Generated at 2022-06-22 06:32:47.264993
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    X = "X"
    object1 = Token(X, 0, 0)
    object2 = Token(X, 0, 0)
    object3 = Token(X, 1, 2)
    object4 = Token(X, 1, 2)

    # Equal
    assert object1 == object2
    assert object3 == object4

    # Not equal
    assert object1 != object3
    assert object2 != object4

    object5 = "X"
    # Type error
    try:
        object1 == object5
    except TypeError:
        assert True
    else:
        assert False, "Shouldn't get here"


# Generated at 2022-06-22 06:32:51.323466
# Unit test for constructor of class ListToken
def test_ListToken():
    a = [1]
    token = ListToken(a, 0, 0, 1)
    assert token._get_value() == a
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == 1

# Generated at 2022-06-22 06:32:55.717899
# Unit test for method lookup of class Token
def test_Token_lookup():
  token = Token(1, 0, 1)
  assert token.lookup([]) == token
  assert token.lookup([]) is not token
  assert token.lookup_key([0]) == token
  assert token.lookup_key([0]) is not token



# Generated at 2022-06-22 06:32:58.996138
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = ScalarToken(1, 0, 1, '12')
    token2 = ScalarToken(2, 2, 3, '12')
    assert token1 == token2



# Generated at 2022-06-22 06:33:05.214503
# Unit test for constructor of class ListToken
def test_ListToken():
    value = []
    start_index = 0
    end_index = 0
    content = ""
    token = ListToken(value, start_index, end_index, content)
    # test_start_index = token._start_index
    # test_end_index = token._end_index
    # test_content = token._content
    print(token._get_value())
    print(token.start)
    print(token.end)
    # print(token._get_position(token._start_index))
    print(token.lookup([2]))
    print(token.lookup_key([2]))
    # print(token.__repr__())


# Generated at 2022-06-22 06:33:07.506610
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token(5, 1, 7, "")
    assert repr(token) == "Token(5)"



# Generated at 2022-06-22 06:33:12.936411
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    start_index = 1
    end_index = 4
    value = [1,2,3,4]
    content = "This is a test"
    token = ListToken(value=value, start_index=start_index, end_index=end_index, content=content)
    assert str(token) == "ListToken([1, 2, 3, 4])"


# Generated at 2022-06-22 06:33:16.894256
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Create an instance of class Token
    token = Token(value = None, start_index = None, end_index = None)
    # Check the __repr__ method of the instance
    assert token.__repr__() == 'Token(None)'


# Generated at 2022-06-22 06:33:26.415729
# Unit test for method lookup of class Token
def test_Token_lookup():
    # Prepare data
    class TokenImp(Token):
        def __init__(self, value, start_index, end_index, content):
            self._value = value
            self._start_index = start_index
            self._end_index = end_index
            self._content = content
        def _get_value(self):
            return self._value
        def _get_child_token(self, key):
            return self._value[key]
        def _get_key_token(self, key):
            raise NotImplementedError  # pragma: nocover

# Generated at 2022-06-22 06:33:29.682914
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    t = ScalarToken(1, 0, 0, "")
    assert str(t) == "ScalarToken('1')"

# Generated at 2022-06-22 06:33:44.572591
# Unit test for method lookup of class Token
def test_Token_lookup():
    """Unit test for method lookup of class Token
    """
    dt = DictToken({}, 0, 0, "")
    assert dt.lookup([]) == dt


# Generated at 2022-06-22 06:33:52.022844
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """
    Tests the method Token.__eq__
    """
    # Create a mock object for class Token
    token1 = mock.Mock(spec=Token)
    # Create a mock object for class Token
    token2 = mock.Mock(spec=Token)
    # Create a mock object for class Token
    token3 = mock.Mock(spec=Token)
    
    # Set the mock returned values of Token.__get_child_token to 0 when
    # Token.__eq__ is called with token1 as parameter, then create a new mock
    # object with this token variable
    token1.__get_child_token.return_value = 0
    token = mock.Mock(spec=Token, token=token1)
    
    # Set the mock returned values of Token.__get_child_token to 0 when
    # Token

# Generated at 2022-06-22 06:34:03.866342
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert Token(
        value=123,
        start_index=0,
        end_index=2,
        content='123'
        ).__repr__() == 'Token(123)', 'Test failed'
    assert Token(
        value=123.456,
        start_index=0,
        end_index=6,
        content='123.456'
        ).__repr__() == 'Token(123.456)', 'Test failed'
    assert Token(
        value='abc',
        start_index=0,
        end_index=2,
        content='abc'
        ).__repr__() == "Token('abc')", 'Test failed'
    assert Token(
        value=True,
        start_index=0,
        end_index=3,
        content='True'
        ).__re

# Generated at 2022-06-22 06:34:09.383501
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """
    Test __eq__ method of class Token
    """
    t = Token(
        value = "Token", start_index = 0, end_index = 1, content = "Token"
    )
    # Test case 3
    try:
        assert t.__eq__("Token1")
    except AssertionError as ae:
        assert True
    else:
        assert False
    

# Generated at 2022-06-22 06:34:20.780450
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    assert ScalarToken("2019-01-01", 10, 19, "2019-01-01") == ScalarToken("2019-01-01", 10, 19, "2019-01-01")
    assert ScalarToken("2019-01-01", 10, 19, "2019-01-01") != ScalarToken("2019-01-02", 10, 19, "2019-01-01")
    assert isinstance(ScalarToken("2019-01-01", 10, 19, "2019-01-01"), ScalarToken)
    assert ScalarToken("2019-01-01", 10, 19, "2019-01-01")._get_value() == ScalarToken("2019-01-01", 10, 19, "2019-01-01")._get_value()

# Generated at 2022-06-22 06:34:32.478976
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    import re
    import typesystem
    value = typesystem.String(name="name").validate("test")
    start_index = 1
    end_index = 2
    content = ""
    x = typesystem.Token(value, start_index, end_index, content)
    assert re.match(r"Token\(['\"]test['\"]\)", repr(x)) is not None
    assert eval(repr(x)) == x
    value = {"one": 1, 2: "two"}
    start_index = 1
    end_index = 2
    content = ""
    x = typesystem.DictToken(value, start_index, end_index, content)
    assert re.match(r"DictToken\({'one': 1, 2: 'two'}\)", repr(x)) is not None

# Generated at 2022-06-22 06:34:36.442713
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    a = ScalarToken(1, 0, 1, "1")
    b = ScalarToken(1, 0, 1, "1")
    assert hash(a) == hash(b)


# Generated at 2022-06-22 06:34:39.433901
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    test = ScalarToken(
        "value",
        start_index=5,
        end_index=9,
        content="contentvaluecontent"
    )


# Generated at 2022-06-22 06:34:44.851379
# Unit test for constructor of class Token
def test_Token():
    # assert isinstance(Token(1,2,3), Token)
    assert Token(1, 2, 3)._value == 1
    assert Token(1, 2, 3)._start_index == 2
    assert Token(1, 2, 3)._end_index == 3
    assert Token(1, 2, 3, "test")._content == "test"



# Generated at 2022-06-22 06:34:47.862201
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(
        value="value", start_index=0, end_index=0, content="content"
    )
    assert hash(token) == hash("value")


# Generated at 2022-06-22 06:35:18.072310
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # Test the case where everything is fine.
    token = ScalarToken(0, 0, 0)
    actual = token.__hash__()
    expected = hash(0) # type: ignore
    assert expected == actual



# Generated at 2022-06-22 06:35:29.778603
# Unit test for constructor of class ListToken
def test_ListToken():
    from typesystem.parser import ParseResult, Parser
    from typesystem.base import Dict, List, Position, Scalar
    from typesystem.parser.tokens import DictToken, ListToken, ScalarToken
    scalar = Scalar("abc", Position(1, 4, 3), Position(1, 7, 6))
    scalar_token = ScalarToken(scalar ,3, 6, "abc")
    # Use relation path to initialize ListToken
    l9 = List([scalar], Position(1, 2, 1), Position(1, 10, 9))
    l1 = List([l9], Position(1, 1, 0), Position(1, 11, 10))
    parse_result1 = ParseResult(l1, True)
    parser1 = Parser(parse_result1)
    token1 = parser1

# Generated at 2022-06-22 06:35:42.123989
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(value = 'x', start_index = 3, end_index = 5, content = '')
    assert (token.value == 'x' and token.start_index == 3 and token.end_index == 5 and token.content == '')
    assert (token.string == '')
    assert (token.start == Position(line_no=1, column_no=1, index=3))
    assert (token.end == Position(line_no=1, column_no=1, index=5))
    assert (token._get_position(index=3) == Position(line_no=1, column_no=1, index=3))
    assert (token._get_position(index=5) == Position(line_no=1, column_no=1, index=5))

# Generated at 2022-06-22 06:35:46.266736
# Unit test for constructor of class Token
def test_Token():
    token = Token(2, 2, 8, 'llllllll')
    assert token.string == 'llllllll'
    assert token.start.column == 2
    assert token.end.column == 8
    assert repr(token) == 'Token(2)'
    assert token == token


# Generated at 2022-06-22 06:35:57.889487
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    t = Token(value = {
        'key1': ScalarToken(value = 'value1', start_index = 5, end_index = 11),
        'key2': ScalarToken(value = 'value2', start_index = 21, end_index = 27),
        'key3': ScalarToken(value = 'value3', start_index = 37, end_index = 43)
    }, start_index = 0, end_index = 47)
    assert t.lookup_key([0]) == ScalarToken(value = 'key1', start_index = 1, end_index = 5)
    assert t.lookup_key([1]) == ScalarToken(value = 'key2', start_index = 12, end_index = 16)

# Generated at 2022-06-22 06:35:59.985116
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    pass # TODO write unit test for method __hash__ of class ScalarToken

# Generated at 2022-06-22 06:36:02.762947
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert (Token("test_value", 0, 4, content="test_content").__repr__() ==
            "Token(\"test_content\")")


# Generated at 2022-06-22 06:36:14.377000
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    t=DictToken({"2": "a"},0,1,content="12")
    assert t.lookup_key([0])==t
    t=DictToken({"2": "a"},0,1,content="12")
    assert str(t.lookup_key([0,"2"]))=="DictToken({'2': 'a'})"
    t=DictToken({"2": "a"},0,1,content="12")
    assert str(t.lookup_key([0,"2"]))=="DictToken({'2': 'a'})"
    t=DictToken({"2": "a"},0,1,content="12")
    assert str(t.lookup_key([0,"2"]))=="DictToken({'2': 'a'})"
    t=D

# Generated at 2022-06-22 06:36:21.014386
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    source = '数据类型定义测试'
    words = list(pyhanlp.segment(source))
    pos = 0
    text = words[-1].word
    length = len(text)
    token = ScalarToken(text, pos, pos+length-1, source)
    assert repr(token) == "ScalarToken('数据类型')"

# Generated at 2022-06-22 06:36:24.882509
# Unit test for constructor of class Token
def test_Token():
    t = Token(value=1, start_index=2, end_index=3)
    assert t._value == 1
    assert t._start_index == 2
    assert t._end_index == 3


# Generated at 2022-06-22 06:37:30.394149
# Unit test for constructor of class DictToken
def test_DictToken():
    tok = DictToken({}, 0, 2, '{}')
    assert tok.string == '{}'


# Generated at 2022-06-22 06:37:33.138526
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value=[], start_index=1, end_index=2, content="")
    assert token.__eq__(token) is True


# Generated at 2022-06-22 06:37:35.345858
# Unit test for constructor of class Token
def test_Token():
    try:
        Token(None, 0, 0)
    except NotImplementedError:
        pass
    else:
        assert False


# Generated at 2022-06-22 06:37:43.819432
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    """Test for method lookup_key of class Token.
    """
    # Unit test for method lookup_key of class Token
    from typesystem.types import Object, String

    class SimpleUser(Object):
        """
        Simple user class for testing.
        """

        name = String()

    schema = SimpleUser()
    data = {
        "name": "John",
    }
    token = schema.validate(data)
    key_token = token.lookup_key(["name"])
    assert isinstance(key_token, ScalarToken)
    assert key_token._get_value() == "name"

# Generated at 2022-06-22 06:37:46.408306
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    t = ScalarToken(value = '', start_index = 1, end_index = 2)
    assert t


# Generated at 2022-06-22 06:37:57.927932
# Unit test for method lookup of class Token
def test_Token_lookup():
    class A(ListToken):
        def __init__(self, value: typing.Any, start_index: int, end_index: int, content: str = ""):
            super().__init__(value, start_index, end_index, content)
            self.a = 1
            self.b = 2
            self._child_tokens = {
                'a': self._child_tokens[0]
            }
        def _get_child_token(self, key: typing.Any) -> Token:
            return self._child_tokens[key]
    class B(ListToken):
        def __init__(self, value: typing.Any, start_index: int, end_index: int, content: str = ""):
            super().__init__(value, start_index, end_index, content)


# Generated at 2022-06-22 06:38:07.649405
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert repr(Token(0, 0, 1)) == 'Token(0)'
    assert repr(Token([], 0, 1)) == 'Token([])'
    assert repr(Token([0], 0, 1)) == 'Token([])'
    assert repr(Token([0], 0, 2)) == 'Token([0])'
    assert repr(Token([[0]], 0, 3)) == 'Token([[0]])'
    assert repr(Token({}, 0, 1)) == 'Token({})'
    assert repr(Token({'a': 0}, 0, 3)) == 'Token({})'
    assert repr(Token({'a': 0}, 0, 4)) == 'Token({})'
    assert repr(Token({'a': 0}, 0, 5)) == 'Token({\'a\': 0})'

# Generated at 2022-06-22 06:38:16.372006
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    keys=["a","b","c"]
    for i in range(len(keys)):
        s=Token(keys[i],10,20,keys[i])
        if (i==0):
            mydict={}
        mydict[s._value]=s
        
    s=Token(mydict,10,20)
    t=s.lookup(["a"])
    assert t==s
    t=t.lookup_key(["a"])
    assert t==s
    return
test_Token_lookup_key()

# Generated at 2022-06-22 06:38:25.954727
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    scalarToken = ScalarToken("value", 0, 3)
    assert scalarToken._value == "value"
    assert scalarToken.lookup([]) == 'value'
    assert scalarToken.lookup_key([]) == 'value'
    assert str(scalarToken) == 'ScalarToken(value)'
    assert scalarToken.__eq__(scalarToken) == True
    assert scalarToken.start == Position(1, 4, 0)
    assert scalarToken.end == Position(1, 4, 3)
    assert scalarToken.__hash__() == hash('value')


# Generated at 2022-06-22 06:38:29.516012
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    args = [1, 2, 3, 4, 5]
    expected = hash(1)
    actual = ScalarToken(*args).__hash__()
    assert actual == expected

# Unit tests for method __eq__ of class Token