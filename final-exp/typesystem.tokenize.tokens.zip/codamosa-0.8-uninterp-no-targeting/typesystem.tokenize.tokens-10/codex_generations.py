

# Generated at 2022-06-22 06:29:04.563799
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken({}, 0, 0)

# Generated at 2022-06-22 06:29:09.413460
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert ScalarToken(True, 0, 4, "true") == ScalarToken(True, 10, 14, "true")
    assert ScalarToken(True, 0, 4, "true") != ScalarToken(True, 10, 13, "true")
    assert ScalarToken(True, 0, 4, "true") != ScalarToken(False, 10, 14, "false")

# Generated at 2022-06-22 06:29:16.923198
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():

    token = ScalarToken(value=True, start_index=0, end_index=1, content="a")
    result = token.__hash__()
    assert isinstance(result, int)
    assert 1 == result

    token = ScalarToken(value=1, start_index=0, end_index=1, content="a")
    result = token.__hash__()
    assert isinstance(result, int)
    assert 1 == result

    token = ScalarToken(value="a", start_index=0, end_index=1, content="a")
    result = token.__hash__()
    assert isinstance(result, int)
    assert 97 == result


# Generated at 2022-06-22 06:29:24.557134
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    a = ScalarToken("a", 0, 1, "ab")
    b = ScalarToken("a", 0, 1, "ab")
    assert a == b
    assert b == a
    b = ScalarToken("a", 1, 2, "ab")
    assert not a == b
    assert not b == a
    b = ScalarToken("b", 0, 1, "ab")
    assert not a == b
    assert not b == a
    b = ScalarToken("a", 0, 1, "ba")
    assert a == b
    assert b == a


# Generated at 2022-06-22 06:29:29.591585
# Unit test for constructor of class ListToken
def test_ListToken():
    # Test with a normal case
    my_token = ListToken([1, 2, 3], 0, 6, content = '123')

    assert my_token.string == '123'
    assert my_token.value == [1, 2, 3]
    assert my_token.start == Position(1, 1, 0)
    assert my_token.end == Position(1, 4, 3)



# Generated at 2022-06-22 06:29:34.862355
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
  token = ScalarToken(value = 1, start_index = 0, end_index = 1, content = "")
  assert(token.string == "1")
  assert(token.value == 1)
  assert(token.start.index == 0 and token.start.line_no == 1 and token.start.column_no == 1)
  assert(token.end.index == 1 and token.end.line_no == 1 and token.end.column_no == 2)
  assert(token.lookup([]) is token)
  assert(token.lookup_key([]) is token)
  assert(str(token) == "ScalarToken('1')")
  assert(not hash(token))
  return


# Generated at 2022-06-22 06:29:39.067196
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    value=["hello", "world"]
    start_index=0
    end_index=1
    content=""
    obj=Token(value, start_index, end_index, content)
    assert obj.__repr__() == "Token([\'hello\', \'world\'])"



# Generated at 2022-06-22 06:29:44.437712
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # TODO: why does this have a hash method? All it does is delegate to the value
    value = "test"
    start_index = 0
    end_index = 0
    content = ""
    assert hash(ScalarToken(value,start_index,end_index,content)) == hash(value)



# Generated at 2022-06-22 06:29:52.320555
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # test for all values, that ScalarToken.__hash__ always returns the same value
    from typesystem.base import scalar
    from typesystem.base import string
    from typesystem.base import integer
    from typesystem.base import number
    from typesystem.base import boolean
    for type_ in [scalar(), string(), integer(), number(), boolean()]:
        for value in [v for v in type_.values()]:
            assert ScalarToken(value, 0, 0).__hash__() == ScalarToken(value, 0, 0).__hash__()

# Generated at 2022-06-22 06:29:56.442463
# Unit test for constructor of class Token
def test_Token():
    token = Token('value', 2, 5, 'content')
    assert token.value == 'value'
    assert token.start_index == 2 
    assert token.end_index == 5
    assert token.content == 'content'


# Generated at 2022-06-22 06:30:11.639886
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    a = Token(value=0, start_index=1, end_index=2)
    b = Token(value=1, start_index=3, end_index=4)
    c = Token(value=2, start_index=5, end_index=6)
    a_ = {a: b}
    b_ = [c]
    a__ = Token(value=a_, start_index=1, end_index=2)
    b__ = Token(value=b_, start_index=3, end_index=4)
    a__._child_tokens = {a: b__}
    a__._child_keys = {a: b__}
    assert a__.lookup_key([0]) == a__


# Generated at 2022-06-22 06:30:18.926827
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    class ConstructorTest(unittest.TestCase):
        # test token value
        def test_value(self):
            self.assertEqual(str(ScalarToken('', 0, 0).value), "'0'")

        # test token string
        def test_string(self):
            self.assertEqual(str(ScalarToken('', 0, 0).string), "0")

        # test token start
        def test_start(self):
            self.assertEqual(ScalarToken('', 0, 0).start, Position(0, 0, 0))

        # test token end
        def test_end(self):
            self.assertEqual(ScalarToken('', 0, 0).end, Position(0, 0, 0))

        # test token lookup

# Generated at 2022-06-22 06:30:23.353975
# Unit test for constructor of class Token
def test_Token():
    t=Token(0,0,0)
    assert t.value == []
    assert t.start == (0,0)
    assert t.end == (0,0)
    assert t.lookup(0) == []
    assert t.lookup_key(0) == []

# Generated at 2022-06-22 06:30:34.881001
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    c1 = Token('[1, 2, 3]', 0, 8, '[1, 2, 3]')
    assert c1.lookup_key([0, 0]) == Token('1', 1, 1, '[1, 2, 3]')
    assert c1.lookup_key([0, 1]) == Token('2', 4, 4, '[1, 2, 3]')
    assert c1.lookup_key([0, 2]) == Token('3', 7, 7, '[1, 2, 3]')
    assert c1.lookup_key([1, 0]) == Token('2', 4, 4, '[1, 2, 3]')
    assert c1.lookup_key([1, 1]) == Token('3', 7, 7, '[1, 2, 3]')

# Generated at 2022-06-22 06:30:39.693803
# Unit test for constructor of class Token
def test_Token():
    print('Testing constructor of Token')
    test_obj = Token(
        value=object, start_index=0, end_index=1, content='content'
    )
    # Tests private variable _value
    assert(test_obj._value==object) 
    # Tests private variable _content
    assert(test_obj._content=='content')
    # Tests private variable _start_index
    assert(test_obj._start_index==0)
    # Tests private variable _end_index
    assert(test_obj._end_index==1)


# Generated at 2022-06-22 06:30:41.755562
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    instance = Token(None, None, None)
    assert instance.__repr__() == "Token(None)"


# Generated at 2022-06-22 06:30:46.153467
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken('Hello', 0, 4, 'Hello, world')
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 6, 5)
    assert token.string == 'Hello'


# Generated at 2022-06-22 06:30:49.715412
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    start_index = 2
    end_index = 3
    value = {}
    content = ""
    token = Token(value, start_index, end_index, content)
    assert isinstance(token == token, bool)

# Generated at 2022-06-22 06:30:54.397581
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken([1,2], 0, 1)
    assert token.string == '1'
    assert token.start.line_no == 1
    assert token.end.line_no == 1
    assert token.end.column_no == 1
    token_value = token.value
    assert token_value == [1]

# Generated at 2022-06-22 06:30:56.444115
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken("")
    assert token._get_value() == []

# Generated at 2022-06-22 06:31:02.224216
# Unit test for constructor of class Token
def test_Token():
    token = Token(2, 3, 5)
    assert token.value == 2
    assert token.start == Position(1, 1, 3)
    assert token.end == Position(1, 1, 5)
    assert token.string == ""



# Generated at 2022-06-22 06:31:04.977397
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(1, 0, 0)
    t2 = Token(1, 0, 0)
    assert t1 == t2


# Generated at 2022-06-22 06:31:07.254878
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token=ScalarToken(value=3.14,start_index=0,end_index=1)
    assert hash(token) == hash(3.14)



# Generated at 2022-06-22 06:31:11.381795
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    tmp = ScalarToken(str, 0, 17, content='-abc: 123\n')
    result = tmp.__hash__()
    expected = hash('-abc: 123\n')
    assert result == expected


# Generated at 2022-06-22 06:31:15.621623
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    test_token = Token(value=None, start_index=None, end_index=None)
    assert test_token.__repr__() == "Token('')"


# Generated at 2022-06-22 06:31:21.072666
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(0, 0, 0)
    t2 = Token(0, 0, 0)
    t3 = Token(1, 0, 0)
    assert t1 == t2
    assert t1 != t3
    assert t2 == t1
    assert t2 != t3
    assert t3 != t1
    assert t3 != t2



# Generated at 2022-06-22 06:31:30.084929
# Unit test for constructor of class ListToken
def test_ListToken():
    # Testing for the constructor of the class ListToken
    # Arrange
    value = [5,42]
    start_index = 0
    end_index = 1
    content = "0123456"

    # Act
    token = ListToken(value, start_index, end_index, content)

    # Assert
    assert(token._value == [5,42])
    assert(token._start_index == 0)
    assert(token._end_index == 1)
    assert(token._content == "0123456")


# Generated at 2022-06-22 06:31:33.593384
# Unit test for constructor of class Token
def test_Token():
  t=Token(1,1,2)
  assert t.value is None
  assert t.start.column == 1
  assert t.start.line == 1
  assert t.string == ''
  assert t.end.column == 2
  assert t.end.line == 1


# Generated at 2022-06-22 06:31:44.051970
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # __eq__ on ScalarToken
    assert ScalarToken(1, 0, 0) == ScalarToken(1, 0, 0)
    assert ScalarToken(2, 0, 0) != ScalarToken(1, 0, 0)
    assert ScalarToken(1, 1, 1) != ScalarToken(1, 0, 0)

    # __eq__ on DictToken
    assert DictToken({'a': 1}, 0, 0) == DictToken({'a': 1}, 0, 0)
    assert DictToken({'a': 1}, 0, 0) != DictToken({'a': 1}, 0, 1)
    assert DictToken({'a': 1}, 0, 0) != DictToken({'a': 1}, 1, 0)
    assert DictToken({'a': 1}, 0, 0) != D

# Generated at 2022-06-22 06:31:56.895099
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    T = Token
    t1 = T('string', 0, 5)
    t2 = T('other', 0, 5)
    t3 = T('string', 5, 0)
    t4 = T('other', 5, 0)

    assert(t1 == t1)
    assert(not (t1 == t2))
    assert(not (t1 == t3))
    assert(not (t1 == t4))

    assert(not (t2 == t1))
    assert(t2 == t2)
    assert(not (t2 == t3))
    assert(not (t2 == t4))

    assert(not (t3 == t1))
    assert(not (t3 == t2))
    assert(t3 == t3)
    assert(not (t3 == t4))


# Generated at 2022-06-22 06:32:08.052403
# Unit test for constructor of class Token
def test_Token():
    t = Token([], 0, 1, "a")
    assert t.string == "a"
    assert t.value == []
    assert t.start == Position(1, 1, 0)
    assert t.end == Position(1, 2, 1)
    assert t.lookup(0) == []
    assert t.lookup_key(0) == []
    assert repr(t) == "Token(['a'])"
    assert t == t



# Generated at 2022-06-22 06:32:18.399455
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    x = "abcd"
    y = ScalarToken(value = x, start_index = 2, end_index = 3, content = x)
    assert y.string == "cd"
    assert y.value == "cd"
    assert y.start.line == 1
    assert y.start.column == 3
    assert y.start.index == 2
    assert y.end.line == 1
    assert y.end.column == 4
    assert y.end.index == 3
    assert repr(y) == "ScalarToken('cd')"
    assert hash(y) == hash(x)
    z = "abc"
    assert y == ScalarToken(value = z, start_index = 2, end_index = 3, content = z)


# Generated at 2022-06-22 06:32:25.651389
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token('', 1, 2) == Token('', 1, 2, content='')
    assert not Token('', 1, 2) == Token('', 1, 3, content='')
    assert not Token('', 1, 2) == Token('', 1, 2, content='abc')
    assert not Token('', 1, 2) == 3
    assert not Token('', 1, 2) == object()
    assert not Token('', 1, 2) == ScalarToken('', 1, 2)

# Unit tests for method __hash__ of class ScalarToken

# Generated at 2022-06-22 06:32:28.244784
# Unit test for constructor of class Token
def test_Token():
    test = Token(None,0,0)
    assert test is not None



# Generated at 2022-06-22 06:32:33.845780
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    import pytest
    import typesystem
    from typesystem.token import Token
    Foo = typesystem.Integer()
    foo = Token(Foo, 0, 0)
    Bar = typesystem.Integer()
    bar = Token(Bar, 0, 0)
    Baz = typesystem.Integer()
    baz = Token(Baz, 0, 0)
    assert foo == foo
    assert foo != bar
    assert foo != baz


# Generated at 2022-06-22 06:32:34.914031
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(1, 0, 1)
    assert hash(token) == hash(1)

# Generated at 2022-06-22 06:32:46.783118
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    import unittest
    import typesystem

    class ExampleSchema(typesystem.Schema):
        example_property = typesystem.String()

    class ExampleDictToken(DictToken):
        def _get_key_token(self, key: typing.Any) -> Token:
            return self._child_keys[key]

    class ExampleSchemaToken(DictToken):
        def _get_key_token(self, key: typing.Any) -> Token:
            return self._child_keys[key]

    class ExampleDocumentToken(Token):
        def _get_value(self) -> typing.Any:
            return self._value.value

    schema_token = ExampleSchemaToken(
        value=ExampleSchema(), start_index=0, end_index=1, content='Schema'
    )
    example_property_

# Generated at 2022-06-22 06:32:57.022593
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert ScalarToken(42, 0, 2) == ScalarToken(42, 0, 2)
    assert ScalarToken(42, 0, 2) != ScalarToken(42, 0, 3)
    assert ScalarToken(42, 0, 2) != ScalarToken(43, 0, 2)
    assert ScalarToken(42, 0, 2) != ScalarToken(42, 0, 3, "123")
    assert ScalarToken(42, 0, 2) != ScalarToken(42, 1, 2, "123")
    assert ScalarToken(42, 0, 2) != ScalarToken(42, 0, 3, "123")
    assert ScalarToken(42, 0, 2) != ScalarToken(42, 1, 2, "123")



# Generated at 2022-06-22 06:33:02.349238
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token("foo", 1, 2)
    with pytest.raises(NotImplementedError):
        token.lookup([])


# Generated at 2022-06-22 06:33:04.698561
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken([1,2], 0, 0, "").value == [1,2]

# Generated at 2022-06-22 06:33:25.494940
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    start_index = 1
    end_index = 5
    content = "12345"
    value = "1234"
    token = ScalarToken(value, start_index, end_index, content)
    assert token.start.index == 1
    assert token.end.index == 5
    assert token.string == "1234"
    assert token.value == "1234"
    assert token.start.column == 1
    assert token.end.column == 4
    assert token.start.line == 1
    assert token.end.line == 1
    assert repr(token) == "ScalarToken('1234')"
    assert ScalarToken("1234",1,4,"12345") == ScalarToken("1234",1,4,"12345")


# Generated at 2022-06-22 06:33:26.023283
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    assert True

# Generated at 2022-06-22 06:33:33.682948
# Unit test for constructor of class Token
def test_Token():
    with pytest.raises(NotImplementedError):
        token = Token("", 0, 0)
        token._get_value()

    with pytest.raises(NotImplementedError):
        token = Token("", 0, 0)
        token._get_child_token(0)

    with pytest.raises(NotImplementedError):
        token = Token("", 0, 0)
        token._get_key_token(0)


# Generated at 2022-06-22 06:33:34.625029
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    pass # FIXME


# Generated at 2022-06-22 06:33:36.787908
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken({}, start_index = 0, end_index = 0, content = "THIS IS A TEST CASE.")
    

# Generated at 2022-06-22 06:33:43.725856
# Unit test for constructor of class Token
def test_Token():
    value = 0
    start_index = 1
    end_index = 2
    content = ""
    token = Token(value, start_index, end_index, content)
    assert token._value == value
    assert token._start_index == start_index
    assert token._end_index == end_index
    assert token._content == content
    assert token.string == content[start_index : end_index + 1]
    assert token.value == token._get_value()
    assert token.start == token._get_position(start_index)
    assert token.end == token._get_position(end_index)


# Generated at 2022-06-22 06:33:46.853455
# Unit test for constructor of class Token
def test_Token():
    start = Position(1, 1, 0)
    end = Position(2, 2, 3)
    t = Token(None, start, end)
    assert t is not None


# Generated at 2022-06-22 06:33:51.065792
# Unit test for constructor of class ListToken
def test_ListToken():
    # Initialise content
    content = ""

    # Initialise value
    value = []

    # Initialise start_index
    start_index = 0

    # Initialise end_index
    end_index = 0

    token = ListToken(value, start_index, end_index, content)
    assert token.string == ""

# Generated at 2022-06-22 06:33:54.936143
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    expected = '<class \'__main__.Token\'>(\'string\')'
    tok = Token('string', 0, 0)
    result = repr(tok)
    assert result == expected


# Generated at 2022-06-22 06:34:01.282980
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    print("Unit test for method __repr__ of class Token")
    obj = Token("", 5, 6)
    expected = "Token('', 5, 6)"
    actural = obj.__repr__()
    if actural == expected:
        print("PASSED")
    else:
        print("FAILED")
    print("Unit test for method __repr__ of class Token is done!")
    print()


# Generated at 2022-06-22 06:34:15.272801
# Unit test for constructor of class Token
def test_Token():
    tok = ScalarToken(None, 0, 1, "a")
    assert tok.string == "a"
    assert tok.start.index == 0
    assert tok.end.index == 1
    assert tok.start.line == 1
    assert tok.end.line == 1
    assert tok.start.column == 1
    assert tok.end.column == 2

# Generated at 2022-06-22 06:34:24.563902
# Unit test for constructor of class DictToken
def test_DictToken():
    # Arrange
    dict_token1 = DictToken({"hello": 1}, 0, 4, "hello")
    dict_token2 = DictToken({"hello": 1}, 0, 4, "hello")
    dict_token3 = DictToken({"test": 1}, 0, 4, "hello")

    # Act
    dict_token1_value = dict_token1._get_value()
    dict_token2_value = dict_token2._get_value()
    dict_token3_value = dict_token3._get_value()
    dict_token1_start = dict_token1.start
    dict_token1_end = dict_token1.end
    dict_token1_string = dict_token1.string

    # Assert
    assert dict_token1_value == {"hello": 1}

# Generated at 2022-06-22 06:34:29.661334
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # Try calling with invalid values
    try:
        token = ScalarToken("", 0, 0, "")
        token.__hash__()
    except Exception as exception:
        assert (
            str(exception) == "ScalarToken.__hash__() not implemented"
        ), "Expecting exception message to be 'ScalarToken.__hash__() not implemented'"
    else:
        raise AssertionError("Expected exception")

    try:
        token = ScalarToken("", 0, 0, "")
        token.__hash__(1)
    except Exception as exception:
        assert (
            str(exception) == "ScalarToken.__hash__() takes no arguments"
        ), "Expecting exception message to be 'ScalarToken.__hash__() takes no arguments'"
    else:
        raise Ass

# Generated at 2022-06-22 06:34:41.566250
# Unit test for constructor of class DictToken
def test_DictToken():
    # create a dictionary
    d = {"a": 1, "b": 2}
    # create a Token object
    t = DictToken(d, 0, 1, "a=1,b=2")
    # test whether the Token object is able to be created
    assert type(t) is DictToken
    # test __repr__ function
    assert t.__repr__() == "DictToken({'a': 1, 'b': 2})"
    # test the string
    assert t.string == "a=1,b=2"
    # test the value
    assert t.value == {"a": 1, "b": 2}
    # test the start position
    assert t.start.line_no == 1 and t.start.column_no == 1 and t.start.index == 0
    # test the end position


# Generated at 2022-06-22 06:34:50.550698
# Unit test for method lookup of class Token
def test_Token_lookup():
    s = 'hello\n"world\n"'
    t1 = ScalarToken('hello', 0, 4,s) 
    t2 = ScalarToken('world', 6, 11,s)
    t3 = ScalarToken('world\n', 6, 12,s)
    s_list=[t1,t2]
    d_list=[(t1,t2),(t1,t3)]
    t4 = ListToken(s_list, 0, 1,s)
    t5 = DictToken({t1:t2,t1:t3}, 0, 1,s)
    assert t4.lookup([0]) == t1
    assert t4.lookup([1]) == t2
    assert t5.lookup([0]) == t2
    assert t5.lookup([1]) == t3

# Generated at 2022-06-22 06:34:54.230721
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    test = ScalarToken("a", 0, 0)
    assert test._value == "a"
    assert test._start_index == 0
    assert test._end_index == 0
    assert test._content == ""

# Generated at 2022-06-22 06:34:56.565937
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert repr(Token("value", 1, 2, "content")) == "Token('e')", "string property does not work in Token"

# Generated at 2022-06-22 06:34:57.609015
# Unit test for constructor of class Token
def test_Token():
    T = Token(1,2,3)
    print(T)


# Generated at 2022-06-22 06:35:00.686111
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(1, 2, 3, content = "This is a test")
    token2 = Token(1, 2, 3, content = "This is a test")

    return token.__eq__(token2)


# Generated at 2022-06-22 06:35:03.889176
# Unit test for constructor of class Token
def test_Token():
    t = Token(1, 2, 3)
    assert t._end_index == 3



# Generated at 2022-06-22 06:35:18.939371
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    """
    Unit test for method lookup_key of class Token
    """
    t = Token(1, 2, 3)
    assert t.lookup_key([0]) is None, "Unit test for method lookup_key of class Token failed!"

# Generated at 2022-06-22 06:35:20.753205
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert ScalarToken(1, 1, 1).__hash__() == hash(1)

# Generated at 2022-06-22 06:35:29.262128
# Unit test for method lookup of class Token
def test_Token_lookup():
    class MyToken(ListToken):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(list(args), 0, 0, "")

    value = [{}, []]
    token = MyToken(DictToken(value[0]), ListToken(value[1]))
    assert token.lookup([0]).value == {}
    assert token.lookup([1, 0]).value == []
    assert token.lookup([1]).value == [value[1]]
    assert token.lookup([1, 0]).value == []

# Generated at 2022-06-22 06:35:40.796538
# Unit test for method lookup of class Token
def test_Token_lookup():
    from typesystem.base import String
    from typesystem.patterns import Dict

    elements = Dict(
        {
            "first": String(),
            "second": String(),
            "third": String(),
        },
        required=["first", "second"],
    )
    token = elements.parse('{"first": "hello", "second": "world", "third": "!"}')

    assert token.lookup(["first"]).value == "hello"

    assert token.lookup(["second"]).value == "world"

    # Test for error
    try:
        token.lookup(["first", "second"])
        raise Exception("Failed to raise error on invalid lookup")
    except LookupError:
        pass



# Generated at 2022-06-22 06:35:44.065514
# Unit test for constructor of class ListToken
def test_ListToken():
    a = [10, 20, 30]
    b = ListToken([1, 2, 3], 10, 12, a)
    c = b._get_value()
    assert c == [1, 2, 3]

test_ListToken()

# Generated at 2022-06-22 06:35:48.728569
# Unit test for constructor of class Token
def test_Token():
    value = 'hey'
    start_index = 0
    end_index = 1
    content = 'heyi'
    tok = Token(value, start_index, end_index, content)
    assert tok.value == None
    assert tok.start_index == 0
    assert tok.end_index == 1
    assert tok.content == 'heyi'


# Generated at 2022-06-22 06:35:50.683690
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token(1, 1, 1, 'test')
    assert token.lookup([]).value == 1

# Generated at 2022-06-22 06:35:52.667593
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken([1, 2, 3, 4], 0, 1, content='')
    print(token)

# Generated at 2022-06-22 06:36:04.892427
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """Test method __eq__ of class Token"""
    
    # Create token
    my_token = Token(1,2,3,"Hello World")
    
    # Compare token with an identical token
    token_equal = Token(1,2,3,"Hello World")
    assert my_token.__eq__(token_equal)
    
    # Compare token with a token that differs in start_index
    token_not_equal = Token(1,3,3,"Hello World")
    assert not my_token.__eq__(token_not_equal)
    
    # Compare token with a token that differs in end_index
    token_not_equal = Token(1,2,4,"Hello World")
    assert not my_token.__eq__(token_not_equal)
    
    # Compare token with a token that differs in content


# Generated at 2022-06-22 06:36:06.734756
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    obj = ScalarToken(0, 0, 0, "")
    # No exception is success
    hash(obj)


# Generated at 2022-06-22 06:36:32.019405
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    import unittest
    import itertools
    class test_test_ScalarToken___hash__(unittest.TestCase):
        @unittest.skip("test a hashable object")
        def test_true_1(self):
            assert ScalarToken(1, int(), int()).__hash__() == 1

        def test_true_2(self):
            assert ScalarToken(True, int(), int()).__hash__() == True

        @unittest.skip("test an unhashable object")
        def test_true_3(self):
            assert ScalarToken(dict(), int(), int()).__hash__() == {None: None}

    unittest.main(module="test_ScalarToken___hash__", exit=False)


# Generated at 2022-06-22 06:36:41.735213
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    tok = ScalarToken('a', 0, 0, 'a')
    assert(tok.string == 'a')
    assert(tok.start.line == 1)
    assert(tok.start.column == 1)
    assert(tok.start.index == 0)
    assert(tok.end.line == 1)
    assert(tok.end.column == 1)
    assert(tok.end.index == 0)
    assert(tok.lookup([]) == tok)
    assert(tok.lookup_key([]) == tok)
    assert(tok.value == 'a')



# Generated at 2022-06-22 06:36:51.222154
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(_value = 1, start_index = 2, end_index = 3, content = "test")
    token2 = Token(_value = 1, start_index = 2, end_index = 3, content = "test")
    token3 = ScalarToken(_value = 1, start_index = 2, end_index = 3, content = "test")
    token4 = ScalarToken(_value = 1, start_index = 2, end_index = 3, content = "test")
    assert token1 == token2
    assert token3 == token4
    assert not token1 == token3


# Generated at 2022-06-22 06:36:57.981726
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = Token(
        1, 
        0, 
        1, 
        "1"
    )
    t2 = Token(
        1, 
        0, 
        1, 
        "1"
    )
    assert t1 == t2
    assert not (t1 != t2)


# Generated at 2022-06-22 06:37:03.708486
# Unit test for constructor of class Token
def test_Token():
    t = Token(1, 1, 2, "Hello World!")
    assert t.value == 1
    assert t.string == "H"
    assert t.start.line == 1
    assert t.start.column == 1
    assert t.start.index == 1
    assert t.end.line == 1
    assert t.end.column == 2
    assert t.end.index == 2

    assert repr(t) == "Token(1)"


# Generated at 2022-06-22 06:37:06.474539
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class_ = Token
    assert_equal(
        class_("", 0, 1).__eq__(class_("", 0, 1)),
        True,
    )

# Generated at 2022-06-22 06:37:09.126744
# Unit test for constructor of class ListToken
def test_ListToken():
    # Given
    x = ListToken(['str','str'], 1, 5, 'string')
    # When
    result = x._get_value()
    # Then
    assert result == ['str','str']

# Generated at 2022-06-22 06:37:18.680470
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    from typesystem.tokenizer import Token
    from typesystem.tokenizer import ScalarToken
    from typesystem.tokenizer import ListToken
    from typesystem.tokenizer import DictToken
    token = Token(10, 20, 30, "content")
    assert repr(token) == "Token('content')"
    token = ScalarToken(10, 20, 30, "content")
    assert repr(token) == "ScalarToken('content')"
    token = ListToken([], 0, 0, "content")
    assert repr(token) == "ListToken('content')"
    token = DictToken({}, 0, 0, "content")
    assert repr(token) == "DictToken('content')"


# Generated at 2022-06-22 06:37:22.721354
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
  str_ = "0"
  start_index = 0
  end_index = 0
  content = str_
  token = Token(str_, start_index, end_index, content)
  result = token.lookup_key([])
  
  assert result is token


# Generated at 2022-06-22 06:37:29.189142
# Unit test for constructor of class DictToken
def test_DictToken():
    a = 1
    kwargs = {
        "value": {a: a},
        "start_index": 1,
        "end_index": 1,
        "content": ""
    }
    assert DictToken(**kwargs)._child_keys == {a: a}
    assert DictToken(**kwargs)._child_tokens == {a: a}

test_DictToken()

# Generated at 2022-06-22 06:38:25.075851
# Unit test for constructor of class Token
def test_Token():
    assert Token(
        "abcd efgh", start_index=1, end_index=3, content="abc defg"
    ).string == "abc"
    assert Token(
        "abcd efgh", start_index=1, end_index=3, content="abc defg"
    )._get_position(1) == Position(1, 2, 1)
    assert Token(
        "a\nb\nc\nd", start_index=4, end_index=7, content="a\nb\nc\nd"
    )._get_position(4) == Position(2, 3, 4)

# Generated at 2022-06-22 06:38:34.800810
# Unit test for constructor of class Token
def test_Token():
    def assert_token_prop(t, value, start_index, end_index, content):
        assert t._value == value
        assert t._start_index == start_index
        assert t._end_index == end_index
        assert t._content == content

    t = ScalarToken('hello', 1, 3, 'he')
    assert_token_prop(t, 'hello', 1, 3, 'he')

    t = ScalarToken('hello', 1, 3, 'he')
    assert_token_prop(t, 'hello', 1, 3, 'he')

    t = ScalarToken('hello', 1, 3, 'he')
    assert_token_prop(t, 'hello', 1, 3, 'he')


# Generated at 2022-06-22 06:38:41.294191
# Unit test for constructor of class Token
def test_Token():
    assert Token(value=None, start_index=0, end_index=0, content=None)._value == None
    assert Token(value=None, start_index=0, end_index=0, content=None)._start_index == 0
    assert Token(value=None, start_index=0, end_index=0, content=None)._end_index == 0
    assert Token(value=None, start_index=0, end_index=0, content=None)._content == None



# Generated at 2022-06-22 06:38:42.382215
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    pass


# Generated at 2022-06-22 06:38:45.770054
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token_child = ListToken([], 0, 0)
    token_parent = DictToken({token_child: token_child}, 0, 0)
    assert token_parent.lookup_key(['']) == token_child


# Generated at 2022-06-22 06:38:51.334944
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    s = Token(value=1, start_index=1, end_index=3)
    s2 = Token(value=1, start_index=1, end_index=3)
    assert s == s2
    assert not (s == 1)
    assert not (s == Token(value=2, start_index=1, end_index=3))
    assert not (s == Token(value=1, start_index=0, end_index=3))
    assert not (s == Token(value=1, start_index=1, end_index=4))


# Generated at 2022-06-22 06:38:52.203624
# Unit test for constructor of class DictToken
def test_DictToken():
    return DictToken()


# Generated at 2022-06-22 06:38:54.401091
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken(value={"key":"value"},start_index=1,end_index=4,content='value')


# Generated at 2022-06-22 06:38:57.784615
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    """
    Method __hash__ of class ScalarToken
    """
    scalar_token = ScalarToken(10, 0, 2, "10")
    assert hash(scalar_token) == hash(10)