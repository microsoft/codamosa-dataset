

# Generated at 2022-06-22 06:29:05.776766
# Unit test for constructor of class ListToken
def test_ListToken():
    assert 1==1

# Generated at 2022-06-22 06:29:15.093065
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # If class ScalarToken is tested, should comment out or delete the first 6 lines
    import io
    import typesystem
    from typesystem.parser import load
    # load content
    with open("/home/minh/dune/typesystem/tests/cases/case.yaml", "r") as f:
        #content = f.read()
        content = yaml.load(f)
        obj = load(content)
        #print(obj)
        #print(obj.fields.schema.items.type)
        #print(obj.fields.schema.to_dict())
        #print(obj.fields.schema.items)
    
    # If class ScalarToken is tested, should remove the next 4 lines and add "obj = ScalarToken('abc',0,2,'abc')"
    #obj = ListToken

# Generated at 2022-06-22 06:29:17.194263
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken({}, 0, 0)
    assert isinstance(token, Token)

# Generated at 2022-06-22 06:29:17.842817
# Unit test for constructor of class Token
def test_Token():
    assert True

# Generated at 2022-06-22 06:29:25.823000
# Unit test for constructor of class DictToken
def test_DictToken():
    test_dict = {'key1': 'value1', 'key2': 'value2'}
    test_args = ('', '', '', test_dict)
    test_kwargs = {}
    test_token = DictToken(*test_args, **test_kwargs)
    assert (getattr(test_token, '_child_keys') == {'key1': 'value1', 'key2': 'value2'})
    assert (getattr(test_token, '_child_tokens') == {'key1': 'value1', 'key2': 'value2'})


# Generated at 2022-06-22 06:29:28.581751
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    t = Token(0,0,0)
    assert repr(t) == 'Token(\'\')'

# Generated at 2022-06-22 06:29:38.145979
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    a = ScalarToken(value=5, start_index=0, end_index=0, content="This is a content")
    # Unit test for property string
    assert a.string == "This is a content"
    # Unit test for property value
    assert a.value == 5
    # Unit test for property start
    assert a.start == Position(1, 1, 0)
    # Unit test for property end
    assert a.end == Position(1, 1, 0)
    # Unit test for method lookup
    assert a.lookup(index=[1,2,3]) == None
    # Unit test for method lookup_key
    assert a.lookup_key(index=[1,2,3]) == None


# Generated at 2022-06-22 06:29:45.269540
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # @ScalarToken(value, start_index, end_index, content)
    #     value: Any
    #     start_index: int
    #     end_index: int
    #     content: str

    # Call the method
    a = ScalarToken(value = 'a', start_index = 1, end_index = 3, content = 'abc')
    a_hash = a.__hash__()
    assert a_hash == hash('a')


# Generated at 2022-06-22 06:29:52.885292
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    assert isinstance(
        ListToken(
            [
                DictToken(
                    {
                        ScalarToken(1, 0, 0): ScalarToken(2, 0, 0),
                        ScalarToken(3, 0, 0): ScalarToken(4, 0, 0),
                    },
                    0,
                    0,
                    "",
                )
            ],
            0,
            0,
            "",
        ).lookup_key([0, 1]),
        ScalarToken
    )

# Generated at 2022-06-22 06:30:04.822041
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    pos = Position(4, 2, 9)
    val = ['val1', 'val2']
    start_index = 0
    end_index = 8
    content = 'wertyu'
    t1 = Token(val, start_index, end_index, content)
    k = ['key1', 'key2']
    t1.lookup(k)
    t1.lookup_key(k)
    t1.start == pos
    t1.end == pos
    t1.string == 'ertyu'
    t1.value == ['val1', 'val2']
    t1.__repr__() == "Token(['ertyu'])"
    t2 = Token(val, start_index, end_index, content)
    t1 == t2

# Generated at 2022-06-22 06:30:16.879427
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    t1 = ScalarToken(1, 0, 0)
    t2 = ScalarToken(2, 0, 0)
    t3 = ScalarToken(3, 0, 0)
    t4 = ScalarToken(4, 0, 0)
    a = ListToken([t1, t2], 0, 0)
    b = DictToken({t3: t4}, 0, 0)
    t5 = DictToken({a: b}, 0, 0)
    assert t5.lookup_key([]) == t5
    assert t5.lookup_key([0]) == a
    assert t5.lookup_key([0, 0]) == t1
    assert t5.lookup_key([0, 1]) == t2
    assert t5.lookup_key([1]) == b
    assert t5.look

# Generated at 2022-06-22 06:30:19.198417
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(0, 0, 0, "")
    assert hash(token) == hash(0)


# Generated at 2022-06-22 06:30:22.966970
# Unit test for constructor of class Token
def test_Token():
    x = Token("value", 0, 10)
    assert x._value == "value"
    assert x._start_index == 0
    assert x._end_index == 10
    assert x._content == ""


# Generated at 2022-06-22 06:30:25.910699
# Unit test for constructor of class Token
def test_Token():
    a = Token(1,2,3)
    assert isinstance(a, Token)


# Generated at 2022-06-22 06:30:36.117061
# Unit test for constructor of class ListToken
def test_ListToken():
    listToken = ListToken("a", 1, 2)
    assert listToken._value == "a"
    assert listToken._start_index == 1
    assert listToken._end_index == 2
    assert listToken._content == ""
    assert listToken.string == "a"
    assert listToken._get_position(0) == Position(1, 1, 0)
    assert listToken.start == Position(1, 1, 1)
    assert listToken.end == Position(1, 1, 2)
    assert listToken.value == "a"
    assert listToken.lookup_key([0]) is None
    assert listToken.lookup_key([]) is None
    assert listToken.lookup([0]) is None
    assert listToken.lookup_key([0]) is None


# Generated at 2022-06-22 06:30:40.780654
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # ScalarToken.__hash__()
    token = ScalarToken([], None, None)
    # Verify the expected hash value.
    assert hash(token) == hash(token._value)

# Generated at 2022-06-22 06:30:48.959459
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class TestToken(Token):
        def _get_value(self) -> typing.Any:
            return self._value

        def _get_child_token(self, key: typing.Any) -> Token:
            return self._value[key]

        def _get_key_token(self, key: typing.Any) -> Token:
            return self._value.keys()[-1]

    token = TestToken([[], "hello"], 0, 4)
    assert token.lookup_key([0, 0]) == TestToken(token._value[0][0], token._start_index, token._start_index)
    assert token.lookup_key([1]) == TestToken(token._value[1], token._start_index, token._end_index)

# Generated at 2022-06-22 06:30:50.658899
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert not (__new__(Token).__repr__() != "{}({})"), "Expected value did not equal actual value"


# Generated at 2022-06-22 06:30:53.968443
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    obj = Token("value_name", 111, 333, 'content_name')
    obj2 = Token("value_name", 111, 333, 'content_name')
    assert obj == obj2


# Generated at 2022-06-22 06:30:57.526778
# Unit test for method lookup of class Token
def test_Token_lookup():
    token1=ListToken(1,1,1)
    assert(token1.lookup !=  [token._get_value() for token in token1._value])

# Generated at 2022-06-22 06:31:09.145153
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    tok = ScalarToken(
        value="foo",
        start_index=0,
        end_index=2,
        content="foo",
    )
    assert tok.value == "foo"
    assert tok.start.line == 1
    assert tok.start.column == 1
    assert tok.start.index == 0
    assert tok.end.line == 1
    assert tok.end.column == 4
    assert tok.end.index == 3
    assert tok.string == "foo"
    assert tok == ScalarToken(
        value="foo",
        start_index=0,
        end_index=2,
        content="foo",
    )


# Generated at 2022-06-22 06:31:12.902022
# Unit test for constructor of class ListToken
def test_ListToken():
    try:
        ListToken(value = [1,2], start_index = 0, end_index = 1)
    except:
        print("ListToken constructor is not working")
    else:
        print("ListToken constructor is working")

# Generated at 2022-06-22 06:31:13.526841
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    pass

# Generated at 2022-06-22 06:31:17.040411
# Unit test for constructor of class ListToken
def test_ListToken():
    # _ListToken.__init__(ListToken, *args: typing.Any, **kwargs: typing.Any) → None
    token = ListToken(1, 2, 3)
    print(token)


# Generated at 2022-06-22 06:31:28.110770
# Unit test for constructor of class Token
def test_Token():
    # initialize the test variables
    value = 1
    start_index = 2
    end_index = 3
    content = 'this is a string'
    token_object = Token(value, start_index, end_index, content)

    # assert the start position is correct
    assert token_object.start == Position(1, 4, 2)
    # assert the end position is correct
    assert token_object.end == Position(1, 5, 3)
    # assert the string is correct
    assert token_object.string == 'i'

    # assert the lookup method works correctly
    assert token_object.lookup([1]) == token_object

    # assert the lookup method works correctly
    assert token_object.lookup_key([1]) == token_object
    # assert the initialization str is correct
    # assert str(token_object) ==

# Generated at 2022-06-22 06:31:32.303748
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    obj = Token(0, 1, 2, 3)
    assert obj.__eq__([]) == False
    assert obj.__eq__(0) == False
    assert obj.__eq__(None) == False
    assert obj.__eq__('/tmp/Path') == False
    assert obj.__eq__('/tmp/Path'.encode()) == False
    assert obj.__eq__(b'/tmp/Path') == False


# Generated at 2022-06-22 06:31:37.639799
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    input_string= "1"
    index = [0, 0]
    token = ScalarToken(0, 0, 0, input_string)
    print(token.lookup_key(index)) # expected result is ScalarToken(1)

# Generated at 2022-06-22 06:31:43.965983
# Unit test for constructor of class DictToken
def test_DictToken():
    string = "{'a': 1}"
    dict_token = DictToken(eval(string), 0, len(string), content=string)
    assert dict_token.string == string
    assert dict_token.start == Position(1, 1, 0)
    assert dict_token.end == Position(1, len(string), len(string))
    assert dict_token._child_keys == {'a': ScalarToken('a', 1, 2)}
    assert dict_token._child_tokens == {'a': ScalarToken(1, 4, 4)}


# Generated at 2022-06-22 06:31:50.243260
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 2, 3) == Token(1, 2, 3)
    assert Token(1, 2, 3) != Token(2, 2, 3)
    assert Token(1, 2, 3) != Token(1, 3, 3)
    assert Token(1, 2, 3) != Token(1, 2, 4)


# Generated at 2022-06-22 06:32:00.513213
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    from uuid import uuid4
    from json import dumps
    from datetime import datetime
    from decimal import Decimal
    from typesystem.types import String, Integer, DateTime, Decimal

    def assert_repr(value: typing.Any) -> None:
        def test_repr(token: Token) -> None:
            assert repr(token) == "%s(%s)" % (token.__class__.__name__, repr(value))

        test_repr(ScalarToken(value, 0, len(value), value))
        test_repr(String.coerce(value))
        test_repr(Integer.coerce(value))
        test_repr(DateTime.coerce(value))
        test_repr(Decimal.coerce(value))


# Generated at 2022-06-22 06:32:33.762879
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    tok1 = ScalarToken(0, 0, 0)
    tok2 = ScalarToken(1, 1, 1)
    dict_token = DictToken({"a": tok1, "b": tok2}, 0, 1)
    assert dict_token.lookup_key(["a"]).start.index == 0
    assert dict_token.lookup_key(["b"]).start.index == 1

# Generated at 2022-06-22 06:32:37.543686
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    value = -789069
    start_index = -69868
    end_index = -23882
    content = "This is a test string"
    token = ScalarToken(value, start_index, end_index, content)
    assert token.__hash__() == hash(value)

# Generated at 2022-06-22 06:32:49.466044
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    import json
    import uuid
    from io import StringIO
    from typesystem.tokenizer import tokenize

    def _tokens(string):
        return list(tokenize(StringIO(string)))

    def _value(token):
        return token.value

    tokens = _tokens('{"a":[1,2,3]}')
    assert (_value(tokens[0]) == {'a': [1, 2, 3]})
    assert (str(tokens[0]) == "DictToken({'a': [1, 2, 3]})")

    tokens = _tokens(json.dumps(uuid.uuid4()))
    assert (_value(tokens[0]) == uuid.UUID('{0}'.format(_value(tokens[0]))))

# Generated at 2022-06-22 06:32:56.050880
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.exceptions import ParseError
    from typesystem.parse import parse_token
    source = '{"a": 1}'
    token1 = parse_token(source)
    token2 = parse_token(source)
    assert token1 == token2
    assert token1 != ParseError()
    try:
        assert token1 == 1
        assert False
    except AssertionError:
        pass
    except Exception as ex:
        assert False, 'Unexpected exception raised: {}'.format(ex)


# Generated at 2022-06-22 06:32:57.186127
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    ScalarToken(1, 0, 0, content='1')


# Generated at 2022-06-22 06:32:59.449650
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(1, 10, 20, "123456789")
    assert token._value == 1
    assert token._start_index  == 10
    assert token._end_index == 20
    assert token.string == "11"
    assert token.value == 1


# Generated at 2022-06-22 06:33:02.349293
# Unit test for constructor of class ListToken
def test_ListToken():
    pos = Position(1,1,1)
    assert ListToken(['a', 'b'], pos, pos)

# Generated at 2022-06-22 06:33:04.698391
# Unit test for method lookup of class Token
def test_Token_lookup():
    t = Token(None, 1, 2)
    assert t.lookup([]) == t

# Generated at 2022-06-22 06:33:13.261033
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(value=1, start_index=1, end_index=2, content="string")
    assert token.string == "s"
    assert token.value == 1
    assert token.start == Position(1, 1, 1)
    assert token.end == Position(1, 1, 2)

    # Unit test for repr of class ScalarToken
    assert repr(token) == "ScalarToken('s')"

    # Unit test for eq of class ScalarToken
    token_neq = ScalarToken(value=2, start_index=1, end_index=2, content="string")
    assert not (token == token_neq)


# Generated at 2022-06-22 06:33:14.789126
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    assert lookup_key([1,2]) == [1,2]

# Generated at 2022-06-22 06:33:56.241323
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    test_token = ListToken(
        [ScalarToken("a", 0, 1, content="a\nb")],
        0,
        1,
        content="a\nb",
    )
    assert test_token.lookup_key([0]) == ScalarToken("a", 0, 1, content="a\nb")


# Generated at 2022-06-22 06:33:57.613485
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken(1,1,1)


# Generated at 2022-06-22 06:34:09.120905
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class TestToken(Token):
        def _get_value(self) -> typing.Any:
            return self._value

    token1 = TestToken(value=1, start_index=0, end_index=0)
    token2 = TestToken(value=1, start_index=0, end_index=0)
    token3 = TestToken(value=2, start_index=0, end_index=0)
    token4 = TestToken(value=1, start_index=1, end_index=0)
    token5 = TestToken(value=1, start_index=0, end_index=1)

    assert (token1==token2)==True
    assert (token1==token3)==False
    assert (token1==token4)==False
    assert (token1==token5)==False

# Generated at 2022-06-22 06:34:12.060621
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(None, 0, 1, "content")
    assert token.__hash__() == hash(None)


# Generated at 2022-06-22 06:34:18.063578
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken(value=[1,2,3], start_index=0, end_index=5, content="hello")
    assert token.string == "hello"
    assert token.value == [1,2,3]
    assert token.start.line_no == 1
    assert token.start.column_no == 1
    assert token.start.index == 0
    assert token.end.line_no == 1
    assert token.end.column_no == 6
    assert token.end.index == 5

# Generated at 2022-06-22 06:34:26.657322
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class MyToken(Token):
        def _get_key_token(self, key: typing.Any) -> "Token":
            return{
                "tokens.name": token(3),
                "tokens.email": token(4),
            }[("tokens.%s" % key)]

    class MyToken1(Token):
        def _get_key_token(self, key: typing.Any) -> "Token":
            return{
                "tokens.name": token(5),
                "tokens.email": token(6),
            }[("tokens.%s" % key)]


# Generated at 2022-06-22 06:34:30.084355
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = ScalarToken('hello', 0, 5, 'hello world')
    assert repr(token) == "ScalarToken('hello')"



# Generated at 2022-06-22 06:34:42.073098
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.base import get_position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.base import Position
    from typesystem.errors import TypeCheckError
    from typesystem.errors import TypeCheckError
    from typesystem.errors import TypeCheckError
    from typesystem.errors import TypeCheckError


# Generated at 2022-06-22 06:34:50.606251
# Unit test for method lookup of class Token
def test_Token_lookup():
    dict_token = DictToken({}, 0, 0)
    list_token = ListToken([], 0, 0)

    scalar_token0 = ScalarToken(0, 0, 0)
    scalar_token1 = ScalarToken(1, 0, 0)
    scalar_token2 = ScalarToken(2, 0, 0)
    scalar_token3 = ScalarToken(3, 0, 0)
    scalar_token4 = ScalarToken(4, 0, 0)

    dict_token._value = {scalar_token0: scalar_token1, scalar_token2: scalar_token3}
    list_token._value = [scalar_token0, scalar_token1, scalar_token2, scalar_token3, scalar_token4]


# Generated at 2022-06-22 06:34:51.913087
# Unit test for method lookup of class Token
def test_Token_lookup():
    doctest_Token_lookup(Token())


# Generated at 2022-06-22 06:35:23.794676
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    tok = ScalarToken("hello", 1, 3)
    assert tok.string == "hello"
    assert tok.start.line_no == 1
    assert tok.end.line_no == 1
    assert tok.start.column_no == 2
    assert tok.end.column_no == 4
    assert tok is not None

# Generated at 2022-06-22 06:35:27.359557
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token('', 0, 0)
    assert repr(token) == "Token('')"
    assert token == Token('', 0, 0)
    assert token != Token('', 1, 0)
    assert token != Token('', 0, 1)

# Generated at 2022-06-22 06:35:31.725357
# Unit test for constructor of class Token
def test_Token():
    token = Token(value="something", start_index=0, end_index=4)
    assert token._value == "something"
    assert token._start_index == 0
    assert token._end_index == 4
    assert token._content == ""



# Generated at 2022-06-22 06:35:35.395927
# Unit test for constructor of class ListToken
def test_ListToken():
    lt = ListToken([1, 2, 3], '', '', '')
    assert lt.value == [1, 2, 3]


# Generated at 2022-06-22 06:35:36.972625
# Unit test for constructor of class Token
def test_Token():
    assert isinstance(Token(1, 2, 3), Token)

# Generated at 2022-06-22 06:35:41.518150
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    args = (2, 3, 4)
    token = ScalarToken(*args)
    assert token.__hash__() == hash(args[0])
    args = (2, 5, 8)
    token = ScalarToken(*args)
    assert token.__hash__() == hash(args[0])


# Generated at 2022-06-22 06:35:46.283610
# Unit test for constructor of class ListToken
def test_ListToken():
    Token.ListToken = ListToken
    content = "[1, 2, 3]"
    a = []
    for i in range(len(content)):
        a.append(Token(content[i], i, i))
    x = ListToken(a, 0, len(content) - 1, content)
    assert x.value == [1, 2, 3]

# Generated at 2022-06-22 06:35:48.211423
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(None, 1, 2)
    assert hash(token) == hash(None)

# Generated at 2022-06-22 06:35:52.769853
# Unit test for constructor of class Token
def test_Token():
    tk = Token('value', 1, 2)
    assert tk.string == ''
    assert tk.value == 'value'
    assert tk.start == Position(1, 1, 1)
    assert tk.end == Position(1, 2, 2)
# test_Token()


# Generated at 2022-06-22 06:36:05.001192
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    import io
    import yaml
    from typesystem.parse import parse_value
    from typesystem.types import List
    from typesystem.types import Object
    from typesystem.types import String

    s = io.StringIO("[{word: hello}, {word: world}]")
    value = parse_value(yaml.load(s), (List(Object([("word", String())])),))

    assert ListToken(value, 0, 21, '[{\n  word: hello\n}, {\n  word: world\n}]\n')\
           .lookup_key([0, "word"])\
           .end\
           == Position(3, 11, 22)

# Generated at 2022-06-22 06:37:54.916710
# Unit test for method lookup of class Token
def test_Token_lookup():
    l1 = [1,2,3]
    l2 = [l1,l1,l1]
    token1 = ListToken(l1,0,0)
    token2 = ListToken(l2,0,0)
    assert token2.lookup([1,1]).value == 1


# Generated at 2022-06-22 06:38:05.833978
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    """
    Given the following object:

    {
        'first': {
            'second': {'third': True}
        },
        'other': {'key': False}
    }
    """
    obj = {
        'first': {
            'second': {'third': True}
        },
        'other': {'key': False}
    }


# Generated at 2022-06-22 06:38:11.601279
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = ListToken(value=[
                      ScalarToken(value=5, start_index=0, end_index=0),
                      ScalarToken(value=12, start_index=2, end_index=2)],
                      start_index=0,
                      end_index=2,
                      content="{5 12}")
    # Assert Token.lookup_key(self, index: list) == Token
    assert token.lookup_key([0]) == ScalarToken(value=5, start_index=0, end_index=0)

# Generated at 2022-06-22 06:38:15.830362
# Unit test for constructor of class Token
def test_Token():
    value = 1
    content = '"a"'
    token = Token(value, 1, 3, content)
    assert isinstance(token, Token)


# Generated at 2022-06-22 06:38:26.677979
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    a = ScalarToken(3, 10, 11, ',\n')
    b = ListToken([a], 10, 21, ',\n')
    c = DictToken({b: b}, 10, 21, ',\n')
    try:
        assert c.lookup_key([0]) == ScalarToken(3, 10, 11, ',\n')
        assert c.lookup_key([0, 0]) == ScalarToken(3, 10, 11, ',\n')
        assert c.lookup_key([0, 1]) == ListToken([a], 10, 21, ',\n')
    except:
        print('Wrong answer in test_Token_lookup_key.')
        return False
    return True


# Generated at 2022-06-22 06:38:36.377923
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    from datetime import datetime
    from decimal import Decimal
    from typesystem import AnyOf, Boolean, Integer, Number, String

    schema = AnyOf(
        [Boolean(), Integer(), Number(), String()],
        serialization_map={"true": True, "false": False, "null": None},
        deserialization_map={True: "true", False: "false", None: "null"},
    )
    tokens = schema.tokenize(
        "[true, 123, 123456789, -1.5, 1.5, 1.5e-3, -1.5e3, 1.5e+3, 1.5e3, 'a string', 'true', 'false', 'null']"
    )

# Generated at 2022-06-22 06:38:39.550786
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(1, 0, 1)
    return token.__hash__() == hash(1)


# Generated at 2022-06-22 06:38:45.870152
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Construct instance of the class to be tested
    _Token = Token(
        value=None, start_index=None, end_index=None, content=None
    )
    # Use the composed class
    assert hasattr(_Token, "__repr__")
    assert hasattr(_Token, "__repr__")
    # Return value of function __repr__ of the class
    return _Token.__repr__


# Generated at 2022-06-22 06:38:47.239757
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    pass


# Generated at 2022-06-22 06:38:53.274134
# Unit test for constructor of class Token
def test_Token():
    value = "test"
    start_index = 0
    end_index = 3
    content = "abcd"
    a = Token(value, start_index, end_index, content)
    assert a._value == value and a._start_index == start_index and a._end_index == end_index and a._content == content, "should be the same"
