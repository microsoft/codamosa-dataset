

# Generated at 2022-06-22 06:29:10.132692
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(
        value="A", start_index=0, end_index=0, content="ABC"
        )
    assert hash(token) == hash("A")


# Generated at 2022-06-22 06:29:13.095395
# Unit test for constructor of class Token
def test_Token():
    try:
        t = Token(None, None, None)
        t.string
    except NotImplementedError:
        print('NotImplementedError')


# Generated at 2022-06-22 06:29:24.168379
# Unit test for constructor of class Token
def test_Token():
    # Test constructor of class ScalarToken
    token = ScalarToken(value = 1, start_index = 0, end_index = 0)
    assert token.value == 1
    assert token.string == "1"
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token

    # Test constructor of class DictToken
    token = DictToken(
        value = {ScalarToken("a", 0, 2, "ab"): ScalarToken("b", 2, 4, "bc")},
        start_index = 0,
        end_index = 4,
        content = "ab bc"
    )
    assert token.value == {"a": "b"}
   

# Generated at 2022-06-22 06:29:24.909144
# Unit test for constructor of class DictToken
def test_DictToken():
    assert True

# Generated at 2022-06-22 06:29:28.321656
# Unit test for constructor of class Token
def test_Token():
    a = ScalarToken(2, 1, 3)

    assert a.value == 2
    assert a.string == '2'
    assert a.start == Position(1, 1, 1)
    assert a.end == Position(1, 2, 3)
    assert a.lookup([]) == a
    assert a.lookup_key([]) == a
    assert repr(a) == "ScalarToken('2')"


# Generated at 2022-06-22 06:29:34.685161
# Unit test for method lookup of class Token
def test_Token_lookup():
    content = '{"age": 27}'
    index_content = '{"age": 27}'
    value = {"age": 27}
    start_index = 0
    end_index = len(content)-1
    token = DictToken(value, start_index, end_index, content)
    index = [0]
    result = token.lookup(index)
    assert result.string == '27'


# Generated at 2022-06-22 06:29:45.353810
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    from hamcrest import assert_that, equal_to
    from nose.tools import assert_raises
    with assert_raises(NotImplementedError):
      assert_that(ScalarToken(value='', start_index=0, end_index=0)._get_value(), equal_to(''))
    with assert_raises(NotImplementedError):
      assert_that(ScalarToken(value='', start_index=0, end_index=0)._get_child_token(key=[]), equal_to(''))
    with assert_raises(NotImplementedError):
      assert_that(ScalarToken(value='', start_index=0, end_index=0)._get_key_token(key=[]), equal_to(''))


# Generated at 2022-06-22 06:29:56.004037
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken(0,0,0)._get_value() == {}
    assert DictToken(0,0,0,{"a":1})[0] == 1
    assert DictToken(0,0,0,{"a":1}).end == Position(0,0,0)
    assert DictToken(0,0,0,{"a":1}) == DictToken(0,0,0,{"a":1})
    assert not DictToken(0,3,0,{"a":1}) == DictToken(0,0,0,{"a":1})
    assert DictToken(0,0,0,{"a":1})[0] == 1


# Generated at 2022-06-22 06:30:05.770492
# Unit test for constructor of class Token
def test_Token():
    assert Token(value=0, start_index=0, end_index=1).string == '0'
    assert Token(value=1.0, start_index=0, end_index=1).string == '1'
    assert Token(value='hello', start_index=0, end_index=1).string == 'h'
    assert Token(value=True, start_index=0, end_index=1).string == 'T'
    assert Token(value=False, start_index=0, end_index=1).string == 'F'
    assert Token(value=None, start_index=0, end_index=1).string == 'N'


# Generated at 2022-06-22 06:30:13.610404
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    assert ScalarToken(42,0,42).value == 42
    assert ScalarToken(42,0,42).start == Position(1,1,0)
    assert ScalarToken(42,0,42).end == Position(1,3,2)
    assert ScalarToken(42,0,42).string == "42"
    assert ScalarToken(42,0,42).lookup([]) == ScalarToken(42,0,42)
    assert ScalarToken(42,0,42).lookup_key([0]) == ScalarToken(42,0,42)


# Generated at 2022-06-22 06:30:29.749133
# Unit test for method lookup of class Token
def test_Token_lookup():
    string = (
        "a:\n"
        "    b:\n"
        "        c:\n"
        "            one: 1\n"
        "            two: 2\n"
        "            three: 3\n"
    )
    parser = Parser(string, "example")

    tree = parser.build_tree()

    a_token = tree.lookup(["a"])
    b_token = tree.lookup(["a", "b"])
    c_token = tree.lookup(["a", "b", "c"])
    
    assert a_token.value == {'b': {'c': {'one': 1, 'two': 2, 'three': 3}}}

# Generated at 2022-06-22 06:30:31.697903
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(42, 0, 2)
    assert hash(token)


# Generated at 2022-06-22 06:30:41.814986
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    start_index = 1
    end_index = 3
    content = "abc"

    try:
        list_token = ListToken([], 0, 0, "")
        list_token.lookup_key([0, 0])
        assert False
    except NotImplementedError:
        assert True

    try:
        dict_token = DictToken({}, 0, 0, "")
        dict_token.lookup_key([0])
        assert False
    except NotImplementedError:
        assert True

    #test for ScalarToken
    scalar_token = ScalarToken("a", start_index, end_index, content)
    assert scalar_token.lookup_key([0]) == scalar_token
    assert scalar_token.lookup_key([]) == scalar_token


# Generated at 2022-06-22 06:30:45.795887
# Unit test for constructor of class ListToken
def test_ListToken():
    t1 = ListToken([1,2,3],1,2, "123")
    print("The list token is: ", t1)
    print("The value of the list token is: ", t1._get_value())



# Generated at 2022-06-22 06:30:48.903296
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(1, 0, 0)

    result = token.__hash__()
    assert isinstance(result, typing.Any)


# Generated at 2022-06-22 06:30:55.789529
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    import builtins
    int_42 = builtins.int(42)
    token0 = ScalarToken(
        value=int_42,
        start_index=builtins.int(2),
        end_index=builtins.int(4),
        content="ab42cd",
    )
    expected = hash(int_42)
    actual = token0.__hash__()
    builtins.print(expected)
    builtins.print(actual)
    assert expected == actual


# Generated at 2022-06-22 06:30:59.513518
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken([1, 2, 3], 2, 3, 'abcde')
    print(token.string)

    token = ListToken([1, 2, 3], 2, 3)
    print(token.string)


# Generated at 2022-06-22 06:31:01.710756
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token(None, None, None)
    assert repr(token) == "Token(None)"

# Generated at 2022-06-22 06:31:05.717750
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = ListToken([0, 1], 0, 5, content="[0, 1]")
    key_token = token.lookup_key([0])
    assert key_token == ScalarToken(0, 1, 1, content="[0, 1]")

# Generated at 2022-06-22 06:31:08.633507
# Unit test for constructor of class DictToken
def test_DictToken():
    try:
        DictToken(1, 1, 2, "a")
    except:
        return True
    return False


# Generated at 2022-06-22 06:31:12.549505
# Unit test for constructor of class Token
def test_Token():
    pass


# Generated at 2022-06-22 06:31:14.441749
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    x = ScalarToken(42, 0, 42)
    assert hash(x) == hash(42)

# Generated at 2022-06-22 06:31:15.960777
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, None, None)
    assert token == token


# Generated at 2022-06-22 06:31:19.846068
# Unit test for constructor of class ListToken
def test_ListToken():
  test_string = "hello world\n"
  list_token = ListToken(value = [], start_index = 0, end_index = 11, content = test_string)
  assert list_token.string == test_string


# Generated at 2022-06-22 06:31:21.215141
# Unit test for constructor of class ListToken
def test_ListToken():
	assert ListToken('hello', 0, 0, content='world')


# Generated at 2022-06-22 06:31:25.567413
# Unit test for method lookup of class Token
def test_Token_lookup():
    a = ListToken([[1,2,3]])
    assert( a.lookup([0,1]).string == '2' )



# Generated at 2022-06-22 06:31:33.688350
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("A", 0, 1, "A")
    assert token.string == "A"
    assert token.value == "A"
    assert token.start == Position(1, 2, 1)
    assert token.end == Position(1, 2, 1)
    assert token.lookup([]) == token
    assert token.lookup_key([]) == token
    assert repr(token) == "ScalarToken('A')"
    assert hash(token) == hash("A")
    assert token == ScalarToken("A", 0, 1, "A")
    assert token != ScalarToken("B", 0, 1, "B")


# Generated at 2022-06-22 06:31:44.095769
# Unit test for constructor of class DictToken
def test_DictToken():
    def __init__(self, *args: typing.Any, **kwargs: typing.Any):
        assert args == (1, 2, 3, 4, 5)
        assert kwargs == {"a": 1, "b": 2, "c": 3}
        assert self._value == {"a": 1, "b": 2, "c": 3}
        assert self._child_keys == {"a": 1, "b": 2, "c": 3}
        assert self._child_tokens == {"a": 1, "b": 2, "c": 3}
        return NotImplemented
    DictToken.__init__ = __init__
    # Test callable
    DictToken(1, 2, 3, 4, 5, a=1, b=2, c=3)
    return True



# Generated at 2022-06-22 06:31:45.757250
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    assert ScalarToken('foo', 1, 1).string == 'f'


# Generated at 2022-06-22 06:31:50.241768
# Unit test for method lookup of class Token
def test_Token_lookup():
    # Create a Token object and call its lookup method
    t = Token(1, 2, 3, 'abc')
    result = t.lookup([])

    # Assert that the correct token was returned
    assert result == t

# Generated at 2022-06-22 06:32:10.868280
# Unit test for constructor of class DictToken
def test_DictToken():
    import sys
    import os
    t1 = os.path.abspath('.').split(os.path.sep)
    t1 = list(filter((lambda x: x != ''), t1))
    t2 = os.path.abspath(os.path.dirname(__file__)).split(os.path.sep)
    t2 = list(filter((lambda x: x != ''), t2))
    d = len(t1) - len(t2)
    if (d == 0):
        sys.path.append('../../')
    elif d == 1:
        sys.path.append('../')
    elif d == 2:
        sys.path.append('./')
    from tests.test_typesystem_base.test_position import test_Position
    test_Position()


# Generated at 2022-06-22 06:32:13.310252
# Unit test for constructor of class ListToken
def test_ListToken():
    foo = [1, 2, 3]
    ListToken(foo, 0, 3)



# Generated at 2022-06-22 06:32:18.477814
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    """Test method __repr__ of class Token"""
    scalar = ScalarToken("1", 0, 1, "12")
    assert eval(repr(scalar)) == scalar
    list = ListToken("2", 0, 2, "12")
    assert eval(repr(list)) == list
    dict = DictToken("3", 0, 2, "12")
    assert eval(repr(dict)) == dict


# Generated at 2022-06-22 06:32:20.778087
# Unit test for constructor of class ListToken
def test_ListToken():
    assert isinstance(ListToken({}, 0, 1, ""), Token) == True

# Generated at 2022-06-22 06:32:26.553984
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    value = 'dummy'
    start_index = 0
    end_index = 4
    content = "dummy"
    token = ScalarToken(value, start_index, end_index, content)
    assert hash(token) == hash(value)


# Generated at 2022-06-22 06:32:33.149190
# Unit test for constructor of class ListToken
def test_ListToken():
    # Arrange
    start_index = 0
    end_index = 2
    value = [1, 2, 3]

    # Act
    token = ListToken(
        value=value, start_index=start_index, end_index=end_index
    )

    # Assert
    assert token is not None
    assert token._value == value
    assert token._start_index == start_index
    assert token._end_index == end_index


# Generated at 2022-06-22 06:32:35.749082
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    instance = ScalarToken(42, 1, 1, "42")
    assert instance.__hash__() == 42, "__hash__ doesn't work"


# Generated at 2022-06-22 06:32:47.226943
# Unit test for constructor of class ListToken
def test_ListToken():
    # arrange
    class Token1(Token):
        def __init__(self, value, start_index, end_index, content):
            super().__init__(value, start_index, end_index, content)
    a = Token1(1, 1, 1, 'a')
    b = Token1(2, 1, 1, 'b')
    c = Token1(3, 1, 1, 'c')
    value = [a, b, c]
    start_index = 1
    end_index = 3
    content = 'abc'

    # assert
    listToken = ListToken(value, start_index, end_index, content)

    # act
    assert listToken == ListToken([a, b, c], 1, 3, 'abc')



# Generated at 2022-06-22 06:32:52.932789
# Unit test for constructor of class ListToken
def test_ListToken():
    a = ListToken(value=[1,2,3], start_index=1, end_index=2, content="123 456")
    assert a._start_index == 1
    assert a._end_index == 2
    assert a._content == "123 456"
    assert a._value == [1,2,3]



# Generated at 2022-06-22 06:32:54.710041
# Unit test for method lookup of class Token
def test_Token_lookup():
    # Test the method lookup of class Token
    # coverage: 100%
    assert True

# Generated at 2022-06-22 06:33:06.602516
# Unit test for constructor of class Token
def test_Token():
    assert Token(1, 2, 3)



# Generated at 2022-06-22 06:33:15.240335
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class T(Token):
        def __init__(
            self, value: typing.Any, start_index: int, end_index: int, content: str = ""
        ) -> None:
            self._value = value
            self._start_index = start_index
            self._end_index = end_index
            self._content = content

    t1 = T(1, 2, 3, "abcdefg")
    t2 = T(1, 2, 3, "hijklmn")
    t3 = T(2, 2, 3, "abcde")

    assert t1 == t2
    assert t1 != t3
    assert t2 != t3



# Generated at 2022-06-22 06:33:27.080478
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    key = 'key'
    value = 'value1'
    test_dict = {key: value}
    test_dict_token = DictToken(test_dict, 0, 3, test_dict)
    test_tuple = (1, 2, 3, 4)
    test_tuple_token = ListToken(test_tuple, 0, 3, test_tuple)
    index = [1]
    result = test_dict_token.lookup_key(index)
    assert result.value == value
    index = [0]
    result = test_tuple_token.lookup_key(index)
    assert result.value == 1
    try:
        result = test_tuple_token.lookup_key([0, 1])
    except Exception:
        pass

# Generated at 2022-06-22 06:33:30.093255
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken({"a": 2}, 0, 1, "a: 2")
    assert a.value == {"a": 2}


# Generated at 2022-06-22 06:33:35.940861
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    content = """
{
  "a": 1,
  "b": 2
}
"""
    tokens = list(tokenizer.Tokens(content))
    token = tokens[0]
    lookup_index = (1, 0)
    result = token.lookup_key(lookup_index)
    assert isinstance(result, Token)
    assert result.string == '"a"'

# Generated at 2022-06-22 06:33:40.017558
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(value=1, start_index=0, end_index=1)
    assert token._value == 1
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 2, 1)
    assert token.value == 1
    assert token.string == "1"


# Generated at 2022-06-22 06:33:47.717261
# Unit test for constructor of class Token
def test_Token():
    # test Token init with 3 arguments
    with pytest.raises(NotImplementedError):
        token = Token(None, None, None)
        print(token._get_value())
        print(token.string)

    # test Token init with 4 arguments
    with pytest.raises(NotImplementedError):
        token = Token(None, None, None, None)
        print(token._get_value())
        print(token.string)


# Generated at 2022-06-22 06:33:56.697424
# Unit test for method lookup of class Token
def test_Token_lookup():
    import pytest
    from textwrap import dedent
    from typesystem.tokenizer import parse
    from typesystem.token_indexer import TokenIndexer

    value = parse("""
    [
        {
            "foo": {"bar": "baz"},
            "bar": ["baz"]
        }
    ]
    """)

    token = TokenIndexer().index(value, "")

    assert repr(token.lookup([0])) == "ListToken('[\n    {\n        \"foo\": {\"bar\": \"baz\"},\n        \"bar\": [\"baz\"]\n    }\n]'\n)"

# Generated at 2022-06-22 06:33:59.825287
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    t = Token(" ",0,0)
    assert repr(t) == "Token(' ')"


# Generated at 2022-06-22 06:34:11.685336
# Unit test for method lookup of class Token
def test_Token_lookup():
    dict0 = {
        "foo": "bar",
        "baz": {"quux": "quuz"},
        "quux": 42,
        "quuz": [1, 2, 3],
    }
    from pprint import pprint
    from textwrap import dedent
    from typesystem.parse import Parser

    parser = Parser()
    token = parser.parse(dedent(f"""\
        {pprint(dict0)}
    """))

    assert token.lookup(["foo"]).value == "bar"
    assert token.lookup(["baz"]).value == {"quux": "quuz"}
    assert token.lookup(["baz", "quux"]).value == "quuz"
    assert token.lookup(["quux"]).value == 42

# Generated at 2022-06-22 06:34:50.863361
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    test_case = Token(value='hello', start_index=0, end_index=4, content='hello')
    expected = 'Token(\'hello\')'
    assert expected == test_case.__repr__()

# Generated at 2022-06-22 06:34:54.874538
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token_str = ScalarToken("this is a string.", 0, 5)
    assert token_str._value == "this is a string."
    assert token_str._start_index == 0
    assert token_str._end_index == 5


# Generated at 2022-06-22 06:34:55.920518
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    pass


# Generated at 2022-06-22 06:34:57.890326
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token=ScalarToken("Hello",1,1)
    assert token.string == "Hello"

# Generated at 2022-06-22 06:35:07.901809
# Unit test for method lookup of class Token
def test_Token_lookup():
    from typesystem.base import BaseType
    from typesystem.schema import Schema

    class MyBaseType(BaseType):
        pass
    class MySchema(Schema):
        items = [MyBaseType()]

    class MyListToken(ListToken):
        def __init__(self, value: typing.Any, start_index: int, end_index: int) -> None:
            super().__init__(value, start_index, end_index)

    value = "abcd"
    start_index = 0
    end_index = 3
    content = "abcd"
    token = MyListToken([MyBaseType(), MyBaseType(), MyBaseType()], start_index, end_index)
    assert token.lookup([0]) == MyBaseType()
    assert token.lookup([1]) == MyBaseType()

# Generated at 2022-06-22 06:35:11.234407
# Unit test for constructor of class Token
def test_Token():
  str1 = "abcd"
  str2 = "efgh"
  test_obj = Token(str1, 0, 3, str2)
  assert test_obj.string == str1


# Generated at 2022-06-22 06:35:16.133077
# Unit test for method lookup of class Token
def test_Token_lookup():
    list_token = ListToken([ScalarToken(1, 0, 1), ScalarToken(2, 2, 3)], 0, 3, "123")
    if list_token.lookup([0]).value == 1:
        if list_token.lookup([1]).value == 2:
            if list_token.lookup([1, 0]).value == 2:
                return True
    else:
        return False

# Generated at 2022-06-22 06:35:17.238019
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert False, "Test if needed"



# Generated at 2022-06-22 06:35:25.706834
# Unit test for method lookup of class Token
def test_Token_lookup():
    object_list=[DictToken({"a":ScalarToken(1,0,0),"b":ScalarToken(2,1,1)}),ScalarToken(1,0,0)]
    expect_token=ScalarToken(2,1,1)
    index=[0,"b"]
    assert object_list[0].lookup(index)==expect_token
    index2=[1]
    assert object_list[1].lookup(index2)==expect_token


# Generated at 2022-06-22 06:35:37.890890
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # set up dict
    dict_inputs = {"inputs": {"aa": {}, "bb": {}, "cc": {}}}
    # set up token
    token_inputs = Token(dict_inputs["inputs"], 0, 0)
    # set up child_tokens
    child_tokens = [
        Token(dict_inputs["inputs"]["aa"], 0, 0),
        Token(dict_inputs["inputs"]["bb"], 0, 0),
        Token(dict_inputs["inputs"]["cc"], 0, 0),
    ]
    # set up get_child_token and get_key_token
    token_inputs._get_child_token = lambda key: child_tokens.pop(0)
    token_inputs._get_key_token = lambda key: Token

# Generated at 2022-06-22 06:36:20.578961
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    t = ScalarToken(value=2, start_index=0, end_index=1)
    assert hash(t) == hash(2)


# Generated at 2022-06-22 06:36:31.517602
# Unit test for method lookup of class Token

# Generated at 2022-06-22 06:36:37.913462
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    x = ScalarToken(value=0, start_index=1, end_index=2)
    hash(x) == hash(0)

    class Foo:

        def __hash__(self):
            return 1

    x = ScalarToken(value=Foo(), start_index=1, end_index=2)
    hash(x) == hash(Foo())



# Generated at 2022-06-22 06:36:41.361230
# Unit test for constructor of class DictToken
def test_DictToken():
    import pprint
    d = {'a':'b','c':'d'}
    dict_token = DictToken(d, 0, 6)
    pprint.pprint(dict_token)

test_DictToken()

# Generated at 2022-06-22 06:36:43.975010
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    assert True
    # return True

# Generated at 2022-06-22 06:36:49.755104
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """Test __eq__ of class Token"""

    # Setup
    Token1 = Token(1,2,3)
    Token2 = Token(1,2,3)
    Token3 = Token(4,5,6)

    # Exercise
    result1 = Token1 == Token2
    result2 = Token1 == Token3

    # Verify
    assert result1 == True
    assert result2 == False

# Generated at 2022-06-22 06:36:51.561864
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(1, 1, 2)
    assert hash(token) == hash(1)


# Generated at 2022-06-22 06:37:03.417061
# Unit test for method lookup of class Token
def test_Token_lookup():
    # Test with nested ListToken
    token = ListToken([ListToken([ScalarToken(1,0,0), ScalarToken(2,1,1)],0,1)],0,1)
    assert token.lookup([0,1]).string == "2"
    # Test with nested DictToken
    token = DictToken({DictToken({ScalarToken("1",0,0):ScalarToken(2,1,1)},0,1): ScalarToken(3,2,2)}, 0, 2)
    assert token.lookup([{'1':2}, "3"]).string == "3"
    assert token.lookup([{'1':2}, 3]).string == "3"
    assert token.lookup([{'1':2}, 3])._get_value() == 3
    assert token

# Generated at 2022-06-22 06:37:11.760216
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for class Token
    token_0 = Token(None, None, None)
    token_1 = Token(None, None, None)
    assert_equal(token_0, token_1)

    token_2 = Token(None, None, None)
    token_2._end_index = 1
    assert_not_equal(token_0, token_2)

    token_3 = Token(None, None, None)
    token_3._start_index = 1
    assert_not_equal(token_0, token_3)

    token_4 = Token(None, None, None)
    token_4._get_value = lambda: 1
    assert_not_equal(token_0, token_4)



# Generated at 2022-06-22 06:37:13.400559
# Unit test for constructor of class ListToken
def test_ListToken():
    listTok = ListToken('something')
    assert listTok.__repr__() == "ListToken('something')"


# Generated at 2022-06-22 06:38:25.079189
# Unit test for method lookup of class Token
def test_Token_lookup():
    from mock_data.test_token_mock_data import TOKEN1
    token = Token(TOKEN1['value'], TOKEN1['start_index'], TOKEN1['end_index'])
    assert token.lookup([0]) == "1"
    


# Generated at 2022-06-22 06:38:35.357531
# Unit test for constructor of class Token
def test_Token():
    # Test constructor and string
    assert Token(1,2,3, '12345').string == '12345'[2:4]
    assert Token(1,2,3, '12345')._value == 1
    assert Token(1,2,3, '12345')._end_index == 3
    # Test start and end
    assert Token(1,2,3, '12345').start == Position(1,3,2)
    assert Token(1,2,3, '12345').end == Position(1,4,3)
    # Test lookup, lookup_key
    assert Token(1,2,3, '12345').lookup([]) == Token(1,2,3, '12345')

# Generated at 2022-06-22 06:38:37.682445
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    t = ScalarToken(1, 1,2, 3)
    assert id(t) != hash(t)
    assert 1 == hash(t)

# Generated at 2022-06-22 06:38:49.071291
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    assert 0 == ScalarToken(0, 0, 0).value
    assert 0.0 == ScalarToken(0.0, 0, 0).value
    assert 1j == ScalarToken(1j, 0, 0).value
    assert "" == ScalarToken("", 0, 0).value
    assert "a" == ScalarToken("a", 0, 0).value
    assert "hello, world" == ScalarToken("hello, world", 0, 0).value
    assert {} == ScalarToken({}, 0, 0).value
    assert set() == ScalarToken(set(), 0, 0).value
    assert [1, 2] == ScalarToken([1, 2], 0, 0).value
    assert (1, 2) == ScalarToken((1, 2), 0, 0).value


# Generated at 2022-06-22 06:38:58.233888
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from _parser import Parser
    from _lexer import Lexer
    from typesystem.base import METADATA, UNKNOWN
    s = "a: {b: c, d: e, f: g}"
    lexer = Lexer(s)
    parser = Parser(lexer)
    ast = parser.parse()
    token = ast.lookup_key([0, 0])
    assert token.string == "b"
    assert token.value == "b"
    token = ast.lookup_key([0, 1])
    assert token.string == "d"
    assert token.value == "d"


