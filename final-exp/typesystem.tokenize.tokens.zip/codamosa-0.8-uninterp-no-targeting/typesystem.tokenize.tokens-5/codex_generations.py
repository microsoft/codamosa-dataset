

# Generated at 2022-06-22 06:29:08.807843
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token("", 1, 2)
    assert str(token) is not None


# Generated at 2022-06-22 06:29:13.859514
# Unit test for constructor of class ListToken
def test_ListToken():
    x = [1, 2, 3]
    x_token = ListToken(x, 0, 5, "[1, 2, 3]")
    assert isinstance(x_token, ListToken)
    assert x_token.string == "[1, 2, 3]"
    assert x_token.value == [1, 2, 3]


# Generated at 2022-06-22 06:29:17.560727
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(0, 0, 0, "")
    # Assert if the hash of the token is equal to the hash of its value
    assert (hash(token) == hash(token.value))

# Generated at 2022-06-22 06:29:28.909772
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    print(Token(value=None, start_index=0, end_index=1, content=None).__repr__())
    print(Token(value=None, start_index=0, end_index=2, content=None).__repr__())
    print(Token(value=None, start_index=1, end_index=1, content=None).__repr__())
    print(Token(value=None, start_index=1, end_index=2, content=None).__repr__())
    print(Token(value=None, start_index=1, end_index=3, content=None).__repr__())
    print(Token(value=None, start_index=2, end_index=3, content=None).__repr__())

# Generated at 2022-06-22 06:29:39.002575
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    content = """
    {
        "a": "b"
    }
    """
    lu = {}
    state = {'lookup': lu}
    from jsonpointer.exceptions import JsonPointerException
    from jsonpointer.resolver import resolve_pointer
    from jsonpointer.tokenizer import Tokenizer

    tokenizer1 = Tokenizer(content)
    token1 = tokenizer1.tokenize()
    if token1 != None: pass
    lookup = {}
    lookup[('a',)] = token1._get_key_token('a')

    assert lookup == lu, 'Expected different values %s != %s' % (lookup, lu)



# Generated at 2022-06-22 06:29:44.072514
# Unit test for constructor of class ListToken
def test_ListToken():
    # Create some sample strings and indexes
    content = "    some content here "
    start_index = 8
    end_index = 17

    # Create some sample values
    value = 1

    # Perform "constructor"
    object = ListToken(value, start_index, end_index, content)



# Generated at 2022-06-22 06:29:46.295205
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    assert hash(ScalarToken([0, 0], 0, 0, {})) == hash([0, 0])


# Generated at 2022-06-22 06:29:58.223529
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    import json
    import unittest.mock as mock

    # mock object for class Token
    class MockToken():
        def __init__(self):
            self.lookup_result = None

        def lookup(self, index):
            return self.lookup_result

    token = MockToken()
    # mock object
    index = ['key', 0]
    token.lookup_result = {
        'a': {
            'key_token': 'value_token1', 
            'key_token2': 'value_token2', 
            'index': MockToken()
        }, 
        'b': {
            'key_token': 'value_token3', 
            'index': MockToken()
        }
    }

    # check the value of returned value of method lookup_key

# Generated at 2022-06-22 06:30:02.483734
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    def lookup_key_Token(index):
        token = Token(index, 0, 0)
        return token.lookup_key(index)

    assert lookup_key_Token([0]) == lookup_key_Token([0])


# Generated at 2022-06-22 06:30:08.526893
# Unit test for constructor of class ListToken
def test_ListToken():
    #Create a list token
    token_name = ListToken([], 5, 9, "")
    #Call the constructor
    token_name.__init__([], 5, 9, "")
    #Make sure it works
    assert token_name is not None



# Generated at 2022-06-22 06:30:19.363931
# Unit test for method lookup of class Token
def test_Token_lookup():
    from typesystem.parser import Parser
    from typesystem.types import String
    from typesystem.array import Array
    from typesystem.object import Object
    from typesystem.schemas import Schema
    from typesystem.utils.metadata import get_metadata_from_definition
    from typesystem.utils.metadata import MetaDefinition

    def parse_string(s):
        return Parser(s, schema=meta_schema).parse()


# Generated at 2022-06-22 06:30:28.870616
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Tests for class Token subclasses ScalarToken and DictToken
    assert ScalarToken(5, 2, 3, "ab5").__eq__(ScalarToken(5, 2, 3, "ab5"))
    dict_token = DictToken(
        {
            ScalarToken("a", 4, 5, "ab5"): ScalarToken("c", 6, 7, "ab5"),
            ScalarToken("b", 10, 11, "ab5"): ScalarToken("d", 12, 13, "ab5"),
        },
        2,
        13,
        "ab5",
    )

# Generated at 2022-06-22 06:30:35.057933
# Unit test for constructor of class ListToken
def test_ListToken():
    list1 = ['test1', 'test2']
    listtoken1 = ListToken(value=list1, start_index=0, end_index=6, content='test1, test2')
    assert listtoken1.value == ['test1', 'test2']
    assert listtoken1.string == 'test1, test2'


# Generated at 2022-06-22 06:30:41.081215
# Unit test for constructor of class Token
def test_Token():
    token1 = Token(1, 2, 3, 'abc')
    token2 = Token(value=1, start_index=2, end_index=3, content='abc')
    
    assert token1 == token2
    assert repr(token1) == 'Token(1)'
    assert repr(token2) == 'Token(1)'


# Generated at 2022-06-22 06:30:52.589790
# Unit test for constructor of class Token
def test_Token():    # pragma: nocover
    token = Token(value = 'a', start_index = 0, end_index = 0)
    assert token.string == 'a'
    assert token.value == 'a'
    assert token.start == (1,1,0)
    assert token.end == (1,1,0)
    assert token == Token(value = 'a', start_index = 0, end_index = 0)
    assert token != Token(value = 'a', start_index = 0, end_index = 1)
    assert token != Token(value = 'b', start_index = 0, end_index = 0)
    assert token != Token(value = 'b', start_index = 0, end_index = 1)
    assert token != Token(value = 'a', start_index = 1, end_index = 1)


# Generated at 2022-06-22 06:31:04.800521
# Unit test for method __repr__ of class Token

# Generated at 2022-06-22 06:31:10.560626
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    input = "5"
    value = 5
    start_index = 0
    end_index = len(input)-1
    content = input
    scalar_token = ScalarToken(value, start_index, end_index, content)
    assert scalar_token.string == input
    assert scalar_token.value == value

# Generated at 2022-06-22 06:31:11.648313
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    assert lookup_key(key=2) == "c"

# Generated at 2022-06-22 06:31:13.107561
# Unit test for constructor of class DictToken
def test_DictToken():
    print('test: constructor of class DictToken')
    pass

# Generated at 2022-06-22 06:31:19.846263
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(value = 1, start_index = 0, end_index = 1, content = "1")
    assert token.string == "1"
    assert token.value == 1
    assert token.start == Position(line_no = 1, column_no = 1, byte_index = 0)
    assert token.end == Position(line_no = 1, column_no = 2, byte_index = 1)
#Test ScalarToken
test_ScalarToken()

# Generated at 2022-06-22 06:31:32.416775
# Unit test for method lookup of class Token
def test_Token_lookup():
    from sources import Source
    from parsing import parse
    from tokenizers import tokenize
    source = Source.from_string("""{ "key": [1, 2, 3] }""")
    root_token = parse(source, tokenize(source))
    key_token = root_token.lookup_key([0])
    assert type(key_token) == ScalarToken
    assert key_token.value == "key"
    list_token = root_token.lookup([0])
    assert type(list_token) == ListToken
    assert list_token.value == [1, 2, 3]

# Generated at 2022-06-22 06:31:38.403368
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 1, 2, "aaa")
    token2 = Token(2, 3, 4, "bbb")
    assert(token1 == token1) is True
    assert(token2 == token2) is True
    assert(token1 == token2) is False


# Generated at 2022-06-22 06:31:47.140955
# Unit test for constructor of class Token
def test_Token():
    content = ""
    t = Token(value = 0, start_index = 0, end_index = 0, content = "")
    assert t.value == 0
    assert t.start.index == 0
    assert t.start.line == 1
    assert t.start.column == 1
    assert t.end.index == 0
    assert t.end.line == 1
    assert t.end.column == 1
    assert t.string == ""


# Generated at 2022-06-22 06:31:52.643747
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, 0, 0)
    assert token == Token(None, 0, 0)

    assert not token == Token(None, 0, 1)
    assert not token == Token(None, 1, 0)
    assert not token == Token(None, 1, 1)
    assert not token == "hello"

# Generated at 2022-06-22 06:31:56.842943
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    content = "Hello, World!"
    start_index = 0
    end_index = len(content) - 1
    token = Token(None, start_index, end_index, content)
    assert repr(token) == "Token('Hello, World!')"


# Generated at 2022-06-22 06:31:58.077131
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    pass
    ### START

    ### END

# Generated at 2022-06-22 06:32:03.219497
# Unit test for constructor of class Token
def test_Token():
    s = "abc"
    token = Token(123, 1, 2, s)
    assert token.string == 'b'
    assert token.start == Position(1, 2, 1)
    assert token.end == Position(1, 3, 2)



# Generated at 2022-06-22 06:32:08.316683
# Unit test for constructor of class DictToken
def test_DictToken():
    """
    >>> DictToken({"a": 1}, 1, 2, "foo")
    DictToken(1)

    >>> DictToken([], 1, 2, "foo")
    Traceback (most recent call last):
      ...
    TypeError: '_value' must be a dict, not a list
    """
    pass


# Generated at 2022-06-22 06:32:09.978140
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken([], 0, 0, content = "")


# Generated at 2022-06-22 06:32:15.285553
# Unit test for constructor of class DictToken
def test_DictToken():
    x = {"a":1, "b":2}
    my_DictToken = DictToken(x, 0, 0)
    assert my_DictToken._value == {"a":1, "b":2}
    assert my_DictToken._start_index == 0
    assert my_DictToken._end_index == 0


# Generated at 2022-06-22 06:32:33.149800
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    s = ScalarToken(10, 0, 5)
    assert s._start_index == 0
    assert s._end_index == 5
    assert s._get_value() == 10
    assert s.string == ''
    assert s.value == 10
    assert s.start == Position(1, 1, 0)
    assert s.end == Position(1, 6, 5)
    assert s.lookup([]) == s
    try:
        assert s.lookup_key([]) == s
        assert False
    except NotImplementedError:
        pass


# Generated at 2022-06-22 06:32:43.260058
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Case 1
    t1 = ScalarToken("value", 0, 0)
    t2 = ScalarToken("value", 0, 0)
    assert t1 == t2
    # Case 2
    t1 = ScalarToken("value", 0, 0)
    t2 = ScalarToken("value1", 0, 0)
    assert not t1 == t2
    # Case 3
    t1 = ScalarToken("value", 0, 0)
    t2 = ScalarToken("value", 1, 0)
    assert not t1 == t2
    # Case 4
    t1 = ScalarToken("value", 0, 0)
    t2 = ScalarToken("value", 0, 1)
    assert not t1 == t2



# Generated at 2022-06-22 06:32:49.308161
# Unit test for constructor of class DictToken
def test_DictToken():
    line_count = 0
    def _count_line(line):
        nonlocal line_count
        line_count += 1
    _count_line("")
    _count_line("")
    _count_line("")
    _count_line("")
    
    assert DictToken({}, 4, 7, "test")._value == {}
    assert DictToken({}, 4, 5, "")._value == {}

# Generated at 2022-06-22 06:32:52.811051
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    f = Token(value="a", start_index=0, end_index=0, content="a")
    assert f.__repr__() == "Token('a')"


# Generated at 2022-06-22 06:33:02.384500
# Unit test for constructor of class DictToken
def test_DictToken():
    p = Position(12, 3, 100)
    print(p)
    d = DictToken({ScalarToken("abc"): ScalarToken("def")}, 0, 1)
    assert d._get_value() == {'abc':'def'}
    assert d._start_index == 0
    assert d._end_index == 1
    # assert d.string == 'def'
    # assert d.value == 'def'
    # assert d.start == Position(0, 0, 0)
    # assert d.end == Position(0, 0, 0)
    # assert d.lookup_key(['abc']) == 'abc'

test_DictToken()



# Generated at 2022-06-22 06:33:07.592024
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    d1 = ScalarToken(1, 0, 0)
    d2 = ScalarToken(2, 0, 0)
    d3 = ScalarToken(1, 0, 0)

    assert hash(d1) != hash(d2)
    assert hash(d1) == hash(d3)


# Generated at 2022-06-22 06:33:18.648673
# Unit test for constructor of class Token
def test_Token():
    # Test the constructor of class Token
    start_index = 0
    end_index = 10
    test_value = 1
    test_content = "test_content"
    test_token = Token(test_value, start_index, end_index, test_content)

    assert test_token._value == test_value
    assert test_token._start_index == start_index
    assert test_token._end_index == end_index
    assert test_token._content == test_content

    # Test the method string
    test_string = test_token.string
    assert test_string == test_content[start_index:end_index+1]

    # Test the method value
    test_token_value = test_token.value
    assert test_token_value == test_value

    # Test the method start
    test_token

# Generated at 2022-06-22 06:33:20.408407
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken([], 0, 0, "")

# Generated at 2022-06-22 06:33:22.749087
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken(value=[], start_index=0, end_index=0, content="")


# Generated at 2022-06-22 06:33:25.209252
# Unit test for constructor of class ListToken
def test_ListToken():
    lt = ListToken([])
    assert lt._get_value() == [], "get_value() not working as expected"

# Generated at 2022-06-22 06:33:44.848336
# Unit test for constructor of class DictToken
def test_DictToken():
    assert 1==1

# Generated at 2022-06-22 06:33:51.022934
# Unit test for constructor of class ListToken
def test_ListToken():
    tokens = [ScalarToken(1, 0, 0), ScalarToken(2, 1, 1)]
    list_tokens = ListToken(tokens, 1, 3)
    # unit test for constructor
    assert list_tokens._start_index == 1
    assert list_tokens._end_index == 3
    # unit test for _get_value
    assert list_tokens._get_value() == [1, 2]



# Generated at 2022-06-22 06:33:54.084214
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token("value", 1, 10, "content")
    assert str(token) == "Token('value')"


# Generated at 2022-06-22 06:34:01.232713
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    c=ScalarToken(5,0,0)
    assert c._value==5
    assert c._start_index==0
    assert c._end_index==0
    assert c.string==''
    assert c.value==5
    assert c.start==Position(1,1,0)
    assert c.end==Position(1,1,0)
    assert c.lookup([0])==c 
    assert c.lookup_key([0])==c


# Generated at 2022-06-22 06:34:12.967737
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    # Test for constructor
    assert ScalarToken(1, 1, 2, "1")
    assert ScalarToken("2", 3, 4, "12")
    assert ScalarToken("3", 5, 6, "123")

    # Test for __eq__
    t1 = ScalarToken("1", 0, 1, "1")
    t2 = ScalarToken("2", 0, 1, "2")
    t3 = ScalarToken("1", 2, 3, "12")
    assert t1 == t1
    assert t1 != t2
    assert t1 != t3

    # Test for __repr__
    assert repr(t1) == "ScalarToken('1')"
    assert repr(t2) == "ScalarToken('2')"

# Generated at 2022-06-22 06:34:20.821304
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(value=True, start_index=0, end_index=3)
    assert token.value == True
    assert token.start.line_no == 1
    assert token.start.column_no == 1
    assert token.start.index == 0
    assert token.end.line_no == 1
    assert token.end.column_no == 4
    assert token.end.index == 3
    assert token.string == "true"


# Generated at 2022-06-22 06:34:26.365036
# Unit test for method lookup of class Token
def test_Token_lookup():
    t1 = Token(value=42, start_index=0, end_index=42, content='')
    assert t1.lookup([]) == t1
    assert t1.lookup(['aa']) == []
    assert t1.lookup_key(['aa']) == []

# Generated at 2022-06-22 06:34:37.242876
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    from .tokenizer import Tokenizer
 
    input_string = '{"$schema": "http://json-schema.org/draft-04/schema#", "type": "array", "items": {"type": "integer"}}'
    tokenizer = Tokenizer()
    tokenizer.setInput(input_string)
    token = tokenizer.getTokenList()
    assert repr(token) == 'TokenList([DictToken({\'\': DictToken({\'$schema\': ScalarToken(\'http://json-schema.org/draft-04/schema#\'), \'type\': ScalarToken(\'array\'), \'items\': DictToken({\'type\': ScalarToken(\'integer\')})})})])'


# Generated at 2022-06-22 06:34:39.771548
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken('hello',0,4,'hello world')
    assert token.string == 'hello'


# Generated at 2022-06-22 06:34:49.675093
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    __tracebackhide__ = True
    import sys
    import io

    from contextlib import contextmanager

    from _pytest.monkeypatch import MonkeyPatch
    from typesystem.token import ScalarToken

    @contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    monkeypatch = MonkeyPatch()

# Generated at 2022-06-22 06:35:59.563495
# Unit test for constructor of class ListToken
def test_ListToken():
   token = ListToken([], 0, 2)
   assert token.value == []
   assert token.start.line_number == 1
   assert token.end.line_number == 1
   assert token.start.column_number == 1
   assert token.end.column_number == 3

# Generated at 2022-06-22 06:36:05.466006
# Unit test for constructor of class ListToken
def test_ListToken():
    token = ListToken([Token], 1, 2, content="")
    assert token.string == ""
    assert token.value == [Token]
    assert token.start == Position(1, 1, 1)
    assert token.end == Position(1, 2, 2)
    assert token.lookup([0]) == Token
    assert token.lookup_key([0, 0]) == Token



# Generated at 2022-06-22 06:36:16.639002
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from typesystem.base import Any, Boolean, Integer, Number, Object, String
    from typesystem.base import validate

    schema = Object(
        properties={
            "foo": Any(properties={}, child=Object()),
            "bar": Boolean(properties={}, child=True),
            "baz": Integer(properties={}, child=1),
            "qux": Number(properties={}, child=1.0),
            "quux": String(properties={}, child="hello"),
        }
    )
    errors = validate(schema, {"foo": 100, "bar": True, "baz": 1, "qux": 1})
    token = errors[0].value.lookup_key(["quux"])

# Generated at 2022-06-22 06:36:23.470607
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from typesystem.components import Schema

    S = Schema.from_json([{"name": "A"}, {"name": "B"}])
    for index, token in (
        ([0, "name"], ScalarToken("A", 4, 6)),
        ([1, "name"], ScalarToken("B", 10, 12)),
    ):
        assert S.lookup_key(index) == token

# Generated at 2022-06-22 06:36:24.977295
# Unit test for method lookup of class Token
def test_Token_lookup():
   assert(Token(True, 0, 1).lookup((4,)).string=='True')

# Generated at 2022-06-22 06:36:36.030597
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # Test whether __hash__() of ScalarToken works correctly
    # Test: initialize an instance of ScalarToken
    instance0 = ScalarToken(
        value=93.128, start_index=0, end_index=5, content="93.128"
    )
    # Test: check whether the hash value is correctly returned
    assert isinstance(instance0.__hash__(), int)
    # Test: initialize an instance of ScalarToken
    instance1 = ScalarToken(
        value=86.2246, start_index=0, end_index=6, content="86.2246"
    )
    # Test: check whether the hash value is correctly returned
    assert isinstance(instance1.__hash__(), int)
    # Test: initialize an instance of ScalarToken

# Generated at 2022-06-22 06:36:41.164886
# Unit test for constructor of class Token
def test_Token():
    t = Token(
        value=None,
        start_index=0,
        end_index=1,
        content="{}"
    )
    assert t.string == "{}"
    assert t.value is None
    assert t.start == Position(1, 1, 0)
    assert t.end == Position(1, 2, 1)


# Generated at 2022-06-22 06:36:44.789080
# Unit test for constructor of class DictToken
def test_DictToken():
    a = 1
    dict_token = DictToken(a, 1, 1, "1")
    assert dict_token._value == a
    assert dict_token._start_index == 1
    assert dict_token._end_index == 1
    assert dict_token._content == "1"


# Generated at 2022-06-22 06:36:48.758511
# Unit test for constructor of class Token
def test_Token():
    t = Token("a", 0, 2, "abc")
    assert t.string == "a"
    assert t.start.line == 1
    assert t.start.column == 1
    assert t.end.line == 1
    assert t.end.column == 1

# Generated at 2022-06-22 06:36:52.104252
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    value = ""
    start_index = 0
    end_index = 0
    content = ""
    token = ScalarToken(value, start_index, end_index, content)
    assert token.__hash__() == hash(value)


# Generated at 2022-06-22 06:37:41.096231
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # assert ScalarToken._get_value() == ScalarToken._get_value()
    assert ScalarToken('a', 0, 1, 'abc') == ScalarToken('a', 0, 1, 'abc')



# Generated at 2022-06-22 06:37:51.858949
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    # ScalarToken object with value as 1, start_index as 1 and end_index as 3
    s = ScalarToken(1, 1, 3)
    assert s._value == 1
    assert s._start_index == 1
    assert s._end_index == 3
    assert s.string == ""
    assert s.value == 1
    assert s.start == Position(1, 1, 1)
    assert s.end == Position(1, 1, 3)
    assert s.lookup([1]) == None
    assert s.lookup_key([1]) == None
    # Test __repr__()
    assert s.__repr__() == "ScalarToken('')"
    # DictToken object with value as {}, start_index as 1 and end_index as 3

# Generated at 2022-06-22 06:37:55.149751
# Unit test for method lookup of class Token

# Generated at 2022-06-22 06:38:02.063962
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    j = [{"id": 1, "name": "name1"}, {"id": 2, "name": "name2"}]
    token = ListToken([DictToken({'id': ScalarToken(1), 'name': ScalarToken('name1')}), DictToken({'id': ScalarToken(2), 'name': ScalarToken('name2')})], 0, 1)
    assert token.lookup_key([1, 'id']) == ScalarToken(2)

# Generated at 2022-06-22 06:38:06.210053
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    list_token = ListToken(
        value=["a", "b", "c", "d"], start_index=0, end_index=3, content="abcd"
    )
    list_key_token = list_token.lookup_key([2])
    assert list_key_token.string == "c"

# Generated at 2022-06-22 06:38:16.267106
# Unit test for method lookup of class Token
def test_Token_lookup():
    from typesystem.exceptions import LookupError as token_lookup_err
    from typesystem import Structure, Scalar, List, Integer

    class MyStructure(Structure):
        a = Scalar(default="a")
        b = List(Scalar)
        c = List(Structure(d=Integer(default=1)))

    structure1 = MyStructure()
    structure2 = MyStructure(a="b", b=["c", "d"], c=[dict(d=1), dict(d=2)])

    def run_test(
        structure: MyStructure, index: list, expected: typing.Any
    ) -> typing.Any:
        token = structure.token
        actual = token.lookup(index).value
        assert actual == expected
        return actual


# Generated at 2022-06-22 06:38:21.755539
# Unit test for constructor of class ListToken
def test_ListToken():
    list_token = ListToken(["a", "b"], 0, 5)
    assert list_token.value == ["a", "b"]
    assert list_token.start == Position(1, 1, 0)
    assert list_token.end == Position(1, 6, 5)


# Generated at 2022-06-22 06:38:26.739587
# Unit test for constructor of class DictToken
def test_DictToken():
	dict1 = {1:"a", 2:"b"}
	test_token = DictToken(dict1,0,2,{1:"a", 2:"b"})
	print(test_token)

if __name__ == "__main__":
	test_DictToken()

# Generated at 2022-06-22 06:38:32.671233
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {1: 1, 2: 2}
    d[1] = 2
    token = DictToken(d, 0, 4)
    assert token.start == Position(1, 5, 4)
    assert token._value.keys() == {1, 2}
    assert token._child_keys == {1: 1, 2: 2}
    assert token._child_tokens == {1: 1, 2: 2}


# Generated at 2022-06-22 06:38:34.706325
# Unit test for method lookup of class Token
def test_Token_lookup():
    assert "_lookup_method" == Token._lookup.__name__
    