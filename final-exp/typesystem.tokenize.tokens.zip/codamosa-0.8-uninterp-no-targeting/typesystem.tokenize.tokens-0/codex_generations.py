

# Generated at 2022-06-22 06:29:13.180794
# Unit test for constructor of class DictToken
def test_DictToken():
    dictionary = DictToken(dictionary, start_index, end_index, content)

    assert dictionary.string == string
    assert dictionary.value == value
    assert dictionary.start == start
    assert dictionary.end == end


# Generated at 2022-06-22 06:29:19.411922
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # Create a ListToken with a value that contains a DictToken
    list_token = ListToken({"a": 1}, 0, 5, content="{'a': 1}\n")
    list_token._value = [DictToken({"a": 1}, 0, 5, content="{'a': 1}\n")]
    # Get the dictionary token and a list as index
    dict_token = list_token.lookup([0])
    # Check that the token returned by lookup_key is a ScalarToken with the value 'a'
    assert list_token.lookup_key([0, 'a']) == ScalarToken('a', 1, 3, content="{'a': 1}\n")

# Generated at 2022-06-22 06:29:25.362808
# Unit test for constructor of class Token
def test_Token():
    token = Token(0, 0, 0)
    assert token.value == 0
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 1, 0)



# Generated at 2022-06-22 06:29:27.964368
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("hi", 0, 3, content="hi")
    assert token._value == "hi"
    assert token._start_index == 0
    assert token._end_index == 2
    assert token._content == "hi"


# Generated at 2022-06-22 06:29:30.051258
# Unit test for method lookup of class Token
def test_Token_lookup():
    a = Token(1, 2, 3)
    assert a.lookup([1, 2, 3]) == None


# Generated at 2022-06-22 06:29:41.042227
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from pytest import raises
    from typesystem.base import Position
    from .primitives import String
    from .parser import parse
    from .token import ScalarToken
    from .token import DictToken
    from .token import ListToken
    from .token import Token
    from .token import ScalarToken
    from .token import DictToken
    from .token import ListToken
    String = String()
    String = String()
    String = String()
    String = String()
    String = String()
    String = String()
    String = String()
    String = String()
    String = String()
    String = String()
    String = String()
    String = String()
    String = String()
    String = String()
    String = String()
    String = String()
    String = String()
    String = String()
   

# Generated at 2022-06-22 06:29:42.335546
# Unit test for constructor of class ListToken
def test_ListToken():
    ListToken([1,2,3])

# Generated at 2022-06-22 06:29:53.714883
# Unit test for constructor of class ListToken
def test_ListToken():
    test = ListToken(value = [], start_index = 1, end_index = 3)
    assert test._value == []
    assert test._get_value() == []
    assert test._start_index == 1
    assert test._end_index == 3
    assert test._start.index == 1
    assert test._start.line == 0
    assert test._start.column == 0
    assert test._end.index == 3
    assert test._end.line == 0
    assert test._end.column == 0
    assert test.string == ""
    assert str(test) == "ListToken()"
    assert test.lookup([0]) == None
    assert test.lookup_key([0]) == None
    assert test.lookup_key([0, 1]) == None

# Generated at 2022-06-22 06:29:59.954831
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # should pass
    s = ['a', 'b', 'c']
    j = {'a': 1, 'b': [2], 'c': {'d': 3}, 'e': {'f': {'g': 4}}}
    t = DictToken({}, 0, 22, content=str(j))
    assert t.lookup_key(s) is not None

# Generated at 2022-06-22 06:30:04.814655
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    repr_ = repr
    repr_ = repr_.__get__
    repr_.__defaults__ = (None,) * len(repr_.__defaults__)
    repr_.__kwdefaults__ = {}
    token = Token(1,1,1,1)
    assert repr_(token) == "Token(1)"


# Generated at 2022-06-22 06:30:16.035795
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken([1, 2, 3], 1, 3)

# Generated at 2022-06-22 06:30:16.651797
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    assert None

# Generated at 2022-06-22 06:30:24.027159
# Unit test for constructor of class DictToken
def test_DictToken():
    dict1 = {
        "a": 1,
        "b": 2
    }
    dict2 = {
        "a": 2,
        "c": 3
    }
    test_token = DictToken(dict1, 2, 10, "a b k i l e")
    assert test_token._child_keys == dict1
    assert test_token._child_tokens == dict2
    assert test_token._start_index == 2
    assert test_token._end_index == 10
    assert test_token._content == "a b k i l e"

# Generated at 2022-06-22 06:30:28.196867
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    obj = ScalarToken(value='str', start_index=0, end_index=1, content='hello, world!')
    assert hash(obj) == hash('str')



# Generated at 2022-06-22 06:30:30.045714
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # TODO: Implement.
    assert False # TODO: remove or implement test.


# Generated at 2022-06-22 06:30:39.565889
# Unit test for constructor of class DictToken
def test_DictToken():
    value = {"dict": {"key": "token"}}
    start_index = 5
    end_index = 10
    content = "dict_content"

    dict_token = DictToken(value, start_index, end_index, content)

    assert dict_token.string == "dict"
    assert dict_token.start.line_no == 1
    assert dict_token.start.column_no == 6
    assert dict_token.start.index == 5
    assert dict_token.end.line_no == 1
    assert dict_token.end.column_no == 11
    assert dict_token.end.index == 10
    assert dict_token.value == {"dict": {"key": "token"}}
    assert dict_token.lookup([0]).string == "dict"
    assert dict_token.lookup([0]).start

# Generated at 2022-06-22 06:30:50.832204
# Unit test for method lookup of class Token
def test_Token_lookup():
    input = '{"a":1, "b":2, "c":3 }'
    token = {
        'start_index': 0,
        'end_index': len(input) - 1,
        'value': {
            'start_index': 0,
            'end_index': len(input) - 1,
            'value': {
                'a': {
                    'start_index': 2,
                    'end_index': 6,
                    'value': 1
                },
                'b': {
                    'start_index': 9,
                    'end_index': 13,
                    'value': 2
                },
                'c': {
                    'start_index': 16,
                    'end_index': 20,
                    'value': 3
                },
            },
        }
    }
    dict_token = Dict

# Generated at 2022-06-22 06:30:54.591938
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    content = "test"
    start_index = 0
    end_index = 4
    value = 5
    test = ScalarToken(value, start_index, end_index, content)
    assert test.value == value



# Generated at 2022-06-22 06:30:59.039410
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("test", 0, 0)
    assert token._value == "test"
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._content == ""


# Generated at 2022-06-22 06:31:05.803273
# Unit test for method lookup of class Token
def test_Token_lookup():
    d = {'a': 1, 'b': 2}
    t = DictToken({'a': ScalarToken(1, 1, 2), 'b': ScalarToken(2, 4, 5)}, 1, 5, 'ab')
    assert t.lookup([0]) == ScalarToken(1, 1, 2)
    assert t.lookup([1]) == ScalarToken(2, 4, 5)



# Generated at 2022-06-22 06:31:22.455822
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    from .lexer import Token
    from .lexer import NumberToken
    from .lexer import StringToken
    from .lexer import ListToken
    from .lexer import DictToken
    from .parser import Object
    from .parser import Scalar
    from .parser import String
    from .parser import Integer
    from .parser import Decimal
    from .parser import Boolean
    from .parser import Null
    from .parser import List
    from .parser import Dict
    from .parser import Variable
    from .lexer import NameToken
    from .lexer import CharToken
    from .parser import BinaryOp
    from .parser import UnaryOp
    from .lexer import BinaryOpToken
    from .lexer import UnaryOpToken
    from .parser import If
    from .lexer import IfToken


# Generated at 2022-06-22 06:31:27.759829
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(value='value', start_index=0, end_index=0, content='')
    assert token.__eq__(token)
    assert isinstance(token, Token)
    assert token.__eq__(None) is False
    assert token.__eq__(True) is False


# Generated at 2022-06-22 06:31:31.908462
# Unit test for constructor of class ListToken
def test_ListToken():
    tlist = []
    for i in range(5):
        tlist.append(ScalarToken(i, 0, 0, ''))
    lt = ListToken(tlist, 0, 0, '')
    assert(lt._get_value() == [0, 1, 2, 3, 4])

# Generated at 2022-06-22 06:31:37.734715
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    return

    # TODO: Implement unit test
    # print("- test_Token_lookup_key()")

    # # Create unit test here
    # test_Token = Token()
    # test_index = []
    # test_Token.lookup_key(test_index)

# Generated at 2022-06-22 06:31:39.826030
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    instance = ScalarToken(None, 0, 0)
    result = instance.__hash__()
    assert result == hash(None)


# Generated at 2022-06-22 06:31:44.827739
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    content = "Hello World"
    token = ScalarToken(value = content, start_index = 0, end_index = len(content) - 1)
    assert token.string == content


# Generated at 2022-06-22 06:31:51.295458
# Unit test for constructor of class DictToken
def test_DictToken():
    assert len(DictToken.__init__.__code__.co_varnames) == 6
    assert len(DictToken.__init__.__code__.co_args) == 5
    assert len(DictToken.__init__.__code__.co_kwonlyargs) == 0
    assert len(DictToken.__init__.__code__.co_defaults) == 0
    assert len(DictToken.__init__.__code__.co_posonlyargs) == 0
    assert DictToken.__init__.__code__.co_flags == 192


# Generated at 2022-06-22 06:32:01.340252
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # Verify dict of ScalarToken class
    expected_hash_dict = {
        42: -9013648558903472135,
        'Inhumans': 7296762242464030439,
        None: -8523718652907838008,
        'Devil Dinosaur': -6760150285847993934,
        'awesome': 4287124856477457136,
        'Groovy.': -6362528459659718783,
        'idk': -7879248576633370137,
        '\n': -8691137779631235759,
        ' ': -8691137779631235759,
        '\t': -8691137779631235759,
    }


# Generated at 2022-06-22 06:32:07.360669
# Unit test for constructor of class Token
def test_Token():
    assert Token(1, 2, 3, "some string").string == "some string"
    assert Token(1, 2, 3, "some string").value == 1
    assert Token(1, 2, 3, "some string").start == Position(1, 1, 2)
    assert Token(1, 2, 3, "some string").end == Position(1, 1, 3)


# Generated at 2022-06-22 06:32:12.999799
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    tok1 = ScalarToken(2,0,0)
    tok2 = ScalarToken(2,0,0)
    tok3 = ScalarToken(4,0,0)
    assert tok1 == tok2
    assert tok1 != tok3

# Generated at 2022-06-22 06:32:17.716637
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    assert False, "Test not implemented"

# Generated at 2022-06-22 06:32:20.773480
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken({"a": 1})
# test_DictToken()


# Generated at 2022-06-22 06:32:26.542828
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # Test Case 1
    assert Token(0, 0, 0, content="").lookup_key([1]) == Token(0, 0, 0, content="")

    # Test Case 1
    assert Token(0, 0, 0, content="").lookup_key([0]) == Token(0, 0, 0, content="")

    # Test Case 1
    assert Token(0, 0, 0, content="").lookup_key([-1]) == Token(0, 0, 0, content="")



# Generated at 2022-06-22 06:32:33.803399
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(value=True, start_index=0, end_index=3)
    assert repr(token) == "ScalarToken('true')"
    assert token.string == "true"
    assert token.value == True
    assert token.start.line_no == 1
    assert token.start.column_no == 1
    assert token.start.index == 0
    assert token.end.line_no == 1
    assert token.end.column_no == 4
    assert token.end.index == 3


# Generated at 2022-06-22 06:32:45.082283
# Unit test for method lookup of class Token
def test_Token_lookup():
    class F(Token):
        def __init__(self, v, s, e, cont=""):
            self._value = v
            self._start_index = s
            self._end_index = e
            self._content = cont
        def _get_value(self):
            return self._value
        def _get_child_token(self, key):
            return self._value[key]
        def _get_key_token(self, key):
            raise NotImplementedError  # pragma: nocover
    testDict = {'a':1, 'b':{'c':3, 'd':4}, 'e':[5,6]}
    testToken = F(testDict, 0, 1, "abce")
    assert testToken.lookup([]) == testToken
    assert testToken.lookup

# Generated at 2022-06-22 06:32:46.716647
# Unit test for method lookup of class Token
def test_Token_lookup():
    assert Token(1, 0, 2).lookup([]).string == "1"


# Generated at 2022-06-22 06:32:50.257009
# Unit test for method lookup of class Token
def test_Token_lookup():
  new_list = [1,2,3]
  new_token = Token(new_list, 0, 3)
  assert new_token.lookup(1) == 2

# Generated at 2022-06-22 06:33:01.713473
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class TokenA(Token):
        pass
    
    class TokenB(Token):
        pass
    
    # noinspection PyUnusedLocal
    def is_token_equal(token, other):
        # type: (Token, Token) -> bool
        return token == other
    
    
    token = TokenA("token", 1, 2)
    # noinspection PyTypeChecker
    assert not is_token_equal(token, None)
    assert not is_token_equal(token, "token")
    assert not is_token_equal(token, TokenB("token", 1, 2))
    assert is_token_equal(token, TokenA("token", 1, 2))
    
    
    token.__class__ = TokenB
    assert is_token_equal(token, TokenB("token", 1, 2))
   

# Generated at 2022-06-22 06:33:05.276543
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = Token({"a": 10}, 0, 15, "{'a': 10}")
    assert token.lookup_key([0, "a"]) is not None

# Generated at 2022-06-22 06:33:07.332999
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    json = ScalarToken("foo", 0, 2)
    assert hash(json) == hash("foo")



# Generated at 2022-06-22 06:33:17.813379
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    t = ScalarToken(
        1,
        2,
        3,
        "",
    )
    hash(t)


# Generated at 2022-06-22 06:33:29.867241
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class FakeToken(Token):
        def _get_value(self) -> typing.Any:
            return self._value
        def _get_child_token(self, key: typing.Any) -> "Token":
            return self._value[key]
        def _get_key_token(self, key: typing.Any) -> "Token":
            return self._value[key]
    content = ''
    token = FakeToken(
        value = [{'a': 'b', 'c': 'd'}, {'e': 'f', 'g': 'h'}],
        start_index = 0, end_index = len(content),
        content = content)
    index = [0, 'c']

# Generated at 2022-06-22 06:33:33.760818
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    a = ScalarToken("a", 1, 2)
    assert a._value == "a"
    assert a._start_index == 1
    assert a._end_index == 2
    assert a.string == "a"



# Generated at 2022-06-22 06:33:41.488503
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    tok =  ScalarToken(value = 'a', start_index = 0, end_index = 0, content = 'a')
    assert tok.string == 'a'
    assert tok.value == 'a'
    assert tok.start.line_no == 1
    assert tok.start.column_no == 1
    assert tok.start.index == 0
    assert tok.end.line_no == 1
    assert tok.end.column_no == 1
    assert tok.end.index == 0
    assert tok.lookup([]) == tok
    assert tok.lookup_key([]) == tok


# Generated at 2022-06-22 06:33:49.408810
# Unit test for constructor of class DictToken
def test_DictToken():
    d1 = {'a': 'b'}
    d2 = {'b': 'c'}
    t1 = DictToken(d1, d1, d1)
    t2 = DictToken(d2, d2, d2)
    d1['a'] = t1
    d2['b'] = t2
    assert t1.value == {'a': t1}
    assert t2.value == {'b': t2}
    assert t1 == t1
    assert t2 == t2
    assert t1 != t2

# Generated at 2022-06-22 06:34:01.814947
# Unit test for constructor of class ListToken
def test_ListToken():
    lt = list()
    lt.append(ScalarToken(1, 0, 1, "1"))
    lt.append(ScalarToken(2, 1, 2, "1"))
    lt.append(ScalarToken(3, 2, 3, "1"))
    lt.append(ScalarToken(4, 3, 4, "1"))
    lt.append(ScalarToken(5, 4, 5, "1"))
    lt.append(ScalarToken(6, 5, 6, "1"))
    lt.append(ScalarToken(7, 6, 7, "1"))
    lt.append(ScalarToken(8, 7, 8, "1"))
    lt.append(ScalarToken(9, 8, 9, "1"))
    lt

# Generated at 2022-06-22 06:34:05.355563
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1, 0, 2)
    token2 = Token(1, 0, 2)
    assert token1 == token2


# Generated at 2022-06-22 06:34:08.770298
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    t = ScalarToken(
        value="token_value",
        start_index=1,
        end_index=2,
        content="token_content"
    )
    assert t.__hash__() == hash("token_value")


# Generated at 2022-06-22 06:34:11.282112
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(1,1,2)
    token2 = Token(1,1,2)
    assert token1 == token2


# Generated at 2022-06-22 06:34:20.108531
# Unit test for method lookup of class Token

# Generated at 2022-06-22 06:34:40.801139
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    assert ScalarToken('test_value', 1, 2).string == 'test_value'
    assert ScalarToken('test_value', 1, 2).value == 'test_value'
    assert ScalarToken('test_value', 1, 2).start == Position(line_no=1, column_no=1, index=1)
    assert ScalarToken('test_value', 1, 2).end == Position(line_no=1, column_no=2, index=2)
    assert ScalarToken('test_value', 1, 2) == ScalarToken('test_value', 1, 2)


# Generated at 2022-06-22 06:34:43.610730
# Unit test for constructor of class ListToken
def test_ListToken():
    list_token = ListToken([1, 2], 0, 3, "abc\ndef")
    assert list_token._get_value() == [1, 2]


# Generated at 2022-06-22 06:34:53.431517
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from .reader import StringTokenReader
    from .utils import TokenizerError
    from typesystem.types import Object

    class Foo(Object):
        bar = Object(fields={
            'baz': {
                'type': 'integer',
                'required': 'true'
            }
        })

    token_reader = StringTokenReader('{"bar": 42}')
    token = token_reader.get_next_token()
    foo = Foo()
    try:
        foo.validate(token.value)
    except TokenizerError as e:
        index = e.index
        error_token = token.lookup_key(index)
        assert error_token.string == 'bar'
    assert token.string == '{"bar": 42}'
    assert token.lookup([0]).string == '"bar"'

# Generated at 2022-06-22 06:34:56.176994
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Calling __repr__(self) of class Token
    t = Token(1, 2, 3)
    assert repr(t) == "Token('1')"


# Generated at 2022-06-22 06:35:05.884844
# Unit test for constructor of class ListToken
def test_ListToken():
        token = ListToken([1,2,3], 1, 2, "ab51ab")
        assert(token.string == "5")
        assert(token.value == [1,2,3])
        assert(token.start.line == 1)
        assert(token.start.column == 2)
        assert(token.start.index == 1)
        assert(token.end.line == 1)
        assert(token.end.column == 3)
        assert(token.end.index == 2)
        assert(repr(token) == "ListToken('5')")
        



# Generated at 2022-06-22 06:35:15.834967
# Unit test for method lookup of class Token
def test_Token_lookup():
    content = "XYZ"
    start_index = 0
    end_index = 2
    # 创建对象
    token = Token(123, start_index, end_index, content)
    # 调用方法_get_position
    start = token._get_position(0)
    end = token._get_position(2)
    # 断言
    assert (start.line_no == 1)
    assert (start.column_no == 1)
    assert (start.index == 0)
    assert (end.line_no == 1)
    assert (end.column_no == 3)
    assert (end.index == 2)
    # 调用方法lookup
    index = []
    token = token.lookup(index)


# Generated at 2022-06-22 06:35:26.883831
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    test_value = {
        "a": {
            "b": {
                "c": 10
            }
        }
    }
    test_token = DictToken(
        {
            ScalarToken("a", 0, 0): DictToken(
                {
                    ScalarToken("b", 2, 2): DictToken(
                        {
                            ScalarToken("c", 4, 4): ScalarToken(10, 6, 6)
                        },
                        0,
                        7
                    )
                },
                0,
                8
            )
        },
        0,
        9
    )
    index = ["a", "b", "c"]
    assert test_token.lookup(index)._value == test_value["a"]["b"]["c"]
    assert test_token.lookup_key

# Generated at 2022-06-22 06:35:39.154794
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Setup
    value_1_1 = 5
    start_index_1_1 = 6
    end_index_1_1 = 4
    content_1_1 = ""
    token_1_1 = Token(value_1_1, start_index_1_1, end_index_1_1, content_1_1)
    value_1_2 = 8
    start_index_1_2 = 6
    end_index_1_2 = 4
    content_1_2 = ""
    token_1_2 = Token(value_1_2, start_index_1_2, end_index_1_2, content_1_2)
    value_1_3 = 5
    start_index_1_3 = 9
    end_index_1_3 = 4
    content_1_3 = ""

# Generated at 2022-06-22 06:35:42.687385
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken("hello", 0, 4) == ListToken("hello", 0, 4)
    assert "hello" == ListToken("hello", 0, 4)
    assert ListToken("hello", 0, 4) == "hello"


# Generated at 2022-06-22 06:35:52.760845
# Unit test for constructor of class Token
def test_Token():
    import string
    from typesystem.base import Position
    a = Token(
        value = 2,
        start_index = 2,
        end_index = 2,
        content = "string"
    )
    assert(a._value == 2)
    assert(a._start_index == 2)
    assert(a._end_index == 2)
    assert(a._content == "string")
    assert(a.string == 'r')
    assert(a.value == 2)
    assert(a.start == Position(1, 2, 2))
    assert(a.end == Position(1, 2, 2))
    assert(a.lookup(2) == a)
    assert(a.lookup_key(2) == a)

# Generated at 2022-06-22 06:36:16.245562
# Unit test for constructor of class ListToken
def test_ListToken():
    from pyserde import serialize
    from pyserde import deserialize
    from pyserde import data_model
    from typesystem.types import ListType
    from typesystem.types import AnyType

    csv_type = ListType(ListType(AnyType))
    csv_data = deserialize(csv_type, [["a", "b"], ["c", "d"]])
    assert isinstance(csv_data, data_model.ListType)

    csv_data = deserialize(csv_type, [["a", "b"]])
    assert isinstance(csv_data, data_model.ListType)

    csv_data = deserialize(csv_type, [["a"]])
    assert isinstance(csv_data, data_model.ListType)

    csv_data = deserial

# Generated at 2022-06-22 06:36:20.163300
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert repr(Token(0, 0, 0)) == "Token('0')"
    assert repr(Token(0, 0, 1, "0")) == "Token('0')"
    assert repr(Token(0, 0, 2, "01")) == "Token('01')"

# Generated at 2022-06-22 06:36:23.750439
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    t = Token(1, 2, 3, 4)
    assert repr(t) == "Token(1)"


# Generated at 2022-06-22 06:36:28.290962
# Unit test for constructor of class ListToken
def test_ListToken():
    t = ListToken([], 0, 10)
    assert t.value == []
    assert t.string == ''
    assert t.start.line_no == 1
    assert t.start.column_no == 1
    assert t.end.line_no == 1
    assert t.end.column_no == 1



# Generated at 2022-06-22 06:36:39.747444
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    t = ScalarToken(1, 0, 1)
    assert t.string == "1"
    assert t.value == 1
    assert t.start.line_no == 1 and t.start.column_no == 1
    assert t.end.line_no == 1 and t.end.column_no == 1

    t = ScalarToken(4.0, 0, 2)
    assert t.string == "4.0"
    assert t.value == 4.0
    assert t.start.line_no == 1 and t.start.column_no == 1
    assert t.end.line_no == 1 and t.end.column_no == 3

    t = ScalarToken("42", 0, 2)
    assert t.string == '42'
    assert t.value == "42"
    assert t.start.line

# Generated at 2022-06-22 06:36:51.078114
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    assert ScalarToken('string', 0, 5) == ScalarToken('string', 0, 5)
    with pytest.raises(NotImplementedError):
        ScalarToken('string', 0, 5)._get_value()
    assert ScalarToken('string', 0, 5).string == 'string'
    assert ScalarToken('string', 0, 5).start == Position(1, 6, 5)
    assert ScalarToken('string', 0, 5).end == Position(1, 6, 5)
    with pytest.raises(NotImplementedError):
        ScalarToken('string', 0, 5)._get_child_token(0)
    with pytest.raises(NotImplementedError):
        ScalarToken('string', 0, 5)._get_key_token('0')

# Generated at 2022-06-22 06:36:56.675035
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    TokenA = Token(value=1, start_index=0, end_index=1, content="")
    TokenB = Token(value=2, start_index=0, end_index=0, content="")
    assert not TokenA == TokenB

# Generated at 2022-06-22 06:37:03.583083
# Unit test for method lookup of class Token
def test_Token_lookup():
    from typesystem.base import String
    from typesystem.compiler import compile_schema
    from typesystem.compiler.tokens import DictToken
    schema = compile_schema({"name": String()})
    assert isinstance(schema.lookup([0, "name"]), DictToken)

# Generated at 2022-06-22 06:37:05.707399
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert repr(Token(None, None, None)) == 'Token(None)'


# Generated at 2022-06-22 06:37:11.150385
# Unit test for constructor of class DictToken
def test_DictToken():
  dict_token = DictToken({}, 0, 1)
  assert dict_token.__repr__() == "DictToken({})"
  assert dict_token._value == {}
  assert dict_token._start_index == 0
  assert dict_token._end_index == 1


# Generated at 2022-06-22 06:37:54.013740
# Unit test for method lookup of class Token
def test_Token_lookup():
    content = "foo bar baz"
    token = ScalarToken("foo", 0, 2, content)
    assert token.lookup([0]).string == "foo"


# Generated at 2022-06-22 06:38:02.308496
# Unit test for method lookup of class Token
def test_Token_lookup():
    class Token(Token):
        def _get_value(self):
            pass
        def _get_child_token(self, key):
          return key
    tokens = [Token("a", 0, 1), Token("b", 2, 3)]
    token = Token(tokens, 4, 5)
    assert token.lookup([0]) == "a"
    assert token.lookup([1]) == "b"
    assert token.lookup([2]) == 2
    assert token.lookup([3]) == 3


# Generated at 2022-06-22 06:38:06.112291
# Unit test for constructor of class Token
def test_Token():
    t1 = Token(1, 2, 3, "123")
    assert t1._value == 1
    assert t1._start_index == 2
    assert t1._end_index == 3
    assert t1._content == "123"

# Generated at 2022-06-22 06:38:08.265169
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(1, 1, 2)
    assert token.__hash__() == hash(1)



# Generated at 2022-06-22 06:38:18.265614
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    t1 = ScalarToken('a', 4, 5)
    print(token_constructor_test.__doc__)
    print(t1.string)
    print(t1.value)
    print(t1.start)
    print(t1.end)
    assert t1.string == 'a'
    assert t1.value == 'a'
    assert t1.start.line_no == 1
    assert t1.start.column_no == 1
    assert t1.start.index == 4
    assert t1.end.line_no == 1
    assert t1.end.column_no == 2
    assert t1.end.index == 5


# Generated at 2022-06-22 06:38:23.492282
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    content = "a:b\n"
    start_index = 0
    end_index = 1
    value = "a"
    obj = Token(
        value, start_index, end_index, content
    )
    index = [0]
    obj_return = obj.lookup_key(index)
    assert isinstance(obj_return, Token)


# Generated at 2022-06-22 06:38:27.682501
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken([]) == ListToken([])
    assert ListToken([ScalarToken('asdf', 0, 3)]) == ListToken([ScalarToken('asdf', 0, 3)])


# Generated at 2022-06-22 06:38:28.785049
# Unit test for constructor of class ListToken
def test_ListToken():
    assert ListToken


# Generated at 2022-06-22 06:38:37.562537
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token(value = 1, start_index = 1, end_index = 2, content = "abc")
    token2 = Token(value = 1, start_index = 1, end_index = 2, content = "abd")
    token3 = Token(value = 1, start_index = 1, end_index = 3, content = "abc")
    token4 = Token(value = 1, start_index = 0, end_index = 2, content = "abc")
    token5 = Token(value = 2, start_index = 1, end_index = 2, content = "abc")
    assert token1 == token2

    assert token1 != token3
    assert token1 != token4
    assert token1 != token5



# Generated at 2022-06-22 06:38:41.865202
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Setup
    token = Token("value", 5, 6, "content")

    # Exercise
    result = repr(token)

    # Verify
    assert result == "Token('content')"

