

# Generated at 2022-06-22 06:29:06.838173
# Unit test for constructor of class DictToken
def test_DictToken():
    with pytest.raises(NotImplementedError):
        test = DictToken("test", 0, 10, "")
        test._get_value()


# Generated at 2022-06-22 06:29:10.290681
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # Initialize test data
    key = 1
    index = [key]
    token = None

    # Invoke method
    result = token.lookup_key(index)

    # Check result
    assert result == token._get_key_token(key)

# Generated at 2022-06-22 06:29:13.898088
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    # Preparation
    value = ScalarToken(99, 0, 1)
    # Action
    result = repr(value)
    # Assertion
    assert result == "ScalarToken('99')"


# Generated at 2022-06-22 06:29:24.994849
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from typesystem.tokenize import tokenize
    from typesystem.types import Array
    from typesystem.types import Dictionary
    from typesystem.types import Integer
    from typesystem.types import new_schema

    schema = new_schema(Dictionary({"amount": Integer, "transactions": Array(Integer)}))
    data = {"amount": 10, "transactions": [1, 2, 3]}
    token = tokenize(schema, data)
    res = token.lookup_key(index=(0, 'transactions', 1))
    assert res is not None
    assert res.start.index == 4
    assert res.end.index == 4
    assert res.end._column_no == 6
    assert res.end._line_no == 1


if __name__ == '__main__':
    test_Token_lookup

# Generated at 2022-06-22 06:29:27.672908
# Unit test for constructor of class ListToken
def test_ListToken():
    string = '{"pokemon_species": "Sandslash", "trainer": "Ash Ketchum", "pokemon_type": "Ground"}'
    a = ListToken(string)
    assert a.string == string


# Generated at 2022-06-22 06:29:34.516511
# Unit test for constructor of class Token
def test_Token():
    token = Token(value=1, start_index=2, end_index=3, content="xyz")
    assert token._value == 1
    assert token._start_index == 2
    assert token._end_index == 3
    assert token._content == "xyz"
    assert token.string == "x"
    assert token.value == 1
    assert token.start.index == 2
    assert token.end.index == 3
    assert repr(token) == "Token('x')"
    assert token.lookup([]).string == "x"
    assert token.lookup_key([]).string == "x"
    assert token == Token(value=1, start_index=2, end_index=3, content="xyz")

# Generated at 2022-06-22 06:29:45.216229
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    class MockedDictToken(DictToken):
        def _get_key_token(self, key: typing.Any) -> Token: # pragma: nocover
            if key == "color":
                return ScalarToken("color", 0, 4, "color")
            if key == "power":
                return ScalarToken("power", 9, 13, "color")

    class MockedListToken(ListToken):
        def _get_child_token(self, key: typing.Any) -> Token: # pragma: nocover
            if key == 0:
                return MockedDictToken({"color": "red", "power": "strong"}, 0, 13, "color: red\npower: strong")

# Generated at 2022-06-22 06:29:49.743131
# Unit test for constructor of class DictToken
def test_DictToken():
    t = DictToken({}, 0, 5)
    assert t._child_keys == {}
    assert t._child_tokens == {}
    assert t._value == {}
    assert t._start_index == 0
    assert t._end_index == 5


# Generated at 2022-06-22 06:29:56.059396
# Unit test for constructor of class ListToken
def test_ListToken():
    def test_ListToken():
        list1 = ListToken(1, 2, 3, start_index=2, end_index=40, content=None)
        assert list1.start == Position(1, 2, 2)
        assert list1.end == Position(1, 2, 40)
        assert list1.string == ''
        assert list1.value == 1

    test_ListToken()



# Generated at 2022-06-22 06:30:02.965307
# Unit test for constructor of class ListToken
def test_ListToken():
    text = "\"Hello\""
    token = ScalarToken("Hello", 0, len(text)-1, text)
    text = "[" + text + "]"
    tokens = ListToken([token], 0, len(text)-1, text)
    assert tokens._value == [token]
    assert tokens._start_index == 0
    assert tokens._end_index == len(text)-1
    assert token._content == text


# Generated at 2022-06-22 06:30:17.084871
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token1 = Token("val1", 1, 2, "content")
    token2 = Token("val1", 2, 3, "content")
    token3 = Token("val1", 1, 2, "content")
    token4 = Token("val2", 1, 2, "content")
    assert token1 == token3
    assert token1 != token2
    assert token1 != token4
    assert token1 != 5



# Generated at 2022-06-22 06:30:25.516112
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    t = ScalarToken('Value', 1, 2, 'Some text')
    assert repr(t) == "ScalarToken('Value', 'Some text')"

    t = DictToken({1: ScalarToken('Value', 1, 2, 'Some text')}, 1, 2, 'Some text')
    assert repr(t) == "DictToken({1: ScalarToken('Value', 'Some text')}, 'Some text')"

    t = ListToken([ScalarToken('Value', 1, 2, 'Some text')], 1, 2, 'Some text')
    assert repr(t) == "ListToken([ScalarToken('Value', 'Some text')], 'Some text')"

# Generated at 2022-06-22 06:30:28.397646
# Unit test for constructor of class Token
def test_Token():
    assert Token(1,2,3) == Token(1,2,3)
    assert Token(1,2,3) != Token(1,2,6)


# Generated at 2022-06-22 06:30:31.124903
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken("", 1, 2)
    print(dict_token)
    assert dict_token == DictToken("", 1, 2)


# Generated at 2022-06-22 06:30:35.259827
# Unit test for constructor of class ListToken
def test_ListToken():
  lst = ListToken(['abc', 'def'], 0, 9)
  assert lst.value == ['abc', 'def']

# Generated at 2022-06-22 06:30:45.672441
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t1 = ScalarToken(value="123", start_index=1, end_index=3)
    t2 = ScalarToken(value="123", start_index=1, end_index=3)
    assert t1 == t2
    assert t2 == t1

    t3 = ScalarToken(value="1", start_index=1, end_index=3)
    assert t1 != t3

    t4 = ListToken([t1])
    t5 = ListToken([t2])
    assert t4 == t5
    assert t5 == t4

    t6 = ListToken([t3])
    assert t4 != t6



# Generated at 2022-06-22 06:30:50.514977
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    content = "123456789"
    token = ListToken([ScalarToken(str(i), i, i, content) for i in range(10)], 0, 9, content)
    assert token.lookup_key([2])._get_position(2).index == 2
    
    

# Generated at 2022-06-22 06:31:01.119847
# Unit test for method lookup of class Token
def test_Token_lookup():
    # test ScalarToken
    scalar_token = ScalarToken(2, 3, 4)
    assert scalar_token.lookup([]) is scalar_token
    with pytest.raises(IndexError):
        scalar_token.lookup([0])
    # test DictToken
    key1_token = ScalarToken(1, 1, 2)
    value1_token = ScalarToken(2, 2, 3)
    key2_token = ScalarToken(3, 3, 4)
    value2_token = ScalarToken(4, 4, 5)
    child_pairs = [
        (key1_token, value1_token),
        (key2_token, value2_token),
    ]
    child_dict = dict(child_pairs)

# Generated at 2022-06-22 06:31:10.060525
# Unit test for constructor of class Token
def test_Token():
    assert Token(value='', start_index=0, end_index=0, content='').start == Position(1,1,0)
    assert Token(value='', start_index=0, end_index=0, content='\n').start == Position(1,1,0)
    assert Token(value='', start_index=0, end_index=1, content='a').start == Position(1,1,0)
    assert Token(value='', start_index=0, end_index=1, content='\na').start == Position(1,1,0)
    assert Token(value='', start_index=0, end_index=2, content='ab').start == Position(1,1,0)

# Generated at 2022-06-22 06:31:15.312145
# Unit test for method lookup of class Token
def test_Token_lookup():
    # Create a new instance of token for unit test,
    # and execute the method lookup of the class Token.
    # input: target: Token; index: list; output: token
    target = Token('test', 'start', 'end', 'content')
    index = ['test']
    result = target.lookup(index)
    assert result == 'test'


# Generated at 2022-06-22 06:31:22.351041
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = Token(0, 0, 0)
    index = [1, 2]
    token.lookup_key(index)



# Generated at 2022-06-22 06:31:27.219811
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = Token("A", 0, 2)
    result = str(token)
    expected = "Token('A')"
    assert result == expected
test_Token___repr__()


# Generated at 2022-06-22 06:31:30.712145
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # Maybe not a good test, but the purpose is to make the code 100% tested.
    token = ScalarToken(0, 0, 0)
    assert token.__hash__() == hash(token.value)


# Generated at 2022-06-22 06:31:32.982734
# Unit test for method lookup of class Token
def test_Token_lookup():
    t = Token(value=1, start_index=1, end_index=1, content='test')
    assert t.lookup(1) == NotImplementedError

# Generated at 2022-06-22 06:31:38.449610
# Unit test for constructor of class ListToken
def test_ListToken():
    list_token = ListToken([])
    assert list_token is not None
    assert list_token._value == []
    assert list_token._start_index == 0
    assert list_token._end_index == 0
    assert list_token._content == ""


# Generated at 2022-06-22 06:31:43.341050
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    d1 = DictToken({})
    assert repr(d1) == 'DictToken({})'
    # test_Token_method__repr__end



# Generated at 2022-06-22 06:31:47.054492
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    print("Testing: __hash__ of ScalarToken")
    test = ScalarToken(1,0,0)
    assert test.__hash__ == ScalarToken.__hash__
    assert test.__hash__() == hash(1)


# Generated at 2022-06-22 06:31:58.761973
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    content = "a = {'b': 'c'}"
    start = 0
    end = len(content) - 1
    child_key_start = 3
    child_key_end = child_key_start + 1
    child_value_start = child_key_end + 3
    child_value_end = child_value_start + 1

    class MyDictToken(DictToken):
        def __init__(self, value: dict, start_index: int, end_index: int) -> None:
            super().__init__(value, start_index, end_index, content=content)


# Generated at 2022-06-22 06:32:05.115935
# Unit test for constructor of class ListToken
def test_ListToken():
    a = ['1', '2', '3']
    b = Token(a, 1, 9, '1,2,3')
    assert b._content == "1,2,3"
    assert b._value == ['1', '2', '3']
    assert b._start_index == 1
    assert b._end_index == 9


# Generated at 2022-06-22 06:32:06.297433
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken()


# Generated at 2022-06-22 06:32:13.136258
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    """
    Test for method __repr__ of class Token
    """
    t = Token(None, 1, 2, content='test')
    assert repr(t) == 'Token(\'test\')'

# Generated at 2022-06-22 06:32:17.070058
# Unit test for constructor of class ListToken
def test_ListToken():
    a = ListToken( list(), 0, 1)
    print (a._get_value())
    print (a._get_child_token(0))

test_ListToken()

# Generated at 2022-06-22 06:32:22.610511
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken(
        1,  # value
        3,  # start_index
        5,  # end_index
        "  foo"  # content
    )
    __expected__ = hash(1)
    assert (token.__hash__() == __expected__)


# Generated at 2022-06-22 06:32:27.651376
# Unit test for constructor of class Token
def test_Token():
    string = "a"
    t = Token(string, 0, 1)
    assert(t.start.line_no == 1)
    assert(t.start.column_no == 1)
    assert(t.start.index == 0)
    assert(t.end.line_no == 1)
    assert(t.end.column_no == 2)
    assert(t.end.index == 1)
    assert(t.string == "a")
    

# Generated at 2022-06-22 06:32:35.965455
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    s = ScalarToken(1,0,1)
    assert s._value == 1
    assert s._start_index == 0
    assert s._end_index == 1
    assert s.string == 1
    assert s.value == 1
    assert s.start == Position(1,1,0)
    assert s.end == Position(1,1,1)
    # assert s.lookup(1) == Token
    # assert s.lookup_key(0,1) == Token
    assert s._get_position(2) == Position(1,1,2)
    assert s.__repr__() == "ScalarToken(1)"
    assert s.__eq__(s) == True


# Generated at 2022-06-22 06:32:38.584920
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken == DictToken(value = dict(a = 1, b = 2), start_index = 1, end_index = 3, content = "")


# Generated at 2022-06-22 06:32:47.937050
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    t = ScalarToken(value="abc", start_index=0, end_index=2)
    assert type(t).__init__(t,"abc",0,2)
    assert type(t.__hash__(t)).__name__ == "NoneType"
    assert type(t.__repr__(t)).__name__ == "str"
    assert type(t.__eq__(t,"abc")).__name__ == "bool"
    assert t._get_value(t) == "abc"
    assert t.string == "abc"
    assert t.value == "abc"
    assert type(t.start).__name__ == "Position"
    assert type(t.end).__name__ == "Position"


# Generated at 2022-06-22 06:32:53.335564
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken("a", 0, 1)
    assert token._get_value() == "a"
    assert token.string == "a"
    assert token.value == "a"
    position = token._get_position(2)
    assert position.line_no == 1 and position.column_no == 2 and position.index == 2


# Generated at 2022-06-22 06:33:03.431092
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # It should correctly compare two tokens
    def test_Token___eq__A():
        t1 = ScalarToken(1, 1, 3, "123")
        t2 = ScalarToken(1, 1, 3, "123")
        assert t1 == t2
    # It should return false if the tokens are not of the same type
    def test_Token___eq__B():
        t1 = ScalarToken(1, 1, 3, "123")
        t2 = DictToken({}, 1, 3, "123")
        assert not (t1 == t2)
    # It should return false if the tokens have different start indexes
    def test_Token___eq__C():
        t1 = ScalarToken(1, 1, 3, "123")
        t2 = ScalarToken(1, 0, 3, "123")
       

# Generated at 2022-06-22 06:33:06.302002
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    from typesystem.token import Token
    token = Token(b'', 0, 10, 'abcde')
    assert repr(token) == "Token('abcde')"

# Generated at 2022-06-22 06:33:14.815271
# Unit test for constructor of class DictToken
def test_DictToken():
    # Arrange
    value = 1
    start_index = 0
    end_index = 1
    content = ""

    # Act
    dict_token = DictToken(value, start_index, end_index, content)

    # Assert
    assert dict_token._value == value
    assert dict_token._start_index == start_index
    assert dict_token._end_index == end_index
    assert dict_token._content == content


# Generated at 2022-06-22 06:33:17.483541
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # inner function in test function can not be tested unless exposed by owning function.
    # this test case is not necessary because method lookup_key is tested through method lookup
    pass


# Generated at 2022-06-22 06:33:26.325360
# Unit test for constructor of class ListToken
def test_ListToken():
    tokenList = ListToken(value = [], start_index = 0, end_index = 0, content = "")
    assert(isinstance(tokenList, ListToken))

# Assume the get_value function of class ListToken has been overridden properly
# because it is an abstract function, no test is needed

# Assume the get_child_token function of class ListToken has been overridden properly
# because it is an abstract function, no test is needed

# Assume the get_position function of class ListToken has been overridden properly
# because the original get_postion funciton has been tested, no test is needed

# Assume the _get_value function of class ListToken has been overridden properly
# because it is an abstract function, no test is needed
    

# Generated at 2022-06-22 06:33:29.601750
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    token = ScalarToken("value", 0, 0)
    assert token.__hash__() == hash("value")


# Generated at 2022-06-22 06:33:35.384439
# Unit test for constructor of class Token
def test_Token():
    my_var = Token(
    1,                                 # value
    2,                                 # start_index
    3,                                 # end_index
    "abcd")                            # content
    assert(my_var._value is 1)
    assert(my_var._start_index is 2)
    assert(my_var._end_index is 3)
    assert(my_var._content is "abcd")

# Generated at 2022-06-22 06:33:37.106031
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    token = _create_token()
    assert repr(token) == "Token(baz)"



# Generated at 2022-06-22 06:33:40.745349
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken('a', 0, 0)
    # check the value
    assert token.value == 'a'
    # check the start position
    assert token.start == Position(1, 1, 0)
    # check the end position
    assert token.end == Position(1, 1, 0)


# Generated at 2022-06-22 06:33:42.570004
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token(1,2,3,"")
    assert Token.lookup(token, []) == token



# Generated at 2022-06-22 06:33:47.674201
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """
    token1 = Token(value="", start_index=0, end_index=0, content="")
    token2 = Token(value="", start_index=0, end_index=0, content="")
    assert token1 == token2
    """
    pass



# Generated at 2022-06-22 06:33:56.360274
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(15, 0, 1, "15")
    assert token.string == "15"
    assert token.value == 15
    assert str(token.start) == "(1, 1)"
    assert str(token.end) == "(1, 2)"
    assert str(token) == "ScalarToken('15')"
    assert token == ScalarToken(15, 0, 1, "15")
    assert token != ScalarToken(16, 0, 1, "16")
    assert hash(token) == hash(15)
    assert token.lookup([]) == token


# Generated at 2022-06-22 06:34:12.756813
# Unit test for method lookup of class Token
def test_Token_lookup():
    class FakeToken(Token):
        def __init__(self, value: str, start_index: int, end_index: int, content: str = ""):
            super().__init__(value, start_index, end_index, content)
            if value == "dict1":
                self._value = {"key1": FakeToken("value1", 1,1, "")}
                self._child_keys = {"key1": "key1"}
                self._child_tokens = {"key1": FakeToken("value1", 1,1, "")}
    
        def __get_child_token(self, key: typing.Any) -> Token:
            return self._child_tokens[key]


# Generated at 2022-06-22 06:34:17.937986
# Unit test for method lookup of class Token
def test_Token_lookup():
    """Add at least one test for every method."""
    token = Token(["a", "b"], 0, 1, "ab")
    assert token.lookup([0]).string == "a"
    assert token.lookup([1]).string == "b"
    assert token.lookup([2]).string == ""
    assert token.lookup([0, 0]).string == ""
    assert token.lookup([0, 1]).string == ""


# Generated at 2022-06-22 06:34:25.743474
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert repr(ScalarToken(1, 0, 0)) == 'ScalarToken(1)'
    assert repr(ScalarToken(1.1, 0, 0)) == 'ScalarToken(1.1)'
    assert repr(ScalarToken('1', 0, 0)) == 'ScalarToken(\'1\')'
    assert repr(ScalarToken(True, 0, 0)) == 'ScalarToken(True)'
    assert repr(ScalarToken(False, 0, 0)) == 'ScalarToken(False)'
    assert repr(ScalarToken(None, 0, 0)) == 'ScalarToken(None)'

# Generated at 2022-06-22 06:34:30.641120
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    value = {
        'a': [1, 2, 3],
        'b': 'xyz'
    }
    content = json.dumps(value)
    token = DictToken(value, 0, len(content) - 1, content)

    assert repr(token) == f"DictToken({token.string!r})"


# Generated at 2022-06-22 06:34:36.139173
# Unit test for method lookup of class Token
def test_Token_lookup():
    token = Token(value = 1, start_index = 2, end_index = 4, content = '12345')
    assert token.start == Position(1, 2 , 1)
    assert token.end == Position(1, 3, 3)
    assert token.lookup([]) == token
    assert token.lookup([0]) == token


# Generated at 2022-06-22 06:34:47.242371
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.parser import _DictToken
    from typesystem.parser import _ScalarToken
    content = "{'a': 2}"
    child_keys = {"a": _ScalarToken("a", 3, 3, content)}
    child_tokens = {"a": _ScalarToken(2, 7, 7, content)}
    d = _DictToken({}, 0, 0, content)
    d.__dict__.update({"_child_keys": child_keys, "_child_tokens": child_tokens})
    dicttoken = DictToken({}, 0, 0, content)
    assert d._get_value() == dicttoken._get_value()
    assert d._get_child_token("a") == dicttoken._get_child_token("a")
    assert d._get_key_token

# Generated at 2022-06-22 06:34:48.596505
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    repr(Token(None, 0, 0, ""))


# Generated at 2022-06-22 06:34:57.956321
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(1, 1, 2, 'abc') == Token(1, 1, 2, 'xyz')
    assert not (Token(1, 1, 2, 'abc') == Token(2, 1, 2, 'abc'))
    assert not (Token(1, 1, 2, 'abc') == Token(1, 2, 2, 'abc'))
    assert not (Token(1, 1, 2, 'abc') == Token(1, 1, 3, 'abc'))
    assert not (Token(1, 1, 2, 'abc') == Token(1, 1, 2, 'xyz'))
    assert not (Token(1, 1, 2, 'abc') == int(1))


# Generated at 2022-06-22 06:35:05.079574
# Unit test for constructor of class ListToken
def test_ListToken():
    value = [1, 2, 3]
    start_index = 0
    end_index = 2
    content = 'abc'
    list_token = ListToken(value, start_index, end_index, content)
    assert list_token._value == value
    assert list_token._start_index == start_index
    assert list_token._end_index == end_index
    assert list_token._content == content


# Generated at 2022-06-22 06:35:08.090716
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    assert repr(Token(value="VALUE", start_index=0, end_index=1, content="CONTENT")) == "Token('VA')"



# Generated at 2022-06-22 06:35:55.635843
# Unit test for constructor of class ListToken
def test_ListToken():
    tokens = [
        ScalarToken('value1', 0, 4, "value1"),
        ScalarToken('value2', 5, 9, "value1"),
        ScalarToken('value3', 10, 14, "value1"),
    ]
    list_token = ListToken(tokens, 0, 14, "value1")
    assert list_token._get_value() == ['value1', 'value2', 'value3']


# Generated at 2022-06-22 06:35:58.919603
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    t = ScalarToken(1, 0, 0)
    assert repr(t) == "ScalarToken('1')"


# Generated at 2022-06-22 06:36:03.073206
# Unit test for constructor of class Token
def test_Token():
    t = Token("foo", 1, 3)
    assert t.string == "foo"
    assert t.value is None
    assert t.start == Position(1, 1, 1)
    assert t.end == Position(1, 3, 3)


# Generated at 2022-06-22 06:36:14.678213
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    a = 5
    b = {"a": [6, 7]}
    c = [b, [8, 9]]
    tokenc = ListToken(c, 0, 0)
    tokenb = DictToken(b, 0, 0)
    tokena = ScalarToken(a, 0, 0)
    assert tokena._value == 5
    assert tokenb._value == {"a": [6, 7]}
    assert tokenc._value == [b, [8, 9]]
    keya = tokenb._get_key_token(a)
    print(keya)
    assert tokenc.lookup_key([0, a])._value == keya
    assert tokenc.lookup_key([0])._value == tokenb

# Generated at 2022-06-22 06:36:18.186606
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    test = ScalarToken(key, start_index, end_index, content)
    expected = hash(value)
    assert test.__hash__() == expected

# Generated at 2022-06-22 06:36:19.845832
# Unit test for constructor of class Token
def test_Token():
    newToken = Token("", 1, 1)
    assert newToken
    assert newToken.value

# Generated at 2022-06-22 06:36:26.717378
# Unit test for constructor of class ListToken
def test_ListToken():
    a = ListToken([(4,'d')],4,8)
    assert(a._get_value() == [(4,'d')])
    assert(a._get_child_token(0) == (4, 'd'))
    assert(len(a) == 2)
    b = ListToken((4,'d'),4,8)
    assert(b._get_value() == [(4,'d')])
    assert(b._get_child_token(0) == (4, 'd'))

# Generated at 2022-06-22 06:36:29.626226
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    value = "test"
    start_index = 1,
    end_index = 2
    content = "Test"
    assert ScalarToken(value, start_index, end_index, content)


# Generated at 2022-06-22 06:36:36.133710
# Unit test for constructor of class Token
def test_Token():
    t1 = Token(5, 0, 2, "This is a string")
    t2 = Token(5, 0, 2, "This is a string")
    t3 = Token(5, 0, 2, "This is a string")
    assert t1 == t2
    assert hash(t1) == hash(t2)
    assert t1 != t3

test_Token()


# Generated at 2022-06-22 06:36:41.961158
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token0 = Token('value_0', 0, 9)
    token1 = Token('value_1', 0, 9)
    token2 = Token('value_0', 1, 10)
    token3 = Token('value_0', 0, 10)
    assert token0 == token0
    assert not (token0 == token1)
    assert not (token0 == token2)
    assert not (token0 == token3)

# Generated at 2022-06-22 06:37:02.520835
# Unit test for method lookup of class Token
def test_Token_lookup():
    dct = {'a': 2 }
    expected = '{'
    actual = Token(dct, 0, 0, '{\'a\': 2 }').lookup([0,0])
    assert actual.string == expected, actual.string


# Generated at 2022-06-22 06:37:06.086098
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(5,1,1)
    assert(token._start_index == 1)
    assert(token._end_index == 1)
    assert(token._value == 5)


# Generated at 2022-06-22 06:37:11.794544
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    dict_token = DictToken(
        {
            ScalarToken(1, 0, 0): ScalarToken(2, 1, 1),
            ScalarToken(3, 2, 2): ScalarToken(4, 3, 3),
        },
        0,
        0,
        "123",
    )
    
    assert dict_token.lookup_key([0]) == ScalarToken(1, 0, 0)
    assert dict_token.lookup_key([1]) == ScalarToken(3, 2, 2)

# Generated at 2022-06-22 06:37:22.723279
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    from typesystem.base import ANY_Type, IntegerType
    from typesystem.base.tokenizer import tokenize

    assert tokenize(ANY_Type().schema) == [ANY_Type().schema]

    schema = {
        "type": "array",
        "items": {"type": "number"},
        "maxItems": 3
    }
    tokens = list(tokenize(schema))
    assert tokens == [schema, typing.List[float], 3]
    assert tokens[0].lookup_key([]).string == '{"type": "array", "items": {"type": "number"}, "maxItems": 3}'


# Generated at 2022-06-22 06:37:28.669610
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
  some_text = " this is a test "
  token = ListToken([ScalarToken(1, 5, 6, some_text ),
                     ScalarToken(2, 5, 6, some_text )],
                     start_index=5, end_index=5, content=some_text)
  key_token = token.lookup_key([1])
  assert key_token._value == 2

test_Token_lookup_key()

# Generated at 2022-06-22 06:37:38.858935
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    '''
    Test for method lookup_key
    '''
    pass

# Generated at 2022-06-22 06:37:42.682999
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    """Unit test for method __hash__ of class ScalarToken."""
    obj = ScalarToken('a', 10, 20)
    res = obj.__hash__()
    assert res == 372748302


# Generated at 2022-06-22 06:37:47.080176
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    token = ScalarToken(123, 0, 2, "abc")
    assert token.start == Position(1, 1, 0)
    assert token.end == Position(1, 4, 3)
    assert token.string == "abc"
    assert token.value == 123


# Generated at 2022-06-22 06:37:52.439903
# Unit test for method lookup of class Token
def test_Token_lookup():
    from typesystem.compiler.parser import Token

    token = Token(value = {'key':'value'}, start_index = 0, end_index = 5, content = 'value')

    assert token.lookup([0]).__repr__() == "Token(value)"
    assert token.lookup_key([0, 0]).__repr__() == "Token(key)"



# Generated at 2022-06-22 06:37:59.835277
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # Constructing a token
    token = Token([], 0, 0, "[]")
    token._get_value = lambda: [0, 0]

    # Simple cases
    assert token.lookup_key([0])._value == 0
    assert token.lookup_key([1])._value == 0

    # Case where index is out of range
    try:
        token.lookup_key([2])
        assert False
    except IndexError:
        pass

    # Case where index is not an int
    try:
        token.lookup_key(["a"])
        assert False
    except IndexError:
        pass


# Generated at 2022-06-22 06:38:42.031513
# Unit test for constructor of class Token
def test_Token():
    assert Token(
        value=None, start_index=0, end_index=0, content=""
    )._value == None
    assert Token(
        value=None, start_index=0, end_index=0, content=""
    )._start_index == 0
    assert Token(
        value=None, start_index=0, end_index=0, content=""
    )._end_index == 0
    assert Token(
        value=None, start_index=0, end_index=0, content=""
    )._content == ""
    assert Token(
        value=None, start_index=0, end_index=0, content=""
    ).string == ""


# Generated at 2022-06-22 06:38:47.883840
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.json_schema import JSONSchema
    from typesystem.jsonschema import parse_schema
    schema = JSONSchema(parse_schema({'my_key': {'type': 'string'}}))
    subject = DictToken({'my_key': ScalarToken('value', 0, 1)}, 0, 1, "tests")
    assert subject._get_value(0) == 'value'

# Generated at 2022-06-22 06:38:58.957216
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    # Test strings
    s = "Hello"
    assert s.__hash__() == ScalarToken(s, 0, 4).__hash__()

    # Test ints
    i = 42
    assert i.__hash__() == ScalarToken(i, 0, 2).__hash__()
    assert i.__hash__() == ScalarToken(i, 0, 2, "42").__hash__()

    # Test lists
    l = [1, 2, 3]
    assert l.__hash__() == ScalarToken(l, 0, 5).__hash__()
    assert l.__hash__() == ScalarToken(l, 0, 5, " [ 1 , 2 , 3 ] ").__hash__()

    # Test dicts
    d = {"a": 1, "b": 2, "c": 3}