

# Generated at 2022-06-26 10:52:25.196007
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    str_0 = dict_token_1.__eq__(dict_token_0)
    assert str_0 == True
    dict_token_2 = DictToken()
    assert dict_token_2 == dict_token_1


# Generated at 2022-06-26 10:52:27.134239
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:52:28.872075
# Unit test for constructor of class DictToken
def test_DictToken():
    try:
        test_case_0()
    except Exception:
        print('Failed test_case_0()')


# Generated at 2022-06-26 10:52:29.659234
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken()


# Generated at 2022-06-26 10:52:34.510559
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


if __name__ == "__main__":
    import sys
    import traceback


# Generated at 2022-06-26 10:52:40.511513
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken(None, 0, 0)
    dict_token_1 = DictToken(None, 0, 0)
    dict_token_2 = DictToken(None, 0, 0, None)
    dict_token_3 = DictToken(None, 0, 0, None)
    dict_token_4 = DictToken(None, 0, 0, None)



# Generated at 2022-06-26 10:52:53.499378
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_1 = DictToken(
        {}, 0, 1, content="{"
    )
    dict_token_2 = DictToken(
        {}, 1, 2, content="}"
    )
    dict_token_3 = DictToken(
        {}, 0, 2, content="{}"
    )

# Generated at 2022-06-26 10:52:54.402492
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:52:55.891881
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

# Generated at 2022-06-26 10:53:02.155971
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, (DictToken, Token))
    assert isinstance(dict_token_0, Token)
    assert dict_token_0 == dict_token_0
    assert dict_token_0 == dict_token_0
    assert not(dict_token_0 != dict_token_0)
    assert dict_token_0 == dict_token_0


# Generated at 2022-06-26 10:53:12.769022
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:53:13.808139
# Unit test for constructor of class DictToken
def test_DictToken():

    pass


# Generated at 2022-06-26 10:53:26.044539
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    dict_token_2 = DictToken()
    dict_token_3 = DictToken()
    dict_token_4 = DictToken()
    dict_token_5 = DictToken()
    dict_token_6 = DictToken()
    dict_token_7 = DictToken()
    dict_token_8 = DictToken()
    dict_token_9 = DictToken()
    dict_token_10 = DictToken()
    dict_token_11 = DictToken()
    dict_token_12 = DictToken()
    dict_token_13 = DictToken()
    dict_token_14 = DictToken()


# Generated at 2022-06-26 10:53:41.025760
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_0_copy = dict_token_0
    assert dict_token_0 == dict_token_0_copy

    dict_token_0_copy = dict_token_0
    assert dict_token_0 == dict_token_0_copy

    list_token_0 = ListToken()
    assert dict_token_0 != list_token_0

    scalar_token_0 = ScalarToken()
    assert dict_token_0 != scalar_token_0

    dict_token_0 = DictToken()
    dict_token_0_copy = dict_token_0
    assert dict_token_0 == dict_token_0_copy

    dict_token_0_copy = dict_token_0
    assert dict_token_0 == dict_token_0_

# Generated at 2022-06-26 10:53:44.737191
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    token_0 = ScalarToken(dict_token_0, 0, 0)
    token_1 = ScalarToken(dict_token_1, 0, 0)
    assert token_0 == token_1


# Generated at 2022-06-26 10:53:48.298255
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert dict_token_0.__eq__(dict_token_1) == True


# Generated at 2022-06-26 10:53:58.138200
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import Token
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from typesystem.base import TupleToken
    from typesystem.base import Position
    def test_case_0():
        dict_token_0 = DictToken()
    def test_case_1():
        dict_token_0 = DictToken()
        dict_token_1 = DictToken(0)
    def test_case_2():
        dict_token_0 = DictToken()
        dict_token_1 = DictToken(0)
        dict_token_2 = DictToken(0, 0)
    def test_case_3():
        dict_token_0 = DictToken()
        dict_token_1 = DictToken

# Generated at 2022-06-26 10:54:01.036313
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert dict_token_0 != dict_token_1



# Generated at 2022-06-26 10:54:02.023385
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()

# Generated at 2022-06-26 10:54:03.290373
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

# isinstance check for Token

# Generated at 2022-06-26 10:54:18.520937
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    assert dict_token_0 == dict_token_0
    scalar_token_0 = ScalarToken(dict_token_0, 0, 0)
    assert scalar_token_0 == scalar_token_0
    list_token_0 = ListToken((), 0, 0)
    assert list_token_0 == list_token_0


# Generated at 2022-06-26 10:54:21.879499
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_1 = DictToken()
    dict_token_2 = DictToken()
    assert dict_token_1 == dict_token_2


# Generated at 2022-06-26 10:54:25.947661
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    dict_token_2 = DictToken()

    assert dict_token_0 != dict_token_1
    assert dict_token_1 != dict_token_2


# Generated at 2022-06-26 10:54:29.984016
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert_equal(dict_token_0._get_value(),{})
    assert_equal(dict_token_0._child_keys,{})
    assert_equal(dict_token_0._child_tokens,{})


# Generated at 2022-06-26 10:54:33.814699
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_0._get_value()
    dict_token_0._end_index
    dict_token_0._get_child_token(0)
    dict_token_0._child_keys


# Generated at 2022-06-26 10:54:34.677797
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:36.913677
# Unit test for constructor of class DictToken
def test_DictToken():
    try:
        dict_token_0 = DictToken()
        assert False
    except NotImplementedError as e:
        assert str(e) == "_get_value()"


# Generated at 2022-06-26 10:54:37.802458
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    test_case_0()

# Generated at 2022-06-26 10:54:39.116088
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:41.917842
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert dict_token_0 == dict_token_1


# Generated at 2022-06-26 10:55:14.632735
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    assert True


# Generated at 2022-06-26 10:55:18.873740
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Token(<value>)
    dict_token_0 = DictToken(
        {},
        0,
        0
    )
    str_token_0 = ScalarToken(
        '',
        0,
        0,
        ''
    )


# Generated at 2022-06-26 10:55:23.835870
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken(((dict_token_0, dict_token_0), ScalarToken(1, 1, 1)), 1, 1)
    assert not (dict_token_0 == ScalarToken(1, 1, 1))


# Generated at 2022-06-26 10:55:31.484048
# Unit test for constructor of class DictToken
def test_DictToken():
    d_0 = DictToken()
    d_0._child_keys, d_0._child_tokens, d_0._content, d_0._end_index, d_0._start_index, d_0._value, d_0.end, d_0.lookup, d_0.lookup_key, d_0.start, d_0.string, d_0.value


# Generated at 2022-06-26 10:55:35.367375
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert dict_token_0.__eq__(dict_token_1) == True,  "Expeceted {} but found {}".format(True, dict_token_0.__eq__(dict_token_1))


# Generated at 2022-06-26 10:55:38.097325
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:55:39.782702
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:55:49.705883
# Unit test for constructor of class DictToken
def test_DictToken():

    dict_token_0 = DictToken(
        {}, 0, 0, """{"a": 1, "b": 2, "c": 3}"""
    )
    dict_token_0._get_value()

    dict_token_1 = DictToken(
        {}, 0, 0, """{"a": 1, "b": 2, "c": 3}"""
    )
    dict_token_1.lookup([0])
    dict_token_1.lookup([1])
    dict_token_1.lookup([2])

    dict_token_2 = DictToken(
        {}, 0, 0, """{"a": 1, "b": 2, "c": 3}"""
    )
    dict_token_2.lookup_key([0])

# Generated at 2022-06-26 10:55:51.745395
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()
    return

test_DictToken()

# Generated at 2022-06-26 10:55:56.854815
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert hasattr(dict_token_0, '_value') == False

# Tests for method DictToken._get_value()

# Generated at 2022-06-26 10:56:34.601714
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0._get_value()=={}

# Generated at 2022-06-26 10:56:36.112028
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:56:37.979045
# Unit test for constructor of class DictToken
def test_DictToken():
    token_0 = DictToken()
    # assert DictToken.__init__(token_0)



# Generated at 2022-06-26 10:56:42.628183
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken(value = None, start_index = None, end_index = None, content = None)
    assert dict_token is not None


# Generated at 2022-06-26 10:56:45.052298
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-26 10:56:45.950223
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:56:47.243721
# Unit test for constructor of class DictToken
def test_DictToken():
    assert True


# Generated at 2022-06-26 10:56:57.209073
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    dict_token_2 = DictToken()
    dict_token_3 = DictToken()
    dict_token_4 = DictToken()
    dict_token_5 = DictToken()
    dict_token_6 = DictToken()
    dict_token_7 = DictToken()
    dict_token_8 = DictToken()
    dict_token_9 = DictToken()
    dict_token_10 = DictToken()
    dict_token_11 = DictToken()
    dict_token_12 = DictToken()
    dict_token_13 = DictToken()
    dict_token_14 = DictToken()
    dict_token_15 = DictToken()

# Generated at 2022-06-26 10:57:01.107166
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:57:03.125230
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:57:38.987027
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:57:40.618253
# Unit test for constructor of class DictToken
def test_DictToken():
    assert isinstance(test_case_0(), DictToken)


# Generated at 2022-06-26 10:57:42.255108
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken(dict_token_0)

# Generated at 2022-06-26 10:57:43.540599
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

# Generated at 2022-06-26 10:57:52.984713
# Unit test for constructor of class DictToken
def test_DictToken():
    token_1 = ScalarToken(1, 0, 0)
    token_2 = ScalarToken(2, 0, 0)
    token_3 = ScalarToken(3, 0, 0)
    token_4 = ScalarToken(4, 0, 0)
    token_5 = ScalarToken(5, 0, 0)

    dict_token_0 = DictToken({}, 0, 0, "")

    dict_token_1 = DictToken({token_1: token_2, token_3: token_4}, 0, 0, "")
    assert dict_token_1._get_value() == {1: 2, 3: 4}

    dict_token_2 = DictToken({token_3: token_4}, 0, 0, "")

# Generated at 2022-06-26 10:58:02.440746
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_1 = DictToken()
    dict_token_2 = DictToken(value="hello", start_index=0, end_index=1)
    dict_token_3 = DictToken(value=12.34, start_index=1, end_index=2)
    dict_token_4 = DictToken(value=[1,2,3], start_index=2, end_index=3)
    dict_token_5 = DictToken(value={1:"hi", 2:"hello"}, start_index=3, end_index=4)
    dict_token_6 = DictToken(value=(1,"hello"), start_index=4, end_index=5)

# Generated at 2022-06-26 10:58:03.290908
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken()


# Generated at 2022-06-26 10:58:05.787041
# Unit test for constructor of class DictToken
def test_DictToken():
    try:
        test_case_0()
    except Exception as e:
        print(e)



# Generated at 2022-06-26 10:58:14.786215
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    dict_token_2 = DictToken()
    dict_token_3 = DictToken()
    dict_token_4 = DictToken()
    dict_token_5 = DictToken()
    dict_token_6 = DictToken()
    dict_token_7 = DictToken()
    dict_token_8 = DictToken()
    dict_token_9 = DictToken()
    dict_token_10 = DictToken()
    dict_token_11 = DictToken()
    dict_token_12 = DictToken()
    dict_token_13 = DictToken()
    dict_token_14 = DictToken()
    dict_token_15 = DictToken()

# Generated at 2022-06-26 10:58:15.944758
# Unit test for constructor of class DictToken
def test_DictToken():
    assert repr(DictToken()) == 'DictToken()'



# Generated at 2022-06-26 10:59:27.127834
# Unit test for constructor of class DictToken
def test_DictToken():
    assert True


# Generated at 2022-06-26 10:59:28.272463
# Unit test for constructor of class DictToken
def test_DictToken():
    assert(isinstance(test_case_0(), DictToken))


# Generated at 2022-06-26 10:59:29.534719
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:59:30.777359
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:59:32.689658
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

# Generated at 2022-06-26 10:59:34.700823
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0._get_value() == {}


# Generated at 2022-06-26 10:59:35.867104
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken({})


# Generated at 2022-06-26 10:59:37.403810
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:59:39.841745
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:59:40.776788
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    print(dict_token_0)
    print("--------------------")


# Generated at 2022-06-26 11:02:06.072318
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:02:07.253872
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:02:11.022663
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_0_value = dict_token_0._get_value()
    # print(dict_token_0_value)
    assert dict_token_0_value == {}


# Generated at 2022-06-26 11:02:22.564586
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_3 = DictToken(
        {},
        0,
        1,
        "{}",
    )
    dict_token_4 = DictToken(
        {
            ScalarToken(
                "a",
                1,
                2,
                "{}",
            ): ScalarToken(
                1,
                4,
                5,
                "{}",
            ),
            ScalarToken(
                2,
                7,
                8,
                "{}",
            ): ScalarToken(
                "b",
                10,
                11,
                "{}",
            ),
        },
        0,
        12,
        "{'a': 1, 2: 'b'}",
    )