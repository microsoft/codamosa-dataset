

# Generated at 2022-06-26 10:52:28.265632
# Unit test for constructor of class DictToken
def test_DictToken():
    bytes_0 = b',K\x17n\x9d\x88\xb6\x88S\x9e\x81\xb5\x92'
    int_0 = -1517
    dict_token_0 = DictToken(int_0, int_0)


# Generated at 2022-06-26 10:52:33.362525
# Unit test for constructor of class DictToken
def test_DictToken():
    bytes_0 = b'W\xe0\xbc\x7f\x82\x13'
    int_0 = -1372868236
    bytes_1 = b'\x07\xf7\xc3\x8d\xbf\x9b\x82\t'
    int_1 = 562652545
    dict_token_0 = DictToken(bytes_0, int_0, bytes_1, int_1)
    assert isinstance(dict_token_0, DictToken)
    if __name__ == '__main__':
        test_case_0()
        test_DictToken()
    print('Test was successful')

# Generated at 2022-06-26 10:52:39.518292
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    bytes_0 = b'\x95\xf6\x15\xf5\x08\xe6'
    int_0 = -208
    list_token_0 = ListToken(bytes_0, int_0, int_0)
    list_token_1 = ListToken(bytes_0, int_0, int_0)
    list_token_0 == list_token_1


# Generated at 2022-06-26 10:52:43.064274
# Unit test for constructor of class DictToken
def test_DictToken():
    received_str_0 = 'foo'
    received_str_1 = 'boo'
    received_str_2 = 'far'
    received_str_3 = 'bar'
    received_str_4 = 'foo'
    received_str_5 = 'boo'
    received_str_6 = 'far'
    received_str_7 = 'bar'
    received_scalar_token_0 = ScalarToken(received_str_0, 0, 0)
    received_scalar_token_1 = ScalarToken(received_str_1, 0, 0)
    received_scalar_token_2 = ScalarToken(received_str_2, 0, 0)
    received_scalar_token_3 = ScalarToken(received_str_3, 0, 0)
    received_scal

# Generated at 2022-06-26 10:52:54.052909
# Unit test for constructor of class DictToken
def test_DictToken():
    bytes_0 = b'\x9c\x03_\xab\x8f\xec\x1a\xa0\x1d]9G\\'
    bytes_1 = b',\xb4\xb4\xed\xe7\x1a\xca\x8d\xc3\x03Z\x19'
    bytes_2 = b'\xa4\x1bG\x93\x06\xa3\x03\xe3\xcf\x18I\xe2\xd2'
    dict_token_0 = DictToken(bytes_0, bytes_1, bytes_2)
    int_0 = 149

# Generated at 2022-06-26 10:53:04.675929
# Unit test for constructor of class DictToken
def test_DictToken():
    bytes_0 = b'\x01\x06\xfa'
    int_0 = -11843
    dict_token_0 = DictToken(bytes_0, int_0, int_0)
    str_0 = 'a'
    bytes_1 = b'\x06\xfa'
    int_1 = -5618
    dict_token_1 = DictToken({str_0: bytes_1}, int_1, int_1)
    bytes_2 = b'\x01\x06\xfa'
    int_2 = -11843
    dict_token_2 = DictToken(bytes_2, int_2, int_2)
    str_1 = 'a'
    bytes_3 = b'\x06\xfa'
    int_3 = -5618
    dict_

# Generated at 2022-06-26 10:53:09.050064
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken(a= "a", b= "b")
    assert dict_token.lookup([0]).string == "a"
    assert dict_token.lookup([1]).string == "b"
    assert dict_token.lookup_key([0]).string == "a"
    assert dict_token.lookup_key([1]).string == "b"


# Generated at 2022-06-26 10:53:15.965756
# Unit test for constructor of class DictToken
def test_DictToken():
    bytes_0 = b',K\x17n\x9d\x88\xb6\x88S\x9e\x81\xb5\x92'
    int_0 = -1517
    int_1 = -1517
    dict_token_0 = DictToken(bytes_0, int_0, int_1)


# Generated at 2022-06-26 10:53:27.524012
# Unit test for constructor of class DictToken
def test_DictToken():
    bytes_0 = b'\x86\x9d9\x8e\xc9\xd6\xaf\xca\x8b\x1c\x11\xa9\xe7\x1b'
    int_0 = -17668
    list_token_0 = DictToken(bytes_0, int_0, int_0)
    bool_0 = list_token_0.start.column_no
    str_0 = list_token_0.start.index
    bool_1 = list_token_0.end.line_no
    list_token_0.end.index
    bool_2 = list_token_0.end.column_no
    str_1 = list_token_0.start.line_no
    str_2 = list_token_0.string

# Generated at 2022-06-26 10:53:34.576518
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    bytes_0 = b'\xdb\x18[\x83M\n\xf8%\x1co\x90\x9e'
    int_0 = 1755
    int_1 = 80
    list_token_0 = ListToken(bytes_0, int_0, int_1)
    int_2 = -1222
    int_3 = -1517
    list_token_1 = ListToken(bytes_0, int_2, int_3)
    int_4 = 1293
    int_5 = 1755
    list_token_2 = ListToken(bytes_0, int_4, int_5)
    token_0 = list_token_2
    list_token_0.__eq__(token_0)

# Generated at 2022-06-26 10:53:40.982346
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    bytes_0 = b'\x86\x9d9\x8e\xc9\xd6\xaf\xca\x8b\x1c\x11\xa9\xe7\x1b'
    int_0 = 149



# Generated at 2022-06-26 10:53:48.398933
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    bytes_0 = b'\x86\x9d9\x8e\xc9\xd6\xaf\xca\x8b\x1c\x11\xa9\xe7\x1b'
    int_0 = 149
    int_1 = 791
    # given start_index = 0 and end_index = 7
    # given start_index = 0 and end_index = 9
    pass


# Generated at 2022-06-26 10:53:58.175393
# Unit test for constructor of class DictToken
def test_DictToken():
    bytes_0 = b'\x80\x7f\xde=\x8f\xaa\x1d\x1a\xe3\xdb\xc2\x06\xd2\x8b\xd8\xea\xeb\x9b\xe1\x8b'
    int_0 = 13

# Generated at 2022-06-26 10:54:07.779725
# Unit test for constructor of class DictToken
def test_DictToken():
    assert Token(typing.Any, 0, 0).string == ""
    assert Token(typing.Any, 0, 0, "").string == ""
    assert Token(typing.Any, 0, 0, "").string == Token(typing.Any, 0, 0, "").string
    assert Token(typing.Any, 0, 0, "").string != Token(typing.Any, 0, 0).string
    assert Token(typing.Dict[str, typing.Any], 0, 0).lookup([0]) == None
    assert Token(typing.Dict[str, typing.Any], 0, 0, "").lookup([0]) == None

# Generated at 2022-06-26 10:54:12.265412
# Unit test for constructor of class DictToken
def test_DictToken():
    bytes_0 = b'\x86\x9d9\x8e\xc9\xd6\xaf\xca\x8b\x1c\x11\xa9\xe7\x1b'
    int_0 = 149



# Generated at 2022-06-26 10:54:21.391577
# Unit test for constructor of class DictToken
def test_DictToken():
    bytes_0 = b'\x86\x9d9\x8e\xc9\xd6\xaf\xca\x8b\x1c\x11\xa9\xe7\x1b'
    int_0 = 149
    double_0 = 149.01
    string_0 = '149'
    instance_0 = DictToken(value=None, start_index=1, end_index=149)
    instance_0._value = {string_0: instance_0._value, bytes_0: string_0}
    dict_0 = instance_0._get_value()


# Generated at 2022-06-26 10:54:25.488373
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    bytes_0 = b'\x86\x9d9\x8e\xc9\xd6\xaf\xca\x8b\x1c\x11\xa9\xe7\x1b'
    int_0 = 149


# Generated at 2022-06-26 10:54:35.086050
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    bytes_0 = b'\xb4\xae~\x89\xed\x87\x12\xa5\xf4\xc5\xae\xe5\x17\x14m'
    value_0 = bytes_0.decode("utf-8")
    value_1 = bytes_0.decode("utf-8")
    int_0 = 172
    int_1 = 21
    dict_0 = {
        "dict_key_0": value_1,
        "dict_key_1": value_0,
    }

    bytes_1 = b'\x17\x8f\x1a{\xb0\x1c\x14\x8d\xba\x9a\xcd\xc8\x1a"\xf3'

# Generated at 2022-06-26 10:54:45.269119
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    bytes_0 = b'\x86\x9d9\x8e\xc9\xd6\xaf\xca\x8b\x1c\x11\xa9\xe7\x1b'
    int_0 = 149
    bytes_1 = b'\x86\x9d9\x8e\xc9\xd6\xaf\xca\x8b\x1c\x11\xa9\xe7\x1b'
    int_1 = 1491
    bytes_2 = b'\x86\x9d9\x8e\xc9\xd6\xaf\xca\x8b\x1c\x11\xa9\xe7\x1b'
    int_2 = 302

# Generated at 2022-06-26 10:54:46.441196
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()

# Generated at 2022-06-26 10:54:57.598066
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert( hasattr(dict_token_0, '_get_value') )
    assert( hasattr(dict_token_0, '_get_child_token') )
    assert( hasattr(dict_token_0, '_get_key_token') )
    assert( hasattr(dict_token_0, 'string') )
    assert( hasattr(dict_token_0, 'value') )
    assert( hasattr(dict_token_0, 'start') )
    assert( hasattr(dict_token_0, 'end') )
    assert( hasattr(dict_token_0, 'lookup') )
    assert( hasattr(dict_token_0, 'lookup_key') )
    # TODO: _get_position()

# Generated at 2022-06-26 10:54:59.228653
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 10:55:09.319110
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test with arg value
    arg_value = {}
    arg_value['key_0'] = 'value_0'
    arg_value['key_1'] = 'value_1'
    arg_value['key_2'] = 'value_2'

    # Test with arg start_index
    arg_start_index = 0

    # Test with arg end_index
    arg_end_index = 0

    # Test with arg content
    arg_content = ''

    obj = DictToken(
        arg_value,
        arg_start_index,
        arg_end_index,
        arg_content,
    )

    assert obj._value == arg_value

    assert obj._start_index == arg_start_index

    assert obj._end_index == arg_end_index

    assert obj._content == arg_content


# Generated at 2022-06-26 10:55:10.491004
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:55:12.534069
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert type(dict_token_0) == DictToken, "Couldn't create an object of type DictToken"


# Generated at 2022-06-26 10:55:13.595696
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:55:14.989984
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken(dict(), 0, 2)



# Generated at 2022-06-26 10:55:22.709431
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken( None, None, None)
    dict_token_1 = DictToken( None, None, None, None)
    dict_token_2 = DictToken( None, None, None, None, None)
    # those 2 assertions should give pass
    assert dict_token_0 is not dict_token_1
    assert dict_token_1 is not dict_token_2


# Generated at 2022-06-26 10:55:24.044508
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_1 = DictToken()


# Generated at 2022-06-26 10:55:29.902673
# Unit test for constructor of class DictToken
def test_DictToken():
    print("Testing constructor of class DictToken")
    try:
        test_case_0()
    except Exception as e:
        print("Failed:", e)
    else:
        print("Passed!")

test_DictToken()

# Generated at 2022-06-26 10:55:48.189039
# Unit test for constructor of class DictToken
def test_DictToken():
    # Create a DictToken object.
    dict_token_0 = DictToken()
    # Get the value property of dict_token_0
    result = dict_token_0._get_value()
    # Assert that result equals {}
    assert result == {}
    # Create a DictToken object.
    dict_token_1 = DictToken()
    # Get the string property of dict_token_1
    result = dict_token_1.string
    # Assert that result equals ''
    assert result == ''
    # Create a DictToken object.
    dict_token_0 = DictToken()
    # Get the end property of dict_token_0
    result = dict_token_0.end
    # Get the line_no property of result
    result = result.line_no
    # Assert that result equals 1

# Generated at 2022-06-26 10:55:50.227090
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, DictToken)
    assert isinstance(dict_token_0, Token)


# Generated at 2022-06-26 10:55:52.203631
# Unit test for constructor of class DictToken
def test_DictToken():
    # test_case_0
    assert test_case_0()


# Generated at 2022-06-26 10:55:54.878790
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:55:56.986434
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:56:01.410932
# Unit test for constructor of class DictToken
def test_DictToken():
    try:
        dict_token_0 = DictToken()
        assert False
    except NotImplementedError:
        assert True
    try:
        dict_token_0 = DictToken()
        assert False
    except NotImplementedError:
        assert True

# Generated at 2022-06-26 10:56:08.710242
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken()


# Generated at 2022-06-26 10:56:10.145209
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:56:12.256032
# Unit test for constructor of class DictToken
def test_DictToken():
    print("== test_DictToken ==")
    test_case_0()
    print("===== End of testing =====")


# Generated at 2022-06-26 10:56:17.355085
# Unit test for constructor of class DictToken
def test_DictToken():
    dict1 = {'key1': "value1"}
    dict_token1 = DictToken(dict1)
    assert dict_token1.lookup([]) == dict_token1
    assert dict_token1.lookup_key([]) == dict_token1._child_keys['key1']
    assert dict_token1.lookup([0]) == dict_token1._child_tokens['key1']


# Generated at 2022-06-26 10:56:31.299758
# Unit test for constructor of class DictToken
def test_DictToken():
    # Intialize token
    dict_token = DictToken()




# Generated at 2022-06-26 10:56:32.850216
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

# Generated at 2022-06-26 10:56:33.809706
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()

# Generated at 2022-06-26 10:56:38.544482
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken([1, 2, 3])
    assert isinstance(dict_token_0, DictToken)
    assert str(dict_token_0) == "DictToken([1, 2, 3])"
    assert repr(dict_token_0) == "DictToken([1, 2, 3])"


# Generated at 2022-06-26 10:56:40.455373
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken(None, 0, 0)


# Generated at 2022-06-26 10:56:43.093135
# Unit test for constructor of class DictToken
def test_DictToken():
    """
    Test constructor of class DictToken
    """
    # Check if DictToken can be created
    test_case_0()

# Generated at 2022-06-26 10:56:45.486666
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_1 = DictToken({}, 0, 0, '')
#


# Generated at 2022-06-26 10:56:47.243392
# Unit test for constructor of class DictToken
def test_DictToken():
    # This assertion is a really simple test for DictToken
    assert True


# Generated at 2022-06-26 10:56:49.678999
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:56:58.164510
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    dict_token_2 = DictToken()
    dict_token_3 = DictToken()
    assert repr(dict_token_0) == 'DictToken()'
    assert repr(dict_token_1) == 'DictToken()'
    assert dict_token_0 == dict_token_1
    assert dict_token_1 != dict_token_2
    assert hash(dict_token_0) == hash(dict_token_1)
    assert hash(dict_token_2) != hash(dict_token_1)
    assert dict_token_0._get_value() == dict_token_3._get_value()
    # Test with other types of values

# Generated at 2022-06-26 10:57:17.500297
# Unit test for constructor of class DictToken
def test_DictToken():
    try:
        dict_token_0 = DictToken()
    except Exception as e:
        print(e.__class__.__name__, ":", e)
    else:
        print("Test Passed")


# Generated at 2022-06-26 10:57:21.096315
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert dict_token_0 == dict_token_1


# Generated at 2022-06-26 10:57:22.315727
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:57:23.606526
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:57:25.108132
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:57:29.216709
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert str(dict_token_0.__repr__()) == "DictToken()"
    assert str(dict_token_0.__str__()) == "DictToken()"
    assert bool(dict_token_0)
    assert bool(dict_token_0.__repr__())
    assert bool(dict_token_0.__str__())


# Generated at 2022-06-26 10:57:42.460550
# Unit test for constructor of class DictToken
def test_DictToken():
    assert repr(DictToken({}, 0, 0, content='')) == "DictToken({})"
    assert repr(DictToken({}, 0, 0, content='')) == "DictToken({})"
    assert repr(DictToken({}, 0, 0, content='')) == "DictToken({})"
    assert repr(DictToken({}, 0, 0, content='')) == "DictToken({})"
    assert repr(DictToken({}, 0, 0, content='')) == "DictToken({})"
    assert repr(DictToken({}, 0, 0, content='')) == "DictToken({})"
    assert repr(DictToken({}, 0, 0, content='')) == "DictToken({})"
    assert repr(DictToken({}, 0, 0, content=''))

# Generated at 2022-06-26 10:57:52.175240
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    dict_token_2 = DictToken()
    dict_token_3 = DictToken()
    dict_token_4 = DictToken()
    dict_token_5 = DictToken()
    dict_token_6 = DictToken()
    dict_token_7 = DictToken()
    dict_token_8 = DictToken()
    dict_token_9 = DictToken()
    dict_token_10 = DictToken()
    dict_token_11 = DictToken()
    dict_token_12 = DictToken()
    dict_token_13 = DictToken()
    dict_token_14 = DictToken()
    dict_token_15 = DictToken()


# Generated at 2022-06-26 10:58:02.636893
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert repr(dict_token_0) == 'DictToken({})'
    assert dict_token_0._value == {}
    assert dict_token_0._start_index == 0
    assert dict_token_0._end_index == 0
    assert dict_token_0._content == ''
    assert dict_token_0._child_tokens == {}
    assert dict_token_0._child_keys == {}
    assert dict_token_0.string == '{}'
    assert dict_token_0.value == {}
    assert dict_token_0.start == Position(1, 1, 0)
    assert dict_token_0.end == Position(1, 2, 1)
    assert dict_token_0.lookup([]) == dict_token_0

# Generated at 2022-06-26 10:58:05.786583
# Unit test for constructor of class DictToken
def test_DictToken():

    obj = DictToken()
    # assert obj.get_value() == {}
    obj = DictToken()
    # assert obj.get_value() == {}



# Generated at 2022-06-26 10:58:25.020121
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()

# Generated at 2022-06-26 10:58:26.537203
# Unit test for constructor of class DictToken
def test_DictToken():
    print('In method test_DictToken')
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:58:27.856133
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 10:58:32.625898
# Unit test for constructor of class DictToken
def test_DictToken():

    # create object of DictToken using DictToken()
    dict_token_0 = DictToken()

    # run parameterized test case
    test_case_0()

    # run parameterized test case
    test_case_1()

    # run parameterized test case
    test_case_2()



# Generated at 2022-06-26 10:58:34.132947
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:58:35.542334
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:58:46.265621
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken()
    assert isinstance(dict_token, Token)
    assert dict_token._get_value() == dict_token._value == dict()
    dict_token_0 = DictToken({})
    assert isinstance(dict_token_0, Token)
    assert dict_token_0._get_value() == dict_token_0._value == dict()

# Generated at 2022-06-26 10:58:50.990318
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken().__class__.__name__ == 'DictToken'


# Generated at 2022-06-26 10:58:52.971090
# Unit test for constructor of class DictToken
def test_DictToken():
    def test_case_0():
        dict_token_0 = DictToken()


# Generated at 2022-06-26 10:58:54.545990
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()

# Generated at 2022-06-26 10:59:40.164814
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:59:41.962247
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert repr(dict_token_0) == "DictToken({})"



# Generated at 2022-06-26 10:59:43.058863
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:59:43.645408
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test Case 0
    test_case_0()

# Generated at 2022-06-26 10:59:44.435271
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:59:46.067903
# Unit test for constructor of class DictToken
def test_DictToken():
    assert(DictToken()._get_value() == {})

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 10:59:47.978077
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:59:49.473695
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:59:51.683228
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, DictToken)


# Generated at 2022-06-26 10:59:52.777709
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:01:02.336953
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:01:13.658157
# Unit test for constructor of class DictToken
def test_DictToken():
    assert not hasattr(DictToken, "_init"), "Do not override __init__. Use helper __new__ instead."
    assert not hasattr(DictToken, "_new"), "Do not override __new__ directly. Use helper _create instead."
    assert not hasattr(DictToken, "_create"), "You may override the _create method."
    assert hasattr(DictToken, "_get_value"), "You may override the _get_value method."
    assert hasattr(DictToken, "_get_child_token"), "You may override the _get_child_token method."
    assert hasattr(DictToken, "_get_key_token"), "You may override the _get_key_token method."
    assert not hasattr(DictToken, "_init"), "Do not override __init__. Use helper __new__ instead."

# Generated at 2022-06-26 11:01:14.797869
# Unit test for constructor of class DictToken
def test_DictToken():
    assert isinstance(dict_token_0, DictToken)



# Generated at 2022-06-26 11:01:20.432510
# Unit test for constructor of class DictToken
def test_DictToken():
    assert hasattr(DictToken, '__init__')
    assert callable(getattr(DictToken, '__init__'))
    test_case_0()


# Generated at 2022-06-26 11:01:22.158452
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0 is not None


# Generated at 2022-06-26 11:01:24.948127
# Unit test for constructor of class DictToken
def test_DictToken():
    # Create instance of class 'DictToken' (line 108)
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:01:28.003704
# Unit test for constructor of class DictToken
def test_DictToken():
    try:
        assert True # TODO: implement your test here
    except BaseException as e:
        raise(e)


# Generated at 2022-06-26 11:01:29.826696
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:01:30.736328
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 11:01:33.492505
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, DictToken)