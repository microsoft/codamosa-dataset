

# Generated at 2022-06-26 10:52:31.706620
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    scalar_token_0 = None
    int_0 = -876
    list_token_0 = ListToken(scalar_token_0, int_0, int_0)
    dict_token_0 = DictToken(list_token_0, int_0, int_0)
    scalar_token_1 = None
    int_1 = -876
    list_token_1 = ListToken(scalar_token_1, int_1, int_1)
    dict_token_1 = DictToken(list_token_1, int_1, int_1)
    assert dict_token_0 == dict_token_1

# Generated at 2022-06-26 10:52:33.747731
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    test_case_0()


# Generated at 2022-06-26 10:52:36.326423
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # TODO: Write unit test for method __eq__ of class Token
    assert True # TODO: replace this line with correct code


# Generated at 2022-06-26 10:52:42.065146
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    scalar_token_0 = None
    int_0 = -876
    list_token_0 = ListToken(scalar_token_0, int_0, int_0)
    scalar_token_1 = None
    int_1 = -876
    list_token_1 = ListToken(scalar_token_1, int_1, int_1)
    assert list_token_0 == list_token_1


# Generated at 2022-06-26 10:52:46.036713
# Unit test for constructor of class DictToken
def test_DictToken():
    scalar_token_0 = None
    dict_token_0 = DictToken(scalar_token_0, scalar_token_0, scalar_token_0)


# Generated at 2022-06-26 10:52:50.989967
# Unit test for constructor of class DictToken
def test_DictToken():
    arg0 = 'test'
    arg1 = 10
    arg2 = 10

    test = DictToken(arg0, arg1, arg2)

    assert test._value == arg0
    assert test._start_index == arg1
    assert test._end_index == arg2


# Generated at 2022-06-26 10:52:54.485845
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    scalar_token_0 = None
    int_0 = -876
    list_token_0 = ListToken(scalar_token_0, int_0, int_0)
    scalar_token_1 = ScalarToken(str_0, int_0, int_0)
    assert scalar_token_1 != list_token_0
    assert scalar_token_1 == scalar_token_1
    str_0 = None
    list_token_0 = ListToken(scalar_token_0, int_0, int_0)
    assert scalar_token_1 != list_token_0
    list_token_1 = ListToken(list_token_0, int_0, int_0)
    assert list_token_1 != list_token_0
    assert list_token_1 == list

# Generated at 2022-06-26 10:53:05.033777
# Unit test for constructor of class DictToken
def test_DictToken():

	# Arrange
	scalar_token_0 = None
	int_0 = -876
	list_token_0 = ListToken(scalar_token_0, int_0, int_0)
	int_1 = -876
	scalar_token_1 = None
	int_2 = -876
	list_token_1 = ListToken(scalar_token_1, int_2, int_2)
	int_3 = -876
	bool_0 = True
	str_0 = 'str_0'
	scalar_token_2 = ScalarToken(bool_0, int_0, int_1)
	scalar_token_3 = ScalarToken(str_0, int_0, int_1)

# Generated at 2022-06-26 10:53:08.778951
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    scalar_token_0 = None
    dict_token_0 = ScalarToken(scalar_token_0, -1, -1)
    dict_token_1 = ScalarToken(scalar_token_0, -1, -1)
    assert dict_token_0 == dict_token_1


# Generated at 2022-06-26 10:53:14.016899
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    scalar_token_0 = None
    token_0 = Token(scalar_token_0, 0, 0, "")
    token_1 = Token(scalar_token_0, 0, 0, "")
    if (token_0 == token_1):
        pass



# Generated at 2022-06-26 10:53:29.645955
# Unit test for constructor of class DictToken
def test_DictToken():
  scalar_token_0 = None
  int_0 = -876
  list_token_0 = ListToken(scalar_token_0, int_0, int_0)
  key_token_0 = ScalarToken(None, -876, -876)
  key_token_1 = ScalarToken(None, -876, -876)
  value_token_0 = scalar_token_0
  value_token_1 = int_0
  value_token_2 = list_token_0
  value_token_3 = list_token_0

# Generated at 2022-06-26 10:53:35.306029
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # test case 0:
    scalar_token_0 = None
    int_0 = -876
    list_token_0 = ListToken(scalar_token_0, int_0, int_0)
    dict_token_0 = DictToken(list_token_0, int_0, int_0)
    scalar_token_0 = ScalarToken(True, int_0, int_0)
    dict_token_1 = DictToken(scalar_token_0, int_0, int_0)
    dict_token_2 = DictToken(dict_token_1, int_0, int_0)
    dict_token_0 = DictToken(dict_token_2, int_0, int_0)

# Generated at 2022-06-26 10:53:45.018826
# Unit test for constructor of class DictToken
def test_DictToken():
    # Create a new DictToken object
    dict_token_0 = DictToken()
    assert not hasattr(dict_token_0, "_DictToken__child_tokens")
    assert hasattr(dict_token_0, "__dict__")
    assert dict_token_0._DictToken__child_tokens is None
    assert dict_token_0.__dict__[
        "_DictToken__child_tokens"
    ] is None, "The attribute _DictToken__child_tokens should be initialized"
    assert dict_token_0.__dict__["_DictToken__child_tokens"] is None, (
        "The attribute _DictToken__child_tokens should be initialized"
    )
    assert dict_token_0._DictToken__child_tokens

# Generated at 2022-06-26 10:53:48.546625
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken(None, None, None)
    dict_token_0._get_value()
    dict_token_0._get_child_token(None)


# Generated at 2022-06-26 10:53:52.748108
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token(None, 29, -16)
    assert token == token
    assert token != None
    assert not(token != token)


# Generated at 2022-06-26 10:53:58.993257
# Unit test for constructor of class DictToken
def test_DictToken():
    scalar_token_0 = None
    int_0 = -876
    list_token_0 = ListToken(scalar_token_0, int_0, int_0)
    list_token_1 = ListToken(scalar_token_0, int_0, int_0)
    list_token_2 = ListToken(scalar_token_0, int_0, int_0)
    list_token_3 = ListToken(scalar_token_0, int_0, int_0)
    list_token_4 = ListToken(scalar_token_0, int_0, int_0)
    list_token_5 = ListToken(scalar_token_0, int_0, int_0)

# Generated at 2022-06-26 10:54:02.511174
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test case 0
    scalar_token_0 = None
    int_0 = -876
    list_token_0 = ListToken(scalar_token_0, int_0, int_0)



# Generated at 2022-06-26 10:54:09.377169
# Unit test for constructor of class DictToken
def test_DictToken():
    scalar_token_0 = None
    float_0 = float("nan")
    float_1 = float("nan")
    scalar_token_1 = None
    dict_0 = dict(((scalar_token_0, float_1), (float_0, scalar_token_1)))
    dict_token_0 = DictToken(dict_0, 0, 0)
    int_0 = -876
    list_token_0 = ListToken(scalar_token_0, int_0, int_0)
    dict_token_1 = DictToken(dict_0, 0, 0, list_token_0)


# Generated at 2022-06-26 10:54:21.231658
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    ### START: Arrange
    scalar_token_0 = ScalarToken(None, -1, -1)
    scalar_token_1 = ScalarToken(None, -1, -1)
    scalar_token_2 = ScalarToken(-1, -1, -1)
    scalar_token_3 = ScalarToken(None, -1, -1, "")

    # END: Arrange

    ### START: Act
    #  END: Act

    ### START: Assert
    assert scalar_token_0 == scalar_token_1
    assert scalar_token_0 == scalar_token_3
    assert scalar_token_1 == scalar_token_3
    assert not scalar_token_0 == scalar_token_2
    assert not scalar_token_1 == scalar_token

# Generated at 2022-06-26 10:54:29.145703
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    scalar_token_0 = None
    int_0 = -876
    list_token_0 = ListToken(scalar_token_0, int_0, int_0)
    assert scalar_token_0 == scalar_token_0
    assert scalar_token_0 != list_token_0
    assert list_token_0 == ListToken(scalar_token_0, int_0, int_0)
    assert list_token_0 != ListToken(scalar_token_0, int_0, int_0)

test_case_0()
test_Token___eq__()

# Generated at 2022-06-26 10:54:47.912633
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    line_no_0 = 100
    column_no_0 = 578
    index_0 = 110
    position_0 = Position(line_no_0, column_no_0, index_0)
    line_no_1 = 0
    column_no_1 = 0
    index_1 = 0
    position_1 = Position(line_no_1, column_no_1, index_1)
    line_no_2 = 130
    column_no_2 = 571
    index_2 = 134
    position_2 = Position(line_no_2, column_no_2, index_2)
    line_no_3 = 735
    column_no_3 = 664
    index_3 = 741

# Generated at 2022-06-26 10:54:56.828962
# Unit test for constructor of class DictToken
def test_DictToken():
    scalar_token_0 = None
    scalar_token_1 = None
    int_0 = -876
    list_token_0 = ListToken(scalar_token_0, int_0, int_0)
    list_token_1 = ListToken(scalar_token_0, int_0, int_0)
    dict_token_0 = DictToken(scalar_token_1, int_0, int_0)
    assert ((dict_token_0._start_index == int_0)
            and (dict_token_0._end_index == int_0)
            and (dict_token_0._value == {}))

# Generated at 2022-06-26 10:54:59.807284
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    test_case_0()

if __name__ == "__main__":
    test_Token___eq__()

# Generated at 2022-06-26 10:55:09.790170
# Unit test for constructor of class DictToken
def test_DictToken():
    scalar_token_0 = None
    int_0 = -876
    list_token_0 = ListToken(scalar_token_0, int_0, int_0)
    int_1 = -1
    scalar_token_1 = ListToken(scalar_token_0, int_0, int_0)
    scalar_token_2 = ListToken(scalar_token_1, int_1, int_1)
    scalar_token_2 = DictToken(scalar_token_2, scalar_token_1, int_0, int_0)
    int_2 = -731
    scalar_token_1 = ListToken(scalar_token_2, int_2, int_2)

# Generated at 2022-06-26 10:55:11.890174
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    scalar_token_0 = None
    list_token_0 = ListToken(None, None, None)
    assert list_token_0 == scalar_token_0


# Generated at 2022-06-26 10:55:14.438881
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    scalar_token_0 = None
    int_0 = -876
    list_token_0 = ListToken(scalar_token_0, int_0, int_0)
    assert not list_token_0 == None


# Generated at 2022-06-26 10:55:25.520374
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_0 = ScalarToken(None, 0, 1)
    token_1 = ScalarToken(None, 0, 1, "abc")
    token_2 = ScalarToken(None, 0, 2, "abc")

    expected_0 = True
    actual_0 = token_0 == token_1
    assert actual_0 == expected_0, "Test 0: Expected %s, got %s" % (
        expected_0,
        actual_0,
    )

    expected_1 = False
    actual_1 = token_1 == token_2
    assert actual_1 == expected_1, "Test 1: Expected %s, got %s" % (
        expected_1,
        actual_1,
    )

    expected_2 = False
    actual_2 = token_1 == object()
    assert actual_

# Generated at 2022-06-26 10:55:32.985353
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    scalar_token_0 = None
    int_0 = -876
    list_token_0 = ListToken(scalar_token_0, int_0, int_0)
    scalar_token_1 = None
    int_1 = -876
    list_token_1 = ListToken(scalar_token_1, int_1, int_1)

    assert list_token_0 == list_token_1


# Generated at 2022-06-26 10:55:34.837015
# Unit test for constructor of class DictToken
def test_DictToken():
    try:
        test_case_0()
    except NotImplementedError as e:
        assert False



# Generated at 2022-06-26 10:55:38.405410
# Unit test for constructor of class DictToken
def test_DictToken():
    scalar_token_0 = None
    int_0 = -876
    list_token_0 = ListToken(scalar_token_0, int_0, int_0)
    internal_value_0 = {"a": list_token_0}
    int_1 = -315
    dict_token_0 = DictToken(internal_value_0, int_0, int_1)



# Generated at 2022-06-26 10:56:00.536277
# Unit test for constructor of class DictToken
def test_DictToken():
    # None case
    scalar_token_0 = None
    int_0 = -876

    my_dict_token_0 = DictToken(scalar_token_0, int_0, int_0)


# Generated at 2022-06-26 10:56:07.168685
# Unit test for constructor of class DictToken
def test_DictToken():
    d = {}
    list_token_0 = ListToken(d, d, d)
    print(list_token_0)


if __name__ == "__main__":
    test_case_0()
    test_DictToken()
    print("End of testcase")

# Generated at 2022-06-26 10:56:10.260867
# Unit test for constructor of class DictToken
def test_DictToken():
    scalar_token_0 = None
    DictToken(scalar_token_0, scalar_token_0, scalar_token_0)


# Generated at 2022-06-26 10:56:11.690560
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test against expected input
    pass
    

# Generated at 2022-06-26 10:56:19.782779
# Unit test for constructor of class DictToken
def test_DictToken():
    def test_case_0():
        scalar_token_0 = None
        int_0 = -876
        list_token_0 = ListToken(scalar_token_0, int_0, int_0)
    def test_case_1():
        scalar_token_0 = None
        int_0 = -876
        list_token_0 = ListToken(scalar_token_0, int_0, int_0)
    def test_case_2():
        scalar_token_0 = None
        int_0 = -876
        list_token_0 = ListToken(scalar_token_0, int_0, int_0)
    def test_case_3():
        scalar_token_0 = None
        int_0 = -876
        list_token_0

# Generated at 2022-06-26 10:56:23.750693
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = 651
    list_token_0 = ListToken(int_0, int_0, int_0)
    dict_token_0 = DictToken(list_token_0, int_0, int_0)
    assert dict_token_0 is not None


# Generated at 2022-06-26 10:56:32.382895
# Unit test for constructor of class DictToken
def test_DictToken():
    scalar_token_0 = None
    scalar_token_1 = scalar_token_0
    scalar_token_2 = None
    list_token_0 = ListToken(scalar_token_2, scalar_token_2, scalar_token_2)
    scalar_token_3 = list_token_0
    scalar_token_4 = None
    scalar_token_5 = scalar_token_4
    scalar_token_6 = scalar_token_5
    scalar_token_7 = scalar_token_6

    ret_0 = DictToken({ scalar_token_0 : scalar_token_3 }, int, int)
    ret_1 = DictToken({ scalar_token_1 : scalar_token_4 }, int, int)
    ret_2 = D

# Generated at 2022-06-26 10:56:35.070739
# Unit test for constructor of class DictToken
def test_DictToken():
    scalar_token = None
    int_ = -876
    dict_token = DictToken(scalar_token, int_, int_)
    return dict_token

# Generated at 2022-06-26 10:56:36.531778
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken( None, None, None, None, None, None)

# Generated at 2022-06-26 10:56:50.574142
# Unit test for constructor of class DictToken
def test_DictToken():
    list_token_0 = ListToken(None, None, None)
    scalar_token_0 = None
    dict_token_0 = DictToken(
        list_token_0, scalar_token_0, scalar_token_0, content=None
    )
    scalar_token_1 = None
    list_token_1 = ListToken(None, None, None)
    dict_token_2 = DictToken(
        list_token_1, scalar_token_1, scalar_token_1, content=None
    )
    dict_token_3 = DictToken(scalar_token_1, scalar_token_1, scalar_token_1)
    dict_token_3.__setattr__("_content", scalar_token_1)
    dict_token_2.__

# Generated at 2022-06-26 10:57:06.119136
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken(None, None)


# Generated at 2022-06-26 10:57:07.468770
# Unit test for constructor of class DictToken
def test_DictToken():
    # TODO: implement test
    pass


# Generated at 2022-06-26 10:57:17.051204
# Unit test for constructor of class DictToken
def test_DictToken():
    scalar_token_0 = ScalarToken(pos, string, obj, start_index, end_index)
    int_0 = -876

    # Test 0
    dict_token_0 = DictToken(scalar_token_0, int_0, int_0)
    assert dict_token_0._child_tokens == {pos, obj}, "Failed test"
    assert dict_token_0._child_keys == {pos, string}, "Failed test"
    dict_token_0._get_value()
    dict_token_0._get_child_token(obj)
    dict_token_0._get_key_token(pos)



# Generated at 2022-06-26 10:57:27.328057
# Unit test for constructor of class DictToken
def test_DictToken():
    scalar_token_0 = None
    int_0 = -876
    list_token_0 = ListToken(scalar_token_0, int_0, int_0)
    str_0 = "Y"
    list_token_1 = ListToken(list_token_0, str_0, int_0)
    bool_0 = True
    list_token_2 = ListToken(list_token_1, bool_0, int_0)
    bool_1 = True
    scalar_token_1 = ScalarToken(bool_1, int_0, int_0)
    list_token_3 = ListToken(list_token_2, scalar_token_1, int_0)
    list_token_4 = ListToken(list_token_3, scalar_token_0, int_0)

# Generated at 2022-06-26 10:57:29.538324
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken(DictToken, None)


# Generated at 2022-06-26 10:57:36.078529
# Unit test for constructor of class DictToken
def test_DictToken():
    value = None
    start_index = -876
    end_index = -876
    content = "Content"
    expected = DictToken(value, start_index, end_index, content)
    actual = DictToken(value, start_index, end_index, content)
    assert actual == expected


# Generated at 2022-06-26 10:57:40.307351
# Unit test for constructor of class DictToken
def test_DictToken():
    scalar_token_1 = None
    scalar_token_0 = None
    dict_token_0 = DictToken(scalar_token_0, scalar_token_1, scalar_token_0)



# Generated at 2022-06-26 10:57:50.700347
# Unit test for constructor of class DictToken
def test_DictToken():
    scalar_token_0 = None
    scalar_token_1 = None
    int_0 = -876
    list_token_0 = ListToken(scalar_token_0, int_0, int_0)
    dict_token = DictToken({scalar_token_1: list_token_0}, scalar_token_0, scalar_token_1, int_0)
    assert dict_token.value == {scalar_token_1._get_value(): list_token_0._get_value()}
    assert dict_token.start == scalar_token_0.start
    assert dict_token.end == scalar_token_1.end
    assert dict_token._value == {scalar_token_1: list_token_0}

# Generated at 2022-06-26 10:57:54.697592
# Unit test for constructor of class DictToken
def test_DictToken():
    scalar_token_0 = None
    list_token_0 = None
    dict_token_0 = DictToken(scalar_token_0, list_token_0, int_0)
    scalar_token_0 = DictToken(scalar_token_0, list_token_0, int_0)
    scalar_token_0 = DictToken(scalar_token_0, list_token_0, int_0)


# Generated at 2022-06-26 10:57:59.926193
# Unit test for constructor of class DictToken
def test_DictToken():

    # Test case for constructor of class DictToken with arguments:
    scalar_token_1 = None
    int_1 = -876
    dict_token_1 = DictToken(scalar_token_1, int_1, int_1)


# Generated at 2022-06-26 10:58:27.133986
# Unit test for constructor of class DictToken
def test_DictToken():
    list_token_0 = ListToken(None, None, None)
    dict_token_0 = DictToken(list_token_0, 0, 6)
    expected = DictToken(list_token_0, 0, 6)
    actual = dict_token_0
    assert actual == expected


# Generated at 2022-06-26 10:58:36.745757
# Unit test for constructor of class DictToken
def test_DictToken():
    scalar_token_0 = None
    true = True
    list_token_0 = ListToken(scalar_token_0, -876, -876)
    decimal_0 = decimal.Decimal("-77")
    false = False
    scalar_token_1 = ScalarToken(false, -876, -876)
    scalar_token_2 = ScalarToken(true, -876, -876)
    scalar_token_3 = ScalarToken(decimal_0, -876, -876)
    dict_token_0 = DictToken(scalar_token_1, -876, -876, ["revi", true, scalar_token_3], [true, true, true])

# Generated at 2022-06-26 10:58:47.118327
# Unit test for constructor of class DictToken
def test_DictToken():
    scalar_token_0 = None
    scalar_token_1 = None
    token_dictionary_0 = {scalar_token_0: scalar_token_1}
    int_0 = -876
    int_1 = -876
    dict_token_0 = DictToken(token_dictionary_0, int_0, int_1)
    scalar_token_2 = None
    scalar_token_3 = None
    token_dictionary_1 = {scalar_token_2: scalar_token_3}
    int_2 = -876
    scalar_token_4 = None
    token_dictionary_2 = {scalar_token_4: scalar_token_4}
    int_3 = -876
    int_4 = -876
    dict

# Generated at 2022-06-26 10:58:52.248709
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken(int, str, int, str)
    
    

# Generated at 2022-06-26 10:58:55.215422
# Unit test for constructor of class DictToken
def test_DictToken():
    dic = {
        "a": "b",
        "c": "d",
    }
    DictToken(dic, 0, 1)

# Generated at 2022-06-26 10:59:03.615622
# Unit test for constructor of class DictToken
def test_DictToken():
    scalar_token_0 = None
    key_0 = 'foo'
    value_0 = 'bar'
    scalar_token_1 = None
    key_1 = 'baz'
    value_1 = 'qux'
    scalar_token_2 = None
    key_2 = 'quz'
    value_2 = 'quuz'
    key_token_0 = ScalarToken(key_0, 0, 0, 'foo')
    key_token_1 = ScalarToken(key_1, 0, 0, 'baz')
    key_token_2 = ScalarToken(key_2, 0, 0, 'quz')
    value_token_0 = ScalarToken(value_0, 0, 0, 'bar')

# Generated at 2022-06-26 10:59:11.104609
# Unit test for constructor of class DictToken
def test_DictToken():
    scalar_token_0 = None
    int_0 = -876
    list_token_0 = ListToken(scalar_token_0, int_0, int_0)
    str_0 = "DictToken"
    dict_token_0 = DictToken(list_token_0, int_0, int_0, str_0)

# Generated at 2022-06-26 10:59:18.693370
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test
    list_token_0 = ListToken(None, None, None)

    # Test
    scalar_token_0 = None
    int_0 = -876
    list_token_0 = ListToken(scalar_token_0, int_0, int_0)

    # Test
    scalar_token_0 = None
    int_0 = -876
    list_token_0 = ListToken(scalar_token_0, int_0, int_0)

    # Test
    scalar_token_0 = None
    list_token_0 = None
    int_0 = -876
    list_token_0 = ListToken(scalar_token_0, list_token_0, int_0)

    # Test
    scalar_token_0 = None
    list_

# Generated at 2022-06-26 10:59:22.561396
# Unit test for constructor of class DictToken
def test_DictToken():
    scalar_token_0 = None
    scalar_token_1 = None
    dict_token_0 = DictToken(scalar_token_0, scalar_token_1, scalar_token_1, scalar_token_0)


# Generated at 2022-06-26 10:59:30.812213
# Unit test for constructor of class DictToken
def test_DictToken():
    scalar_token_0 = None
    int_0 = -876
    list_token_0 = ListToken(scalar_token_0, int_0, int_0)
    scalar_token_1 = None
    int_1 = -876
    list_token_1 = ListToken(scalar_token_1, int_1, int_1)
    scalar_token_2 = None
    int_2 = -876
    list_token_2 = ListToken(scalar_token_2, int_2, int_2)
    scalar_token_3 = None
    int_3 = -876
    list_token_3 = ListToken(scalar_token_3, int_3, int_3)

# Generated at 2022-06-26 11:00:33.604630
# Unit test for constructor of class DictToken
def test_DictToken():
    a = {
        "key1": {"key2": "key3"},
        "key2": {"key2": "key3"},
        "key3": {"key2": "key3"},
    }

    b = {}
    for k, v in a.items():
        b[k] = v

    return a == b


if __name__ == "__main__":
    test_case_0()
    test_DictToken()

# Generated at 2022-06-26 11:00:36.117580
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = -876
    scalar_token_0 = None
    dict_token_0 = DictToken({})


# Generated at 2022-06-26 11:00:37.537565
# Unit test for constructor of class DictToken
def test_DictToken():
    class_0 = DictToken(5, 6)
    print(class_0)


# Generated at 2022-06-26 11:00:46.277583
# Unit test for constructor of class DictToken
def test_DictToken():
    scalar_token_0 = None
    scalar_token_1 = None
    key_token_0_0 = scalar_token_0
    key_token_0_1 = scalar_token_1
    scalar_token_2 = None
    scalar_token_3 = None
    value_token_0_0 = scalar_token_2
    value_token_0_1 = scalar_token_3
    token_0 = DictToken(
        [key_token_0_0, key_token_0_1], [value_token_0_0, value_token_0_1], int_0, int_0
    )
    assert token_0 is not None


# Generated at 2022-06-26 11:00:47.864725
# Unit test for constructor of class DictToken
def test_DictToken():
    with pytest.raises(TypeError):
        test_case_0()

# Generated at 2022-06-26 11:00:49.739467
# Unit test for constructor of class DictToken
def test_DictToken():
    test = DictToken()
    assert isinstance(test, DictToken)


# Generated at 2022-06-26 11:00:55.639740
# Unit test for constructor of class DictToken
def test_DictToken():
    scalar_token_0 = None
    int_0 = -876
    dict_token_0 = DictToken(scalar_token_0, int_0, int_0)


# Generated at 2022-06-26 11:00:56.991161
# Unit test for constructor of class DictToken
def test_DictToken():
    scalar_token_0 = None
    int_0 = -876

# Generated at 2022-06-26 11:01:00.202582
# Unit test for constructor of class DictToken
def test_DictToken():
    scalar_token_0 = None
    scalar_token_1 = None
    dict_token_0 = DictToken(scalar_token_0, scalar_token_1, scalar_token_1)


# Generated at 2022-06-26 11:01:03.979157
# Unit test for constructor of class DictToken
def test_DictToken():
    _args = [{}]
    _kwargs = {}
    _expect = {}
    _return = DictToken(*_args, **_kwargs)
    _expect = DictToken()
    assert _return == _expect
