

# Generated at 2022-06-26 10:52:30.743139
# Unit test for constructor of class DictToken
def test_DictToken():
    # initialize a dictionary
    byte_list = bytes([0, 1, 2, 3, 4, 5])
    some_list = [0, 1, 2, 3, 4, 5]
    some_dict = {
        b"A": byte_list,
        b"B": some_list,
        b"C": b"Hello, World",
        b"D": "Hello, World",
    }

    # create a dictionary token
    dict_token = DictToken(some_dict)

    # get the key token for "A"
    key_token_for_A = dict_token._get_key_token(b"A")

    # get the child token for "A"
    child_token_for_B = dict_token._get_child_token(b"B")

    # get the child token for b"C

# Generated at 2022-06-26 10:52:37.988457
# Unit test for constructor of class DictToken
def test_DictToken():
    bytes_0 = b'\x01\x02\x03\x04'
    int_0 = 198
    int_1 = 208
    str_0 = '6$zkWY1F\x7f]S0S'
    dict_token_0 = DictToken(bytes_0, int_0, int_1, str_0)


# Generated at 2022-06-26 10:52:42.601871
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    bytes_0 = b'\xc4\x00'
    int_0 = -1028
    str_0 = '2=rMLoVZB&glH4o,%>J'
    list_token_0 = ListToken(bytes_0, int_0, int_0, str_0)
    assert list_token_0 == list_token_0


# Generated at 2022-06-26 10:52:50.629753
# Unit test for constructor of class DictToken
def test_DictToken():

    bytes_0 = b'\xc4\x00'
    int_0 = -1028
    int_1 = -1028
    str_0 = '2=rMLoVZB&glH4o,%>J'
    list_token_0 = ListToken(bytes_0, int_0, int_1, str_0)
    dict_token_0 = DictToken(list_token_0, int_0, int_1, str_0)


# Generated at 2022-06-26 10:52:57.758394
# Unit test for constructor of class DictToken
def test_DictToken():
    bytes_0 = b'\xc4\x00'
    int_0 = -1028
    str_0 = '2=rMLoVZB&glH4o,%>J'
    list_token_0 = ListToken(bytes_0, int_0, int_0, str_0)

    bytes_1 = b'^,\xba\x1d\x1e\x16'
    int_1 = -1028
    str_1 = '2=rMLoVZB&glH4o,%>J'
    list_token_1 = ListToken(bytes_1, int_1, int_1, str_1)

    ScalarToken(bytes_0, 0, 1)

# Generated at 2022-06-26 10:53:05.333346
# Unit test for constructor of class DictToken
def test_DictToken():
    bytes_0 = b'\xc4\x00'
    int_1 = -1028
    int_0 = -1028
    str_0 = '2=rMLoVZB&glH4o,%>J'
    list_token_0 = ListToken(bytes_0, int_1, int_0, str_0)
    dict_token_0 = DictToken(list_token_0, int_0, int_0, str_0)
    assert(dict_token_0.string == '2=rMLoVZB&glH4o,%>J')


# Generated at 2022-06-26 10:53:08.836985
# Unit test for constructor of class DictToken
def test_DictToken():
    # Initialize test variables
    bytes_0 = b'\xc4\x00'
    int_0 = -1028
    str_0 = '2=rMLoVZB&glH4o,%>J'
    list_token_0 = ListToken(bytes_0, int_0, int_0, str_0)
    dict_token_0 = DictToken(bytes_0, int_0, list_token_0, str_0)



# Generated at 2022-06-26 10:53:17.885958
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    bytes_0 = bytes(b'')
    int_0 = 111
    str_0 = '4.>|s'
    list_token_0 = ListToken(bytes_0, int_0, int_0, str_0)
    bytes_1 = bytes(b'')
    int_1 = 47789
    str_1 = '<'
    list_token_1 = ListToken(bytes_1, int_1, int_1, str_1)
    assert list_token_0 != list_token_1


# Generated at 2022-06-26 10:53:29.524828
# Unit test for constructor of class DictToken
def test_DictToken():
    bytes_0 = b'\xc4\x00'
    int_0 = 769
    bytes_1 = b'\xce\xfa\x1b\x84\xc8\x95\x9dP'
    int_1 = int_0
    str_0 = '*gP%91M8\x1d\x1b\x0f#EH\x93\x17\x8e\x13`h\x1e\x1cq'
    bytes_2 = b'\xfc\xe6\x14\xc1t\xff\x0e\x92\xb8'
    int_2 = 3

# Generated at 2022-06-26 10:53:32.139326
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken(1, 2, 3) == DictToken(1, 2, 3)


# Generated at 2022-06-26 10:53:45.852971
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    str_token_0 = ScalarToken(0, 0, 0, "")
    str_token_1 = ScalarToken(0, 0, 0, "")
    str_token_2 = ScalarToken(0, 0, 0, "")
    str_token_3 = ScalarToken(0, 0, 0, "")
    str_token_4 = ScalarToken(0, 0, 0, "")
    str_token_5 = ScalarToken(0, 0, 0, "")
    str_token_6 = ScalarToken(0, 0, 0, "")
    str_token_7 = ScalarToken(0, 0, 0, "")

# Generated at 2022-06-26 10:53:47.284564
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:53:48.780293
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken()


# Generated at 2022-06-26 10:54:00.261912
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_1 = DictToken()
    assert isinstance(dict_token_1, Token)
    assert dict_token_1._get_value() == {}
    dict_token_2 = DictToken()
    assert isinstance(dict_token_2, Token)
    assert dict_token_2._get_value() == {}
    assert dict_token_1 == dict_token_2


# Generated at 2022-06-26 10:54:01.592778
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:02.554076
# Unit test for constructor of class DictToken
def test_DictToken():
    assert True


# Generated at 2022-06-26 10:54:10.228362
# Unit test for method __eq__ of class Token

# Generated at 2022-06-26 10:54:15.193207
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Assign
    # Create an instance of the Token class "dict_token_0"
    dict_token_0 = DictToken()

    # Assert
    # Check that the given value corresponds to the expected value
    assert (dict_token_0 == dict_token_0), "Incorrect value for dict_token_0"



# Generated at 2022-06-26 10:54:16.710240
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    assert False


# Generated at 2022-06-26 10:54:27.888464
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    a = ScalarToken(12345, 0, 5)
    b = ScalarToken(12345, 0, 5)
    c = ScalarToken(12345, 0, 6)
    d = ScalarToken(54321, 0, 5)
    e = ScalarToken(12345, 1, 5)
    f = ScalarToken(12345, 0, 4)
    g = ScalarToken(12345, 1, 6)
    h = ScalarToken(12345, 1, 4)
    i = ScalarToken(54321, 1, 6)
    j = ScalarToken(54321, 1, 4)
    assert a == b
    assert not(a == c)
    assert not(a == d)
    assert not(a == e)
    assert not(a == f)

# Generated at 2022-06-26 10:54:43.990659
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    print('Method __eq__ of class Token')

    dict_token_1 = DictToken()
    dict_token_2 = DictToken()
    dict_token_3 = DictToken()

    # Check that the method __eq__ of class Token works correctly on the first use case
    if dict_token_1.__eq__(dict_token_2) is True and dict_token_2.__eq__(dict_token_1) is True and dict_token_2.__eq__(dict_token_3) is False and dict_token_3.__eq__(dict_token_2) is False:
        print('Method __eq__ of class Token works correctly on the first use case')
    else:
        print('Method __eq__ of class Token does not work correctly on the first use case')


# Generated at 2022-06-26 10:54:48.337365
# Unit test for method __eq__ of class Token
def test_Token___eq__():

    # Call: __eq__({})
    instance = Token(value={})
    assert not instance.__eq__({})
    # Call: __eq__((), [12])
    instance = Token(value=(), start_index=12)
    assert not instance.__eq__((), [12])


# Generated at 2022-06-26 10:54:52.817809
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    scalar_token_0 = ScalarToken()
    token_0 = Token(dict_token_0, 0, 0)
    token_1 = Token(scalar_token_0, 0, 0)
    assert token_0 != token_1


# Generated at 2022-06-26 10:54:54.663941
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, DictToken)


# Generated at 2022-06-26 10:54:55.835306
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:58.281573
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    str_token_0 = ScalarToken('asdf')
    assert not bool(dict_token_0 == str_token_0)

# Generated at 2022-06-26 10:55:00.691009
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    assert() # TypeError


# Generated at 2022-06-26 10:55:04.032621
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test with a token class
    token_0 = ScalarToken()
    assert not token_0 == ScalarToken()
    # Test with a different class
    assert not token_0 == DictToken()


# Generated at 2022-06-26 10:55:12.798288
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    name_0 = 'name_0'
    name_1 = 'name_1'
    name_2 = 'name_2'
    name_3 = 'name_3'
    name_4 = 'name_4'
    name_5 = 'name_5'
    name_6 = 'name_6'
    name_7 = 'name_7'
    name_8 = 'name_8'
    name_9 = 'name_9'

    # Dictionary of comparisons
    value_0 = {name_0: 0.0, name_1: 1.1, name_2: 2.2, name_3: 3.3, name_4: 4.4}

# Generated at 2022-06-26 10:55:16.171994
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    # Compare two tokens
    assert (dict_token_0 == dict_token_1) == True


# Generated at 2022-06-26 10:55:32.156912
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    token_0 = Token(dict_token_0._get_value(), 0, 0, "")
    token_1 = Token(dict_token_1._get_value(), 0, 0, "")
    assert token_0 == token_1
    assert token_1 == token_0


# Generated at 2022-06-26 10:55:35.364571
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # create a instance of Token
    dict_token_0 = DictToken()
    # call method __eq__ with parameters
    result = dict_token_0.__eq__(dict_token_0)
    # compare the result with expected result
    assert result == True


# Generated at 2022-06-26 10:55:40.750587
# Unit test for constructor of class DictToken
def test_DictToken():
    import json
    json_str = '{"a": 1, "b": 2, "c": {"d": 3, "e": 4}}'
    json_dict = json.loads(json_str)
    keys = json_dict.keys()
    values = json_dict.values()
    tokens = OrderedDict([])
    for key, value in json_dict.items():
        tokens[key] = value
    dict_token_0 = DictToken(tokens, 0, len(json_str) - 1, json_str)
    assert str(dict_token_0) == "DictToken({'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}})"


# Generated at 2022-06-26 10:55:50.073332
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # simple test
    assert ScalarToken(30, 10, 20) == ScalarToken(30, 10, 20)
    assert ScalarToken(30, 10, 20) != ScalarToken(30, 10, 21)
    assert ScalarToken(30, 10, 20) != ScalarToken(30, 10, 20, "Hello")
    assert ScalarToken(30, 10, 20) != ScalarToken(30, 10, 20, "world")
    assert ScalarToken(30, 10, 20) != ScalarToken(31, 10, 20)
    assert ScalarToken(30, 10, 20) != ScalarToken(29, 10, 20)
    assert ScalarToken(30, 10, 20) != ScalarToken(30, 11, 20)

# Generated at 2022-06-26 10:55:53.738571
# Unit test for constructor of class DictToken
def test_DictToken():
    assert_is_instance(test_case_0(), DictToken)

if __name__ == "__main__":
    import pytest

    pytest.main()

# Generated at 2022-06-26 10:56:03.755229
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    result_a = (dict_token_0 == dict_token_0)
    result_b = (dict_token_1 != dict_token_1)
    result_c = (dict_token_0 == dict_token_1)
    result_d = (dict_token_1 != dict_token_0)
    result_e = (dict_token_1 == dict_token_1)
    result_f = (dict_token_1 != dict_token_1)
    assert result_a == True and result_b == True and result_c == False and result_d == False and result_e == True and result_f == False


# Generated at 2022-06-26 10:56:09.269781
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

if __name__ == "__main__":
    import logging

    logging.basicConfig(level=logging.DEBUG)
    unittest.main()

# Generated at 2022-06-26 10:56:10.507700
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    test_case_0()


# Generated at 2022-06-26 10:56:18.942213
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = dict_token_0
    dict_token_2 = DictToken()
    dict_token_2._end_index = 5
    dict_token_3 = DictToken()
    dict_token_3._start_index = 5
    dict_token_4 = DictToken()
    dict_token_4._start_index = 10
    dict_token_5 = DictToken()
    dict_token_5._start_index = 5
    dict_token_5._end_index = 5
    dict_token_6 = DictToken()
    dict_token_6._start_index = 5
    dict_token_6._end_index = 10
    dict_token_7 = DictToken()

# Generated at 2022-06-26 10:56:23.322692
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    token = DictToken(dict_token_0, 0, 0)
    token_1 = DictToken(dict_token_0, 0, 0)
    assert token == token_1



# Generated at 2022-06-26 10:56:54.466289
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    assert dict_token_0 == dict_token_0
    str_token_0 = ScalarToken('abc')
    str_token_1 = ScalarToken('abc')
    str_token_2 = ScalarToken('abcd')
    str_token_3 = ScalarToken('bc')
    str_token_4 = ScalarToken('abcd')
    str_token_5 = ScalarToken('bcd')
    str_token_6 = ScalarToken('c')
    str_token_7 = ScalarToken('d')
    assert str_token_0 == str_token_1
    assert not (str_token_0 == str_token_2)
    assert not (str_token_0 == str_token_3)
    assert str_token_2 == str_

# Generated at 2022-06-26 10:56:56.636308
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert not (dict_token_0 == dict_token_1)



# Generated at 2022-06-26 10:57:02.075861
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert dict_token_0 == dict_token_1


# Generated at 2022-06-26 10:57:03.369342
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()

# Generated at 2022-06-26 10:57:05.890922
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    assert dict_token_0.__eq__(DictToken())

# Generated at 2022-06-26 10:57:09.800814
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_0 = ScalarToken(value, start_index, end_index, content)
    token_1 = Token(value, start_index, end_index, content)
    assert token_0 == token_1


# Generated at 2022-06-26 10:57:21.304330
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    token_0 = Token(None, 0, 0)
    assert not isinstance(token_0, Token)
    assert token_0 == token_0
    assert not (token_0 != token_0)
    assert token_0 == dict_token_0
    assert not (token_0 != dict_token_0)
    token_1 = Token(None, 0, 1)
    assert not (token_1 == token_0)
    assert token_1 != token_0
    assert not (token_0 == token_1)
    assert token_0 != token_1
    token_2 = Token(None, 1, 0)
    assert not (token_2 == token_0)
    assert token_2 != token_0
    assert not (token_0 == token_2)


# Generated at 2022-06-26 10:57:29.432381
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    scalar_token_0 = ScalarToken(None)
    scalar_token_0._value = 'k[\'k\']'
    dict_token_0._value['k'] = scalar_token_0
    # If the test fails, dict_token_0._value['k']._start_index must be equal to 3
    assert dict_token_0._value['k']._start_index == 3
    # If the test fails, dict_token_0._start_index must be equal to 0
    assert dict_token_0._start_index == 0
    list_token_0 = ListToken()
    # If the test fails, list_token_0._content must be equal to ''
    assert list_token_0._content == ''
    # If the test fails,

# Generated at 2022-06-26 10:57:35.053801
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # normal case
    dict_token_0 = DictToken({1:2})
    assert dict_token_0 == DictToken({1:2})
    # boundary case
    dict_token_0 = DictToken({1:2})
    assert not dict_token_0 == ScalarToken("")


# Generated at 2022-06-26 10:57:39.817997
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    other_0 = None

    with pytest.raises(NameError):
        bool_0 = (dict_token_0.__eq__(other_0))


# Generated at 2022-06-26 10:58:35.581522
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0._value == {}
    assert dict_token_0._start_index == 0
    assert dict_token_0._end_index == 0
    assert dict_token_0._content == ""
    assert dict_token_0.string == ""
    assert dict_token_0.value == {}
    assert dict_token_0.start == Position(1, 1, 0)
    assert dict_token_0.end == Position(1, 1, 0)
    assert dict_token_0.lookup([]) == dict_token_0
    assert dict_token_0.lookup_key([]) == dict_token_0
    assert repr(dict_token_0) == "DictToken({})".format("{}")


# Generated at 2022-06-26 10:58:40.726474
# Unit test for constructor of class DictToken
def test_DictToken():
    try:
        test_case_0()
    except:
        print('Exception in test case: ', sys._getframe().f_code.co_filename, sys._getframe().f_code.co_name, sys._getframe().f_lineno)
        raise AssertionError('Exception in test case')


# Generated at 2022-06-26 10:58:49.034693
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert repr(dict_token_0) == "DictToken({})"
    assert isinstance(dict_token_0, DictToken)
    assert isinstance(dict_token_0, Token)
    assert dict_token_0.string == '{}'
    assert isinstance(dict_token_0.value, typing.Dict)
    assert len(dict_token_0.value) == 0
    assert dict_token_0.start.column == 1
    assert dict_token_0.start.index == 0
    assert dict_token_0.start.line == 1
    assert dict_token_0.end.column == 2
    assert dict_token_0.end.index == 1
    assert dict_token_0.end.line == 1



# Generated at 2022-06-26 10:58:49.654769
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()

# Generated at 2022-06-26 10:58:50.938374
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0._get_value() == {}


# Generated at 2022-06-26 10:58:52.536412
# Unit test for constructor of class DictToken
def test_DictToken():
    pass #do nothing here, we only want to see coverage report for this class

# Generated at 2022-06-26 10:58:55.501697
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_1 = DictToken()
    assert isinstance(dict_token_1, DictToken)



# Generated at 2022-06-26 10:59:03.795141
# Unit test for constructor of class DictToken
def test_DictToken():
    expected_dict_token_0 = DictToken({}, 3, 2)
    assert expected_dict_token_0._get_value() == {}, "expected dict token value should be {}"
    dict_token_0 = DictToken({}, 3, 2)
    assert dict_token_0 == expected_dict_token_0, "dict token should be equal to expected dict token"
    assert dict_token_0.start._line == 4 and dict_token_0.start._column == 2 and dict_token_0.start._index == 3, "dict token start should be (4,2,3)"
    assert dict_token_0.end._line == 4 and dict_token_0.end._column == 2 and dict_token_0.end._index == 2, "dict token end should be (4,2,2)"
    assert dict_

# Generated at 2022-06-26 10:59:08.203289
# Unit test for constructor of class DictToken
def test_DictToken():
    # First test
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:59:09.516549
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0


# Generated at 2022-06-26 11:00:05.630354
# Unit test for constructor of class DictToken
def test_DictToken():
    # TODO implement this test
    assert True


# Generated at 2022-06-26 11:00:07.474306
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:00:08.621943
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:00:09.717032
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:00:10.487783
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken()


# Generated at 2022-06-26 11:00:12.846616
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0 is not None


# Generated at 2022-06-26 11:00:17.029552
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_1 = DictToken(
        '{}',
        start_index=0,
        end_index=1,
        content='{}')
    print(dict_token_1)
    assert dict_token_1 != None


# Generated at 2022-06-26 11:00:27.221689
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_0._get_position(4)
    assert dict_token_0._get_position(4) == Position(line_no=5, column_no=5, index=4)
    dict_token_0._get_value()
    assert dict_token_0._get_value() == {}
    dict_token_0.lookup([])
    assert dict_token_0.lookup([]) == dict_token_0
    dict_token_0.lookup_key(["foo", "bar"])
    assert dict_token_0.lookup_key(["foo", "bar"]) == DictToken()
    dict_token_0._get_child_token("foo")
    assert dict_token_0._get_child_token("foo") == Dict

# Generated at 2022-06-26 11:00:32.309702
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.token import DictToken
    from typesystem.token import ScalarToken
    from typesystem.token import DictToken

    x = DictToken()

    assert (x._child_keys == {})
    assert (x._child_tokens == {})
    assert (x._content == "")
    assert (x._end_index == 0)
    assert (x._start_index == 0)
    assert (x._value == {})


# Generated at 2022-06-26 11:00:33.119170
# Unit test for constructor of class DictToken
def test_DictToken():
    assert True == True
