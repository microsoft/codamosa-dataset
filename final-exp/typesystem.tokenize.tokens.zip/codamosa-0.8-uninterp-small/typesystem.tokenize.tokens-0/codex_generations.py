

# Generated at 2022-06-26 10:52:25.017385
# Unit test for constructor of class DictToken
def test_DictToken(): # pass
    dict_token_1 = DictToken()



# Generated at 2022-06-26 10:52:27.645583
# Unit test for constructor of class DictToken
def test_DictToken():
    # Since the constructor accepts arbitrary arguments, we just test for some
    # example values.
    test_case_0()


# Generated at 2022-06-26 10:52:33.183093
# Unit test for constructor of class DictToken
def test_DictToken():
    assert getattr(DictToken, '__init__', None) != None
    dict_token_0 = DictToken()
    assert getattr(DictToken, '_get_child_token', None) != None
    assert getattr(DictToken, '_get_key_token', None) != None
    assert getattr(DictToken, '_get_value', None) != None
    assert getattr(DictToken, 'is_member', None) != None
    assert getattr(DictToken, 'lookup', None) != None
    assert getattr(DictToken, 'lookup_key', None) != None
    assert getattr(DictToken, 'path', None) != None


# Generated at 2022-06-26 10:52:35.265180
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert repr(dict_token_0) == "DictToken({})"

# Generated at 2022-06-26 10:52:44.715639
# Unit test for method __eq__ of class Token
def test_Token___eq__():

    # Test cases for method __eq__, which returns a Boolean
    
    
    # Failure case.
    # Should return False.
    assert ScalarToken(3, 1, 3).__eq__(DictToken()), "Expected False."
    # Success case.
    # Should return True.
    assert ScalarToken(6, 2, 5).__eq__(ScalarToken(6, 2, 5)), "Expected True."
    # Failure case.
    # Should return False.
    assert ScalarToken(7, 3, 5).__eq__(ScalarToken(7, 4, 5)), "Expected False."
    # Failure case.
    # Should return False.
    assert ScalarToken(11, 1, 4).__eq__(ScalarToken(12, 2, 4)), "Expected False."
    #

# Generated at 2022-06-26 10:52:53.414900
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, DictToken)
    assert dict_token_0._child_keys
    assert dict_token_0._child_tokens
    assert dict_token_0._content
    assert dict_token_0._end_index
    assert dict_token_0._start_index
    assert dict_token_0._value
    assert dict_token_0.end
    assert dict_token_0.start
    assert dict_token_0.string
    assert dict_token_0.value

test_DictToken()

# Generated at 2022-06-26 10:52:54.893451
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken() == DictToken()


# Generated at 2022-06-26 10:53:05.290670
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_0 = ScalarToken(0)
    token_1 = ScalarToken(0)
    assert token_0 == token_1
    token_0 = ScalarToken(0)
    token_1 = ScalarToken(0)
    assert token_0 == token_1
    token_0 = ScalarToken(0)
    token_1 = ScalarToken(1)
    assert token_0 != token_1
    token_0 = ScalarToken(0)
    token_1 = ScalarToken(1)
    assert token_0 != token_1
    token_0 = ScalarToken(True)
    token_1 = ScalarToken(True)
    assert token_0 == token_1
    token_0 = ScalarToken(True)
    token_1 = ScalarToken(True)
    assert token_0

# Generated at 2022-06-26 10:53:10.471138
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()

    dict_token_0.__eq__(dict_token_1)

    scalar_token_0 = ScalarToken()
    scalar_token_1 = ScalarToken()

    scalar_token_0.__eq__(scalar_token_1)

    list_token_0 = ListToken()
    list_token_1 = ListToken()

    list_token_0.__eq__(list_token_1)


# Generated at 2022-06-26 10:53:16.704807
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    # make sure that the object has the right attributes
    assert isinstance(dict_token_0, DictToken)
    assert isinstance(dict_token_0._child_keys, dict)
    assert isinstance(dict_token_0._child_tokens, dict)


# Generated at 2022-06-26 10:53:36.964685
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    # calling instance method _get_value(self) of class DictToken
    value_0 = dict_token_0._get_value()
    assert value_0 == {}


# Generated at 2022-06-26 10:53:39.102165
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:53:50.707012
# Unit test for constructor of class DictToken
def test_DictToken():
    index_0 = [
      1,
      2,
      3,
    ]
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    token_0 = dict_token_0.lookup(index_0)
    token_1 = dict_token_1.lookup(index_0)
    assert token_0 == token_1
    token_2 = dict_token_0.lookup_key(index_0)
    token_3 = dict_token_1.lookup_key(index_0)
    assert token_2 == token_3


# Generated at 2022-06-26 10:53:54.396646
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 10:53:56.074293
# Unit test for constructor of class DictToken
def test_DictToken():
    assert isinstance(test_case_0(), DictToken)


# Generated at 2022-06-26 10:53:58.663921
# Unit test for constructor of class DictToken
def test_DictToken():
    def test_case_0():
        dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:01.082471
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, DictToken)


# Generated at 2022-06-26 10:54:02.422272
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:54:10.154831
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, DictToken)
    assert not hasattr(dict_token_0, '_DictToken__dict')
    assert isinstance(dict_token_0._child_keys, dict)
    assert len(dict_token_0._child_keys) == 0
    assert isinstance(dict_token_0._child_tokens, dict)
    assert len(dict_token_0._child_tokens) == 0
    assert not hasattr(dict_token_0, '_DictToken__dict')
    assert not hasattr(dict_token_0, '_DictToken__value')
    assert not hasattr(dict_token_0, '_DictToken__value')

# Generated at 2022-06-26 10:54:12.712747
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_1 = DictToken(
        '{}',
        0,
        1,
    )
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:38.667108
# Unit test for constructor of class DictToken
def test_DictToken():
    # Case 1
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:47.912439
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken(
        {
            KeywordToken(
                "test_keyword",
                0,
                9,
            ):
            ScalarToken(2, 0, 0),
        },
        0,
        9,
    )
    dict_token_1 = DictToken(
        {
            KeywordToken(
                "test_keyword",
                0,
                9,
            ):
            ScalarToken(2, 0, 0),
        },
        0,
        9,
    )

    assert dict_token_0 is not dict_token_1
    assert dict_token_0 == dict_token_1


# Generated at 2022-06-26 10:54:50.635975
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    s = repr(dict_token_0)
    assert s == "DictToken(...)"

# Generated at 2022-06-26 10:54:51.546329
# Unit test for constructor of class DictToken
def test_DictToken():
    print(dict_token_0)


# Generated at 2022-06-26 10:54:52.817812
# Unit test for constructor of class DictToken
def test_DictToken():
    if __name__ == "__main__":
        test_case_0()

# Generated at 2022-06-26 10:54:53.795314
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:55.277288
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:56.118438
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:54:57.286977
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:54:59.911027
# Unit test for constructor of class DictToken
def test_DictToken():

    dict_token_0 = DictToken(value = True, start_index = 5)


# Generated at 2022-06-26 10:55:18.785157
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken()



# Generated at 2022-06-26 10:55:21.500145
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test for constructor
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:55:22.900708
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:55:29.913285
# Unit test for constructor of class DictToken
def test_DictToken():
    args_0 = ()
    kwargs_0 = {}
    dict_token_0 = DictToken(*args_0, **kwargs_0)
    assert dict_token_0.__class__ == DictToken
    assert dict_token_0._get_value() == {}


# Generated at 2022-06-26 10:55:31.863271
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_method_0 = test_case_0()
# --------------------------------------------------------------------------------- End of test cases for constructor of class DictToken

# Generated at 2022-06-26 10:55:33.435289
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0 is not None


# Generated at 2022-06-26 10:55:36.806131
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken.__doc__ is not None
    assert DictToken.__init__.__doc__ is not None
    assert test_DictToken.__doc__ is not None

    case_0 = ScalarToken("Boolean", 0, 7, "Boolean")

    test_case_0()


# Generated at 2022-06-26 10:55:39.350903
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:55:41.262639
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken()
    assert dict_token

# Generated at 2022-06-26 10:55:42.822230
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:56:21.066129
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:56:22.500537
# Unit test for constructor of class DictToken
def test_DictToken():
    assert test_case_0() == None


# Generated at 2022-06-26 10:56:23.750231
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:56:27.496852
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


if __name__ == "__main__":
    import nose

    nose.main(argv=[__file__, "--nocapture", "--logging-level", "ERROR"])

# Generated at 2022-06-26 10:56:34.651219
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    # check if all properties of class DictToken was set correctly
    assert dict_token_0._start_index == None, "Attribut _start_index was not set correctly"
    assert dict_token_0._end_index == None, "Attribut _end_index was not set correctly"
    assert dict_token_0._content == "", "Attribut _content was not set correctly"

# Generated at 2022-06-26 10:56:36.814218
# Unit test for constructor of class DictToken
def test_DictToken():
    try:
        dict_token_0 = DictToken()
    except:
        assert False


# Generated at 2022-06-26 10:56:38.108382
# Unit test for constructor of class DictToken
def test_DictToken():
    # Run test case 0
    test_case_0()


# Generated at 2022-06-26 10:56:41.856391
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()

# Generated at 2022-06-26 10:56:43.036101
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:56:45.094231
# Unit test for constructor of class DictToken
def test_DictToken():
    result = DictToken()
    assert result != None


# Generated at 2022-06-26 10:58:08.086155
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0.__class__.__name__ == "DictToken"
    assert dict_token_0.__class__.__bases__ == (Token,)
    dict_token_1 = DictToken()
    assert dict_token_1.__class__.__name__ == "DictToken"
    assert dict_token_1.__class__.__bases__ == (Token,)
    dict_token_2 = DictToken()
    assert dict_token_2.__class__.__name__ == "DictToken"
    assert dict_token_2.__class__.__bases__ == (Token,)
    dict_token_3 = DictToken()
    assert dict_token_3.__class__.__name__ == "DictToken"


# Generated at 2022-06-26 10:58:10.612241
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

if __name__ == '__main__':
    test_case_0()
    test_DictToken()

# Generated at 2022-06-26 10:58:11.793354
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:58:12.662325
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

# Generated at 2022-06-26 10:58:19.625278
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test with a token with no arguments
    dict_token_0 = DictToken()
    assert dict_token_0.value == {}, "Constructor raises exception when instantiated with no arguments"
    # Test with a token with one argument
    dict_token_1 = DictToken(1)
    assert dict_token_1.value == 1, "Constructor raises exception when instantiated with one argument"
    # Test with a token with multiple arguments
    dict_token_2 = DictToken(1,2)
    assert dict_token_2.value == 2, "Constructor raises exception when instantiated with multiple arguments"


# Generated at 2022-06-26 10:58:20.459975
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

# Generated at 2022-06-26 10:58:21.414913
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken()


# Generated at 2022-06-26 10:58:22.498257
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

# Generated at 2022-06-26 10:58:25.460908
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, Token)
    assert isinstance(dict_token_0, DictToken)


# Generated at 2022-06-26 10:58:26.655185
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:01:14.196025
# Unit test for constructor of class DictToken
def test_DictToken():
    # 1. Args:
    #   1.1 ScalarToken
    #       1.1.1 Value: integer
    #       1.1.2 Value: float
    #       1.1.3 Value: string
    #   1.2 DictToken
    #   1.3 ListToken
    # 2. Kwargs:
    #   2.1 ScalarToken
    #       2.1.1 Value: integer
    #       2.1.2 Value: float
    #       2.1.3 Value: string
    #   2.2 DictToken
    #   2.3 ListToken

    # Args
    # 1.1.1 Integer
    dict_token_0 = DictToken(5)
    assert dict_token_0 == DictToken(ScalarToken(5,0,0))
   

# Generated at 2022-06-26 11:01:15.618859
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:01:20.234382
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 11:01:21.745306
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:01:23.378924
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()



# Generated at 2022-06-26 11:01:24.709666
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 11:01:26.981697
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken()
    return True


# Generated at 2022-06-26 11:01:29.108700
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:01:34.064972
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert "DictToken()" == str(dict_token_0)
    assert "{}" == str(dict_token_0._get_value())
    assert "DictToken()" == repr(dict_token_0)
    assert "{}" == repr(dict_token_0._get_value())


# Generated at 2022-06-26 11:01:38.910275
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test exception
    try:
        DictToken()
    except Exception as ex:
        assert False, 'Failed to construct DictToken'
