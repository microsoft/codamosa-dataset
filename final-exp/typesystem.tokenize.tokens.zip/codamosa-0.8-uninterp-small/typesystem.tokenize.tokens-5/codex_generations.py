

# Generated at 2022-06-26 10:52:26.983275
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0._value == {} and dict_token_0._child_tokens == {}, "Constructor error in class DictToken"


# Generated at 2022-06-26 10:52:33.345842
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    dict_token_0 = DictToken({})
    dict_token_1 = DictToken({})
    dict_token_0 = DictToken({}, 0, 0, "")
    dict_token_1 = DictToken({}, 0, 0, "")
    dict_token_0 = DictToken({}, 0, 0)
    dict_token_1 = DictToken({}, 0, 0)
    dict_token_0 = DictToken({}, 0, 0, "", "")
    dict_token_1 = DictToken({}, 0, 0, "", "")
    dict_token_0 = DictToken({}, 0, 0, 0, "")

# Generated at 2022-06-26 10:52:35.504852
# Unit test for constructor of class DictToken
def test_DictToken():
    with pytest.raises(NotImplementedError):
        test_case_0()


# Generated at 2022-06-26 10:52:37.311875
# Unit test for method __eq__ of class Token
def test_Token___eq__():

    # Test Case 0
    test_case_0()



# Generated at 2022-06-26 10:52:38.264836
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 10:52:42.531100
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    """
    Test Token.__eq__ method.
    """
    dict_token_0 = DictToken(None, 0, 0)
    dict_token_1 = DictToken(None, 0, 0)
    expr_0 = dict_token_0 == dict_token_1
    assert expr_0



# Generated at 2022-06-26 10:52:43.642112
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:52:47.744657
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert dict_token_0 == dict_token_1



# Generated at 2022-06-26 10:52:53.511943
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    scalar_token_0 = ScalarToken()
    scalar_token_1 = ScalarToken()
    list_token_0 = ListToken()

    assert dict_token_0 != scalar_token_0
    assert dict_token_0 == dict_token_0
    assert scalar_token_0 != scalar_token_1
    assert scalar_token_0 == scalar_token_0


# Generated at 2022-06-26 10:52:56.595241
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(value=1, start_index=5, end_index=5, content="") == Token(value=1, start_index=5, end_index=5, content="")


# Generated at 2022-06-26 10:53:10.866895
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_0
    assert not dict_token_0 == 1
    assert not dict_token_0 == list()
    assert not dict_token_0 == {}
    assert not dict_token_0 == ()
    assert not dict_token_0 == "Hello"
    assert not dict_token_0 == ""
    assert not dict_token_0 == ()
    assert not dict_token_0 == "Hello"

# Generated at 2022-06-26 10:53:13.968342
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_1 = DictToken()
    dict_token_2 = DictToken()
    assert dict_token_1 == dict_token_2


# Generated at 2022-06-26 10:53:17.091143
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_1 = DictToken("typesystem.derive:expr.py", 1, 11, content="test_case_0")


# Generated at 2022-06-26 10:53:19.233893
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0._get_value() == {}


# Generated at 2022-06-26 10:53:21.070063
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()



# Generated at 2022-06-26 10:53:25.631388
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_0 = Token(value = None, start_index = None, end_index = None, content = None)
    token_1 = Token(value = None, start_index = None, end_index = None, content = None)

    assert token_0 == token_1



# Generated at 2022-06-26 10:53:30.724967
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:53:32.191143
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

# Generated at 2022-06-26 10:53:41.625224
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert repr(dict_token_0) == "DictToken({})"
    assert isinstance(dict_token_0, Token)
    assert dict_token_0.value == {}
    assert dict_token_0.start == Position(1, 1, 0)
    assert dict_token_0.end == Position(1, 1, 0)
    assert dict_token_0.lookup([]) == dict_token_0
    try:
        dict_token_0.lookup_key([])
    except:
        assert True
    else:
        assert False
    assert dict_token_0.string == "{}"


# Generated at 2022-06-26 10:53:44.736304
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()

if __name__ == "__main__":
    # test_DictToken()
    pass

if __name__ == "__main__":
    # test_DictToken()
    pass

# Generated at 2022-06-26 10:54:40.007148
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert dict_token_0.__eq__(dict_token_1) == True


# Generated at 2022-06-26 10:54:42.115915
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_1 = DictToken()

    dict_token_2 = DictToken()

    assert dict_token_1 == dict_token_2

# Generated at 2022-06-26 10:54:52.988564
# Unit test for constructor of class DictToken
def test_DictToken():
    scalar_token_0 = ScalarToken("weird string", 0, 5)
    scalar_token_1 = ScalarToken("baz", 0, 2)
    dict_token_0 = DictToken(
        {scalar_token_0: scalar_token_1}, 0, 5, "weird string"
    )
    scalar_token_2 = ScalarToken("bar", 0, 2)
    scalar_token_3 = ScalarToken("baz", 0, 2)
    scalar_token_4 = ScalarToken("foo", 0, 2)
    scalar_token_5 = ScalarToken("asfd", 0, 3)
    scalar_token_6 = ScalarToken("weird string", 0, 5)

# Generated at 2022-06-26 10:54:54.193160
# Unit test for constructor of class DictToken
def test_DictToken():
    # FIXME: This should be implemented
    pass



# Generated at 2022-06-26 10:54:55.706403
# Unit test for constructor of class DictToken
def test_DictToken():
    assert isinstance(DictToken(), DictToken)


# Generated at 2022-06-26 10:54:59.129705
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    token_0 = Token(None, 1, 2)
    assert_equal(token_0.__eq__(dict_token_0), False)


# Generated at 2022-06-26 10:55:08.527709
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    arg_0 = ScalarToken("test", 1, 2)
    arg_1 = DictToken({arg_0: arg_0}, start_index=1, end_index=2, content="test")
    arg_2 = ScalarToken("test", 1, 2)
    arg_3 = DictToken({arg_2: arg_2}, start_index=1, end_index=2, content="test")
    arg_4 = ScalarToken("test2", 1, 2)
    arg_5 = DictToken({arg_4: arg_4}, start_index=1, end_index=2, content="test")
    assert arg_1 == arg_3
    assert arg_1 != arg_5


# Generated at 2022-06-26 10:55:11.044165
# Unit test for constructor of class DictToken
def test_DictToken():
    expected = 'number'
    dict_token_0 = DictToken()
    actual = type(dict_token_0).__name__
    print(actual)
    assert actual == expected


# Generated at 2022-06-26 10:55:22.217923
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert dict_token_0 == dict_token_1
    list_token_0 = ListToken()
    list_token_1 = ListToken()
    assert list_token_0 == list_token_1
    scalar_token_0 = ScalarToken(9, 6, 7)
    scalar_token_1 = ScalarToken(5, 2, 3)
    assert scalar_token_0 == scalar_token_1
    scalar_token_2 = ScalarToken(10, 16, 17)
    scalar_token_3 = ScalarToken(10, 9, 10)
    assert scalar_token_2 == scalar_token_3

# Generated at 2022-06-26 10:55:25.763106
# Unit test for constructor of class DictToken
def test_DictToken():
    # Constructor test case 0
    try:
        test_case_0()
    except Exception as e:
        print("Constructor test case 0 failed.")
        print(e)
    # Constructor test case 1

    # Constructor test case 2

    # Constructor test case 3

    # Constructor test case 4



# Generated at 2022-06-26 10:55:52.011051
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:55:57.528621
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token()

    assert token == token
    assert token == Token()
    assert token != ScalarToken("value", 0, 0)
    assert token != ListToken([], 0, 0)
    assert token != object()


# Generated at 2022-06-26 10:55:59.079811
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:56:10.925694
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, DictToken)
    assert not hasattr(dict_token_0, 'arg_0')
    assert not hasattr(dict_token_0, 'arg_1')
    assert not hasattr(dict_token_0, 'arg_2')
    assert not hasattr(dict_token_0, 'arg_3')
    assert not hasattr(dict_token_0, 'arg_4')
    assert not hasattr(dict_token_0, 'arg_5')
    assert not hasattr(dict_token_0, 'arg_6')
    assert not hasattr(dict_token_0, 'arg_7')
    assert not hasattr(dict_token_0, 'arg_8')

# Generated at 2022-06-26 10:56:15.594030
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0._value == None
    assert dict_token_0._start_index == None
    assert dict_token_0._end_index == None
    assert dict_token_0._content == ""
    assert dict_token_0._child_keys == None
    assert dict_token_0._child_tokens == None


# Generated at 2022-06-26 10:56:21.759423
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert ScalarToken(100, 0, 0) == ScalarToken(100, 0, 0) 
    assert ScalarToken(100, 0, 0) != ScalarToken(200, 0, 0) 
    assert ScalarToken(100, 1, 0) == ScalarToken(100, 1, 0) 
    assert ScalarToken(100, 1, 0) != ScalarToken(100, 2, 0) 
    assert ScalarToken(100, 1, 1) == ScalarToken(100, 1, 1) 
    assert ScalarToken(100, 1, 1) != ScalarToken(100, 1, 2) 
    assert DictToken() == DictToken() 
    assert DictToken() != ListToken() 
    assert ListToken() == ListToken() 


# Generated at 2022-06-26 10:56:31.462968
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test for function 0
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    dict_token_2 = DictToken()
    dict_token_3 = DictToken()

    # Test for function 1
    dict_token_0 = DictToken()
    dict_token_1 = dict_token_0
    dict_token_2 = dict_token_0
    dict_token_3 = dict_token_0
    dict_token_0 == dict_token_0
    dict_token_0 == dict_token_1
    dict_token_0 == dict_token_2
    dict_token_0 == dict_token_3

    # Test for function 2
    dict_token_0 = DictToken()
    dict_token_1 = dict_token_0
    dict

# Generated at 2022-06-26 10:56:32.649802
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

# Generated at 2022-06-26 10:56:34.023821
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:56:35.482234
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:57:05.607832
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:57:06.967171
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:57:08.290126
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:57:20.406357
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken(
        {ScalarToken(5, 0, 0, "5"): ScalarToken(5, 0, 0, "5")},
        0,
        0,
        "",
    )
    dict_token_2 = DictToken(
        {ScalarToken(1, 1, 1, "1"): ScalarToken(2, 2, 2, "2")},
        1,
        2,
        "1",
    )
    dict_token_3 = DictToken(
        {ScalarToken(1, 1, 1, "1"): ScalarToken(3, 3, 3, "3")},
        1,
        3,
        "1",
    )
    dict_token_4 = D

# Generated at 2022-06-26 10:57:21.642168
# Unit test for constructor of class DictToken
def test_DictToken():
    unknown_result = DictToken()
    assert True


# Generated at 2022-06-26 10:57:22.525856
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 10:57:23.467528
# Unit test for constructor of class DictToken
def test_DictToken():
    assert test_DictToken


# Generated at 2022-06-26 10:57:24.737755
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken()


# Generated at 2022-06-26 10:57:26.569763
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert dict_token_0 == dict_token_1

# Generated at 2022-06-26 10:57:27.337478
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

# Generated at 2022-06-26 10:58:31.746514
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = Token()
    dict_token_1._get_value = test_case_0
    dict_token_1._start_index = -1
    dict_token_1._end_index = -1
    dict_token_1._content = ''
    dict_token_1._value = {'a': 1, 'b': 2}
    dict_token_0._value = {'a': 1, 'b': 2}
    assert dict_token_0 == dict_token_0
    assert not dict_token_1 == dict_token_0


# Generated at 2022-06-26 10:58:38.857684
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken(
        {
            ScalarToken(
                "", 0, 0, content = """{'a': 1, 'b': 2}"""
            ): ScalarToken(
                "", 0, 0, content = """{'a': 1, 'b': 2}"""
            )
        },
        0,
        1,
        content = """{'a': 1, 'b': 2}""",
    )

# Generated at 2022-06-26 10:58:40.339439
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:58:43.521011
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    assert dict_token_0 == dict_token_0
    assert dict_token_0 == dict_token_0


# Generated at 2022-06-26 10:58:45.881921
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    tk = Token(None, 0, 1)
    assert tk == tk
    assert tk != list(range(10))


# Generated at 2022-06-26 10:58:46.820872
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    return 


# Generated at 2022-06-26 10:58:51.659445
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    d = DictToken()
    assert d == DictToken()


# Generated at 2022-06-26 10:58:53.108610
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:58:55.265236
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()

test_DictToken()

# Generated at 2022-06-26 10:59:03.012955
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_0._start_index = 0
    dict_token_0._end_index = 0
    dict_token_0._value = {}
    dict_token_0._child_keys = {}
    dict_token_0._child_tokens = {}
    dict_token_1 = DictToken()
    dict_token_1._start_index = 0
    dict_token_1._end_index = 0
    dict_token_1._value = {}
    dict_token_1._child_keys = {}
    dict_token_1._child_tokens = {}
    assert dict_token_0 == dict_token_1


# Generated at 2022-06-26 11:01:18.775014
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

# Generated at 2022-06-26 11:01:21.640507
# Unit test for constructor of class DictToken
def test_DictToken():
    token_0 = DictToken()
    # The next line raises a TypeError.
    try:
        DictToken()
    except TypeError:
        pass


# Generated at 2022-06-26 11:01:23.277802
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 11:01:24.912707
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test with DictToken(args)
    args = ()
    assert DictToken(args)


# Generated at 2022-06-26 11:01:31.655299
# Unit test for constructor of class DictToken
def test_DictToken():
    # Class DictToken has no constructor
    # assertEqual(dict_token_0._start_index, 0)
    # assertEqual(dict_token_0._end_index, 0)
    # assertEqual(dict_token_0._value, None)

    dict_token_1 = DictToken()
    dict_token_2 = DictToken()
    dict_token_3 = DictToken()
    dict_token_4 = DictToken()
    dict_token_5 = DictToken()
    dict_token_6 = DictToken()

    # assertEqual(dict_token_1._start_index, dict_token_2._start_index)
    # assertEqual(dict_token_1._end_index, dict_token_2._end_index)
    # assertEqual(dict_

# Generated at 2022-06-26 11:01:34.739923
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(self, value, start_index, end_index, content)
    assert token is not None, 'Constructor failed, got: %s' % token




# Generated at 2022-06-26 11:01:38.460208
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:01:40.661689
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, DictToken)


# Generated at 2022-06-26 11:01:42.239429
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:01:45.378914
# Unit test for constructor of class DictToken
def test_DictToken():
    from collections import OrderedDict
    dict_token_0 = DictToken(OrderedDict(), 0, 0, "")
    dict_token_1 = DictToken({}, 0, 0, "")
