

# Generated at 2022-06-26 10:52:23.810502
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:52:32.101002
# Unit test for method __eq__ of class Token
def test_Token___eq__():

    # Test case 0
    dict_token_0 = DictToken({}, 0, 0)
    dict_token_1 = DictToken({}, 0, 0)
    assert dict_token_0 == dict_token_1

    # Test case 1
    dict_token_0 = DictToken({}, 0, 0)
    dict_token_1 = DictToken({}, 1, 1)
    assert not (dict_token_0 == dict_token_1)

    # Test case 2
    dict_token_0 = DictToken({}, 0, 0)
    dict_token_1 = DictToken({}, 0, 1)
    assert not (dict_token_0 == dict_token_1)

    # Test case 3
    dict_token_0 = DictToken({}, 0, 0)
    dict_token_1 = D

# Generated at 2022-06-26 10:52:40.368458
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    list_token_0 = ListToken()
    scalar_token_0 = ScalarToken(1)
    scalar_token_1 = ScalarToken(2)
    assert scalar_token_0 == scalar_token_0
    assert scalar_token_0 != scalar_token_1
    assert scalar_token_0 != dict_token_0
    assert scalar_token_0 != list_token_0
    #assert False  # TODO: implement your test here


# Generated at 2022-06-26 10:52:42.321576
# Unit test for constructor of class DictToken
def test_DictToken():
    for i in range(0, 6, 1):
        if i == 0:
            # Test case function call
            test_case_0()

# Generated at 2022-06-26 10:52:44.328019
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert dict_token_0 == dict_token_1


# Generated at 2022-06-26 10:52:48.302887
# Unit test for constructor of class DictToken
def test_DictToken():
    # Arrange
    dict_token_0 = DictToken()
    # Act
    # Assert
    assert dict_token_0 is not None


# Generated at 2022-06-26 10:52:50.767886
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert dict_token_0 == dict_token_1


# Generated at 2022-06-26 10:52:52.159815
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:52:55.850125
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_0 = Token()
    token_1 = Token()
    result_bool = token_0 == token_1
    assert result_bool == True


# Generated at 2022-06-26 10:53:00.830116
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Assignment statements
    dict_token_0 = DictToken()

    # Actual output
    actual_output = dict_token_0.__eq__(dict_token_0)

    # Expected output
    expected_output = True

    # Compare actual output with expected output
    assert expected_output == actual_output


# Generated at 2022-06-26 10:53:14.416774
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    dict_token_2 = DictToken()
    assert dict_token_0 == dict_token_1
    assert not (dict_token_0 != dict_token_1)
    assert not (dict_token_0 == dict_token_2)
    assert dict_token_0 != dict_token_2


# Generated at 2022-06-26 10:53:19.461396
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert dict_token_0.__eq__(dict_token_1) == False
    assert dict_token_1.__eq__(dict_token_0) == False

# Generated at 2022-06-26 10:53:22.005646
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = Token()
    assert not (dict_token_0 == dict_token_1)


# Generated at 2022-06-26 10:53:32.416125
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token.__eq__(Token(), Token())
    assert Token.__eq__(Token(1, 1, 1, ""), Token(1, 1, 1, ""))
    assert Token.__eq__(Token(1, 1, 1, ""), Token(1, 1, 1, ""))
    assert Token.__eq__(Token(1, 1, 1, ""), Token(1, 1, 1, ""))
    assert Token.__eq__(Token(1, 1, 1, ""), Token(1, 1, 1, ""))
    assert Token.__eq__(Token(1, 1, 1, ""), Token(1, 1, 1, ""))
    assert Token.__eq__(Token(1, 1, 1, ""), Token(1, 1, 1, ""))

# Generated at 2022-06-26 10:53:34.218828
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # No unit test available
    pass


# Generated at 2022-06-26 10:53:35.572765
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken({})


# Generated at 2022-06-26 10:53:38.483691
# Unit test for constructor of class DictToken
def test_DictToken():
    try:
        test_case_0()
    except:
        print("Constructor of class DictToken throws an exception")
# ------------------------------------------------------------------------------

# Generated at 2022-06-26 10:53:42.689721
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0 is not None, 'Failed to instantiate DictToken'


# Generated at 2022-06-26 10:53:55.954614
# Unit test for constructor of class DictToken
def test_DictToken():
    # DictToken(value: typing.Any, start_index: int, end_index: int, content: str = '')
    try:
        dict_token_0 = DictToken(None, None, None, None)
    except TypeError:
        pass
 
    try:
        dict_token_0 = DictToken(None, None, None, '')
    except TypeError:
        pass
 
    try:
        dict_token_0 = DictToken(None, None, None)
    except TypeError:
        pass
 
    try:
        dict_token_0 = DictToken(None, None, 0)
    except TypeError:
        pass
 
    try:
        dict_token_0 = DictToken(None, 0, None)
    except TypeError:
        pass
 

# Generated at 2022-06-26 10:53:59.798454
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert dict_token_0 == dict_token_1



# Generated at 2022-06-26 10:54:08.440899
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:11.680625
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_10 = ScalarToken(None, None, None)
    token_20 = ScalarToken(None, None, None)

    assert token_10 == token_20


# Generated at 2022-06-26 10:54:13.014367
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:24.785284
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    from typesystem.base import Token
    from typesystem.base import ScalarToken
    from typesystem.base import DictToken
    from typesystem.base import ListToken
    from sys import argv

    if (len(argv) != 2):
        raise ValueError('Provide exactly 1 arguments')
    option = int(argv[1])

    if (option == 0):
        token1 = ScalarToken(0, 0, 0)
        token2 = ScalarToken(0, 0, 0)

        assert token1.__eq__(token2) == True

    if (option == 1):
        token1 = ScalarToken(0, 0, 0)
        token2 = ScalarToken(1, 0, 0)

        assert token1.__eq__(token2) == False

    if (option == 2):
        token

# Generated at 2022-06-26 10:54:26.038456
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:34.668832
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    class Token_0(Token):
        def __init__(self, value: typing.Any, start_index: int, end_index: int, content: str = "") -> None:
            self._value = value
            self._start_index = start_index
            self._end_index = end_index
            self._content = content
    value = typing.Any
    start_index = int
    end_index = int
    content = str
    token = Token_0(value, start_index, end_index, content)
    other = Token_0(value, start_index, end_index, content)
    assert token.__eq__(other) == True

# Unit tests for method __hash__ of class Token

# Generated at 2022-06-26 10:54:35.368578
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    test_case_0()

# Generated at 2022-06-26 10:54:44.913712
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_0._start_index = 100
    dict_token_0._end_index = 100
    dict_token_0._content = 'content'
    dict_token_0._value = {'key': 'value'}
    dict_token_1 = dict_token_0
    dict_token_2 = Token('value', 100, 100, 'content')
    dict_token_3 = Token('value', 100, 100)
    dict_token_3._content = 'content'
    assert dict_token_0 == dict_token_1
    assert dict_token_0 != dict_token_2
    assert dict_token_0 != dict_token_3


# Generated at 2022-06-26 10:54:45.850530
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    test_case_0()


# Generated at 2022-06-26 10:54:47.384709
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:55:03.713739
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:55:06.646875
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:55:09.979149
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import Token

    # Test that instance of DictToken is created correctly
    # with constructor without arguments
    assert test_case_0()

    # Test that instance of class Token is created correctly
    assert test_case_0() == Token()



# Generated at 2022-06-26 10:55:10.811660
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()

# Generated at 2022-06-26 10:55:12.277103
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0 != None


# Generated at 2022-06-26 10:55:13.187379
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:55:14.007759
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

# Generated at 2022-06-26 10:55:16.225136
# Unit test for constructor of class DictToken
def test_DictToken():
    assert isinstance(DictToken(), DictToken)


# Generated at 2022-06-26 10:55:17.130592
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()

# Generated at 2022-06-26 10:55:18.480994
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:55:51.014995
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

    #
    # test get_value()
    #
    dict_value = dict_token_0.value
    assert dict_value == dict()

    #
    # test get_child_token() and get_key_token()
    #

    # construct a deeper structure for testing
    dict_token_1 = DictToken()
    list_token_0 = ListToken([dict_token_1])
    dict_token_0 = DictToken({"foo": list_token_0})

    # obtain the child token
    # should get a ListToken(...)
    child_token = dict_token_0.lookup(["foo"])
    # ListToken get_value() should return the correct list
    assert child_token.value == [dict_token_1]

    # obtain

# Generated at 2022-06-26 10:55:56.207342
# Unit test for constructor of class DictToken
def test_DictToken():
    print("\nTesting DictToken class")
    test_DictToken_0 = test_case_0()
    test_DictToken_0


# Generated at 2022-06-26 10:55:59.927718
# Unit test for constructor of class DictToken
def test_DictToken():
    # We create a DictToken instance
    dict_token_0 = DictToken()
    # We validate that dict_token_0 was properly initialized
    assert dict_token_0 is not None


# Generated at 2022-06-26 10:56:01.382731
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:56:02.933960
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, DictToken) == True


# Generated at 2022-06-26 10:56:08.979436
# Unit test for constructor of class DictToken
def test_DictToken():
    obj = DictToken(1, 2, 3, value='test')
    assert obj._get_value() == 'test'
    assert obj._start_index == 1
    assert obj._end_index == 2


# Generated at 2022-06-26 10:56:10.603696
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:56:13.500220
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_0._get_value()
    dict_token_0._get_child_token(None)
    dict_token_0._get_key_token(None)


# Generated at 2022-06-26 10:56:14.864362
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:56:16.159888
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:57:22.482924
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:57:23.425702
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 10:57:25.026255
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:57:25.896686
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 10:57:29.861473
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0._value == {}
    assert dict_token_0._start_index == 0
    assert dict_token_0._end_index == 0
    assert dict_token_0._content == ""


# Generated at 2022-06-26 10:57:31.493656
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

# Generated at 2022-06-26 10:57:40.700443
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    try:
        assert (
            isinstance(dict_token_0, DictToken)
            and isinstance(dict_token_0._child_keys, dict)
            and isinstance(dict_token_0._child_tokens, dict)
        )
    except AssertionError:
        print("AssertionError raised, DictToken is not constructed successfully")
    else:
        print("Pass test_DictToken")


# Generated at 2022-06-26 10:57:41.599915
# Unit test for constructor of class DictToken
def test_DictToken():
    print("Testing DictToken")
    test_case_0()

if __name__ == "__main__":
    test_DictToken()

# Generated at 2022-06-26 10:57:43.414288
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0 != None


# Generated at 2022-06-26 10:57:46.673349
# Unit test for constructor of class DictToken
def test_DictToken():
    print("Testing constructor of class DictToken")
    try:
        test_case_0()
    except Exception as ex:
        print(ex)
    else:
        print("PASS")


# Generated at 2022-06-26 10:58:25.703874
# Unit test for constructor of class DictToken
def test_DictToken():
    print("constructor of class DictToken")
    test_case_0()



# Generated at 2022-06-26 10:58:29.166193
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0._child_keys == {}
    assert dict_token_0._child_tokens == {}

# Generated at 2022-06-26 10:58:32.056975
# Unit test for constructor of class DictToken
def test_DictToken():
    try:
        test_case_0()
    except Exception as e:
        assert False, "Exception raised in constructor of class DictToken: {}".format(e.args)


# Generated at 2022-06-26 10:58:33.644833
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:58:34.759065
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:58:35.886880
# Unit test for constructor of class DictToken
def test_DictToken():
    rv = DictToken()



# Generated at 2022-06-26 10:58:39.199157
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-26 10:58:47.943746
# Unit test for constructor of class DictToken

# Generated at 2022-06-26 10:58:49.940640
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, DictToken)
    assert repr(dict_token_0) == "DictToken()"


# Generated at 2022-06-26 10:58:53.109947
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, DictToken)


# Generated at 2022-06-26 11:00:15.237726
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    dict_token_2 = DictToken({}, scalar_token_0, scalar_token_1)
    dict_token_3 = DictToken(dict_token_2, scalar_token_0, scalar_token_1)
    dict_token_4 = DictToken(dict_token_1, dict_token_2, dict_token_3)
    dict_token_5 = DictToken(dict_token_2, dict_token_3, dict_token_4)
    dict_token_6 = DictToken(dict_token_0, dict_token_1, dict_token_2, dict_token_3, dict_token_4, dict_token_5)


# Generated at 2022-06-26 11:00:16.454472
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 11:00:17.555180
# Unit test for constructor of class DictToken
def test_DictToken():
    assert test_case_0() == None


# Generated at 2022-06-26 11:00:19.885519
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, DictToken)



# Generated at 2022-06-26 11:00:22.175990
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0 is not None


# Generated at 2022-06-26 11:00:30.610105
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0 = DictToken(ScalarToken("token-0", 1, 5), ScalarToken("token-1", 1, 5))
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0

# Generated at 2022-06-26 11:00:34.501719
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert repr(DictToken()) == "DictToken()"
    assert isinstance(dict_token_0, DictToken)
    assert isinstance(dict_token_0, Token)
    assert not hasattr(dict_token_0, "__len__")


# Generated at 2022-06-26 11:00:35.930346
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_1 = DictToken()


# Generated at 2022-06-26 11:00:36.764560
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 11:00:38.119028
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0._value == {}
