

# Generated at 2022-06-26 10:52:41.563459
# Unit test for constructor of class DictToken
def test_DictToken():
    str_1 = None
    int_0 = -1156
    str_0 = None
    list_token_0 = ListToken(str_0, int_0, int_0)
    dict_token_1 = DictToken(str_1, int_0, int_0)


# Generated at 2022-06-26 10:52:42.442683
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()

# Generated at 2022-06-26 10:52:48.517472
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = "".join([chr(i) for i in range(256)])
    assert len(str_0) == 256
    for i in range(256):
        assert str_0[i] == chr(i)
    int_0 = -2147483647
    int_1 = 2147483647
    str_1 = ""
    str_2 = str_0
    str_3 = "".join([chr(i) for i in range(256)])
    assert len(str_3) == 256
    for i in range(256):
        assert str_3[i] == chr(i)
    dict_token_0 = DictToken(str_0, int_0, int_1, str_1)

# Generated at 2022-06-26 10:52:56.551672
# Unit test for constructor of class DictToken
def test_DictToken():
    num_0 = 1171
    num_1 = -81
    num_2 = 69
    # Element initializer list generation for ListToken
    tuple_0 = (num_0, num_1, num_2)
    list_token_0 = ListToken(tuple_0, num_0, num_1)
    # Element initializer list generation for ListToken
    tuple_1 = (num_0, num_1, num_2)
    list_token_1 = ListToken(tuple_1, num_0, num_1)
    # Element initializer list generation for DictToken
    tuple_2 = (list_token_0, list_token_1)
    dict_token_0 = DictToken(tuple_2, num_0, num_0)
    # Validate that method DictToken.__init

# Generated at 2022-06-26 10:53:06.725083
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = "-"
    int_0 = -1036
    list_token_0 = ListToken(str_0, int_0, int_0)
    str_1 = ")"
    int_1 = 746
    list_token_1 = ListToken(str_1, int_1, int_1)
    dict_token_0 = DictToken(list_token_0, int_1, int_1, "qljhqd")
    str_2 = "KjF-"
    int_2 = 0
    list_token_2 = ListToken(str_2, int_2, int_2)
    dict_token_1 = DictToken(list_token_2, int_2, int_2, "hrdyw")
    str_3 = "("

# Generated at 2022-06-26 10:53:08.304425
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = None
    int_0 = -1156
    list_token_0 = ListToken(str_0, int_0, int_0)
    

# Generated at 2022-06-26 10:53:18.291044
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = None
    int_0 = -1156
    dict_token_0 = DictToken(str_0, int_0, int_0)
    assert dict_token_0 is not None
    assert dict_token_0.end.column_no == 1
    assert dict_token_0.value is None
    assert dict_token_0.string == ""
    assert dict_token_0.start.column_no == 1
    assert dict_token_0.start.line_no == 1
    assert dict_token_0.end.line_no == 1


# Generated at 2022-06-26 10:53:22.097893
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = None
    int_0 = -1156
    list_token_0 = ListToken(str_0, int_0, int_0)
    dict_token_0 = DictToken(str_0, int_0, int_0)


# Generated at 2022-06-26 10:53:30.564576
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = None
    int_0 = -1156
    dict_token_0 = DictToken(
        str_0, int_0, int_0
    )  # Initializing a dict_token_0
    dict_token_0 = DictToken(
        str_0, int_0, int_0,
        content="None"
    )  # Initializing a dict_token_0
    dict_token_0 = DictToken(str_0, int_0, int_0, content="None")  # Initializing a dict_token_0



# Generated at 2022-06-26 10:53:36.051939
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = None
    str_1 = "HTBAZR[HMZP"
    dict_token_0 = DictToken(str_1, str_0, str_0)

    # Check instance
    assert isinstance(dict_token_0, DictToken) == True


# Generated at 2022-06-26 10:53:41.117042
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()

# Generated at 2022-06-26 10:53:43.602028
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = None
    dict_token_0 = DictToken(int_0, int_0, int_0)

# Generated at 2022-06-26 10:53:50.334553
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = None
    list_token_0 = ListToken(int_0, int_0, int_0)
    dict_token_0 = DictToken(list_token_0._value, int_0, int_0)
    assert dict_token_0._get_value() == 'e10y'


# Generated at 2022-06-26 10:53:55.917509
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = None
    dict_token_0 = DictToken(int_0, int_0, int_0)


# Generated at 2022-06-26 10:54:00.525286
# Unit test for constructor of class DictToken
def test_DictToken():
    list_token_0 = None
    scalar_token_0 = None
    int_0 = None
    dict_token_0 = DictToken(scalar_token_0, int_0, int_0)


# Generated at 2022-06-26 10:54:08.855962
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = None
    dict_token_0 = DictToken(int_0, int_0, int_0)
    dict_token_0._child_keys = int_0
    assert dict_token_0._child_keys == int_0
    dict_token_0._child_tokens = int_0
    assert dict_token_0.start == int_0
    dict_token_0._end_index = int_0
    assert dict_token_0._end_index == int_0
    dict_token_0._start_index = int_0
    assert dict_token_0._start_index == int_0
    dict_token_0._value = int_0
    assert dict_token_0._value == int_0


# Generated at 2022-06-26 10:54:11.641410
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = None
    dict_token_0 = DictToken(int_0, int_0, int_0)


# Generated at 2022-06-26 10:54:14.497284
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = None
    int_1 = None
    int_2 = None
    dict_token_token_0 = DictToken(int_0, int_1, int_2)

# Generated at 2022-06-26 10:54:20.539447
# Unit test for constructor of class DictToken
def test_DictToken():
    content = ""
    start_index = 0
    end_index = 0
    value = {}
    int_0 = None
    list_token_0 = ListToken(int_0, int_0, int_0)
    dict_token_0 = DictToken(value, start_index, end_index, content)

# test_case_0

# Generated at 2022-06-26 10:54:22.509342
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_1 = {}
    dict_token_0 = DictToken(dict_1, int_0, int_0)


# Generated at 2022-06-26 10:54:35.479917
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_0 = dict()
    dict_0['a'] = 'b'
    dict_0['c'] = 'd'
    dict_0['a'] = 'a'
    concept_dict = dict()

    var_0 = DictToken(concept_dict, 12, -5, "e' is required")
    var_1 = DictToken(concept_dict, 12, -5, "e' is required")
    var_2 = DictToken(concept_dict, 12, -5, "e' is required")
    assert var_0 == var_1
    assert var_0 == var_2
    assert var_1 == var_2

    var_0 = DictToken(dict_0, 0, -1, "e' is required")

# Generated at 2022-06-26 10:54:36.672253
# Unit test for constructor of class DictToken
def test_DictToken():
    a = DictToken(dict({}), 0, 6, "")


# Generated at 2022-06-26 10:54:40.498566
# Unit test for constructor of class DictToken
def test_DictToken():
    import json
    import jsonpath_rw
    input = """{
    "a": 1,
    "b": 2
}"""
    j = json.loads(input)
    expr = jsonpath_rw.parse("$.a")
    assert expr.find(j)[0].value == 1

# Generated at 2022-06-26 10:54:42.203050
# Unit test for constructor of class DictToken
def test_DictToken():
    var_0 = DictToken({"v": 1}, 0, 3, '{"v": 1}')


# Generated at 2022-06-26 10:54:53.041065
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test case 0
    # Not exists test case 0
    # Test case 1
    var_1 = None
    # Test case 2
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    # Test case 3
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    # Test case 4
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    # Test case 5
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
   

# Generated at 2022-06-26 10:54:54.868747
# Unit test for constructor of class DictToken
def test_DictToken():
    var_0 = None
    var_1 = DictToken(var_0, 0, 0)



# Generated at 2022-06-26 10:54:56.898721
# Unit test for constructor of class DictToken
def test_DictToken():
    var_0 = DictToken()
    assert isinstance(var_0, DictToken), "Expected an instance of type 'DictToken'"
    pass



# Generated at 2022-06-26 10:55:00.691306
# Unit test for constructor of class DictToken
def test_DictToken():
    var_0 = {
        int: 1,
    }
    var_0 = DictToken(
        var_0,
        0,
        1,
        content='',
    )


# Generated at 2022-06-26 10:55:04.934688
# Unit test for constructor of class DictToken
def test_DictToken():
    var_0 = 1
    var_1 = 1
    var_8 = DictToken({1: 1}, 1, 1)
    var_2 = 1
    var_3 = 1
    var_9 = DictToken({1: 1}, 1, 1)
    pass


# Generated at 2022-06-26 10:55:06.909923
# Unit test for constructor of class DictToken
def test_DictToken():
    var_0 = None
    try:
        var_0 = DictToken()
    except Exception:
        assert False


# Generated at 2022-06-26 10:55:15.318865
# Unit test for constructor of class DictToken

# Generated at 2022-06-26 10:55:26.080191
# Unit test for constructor of class DictToken
def test_DictToken():
    assert (DictToken(None, None, None)._child_tokens == {}), "attribute _child_tokens should be: {}"
    assert (DictToken(None, None, None)._child_keys == {}), "attribute _child_keys should be: {}"
    assert (DictToken(None, None, None)._value == None), "attribute _value should be: None"
    assert (DictToken(None, None, None)._start_index == None), "attribute _start_index should be: None"
    assert (DictToken(None, None, None)._end_index == None), "attribute _end_index should be: None"
    assert (DictToken(None, None, None)._content == ""), "attribute _content should be: None"

# Generated at 2022-06-26 10:55:36.877765
# Unit test for constructor of class DictToken
def test_DictToken():
    var_0 = {'a': 1234}
    var_1 = {'a': 1234}
    var_1['a']
    var_2 = {'b': 5678}
    var_1['b']
    var_3 = {'c': 1234}
    var_2['c']
    var_4 = {'d': 5678}
    var_3['d']
    var_5 = {'e': 1234}
    var_4['e']
    var_6 = {'f': 5678}
    var_5['f']
    var_7 = {'g': 1234}
    var_6['g']
    var_8 = {'h': 5678}
    var_7['h']
    var_9 = {'i': 1234}

# Generated at 2022-06-26 10:55:39.350400
# Unit test for constructor of class DictToken
def test_DictToken():
    var_0 = DictToken(DictToken)


# Generated at 2022-06-26 10:55:42.150738
# Unit test for constructor of class DictToken
def test_DictToken():
    expected = DictToken
    actual = DictToken(1, 2, 3, )
    assert type(actual) == expected


# Generated at 2022-06-26 10:55:50.781807
# Unit test for constructor of class DictToken
def test_DictToken():
	var_0 = None
	var_1 = None
	var_2 = None
	var_3 = None
	var_4 = None
	var_5 = None
	var_6 = None
	var_7 = None
	var_8 = None
	var_9 = None
	var_10 = None
	var_11 = None
	var_12 = None
	var_13 = None
	var_14 = None
	var_15 = None
	var_16 = None
	var_17 = None
	var_18 = None
	var_19 = None
	var_20 = None
	var_21 = None
	var_22 = None
	var_23 = None
	var_24 = None
	var_25 = None
	var_26 = None
	var_27 = None
	var_

# Generated at 2022-06-26 10:55:52.251781
# Unit test for constructor of class DictToken
def test_DictToken():
    var_0 = None


# Generated at 2022-06-26 10:55:55.108522
# Unit test for constructor of class DictToken
def test_DictToken():
    var_0 = DictToken( var_0  )


# Generated at 2022-06-26 10:55:57.073999
# Unit test for constructor of class DictToken
def test_DictToken():
    var_0 = DictToken(None, None, None, None)


# Generated at 2022-06-26 10:56:02.598828
# Unit test for constructor of class DictToken
def test_DictToken():
    # create a dict for testing
    var_1 = {}

    # test for constructor of class DictToken
    var_0 = DictToken(var_1, 0, 0, "a")
    assert var_0._value == {}
    assert var_0._start_index == 0
    assert var_0._end_index == 0
    assert var_0._content == "a"


# Generated at 2022-06-26 10:56:36.530696
# Unit test for constructor of class DictToken
def test_DictToken():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    DictToken(var_0, var_1, var_2, var_3, var_4, var_5, var_6, var_7, var_8, var_9, var_10, var_11, var_12)


# Generated at 2022-06-26 10:56:45.699690
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    var_1 = ScalarToken(var_0, var_0, var_0)
    print(var_1.string)
    print(var_1.value)
    print(var_1.start)
    print(var_1.end)
    print(var_1.lookup(var_0))
    print(var_1.lookup_key(var_0))
    print(var_1._get_position(var_0))
    print(var_1)


# Generated at 2022-06-26 10:56:47.111467
# Unit test for constructor of class Token
def test_Token():
    var_0 = None
    assert var_0 == None

# Generated at 2022-06-26 10:56:50.643331
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token = StringToken("", 15, 20)
    index = [5, 7]
    assert token.lookup_key(index) == token, "returns correct value"


# Generated at 2022-06-26 10:56:54.993273
# Unit test for method lookup of class Token
def test_Token_lookup():
    import typesystem
    var_0 = typesystem.parse("{'a': 1, 'b': 2, 'c': 3}")
    var_1 = var_0.lookup([0])
    var_2 = var_0.lookup([1])
    var_3 = var_0.lookup([2])


# Generated at 2022-06-26 10:57:05.226405
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    var_0 = None
    try:
        var_1 = Token(var_0, var_0, var_0)
        var_2 = var_1
        var_3 = var_2.__repr__()
        assert var_3 == "Token(None)"
    except Exception as var_4:
        print(var_4)
    try:
        var_5 = None
        var_6 = Token(var_0, var_5, var_5)
        var_7 = var_6
        var_8 = var_7.__repr__()
        assert var_8 == "Token(None)"
    except Exception as var_9:
        print(var_9)

# Generated at 2022-06-26 10:57:07.134943
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    assert ScalarToken(var_0, var_0, var_0) is not None


# Generated at 2022-06-26 10:57:10.207282
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    var_1 = ScalarToken(value=None, start_index=0, end_index=0, content='')
    var_2 = None


# Generated at 2022-06-26 10:57:12.225005
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    assert Token(var_0, var_0, var_0) == Token(var_0, var_0, var_0)


# Generated at 2022-06-26 10:57:16.885736
# Unit test for method lookup of class Token
def test_Token_lookup():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    print('Start test of method lookup of class Token')
    test_case_0()
    print('End test of method lookup of class Token')


# Generated at 2022-06-26 10:57:50.980821
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    var_0 = None
    var_0 = Token(None, 1, 1, "")
    assert var_0.__repr__() == 'Token(None)'


# Generated at 2022-06-26 10:57:53.031419
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    # init class
    obj = test_case_0()

    # call method
    result = obj.lookup_key(["start", "start", "start", "start", "start"])
    assert result == None

# Generated at 2022-06-26 10:57:55.075356
# Unit test for constructor of class Token
def test_Token():
    try:
        test_case_0()
    except NotImplementedError:
        assert True == True
    except BaseException:
        assert False == True


# Generated at 2022-06-26 10:58:00.317962
# Unit test for constructor of class ListToken
def test_ListToken():
    try:
        test_case_0()
    except Exception as ex:
        print(ex)
        assert False

    print("Passed.")
    return 0

if (__name__ == '__main__'):
    sys.exit(test_ListToken())

# Generated at 2022-06-26 10:58:02.872131
# Unit test for method lookup of class Token
def test_Token_lookup():
    (var_0, var_1, var_2, var_3, var_4, var_5, var_6) = (None, None, None, None, None, None, None)


# Generated at 2022-06-26 10:58:05.376966
# Unit test for constructor of class Token
def test_Token():

    # Assert that instance created properly
    assert test_case_0 is not None


# Generated at 2022-06-26 10:58:06.244549
# Unit test for constructor of class DictToken
def test_DictToken():
    # test constructor
    var_0 = DictToken()

# Generated at 2022-06-26 10:58:07.435148
# Unit test for constructor of class ListToken
def test_ListToken():
    var_1 = ListToken(var_0, 2, 3, 'a')


# Generated at 2022-06-26 10:58:13.577326
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    var_0 = ScalarToken(1, 0, 0)
    var_1 = ListToken([var_0], 0, 3)
    expected_var_1 = var_0
    actual_var_1 = var_1.lookup_key([0])
    assert expected_var_1 == actual_var_1
    var_2 = None
    expected_var_2 = var_2
    actual_var_2 = var_1.lookup_key([1])
    assert expected_var_2 == actual_var_2


# Generated at 2022-06-26 10:58:18.317372
# Unit test for method lookup of class Token
def test_Token_lookup():
    var_0 = DictToken((), None, None, None, (), ()) # TOKEN: DictToken
    var_1 = var_0.lookup(()) # TOKEN: DictToken
    var_2 = var_1.lookup(()) # TOKEN: DictToken
    var_3 = var_2.lookup((1,)) # TOKEN: ScalarToken
    return


# Generated at 2022-06-26 10:58:50.737257
# Unit test for method __repr__ of class Token
def test_Token___repr__():
    dict_token_0 = DictToken()
    assert repr(dict_token_0) == 'DictToken({})'

# Generated at 2022-06-26 10:59:00.317282
# Unit test for method lookup of class Token
def test_Token_lookup():
    dict_token_0 = DictToken()
    token_0 = Token(2, 1, 2)
    token_1 = Token(4, 4, 4)
    token_2 = Token(3, 0, 1)
    token_3 = DictToken({"a": token_1}, 1, 2)
    token_4 = ListToken([token_2, token_3], 3, 4)
    dict_token_0._value = {token_0: token_4}
    token_5 = dict_token_0.lookup([2])
    assert token_5._start_index == 0
    assert token_5._end_index == 1
    assert token_5._content == ""


# Generated at 2022-06-26 10:59:01.647022
# Unit test for constructor of class Token
def test_Token():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:59:14.883410
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    token_0 = Token()

# Generated at 2022-06-26 10:59:16.530902
# Unit test for constructor of class Token
def test_Token():
    assert repr(test_case_0()) == "DictToken([])"


# Generated at 2022-06-26 10:59:27.501604
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Create an instance of the class under test (the SystemUnderTest, or SUT)
    token_0 = Token()

    # Create an instance of a dummy object, to use to invoke __eq__ in the
    # System Under Test (token_0). The dummy object must implement the __eq__
    # method, to avoid getting NotImplementedError.
    dummy = object()
    dummy.__eq__ = lambda _: False

    # Invoke the __eq__ method in the SystemUnderTest, with the dummy object
    # as the argument. Capture the value returned by __eq__
    result = token_0.__eq__(dummy)

    # Assert the result
    assert result is False


# Generated at 2022-06-26 10:59:30.110550
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert (dict_token_0 == dict_token_1) # AssertionError


# Generated at 2022-06-26 10:59:40.466009
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_0 = Token()  # Exception: AssertionError:
    token_1 = Token()  # Exception: AssertionError:
    assert token_0 .__eq__(token_1) == 0
    token_0 = Token()
    token_1 = DictToken()
    assert token_0 .__eq__(token_1) == 0
    token_0 = ScalarToken()
    token_1 = ScalarToken()
    assert token_0 .__eq__(token_1) == 0
    token_0 = ScalarToken()
    token_1 = ScalarToken()
    assert token_0 .__eq__(token_1) == 0


# Generated at 2022-06-26 10:59:45.169867
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test iterators.
    token_0 = ScalarToken()
    token_1 = ScalarToken()
    token_2 = ScalarToken()
    assert token_0 == token_1
    assert token_0 != token_2
    assert token_0 != 0
    token_0 = DictToken()
    token_1 = DictToken()
    token_2 = DictToken()
    assert token_0 == token_1
    assert token_0 != token_2
    token_0 = ListToken()
    token_1 = ListToken()
    token_2 = ListToken()
    assert token_0 == token_1
    assert token_0 != token_2


# Generated at 2022-06-26 10:59:45.944031
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:01:38.668376
# Unit test for constructor of class Token
def test_Token():
    assert Token({'a': 1}, 12, 17)

# Generated at 2022-06-26 11:01:39.767853
# Unit test for constructor of class Token
def test_Token():
    test_case_0()

# Generated at 2022-06-26 11:01:41.032679
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken(dict_token_0)



# Generated at 2022-06-26 11:01:42.551395
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    dict_token_0 = ScalarToken(None, None, None)


# Generated at 2022-06-26 11:01:45.053172
# Unit test for method lookup of class Token
def test_Token_lookup():
    dict_token_0 = DictToken()
    dict_token_1 = dict_token_0.lookup(list("(1,)"))



# Generated at 2022-06-26 11:01:46.778210
# Unit test for constructor of class ListToken
def test_ListToken():
    print("========test ListToken's constructor======")
    a = ListToken()
    print(a)


# Generated at 2022-06-26 11:01:47.690451
# Unit test for method lookup of class Token
def test_Token_lookup():
    test_case_0()


# Generated at 2022-06-26 11:01:52.834186
# Unit test for constructor of class ListToken
def test_ListToken():
    token_0 = ListToken()
    assert len(token_0) == 0
    token_1 = ListToken()
    assert len(token_1) == 0

# Generated at 2022-06-26 11:02:03.186852
# Unit test for constructor of class Token
def test_Token():
    dict_token_0 = DictToken()
    scalar_token_0 = ScalarToken(value="ABC")
    scalar_token_1 = ScalarToken()
    scalar_token_2 = ScalarToken(value=4)
    scalar_token_3 = ScalarToken(value=True)
    scalar_token_4 = ScalarToken(value=1)
    scalar_token_2.value = scalar_token_3.value
    scalar_token_1.value = scalar_token_2.value
    scalar_token_3.value = scalar_token_4.value
    scalar_token_0.value = scalar_token_1.value
    list_token_0 = ListToken()
    scalar_token_5 = ScalarToken()
    scalar_token_

# Generated at 2022-06-26 11:02:14.644579
# Unit test for constructor of class Token
def test_Token():
    dict_token_0 = DictToken()
    assert dict_token_0 is not None
    assert dict_token_0.start is not None
    assert dict_token_0.end is not None
    assert dict_token_0.string is not None
    assert dict_token_0._get_value() is not None
    assert dict_token_0._get_child_token(None) is not None
    assert dict_token_0._get_key_token(None) is not None
    assert dict_token_0.lookup(None) is not None
    assert dict_token_0.lookup_key(None) is not None
    dict_token_1 = DictToken()
    assert isinstance(dict_token_1, Token)
    assert dict_token_1 is not None