

# Generated at 2022-06-26 10:52:24.606235
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    str_0 = 'e?_$xwrq-\t'
    str_1 = '!HT@2'
    int_0 = 9
    list_0 = [int_0, int_0, int_0]
    token_0 = ListToken(**{'value': list_0, 'start_index': int_0, 'end_index': int_0})
    bool_0 = token_0.__eq__(token_0)
    assert not bool_0


# Generated at 2022-06-26 10:52:29.696381
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    str_0 = 'Xm/FbE.q'
    dict_0 = {str_0: str_0}
    dict_token_0 = DictToken(**dict_0)
    dict_0 = {str_0: str_0}
    dict_token_1 = DictToken(**dict_0)
    assert dict_token_0 == dict_token_1


# Generated at 2022-06-26 10:52:34.542438
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = 'Yy.fDx#'
    dict_0 = {str_0: str_0}
    dict_token_0 = DictToken(**dict_0)


# Generated at 2022-06-26 10:52:41.215615
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Create objects for test
    dict_0 = {'Xm/FbE.q': 'Xm/FbE.q'}
    dict_token_0 = DictToken(**dict_0)
    dict_token_1 = DictToken(**dict_0)
    dict_token_2 = dict_token_1
    assert dict_token_0 == dict_token_1
    assert dict_token_1 == dict_token_2


# Generated at 2022-06-26 10:52:44.816113
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    str_0 = 'Zp{*nH'
    dict_0 = {str_0: str_0}
    dict_token_0 = DictToken(**dict_0)
    dict_token_0 == dict_token_0
    dict_token_0 == dict_0
    dict_token_0 != dict_0


# Generated at 2022-06-26 10:52:51.731345
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    str_0 = 'Fn/aP,H'
    str_1 = '|(,M+$'
    str_2 = 'W@R+'
    list_0 = [str_0, str_1, str_2]
    list_token_0 = ListToken(**list_0)
    list_token_1 = ListToken(**list_0)
    assert list_token_0 == list_token_1


# Generated at 2022-06-26 10:52:58.313851
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    str_0 = 'JY'
    dict_0 = {str_0: []}
    dict_token_0 = DictToken(**dict_0)
    dict_0 = {str_0: []}
    dict_token_1 = DictToken(**dict_0)
    dict_0 = {str_0: []}
    dict_token_2 = DictToken(**dict_0)
    dict_token_1 = DictToken(**dict_0)
    dict_token_2 = DictToken(**dict_0)
    dict_token_1 = DictToken(**dict_0)
    dict_token_2 = DictToken(**dict_0)
    dict_token_1 = DictToken(**dict_0)

# Generated at 2022-06-26 10:52:59.269448
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    test_case_0()


# Generated at 2022-06-26 10:53:00.370805
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()

# Generated at 2022-06-26 10:53:09.313770
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    str_0 = 'a'
    str_1 = 'b'
    str_2 = 'c'
    str_3 = 'd'
    str_4 = 'e'
    str_5 = 'f'
    str_6 = 'g'
    str_7 = 'h'
    str_8 = 'i'
    str_9 = 'j'
    str_10 = 'k'
    str_11 = 'l'
    str_12 = 'm'
    str_13 = 'n'
    str_14 = 'o'
    str_15 = 'p'
    str_16 = 'q'
    str_17 = 'r'
    str_18 = 's'
    str_19 = 't'
    str_20 = 'u'
    str_21 = 'v'
   

# Generated at 2022-06-26 10:53:23.598413
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    key_token_0 = dict_token_0._get_child_token(0)
    key_token_1 = dict_token_0._get_child_token(1)
    key_token_2 = dict_token_0._get_child_token(2)
    key_token_3 = dict_token_0._get_child_token(3)
    key_token_4 = dict_token_0._get_child_token(4)
    key_token_5 = dict_token_0._get_child_token(5)
    key_token_6 = dict_token_0._get_child_token(6)
    key_token_7 = dict_token_0._get_child_token(7)
    key_token_8 = dict_token_

# Generated at 2022-06-26 10:53:26.915594
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_0.__eq__(dict_token_0)


# Generated at 2022-06-26 10:53:30.714150
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    try:
        assert ScalarToken(1, 2, 3) == ScalarToken(1, 2, 3)
    except AssertionError:
        raise AssertionError("Unexpected AssertionError while testing method __eq__ of class Token")



# Generated at 2022-06-26 10:53:33.073196
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()


# Generated at 2022-06-26 10:53:34.406897
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    assert dict_token_0 == dict_token_0


# Generated at 2022-06-26 10:53:36.526839
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test with empty items:
    dict_token_0 = DictToken()
    print('Test succeeded.')
    return dict_token_0


# Generated at 2022-06-26 10:53:40.112798
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert dict_token_0.__eq__(dict_token_1)


# Generated at 2022-06-26 10:53:42.122085
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:53:45.015171
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_0.__eq__(dict_token_0)


# Generated at 2022-06-26 10:53:47.236774
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    _0 = Token()
    _1 = Token()

    assert _0 == _0
    assert _0 != _1


# Generated at 2022-06-26 10:54:00.385840
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_0._start_index = 0
    dict_token_0._end_index = 100
    dict_token_1 = DictToken()
    dict_token_1._start_index = 100
    dict_token_1._end_index = 0
    assert not (dict_token_0 == dict_token_1)


# Generated at 2022-06-26 10:54:01.723521
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:04.416945
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    bool_0 = Token.__eq__(dict_token_0, dict_token_0)
    assert bool_0
    assert bool_0 is True


# Generated at 2022-06-26 10:54:08.881717
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert dict_token_0 == dict_token_1


# Generated at 2022-06-26 10:54:20.921303
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert dict_token_0 == dict_token_1
    scalar_token_0 = ScalarToken()
    scalar_token_1 = ScalarToken()
    assert scalar_token_0 == scalar_token_1
    assert scalar_token_0 != dict_token_0
    assert scalar_token_1 != dict_token_1
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert dict_token_0 == dict_token_1
    scalar_token_0 = ScalarToken()
    scalar_token_1 = ScalarToken()
    assert scalar_token_0 == scalar_token_1

# Generated at 2022-06-26 10:54:22.173287
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:25.891720
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    int_0 = dict_token_0.__eq__(dict_token_1)
    assert int_0 == 0



# Generated at 2022-06-26 10:54:35.410202
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dictionary_0 = {}
    dictionary_0["0"] = 0
    dictionary_0["0"] = 0
    dictionary_0["0"] = 0
    dictionary_0["0"] = 0
    dictionary_0["0"] = 0
    dictionary_0["0"] = 0
    dictionary_0["0"] = 0
    dictionary_0["0"] = 0
    dictionary_0["0"] = 0

    # Test that the method __eq__ of Token returns true when the two tokens compared are equal
    assert (dict_token_0.__eq__(dict_token_0))
    # Test that the method __eq__ of Token returns false when the two tokens compared are not equal
    assert (not dict_token_0.__eq__(dict_token_1))

    # Test that the method __eq__ of Token returns true when the two tokens compared

# Generated at 2022-06-26 10:54:38.722611
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token()
    assert token.__eq__(None) == False, "expected False"
    assert token.__eq__(None) == False, "expected False"
    assert token.__eq__(None) == False, "expected False"


# Generated at 2022-06-26 10:54:42.989315
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test case 1
    token_0 = Token(value=test_case_0(), start_index=0, end_index=0)
    token_1 = Token(value=test_case_0(), start_index=0, end_index=0)
    assert token_0 == token_1


# Generated at 2022-06-26 10:54:53.877259
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    str_token_1 = ScalarToken("hello")
    str_token_2 = ScalarToken("hello")
    str_token_3 = ScalarToken("world")
    assert not str_token_1 == str_token_3
    assert str_token_1 == str_token_2


# Generated at 2022-06-26 10:54:59.231752
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    testcase = Token
    token1 = Token(1, 0, 0, content="")
    token2 = Token(1, 0, 0, content="")

    # testcase __eq__ follows PEP 484 type hints
    # https://www.python.org/dev/peps/pep-0484/
    assert token1 == token2


# Generated at 2022-06-26 10:55:01.102247
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    t2 = Token()
    t1 = Token()
    assert t2 == t1


# Generated at 2022-06-26 10:55:03.936846
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    str_0 = str()
    assert Token.__eq__(dict_token_0, str_0)


# Generated at 2022-06-26 10:55:05.108139
# Unit test for constructor of class DictToken
def test_DictToken():
    pass


# Generated at 2022-06-26 10:55:06.011523
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    pass


# Generated at 2022-06-26 10:55:14.126977
# Unit test for constructor of class DictToken
def test_DictToken():
    char_0 = 'a'
    char_1 = '1'
    integer_0 = 0
    integer_1 = 1
    float_0 = 2.0
    float_1 = 3.0
    float_2 = 4.0
    boolean_0 = True
    boolean_1 = True
    string_0 = "abcdefghijklmnopqrstuvwxyz"
    string_1 = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"

# Generated at 2022-06-26 10:55:16.298987
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:55:26.278800
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0._child_keys == {}
    assert dict_token_0._child_tokens == {}
    # Test for constructor failure.
    try:
        dict_token_1 = DictToken(None, 1, 2, content="content", glue=None)
    except TypeError:
        pass
    # Test for constructor failure.
    try:
        dict_token_2 = DictToken(None, 1, 2, glue=None)
    except TypeError:
        pass
    # Test for constructor failure.
    try:
        dict_token_3 = DictToken(None, content="content", glue=None)
    except TypeError:
        pass
    # Test for constructor failure.

# Generated at 2022-06-26 10:55:30.650591
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    assert dict_token_0 is not None
    assert dict_token_0 == dict_token_0


# Generated at 2022-06-26 10:55:43.323571
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_0 = ScalarToken("a", 1, 2)
    token_1 = ScalarToken('"a"', 10, 11)
    token_0_copy = ScalarToken("a", 1, 2)
    assert token_0.__eq__(token_1) == False
    assert token_0.__eq__(token_0_copy) == True


# Generated at 2022-06-26 10:55:48.383487
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = ScalarToken()
    dict_token_2 = dict_token_0
    dict_token_3 = dict_token_0
    dict_token_2.__eq__(dict_token_3)
    dict_token_0.__eq__(dict_token_1)
    dict_token_0.__eq__(dict_token_0)


# Generated at 2022-06-26 10:55:50.817329
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    #
    # Verify that the == operator works on the Token class
    #
    assert dict_token_0 == dict_token_1


# Generated at 2022-06-26 10:55:58.087011
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = ScalarToken()
    dict_token_0.string
    dict_token_0.value
    dict_token_0.start
    dict_token_0.end
    dict_token_0.lookup([0])
    dict_token_0.lookup_key([0])


# Generated at 2022-06-26 10:56:02.106670
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    expected_result_0 = True
    actual_result_0 = dict_token_0.__eq__(dict_token_0)

    assert expected_result_0 is actual_result_0


# Generated at 2022-06-26 10:56:02.900389
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken() is not None


# Generated at 2022-06-26 10:56:13.958810
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    __expected__ = {
        "value": "",
        "start_index": 0,
        "end_index": 0,
        "content": "",
        "args": (
            "",
            0,
            0,
        ),
        "kwargs": {},
    }
    __test__ = {
        "args": (
            "",
            0,
            0,
        ),
        "kwargs": {},
    }
    __result__ = None
    if __test__ == __expected__:
        __result__ = "pass"
    else:
        __result__ = "fail"
    assert __result__ == "pass", "Test failure at line {0}".format(
        inspect.getframeinfo(inspect.currentframe()).lineno
    )



# Generated at 2022-06-26 10:56:16.456535
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = ScalarToken(42, 5, 10, 'The value is: 42')
    other = ScalarToken(42, 5, 10, 'The value is: 42')
    assert token == other


# Generated at 2022-06-26 10:56:17.749990
# Unit test for constructor of class DictToken
def test_DictToken():
    assert True == True


# Generated at 2022-06-26 10:56:20.759741
# Unit test for constructor of class DictToken
def test_DictToken():
    # Construct a DictToken with one of attr = None
    dict_token_1 = DictToken(None)


# Generated at 2022-06-26 10:56:34.288420
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = Token({'a': 'b'}, 0, 1)
    assert isinstance(dict_token_0, Token)
    assert isinstance(dict_token_0, DictToken)
    assert not hasattr(dict_token_0, '_get_child_token')


# Generated at 2022-06-26 10:56:37.117001
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken()
    assert token.start == Position(1,1,0)
    assert token.end == Position(1,1,0)


# Generated at 2022-06-26 10:56:41.513362
# Unit test for constructor of class DictToken
def test_DictToken():
    print("Testing DictToken constructor")
    test_case_0()
    print("DictToken constructor test passed")
    print("------")


# Generated at 2022-06-26 10:56:43.857542
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, DictToken)



# Generated at 2022-06-26 10:56:45.783929
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:56:56.421846
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken(
        {1: 1}, start_index=0, end_index=0, content=None
    )
    dict_token_2 = DictToken(None, start_index=0, end_index=0)

# Generated at 2022-06-26 10:57:00.558254
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:57:03.546078
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, DictToken)



# Generated at 2022-06-26 10:57:06.026527
# Unit test for constructor of class DictToken
def test_DictToken():
    token_0 = DictToken(None, 0, 3, "test")


# Generated at 2022-06-26 10:57:17.175349
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken(None)
    dict_token_2 = DictToken("", True, 0)
    dict_token_3 = DictToken("test_value", True, 0)
    dict_token_4 = DictToken("test_value", True, 0)
    dict_token_5 = DictToken("test_value", True, 0, "test_content")
    dict_token_6 = DictToken("test_value", True, 0, "test_content")
    dict_token_7 = DictToken("test_value", True, 0, "test_content")
    dict_token_8 = DictToken("test_value", True, 0, "test_content")

# Generated at 2022-06-26 10:57:29.773899
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:57:43.085047
# Unit test for constructor of class DictToken
def test_DictToken():
    # case 0:
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, DictToken)
    assert isinstance(dict_token_0, Token)
    assert dict_token_0._value is undefined
    assert dict_token_0._start_index is undefined
    assert dict_token_0._end_index is undefined
    assert dict_token_0._content is undefined
    assert dict_token_0._child_keys is undefined
    assert dict_token_0._child_tokens is undefined
    # case 1:
    dict_token_1 = DictToken(value, start_index, end_index, content)
    assert isinstance(dict_token_1, DictToken)
    assert isinstance(dict_token_1, Token)
    assert dict_token_1._value

# Generated at 2022-06-26 10:57:44.357589
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_1 = DictToken()


# Generated at 2022-06-26 10:57:48.775468
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0.value == {}
    assert dict_token_0.start == Position(1, 1, 0)
    assert dict_token_0.end == Position(1, 1, 0)


# Generated at 2022-06-26 10:57:49.497168
# Unit test for constructor of class DictToken
def test_DictToken():
    # to ensure that the test runner is doing something...
    assert True


# Generated at 2022-06-26 10:57:50.274023
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:57:50.981521
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

# Generated at 2022-06-26 10:57:56.465494
# Unit test for constructor of class DictToken
def test_DictToken():

    # Test where index is an int
    dict_token_0 = DictToken(0, '', '', 'abc')

    assert dict_token_0.value == None

    # Test where index is a str
    dict_token_1 = DictToken('', 0, '', 'abc')

    assert dict_token_1.value == None

    # Test where index is none
    dict_token_2 = DictToken(None, 0, '', 'abc')

    assert dict_token_2.value == None



# Generated at 2022-06-26 10:57:59.401403
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:58:00.674189
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:58:42.841235
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:58:45.846788
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    """
    Ensure lookup_key can find keys in a nested dict.
    """
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:58:54.068971
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    dict_token_0 = DictToken()
    scalar_hash = ScalarToken.__hash__(dict_token_0)
    scalar_hash_expected = hash(None)
    assert scalar_hash == scalar_hash_expected, "Expected: %s, Actual: %s" % (scalar_hash_expected, scalar_hash)


# Generated at 2022-06-26 10:59:03.130729
# Unit test for method lookup of class Token
def test_Token_lookup():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    dict_token_2 = DictToken()
    dict_token_3 = DictToken()
    dict_token_4 = DictToken()
    dict_token_5 = DictToken()
    dict_token_6 = DictToken()
    dict_token_7 = DictToken()
    dict_token_8 = DictToken()
    dict_token_9 = DictToken()

    assert dict_token_0.lookup([]) == dict_token_0


# Generated at 2022-06-26 10:59:04.287892
# Unit test for method lookup of class Token
def test_Token_lookup():
    assert True == True


# Generated at 2022-06-26 10:59:16.699420
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    dict_ScalarToken___hash__ = {
        "0": {
            "in": {
            },
            "out": 0,
        },
    }
    dict_ScalarToken___hash___0 = dict(dict_ScalarToken___hash__)
    for func_key, func_val in dict_ScalarToken___hash___0.items():
        if isinstance(func_val, dict):
            dict_in = func_val["in"]
            expected_out = func_val["out"]
            class_ScalarToken = ScalarToken

# Generated at 2022-06-26 10:59:18.480105
# Unit test for constructor of class ListToken
def test_ListToken():
    # Test the constructor of class ListToken
    list_token_0 = ListToken()


# Generated at 2022-06-26 10:59:19.645292
# Unit test for constructor of class Token
def test_Token():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:59:29.812952
# Unit test for method lookup_key of class Token
def test_Token_lookup_key():
    dict_token_0 = DictToken()
    list_token_0 = ListToken(dict_token_0, 0, 0)
    dict_token_0.lookup_key([])
    position_0 = Position(1, 1, 1)
    position_1 = Position(1, 2, 2)
    dict_token_0.lookup_key([position_0, position_1])
    dict_token_0.lookup_key([position_0])
    position_0 = Position(1, 1, 1)
    position_1 = Position(1, 2, 2)
    dict_token_0.lookup_key([position_0, position_1, position_1])
    position_0 = Position(1, 1, 1)
    position_1 = Position(1, 2, 2)

# Generated at 2022-06-26 10:59:31.012999
# Unit test for constructor of class DictToken
def test_DictToken():
    print("test_DictToken")
    test_case_0()


# Generated at 2022-06-26 11:00:47.863970
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:00:50.058980
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0._get_value() == {}


# Generated at 2022-06-26 11:00:55.275260
# Unit test for constructor of class ScalarToken
def test_ScalarToken():
    # Test type of input parameters (if constructor is used correctly)
    # Test if members are initialized correctly (if constructor is used correctly)
    pass


# Generated at 2022-06-26 11:01:02.338660
# Unit test for method lookup of class Token
def test_Token_lookup():

    # Given
    dict_token_0 = DictToken()
    index = [0]

    # When
    result_token = dict_token_0.lookup(index)
    # Then
    assert type(result_token) == DictToken
    assert result_token._value == {'shape': {'type': 'number'}, 'size': {'type': 'number'}}
    assert result_token._content == '{"shape": {"type": "number"}, "size": {"type": "number"}}'


# Generated at 2022-06-26 11:01:10.121871
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    # DEBUG: dict_token_0._start_index = 985
    # DEBUG: dict_token_0._content = '{"a":4}'
    token_0 = Token(dict_token_0, 985, 989)
    dict_token_1 = DictToken()
    token_1 = Token(dict_token_1, 985, 989)
    assert token_0 == token_1


# Generated at 2022-06-26 11:01:12.494610
# Unit test for method lookup of class Token
def test_Token_lookup():
    def tokens_lookup(self, index):
        return self.lookup(index)

    tokens_lookup(dict_token_0, [])



# Generated at 2022-06-26 11:01:20.411483
# Unit test for method lookup of class Token
def test_Token_lookup():
    # Declare objects and variables
    dict_token_0 = DictToken()
    list_token_0 = ListToken()
    list_token_0_0 = ListToken()
    int_token_0_0_0 = ScalarToken(1)
    int_token_0_0_1 = ScalarToken(2)
    list_token_0_1 = ListToken()
    int_token_0_1_0 = ScalarToken(3)
    int_token_0_1_1 = ScalarToken(4)
    str_token_0_1_1 = ScalarToken(" a")
    str_token_0_1_1_1 = ScalarToken(" a")
    str_token_0_2 = ScalarToken("b")

# Generated at 2022-06-26 11:01:24.047404
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert dict_token_0 == dict_token_1
    assert not dict_token_0 == 1


# Generated at 2022-06-26 11:01:24.973707
# Unit test for method __hash__ of class ScalarToken
def test_ScalarToken___hash__():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:01:27.221218
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

