

# Generated at 2022-06-26 10:52:20.953685
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 10:52:27.293543
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_1 = DictToken()
    int_1 = -1900
    scalar_token_1 = ScalarToken(dict_token_1, int_1, int_1)
    assert scalar_token_1._get_value() == dict_token_1
    assert scalar_token_1._start_index == int_1
    assert scalar_token_1._end_index == int_1


# Generated at 2022-06-26 10:52:29.920775
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken({})
    int_0 = -1900
    scalar_token_0 = ScalarToken(0, int_0, int_0)
    assert scalar_token_0 is not None


# Generated at 2022-06-26 10:52:36.225788
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    int_0 = -1900
    scalar_token_0 = ScalarToken(dict_token_0, int_0, int_0)
    assert (scalar_token_0.value == {}), "Incorrect value after constructor"



# Generated at 2022-06-26 10:52:45.167824
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    int_0 = -1900
    scalar_token_1 = ScalarToken(dict_token_0, int_0, int_0)
    dict_token_2 = DictToken(scalar_token_1._value, scalar_token_1._start_index, scalar_token_1._end_index,scalar_token_1._content)
    #Test .start
    assert(dict_token_2.start.column==1)
    assert(dict_token_2.start.index==int_0)
    assert(dict_token_2.start.line==1)
    #Test .end
    assert(dict_token_2.end.column==1)
    assert(dict_token_2.end.index==int_0)

# Generated at 2022-06-26 10:52:52.255917
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    int_0 = -1900
    scalar_token_0 = ScalarToken(dict_token_0, int_0, int_0)
    dict_token_1 = DictToken()
    int_1 = -1900
    scalar_token_1 = ScalarToken(dict_token_1, int_1, int_1)
    assert scalar_token_0 == scalar_token_1


# Generated at 2022-06-26 10:52:57.976213
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    int_0 = -1900
    try:
        DictToken(None)
        assert False
    except:
        assert True
    scalar_token_0 = ScalarToken(dict_token_0, int_0, int_0)


# Generated at 2022-06-26 10:53:01.804877
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    int_0 = -1900
    scalar_token_0 = ScalarToken(dict_token_0, int_0, int_0)
    assert scalar_token_0 == scalar_token_0


# Generated at 2022-06-26 10:53:07.340636
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    int_0 = -1900
    scalar_token_0 = ScalarToken(dict_token_0, int_0, int_0)
    int_1 = -1900
    scalar_token_1 = ScalarToken(dict_token_0, int_1, int_1)
    assert scalar_token_0 == scalar_token_1
    assert scalar_token_1 == scalar_token_0


# Generated at 2022-06-26 10:53:10.624930
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    # AssertionError: DictToken does not provide valid constructor
    try:
        dict_token_0 = DictToken(int(), dict(), dict(), int())
    except AssertionError:
        pass


# Generated at 2022-06-26 10:53:26.747066
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken(3, 0, 2, "")
    dict_token_1._value[1] = dict_token_0
    dict_token_0._value[2] = dict_token_1
    dict_token_1._value[3] = dict_token_1
    dict_token_0._value[4] = dict_token_1
    dict_token_1._value[5] = dict_token_0
    dict_token_1._value[6] = dict_token_0
    dict_token_0._value[7] = dict_token_1
    dict_token_1._value[8] = dict_token_0
    dict_token_1._value[9] = dict_token_1
    dict_token_

# Generated at 2022-06-26 10:53:28.167815
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:53:30.156844
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_0._get_value()


# Generated at 2022-06-26 10:53:33.489669
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert repr(dict_token_0) == 'DictToken({})'


# Generated at 2022-06-26 10:53:35.963000
# Unit test for constructor of class DictToken
def test_DictToken():
    try:
        test_case_0()
    except Exception as ex:
        print(ex)
        traceback.print_exc()


# Generated at 2022-06-26 10:53:42.319679
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    string_0 = '{"K": "V"}'
    int_0 = 0
    int_1 = 0
    token_0 = ScalarToken('V', 5, 5, string_0)
    token_1 = ScalarToken('K', 2, 2, string_0)
    token_2 = DictToken({token_1: token_0}, int_1, int_0, string_0)
    assert token_2 == token_2



# Generated at 2022-06-26 10:53:45.585738
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0 != None
    assert isinstance(dict_token_0, DictToken)


# Generated at 2022-06-26 10:53:46.973062
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:53:56.969262
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken(None, None, None)
    dict_token_1 = DictToken(None, None, None)
    dict_token_1._end_index = 0
    dict_token_2 = DictToken(None, None, None)
    dict_token_2._start_index = 0
    dict_token_3 = DictToken(None, None, None)
    dict_token_3._value = None
    assert dict_token_0 != dict_token_1
    assert dict_token_0 != dict_token_2
    assert dict_token_0 != dict_token_3


# Generated at 2022-06-26 10:53:58.080207
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

# Generated at 2022-06-26 10:54:09.111800
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert dict_token_0 == dict_token_1


# Generated at 2022-06-26 10:54:20.074847
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import Token, ScalarToken
    dict_token_0 = DictToken(
        value={},
        start_index=0,
        end_index=0,
        content='{"foo":"bar"}'
    )
    assert dict_token_0.string == '{"foo":"bar"}'
    assert dict_token_0.value == {}
    assert dict_token_0.start.line == 1
    assert dict_token_0.start.column == 1
    assert dict_token_0.start.offset == 0
    assert dict_token_0.end.line == 1
    assert dict_token_0.end.column == 13
    assert dict_token_0.end.offset == 12


# Generated at 2022-06-26 10:54:21.225902
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 10:54:22.129619
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 10:54:24.827940
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    Token_obj_0 = Token()
    Token_obj_1 = Token()
    assert Token_obj_0 == Token_obj_1


# Generated at 2022-06-26 10:54:29.189474
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    
    assert dict_token_0 == dict_token_1

    dict_token_2 = dict_token_0
    assert dict_token_2 == dict_token_1
    assert dict_token_1 == dict_token_2



# Generated at 2022-06-26 10:54:33.775559
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    Token._value = dict_token_0
    Token._start_index = dict_token_0
    Token._end_index = dict_token_0
    dict_token_0.__eq__(dict_token_1)


# Generated at 2022-06-26 10:54:34.935801
# Unit test for constructor of class DictToken
def test_DictToken():
    result = DictToken()
    assert result


# Generated at 2022-06-26 10:54:40.586133
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test 0
    dict_token_0 = DictToken(value={}, start_index=0, end_index=1, content='{"a": 1}' )
    assert dict_token_0._value == {}
    assert dict_token_0._start_index == 0
    assert dict_token_0._end_index == 1
    assert dict_token_0._content == '{"a": 1}'
    assert dict_token_0.string == '{'


# Generated at 2022-06-26 10:54:41.521401
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    test_case_0()


# Generated at 2022-06-26 10:55:00.690655
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert (dict_token_0 == dict_token_1)


# Generated at 2022-06-26 10:55:02.427381
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:55:09.319047
# Unit test for constructor of class DictToken
def test_DictToken():
    dt = DictToken(
        value = {"foo": "bar"},
        start_index = 10,
        end_index = 20,
        content = "abc",
    )
    assert dt.value == {"foo": "bar"}
    assert dt.start == Position(1, 4, 10)
    assert dt.end == Position(1, 5, 20)
    assert dt.string == "b"
    assert dt.lookup([0]).value == "bar"
    assert dt.lookup_key([0]).value == "foo"



# Generated at 2022-06-26 10:55:10.044331
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:55:11.824299
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_0.__eq__(dict_token_0)


# Generated at 2022-06-26 10:55:12.981781
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:55:14.083457
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:55:16.983396
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    scalar_token_0 = ScalarToken()
    list_token_0 = ListToken()

# Generated at 2022-06-26 10:55:23.757040
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Initializing an instance of Token
    dict_token_0 = DictToken()

    # Instance methods
    scalar_token_0 = ScalarToken("", 0, 0)
    scalar_token_0.string
    scalar_token_1 = ScalarToken("", 0, 0)
    scalar_token_1.string

    assert scalar_token_0 == scalar_token_1


# Generated at 2022-06-26 10:55:30.375043
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # example_0
    token_0 = ScalarToken(1, 1, 1, content='')
    token_1 = ScalarToken(1, 1, 1, content='')
    try:
        token_0 is token_1
    except Exception:
        pass


# Generated at 2022-06-26 10:57:29.261935
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:57:30.728932
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:57:39.085554
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken(value = {}, start_index = 0, end_index = 0, content = "str")
    dict_token = DictToken(value = {}, start_index = 0, end_index = 0)
    dict_token = DictToken(value = {}, start_index = 0)
    dict_token = DictToken(value = {})
    dict_token = DictToken()


# Generated at 2022-06-26 10:57:39.619902
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_1 = DictToken()

# Generated at 2022-06-26 10:57:40.236504
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:57:41.757500
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:57:42.341730
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:57:43.622636
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:57:46.995322
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert str(dict_token_0) == "DictToken({})"
    assert dict_token_0.string == "{}"


# Generated at 2022-06-26 10:57:48.220677
# Unit test for constructor of class DictToken
def test_DictToken():
    print(DictToken())



# Generated at 2022-06-26 10:58:39.888714
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:58:47.285106
# Unit test for constructor of class DictToken
def test_DictToken():
    map_0 = {
        ScalarToken(0, 0, 1, "x"): ScalarToken(1, 2, 3, "x"),
        ScalarToken(3, 1, 3, "x"): ScalarToken(1, 2, 3, "x"),
        ScalarToken(0, 2, 3, "x"): ScalarToken(1, 2, 3, "x"),
        ScalarToken(2, 3, 3, "x"): ScalarToken(1, 2, 3, "x"),
    }
    dict_token_0 = DictToken(map_0, 0, 4, "x")
    assert dict_token_0 is not None


# Generated at 2022-06-26 10:58:52.248997
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:58:54.070004
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:58:57.928249
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken(None, 0, 1)
    assert isinstance(dict_token_0, Token)

    try:
        # Test for valid call
        test_case_0()
    except TypeError:
        print("TypeError")


# Generated at 2022-06-26 10:59:01.375547
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken("my_value", 0, 5, "my_content")

    # Assert that instance created
    assert dict_token

    # Assert that instance is of class DictToken
    assert isinstance(dict_token, DictToken)


# Generated at 2022-06-26 10:59:14.638435
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem import Dict
    from unittest import TestCase
    from unittest.mock import Mock, patch

    class TestDictToken(TestCase):
        @patch('typesystem.validation.tokens.ScalarToken')
        @patch('typesystem.validation.tokens.DictToken')
        @patch('typesystem.validation.tokens.ListToken')
        @patch('typesystem.validation.tokens.Token')
        def test___init__(self, _token, _list_token, _dict_token, _scalar_token):
            _value = Mock(spec=Dict, name='value')
            _start_index = Mock(name='start_index')
            _end_index = Mock(name='end_index')

# Generated at 2022-06-26 10:59:15.940494
# Unit test for constructor of class DictToken
def test_DictToken():
    ex0 = DictToken()
    print(ex0)


# Generated at 2022-06-26 10:59:17.202119
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 10:59:18.479914
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 11:01:09.163753
# Unit test for constructor of class DictToken
def test_DictToken():
    # Should throw an error since parameters are not correct
    try:
        dict_token_0 = DictToken()
    except:
        pass


# Generated at 2022-06-26 11:01:11.678751
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert {} == dict_token_0._get_value()
    assert {} == dict_token_0.value


# Generated at 2022-06-26 11:01:16.917118
# Unit test for constructor of class DictToken
def test_DictToken():
    # constructor
    # initialize the value and create a token from the value
    dict_value = {1: "a", 2: "b"}
    dict_token = DictToken(dict_value, 0, 2, "1: a\n2: b")
    assert type(dict_token) == DictToken
    assert dict_token._value == dict_value
    assert dict_token._start_index == 0
    assert dict_token._end_index == 2
    assert dict_token._content == "1: a\n2: b"



# Generated at 2022-06-26 11:01:17.928832
# Unit test for constructor of class DictToken
def test_DictToken():
  dict_token_0 = DictToken()
  assert dict_token_0 is not None

# Generated at 2022-06-26 11:01:19.888060
# Unit test for constructor of class DictToken
def test_DictToken():
    print(test_case_0.__doc__)
    test_case_0()


# Generated at 2022-06-26 11:01:24.263183
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = test_case_0()
    assert dict_token_0._value == None
    assert dict_token_0._start_index == None
    assert dict_token_0._end_index == None
    assert dict_token_0._content == None

# Generated at 2022-06-26 11:01:26.271022
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken()


# Generated at 2022-06-26 11:01:29.108949
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0,DictToken)


# Generated at 2022-06-26 11:01:29.902498
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 11:01:31.093391
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
