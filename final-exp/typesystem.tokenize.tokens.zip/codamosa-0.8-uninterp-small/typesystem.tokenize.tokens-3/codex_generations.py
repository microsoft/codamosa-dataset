

# Generated at 2022-06-26 10:52:29.622520
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0._child_keys == dict()   # Type dict
    assert dict_token_0._child_tokens == dict()   # Type dict
    
    

# Generated at 2022-06-26 10:52:30.925710
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    assert not (dict_token_0 == 0)


# Generated at 2022-06-26 10:52:33.988426
# Unit test for constructor of class DictToken
def test_DictToken():
    print('testing constructor of class DictToken')
    test_case_0()

# Generated at 2022-06-26 10:52:36.180869
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0 != None


# Generated at 2022-06-26 10:52:37.500475
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 10:52:38.447734
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    pass


# Generated at 2022-06-26 10:52:40.939357
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert dict_token_0 != dict_token_1



# Generated at 2022-06-26 10:52:42.800288
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    boolean_0 = "foo" == dict_token_0
    assert not boolean_0


# Generated at 2022-06-26 10:52:44.370060
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:52:47.494672
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()


# Generated at 2022-06-26 10:52:53.079410
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert dict_token_0 == dict_token_1

# Generated at 2022-06-26 10:52:55.206461
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()

if __name__ == "__main__":
    test_DictToken()
    pass

# Generated at 2022-06-26 10:52:56.637370
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:52:58.865323
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0 is not None


# Generated at 2022-06-26 10:52:59.800403
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 10:53:02.519281
# Unit test for constructor of class DictToken
def test_DictToken():

    try:
        dict_token_0 = DictToken()
    except BaseException as e:
        raise AssertionError(str(e))



# Generated at 2022-06-26 10:53:03.930423
# Unit test for constructor of class DictToken
def test_DictToken():
    # test constructor of class DictToken
    test_case_0()

# Generated at 2022-06-26 10:53:05.199770
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:53:08.004925
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    result = (dict_token_0 == dict_token_1)
    assert isinstance(result, bool)
    assert result


# Generated at 2022-06-26 10:53:20.227785
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test to make sure anything is equal to itself
    token = Token('token', 0, 0, 'token')
    assert (token == token)
    # Test to make sure equivalent Tokens are equal
    assert (Token('retVal', 2, 7, 'token') == Token('retVal', 2, 7, 'token'))
    # Test to make sure Tokens with different values are not equal
    assert (Token('retVal1', 2, 7, 'token') != Token('retVal2', 2, 7, 'token'))
    # Test to make sure Tokens with different start indices are not equal
    assert (Token('retVal', 3, 7, 'token') != Token('retVal', 2, 7, 'token'))
    # Test to make sure Tokens with different end indices are not equal

# Generated at 2022-06-26 10:53:31.690006
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    str_0 = str(dict_token_0)

# Generated at 2022-06-26 10:53:35.157320
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    boolean_0 = ScalarToken(True, 0, 3, " True") == dict_token_0
    assert boolean_0


# Generated at 2022-06-26 10:53:38.840194
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # __eq__ is None
    try:
        assert Token(0, 0, 0) == 0
    except NotImplementedError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-26 10:53:40.154611
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:53:42.160422
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    dict_token_0.__eq__(dict_token_1)


# Generated at 2022-06-26 10:53:46.682972
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test with positional arguments
    dict_token_0 = DictToken()
    # Test with positional and keyword arguments
    dict_token_1 = DictToken()
    # Test with keyword arguments
    dict_token_2 = DictToken()



# Generated at 2022-06-26 10:53:48.637973
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:53:54.872533
# Unit test for constructor of class DictToken
def test_DictToken():
    assert isinstance(DictToken(), DictToken)


# Generated at 2022-06-26 10:54:05.795324
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # test simple cases
    assert ScalarToken(1, 0, 1, "1").__eq__(ScalarToken(1, 0, 1, "1"))
    assert not ScalarToken(1, 0, 1, "1").__eq__(ScalarToken(2, 0, 1, "2"))
    assert not ScalarToken(1, 1, 1, "1").__eq__(ScalarToken(1, 0, 1, "1"))
    assert not ScalarToken(1, 0, 2, "1").__eq__(ScalarToken(1, 0, 1, "1"))
    # test complex cases

# Generated at 2022-06-26 10:54:09.409760
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    assert not (dict_token_0 == Token(None, 0, 0, "")), "Expected False, got True"


# Generated at 2022-06-26 10:54:21.835614
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:32.159330
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken(None, None, None, )
    dict_token_0._get_value()
    dict_token_0._get_child_token(None)
    dict_token_0._get_key_token(None)
    dict_token_0.lookup(None)
    dict_token_0.lookup_key(None)
    dict_token_0._get_position(None)
    dict_token_0.__repr__()
    dict_token_0.__eq__(None)
    dict_token_0.__hash__()
    dict_token_1 = DictToken(None, None, None, )
    dict_token_1._get_value()
    dict_token_1._get_child_token(None)
    dict_token_1._get

# Generated at 2022-06-26 10:54:36.378211
# Unit test for constructor of class DictToken
def test_DictToken():
    for test_case_no in range(0, 1):
        result = test_case_0()
        print(result)

if __name__ == "__main__":
    test_case_no = int(input())

    if test_case_no == 0:
        test_DictToken()
    else:
        raise RuntimeError(f"unsupported test case: {test_case_no}")

# Generated at 2022-06-26 10:54:37.669140
# Unit test for constructor of class DictToken
def test_DictToken():
    try:
        DictToken()
    except:
        assert False


# Generated at 2022-06-26 10:54:39.734323
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0 is not None


# Generated at 2022-06-26 10:54:41.101972
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:54:41.668580
# Unit test for constructor of class DictToken
def test_DictToken():
    pass

# Generated at 2022-06-26 10:54:42.946373
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:48.837682
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0._value == {}
    assert dict_token_0._start_index == 0
    assert dict_token_0._end_index == 0
    assert dict_token_0._content == ""
    assert dict_token_0._child_keys == {}
    assert dict_token_0._child_tokens == {}


# Generated at 2022-06-26 10:54:53.284609
# Unit test for constructor of class DictToken
def test_DictToken():
    std_test_case_0 = """
        def test_case_0():
            dict_token_0 = DictToken()
    """
    dict_token_0_obj= DictToken()
    assert str(dict_token_0_obj) == "DictToken(None)"




# Generated at 2022-06-26 10:55:15.761623
# Unit test for constructor of class DictToken
def test_DictToken():
    # test constructor 0. func: __init__
    tk0 = test_case_0()

    # test constructor 1. func: __init__
    tk1 = test_case_0()

    # test constructor 2. func: __init__
    tk2 = test_case_0()

    # test constructor 3. func: __init__
    tk3 = test_case_0()

    # test constructor 4. func: __init__
    tk4 = test_case_0()

    # test constructor 5. func: __init__
    tk5 = test_case_0()

    # test constructor 6. func: __init__
    tk6 = test_case_0()

    # test constructor 7. func: __init__
    tk7 = test_case_0()

    # test constructor 8. func

# Generated at 2022-06-26 10:55:18.447301
# Unit test for constructor of class DictToken
def test_DictToken():
    # FAIL: Caught this exception: IndexError: list index out of range
    try:
        test_case_0()
        assert False
    except IndexError as e:
        assert True

# Generated at 2022-06-26 10:55:19.350303
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken()


# Generated at 2022-06-26 10:55:24.836879
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken(
        dict(),
        0,
        0,
        "'''\nExample:\n\n    >>> numbers = [1, 2, 3]\n\n    >>> print(numbers)\n    [1, 2, 3]\n\n'''",
    )


# Generated at 2022-06-26 10:55:28.526415
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

# Generated at 2022-06-26 10:55:29.166067
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()
    test_case_0()


# Generated at 2022-06-26 10:55:30.564386
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:55:31.484805
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken()


# Generated at 2022-06-26 10:55:33.392068
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0 is not None


# Generated at 2022-06-26 10:55:36.772539
# Unit test for constructor of class DictToken
def test_DictToken():
    print("test_DictToken")
    instance_0 = DictToken()
    instance_1 = DictToken("start_index", "end_index", "content")
    instance_2 = DictToken("start_index", "end_index", "content", "kwarg_0")


# Generated at 2022-06-26 10:56:12.607445
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken(dict_token_0 = dict(), dict_token_1 = dict(), dict_token_2 = dict())
    dict_token_1 = DictToken(dict_token_0 = dict(), dict_token_1 = dict(), dict_token_2 = dict())
    assert dict_token_0 == dict_token_1


# Generated at 2022-06-26 10:56:14.197652
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:56:18.891358
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test case 0
    dict_token_0 = DictToken()
    # AssertionError: 3 != 4

    # Test case 1

# Generated at 2022-06-26 10:56:21.024462
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:56:22.802550
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:56:25.638117
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, DictToken) is True


# Generated at 2022-06-26 10:56:28.349837
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:56:30.168894
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:56:35.586453
# Unit test for constructor of class DictToken
def test_DictToken():
    try:
        test_case_0()
    except AssertionError as e:
        print("Test Failed when testing DictToken constructor.", e)
    print("Test Passed for DictToken constructor.")
    try:
        assert DictToken(None, None, None)
    except:
        pass

# Testing for constructor of class ListToken

# Generated at 2022-06-26 10:56:37.892220
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, DictToken)


# Generated at 2022-06-26 10:57:39.672323
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:57:42.095107
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert (dict_token_0._get_value() == {})
    assert (dict_token_0.__class__.__name__ == "DictToken")
    assert (dict_token_0.__module__ == "typesystem.token")
    assert (dict_token_0._start_index == 0)
    assert (dict_token_0._end_index == 0)
    assert (dict_token_0._content == "")


# Generated at 2022-06-26 10:57:44.548150
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0
    assert isinstance(dict_token_0, DictToken)


# Generated at 2022-06-26 10:57:45.759103
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 10:57:48.775088
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert type(dict_token_0) == DictToken
    assert dict_token_0._get_value() == {}


# Generated at 2022-06-26 10:57:51.527866
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0 is not None
    assert dict_token_0._child_keys == {}
    assert dict_token_0._child_tokens == {}


# Generated at 2022-06-26 10:58:00.715323
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    dict_token_2 = DictToken()
    dict_token_3 = DictToken()
    dict_token_4 = DictToken()
    dict_token_5 = DictToken()
    dict_token_6 = DictToken()
    dict_token_7 = DictToken()
    dict_token_8 = DictToken()
    dict_token_9 = DictToken()
    dict_token_10 = DictToken()
    dict_token_11 = DictToken()
    dict_token_12 = DictToken()
    dict_token_13 = DictToken()


# Generated at 2022-06-26 10:58:01.910421
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:58:02.798101
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 10:58:12.562688
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert dict_token_1 == dict_token_0
    assert isinstance(dict_token_0, DictToken)
    assert isinstance(dict_token_0, Token)
    dict_token_2 = DictToken()
    assert dict_token_2 == dict_token_0
    assert isinstance(dict_token_2, DictToken)
    assert isinstance(dict_token_2, Token)
    dict_token_3 = DictToken()
    assert dict_token_3 == dict_token_0
    assert isinstance(dict_token_3, DictToken)
    assert isinstance(dict_token_3, Token)
    dict_token_4 = DictToken()
    assert dict_token_4

# Generated at 2022-06-26 11:00:23.610614
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:00:26.234621
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0._child_tokens == {}
    assert dict_token_0._child_keys == {}


# Generated at 2022-06-26 11:00:27.379572
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:00:36.484004
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, Token)
    assert isinstance(dict_token_0, DictToken)
    assert not isinstance(dict_token_0, ListToken)
    assert not isinstance(dict_token_0, ScalarToken)
    str(dict_token_0)
    repr(dict_token_0)
    dict_token_0_0 = DictToken()
    assert dict_token_0 == dict_token_0_0
    assert not isinstance(dict_token_0.value, DictToken)
    assert not isinstance(dict_token_0.value, ListToken)
    assert not isinstance(dict_token_0.value, ScalarToken)

# Generated at 2022-06-26 11:00:40.025346
# Unit test for constructor of class DictToken
def test_DictToken():
    text = "{"
    start_index = 0
    end_index = 2
    content = "{"
    assert DictToken(
        text, start_index, end_index, content
    ).__repr__() == "DictToken({}"



# Generated at 2022-06-26 11:00:41.890492
# Unit test for constructor of class DictToken
def test_DictToken():
    assert isinstance(DictToken(), DictToken)


# Generated at 2022-06-26 11:00:43.815410
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0._get_value() == {}


# Generated at 2022-06-26 11:00:46.989719
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_0._value
    dict_token_0._start_index
    dict_token_0._end_index
    dict_token_0._content
    dict_token_0.string
    dict_token_0.value

# Generated at 2022-06-26 11:00:48.343899
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:00:49.550516
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken()

