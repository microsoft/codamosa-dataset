

# Generated at 2022-06-26 10:52:33.077219
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    str_0 = 'C@QG.v^s?{WKEg#>j'
    int_0 = 1417
    token_0 = Token(str_0, int_0, int_0, str_0)
    str_1 = '|?Qk0~U&$i:6Km[))p'
    int_1 = 848
    token_1 = Token(str_1, int_1, int_1, str_1)
    b_0 = token_0 == token_1
    str_2 = '-w%Pt$@q3)4 7*hO^'
    int_2 = 1341
    token_2 = Token(str_2, int_2, int_2, str_2)

# Generated at 2022-06-26 10:52:34.273272
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    test_case_0()


# Generated at 2022-06-26 10:52:39.517963
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    str_0 = 'zs8wv+L&h'
    int_0 = -1018
    token_0 = Token(str_0, int_0, int_0, str_0)
    assert not token_0.__eq__('L,7c|HrL}M7K')


# Generated at 2022-06-26 10:52:46.791552
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    str_0 = 'aAxt/j]BMfh/z?a{vLX'
    int_0 = 2130
    token_0 = Token(str_0, int_0, int_0, str_0)
    str_0 = 'Yc%Rg&v{"#kBTB`q]z*'
    int_0 = 2215
    token_1 = Token(str_0, int_0, int_0, str_0)
    assert token_0.__eq__(token_1), 'Failed test_Token___eq__'
    str_0 = 'oNlU(9J@Z%cq?YnU;]b'
    int_0 = 922
    token_0 = Token(str_0, int_0, int_0, str_0)
   

# Generated at 2022-06-26 10:52:47.817272
# Unit test for constructor of class DictToken
def test_DictToken():
    token_0 = DictToken(
        {}, 0, 0, '',
    )



# Generated at 2022-06-26 10:52:54.750111
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    str_0 = '{y#Eb'
    int_0 = -9279
    str_1 = '<i}Dp!?hP<o`{'
    int_1 = -1789
    Token_0 = Token(str_0, int_0, int_0, str_0)
    Token_1 = Token(str_1, int_1, int_1, str_1)
    Token_2 = Token(str_1, int_1, int_1, str_1)
    test_case_0(Token_0, Token_1, Token_2)


# Generated at 2022-06-26 10:53:05.158181
# Unit test for method __eq__ of class Token
def test_Token___eq__():

    print('Test: __eq__')

    str_0 = 'P'
    int_0 = 114
    token_0 = Token(str_0, int_0, int_0, str_0)
    str_1 = 'r'
    int_1 = 142
    token_1 = Token(str_1, int_1, int_1, str_1)
    assert not token_0._eq__(token_1)

    str_0 = '+'
    int_0 = 4
    token_0 = Token(str_0, int_0, int_0, str_0)
    str_1 = '+'
    int_1 = 4
    token_1 = Token(str_1, int_1, int_1, str_1)
    assert token_0._eq__(token_1)



# Generated at 2022-06-26 10:53:09.151393
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    str_0 = 'sRIrfX/r^IBeoV!R?x}a'
    int_0 = 1808
    token_0 = Token(str_0, int_0, int_0, str_0)
    token_1 = Token(str_0, int_0, int_0, str_0)
    assert token_0 == token_1


# Generated at 2022-06-26 10:53:16.456667
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    str_0 = 'Z!8'
    int_0 = 8886
    token_0 = Token(str_0, int_0, int_0, str_0)
    int_1 = 3520
    token_1 = Token(str_0, int_1, int_1, str_0)
    assert not token_0.__eq__(token_1)


# Generated at 2022-06-26 10:53:22.230398
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    str_0 = 'sRIrfX/r^IBeoV!R?x}a'
    int_0 = 1808
    token_0 = Token(str_0, int_0, int_0, str_0)
    token_1 = Token(str_0, int_0, int_0, str_0)
    bool_0 = token_0 == token_1


# Generated at 2022-06-26 10:53:37.971810
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = '?a{0"*3!2#1~d;'
    str_1 = '_b$t<"c%r>:'
    int_0 = 12
    dict_0 = {ScalarToken(str_0, int_0, int_0, str_0): ScalarToken(str_1, int_0, int_0, str_1)}
    dict_token_0 = DictToken(dict_0, int_0, int_0, str_0)


# Generated at 2022-06-26 10:53:39.144178
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    pass


# Generated at 2022-06-26 10:53:46.900528
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    str_0 = u'j|;Y`\x1cIx}Aj'
    int_0 = 10
    token_0 = Token(str_0, int_0, int_0, str_0)
    str_1 = u'j|;Y`\x1cIx}Aj'
    int_1 = 10
    token_1 = Token(str_1, int_1, int_1, str_1)
    assert token_0 == token_1
    str_2 = u'J|;Y`\x1cIx}Aj'
    int_2 = 10
    token_2 = Token(str_2, int_2, int_2, str_2)
    assert not (token_0 == token_2)

# Generated at 2022-06-26 10:53:53.810510
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    str_0 = 'sRIrfX/r^IBeoV!R?x}a'
    int_0 = 1808
    token_0 = Token(str_0, int_0, int_0, str_0)
    token_1 = token_0
    assert (token_0 == token_1)


# Generated at 2022-06-26 10:54:00.430747
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    str_0 = '7ncIwf)n.t/N'
    int_0 = 1600
    token_0 = Token(str_0, int_0, int_0)
    int_1 = 1200
    token_1 = Token(str_0, int_1, int_0)
    assert not token_0.__eq__(token_1)


# Generated at 2022-06-26 10:54:06.956491
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    str_0 = 'CXx#[nB\x1bkI-(R/TW'
    int_0 = 684
    token_0 = Token(str_0, int_0, int_0, str_0)
    str_1 = 'CXx#[nB\x1bkI-(R/TW'
    int_1 = 684
    token_1 = Token(str_1, int_1, int_1, str_1)
    assert token_0.__eq__(token_1)


# Generated at 2022-06-26 10:54:11.801520
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = 'H8:>L-iC|w4"B@C!M^'
    int_0 = 598
    token_0 = DictToken(str_0, int_0, int_0, str_0)


# Generated at 2022-06-26 10:54:14.304605
# Unit test for constructor of class DictToken
def test_DictToken():
    object_0 = object()
    token_0 = DictToken({object_0: object_0}, 0, 0)


# Generated at 2022-06-26 10:54:25.700242
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    str_0 = 'sRIrfX/r^IBeoV!R?x}a'
    int_0 = 1808
    token_0 = Token(str_0, int_0, int_0, str_0)
    token_1 = Token(str_0, int_0, int_0, str_0)
    str_1 = 'sRIrfX/r^IBeoV!R?x}a'
    int_1 = 1808
    token_2 = Token(str_1, int_1, int_1, str_1)

    assert token_0 == token_1
    assert token_0 == token_2
    assert token_1 == token_0
    assert token_1 == token_2
    assert token_2 == token_0
    assert token_2 == token_1

   

# Generated at 2022-06-26 10:54:32.482013
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    str_0 = 'sRIrfX/r^IBeoV!R?x}a'
    int_0 = 1808
    token_0 = Token(str_0, int_0, int_0, str_0)
    str_1 = 'sRIrfX/r^IBeoV!R?x}a'
    int_1 = 1808
    token_1 = Token(str_1, int_1, int_1, str_1)
    assert token_0 == token_1


# Generated at 2022-06-26 10:54:47.697460
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    str_0 = '@E}s/faI+pw.IZxx:fj`'
    int_0 = 111
    token_0 = Token(str_0, int_0, int_0, str_0)
    int_1 = 112
    token_1 = Token(str_0, int_1, int_1, str_0)
    int_2 = 113
    token_2 = Token(str_0, int_2, int_2, str_0)
    bool_0 = token_0 == token_1
    assert bool_0 == False
    bool_1 = token_1 == token_2
    assert bool_1 == False
    bool_2 = token_0 == token_2
    assert bool_2 == False


# Generated at 2022-06-26 10:54:56.692393
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = 'kF/N(IjMbZ=X"g.4Y0z~'
    int_0 = 1041
    dict_0 = {}
    dict_1 = {}
    dict_1[str_0] = dict_0
    dict_2 = {}
    dict_2[str_0] = dict_1
    dict_3 = {}
    dict_3[str_0] = dict_2
    dict_4 = {}
    dict_4[str_0] = dict_3
    dict_5 = {}
    dict_5[str_0] = dict_4
    dict_6 = {}
    dict_6[str_0] = dict_5
    dict_7 = {}
    dict_7[str_0] = dict_6
    dict_8 = {}
    dict

# Generated at 2022-06-26 10:55:03.265131
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    str_0 = '!_S"d'
    int_0 = 5560
    str_1 = 'F%o'
    token_0 = DictToken(str_1, int_0, int_0, str_0)
    token_1 = DictToken(str_0, int_0, int_0, str_0)
    assert token_0 == token_1


# Generated at 2022-06-26 10:55:12.197563
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = '|+<I,0J'
    int_0 = 996
    token_0 = Token(str_0, int_0, int_0, str_0)
    list_0 = [token_0]
    dict_0 = {token_0: token_0}
    dict_token_0 = DictToken(dict_0, int_0, int_0, str_0)
    dict_token_1 = DictToken(dict_0, int_0, int_0, str_0)
    dict_token_2 = DictToken(dict_0, int_0, int_0, str_0)
    dict_token_3 = DictToken(dict_0, int_0, int_0, str_0)

# Generated at 2022-06-26 10:55:23.010666
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    str_0 = 'sRIrfX/r^IBeoV!R?x}a'
    int_0 = 1808
    int_0a = int_0+1
    token_0 = Token(str_0, int_0, int_0, str_0)
    token_0a = Token(str_0, int_0, int_0, str_0)
    token_0b = Token(str_0+'a', int_0, int_0, str_0)
    token_0c = Token(str_0, int_0a, int_0, str_0)

    assert token_0 == token_0a
    assert token_0 != token_0b
    assert token_0 != token_0c



# Generated at 2022-06-26 10:55:28.981644
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    str_0 = 'w#'
    int_0 = 440
    token_0 = Token(str_0, int_0, int_0, str_0)
    assert token_0.__eq__(token_0) == True


# Generated at 2022-06-26 10:55:30.838165
# Unit test for constructor of class DictToken
def test_DictToken():
    assert token_0.__class__.__name__ == 'DictToken'


# Generated at 2022-06-26 10:55:38.439917
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = '{#\x1cx\x9d}W\x8f\x97\x85\x08\xae\x8a\x1c\xcc\x99q\x89\xcb\x84\xae\xac\xe8\xbe\x8d'
    int_1 = 1
    token_0 = Token(str_0, int_1, int_1, str_0)
    int_0 = 1
    str_1 = '{#\x1cx\x9d}W\x8f\x97\x85\x08\xae\x8a\x1c\xcc\x99q\x89\xcb\x84\xae\xac\xe8\xbe\x8d'
    token_1 = Dict

# Generated at 2022-06-26 10:55:46.256278
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = '<w?BfZG{\'tS'
    str_1 = '!z&'
    str_2 = 'Y$Y=HnZ'
    int_0 = 9
    int_1 = 4
    token_0 = Token(str_0, int_0, int_0, str_0)
    token_1 = Token(str_1, int_1, int_1, str_1)
    token_2 = DictToken({token_0: token_1}, int_0, int_1, str_2)


# Generated at 2022-06-26 10:55:49.294521
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = 'X9$][,'
    int_0 = 2
    int_1 = 2
    dict_token_0 = DictToken(str_0, int_0, int_1, str_0)


# Generated at 2022-06-26 10:56:15.654284
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    print("Testing __eq__...")

    int_0 = 0
    str_0 = 'token'
    token_0 = Token(str_0, int_0, int_0, str_0)
    str_1 = 'Token'
    token_1 = Token(str_1, int_0, int_0, str_1)
    str_2 = 'token'
    token_2 = Token(str_2, int_0, int_0, str_2)
    str_3 = 'tokEn'
    token_3 = Token(str_3, int_0, int_0, str_3)

    assert token_0 == token_2
    assert token_2 == token_0
    assert token_1 != token_0
    assert token_0 != token_1
    assert token_2 != token_

# Generated at 2022-06-26 10:56:21.966326
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = 'sRIrfX/r^IBeoV!R?x}a'
    int_0 = 1808
    token_0 = Token(str_0, int_0, int_0, str_0)
    str_1 = '}[X;$H}jEORQZ5'
    str_2 = 'i#]*Gz~^jKQ'
    int_1 = 2899
    int_2 = 1507
    int_3 = 1042
    int_4 = 2494
    int_5 = 1557
    token_1 = Token(str_1, int_2, int_3, str_1)
    token_2 = Token(str_2, int_4, int_5, str_2)

# Generated at 2022-06-26 10:56:30.588990
# Unit test for constructor of class DictToken
def test_DictToken():
    
    # Test Case 1
    str_0 = '\u000f'
    int_0 = 2
    str_1 = 'a{'
    int_1 = 0
    str_2 = '!S\u0015'
    str_3 = '5tF'
    int_2 = 2
    token_1 = Token(str_0, int_0, int_0, str_1)
    token_2 = Token(str_2, int_1, int_2, str_3)
    dict_1 = {token_1: token_2}
    str_4 = '3qr'
    int_3 = 1
    token_3 = DictToken(dict_1, int_0, int_3, str_4)


# Generated at 2022-06-26 10:56:34.602765
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    str_0 = 'y\te'
    int_0 = -13188
    token_0 = Token(str_0, int_0, int_0, str_0)
    assert token_0 == token_0


# Generated at 2022-06-26 10:56:42.937229
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Init
    symbol_0 = ScalarToken('=', 0, 0, '=')
    symbol_1 = ScalarToken('=', 1, 1, '=')
    # Test
    test_0 = symbol_0 == symbol_0
    test_1 = symbol_1 == symbol_1
    test_2 = symbol_0 == symbol_1
    assert test_0 == True
    assert test_1 == True
    assert test_2 == False


# Generated at 2022-06-26 10:56:49.771380
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    str_0 = ']O'
    int_0 = 34
    int_1 = 60
    token_0 = ScalarToken(str_0, int_0, int_1)
    int_2 = 60
    token_1 = ScalarToken(str_0, int_0, int_2)
    assert (token_0 == token_1)


# Generated at 2022-06-26 10:56:58.223720
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = u'\u0015\u0016y\x1f\x1cL\u0001\x10X\x19A\x07\u0010\u001E\x1b\u000f\x06\u0011\x1b\u0007\x17'
    str_1 = u'S0\x18\x06P\u0017Z2\x15"\x1e'
    int_0 = 1776
    int_1 = 1641
    token_0 = Token(str_0, int_0, int_1, str_1)
    str_2 = u'\u0018\u0012\u0016\u000f\u0010\x15\x0f\x12\u0018\u0013\u0011\u000e'

# Generated at 2022-06-26 10:57:07.669079
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_0 = {}
    dict_0['a'] = 1
    dict_0['b'] = 2
    dict_0['c'] = 3
    int_0 = 4
    str_0 = "DictToken"
    token_0 = DictToken(dict_0, int_0, int_0, str_0)
    assert isinstance(token_0, DictToken) is True


# Generated at 2022-06-26 10:57:14.999904
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Token::__eq__(Token)
    str_0 = 'sRIrfX/r^IBeoV!R?x}a'
    int_0 = 1808
    token_0 = Token(str_0, int_0, int_0, str_0)
    int_1 = 1808
    token_1 = Token(str_0, int_1, int_1, str_0)
    assert (token_0 == token_1)


# Generated at 2022-06-26 10:57:25.654226
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = 'N~Rx{Eor/G]cND5'
    int_0 = 1796
    token_0 = Token(str_0, int_0, int_0, str_0)

    str_1 = '}C>|'
    int_1 = 1798
    token_1 = Token(str_1, int_1, int_1, str_1)

    str_2 = 'KxFeE?6~-'
    int_2 = 1796
    token_2 = Token(str_2, int_2, int_2, str_2)

    str_3 = 'r'
    int_3 = 1798
    token_3 = Token(str_3, int_3, int_3, str_3)

    str_4 = 'b'

# Generated at 2022-06-26 10:57:42.579329
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = 'sRIrfX/r^IBeoV!R?x}a'
    int_0 = 1808
    token_0 = Token(str_0, int_0, int_0, str_0)
    dict_0 = {token_0 : token_0}
    dict_token_0 = DictToken(dict_0, int_0, int_0, str_0)
    dict_token_0._child_tokens[token_0._get_value()]
    dict_token_0._child_keys[token_0._get_value()]


# Generated at 2022-06-26 10:57:48.135473
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = '{h|S-a8x}x%cG<h[E>>4yv'
    int_0 = 1698
    token = Token(str_0, int_0, int_0, str_0)
    dict_token = DictToken(token, int_0, int_0, str_0)
    return dict_token


# Generated at 2022-06-26 10:57:55.142983
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = '$RynfJT*l%'
    int_0 = 1148
    str_1 = 'E+p@x.z/C/D*jF`=;9X~o'
    str_2 = 'bv'
    str_3 = 'Q\x16\x0b\x1e'
    str_4 = 'Cfv[d+q'
    int_1 = 5933
    token_0 = ListToken(str_0, int_0, int_0, str_0)
    token_1 = ScalarToken(str_1, int_0, int_0, str_0)
    token_2 = ListToken(str_2, int_0, int_0, str_0)

# Generated at 2022-06-26 10:58:02.995392
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = '9Wj}hYg~(R-fz'
    int_0 = 1801
    token_0 = Token(str_0, int_0, int_0, str_0)
    dict_token_0 = DictToken(str_0, int_0, int_0, str_0)
    assert dict_token_0._child_keys[str_0] == token_0
    assert dict_token_0._child_tokens[str_0] == token_0


# Generated at 2022-06-26 10:58:07.839392
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = '"sRIrfX/r^IBeoV!R?x}a"'
    str_1 = "{\'A\': 0, \'B\': 1}"
    int_0 = 12
    token_0 = DictToken(str_0, int_0, int_0, str_1)


# Generated at 2022-06-26 10:58:16.728747
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = '"asdf"'
    str_1 = 'asc'
    str_2 = '"asdf"'
    str_3 = 'asc'
    str_4 = 'cs'
    str_5 = 'ssss'
    str_6 = 'bob'
    dict_0 = {str_0 : Token(str_2, 0, 4, '"asdf"'), str_1 : Token(str_3, 0, 2, 'asc'), str_4 : Token(str_5, 0, 4, 'ssss'), str_6 : Token(str_2, 0, 4, '"asdf"')}
    dict_1 = {str_1 : Token(str_3, 0, 2, 'asc')}

# Generated at 2022-06-26 10:58:21.336006
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = 'sRIrfX/r^IBeoV!R?x}a'
    int_0 = 1808
    token_0 = Token(str_0, int_0, int_0, str_0)
    dict_0 = {token_0:token_0}
    token_0 = DictToken(dict_0, int_0, int_0, str_0)



# Generated at 2022-06-26 10:58:21.890576
# Unit test for constructor of class DictToken
def test_DictToken():
    pass

# Generated at 2022-06-26 10:58:33.364025
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = 'c7B'
    tuple_0 = ([],)
    str_1 = '+`3q"I'
    str_2 = "%)"
    list_0 = ['I']
    int_0 = 2
    str_3 = '9b(n'
    str_4 = '3qQ_>T'
    float_0 = 3.33
    str_5 = '.'
    str_6 = 'aHt@y%'
    str_7 = 'W]*'
    str_8 = 'p'
    str_9 = '0?`'
    str_10 = '@;d'
    str_11 = '?v'
    str_12 = 'i'
    token_0 = Token(str_0, int_0, int_0, str_0)

# Generated at 2022-06-26 10:58:39.459584
# Unit test for constructor of class DictToken
def test_DictToken():
    if Token(Token("", 1, 0, ""), 1, 0, "") != Token("", 1, 0, ""):
        raise ValueError(
            f'_get_value not working as expected in constructor of class DictToken'
        )
    if Token("", 1, 0, "", Token("", 1, 0, "")) != Token("", 1, 0, ""):
        raise ValueError(
            f'_get_value not working as expected in constructor of class DictToken'
        )
    if Token(Token("", 1, 0, ""), 1, 0, "", Token("", 1, 0, "")) != Token("", 1, 0, ""):
        raise ValueError(
            f'_get_value not working as expected in constructor of class DictToken'
        )

# Generated at 2022-06-26 10:59:07.028831
# Unit test for constructor of class DictToken
def test_DictToken():
    a = 1
    b = 1
    token = DictToken(a, b, b, str_0)
    token = DictToken("")
    token = DictToken("", b)
    token = DictToken("", b, b)
    token = DictToken("", b, b, str_0)


# Generated at 2022-06-26 10:59:16.883989
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = ')'
    str_1 = ':y)C<G'
    str_2 = '6x5I[f]iV"O\f`Ggr='
    str_3 = 'V7'
    str_4 = 'Z#'
    str_5 = '\r#o'
    str_6 = '7V'
    str_7 = 'd'
    str_8 = '=M'
    str_9 = 'P'
    str_10 = 'U"x6^)'
    str_11 = 'L0+'
    str_12 = 'D'
    str_13 = 'F'
    str_14 = 'a'
    str_15 = ','
    str_16 = 'R'
    str_17 = 'Z'

# Generated at 2022-06-26 10:59:28.343932
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = 'D{dbm$-E'
    int_0 = 3
    token_0 = Token(str_0, int_0, int_0, str_0)
    str_0 = 'o|'
    int_0 = 327
    token_0 = Token(str_0, int_0, int_0, str_0)
    str_0 = ''
    int_0 = 9921
    token_0 = Token(str_0, int_0, int_0, str_0)
    str_0 = '\x00('
    int_0 = 4
    token_0 = Token(str_0, int_0, int_0, str_0)
    str_0 = '\nN5-8'
    int_0 = 952

# Generated at 2022-06-26 10:59:39.661254
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_0 = {}
    dict_0["token_1"] = 'token_2'
    str_0 = 'token_1'
    int_0 = 0
    token_0 = Token(str_0, int_0, int_0, str_0)
    str_1 = 'token_2'
    int_1 = 0
    token_1 = Token(str_1, int_1, int_1, str_1)
    dict_0[token_0] = token_1

    str_2 = 'token_1'
    int_2 = 0
    token_2 = Token(str_2, int_2, int_2, str_2)
    str_3 = 'token_2'
    int_3 = 0

# Generated at 2022-06-26 10:59:45.100855
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = -245
    int_1 = -18
    int_2 = 89
    str_0 = '9.f}Kj^z`OIw\x7f'
    str_1 = 'r5t^'
    str_2 = '3qYg'
    str_3 = 'I'
    str_4 = '\u0011T|vK'
    str_5 = 'VWCw'
    str_6 = 'A<sza'
    str_7 = 'JX1C'
    str_8 = '\x1d*x\x02^"'
    str_9 = 'dU_|'
    str_10 = '@Qyj'
    str_11 = '\x7f'
    str_12 = '\u0006'
    str

# Generated at 2022-06-26 10:59:54.269067
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = 'Dl'
    int_0 = -4
    int_1 = 2
    token_0 = Token(str_0, int_0, int_1, str_0)
    str_1 = 'nP$GZp'
    int_2 = 14
    token_1 = Token(str_1, int_2, int_0, str_1)
    token_0 = DictToken({token_1: token_0}, int_2, int_2, str_1)
    str_2 = '~3m8a@fK'
    int_3 = 8
    str_3 = '~3m8a@fK'
    token_2 = Token(str_2, int_3, int_1, str_3)
    str_4 = 'V2Q*G'

# Generated at 2022-06-26 11:00:03.481009
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = 't_jKpC'
    int_0 = 7072
    int_1 = 3933
    token_0 = Token(str_0, int_0, int_1, str_0)
    dict_0 = {token_0: token_0}
    int_2 = 7072
    token_1 = DictToken(dict_0, int_2, int_2)
    # AssertionError: 'DictToken(Token('t_jKpC', 7072, 7072))' != 'DictToken(Token('t_jKpC', 7072, 3933))'
    assert token_1 == DictToken({token_0: token_0}, 7072, 3933)


# Generated at 2022-06-26 11:00:04.965559
# Unit test for constructor of class DictToken
def test_DictToken():
    token_0 = DictToken({}, 0, 0, str_0)


# Generated at 2022-06-26 11:00:12.891322
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = 'sRIrfX/r^IBeoV!R?x}a'
    int_0 = 1808
    token_0 = Token(str_0, int_0, int_0, str_0)
    token_0._get_child_token(str_0)
    str_1 = 'sRIrfX/r^IBeoV!R?x}a'
    int_1 = 1808
    token_1 = Token(str_1, int_1, int_1, str_1)
    token_2 = DictToken(token_0, int_0, int_1, str_1)
    token_2._get_child_token(str_1)
    str_2 = 'sRIrfX/r^IBeoV!R?x}a'
    int

# Generated at 2022-06-26 11:00:14.935467
# Unit test for constructor of class DictToken
def test_DictToken():
    # Constructor:
    #   def __init__(self, value, start_index, end_index, content=""):
    pass
    

# Generated at 2022-06-26 11:00:47.952795
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_0 = {} # pylint: disable=invalid-sequence-index
    token_0 = DictToken(dict_0, 1, 1, 'DictToken')

# Generated at 2022-06-26 11:00:59.014219
# Unit test for constructor of class DictToken
def test_DictToken():
    # Constructor call with arguments
    str_0 = 'sRIrfX/r^IBeoV!R?x}a'
    int_0 = 1808
    token_0 = Token(str_0, int_0, int_0, str_0)
    list_token_0 = ListToken(token_0, int_0, int_0, str_0)
    token_1 = Token(list_token_0, int_0, int_0, str_0)
    dict_0 = {token_0: token_1}
    dict_token_0 = DictToken(dict_0, int_0, int_0, str_0)


# Generated at 2022-06-26 11:01:03.760322
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = 'UitkouU+'
    dict_0 = dict()
    dict_0[str_0] = str_0
    int_0 = 0
    # int_1 = 17
    # int_0 = 16
    token_0 = DictToken((dict_0, int_0, int_0, str_0))

# Generated at 2022-06-26 11:01:12.786271
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = 'dicTToken'
    int_0 = 1808
    str_1 = 'dictToken'
    int_1 = 3008
    token_0 = Token(str_0, int_0, int_1, str_0)
    token_1 = Token(str_1, int_0, int_1, str_1)
    dictToken = DictToken(token_0, int_1, int_1, str_0)
    assert dictToken is not None
    assert dictToken._child_keys[str_0] == token_0


# Generated at 2022-06-26 11:01:18.190946
# Unit test for constructor of class DictToken
def test_DictToken():
  str_0 = 'T{V7g'
  int_0 = 244
  dict_0 = DictToken(str_0, int_0, int_0, str_0)
  dict_0 = DictToken(str(int_0), int_0, int_0, str_0)
  dict_0 = DictToken(str_0, int(str_0), int_0, str_0)
  dict_0 = DictToken(str(int_0), int(str_0), int(str_0), str_0)


# Generated at 2022-06-26 11:01:27.396744
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = 'sRIrfX/r^IBeoV!R?x}a'
    int_0 = 1808
    token_0 = Token(str_0, int_0, int_0, str_0)
    str_1 = '6U-o(JQ$<U/}x%m]^qK'
    token_1 = Token(str_1, int_0, int_0, str_1)
    str_2 = 'c%?_jK}y*[^2a:t3a,'
    token_2 = Token(str_2, int_0, int_0, str_2)
    str_3 = 'H<Oe-Z^s`s\\s]oNh-x'

# Generated at 2022-06-26 11:01:30.735327
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_0 = {str_0: token_1, token_1: str_0}
    token_2 = DictToken(dict_0, int_0, int_0, str_0)


# Generated at 2022-06-26 11:01:31.917896
# Unit test for constructor of class DictToken
def test_DictToken():
    # stub method
    pass


# Generated at 2022-06-26 11:01:44.101525
# Unit test for constructor of class DictToken
def test_DictToken():
    string_0 = "z0t,1^~YjKt:Q_t0q3o|`"
    list_0 = []
    dict_0 = {
        '+P$VJ@': list_0,
    }
    dict_1 = dict_0
    dict_1['u#IY$T7V'] = list_0
    dict_2 = dict_1
    dict_2['%n,{Y1R/'] = list_0
    dict_3 = dict_2
    dict_3['d8EMb3kK'] = list_0
    dict_4 = dict_3
    dict_4['5ZIdF,xQ'] = list_0
    int_0 = 7592
    dict_5 = dict_4

# Generated at 2022-06-26 11:01:52.327213
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = 2
    str_0 = 'X2v1'
    list_0 = [str_0, str_0, str_0]
    dict_0 = {str_0: list_0, str_0: list_0}
    int_1 = 100
    int_2 = 100
    token_0 = DictToken(dict_0, int_0, int_1, str_0)
