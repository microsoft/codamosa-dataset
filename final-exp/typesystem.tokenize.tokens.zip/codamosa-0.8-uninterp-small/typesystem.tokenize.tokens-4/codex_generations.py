

# Generated at 2022-06-26 10:52:30.405323
# Unit test for constructor of class DictToken
def test_DictToken():
    list_0 = []
    int_0 = -1139
    scalar_token_0 = ScalarToken(list_0, int_0, int_0)
    int_1 = 0
    scalar_token_1 = ScalarToken(list_0, int_1, int_1)
    dict_0 = {scalar_token_0 : scalar_token_1}
    int_2 = -1139
    dict_token_0 = DictToken(dict_0, int_2, int_2)


# Generated at 2022-06-26 10:52:38.360448
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    list_0 = []
    int_0 = -1139
    scalar_token_0 = ScalarToken(list_0, int_0, int_0)
    list_1 = []
    int_1 = -1139
    scalar_token_1 = ScalarToken(list_1, int_1, int_1)
    assert scalar_token_0.__eq__(scalar_token_1)


# Generated at 2022-06-26 10:52:43.224958
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    list_0 = []
    int_0 = -1139
    scalar_token_0 = ScalarToken(list_0, int_0, int_0)

    # Test 1
    if scalar_token_0 == 7:
        raise RuntimeError("AssertionError")

    # Test 2
    if scalar_token_0 == "":
        raise RuntimeError("AssertionError")



# Generated at 2022-06-26 10:52:54.208678
# Unit test for constructor of class DictToken
def test_DictToken():
    list_0 = []
    int_0 = -1139
    scalar_token_0 = ScalarToken(list_0, int_0, int_0)

    dict_0 = {
        'a': scalar_token_0
    }
    int_1 = 178
    int_2 = 382
    dict_token_0 = DictToken(dict_0, int_1, int_2)
    assert str(dict_token_0.string) == "a: []"
    assert dict_token_0.value == {
        'a': []
    }
    assert str(dict_token_0.start) == "(1, 1, 0)"
    assert str(dict_token_0.end) == "(1, 5, 4)"

# Generated at 2022-06-26 10:53:03.737734
# Unit test for constructor of class DictToken
def test_DictToken():
    list_0 = []
    int_0 = -1330
    scalar_token_0 = ScalarToken(list_0, int_0, int_0)

    list_1 = []
    int_1 = -1330
    scalar_token_1 = ScalarToken(list_1, int_1, int_1)

    dict_0 = {}
    dict_0[scalar_token_0] = scalar_token_1
    int_2 = -1330
    str_0 = "{\n  []= []\n}"
    dict_token_0 = DictToken(dict_0, int_2, int_2, str_0)


# Generated at 2022-06-26 10:53:11.279593
# Unit test for constructor of class DictToken
def test_DictToken():
    list_0 = []
    int_0 = -1642
    scalar_token_0 = ScalarToken(list_0, int_0, int_0)
    list_1 = []
    int_1 = -1641
    scalar_token_1 = ScalarToken(list_1, int_1, int_1)
    list_2 = []
    int_2 = -1640
    scalar_token_2 = ScalarToken(list_2, int_2, int_2)
    list_3 = []
    int_3 = -1639
    scalar_token_3 = ScalarToken(list_3, int_3, int_3)
    list_4 = []
    int_4 = -1638

# Generated at 2022-06-26 10:53:22.726390
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    list_0 = []
    int_0 = -1139
    scalar_token_0 = ScalarToken(list_0, int_0, int_0)
    list_1 = []
    int_1 = -1139
    scalar_token_1 = ScalarToken(list_1, int_1, int_1)
    list_2 = ['a', 'b']
    int_2 = -1140
    scalar_token_2 = ScalarToken(list_2, int_2, int_2)
    assert scalar_token_0.__eq__(scalar_token_2) == False
    assert scalar_token_1.__eq__(scalar_token_2) == False
    assert scalar_token_0.__eq__(scalar_token_1) == True

# Generated at 2022-06-26 10:53:32.166985
# Unit test for constructor of class DictToken
def test_DictToken():
    list_0 = []
    int_0 = -1139
    scalar_token_0 = ScalarToken(list_0, int_0, int_0)
    list_1 = []
    int_1 = -1870
    scalar_token_1 = ScalarToken(list_1, int_1, int_1)
    mapping_0 = {scalar_token_0: scalar_token_1}
    int_2 = -1433
    int_3 = -4166
    str_0 = '''blah'''
    dict_token_0 = DictToken(mapping_0, int_2, int_3, str_0)


# Generated at 2022-06-26 10:53:35.572652
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_0 = {}
    int_0 = -2265
    dict_token_0 = DictToken(dict_0, int_0, int_0)


# Generated at 2022-06-26 10:53:41.130158
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    list_0 = []
    int_0 = -1139
    scalar_token_0 = ScalarToken(list_0, int_0, int_0)
    assert scalar_token_0 == scalar_token_0, "Expected: %s, Actual: %s" % (
        scalar_token_0,
        scalar_token_0
    )


# Generated at 2022-06-26 10:53:51.470384
# Unit test for constructor of class DictToken
def test_DictToken():
    # test_case_0
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:53:54.997741
# Unit test for constructor of class DictToken
def test_DictToken():
    _dict_token_0 = DictToken()


# Generated at 2022-06-26 10:53:56.916278
# Unit test for constructor of class DictToken
def test_DictToken():
    assert test_DictToken() == True


# Generated at 2022-06-26 10:53:58.462331
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:07.126313
# Unit test for constructor of class DictToken
def test_DictToken():
    assert repr(DictToken(
        value = {
            ScalarToken(
                value = "foo",
                start_index = 1,
                end_index = 3
            ): ScalarToken(
                value = "bar",
                start_index = 4,
                end_index = 6
            ),
            ScalarToken(
                value = "baz",
                start_index = 7,
                end_index = 9
            ): ScalarToken(
                value = "qux",
                start_index = 10,
                end_index = 12
            )
        },
        start_index = 0,
        end_index = 13
    )) == "(foo: bar, baz: qux)"


# Generated at 2022-06-26 10:54:08.565111
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken()



# Generated at 2022-06-26 10:54:11.770467
# Unit test for constructor of class DictToken
def test_DictToken():
    try:
        dict_token_0 = DictToken()
    except Exception:
        assert False, "Unexpected exception"
    assert True


# Generated at 2022-06-26 10:54:13.901977
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_1 = DictToken(None, None, None, )


# Generated at 2022-06-26 10:54:15.344986
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken() # NOQA


# Generated at 2022-06-26 10:54:17.802483
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0 is not None, "object should not be None"



# Generated at 2022-06-26 10:54:41.111810
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0._get_value() == {}, "'dict_token_0._get_value()' expected {}"


# Generated at 2022-06-26 10:54:45.353616
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, Token)
    assert isinstance(dict_token_0, ScalarToken)
    assert isinstance(dict_token_0, DictToken)
    test_case_0()


# Generated at 2022-06-26 10:54:48.651075
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken(1, 2, content=__name__)
    print(repr(dict_token_0))

if __name__ == "__main__":
    test_case_0()
    test_DictToken()

# Generated at 2022-06-26 10:54:50.676448
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:51.953028
# Unit test for constructor of class DictToken
def test_DictToken():
    assert type(test_case_0()) == DictToken
    


# Generated at 2022-06-26 10:54:53.201677
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:54:54.702457
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()



# Generated at 2022-06-26 10:54:55.874359
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:56.998188
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = test_case_0()


# Generated at 2022-06-26 10:54:59.179019
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:55:14.594654
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    def test_case_0():
        dict_token_0 = DictToken()


# Generated at 2022-06-26 10:55:18.055223
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0
    assert isinstance(dict_token_0, DictToken)
    assert isinstance(dict_token_0, Token)


# Generated at 2022-06-26 10:55:19.047232
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()

# Generated at 2022-06-26 10:55:22.709741
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken(None, 0, 0)
    assert dict_token_0 is not None


# Generated at 2022-06-26 10:55:25.438322
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert (type(dict_token_0) == DictToken)


# Generated at 2022-06-26 10:55:28.917829
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:55:30.076072
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 10:55:33.722050
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert repr(dict_token_0) == 'DictToken()'
    assert not dict_token_0 == dict_token_0
    dict_token_1 = DictToken()
    assert dict_token_0 == dict_token_1


# Generated at 2022-06-26 10:55:34.969017
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:55:37.217011
# Unit test for constructor of class DictToken
def test_DictToken():
    with pytest.raises(TypeError) as excinfo:
        test_case_0()
    the_exception = excinfo.value
    assert "TypeError" in str(the_exception)


# Generated at 2022-06-26 10:56:03.756859
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken(
        {}, 0, 0, {}
    )


# Generated at 2022-06-26 10:56:07.044621
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:56:09.070895
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken({})
    dict_token_1 = DictToken({})

# Generated at 2022-06-26 10:56:10.748945
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:56:15.795357
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken({}, start_index=3, end_index=2, content="")
    assert dict_token.value == {}
    assert dict_token.start == Position(1, 1, 3)
    assert dict_token.end == Position(1, 1, 2)
    assert dict_token.string == ""
    assert dict_token.lookup([]) == dict_token

# Unit  test for constructor of class ListToken

# Generated at 2022-06-26 10:56:22.016470
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken(1, 2, content='abc', start_index=2)
    assert repr(dict_token_0) == "DictToken('')"
    assert dict_token_0.string == ""
    assert dict_token_0.start == Position(1, 1, 2)
    assert dict_token_0.end == Position(1, 1, 2)
    assert dict_token_0.value == {}
    assert dict_token_0.lookup([]) == dict_token_0
    dict_token_0.string
    dict_token_0.value
    dict_token_0.start
    dict_token_0.end
    dict_token_0.lookup([])

# Generated at 2022-06-26 10:56:23.409056
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:56:25.538672
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:56:28.348032
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:56:41.740484
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    def test_case_1():
        dict_token_0 = DictToken()
    def test_case_2():
        dict_token_1 = DictToken()
        dict_token_1._get_value()
    def test_case_3():
        dict_token_2 = DictToken()
        dict_token_2._get_child_token()
    def test_case_4():
        dict_token_3 = DictToken()
        dict_token_3._get_key_token()
    def test_case_5():
        dict_token_4 = DictToken()
        def foo(arg):
            dict_token_4.lookup(arg)
        foo('')

# Generated at 2022-06-26 10:57:22.963266
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_1 = DictToken()
    assert dict_token_1
    assert dict_token_1._value
    assert isinstance(dict_token_1._value, list)
    assert not dict_token_1._value


# Generated at 2022-06-26 10:57:24.560379
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:57:25.813933
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:57:30.599948
# Unit test for constructor of class DictToken
def test_DictToken():
    from typesystem.base import Token
    from typesystem.token import DictToken
    D = DictToken
    assert isinstance(D().value, dict)
    assert isinstance(D().value, Token)
    assert isinstance(D().start, Position)
    assert isinstance(D().end, Position)
test_DictToken()


# Generated at 2022-06-26 10:57:36.524817
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_2 = DictToken()
    try:
        # Line 186
        assert isinstance(dict_token_2, DictToken) == True, 'Line 186'
    except AssertionError:
        print('Line 186')
        raise


# Generated at 2022-06-26 10:57:39.211860
# Unit test for constructor of class DictToken
def test_DictToken():
    if test_DictToken.__name__ == "__main__":
        test_case_0()
# EOF



# Generated at 2022-06-26 10:57:41.199241
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_0.__init__()


# Generated at 2022-06-26 10:57:48.817938
# Unit test for constructor of class DictToken
def test_DictToken():
    # Testing if get_value() will return {}(which is the corresponding value of an instance of DictToken)
    #   when an instance of DictToken is created(without passing any arguments)
    # instance variable _value is a dictionary
    assert test_case_0._value == {}
    # instance variable _child_keys is a dictionary
    assert test_case_0._child_keys == {}
    # instance variable _child_tokens is a dictionary
    assert test_case_0._child_tokens == {}


# Generated at 2022-06-26 10:57:54.749459
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken({}) == DictToken({})
    assert DictToken({}, 1, 2) == DictToken({}, 1, 2)
    assert DictToken({}, start_index=1) == DictToken({}, start_index=1)
    assert DictToken({}, end_index=2) == DictToken({}, end_index=2)
    assert DictToken({}, content="") == DictToken({}, content="")
    assert DictToken(
        {}, start_index=1, end_index=2, content=""
    ) == DictToken({}, start_index=1, end_index=2, content="")


# Generated at 2022-06-26 10:58:01.341329
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert repr(dict_token_0) == "DictToken({})"
    assert dict_token_0.string == "{}"
    assert dict_token_0.start == Position(1, 1, 0)
    assert dict_token_0.end == Position(1, 2, 1)
    pass_assert(dict_token_0, {})



# Generated at 2022-06-26 10:58:45.697960
# Unit test for constructor of class DictToken
def test_DictToken():
    print('Test constructor of class DictToken')
    test_case_0()
    print('Success!')


# Generated at 2022-06-26 10:58:50.035413
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0._child_keys == {}
    assert dict_token_0._child_tokens == {}


# Generated at 2022-06-26 10:58:53.796732
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert dict_token_0 == dict_token_1


# Generated at 2022-06-26 10:58:55.967597
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0 is not None



# Generated at 2022-06-26 10:58:57.053788
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 10:58:57.927585
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken()


# Generated at 2022-06-26 10:58:59.246466
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:59:01.471183
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

test_DictToken()

# Generated at 2022-06-26 10:59:06.722231
# Unit test for constructor of class DictToken
def test_DictToken():
    # List of all errors and warnings collected by typer
    typer = Typer()

    def test_case_0():
        dict_token_0 = DictToken()

    test_case_0()


# Generated at 2022-06-26 10:59:08.416930
# Unit test for constructor of class DictToken
def test_DictToken():
    print("test_DictToken")
    test_case_0()

# Generated at 2022-06-26 11:00:40.024156
# Unit test for constructor of class DictToken
def test_DictToken():
    assert isinstance(DictToken(), DictToken)


# Generated at 2022-06-26 11:00:41.890360
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:00:43.228275
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    

# Generated at 2022-06-26 11:00:47.268108
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0._value is None
    assert dict_token_0._start_index == 0
    assert dict_token_0._end_index == 0
    assert dict_token_0.lookup([1]) is None
    assert dict_token_0.lookup_key([1]) is None


# Generated at 2022-06-26 11:00:48.865788
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:00:49.739778
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken()


# Generated at 2022-06-26 11:00:55.221206
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, Token)
    assert isinstance(dict_token_0, DictToken)


# Generated at 2022-06-26 11:00:56.647764
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test initialization from constructor
    assert DictToken() != None


# Generated at 2022-06-26 11:00:58.095771
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0 is not None


# Generated at 2022-06-26 11:00:58.973450
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken()
