

# Generated at 2022-06-26 10:52:31.649627
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    int_0 = 2
    str_0 = "b"
    int_1 = 3
    str_1 = "d"
    int_2 = 4
    str_2 = "c"
    int_3 = 5
    str_3 = "e"
    int_4 = 6
    str_4 = "f"
    int_5 = 7
    str_5 = "a"
    int_6 = 8
    str_6 = "h"
    int_7 = 9
    str_7 = "g"
    int_8 = 10
    str_8 = "i"
    int_9 = 11
    str_9 = "j"
    token_0 = dict_token_0

# Generated at 2022-06-26 10:52:36.136281
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    int_0 = 2
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert not (dict_token_0 == dict_token_1)

# Generated at 2022-06-26 10:52:42.839062
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = 2
    list_token_0 = ListToken()
    dict_token_0 = DictToken()
    dict_token_1 = DictToken(dict_token_0)
    assert isinstance(dict_token_1, DictToken)
    assert dict_token_1._start_index == dict_token_0._start_index
    assert dict_token_1._end_index == dict_token_0._end_index
    assert dict_token_1._content == dict_token_0._content


# Generated at 2022-06-26 10:52:45.378365
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = 2
    dict_token_0 = DictToken()
    assert dict_token_0


# Generated at 2022-06-26 10:52:48.302400
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = 2
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:52:52.255627
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    class_name_0 = dict_token_0.__class__.__name__
    assert class_name_0 == 'DictToken', 'Failed at line 14, expect class_name_0 == "DictToken", actual: ' + class_name_0

# Generated at 2022-06-26 10:52:56.720883
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = 2
    dict_token_0 = DictToken()
    # TESTCASE 1:
    dict_token_0 = DictToken()
    # TESTCASE 2:
    dict_token_0 = DictToken()

# Generated at 2022-06-26 10:52:58.539858
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = 2
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:53:00.325766
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = 2
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:53:04.491120
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    int_0 = 2
    dict_token_0 = DictToken()
    bool_0 = dict_token_0 == dict_token_0
    assert bool_0
    list_token_0 = ListToken()
    assert dict_token_0 != list_token_0


# Generated at 2022-06-26 10:53:11.583521
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:53:16.755078
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = ScalarToken()
    dict_token_2 = ScalarToken()
    assert not(dict_token_0 == dict_token_1)
    assert dict_token_1 == dict_token_2


# Generated at 2022-06-26 10:53:20.620728
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token_0 = ScalarToken(value=True, start_index=1, end_index=5)
    token_1 = ScalarToken(value=True, start_index=2, end_index=5)



# Generated at 2022-06-26 10:53:22.725998
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert hasattr(dict_token_0, "_value")


# Generated at 2022-06-26 10:53:27.227398
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_1 = DictToken(dict())
    dict_token_2 = DictToken(dict(), 0, 0)
    dict_token_3 = DictToken(dict(), 0, 0, "")



# Generated at 2022-06-26 10:53:28.214992
# Unit test for constructor of class DictToken
def test_DictToken():
    pass # TODO


# Generated at 2022-06-26 10:53:31.634085
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    assert dict_token_0 == dict_token_0


# Generated at 2022-06-26 10:53:42.390392
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken()
    dict_token = DictToken(value = {}, start_index = 0, end_index = 0, content = "")
    dict_token = DictToken(value = {}, start_index = 0, end_index = 0)
    dict_token = DictToken(value = {}, start_index = 0)
    dict_token = DictToken(value = {})
    dict_token = DictToken(value = {})
    dict_token = DictToken(start_index = 0, end_index = 0, content = "")
    dict_token = DictToken(start_index = 0, end_index = 0)
    dict_token = DictToken(start_index = 0)
    dict_token = DictToken(start_index = 0)

# Generated at 2022-06-26 10:53:44.258587
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:53:45.387610
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    test_case_0()


# Generated at 2022-06-26 10:53:57.559912
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    bool_0 = dict_token_0 == dict_token_1
    assert bool_0



# Generated at 2022-06-26 10:54:00.526976
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, DictToken)
    assert isinstance(dict_token_0, Token)


# Generated at 2022-06-26 10:54:05.140146
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken({"key_0": ScalarToken(5, 0, 1)}, 5, 6)
    assert dict_token_0 == dict_token_0
    dict_token_1 = DictToken({"key_0": ScalarToken(5, 0, 1)}, 5, 6)
    assert dict_token_0 == dict_token_1



# Generated at 2022-06-26 10:54:07.255544
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:10.018337
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token = DictToken({}, 0, 9, content="abc")
    assert dict_token == dict_token


# Generated at 2022-06-26 10:54:12.385852
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    assert True, "Expected True, but got %s" % str(True)


# Generated at 2022-06-26 10:54:15.874090
# Unit test for method __eq__ of class Token
def test_Token___eq__():
	dict_token_0 = DictToken()
	token_0 = DictToken()
	assert token_0 == token_0
	assert dict_token_0 != token_0


# Generated at 2022-06-26 10:54:19.258143
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()

    assert dict_token_0.__eq__(dict_token_1)


# Generated at 2022-06-26 10:54:20.627672
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()

# Generated at 2022-06-26 10:54:21.923090
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    token = Token()
    assert token == token


# Generated at 2022-06-26 10:54:37.976747
# Unit test for method __eq__ of class Token
def test_Token___eq__():

    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert dict_token_0 == dict_token_1


# Generated at 2022-06-26 10:54:42.288535
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    scalar_token_0 = ScalarToken()
    scalar_token_1 = ScalarToken()
    scalar_token_0.__eq__(scalar_token_1) == scalar_token_1.__eq__(scalar_token_0)


# Generated at 2022-06-26 10:54:53.115533
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    dict_token_2 = DictToken()
    dict_token_3 = DictToken()
    dict_token_4 = DictToken()
    dict_token_5 = DictToken()
    dict_token_6 = DictToken()
    dict_token_7 = DictToken()
    dict_token_8 = DictToken()
    dict_token_9 = DictToken()
    dict_token_10 = DictToken()
    dict_token_11 = DictToken()
    dict_token_12 = DictToken()
    dict_token_13 = DictToken()
    dict_token_14 = DictToken()
    dict_token_15 = DictToken()

# Generated at 2022-06-26 10:54:54.212072
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_1 = DictToken()


# Generated at 2022-06-26 10:54:55.706595
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:56.832449
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:55:07.864712
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    assert dict_token_0.__eq__(None) == False
    assert classmethod(dict_token_0.__eq__)(None) == False
    assert dict_token_0.__eq__(False) == False
    dict_token_0 = DictToken()
    dict_token_0.__eq__(True)
    dict_token_0 = DictToken()
    assert dict_token_0 is not None
    dict_token_0 = DictToken()
    dict_token_0.__eq__("")
    dict_token_0 = DictToken()
    assert dict_token_0 == dict_token_0
    dict_token_0 = DictToken()
    dict_token_0.__eq__(dict_token_0)
    dict_

# Generated at 2022-06-26 10:55:10.131254
# Unit test for constructor of class DictToken
def test_DictToken():
    # Two different arguments
    assert isinstance(DictToken(dict_token_0, 0, 5, ''), Token)

# Unit tests for methods of class DictToken

# Generated at 2022-06-26 10:55:13.137241
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()

    # __eq__ returns NotImplemented
    assert dict_token_0.__eq__(dict_token_1) == NotImplemented


# Generated at 2022-06-26 10:55:19.220253
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, DictToken)
    assert isinstance(dict_token_0, Token)
    assert not hasattr(dict_token_0, '_value')
    assert not hasattr(dict_token_0, '_child_keys')
    assert not hasattr(dict_token_0, '_child_tokens')


# Generated at 2022-06-26 10:55:36.772098
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()

# Generated at 2022-06-26 10:55:41.528543
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken({"hello": "world"})
    assert repr(dict_token_0) == "DictToken({'hello': 'world'})"


# Generated at 2022-06-26 10:55:50.420513
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_0_0 = dict_token_0._get_child_token(None)
    assert dict_token_0._get_value() == dict_token_0_0._get_value()
    assert dict_token_0._start_index == dict_token_0_0._start_index
    assert dict_token_0._end_index == dict_token_0_0._end_index
    dict_token_0_1 = dict_token_0._get_child_token(None)
    dict_token_0_2 = dict_token_0._get_child_token(None)
    dict_token_0_3 = dict_token_0._get_child_token(None)
    dict_token_0_4 = dict_token_0._get_

# Generated at 2022-06-26 10:55:52.381990
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:55:58.840502
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_1 = DictToken()
    dict_token_2 = DictToken(dict_token_1._value, dict_token_1._start_index, dict_token_1._end_index, dict_token_1._content)
    assert dict_token_2 == dict_token_1


# Generated at 2022-06-26 10:56:00.293419
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:56:01.889514
# Unit test for constructor of class DictToken
def test_DictToken():
    instance = DictToken()


if __name__ == "__main__" :
    test_DictToken()

# Generated at 2022-06-26 10:56:04.170320
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    str_0 = str()
    Token.__eq__(dict_token_0, str_0)


# Generated at 2022-06-26 10:56:13.384163
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    str_0 = str()
    str_1 = str()

    # Call Token.__eq__(dict_token_0, str_0)
    try:
        bool_0 = Token.__eq__(dict_token_0, str_0)
        assert False
    except NotImplementedError:
        assert True

    # Call Token.__eq__(dict_token_0, str_1)
    try:
        bool_1 = Token.__eq__(dict_token_0, str_1)
        assert False
    except NotImplementedError:
        assert True


# Generated at 2022-06-26 10:56:14.823401
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Case A: Inputs are invalid.
    assert_not_equal()


# Generated at 2022-06-26 10:56:31.818586
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert repr(dict_token_0) == "DictToken({})"
    assert dict_token_0._get_value() == {}
    assert dict_token_0.lookup([]) == dict_token_0


# Generated at 2022-06-26 10:56:44.771253
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    dict_token_2 = DictToken()
    dict_token_3 = DictToken()
    dict_token_4 = DictToken()
    dict_token_5 = DictToken()
    dict_token_6 = DictToken()
    dict_token_7 = DictToken()
    dict_token_8 = DictToken()
    list_token_0 = ListToken()
    list_token_1 = ListToken()
    list_token_2 = ListToken()
    list_token_3 = ListToken()
    list_token_4 = ListToken()
    list_token_5 = ListToken()
    list_token_6 = ListToken()
    list_token_7 = ListToken()
    list_

# Generated at 2022-06-26 10:56:45.740096
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:56:54.036064
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    token_0 = Token(dict_token_0, 0, 80, "")
    dict_token_1 = DictToken()
    token_1 = Token(dict_token_1, 0, 0, "")
    Token.__eq__(token_0, token_1)
    dict_token_2 = DictToken()
    token_2 = Token(dict_token_2, 0, 0, "")
    Token.__eq__(token_0, token_2)


# Generated at 2022-06-26 10:57:04.893659
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Set up objects for method __eq__ of class Token
    token_0 = ScalarToken(123, 0, 3, "123")
    token_1 = ScalarToken(123, 0, 4, "123")
    token_2 = ScalarToken(12, 0, 2, "123")
    token_3 = ScalarToken(123, 0, 3, "123")
    # Test method __eq__ of class Token
    assert token_0.__eq__(token_0) == True
    assert token_1.__eq__(token_1) == True
    assert token_2.__eq__(token_2) == True
    assert token_3.__eq__(token_3) == True
    assert token_0.__eq__(token_1) == False

# Generated at 2022-06-26 10:57:06.926019
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    assert dict_token_0 == dict_token_0

# Generated at 2022-06-26 10:57:10.682350
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert (dict_token_0._start_index == 0)
    assert (dict_token_0._end_index == 0)
    assert (dict_token_0._content == '')

# Generated at 2022-06-26 10:57:12.349123
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken(dict_token_0, 0, 4)



# Generated at 2022-06-26 10:57:15.883959
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = dict_token_0
    assert dict_token_0 == dict_token_1


# Generated at 2022-06-26 10:57:19.453193
# Unit test for constructor of class DictToken
def test_DictToken():
    token_0 = DictToken()
    assert token_0._value == {}
    assert token_0._child_keys == {}
    assert token_0._child_tokens == {}


# Generated at 2022-06-26 10:57:46.070854
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:57:53.883576
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test case where self._get_value() does not equal other._get_value()
    token_0 = Token(0, 0, 0)
    token_1 = Token(1, 1, 1)
    result_0 = token_0.__eq__(token_1)
    assert(result_0 == False)

    # Test case where self._start_index does not equal other._start_index
    result_1 = token_0.__eq__(token_0)
    assert(result_1 == True)

    # Test case where self._end_index does not equal other._end_index
    result_2 = token_0.__eq__(token_0)
    assert(result_2 == True)


# Generated at 2022-06-26 10:57:55.655701
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0 == DictToken()
    return None

# Generated at 2022-06-26 10:57:57.921105
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

    print(dict_token_0)



# Generated at 2022-06-26 10:58:01.135131
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_1 = DictToken()
    assert repr(dict_token_1) == "DictToken({})", "Test failed"



# Generated at 2022-06-26 10:58:02.353253
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:58:03.522814
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:58:05.704489
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:58:10.572683
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    dict_token_2 = Token()
    assert dict_token_1.__eq__(dict_token_0)
    assert dict_token_0.__eq__(dict_token_1)
    assert not dict_token_1.__eq__(dict_token_2)


# Generated at 2022-06-26 10:58:12.087631
# Unit test for constructor of class DictToken
def test_DictToken():
    print('Testing dector of class DictToken')
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:58:41.166717
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0._value == dict_token_0._child_tokens


# Generated at 2022-06-26 10:58:43.698418
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    # asserts check that no errors are thrown
    assert True


# Generated at 2022-06-26 10:58:45.914454
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, DictToken)


# Generated at 2022-06-26 10:58:46.816166
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:58:51.659638
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

# Method test

# Generated at 2022-06-26 10:58:54.442571
# Unit test for constructor of class DictToken
def test_DictToken():
    print("Testing __init__ of class DictToken")
    test_case_0()
    print("Class DictToken has been tested successfully")


# Generated at 2022-06-26 10:58:56.415486
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:59:04.210231
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0._get_value() == {}, "The '_get_value' method of 'DictToken' did not return a valid value"
    assert dict_token_0.__dict__ == {'_child_keys': {}, '_child_tokens': {}, '_value': {}, '_content': '', '_start_index': 0, '_end_index': 0}, 'The __dict__ method of \'DictToken\' did not return a valid value'
    assert dict_token_0.string == '', "The 'string' property of 'DictToken' did not return a valid value"
    assert dict_token_0.value == {}, "The 'value' property of 'DictToken' did not return a valid value"
    assert dict_token_

# Generated at 2022-06-26 10:59:09.390862
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken();
    dict_token_1 = DictToken();
    assert dict_token_0 != dict_token_1


# Generated at 2022-06-26 10:59:17.938524
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0.lookup([]) == dict_token_0
    dict_token_0 = DictToken()
    assert dict_token_0.lookup_key([]) == dict_token_0
    dict_token_0 = DictToken()
    assert dict_token_0.value == {}
    dict_token_0 = DictToken()
    assert dict_token_0.value == {}
    dict_token_0 = DictToken()
    assert dict_token_0.start == Position(1, 1, 0)
    dict_token_0 = DictToken()
    assert dict_token_0.end == Position(1, 1, 0)
    dict_token_0 = DictToken()
    assert dict_token_0._start_index == 0

# Generated at 2022-06-26 11:00:00.828647
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:00:10.454202
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken(dict(), 0, 1, )
    assert isinstance(dict_token_0, DictToken)
    # testing __eq__ method of class DictToken
    assert dict_token_0 == DictToken(dict(), 0, 1, )
    assert not (dict_token_0 != DictToken(dict(), 0, 1, ))
    # testing __hash__ method of class DictToken
    assert hash(DictToken(dict(), 0, 1, )) != 0
    # testing __repr__ method of class DictToken
    str_0: str = "DictToken({})"
    assert repr(DictToken(dict(), 0, 1, )) == str_0
    # testing __str__ method of class DictToken
    str_0: str = "DictToken({})"
   

# Generated at 2022-06-26 11:00:13.395049
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, DictToken)



# Generated at 2022-06-26 11:00:15.386986
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test 1
    dict_token_0 = DictToken()
    # End of test 1
    # End of test case 0



# Generated at 2022-06-26 11:00:26.316288
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken(1, 1, 1)
    assert dict_token_0.start == Position(1, 1, 1)

    dict_token_1 = DictToken("s", 0, 4, "abcde")
    assert dict_token_1.end == Position(1, 5, 4)

    dict_token_2 = DictToken(0.0, 1, 3, "abcde")
    assert dict_token_2.value == 0.0

    dict_token_3 = DictToken(9.9, 0, 4, "abcde")
    assert dict_token_3.string == "e"

    dict_token_4 = DictToken(dict(), 1, 2)
    assert dict_token_4.start == Position(1, 1, 1)

    dict_token_5 = D

# Generated at 2022-06-26 11:00:27.805571
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert(dict_token_0.value == {})


# Generated at 2022-06-26 11:00:32.438231
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, Token)
    assert not hasattr(dict_token_0, "value")
    assert not hasattr(dict_token_0, "start")
    assert not hasattr(dict_token_0, "end")
    assert not hasattr(dict_token_0, "string")


# Generated at 2022-06-26 11:00:33.649130
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:00:35.466529
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:00:37.571004
# Unit test for constructor of class DictToken
def test_DictToken():
    try:
        dict_token_0 = DictToken()
    except Exception as e:
        print("Exception: {}".format(str(e)))
        

# Generated at 2022-06-26 11:01:56.866204
# Unit test for constructor of class DictToken
def test_DictToken():
    # Setup
    dict_token_0 = DictToken()



# Generated at 2022-06-26 11:01:58.247811
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 11:02:01.176357
# Unit test for constructor of class DictToken
def test_DictToken():
    final_value = {}
    dict_token_0 = DictToken(final_value, 0, 0, "")


# Generated at 2022-06-26 11:02:01.997496
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:02:03.139012
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:02:05.962114
# Unit test for constructor of class DictToken
def test_DictToken():
    foo = DictToken(1, 1, 0, {})
    assert foo is not None


# Generated at 2022-06-26 11:02:07.133376
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:02:08.819556
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:02:10.445656
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:02:11.627237
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
