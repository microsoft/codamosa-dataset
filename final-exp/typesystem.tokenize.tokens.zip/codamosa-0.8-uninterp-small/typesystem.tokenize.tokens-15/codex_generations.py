

# Generated at 2022-06-26 10:52:31.161146
# Unit test for constructor of class DictToken
def test_DictToken():
    bool_0 = True
    int_0 = 2030
    scalar_token_0 = ScalarToken(bool_0, int_0, int_0)
    scalar_token_1 = ScalarToken(bool_0, int_0, int_0)
    scalar_token_2 = ScalarToken(bool_0, int_0, int_0)
    list_token_0 = ListToken(scalar_token_0, int_0, int_0)
    list_token_1 = ListToken(scalar_token_1, int_0, int_0)
    list_token_2 = ListToken(scalar_token_2, int_0, int_0)
    bool_1 = True
    bool_2 = True
    int_1 = 2030
    int_2 = 2030
   

# Generated at 2022-06-26 10:52:42.645269
# Unit test for constructor of class DictToken
def test_DictToken():
    bool_0 = True
    int_0 = 2030
    Token_0 = ScalarToken(bool_0, int_0, int_0)
    bool_1 = True
    int_1 = 2030
    Token_1 = ScalarToken(bool_1, int_1, int_1)
    dict_0 = {
        Token_0: Token_1
    }
    dict_token_0 = DictToken(dict_0, int_0, int_0)
    assert dict_token_0.start == Position(1, 1, 2030)
    assert dict_token_0.end == Position(1, 1, 2030)
    assert dict_token_0.value == {
        True: True
    }
    assert dict_token_0.string == "{}"


# Generated at 2022-06-26 10:52:48.443423
# Unit test for constructor of class DictToken
def test_DictToken():
    bool_0 = True
    int_0 = 2030
    scalar_token_0 = ScalarToken(bool_0, int_0, int_0)
    dict_token_0 = DictToken(dict({"key_01": scalar_token_0}), int_0, int_0)


# Generated at 2022-06-26 10:52:50.540464
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_0 = {}
    dict_token_0 = DictToken(dict_0, 0, 0)


# Generated at 2022-06-26 10:52:55.511913
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    bool_0 = True
    int_0 = 2030
    scalar_token_0 = ScalarToken(bool_0, int_0, int_0)
    scalar_token_1 = ScalarToken(bool_0, int_0, int_0)
    token_0 = Token(scalar_token_0, int_0, int_0)
    token_1 = Token(scalar_token_1, int_0, int_0)


# Generated at 2022-06-26 10:53:01.187008
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    bool_0 = True
    int_0 = 2030
    scalar_token_0 = ScalarToken(bool_0, int_0, int_0)
    bool_1 = True
    int_1 = 2030
    scalar_token_1 = ScalarToken(bool_1, int_1, int_1)
    assert scalar_token_0 == scalar_token_1



# Generated at 2022-06-26 10:53:06.303329
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    bool_0 = True
    int_0 = 2030
    scalar_token_0 = ScalarToken(bool_0, int_0, int_0)
    bool_1 = True
    int_1 = 2030
    scalar_token_1 = ScalarToken(bool_1, int_1, int_1)

    assert scalar_token_0 == scalar_token_1


# Generated at 2022-06-26 10:53:08.732171
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = 0
    int_1 = 1
    str_0 = "11"
    x = DictToken(int_0, int_1, str_0)


# Generated at 2022-06-26 10:53:17.286998
# Unit test for constructor of class DictToken
def test_DictToken():
    content = ""
    start_index = 0
    end_index = 0
    bool_0 = True
    int_0 = 2030
    token_0 = ScalarToken(bool_0, int_0, int_0, content)
    int_1 = 2030
    token_1 = ScalarToken(bool_0, int_1, int_1, content)
    dict_token_0 = DictToken({token_0: token_1}, start_index, end_index, content)


# Generated at 2022-06-26 10:53:22.909331
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Setup
    str_0 = "A"
    int_0 = 2025
    int_1 = 2026
    str_1 = "B"
    str_2 = "A"
    int_2 = 2025
    int_3 = 2026
    # Comparison
    assert ((str_0, int_0, int_1) != (str_1, int_2, int_3)) == True


# Generated at 2022-06-26 10:53:30.072021
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    int_0 = 0
    float_0 = 0.0
    int_1 = 1
    dict_0 = {}

# Generated at 2022-06-26 10:53:41.769662
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    # Test when both argument and parameter is null
    try:
        obj_0 = Token()
        Token.__eq__(obj_0, None)
    except:
        assert False
    else:
        assert True
    # Test when argument is null and parameter is not null
    obj_0 = Token()

# Generated at 2022-06-26 10:53:43.672683
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    var_0 = {}
    int_0 = 0


# Generated at 2022-06-26 10:53:55.422530
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    var_0 = ScalarToken(0, 0, 1)
    var_1 = ScalarToken(0, 0, 1)
    var_2 = ScalarToken(1, 0, 1)
    var_3 = ScalarToken(1, 0, 1)

    val_0 = var_0.__eq__(var_1)
    val_1 = var_0.__eq__(var_2)
    val_2 = var_2.__eq__(var_0)
    val_3 = var_2.__eq__(var_3)

    assert val_0
    assert not val_1
    assert not val_2
    assert val_3


# Generated at 2022-06-26 10:54:01.215923
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    var_1 = Token(int(0), 0, 0)
    var_2 = Token(int(0), 0, 0)
    var_3 = Token(int(1), 1, 1)
    assert (var_1 == var_2) == True
    assert (var_1 == var_3) == False


# Generated at 2022-06-26 10:54:02.865539
# Unit test for constructor of class DictToken
def test_DictToken():
    var_0 = {}
    int_0 = 0
    test_case_0()


# Generated at 2022-06-26 10:54:04.459259
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    var_0 = test_case_0()
    assert var_0 == var_0


# Generated at 2022-06-26 10:54:08.378684
# Unit test for constructor of class DictToken
def test_DictToken():
    # Calling the constructor of the class
    var_0 = {}
    int_0 = 0
    # Calling the constructor of the class


# Generated at 2022-06-26 10:54:11.321081
# Unit test for constructor of class DictToken
def test_DictToken():
    var_0 = {}
    int_0 = 0
    DictToken(var_0, int_0, int_0, var_0)

# Generated at 2022-06-26 10:54:12.511889
# Unit test for constructor of class DictToken
def test_DictToken():
    var_0 = DictToken({}, 0, 0)
    return


# Generated at 2022-06-26 10:54:19.941727
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:21.835597
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0._value == {}

# Generated at 2022-06-26 10:54:23.077173
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:25.106446
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:27.312452
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0._get_value() == {}


# Generated at 2022-06-26 10:54:29.320080
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, DictToken)


# Generated at 2022-06-26 10:54:31.954911
# Unit test for constructor of class DictToken
def test_DictToken():
    try:
        dict_token_0 = DictToken()
    except:
        print('Exception caught: ', sys.exc_info()[0])


# Generated at 2022-06-26 10:54:33.372953
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:34.212037
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:54:35.119078
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:51.503911
# Unit test for constructor of class DictToken
def test_DictToken():
    # Positional arguments tests
    try:
        DictToken()
    except TypeError:
        pass
    else:
        raise Exception("Expected TypeError for invalid positional arguments")

    # Keyword arguments tests
    # Invalid keyword argument 'value' for DictToken
    # Type of argument = <class 'str'>, argument number = 5
    # Type of parameter = <class 'typing.Dict'>
    try:
        DictToken(value="test")
    except TypeError:
        pass
    else:
        raise Exception(
            "Expected TypeError for invalid keyword argument value for constructor of DictToken"
        )

    # Invalid keyword argument 'start_index' for DictToken
    # Type of argument = <class 'str'>, argument number = 6
    # Type of parameter = <class 'int'>

# Generated at 2022-06-26 10:54:52.430734
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 10:54:53.660944
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:54:54.197373
# Unit test for constructor of class DictToken

# Generated at 2022-06-26 10:54:55.306462
# Unit test for constructor of class DictToken
def test_DictToken():
    # Constructor test 1, normal case
    test_case_0()



# Generated at 2022-06-26 10:54:57.075787
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken()
    assert repr(dict_token) == "DictToken({})"


# Generated at 2022-06-26 10:55:00.108740
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken(value = {}, start_index = 0, end_index = 0)
    assert dict_token


# Generated at 2022-06-26 10:55:02.317898
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test initializer values
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:55:03.714422
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 10:55:04.877205
# Unit test for constructor of class DictToken
def test_DictToken():
    assert test_case_0() is None


# Generated at 2022-06-26 10:55:17.427660
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    print(dict_token_0)


# Generated at 2022-06-26 10:55:18.393062
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 10:55:19.650714
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

# Generated at 2022-06-26 10:55:22.266560
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken()

# Generated at 2022-06-26 10:55:24.195528
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_1 = DictToken()



# Generated at 2022-06-26 10:55:25.999535
# Unit test for constructor of class DictToken
def test_DictToken():
    assert hasattr(DictToken, '__init__')


# Generated at 2022-06-26 10:55:29.467370
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:55:30.418281
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

# Generated at 2022-06-26 10:55:31.652275
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:55:33.231380
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0 is not None



# Generated at 2022-06-26 10:56:20.681567
# Unit test for constructor of class DictToken
def test_DictToken():
    assert test_case_0()

# Generated at 2022-06-26 10:56:21.877782
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 10:56:24.831306
# Unit test for constructor of class DictToken
def test_DictToken():
    import DictToken as test_class
    tester = test_class.DictToken()
    return tester


# Generated at 2022-06-26 10:56:28.181486
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:56:30.008828
# Unit test for constructor of class DictToken
def test_DictToken():
    print("Constructor DictToken")
    test_case_0()



# Generated at 2022-06-26 10:56:33.345784
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, Token)
    assert isinstance(dict_token_0, DictToken)


# Generated at 2022-06-26 10:56:35.226553
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0 is not None


# Generated at 2022-06-26 10:56:47.564629
# Unit test for constructor of class DictToken
def test_DictToken():
    token = Token(1, 2, 3)
    dict_token = DictToken(token, 4, 5)
    assert dict_token._content == ""
    assert dict_token._start_index == 4
    assert dict_token._end_index == 5
    assert dict_token._child_keys == {}
    assert dict_token._child_tokens == {}
    assert dict_token._value == token
    assert dict_token._get_value() == token._get_value()
    assert dict_token.string == ""
    assert dict_token.value == token._get_value()
    assert dict_token.start == Position(1, 5, 4)
    assert dict_token.end == Position(1, 6, 5)


# Generated at 2022-06-26 10:56:49.918707
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:56:50.871529
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()

# Generated at 2022-06-26 10:57:28.544376
# Unit test for constructor of class DictToken
def test_DictToken():
    assert (DictToken()._value == {})


# Generated at 2022-06-26 10:57:42.136896
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken()
    assert isinstance(token, DictToken)
    assert isinstance(token, Token)
    assert not isinstance(token, ScalarToken)
    assert not isinstance(token, ListToken)
    assert token.__dict__ == {'_value': {}, '_content': '', '_start_index': 0, '_end_index': 0, '_child_keys': {}, '_child_tokens': {}}
    assert token._content == ''
    assert token._start_index == 0
    assert token._end_index == 0
    assert token._get_position(0) == Position(1, 1, 0)
    assert token._get_position(1) == Position(1, 2, 1)
    assert token._get_position(2) == Position(1, 3, 2)


# Generated at 2022-06-26 10:57:51.931088
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    assert dict_token_0 == dict_token_1
    dict_token_2 = DictToken()
    dict_token_3 = DictToken()
    assert dict_token_2 == dict_token_3
    dict_token_4 = DictToken()
    dict_token_5 = DictToken()
    assert dict_token_4 == dict_token_5
    dict_token_6 = DictToken()
    dict_token_7 = DictToken()
    assert dict_token_6 == dict_token_7
    dict_token_8 = DictToken()
    dict_token_9 = DictToken()
    assert dict_token_8 == dict_token_9
    dict_token_10 = Dict

# Generated at 2022-06-26 10:57:54.016734
# Unit test for constructor of class DictToken
def test_DictToken():    
    assert type(DictToken) == type
    assert type(DictToken()) == DictToken
    print('test_DictToken() passed.')


# Generated at 2022-06-26 10:57:56.095190
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

    assert isinstance(dict_token_0, DictToken)



# Generated at 2022-06-26 10:57:58.279785
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:58:00.142868
# Unit test for constructor of class DictToken
def test_DictToken():
    assert type(test_case_0()) is DictToken


# Generated at 2022-06-26 10:58:01.052909
# Unit test for constructor of class DictToken
def test_DictToken():

    # Test case #0
    test_case_0()

# Generated at 2022-06-26 10:58:02.271010
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:58:03.116763
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_1 = DictToken()

# Generated at 2022-06-26 10:59:19.257228
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_0.__init__()


# Generated at 2022-06-26 10:59:29.592092
# Unit test for constructor of class DictToken
def test_DictToken():
    # Case: 0
    dict_token_0 = DictToken()

    # Case: 1
    dict_token_1 = DictToken(None, None, None, None)

    # Case: 2
    dict_token_2 = DictToken("str", None, None, None)

    # Case: 3
    dict_token_3 = DictToken(1, None, None, None)

    # Case: 4
    dict_token_4 = DictToken("This is a string.", None, None, None)

    # Case: 5
    dict_token_5 = DictToken("This is a string.", "This is a string.", None, None)

    # Case: 6
    dict_token_6 = DictToken("This is a string.", "This is a string.", "This is a string.", None)

    # Case:

# Generated at 2022-06-26 10:59:34.029409
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    dict_token_2 = DictToken()
    assert dict_token_0 == dict_token_1
    assert dict_token_0 != dict_token_2


# Generated at 2022-06-26 10:59:35.219687
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:59:36.365488
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:59:39.138441
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:59:40.454399
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken()


# Generated at 2022-06-26 10:59:41.921997
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken(None, None, None, )


# Generated at 2022-06-26 10:59:44.467148
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_0._get_position(2)
    dict_token_0.lookup([])
    dict_token_0.lookup_key([])


# Generated at 2022-06-26 10:59:45.819411
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0


# Generated at 2022-06-26 11:02:15.088743
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = None
    dict_token_1 = DictToken(dict_token_0)
    dict_token_2 = dict_token_1
    dict_token_3 = dict_token_2
    dict_token_3

