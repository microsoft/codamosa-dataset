

# Generated at 2022-06-26 10:52:23.521687
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 10:52:24.427379
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()



# Generated at 2022-06-26 10:52:30.927250
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    int_0 = -4876
    int_1 = 0
    scalar_token_0 = ScalarToken(int_0, int_1, int_0)
    int_2 = 0
    int_3 = 8
    scalar_token_1 = ScalarToken(int_2, int_2, int_3)
    scalar_token_2 = scalar_token_0
    bool_0 = scalar_token_0 == scalar_token_1
    bool_1 = scalar_token_0 == scalar_token_2



# Generated at 2022-06-26 10:52:36.375658
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()



# Generated at 2022-06-26 10:52:41.085193
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = -1205
    int_1 = -1205
    list_0 = [
        int_0,
        int_1,
    ]
    list_1 = list([])
    dict_token_0 = DictToken(list_0, int_1, int_0, content=list_1)



# Generated at 2022-06-26 10:52:53.205307
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    int_0 = -4876
    int_1 = 0
    scalar_token_0 = ScalarToken(int_0, int_1, int_0)
    dict_token_0 = DictToken(scalar_token_0, int_0, int_0, None)
    dict_token_1 = DictToken(scalar_token_0, int_0, int_0, None)
    dict_token_2 = DictToken(scalar_token_0, int_0, int_0, None)
    int_2 = dict_token_0 == dict_token_1
    assert int_2 == True
    int_3 = dict_token_0 == dict_token_2
    assert int_3 == True


# Generated at 2022-06-26 10:53:03.930738
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = -4876
    int_1 = 0
    scalar_token_0 = ScalarToken(int_0, int_1, int_0)
    scalar_token_1 = ScalarToken(int_0, int_1, int_0)
    scalar_token_2 = ScalarToken(int_0, int_1, int_0)
    scalar_token_3 = ScalarToken(int_0, int_1, int_0)
    scalar_token_4 = ScalarToken(int_0, int_1, int_0)
    scalar_token_5 = ScalarToken(int_0, int_1, int_0)
    scalar_token_6 = ScalarToken(int_0, int_1, int_0)

# Generated at 2022-06-26 10:53:08.769719
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    int_0 = 0
    str_0 = ""
    token_0 = Token(int_0, int_0, int_0, str_0)
    token_0_copy = Token(int_0, int_0, int_0, str_0)
    assert token_0 == token_0_copy

    float_0 = -3.999999e-07
    token_0 == float_0


# Generated at 2022-06-26 10:53:16.409054
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = -16684
    int_1 = 0
    dict_token_0 = DictToken({}, int_0, int_1)
    assert dict_token_0.string == ""
    assert dict_token_0.value == {}
    assert dict_token_0.start == Position(1, 1, 0)
    assert dict_token_0.end == Position(1, 1, 0)


# Generated at 2022-06-26 10:53:22.230722
# Unit test for method __eq__ of class Token
def test_Token___eq__():
    int_0 = -4876
    int_1 = 0
    scalar_token_0 = ScalarToken(int_0, int_1, int_0)
    int_2 = 65
    int_3 = 58
    scalar_token_1 = ScalarToken(int_2, int_3, int_2)
    assert scalar_token_0 != scalar_token_1


# Generated at 2022-06-26 10:53:34.177722
# Unit test for constructor of class DictToken
def test_DictToken():
    int_1 = 1
    # make token for every key in the dict
    scalar_token_1 = ScalarToken(int_1, int_1, int_1)
    int_2 = 2
    scalar_token_2 = ScalarToken(int_2, int_2, int_2)
    # make token for every value in the dict
    scalar_token_3 = ScalarToken(int_1, int_1, int_1)
    scalar_token_4 = ScalarToken(int_2, int_2, int_2)
    # make a dict of tokens
    dict_token = {scalar_token_1: scalar_token_3, scalar_token_2: scalar_token_4}
    # call the constructor of DictToken

# Generated at 2022-06-26 10:53:41.624546
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = 0
    scalar_token_0 = ScalarToken(int_0, int_0, int_0)
    int_1 = 1
    scalar_token_1 = ScalarToken(int_1, int_1, int_1)
    dict_0 = {
        scalar_token_0: scalar_token_0,
        scalar_token_1: scalar_token_0
    }
    dict_token_0 = DictToken(dict_0, int_1, int_1, "")


# Generated at 2022-06-26 10:53:51.715239
# Unit test for constructor of class DictToken
def test_DictToken():
    for i in range(0, 10):
        for j in range(0, 10):
            for k in range(0, 10):
                int_0 = 0
                scalar_token_0 = ScalarToken(int_0, int_0, int_0)
                int_1 = 1
                scalar_token_1 = ScalarToken(int_1, int_1, int_1)
                dict_token_0 = DictToken({scalar_token_0: scalar_token_1}, int_0, int_1)


# Generated at 2022-06-26 10:53:56.968020
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = 0
    dict_0 = {scalar_token_0: scalar_token_0}
    dict_token_0 = DictToken(dict_0, int_0, int_0)
    assert dict_token_0 is not None
    assert dict_token_0._child_keys is dict_0
    assert dict_token_0._child_tokens is dict_0



# Generated at 2022-06-26 10:54:01.128171
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_0 = {}
    dict_1 = {}
    dict_token_1 = DictToken(dict_0, dict_1, dict_1)
    assert dict_token_1
    assert dict_token_1.lookup_key(dict_0)


# Generated at 2022-06-26 10:54:09.433623
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = 0
    scalar_token_0 = ScalarToken(int_0, int_0, int_0)
    list_0 = []
    list_0.append("")
    arguments_0 = {scalar_token_0: scalar_token_0}
    dict_token_0 = DictToken(arguments_0, int_0, int_0)
    dict_token_0._value = arguments_0
    arguments_0 = {scalar_token_0: scalar_token_0}
    list_token_0 = ListToken(arguments_0, int_0, int_0)
    list_token_0._value = list_0
    arguments_0 = {key_: value_ for key_, value_ in arguments_0.items()}
    str_0 = ""

# Generated at 2022-06-26 10:54:13.305055
# Unit test for constructor of class DictToken
def test_DictToken():
    str_0 = ''
    content = str_0
    end_index = 0
    start_index = 0
    value = {}
    token = DictToken(value, start_index, end_index, content)

# Generated at 2022-06-26 10:54:23.116785
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_1['foo'] = dict_0
    dict_3['a'] = dict_0
    dict_3['b'] = dict_1
    dict_5['a'] = dict_2
    dict_5['b'] = dict_3
    dict_4['foo'] = dict_1
    dict_4['bar'] = dict_3
    dict_5['bar'] = dict_4
    dict_token_0 = DictToken(dict_5, int_9, int_9)

# Generated at 2022-06-26 10:54:32.055886
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = 0
    int_1 = 1
    int_2 = 2
    scalar_token_0 = ScalarToken(int_0, int_0, int_0)
    scalar_token_1 = ScalarToken(int_1, int_1, int_1)
    scalar_token_2 = ScalarToken(int_2, int_2, int_2)
    dict_token_0 = DictToken(
        {scalar_token_0: scalar_token_1, scalar_token_2: scalar_token_2},
        int_0,
        int_2,
        "",
    )


# Generated at 2022-06-26 10:54:41.159194
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = 0
    int_1 = 1
    int_2 = 2
    str_0 = "0"
    str_1 = "1"
    str_2 = "2"
    scalar_token_0 = ScalarToken(int_0, int_0, int_0)
    scalar_token_1 = ScalarToken(int_1, int_1, int_1)
    scalar_token_2 = ScalarToken(int_2, int_2, int_2)
    list_token_0 = ListToken([scalar_token_0], int_0, int_0)
    list_token_1 = ListToken([scalar_token_1], int_1, int_1)

# Generated at 2022-06-26 10:54:51.823312
# Unit test for constructor of class DictToken
def test_DictToken():
    args = ()
    kwargs = {}
    test_instance_0 = DictToken(*args, **kwargs)
    token_value_0 = test_instance_0._value
    test_instance_0_child_keys = test_instance_0._child_keys
    test_instance_0_child_tokens = test_instance_0._child_tokens
    int_0 = 0


# Generated at 2022-06-26 10:54:58.468373
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = 0
    # caller
    int_id = id(int_0)
    # callee
    from typesystem import Token, DictToken
    # callee
    from typesystem import Token, ScalarToken
    # callee
    from typesystem import Position
    # callee
    from typesystem import Token, DictToken
    # callee
    from typesystem import Token, DictToken, ScalarToken
    # callee
    from typesystem import Position
    # callee
    from typesystem import Token, DictToken
    # callee
    from typesystem import Token, ListToken, ScalarToken
    # callee
    from typesystem import Position
    # callee
    from typesystem import Token, ListToken, ScalarToken
    # callee
    from typesystem import Position
    # callee
   

# Generated at 2022-06-26 10:55:01.154969
# Unit test for constructor of class DictToken
def test_DictToken():
    d = DictToken('s', 'e', 'c')
    assert d.__class__.__name__ == 'DictToken'


# Generated at 2022-06-26 10:55:10.734994
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = 0
    float_0 = float(0)
    float_1 = float(1)
    float_2 = float(2)
    float_3 = float(3)
    float_4 = float(4)
    float_5 = float(5)
    float_6 = float(6)
    float_7 = float(7)
    float_8 = float(8)
    float_9 = float(9)
    
    str_0 = ""
    str_1 = "1"
    str_2 = "2"
    
    list_0 = []
    list_1 = [float_7, float_8]
    list_2 = [float_1, float_3, float_8]
    list_3 = [float_2, float_8, float_5]
    list_

# Generated at 2022-06-26 10:55:13.053777
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = 0
    int_1 = 0
    obj_2 = DictToken(int_0, int_1, {})
    assert(obj_2 is not None)


# Generated at 2022-06-26 10:55:16.571689
# Unit test for constructor of class DictToken
def test_DictToken():
    data = {}
    start_index = 0
    end_index = 0
    content = ""
    dt = DictToken(data, start_index, end_index, content)
    assert True


# Generated at 2022-06-26 10:55:22.034928
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = 0
    str_1 = "test_case_0"
    dict_2 = {'foo': str_1}
    dict_token_3 = DictToken(dict_2, int_0, int_0+len(str_1))
    test_case_0()



# Generated at 2022-06-26 10:55:22.970393
# Unit test for constructor of class DictToken
def test_DictToken():
    test_DictToken_0()


# Generated at 2022-06-26 10:55:24.559119
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken((0),(0),(0), (0))


# Generated at 2022-06-26 10:55:36.156828
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = 0
    int_1 = 1
    int_1_again = 1
    t1 = ScalarToken(int_0, 0, 2, "")
    t2 = ScalarToken(int_1, 3, 3, "")
    t3 = ScalarToken(int_1_again, 4, 4, "")
    test_dict = {t2: t3}
    test = DictToken(test_dict, int_1, int_1, "")
    assert test.value == {t2._get_value(): t3._get_value()}
    assert test.start == Position(1, 1, int_1)
    assert test.end == Position(1, 1, int_1)

# Generated at 2022-06-26 10:55:59.345539
# Unit test for constructor of class DictToken
def test_DictToken():
    # Stub
    args = ()
    kwargs = {}
    Token._value = typing.Any
    kwargs['_child_keys'] = {k._value: k for k in self._value.keys()}
    kwargs['_child_tokens'] = {k._value: v for k, v in self._value.items()}
    test_DictToken = DictToken(*args, **kwargs)


# Generated at 2022-06-26 10:56:01.486654
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(value, start_index, end_index, content)


# Generated at 2022-06-26 10:56:12.798809
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = 0
    int_1 = 0
    int_2 = 0
    int_3 = 0
    int_4 = 0
    int_5 = 0
    int_6 = 0
    int_7 = 0
    int_8 = 0
    int_9 = 0
    int_10 = 0
    int_11 = 0
    int_12 = 0
    int_13 = 0
    int_14 = 0
    int_15 = 0
    int_16 = 0
    int_17 = 0
    int_18 = 0
    int_19 = 0
    int_20 = 0
    int_21 = 0
    int_22 = 0
    int_23 = 0
    int_24 = 0
    int_25 = 0
    int_26 = 0
    int_27 = 0
    int_

# Generated at 2022-06-26 10:56:18.739110
# Unit test for constructor of class DictToken
def test_DictToken():
    token = ScalarToken(10, 0, 0)
    value = {token: token}
    start_index = 1
    end_index = 0
    content = "content"
    obj = DictToken(value, start_index, end_index, content)
    assert obj._start_index == start_index
    assert obj._end_index == end_index
    assert obj._content == content
    assert obj._child_keys == {10: token}
    assert obj._child_tokens == {10: token}


# Generated at 2022-06-26 10:56:29.477663
# Unit test for constructor of class DictToken
def test_DictToken():
    # TEST CASE 1
    int_0 = 0
    int_1_1 = 1
    int_2_1 = 2
    int_3_1 = 3
    test_case_1 = { '1' : int_1_1, '2' : int_2_1, '3' : int_3_1, '0' : int_0}
    int_0_1 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3
    test_case_2 = { '1' : int_1, '2' : int_2, '3' : int_3, '0' : int_0_1}
    dict_token_1 = DictToken(test_case_1, int_0, int_3, "")

# Generated at 2022-06-26 10:56:31.402901
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 10:56:32.546817
# Unit test for constructor of class DictToken
def test_DictToken():
    DictToken()


# Generated at 2022-06-26 10:56:35.175078
# Unit test for constructor of class DictToken
def test_DictToken():
    token_0 = DictToken([1,2,3])
    # Successfully created an instance of class DictToken
    assert token_0.__class__ == DictToken


# Generated at 2022-06-26 10:56:42.280432
# Unit test for constructor of class DictToken
def test_DictToken():
    int_0 = None
    int_0 = DictToken(int_0, 0, 1, "hello")
    int_0 = DictToken
    int_0 = DictToken()
    int_0 = DictToken
    int_0 = DictToken()
    int_0 = DictToken
    int_0 = DictToken()

# Generated at 2022-06-26 10:56:43.340251
# Unit test for constructor of class DictToken
def test_DictToken():
    pass


# Generated at 2022-06-26 10:56:52.186348
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0.value == {}


# Generated at 2022-06-26 10:56:53.672117
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    return 


# Generated at 2022-06-26 10:56:55.587787
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

# Test case for DictToken object

# Generated at 2022-06-26 10:56:56.400855
# Unit test for constructor of class DictToken
def test_DictToken():
    assert test_DictToken


# Generated at 2022-06-26 10:57:01.916725
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, DictToken)
    assert dict_token_0.value == {}


# Generated at 2022-06-26 10:57:10.012451
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert_equal(dict_token_0._value, {})
    assert_equal(dict_token_0._child_keys, {})
    assert_equal(dict_token_0._child_tokens, {})
    assert_equal(dict_token_0._start_index, 0)
    assert_equal(dict_token_0._end_index, 0)
    assert_equal(dict_token_0._content, "")


# Generated at 2022-06-26 10:57:10.522099
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 10:57:18.319668
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0.string == ""
    assert dict_token_0.value == {}
    assert dict_token_0.start == Position(1, 1, 0)
    assert dict_token_0.end == Position(1, 1, 0)
    assert dict_token_0.lookup([]) == dict_token_0
    assert dict_token_0.lookup_key([]) == dict_token_0
    assert dict_token_0._get_position(0) == Position(1, 1, 0)


# Generated at 2022-06-26 10:57:21.547207
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, DictToken)

# Generated at 2022-06-26 10:57:22.835016
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:57:52.619772
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken(True, False, True, False)
    dict_token_2 = DictToken(dict_token_0, dict_token_1, dict_token_0, dict_token_1)
    dict_token_3 = DictToken(dict_token_1, dict_token_0, dict_token_1, dict_token_0)
    dict_token_4 = DictToken(dict_token_2, dict_token_3, dict_token_2, dict_token_3)
    dict_token_5 = DictToken(dict_token_3, dict_token_2, dict_token_3, dict_token_2)


# Generated at 2022-06-26 10:57:53.517395
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

# Generated at 2022-06-26 10:57:54.322213
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()

# Generated at 2022-06-26 10:57:55.769065
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:57:57.326052
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:57:59.794998
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:58:09.658676
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken({})
    dict_token_1 = DictToken(dict_token_0._value, 0, 0)
    dict_token_2 = DictToken(dict_token_1._value, dict_token_1._start_index, dict_token_1._end_index)
    dict_token_3 = DictToken(dict_token_2._value, dict_token_2._start_index, dict_token_2._end_index)
    dict_token_4 = DictToken({})

    dict_token_0._value = dict_token_4._value
    dict_token_0._start_index = dict_token_4._start_index
    dict_token_0._end_index = dict_token_4._end_index

    assert dict_token_0 is not dict

# Generated at 2022-06-26 10:58:18.278089
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(
        {0: ScalarToken(0, 1, 4, "None")},
        1,2,3
    )
    if token.string != None:
        print("Expected : None , Actual : " + token.string)
    if token.value != {0: None}:
        print("Expected : {0: None} , Actual : " + token.value)
    if token.start != Position(1,1,1):
        print("Expected : Position(1, 1, 1) , Actual : " + token.start)
    if token.end != Position(2,3,3):
        print("Expected : Position(2, 3, 3) , Actual : " + token.end)

# Generated at 2022-06-26 10:58:23.772497
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert repr(dict_token_0) == "DictToken()"
    assert str(dict_token_0) == "DictToken()"
    assert dict_token_0 == DictToken()
    assert hash(dict_token_0) == hash(DictToken())
    assert dict() == DictToken()
    assert {} == DictToken()


# Generated at 2022-06-26 10:58:26.693721
# Unit test for constructor of class DictToken
def test_DictToken():
    # the following call to the constructor of class DictToken
    # with no arguments should raise a TypeError
    try:
        DictToken()
    except TypeError:
        pass
    except:
        raise AssertionError


# Generated at 2022-06-26 10:58:54.645435
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()


# Generated at 2022-06-26 10:58:55.778287
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()

# Generated at 2022-06-26 10:59:00.826297
# Unit test for constructor of class DictToken
def test_DictToken():
    # No exception is raised
    token_0 = DictToken()
    # No exception is raised
    token_0 = DictToken(0.17068741, 0.1, 3.2, "", "", "", "", "", "", "", "")
    # No exception is raised
    token_0 = DictToken()
    # No exception is raised
    token_0 = DictToken()


# Generated at 2022-06-26 10:59:02.402924
# Unit test for constructor of class DictToken
def test_DictToken():
    try:
        test_case_0()
    except Exception as e:
        print(str(e))

# Generated at 2022-06-26 10:59:03.694720
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:59:08.091256
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 10:59:09.098789
# Unit test for constructor of class DictToken
def test_DictToken():
    pass


# Generated at 2022-06-26 10:59:09.959916
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

# Generated at 2022-06-26 10:59:11.102364
# Unit test for constructor of class DictToken
def test_DictToken():
    assert DictToken


# Generated at 2022-06-26 10:59:13.092822
# Unit test for constructor of class DictToken
def test_DictToken():
    # Test case 1
    test_case_0()


# Generated at 2022-06-26 10:59:52.516733
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()

if __name__ == '__main__':
    test_case_0()
    test_DictToken()

# Generated at 2022-06-26 10:59:54.562884
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert dict_token_0 is not None
    assert str(dict_token_0) == "DictToken({})"


# Generated at 2022-06-26 11:00:04.116644
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_1 = DictToken()
    assert (dict_token_1._value == {})
    assert (dict_token_1._start_index == 0)
    assert (dict_token_1._end_index == -1)
    assert (dict_token_1._content == "")
    assert (dict_token_1.string == "")
    assert (dict_token_1.start == Position(1, 1, 0))
    assert (dict_token_1.end == Position(1, 1, 0))
    assert (dict_token_1.value == {})
    assert repr(dict_token_1) == "DictToken({})"
    assert (dict_token_1._child_keys == {})
    assert (dict_token_1._child_tokens == {})


# Generated at 2022-06-26 11:00:05.938416
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert (dict_token_0._get_value() == {})


# Generated at 2022-06-26 11:00:07.513598
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()

# Generated at 2022-06-26 11:00:10.170161
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken(dict(), 0, 3)
    assert isinstance(dict_token_0, DictToken)
    assert repr(dict_token_0) == "DictToken({})"


# Generated at 2022-06-26 11:00:14.386575
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_2 = {
        ScalarToken("a", 0, 0): ScalarToken(1, 1, 1),
        ScalarToken("b", 2, 2): ScalarToken(2, 3, 3),
        ScalarToken("c", 4, 4): ScalarToken(3, 5, 5),
        ScalarToken("d", 6, 6): ScalarToken(4, 7, 7),
    }
    dict_token_0 = DictToken(dict_token_2)
    assert dict_token_2 == dict_token_0


# Generated at 2022-06-26 11:00:15.649805
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:00:17.553815
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:00:19.843394
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert (isinstance(dict_token_0, DictToken))


# Generated at 2022-06-26 11:01:38.967763
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


if __name__ == "__main__":
    import doctest

    # Run doctests
    doctest.testmod()

    # Run unit tests
    test_case_0()
    test_DictToken()

# Generated at 2022-06-26 11:01:42.395216
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    assert isinstance(dict_token_0, DictToken)
    assert not hasattr(dict_token_0, "_value")
    assert dict_token_0.value == {}


# Generated at 2022-06-26 11:01:43.526082
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()


# Generated at 2022-06-26 11:01:46.179968
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()
    dict_token_1 = DictToken()
    dict_token_0.__eq__(dict_token_1)



# Generated at 2022-06-26 11:01:52.206462
# Unit test for constructor of class DictToken
def test_DictToken():
    token = DictToken(
        {
            ScalarToken("foo", 0, 2): ScalarToken("bar", 4, 6),
            ScalarToken("baz", 8, 10): ScalarToken("qux", 12, 14),
        },
        0,
        14,
    )
    assert token.lookup([0]) == ScalarToken("foo", 0, 2)
    assert token.lookup([1]) == ScalarToken("baz", 8, 10)
    assert token.lookup([2]) == ScalarToken("qux", 12, 14)
    assert token.lookup([3, 0]) == ScalarToken("bar", 4, 6)



# Generated at 2022-06-26 11:01:59.427227
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token = DictToken(None, 0, 0, "")
    assert(dict_token != None)
    assert(dict_token.string == "")
    assert(dict_token.value == {})
    assert(dict_token.start.line == 1)
    assert(dict_token.start.column == 1)
    assert(dict_token.start.index == 0)
    assert(dict_token.end.line == 1)
    assert(dict_token.end.column == 1)
    assert(dict_token.end.index == 0)


# Generated at 2022-06-26 11:02:02.266123
# Unit test for constructor of class DictToken
def test_DictToken():
    print('Testing constructor of class DictToken')
    test_case_0()
    print('Class DictToken constructor test completed')


# Generated at 2022-06-26 11:02:03.923156
# Unit test for constructor of class DictToken
def test_DictToken():
    dictToken = DictToken()
    assert isinstance(dictToken, DictToken)


# Generated at 2022-06-26 11:02:06.071556
# Unit test for constructor of class DictToken
def test_DictToken():
    dict_token_0 = DictToken()



# Generated at 2022-06-26 11:02:06.935575
# Unit test for constructor of class DictToken
def test_DictToken():
    test_case_0()
