

# Generated at 2022-06-22 14:01:38.612137
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DictDataLoader({})
    inventory = Inventory(loader)
    variable_manager = VariableManager(loader, inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager)

    conditional = Conditional()
    conditional.when = [dict(a=1)]

    res = conditional.evaluate_conditional(templar, variable_manager.get_vars())
    assert res == True

    conditional.when = [dict(a=2)]
    res = conditional.evaluate_conditional(templar, variable_manager.get_vars())
    assert res == False

    conditional.when = [dict(a=2), dict(a=1)]

# Generated at 2022-06-22 14:01:45.583420
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.extra_vars = dict(
        foo='bar',
        baz=42,
        some_ip='127.0.0.1',
        some_ipv6='::1',
        some_host='example.org',
        some_dict={'a': 'b', 'c': 'd'},
        some_list=['a', 'b', 'c', 'd'],
        some_undefined=variable_manager.get_vars()['some_undefined'],
    )
    templar = Templar(loader=loader, variables=variable_manager)

# Generated at 2022-06-22 14:01:53.506082
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # test case 1: no match
    t = Task()
    assert [] == t.extract_defined_undefined("a is b")

    # test case 2: one match
    t = Task()
    assert [('a', 'is', 'defined')] == t.extract_defined_undefined("a is defined")

    # test case 3: multiple matches
    t = Task()
    assert [('a', 'is', 'defined'), ('b', 'is', 'undefined')] == t.extract_defined_undefined("a is defined and b is undefined")

    # test case 4: multiple matches of different types
    t = Task()

# Generated at 2022-06-22 14:02:03.900483
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    # Initialize ansible host variables
    ansible_vars = {}
    ansible_vars['hostvars'] = {}
    hostname = '10.11.12.13'
    ansible_vars['hostvars'][hostname] = {}
    ansible_vars['hostvars'][hostname]['ansible_host'] = 'myexample.com'
    ansible_vars['hostvars'][hostname]['ansible_user'] = 'myuser'
    ansible_vars['hostvars'][hostname]['ansible_password'] = 'mypassword'
    ansible_vars['hostvars'][hostname]['ansible_port'] = 22
    ansible_vars['ansible_default_ipv4'] = {}

# Generated at 2022-06-22 14:02:16.112548
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.vars import VariableManager
    import jinja2

    class TestClass(Base, Conditional):
        def __init__(self, tmplar = None, variables = None):
            self._ds = dict()
            self._loader = jinja2.DictLoader({})
            self.when = []
            self.default_vars = variables
            self._templar = tmplar


# Generated at 2022-06-22 14:02:29.550251
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    conditional = "a is defined and b is not defined"
    assert c.extract_defined_undefined(conditional) == [(u'a', u'is', u'defined'), (u'b', u'is not', u'defined')]

    conditional = "a is defined and b is not defined and (c is undefined or d is defined)"
    assert c.extract_defined_undefined(conditional) == [(u'a', u'is', u'defined'), (u'b', u'is not', u'defined'), (u'c', u'is', u'undefined'), (u'd', u'is', u'defined')]

    conditional = "a is defined"
    assert c.extract_defined_undefined(conditional) == [(u'a', u'is', u'defined')]

# Generated at 2022-06-22 14:02:42.260438
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    conditional = 'is_pkg_installed is defined or not is_pkg_installed is defined'
    assert c.extract_defined_undefined(conditional) == [('is_pkg_installed', 'is', 'defined'), ('is_pkg_installed', 'is', 'undefined')]
    conditional = 'not is_pkg_installed is defined'
    assert c.extract_defined_undefined(conditional) == [('is_pkg_installed', 'is', 'undefined')]
    conditional = 'not is_pkg_installed is undefined'
    assert c.extract_defined_undefined(conditional) == [('is_pkg_installed', 'is', 'defined')]
    conditional = 'not is_pkg_installed is not defined'

# Generated at 2022-06-22 14:02:54.702322
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # class MockLoader:
    #     def load(self, file, filetype='auto', ignore_errors=False,
    #              variable_start_string=None, variable_end_string=None):
    #         self.file = file
    #         self.filetype = filetype
    #         self.ignore_errors = ignore_errors
    #         self.variable_start_string = variable_start_string
    #         self.variable_end_string = variable_end_string
    #         if filetype == 'yaml':
    #             return {'mock_var': 'mock_val'}
    #         else:
    #             return 'mock_val'

    class MockTemplar:
        def __init__(self):
            self.environment = None


# Generated at 2022-06-22 14:03:04.371139
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Define some useful variables
    foo = 'bar'
    items = [ 1, 2, 3 ]
    play_context = PlayContext(variables = dict(foo = foo, items = items))
    templar = Templar(loader = None, variables = dict(foo = foo, items = items), shared_loader_obj = False)

    #############################################################################################################
    # Test variable replacement; should return True
    test_conditional = 'items|length > 3'
    test_obj = Conditional(loader = None)
    test_obj.when = [test_conditional]

    result = test_obj.evaluate_conditional(templar, play_context)
    assert result is True

    #############################################################################################################
   

# Generated at 2022-06-22 14:03:12.432467
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('foo') == []
    assert conditional.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined('foo is not defined or bar is not undefined') == [
        ('foo', 'is not', 'defined'),
        ('bar', 'is not', 'undefined'),
    ]


# Generated at 2022-06-22 14:03:28.745663
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:03:40.693678
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()


# Generated at 2022-06-22 14:03:52.939962
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-22 14:04:04.019207
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    # Test the simple case
    tests = [
        ("foo is defined", (('foo', 'is', 'defined'),)),
        ("foo is defined and bar is defined", (('foo', 'is', 'defined'), ('bar', 'is', 'defined'))),
        ("foo is not defined or bar is defined", (('foo', 'is not', 'defined'), ('bar', 'is', 'defined'))),
        ("foo is defined or bar not is undefined", (('foo', 'is', 'defined'), ('bar', 'not is', 'undefined'))),
    ]
    for (cond, expected_results) in tests:
        results = conditional.extract_defined_undefined(cond)
        assert results == expected_results

    # Test the mixed case

# Generated at 2022-06-22 14:04:10.756359
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # SETUP
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars import VariableManager
    hostvars = dict(
        foo          = 'bar',
        foo_is_true  = True,
        foo_is_false = False,
        foo_is_none  = None,
        foo_is_zero  = 0,
        foo_is_1     = 1,
        foo_is_empty = '',
    )
    variable_manager = VariableManager()
    variable_manager.set_host_variable(host='testhost', varname='hostvars', value=hostvars)



# Generated at 2022-06-22 14:04:15.728221
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert Conditional.extract_defined_undefined('hostvars["foo"] is defined or hostvars["bar"] is not undefined') == [('hostvars["foo"]', 'is', 'defined'), ('hostvars["bar"]', 'is not', 'undefined')]
    assert Conditional.extract_defined_undefined('"this is a normal string"') == []


# Generated at 2022-06-22 14:04:21.513117
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    ''' test class Conditional method evaluate_conditional '''
    ########################################################
    # Test the Conditional class

    def _evaluate_conditional(conditional, templar, all_vars):
        class C(Conditional):
            pass

        c = C()
        c.when = [conditional]
        return c.evaluate_conditional(templar, all_vars)

    from ansible.template import Templar

    class M(object):

        def __init__(self, data=None, basedir=None):
            self._basedir = basedir
            self.data = data

        def get_basedir(self):
            return self._basedir

        def __getitem__(self, name):
            if self.data is not None:
                return self.data.get(name)
            return

# Generated at 2022-06-22 14:04:33.632810
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    unset_variable = {}
    set_variable = { "foo": "bar" }

    # Testing empty when
    conditional = Conditional()
    result = conditional.evaluate_conditional(None, set_variable)
    assert result is True

    # Testing unset variable
    conditional.when = ["not_existing_variable"]
    result = conditional.evaluate_conditional(None, set_variable)
    assert not result

    # Testing set variable
    conditional.when = ["foo"]
    result = conditional.evaluate_conditional(None, set_variable)
    assert result

    # Testing positive when with defined
    conditional.when = ["foo is defined"]
    result = conditional.evaluate_conditional(None, set_variable)
    assert result

    # Testing negative when with defined
    conditional.when = ["foo is not defined"]

# Generated at 2022-06-22 14:04:38.392467
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # We can't instantiate Conditional
    try:
        c = Conditional()
        raise Exception("Conditional instantiation must fail")
    except AnsibleError:
        pass
    # TODO: Add unit tests when we test the concrete classes



# Generated at 2022-06-22 14:04:46.855039
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("") == []
    assert c.extract_defined_undefined("not_defined") == []

# Generated at 2022-06-22 14:05:08.250341
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from units.mock.loader import DictDataLoader
    assert Conditional(DictDataLoader()).evaluate_conditional(None, {})


# Generated at 2022-06-22 14:05:16.792226
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    class DummyModule():

        def __init__(self, host_vars):
            self.host_vars = host_vars

        def get_host_vars(self, host):
            return self.host_vars[host]

    class DummyRunner():
        module_vars = {}

        def __init__(self, host_vars, available_variables):
            self.host_vars = host_vars
            self.available_variables = available_variables

        def get_host_vars(self, host):
            return self.host_vars[host]

        def get_accessible_variables(self, play=None):
            return self.available_variables

    # Test the case when the only conditional is 'True'
    dm = DummyModule({})
    dr = D

# Generated at 2022-06-22 14:05:26.426198
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    initialize_test = True

    # when used directly, this class needs a loader, and we want to
    # make sure we don't trample on the existing one if this class
    # is used as a mix-in with a playbook base class
    if initialize_test:
        mock_loader = DataLoader()
        templar = Templar(mock_loader, variables=VariableManager())

    # test with existing dunder method
    test1 = dict(
        when = 'not ansible_os_family == RedHat'
    )

# Generated at 2022-06-22 14:05:32.116461
# Unit test for constructor of class Conditional
def test_Conditional():
    class TestClass(object):
        __metaclass__ = Conditional
        def test_method(self):
            pass
    c = TestClass()
    try:
        c.test_method()
    except:
        print("Class tester: Conditional testing passed")


# Generated at 2022-06-22 14:05:41.410722
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-22 14:05:46.237137
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Validate the "evaluate_conditional" method of class Conditional
    '''

    # Some parameters for the tests
    inventory_hostname = 'localhost'
    play_hosts = ['localhost']
    test_user = 'testuser'

    # Initialize the class VariableManager
    from ansible.vars import VariableManager
    inventory = None
    variable_manager = VariableManager(loader=None, inventory=inventory)

    # Initialize the class Jinja2
    from ansible.template import Jinja2
    jinja2_env_options = {'extensions': ['jinja2.ext.do', 'jinja2.ext.loopcontrols']}
    j2_env = Jinja2.environment(**jinja2_env_options)

    # Initialize the class PlayContext

# Generated at 2022-06-22 14:05:54.421730
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-22 14:06:03.797435
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = True
    play_context.become_user = 'test_user'

    # Create a new play object

# Generated at 2022-06-22 14:06:13.181074
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:06:23.859495
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

    assert cond.extract_defined_undefined('foo.bar is defined') == [('foo.bar', 'is', 'defined')]
    assert cond.extract_defined_undefined('foo.bar is not defined') == [('foo.bar', 'is not', 'defined')]
    assert cond.extract_defined_undefined('foo.bar is undefined') == [('foo.bar', 'is', 'undefined')]
    assert cond.extract_defined_undefined('foo.bar is not undefined') == [('foo.bar', 'is not', 'undefined')]
    assert cond.extract_defined_undefined('foo.bar is defined and bar.foo is undefined') == [('foo.bar', 'is', 'defined'), ('bar.foo', 'is', 'undefined')]

    # only

# Generated at 2022-06-22 14:07:08.869800
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.plugins.loader import action_loader, connection_loader, module_loader
    module_loader.add_directory(C.DEFAULT_MODULE_PATH)
    connection_loader.add_directory(C.DEFAULT_CONNECTION_PLUGIN_PATH)
    action_loader.add_directory(C.DEFAULT_ACTION_PLUGIN_PATH)
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # load a test inventory file
    test_inventory_file = os.path.join(os.path.dirname(__file__), 'test_templar_inventory.yml')
    inventory = Inventory

# Generated at 2022-06-22 14:07:18.228623
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # for a well formed conditional
    test_conditional = "((foo is defined) and (bar is not defined))"
    test_obj = Conditional()
    result = test_obj.extract_defined_undefined(test_conditional)
    assert result == [('foo', 'is', 'defined'), ('bar', 'is not', 'defined')]

    # for a conditional with errors
    test_conditional = "((foo is defined) or (bar is undefined))"
    test_obj = Conditional()
    result = test_obj.extract_defined_undefined(test_conditional)
    assert result == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]

    test_conditional = "((foo  is  defined) or (bar is undefined))"
    test_obj = Conditional()

# Generated at 2022-06-22 14:07:26.782504
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    local_vars = dict(omar='omar', maria='maria', pablo='pablo')

    # Instantiate needed objects
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Set variables
    variable_manager.set_nonpersistent_fact('omar', 'omar')
    variable_manager.set_nonpersistent_fact('maria', 'maria')
    variable_manager.set_nonpersistent_fact('pablo', 'pablo')

    # Instantiate a

# Generated at 2022-06-22 14:07:36.811526
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    if C.DEFAULT_KEEP_REMOTE_FILES:
        raise AssertionError("C.DEFAULT_KEEP_REMOTE_FILES should be False in tests")

    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    debug_override = dict(
        debug=dict(
            verbosity=5,
            hostvars=dict(
                localhost=dict(
                    foo="bar"
                )
            )
        )
    )
    b_obj = Base()

# Generated at 2022-06-22 14:07:46.057553
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    cond = Conditional(loader=None)

    vm = VariableManager()
    vm.set_variable('foo', 'bar')
    vm.set_variable('baz', 'qux')

    templar = Templar(loader=None, variables=vm)

    # Test 1
    test_conditional = ''
    test_result = cond.evaluate_conditional(templar, vm)
    assert test_result, 'Test 1 failed'

    # Test 2
    test_conditional = 'foo == "bar"'
    test_result = cond.evaluate_conditional(templar, vm)
    assert test_result, 'Test 2 failed'

    # Test 3
    test_conditional = 'foo == "baz"'

# Generated at 2022-06-22 14:07:54.385008
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    ######################################################################################
    class TestConditional(Conditional):
        def __init__(self, when, conditionals):
            self.when = when
            self.conditionals = conditionals
    ######################################################################################

    import unittest
    from ansible.template import Templar

    class TestConditionalEvaluateConditional(unittest.TestCase):
        def setUp(self):
            self.test_conditional = TestConditional(['1 == 1', True, "2 != 3", "foo == 'bar'"],
                ['1 == 1', True, "2 != 3", "foo == 'bar'"])

            self.test_conditional2 = TestConditional(['1 == 1', True, "2 != 3", "foo == 'bar'"],
                ['1 == 1'])

            self.templar

# Generated at 2022-06-22 14:08:04.306908
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Tests the method evaluate_conditional of class Conditional
    #
    # Args:
    #
    # Returns:
    #    None
    #
    # Raises:
    #    None

    # Setup mock values
    def raise_error(msg, obj=None, wrap_info=None):
        raise Exception(msg)

    c = Conditional()
    c._ds = None
    c.when = ["my_variable is defined", "my_variable == 'my_value'"]

    # Setup mock objects
    class J2Vars(object):
        def __init__(self):
            self.all = dict()

    class J2Template(object):
        def __init__(self, environment):
            self.available_variables = dict()
            self.environment = environment


# Generated at 2022-06-22 14:08:17.789771
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:08:26.669049
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    # Test for a simple conditional
    c = conditional.extract_defined_undefined("foo is not defined")
    assert c[0][0] == "foo"
    assert c[0][1] == "is not"
    assert c[0][2] == "defined"

    # Test for multiple conditionals
    c = conditional.extract_defined_undefined(
        'hostvars["foo"] is defined and hostvars["bar"] is undefined'
    )
    assert c[0][0] == 'hostvars["foo"]'
    assert c[0][1] == "is"
    assert c[0][2] == "defined"

    assert c[1][0] == 'hostvars["bar"]'
    assert c[1][1] == "is"

# Generated at 2022-06-22 14:08:38.508214
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar


# Generated at 2022-06-22 14:09:51.696988
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(first_var='I am defined', second_var=dict(a_nested_var=[]))
    variable_manager.options_vars = dict(third_var='I am also defined')
    variable_manager.set_available_variables(loader=None, play=None)
    templar = Templar(loader=None, variables=variable_manager)

    c = Conditional(loader=None)
    c.when = ["first_var is defined"]
    assert c.evaluate_conditional(templar, variable_manager)

    c.when = ["second_var is defined"]
    assert c.evaluate_conditional(templar, variable_manager)



# Generated at 2022-06-22 14:09:59.881414
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    testobj = Conditional()
    testcases = [
        ('hostvars["foo"] is defined', [('hostvars["foo"]', 'is', 'defined')]),
        ('hostvars["foo"] is not defined', [('hostvars["foo"]', 'is not', 'defined')]),
        ('hostvars["foo"] is defined and hostvars["bar"] is defined', [('hostvars["foo"]', 'is', 'defined'), ('hostvars["bar"]', 'is', 'defined')]),
    ]
    for (testcase, expected_result) in testcases:
        assert testobj.extract_defined_undefined(testcase) == expected_result


# Generated at 2022-06-22 14:10:10.736780
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    module_args = dict(
        when=[
            "ansible_nodename == 'host1'",
            "not (ansible_nodename == 'host2')",
            "ansible_nodename == 'host3'",
        ]
    )
    module_default_args = dict(
        when=[
            "ansible_nodename == 'host1'"
        ]
    )
    class FakeModule:
        def __init__(self, args):
            self.params = args
        def fail_json(self, msg):
            raise Exception(msg)

    class FakeTemplar:
        def __init__(self):
            self.available_variables = dict()
        def is_template(self, value):
            return False

# Generated at 2022-06-22 14:10:23.144002
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    data = dict()
    data["hostvars"] = {}
    data["hostvars"]["localhost"] = {}
    data["hostvars"]["localhost"]["ansible_facts"] = {}
    data["hostvars"]["localhost"]["ansible_facts"]["os_family"] = "Debian"

    from ansible.template import Templar
    templar = Templar(loader=None, variables=data)
    from ansible.playbook.base import Base
    module = Base()
    module._loader = None

    # import pprint
    # pp = pprint.PrettyPrinter(indent=1)

    def test(self, desc, when, expected_result):
        self.when = [ when ]
        result = self.evaluate_conditional(templar, data)

# Generated at 2022-06-22 14:10:35.560473
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    play_context = PlayContext()
    templar = Templar(loader=None, variables=combine_vars(loader=None, templar=templar, all_vars=dict(hostvars={})))

    # when
    conditional = Conditional()
    conditional.when = [{'hostvars[inventory_hostname]': 'foobar'}]
    assert conditional.evaluate_conditional(templar, dict(hostvars={})) == False
    assert conditional.evaluate_conditional(templar, dict(hostvars={'localhost': {'inventory_hostname': 'foobar'}})) == True

# Generated at 2022-06-22 14:10:48.819209
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class ConditionalHelper(Conditional):
        def __init__(self, loader):
            Conditional.__init__(self, loader)


# Generated at 2022-06-22 14:11:02.770646
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and (bar is defined or baz is not defined)") == \
        [("foo", "is", "defined"), ("bar", "is", "defined"), ("baz", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("hostvars['foo'] is defined") == [("hostvars['foo']", "is", "defined")]

# Generated at 2022-06-22 14:11:16.441528
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Retrieve the function to test
    fct = Conditional().evaluate_conditional
    # Tests
    # Define the variables
    all_vars = dict(
        collection = dict(
            variable = 'bar'
        ),
        ds = dict(
            variable = 'foo'
        ),
        var = 'foo'
    )