

# Generated at 2022-06-22 14:01:38.517943
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    conditional = "hostvars['somehostname'] is defined and hostvars['somehostname']['var'] is defined"
    results = c.extract_defined_undefined(conditional)
    assert results == [('hostvars[\'somehostname\']', 'is', 'defined'), ('hostvars[\'somehostname\'][\'var\']', 'is', 'defined')]
    assert results[0][0] == 'hostvars[\'somehostname\']'
    assert results[0][1] == 'is'
    assert results[0][2] == 'defined'
    assert results[1][0] == 'hostvars[\'somehostname\'][\'var\']'
    assert results[1][1] == 'is'

# Generated at 2022-06-22 14:01:45.502843
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    # Create an instance of class Conditional
    conditional = Conditional()

    # Conditional.extract_defined_undefined() only accepts strings, so test some strings
    # and check that the expected result is returned.

# Generated at 2022-06-22 14:01:52.622001
# Unit test for constructor of class Conditional
def test_Conditional():

    class MyConditional(Conditional):
        def __init__(self, loader):
            super(MyConditional, self).__init__(loader)
            self._loader = loader
            self.name = 'test'
            self.when = [True, 'test', False]

    conditional = MyConditional(None)
    assert conditional.when == [True, 'test', False]

# Generated at 2022-06-22 14:02:03.741368
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar

    class TestModule(object):
        def __init__(self, data, loader):
            self._ds = data
            self._loader = loader
            for attr in data:
                setattr(self, attr, data[attr])

    # setup stub objects
    t = Templar(loader=None)
    all_vars = dict(foo=1, bar=2, blah="Hello, I am a test string.", foo_bar="This sentence shouldn't match.")

    # test the tests
    assert DEFINED_REGEX.search("foo is defined and bar is defined")
    assert not DEFINED_REGEX.search("foo is defined and bar is not defined")
    assert DEFINED_REGEX.search("blah is not defined or blah is undefined")
    assert DEFINED_REGEX.search

# Generated at 2022-06-22 14:02:16.044698
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    actual = Conditional().extract_defined_undefined("{{ a not is defined }} and {{ b is not undefined }} and {{ c is defined }}")
    assert len(actual) == 3
    (a_var, a_logic, a_state) = actual[0]
    (b_var, b_logic, b_state) = actual[1]
    (c_var, c_logic, c_state) = actual[2]
    assert a_var == "a"
    assert a_logic == "not is"
    assert a_state == "defined"
    assert b_var == "b"
    assert b_logic == "is not"
    assert b_state == "undefined"
    assert c_var == "c"
    assert c_logic == "is"

# Generated at 2022-06-22 14:02:29.457213
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.task import Task

# Generated at 2022-06-22 14:02:42.259754
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar

    class TestClass(Conditional):
        def __init__(self, loader=None):
            super(TestClass, self).__init__(loader=loader)

# Generated at 2022-06-22 14:02:54.701795
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    conditional = Conditional()

    tests = [
        ('not hostvars["foo"] is defined', [('hostvars["foo"]', 'not is', 'defined')]),
        ('hostvars["foo"] is defined', [('hostvars["foo"]', 'is', 'defined')]),
        ('hostvars["foo"] is not undefined', [('hostvars["foo"]', 'is', 'undefined')]),
        ('hostvars["foo"] is not defined', [('hostvars["foo"]', 'is', 'defined')]),
    ]
    for test in tests:
        result = conditional.extract_defined_undefined(test[0])

# Generated at 2022-06-22 14:03:04.371552
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    def _get_vars(vars):
        new_vars = VariableManager()
        new_vars.extra_vars = vars
        return new_vars

    loader = DictDataLoader({})
    itm = Conditional(loader=loader)
    templar = Templar(loader=loader, variables=VariableManager())

    test_vars = {
        "a": True
    }
    itm.when = ["a"]
    assert itm.evaluate_conditional(templar, _get_vars(test_vars))

    test_vars = {
        "a": False
    }
    itm.when = ["a"]

# Generated at 2022-06-22 14:03:12.080183
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # First test, condition is True
    conditional = Conditional()
    conditional.when = [True]
    assert conditional.evaluate_conditional('', {})

    # Second test, condition is False
    conditional = Conditional()
    conditional.when = [False]
    assert not conditional.evaluate_conditional('', {})

    # Third test, condition is True
    conditional = Conditional()
    conditional.when = ['True']
    assert conditional.evaluate_conditional('', {})

    # Fourth test, condition is False
    conditional = Conditional()
    conditional.when = ['False']
    assert not conditional.evaluate_conditional('', {})

    # Fifth test, condition is True, validation error message
    conditional = Conditional()
    conditional.when = ['0']
    assert conditional.evaluate_conditional('', {})

    # Sixth

# Generated at 2022-06-22 14:03:26.420909
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = "hostvars[inventory_hostname] is defined and hostvars[inventory_hostname].group_names is defined and 'linux' in hostvars[inventory_hostname].group_names"

    obj = Conditional()
    assert obj.extract_defined_undefined(conditional) == [('hostvars[inventory_hostname]', 'is', 'defined'), ('hostvars[inventory_hostname].group_names', 'is', 'defined')]


# Generated at 2022-06-22 14:03:38.441149
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined("foo not is undefined") == [('foo', 'not is', 'undefined')]
    assert c.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert c.extract_defined_undefined("foo is undefined and bar not is defined") == \
        [('foo', 'is', 'undefined'), ('bar', 'not is', 'defined')]
    assert c.extract_defined_undefined("foo is not undefined or bar not is defined") == \
        [('foo', 'is not', 'undefined'), ('bar', 'not is', 'defined')]


# Generated at 2022-06-22 14:03:49.958536
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    raises = False
    try:
        test_object = Conditional()
        does_not_raise = test_object.evaluate_conditional(None, None)
    except (AnsibleError, TypeError):
        raises = True
    assert raises == True, "Test should raise exception"

    raises = False
    try:
        test_object = Conditional(None)
        does_not_raise = test_object.evaluate_conditional(None, None)
    except (AnsibleError, TypeError):
        raises = True
    assert raises == True, "Test should raise exception"

    raises = False
    try:
        test_object = Conditional()
        does_not_raise = test_object.evaluate_conditional(object(), object())
    except (AnsibleError, TypeError):
        raises = True
    assert raises

# Generated at 2022-06-22 14:03:55.252703
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class Test_Conditional:
        @staticmethod
        def __init__():
            self = Test_Conditional
            self._loader = DummyLoader()

        @staticmethod
        def evaluate_conditional(templar, all_vars):
            return Conditional.evaluate_conditional(self, templar, all_vars)

        @staticmethod
        def _check_conditional(conditional, templar, all_vars):
            return Conditional._check_conditional(self, conditional, templar, all_vars)

        @staticmethod
        def _validate_when(attr, name, value):
            return Conditional._validate_when(self, attr, name, value)

    tc = Test_Conditional()
    # we need a host for magic variables

# Generated at 2022-06-22 14:04:06.036971
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.play_context import PlayContext

    # test for code coverage on some other conditional
    assert Conditional(PlayContext()).extract_defined_undefined('something') == []


# Generated at 2022-06-22 14:04:15.105067
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

# Generated at 2022-06-22 14:04:20.313420
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.parsing import DataLoader

    conditional = "check_mode is not defined and (ansible_os_family == 'FreeBSD' or ansible_os_family == 'Linux')"

    loader = DataLoader()
    c = Conditional(loader=loader)
    results = c.extract_defined_undefined(conditional)
    assert(results == [('check_mode', 'is not', 'defined')])



# Generated at 2022-06-22 14:04:33.438776
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    cond = Conditional()


# Generated at 2022-06-22 14:04:44.459018
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class MockTemplar(object):

        def is_template(self, conditional):
            return False

        def template(self, conditional, disable_lookups=False):
            if 'raise AnsibleError' in conditional:
                raise AnsibleError('mock failure')
            return conditional

    class MockConditional(Conditional):
        pass

    templar = MockTemplar()
    conditional = MockConditional()

    all_vars = {
        'foo': 'bar',
        'baz': 'boo',
        'boo': 'foo',
        'gooo': 'blooo',
        'boooboohoo': '12',
        'array': ['foo', 'bar']
    }

    # True
    assert conditional.evaluate_conditional(templar, all_vars) is True
    assert conditional

# Generated at 2022-06-22 14:04:54.866073
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    cond = Conditional()
    play_context = PlayContext()
    play_context._set_variable_manager(Play()._variable_manager)
    play_context._set_task_and_variable_override('foo', dict(a='b'))
    templar = Templar(loader=None, variables=None, shared_loader_obj=None)
    res = cond.extract_defined_undefined('foo is defined and (bar is undefined or (baz is defined and baz == "zab"))')
    assert(res == [['foo', 'is', 'defined'], ['bar', 'is', 'undefined'], ['baz', 'is', 'defined']])
   

# Generated at 2022-06-22 14:05:24.061334
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    import pytest
    obj = Conditional(None)
    assert all(isinstance(i, tuple) for i in obj.extract_defined_undefined('result is defined'))
    assert all(isinstance(i, tuple) for i in obj.extract_defined_undefined('"result" not is defined'))
    assert all(isinstance(i, tuple) for i in obj.extract_defined_undefined('result is not undefined'))
    assert all(isinstance(i, tuple) for i in obj.extract_defined_undefined('"result" is undefined'))
    assert all(isinstance(i, tuple) for i in obj.extract_defined_undefined('"result" is undefined and other is defined'))

# Generated at 2022-06-22 14:05:36.968443
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class UnitUnderTest(Conditional):
        pass

    class TaskUnderTest(UnitUnderTest):
        pass

    class PlayUnderTest(UnitUnderTest):
        pass

    class PlaybookUnderTest(UnitUnderTest):
        pass

    class VariableManagerUnderTest(UnitUnderTest):
        pass

    FakeTemplar = type('FakeTemplar', (object,), {
        'template': lambda s, text: text,
        'is_template': lambda s, text: False,
        'environment': type('FakeEnvironment', (object,), {
            'parse': ast.parse,
            'compile': compile
        })(),
        'available_variables': {}
    })

    # classes without a _loader attribute fail
    uut = UnitUnderTest()

# Generated at 2022-06-22 14:05:48.395456
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    templar = Templar(loader=None, variables=VariableManager(), shared_loader_obj=None)

    c = Conditional()
    c._when = ['inventory_hostname == "host", "hostvar" in hostvars[inventory_hostname], False']

    all_vars = {
        'hostvar': 'value',
        'inventory_hostname': 'host',
        'omg': 'bbq',
    }

    assert c.evaluate_conditional(templar, all_vars) is True


# Generated at 2022-06-22 14:05:59.296500
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test when condition is empty
    cond1 = Conditional()
    cond1.when = ['']
    templar1 = DummyTemplar()
    all_vars1 = {'hostvars': {'hostname1': {'ansible_os_family': 'Debian'}}}
    assert cond1.evaluate_conditional(templar1, all_vars1)

    # Test when condition is not empty
    cond2 = Conditional()
    cond2.when = ['hostvars[inventory_hostname]["ansible_os_family"] == "Debian"']
    templar2 = DummyTemplar()
    all_vars2 = {'hostvars': {'hostname2': {'ansible_os_family': 'Red Hat'}}}
    assert not cond2.evaluate_cond

# Generated at 2022-06-22 14:06:10.528882
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    class FakeConditional(Conditional, AnsibleBaseYAMLObject):
        pass
    fake_conditional = FakeConditional()
    assert fake_conditional.extract_defined_undefined("hostvars['inventory_hostname'] == 'foo.bar'") == []
    assert fake_conditional.extract_defined_undefined("hostvars['inventory_hostname'] is 'foo.bar'") == []
    assert fake_conditional.extract_defined_undefined("hostvars['inventory_hostname'] not is 'foo.bar'") == []

# Generated at 2022-06-22 14:06:22.469145
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # test case {"conditional": "expected result"}
    test_cases = {
        "foo": True,
        "foo and bar": True,
        "foo and bar is defined": True,
        "bar is defined": True,
        "foo and bar is undefined": False,
        "foo is defined and bar is undefined": False,
        "not (foo is defined and bar is defined)": False,
        "not (foo is defined and bar is undefined)": True,
        "not (foo is undefined and bar is undefined)": True,
        "not (foo is undefined and bar is defined)": False,
    }
    from ansible.playbook.play_context import PlayContext

    pc = PlayContext()


# Generated at 2022-06-22 14:06:23.701921
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c.when == []

# Generated at 2022-06-22 14:06:30.946968
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    class TestConditional(Conditional):
        _name = 'test'
        _when = ['testvar']

    t = TestConditional(loader=loader)
    t._validate_when('testvar', '_when', 'testvar')
    assert t.evaluate_conditional(variable_manager.get_vars, {'testvar': 'testval'})

    t._validate_when('testvar', '_when', 'testvar2')

# Generated at 2022-06-22 14:06:31.653621
# Unit test for constructor of class Conditional
def test_Conditional():
    assert Conditional()

# Generated at 2022-06-22 14:06:43.022404
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # create instance of FieldAttribute class
    field_attribute = FieldAttribute(isa='list', default=list, extend=True, prepend=True)
    # set _when attribute on it
    field_attribute._when = ['{{ 1 < 2 }}', '{{ 1 > 2 }}']
    # create instance of Base class with when attribute
    test_base = Base(when=['{{ 1 < 2 }}', '{{ 1 > 2 }}'])
    # create instance of Conditional class with _when attribute set to `field_attribute._when`
    conditional = Conditional(when=field_attribute._when)
    # set _when attribute on instance of Conditional class
    conditional._when = field_attribute._when
    # set _ds attribute on instance of Conditional class
    conditional._ds = 'test'
    # create instance of DataLoader class
    loader = DataLoader

# Generated at 2022-06-22 14:07:21.749492
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager

    def _test(t, conditional, result):
        play_context = PlayContext()
        play_context.variable_manager = VariableManager()

# Generated at 2022-06-22 14:07:33.749446
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('') == []
    assert c.extract_defined_undefined('not x') == []
    assert c.extract_defined_undefined('not y is defined') == []
    assert c.extract_defined_undefined('x is not defined') == [('x', 'is', 'not')]
    assert c.extract_defined_undefined('y is not defined') == [('y', 'is', 'not')]
    assert c.extract_defined_undefined('z is defined') == [('z', 'is', 'defined')]
    assert c.extract_defined_undefined('x is undefined') == [('x', 'is', 'undefined')]

# Generated at 2022-06-22 14:07:44.232471
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined('foo not is undefined') == [('foo', 'not is', 'undefined')]
    assert c.extract_defined_undefined('bar is not defined') == [('bar', 'is not', 'defined')]
    assert c.extract_defined_undefined('1 > 2') == []
    assert c.extract_defined_undefined('foo == bar') == []
    assert c.extract_defined_undefined('(foo is defined) and (bar is not defined)') == [('foo', 'is', 'defined'), ('bar', 'is not', 'defined')]

# Generated at 2022-06-22 14:07:53.419840
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    '''
    This method tests the conditional evaluation logic in class Conditional
    methods_to_test: _check_conditional, _validate_when, evaluate_conditional
    '''

    class TestConditional(Conditional):

        def __init__(self):
            super(Conditional, self).__init__()
            self._loader = None
            self._name = None
            self._ds = None
            self._attributes = {}

    # This test case tests whether the truth table for the
    # Boolean logic operators is implemented correctly.
    #
    # In other words:
    # A and B | not A and B | A and not B | not A and not B
    # True     | False        | False       | True
    # False    | False        | True        | False

    test_

# Generated at 2022-06-22 14:08:04.568298
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    conditional = C.DEFAULT_UNDEFINED_VAR_BEHAVIOR == 'smart'
    cond = Conditional(loader=None)
    assert cond.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert cond.extract_defined_undefined("foo not is undefined") == [("foo", "not is", "undefined")]
    assert cond.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert cond.extract_defined_undefined("foo not is defined") == [("foo", "not is", "defined")]


# Generated at 2022-06-22 14:08:18.049927
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    import ansible.template
    import ansible.vars
    import ansible.inventory

    c = Conditional()

    pc = PlayContext()
    templar = ansible.template.Templar(loader=c._loader, variables=ansible.vars.VariableManager())

    host = ansible.inventory.Host(name="foobar")
    hostvars = ansible.vars.HostVars(
        host=host,
        variables=dict(
            a=1,
            b=2,
            sub=dict(
                c=3,
                d=4
            )
        )
    )

# Generated at 2022-06-22 14:08:26.816177
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()


# Generated at 2022-06-22 14:08:32.834941
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    assert conditional.extract_defined_undefined("") == []
    assert conditional.extract_defined_undefined("foo") == []
    assert conditional.extract_defined_undefined("foo and bar") == []
    assert conditional.extract_defined_undefined("foo and bar and hostvars[inventory_hostname] is defined") == [("hostvars[inventory_hostname]", "is", "defined")]
    assert conditional.extract_defined_undefined("foo and bar and hostvars[inventory_hostname] is defined and baz") == [("hostvars[inventory_hostname]", "is", "defined")]

# Generated at 2022-06-22 14:08:44.737568
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()


# Generated at 2022-06-22 14:08:56.877016
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.become import Become
    from ansible.playbook.connection import Connection
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    mock_ds = {'hosts': 'localhost'}

    assert Conditional().evaluate_conditional(Templar(loader=None, variables=dict()), dict())

    assert Conditional(loader=None).evaluate_conditional(Templar(loader=None, variables=dict()), dict())

    assert not Become(loader=None, when=[False]).evaluate_conditional(Templar(
        loader=None, variables=dict()), dict())

    assert not TaskInclude(loader=None, when=[False]).evaluate_conditional(
        Templar(loader=None, variables=dict()), dict())

    assert not TaskInclude

# Generated at 2022-06-22 14:10:10.337693
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    class MyConditional(Conditional):
        _validate_when = Conditional._validate_when
        _check_conditional = Conditional._check_conditional

    conditional = MyConditional()
    conditional.when = ['test1', 'test2', 'test3']

    templar = Templar(loader={}, variables={'a': True, 'b': False, 'c': True})
    templar._available_variables = {'a': True, 'b': False, 'c': True}
    templar.set_environment()
    templar.basedir = '.'

    conditional.when[0] = 'a'

# Generated at 2022-06-22 14:10:12.783065
# Unit test for constructor of class Conditional
def test_Conditional():
    cond = Conditional()

    assert cond._when == []
    assert isinstance(cond._when, list)


# Generated at 2022-06-22 14:10:18.288595
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class TestConditional(Conditional):
        pass

    results = TestConditional().extract_defined_undefined('not blah.defined and foo.defined')
    assert [(u'blah', u'not is', u'defined')] == results



# Generated at 2022-06-22 14:10:26.772600
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Dummy class for testing
    class DummyConditional:
        _when = FieldAttribute(isa='list', default=list, extend=True, prepend=True)

        def __init__(self, loader=None):
            pass

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar


# Generated at 2022-06-22 14:10:30.308952
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # TODO: This is a placeholder for a real test.
    #assert False,"TODO: Write a test that tests the method evaluate_conditional"
    assert True

# Generated at 2022-06-22 14:10:39.853329
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

# Generated at 2022-06-22 14:10:43.537292
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    item = Conditional()
    item.when = 'false'
    templar = FakeTemplar()
    all_vars = dict()
    assert item.evaluate_conditional(templar, all_vars) is False



# Generated at 2022-06-22 14:10:52.392850
# Unit test for constructor of class Conditional
def test_Conditional():
    class MyConditional(Conditional):
        def __init__(self, when, loader=None):
            super(MyConditional, self).__init__(loader)
            setattr(self, 'when', when)

    loader = None
    when = ['hostvars[inventory_hostname] is defined']
    cond = MyConditional(when, loader)

    # For some reason, the when statement is returned as a list
    assert when == cond._when

    assert cond.evaluate_conditional(None, None) is True

# Generated at 2022-06-22 14:11:04.812117
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import jinja2

    # Test setup
    class MockTemplar(object):
        '''Mock Templar object.'''
        def __init__(self, environment):
            self.environment = environment
            self.available_variables = {}

        def is_template(self, data, validate_only=False):
            '''True if the data is safe for templating, otherwise False.'''
            return True

        def template(self, data, convert_bare=True, preserve_trailing_newlines=False, fail_on_undefined=True, \
                     disable_lookups=False, escape_backslashes=True, override_vars=None):
            '''Returns the templated data, with jinja2 templating applied to it.'''
            return data

    # The data we will use for the tests.


# Generated at 2022-06-22 14:11:18.224454
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import sys
    import os
    import unittest

    # the base class we will use for testing
    class MyTestClass(Conditional):
        def __init__(self):
            super(MyTestClass, self).__init__()

        def evaluation_should_fail(self):
            # this method is used to test error handling in evaluate_conditional()
            raise Exception("This method should never be called!")

    # for the test cases we need a special step in our loader object
    class FakeStepLoader(object):
        def __init__(self):
            self.logger = display

        def get(self, *args, **kwargs):
            return self.fail_on_undefined_template_vars

    # create an instance of our test class
    t = MyTestClass()

    # create a test loader to be used by