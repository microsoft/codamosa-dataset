

# Generated at 2022-06-22 14:01:46.826347
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    test_vars = dict(
        foo=2,
        bar=1,
        zot=True,
        zap=False,
    )

    # We need a mock PlayContext
    pc = PlayContext()
    pc.variable_manager.extra_vars = dict(test_vars)

    # We need a mock loader
    class TestLoader():
        def __init__(self):
            self.paths = []

        def get_basedir(self):
            return '.'

    loader = TestLoader()

    # We need an object to use Conditional()
    class TestObject():
        pass

    obj = TestObject()
    obj._loader = loader
    obj.when = []

    # We need a mock

# Generated at 2022-06-22 14:01:56.999838
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    result = Conditional().extract_defined_undefined('hostvars["v2"] is defined or (hostvars["v1"] is not defined or hostvars["v1"])')
    assert result == [('hostvars["v2"]', 'is', 'defined'), ('hostvars["v1"]', 'is not', 'defined')]

    result = Conditional().extract_defined_undefined('hostvars["v1"] is not defined or hostvars["v1"]')
    assert result == [('hostvars["v1"]', 'is not', 'defined')]

    result = Conditional().extract_defined_undefined('1>2 and 3<4')
    assert result == []

# Generated at 2022-06-22 14:02:05.235221
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """
    Unit test for method evaluate_conditional of class Conditional.

    The method is tested in isolation, without the rest of the module.
    """

    # The template engine is a minimalistic one for the test.
    # It always returns the string argument passed to it, as long as it is a non-empty string
    class Templar:
        def is_template(self, arg):
            return isinstance(arg, str) and arg != ''
        def template(self, arg):
            return arg

    # A fake object that is the target of the method tested
    class FakeConditional:
        def __init__(self):
            self.when = []

    # Same instance for all tests
    templar = Templar()

    fake_vars = {}

    # Tests with no 'when' clause
    obj0 = FakeConditional()
   

# Generated at 2022-06-22 14:02:16.517696
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined('foo not is defined') == [('foo', 'not is', 'defined')]
    assert c.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined('foo not is undefined') == [('foo', 'not is', 'undefined')]
    assert c.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]

    # test multiple conditions

# Generated at 2022-06-22 14:02:29.993834
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

    result = c.extract_defined_undefined("foo is defined and bar is not defined")
    assert result == [('foo', 'is', 'defined'), ('bar', 'is not', 'defined')]

    result = c.extract_defined_undefined("foo is defined")
    assert result == [('foo', 'is', 'defined')]

    result = c.extract_defined_undefined("bar is not defined")
    assert result == [('bar', 'is not', 'defined')]

    result = c.extract_defined_undefined("(foo is defined and bar is not defined) or baz is defined")
    assert result == [('foo', 'is', 'defined'), ('bar', 'is not', 'defined'), ('baz', 'is', 'defined')]

    result = c.extract

# Generated at 2022-06-22 14:02:42.394475
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:02:54.891472
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    """
    Test Conditional.extract_defined_undefined()
    """
    class TestConditional(Conditional):
        pass

    c = TestConditional(loader={})
    conditional = "a is defined"
    result = c.extract_defined_undefined(conditional)
    assert result == [["a", "is", "defined"]]

    conditional = "a is defined and b is not defined"
    result = c.extract_defined_undefined(conditional)
    assert result == [["a", "is", "defined"], ["b", "is not", "defined"]]

    conditional = "a is defined and hostvars['foo'] is defined"
    result = c.extract_defined_undefined(conditional)

# Generated at 2022-06-22 14:03:06.438890
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-22 14:03:13.596989
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:03:19.124703
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    def_undef = conditional.extract_defined_undefined("a.b.c is defined and a.d.e is undefined")
    assert def_undef == [(u'a.b.c', u'is', u'defined'), (u'a.d.e', u'is', u'undefined')]

# Generated at 2022-06-22 14:03:46.566928
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined('foo is defined or bar is undefined') == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]

# Generated at 2022-06-22 14:03:57.267897
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()

    def test(conditional, templar, all_vars, result, msg=None):
        if conditional.evaluate_conditional(templar, all_vars) != result:
            raise AssertionError("conditional: %s, all_vars: %s, result: %s" % (conditional, all_vars, result))

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    templar = Templar(loader=loader, variables=VariableManager())

    test(Conditional(), templar, dict(a='foo'), True)


# Generated at 2022-06-22 14:04:06.716831
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = '''
        - name: foo
          debug:
            msg: "{{ hostvars['foo']['bar'] }}"
          when:
            - hostvars['foo']['bar']['baz'] is defined
            - hostvars['foo']['yolo'] is not defined
            - yolo is defined
            - 'foo' in groups
    '''
    cond = Conditional()
    def_undef = cond.extract_defined_undefined(conditional)
    assert ('hostvars[\'foo\'][\'bar\'][\'baz\']', 'is', 'defined') in def_undef
    assert ('hostvars[\'foo\'][\'yolo\']', 'is not', 'defined') in def_undef
    assert ('yolo', 'is', 'defined') in def_

# Generated at 2022-06-22 14:04:15.775106
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class MyBase:
        def __init__(self):
            self._ds = "ds"

    # Instantiate a Conditional object for negative testing
    cond = Conditional()

    # Instantiate a Conditional object for positive testing
    cond2 = Conditional(loader="loader")

    # Negative test which is expected to fail
    # Because the Base instance does not have attribute _ds
    try:
        for cond2 in cond.evaluate_conditional:
            pass
    except AnsibleError as e:
        assert "a loader must be specified when using Conditional() directly" in to_text(e)

    # Negative test which is expected to fail
    # Because Base instance does not initialize _when attribute
    try:
        cond2.evaluate_conditional
    except AnsibleError as e:
        assert "has no attribute '_when'" in to_

# Generated at 2022-06-22 14:04:21.529449
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class Base:
        def __init__(self):
            self._ds = None
    # Class with Conditional, so that method evaluate_conditional can be called
    class ConditionalTest(Conditional, Base):
        pass
    ctest = ConditionalTest()
    # variable_manager and loader are needed as attributes of class Play
    class Play:
        def __init__(self):
            self.variable_manager = None
            self.loader = None
    play = Play()
    # Templates need play, to call get_variables
    class Templates:
        def __init__(self, play):
            self.play = play
            self.basedir = None
            self.env = None
    # Templar needs play and templates, to call get_available_variables

# Generated at 2022-06-22 14:04:33.682521
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-22 14:04:41.386833
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    import base64
    from ansible.parsing.vault import VaultLib

    class DummyVaultLib(VaultLib):
        def __init__(self):
            pass
    VaultLib.get_vault_secrets = lambda: dict()
    VaultLib.get_vault_password = lambda x, y: 'd'
    vault = DummyVaultLib()

    class DummyVarsModule:
        def __init__(self):
            self.vars = dict()

    class DummyConnection:
        def __init__(self):
            self.become_method = ''

        def __nonzero__(self):
            return True

        def __bool__(self):
            return True

    class DummyPlayContext:
        def __init__(self):
            self.connection = DummyConnection()


# Generated at 2022-06-22 14:04:53.792091
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars

    fake_loader = DictDataLoader({
        "some_file": """
            - hosts: all
              gather_facts: no
              tasks:
                - name: some_task
                  ping:
                  when: hostvars[inventory_hostname]['some_var'] != '/a/b/c'
              """
    })
    fake_inventory = create_fake_inventory()
    variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)
    play_context = PlayContext()

# Generated at 2022-06-22 14:05:05.554293
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    class Test:
        _when = []
        def __init__(self,when=None,loader=None):
            self._when = when
            self._loader = loader
    loader = DataLoader()
    obj = Test(loader=loader)
    class Test2(Conditional):
        _when = []
        def __init__(self,when=None,loader=None):
            self._when = when
            self._loader = loader
            Conditional.__init__(self,loader=loader)
    obj2 = Test2(loader=loader)
    assert Conditional.evaluate_conditional(obj2, loader.load_from_file('test/test_jinja2/test_conditional.yml'), {'foo': 'bar'}) == False

# Generated at 2022-06-22 14:05:15.813059
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestClass:
        def __init__(self):
            pass

    test_class_instance = TestClass()
    test_conditional_instance = Conditional()
    test_conditional_instance._ds = test_class_instance
    test_conditional_instance.when = [
        'ansible_os_family in [ "Debian", "RedHat" ]',
        '"foo" in test_variable'
    ]
    test_variables = dict(
        test_variable="baz"
    )
    test_conditional_instance._loader = DictDataLoader(
        dict(
            templates=dict(
                fail_template="{{ foo }}"
            )
        )
    )

# Generated at 2022-06-22 14:05:57.531985
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    results = conditional.extract_defined_undefined("hostvars[inventory_hostname] is defined")
    assert results == [("hostvars[inventory_hostname]", "is", "defined")], results
    results = conditional.extract_defined_undefined("hostvars[inventory_hostname] is defined and hostvars[inventory_hostname].os == 'Linux'")
    assert results == [("hostvars[inventory_hostname]", "is", "defined")], results
    results = conditional.extract_defined_undefined("hostvars[inventory_hostname] is defined and hostvars[inventory_hostname].os == 'Linux' or hostvars[inventory_hostname].os is undefined")

# Generated at 2022-06-22 14:06:01.178034
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional._when == list(), "Default value of when is not an empty list"



# Generated at 2022-06-22 14:06:11.464231
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # pylint: disable=unused-import,import-error
    from ansible.playbook.base import Base
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    import ansible.constants as C

    # make a fake plugin loader
    loader = DictDataLoader()

    # force config to use a minimal set of vars

# Generated at 2022-06-22 14:06:12.703979
# Unit test for constructor of class Conditional
def test_Conditional():
    assert Conditional()


# Generated at 2022-06-22 14:06:22.197975
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conds = Conditional()
    conds.when = ['cond 1', 'cond 2']
    conds._check_conditional = lambda x, templar, all_vars: x == 'cond 1'

    assert conds.evaluate_conditional(templar = None, all_vars = None)

    conds = Conditional()
    conds.when = ['cond 1', 'cond 2']
    conds._check_conditional = lambda x, templar, all_vars: x == 'cond 3'

    assert not conds.evaluate_conditional(templar = None, all_vars = None)

# Generated at 2022-06-22 14:06:33.198930
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    """
    Tests for method extract_defined_undefined of class Conditional
    """
    conditional = Conditional()
    # Test with a simple expression
    ud = conditional.extract_defined_undefined("not x is defined and not y is undefined")
    assert ud == [("x", "is", "defined"), ("y", "is", "undefined")]
    # Test with an empty string
    ud = conditional.extract_defined_undefined("")
    assert ud == []
    # Test with a string without any definition
    ud = conditional.extract_defined_undefined("x is not empty")
    assert ud == []
    # Test with a definition with whitespaces
    ud = conditional.extract_defined_undefined("x     is     defined")

# Generated at 2022-06-22 14:06:45.249352
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    context = PlayContext()
    loader = DataLoader()
    vars_mgr = VariableManager(loader=loader)


# Generated at 2022-06-22 14:06:53.805910
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    import os

    basedir = os.path.dirname(os.path.dirname(__file__))
    loader = DataLoader()
    variable_manager = VariableManager()

    templar = Templar(loader=loader, variables=variable_manager)
    variable_manager.set_variable_manager(variable_manager)

    c = Conditional()
    c.when = ["'foo' in groups"]
    assert c.evaluate_conditional(templar, dict(groups=['bar', 'foo']))

    c.when = ["'foo' in groups", "inventory_hostname == 'localhost'"]
    assert c.evaluate_conditional(templar, dict(groups=['bar', 'foo'], inventory_hostname='localhost'))

   

# Generated at 2022-06-22 14:06:57.161661
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    if not isinstance(conditional, Conditional):
        raise AssertionError("'conditional' is not instance of class 'Conditional'")

# Generated at 2022-06-22 14:07:09.852954
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    a = Conditional()
    templar = None
    all_vars = dict(a='bar', foo=1)
    assert a.evaluate_conditional(templar, all_vars)
    a.when = []
    assert a.evaluate_conditional(templar, all_vars)
    a.when = ['foo']
    assert a.evaluate_conditional(templar, all_vars)
    a.when = ['foo is bar']
    assert not a.evaluate_conditional(templar, all_vars)
    a.when = ['foo is bar', 'a is bar']
    assert not a.evaluate_conditional(templar, all_vars)
    a.when = ['foo is bar', 'a is not bar']

# Generated at 2022-06-22 14:08:20.896768
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

# Generated at 2022-06-22 14:08:28.358524
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

# Generated at 2022-06-22 14:08:39.414813
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

# Generated at 2022-06-22 14:08:52.959808
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert([('hostvars[inventory_hostname]', 'is', 'defined')] == cond.extract_defined_undefined('hostvars[inventory_hostname] is defined'))
    assert([('hostvars[inventory_hostname]', 'is', 'defined'), ('myvar', 'is', 'defined')] == cond.extract_defined_undefined('hostvars[inventory_hostname] is defined and myvar is defined'))
    assert([('myvar', 'is', 'defined'), ('myvar2', 'is', 'defined')] == cond.extract_defined_undefined('myvar is defined or myvar2 is defined'))

# Generated at 2022-06-22 14:08:54.794503
# Unit test for constructor of class Conditional
def test_Conditional():
    class TestClass(Conditional):
        pass
    
    obj = TestClass()
    assert obj


# Generated at 2022-06-22 14:09:07.053698
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from jinja2 import Environment
    from jinja2.ext import Extension
    from jinja2.runtime import Undefined

    class MyExtension(Extension):
        pass

    class MyEnvironment(Environment):
        def __init__(self, extensions=()):
            super(MyEnvironment, self).__init__(extensions=[MyExtension])

    class Conditional(object):
        def __init__(self, when):
            self.when = when

        def evaluate_conditional(self, templar, all_vars):
            '''
            Loops through the conditionals set on this object, returning
            False if any of them evaluate as such.
            '''
            result = True

# Generated at 2022-06-22 14:09:20.120477
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    from ansible.playbook.task import Task
    from ansible.vars.manager import DefaultVariableManager
    from ansible.parsing.vault import VaultLib

    host_list = [
        {'hostname': 'host1', 'vars': {'var1': 'value1', 'var2': 'value2'}},
        {'hostname': 'host2', 'vars': {'var1': 'value1', 'var2': 'value2'}}
    ]
    inventory = InventoryManager(loader=DataLoader(), sources='')

# Generated at 2022-06-22 14:09:29.719109
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    # Init vars
    test_str = "{{ NotInVars }} == ok"
    test_str1 = "{{ NotInVars }} == foo"
    test_str2 = "{{ NotInVars }}"
    test_str3 = "{{ NotInVars }} is defined"
    test_str4 = "{{ NotInVars }} is foo"
    test_str5 = "{{ NotInVars }} == foo and {{ NotInVars }} == bar"


# Generated at 2022-06-22 14:09:37.751836
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    display.v['VERBOSITY'] = 0 # prevent debug output to stdout
    results = []
    c = Conditional()
    fakevars = {'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd'}

    results.append(c.evaluate_conditional(fakevars, True)) # True
    results.append(c.evaluate_conditional(fakevars, False)) # False
    results.append(c.evaluate_conditional(fakevars, 0)) # False
    results.append(c.evaluate_conditional(fakevars, 1)) # True
    results.append(c.evaluate_conditional(fakevars, [])) # False
    results.append(c.evaluate_conditional(fakevars, [])) # False

# Generated at 2022-06-22 14:09:48.166118
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    try:
        import jinja2
    except ImportError:
        raise SkipTest("jinja2 is required for this test")
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    ds = dict()
    t = Conditional(loader=loader)
    t._ds = ds

    # Test against a boolean
    ds['truthy'] = True
    assert t.evaluate_conditional(t, dict(ds=ds))
    ds['truthy'] = False
    assert not t.evaluate_conditional(t, dict(ds=ds))

    # Test against an int
    ds['num'] = 42
    assert t.evaluate_conditional(t, dict(ds=ds))
    ds['num'] = 1

# Generated at 2022-06-22 14:10:58.851400
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    class MyClass(Conditional):
        def __init__(self, loader=None):
            self._loader = loader
            self._variable_manager = VariableManager()
            self.inventory = Inventory(loader=loader, variable_manager=self._variable_manager, host_list=['localhost'])
            self._variable_manager.set_inventory(self.inventory)
            self.when = ['foo', 'bar and not baz', 'ansible_distribution == "Fedora"']
    obj = MyClass(DataLoader())

# Generated at 2022-06-22 14:11:07.953317
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional = Conditional()

    from ansible.vars.unsafe_proxy import wrap_var

    class DummyLoader:
        def get_basedir(self):
            return '/nonexistent'

    class DummyTemplar:
        def __init__(self, variables):
            self.loader = DummyLoader()
            self.environment = None
            self.available_variables = variables

        def template(self, data, disable_lookups=False):
            return data

        def is_template(self, data):
            return data.startswith('{{') and data.endswith('}}')

    # Simple conditional check
    conditional.when = wrap_var(['var1 is defined'])

# Generated at 2022-06-22 14:11:19.583627
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # test case 1: when is a list
    when = []
    conditional = "foo.bar == 'ok'"
    when.append(conditional)
    cond = Conditional()
    cond._ds = MockData()
    cond._validate_when(None, 'when', when)

    templar = MockTemplar(conditional)
    all_vars = MockAllVars()
    result = cond.evaluate_conditional(templar, all_vars)

    assert result is True

    # test case 2: when is a string
    when = "foo.bar == 'ok'"
    conditional = "foo.bar == 'ok'"
    cond = Conditional()
    cond._ds = MockData()
    cond._validate_when(None, 'when', when)
