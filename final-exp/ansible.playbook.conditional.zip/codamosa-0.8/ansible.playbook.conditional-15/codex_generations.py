

# Generated at 2022-06-22 14:01:33.852975
# Unit test for constructor of class Conditional
def test_Conditional():
    templar = MockTemplar()
    loader = MockLoader()
    res = Conditional(loader)
    assert isinstance(res, Conditional)



# Generated at 2022-06-22 14:01:42.077228
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # unit tests for extract_defined_undefined()
    # This needs templar object (see construct_* tests)
    global templar
    # For convenience
    eu = Conditional().extract_defined_undefined

    # simple logic
    assert eu("foo is defined") == [('foo', 'is', 'defined')]
    assert eu("foo not is defined") == [('foo', 'not is', 'defined')]
    assert eu("foo is not defined") == [('foo', 'is not', 'defined')]
    assert eu("foo not is not defined") == [('foo', 'not is not', 'defined')]
    assert eu("foo is undefined") == [('foo', 'is', 'undefined')]

# Generated at 2022-06-22 14:01:52.726862
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    import sys

    import unittest2 as unittest
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.template import Templar

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    class TestConditional(unittest.TestCase):

        def setUp(self):
            self.loader = DataLoader()
            self.variable_manager = VariableManager()
            self.result = None
            self.templar = Templar(loader=self.loader, variables=self.variable_manager)

            self.variable_manager.set_variable_amount_warnings(0)

# Generated at 2022-06-22 14:02:03.808755
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

# Generated at 2022-06-22 14:02:16.033600
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    cond1 = "foo is defined and bar is not defined"
    cond2 = "foo and foo is not defined or bar"
    cond3 = "foo is defined or bar and baz is undefined"
    cond4 = "foo"
    cond5 = "foo and bar is not defined"
    cond6 = "foo is defined and bar and baz is not undefined"
    cond7 = "a is defined and b not is defined or c is not defined"
    cond8 = "not (a is defined and b is defined)"
    cond9 = "a and b or c and d is not defined"
    cond10 = "foo is not defined"
    cond11 = "foo is undefined"
    cond12 = "foo is defined and bar is not defined and baz is defined"

# Generated at 2022-06-22 14:02:22.307474
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    cond = Conditional()

    result = cond.extract_defined_undefined('result | failed and (ansible_facts["distribution"] is defined)')

    assert result == [['ansible_facts["distribution"]', 'is', 'defined']]


# Generated at 2022-06-22 14:02:32.495567
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestClass():
        def __init__(self, loader=None):
            self._loader = loader
            self._ds = dict()
            self.when = []

    class TestLoader():
        def __init__(self, variable_manager):
            self._variable_manager = variable_manager

    class TestVariableManager():
        def __init__(self, inventory):
            self._inventory = inventory

    class TestInventory():
        def __init__(self):
            self._hosts_cache = dict()


    #####################################################################
    # test 1
    #####################################################################
    hostvars = dict()
    hostvars[u'127.0.0.1'] = dict()

# Generated at 2022-06-22 14:02:44.737169
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.base import Base
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    class TestConditional(Conditional, Base):
        pass

    loader = DictDataLoader({})
    test_obj = TestConditional(loader=loader)

    # Test if the conditional with invalid variable not throw error
    test_obj.when = 'my_var_which_not_defined'
    res = test_obj.evaluate_conditional(loader.load_from_file, dict())
    assert res is False

    # Test if the conditional with invalid variable

# Generated at 2022-06-22 14:02:57.814671
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar

    inventory = InventoryManager(loader=DataLoader(), sources=[])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

    class TestObject(Conditional):
        def __init__(self):
            self._ds = dict()

    conditional = TestObject()
    conditional.when = "a == 5 and b == 6"

    variable_manager.set_host_variable(host=None, varname='a', value="5")
    variable_manager.set_host_variable(host=None, varname='b', value="6")


# Generated at 2022-06-22 14:03:08.372423
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:03:20.310507
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()

    # test that str() and repr() of an undefined conditional return nothing
    assert str(conditional) == ''
    assert repr(conditional) == "<ansible conditional />"

# Generated at 2022-06-22 14:03:28.500931
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

    # object is defined
    conditional = 'is_defined is defined'
    res = c.extract_defined_undefined(conditional)
    assert len(res) == 1
    assert res[0][0] == 'is_defined'
    assert res[0][1] == 'is'
    assert res[0][2] == 'defined'

    # object is not defined
    conditional = 'is_undefined is not defined'
    res = c.extract_defined_undefined(conditional)
    assert len(res) == 1
    assert res[0][0] == 'is_undefined'
    assert res[0][1] == 'is not'
    assert res[0][2] == 'defined'

    # object is undefined
    conditional = 'is_undefined is undefined'
   

# Generated at 2022-06-22 14:03:31.304205
# Unit test for constructor of class Conditional
def test_Conditional():
    '''
    condtional = Conditional(loader='some_loader')
    assert conditional is not None
    '''
    pass

# Generated at 2022-06-22 14:03:34.420264
# Unit test for constructor of class Conditional
def test_Conditional():
    # success test
    obj = Conditional()

    # failure test
    try:
        obj = Conditional(loader=None)
        assert False
    except AnsibleError:
        assert True



# Generated at 2022-06-22 14:03:46.980749
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    class TestConditional():
        # (variable, logic, state)
        conditions = (
            ('a', 'is', 'defined'),
            ('a is defined', '', ''),
            ('b is not undefined', '', ''),
            ('c is not defined', '', ''),
            ('c is undefined', '', ''),
            ('b is defined and c is defined', '', ''),
            ('b is defined or c is defined', '', ''),
            ('not c is defined', '', ''),
            ('not c is undefined', '', ''),
            ('a is defined and b is not defined or c is undefined', '', ''),
            ('a is defined and b is not defined or c is undefined and d is', '', ''),
        )

    for cond in TestConditional:
        results = conditional

# Generated at 2022-06-22 14:03:53.731855
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext

    class BaseForTest:

        def __init__(self):
            self._ds = None
            self._loader = None

    class ConditionalForTest(Conditional):
        pass

    class TestModule:

        def __init__(self):
            self.params = dict(
                foo=dict(
                    bar=None,
                ),
            )

    class VariableManagerForTest:
        def __init__(self):
            self.extra_vars = dict(
                foo=dict(
                    bar='hello'
                ),
            )
            self.host_vars = self.extra_vars

    play_context = PlayContext()
    variable_manager = VariableManagerForTest()

    conditional_test = ConditionalForTest()

# Generated at 2022-06-22 14:03:58.948946
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    display = Display()
    display.verbosity = 5

    import ansible.plugins.loader as plugins
    import ansible.template as template
    plugins.add_all_plugin_dirs()

    import jinja2
    jenv = jinja2.Environment(undefined=jinja2.StrictUndefined)
    jenv.filters.update(C.DEFAULT_JINJA2_FILTERS)
    loader = jinja2.BaseLoader()
    t = template.AnsibleJ2TemplateModule(loader=loader, shared_loader_obj=None, jinja2_env=jenv)


# Generated at 2022-06-22 14:04:07.659769
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    handlers = []
    results = []
    t1 = Task()
    t1.name = 'test task'
    t1._role = None
    t1._loader = loader

# Generated at 2022-06-22 14:04:17.997440
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # setup
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(one='foo',two='bar',three=dict(four='baz'))
    variable_manager.set_nonpersistent_facts(dict(five=dict(six='qux')))

    # test with no when clause
    p = Conditional()
    assert p.evaluate_conditional(PlayContext(variable_manager=variable_manager), variable_manager.get_vars(loader=None)) == True

    # test with a single when clause
    p._when = [ 'one in [\'foo\',\'bar\']' ]

# Generated at 2022-06-22 14:04:18.894576
# Unit test for constructor of class Conditional
def test_Conditional():
    assert Conditional(None)

# Generated at 2022-06-22 14:04:45.771830
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert [("foo", "is", "defined")] == cond.extract_defined_undefined("foo is defined")
    assert [("foo", "is", "defined")] == cond.extract_defined_undefined("foo is   defined")
    assert [("foo", "is", "not"), ("foo", "is", "defined")] == cond.extract_defined_undefined("foo is not defined")
    assert [("foo", "is", "not"), ("foo", "is", "defined")] == cond.extract_defined_undefined("foo is not  defined")
    assert [("foo", "is", "not"), ("foo", "is", "defined")] == cond.extract_defined_undefined("foo is  not  defined")

# Generated at 2022-06-22 14:04:46.961137
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()


# Generated at 2022-06-22 14:04:56.377541
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook import Playbook
    from ansible.template import Templar

    # This first test checks that undefined variables are evaluated to false
    # and enforcing this behavior with a conditional is optional
    pb = Playbook()
    t = Templar(pb.extra_vars, pb._loader)
    c = Conditional()
    c._loader = pb._loader
    assert c.evaluate_conditional(t, dict(foo='bar')) is True
    c.when = ['foo is undefined']
    assert c.evaluate_conditional(t, dict(foo='bar')) is False

    # This second test checks the handling of undefined variables in conditionals
    # with the enforce_undefined_variables Ansible config value set to True
    C.ANSIBLE_HOST_VARIABLE_MAPPING_FILE = None  #

# Generated at 2022-06-22 14:05:08.121133
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    ''' Unit test for method Conditional.evaluate_conditional.

        Input: self, templar, all_vars
        Output: True or False
    '''
    # case 1: conditional is None
    conditional = None
    templar = None
    all_vars = None

    cond = Conditional()
    res = cond.evaluate_conditional(templar, all_vars)

    assert (res is True)

    # case 2: conditional is bool type
    conditional = True
    templar = None
    all_vars = None

    cond = Conditional()
    res = cond.evaluate_conditional(templar, all_vars)

    assert (res is True)

    # case 3: conditional is str type, but is empty
    conditional = ""
    templar = None
    all_

# Generated at 2022-06-22 14:05:16.713697
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    _conditional = Conditional()
    conditional = "sanpham is defined and sanpham not in aaa"
    def_undef = _conditional.extract_defined_undefined(conditional)
    assert def_undef == [('sanpham', 'is', 'defined')] , "test failed %s" % def_undef
    conditional = "sanpham is defined and sanpham in aaa"
    def_undef = _conditional.extract_defined_undefined(conditional)
    assert def_undef == [('sanpham', 'is', 'defined')] , "test failed %s" % def_undef
    conditional = "sanpham is not defined and sanpham in aaa and sanpham not in bbb"
    def_undef = _conditional.extract_defined_und

# Generated at 2022-06-22 14:05:26.898804
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    # common cases
    assert cond.extract_defined_undefined("a.b.c.d is defined") == [ ("a.b.c.d", "is", "defined") ]
    assert cond.extract_defined_undefined("a.b.c.d is not defined") == [ ("a.b.c.d", "is not", "defined") ]
    assert cond.extract_defined_undefined("a.b.c.d is undefined") == [ ("a.b.c.d", "is", "undefined") ]
    assert cond.extract_defined_undefined("a.b.c.d is not undefined") == [ ("a.b.c.d", "is not", "undefined") ]
    # with extra spaces
    assert cond.extract_defined_undefined

# Generated at 2022-06-22 14:05:38.781741
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-22 14:05:49.948143
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
   conditional = Conditional()
   test_case = '''
       (foo1 is defined and foo2 is not defined) and
       (foo3 is defined or foo4 is defined) and
       (foo5 is defined and foo6 is undefined) and
       (foo7 is not defined or foo8 is not defined)
   '''
   result = conditional.extract_defined_undefined(test_case)
   assert len(result) == 8
   assert result[0] == ("foo1", "is", "defined")
   assert result[1] == ("foo2", "is not", "defined")
   assert result[2] == ("foo3", "is", "defined")
   assert result[3] == ("foo4", "is", "defined")
   assert result[4] == ("foo5", "is", "defined")

# Generated at 2022-06-22 14:06:00.342182
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from jinja2 import Environment as JinjaEnvironment

    class FakeData(object):
        def __init__(self):
            self.ds = 'fake'

    class FakeTemplar(object):
        def __init__(self):
            class FakeEnvironment(object):
                def __init__(self):
                    self.filters = {}
            self.environment = FakeEnvironment()
            self._available_variables = {}

        def set_available_variables(self, variables):
            self._available_variables = variables

        @property
        def available_variables(self):
            return self._available_variables

        @available_variables.setter
        def available_variables(self, variables):
            self._available_variables = variables


# Generated at 2022-06-22 14:06:10.901621
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('foo is not defined and bar is not defined') == [('foo', 'is not', 'defined'), ('bar', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('foo is not defined and (bar is not defined or baz is not undefined)') == [('foo', 'is not', 'defined'), ('bar', 'is not', 'defined'), ('baz', 'is not', 'undefined')]

# Generated at 2022-06-22 14:06:54.302060
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.module_utils.six import iteritems

    from ansible.playbook.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.template import Templar

    # Create a fake inventory
    inv = Inventory(loader=None)

    # Create host
    hn = "test_host"
    host = Host(name=hn)
    host.set_variable("inventory_hostname", hn)
    host.set_variable("group_names", ["test_group"])

    # Create group
    gn = "test_group"
    group = Group(name=gn)
    group.set_variable("inventory_group_name", gn)

    # Add host to group
    group.add_host(host)

    # Add group to inventory
    inv

# Generated at 2022-06-22 14:06:58.148808
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader

    # instantiate a class
    conditional = Conditional(loader=DataLoader())
    assert conditional is not None


# Generated at 2022-06-22 14:07:07.433787
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestClass(Conditional):
        pass
    test_instance = TestClass()
    assert test_instance.evaluate_conditional(conditional=None) is True
    assert test_instance.evaluate_conditional(conditional=1) is True
    assert test_instance.evaluate_conditional(conditional=0) is True
    assert test_instance.evaluate_conditional(conditional='') is True
    assert test_instance.evaluate_conditional(conditional=True) is True
    assert test_instance.evaluate_conditional(conditional=False) is False

# Generated at 2022-06-22 14:07:17.313363
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar

    # Make sure the template returns a non-empty string when
    # the condition is true
    host_vars = {'foo': True, 'bar': False}
    loader = MockDataLoader()
    templar = Templar(loader=loader, variables=host_vars)
    c = Conditional(loader=loader)
    c.when = ["{{ foo }}"]
    assert c.evaluate_conditional(templar, host_vars)

    # Make sure the template fails when the condition is false
    host_vars = {'foo': False, 'bar': False}
    loader = MockDataLoader()
    templar = Templar(loader=loader, variables=host_vars)
    c = Conditional(loader=loader)
    c.when = ["{{ foo }}"]

# Generated at 2022-06-22 14:07:26.340379
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    c = Conditional(loader)

    conditional = 'hostvars[\'host1\'][\'foo\'] not is defined or hostvars[\'host2\'][\'bar\'] is undefined or hostvars[\'host3\'][\'baz\'] is defined'
    # this should extract the var names, logic and state from a dictionary of lists
    # [ {'hostvars[\'host1\'][\'foo\']', 'not', 'defined'},
    #   {'hostvars[\'host2\'][\'bar\']', 'is', 'undefined'} ]
    extracted = c.extract_defined_undefined(conditional)


# Generated at 2022-06-22 14:07:29.090662
# Unit test for constructor of class Conditional
def test_Conditional():
    class test_class():
        pass

    conditional = Conditional(None)
    assert isinstance(conditional, Conditional)
    assert conditional._when == []
    assert conditional._loader == None
    assert conditional._ds == None

    test_class.when = []
    conditional = Conditional(None)
    assert not isinstance(conditional, Conditional)


# Generated at 2022-06-22 14:07:38.909408
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """
       Unit Tests for method evaluate_conditional of class Conditional
    """
    # Check if the conditional evaluates to False in case if the condition is None or empty string
    import ansible.playbook
    import ansible.template
    templar = ansible.template.Templar(loader=None, variables={'test_var': 'test_var_val'})
    conditional = None
    all_vars = dict()
    cond = Conditional(loader=None)
    assert not cond.evaluate_conditional(templar, all_vars)

    conditional = ''
    assert not cond.evaluate_conditional(templar, all_vars)

    # Check if the conditional evaluates to False in case if the condition evaluates to False
    conditional = 'test_var != test_var_val'
    assert not cond.evaluate_

# Generated at 2022-06-22 14:07:47.604316
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    # test evaluate_conditional given when having a single conditional
    conditional_task_1 = Task()
    setattr(conditional_task_1, 'when', ['1 == 1'])
    assert conditional_task_1.evaluate_conditional(templar, {})
    setattr(conditional_task_1, 'when', ['1 == 0'])
    assert not conditional_task_1.evaluate_conditional(templar, {})

    # test evaluate_conditional given when having a list of conditional
    conditional_task_2 = Task()

# Generated at 2022-06-22 14:07:54.238558
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    import sys
    import __main__

    if sys.version_info[:2] == (2, 6):
        raise Exception("The Conditional class is not valid to test in Python 2.6")

    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    class TestPlaybook(object):
        def __init__(self):
            self.hostvars = dict(
                localhost=dict(
                    test="defined",
                    test2="defined but undefined",
                    test3="defined",
                )
            )

    class TestConditional(Conditional):
        def __init__(self):
            super(TestConditional, self).__init__(loader=None)

    #When

    #   Conditional is True
    #   ------------------

    #When

# Generated at 2022-06-22 14:08:04.134755
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

# Generated at 2022-06-22 14:09:22.598328
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Set up
    cond = Conditional()
    cond._when = ["foo", "bar", "foobar", "foofoo", "barfoo"]
    templar = None
    all_vars = {"foo": True, "bar": False, "foobar": False, "foofoo": True}
    expected_result = False

    # Test
    result = cond.evaluate_conditional(templar, all_vars)
    assert result == expected_result, 'Expected {} but got {}'.format(expected_result, result)


# Generated at 2022-06-22 14:09:31.201044
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    def create_instance(when):
        instance = Conditional()
        setattr(instance, '_when', when)
        return instance

    when = 'foo is not defined and bar is defined and zap is undefined'
    instance = create_instance(when)
    assert instance.extract_defined_undefined(when) == \
        [('foo', 'is not', 'defined'), ('bar', 'is ', 'defined'), ('zap', 'is', 'undefined')]

    when = 'bar is defined'
    instance = create_instance(when)
    assert instance.extract_defined_undefined(when) == [('bar', 'is ', 'defined')]

    when = 'bar is not defined'
    instance = create_instance(when)

# Generated at 2022-06-22 14:09:43.470290
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    res = c.extract_defined_undefined("a is defined and b is not defined")
    assert(res == [("a", "is", "defined"), ("b", "is not", "defined")])

    res = c.extract_defined_undefined("a is undefined or b is not undefined")
    assert(res == [("a", "is", "undefined"), ("b", "is not", "undefined")])

    res = c.extract_defined_undefined("a is defined and b is undefined")
    assert(res == [("a", "is", "defined"), ("b", "is", "undefined")])

    res = c.extract_defined_undefined("a is undefined or b is defined")

# Generated at 2022-06-22 14:09:52.127109
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    '''
    Test for various conditions
    '''

    # FIXME: the tests are currently pretty messy, but could be easily
    #        cleaned up once we have proper argument spec validation

    class FakeTemplar(object):
        def __init__(self, ds):
            self._ds = ds
        def is_template(self, data):
            return False
        def template(self, data, disable_lookups=None):
            return data
        @property
        def environment(self):
            # FIXME: probably need to mock the TemplateEnvironment
            return self._ds

    class TestConditional(Conditional):
        def __init__(self, ds, when, loader=None):
            self._when = when
            self._ds = ds
            super(TestConditional, self).__init__(loader=loader)

# Generated at 2022-06-22 14:10:01.001636
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    """
    Test for method extract_defined_undefined of class Conditional
    """
    conditional = Conditional()
    result = conditional.extract_defined_undefined('defined')
    assert list() == result

    result = conditional.extract_defined_undefined('hostvars["foo"] is defined')
    assert [(u'hostvars["foo"]', u'is', u'defined')] == result

    result = conditional.extract_defined_undefined(r'hostvars[\'foo\'] is defined and hostvars["bar"] is not undefined')
    assert [(u'hostvars[\'foo\']', u'is', u'defined'), (u'hostvars["bar"]', u'is not', u'undefined')] == result


# Generated at 2022-06-22 14:10:11.275056
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    collect = {'a': '1', 'b': '2', 'c': '3'}
    class Foo(Conditional):
        def __init__(self, loader):
            self._loader = loader
            self._ds = dict(name='foo')

    loader = None
    f = Foo(loader)

    # test simple equality evaluation
    f._when = ['a == 1']
    result = f.evaluate_conditional(None, collect)
    assert result == True, "a == 1"
    f._when = ['a != 1']
    result = f.evaluate_conditional(None, collect)
    assert result == False, "a != 1"
    f._when = ['a == 1 or b == 2']
    result = f.evaluate_conditional(None, collect)

# Generated at 2022-06-22 14:10:23.594728
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    conditioned_task = Task()
    conditioned_task.when = ["false", "false", "false"]
    conditioned_task.when[0] = 'ansible_play_hosts == ["localhost"]'
    conditioned_task.when[1] = ["false", "true", "true"]
    conditioned_task.when[1][0] = 'ansible_play_hosts == ["localhost", "127.0.0.1"]'
    conditioned_task.when[1][1] = 'ansible_play_hosts == ["localhost", "127.0.0.2"]'

# Generated at 2022-06-22 14:10:35.602122
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    class TestClass(Conditional):
        def __init__(self, loader, variable_manager):
            self.variable_manager = variable_manager
            super(TestClass, self).__init__(loader=loader)

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    t = Templar(loader=loader, variables=variable_manager)

    c = TestClass(loader, variable_manager)
    c.when = ['this is true', 'True', False]
    assert c.evaluate_conditional(t, {}) is False

    c.when = []
    assert c.evaluate_conditional(t, {}) is True


# Generated at 2022-06-22 14:10:48.866446
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    All conditions are false, because they are undefined:
    '''

    class MockTemplar:
        def __init__(self, is_template_result=False, template_result=''):
            self.is_template_result = is_template_result
            self.template_result = template_result
            self.available_variables = {}

        def is_template(self, data):
            return self.is_template_result

        def template(self, data, disable_lookups):
            return self.template_result

    t = MockTemplar()

    c = Conditional()


# Generated at 2022-06-22 14:10:53.703847
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class TestConditional(Conditional):
        def __init__(self):
            self._when = FieldAttribute(isa='list', default=list, extend=True, prepend=True)

    # AssertionError: Lists differ: ['foo', 'bar'] != ['foo', 'bar', 'baz']
    # First differing element 0:
    # foo
    # baz
    # ['foo', 'bar']
    # ['foo', 'bar', 'baz']
    t = TestConditional()
    actual = t.extract_defined_undefined("fred is defined and not bar is undefined")
    assert actual == [('fred', 'is', 'defined'), ('bar', 'not is', 'undefined')], actual
    actual = t.extract_defined_undefined("not fred is defined and bar is undefined")