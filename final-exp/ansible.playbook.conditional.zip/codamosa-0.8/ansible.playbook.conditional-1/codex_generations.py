

# Generated at 2022-06-22 14:01:39.125618
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # Setup playbook
    variable_manager = VariableManager()
    loader = variable_manager.loader
    variable_manager.set_inventory(loader.load_inventory_from_list([{'hosts': ['localhost']}]))

    # Setup play
    play_context = PlayContext()
    play_source = dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        roles = [],
        tasks = []
    )


# Generated at 2022-06-22 14:01:45.873865
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """
    Runs a simple unit test of Conditional.evaluate_conditional()
    """
    # set up test objects
    cond = Conditional()
    templar = dict()
    all_vars = dict()

    # if variable x is in the dict, return True, else False
    def is_set_x(x):
        return (x in all_vars)

    # check if variable y is not in the dict, return True, else False
    def is_not_set_y(y):
        return (y not in all_vars)

    # test when has no elements
    assert cond.evaluate_conditional(templar, all_vars) == True

    # test when evaluates to True
    cond.when = ["'something' in hostvars['foo']"]

# Generated at 2022-06-22 14:01:53.653256
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class Dummy(object):
        pass
    display = Dummy()
    display.debug = lambda x: None
    # Test for the case where condition is None or empty string
    conditional = Conditional(loader=Dummy())
    conditional._ds = 'fake_ds'
    conditional._when = [None, '', True]
    templar = Dummy()
    # Set templar.template method to identity function
    templar.template = lambda x, dl=False: x
    assert conditional.evaluate_conditional(templar, {}) == True
    # Test for the case where conditional is not a string
    conditional = Conditional(loader=Dummy())
    conditional._ds = 'fake_ds'
    conditional._when = [False, 0, 1]
    assert conditional.evaluate_conditional(templar, {})

# Generated at 2022-06-22 14:02:03.991164
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    myplay = PlayContext()
    myplay._variable_manager = {"host_vars": {"foo": "bar"}, "group_vars": {}, "extra_vars": {}}
    templar = Templar(play=myplay)
    myplay._variable_manager._extra_vars = {"foo": "bar"}  # use dict to avoid deprecation notice about "foo"

    # Test for a normal conditional operation
    conditional = Conditional()
    assert conditional.evaluate_conditional(templar, myplay._variable_manager._extra_vars)

    # Test for a simple conditional that should not be true
    conditional = Conditional()
    conditional.when = ['1 == 2']  # the opposite of a true statement

# Generated at 2022-06-22 14:02:16.147452
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class TestConditional(Conditional): pass
    c = TestConditional()

    assert (c.extract_defined_undefined('myvar is defined')) == \
        [('myvar', 'is', 'defined')]
    assert (c.extract_defined_undefined('myvar is defined and othervar is undefined')) == \
        [('myvar', 'is', 'defined'), ('othervar', 'is', 'undefined')]
    # Test with not
    assert (c.extract_defined_undefined('myvar is not defined')) == \
        [('myvar', 'is not', 'defined')]

# Generated at 2022-06-22 14:02:29.630820
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.conditional import Conditional
    conditional = Conditional()
    test_strings = [
        "foo not is defined",
        "foo is defined",
        "foo is not defined",
        "hostvars['foo'] is not defined",
        "hostvars[inventory_hostname] is not defined",
        "hostvars[inventory_hostname] is defined",
        "hostvars['foo'] not is defined or hostvars[inventory_hostname] is defined and hostvars['foo'] is defined",
    ]
    for (i, cond_str) in enumerate(test_strings, start=1):
        results = conditional.extract_defined_undefined(cond_str)

# Generated at 2022-06-22 14:02:34.626317
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

    # Test with a lot of conditions containing and not containing is or is not defined or undefined

# Generated at 2022-06-22 14:02:45.422760
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.template import Templar
    from ansible.vars import VariableManager


# Generated at 2022-06-22 14:02:57.867232
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("foobar is not defined") == [("foobar", "is not", "defined")]
    assert c.extract_defined_undefined("foobar is defined") == [("foobar", "is", "defined")]
    assert c.extract_defined_undefined("foobar is undefined") == [("foobar", "is", "undefined")]
    assert c.extract_defined_undefined("foobar not is defined") == [("foobar", "not is", "defined")]
    assert c.extract_defined_undefined("foobar not is undefined") == [("foobar", "not is", "undefined")]

# Generated at 2022-06-22 14:03:08.412302
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager,  host_list=['localhost'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variable_manager=variable_manager, play_context=play_context)

    conditional = Conditional()

    class ConditionalObj:
        def __init__(self, when_conditions, loader):
            self._when = when_conditions
            self

# Generated at 2022-06-22 14:03:24.774859
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    def _run_test(args, templar, assertions):
        assert len(args) == len(assertions) + 1

        c = Conditional()
        c.when = args[0]

        for i in range(len(assertions)):
            res = c.evaluate_conditional(templar, args[i + 1])
            assert res == assertions[i], "expected=%s, actual=%s, when=%s" % (assertions[i], res, args[0])

    from ansible.template import Templar


# Generated at 2022-06-22 14:03:36.944295
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Verify members are present
    conditional = Conditional()
    assert hasattr(conditional, '_when')

    # Verify members are available through constructor
    assert isinstance(conditional._when, list)
    assert len(conditional._when) == 0
    assert conditional._when[0:0] == []

    assert hasattr(conditional, '_loader')

    # Validation
    conditional = Conditional('loader')
    assert conditional._loader == 'loader'

    # Validation
    # Since a datastructure is required, we need both a loader and a datastructure

# Generated at 2022-06-22 14:03:48.661344
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # NOTE:  Failing tests are commented out as the variables are in fact undefined
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    hostvars = {'localhost': {'foo': 1, 'bar': 2, 'bam': 3, 'barfoo': 4}}

    import jinja2
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.set_inventory(inventory)

    templar = Templar(loader=loader, variables=variable_manager)

    conditional

# Generated at 2022-06-22 14:03:58.313058
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.template.vars import AnsibleHostVars
    from ansible.vars.manager import VariableManager

    p = Play().load({'name': 'test', 'hosts': 'all'}, loader=None, variable_manager=VariableManager())
    t = Templar(loader=None, variables=VariableManager())

    c = Conditional()
    c._ds = p
    c._loader = None

    hv = AnsibleHostVars(loader=None, variables=VariableManager())
    t.available_variables = hv

    #  When is a string
    c.when = u'{{ 1 == 0 }}'
    assert not c.evaluate_conditional(t, hv)

# Generated at 2022-06-22 14:04:07.276704
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import sys
    import jinja2

    from ansible.template import Templar

    def fake_ds(s):
        return s

    # We want to display warnings, so let's hack this
    old_show = display.show
    old_verbosity = display.verbosity
    display.verbosity = 4
    display.show = lambda *args, **kwargs: True

    loader = jinja2.DictLoader({})
    templar = Templar(loader=loader)
    templar.environment.filters.update(C.DEFAULT_JINJA2_FILTERS)

    # Test strings with the right trailing spaces
    test1 = "{{ 'yes' if True  else 'no' }}"
    test2 = "{% if True %}yes{% else %}no{% endif %}"

# Generated at 2022-06-22 14:04:16.515309
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Test that the method extract_defined_undefined can extract defined/undefined checks
    # and the associated variables from a given conditional

    # Test a conditional with a single defined/undefined check
    conditional = 'hostvars["foo"] is defined'
    def_undef = Conditional().extract_defined_undefined(conditional)
    assert def_undef == [('hostvars["foo"]', 'is', 'defined')]

    # Test a conditional with multiple defined/undefined checks
    conditional = 'inventory_hostname is defined and hostvars["foo"] is not defined'
    def_undef = Conditional().extract_defined_undefined(conditional)
    assert def_undef == [('inventory_hostname', 'is', 'defined'), ('hostvars["foo"]', 'is not', 'defined')]

    #

# Generated at 2022-06-22 14:04:24.852787
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = "{{ user_var is defined or user_var2 is not defined or some_var3 is defined }} and stuff"
    fc = Conditional()
    an_answer = fc.extract_defined_undefined(cond)
    assert an_answer == [('user_var', 'is', 'defined'), ('user_var2', 'is not', 'defined'), ('some_var3', 'is', 'defined')], \
        "test_Conditional_extract_defined_undefined(): incorrect result: %s" % str(an_answer)
    assert 0

# Generated at 2022-06-22 14:04:27.603881
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    cond = Conditional()
    # FIXME
    # this unit test was added in theory, but it is not actually functional
    return False



# Generated at 2022-06-22 14:04:39.799527
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    f = Conditional()
    # Normal usage
    r = f.extract_defined_undefined("foo is defined")
    assert r == [("foo", "is", "defined")]
    r = f.extract_defined_undefined("hostvars['foo'] is not defined")
    assert r == [("hostvars['foo']", "is not", "defined")]
    r = f.extract_defined_undefined("foo is defined or bar is undefined")
    assert r == [("foo", "is", "defined"), ("bar", "is", "undefined")]
    # Normal usage with more chars between words
    r = f.extract_defined_undefined("foo\tis defined")
    assert r == [("foo", "is", "defined")]

# Generated at 2022-06-22 14:04:52.217897
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Create a dummy class and give it a loader
    class MyClass(object):
        _loader = 'fake_loader'
    # Add the Conditional mixin to our dummy class
    MyClass = type('MyClass', (Conditional,), {})
    # Create an instance of our dummy class
    test_obj = MyClass()
    # Set the when attribute to be a list of conditionals that are all True
    test_obj.when = [True, 'True', 'true', 1, '1']
    # Check that evaluate_conditional() returns True
    assert test_obj.evaluate_conditional('templar', 'all_vars') is True
    # Set the when attribute to be a list of conditionals with one False

# Generated at 2022-06-22 14:05:15.715959
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test all possible cases in the switch statement "conditional_type"
    # of method _check_conditional()
    class Obj:
        pass
    obj = Obj()
    obj.when = "{{ foo }}"
    obj._ds = "test_Conditional_evaluate_conditional"
    obj._loader = None
    obj._check_conditional(obj.when, obj, {"foo": True})
    obj._check_conditional(obj.when, obj, {"foo": False})
    obj.when = "{{ foo | bool }}"
    obj._check_conditional(obj.when, obj, {"foo": True})
    obj._check_conditional(obj.when, obj, {"foo": False})
    obj.when = "not foo"
    obj._check_conditional(obj.when, obj, {"foo": True})

# Generated at 2022-06-22 14:05:26.201180
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    templar = Templar(loader=loader)
    conditional = Conditional(loader=loader)
    display.verbosity = 4
    display.debugvvvv = None
    display.debugvvv = None
    display.debugv = None
    display.debug = None

    #Test when always evaluates to True
    conditional._when = [True]
    assert(conditional.evaluate_conditional(templar) == True)
    conditional._when = [1]
    assert(conditional.evaluate_conditional(templar) == True)
    conditional._when = ["ok"]
    assert(conditional.evaluate_conditional(templar) == True)

    #Test when always evaluates to

# Generated at 2022-06-22 14:05:28.069505
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional, "Conditional not instantiated"

# Generated at 2022-06-22 14:05:39.654196
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    display.verbosity = 4
    display.color = False

    loader = DictDataLoader({})
    templar = Templar(loader=loader, variables={})
    cond_obj = Conditional()

    cond_obj.when = [ 'localhost' ]
    assert cond_obj.evaluate_conditional(templar, dict(inventory_hostname='localhost')) is True
    assert cond_obj.evaluate_conditional(templar, dict(inventory_hostname='127.0.0.1')) is False

    cond_obj.when = [ "inventory_hostname == 'localhost'" ]
    assert cond_obj.evaluate_conditional(templar, dict(inventory_hostname='localhost')) is True

# Generated at 2022-06-22 14:05:47.085056
# Unit test for constructor of class Conditional
def test_Conditional():
    display = Display()
    loader = DictDataLoader({
        "vars": {
            'a': 123,
            'b': 456,
            'c': 'value',
        },
    })
    templar = Templar(loader=loader, variables={})
    all_vars = dict(hostvars=dict())
    res = Conditional(loader=loader).evaluate_conditional(templar, all_vars)
    print(res)
    display.display("SUCCESS")


# Generated at 2022-06-22 14:05:58.986752
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def verify(cstr, tuples):
        assert Conditional().extract_defined_undefined(cstr) == tuples

    verify("a is defined and b is not defined", [('a', 'is', 'defined'), ('b', 'is not', 'defined')])
    verify("(a is defined) and (b is not defined)", [('a', 'is', 'defined'), ('b', 'is not', 'defined')])
    verify("(a is  defined) and (b is not  defined)", [('a', 'is', 'defined'), ('b', 'is not', 'defined')])
    verify("(a is defined) and ((b is not  defined) and c is defined)", [('a', 'is', 'defined'), ('b', 'is not', 'defined'), ('c', 'is', 'defined')])

# Generated at 2022-06-22 14:06:05.321862
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert Conditional().extract_defined_undefined("undefined_var is undefined") == [("undefined_var", "is", "undefined")]
    assert Conditional().extract_defined_undefined("defined_var is defined") == [("defined_var", "is", "defined")]
    assert Conditional().extract_defined_undefined("not_var is not defined") == [("not_var", "is not", "defined")]
    assert Conditional().extract_defined_undefined("defined_var is defined and not not_var is not undefined") == [("defined_var", "is", "defined"), ("not_var", "is not", "undefined")]

# Generated at 2022-06-22 14:06:14.077125
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    from ansible.playbook.task import Task

    t = Task()

    tests = (
        ('', []),
        ('foo', []),
        ('foo is defined', [('foo', 'is', 'defined')]),
        ('foo is not defined', [('foo', 'is not', 'defined')]),
        ('foo is not defined and bar is defined', [('foo', 'is not', 'defined'), ('bar', 'is', 'defined')]),
        ('foo is undefined and bar is defined', [('foo', 'is', 'undefined'), ('bar', 'is', 'defined')]),
        ('foo is not defined or bar is undefined', [('foo', 'is not', 'defined'), ('bar', 'is', 'undefined')]),
    )

    for (cond, expected) in tests:
        result = t.extract_defined_undefined

# Generated at 2022-06-22 14:06:23.914432
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # set up a simple test instance
    conditional = Conditional()

    # this test should return an array with one tuple
    conditional_string = "hostvars['foo'] is defined"
    assert conditional.extract_defined_undefined(conditional_string) == \
        [('hostvars[\'foo\']', 'is', 'defined')]

    # this test should return an array with two tuples
    conditional_string = "hostvars['foo'] is defined and hostvars['bar'] is undefined"
    assert conditional.extract_defined_undefined(conditional_string) == \
        [('hostvars[\'foo\']', 'is', 'defined'), ('hostvars[\'bar\']', 'is', 'undefined')]

    # this test should return an array with no tuples

# Generated at 2022-06-22 14:06:34.401684
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def test_case(case):
        conditional = Conditional()
        result = conditional.extract_defined_undefined(case["input"])
        assert result == case["expected"]


# Generated at 2022-06-22 14:07:11.757790
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    try:
        import jinja2
        from ansible.template import Templar
        from ansible.inventory.host import Host
    except ImportError:
        print("SKIPPING TESTS FOR Conditional evaluate_conditional as jinja2 or ansible.template are missing...")
        return True

    # test simple conditional
    data = dict(
        when=dict(
            expression=dict(
                name="foo",
                test="is defined"
            )
        ),
        vars=dict(
            foo=True
        )
    )
    th = Conditional()
    th._loader = DataLoader()
    th._variable_manager = VariableManager()
    th._host = Host(name="127.0.0.1")

# Generated at 2022-06-22 14:07:19.939302
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Create a simple object that uses the Conditional mix-in class
    class MyObj:
        def __init__(self):
            self.when = None
            self._ds = 'for unit tests'
        def set_loader(self, loader):
            self._loader = loader

    # For the "when" conditional we need the loader to inject other things
    # into the templating engine, so we use a very simple one.  Could use
    # a MockObject instead.
    loader = DictDataLoader({'vars': {'foo': 'bar'}})

    # This is the meat of the test, a conditional expression that will evaluate
    # to True when the foo variable is bar.  Also includes check of "is defined"
    # in the conditional, which was the cause of an earlier bug.

# Generated at 2022-06-22 14:07:32.662745
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # prepare AnsibleUndefinedVariable error as an exception
    exception = AnsibleUndefinedVariable('err')
    # prepare MockLoader as a loader and MockTemplar as a templar
    loader = MockLoader()
    templar = MockTemplar(loader)
    # prepare vars (as if we run with action plugin)
    vars = {'ansible_check_mode': False, 'ansible_debug': False}
    # prepare instance of class Conditional with MockLoader as a loader
    cnd = Conditional(loader)
    # conditionals used in the tests
    conditional = False
    conditional2 = True
    conditional3 = 'not_defined'
    conditional4 = '{{ansible_debug}}'
    conditional5 = 'not defined'
    conditional6 = 'defined'

# Generated at 2022-06-22 14:07:41.982617
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Test for boolean conditions
    #
    # Test for single boolean condition
    # Test for multiple boolean conditions

    # Test for string conditions
    #
    # Test for single string condition
    # Test for multiple string conditions

    # Test for dict conditions
    #
    # Test for single dict condition
    # Test for multiple dict conditions

    # Test for list conditions
    #
    # Test for single list condition
    # Test for multiple list conditions

    # Test for empty conditions
    #
    # Test for single empty condition
    # Test for multiple empty conditions

    # Test for no condition

    # Test for invalid conditions

    pass


# Generated at 2022-06-22 14:07:51.609058
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from units.mock.loader import DictDataLoader
    loader = DictDataLoader({})
    variable_manager = VariableManager()

# Generated at 2022-06-22 14:08:04.110110
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    class MyConditional(Conditional):
        pass
    def _assert(conditional, all_vars, result):
        c = MyConditional()
        c.when = [conditional]
        play_context = PlayContext()
        templar = Templar(loader=None, variables=all_vars, shared_loader_obj=None, play_context=play_context)
        res = c.evaluate_conditional(templar, all_vars)

# Generated at 2022-06-22 14:08:16.759692
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    conditional = ("(ansible_ssh_host is defined) or ((ansible_ssh_port is defined) and (ansible_ssh_host not in groups['local_only'])) or (ansible_ssh_host == inventory_hostname)")
    res1 = c.extract_defined_undefined(conditional)
    res2 = [('ansible_ssh_host', 'is', 'defined'), ('ansible_ssh_port', 'is', 'defined'), ('ansible_ssh_host', 'not', 'in'), ('ansible_ssh_host', '==', 'defined')]
    assert res1 == res2, 'extract_defined_undefined(%s) returned %s but expected %s' % (conditional, res1, res2)


# Generated at 2022-06-22 14:08:21.184415
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    cond = "[foo is defined] and [bar is not defined]"
    results = c.extract_defined_undefined(cond)
    assert results == [('foo', 'is', 'defined'), ('bar', 'is not', 'defined')], results



# Generated at 2022-06-22 14:08:34.699100
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class C(Conditional):
        def __init__(self):
            class D():
                def __init__(self):
                    self.data = {
                        'foo': 'bar'
                    }
            self._ds = D()
    c = C()
    c._when = ['foo == "bar"', None, True, 'false']
    res = c.evaluate_conditional(None, None)
    assert not res

    c._when = ['bar == "bar"']
    res = c.evaluate_conditional(None, None)
    assert res

    c._when = ['bar == "bar" or 1 == 2 or 3 == 4 or 5 == 6 or 7 == 8 or 9 == 10 or 11 == 12']
    res = c.evaluate_conditional(None, None)
    assert res


# Generated at 2022-06-22 14:08:46.754493
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # imports

    # Constants
    mock_self = 'foo'
    mock_all_vars = {'ansible_distribution': 'Ubuntu'}
    mock_ds = 'bar'
    mock_templar = type('templar', (object,), dict(template=lambda s, *_, **__: s))

    # Helpers

    # Mocks

    # Tests

    # Mock object creation
    setattr(mock_self, '_loader', None)
    setattr(mock_self, '_ds', mock_ds)
    setattr(mock_self, 'when', ['ansible_distribution == "Ubuntu"', 'ansible_distribution != "Centos"'])

    # Mock objects creation
    conditional = Conditional()

    # Test
    result = conditional.evaluate_conditional

# Generated at 2022-06-22 14:09:40.254489
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Initialize the Conditional for testing
    c = Conditional()

    # Test the normal case
    all_vars = dict(
        foo=1,
    )
    c._when = [
        'foo',
        'not foo'
    ]
    assert c.evaluate_conditional(None, all_vars)

    # Test the dark case
    all_vars = dict(
        foo=1,
        bar='bar',
        baz='{{ bar }}',
        baz2='{{ baz }}',
    )

    c._when = [
        'foo',
        'not "bar" in baz',
        'baz2 is not defined',
    ]
    assert not c.evaluate_conditional(None, all_vars)



# Generated at 2022-06-22 14:09:49.907820
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    # Test with a valid conditional string return a list
    conditional_string = "hostvars['foo'] is not defined or hostvars['bar'] is defined"
    result = conditional.extract_defined_undefined(conditional_string)
    assert result == [('hostvars[\'foo\']', 'is not', 'defined'), ('hostvars[\'bar\']', 'is', 'defined')], \
        "extract_defined_undefined returned unexpected value"

    # Test with an empty string return an empty list
    conditional_string = ""
    result = conditional.extract_defined_undefined(conditional_string)
    assert result == [], "extract_defined_undefined returned unexpected value"

    # Test with an invalid conditional string return an empty list

# Generated at 2022-06-22 14:09:59.850527
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    my_conditional = Conditional(object())

    # Tests with None
    result = my_conditional.extract_defined_undefined(None)
    assert result == []

    # Tests with empty string
    result = my_conditional.extract_defined_undefined('')
    assert result == []

    # Tests with True and False
    result = my_conditional.extract_defined_undefined('True and False')
    assert result == []

    # Tests with a conditional
    result = my_conditional.extract_defined_undefined('foo is defined or some_variable is not defined')
    assert result == [('foo', 'is', 'defined'), ('some_variable', 'is not', 'defined')]

    # Tests with a conditional with space at the end
    result = my_conditional.extract_defined_und

# Generated at 2022-06-22 14:10:10.740640
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-22 14:10:23.145168
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:10:35.559145
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    Ensure extract_defined_undefined method of class Conditional
    accurately extracts defined/undefined tests from a conditional
    '''
    
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence

    # Test 1: Test that method extracts a single defined test, when given
    # only a single defined test, and no other tests
    c = Conditional()
    cond = "def_var is defined"
    result = c.extract_defined_undefined(cond)
    expected_result = [('def_var', 'is', 'defined')]
    assert result == expected_result, \
        "Unexpected result: %s vs expected %s" % (result, expected_result)

    # Test 2: Test that method extracts a single undefined test, when given
    # only a single undefined

# Generated at 2022-06-22 14:10:48.813792
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    test = conditional.extract_defined_undefined('foo is defined')
    assert test == [['foo', 'is', 'defined']]

    test = conditional.extract_defined_undefined('foo is not defined')
    assert test == [['foo', 'is not', 'defined']]

    test = conditional.extract_defined_undefined('foo is undefined')
    assert test == [['foo', 'is', 'undefined']]

    test = conditional.extract_defined_undefined('foo is not undefined')
    assert test == [['foo', 'is not', 'undefined']]

    test = conditional.extract_defined_undefined('foo is defined or bar is not undefined')
    assert test == [['foo', 'is', 'defined'], ['bar', 'is not', 'undefined']]

# Generated at 2022-06-22 14:11:02.789446
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    display.verbosity = 4
    failed = False
    print("\n\nUNIT TESTS FOR Conditional CLASS METHOD: evaluate_conditional\n")
    # create a new Conditional object
    conditional_object = Conditional()
    # set initialized data sample
    conditional_object._loader = {'_basedir': 'my_base_dir', '_vault_password': 'my_vault_password'}
    conditional_object.when = 'my_condition'
    conditional_object._ds = {'path': 'my_path'}
    # initialize templar and all_vars
    all_vars = {'my_var': 'my_val'}
    templar = Templar(loader=conditional_object._loader, variables=all_vars)

# Generated at 2022-06-22 14:11:16.441942
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert [] == Conditional().extract_defined_undefined('defined')
    assert [('foo', 'not', 'defined')] == Conditional().extract_defined_undefined('foo is not defined')
    assert [('x', 'is', 'undefined'), ('y', 'is not', 'defined'), ('z', 'not', 'defined')] == \
        Conditional().extract_defined_undefined('x is undefined and y is not defined and z not defined')
    assert [('x', 'is', 'undefined')] == Conditional().extract_defined_undefined('x is undefined')
    assert [('x', 'is not', 'defined')] == Conditional().extract_defined_undefined('x is not defined')
    assert [('x', 'is', 'undefined')] == Conditional().extract_defined_undefined

# Generated at 2022-06-22 14:11:27.679832
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def test_Conditional(conditional, expected):
        c = Conditional()
        result = c.extract_defined_undefined(conditional)
        assert(result == expected)

    tests = dict(
        simple="hostvars['foo'] is undefined",
        one_not="hostvars['foo'] not is undefined",
        two_not="hostvars['foo'] is not defined",
        mix="hostvars['foo'] not is defined and hostvars['bar'] is not undefined"
    )