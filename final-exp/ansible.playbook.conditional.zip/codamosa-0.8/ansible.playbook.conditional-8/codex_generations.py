

# Generated at 2022-06-22 14:01:33.772024
# Unit test for constructor of class Conditional
def test_Conditional():
    '''
    constructor test of Conditional class
    '''

    def test_Conditional_init(self):
        assert self._loader is not None
        assert self._when == list


# Generated at 2022-06-22 14:01:41.982280
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    results_is_true = [
        "true is true",
        "1 is 1",
        "1 == 1",
    ]
    results_is_false = [
        "true is false",
        "1 is 2",
        "1 == 2",
        "true | bool is false",
        "1 > 2",
        "not(true)",
        "false & true",
        "true | false",
    ]

    # mock a dict of variables (all_vars)

# Generated at 2022-06-22 14:01:52.727170
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    if not C.DEVELOPMENT:
        pytest.skip("This test is only valid on development systems.")

    # Test Definition Variables
    my_vars = dict(
        hostvars = dict(
            host1 = dict(
                foo = dict(
                    bar = dict(
                        answer = 42,
                    ),
                ),
            ),
        ),
        my_var = 'a',
        group_names = ['group1', 'group2'],
        group_names_set = frozenset(['group1', 'group2']),
    )
    my_host = dict(name = 'host1')

# Generated at 2022-06-22 14:02:03.809087
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from collections import namedtuple
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import wrap_var

    TestCase = namedtuple('TestCase', ['conditional', 'expect', 'variables'])


# Generated at 2022-06-22 14:02:06.663239
# Unit test for constructor of class Conditional
def test_Conditional():
    my_conditional = Conditional()
    assert my_conditional

# Generated at 2022-06-22 14:02:16.928480
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    def _loader():
        return DataLoader()

    def _variable_manager(loader):
        return VariableManager(loader=loader)

    def _inventory(loader):
        return InventoryManager(loader=loader)

    loader = _loader()
    variable_manager = _variable_manager(loader)
    inventory = _inventory(loader)

    all_vars = dict()
    hostvars = dict()
    all_vars['hostvars'] = hostvars

    c = Conditional()
    c._loader = loader
    c._variable_manager = variable_manager
    c._inventory = inventory
    c._ds = dict()

    # Test succeed on all is not

# Generated at 2022-06-22 14:02:30.329623
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class UUT(object):
        def __init__(self):
            self.__class__ = type(
                'UUIClass',
                (Conditional, self.__class__),
                {}
            )

    uut = UUT()

    def check(input, expected):
        result = uut.extract_defined_undefined(input)
        assert result == expected, "Failed to extract defined/undefined of '%s' (expected %s, got %s)" \
                                   % (input, expected, result)

    # Basic cases
    check('', [])
    check('foo', [])
    check('foo is defined', [('foo', 'is', 'defined')])
    check('foo is not defined', [('foo', 'is', 'not defined')])

# Generated at 2022-06-22 14:02:42.745622
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Sample test data
    conditional_test_data = ['foo is defined',
                             'foo or bar is defined',
                             'foo and bar is defined',
                             'foo in bar is defined',
                             'foo not in bar is defined',
                             'foo is undefined',
                             'foo is not undefined',
                             'foo is not defined',
                             'foo is not defined or baz is defined',
                             'foo is not bar is not undefined']

    # Expected result

# Generated at 2022-06-22 14:02:55.261027
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list=["localhost"])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-22 14:03:06.784935
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    # if the conditional is "unsafe", disable lookups

# Generated at 2022-06-22 14:03:24.267298
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.errors import AnsibleError
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    from ansible.module_utils._text import to_bytes
    from units.mock.loader import DictDataLoader

    from units.compat.mock import Mock, patch


# Generated at 2022-06-22 14:03:36.741264
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    actual = c.extract_defined_undefined('')
    assert actual == [], actual

    actual = c.extract_defined_undefined('foo')
    assert actual == [], actual

    actual = c.extract_defined_undefined('"foo"')
    assert actual == [], actual

    actual = c.extract_defined_undefined('foo is defined')
    assert actual == [('foo', 'is', 'defined')], actual

    actual = c.extract_defined_undefined('foo is not defined')
    assert actual == [('foo', 'is not', 'defined')], actual

    actual = c.extract_defined_undefined('foo is undefined')
    assert actual == [('foo', 'is', 'undefined')], actual

    actual = c.extract_defined_

# Generated at 2022-06-22 14:03:48.496083
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("") == []
    assert c.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert c.extract_defined_undefined("  a   is defined") == [("a", "is", "defined")]
    assert c.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]
    assert c.extract_defined_undefined("b is c and d is defined") == [("d", "is", "defined")]
    assert c.extract_defined_undefined("b is c and d is defined and e is not undefined") == [("d", "is", "defined"), ("e", "is not", "undefined")]

# Generated at 2022-06-22 14:03:57.936540
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    result = Conditional().extract_defined_undefined("a is defined and b is defined")
    assert result == [('a', 'is', 'defined'), ('b', 'is', 'defined')]
    result = Conditional().extract_defined_undefined("a is defined and (b is defined or c is defined)")
    assert result == [('a', 'is', 'defined'), ('b', 'is', 'defined'), ('c', 'is', 'defined')]
    result = Conditional().extract_defined_undefined("not a is defined and not b is defined")
    assert result == [('a', 'is', 'defined'), ('b', 'is', 'defined')]
    result = Conditional().extract_defined_undefined("a is not defined and b is not defined")

# Generated at 2022-06-22 14:04:05.689116
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext

    conditional = Conditional()
    conditional.when = ["False", "{{ y }}", "{{ true_var }}"]

    templar = DummyTemplar()
    templar.environment = DummyEnvironment()
    templar.available_variables = { "false_var": False, "true_var": True, "y": "{{ false_var }}" }
    pc = PlayContext()
    templar.set_play_context(pc)

    result = conditional.evaluate_conditional(templar, templar.available_variables)
    assert result == False


# Generated at 2022-06-22 14:04:17.755706
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.utils.unsafe_proxy import wrap_var

    # teststrings
    when_true = 'foo is defined'
    when_true_alt = 'bar is defined'
    when_false = 'baz is defined'
    when_false_alt = 'vaz is defined'
    when_unsafe = wrap_var('stack is defined')
    when_unsafe_alt = wrap_var('food is defined')
    hostvars_string_true = 'hostvars["foo"] is defined'
    hostvars_string_false = 'hostvars["bar"] is defined'
    task_true_string = 'myhost is defined'
    ansible_

# Generated at 2022-06-22 14:04:26.064721
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # check that a simple conditional is correctly evaluated
    assert Conditional(None).evaluate_conditional(Templar(None), dict()) is True
    assert Conditional(None).evaluate_conditional(Templar(None), dict(foo=True)) is True
    assert Conditional(None).evaluate_conditional(Templar(None), dict(foo=True, bar=True)) is True
    assert Conditional(None).evaluate_conditional(Templar(None), dict(foo=False, bar=True)) is False
    assert Conditional(None).evaluate_conditional(Templar(None), dict(foo=True, bar=False)) is False

# Generated at 2022-06-22 14:04:31.873674
# Unit test for constructor of class Conditional
def test_Conditional():
    class Test():
        '''
        This is a test class
        '''
        _when = FieldAttribute(isa='list', default=list, extend=True, prepend=True)
        def __init__(self):
            self.when = ['a']
    a = Test()
    b = Conditional()
    b.__init__(a, loader=None)

# Generated at 2022-06-22 14:04:43.241384
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    display.verbosity = 4
    display.color = False
    # import the class for testing
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    # initialize needed objects
    ti = TaskInclude('include_role', dict(name='some_role'), dict(role_paths=['../../']))
    v = VariableManager()
    i = Inventory(loader=DataLoader())
    v.set_inventory(i)

    # set various value to be tested as variables

# Generated at 2022-06-22 14:04:54.097560
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class TestClass(Conditional):
        def __init__(self, loader=None):
            super(TestClass, self).__init__(loader=loader)
            self.when = list()

    test_obj = TestClass()


# Generated at 2022-06-22 14:05:16.870311
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import sys
    sys.stderr = None
    res = {}

# Generated at 2022-06-22 14:05:26.556386
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    class TestConditional(Conditional):
        
        when = FieldAttribute(isa='list', default=list)

        def __init__(self,loader=None):
            if loader is None:
                raise AnsibleError("a loader must be specified when using Conditional() directly")
            else:
                self._loader = loader
            self.when = None

    from ansible.template import Templar

    loader = None
    templar = Templar(loader=loader, shared_loader_obj=None)

    # simple string
    condition = TestConditional(loader=loader)
    condition.when = "fact.name == 'Windows'"
    all_vars = dict(fact=dict(name="Windows"))
    assert condition.evaluate_conditional(templar, all_vars)

    condition.when = "fact.name == 'linux'"


# Generated at 2022-06-22 14:05:35.226096
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # setup mocks for templar
    mock_loader = Mock()
    mock_inventory = Mock()
    mock_variable_manager = VariableManager(loader=mock_loader, inventory=mock_inventory)
    templar = Templar(loader=mock_loader, variables=mock_variable_manager)

    # setup mocks for Conditional
    mock_ds = Mock()
    mock_ds._ds = 'mock_ds'
    mock_ds._play = Mock()
    mock_ds._play.debug = ('vars', 'vvv', 'vvvv')

    # test data

# Generated at 2022-06-22 14:05:42.933002
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Compose the input string to method extract_defined_undefined
    def_undef = "not (variable_1 is undefined or variable_2 is undefined and variable_3 is undefined)"
    # Call method extract_defined_undefined
    result = Conditional().extract_defined_undefined(def_undef)
    # This test will always be True, unless the above method fails
    assert result is not None

# Generated at 2022-06-22 14:05:54.981320
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()


# Generated at 2022-06-22 14:05:56.321080
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    assert True


# Generated at 2022-06-22 14:06:08.083631
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from collections import namedtuple
    import pytest
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    class Test(AnsibleBaseYAMLObject):
        def __init__(self, data=None):
            super(Test, self).__init__(self)
            self.data = data

    class DunderUndefined(object):
        def __contains__(self, key):
            return False

        def __getattr__(self, key):
            return None

        def __getitem__(self, key):
            return None

        def __bool__(self):
            return False

    test_data = namedtuple('test_data', ['conditional', 'all_vars', 'expected'])

# Generated at 2022-06-22 14:06:17.192235
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class ConditionalStub(Conditional):
        when = []

    all_vars = {'foo': 'bar'}
    templar_stub = TemplarStub()

    assert ConditionalStub.evaluate_conditional(ConditionalStub(), templar_stub, all_vars) == True

    ConditionalStub.when = [False]
    assert ConditionalStub.evaluate_conditional(ConditionalStub(), templar_stub, all_vars) == False



# Generated at 2022-06-22 14:06:22.414163
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:06:27.550769
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    result = Conditional().extract_defined_undefined("hostvars['foo'] is defined and hostvars['bar'] is not defined")
    assert result == [('hostvars[\'foo\']', 'is', 'defined'), ('hostvars[\'bar\']', 'is not', 'defined')]


# Generated at 2022-06-22 14:07:09.072173
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    from ansible.playbook import Task
    import os

    results = [ ('ansible_distribution_major_version', 'is', 'defined'), ('ansible_os_family', 'is', 'undefined')]
    env_file = os.path.join(os.path.dirname(__file__), "unittest_data", "env.yml")
    task = Task.load(dict(action="copy",
                          when="ansible_distribution_major_version is defined and ansible_os_family is undefined",
                          src="{{ test_data_dir }}/unit_tests/conditional_test.txt",
                          dest="/tmp/ansible_test_conditional_test.txt",
                          environment=env_file),
                     loader=None,
                     variable_manager=None)

# Generated at 2022-06-22 14:07:21.515235
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('bar is not bar') == []
    assert conditional.extract_defined_undefined('foo is not defined and bar not in baz') == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('bar not in baz and foo is not defined') == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('bar not in baz or foo is not defined') == [('bar', 'not in', 'baz'), ('foo', 'is not', 'defined')]

# Generated at 2022-06-22 14:07:33.678128
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # FIXME: Creating a fake 'loader' is bad and we know it.
    fake_loader = type('FakeLoader', (object,), {})()
    conditional = Conditional(loader=fake_loader)

    # Test empty list when
    fake_self = type('FakeSelf', (object,), {"_ds": "Test"})
    conditional._when = []
    assert conditional.evaluate_conditional(None, None) == True

    # Test a simple conditional
    conditional._when = ["1 == 1"]
    assert conditional.evaluate_conditional(None, None) == True

    # Test a simple conditional
    conditional._when = ["1 == 0"]
    assert conditional.evaluate_conditional(None, None) == False

    # Test a undefined variable
    conditional._when = ["{{ undefined }}"]

# Generated at 2022-06-22 14:07:35.624607
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()

    assert c._when == []


# Generated at 2022-06-22 14:07:45.307860
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # define the input variables to be used by the when statement
    all_vars = {
        "foo": "1",
        "bar": False,
        "baz": 'true'
    }

    # define the conditional to be evaluated
    # the value of this string is not relevant, only its content
    conditional = u'(foo == 1 and bar == False) or (foo == "1" and int(baz)==1) or (foo == "1" and baz == "true")'

    # create a mock class to be able to call the evaluate_conditional method
    from mock import Mock
    from ansible.template import Templar
    mock_templar = Mock(spec=Templar)

# Generated at 2022-06-22 14:07:53.965399
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-22 14:08:04.670878
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import sys
    import os
    #if not C.DEFAULT_MODULE_PATH.startswith("/usr/share/ansible/plugins/modules"):
    #    os.environ['ANSIBLE_MODULE_UTILS'] = C.DEFAULT_MODULE_PATH
    #sys.path.insert(0, C.DEFAULT_MODULE_PATH)

    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from units.mock.loader import DictDataLoader
    from units.mock.inventory import DictInventory

    #test setup:

# Generated at 2022-06-22 14:08:18.151775
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # tests performed with plain Conditional class to avoid class hierarchy
    # and subsequent unnecessary dependencies
    c = Conditional()

# Generated at 2022-06-22 14:08:26.873639
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:08:32.894769
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class TestConditional(Conditional):
        def __init__(self, loader=None):
            super(TestConditional, self).__init__(loader)
            self.when = [ 'false', 'false', 'true' ]

    # create the objects we need to test evaluate_conditional
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = variable_manager.get_inventory(loader)
    play_context = PlayContext()
    templar = Templar(loader=loader, variable_manager=variable_manager, play_context=play_context)
    all_vars = inventory.get_

# Generated at 2022-06-22 14:09:37.203042
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.play_context import PlayContext

    # Do a quick test to verify the class is not missing anything
    # It's not a full test coverage, just a smoke test

    # Setup minimal class with mock loader
    class FauxLoader:
        def get_basedir(self):
            return '/dev/null'
    loader = FauxLoader()

    class FauxConditional(Conditional):
        def __init__(self, loader=None):
            super(FauxConditional, self).__init__(loader=loader)

    test_task = FauxConditional(loader=loader)
    templar = loader.get_shared_jinja2_environment()

    # Test empty when
    assert (test_task.evaluate_conditional(templar, {}))

    # Test single conditional

# Generated at 2022-06-22 14:09:47.825362
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional1 = 'hostvars[inventory_hostname].get("a", 0) is defined and hostvars[inventory_hostname].get("a", 0) > 2'
    conditional2 = 'hostvars[inventory_hostname].get("a", 0) is not defined and hostvars[inventory_hostname].get("a", 0) > 2'
    conditional3 = 'hostvars[inventory_hostname] is defined and hostvars[inventory_hostname].get("a", 0) > 2'
    conditional4 = 'hostvars[inventory_hostname] is not defined and hostvars[inventory_hostname].get("a", 0) > 2'


# Generated at 2022-06-22 14:09:58.967893
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:10:10.299896
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import Variables
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    h = Host('testhost')
    g = Group('testgroup')
    h.groups = [g]
    g.hosts = [h]
    h.vars = Variables(loader=None, variables=dict(x=42, y=43, z=44))
    g.vars = Variables(loader=None, variables=dict(y=45))
    vars = Variables(loader=None, variables=dict(z=46))
    templar = Templar(loader=None, variables=vars)


# Generated at 2022-06-22 14:10:12.039496
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c.when == []



# Generated at 2022-06-22 14:10:24.193637
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Setup the tests, ansible.parsing.dataloader will be loaded
    # by the first init_runner()
    import ansible.playbook.play_context
    import ansible.parsing.mod_args
    import ansible.parsing.yaml.objects
    import ansible.template
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Init the class, loaders are only used to
    # initialize variable_manager
    class TestTask:
        _role = None
        name = None

    class TestPlaybook:
        def __init__(self, variable_manager):
            self.variable_manager = variable_manager


# Generated at 2022-06-22 14:10:36.073062
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    This method is only called if run as a unit test.  It tests the
    evaluate_conditional() method of the class Conditional.
    '''

    import unittest
    import sys
    # Need to access ansible.playbook.play_context.PlayContext
    sys.path.insert(0, "lib/ansible")
    from ansible.playbook import play_context

    class TestConditional(unittest.TestCase):

        def setUp(self):
            '''
            This method creates an object of the class Conditional, using the
            class VariableManager to initialize the templar attribute.
            '''

            class Dummy(object):

                '''
                A dummy class for a datastructure object.
                '''

                pass

            # Add _ds to the object for error reporting
            self

# Generated at 2022-06-22 14:10:48.974617
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    def create_task(name, when):
        task = type('task', (object,), {})()
        task.name = name
        task.when = when
        return task

    Conditional._check_conditional = Conditional.evaluate_conditional


# Generated at 2022-06-22 14:11:02.903284
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.base import Base
    mixin = Conditional()
    for c in ('a is defined',
              'a is not undefined',
              'a is defined and b is defined',
              'c is defined or a is not undefined',
              'a is defined or b is defined or c is defined or d is undefined',
              'hostvars["x"] is defined'):
        mixin.when = [c]
        assert mixin.evaluate_conditional(None, Base.load_extra_vars({})) is True
        assert set(mixin.extract_defined_undefined(c)) == set([('a', 'is', 'defined')])

# Generated at 2022-06-22 14:11:16.545968
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    def _test_condition(condition, expected_result):

        class MyClass(Conditional):
            def get_loader(self, engine):
                class FakeLoader:
                    def get_basedir(self, name):
                        return name

                return FakeLoader()

        obj = MyClass()
        obj.when = [condition]

        templar = MockTemplar(Callbacks(obj))
        obj.evaluate_conditional(templar, variables=dict(user_id=400, user_id_int=400, user_id_string='400'))

        assert expected_result == templar.result
