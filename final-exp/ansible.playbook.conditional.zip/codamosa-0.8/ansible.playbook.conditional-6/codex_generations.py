

# Generated at 2022-06-22 14:01:37.608206
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    try:
        conditional = '''(foo is defined) and (bar is not undefined) and (baz is not defined)'''
        assert(Conditional().extract_defined_undefined(conditional) == [('foo', 'is', 'defined'), ('bar', 'is not', 'undefined'), ('baz', 'is not', 'defined')])
    except Exception as e:
        print(e)
        print("Test for method extract_defined_undefined failed!")
        raise

# Generated at 2022-06-22 14:01:48.841134
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # all AttributeOverrides are removed, we need to create a new class here
    class TestConditional(Conditional):
         _name = FieldAttribute(isa='str')

    display = Display()
    display.verbosity = 2


# Generated at 2022-06-22 14:01:54.977500
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.splitter import parse_kv

    display.verbosity = 3
    display.verbose = lambda x: None

    class TestConditional():
        def __init__(self, cond_str, vars):
            self.when = cond_str
            self.vars = vars

        def evaluate_conditional(self, templar, all_vars):
            # since we are only testing the evaluation of conditionals, we
            # can't use the templar.template() method, so we just fake it here
            # by using parse_kv()
            return super(TestConditional, self).evaluate_conditional(parse_kv, all_vars)

    class TestConditionalWithVars(Conditional, TestConditional):
        pass

    # simple conditionals
    a = TestCond

# Generated at 2022-06-22 14:02:04.269059
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    class TestConditional(Conditional):
        pass

    class FakeTask(object):
        pass

    from ansible.template import Templar

    faketask = FakeTask()
    faketask._ds = dict(name='test_str')
    templar = Templar(faketask._ds)

    test_conditional = TestConditional(templar)

    # test when is None
    test_conditional.when = None
    assert test_conditional.evaluate_conditional(templar, dict())

    # test when is 'True'
    test_conditional.when = True
    assert test_conditional.evaluate_conditional(templar, dict())

    # test when is 'False'
    test_conditional.when = False

# Generated at 2022-06-22 14:02:16.183804
# Unit test for constructor of class Conditional
def test_Conditional():
    # validate that the class will be initialized without error
    b = Base()
    c = Conditional()

    # validate that the constructor fails with an error when no loader is passed in
    class NoLoader:
        pass

    try:
        cl = Conditional(loader=NoLoader())
    except AnsibleError:
        pass
    else:
        assert False, 'should make sure loader is passed in by constructor'

    # validate that the constructor works with a loader
    cl = Conditional(loader=NoLoader())

    # validate that the constructor works when a loader is passed in through the base class
    #
    # NOTE: The order here is critical, Conditional must come first or the _loader attribute
    #       on Base will take precedence and ConditionalLoader will never be initialized
    class ConditionalLoader(Conditional, Base):
        pass

    cl = Conditional

# Generated at 2022-06-22 14:02:29.647385
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    play_context = PlayContext()
    play_context._vars = {
        'var1': 'foo1',
        'var2': {
            'var2_key1': 'foo2',
            'var2_key2': 'foo3'
        },
        'var3': 'foo4',
        'var4': 'foo5',
        'var5': 'foo6',
    }
    templar = Templar(loader=None, variables=play_context.get_vars(), shared_loader_obj=None)

    conditional = Conditional(loader=None)

    assert conditional.evaluate_conditional(templar, play_context.get_vars())

    conditional = Conditional(loader=None)
    conditional.when = [False]

   

# Generated at 2022-06-22 14:02:34.625955
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("") == []
    assert conditional.extract_defined_undefined("1") == []
    assert conditional.extract_defined_undefined("a") == []
    assert conditional.extract_defined_undefined("a b") == []
    assert conditional.extract_defined_undefined("a is defined") == [('a', 'is', 'defined')]
    assert conditional.extract_defined_undefined("a is not defined") == [('a', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("a is b") == [('a', 'is', 'b')]

# Generated at 2022-06-22 14:02:42.503796
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    unit test for method evaluate_conditional of class Conditional
    '''

    # Test when conditional is False
    test_conditional = Conditional()
    all_vars = {'x':2, 'y':4}
    templar = Dictable()
    test_conditional.when = [False, False]
    result = test_conditional.evaluate_conditional(templar, all_vars)
    assert result is False

    # Test when first conditional is False and second is True
    test_conditional = Conditional()
    all_vars = {'x':2, 'y':4}
    templar = Dictable()
    test_conditional.when = [False, True]
    result = test_conditional.evaluate_conditional(templar, all_vars)


# Generated at 2022-06-22 14:02:55.031429
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    ''' Test that extract_defined_undefined method
    works properly for happy path
    '''

    conditional = "hostvars['foo1'] is defined and hostvars['foo2'] is undefined and hostvars['foo1'] is not defined"
    expected_matches = [("hostvars['foo1']", "is", "defined"), ("hostvars['foo2']", "is", "undefined"), ("hostvars['foo1']", "is not", "defined")]

    # Test happy path
    conditional_mock = Conditional()
    matches = conditional_mock.extract_defined_undefined(conditional)

    assert matches == expected_matches

    # Test edge case with no matches
    conditional = "foo1 is defined and foo2 is undefined and foo1 is not defined"
    expected_matches = []



# Generated at 2022-06-22 14:02:55.638106
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    assert True


# Generated at 2022-06-22 14:03:11.507213
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional(None)
    test = 'asd and (hostvars[inventory_hostname].ansible_hostname is not  defined or inventory_hostname == "localhost") and (hostvars[inventory_hostname].ansible_test is defined or inventory_hostname != "localhost")'
    r1 = ('hostvars[inventory_hostname].ansible_hostname', 'is not', 'defined')
    r2 = ('hostvars[inventory_hostname].ansible_test', 'is', 'defined')
    result = conditional.extract_defined_undefined(test)

    assert result[0] == r1, 'Conditional.extract_defined_undefined should return first match of test'
    assert result[1] == r2, 'Conditional.extract_defined_undefined should return second match of test'

# Generated at 2022-06-22 14:03:22.692780
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Test variable definition with double quotes
    if Conditional("").extract_defined_undefined("hostvars['hostname'] is defined") != [("hostvars['hostname']", 'is', 'defined')]:
        raise AssertionError("extract_defined_undefined(%s) should have been %s but was %s" % ("hostvars['hostname'] is defined",
            [("hostvars['hostname']", 'is', 'defined')],
            Conditional("").extract_defined_undefined("hostvars['hostname'] is defined")))
    # Test variable definition with single quotes
    if Conditional("").extract_defined_undefined("hostvars[\"hostname\"] is defined") != [("hostvars[\"hostname\"]", 'is', 'defined')]:
        raise AssertionError

# Generated at 2022-06-22 14:03:35.491046
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook import Play
    from ansible.template import Templar
    from ansible.vars import VariableManager

    class TestClass(Conditional):

        def __init__(self):
            super(TestClass, self).__init__()

    v = VariableManager()
    p = Play().load(dict(
        name="test",
        hosts='all',
        gather_facts='no',
    ), variable_manager=v, loader=None)

    t = Templar(loader=None, variables=v)

    c = TestClass()

    c.when = list(range(7))

# Generated at 2022-06-22 14:03:47.473059
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:03:51.756956
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # arrange
    conditional = Conditional()

    # act
    result = conditional.extract_defined_undefined('hostvars[inventory_hostname] is not defined')

    # assert
    assert '[(\'hostvars[inventory_hostname]\', \'is not\', \'defined\')]' == str(result)


# Generated at 2022-06-22 14:04:02.061544
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    class MockTemplar(object):
        def __init__(self, env):
            self.env = env

        def is_template(self, value):
            return self.env.is_template(value)

        def template(self, value, disable_lookups=False):
            return self.env.template(value, disable_lookups)

    def _check_conditional(self, conditional):
        templar = MockTemplar(self.env)
        return super(Conditional, self)._check_conditional(conditional, templar, dict(hostvars={}))

    class TestConditional(Conditional):
        def __init__(self, env):
            self.env = env

    c = TestConditional(env=jinja2.Environment())
    c._check_conditional = _check_cond

# Generated at 2022-06-22 14:04:09.549177
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create objects
    context = PlayContext()
    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)

# Generated at 2022-06-22 14:04:19.376000
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader)
    variable_manager.extra_vars = {'test': 'foo'}

    conditional = Conditional(loader=loader)
    assert conditional is not None

    conditional2 = Task()
    assert conditional2 is not None
    conditional2.when = [{'test': 'foo'}]

    conditional3 = Task()
    assert conditional3 is not None
    conditional3.when = [{'test': 'foo'}]

# Generated at 2022-06-22 14:04:27.117722
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def normalize_result(result):
        return list(map(lambda tuple: (tuple[0], tuple[1].strip(), tuple[2]), result))

    c = Conditional()
    assert c.extract_defined_undefined("defined") == []
    assert c.extract_defined_undefined("undefined") == []
    assert c.extract_defined_undefined("x is defined") == [("x", "is", "defined")]
    assert c.extract_defined_undefined("x not is defined") == [("x", "not is", "defined")]
    assert c.extract_defined_undefined("x is not defined") == [("x", "is not", "defined")]

# Generated at 2022-06-22 14:04:39.357212
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar

    class FakeTask(Conditional):
        pass

    task = FakeTask()

    # The attributes of the object play no role for this method
    setattr(task, '_ds', 'fake_ds')

    task._loader = FakeLoader()

    # It should return True if the conditional is None
    task.when = [None]
    assert task.evaluate_conditional(Templar(loader=task._loader, variables=dict()), dict())

    # It should return True if the conditional is an empty string
    task.when = ['']
    assert task.evaluate_conditional(Templar(loader=task._loader, variables=dict()), dict())

    # It should return True if the conditional is True
    task.when = [True]

# Generated at 2022-06-22 14:04:55.825134
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    def check_conditional(conditional, all_vars, expected):
        result = True
        t = Templar(loader=None, variables=all_vars)
        p = Conditional()
        p.when = [conditional]
        try:
            res = p.evaluate_conditional(t, all_vars)
        except Exception as e:
            raise AnsibleError("Evaluating %s failed. The error was: %s" % (conditional, to_native(e)))

# Generated at 2022-06-22 14:05:07.681226
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Evaluate when conditional is 'None'
    res = Conditional().evaluate_conditional(None, None)
    assert res == True, "Unexpected result: %s" % res
    
    # Evaluate when conditional is 'False'
    res = Conditional().evaluate_conditional(None, None)
    assert res == True, "Unexpected result: %s" % res
    
    # Evaluate when conditional is 'True'
    res = Conditional().evaluate_conditional(None, None)
    assert res == True, "Unexpected result: %s" % res
    
    # Evaluate when conditional is 'not None'
    res = Conditional().evaluate_conditional(None, None)
    assert res == True, "Unexpected result: %s" % res
    
    # Evaluate when conditional is 'not False'
    res

# Generated at 2022-06-22 14:05:16.422839
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    display = Display()
    display.verbosity = 4
    conditional = Conditional()

    # 1. Test that defined variables are extracted
    conditional = """variables are not C.DEFAULT_KEEP_REMOTE_FILES and (
    hostvars['localhost']['ansible_architecture'] is defined or
    hostvars['localhost']['ansible_distribution'] is not undefined
)"""
    result = [('hostvars[\'localhost\'][\'ansible_architecture\']', 'is', 'defined'), ('hostvars[\'localhost\'][\'ansible_distribution\']', 'is not', 'undefined')]
    assert(conditional.extract_defined_undefined(conditional) == result)

    # 2. Test that a variable with no spaces is extracted

# Generated at 2022-06-22 14:05:19.332102
# Unit test for constructor of class Conditional
def test_Conditional():
    cond = Conditional()
    assert hasattr(cond, 'when')
    assert cond.when == []

# Generated at 2022-06-22 14:05:28.506692
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    # when:
    conditional.when = ['1 == 1', '2 == 2']
    # all_vars:
    all_vars = dict(da1=1, da2=2)
    # should return True
    assert True == conditional.evaluate_conditional(templar=None, all_vars=all_vars)
    # when:
    conditional.when = ['1 == 2', '2 == 2']
    # should return True
    assert True == conditional.evaluate_conditional(templar=None, all_vars=all_vars)
    # when:
    conditional.when = ['1 == 2', '2 == 3']
    # should return False
    assert False == conditional.evaluate_conditional(templar=None, all_vars=all_vars)


# Generated at 2022-06-22 14:05:39.695051
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    test function for method evaluate_conditional of class Conditional

    :Case level: Unit test
    '''

    # create object test
    test = Conditional()

    # object test_ok
    test_ok = Conditional()
    test_ok._when = 'result_ok'
    test_ok._ds = 'object test_ok'
    test_ok.evaluate_conditional('result_ok', {'result_ok': 'result_ok'})

    # object test_error_01
    test_error_01 = Conditional()
    test_error_01._when = 'result_error_01'
    test_error_01._ds = 'object test_error_01'
    test_error_01.evaluate_conditional('result_error_01', dict())

    # object test_error_02
   

# Generated at 2022-06-22 14:05:50.692819
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=[])
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=play_context.vardir)

    task1 = Conditional()

    # no conditions defined
    assert task1.evaluate_conditional(templar, {})

    # when is a string
    task1.when = '1'
    assert task1.evaluate_conditional(templar, {})



# Generated at 2022-06-22 14:06:01.062095
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    all_vars = dict(var1=1, var2=[1,2,3], var3="ansible")
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.template import Templar
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(loader=loader), host_list=[])
    templar = Templar(loader=loader, variables=all_vars)
    my_class = type('MyClass', (Conditional,), {})
    my_obj = my_class()

    # Test when the conditional is empty
    assert my_obj.evaluate_conditional(templar, all_vars) is True

    # Test when the conditional is True or False
   

# Generated at 2022-06-22 14:06:11.387167
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:06:23.140582
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestClass(Conditional):
        pass

    test_class = TestClass()
    from jinja2 import Environment
    from ansible.vars import VariableManager
    from ansible.template import Templar

    variable_manager = VariableManager()
    loader = None
    templar = Templar(loader=loader, variables=variable_manager)
    variable_manager.set_available_variables(dict(a_true=True,
                                                  a_false=False,
                                                  a_variable=23,
                                                  a_string="A String"))

    assert test_class.evaluate_conditional(templar, variable_manager.get_vars(loader=loader, play=None, task=None))

    test_class.when = ["some_variable"]

# Generated at 2022-06-22 14:06:46.591149
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    test_data = [
        ('', []),
        ('not foo', []),
        ('foo is undefined', [('foo', 'is', 'undefined')]),
        ('foo is not defined', [('foo', 'is not', 'defined')]),
        ('foo is not defined and bar is not undefined and baz is defined',
         [('foo', 'is not', 'defined'), ('bar', 'is not', 'undefined'), ('baz', 'is', 'defined')]),
    ]
    for (conditional, expected) in test_data:
        result = c.extract_defined_undefined(conditional)
        assert result == expected, "Actual: %s" % result


# Generated at 2022-06-22 14:06:57.932675
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    import pytest

    class MyClass(Conditional):
        def __init__(self, ds, context):
            self._ds = ds
            self.when = ['True']
            self.NAME = 'test'
            self.vars = dict(
                hostvar="hostvar",
                hostvars=dict(
                    hostvar="hostvar"),
                ansible_hostvars=dict(
                    hostvar="hostvar"),
                var="var",
                undefined=None,
            )
            self._templar = Templar(loader=None, variables=self.vars)
            self._templar.set_available_variables(self.vars)


# Generated at 2022-06-22 14:07:10.521484
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list='localhost')
    variable_manager = inventory.get_variable_manager()
    templar = Templar(loader=loader, variables=variable_manager.get_vars(loader=loader, play=None))

    conditional = Conditional(loader=loader)

    assert conditional.evaluate_conditional(templar, {})
    assert conditional.evaluate_conditional(templar, dict(a=1))

    conditional = Conditional(loader=loader)

# Generated at 2022-06-22 14:07:19.331991
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Unit test for method evaluate_conditional of class Conditional
    '''

    from ansible.vars.manager import VariableManager

    conditional = Conditional()

    # test with defined variable
    assert conditional.evaluate_conditional("{{ var is defined }}", "var")

    # test with undefined variable
    assert not conditional.evaluate_conditional("{{ var is defined }}", "")

    # test with defined variable and negative evaluation
    assert not conditional.evaluate_conditional("{{ var is not defined }}", "var")

    # test with undefined variable and negative evaluation
    assert conditional.evaluate_conditional("{{ var is not defined }}", "")

    # test with extra spaces
    assert conditional.evaluate_conditional(" {{ var  is   defined }} ", "var")

    # test with multiple defined variables

# Generated at 2022-06-22 14:07:24.984827
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    class TestClass(Conditional):
        def __init__(self):
            self._loader = None
            self._ds = None
            self._templar = None
            self._extras = None
            super(TestClass, self).__init__()

    # Change some default constants to avoid user config and other side effects
    saved_constants = (
        C.DEFAULT_HASH_BEHAVIOUR,
        C.HOST_VAR_NAME,
    )

# Generated at 2022-06-22 14:07:36.020220
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    t = Conditional()

    assert t.extract_defined_undefined('') == []
    # Some positive tests
    assert t.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert t.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert t.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert t.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert t.extract_defined_undefined('foo is defined or bar is not defined') == \
            [('foo', 'is', 'defined'), ('bar', 'is not', 'defined')]


# Generated at 2022-06-22 14:07:45.452294
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible import errors

    module_name = 'test_Conditional_evaluate_conditional'
    class TestConditional(Conditional):
        def __init__(self, loader=None):
            super(TestConditional, self).__init__(loader)

    # Create a TestConditional object and set a list of conditions
    test_conditional = TestConditional(None)
    test_conditional._ds = 'test_conditional_ds'
    test_conditional.when = [
        'good_cond1',
        'bad_cond1',
        'good_cond11',
    ]

    # Create a Templer object to test with
    from ansible.templating import Templa
    templar = Templa(loader=None)

# Generated at 2022-06-22 14:07:54.057335
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """
    This method to test the evaluate_conditional method of class Conditional.
    It uses the 'when' xmltodict.
    """
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.plugins import module_loader

    # Create a play object
    class Play:
        pass
    play = Play()

    # Create a task object
    class Task:
        pass
    task = Task()

    # Create a play_context object
    play_context = PlayContext()

    # Create a variable_manager object
    variable_manager = VariableManager()

    # Parse the host file
    host_file = C.DEFAULT_HOST_LIST

# Generated at 2022-06-22 14:08:02.050153
# Unit test for constructor of class Conditional
def test_Conditional():
 if False:
   hostvars = dict(
       oo_ip="192.168.1.1",
       oo_hostname="foo.example.com"
   )
   all_vars = dict(
       inventory_hostname="foo.example.com",
       group_names=['oo'],
       groups=dict(oo=['foo.example.com', 'bar.example.com'])
   )

   obj = Conditional()
   print(obj.evaluate_conditional(templar, all_vars))

# Generated at 2022-06-22 14:08:14.424643
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

    def_undef = cond.extract_defined_undefined('foo is defined')
    assert len(def_undef) == 1
    assert def_undef[0][0] == 'foo' and def_undef[0][1] == 'is' and def_undef[0][2] == 'defined'

    def_undef = cond.extract_defined_undefined('foo is undefined')
    assert len(def_undef) == 1
    assert def_undef[0][0] == 'foo' and def_undef[0][1] == 'is' and def_undef[0][2] == 'undefined'

    def_undef = cond.extract_defined_undefined('foo not is defined')
    assert len(def_undef) == 1

# Generated at 2022-06-22 14:08:55.180654
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    test_cases = {}
    test_cases['cond1'] = []
    test_cases['cond2'] = []
    test_cases['cond3'] = []
    test_cases['cond4'] = [('a', 'not is', 'undefined')]
    test_cases['cond5'] = [('a', 'is', 'undefined')]
    test_cases['cond6'] = [('hostvars["foo"]', 'is', 'defined')]
    test_cases['cond7'] = [('hostvars["foo"]', 'not is', 'defined')]
    test_cases['cond8'] = [('a', 'is', 'undefined')]
    test_cases['cond9'] = [('b', 'not is', 'undefined')]

# Generated at 2022-06-22 14:09:07.103667
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class MyLoader3:
        def __init__(self):
            self.path = list()
    class MyConditional(Conditional):
        pass
    class Options:
        verbosity = 0
        force_handlers = False

    myconditional = MyConditional(loader=MyLoader3())
    myconditional.when = list()

    templar = Templar(loader=DataLoader(), variables={}, options=Options())

    myconditional.when.append("{{ test }}")
    assert (myconditional.evaluate_conditional(templar, {'test': False}) == False)
    assert (myconditional.evaluate_conditional(templar, {'test': True}) == True)

    myconditional.when.append("{{ test }}")

# Generated at 2022-06-22 14:09:13.564893
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = "my_var and my_var2"
    cond_result = True
    my_var = "OK"
    my_var2 = "OK"
    all_vars = dict(my_var=my_var, my_var2=my_var2)
    result = Conditional().evaluate_conditional(conditional, all_vars)
    assert result == cond_result, "The result of the test should have been a boolean value (%s)." % str(cond_result)

    conditional = "my_var > 4"
    cond_result = True
    my_var = 5
    all_vars = dict(my_var=my_var)
    result = Conditional().evaluate_conditional(conditional, all_vars)

# Generated at 2022-06-22 14:09:21.681983
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()

    result_str = ''
    result_str += "result before variable substitution is "
    result_str += "False"
    res = p.evaluate_conditional(t, dict(a=1, b=2, c=3))

    # assert
    assert res == False
    assert sys.stdout.getvalue() == result_str

    sys.stdout = old_stdout

# Generated at 2022-06-22 14:09:24.593336
# Unit test for constructor of class Conditional
def test_Conditional():
    loader = 'loader'
    instance = Conditional(loader)
    assert instance._loader == loader, instance._loader
    assert instance._when == [], instance._when


# Generated at 2022-06-22 14:09:32.324261
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.task import Task
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    t = Task()

# Generated at 2022-06-22 14:09:44.420789
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-22 14:09:56.311021
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

    assert c.extract_defined_undefined('a is defined') == [('a', 'is', 'defined')]
    assert c.extract_defined_undefined('a.b is not defined') == [('a.b', 'is not', 'defined')]
    assert c.extract_defined_undefined('a.b is defined and b.c is not defined') == [
        ('a.b', 'is', 'defined'),
        ('b.c', 'is not', 'defined'),
    ]
    assert c.extract_defined_undefined('hostvars[inventory_hostname].key is defined') == [
        ('hostvars[inventory_hostname].key', 'is', 'defined'),
    ]

# Generated at 2022-06-22 14:10:08.663106
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    module_utils_basic = AnsibleModule(argument_spec={})
    from ansible.template import Templar
    from ansible.template.vars import AllVars
    # _templar shouldn't be used here. Only to test evaluate_conditional
    # method of Conditional mixin class.
    templar = Templar(loader=None, variables=AllVars(loader=None))
    conditional = Conditional(loader=None)

    assert conditional.evaluate_conditional(templar, {'foo': 'bar'})
    # true
    assert conditional.evaluate_conditional(templar, {'foo': 'bar'})
    conditional.when = [1, 2, 3]
    assert conditional.evaluate_conditional(templar, {'foo': 'bar'})
    conditional.when = [0, False, None]

# Generated at 2022-06-22 14:10:22.035135
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from io import StringIO

    class TestClass(Conditional):
        def __init__(self):
            self._loader = FakeLoader()
            self.when = [
                "foo | default(bar) == 'success'",
                "baz is defined and not baz",
            ]
            self._ds = PlayContext()
            self._ds._search_path = (None,)

            self.templar = Templar(loader=self._loader, variables=self._ds)

    test_obj = TestClass()

    all_vars = dict(
        foo='success',
        baz=False,
    )
    result = test_obj.evaluate_conditional(test_obj.templar, all_vars)
   

# Generated at 2022-06-22 14:11:27.130898
# Unit test for method evaluate_conditional of class Conditional