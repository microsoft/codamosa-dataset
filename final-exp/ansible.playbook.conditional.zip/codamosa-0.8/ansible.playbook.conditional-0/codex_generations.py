

# Generated at 2022-06-22 14:01:37.620762
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    cls = Conditional()
    # test without templar
    cls.when = ["1==1", "{{ 1 == 1 }}", "{{ 2 == 1 }}", "{{ 1 == 1 }} and {{ 2 == 1 }} and {{ 3 == 1 }}"]
    assert cls.evaluate_conditional(None, None) == False
    cls.when = ["{{ 1 == 1 }} and {{ 2 == 1 }}", "{{ 1 == 1 }} and {{ 2 == 1 }} and {{ 3 == 1 }}"]
    assert cls.evaluate_conditional(None, None) == False
    cls.when = ["{{ 1 == 1 }} and {{ 2 == 1 }} and {{ 3 == 1 }}", "2==1"]
    assert cls.evaluate_conditional(None, None) == False
    cls.when = []
    assert cls.evaluate_conditional

# Generated at 2022-06-22 14:01:48.881702
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    class DummyClass(Conditional):
        def __init__(self, loader=None):
            self._loader = loader
            self.when = ['foo', 'foo and true']

    # test evaluate_conditional()
    dc = DummyClass(loader=DataLoader())
    templar = Templar(loader=dc._loader, variables={'foo': True})
    results = dc.evaluate_conditional(templar=templar, all_vars={})
    assert len(results) == 2
    assert results[0] is True
    assert results[1] is True

    # test evaluate_conditional() with invalid data structure
    dc = DummyClass()

# Generated at 2022-06-22 14:02:02.190947
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    fake_vars = dict(
        _original_file='/etc/ansible/roles/common/tasks/main.yml',
        a='a',
        b='b',
        c='c',
        D=dict(
            d='d',
            e='e',
            f='f',
        )
    )

    # Test 1: conditional is None
    test_conditional_1 = Conditional()
    assert test_conditional_1.evaluate_conditional(None, fake_vars) is True

    # Test 2: conditional is empty string
    test_conditional_2 = Conditional()
    test_conditional_2.when = ['']
    assert test_conditional_2.evaluate_conditional(None, fake_vars) is True

    # Test 3: conditional is False
    test

# Generated at 2022-06-22 14:02:15.157940
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    cond = Conditional()
    print('Testing Conditional.evaluate_conditional')

    # testing "when: 1 == 1"
    print('   assert: 1 == 1')
    context = PlayContext()
    templar = Templar(loader=None, variables={})
    assert cond.evaluate_conditional(templar, dict(one='1', hostvars={'foo': {'baz': 'X'}}))

    # testing "when: hostvars[inventory_hostname] == 'foo' "
    print('   assert: hostvars[inventory_hostname] == "foo"')

# Generated at 2022-06-22 14:02:28.518795
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    test_conditional = Conditional(loader=loader)

    # Test cases

    # 1) Test when: (1 == 1 and 1 == 1)
    vars = VariableManager()
    vars.extra_vars = {
        'foo': 1,
        'bar': 1,
        'baz': 3
    }

    test_conditional._when = [
        "(foo == 1 and bar == 1)"
    ]


# Generated at 2022-06-22 14:02:37.449056
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.base import Base
    class BaseClass(Base, Conditional):
        pass

    class Object(BaseClass):
        pass

    obj = Object()
    templar = {}
    all_vars = {}
    assert obj.evaluate_conditional(templar, all_vars)

    obj = Object(when=['1==2'])
    templar = {}
    all_vars = {}
    assert not obj.evaluate_conditional(templar, all_vars)


# Generated at 2022-06-22 14:02:46.145926
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    mystring = "hostvars['foo']['bar'] is defined and not hostvars['baz']"
    assert c.extract_defined_undefined(mystring) == [("hostvars['foo']['bar']", 'is', 'defined'),
                                                     ("hostvars['baz']", 'not', 'is')]

    mystring = "hostvars['foo']['bar'] is not defined or hostvars['baz'] is undefined"
    assert c.extract_defined_undefined(mystring) == [("hostvars['foo']['bar']", 'is', 'not'),
                                                     ("hostvars['baz']", 'is', 'undefined')]

# Generated at 2022-06-22 14:02:58.703169
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert Conditional.extract_defined_undefined(None, '') == []
    assert Conditional.extract_defined_undefined(None, 'foo') == []
    assert Conditional.extract_defined_undefined(None, ' "foo" ') == []

    assert Conditional.extract_defined_undefined(None, 'foo is defined') == [('foo', 'is', 'defined')]
    assert Conditional.extract_defined_undefined(None, 'foo is undefined') == [('foo', 'is', 'undefined')]
    assert Conditional.extract_defined_undefined(None, 'foo is not defined') == [('foo', 'is not', 'defined')]

# Generated at 2022-06-22 14:03:08.918430
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestConditional(Conditional):
        def __init__(self, loader=None):
            self.when = ['1 == 1', '1 == 2']
            self.when_no_such_var = ['1 == 1', 'not 1 == 2', "* | list | length > 0", "{% if False %} 1 {% elif True %} 2 {% else %} 3 {% endif %} == 2",
                                     "{{ not_a_real_var }} == 'defined'", "{{ not_a_real_var_2 }} is undefined"]

# Generated at 2022-06-22 14:03:14.977126
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    pc = PlayContext()
    t = Templar(loader=None, variables={})

    # no conditionals returns True
    c = Conditional()
    assert c.evaluate_conditional(t, {}) == True

    # no conditionals returns True
    c = Conditional()
    c._when = 'foo'
    assert c.evaluate_conditional(t, {}) == True

    # conditional is a literal True, returns True
    c = Conditional()
    c._when = True
    assert c.evaluate_conditional(t, {}) == True

    # conditional is a literal False, returns False
    c = Conditional()
    c._when = False
    assert c.evaluate_conditional(t, {}) == False

    #

# Generated at 2022-06-22 14:03:33.791350
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('hostvars["foo"] is defined') == [('hostvars["foo"]', 'is', 'defined')]
    assert c.extract_defined_undefined('foo_var is not defined') == [('foo_var', 'is not', 'defined')]
    assert c.extract_defined_undefined(
        'hostvars["foo"] is defined and hostvars["bar"] is not undefined') == [
            ('hostvars["foo"]', 'is', 'defined'),
            ('hostvars["bar"]', 'is not', 'undefined')
        ]

# Generated at 2022-06-22 14:03:46.471705
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    def clean_dict(d):
        for key, value in d.items():
            if isinstance(value, dict):
                if len(value) == 0:
                    del d[key]
                    continue
                clean_dict(value)
            if isinstance(value, list):
                if len(value) == 0:
                    del d[key]
                    continue
                delete = True
                for elem in value:
                    if not isinstance(elem, dict):
                        delete = False
                        break
                if delete:
                    del d[key]

    def test_conditional(all_vars, conditional):
        pc = PlayContext()


# Generated at 2022-06-22 14:03:53.729738
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestConditional(Conditional):
        def __init__(self, loader=None):
            self._loader = loader


    def test_function(templar, plugin, all_vars, test_var_name, test_conditional):
        obj = TestConditional(loader=templar._loader)
        obj._ds = dict(name="test")
        attr_name, attr_value = test_var_name
        setattr(obj, attr_name, attr_value)
        setattr(obj, 'when', [test_conditional])
        return obj.evaluate_conditional(templar, all_vars)

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    C.DEFAULT

# Generated at 2022-06-22 14:04:05.275598
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    display = Display()
    loader = DictDataLoader({
        't1.yml': """
            #!/usr/bin/ansible-playbook
            ---
            tasks:
                - name: test
                  debug:
                    msg: "This is test"
                  when: 'test' in groups
        """,
    })
    inventory = HostsInventoryLoader([], None, loader=loader)
    play = Play().load('t1.yml', loader=loader, variable_manager=VariableManager(loader=loader, inventory=inventory))
    task = play.get_tasks()[0]
    conditional = Conditional()
    conditional.when = ['test' in groups]
    conditional._loader = loader

# Generated at 2022-06-22 14:04:17.630268
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.plugins.action import ActionBase
    class TestAction(ActionBase, Conditional):
        def run(self, tmp=None, task_vars=None):
            return super(TestAction, self).run(tmp, task_vars)
    def test(s, expected):
        c = TestAction(None)
        assert c.extract_defined_undefined(s) == expected
    test("defined foo",
         [("foo", "is", "defined")])
    test("foo is defined",
         [("foo", "is", "defined")])
    test("foo is not defined",
         [("foo", "is", "not")])
    test("foo is not  defined",
         [("foo", "is", "not")])

# Generated at 2022-06-22 14:04:22.124831
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.module_utils.six import PY3
    from ansible.template import Templar
    from ansible.vars import VariableManager

    if PY3:
        assert False, "This test has not been implemented for Python 3 yet"

    # setup ansible module_utils environment
    mock_tqm = None
    variables = VariableManager()
    loader = 'dummy_loader'
    shared_loader_obj = None

    # instantiate a new Templat object to be used in our tests
    templar = Templar(loader=loader, variables=variables, shared_loader_obj=shared_loader_obj)
    templar.environment.filters['quote'] = lambda x: '"%s"' % x

# Generated at 2022-06-22 14:04:35.024340
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    cond = Conditional()

    assert cond.extract_defined_undefined("") == []
    assert cond.extract_defined_undefined("this is a test") == []
    assert cond.extract_defined_undefined("this is not defined") == [("this", "is", "not")]
    assert cond.extract_defined_undefined("this is defined") == [("this", "is", "defined")]
    assert cond.extract_defined_undefined("not this is defined") == [("this", "is", "defined")]
    assert cond.extract_defined_undefined("not this is not defined") == [("this", "is", "not")]
    assert cond.extract_defined_undefined("this is undefined") == [("this", "is", "undefined")]
    assert cond.extract

# Generated at 2022-06-22 14:04:44.892571
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar
    from ansible.vars import VariableManager
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(x='foo', y='bar')
    templar = Templar(loader=None, variables=variable_manager)

    c = Conditional()
    assert c.evaluate_conditional(templar, variable_manager.extra_vars)

    setattr(c, 'when', [True])
    assert c.evaluate_conditional(templar, variable_manager.extra_vars)

    setattr(c, 'when', ['x|default("bad") == "foo"'])
    assert c.evaluate_conditional(templar, variable_manager.extra_vars)

    setattr(c, 'when', ['x == "baz"'])

# Generated at 2022-06-22 14:04:55.241865
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:04:56.948572
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    assert False  # TODO: implement your test here


# Generated at 2022-06-22 14:05:23.300869
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def test_eval(conditional, expected):
        conditional = Conditional()
        result = conditional.extract_defined_undefined(conditional)
        assert expected == result

    test_eval("foo is defined", [("foo", "is", "defined")])
    test_eval("foo is undefined", [("foo", "is", "undefined")])
    test_eval("foo is not defined", [("foo", "is not", "defined")])
    test_eval("foo not is undefined", [("foo", "not is", "undefined")])
    test_eval("hostvars['foo'] is defined", [("hostvars['foo']", "is", "defined")])
    test_eval("hostvars['foo'] is defined and bar is undefined", [("hostvars['foo']", "is", "defined")])
   

# Generated at 2022-06-22 14:05:36.163174
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Basic unit test for Conditional.evaluate_conditional

    Note: This is intended to run with the test.yml files in this directory.
    '''
    import ansible.parsing.yaml.objects
    import ansible.plugins.loader
    import ansible.template
    import ansible.playbook
    import ansible.executor.play_iterator
    import ansible.playbook.play
    import ansible.playbook.block
    import ansible.playbook.task
    import ansible.playbook.role

    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block

# Generated at 2022-06-22 14:05:43.633332
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_obj = Conditional(None)

    conditional_1 = "5 == 5"
    conditional_2 = "5 == 6"
    all_vars = {}

    conditional_obj.when = [conditional_1, conditional_2]
    
    templar = CagomiTemplar(all_vars, enable_lookups=False)
    assert conditional_obj.evaluate_conditional(templar, all_vars) == True
    conditional_obj.when = [conditional_2, conditional_1]
    assert conditional_obj.evaluate_conditional(templar, all_vars) == False

    conditional_obj.when = [conditional_1, conditional_2, True]
    assert conditional_obj.evaluate_conditional(templar, all_vars) == True

    conditional_obj.when

# Generated at 2022-06-22 14:05:56.166791
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    results = []
    # most basic tests
    results.append(_eval_conditional("True", True))
    results.append(_eval_conditional("False", False))
    results.append(_eval_conditional("yes", True))
    results.append(_eval_conditional("no", False))
    results.append(_eval_conditional("1", True))
    results.append(_eval_conditional("0", False))
    results.append(_eval_conditional("True and False", False))
    results.append(_eval_conditional("True and True", True))
    results.append(_eval_conditional("True or False", True))
    results.append(_eval_conditional("False or False", False))
    # jinja2 tests


# Generated at 2022-06-22 14:06:07.880139
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    data = dict()
    data['test_hostvars'] = dict()
    data['test_hostvars']['foo'] = dict()
    data['test_hostvars']['foo']['bar'] = 'test_value'
    data['test_defined_var'] = 'test_value'
    data['test_not_defined_var'] = None

    loader = DictDataLoader({})
    inventory = Inventory(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)
    class TestConditional(Conditional):
        _when = FieldAttribute(isa='list', default=list, extend=True, prepend=True)
    test_conditional = TestConditional(loader=loader)
    test_cond

# Generated at 2022-06-22 14:06:20.521667
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("a is defined") == [('a', 'is', 'defined')]
    assert c.extract_defined_undefined("a is not defined") == [('a', 'is not', 'defined')]
    assert c.extract_defined_undefined("a is undefined") == [('a', 'is', 'undefined')]
    assert c.extract_defined_undefined("a is not undefined") == [('a', 'is not', 'undefined')]
    assert c.extract_defined_undefined("a is defined or b is is defined") == [('a', 'is', 'defined'), ('b', 'is', 'defined')]

# Generated at 2022-06-22 14:06:31.901032
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    display = Display()
    display.verbosity = 5
    class Hostname:
        def __init__(self, hostname):
            self.name = hostname
    class VarsModule:
        def __init__(self, vars):
            self.vars = vars
            self.vars['groups'] = {}

        def get_vars(self):
            return self.vars

        def get_hostvars(self):
            return self.vars.get('hostvars', {})

    def get_host_name(hostname):
        return Hostname(hostname)
    def get_VariableManager(vars=dict(groups=dict())):
        from ansible.vars import VariableManager
        from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-22 14:06:44.238961
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c_pos = Conditional()
    res = c_pos.extract_defined_undefined("var0 is defined or var1 is undefined")
    assert res == [('var0', 'is', 'defined'), ('var1', 'is', 'undefined')]

    res = c_pos.extract_defined_undefined("var0 is defined and var1 is undefined")
    assert res == [('var0', 'is', 'defined'), ('var1', 'is', 'undefined')]

    res = c_pos.extract_defined_undefined("var0 is defined")
    assert res == [('var0', 'is', 'defined')]

    res = c_pos.extract_defined_undefined("var0 is defined and var1 is defined")

# Generated at 2022-06-22 14:06:50.335133
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    rv = Conditional().extract_defined_undefined('1 == 1 or hostvars[inventory_hostname] is undefined')
    assert len(rv) == 1
    assert rv[0][0] == 'hostvars[inventory_hostname]'
    assert rv[0][1] == 'is'
    assert rv[0][2] == 'undefined'

    rv = Conditional().extract_defined_undefined('1 == 1 or hostvars["inventory_hostname"] is not defined')
    assert len(rv) == 1
    assert rv[0][0] == 'hostvars["inventory_hostname"]'
    assert rv[0][1] == 'is not'
    assert rv[0][2] == 'defined'

    rv = Conditional().extract_defined_und

# Generated at 2022-06-22 14:06:58.252580
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = "foo.bar is defined or hostvars['example.com']['foo']['bar'] is undefined or baz is defined"
    results = Conditional.extract_defined_undefined('', cond)
    expected = [('foo.bar', 'is', 'defined'),
                ("hostvars['example.com']['foo']['bar']", 'is', 'undefined'),
                ('baz', 'is', 'defined')]
    assert results == expected



# Generated at 2022-06-22 14:07:31.036542
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Test case for method evaluate_conditional of class Conditional
    '''
    myconditional = Conditional()
    templar = myconditional._loader.get_basedir() + '/templar'
    all_vars = myconditional._loader.get_basedir() + '/vars'
    assert(myconditional.evaluate_conditional(templar, all_vars)==False)

# Generated at 2022-06-22 14:07:42.760869
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(variable_manager.get_vars(loader=None, play=None, host=None))
    templar = Templar(loader=None, variables=variable_manager)

    task = Conditional()

    all_vars = dict()
    task.when = ['True']
    assert (task.evaluate_conditional(templar, all_vars) is True)

    task.when = ['False']
    assert (task.evaluate_conditional(templar, all_vars) is False)

    task.when = ['1 == 1']
    assert (task.evaluate_conditional(templar, all_vars) is True)

   

# Generated at 2022-06-22 14:07:52.323506
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.plugins import module_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    attr_test_cases = [
        ('test_undefined', False),
        ('test_defined', True),
        ('test_not_defined', True),
        ('test_undefined_not_defined', True),
    ]
    failed_case = 'test_undefined_not_defined'

    play_context = PlayContext()

    loader = DataLoader()

# Generated at 2022-06-22 14:08:02.760667
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.task import Task
    task = Task()
    conditional = 'a is defined or b is defined and c is undefined or d'
    assert task.extract_defined_undefined(conditional) == [('a', 'is', 'defined'), ('b', 'is', 'defined'), ('c', 'is', 'undefined')]
    conditional = 'not (a is not defined) and not (b is defined and not (c is undefined)) or d'
    assert task.extract_defined_undefined(conditional) == [('a', 'is', 'not'), ('b', 'is', 'defined'), ('c', 'is', 'undefined')]

# Generated at 2022-06-22 14:08:15.578881
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.inventory.inventory import Inventory

    class FooConditional(Conditional):
        pass

    host = Host(name='foo')
    group = Group(name='bar')
    group.add_host(host)
    inventory = Inventory(loader=None, groups=[group])
    variables = VariableManager(loader=None, inventory=inventory)
    play = Play().load({}, variable_manager=variables, loader=None)

# Generated at 2022-06-22 14:08:21.327088
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    cond = Conditional(loader=loader)
    assert cond._loader == loader
    assert type(cond._when) == list
    assert cond._when == []
    assert cond._ds is None

# Generated at 2022-06-22 14:08:34.763311
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond0 = Conditional()
    s0 = cond0.extract_defined_undefined('a is defined and b is defined and c is defined')
    assert (s0 == [('a', 'is', 'defined'), ('b', 'is', 'defined'), ('c', 'is', 'defined')])

    cond1 = Conditional()
    s1 = cond1.extract_defined_undefined('a and b')
    assert (s1 == [])

    cond2 = Conditional()
    s2 = cond2.extract_defined_undefined('a is not defined and b is undefined')
    assert (s2 == [('a', 'is not', 'defined'), ('b', 'is', 'undefined')])

    cond3 = Conditional()

# Generated at 2022-06-22 14:08:40.281086
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    c = Conditional()

    expr = "$IS_MASTER is defined"
    asserts = [("IS_MASTER", "is", "defined")]
    assert asserts == c.extract_defined_undefined(expr)

    expr = "master is not defined"
    asserts = [("master", "is not", "defined")]
    assert asserts == c.extract_defined_undefined(expr)

    expr = "not (master is defined or slave.status is undefined)"
    asserts = [("master", "is", "defined"), ("slave.status", "is", "undefined")]
    assert asserts == c.extract_defined_undefined(expr)

    expr = "not master.other is undefined"
    asserts = [("master.other", "is", "undefined")]
    assert asserts == c.extract_defined_

# Generated at 2022-06-22 14:08:48.352845
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert sorted(list(Conditional().extract_defined_undefined('hostvars[inventory_hostname] is defined and foo is not defined'))) == [('foo', 'is not', 'defined'), ('hostvars[inventory_hostname]', 'is', 'defined')]
    assert Conditional().extract_defined_undefined('invalid') == []
    assert Conditional().extract_defined_undefined('') == []


# Generated at 2022-06-22 14:08:58.546263
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import sys
    import os
    import unittest
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    import jinja2.exceptions
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import DEFAULT_VAULES, DEFAULT_HASH_BEHAVIOUR

    vars_manager = VariableManager()
    loader = DataLoader()
   

# Generated at 2022-06-22 14:09:55.902413
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    class TestConditional(Conditional):
        pass

    assert TestConditional(loader=None).extract_defined_undefined(
        cond="something foo is defined"
    ) == [('foo', 'is', 'defined')]
    assert TestConditional(loader=None).extract_defined_undefined(
        cond="something foo is not defined"
    ) == [('foo', 'is not', 'defined')]
    assert TestConditional(loader=None).extract_defined_undefined(
        cond="something foo is undefined"
    ) == [('foo', 'is', 'undefined')]
    assert TestConditional(loader=None).extract_defined_undefined(
        cond="something foo is not undefined"
    ) == [('foo', 'is not', 'undefined')]



# Generated at 2022-06-22 14:10:08.481781
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:10:22.035163
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    def test(conditional, expected):
        c = Conditional()
        actual = c.extract_defined_undefined(conditional)
        print(actual)
        assert expected == actual

    test('some_var is defined or hostvars[inventory_hostname] is not undefined', [('some_var', 'is', 'defined'),
                                                                                  ('hostvars[inventory_hostname]', 'is not', 'undefined')])
    test('some_var is undefined or hostvars[inventory_hostname] is defined', [('some_var', 'is', 'undefined'),
                                                                              ('hostvars[inventory_hostname]', 'is', 'defined')])

# Generated at 2022-06-22 14:10:28.111621
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    display.verbosity = 4
    import ansible.constants as C
    import ansible.utils.template as template
    import ansible.vars.manager as var_manager
    import ansible.vars.hostvars as hostvars
    import ansible.template.vars as template_vars
    import ansible.template.safe_eval as safe_eval
    import ansible.template.templar as templar
    import jinja2
    import sys

    class TestVarsModule(object):
        def __init__(self, basedir=None, vars=dict()):
            self.basedir = basedir
            self.vars = vars

        def run(self, terms, inject=None, **kwargs):
            results = []

# Generated at 2022-06-22 14:10:38.039433
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # create fake loader to get one
    class FakeVarsModule():
        def __init__(self, ds_data):
            self.ds = ds_data;
            self.ds['meta'] = {'hostvars': {}}
        def get_vars(self, loader, path, entities, cache=True):
            return self.ds
        def set_variable_manager(self, vm):
            return

    class FakeLoader():
        def __init__(self):
            self._fact_cache = {}
            self.vars_loader = FakeVarsModule({})
        def add_directory(self, dir_name):
            return
        def _filter_empty(self, results):
            return results
        def _add_directory(self, search_path):
            return

# Generated at 2022-06-22 14:10:51.064060
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    ''' Test evaluation of ansible conditional statements '''
    class test_Conditional_evaluate_conditional(object):
        pass
    test_Conditional_evaluate_conditional.when = ['', 'false', '"false"', 'true', '"true"', True, False, 'True', 'False']
    test_Conditional_evaluate_conditional.when = list(set(test_Conditional_evaluate_conditional.when))

    for conditional in test_Conditional_evaluate_conditional.when:
        # print(conditional)
        tc = Conditional()
        hostvars = dict()
        hostvars['test_inventory_hostname'] = None

        templar = Templar(loader=DataLoader())

# Generated at 2022-06-22 14:10:55.060256
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("hostvars['foo'] is undefined") == [("hostvars['foo']", "is", "undefined")]


# Generated at 2022-06-22 14:11:01.243600
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is not defined') == [('hostvars[inventory_hostname]', 'not is', 'defined')]
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is undefined') == [('hostvars[inventory_hostname]', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is not undefined') == [('hostvars[inventory_hostname]', 'not is', 'undefined')]

    assert conditional.extract

# Generated at 2022-06-22 14:11:08.761671
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.parsing.dataloader import DataLoader

    class MyTask(Conditional):
        def __init__(self):
            loader = DataLoader()
            super(MyTask, self).__init__(loader=loader)

    class MyHost():
        def __init__(self, vars):
            self.vars = vars

        def get_vars(self):
            return self.vars

    # Test case: conditional is set to None
    # Expected result: True
    mytask = MyTask()
    mytask.when = None
    myhost = MyHost({})
    assert mytask.evaluate_conditional(myhost.get_vars())

    # Test case: conditional is set to False
    # Expected result: False
    mytask = MyTask()

# Generated at 2022-06-22 14:11:20.201667
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    test_data = (
        # input string     , output
        ('foo not is defined', [('foo', 'not is', 'defined')]),
        ('foo is defined', [('foo', 'is', 'defined')]),
        ('foo is not defined', [('foo', 'is not', 'defined')]),
        ('foo is undefined', [('foo', 'is', 'undefined')]),
        ('foo is not undefined', [('foo', 'is not', 'undefined')]),
        ('foo is defined and bar is undefined', [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]),
    )

    for (in_str, expected) in test_data:
        c = Conditional()
        actual = c.extract_defined_undefined(in_str)