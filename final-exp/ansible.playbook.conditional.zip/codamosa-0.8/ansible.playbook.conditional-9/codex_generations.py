

# Generated at 2022-06-22 14:01:35.729655
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    l = c.extract_defined_undefined('a is defined and b is defined')
    assert l == [ ('a', 'is', 'defined'), ('b', 'is', 'defined') ]
    l = c.extract_defined_undefined('not a is defined and b is not defined')
    assert l == [ ('a', 'not is', 'defined'), ('b', 'is not', 'defined') ]
    l = c.extract_defined_undefined('a and b is defined')
    assert l == []
    l = c.extract_defined_undefined('a and b is not defined')
    assert l == []
    l = c.extract_defined_undefined('a not is defined and b')
    assert l == []

# Generated at 2022-06-22 14:01:43.409602
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    # Test cases
    test_data = [
        ("foo == 'bar'", []),
        ("hostvars['foo'] is undefined", [(u'hostvars[\'foo\']', u'is', u'undefined')]),
        ("hostvars['foo'] is undefined and hostvars['bar'] is defined", [(u'hostvars[\'foo\']', u'is', u'undefined'), (u'hostvars[\'bar\']', u'is', u'defined')]),
        ("hostvars['foo'] is undefined and x is undefined", [(u'hostvars[\'foo\']', u'is', u'undefined'), (u'x', u'is', u'undefined')]),
        ("A and B or (D is defined and E is defined) and F", [])
    ]

    # Loop

# Generated at 2022-06-22 14:01:52.818309
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Note: we want to test the method Conditional.evaluate_conditional only.
    # We don't want to go into the details of the class Conditional.
    # So, we don't use unittest.TestCase and simply
    # write some test functions with assert statements.

    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()


# Generated at 2022-06-22 14:02:03.869980
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # this code is used for testing the Conditional class
    # it should not be included in the actual code base

    # Mock PlayContext and templar for testing.
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    fake_loader = DictDataLoader({
        "a.yml": "a: 1",
        "b.yml": "b: 2",
    })
    fake_inventory = make_inventory(loader=fake_loader)

    class FakeOptions:
        pass
    fake_options = FakeOptions()
    fake_options.connection = 'localhost'
    fake_options.module_path = '/path/to/mymodules'
    fake

# Generated at 2022-06-22 14:02:16.074205
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.module_utils.facts import Facts

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    Cond = Conditional()

    # Create a dictionary for all_vars to use (actual vars are not relevant)
    all_vars = dict()

    # Mock Facts object
    factobj = Facts()
    factobj.add_host()
    factobj.add_host()

    # Mock PlayContext object
    playcon = PlayContext()

    # Create a Templar object
    templar = Templar(loader=None, variables=factobj.get_facts(playcon.remote_addr))


    conditional = "inventory_hostname == 'localhost'"
    assert Cond.evaluate_conditional(templar, all_vars) == True



# Generated at 2022-06-22 14:02:29.503561
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Test the case where a variable is defined
    assert Conditional().evaluate_conditional('{{ test_var }}', {'test_var': 'test_val'})

    # Test the case where a variable is not defined
    assert not Conditional().evaluate_conditional('{{ test_var }}', {})

    # Test the case where no variable is present
    assert Conditional().evaluate_conditional('Hello', {})

    # Test the case where a variable is undefined and we want to skip the line
    assert not Conditional().evaluate_conditional('{{ test_var is undefined }}', {})

    # Test the case where a variable is defined and we want to skip the line
    assert not Conditional().evaluate_conditional('{{ test_var is defined }}', {'test_var': 'test_val'})

    # Test the case where a complex condition is present

# Generated at 2022-06-22 14:02:41.002836
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    ''' unit test to check execution of evaluate_conditional method of class Conditional '''

    class MyClass(Conditional):
        def __init__(self, loader):
            self._loader = loader
            self.when = ["any"]

    p = MyClass(loader=None)
    templar = None
    all_vars = None

    assert p.evaluate_conditional(templar, all_vars)

    p.when = ["1 == 1"]
    assert p.evaluate_conditional(templar, all_vars)

    p.when = ["1 != 1"]
    assert not p.evaluate_conditional(templar, all_vars)


# Generated at 2022-06-22 14:02:53.126614
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    #given
    when = '{{ ansible_managed is defined and ansible_managed == "Automation for the People" }}'
    condition = Conditional()
    #when
    result = condition.extract_defined_undefined(when)
    #then
    assert result == [('ansible_managed', 'is', 'defined')]

    #given
    when = '{{ my_var is not defined or my_var == "my_val" }}'
    #when
    result = condition.extract_defined_undefined(when)
    #then
    assert result == [('my_var', 'is', 'undefined')]

    #given
    when = '{{ my_var is not defined or ( my_var == "my_val" and other_var is defined) }}'
    #when
    result = condition.extract

# Generated at 2022-06-22 14:03:04.947786
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # test a simple use case
    conditional = 'testvar is defined or testvar2 is not defined'
    results = Conditional().extract_defined_undefined(conditional)
    assert len(results) == 2
    assert ('testvar','is','defined') in results
    assert ('testvar2','is not','defined') in results

    # test the case where extra whitespace is present
    conditional = 'testvar is defined   or testvar2 is not defined'
    results = Conditional().extract_defined_undefined(conditional)
    assert len(results) == 2
    assert ('testvar','is','defined') in results
    assert ('testvar2','is not','defined') in results

    # test the case where the statements are reversed
    conditional = 'testvar is defined and testvar2 is undefined'
    results = Conditional().ext

# Generated at 2022-06-22 14:03:12.165094
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    t = Templar(loader=None, variables=VariableManager())
    c = Conditional(loader=None)

    c.when = '{{ foo is defined and bar is defined }}'
    res = c.extract_defined_undefined(c.when)
    assert res == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

    c.when = u'{{ foo is defined and (bar is defined or bam is defined) }}'
    res = c.extract_defined_undefined(c.when)
    assert res == [('foo', 'is', 'defined'), ('bar', 'is', 'defined'), ('bam', 'is', 'defined')]



# Generated at 2022-06-22 14:03:36.990090
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    ''' test all logic paths in Conditional.evaluate_conditional '''

    #    all_vars = dict(
    #        test_true1=True,
    #        test_true2=True,
    #        test_true3=True,
    #        test_false1=False,
    #        test_false2=False,
    #        test_false3=False,
    #        test_equal_true1='me',
    #        test_equal_true2='me',
    #        test_equal_true3='me',
    #        test_equal_true4='me'
    #)

    # Define the test

# Generated at 2022-06-22 14:03:48.697546
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    c = Conditional()
    templar = Templar(loader=None, variables={})
    result = c.evaluate_conditional(templar, {})
    assert result == True

    play_context = PlayContext()
    setattr(c, '_play_context', play_context)
    setattr(c, '_ds', 'test')

    c._when = [False]
    result = c.evaluate_conditional(templar, {})
    assert result == False

    c._when = [True]
    result = c.evaluate_conditional(templar, {})
    assert result == True

    c._when = ['false']
   

# Generated at 2022-06-22 14:03:58.399869
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    class TestConditional(object):
        def __init__(self):
            self.__dict__ = {}

        def extract_defined_undefined(self, conditional):
            return Conditional.extract_defined_undefined(self, conditional)

    c = TestConditional()

    # empty string
    assert c.extract_defined_undefined('') == []
    # string without define/undefined test
    assert c.extract_defined_undefined('foo') == []
    # string with defined test
    assert c.extract_defined_undefined('foo bar is defined') == [('foo bar', 'is', 'defined')]
    # string with undefined test
    assert c.extract_defined_undefined('foo bar is not defined') == [('foo bar', 'is not', 'defined')]
    # string with two

# Generated at 2022-06-22 14:04:05.856942
# Unit test for constructor of class Conditional
def test_Conditional():
    cond = Conditional()
    # print(cond._when)
    print(vars(cond))
    if vars(cond)['_when'] == []:
        print("testing class method '__init__' of class 'Conditional' - ok")
    else:
        print("testing class method '__init__' of class 'Conditional' - fail")


if __name__ == '__main__':
    test_Conditional()

# Generated at 2022-06-22 14:04:17.755994
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("(test|test2) is defined") == []
    assert c.extract_defined_undefined("(test|test2) is defined and (hostvars['hostname'] is not defined or hostvars['hostname']['ansible_ssh_host'] is defined)") == [("hostvars['hostname']", "is not", "defined"), ("hostvars['hostname']['ansible_ssh_host']", "is", "defined")]
    assert c.extract_defined_undefined("test is defined") == [("test", "is", "defined")]

# Generated at 2022-06-22 14:04:26.036840
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Test with a conditional that is valid
    conditional = Conditional()
    conditional.when = ['True']
    templar = FakeTemplar()
    all_vars = {'foo': 'bar'}
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test with a conditional that is invalid
    conditional = Conditional()
    conditional.when = ['']
    templar = FakeTemplar()
    all_vars = {'foo': 'bar'}
    assert not conditional.evaluate_conditional(templar, all_vars)

    # Test with multiple conditionals where one is invalid
    conditional = Conditional()
    conditional.when = ['True', '']
    templar = FakeTemplar()
    all_vars = {'foo': 'bar'}


# Generated at 2022-06-22 14:04:38.484513
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Testing normal jinja2 template with 'is defined' in when condition
    # The variable `apache_enabled` is defined in dict test_hostvars
    conditional = """{{ 'apache_enabled' is defined }}"""
    conditional = Conditional._check_conditional(conditional, templar, test_hostvars)
    assert conditional == True

    # Testing normal jinja2 template with 'is not defined' in when condition
    # The variable `apache_enabled` is defined in dict test_hostvars
    conditional = """{{ 'apache_enabled' is not defined }}"""
    conditional = Conditional._check_conditional(conditional, templar, test_hostvars)
    assert conditional == False

    # Testing compound jinja2 template with 'is defined' in when condition
    # The variable `apache_enabled` is defined in dict

# Generated at 2022-06-22 14:04:50.630917
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar

    cls = Conditional()
    cls.when = ['foo.bar', True]
    assert cls._check_conditional(True, Templar(loader=None), dict())
    assert not cls._check_conditional(False, Templar(loader=None), dict())

    # try parsing a simple string using the templar
    assert cls._check_conditional('True', Templar(loader=None), dict())
    assert not cls._check_conditional('False', Templar(loader=None), dict())

    # simple var lookup
    d = dict(a=True)
    assert cls._check_conditional('a', Templar(loader=None), dict(a=True))
    assert not cls._check_conditional('a', Templar(loader=None), dict(a=False))

    #

# Generated at 2022-06-22 14:04:57.934741
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    pc = PlayContext()
    loader = DataLoader()
    inventory = InventoryManager(loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    class TestConditional(Base):
        _when = FieldAttribute(isa='list', default=list, extend=True)

    c = TestConditional()

# Generated at 2022-06-22 14:05:08.854109
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''test method evaluate_conditional'''
    from ansible.template import Templar
    from ansible.vars import VariableManager

    class Object(object):
        pass

    conditional = Conditional()
    templar = Templar(loader=None, variables=VariableManager())

    # if evaluate_conditional return True, then it pass
    # define a simple dictionary
    all_vars = dict(key1='hello', key2=10)
    # this should return True
    assert conditional.evaluate_conditional(templar, all_vars)

    # test with a simple boolean
    conditional = Object()
    conditional.when = [True]
    all_vars = dict(key1='hello', key2=10)
    assert conditional.evaluate_conditional(templar, all_vars)

    conditional.when = False

# Generated at 2022-06-22 14:05:29.923323
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

# Generated at 2022-06-22 14:05:40.356630
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.utils import context_objects as co

    fake_loader = co.get_loader({})
    fake_tqm = co.get_tqm(None, 10, {}, fake_loader)
    fake_all_vars = co.get_variable_manager(fake_loader, fake_tqm.inventory, {}).get_vars(play=co.get_play())

    cond = Conditional(loader=fake_loader)

    expected_results = [
        ('host_name', ' ', 'defined'),
        ('host_name', ' ', 'defined')
    ]
    conditional = 'host_name is defined or host_name is defined'
    results = cond.extract_defined_undefined(conditional)
    assert results == expected_results, results


# Generated at 2022-06-22 14:05:51.026071
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook import Play
    from ansible.playbook.play import Play as Play_ds
    from ansible.template import Templar

    def test(conditional, variables):
        # create a fake play to hold variables
        play_obj = Play().load({'name': 'test', 'hosts': 'all', 'gather_facts': 'no'}, variable_manager=variables)
        play = Play_ds()
        play._variable_manager = variables
        templar = Templar(loader=None, variables=variables)

        # create a fake base object
        class Base:
            pass
        base_obj = Base()
        base_obj._ds = None

        # create a Conditional object and run it
        Conditional.mixin(Base)
        base_obj._when = [conditional]
        return base_

# Generated at 2022-06-22 14:06:01.318155
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    templar = Templar(loader=loader, variables={'var1':'foo', 'var2':'bar'})
    cond = Conditional()

    cond.when = [{'var1': 'foo'}]
    assert cond.evaluate_conditional(templar, templar.available_variables)

    cond.when = ['var1=="foo"']
    assert cond.evaluate_conditional(templar, templar.available_variables)

    cond.when = ['var1=="foobar"']
    assert not cond.evaluate_conditional(templar, templar.available_variables)

    cond.when = ['var1==var2']
   

# Generated at 2022-06-22 14:06:11.538768
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    display.verbosity = 3

    class Example(object):

        def __init__(self):
            self._when = [
                'a',
                'b',
                'c',
            ]
            # remember that self._when is a list
            self._when.extend([
                'foo is defined',
                'bar is not defined',
                'baz is undefined',
                'badger is defined',
                "foo == 'bar' or foo != 'baz'",
            ])


# Generated at 2022-06-22 14:06:23.231055
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:06:33.950518
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    class MyTemplar(Templar):
        # For testing, the superclass methods are useless because they don't set the expected values
        # So override them to call the special _add_hostvars_from_inventory() method
        # which is added to make testing easier
        def _add_hostvars_from_inventory(self):
            self.available_variables['inventory_hostname'] = 'localhost'
            self.available_variables['inventory_hostname_short'] = 'localhost'
            self.available_variables['group_names'] = ['ungrouped']
            self.available_variables['groups'] = { 'ungrouped': [] }


# Generated at 2022-06-22 14:06:45.918784
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    text1 = 'invalid'
    assert Conditional().extract_defined_undefined(text1) == []

    text1 = 'hostvars[inventory_hostname] is undefined'
    assert Conditional().extract_defined_undefined(text1) == [('hostvars[inventory_hostname]', 'is', 'undefined')]

    text1 = 'hostvars[inventory_hostname] is defined'
    assert Conditional().extract_defined_undefined(text1) == [('hostvars[inventory_hostname]', 'is', 'defined')]

    text1 = 'inventory_hostname is defined'
    assert Conditional().extract_defined_undefined(text1) == [('inventory_hostname', 'is', 'defined')]

    text1 = 'inventory_hostname not is defined'
   

# Generated at 2022-06-22 14:06:54.273802
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    import ansible.playbook.role

# Generated at 2022-06-22 14:07:07.577239
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond_obj = Conditional()
    conditional1 = 'foo is defined and bar is defined'
    assert cond_obj.extract_defined_undefined(conditional1) == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]
    conditional2 = 'foo is not defined and bar is undefined'
    assert cond_obj.extract_defined_undefined(conditional2) == [('foo', 'is not', 'defined'), ('bar', 'is', 'undefined')]
    # no defined/undefined tests in conditional
    conditional3 = 'foo is bar and bar is foo'
    assert cond_obj.extract_defined_undefined(conditional3) == []
    # not a string
    conditional4 = 42
    assert cond_obj.extract_defined_undefined(conditional4) == []


# Generated at 2022-06-22 14:07:20.652906
# Unit test for constructor of class Conditional
def test_Conditional():
    condition = Conditional()
    assert condition is not None

# Generated at 2022-06-22 14:07:33.271402
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar

    vm = VariableManager()
    vm.set_vars(dict(
        TEST_VAR = "test_value",
        TEST_DICT = dict(a="dict_value"),
        TEST_BOOL = True,
        TEST_LIST = ["item1", "item2"],
    ))

# Generated at 2022-06-22 14:07:43.868707
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Test that basic calls to extract_defined_undefined work,
    # using a Conditional with minimal attributes
    c = Conditional(loader=None)

    # Test defined
    results = c.extract_defined_undefined("{{ foo is defined }}")
    assert len(results) == 1, "result length: %d" % len(results)
    assert results[0][0] == 'foo'
    assert results[0][1] == 'is'
    assert results[0][2] == 'defined'

    # Test is not defined
    results = c.extract_defined_undefined("{{ foo is not defined }}")
    assert len(results) == 1, "result length: %d" % len(results)
    assert results[0][0] == 'foo'
    assert results[0][1] == 'is not'

# Generated at 2022-06-22 14:07:53.138570
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class MyConditional(Conditional):
        def __init__(self, when=None):
            self.when = when

    # Test list of conditions
    conditional = MyConditional(when=['{{ foo is defined }}', 'bar is defined'])
    templar = DummyTemplar()
    all_vars = dict(foo='foo', bar='bar')
    assert conditional.evaluate_conditional(templar, all_vars)
    conditional = MyConditional(when=['{{ foo is defined }}', 'bar is not defined'])
    assert not conditional.evaluate_conditional(templar, all_vars)

    # Test one single defined condition
    conditional = MyConditional(when=['{{ foo is defined }}'])
    assert conditional.evaluate_conditional(templar, all_vars)
    all

# Generated at 2022-06-22 14:08:04.533095
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:08:17.941700
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar

    class TestCond(Conditional):
        def __init__(self):
            self._ds = 'test_file.yml'
            self._loader = None
            self._name = 'test_name'
            self._when = []

    when = []

    when.append(['foo in bar'])
    when.append(['foo in bar', 'foo in foo'])
    when.append(['false', 'foo in foo'])
    when.append(['false', 'foo in foo'])
    when.append(['foo in bar', 'false', 'foo in foo'])
    when.append(['foo in bar', 'false', 'foo in foo', 'foo in baz', 'foo in quux'])
    when.append(['zoo not in bar'])

# Generated at 2022-06-22 14:08:26.758336
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # create a conditional object and call evaluate_conditional
    c = Conditional()
    # create a templar and variable manager with a dictionary of variables
    t = Templar(loader=DataLoader())
    vars_manager = VariableManager()
    vars_manager.set_host_variable('hostname', "testhost")
    vars_manager.set_host_variable('hostvars[inventory_hostname]', "hostvarvalue")
    vars_manager.extra_vars = {'extra_var': 'extra_value'}

    # 
    # test undefined variable
    #

# Generated at 2022-06-22 14:08:31.798975
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    # list of pairs: test data and expected result
    test_data = [
        ('', []),
        ('foo is defined', [('foo', 'is', 'defined')]),
        ('foo is not defined', [('foo', 'is not', 'defined')]),
        ('foo is undefined', [('foo', 'is', 'undefined')]),
        ('foo is not undefined', [('foo', 'is not', 'undefined')]),
    ]

    for i in range(len(test_data)):
        assert test_data[i][1] == conditional.extract_defined_undefined(test_data[i][0])


# Generated at 2022-06-22 14:08:39.179209
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

    assert set(cond.extract_defined_undefined('hostvars[host1] is defined and hostvars[host3] is defined')) == set([('hostvars[host1]', 'is', 'defined'), ('hostvars[host3]', 'is', 'defined')])
    assert set(cond.extract_defined_undefined('foo is defined or bar is undefined')) == set([('foo', 'is', 'defined'), ('bar', 'is', 'undefined')])

# Generated at 2022-06-22 14:08:52.623778
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined(None) == []
    assert c.extract_defined_undefined('') == []
    assert c.extract_defined_undefined('a') == []
    assert c.extract_defined_undefined('a and b') == []
    assert c.extract_defined_undefined('a is defined') == [('a', 'is', 'defined')]
    assert c.extract_defined_undefined('a is undefined') == [('a', 'is', 'undefined')]
    assert c.extract_defined_undefined('a not is defined') == [('a', 'not is', 'defined')]
    assert c.extract_defined_undefined('a not is undefined') == [('a', 'not is', 'undefined')]


# Generated at 2022-06-22 14:09:28.061155
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class MyConditional(Conditional):
        def __init__(self, when, **kwargs):
            self.when = when

    # Example: when: "'foo' in group_names"
    when = [ "'foo' in group_names" ]
    myconditional = MyConditional(when)
    myconditional.evaluate_conditional()

    # Example: when: "foo in group_names"
    when = [ "foo in group_names" ]
    myconditional = MyConditional(when)
    myconditional.evaluate_conditional()

    # Example: when: "foo in group_names or bar in hostvars[inventory_hostname]"
    when = [ "foo in group_names or bar in hostvars[inventory_hostname]" ]
    myconditional = MyConditional(when)
    myconditional

# Generated at 2022-06-22 14:09:36.727518
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook import PlaybookInclude

    fake_loader = DummyLoader()

    def check_conditional(conditional):
        # Dummy loader doesn't support any vars
        all_vars = dict()
        obj = PlaybookInclude(loader=fake_loader,
                              file_name='dummy_playbook_include',
                              conditional=conditional)
        return obj.evaluate_conditional(obj._loader.get_basedir(), all_vars)

    # Check OK without templating
    assert check_conditional(True) is True
    assert check_conditional(False) is False

    # Check OK with templating
    assert check_conditional("{{ true }}") is True
    assert check_conditional("{{ false }}") is False

    # Check that invalid conditionals raise

# Generated at 2022-06-22 14:09:47.489630
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestConditional(Conditional):
        _when = FieldAttribute(isa='list', default=[None])
    tc = TestConditional()

    assert True == tc.evaluate_conditional('test', {'test': 'success'})
    assert True == tc.evaluate_conditional({'test': 'success'}, {'test': 'success'})
    assert True == tc.evaluate_conditional('True', {'test': 'success'})
    assert True == tc.evaluate_conditional('True and True', {'test': 'success'})
    assert True == tc.evaluate_conditional('True and test', {'test': 'success'})
    assert True == tc.evaluate_conditional('True and test and True', {'test': 'success'})

# Generated at 2022-06-22 14:09:58.657855
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Setup
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    context = PlayContext()

    test_vars = dict(
        hostvars = dict(
            foo = dict(
                bar = 'baz'
            ),
        ),
    )

    # Stored class attributes
    all_vars = dict()
    conditional = 'hostvars["foo"].bar == "baz"'
    templar = Templar(loader=loader, variables=variable_manager, shared_loader_obj=loader,cache=variable_manager.cache)

    # Test hostvars

# Generated at 2022-06-22 14:10:10.299105
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:10:23.015987
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    display = Display()
    filename = 'somefile.yml'
    loader = DictDataLoader({filename: dict(hosts=[], tasks=[])})
    play = Play().load(loader=loader, file_name=filename, variable_manager=VariableManager(), loader_name='somefile.yml')
    task = Task()
    task._play = play

# Generated at 2022-06-22 14:10:35.559628
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = None
    play_context = PlayContext()
    templar = Templar(loader=loader, variables={'a':1}, shared_loader_obj=loader, context=play_context)
    c = Conditional()

    # Using is_template method, test if the given conditional is a template (string).
    # If so, display a warning
    conditional = "{{ a }}"
    assert c._check_conditional(conditional, templar, None)

    # test 'when: a'
    conditional = "a"
    assert c._check_conditional(conditional, templar, None)

    # test 'when: not a'
    conditional = "not a"

# Generated at 2022-06-22 14:10:41.023199
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestConditional(Conditional):
        def __init__(self, when=list()):
            self.when = when
    my_cond = TestConditional(["{{ 1 == 1 }}"])
    assert(my_cond.evaluate_conditional(None, None))



# Generated at 2022-06-22 14:10:50.229838
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.inventory.host import Host

    host = Host(name="foo")
    host.vars = dict(ansible_os_family="Debian")

    task = Conditional()
    task.when = ["ansible_os_family != \"Debian\""]

    templar = Templar(loader=None, variables=dict(hostvars=dict(foo=host.vars)))

    assert task.evaluate_conditional(templar, dict(hostvars=dict(foo=host.vars)))

# Generated at 2022-06-22 14:11:03.317760
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Unit test for method evaluate_conditional of class Conditional
    '''

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from jinja2.environment import Environment
