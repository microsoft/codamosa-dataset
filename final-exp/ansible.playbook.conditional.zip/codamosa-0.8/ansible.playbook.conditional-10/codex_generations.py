

# Generated at 2022-06-22 14:01:43.471550
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class MyConditional(Conditional):
        def __init__(self, loader=None, templar=None, all_vars=None):
            self._loader = loader
            self.templar = templar
            self.all_vars = all_vars
            self.when = []
    class MyTemplar(object):
        environment = None
        def is_template(self, s):
            return False
        def template(self, data, *args, **kwargs):
            return self.environment.from_string(data).render(self.variables)
        @property
        def variables(self):
            return self.available_variables
    class MyEnvironment(object):
        def __init__(self):
            self.globals = {}
        def from_string(self, s):
            return

# Generated at 2022-06-22 14:01:53.001345
# Unit test for constructor of class Conditional
def test_Conditional():
    variable_manager = VariableManager()
    loader = DataLoader()

    dbg = Conditional(loader=loader)

    # initialize the variable manager for the playbook
    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager, host_list='/dev/null'))

    # set the variable manager for the task and set some variables
    dbg.variable_manager = variable_manager
    variable_manager.set_nonpersistent_facts({"test": "foo"})

    # now check a conditional which should fail to parse for templating
    dbg.when = ["{{ test }} == foo"]
    assert dbg.evaluate_conditional(dbg.get_loader(), variable_manager.get_vars(play=None, host=None)) is True

# Generated at 2022-06-22 14:02:03.869840
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    C.ANSIBLE_INTERNAL_TASK_VARS = False
    cond = Conditional()
    assert cond.extract_defined_undefined("") == []
    assert cond.extract_defined_undefined("a") == []
    assert cond.extract_defined_undefined(" a") == []
    assert cond.extract_defined_undefined(" a ") == []
    assert cond.extract_defined_undefined("a is") == []

    assert cond.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert cond.extract_defined_undefined(" a is defined ") == [("a", "is", "defined")]

# Generated at 2022-06-22 14:02:16.073332
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook import Playbook
    from units.mock.loader import DictDataLoader

    def get_playbook(playbook_str, vault_password=None):

        if isinstance(playbook_str, text_type):
            playbook_str = to_bytes(playbook_str)

        try:
            loader = DictDataLoader({
                "test.yml": playbook_str
            })
            inventory = PlaybookInventory(loader=loader)
            pb = Playbook.load(loader.path_dwim("test.yml"), inventory, vault_password=vault_password)
        except Exception as e:
            print(to_text(e))
            return None
        return pb

    # test case 1: invalid syntax

# Generated at 2022-06-22 14:02:29.506391
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    pc = PlayContext()
    var_mgr = VariableManager()
    vars = {}
    loader = DataLoader()
    templar = Templar(loader=loader, variables=vars)
    class TestClass(Conditional):
        def __init__(self, templar=None, var_mgr=None):
            self._templar = templar
            self._variable_manager = var_mgr
            self._loader  = loader

    t = TestClass(templar=templar, var_mgr=var_mgr)



# Generated at 2022-06-22 14:02:42.259111
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-22 14:02:54.701964
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("hostvars['localhost']['ansible_facts']['distribution_major_version'] == '14.04'") == [('hostvars[\'localhost\'][\'ansible_facts\'][\'distribution_major_version\']', '==', '14.04')]
    assert conditional.extract_defined_undefined("lookup('file','/var/lib/docker/volumes/lxc-homedirs/_data/home/lxc-test/test.txt') == 'a'") == []

# Generated at 2022-06-22 14:03:06.259077
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()

    variable_manager.set_nonpersistent_facts(dict(foo="bar",
                                                  baz="bar",
                                                  dict={'a':1}))

    conditional = Conditional()
    templar = Templar(loader=None, variables=variable_manager)


# Generated at 2022-06-22 14:03:13.025891
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader

    v = Conditional(loader=DataLoader())

    assert v.evaluate_conditional(v, {'a': '1'}, 'a == 1') == True, "should be True"
    assert v.evaluate_conditional(v, {'a': '2'}, 'a == 1') == False, "should be False"
    assert v.evaluate_conditional(v, {'a': '1'}, 'a != 1') == False, "should be False"
    assert v.evaluate_conditional(v, {'a': '2'}, 'a != 1') == True, "should be True"
    assert v.evaluate_conditional(v, {'a': '1'}, 'a is defined') == True, "should be True"
    assert v.evaluate

# Generated at 2022-06-22 14:03:23.590296
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    my_conditional = Conditional()
    all_vars = {"dummy": "value"}
    # pylint: disable=protected-access
    assert my_conditional._check_conditional("dummy", my_conditional._loader.templar, all_vars) is True
    assert my_conditional._check_conditional("dummy|default('not_defined')", my_conditional._loader.templar, all_vars) is True
    assert my_conditional._check_conditional("undef_var", my_conditional._loader.templar, all_vars) is False
    assert my_conditional._check_conditional("undef_var|default('not_defined')", my_conditional._loader.templar, all_vars) is False

# Generated at 2022-06-22 14:03:44.569043
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    a = AnsibleModule(dict(a=dict(required=True)))
    # simple dict
    res = a._check_conditional('a|d({"b": 1}) == {"b": 1}', templar=a, all_vars=dict(a=dict(b=1)))
    assert res == True
    # simple list
    res = a._check_conditional('a|d([1, 2, 3]) == [1, 2, 3]', templar=a, all_vars=dict(a=[1, 2, 3]))
    assert res == True
    # simple string
    res = a._check_conditional('a|d("b") == "b"', templar=a, all_vars=dict(a="b"))
    assert res == True
    # complex dict
    res = a

# Generated at 2022-06-22 14:03:51.033007
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    C1 = Conditional()

    conditional = "a.b.c is defined and a.x is defined or a.y is not defined"
    extracted = C1.extract_defined_undefined(conditional)
    assert extracted == [('a.b.c', 'is', 'defined'), ('a.x', 'is', 'defined'), ('a.y', 'is not', 'defined')]


# Generated at 2022-06-22 14:04:02.076816
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert [] == cond.extract_defined_undefined("str")
    assert [] == cond.extract_defined_undefined("")
    assert [] == cond.extract_defined_undefined("not defined")
    assert [(u'hostvars["ansible_hostname"]', 'not', 'defined')] == cond.extract_defined_undefined("hostvars['ansible_hostname'] not defined")
    assert [(u'hostvars[\'ansible_hostname\']', 'not', 'defined')] == cond.extract_defined_undefined("hostvars[\"ansible_hostname\"] not defined")

# Generated at 2022-06-22 14:04:12.486265
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    h = Host(name="foo")
    hv = HostVars(
        host=h,
        variables=dict(
            a_var=20,
            another_var="defined"
        )
    )
    h.set_vars(hv)
    t = Task()
    t._role = Role()
    t._role._role_path = "/a/b/c"
    t._role._role_

# Generated at 2022-06-22 14:04:23.747097
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.plugins import pkg_finder

    lookup_finder = pkg_finder.LookupModuleFinder()

    templar = Templar(loader=None, variables={})
    # AnsibleModule uses the VariableManager
    variable_manager = VariableManager(loader=None, inventory=InventoryManager(loader=None, sources=''))
    # The PlayContext() is required to set a top level play_context
    pc = PlayContext()
    pc.variable_manager = variable_manager
    pc.lookup_plugin_loader = lookup_finder

    setattr(templar, '_vars', variable_manager)


# Generated at 2022-06-22 14:04:31.446073
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    test_result = Conditional().evaluate_conditional(None, {}, {'var': 'test'})
    assert False == test_result

    test_conditional = Conditional()
    test_conditional._validate_conditional('test', '')
    test_conditional._validate_conditional('test', None)
    test_conditional._validate_conditional('test', True)
    test_conditional._validate_conditional('test', 'var == "test"')



# Generated at 2022-06-22 14:04:42.908670
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    context = PlayContext()
    inventory = InventoryManager(loader=loader, sources=None)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    my_task = Conditional(loader=loader)

    my_task.when = ["{{ test }}"]
    assert my_task.evaluate_conditional(templar, {"test": "moo == 'foo'"}) is False

# Generated at 2022-06-22 14:04:54.055786
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    import ansible.constants as C
    import sys
    import os

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='{{{ jinja2_var1 }}}')))
            ]
        )


# Generated at 2022-06-22 14:05:05.815288
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # No value for var1. Hence var1 undefined
    all_vars = dict(var1=None, var2=None)

    # Empty conditional
    conditional = None
    res = Conditional().evaluate_conditional(Templar(all_vars), all_vars)
    assert res is True

    # True conditional
    conditional = True
    res = Conditional().evaluate_conditional(Templar(all_vars), all_vars)
    assert res is True

    # False conditional
    conditional = False
    res = Conditional().evaluate_conditional(Templar(all_vars), all_vars)
    assert res is False

    # Defined conditional
    conditional = 'var1 is defined'
    res = Conditional().evaluate_conditional(Templar(all_vars), all_vars)

# Generated at 2022-06-22 14:05:11.874124
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    c = Conditional()
    c._ds = object()

    # Test invalid conditional
    try:
        c.evaluate_conditional("foobarbaz", {}, {}, {})
        assert False, "Failed to throw AnsibleError"
    except AnsibleError:
        pass

    # Test valid conditionals
    assert c.evaluate_conditional("a.b.c == 3", {}, {}, {}) == False
    assert c.evaluate_conditional("a.b.c == '3'", {}, {}, {}) == True

# Generated at 2022-06-22 14:05:39.282850
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import jinja2
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    all_vars = dict(first=True, second="value", third="value2")

    def get_loader(*args, **kwargs):
        return AnsibleLoader(None, list(), *args, **kwargs)

    t = Templar(get_loader=get_loader, variables=all_vars)
    t.set_available_variables(all_vars)

    # check for None case
    try:
        assert t.template(None) == None
    except jinja2.exceptions.TemplateAssertionError as e:
        assert False, "unable to evaluate conditional: %s" % str(e)

    # check for empty string

# Generated at 2022-06-22 14:05:50.430892
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # test default behavior (skip task)
    task = Conditional()
    assert task.evaluate_conditional() is False

    # test no when clauses
    task = Conditional()
    task._when = None
    assert task.evaluate_conditional() is True

    # test when true
    task = Conditional()
    task._when = [True]
    assert task.evaluate_conditional() is True

    # test when false
    task = Conditional()
    task._when = [False]
    assert task.evaluate_conditional() is False

    # test when "0"
    task = Conditional()
    task._when = ["0"]
    assert task.evaluate_conditional() is False

    # test when "0"
    task = Conditional()
    task._when = ["1"]
    assert task.evaluate_conditional()

# Generated at 2022-06-22 14:06:00.761864
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():


    class DummyClass(Conditional):
        def __init__(self):
            self._ds = "test"
            self._name = "test"

    class DummyTemplar(object):
        def template(self, conditional, disable_lookups=False):
            if conditional == "valid_conditional":
                return "True"

            if conditional == "variable_not_defined":
                raise AnsibleUndefinedVariable("variable_not_defined")

            if conditional == "valid_conditional_with_undefined":
                return "variable_not_defined is defined"

            if conditional == "valid_conditional_with_defined":
                return "variable_not_defined is not defined"

        def is_template(self, conditional):
            if conditional == "valid_conditional":
                return True


# Generated at 2022-06-22 14:06:11.189931
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader

    cond = Conditional()
    cond.loader = DataLoader()

    value = cond.evaluate_conditional(cond.loader.load_from_file('test/unit/playbooks/evaluate_conditional.yml'), dict(foo="bar"))
    assert value is True
    value = cond.evaluate_conditional(cond.loader.load_from_file('test/unit/playbooks/evaluate_conditional.yml'), dict())
    assert value is False

    value = cond.evaluate_conditional(cond.loader.load_from_file('test/unit/playbooks/evaluate_conditional_list.yml'), dict(test_list=['foo', 'bar']))
    assert value is True
    value = cond.evaluate

# Generated at 2022-06-22 14:06:22.979928
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.attribute import FieldAttribute
    from ansible.template import Templar

    class MockLoader(object):
        pass

    class Base(object):
        _field_attributes = dict(
            when=FieldAttribute(isa='list', default=list, extend=True, prepend=True)
        )

    class Cond(Conditional, Base):
        pass

    class MockVarsModule(object):
        def __call__(self, *args, **kwargs):
            return dict(foo=dict(bar=dict(baz=dict(qux=True))))

    # create new conditional instance
    c = Cond(loader=MockLoader())
    c._loader.module_loader.module_vars = MockVarsModule()

    t = Templar(loader=c._loader)

    # define set of testcases
   

# Generated at 2022-06-22 14:06:33.622052
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_object = Conditional()

    conditional = '1 < 2'
    assert conditional_object.evaluate_conditional(None, None, conditional) == True

    conditional = '1 > 2'
    assert conditional_object.evaluate_conditional(None, None, conditional) == False

    conditional = '"foobar" in groups'
    assert conditional_object.evaluate_conditional(None, None, conditional) == False

    conditional = '"foobar" not in groups'
    assert conditional_object.evaluate_conditional(None, None, conditional) == True

    conditional = 'variable is defined'
    assert conditional_object.evaluate_conditional(None, None, conditional) == False

    conditional = 'variable is undefined'
    assert conditional_object.evaluate_conditional(None, None, conditional) == True


# Generated at 2022-06-22 14:06:45.651568
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook import Play

    play_context = dict(
        foo='bar',
        list=['a', 'b', 'c'],
        dict=dict(
            a='1',
            b='2',
            c='3'
        ),
        list_of_dicts=[
            dict(
                a=1,
                b=2,
                c=3
            ),
            dict(
                d=4,
                e=5,
                f=6
            )
        ]
    )

    # Make sure that a single conditional statement is evaluated correctly
    # These statements should evaluate to True

# Generated at 2022-06-22 14:06:54.090672
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

    # Test normal case
    data = cond.extract_defined_undefined("hostvars['foo_host'] is defined")
    assert data == [("hostvars['foo_host']", "is", "defined")]

    # Test multiple defined/undefined
    data = cond.extract_defined_undefined("hostvars['foo_host'] is defined and bar is undefined")
    assert data == [("hostvars['foo_host']", "is", "defined"),
                    ("bar", "is", "undefined")]

    # Test multiple defined/undefined with 'not'
    data = cond.extract_defined_undefined("hostvars['foo_host'] is defined and bar is not undefined")

# Generated at 2022-06-22 14:07:07.386711
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.base import Base
    base = Base()
    conditional = Conditional()
    
    test_arguments = [
        'x is undefined',
        'x is not defined',
        'x is undefined and y is undefined',
        'hostvars["hostname"] is defined',
        'hostvars[\'hostname\'] is not defined',
        'hostvars[\'hostname\'] is defined and x is undefined',
        'hostvars[\'hostname\'] is defined and y is not defined',
        'hostvars[inventory_hostname]  is defined and hostvars[\'hostname\'] is not defined and x is undefined',
    ]
    

# Generated at 2022-06-22 14:07:17.274482
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    # make sure we get an error when missing the 'loader' parameter
    try:
        other_conditional = Conditional()
    except:
        pass
    else:
        raise Exception("Failed to raise an exception when missing 'loader' parameter")
    # make sure we get an error when passing None as 'loader' parameter
    try:
        other_conditional = Conditional(loader=None)
    except:
        pass
    else:
        raise Exception("Failed to raise an exception when passing None as 'loader' parameter")
    # make sure we get an error when passing an empty string as 'loader' parameter
    try:
        other_conditional = Conditional(loader='')
    except:
        pass

# Generated at 2022-06-22 14:08:01.363319
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    hostvars = dict(
        foo='bar'
    )
    all_vars = dict(
        hostvars=hostvars,
        play_hosts=['localhost'],
    )

    loader = DummyLoader()

    conditional = Conditional(loader)
    templar = Templar(loader=loader, variables=all_vars)


# Generated at 2022-06-22 14:08:02.841255
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # TODO: there is not a unit test for this method
    assert False

# Generated at 2022-06-22 14:08:09.630714
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Initialize Conditional class and add a when variable
    cond = Conditional()
    cond.when = ['myvar == "myvalue"']

    # Initialize templar
    templar = Conditional()

    # Initialize all_vars
    all_vars = dict()

    # Call the method
    result = cond.evaluate_conditional(templar, all_vars)

    # Check the result
    assert not result

# Generated at 2022-06-22 14:08:22.191818
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    class DummyTask:
        when = []
        env = dict()

    import ansible.callbacks
    display = ansible.callbacks.Display()

# Generated at 2022-06-22 14:08:35.271572
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # Create Ansible template

    ansible_template = '''
    ---
    hosts: all
    tasks:
      - name: conditional test
        debug:
          msg: "{{ test }}"
        when: test
    '''

    from ansible.playbook import Playbook

    yaml_data = dict()
    variable_manager = VariableManager()
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)
    playbook = Playbook().load(ansible_template, loader=loader, variable_manager=variable_manager)
    play = playbook.get_plays()[0]
    tasks = play.compile()
    task = tasks[0]

    # Testing
    variable_manager.set_non

# Generated at 2022-06-22 14:08:47.249430
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from units.mock.loader import DictDataLoader
    from units.compat.mock import patch, MagicMock

    mock_ds = MagicMock()
    mock_ds.module_name = 'command'

    conditional = Conditional(DictDataLoader({}))

    with patch.dict(C.DEFAULT_LOAD_CALLBACK_PLUGINS, {'vault': 'vault_callback'}):
        # success
        assert conditional.evaluate_conditional(MagicMock(), {})

        # failure
        mock_ds.get_failed_conditions = lambda: [('x==1', 'skip', 'not 1')]
        conditional.ds = mock_ds
        assert not conditional.evaluate_conditional(MagicMock(), {})

        # skip

# Generated at 2022-06-22 14:08:58.315334
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # unit test class
    class MyTestClass(object):
        pass

    # setup some test variables
    test_attr = 'test_attr'
    test_attr_value = True
    test_attr_true = 'test_attr_true'
    test_attr_false = 'test_attr_false'
    test_var_key = 'test_var_key'
    test_var_value = 'test_var_value'
    all_vars = {test_attr: test_attr_value}
    all_vars[test_var_key] = test_var_value
    test_when_true = '%s and %s' % (test_attr_true, test_var_value)
    test_when_false = '%s and %s' % (test_attr_true, test_attr_false)

# Generated at 2022-06-22 14:09:10.342843
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.play_context import PlayContext

    all_vars = {}
    templar = DummyTemplar()

    # no when
    conditional = Conditional(loader=DummyLoader())
    assert conditional.evaluate_conditional(templar, all_vars)

    # one string
    conditional = Conditional(loader=DummyLoader())
    conditional.when = "OK"
    assert conditional.evaluate_conditional(templar, all_vars)

    # list of strings
    conditional = Conditional(loader=DummyLoader())
    conditional.when = ["OK", "OK"]
    assert conditional.evaluate_conditional(templar, all_vars)

    # list of strings with a failure
    conditional = Conditional(loader=DummyLoader())

# Generated at 2022-06-22 14:09:23.629132
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    c = Conditional()
    assert not c.extract_defined_undefined("")
    assert not c.extract_defined_undefined("defined(foo)")
    assert not c.extract_defined_undefined("undefined(bar)")
    assert not c.extract_defined_undefined("True")
    assert not c.extract_defined_undefined("False")
    assert not c.extract_defined_undefined(True)
    assert not c.extract_defined_undefined(False)
    assert not c.extract_defined_undefined(1)
    assert not c.extract_defined_undefined(0)
    assert not c.extract_defined_undefined(AnsibleUnsafeText("foo"))
   

# Generated at 2022-06-22 14:09:31.772487
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars import VariableManager

    vault_pass = C.DEFAULT_VAULT_PASSWORD_FILE
    vault_password_file = None
    if vault_pass:
        vault_password_file = os.path.expanduser(vault_pass)

    my_loader = DictDataLoader({})
    my_vars = VariableManager(loader=my_loader)
    my_vault = VaultLib(vault_password_file)
    my_templar = Templar(loader=my_loader, variables=my_vars, vault_secrets=my_vault)

    # old: assert evaluate_conditional(my_templar, "foo == 'bar'") == False
    assert Conditional

# Generated at 2022-06-22 14:10:48.364096
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar

    hvars = HostVars(loader=None, variables=dict())
    vars_manager = VariableManager(loader=None)
    vars_manager._hostvars_cache.update(hvars.get_vars(host=None, include_hostvars=True))

    display.verbosity = 0
    templar = Templar(loader=None, variables=vars_manager)

    # test: #1
    assert Conditional().evaluate_conditional(templar, vars_manager.get_vars(play=dict(name='test')))

    # test: #2 -- evaluate_conditional() should check for undefined variables in with_ loops

# Generated at 2022-06-22 14:11:02.356484
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    def get_loader():
        return DataLoader()

    def _get_var_manager(loader=None):
        if loader is None:
            loader = get_loader()
        return VariableManager(loader=loader)

    # get a loader and variable manager for testing
    loader = get_loader()
    variable_manager = _get_var_manager(loader)

    class TestConditional(Conditional):
        def __init__(self):
            super(TestConditional, self).__init__(loader)

    # test when is a list
    t1 = TestConditional()
    t1._when = [None]

# Generated at 2022-06-22 14:11:15.746333
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    class BaseTask(Conditional):
        def __init__(self):
            self._ds = {}

    class MockTask(BaseTask):
        def __init__(self):
            super(MockTask, self).__init__()

        def run(self, tmp=None, task_vars=None):
            return self.evaluate_conditional(tmp, task_vars)

    class FakeVarsModule:
        def __init__(self, vars):
            self.vars = vars

        def __getitem__(self, key):
            return self.vars[key]

    class FakeModuleUtils:
        def __init__(self, tmp):
            self.tmp = tmp

        def _load_params(self):
            return {}

        @property
        def params(self):
            return self._load

# Generated at 2022-06-22 14:11:26.880084
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    v = Conditional()
    print("------test 1-------")
    assert v.extract_defined_undefined("") == []
    print("------test 2-------")
    assert v.extract_defined_undefined("defined_vars['foo']") == []
    print("------test 3-------")
    assert v.extract_defined_undefined("foo not is defined") == [('foo', 'not is', 'defined')]
    print("------test 4-------")
    assert v.extract_defined_undefined("bar is defined") == [('bar', 'is', 'defined')]
    print("------test 5-------")
    assert v.extract_defined_undefined("foo is defined  and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]