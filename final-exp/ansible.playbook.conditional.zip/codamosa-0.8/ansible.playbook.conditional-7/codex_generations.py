

# Generated at 2022-06-22 14:01:40.276712
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    vars = VariableManager()

# Generated at 2022-06-22 14:01:52.300934
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    assert conditional.extract_defined_undefined('foo is defined and baz is undefined') == [('foo', 'is', 'defined'), ('baz', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('foo is defined and baz is not undefined') == [('foo', 'is', 'defined'), ('baz', 'is', 'not', 'undefined')]
    assert conditional.extract_defined_undefined('foo is not defined and baz is not undefined') == [('foo', 'is', 'not', 'defined'), ('baz', 'is', 'not', 'undefined')]
    assert conditional.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]

# Generated at 2022-06-22 14:02:03.596727
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import sys
    import os
    import io

    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'lib', 'ansible'))
    from ansible.template import Templar


# Generated at 2022-06-22 14:02:15.992877
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

# Generated at 2022-06-22 14:02:29.409736
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext

    # Create a play context for this test
    play_context = PlayContext()

# Generated at 2022-06-22 14:02:42.259763
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    assert Conditional().evaluate_conditional(None, None) == True

    obj = Conditional()
    obj._ds = 1
    try:
        obj.evaluate_conditional(None, None)
    except AnsibleError:
        assert True
    else:
        assert False

    obj = Conditional()
    obj._ds = 1
    obj.when = 1
    assert obj.evaluate_conditional(None, None) == True

    obj = Conditional()
    obj._ds = 1
    obj.when = []
    assert obj.evaluate_conditional(None, None) == True

    obj = Conditional()
    obj._ds = 1
    obj.when = False
    assert obj.evaluate_conditional(None, None) == False

    obj = Conditional()
    obj._ds = 1

# Generated at 2022-06-22 14:02:54.748704
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.base import Base

    my_base = Base()
    my_base.name = 'this is for jinja2'  #conditional
    my_base._loader = DummyLoader()
    my_base.vars = {'this_is_for_jinja2':True}

    assert(my_base.evaluate_conditional(my_base._loader.get('vars'),my_base.vars))

    my_base.name = 'this is not for jinja2'  #conditional
    assert(not my_base.evaluate_conditional(my_base._loader.get('vars'),my_base.vars))

    my_base.name = True  #conditional

# Generated at 2022-06-22 14:03:04.373243
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    p = Base()
    c = Conditional()

    p._variable_manager = VariableManager()
    p._variable_manager.set_nonpersistent_facts(dict(a="hello"))

    c._loader = p._loader

    if not c.evaluate_conditional(Templar(play_context=PlayContext(p._variable_manager)), p._variable_manager.get_vars(loader=p._loader, play=p)):
        assert False
    if c.evaluate_conditional(Templar(play_context=PlayContext(p._variable_manager)), p._variable_manager.get_vars(loader=p._loader, play=p)):
        assert False



# Generated at 2022-06-22 14:03:12.433149
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Here we test the method evaluate_conditional of the class Conditional.
    # This method is used to evaluate conditional statements.
    #
    # The method verify the syntax of the conditional statement and
    # evaluate it. Several tests are done to verify its robustness.

    # Import the class Conditional
    from ansible.playbook.conditional import Conditional
    # Create instance of Conditional
    conditional_test = Conditional()

    # First we verify the evaluation of a simple expression
    conditional = "ansible_facts['distribution'] == 'RedHat'"
    all_vars = {
        'ansible_facts': {
            'distribution': 'RedHat'
        }
    }
    res = conditional_test.evaluate_conditional(conditional, all_vars)
    assert res == True

    # We verify the evaluation method with

# Generated at 2022-06-22 14:03:23.258862
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

    # empty string
    assert cond.extract_defined_undefined('') == []

    # no defined/undefined
    assert cond.extract_defined_undefined('''
        some text
        not defined
        (undefined)
        defined: undefined
    ''') == []

    # single defined/undefined
    assert cond.extract_defined_undefined('hostvars[foo] is not defined') == [('hostvars[foo]', 'is not', 'defined')]
    assert cond.extract_defined_undefined('hostvars["foo"] is not defined') == [('hostvars["foo"]', 'is not', 'defined')]

# Generated at 2022-06-22 14:03:49.305915
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestConditional:
        _loader = None
        _ds = None
        when = None

        def __init__(self):
            self.when = []

        def _check_conditional(self, conditional, templar, all_vars):
            return conditional
    t = TestConditional()

    t.when = [True]
    assert t.evaluate_conditional(None, None)
    t.when = [False]
    assert not t.evaluate_conditional(None, None)
    t.when = [True, True]
    assert t.evaluate_conditional(None, None)
    t.when = [True, False]
    assert not t.evaluate_conditional(None, None)
    t.when = [False, True]
    assert not t.evaluate_conditional(None, None)
   

# Generated at 2022-06-22 14:03:59.100710
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

# Generated at 2022-06-22 14:04:07.753827
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    #setup
    class FakeConditional():
        def __init__(self, when):
            self.when = when

    conditional = FakeConditional([
            '{% if "' + C.DEFAULT_HASH_BEHAVIOUR + '" in (ansible_hash_behaviour|lower) %}True{% else %}False{% endif %}', # True
            '{{ ansible_os_family|lower }} == "unix" or ansible_distribution|lower in ["ubuntu"]', # True
            # undefined
            '{{ansible_foo}} == "bar"', # False
            # not defined
            '{{ansible_bar}} is defined', # False
            # defined
            'ansible_baz is not defined' # True
    ])

    from ansible.template import Templar

# Generated at 2022-06-22 14:04:12.874167
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    res = c.extract_defined_undefined('my_var is defined and my_var2 is defined and hostvars[\'foo\'] is not defined')
    assert (res == [('my_var', 'is', 'defined'), ('my_var2', 'is', 'defined'), ('hostvars[\'foo\']', 'is not', 'defined')])


# Generated at 2022-06-22 14:04:17.278322
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional('/bin/foobar')
    c._validate_when(c, '_when', 'foobar')
    assert c._when == ['foobar']
    c._validate_when(c, '_when', 121)
    assert c._when == [121]
    c._validate_when(c, '_when', None)
    assert c._when == [None]


# Generated at 2022-06-22 14:04:25.701492
# Unit test for constructor of class Conditional
def test_Conditional():
    (cond, result) = (Conditional(), True)
    # when is an empty list, so the only thing to test is whether the conditional,
    # which is a boolean value, is True
    assert(cond.evaluate_conditional(cond, {}))
    # when is a list of a single boolean, so the only thing to test is whether the conditional,
    # which is a boolean value, is True
    cond.when = [True]
    assert(cond.evaluate_conditional(cond, {}))
    # when is a list of a single boolean that is False, so the only thing to test is whether the conditional,
    # which is a boolean value, is False
    cond.when = [False]
    assert(not cond.evaluate_conditional(cond, {}))
    # when is a list of a single string, so the only thing to test is whether

# Generated at 2022-06-22 14:04:38.142570
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.base import Base
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Test 1
    # Test with a valid condition for simple 'defined' user variable name
    conditional = "user1 is defined"
    cond_obj = Conditional(DataLoader())
    def_undef = cond_obj.extract_defined_undefined(conditional)
    assert(len(def_undef)==1)
    assert(def_undef[0][0] == 'user1')
    assert(def_undef[0][1] == 'is')
    assert(def_undef[0][2] == 'defined')

    # Test 2
    # Test with a valid condition for simple 'undefined' user variable name

# Generated at 2022-06-22 14:04:46.707086
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    m = Conditional()

# Generated at 2022-06-22 14:04:56.226095
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.hostvars import HostVars
    rd = RoleDefinition()
    rd.when = ['hostvars["inventory_hostname"] == 1', 'hostvars["inventory_hostname"] is not defined', 'hostvars["inventory_hostname"] is undefined', 'hostvars["inventory_hostname"] is not defined or hostvars["inventory_hostname"] is undefined']
    rd.extract_defined_undefined('hostvars["inventory_hostname"] == 1')
    rd.extract_defined_undefined(rd.when)
    assert rd.extract_defined_undefined('hostvars["inventory_hostname"] == 1') == [('hostvars["inventory_hostname"]', '==', '1')]

# Generated at 2022-06-22 14:05:08.044258
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-22 14:05:43.568378
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    vars_mgr = VariableManager()
    loader = DataLoader()

    res = evaluate_conditional(vars_mgr, '1', loader)
    assert res is True

    res = evaluate_conditional(vars_mgr, '1 == 1', loader)
    assert res is True

    res = evaluate_conditional(vars_mgr, '1 == 2', loader)
    assert res is False

    res = evaluate_conditional(vars_mgr, 'something_not_defined', loader)
    assert res is False

    res = evaluate_conditional(vars_mgr, 'something_not_defined is undefined', loader)
    assert res is True


# Generated at 2022-06-22 14:05:56.071394
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(a=1, b=2, c=4, d=8)
    templar = Templar(loader=loader, variables=variable_manager)

    c = Conditional(loader=loader)

# Generated at 2022-06-22 14:06:07.717500
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Setup
    conditional = Conditional()

    # Test 1
    test1 = conditional.extract_defined_undefined("a is defined or  b is undefined")
    assert test1 == [('a', 'is', 'defined'), ('b', 'is', 'undefined')]

    # Test 2
    test2 = conditional.extract_defined_undefined("foo is not undefined and bar is not defined")
    assert test2 == [('foo', 'is not', 'undefined'), ('bar', 'is not', 'defined')]

    # Test 3
    test3 = conditional.extract_defined_undefined("hostvars['foo'] is defined")
    assert test3 == [('hostvars[\'foo\']', 'is', 'defined')]

    # Test 4

# Generated at 2022-06-22 14:06:17.725766
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    #  result is a list of tuples:
    #  [(lookup_variable, negation_logic, defined_or_undefined),...]
    result = cond.extract_defined_undefined(
        'some_condition and (hostvars["foo"] is defined) or '
        '(hostvars["foo"] is not undefined) and other_condition'
    )
    assert(result == [('hostvars["foo"]', 'is', 'defined'), ('hostvars["foo"]', 'is not', 'undefined')])


# Generated at 2022-06-22 14:06:30.491784
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-22 14:06:41.905916
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("hostvars[inventory_hostname] is defined and hostvars[inventory_hostname].a_fact == 'A'") == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert conditional.extract_defined_undefined("hostvars['inventory_hostname'] is defined and hostvars[inventory_hostname].a_fact == 'A'") == [("hostvars['inventory_hostname']", 'is', 'defined')]
    assert conditional.extract_defined_undefined("hostvars[inventory_hostname] is defined and hostvars['inventory_hostname'].a_fact == 'A'") == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert conditional.ext

# Generated at 2022-06-22 14:06:52.147234
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.module_utils.six import PY3

    if PY3:
        return

    from ansible.playbook.play_context import PlayContext
    from ansible.templating.jinja2.environment import StrictUndefined
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.vault import VaultLib

    play_context = PlayContext()
    play_context.vars = {}

    class HostVarsTemplate(Conditional):
        pass

    host_vars_template = HostVarsTemplate()

    # positive tests

# Generated at 2022-06-22 14:07:05.882707
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    import ansible.playbook.task

    test_conditional = '''
        ((foo not is defined and foo == 1) or
         (bar is defined and bar == 1) or
         (baz is undefined and baz == 1) or
         (qux is not undefined and qux == 1)) and
         (hostvars["example.com"] == 1)
         '''

    test_conditional_ast_list = [
        ('foo', 'not is', 'defined'),
        ('bar', 'is', 'defined'),
        ('baz', 'is', 'undefined'),
        ('qux', 'is not', 'undefined'),
        ('hostvars["example.com"]', '==', '1')
    ]

    task = ansible.playbook.task.Task()
    assert task.extract_defined_undefined

# Generated at 2022-06-22 14:07:16.212810
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    variable_manager = VariableManager(loader=None)

    templar = Templar(
        loader=None,
        variables=variable_manager,
        shared_loader_obj=None
    )

    # Validate basic conditional
    my_conditional = 'hostvars["foo"] is defined'
    conditional = Conditional()
    conditional.when = [ my_conditional ]
    scope_vars = dict(hostvars=dict(foo="bar"))
    result = conditional.evaluate_conditional(templar, scope_vars)
    assert result == True

    # Validate basic conditional

# Generated at 2022-06-22 14:07:25.678067
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    ansible_vars = dict(
        a='abc',
        b='ansible',
        c={'a': 'abc'},
        d='abd',
        e='123',
        f='123',
        g='',
        h='xyz',
        i='xyz',
        j='true',
        k='false',
        l=[],
        m='',
        n=False,
        o=True,
        p=None,
        q='None',
        r='',
        s='',
        t='abcdefg',
        u='abcdefg',
        v='ansible_facts',
        w='ansible_foo'
    )

    test_cases = set()
    test_cases.add(('a == "abc"', True))


# Generated at 2022-06-22 14:08:04.638295
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.executor.task_result import TaskResult
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.task import Task

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=[])
    templar = Templar(loader=loader, variables=inventory.get_vars(host=None, include_hostvars=True))

    def get_host(name):
        host = inventory.get_host(name)
        if host is None:
            host = Host(name)
            inventory

# Generated at 2022-06-22 14:08:18.101488
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class Test(Conditional):
        def __init__(self):
            self._loader = DictDataLoader({})

    # testing the when field with boolean value
    assert Test(dict(when=True)).evaluate_conditional(DictTemplate(), dict())
    assert not Test(dict(when=False)).evaluate_conditional(DictTemplate(), dict())

    # testing logic without dunder variables
    assert Test(dict(when="a == True")).evaluate_conditional(DictTemplate(), dict(a=True))
    assert not Test(dict(when="a == True")).evaluate_conditional(DictTemplate(), dict(a=False))
    assert Test(dict(when="a == False")).evaluate_conditional(DictTemplate(), dict(a=False))
    assert not Test(dict(when="a == False")).evaluate_conditional

# Generated at 2022-06-22 14:08:20.897216
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    c = Conditional()
    c.when = ['foo', 'bar']
    c.evaluate_conditional(None, dict(foo=True, bar=False)) == False

# Generated at 2022-06-22 14:08:34.699344
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    def test(conditional, expected):
        '''
        Helper method to run a test case
        '''
        # mock the objects we need to test
        c = Conditional()
        t = templar.Templar(loader=None)
        t.available_variables = {}
        # run the test
        result = c._check_conditional(conditional, t, {})
        assert result == expected
    # And finally the actual test cases
    test(True, True)
    test(False, False)
    test('True', True)
    test('yes', False)
    test('0', False)
    test('', False)
    test('a == b', False)
    test('1 == 1', True)
    test('1 == "1"', True)

# Generated at 2022-06-22 14:08:40.203877
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestConditional(Conditional):
        def __init__(self):
            self.when = list()
            super(TestConditional, self).__init__()

    test_conditional = TestConditional()

    class TestTemplar():
        @staticmethod
        def is_template(value):
            return False

        @staticmethod
        def template(value, disable_lookups=False):
            return False

    class TestVars():
        pass

    # Test with no when
    test_conditional.when = None
    assert test_conditional.evaluate_conditional(TestTemplar, TestVars)

    # Test with empty when
    test_conditional.when = []
    assert test_conditional.evaluate_conditional(TestTemplar, TestVars)

    # Test with when is None
    test

# Generated at 2022-06-22 14:08:53.801114
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.extra_vars = {'value1':True, 'value2':False}
    variable_manager.set_nonpersistent_facts(variable_manager.extra_vars)
    variable_manager.set_fact_cache(variable_manager.extra_vars)

# Generated at 2022-06-22 14:09:06.740741
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class Test_Conditional(Conditional):
        def __init__(self):
            class Test_Display(object):
                def debug(self, s): pass
            class Test_Templar(object):
                def __init__(self):
                    self.templar = {'environment': Test_Environment()}
                def is_template(self, str):
                    return False
                def template(self, str):
                    return str
            class Test_Environment(object):
                def __init__(self):
                    self.loader = None
                def parse(self, str, *args):
                    return ast.parse(str, mode='eval')
                def generate(self, node):
                    return generate(node, self.environment, None, None)
            self.display = Test_Display()
            self.templar = Test_Templ

# Generated at 2022-06-22 14:09:19.809089
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # test when no conditional
    p = Conditional()
    templar = Templar(loader=None, variables=VariableManager())
    result = p.evaluate_conditional(templar, dict())
    assert result is True

    # test with null/empty conditional
    p = Conditional()
    p._when = ['']
    templar = Templar(loader=None, variables=VariableManager())
    result = p.evaluate_conditional(templar, dict())
    assert result is True

    # test with conditional that is false
    p = Conditional()
    p._when = ['myvar']
    templar = Templar(loader=None, variables=VariableManager(host_vars=dict(myvar=False)))

# Generated at 2022-06-22 14:09:29.502194
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    cond = '1 == 1'
    ds = None
    all_vars = {
        'hostvars': {
            # hostvars['thisone'] and hostvars['thatone'] are defined
            'thisone': {'a':1},
            'thatone': [1,2,3],
            # hostvars['anotherone'] is undefined
            'anotherone': None,
            },
        'somelist': [1,2,3],
        'somestring': 'this is a string',
        'somemap': {'a':1},
        }
    # Default constructor
    cond1 = Conditional()
    # Constructor with loader
    cond2 = Conditional(loader=None)
    # Check the result of isinstance

# Generated at 2022-06-22 14:09:37.327705
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class TestConditional(Conditional):
        def __init__(self):
            super(TestConditional, self).__init__()

    c = TestConditional()

    cond1 = "foo is defined or bar is not defined"
    assert c.extract_defined_undefined(cond1) == [
        ('foo', 'is', 'defined'),
        ('bar', 'is', 'not'),
        ('defined', '', ''),
    ]
    cond2 = "baz is undefined or qux is not undefined"
    assert c.extract_defined_undefined(cond2) == [
        ('baz', 'is', 'undefined'),
        ('qux', 'is', 'not'),
        ('undefined', '', ''),
    ]

# Generated at 2022-06-22 14:10:44.953331
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('') == []
    assert c.extract_defined_undefined('unsafe is defined') == [('unsafe', 'is', 'defined')]
    assert c.extract_defined_undefined('unsafe is defined and safe is undefined') == [('unsafe', 'is', 'defined'), ('safe', 'is', 'undefined')]
    assert c.extract_defined_undefined('unsafe is defined and safe is not undefined') == [('unsafe', 'is', 'defined'), ('safe', 'is', 'not', 'undefined')]

# Generated at 2022-06-22 14:10:58.794292
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    display.verbosity = 3

    # test unset variables
    task1 = Conditional()
    task1.when = [
        '{{ this_var }} is defined',
        '{{ this_var }} == "hello"',
        '{{ this_var }} == "goodbye"',
    ]
    templar = DummyVarsTemplate()
    assert not task1.evaluate_conditional(templar, {})

    # test set variables
    task2 = Conditional()
    task2.when = [
        '{{ this_var }} is defined',
        '{{ this_var }} == "goodbye"',
    ]
    templar = DummyVarsTemplate()
    assert task2.evaluate_conditional(templar, {'this_var': 'goodbye'})

    # test set variables
    task3

# Generated at 2022-06-22 14:11:07.924886
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    res = c.extract_defined_undefined("'foo' in groups or foo is defined or foo.bar is defined")
    assert res == [('foo', 'is', 'defined'), ('foo.bar', 'is', 'defined')], res

    res = c.extract_defined_undefined("foo is not defined")
    assert res == [('foo', 'is not', 'defined')], res

    res = c.extract_defined_undefined("1 + 1 == 2")
    assert res == [], res

    res = c.extract_defined_undefined("1 + 1 == 2 and foo is not defined or bar.baz is defined")
    assert res == [('foo', 'is not', 'defined'), ('bar.baz', 'is', 'defined')], res

    res = c.extract

# Generated at 2022-06-22 14:11:19.541034
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    class FakeConditional:
        def __init__(self):
            self.when = []
            self.when.append("my_var is undefined")
            self.when.append("my_var is defined and another_var is not undefined")
            self.when.append("my_var is defined")
            self.when.append("my_var.key is undefined")


        def extract_defined_undefined(self, conditional):
            return Conditional.extract_defined_undefined(self, conditional)

    c = FakeConditional()
    r1 = c.extract_defined_undefined(c.when[0])
    assert (len(r1) == 1)
    assert (r1[0][0] == "my_var")
    assert (r1[0][1] == "is")