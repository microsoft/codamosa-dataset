

# Generated at 2022-06-22 14:01:37.607881
# Unit test for constructor of class Conditional
def test_Conditional():
    assert issubclass(Conditional, object)
    assert Conditional
    assert Conditional._when



# Generated at 2022-06-22 14:01:44.755042
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    display = Display()
    display.verbosity = 3
    t = Templar(None, variable_manager=VariableManager(), loader=DataLoader())
    cond = Conditional()
    cond.when = ['hostvars["foo"] == "bar"']
    t.set_available_variables({"hostvars": {"foo": "bar"}})
    assert cond.evaluate_conditional(t, {"hostvars": {"foo": "bar"}})
    cond.when = ['hostvars["foo"] != "bar"']

# Generated at 2022-06-22 14:01:53.094553
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.conditional import Conditional

    play_name = Play().get_name()

    # Test 1: Any of the when conditions are false
    task = Task()
    setattr(task, 'when', ['1 == 2', '2 == 1'])

    conditional = Conditional()
    all_vars = dict()
    assert not conditional.evaluate_conditional(task, all_vars)

    # Test 2: All the when conditions are true
    task = Task()
    setattr(task, 'when', ['1 == 1', '2 == 2'])

    conditional = Conditional()
    all_vars = dict()
    assert conditional.evaluate_conditional(task, all_vars)

    # Test

# Generated at 2022-06-22 14:02:01.271046
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    data = "A and B and C"
    result = c.extract_defined_undefined(data)
    assert isinstance(result, list)
    assert len(result) == 0
    data = "A and B and C is defined"
    result = c.extract_defined_undefined(data)
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0] == ('C', 'is', 'defined')
    data = "A and B and hostvars[inventory_hostname] is defined and (D or E) is not defined"
    result = c.extract_defined_undefined(data)
    assert isinstance(result, list)
    assert len(result) == 3

# Generated at 2022-06-22 14:02:13.941391
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    conditional = "(hostvars['host1'].bit1 or hostvars['host2'].bit2) and not (hostvars['localhost'].bit3 or foo is undefined)"
    results = c.extract_defined_undefined(conditional)
    expected = [('foo', 'is', 'undefined')]
    assert results == expected, "Got %s Expected %s" % (results, expected)

    conditional = "'host1' in groups['all'] and ('host2' in groups['all'] or ('localhost' in groups['all'] and (ipa.domain is not defined or ipa.domain == 'example.com')))"
    results = c.extract_defined_undefined(conditional)
    expected = [('ipa.domain', 'is not', 'defined')]
    assert results

# Generated at 2022-06-22 14:02:18.206301
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Setup the class instance
    cond = Conditional()

    # test for valid conditional
    cond.when = ['True']
    assert cond.evaluate_conditional(None, None) == True

    # test for valid conditional with list of conditions
    cond.when = ['True', 'True']
    assert cond.evaluate_conditional(None, None) == True

    # test for invalid conditional
    cond.when = ['False']
    assert cond.evaluate_conditional(None, None) == False



# Generated at 2022-06-22 14:02:30.845621
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    a_instance = Conditional()

    test1 = AnsibleBaseYAMLObject("test1", load_succeeded=True, start_line=1, start_column=1)
    test1.data = "hostvars['test'] is defined"
    assert a_instance.extract_defined_undefined(test1) == [("hostvars['test']", 'is', 'defined')]

    test2 = AnsibleUnsafeText("test2")
    test2.data = "a is undefined and b is defined"

# Generated at 2022-06-22 14:02:43.241021
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.inventory.host import Host
    from ansible.playbook.base import Base
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    class TestConditional(Conditional, Base):
        pass

    class TestTask(TestConditional):
        pass

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Host(name='localhost')
    variable_manager.set_inventory(inventory)

    # Test conditionals with 'in'
    # this will test with a string, a list and a dict
    templar = Templar(loader=loader, variables=variable_manager)
    all_vars = variable_manager.get_vars(loader=loader, play=None)
    test_task

# Generated at 2022-06-22 14:02:55.674503
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible import constants
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    def _make_module_utils_module():
        import ansible.module_utils.basic
        return ansible.module_utils.basic

    def _make_conditional():
        import ansible.playbook.base
        return Conditional(ansible.playbook.base.Base())

    # noinspection PyUnusedLocal
    def _make_ds(playbook=None, role=None, task=None):
        import ansible.playbook.base
        return ansible.playbook.base.Base(loader=None, inventory=None)


# Generated at 2022-06-22 14:03:07.084078
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    # for testing purposes, you create one of these objects and pass it around
    loader = DataLoader()

    # this is a test inventory we can use for the purposes of this test
    test_inventory = """
[test_host]
localhost
"""
    # these are the variables we've gathered from that test inventory
    test_vars = dict(
        ansible_all_ipv4_addresses=["127.0.0.1"],
        ansible_all_ipv6_addresses=["1:2:3::4"],
    )

    # create a test play context object, which will be used by the templar
    test_play_context = PlayContext()

    # create a conditional object,

# Generated at 2022-06-22 14:03:23.950539
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    r = Conditional.extract_defined_undefined("blah not is defined")
    assert r == [("blah", "not is", "defined")]

    r = Conditional.extract_defined_undefined("blah is undefined")
    assert r == [("blah", "is", "undefined")]

    r = Conditional.extract_defined_undefined("blah is defined")
    assert r == [("blah", "is", "defined")]

    r = Conditional.extract_defined_undefined("blah is not defined")
    assert r == [("blah", "is not", "defined")]

    r = Conditional.extract_defined_undefined("blah not is undefined")
    assert r == [("blah", "not is", "undefined")]


# Generated at 2022-06-22 14:03:36.637309
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    variable_regex = re.compile(r'(hostvars\[.+\]|[\w_]+)')
    conditional = Conditional()

    # Test 1
    conditional_1 = "foo is defined and bar is not defined"
    res = conditional.extract_defined_undefined(conditional_1)
    assert len(res) == 2
    assert all((variable_regex.match(r[0]).group(), r[1], r[2]) == ('foo', 'is', 'defined') for r in res)
    assert any((variable_regex.match(r[0]).group(), r[1], r[2]) == ('bar', 'is not', 'defined') for r in res)

    # Test 2
    conditional_2 = "some_var is undefined"
    res = conditional.extract_defined_

# Generated at 2022-06-22 14:03:48.413846
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class FakeInventory():
        def __init__(self):
            self.vars = {
                'foo': '123',
                'bar': '',
                'baz': False,
            }

    class FakePlaybook():
        def __init__(self, loader):
            pass

    class FakeTemplar():
        def __init__(self, loader, inventory):
            self.loader = loader
            self.inventory = inventory
            self.environment = Environment()
            self.available_variables = {}

        def template(self, data, fail_on_undefined=True):
            if isinstance(data, bool):
                return data

# Generated at 2022-06-22 14:03:53.782045
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    cond = Conditional()
    conditional = "hostvars['foo'] is defined and hostvars[inventory_hostname] is not undefined or hostvars[bar] is undefined"
    results = cond.extract_defined_undefined(conditional)

    assert results == [
        ("hostvars['foo']", 'is', 'defined'),
        ("hostvars[inventory_hostname]", 'is not', 'undefined'),
        ("hostvars[bar]", 'is', 'undefined')
    ]

# Generated at 2022-06-22 14:03:59.017977
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    import sys
    import __builtin__
    setattr(__builtin__, '__OPTIONS__', C.config.__dict__)

    my_display = Display()
    my_display.verbosity = 3
    setattr(C, 'display', my_display)

    my_deprecation = AnsibleDeprecationWarning()
    setattr(C, 'deprecation', my_deprecation)

    my_pluginloader = PluginLoader()
    setattr(C, 'plugin_loader', my_pluginloader)

    my_play_context = PlayContext()
    setattr(my_play_context, 'CLIARGS', dict())
    setattr(C, 'play_context', my_play_context)

    my_loader = DataLoader()
    my_variable_manager = VariableManager()
    my_

# Generated at 2022-06-22 14:04:07.691917
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Mock objects
    class MockBase:
        pass

    class MockLoader:
        pass

    class MockTemplar:

        def __init__(self, variables=None):
            self.available_variables = variables

        def is_template(self, value):
            if "{{ " in value:
                return True
            return False

        def template(self, template, disable_lookups=False):
            if "when_a" in template:
                return "True"
            if "when_b" in template:
                return "True"
            if "when_c" in template:
                return "True"
            if "when_d" in template:
                return "False"
            if "when_e" in template:
                return "True"
            if "when_f" in template:
                return "True"

# Generated at 2022-06-22 14:04:16.823723
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    print('')
    print('TEST: Conditional._extract_defined_undefined()')
    cond = Conditional()
    print('TEST: %s' % cond.extract_defined_undefined('hostvars[inventory_hostname] is defined'))
    print('TEST: %s' % cond.extract_defined_undefined('hostvars[inventory_hostname]is not defined'))
    print('TEST: %s' % cond.extract_defined_undefined('hostvars[inventory_hostname]is defined'))
    print('TEST: %s' % cond.extract_defined_undefined('hostvars[inventory_hostname]isdefined'))

# Generated at 2022-06-22 14:04:28.623561
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook import Play
    from ansible.parsing.dataloader import DataLoader


    class TestClass(Play, Conditional):
        def __init__(self, name, loader, variable_manager, templar, all_vars):
            super(TestClass, self).__init__(name, variable_manager=variable_manager, templar=templar)

            self.all_vars = all_vars
            self._loader = loader

    loader = DataLoader()

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test_key': 'test_value'}

# Generated at 2022-06-22 14:04:40.884918
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = "hostvars['foo'] is undefined and hostvars['bar'] is not defined"
    results = Conditional().extract_defined_undefined(cond)
    assert results == [("hostvars['foo']", "is", "undefined"), ("hostvars['bar']", "is not", "defined")]
    cond = 'hostvars["foo"] is undefined and hostvars["bar"] is not defined'
    results = Conditional().extract_defined_undefined(cond)
    assert results == [("hostvars['foo']", "is", "undefined"), ("hostvars['bar']", "is not", "defined")]
    cond = 'hostvars["foo"] is undefined and hostvars["bar"] is not defined and hostvars["baz"] is undefined'
    results = Conditional().extract_

# Generated at 2022-06-22 14:04:48.179005
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def test(s, expected):
        r = Conditional().extract_defined_undefined(s)
        if r != expected:
            raise Exception("%s != %s" % (r, expected))

    test('hostvars["foo"] is defined or hostvars["bar"] is undefined', [('hostvars["foo"]', 'is', 'defined'), ('hostvars["bar"]', 'is', 'undefined')])
    test('hostvars["foo"] is defined or hostvars[x] is undefined', [('hostvars["foo"]', 'is', 'defined'), ('hostvars[x]', 'is', 'undefined')])
    test('hostvars["foo"] is defined', [('hostvars["foo"]', 'is', 'defined')])

# Generated at 2022-06-22 14:05:07.024617
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.parsing.dataloader import DataLoader

    c = Conditional(loader=DataLoader())
    assert c.extract_defined_undefined("") == []
    assert c.extract_defined_undefined("   ") == []
    assert c.extract_defined_undefined("true") == []
    assert c.extract_defined_undefined("hostvars['foo'] is not defined") == [('hostvars[\'foo\']', 'is not', 'defined')]
    assert c.extract_defined_undefined("hostvars['foo'] is defined") == [('hostvars[\'foo\']', 'is', 'defined')]

# Generated at 2022-06-22 14:05:14.671368
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    task1 = Task()
    play1 = Play()
    task1.set_loader(play1._loader)

    conn_list = [u'network_cli', u'local']
    task1.when = [u"ansible_connection in '%s'" % u"', '".join(conn_list), u"foo"]
    task1.when = [u"ansible_connection == 'network_cli'"]
    display.debug("Evaluated conditional (%s): %s" % (task1.when, task1.evaluate_conditional()))

# Generated at 2022-06-22 14:05:25.881415
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    play = Conditional()

# Generated at 2022-06-22 14:05:38.173584
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext

    # Create a play
    play_source = dict(
        name="foobar",
        hosts='all',
        gather_facts='no',
        tasks=[dict(action=dict(module='debug', args=dict(msg='ok')))]
    )
    play = Play().load(play_source, variable_manager=VariableManager(), loader=DataLoader())

    # Create the task
    task = play.get_tasks()[0]

    # Create the context
    context = PlayContext(play=play, options=dict(tags='always'))

    # Create a templar
    templar = Templar(loader=DataLoader())

    # Test

# Generated at 2022-06-22 14:05:49.305330
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext

    # create the object on which to call the method
    cond = Conditional()

    # input
    templar = DummyTemplar()
    all_vars = dict(a=0, b=1, c=2)

    # expected results without any "when" clause
    cond.when = []
    res = cond.evaluate_conditional(templar, all_vars)
    assert (res is True)

    # expected results with constant "True"
    cond.when = [True]
    res = cond.evaluate_conditional(templar, all_vars)
    assert (res is True)

    # expected results with constant "False"
    cond.when = [False]

# Generated at 2022-06-22 14:05:56.140507
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    # test that it works for simple syntax:
    result = cond.extract_defined_undefined("myvar is defined")
    assert len(result) == 1
    assert result[0][0] == 'myvar'
    assert result[0][1] == 'is'
    assert result[0][2] == 'defined'
    # Test with various spaces
    result = cond.extract_defined_undefined("myvar is  defined")
    assert len(result) == 1
    assert result[0][0] == 'myvar'
    assert result[0][1] == 'is'
    assert result[0][2] == 'defined'
    result = cond.extract_defined_undefined("myvar   is defined")
    assert len(result) == 1
    assert result[0][0]

# Generated at 2022-06-22 14:06:07.826584
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = '''
    ((my_var is defined) and (my_var is not defined)) or (item is undefined)
    or (my_var is undefined) or ((my_var is defined) or (item is undefined))
    or ((my_var is defined) or (item is defined))
    or (item not in hostvars['foobar']['my_var'])
    or (foo in hostvars['foobar']['my_var'])
    or ((hostvars['foobar']['my_var'] is defined) and (hostvars['foobar1']['my_var'] is undefined))
    '''

    c = Conditional()
    result = c.extract_defined_undefined(conditional)
    print(result)

# Generated at 2022-06-22 14:06:12.174735
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = 'foo is defined and bar is not defined'
    c = Conditional()
    result = c.extract_defined_undefined(conditional)
    assert result[0] == ('foo', 'is', 'defined')
    assert result[1] == ('bar', 'is not', 'defined')


# Generated at 2022-06-22 14:06:15.306380
# Unit test for constructor of class Conditional
def test_Conditional():
    assert isinstance(Conditional(loader=None), Conditional)

# Generated at 2022-06-22 14:06:24.392567
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    from ansible.template import Templar

    from ansible.vars.manager import VariableManager

    # initialize a variable manager for tracking objects
    # this is used when a conditional references another object
    var_manager = VariableManager()

    # set some vars in the var manager
    var_manager.extra_vars = {'var1': 1}

    host = 'somehost'
    templar = Templar(loader=None, variables=var_manager,
                      shared_loader_obj=None)

    # create a Conditional object with a fake _ds attribute
    class ConditionalObj:
        _ds = 'VarTask'

    # create a Conditional object and register the conditional method
    obj = ConditionalObj()
    obj.when = []

# Generated at 2022-06-22 14:06:48.730670
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext

    # Unit test implementation for class Conditional
    class ConditionalClass(object):
        _when = None

        @property
        def when(self):
            return self._when

        @when.setter
        def when(self, value):
            self._when = value

        @when.deleter
        def when(self):
            del self._when


# Generated at 2022-06-22 14:06:50.197413
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional._ds == None


# Generated at 2022-06-22 14:06:56.567337
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    play_context = PlayContext(variable_manager=variable_manager, loader=loader)
    host = inventory.get_host('some_host')
    host.set_variable('foo', None)
    variable_manager.set_host_variable(host, 'bar', [])
    variable_manager.set_host_variable(host, 'baz', dict())
    variable_manager.set_host_variable(host, 'quux', set())
   

# Generated at 2022-06-22 14:07:09.541994
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext

    cls = Conditional()
    assert cls._check_conditional('foo', None, dict(foo='bar'))
    assert not cls._check_conditional('foo != bar', None, dict(foo='bar'))
    assert not cls._check_conditional('foo', None, dict(foo=''))
    assert cls._check_conditional('foo and foo != bar', None, dict(foo='bar'))
    assert not cls._check_conditional('foo and foo != bar', None, dict(foo=''))
    assert cls._check_conditional('foo or foo == bar', None, dict(foo=''))
    assert cls._check_conditional('foo == "bar baz"', None, dict())
    assert cls._check_

# Generated at 2022-06-22 14:07:18.649957
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """Unit test: ansible.playbook.conditional.Conditional.evaluate_conditional

    :param Conditional self: A Conditional object.
    :returns: None
    :rtype: None

    """
    import ansible.playbook.conditional
    conditional = ansible.playbook.conditional.Conditional()
    conditional._check_conditional('True', None, None)
    conditional._check_conditional('False', None, None)
    conditional._check_conditional('hello', None, None)
    conditional._check_conditional(1, None, None)
    conditional._check_conditional(0, None, None)
    conditional._check_conditional(100, None, None)
    conditional._check_conditional(None, None, None)
    conditional.when = ['hello', 'hello', 'hello']


# Generated at 2022-06-22 14:07:24.551434
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    c = Conditional()

    play_context = PlayContext()
    c._play_context = play_context

    templar = c._templar

    all_vars = dict(
        a="1",
        b=2,
        c=False,
        d=["a", "b", "c"],
        e=dict(a=1, b=2, c=3),
    )

    display.verbosity = 3

    def test(conditional, expected, fail_on_undefined=True):
        play_context.fail_on_undefined_errors = fail_on_undefined

# Generated at 2022-06-22 14:07:30.412670
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Given
    conditional = Conditional()

    # When
    output = conditional.extract_defined_undefined("result.rc == 0 and 'STIGID' in result.stdout")

    # Then
    assert output == [('result.rc', '==', '0')]


# Generated at 2022-06-22 14:07:42.072955
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    display = Display()
    # Basic tests

# Generated at 2022-06-22 14:07:51.688715
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestObj(Conditional, Base):
        def vars(self):
            return dict()

    t = TestObj()
    templar = Templar(loader=None, variables=VariableManager())

    test_obj = {'foo': 'bar'}

    # not sure how to properly construct test dictionaries with mixed string/unicode keys
    # so the tests that use the test_obj dictionary above are below instead

    # Test a basic conditional that contains a variable
    t.when = u"{{ foo }} == 'bar'"
    rval = t.evaluate_conditional(templar, test_obj)
    assert (rval == True)

    # Test a basic conditional that doesn't contain a variable

# Generated at 2022-06-22 14:08:04.192481
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.errors import AnsibleError
    conditional = Conditional()

    # assert error when not given a string
    test_cases = [
        None,
        [],
        {},
        True,
        False,
        0,
        1,
        1.1,
        '',
        'test',
    ]
    for test_case in test_cases:
        try:
            conditional.extract_defined_undefined(test_case)
        except Exception as e:
            assert isinstance(e, AnsibleError)
        else:
            raise AssertionError('An AnsibleError should have been raised')

    # assert correct result when given a valid string

# Generated at 2022-06-22 14:08:36.868237
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('jeff is not defined')==[('jeff', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('jeff is undefined')==[('jeff', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('hostvars["hostname"] is defined')==[('hostvars["hostname"]', 'is', 'defined')]



# Generated at 2022-06-22 14:08:40.434981
# Unit test for constructor of class Conditional
def test_Conditional():
    """
    Ensure Parameter Conditional initialization is correct.
    """
    cond = Conditional()

    # Make sure all instances have attributes assigned correctly.
    assert hasattr(cond, '_when')
    assert cond._when == []

# Generated at 2022-06-22 14:08:53.985675
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    module_loader = None
    variable_manager = VariableManager(loader=DataLoader())
    template_vars = {'foo': 'foovalue', 'dict': {'a': 1, 'b': 2}, 'dictstr': u'{"a": 1, "b": 2}'}
    template_vars.update(C.DEFAULT_TEMPLATE_VARS)
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=module_loader)
    conditional = Conditional()
    # Tests for undefined variables

# Generated at 2022-06-22 14:09:02.640424
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Prepare a fake class implementing Conditional
    class DummyClass(Conditional):
        def __init__(self):
            self.when = "v1"
        def _get_vars(self):
            return dict(v1=True)

    for cls in (DummyClass,):
        res = cls().evaluate_conditional(None, None)
        assert res is True, "FAIL: %s.evaluate_conditional() = %r" % (cls, res)


# Generated at 2022-06-22 14:09:15.297479
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    import jinja2

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)
    task = TaskInclude(loader=loader)

    # test working with undefined variable
    # test1

# Generated at 2022-06-22 14:09:21.207545
# Unit test for constructor of class Conditional
def test_Conditional():
    test_variable_manager = dict()
    test_loader = dict()
    test_display = Display()
    test_conditional = Conditional(loader=test_loader, variable_manager=test_variable_manager, display=test_display)
    # the result need to be None, otherwise it will raise Exception
    assert test_conditional is not None

# Generated at 2022-06-22 14:09:30.440505
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    print('Unit test for Conditional._evaluate_conditional()')
    print('')
    print('Testing for conditions...')
    print('')

    #Creating test objects
    class ClassA:
        def fn(self, txt):
            return txt.upper()

    class ClassB(Conditional):
        pass

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    var_mngr = VariableManager()
    var_mngr.set_nonpersistent_facts(dict(version='1.2.3'))
    var_mngr.set_nonpersistent_facts(dict(string='Hello'))
    var_mngr.set_nonpersistent_facts(dict(number=123))


# Generated at 2022-06-22 14:09:42.835869
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars import VariableManager
    from ansible.template import Templar

    variable_manager = VariableManager()
    variable_manager.set_inventory(None)

    display = Display()
    display.verbosity = 3

    templar = Templar(loader=None, variables=variable_manager.get_vars(play=None, host=None))

    variable_manager.set_nonpersistent_facts(dict(nested=dict(deep="yes"), key1="value1"))

    conditional = Conditional()

    assert conditional.evaluate_conditional(templar, variable_manager.get_vars(play=None, host=None))

    conditional.when = ["some_dict|length > 3", "nested.deep is defined"]

# Generated at 2022-06-22 14:09:51.729124
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined(None) == []
    assert conditional.extract_defined_undefined('') == []
    assert conditional.extract_defined_undefined('bla') == []
    assert conditional.extract_defined_undefined('a is defined') == [('a', 'is', 'defined')]
    assert conditional.extract_defined_undefined('a is not defined') == [('a', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('a not is defined') == [('a', 'not is', 'defined')]
    assert conditional.extract_defined_undefined('a not is not defined') == [('a', 'not is not', 'defined')]
    assert conditional.extract_defined_undefined('a is undefined')

# Generated at 2022-06-22 14:10:00.814420
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    def _test_eval_cond(conditional, variables, expected_result):
        ds = type('',(object,),{})()
        ds.name = "test_conditional"
        ds.when = conditional
        c = Conditional()
        c.when = conditional
        # Use the following instead of lambda to work around issue #21522 with Python 2.7.x
        # see https://github.com/ansible/ansible-modules-core/issues/3595 for details
        res = c.evaluate_conditional(conditional=c.when, all_vars=variables)
        assert res == expected_result

    _test_eval_cond('somevar == True', {'somevar': True}, True)
    _test_eval_cond('somevar == False', {'somevar': True}, False)
   

# Generated at 2022-06-22 14:11:04.887960
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    # empty conditional
    assert conditional.extract_defined_undefined('') == []

    # only defined/undefined
    assert conditional.extract_defined_undefined('not is undefined') == [('', 'not is', 'undefined')]

    # defined/undefined with variable
    assert conditional.extract_defined_undefined('a is undefined') == [('a', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('a is not undefined') == [('a', 'is not', 'undefined')]

    # defined/undefined with complex variable
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is undefined') == [('hostvars[inventory_hostname]', 'is', 'undefined')]
    assert conditional.ext

# Generated at 2022-06-22 14:11:17.145220
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from mock import MagicMock
    import ansible.playbook.base

    c = Conditional()

    # c._ds does not exist, should raise an exception
    try:
        c.evaluate_conditional(None, None)
        assert False, 'evaluate_conditional did not raise an exception'
    except AnsibleError:
        pass

    # c._ds exists, should not raise an exception
    c._ds = MagicMock()
    templar = MagicMock()
    all_vars = MagicMock()
    try:
        c.evaluate_conditional(templar, all_vars)
        assert True
    except AnsibleError:
        assert False, 'evaluate_conditional raised an unexpected exception'



# Generated at 2022-06-22 14:11:28.309851
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    C.ANSIBLE_VARIABLE_PREFIX = 'ans_'
    example_cases = ['(ans_var1 | default("not_defined"))|default("more_not_defined") is defined',
                     'ans_var1 is defined or ans_var2 is undefined',
                     'not (ans_var1 | default("not_defined")) is defined',
                     '(ans_var1 | default("not_defined")) | default("more_not_defined") is defined',
                     'ans_var1 | default("not_defined") | default("more_not_defined") is defined',
                     'ans_var1 | default("not_defined") is defined or ans_var2 is undefined',
                     'not (ans_var1 | default("not_defined")) is defined']