

# Generated at 2022-06-22 14:01:39.964767
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class A(Conditional):
        pass

    hostvars = dict(a=1, b=2)

    loader = DataLoader()
    play_context = PlayContext(vault_password='123')
    templar = Templar(loader=loader, play_context=play_context)

    a = A(loader=loader)
    a.when = [
        "a == 1",
        "2 == b",
        "a == 0",
    ]
    assert a.evaluate_conditional(templar=templar, all_vars=hostvars) is True


# Generated at 2022-06-22 14:01:46.362907
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('foo is defined and bar is not undefined') == [('foo', 'is', 'defined'), ('bar', 'is not', 'undefined')]
    assert c.extract_defined_undefined('test1 is defined or test2 is not undefined') == [('test1', 'is', 'defined'), ('test2', 'is not', 'undefined')]
    assert c.extract_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert c.extract_defined_undefined('hostvars[foo_host] is undefined') == [('hostvars[foo_host]', 'is', 'undefined')]
    assert c.extract_defined_

# Generated at 2022-06-22 14:01:53.909946
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    vm = VariableManager()
    loader = DataLoader()
    playbook_path = './playbooks/test_playbook.yml'

    # Set undefined variables
    vm.set_host_variable(host=PlaybookExecutor.get_default_host(), varname='test_var', value=42)
    vm.set_host_variable(host=PlaybookExecutor.get_default_host(), varname='missing_var', value=None)



# Generated at 2022-06-22 14:02:04.115839
# Unit test for constructor of class Conditional
def test_Conditional():
    # When constructing an instance of Conditional, a loader is required to be passed.
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    # We create these managed classes for testing, by passing an empty inventory
    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources='')
    vm = VariableManager(loader=loader, inventory=inv_manager)
    host = vm.get_host('127.0.0.1')
    host.vars = {'var': 'test'}
    all_vars = vm.get_vars(host=host)
    test_cond = Conditional(loader=loader)
    test_cond.when = ['var==test']
    # We expect

# Generated at 2022-06-22 14:02:16.184000
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook import PlayBook
    from ansible.playbook.play_context import PlayContext

    playbook = PlayBook()

    context = PlayContext()
    loader = playbook._loader
    templar = loader.load_basedir(
        os.path.join(os.path.dirname(__file__), '../../test_data/templates/')
    )
    templar.set_available_variables(dict(a=1, b=2, c=3))

    test = Conditional(loader=loader)
    test.when = ["a==1", "b==2", "c==3"]

    assert test.evaluate_conditional(templar, context.get_vars()) is True

    test.when = ['a==1', 'b==4']
    assert test.evaluate_conditional

# Generated at 2022-06-22 14:02:29.639512
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    q = Conditional()
    assert q is not None
    assert q.extract_defined_undefined('hostvars["foo"] is defined') == [('hostvars["foo"]', 'is', 'defined')]
    assert q.extract_defined_undefined('hostvars[foo] is not defined') == [('hostvars[foo]', 'is not', 'defined')]
    assert q.extract_defined_undefined('hostvars[foo] is undefined') == [('hostvars[foo]', 'is', 'undefined')]
    assert q.extract_defined_undefined('hostvars[foo] is not undefined') == [('hostvars[foo]', 'is not', 'undefined')]

# Generated at 2022-06-22 14:02:36.356541
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.base import Base
    class DummyClass(Base, Conditional):
        pass
    dummy_class = DummyClass()

    tests = [
        ("a == 'asdf'", []),
        ("a is defined", [('a', 'is', 'defined')]),
        ("a not is undefined or a == 'asdf'", [('a', 'not is', 'undefined')]),
        ("a is defined or a is undefined", [('a', 'is', 'defined'), ('a', 'is', 'undefined')]),
    ]
    for test, expected in tests:
        res = dummy_class.extract_defined_undefined(test)
        assert res == expected, "extract_defined_undefined failed for: %s got: %s" % (test, res)

# Unit tests for method

# Generated at 2022-06-22 14:02:46.057321
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    display = Display()
    display.verbosity = 3

    # Dummy class that inherits from Conditional, needed for the test
    class Dummy(Conditional):
        when = None

    # Get a play context and initialize it
    pc = PlayContext()
    pc.vars = {'inventory_hostname': 'localhost'}

    # Initialize a templar object and set a dummy play context on it
    templar = Templar(loader=None, variables=pc.vars, fail_on_undefined=True)
    templar._play_context = pc

    # Create a dummy object, used to evaluate the conditionals
    dummy = Dummy()

    # Should return True

# Generated at 2022-06-22 14:02:58.597901
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.vars.hostvars import HostVarsVars
    from ansible.template import Templar

    variable_manager = VariableManager()

    variable_manager.set_host_variable("host1", HostVarsVars())
    variable_manager.get_host_vars("host1")["var1"] = 4
    variable_manager.get_host_vars("host1")["hostvars"] = {
        'host1': {'var1': 4}
    }
    variable_manager.set_host_variable("host2", HostVarsVars())
    variable_manager.get_host_vars("host2")["var1"] = 6
    variable_manager.get_host_v

# Generated at 2022-06-22 14:03:06.997912
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    conditional = "foo is defined"
    assert(cond.extract_defined_undefined(conditional) == [(u'foo', u'is', u'defined')])
    conditional = "foo is defined and bar is not defined"
    assert(cond.extract_defined_undefined(conditional) == [(u'foo', u'is', u'defined'), (u'bar', u'is not', u'defined')])
    conditional = "non_existent_regex"
    assert(cond.extract_defined_undefined(conditional) == [])


# Generated at 2022-06-22 14:03:35.912174
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Since evaluating conditionals involves a lot of jinja, we only verify that
    # the conditionals are templated in the first place
    class Play:
        pass
    class PlayContext:
        def __init__(self):
            self.hostvars = {'testhost': {'foo': 'bar', 'empty': '', 'zero': 0}}
            self.vars = {'var1': 'ok'}
    class FakeTemplar:
        def __init__(self):
            self.environment = DummyEnvironment()
        def is_template(self, cond):
            return True
        def template(self, cond, disable_lookups=True):
            return cond
    task = Conditional()
    play = Play()

# Generated at 2022-06-22 14:03:47.776609
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    display = Display()
    display.verbosity = 1

    class ConditionalTester(Conditional):
        pass

    conditionalTester = ConditionalTester()

    # test missing variable
    variable_name = 'test_var'
    variable_value = 'test_value'

    missing_var_conditional = "%s == '%s'" % (variable_name, variable_value)
    conditionalTester._when = [missing_var_conditional]

    all_vars = dict()
    result = conditionalTester.evaluate_conditional(None, all_vars)
    assert(result == False)

    # test non-matching variable value
    non_matching_var_value = 'non_matching_value'
    all_vars = {variable_name: non_matching_var_value}

# Generated at 2022-06-22 14:03:57.236756
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def test_assert(conditional, result):
        c = Conditional()
        assert c.extract_defined_undefined(conditional) == result
    test_assert('hostvars["foo"] is not defined', [('hostvars["foo"]', 'is not', 'defined')])
    test_assert('hostvars["foo"] is defined and hostvars["bar"] is defined',
                [('hostvars["foo"]', 'is', 'defined'), ('hostvars["bar"]', 'is', 'defined')])
    test_assert('hostvars["foo"] is defined or hostvars["bar"] is not defined',
                [('hostvars["foo"]', 'is', 'defined'), ('hostvars["bar"]', 'is not', 'defined')])

# Generated at 2022-06-22 14:04:01.680284
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    c = Conditional()

    d = {'foo': 'bar'}
    assert c.evaluate_conditional(d)

    c.when = 'foo is bar'
    assert c.evaluate_conditional(d)

    c.when = 'foo is yar'
    assert not c.evaluate_conditional(d)

# Generated at 2022-06-22 14:04:09.291961
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import jinja2
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    class TestObject:
        _loader = loader
    class TestModule:
        _loader = loader
        _templar = jinja2.Environment(undefined=jinja2.StrictUndefined)
        def get_name(self):
            return "test_module"

    display.verbosity = 3
    # test on a task
    all_vars = dict()
    task_ = TestObject()
    tm = TestModule()
    assert task_.evaluate_conditional(tm._templar, all_vars) == True
    task_._ds = {'name': 'task1'}

# Generated at 2022-06-22 14:04:19.182516
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    conditional = Conditional()

    # test 1: No defined/undefined test
    cond = "answer == 42"
    assert conditional.extract_defined_undefined(cond) == []

    # test 2: Simple defined/undefined test
    cond = "answer is defined"
    assert conditional.extract_defined_undefined(cond) == [('answer', 'is', 'defined')]

    # test 3: Simple undefined test with not
    cond = "answer not is undefined"
    assert conditional.extract_defined_undefined(cond) == [('answer', 'not is', 'undefined')]

    # test 4: Simple undefined test
    cond = "answer is undefined"
    assert conditional.extract_defined_undefined(cond) == [('answer', 'is', 'undefined')]

    # test 5: Simple undefined test with no

# Generated at 2022-06-22 14:04:20.471518
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert isinstance(conditional, Conditional)

# Generated at 2022-06-22 14:04:26.188514
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Create a Conditional instance
    c = Conditional()

    # Test the method extract_defined_undefined
    test_string = 'a is defined'
    assert c.extract_defined_undefined(test_string) == [('a', 'is', 'defined')]

# Generated at 2022-06-22 14:04:38.628126
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # my_hostvars is a dict with the same structure as hostvars, because we don't want to test
    # hostvars itself, just the template evaluation.
    my_hostvars = {'hostname': {'ansible_host': '127.0.0.1'}}

    # my_vars is a dict with the same structure as vars, because we don't want to test vars
    # itself, just the template evaluation.
    my_vars = {'myvar1': 'something', 'myvar2': 'somethingelse'}

    my_loader = DataLoader()
    my_variable_manager = VariableManager()
    my_variable_manager.extra_vars = my_vars

# Generated at 2022-06-22 14:04:50.845084
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Conditional, AnsibleMapping):
        pass

    template_data = dict(
        a="foo",
        b="bar",
        c=None,
        d=dict(e=22),
        f=list(range(0, 10)),
        g="33",
    )

    # Testing when undefined value

# Generated at 2022-06-22 14:05:34.612559
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:05:42.857164
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.base import Base

    class TestConditional(Base, Conditional):
        pass
    cond = TestConditional()


# Generated at 2022-06-22 14:05:54.822674
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Set up dummy class for test
    class DummyParent(object):
        def __init__(self, ds=None):
            self._ds = ds

    class DummyModule(object):
        def __init__(self, params=None):
            self.params = params or {}

    module = DummyModule()
    parent = DummyParent()
    module.no_log = True
    templar = DummyTemplar(variables=dict(), loader=DummyLoader())
    conditional = Conditional()

    # Test a few valid conditions

# Generated at 2022-06-22 14:06:03.988795
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    def test_one(when_str, hostvars, expected):
        # Make an object of class Conditional
        c = Conditional()
        c.when = when_str

        # Make a templar object
        from ansible.vars.manager import VariableManager
        from ansible.template import Templar
        v = VariableManager(loader=None)
        v.set_host_variable(None, "hostvars", {'u':'v', 'x':'y'})
        t = Templar(loader=None, variables=v)

        # Execute the method under test for function Conditional.evaluate_conditional
        actual = c.evaluate_conditional(templar=t, all_vars=v.get_vars(play=None, host=None, include_hostvars=True))


# Generated at 2022-06-22 14:06:13.301754
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    import pytest

    C.DEFAULT_HASH_BEHAVIOUR = 'replace'

    # helper function to evaluate a condition against a string
    def evaluate(condition, string):
        class TestObj(Conditional):
            def __init__(self, condition):
                self.when = condition
        # add globals

# Generated at 2022-06-22 14:06:19.064609
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    The method evaluate_conditional of class Conditional allow to evaluate
    conditionals set on this object, returning False if any of them evaluate
    as such.

    This unit test checks if the method evaluate_conditional returns True or
    False in the different conditions.
    '''

    # This class is intended to emulate the class Conditional when using
    # it as a mix-in
    class ConditionalMixIn():
        def __init__(self):
            # Set the conditional to test
            self.when = "test_when"

    # Set the flag to False
    result = False

    # Create one instance of the class Conditional and one instance of the
    # class ConditionalMixIn
    conditional = Conditional()
    conditional_mixin = ConditionalMixIn()

    # To test the method we need to get a templar and

# Generated at 2022-06-22 14:06:26.151254
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    test_class = type("TestClass", (Conditional,), {})
    test_class._when = ["", "", "ansible_os_family == 'RedHat'"]
    all_vars = dict(ansible_os_family="RedHat")
    test_obj = test_class(None)
    result = test_obj.evaluate_conditional(None, all_vars)
    assert result is True

# Generated at 2022-06-22 14:06:35.578404
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.module_utils.six import PY3
    from ansible.template import Templar
    from ansible.vars import VariableManager

    templar = Templar(loader=None, variables=VariableManager())

    c = Conditional()
    # test with a None value
    assert(c.evaluate_conditional(templar, dict())==True)

    # test with a non-string value
    assert(c.evaluate_conditional(templar, dict(), {'when':[True]})==True)

    # test with a string (basic)
    assert(c.evaluate_conditional(templar, dict(), {'when':['a==b']})==False)

    # test with a string (using a var)

# Generated at 2022-06-22 14:06:47.275085
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    templar = Templar(loader=loader, variables={
        'a': True,
        'b': False,
        'c': True,
        'd': False,
        'e': ['foo', 'bar'], 'f': {'hello': 'world'}
    })
    base_item = Conditional(loader=loader)
    base_item._ds = {'name': 'test_Conditional_evaluate_conditional'}
    display.verbosity = 4
    assert base_item.evaluate_conditional(templar, templar.available_variables)
    base_item.when = ['a']

# Generated at 2022-06-22 14:06:55.070856
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Test the low-level conditional evaluation method, using a series of
    fictional variables in the "all_vars" dictionary.
    '''
    # prep setup
    from ansible.plugins.loader import conditionals
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    mr = conditionals.Conditional(loader=loader)


# Generated at 2022-06-22 14:07:28.578020
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional


# Generated at 2022-06-22 14:07:38.723209
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Test multiple is/is not defined in string
    cond = 'test is defined and test1 is not defined and test2 is not defined'
    result = Conditional().extract_defined_undefined(cond)
    assert result[0][2] == 'defined'
    assert result[1][2] == 'undefined'
    assert result[2][2] == 'undefined'

    # Test not is defined in string
    cond = 'test not is defined'
    result = Conditional().extract_defined_undefined(cond)
    assert result[0][1] == 'not is'

    # Test is not defined in string
    cond = 'test is not defined'
    result = Conditional().extract_defined_undefined(cond)
    assert result[0][1] == 'is not'

    # Test multiple is defined in string

# Generated at 2022-06-22 14:07:47.473016
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible import errors
    from ansible.template import Templar

    # test each invalid conditional type
    for test_val in (None, '', True, False, [], {}):
        module = Conditional()
        module._ds = None
        try:
            module.evaluate_conditional(Templar(loader=None, variables={}), {})
        except errors.AnsibleError as e:
            pass
        else:
            raise AssertionError("No exception was thrown on 'evaluate_conditional()' with an invalid conditional: '%s'" % test_val)

    # test a valid conditional which evaluated to True
    test_val = 'foo'
    module = Conditional()
    module.when = test_val
    module._ds = None

# Generated at 2022-06-22 14:07:55.119414
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    t = Conditional()
    assert t.extract_defined_undefined('a and b or c') == [], "Unrecognized string - should return empty list"
    assert t.extract_defined_undefined('a and  hostvars["foo"] is undefined or c') == [('hostvars["foo"]', 'is', 'undefined')], "Recognized string - should return a list"

    # use variables as defined or undefined
    assert t.extract_defined_undefined('a and  hostvars["foo"] is defined or c') == [('hostvars["foo"]', 'is', 'defined')], "Recognized string - should return a list"

# Generated at 2022-06-22 14:08:04.961062
# Unit test for constructor of class Conditional
def test_Conditional():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory_manager = InventoryManager(loader=loader, sources=["/etc/ansible/hosts"])
    play_source = dict(
        name="Ad-hoc test play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='setup', args='')),
        ]
    )


# Generated at 2022-06-22 14:08:18.410329
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    fake_loader = DictDataLoader({})

    fake_variable_manager = VariableManager(loader=fake_loader, host_vars=HostVars(loader=fake_loader, variable_manager=None))
    fake_variable_manager.set_nonpersistent_facts(dict(omit=[]))

    fake_play_context = PlayContext()

    play = Play().load({}, variable_manager=fake_variable_manager, loader=fake_loader)


# Generated at 2022-06-22 14:08:26.303486
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    any_conditional = 'some_var is defined or (not another_var is undefined and ' \
                      '(var3 is defined or not var4 is undefined) or foo_bar is defined) or ' \
                      'custom_var is defined'
    conditional_class = Conditional(None)
    assert conditional_class.extract_defined_undefined(any_conditional) == \
           [('some_var', 'is', 'defined'),
            ('another_var', 'is not', 'undefined'),
            ('var3', 'is', 'defined'),
            ('var4', 'is not', 'undefined'),
            ('foo_bar', 'is', 'defined'),
            ('custom_var', 'is', 'defined')]


# Generated at 2022-06-22 14:08:38.466033
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    result = []
    result.append(Conditional()._check_conditional(text_type('1 == 1'), None, None))
    result.append(Conditional()._check_conditional(text_type('1 == 0'), None, None))
    result.append(Conditional()._check_conditional(text_type('2 < 3'), None, None))
    result.append(Conditional()._check_conditional(text_type('2 > 3'), None, None))
    result.append(Conditional()._check_conditional(text_type('a < "b"'), None, None))
    result.append(Conditional()._check_conditional(text_type('a < "a"'), None, None))

# Generated at 2022-06-22 14:08:51.791421
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Testing a simple value
    host_vars = dict(host_var='host_var_value')
    templar = DummyTemplar(host_vars)
    conditional = Conditional(templar=templar)
    conditional.when = ['host_var == "host_var_value"']
    assert conditional.evaluate_conditional(templar, {})

    # Testing a value with jinja2 tags
    conditional.when = ['host_var == "host_var_value" | ternary("host_var_value", "wrong_value")']
    assert conditional.evaluate_conditional(templar, {})

    # Testing a value doesn't evaluate to true
    conditional.when = ['host_var == "wrong_value" | ternary("host_var_value", "wrong_value")']

# Generated at 2022-06-22 14:08:55.093724
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    test_conditions = {
        'True': (
            True,
            "{{ is_windows }} and {{ lookup('file', '/') != '/' }}",
            {'is_windows': True},
        ),
        'False': (
            False,
            "{{ is_windows }} and {{ lookup('file', '/') != '/' }}",
            {'is_windows': False},
        ),
    }
    for res, condition, all_vars in test_conditions.values():
        from ansible.template import Templar
        templar = Templar(None, loader=None)
        assert res == Conditional().evaluate_conditional(templar, all_vars)



# Generated at 2022-06-22 14:09:35.761772
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()


# Generated at 2022-06-22 14:09:42.565952
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    # Setup
    class TestVariable(object):
        def __init__(self, value):
            self.value = value

    class TestHost(object):
        def __init__(self, variable, value):
            self.vars = TestVariable(value)
            setattr(self.vars, variable, value)

    class TestPlayContext(object):
        def __init__(self, variable, value):
            self.hostvars = {'inventory_hostname_short': TestHost(variable, value)}

    class TestPlay(object):
        def __init__(self, variable, value):
            self.context = TestPlayContext(variable, value)


# Generated at 2022-06-22 14:09:51.565504
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Test the method evaluate_conditional with a simple conditionnal expression
    # Check that the method evaluates correctly when the conditional is 'foo'
    class TestConditional(Conditional):
        when = FieldAttribute(isa='list', default=list, extend=True, prepend=True)
    tc = TestConditional()
    tc.when = 'foo'
    all_vars = {'foo': 'foo'}
    from ansible.template import Templar
    templar = Templar(loader=None, variables=all_vars)
    assert tc.evaluate_conditional(templar, all_vars)

    # Check that the method evaluates correctly when the conditional is 'foo'
    tc = TestConditional()
    tc.when = 'foo'
    all_vars = {'foo': 'bar'}

# Generated at 2022-06-22 14:10:00.714156
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:10:04.720785
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert Conditional().extract_defined_undefined(u'') == []
    assert Conditional().extract_defined_undefined(u'hostvars[inventory_hostname] is undefined') == [('hostvars[inventory_hostname]', 'is', 'undefined')]

# Generated at 2022-06-22 14:10:13.519016
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    from ansible.playbook.task import Task
    import os

    class TestModule():
        def __init__(self, params):
            self.params = params
        def fail_json(self, **kwargs):
            return 0

    test_loader = DataLoader()
    test_inventory = InventoryManager(loader=test_loader, sources=[os.path.join(os.path.dirname(__file__), 'test_conditionals_inventory.yaml')])
    test_variable_manager = VariableManager(loader=test_loader, inventory=test_inventory)

    test_conditional = Conditional()
    test_

# Generated at 2022-06-22 14:10:24.985153
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars

    # setup
    vars_manager = VariableManager()
    templar = Templar(loader=None, variables=vars_manager)

    # test with an empty condition
    condition = None
    res = Conditional().evaluate_conditional(templar, combine_vars(loader=None, variables=vars_manager))
    assert(res)

    # test with a boolean condition
    condition = True
    res = Conditional().evaluate_conditional(templar, combine_vars(loader=None, variables=vars_manager))
    assert(res == condition)

    # test with a condition that contains a template
    condition = "{{ foo }}"
    res = Conditional().evaluate

# Generated at 2022-06-22 14:10:36.487826
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Expected results
    expected = [("hostvars['foo']", 'is', 'defined'),
                ("hostvars[inventory_hostname]", 'is', 'defined'),
                ("hostvars['bar']", 'is', 'undefined'),
                ("hostvars[inventory_hostname]", 'is', 'undefined'),
                ("parent_var", 'is', 'defined'),
                ("parent_var", 'is not', 'defined'),
                ("parent_var", 'is', 'undefined'),
                ("parent_var", 'not is', 'undefined'),
                ("child_var", 'is', 'defined'),
                ("child_var", 'is not', 'defined'),
                ("child_var", 'is', 'undefined'),
                ("child_var", 'not is', 'undefined')]

    # Input test cases

# Generated at 2022-06-22 14:10:50.071796
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

    conditional = "foo is defined and bar is undefined"
    result = cond.extract_defined_undefined(conditional)
    assert len(result) == 2
    assert result[0] == ('foo', 'is', 'defined')
    assert result[1] == ('bar', 'is', 'undefined')

    conditional = "foo is defined and not bar is defined"
    result = cond.extract_defined_undefined(conditional)
    assert len(result) == 2
    assert result[0] == ('foo', 'is', 'defined')
    assert result[1] == ('bar', 'not is', 'defined')

    conditional = "foo is defined"
    result = cond.extract_defined_undefined(conditional)
    assert len(result) == 1

# Generated at 2022-06-22 14:11:03.151614
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import yaml
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Create data loader
    loader = DataLoader()

    # Create variable manager