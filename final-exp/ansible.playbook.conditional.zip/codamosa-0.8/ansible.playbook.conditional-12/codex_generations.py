

# Generated at 2022-06-22 14:01:39.128222
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-22 14:01:51.107619
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def test_match(test, expected):
        c = Conditional()
        act = c.extract_defined_undefined(test)
        if act != expected:
            raise AssertionError("%s should be %s but found %s" % (test, expected, act))

    test_match("foo not is defined", [('foo', 'not is', 'defined')])
    test_match("bar is defined", [('bar', 'is', 'defined')])
    test_match("baz is undefined", [('baz', 'is', 'undefined')])
    test_match("baz is not undefined", [('baz', 'is not', 'undefined')])
    test_match("foo not is defined and bar is defined", [('foo', 'not is', 'defined'), ('bar', 'is', 'defined')])
   

# Generated at 2022-06-22 14:02:02.974142
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    conditional = Conditional()
    templar = Templar(loader=None, variables=VariableManager())

    # Basic tests
    assert conditional.evaluate_conditional(templar, dict())
    assert conditional.evaluate_conditional(templar, dict(a=1))

    # Test basic conditional results
    assert conditional.evaluate_conditional(templar, dict(a=1))
    assert not conditional._check_conditional('a == 2', templar, dict(a=1))

    # Evaluate a conditional with a Jinja2 expression
    assert conditional._check_conditional("dns_servers|length > 0", templar, dict(dns_servers=['dns1', 'dns2']))

    # Isolated tests for

# Generated at 2022-06-22 14:02:15.908788
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:02:29.307263
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars import VariableManager
    from ansible.template import Templar

    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(test_host='testhost.example.com', test_foo='foo'))
    variable_manager.set_host_variable('testhost.example.com', 'ansible_host', 'testhost.example.com')
    variable_manager.set_host_variable('testhost.example.com', 'test_bar', 'bar')
    variable_manager.set_host_variable('testhost.example.com', 'my_list', [1, 2, 3])

    class TestConditional(Conditional):
       name = ''
       when = []

       def __init__(self, when, loader=None):
           self.when = when

# Generated at 2022-06-22 14:02:42.116797
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test with boolean
    def test_evaluate_conditional_bool(conditional_obj, templar, all_vars):
        res = conditional_obj.evaluate_conditional(templar, all_vars)
        if not isinstance(res, bool):
            raise AssertionError("The result for evaluate_conditional is not a boolean")
    conditional_obj = Conditional()
    conditional_obj.when = True
    templar = None
    all_vars = None
    test_evaluate_conditional_bool(conditional_obj, templar, all_vars)

    # Test without disable_lookups

# Generated at 2022-06-22 14:02:54.503038
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.template import Templar
    play_context = dict()

    def _dummy_loader(path):
        return dict()

    play1 = Play().load({}, play_context, _dummy_loader)
    block1 = Block().load({}, play1, play_context, _dummy_loader)
    hostvars = dict()
    templar = Templar(loader=_dummy_loader, variables=hostvars)
    task1 = Task().load({}, block1, play1, play_context, _dummy_loader)

    cond = Conditional()
    cond_str = 'foo is defined and (bar is undefined or baz is defined)'
    assert len

# Generated at 2022-06-22 14:02:58.113099
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    conditional_test = Conditional(loader=loader)
    conditional_test.when = 'test'

# Generated at 2022-06-22 14:03:08.520926
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    def _get_loader(data=None):
        if data is None:
            data = dict()
        return DictDataLoader(data)

    class TestConditional(Conditional):
        def __init__(self, data=None):
            super(TestConditional, self).__init__(_get_loader(data))

    # Mock some variables
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(
        foo='bar',
        ansible_check_mode=True,
        ansible_version=dict(
            full='2.0.0.0'
        )
    )

    templar = Templar(loader=_get_loader(), variables=variable_manager)


# Generated at 2022-06-22 14:03:14.182577
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    sample_conditional = 'hostvars["host_name"].ansible_bios_date != "undefined" and hostvars["host_name"].ansible_bios_version != "undefined"'
    c = Conditional()
    result = c.extract_defined_undefined(sample_conditional)
    assert len(result) == 2
    assert result[0] == ('hostvars["host_name"].ansible_bios_date', '!=', 'undefined')
    assert result[1] == ('hostvars["host_name"].ansible_bios_version', '!=', 'undefined')

    sample_conditional = 'hostvars["host_name"].ansible_bios_date != "undefined"'

# Generated at 2022-06-22 14:03:40.172946
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:03:52.405472
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class TestConditional (Conditional):
        def __init__(self):
            super(Conditional, self).__init__()

    cond = TestConditional()

# Generated at 2022-06-22 14:03:53.374541
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional.when is None

# Generated at 2022-06-22 14:04:03.796455
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    variable_manager = VariableManager()
    loader = DataLoader()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      fail_on_undefined=C.DEFAULT_UNDEFINED_VAR_BEHAVIOR)

    item = Conditional(loader=loader)
    variable_manager.set_nonpersistent_facts(dict())
    variable_manager.set_facts(dict())

    # If the conditional is None, the result should be True
    item.when = None

# Generated at 2022-06-22 14:04:10.630368
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    Unit test for method extract_defined_undefined of class Conditional
    :return:
    '''
    conditional = Conditional()
    # Simple defined/undefined test
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]
    # Multiple defined/undefined test
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is defined and hostvars[inventory_hostname] is not undefined') == [('hostvars[inventory_hostname]', 'is', 'defined'), ('hostvars[inventory_hostname]', 'is not', 'undefined')]
    # No defined/undefined test

# Generated at 2022-06-22 14:04:20.166583
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from units.mock.loader import DictDataLoader

    # The loader has no role in the test. However it is a mandatory argument.
    loader = DictDataLoader({})

    # Test a conditional statement without variables
    # The variable names and the variable types are not relevant.
    all_vars = {'name1': 'value1', 'name2': 'value2'}
    task = Conditional(loader=loader)
    task._when = ['test_conditional']

    res = task.evaluate_conditional(None, all_vars)
    assert res == True

    # Test a conditional statement with variable
    # The variable name is not relevant.
    all_vars = {'name1': 'value1', 'name2': 'value2'}
    task = Conditional(loader=loader)

# Generated at 2022-06-22 14:04:33.340287
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    TEST_VARIABLES = ['a', 'b', 'c']
    TEST_VALUES = ['defined', 'undefined']
    TEST_CONDITIONALS = ['a is undefined and b is defined or c is undefined',
                         'not a is defined or not b is undefined and c is defined',
                         'hostvars[\'foo\'] is defined or hostvars["bar"] is undefined and hostvars[baz] is undefined',
                         'not hostvars[\'foo\'] is undefined or not hostvars["bar"] is defined and hostvars[baz] is defined']

# Generated at 2022-06-22 14:04:44.383208
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = 'ssl_admin_cert not is defined'
    result = Conditional().extract_defined_undefined(conditional)
    assert result == [('ssl_admin_cert', 'not is', 'defined')]

    conditional = 'ssl_admin_cert not is defined or docker_service is not defined'
    result = Conditional().extract_defined_undefined(conditional)
    assert result == [('ssl_admin_cert', 'not is', 'defined'),
                      ('docker_service', 'is not', 'defined')]

    conditional = 'ssl_admin_cert not is defined and (docker_service is not defined or '\
                  'docker_service is defined)'
    result = Conditional().extract_defined_undefined(conditional)

# Generated at 2022-06-22 14:04:54.792217
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    conditional = Conditional()

    def run_test(conditional, all_vars, should_pass):
        result = conditional.evaluate_conditional(templar, all_vars)
        if should_pass:
            assert result is True, "%s did not pass" % conditional.when
        else:
            assert result is False, "%s should not have passed" % conditional.when

    # set up templating
    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    variable_manager.set_inventory(loader.load_inventory(loader.inventory_basedirs))
    templar = Templar(loader=loader, variables=variable_manager.get_vars())

    # test simple, non-templ

# Generated at 2022-06-22 14:05:06.853939
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    templar = Templar(None, play_context=PlayContext(variable_manager=None))
    conditional = Conditional()
    all_vars = dict(hostvars=dict(aaa=1), bbb=2, ccc=dict(ddd=3))
    # 1
    assert conditional.evaluate_conditional(templar, all_vars) == True
    conditional.when = ['hostvars[aaa] == 1']
    # 2
    assert conditional.evaluate_conditional(templar, all_vars) == True
    conditional.when = ['hostvars[aaa] == 2']
    # 3
    assert conditional.evaluate_conditional(templar, all_vars) == False
    conditional.when

# Generated at 2022-06-22 14:05:42.827071
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import copy
    import sys
    import yaml

    # In unit test, we use the same name (CopiedSuperConditional) for
    # the first superclass of ConditionalTest in order to simulate the
    # situation in the code where the third-level superclass is inherited
    # by Conditional when ConditionalTest is the second-level superclass
    # of Conditional.
    class CopiedSuperConditional(object):
        def __init__(self):
            self.when = []

    class SuperConditional(CopiedSuperConditional):
        def __init__(self):
            CopiedSuperConditional.__init__(self)

    class ConditionalTest(SuperConditional, Conditional):
        def __init__(self):
            SuperConditional.__init__(self)
            Conditional.__init__(self)
           

# Generated at 2022-06-22 14:05:52.188017
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.task_include import TaskInclude
    import ansible.playbook
    import ansible.template
    from ansible.vars.hostvars import HostVars
    import jinja2

    class VarsModule:
        def get_vars(inner_self, loader, play, host, task):
            hvars = HostVars(loader=loader, play=play, host=host).get_vars()
            tvars = ansible.template.template_vars(play=play, host=host, task=task)
            return dict(hvars.items() + tvars.items())

    def _create_fake_loader(path):
        class StreamOnlyLoader:
            def get_basedir(inner_self, inner_path):
                return path


# Generated at 2022-06-22 14:06:02.472565
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional = Conditional()

    vars={'a':True, 'b':False}
    assert conditional._check_conditional('a', variable_manager=None, all_vars=vars) is True
    assert conditional._check_conditional('a and b', variable_manager=None, all_vars=vars) is False
    assert conditional._check_conditional('a or b', variable_manager=None, all_vars=vars) is True
    assert conditional._check_conditional('c', variable_manager=None, all_vars=vars) is False

    vars={'a':1, 'b':0}
    assert conditional._check_conditional('a', variable_manager=None, all_vars=vars) is True

# Generated at 2022-06-22 14:06:09.420136
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    assert True is Conditional().evaluate_conditional(None, {})
    assert False is Conditional(when=None).evaluate_conditional(None, {})
    assert False is Conditional(when=[]).evaluate_conditional(None, {})
    assert False is Conditional(when=[False]).evaluate_conditional(None, {})
    assert True is Conditional(when=[True]).evaluate_conditional(None, {})
    assert True is Conditional(when=[True, False]).evaluate_conditional(None, {})



# Generated at 2022-06-22 14:06:21.536811
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    t = Task()
    p = PlayContext()
    c = Conditional()
    v = VariableManager()

    results = c.extract_defined_undefined('hostvars[inventory_hostname] is defined')
    assert results == [('hostvars[inventory_hostname]', 'is', 'defined')]

    results = c.extract_defined_undefined('result | success or not hostvars[inventory_hostname] is not undefined')
    assert results == [('result', 'or', 'undefined'), ('hostvars[inventory_hostname]', 'is', 'not undefined')]

    results = c.ext

# Generated at 2022-06-22 14:06:22.729107
# Unit test for constructor of class Conditional
def test_Conditional():
    Conditional(None)
    return True

# Generated at 2022-06-22 14:06:33.432442
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import jinja2
    from ansible.template import Templar

    # test for undefined variable
    conditional = "{{ a }}"
    templar = Templar(loader=None, shared_loader_obj=None, variables={})

    try:
        conditional = Conditional()
        conditional.evaluate_conditional(templar, [])
    except Exception as e:
        assert "The conditional check '{{ a }}' failed. The error was: 'a' is undefined" in to_native(e)

    # test for as used in comment
    conditional = "# as"
    try:
        conditional = Conditional()
        conditional.evaluate_conditional(templar, [])
    except Exception as e:
        assert "Unexpected templating type error occurred on ({{# as }}): expected string or buffer" in to_native(e)



# Generated at 2022-06-22 14:06:45.472419
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('hostvars["foo"] is defined or a == b') == [('hostvars["foo"]', 'is', 'defined')]
    assert conditional.extract_defined_undefined('hostvars["foo"] not is undefined and b > c') == [('hostvars["foo"]', 'not is', 'undefined')]
    assert conditional.extract_defined_undefined('a==1 or (b==2 and hostvars["foo"] is defined)') == [('hostvars["foo"]', 'is', 'defined')]

# Generated at 2022-06-22 14:06:53.966757
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:07:07.283270
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    from ansible.template import Templar

    conditional = Conditional()


# Generated at 2022-06-22 14:07:43.811897
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    context = dict(hostvars=dict(hostname=dict(test_attr='test_value')))
    context.update(dict(ansible_foo_var='foo', ansible_var='value'))

    def get_conditional_object(loader):
        class TestConditional(object):
            _when = FieldAttribute(isa='list')

            def __init__(self):
                self.when = ['test_value', 'ansible_foo_var == foo', 'ansible_var == "value"' 'test_attr == something_else']

        test_conditional = TestConditional()

        test_conditional._loader = loader

        return test_conditional

    # test cases

# Generated at 2022-06-22 14:07:53.068574
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    class TestConditionalClass(Conditional):
        def __init__(self, when=None):
            self._ds = False
            self.when = when

    test_obj = TestConditionalClass(when=['{{a}} == 1', '{{b}} == "1"', "{{c}} == '1'", '"{{d}}" == "1"'])

    variables = {'a': 1, 'b': '1', 'c': "1", 'd': 1}

    assert test_obj.evaluate_conditional(variables) is True, 'test_Conditional_evaluate_conditional failed to return true when all vars match.'

    variables = {'a': 1, 'b': '1', 'c': "2", 'd': 1}


# Generated at 2022-06-22 14:08:04.534210
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Simple cases
    t = Conditional()
    assert t.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert t.extract_defined_undefined('foo not is undefined') == [('foo', 'not is', 'undefined')]
    # Multiple matches
    assert t.extract_defined_undefined('foo not is defined and bar is undefined') == [
        ('foo', 'not is', 'defined'), ('bar', 'is', 'undefined')
    ]
    # Whitespace variations
    assert t.extract_defined_undefined('foo\tnot\tis defined') == [('foo', 'not is', 'defined')]
    # Hostvars

# Generated at 2022-06-22 14:08:17.994126
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.task_include import TaskInclude
    ti = TaskInclude("foo")
    ti._ds = "my_ds"
    ti.when = ["a", "b"]
    ti.when.append(None)

    class fake(object):
        pass

    class fake_templar(object):
        def template(self, conditional, disable_lookups):
            if conditional in ('a', 'b', None):
                return 'True'
            else:
                return 'False'

    from ansible.template import Templar
    t = Templar(loader=None)
    f = fake()
    all_vars = {}

    result = ti.evaluate_conditional(fake_templar(), all_vars)
    assert result == True, "%s != True" % result


# Generated at 2022-06-22 14:08:29.093315
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class MyConditional(Conditional):
        def __init__(self):
            pass

    cond = MyConditional()

    # Empty conditional
    res = cond.extract_defined_undefined('')
    assert res == []

    # No match
    res = cond.extract_defined_undefined('nothing to match here')
    assert res == []

    # Single match
    res = cond.extract_defined_undefined('hostvars[inventory_hostname] is not undefined')
    assert res == [('hostvars[inventory_hostname]', 'is not', 'undefined')]

    # Multiple matches
    res = cond.extract_defined_undefined('hostvars[inventory_hostname] is not undefined and hostvars[inventory_hostname] is defined')

# Generated at 2022-06-22 14:08:39.990752
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Test `evaluate_conditional` with simple conditionals
    '''

    from ansible.template import Templar

    class WhenTest(Conditional):
        def __init__(self, when, all_vars):
            self._ds = {}
            self.when = when
            self._loader = None
            self._validate_when('when', 'when', when)

    # test with a single conditional
    cond_single_true = WhenTest(['foo == 1'], dict(foo=1))
    assert cond_single_true.evaluate_conditional(Templar(loader=None), dict(foo=1))

    cond_single_false = WhenTest(['foo == 1'], dict(foo=2))

# Generated at 2022-06-22 14:08:53.649202
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-22 14:09:00.711280
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
        # Create a Conditional object
        conditional = Conditional()
        # Some assertions to test the method extract_defined_undefined
        assert conditional.extract_defined_undefined("hostvars['hostvars['host_name']] is defined") == []
        assert conditional.extract_defined_undefined("hostvars['localhost'] is defined") == [("hostvars['localhost']", "is", "defined")]
        assert conditional.extract_defined_undefined("hostvars['host_name'] is undefined") == [("hostvars['host_name']", "is", "undefined")]

# Generated at 2022-06-22 14:09:12.545592
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # First, we test the case where the conditional is evaluated to true
    class test_1(Conditional):
        def __init__(self):
            super(test_1, self).__init__()
            self.when = ['1 == 1']

    c = test_1()

    assert c.evaluate_conditional(None, None)

    # Then we test the case where the conditional is evaluated to false
    class test_2(Conditional):
        def __init__(self):
            super(test_2, self).__init__()
            self.when = ['1 == 2']

    c = test_2()

    assert not c.evaluate_conditional(None, None)

    # Now we test the case where a conditional contains defined/undefined tests

# Generated at 2022-06-22 14:09:25.376284
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    hosts = { 'foo': [None] }
    play_context = PlayContext(loader=loader, new_stdin=None, prompt_uuid=None)

    # Regular tests
    conditional = 'hostvars["foo"] is undefined and hostvars["bar"] is defined and play_hosts["foo"] is undefined and play_hosts["bar"] is defined'

# Generated at 2022-06-22 14:10:01.048761
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestConditional(Conditional):
        def __init__(self):
            from ansible.parsing.vault import VaultLib
            from ansible.vars.manager import VariableManager
            from ansible.template import Templar
            from ansible.vars.unsafe_proxy import UnsafeProxy
            from ansible.vars import DataLoader

            loader = DataLoader()
            vault_secrets = VaultLib(loader.get_vault_secrets())
            self._variable_manager = VariableManager(loader=loader, vault_secrets=vault_secrets)
            self._templar = Templar(loader=loader, variables=self._variable_manager)

    test_conditional = TestConditional()

    assert test_conditional.evaluate_conditional(test_conditional._templar, {}) == True
    test_

# Generated at 2022-06-22 14:10:08.032443
# Unit test for constructor of class Conditional
def test_Conditional():
    '''
    I will test all the methods of class Conditional
    '''

    ###################################################################
    # test Conditional
    ###################################################################
    c = Conditional()
    # this class is a mix-in, so we need to set the loader
    c._loader = Mock()
    try:
        c.evaluate_conditional(Mock(), Mock())
    except Exception as e:
        print (e.message, e.__class__.__name__)
    else:
        print('Test 1 failed')

    ###################################################################
    # test Conditional
    ###################################################################
    c = Conditional()
    try:
        c.evaluate_conditional(Mock(), Mock())
    except Exception as e:
        print (e.message, e.__class__.__name__)

# Generated at 2022-06-22 14:10:09.647348
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # TODO
    pass


# Generated at 2022-06-22 14:10:22.481334
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    display_param = dict(foo = 'bar')
    play_context = PlayContext(display=display_param)

    def test_evaluate_conditional(conditional, variable, value, result, display_param=None):
        context = {'play_context': play_context}
        display.__dict__.update(display_param or {})
        c = Conditional()
        c.when = [conditional]
        templar = Templar(loader=None, variables=variable)
        v = c.evaluate_conditional(templar, value)

# Generated at 2022-06-22 14:10:35.380861
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Test case 1:
    c = Conditional()
    c.when = [u'False', u'True', u'NonEmpty']
    templar = object()
    all_vars = object()
    result = c.evaluate_conditional(templar, all_vars)
    assert(result == False)

    # Test case 2:
    c = Conditional()
    c.when = [u'True', u'True', u'NonEmpty']
    templar = object()
    all_vars = object()
    result = c.evaluate_conditional(templar, all_vars)
    assert(result == True)

    # Test case 3:
    c = Conditional()
    c.when = [u'False', u'False', u'NonEmpty']
    templar = object()

# Generated at 2022-06-22 14:10:48.589728
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    variable_manager.set_variable("myvar", 'myvalue')
    variable_manager.set_variable("myvar2", 'myvalue2')
    variable_manager.set_variable("myvar3", 'myvar4')
    variable_manager.set_variable("myvar4", 'myvalue4')
    variable_manager.set_variable("myvar5", None)
    variable_manager.set_variable("myvar6", [])
    variable_manager.set_variable("myvar7", {})
    variable_manager.set_variable("myvar8", '')
    variable_manager.set_variable("myvar9", True)
   

# Generated at 2022-06-22 14:11:02.543034
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    fixture_path = os.path.join(os.path.dirname(__file__), '../fixtures')
    fixture_path = os.path.abspath(fixture_path)

    test_vars = VariableManager()
    test_loader = DataLoader()
    test_env = Environment(loader=test_loader)
    test_env.filters = C.DEFAULT_JINJA2_FILTERS.copy()

    test_templar = Templar(loader=test_loader, variables=test_vars, env=test_env)

    test_conds = list()
    test_conds.append(['False', 'False'])
    test_conds.append([True, 'True'])
    test_conds.append(['True', 'True'])

# Generated at 2022-06-22 14:11:16.183846
# Unit test for method evaluate_conditional of class Conditional