

# Generated at 2022-06-22 14:01:37.470105
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    res = conditional.extract_defined_undefined(
        "hostvars['hostname'] is defined or hostvars['hostname'] is not defined"
    )
    expected = [
        ('hostvars[\'hostname\']', 'is', 'defined'),
        ('hostvars[\'hostname\']', 'is not', 'defined'),
    ]
    assert expected == res



# Generated at 2022-06-22 14:01:44.668717
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.template.template import AnsibleTemplate

    play_context = PlayContext()
    variable_manager = VariableManager()
    hostvars = HostVars(loader=None, variables=dict())

    test_host = "testhost01.example.com"
    test_task = TaskInclude("test_task", None)

    class Conditional_evaluate_conditional_subclass(Conditional):
        pass

    class Conditional_evaluate_conditional_subsubclass(Conditional_evaluate_conditional_subclass):
        pass


# Generated at 2022-06-22 14:01:53.079683
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from jinja2.environment import Environment
    from jinja2.loaders import DictLoader

    from ansible.plugins import module_loader
    from ansible.template import Templar
    from ansible.vars import VariableManager


# Generated at 2022-06-22 14:02:01.271390
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # test evaluate_conditional against a dummy class
    class DummyClass(Conditional):
        _when = [
            'inventory_hostname == "localhost"',
            'inventory_hostname == "localhost" and foo',
            'bar',
        ]

    dc = DummyClass()
    # simulate the templar object
    class DummyTemplar(object):
        def __init__(self):
            self.environment = None
            self.available_variables = {'inventory_hostname': 'localhost', 'bar': False}

        def template(self, data):
            return data

        def is_template(self, data):
            return False

    dt = DummyTemplar()

    assert dc.evaluate_conditional(dt, dt.available_variables) is False, "unexpected result"


#

# Generated at 2022-06-22 14:02:13.985130
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    # Test valid inputs

# Generated at 2022-06-22 14:02:20.040831
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    c = Conditional()
    # no exception if the conditional is True
    c._check_conditional('1==1', None, {})
    # no exception if the conditional is False
    c._check_conditional('1==2', None, {})
    # no exception if the conditional is True and we are looking for undefined variables
    c._check_conditional('1==1 and foo is undefined', None, {})
    # exception if the conditional is False and we are looking for undefined variables
    try:
        c._check_conditional('1==2 and foo is undefined', None, {})
        assert False
    except AnsibleUndefinedVariable as e:
        assert str(e) == "error while evaluating conditional (1==2 and foo is undefined): 'foo' is undefined"
    # no exception if the conditional is True and we are looking for defined variables

# Generated at 2022-06-22 14:02:20.541824
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c is not None

# Generated at 2022-06-22 14:02:25.309953
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    play_context = PlayContext(variables=dict(name='value'))
    templar = Templar(None, play_context)
    assert Conditional().evaluate_conditional(templar, dict()) is True

# Generated at 2022-06-22 14:02:33.973076
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.base import Base
    from ansible.template import Templar

    class TestClass(Base, Conditional):
        pass

    t1 = TestClass()
    t1._ds = {'test_var': 'test1 value'}
    t1.when = [
        "{{ test_var }} == 'test1 value'",
        "{{ test_var }} == 'test2 value'",
        "{{ test_var }} == 'test3 value'"
    ]
    templar = Templar(loader=None, variables={})

    # Test 1: Test that all
    assert t1.evaluate_conditional(templar, dict()) == True

    # Test 2: Test that first

# Generated at 2022-06-22 14:02:45.355121
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # create environment
    from ansible.template import Templar # module under test
    from ansible.vars import VariableManager # needed by Templar
    from ansible.vars.manager import AnsibleVaultEncryptedUnicode
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import shared_plugin_loader_callbacks
    from jinja2 import Environment, FileSystemLoader
    from collections import namedtuple
    loader = DataLoader()
    passwords = dict(vault_pass='secret')
    inventory = InventoryManager(loader=loader, sources=None)

# Generated at 2022-06-22 14:03:05.092866
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Set up the arguments needed for TaskQueueManager
    variable_manager.set_inventory(inventory)

    variable_manager.extra_vars = \
        {"ec2_instance_name": "test_ec2_instance", "ansible_connection": "ssh"}

    # Create the PlayContext to be used for templating
    play_context = TaskQueueManager.load_play_

# Generated at 2022-06-22 14:03:06.061980
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # TODO
    assert False


# Generated at 2022-06-22 14:03:13.364718
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:03:23.799871
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    loader = DummyLoader()

    # Both create_object and create_conditional method will create an object
    # of Conditional class. It is needed to pass in test_data.
    # test_data is a list of dictionaries. Each dictionary contains information
    # to test each conditional clause set on variables.
    #
    # The way we test is:
    # 1. setup the conds dictionary with all_vars, templar and conditional_clause
    #    from test_data
    # 2. call evaluate_conditional(templar, all_vars) to evaluate the conditional clause
    # 3. Compare result of evaluate_conditional() and expected result.
    #
    # If the test is for 'when one of item is true', we need to create multiple
    # variables and set them in all_vars, with values to make one

# Generated at 2022-06-22 14:03:33.791091
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional1 = "some_var is defined"
    conditional2 = "some_var is undefined"
    conditional3 = "some_var is defined or some_var1 is defined"

    assert Conditional().extract_defined_undefined(conditional1) == [("some_var", "is", "defined")]
    assert Conditional().extract_defined_undefined(conditional2) == [("some_var", "is", "undefined")]
    assert Conditional().extract_defined_undefined(conditional3) == [("some_var", "is", "defined"), ("some_var1", "is", "defined")]



# Generated at 2022-06-22 14:03:43.278506
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={'a': 1, 'b': 2})
    conditional = Conditional()
    conditional.when = ['a == 1', 'b == 2']

    assert conditional.evaluate_conditional(templar, None)

    conditional.when = ['a == 2', 'b == 2']
    assert not conditional.evaluate_conditional(templar, None)

# Generated at 2022-06-22 14:03:47.072301
# Unit test for constructor of class Conditional
def test_Conditional():
    # Test calls
    conditional = Conditional()
    conditional = Conditional(loader='loader')

    # Test attributes after constructor execution
    assert hasattr(conditional, '_ds') == False and hasattr(conditional, '_loader') == True


# Generated at 2022-06-22 14:03:51.140528
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.conditional import Conditional
    c = Conditional()
    conditional = 'foobar is defined and (baz is not defined or baz in group_names)'
    assert c.extract_defined_undefined(conditional) == [ ('foobar', 'is', 'defined'), ('baz', 'is not', 'defined'), ('baz', 'is', 'undefined') ]


# Generated at 2022-06-22 14:04:02.076921
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert [('foo', 'is', 'defined'), ('bar', 'is', 'defined'), ('baz', 'is', 'defined')] == conditional.extract_defined_undefined('foo is defined and bar is defined and baz is defined')
    assert [('foo', 'is', 'defined')] == conditional.extract_defined_undefined('foo is defined')
    assert [('foo', 'is', 'defined')] == conditional.extract_defined_undefined('foo is defined and (bar is defined or baz is defined)')
    assert [('bar', 'is', 'not')] == conditional.extract_defined_undefined('foo is defined and bar is not defined or baz is defined')

# Generated at 2022-06-22 14:04:09.570147
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # no defined/undefined test in conditional
    cond = "this is a conditional without defined/undefined test"
    assert Conditional.extract_defined_undefined(Conditional(), cond) == []
    # some defined/undefined test in conditional
    cond = "defined(var1) is defined and undefined(var2) is undefined and var3 is not defined"
    def_undef_list = Conditional.extract_defined_undefined(Conditional(), cond)
    assert len(def_undef_list) == 6
    assert [def_undef[0] for def_undef in def_undef_list] == ['var1', 'var2', 'var2', 'var3', 'var3', 'var3']

# Generated at 2022-06-22 14:04:25.569458
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class testConditionalClass(Conditional):
        pass

    ansible = testConditionalClass()
    conditionals = [
        ("foo is not defined and bar is defined",  [("foo", "is not", "defined"), ("bar", "is", "defined")]),
        ("baz is not undefined",                  [("baz", "is not", "undefined")]),
        ("foo is defined",                       [("foo", "is", "defined")]),
        ("bar is not defined",                   [("bar", "is not", "defined")]),
        ("hostvars['foo'] is defined",           [("hostvars['foo']", "is", "defined")]),
    ]

    for cond, result in conditionals:
        extracted = ansible.extract_defined_undefined(cond)
        assert extracted == result


# Generated at 2022-06-22 14:04:38.094652
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    def _wrap(thing):
        return getattr(thing, '__UNSAFE__', thing)

    # Tests not using templating engine
    assert False == Conditional().evaluate_conditional(Templar(VariableManager(), PlayContext()), dict(a=1))
    assert True == Conditional().evaluate_conditional(Templar(VariableManager(), PlayContext()), dict(a=True))
    assert False == Conditional().evaluate_conditional(Templar(VariableManager(), PlayContext()), dict(a=False))

# Generated at 2022-06-22 14:04:46.675608
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Patch the module being imported
    import ansible.playbook
    old_Base = ansible.playbook.Base
    del ansible.playbook.Base

    def Base(*args, **kwargs):
        return Conditional(*args, **kwargs)

    ansible.playbook.Base = Base

    from ansible.playbook.conditional import Conditional
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # Create an instance of Conditional
    conditional = Conditional()
    # Create an instance of Templar
    templar = Templar(loader=None)
    templar._available_variables = dict()
    templar._available_variables['yoyo'] = 'y'
    templar._available_variables['foo'] = 'bar'
   

# Generated at 2022-06-22 14:04:56.196641
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # prepare host.
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.host import Host
    test_host = Host(name='test_host')

    # prepare variables.
    all_vars_dict = dict()
    all_vars_dict['test_var'] = 'test_val'
    all_vars_dict['test_var2'] = 'test_val2'
    all_vars_dict['test_var3'] = 'test_val3'
    all_vars_dict['test_var4'] = 'test_val4'

# Generated at 2022-06-22 14:05:08.011848
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar

    class my_vars(object):
        '''
        A simple object to test evaluation of vars in conditional, by implementing
        dictionary interface
        '''

        def __init__(self):
            self.vars = {}

        def __getitem__(self, key):
            try:
                return self.vars[key]
            except KeyError:
                raise AnsibleUndefinedVariable()

    class my_cond(Conditional):
        '''
        A subclass of Conditional, with templar updated to my_vars
        '''

        def __init__(self, loader=None):
            self.vars = my_vars()
            self.templar = Templar(loader=loader, variables=self.vars)
            super(my_cond, self).__init__

# Generated at 2022-06-22 14:05:16.658048
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    pb = Playbook()
    play = Play().load(dict(name='test', hosts=['all'], gather_facts='no',
                            tasks=[dict(action='debug', msg='msg here'),
                                   dict(action='debug', msg='{{ "msg here" | upper }}')]))
    pb._entries.append(play)
    pb.vars = dict(test1='test1', test2='test2')
    pb.hostvars = dict()
    pb.basedir = './test/units/'
    pb.register['registered_var'] = 'value'

    # test1
    conditional = Conditional()
    conditional._loader, conditional._basedir = pb._loader, pb

# Generated at 2022-06-22 14:05:26.540335
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # This method requires two arguments:
    #   - templar: an object of class AnsibleTemplar with attribute `template`
    #   - all_vars: a dict of all variables available to the templar

    from ansible.template import Templar, AnsibleUndefinedVariable, AnsibleForLoopRef
    from ansible.vars.manager import VariableManager

    # Create a mock object of class AnsibleTemplar, with attribute `template`
    # returning the argument of function `template`
    templar = Templar(None)
    templar.template = lambda x: x

    # Create a mock object of class VariableManager
    variable_manager = VariableManager()

    # Add some variables to the variable manager

# Generated at 2022-06-22 14:05:35.224185
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    return a list of definitions or undefined
    '''
    t = Conditional()
    # test only one definition
    conditional = 'hostvars["foo"] is defined or hostvars["buz"] is undefined'
    res = [('hostvars["foo"]', 'is', 'defined'), ('hostvars["buz"]', 'is', 'undefined')]
    assert res == t.extract_defined_undefined(conditional)

    # test two definitions
    conditional = 'hostvars["foo"] is defined or hostvars["buz"] is not defined'
    res = [('hostvars["foo"]', 'is', 'defined'), ('hostvars["buz"]', 'is not', 'defined')]
    assert res == t.extract_defined_undefined(conditional)

    # test empty string

# Generated at 2022-06-22 14:05:47.384745
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    print("IN test_Conditional_extract_defined_undefined")

    # Create a conditional object
    assignment = {}
    def load_callback(loader, path, name, column, lineno):
        if name not in assignment:
            assignment[name] = 42
    display.verbosity = 4
    conditional = Conditional(loader=load_callback)

    # Get a list of expected values from extract_defined_undefined

# Generated at 2022-06-22 14:05:59.025586
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    class TestTask(object):
        def __init__(self, when_value):
            self._ds = None
            self.when = when_value

    task = TestTask('item == "foo" and item2 == [1, 2, 3]')
    templar = Templar(loader=None)
    result = task.evaluate_conditional(templar, dict(item='foo', item2=[1, 2, 3]))
    assert result is True

    task = TestTask('item == "foo" and item2 == [1, 2, 3]')
    templar = Templar(loader=None)
    result = task.evaluate_conditional(templar, dict(item='bar', item2=[1, 2, 3]))
    assert result is False


# Generated at 2022-06-22 14:06:23.889265
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    c = Conditional()
    pc = PlayContext()
    t = Templar(loader=None, variables={'a': 1, 'b': 2, 'c': 3})

    # Test various permutations of: foo is defined
    assert c._check_conditional("a is defined", t, t._available_variables)
    assert not c._check_conditional("z is defined", t, t._available_variables)

    # Test various permutations of: foo is not defined
    assert c._check_conditional("z is not defined", t, t._available_variables)
    assert not c._check_conditional("a is not defined", t, t._available_variables)

    # Test various permutations of: foo is undefined
   

# Generated at 2022-06-22 14:06:34.369020
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Initialization of class Conditional
    conditional = Conditional()

    # Unit test for method evaluate_conditional of class Conditional
    # with no conditional set
    conditional.when = []
    assert conditional.evaluate_conditional(None, None)
    conditional.when = ['dummy_1']
    assert not conditional.evaluate_conditional(None, None)
    # We do not specify 'conditional.when' to retain the value of 'dummy_1'
    assert not conditional.evaluate_conditional(None, None)

    # Unit test for method evaluate_conditional of class Conditional
    # with boolean values for conditional
    conditional.when = [False]
    assert not conditional.evaluate_conditional(None, None)
    conditional.when = [True]
    assert conditional.evaluate_conditional(None, None)
    # We do

# Generated at 2022-06-22 14:06:46.319360
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo not is defined") == [('foo', 'not is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo not is undefined") == [('foo', 'not is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_

# Generated at 2022-06-22 14:06:54.522889
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.task import Task
    from ansible.template import Templar

    t = Templar(variables={})
    c = Conditional()

    # check case when conditional is '', None, or False
    assert c.evaluate_conditional(t, {})
    c.when = None
    assert c.evaluate_conditional(t, {})
    c.when = False
    assert not c.evaluate_conditional(t, {})

    # check simple variable lookup
    c.when = 'foo is defined'
    assert not c.evaluate_conditional(t, {})
    c.when = 'foo is defined'
    assert c.evaluate_conditional(t, {'foo': 1})

    # check variable expansion in the conditional
    c.when = 'foo is defined and {bar}'
    assert not c

# Generated at 2022-06-22 14:07:07.843867
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    my_task = Task()
    my_task._role = None
    my_task._parent = IncludeRole()
    my_task._role._role_path = "/etc/ansible/roles/common"
    my_task.action = "debug"
    my_task.args = dict(msg="This is a test message")

# Generated at 2022-06-22 14:07:17.550228
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    # Create a trivial class to make it easy to mock attribute methods
    class Trivial(Conditional):
        def __init__(self, when_str):
            self.when = when_str
            super(Trivial, self).__init__()

    # Create a host and add some needed faked data
    host = Host()
    host.vars = HostVars(host=host)
    host.vars.update({'ansible_eth0': {'ipv4': {'address': '192.168.1.1'}}})
    host.vars.update({'foo': 'bar'})

# Generated at 2022-06-22 14:07:26.497630
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    class MyClass(Conditional):
        pass

    class MyVarsModule(object):
        def __init__(self):
            self.vars = {
                'name1': True,
                'name2': False,
            }

        def get_vars(self, loader, path, entities, cache=True):
            return self.vars

    class MyData(object):
        def __init__(self, data):
            self._data = data

    class MyLoader(object):
        def __init__(self):
            self._templar = Templar(loader=self)
            self._vars_cache = dict()

        def get_vars(self, play):
            return self._templar.v

# Generated at 2022-06-22 14:07:31.616837
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    def _check(cond, hostvars, allow_lookups, expect):
        play_context = PlayContext()
        play_context._vars_per_host = hostvars
        templar = Templar(loader=None, variables=play_context.variables)
        conditional = Conditional(loader=None)
        result = conditional.evaluate_conditional(templar, variables=play_context.variables)
        assert result == expect

    hosts = ['a', 'b', 'c']
    hostvars = dict(zip(hosts, [
        dict(foo='foo'),
        dict(bar='bar'),
        dict(foo='foo', bar='bar'),
    ]))

    # Simple cases from the docs
    _

# Generated at 2022-06-22 14:07:42.801794
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    class ConditionalTest(Conditional):
        def __init__(self, loader=None, when_str=None, when_list=None, when_bool=None):
            self._loader = loader
            self.when = when_list or []
            if when_str:
                self.when.append(when_str)
            if when_bool:
                self.when.append(when_bool)

    from ansible.template import Templar

    # This will trigger AnsibleUndefinedVariable exception for two reasons:
    #   1. non-existing variable 'foo'
    #   2. missing double quotes around 'foo'
    class Test_Conditional_evaluate_conditional1(unittest.TestCase):
        def test_basic(self):
            with self.assertRaises(AnsibleUndefinedVariable) as cm:
                Cond

# Generated at 2022-06-22 14:07:48.403076
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert Conditional().extract_defined_undefined('hostvars[foo] is defined') == [('hostvars[foo]', 'is', 'defined')]
    assert Conditional().extract_defined_undefined('hostvars[foo] is defined or foo is not undefined') == [('hostvars[foo]', 'is', 'defined'), ('foo', 'is not', 'undefined')]



# Generated at 2022-06-22 14:08:26.925030
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible import constants as C
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class Foo(Conditional):
        pass

    class Play:
        def __init__(self):
            self.hostvars = {}

    play = Play()

    # init with a very simple set of vars
    play.hostvars = {
        'variable': 'value',
        'variable_with_hyphens': 'value_with_hyphens',
        'variable_with_underscores': 'value_with_underscores',
    }

    # init the class
    f = Foo()
    p = PlayContext()
    t = Templar(loader=None, variables=play.hostvars)

    # Set the play context
    p.prompt = "test"
    p

# Generated at 2022-06-22 14:08:38.598681
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestConditional(Conditional):
        pass

    test_tasks = [
        {
            'name': 'First task',
            'when': '{{ c1 }}',
        },
        {
            'name': 'Second task',
            'when': [
                '{{ c2 }}',
                '{{ c3 }}',
            ],
        },
        {
            'name': 'Third task',
            'when': '{{ c4 }}',
        },
        {
            'name': 'Fourth task',
            'when': [
                '{{ c5 }}',
                '{{ c6 }}',
            ],
        },
    ]

    def _collect_vars(varlist):
        cond_vars = {}

# Generated at 2022-06-22 14:08:51.932437
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition

    # Mock the loader
    class MockLoader:
        def get(self, key, default=None, all_vars=None, wantlist=False):
            return 'my_playbook'
    mock_loader = MockLoader()

    # Mock the templar
    class MockTemplar:
        def __init__(self):
            self.available_variables = {}
            self.environment = None

        def is_template(self, conditional):
            if LOOKUP_REGEX.search(conditional):
                return True
            else:
                return False


# Generated at 2022-06-22 14:09:00.140138
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    conditional = Conditional()
    all_vars = dict(
        foo='123',
        bar='abc',
    )

    def _assert_condition(condition, expected_value):
        assert conditional.evaluate_conditional(templar, all_vars) is expected_value

    # Set up Templar
    play_context = PlayContext()
    templar = Templar(loader=None, variables=play_context.update_vars(all_vars))

    # Normal conditions
    _assert_condition('foo == 123', True)
    _assert_condition('bar == "abc"', True)
    _assert_condition('foo != 123', False)
    _assert_condition('bar != "abc"', False)
    _assert

# Generated at 2022-06-22 14:09:12.194730
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class Test:
        pass

    test = Test()

# Generated at 2022-06-22 14:09:25.197896
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    display.verbosity = 3
    conditionalObject = Conditional()

    templar = {}
    all_vars = {}

    # case 1
    conditional1 = "1"
    actual_result1 = conditionalObject._check_conditional(conditional1, templar, all_vars)
    expected_result1 = True
    assert actual_result1 == expected_result1

    # case 2
    conditional2 = "1==1"
    actual_result2 = conditionalObject._check_conditional(conditional2, templar, all_vars)
    expected_result2 = True
    assert actual_result2 == expected_result2

    # case 3
    conditional3 = '''"{{a}}" != "{{b}}"'''

# Generated at 2022-06-22 14:09:34.687712
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    task = Task.load(dict(action='test', when='abc'), loader=None, play=None)
    assert task.when == ['abc']

    block = Block.load(dict(block, tasks=[task]), loader=None, play=None)
    assert block.when == ['abc']

    task = Task.load(dict(action='test', when='abc'), loader=None, play=None)
    assert task.when == ['abc']

    block = Block.load(dict(block, when='def', tasks=[task]), loader=None, play=None)
    assert block.when == ['def']

    task = Task.load(dict(action='test', when='abc'), loader=None, play=None)
    assert task.when

# Generated at 2022-06-22 14:09:35.944955
# Unit test for constructor of class Conditional
def test_Conditional():
    C()


# Generated at 2022-06-22 14:09:42.587791
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:09:46.966247
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    module_vars_dict = {
        'one': '1',
        'two': '2',
        'three': '3',
        'four': '4',
        'ansible_check_mode': False,
        'bad_var': '{{foo}}',
        'word1': 'word',
        'word2': 'Word',
    }

    class MockBase:
        name = 'testcond'
        _ds = dict()

    class TestConditional(MockBase, Conditional):
        pass

    test_cond = TestConditional()
    test_cond._loader = lambda x: x  # noqa
    templar = Templar(loader=None, variables=module_vars_dict)

# Generated at 2022-06-22 14:10:59.642601
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    import types
    conditional = Conditional()
    assert isinstance(conditional, Conditional)
    assert isinstance(conditional.extract_defined_undefined("hostvars['foo'] is undefined"), list)
    assert conditional.extract_defined_undefined("hostvars['foo'] is undefined") == [("hostvars['foo']", "is", "undefined")]
    assert isinstance(conditional.extract_defined_undefined("'foo' is undefined"), list)
    assert conditional.extract_defined_undefined("'foo' is undefined") == [("'foo'", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]

# Generated at 2022-06-22 14:11:08.368080
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def assert_undefined_variables(str, expected):
        assert expected == Conditional().extract_defined_undefined(str)

    # Test simple conditional with spaces around the logical operator
    assert_undefined_variables(
        "variable_name is undefined",
        [('variable_name', 'is', 'undefined')]
    )

    # Test simple conditional with logical operator without spaces
    assert_undefined_variables(
        "variable_name isundefined",
        [('variable_name', 'is', 'undefined')]
    )

    # Test simple conditional with logical operator without spaces
    assert_undefined_variables(
        "variable_name isundefined",
        [('variable_name', 'is', 'undefined')]
    )

    # Test simple conditional with logical operator without spaces
    assert_undefined

# Generated at 2022-06-22 14:11:19.960562
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    ######################################################################
    #  Preparing test
    ######################################################################
    setattr(C, 'DEFAULT_DEBUG', False)
    setattr(C, 'DEFAULT_SYSTEM_WARNINGS', False)
    setattr(C, 'DEFAULT_FORKS', 1)
    setattr(C, 'DEFAULT_MODULE_LANG', 'C')

    from ansible.playbook import Play
    from ansible.playbook.play import Play as PlaybookPlay
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude

    from ansible.template import Templar
    from ansible.vars import Variable