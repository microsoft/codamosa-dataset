

# Generated at 2022-06-22 14:01:40.417637
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:01:47.078635
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    extracted = conditional.extract_defined_undefined('foo is not defined or beep is defined')
    assert extracted == [['foo', 'is not', 'defined'], ['beep', 'is', 'defined']]



# Generated at 2022-06-22 14:01:57.886587
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Note:
    # - use print to display test result
    # - use self.assert* to check test result

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel

    display = Display()
    class Options(object):
        def __init__(self, vars):
            self.connection = 'local'
            self.remote_user = None
            self.become = False
            self.become_method = None
            self.become_user = None
            self.become_ask_pass = False
            self.verbosity = 3
            self.check = False
            self.vars = vars

    options = Options

# Generated at 2022-06-22 14:02:08.980410
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class TestConditional(Conditional):
        pass

    # Init
    t = TestConditional()

    # Empty input
    assert t.extract_defined_undefined('') == []

    # Test all valid forms:
    # a defined
    # b undefined
    # c not is defined
    # d is defined
    # e is not undefined
    # f not is undefined
    # g not is not defined
    # h not is not undefined
    assert t.extract_defined_undefined('a defined') == [('a', 'not', 'is')]
    assert t.extract_defined_undefined('b undefined') == [('b', 'not', 'is')]
    assert t.extract_defined_undefined('c not is defined') == [('c', 'not', 'is')]
    assert t.ext

# Generated at 2022-06-22 14:02:18.074835
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class test_Conditional_evaluate_conditional(object):
        pass

    class test_Conditional_evaluate_conditional_sub(Conditional, test_Conditional_evaluate_conditional):
        pass

    # In this test we test the failure conditions
    conditional_object = test_Conditional_evaluate_conditional_sub(loader=None)
    all_vars = {}
    conditional_object.when = ["hostvars['host']['var_test1'] == 1"] # This should fail as
                                                                     # 'hostvars' is not available
    conditional_object._templar = None

# Generated at 2022-06-22 14:02:30.741413
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    assert Conditional().evaluate_conditional(None, 'True') is True
    assert Conditional().evaluate_conditional(None, 'false') is False
    assert Conditional().evaluate_conditional(None, '"a string"') is True
    assert Conditional().evaluate_conditional(None, '[]') is True
    assert Conditional().evaluate_conditional(None, '{}') is True
    assert Conditional().evaluate_conditional(None, '0') is True
    assert Conditional().evaluate_conditional(None, 'not True') is False
    assert Conditional().evaluate_conditional(None, 'defined') is False
    assert Conditional().evaluate_conditional(None, 'true and False') is False
    assert Conditional().evaluate_conditional(None, 'True and false') is False

# Generated at 2022-06-22 14:02:43.161307
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    assert True
    class test_class():
      pass
      
    test_class.when = [ u"{{False}}", u"{{False if True else False}}" ]
    test_obj = test_class()
    result = test_obj.evaluate_conditional(None, None)
    assert result == False
    
    test_class.when = [ u"{{False if False else True}}", u"{{True}}" ]
    test_obj = test_class()
    result = test_obj.evaluate_conditional(None, None)
    assert result == True
    
    test_class.when = [ u"{{True}}", u"{{False}}" ]
    test_obj = test_class()
    result = test_obj.evaluate_conditional(None, None)
    assert result == True
    
    test_class

# Generated at 2022-06-22 14:02:55.584390
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.vars.manager import VariableManager
    from ansible.template.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    templar = Templar(
        loader=loader,
        variable_manager=variable_manager,
        vault_secrets=['vault_password']
    )

    variable_manager.set_nonpersistent_facts(dict(templar_test_unquoted_string='"string"'))

    cond = Conditional()

# Generated at 2022-06-22 14:03:07.084603
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Run unit tests to test the method evaluate_conditional of class
    Conditional.
    '''
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    tests = [
        (
            'this is a conditional',
            'this is a conditional',
            {},
            None,
            'The conditional check \'this is a conditional\' failed. The error was: ' +
            'error while evaluating conditional (this is a conditional): ' +
            'undefined variable: this',
        ),
    ]

    loader = DataLoader()
    variable_manager = VariableManager(loader)
    templar = Templar(loader, variable_manager)
    conditional = Conditional(loader=loader)


# Generated at 2022-06-22 14:03:13.435061
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    res = Conditional(None).extract_defined_undefined("hostvars['foo'] is defined")
    assert res == [('hostvars[foo]', 'is', 'defined')]

    res = Conditional(None).extract_defined_undefined(
        "hostvars['foo'] is defined or hostvars['bar'] is not defined and 'foo' not in hostvars and hostvars['baz'] not in ['a','b','c']"
    )
    assert res == [('hostvars[foo]', 'is', 'defined'), ('hostvars[bar]', 'is not', 'defined'), ('hostvars[baz]', 'not in', 'defined')]

    res = Conditional(None).extract_defined_undefined("")
    assert res == []


# Generated at 2022-06-22 14:03:34.526713
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import ansible.executor.task_result as task_result
    import ansible.inventory.host as host
    import ansible.utils.unsafe_proxy as unsafe_proxy
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext

    # Prepare a fake task object because Task is a class and not an object.
    fake_result = task_result.TaskResult()
    fake_result._host = host.Host("localhost")
    fake_result._task = Task()
    fake_result._task._role = None
    fake_result._task._parent = None
    fake_result._task.action = "test stuff"
    fake_result._task.args = {}
   

# Generated at 2022-06-22 14:03:47.120408
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
        This is a unit test for the method evaluate_conditional of the class Conditional
        The syntax for its use is:
            python -m ansible.playbook.conditional test_Conditional_evaluate_conditional

        The results from each run of the test are appended to a file.
        The name of the file is:  result.txt

        The version used for these tests is:  ansible 2.4.0.0
    '''

    #
    # input arguments
    #

    # set the values for the arguments
    cond_name              = 'foo'
    cond_check             = 'bar'
    # cond_loader            = None
    # cond_ds                = None

    # create a Conditional object
    test_conditional = Conditional()
    #
    # call the Conditional method
    #

   

# Generated at 2022-06-22 14:03:53.794991
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    ''' Conditional: unit tests for method evaluate_conditional '''
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    import ansible.constants as C
    import os
    import tempfile
    import shutil

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(HostVars(loader=loader,
                                            inventory=None))
    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-22 14:04:05.318910
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    display.verbosity = 3
    display.debug("test_Conditional_evaluate_conditional() called")


# Generated at 2022-06-22 14:04:17.672423
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_class = Conditional()
    assert [] == conditional_class.extract_defined_undefined("toto")
    assert [] == conditional_class.extract_defined_undefined("toto is defined")
    assert [("toto", "is", "defined")] == conditional_class.extract_defined_undefined("toto is defined and lala is undefined")

    assert [("toto", "not is", "defined"), ("lala", "is", "defined")] == conditional_class.extract_defined_undefined("toto not is defined and lala is defined")
    assert [("toto", "is", "defined")] == conditional_class.extract_defined_undefined("toto is defined and lala not is undefined")
    assert [("toto", "is", "undefined")] == conditional_class.ext

# Generated at 2022-06-22 14:04:25.979990
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-22 14:04:30.926855
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    def test(conditional, templar, all_vars, res):
        c = Conditional()
        c.when = [conditional]
        assert(c.evaluate_conditional(templar, all_vars) == res)

    class Templar:
        @staticmethod
        def is_template(test):
            return test.find('{{') != -1 or test.find('{%') != -1

        @staticmethod
        def template(test, disable_lookups):
            if not disable_lookups:
                if test.find('{{') != -1:
                    test = test.replace('{{', '__SAFE__').replace('}}', '__UNSAFE__')

# Generated at 2022-06-22 14:04:42.613543
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    t = Templar(loader=None)
    c = Conditional()
    c.when = ['a', 'b', 'c']

    def mock_is_template(s):
        """ Mock function to test the conditional.
        """
        if s in ('a', 'b', 'c'):
            return True
        return False

    templar_is_template_orig = Templar.is_template
    Templar.is_template = mock_is_template

    def mock_template(s, disable_lookups=False):
        """ Mock function to test the conditional.
        """
        if s in ('a', 'b', 'c'):
            return s + '_evaluated'
        return 'd'

    templar_template_orig = Templar.template
    Templar.template = mock_template

# Generated at 2022-06-22 14:04:54.013246
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.play_context import PlayContext

    class Task(Conditional):
        def __init__(self, play_context=PlayContext(), loader=None):
            self._play_context = play_context
            super(Task, self).__init__(loader=loader)

        def set_loader(self, loader):
            self._loader = loader

        def get_vars(self):
            return dict()

    class Play(object):
        def __init__(self, play_context=PlayContext(), loader=None):
            self._play_context = play_context
            self._loader = loader

        # this is used by Conditional.evaluate_conditional() to get the variables (see get_vars() in Conditional)
        def get_variable_manager(self):
            return self


# Generated at 2022-06-22 14:05:05.771621
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import sys
    class DummySudoable(object):
        def __init__(self):
            self._ds = 'dummy'
            self._loader = None
            self._play = None
            self._play_context = None
            self._task = None
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    # If ansible is not installed on system, set ansible path to test path
    if sys.path[0] == '.':
        sys.path.insert(0, 'test/lib')

    ds = DummySudoable()
    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-22 14:05:25.882639
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    conditional = Conditional()

    assert conditional. evaluate_conditional(
        templar=templar,
        all_vars={'hostvars': {'localhost': {'ansible_host': '127.0.0.1', 'ansible_password': '123'}}, 'inventory_hostname': 'localhost'}
    ) is True

    conditional._when = ['{% if not "localhost" in groups["test"] %}', '{% endif %}']

# Generated at 2022-06-22 14:05:38.175412
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    display.verbosity = 3
    # Test the early return conditions
    assert Conditional().evaluate_conditional(None, None) is True
    assert Conditional().evaluate_conditional(None, None, None) is True

    # Test an actual conditional
    host = object()
    all_vars = dict(hostvars=dict(host=host))
    assert Conditional().evaluate_conditional(
        Templar(all_vars), all_vars, dict(hostvars=host)
    ) is True
    assert Conditional().evaluate_conditional(
        Templar(all_vars), all_vars, dict(hostvars='another_host')
    ) is False

    # Test evaluating a conditional for an undefined variable
    all_vars = dict(hostvars=dict(host=host))

# Generated at 2022-06-22 14:05:49.260375
# Unit test for constructor of class Conditional
def test_Conditional():

    from ansible.playbook import PlayBook
    from ansible.playbook.play_context import PlayContext

    pb = PlayBook(
        playbook     = 'test_conditional.yml',
        loader       = PlayBook.loader,
        variable_manager = PlayBook.variable_manager,
        inventory    = PlayBook.inventory,
        host_list    = C.DEFAULT_HOST_LIST,
        callbacks    = PlayBook.callbacks,
        runner_callbacks = PlayBook.runner_callbacks,
    )

    play_context = PlayContext()
    play_context.become = False
    templar = pb.variable_manager.extra_vars.copy()

# Generated at 2022-06-22 14:05:59.663372
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.vars import VariableManager
    from ansible.utils.display import Display
    from ansible.template import Templar
    from units.mock.plugins.strategy import ActionModule
    from units.mock.plugins.filter import FilterModule
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.cli import CLI
    from ansible.parsing.dataloader import DataLoader
    import sys

    display = Display()
    cl

# Generated at 2022-06-22 14:06:10.570706
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    def equal_and_sorted(first_list, second_list):
        return (first_list == second_list) and (first_list.sort() == second_list.sort())

    conditional = Conditional()
    assert equal_and_sorted(
        conditional.extract_defined_undefined('var1 is defined and var2 == "foo"'),
        [('var1', 'is', 'defined'), ('var2', '==', None)]
    )
    assert equal_and_sorted(
        conditional.extract_defined_undefined('var1 == "foo" and var2 is defined'),
        [('var2', 'is', 'defined'), ('var1', '==', None)]
    )

# Generated at 2022-06-22 14:06:22.505720
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    #make a test inventory
    myinventory = InventoryManager(loader=DataLoader())

    # Instatiate a test host
    myhost = myinventory.get_host("myhost")

    # Mock task_vars for testing "when" statement
    # with ansible_facts.
    task_vars = {
        'ansible_facts': {
            'distribution': 'debian',
            'distribution_major_version': '7',
            'distribution_release': 'wheezy',
            'distribution_version': '7.0',
            'os_family': 'Debian',
        },
    }

    # Create fake task to set self

# Generated at 2022-06-22 14:06:33.356854
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import sys
    if sys.version_info < (2, 7):
        return
    import unittest

    import ansible.template.template as template

    class FakePlayContext(object):
        def __init__(self):
            pass

    class FakeVariableManager(object):
        def __init__(self):
            pass

    class TestConditionalEvaluation(unittest.TestCase):
        def setUp(self):
            self.fakePlayContext = FakePlayContext()
            self.fakeVariableManager = FakeVariableManager()
            self.templar = template.Templar(loader=None, variable_manager=self.fakeVariableManager,
                                            shared_loader_obj=None)

        def test_truthy_conditional(self):
            conditional = 'foo == "foo"'
            all_vars = dict

# Generated at 2022-06-22 14:06:45.384157
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template.template import Templar

    p = PlayContext()
    p.hostvars = dict(test_host=dict(test_var='test_value'))
    t = Templar(loader=None, variables=dict(var='test'))
    c = Conditional(loader=None)

    def throw(msg):
        raise Exception(msg)

    def test(conditional, truth_value, templar=t, all_vars=p.hostvars):
        if c.evaluate_conditional(templar, all_vars) != truth_value:
            throw("Error with conditional: {0}".format(conditional))

    # --- Tests for Conditional.evaluate_conditional ---

    # Tests for syntax not allowed in conditionals
    test

# Generated at 2022-06-22 14:06:50.528706
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    test_string = "var1 not is defined and var2 is defined and var3 is undefined or var4 is defined"
    result = [('var1', 'not is', 'defined'), ('var2', 'is', 'defined'), ('var3', 'is', 'undefined'), ('var4', 'is', 'defined')]
    assert result == cond.extract_defined_undefined(test_string)



# Generated at 2022-06-22 14:06:56.733314
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    loader = DictDataLoader(dict())
    jinja_env = JinjaEnvironment(loader, undefined=StrictUndefined)
    templar = Templar(loader=loader, variables={'a': 1, 'b': {'x': 'foo'}}, environment=jinja_env)
    conditional = Conditional(loader=loader)

    # Test basic when/then conditional
    assert conditional.evaluate_conditional(templar, dict()) is True
    assert conditional._check_conditional("1 == 1", templar, dict())

    # Check that we can return non-booleans
    assert conditional._check_conditional("1", templar, dict()) == 1

    # Test that undefined variables fail
    assert conditional._check_conditional("Z == 1", templar, dict()) is False

# Generated at 2022-06-22 14:07:21.806322
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook import PlayBook
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    pb = PlayBook(
        loader=loader,
        playbook=[
            dict(
                hosts='all',
                gather_facts='no',
                tasks=[
                    dict(
                        action=dict(
                            module='command',
                            args=dict(
                                cmd='/bin/foo'
                            )
                        ),
                        when='cluster.server != 1'
                    )
                ]
            )
        ]
    )

    p = pb.get_plays()
    t = p[0].get_tasks()
    task = Task.load(t[0], play=p[0])

# Generated at 2022-06-22 14:07:33.787001
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    a = Conditional()
    assert a.extract_defined_undefined('cond1') == []
    assert a.extract_defined_undefined('cond1 and cond2') == []
    assert a.extract_defined_undefined('cond1 and cond2 and cond3') == []
    assert a.extract_defined_undefined('cond1 and cond2 and cond3 and cond4') == []
    assert a.extract_defined_undefined('cond1 and cond2 and cond3 or cond4') == []
    assert a.extract_defined_undefined('cond1 and cond2 or cond3 and cond4') == []
    assert a.extract_defined_undefined('cond1 or cond2 and cond3 and cond4') == []

# Generated at 2022-06-22 14:07:44.271025
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert list(Conditional().extract_defined_undefined('')) == []
    assert list(Conditional().extract_defined_undefined('a')) == []
    assert list(Conditional().extract_defined_undefined('(a)')) == []
    assert list(Conditional().extract_defined_undefined('(a or b)')) == []
    assert list(Conditional().extract_defined_undefined('a is defined')) == [('a', 'is', 'defined')]
    assert list(Conditional().extract_defined_undefined('(a is defined)')) == [('a', 'is', 'defined')]
    assert list(Conditional().extract_defined_undefined('a is not defined')) == [('a', 'is not', 'defined')]

# Generated at 2022-06-22 14:07:53.452748
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

# Generated at 2022-06-22 14:08:04.603963
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    cases = []
    # Case 1
    # Confirm that if there is no when statement in the class, it returns True
    # when there is no when condition.
    # (conditional, all_vars, result)
    cases.append( ("", {}, True) )

    # Case 2
    # Confirm that if there is no when statement in the class, it returns False
    # when there is a when condition.
    # (conditional, all_vars, result)
    cases.append( ("ansible_hostname == 'test'", {}, False) )

    # Case 3
    # Confirm that if there is a when statement in the class, it returns True
    # when there is no when condition.
    # (conditional, all_vars, result)
    cases.append( (None, {}, True) )

   

# Generated at 2022-06-22 14:08:18.099280
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    d = dict(
        a = dict(
            b = "{{x}}",
            c = "{{y}}",
            d = "{{z}}",
            e = True
        )
    )

    # variables
    z = 10
    y = dict(
        z1 = 10,
        z2 = 20
    )
    x = dict(
        y1 = dict(
            z1 = 10,
            z2 = 20
        ),
        y2 = dict(
            z1 = 30,
            z2 = 40
        )
    )

    # test

    # ---------------------------------------
    # True

    # 1
    # (a.b == x.y1.z1) and (a.c == x.y1)

# Generated at 2022-06-22 14:08:29.531914
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    class MyModule:
        def __init__(self,_loader,_path,_vars):
            self._loader = _loader
            self._path = _path
            self._vars = _vars

        def get_path(self):
            return self._path

        def get_vars(self):
            return self._vars

        def get_loader(self):
            return self._loader


# Generated at 2022-06-22 14:08:35.333038
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:08:47.351930
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    var_manager = VariableManager()
    var_manager.set_inventory(Inventory(loader=None))

    context = PlayContext()

    templar = Templar(loader=None, variables=var_manager, shared_loader_obj=None)

    play_book = Conditional()
    play_book._ds = {}

    assert play_book._check_conditional(
        'foo in [1, 2, 3]', templar, {}) is False, 'foo in [1, 2, 3] should be False'

    play_book.when = [True]
    assert play_book.evaluate_conditional(templar, {}) is True, 'when should be True'

# Generated at 2022-06-22 14:08:58.385064
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-22 14:09:38.549364
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional(loader=None)


# Generated at 2022-06-22 14:09:48.665878
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible import constants as C
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar


# Generated at 2022-06-22 14:09:59.295700
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class ConditionalObject(Conditional):
        def __init__(self, conditional):
            self._when = conditional

    display.verbosity = 3

# Generated at 2022-06-22 14:10:10.336280
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # test normal
    c = Conditional()
    c.when = ["1 + 1 == 2"]
    c.tags = []
    c.skipped_tags = []
    from ansible.template import Templar
    from ansible.vars import VariableManager
    t = Templar(variable_manager=VariableManager())
    all_vars = dict()
    assert c.evaluate_conditional(t, all_vars)

    # test exception
    try:
        c.when = ["1 + 1 == 3"]
        assert c.evaluate_conditional(t, all_vars)
        assert False
    except Exception as e:
        assert "The conditional check '1 + 1 == 3' failed. The error was: " in to_native(e)

    # test undefined variable
    c.when = ["not test_var"]

# Generated at 2022-06-22 14:10:23.059872
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(current_host="foobar", inventory_hostname="foobar")
    variable_manager.set_nonpersistent_facts(dict(inventory_hostname="foobar"))
    variable_manager.set_inventory(dict(hosts=dict(foobar=dict(ansible_ssh_host="foobar"))))
    play_context = PlayContext()
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None, playcontext=play_context)

    # Test conditional when the evaluated conditional returns False
    cond = Conditional()
    cond.when = [ "0" ]

# Generated at 2022-06-22 14:10:35.559902
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Invoke method extract_defined_undefined of class Conditional
    c = Conditional()
    assert c.extract_defined_undefined("{test_var} is defined") == [('test_var', 'is', 'defined')]
    assert c.extract_defined_undefined("{test_var} is undefined") == [('test_var', 'is', 'undefined')]
    assert c.extract_defined_undefined("{test_var} not is defined") == [('test_var', 'not is', 'defined')]
    assert c.extract_defined_undefined("{test_var} not is undefined") == [('test_var', 'not is', 'undefined')]

# Generated at 2022-06-22 14:10:48.813846
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class TestClass:
        pass

    class TestPlaybook:
        def __init__(self):
            self.set_variable_manager()

        def set_variable_manager(self):
            self.variable_manager = VariableManager()
            self.variable_manager.set_play_context(PlayContext())

        def get_variable_manager(self):
            return self.variable_manager

    class TestPlay:
        def __init__(self):
            self.set_loader()

        def set_loader(self):
            self.loader = DataLoader()

        def get_loader(self):
            return self.loader

    class TestTaskInclude:
        def __init__(self):
            self.clean_reload()



# Generated at 2022-06-22 14:11:02.726751
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("a is defined and b is not defined and c is undefined") == \
        [('a', 'is', 'defined'), ('b', 'is not', 'defined'), ('c', 'is', 'undefined')]
    assert cond.extract_defined_undefined("a is foo and b is bar and c is baz") == []
    assert cond.extract_defined_undefined("a is defined or b is defined and c is defined") == \
        [('a', 'is', 'defined'), ('b', 'is', 'defined'), ('c', 'is', 'defined')]

# Generated at 2022-06-22 14:11:16.387062
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Create a fake class having the required methods (evaluate_conditional)
    # Since this is going to check the parent class, go ahead and create it as well
    class FakeClass:
        pass

    class TestClass(FakeClass, Conditional):
        pass

    # Create the instance of the class
    test_instance = TestClass()

    # Create a fake templar class and instance
    class Templar():
        def __init__(self):
            self.template_data = ''
            self.template_args = {}
            self.environment = ''
            self.vars = {}
            self.is_template = False
            self.template_result = ''

        def is_unsafe(self, a):
            return self.is_template

        def template(self, data, vars=None, **kwargs):
            self.template_

# Generated at 2022-06-22 14:11:20.533507
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    ''' Return a list of tuples
    '''
    conditional = Conditional()
    data = conditional.extract_defined_undefined('hostvars[inventory_hostname] is undefined or hostvars[inventory_hostname] is defined')
    assert isinstance(data, list)
