

# Generated at 2022-06-22 16:27:51.424039
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager)

    task = Task()
    task.when = ['foo is defined']
    task.evaluate_conditional(templar, variable_manager.get_vars(play=play_context))

    task = Task()
    task

# Generated at 2022-06-22 16:28:03.041703
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Test with a simple conditional
    conditional = "hostvars['foo'] is defined"
    c = Conditional()
    assert c.extract_defined_undefined(conditional) == [('hostvars[\'foo\']', 'is', 'defined')]

    # Test with a conditional containing a variable name with a dot
    conditional = "hostvars['foo.bar'] is defined"
    c = Conditional()
    assert c.extract_defined_undefined(conditional) == [('hostvars[\'foo.bar\']', 'is', 'defined')]

    # Test with a conditional containing a variable name with a dot and a space
    conditional = "hostvars['foo.bar'] is not defined"
    c = Conditional()

# Generated at 2022-06-22 16:28:14.535521
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)
    conditional.when = ['foo is defined', 'bar is not defined']

    all_vars = dict(foo='bar')

# Generated at 2022-06-22 16:28:24.993965
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:28:37.217040
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)
    conditional.when = ['{{ test_var }}']
    variable_manager.set_nonpersistent_facts(dict(test_var=True))

# Generated at 2022-06-22 16:28:48.383207
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is not undefined") == [("foo", "is", "defined"), ("bar", "is not", "undefined")]

# Generated at 2022-06-22 16:28:57.415482
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Create a Conditional object
    class TestConditional(Conditional):
        pass
    conditional = TestConditional()

    # Create a PlayContext object
    play_context = PlayContext()

    # Create a Templar object
    templar = Templar(loader=None, variables={})

    # Test with a conditional that evaluates to True
    conditional.when = ['1 == 1']
    assert conditional.evaluate_conditional(templar, play_context)

    # Test with a conditional that evaluates to False
    conditional.when = ['1 == 2']
    assert not conditional.evaluate_conditional(templar, play_context)

    # Test with a conditional that evaluates to True
    conditional.when = ['1 == 1 and 2 == 2']


# Generated at 2022-06-22 16:29:10.646756
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # create a fake inventory
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=['localhost,'])
    host = Host(name='localhost')
    group = Group(name='ungrouped')
    group.add_host(host)
    inv.add_group(group)
    inv.add_host(host)

    # create a fake variable manager
    variable_manager = VariableManager(loader=loader, inventory=inv)

    # create a fake task
    from ansible.playbook.task import Task

# Generated at 2022-06-22 16:29:22.758407
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    # Test with a conditional that is None
    conditional = Conditional()
    conditional.when = None
    assert conditional.evaluate_conditional(templar, play_context)

    # Test with a conditional that is an empty string
    conditional = Conditional()
    conditional.when = ''
    assert conditional.evaluate_conditional(templar, play_context)

    # Test with a conditional that is a boolean
    conditional = Conditional()
    conditional.when = True
    assert conditional.evaluate_conditional(templar, play_context)

    # Test with a conditional that is a string
    conditional = Conditional()
    conditional.when

# Generated at 2022-06-22 16:29:31.741564
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('foo is defined and bar is not defined') == [('foo', 'is', 'defined'), ('bar', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo is defined and bar is defined') == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo is defined and bar is defined and baz is defined') == [('foo', 'is', 'defined'), ('bar', 'is', 'defined'), ('baz', 'is', 'defined')]

# Generated at 2022-06-22 16:29:50.930020
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert c.extract_defined_undefined('foo is defined and bar is defined') == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:30:00.785828
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # create a fake play context
    pc = PlayContext()
    pc.remote_addr = '127.0.0.1'
    pc.port = 22
    pc.remote_user = 'root'
    pc.connection = 'ssh'
    pc.become = False
    pc.become_method = 'sudo'
    pc.become_user = 'root'
    pc.check_mode = False
    pc.diff = False

# Generated at 2022-06-22 16:30:10.099318
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("a is defined") == [('a', 'is', 'defined')]
    assert conditional.extract_defined_undefined("a is not defined") == [('a', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("a is undefined") == [('a', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("a is not undefined") == [('a', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("a is defined and b is defined") == [('a', 'is', 'defined'), ('b', 'is', 'defined')]

# Generated at 2022-06-22 16:30:21.043838
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    class TestConditional(Conditional):
        def __init__(self, loader=None):
            super(TestConditional, self).__init__(loader=loader)
            self._ds = None

    # Test with a simple conditional
    test_conditional = TestConditional()
    test_conditional.when = [ "a == 1" ]
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(a=1))
    templar = Templar(loader=None, variables=variable_manager)
    assert test_conditional.evaluate_conditional(templar, variable_manager.get_vars(play=None, include_hostvars=True))

    # Test with a simple conditional
    test_

# Generated at 2022-06-22 16:30:26.245496
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    p = PlayContext()
    t = Templar(loader=None, variables={})
    c = Conditional(loader=None)

    assert c.evaluate_conditional(t, p) == True

# Generated at 2022-06-22 16:30:34.584893
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    conditional = Conditional(loader=loader)
    conditional.when = ['1 == 1']
    assert conditional.evaluate_conditional(variable_manager, play_context)

    conditional.when = ['1 == 2']
    assert not conditional.evaluate_conditional(variable_manager, play_context)

    conditional.when = ['1 == 1', '2 == 2']
    assert conditional.evaluate_

# Generated at 2022-06-22 16:30:46.166600
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    conditional = Conditional()
    conditional.when = [
        'foo is defined',
        'bar is not defined',
        'baz is defined',
        'qux is not defined',
        'quux is defined',
        'corge is not defined',
        'grault is defined',
        'garply is not defined',
        'waldo is defined',
        'fred is not defined',
        'plugh is defined',
        'xyzzy is not defined',
        'thud is defined',
    ]

    # Test with no variables defined
    assert conditional.evaluate_conditional(templar, {}) is False

   

# Generated at 2022-06-22 16:30:59.933868
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake host
    host = type('FakeHost', (object,), {'get_vars': lambda self: {}})()

    # Create a fake play
    play_context = PlayContext()
    play_context.prompt = None
    play_context._ds = None
    play_context.become = False
    play_context.become_method = None
    play_context.become_user = None
    play_context.remote_addr = None
    play_context.connection = None
    play_context.network_os = None
    play_context.port = None
    play_context.remote_user = None
    play_context.password = None

# Generated at 2022-06-22 16:31:10.737694
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined and bar is undefined") == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not defined and bar is not undefined") == [('foo', 'is not', 'defined'), ('bar', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is not undefined") == [('foo', 'is', 'defined'), ('bar', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not defined and bar is undefined") == [('foo', 'is not', 'defined'), ('bar', 'is', 'undefined')]

# Generated at 2022-06-22 16:31:22.364541
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class TestConditional(Conditional):
        def __init__(self):
            self.when = []

    class TestPlayContext(PlayContext):
        def __init__(self):
            self.vars = dict()

    class TestTemplar(Templar):
        def __init__(self):
            self.environment = None
            self.available_variables = dict()

        def is_template(self, data):
            return False

        def template(self, data, disable_lookups=False):
            return data

    # Test with a boolean
    test_conditional = TestConditional()
    test_conditional.when = [True]
    test_play_context = TestPlayContext()
    test_templ

# Generated at 2022-06-22 16:31:37.684176
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.task import Task
    task = Task()
    conditional = "hostvars['foo'] is defined and hostvars['bar'] is not defined"
    results = task.extract_defined_undefined(conditional)
    assert results == [('hostvars[\'foo\']', 'is', 'defined'), ('hostvars[\'bar\']', 'is not', 'defined')]


# Generated at 2022-06-22 16:31:46.477128
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("") == []
    assert conditional.extract_defined_undefined("foo") == []
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]

# Generated at 2022-06-22 16:31:53.744895
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)

# Generated at 2022-06-22 16:32:06.041487
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:32:15.435503
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class TestConditional(Conditional):
        def __init__(self):
            self._loader = None
            self._ds = None
            self.when = []

    c = TestConditional()

# Generated at 2022-06-22 16:32:23.298283
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)
    conditional.when = ['foo']

# Generated at 2022-06-22 16:32:30.275468
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a Conditional object
    conditional = Conditional()

    # Create a PlayContext object
    play_context = PlayContext()

    # Create a VariableManager object
    variable_manager = VariableManager()

    # Create a Templar object
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    # Create a dictionary
    all_vars = dict()

    # Test the method evaluate_conditional with conditional = None
    conditional.when = None
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test the method evaluate_conditional with conditional = ''
    conditional.when = ''

# Generated at 2022-06-22 16:32:42.040144
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert c.extract_defined_undefined('foo is defined and bar is defined') == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:32:54.526267
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    class TestConditional(Conditional):
        def __init__(self, loader):
            super(TestConditional, self).__init__(loader)

    test_conditional = TestConditional(loader)

    # Test with a simple string
    test_conditional.when = 'test_string'
    assert test_conditional.evaluate_conditional(templar, {})

    # Test with a simple string, but with a variable
    test_conditional.when = 'test_string_with_variable'
    assert not test_cond

# Generated at 2022-06-22 16:33:07.464394
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:33:27.994164
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined('foo is not defined and bar is not undefined') == [('foo', 'is not', 'defined'), ('bar', 'is not', 'undefined')]

# Generated at 2022-06-22 16:33:35.078566
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.base import Base
    from ansible.template import Templar

    class TestConditional(Base, Conditional):
        pass

    test_conditional = TestConditional()

    # Test with a simple conditional
    conditional = "a is defined"
    result = test_conditional.extract_defined_undefined(conditional)
    assert result == [('a', 'is', 'defined')]

    # Test with a conditional containing a variable
    conditional = "hostvars['foo'] is defined"
    result = test_conditional.extract_defined_undefined(conditional)
    assert result == [('hostvars[\'foo\']', 'is', 'defined')]

    # Test with a conditional containing a variable and a negation
    conditional = "hostvars['foo'] is not defined"

# Generated at 2022-06-22 16:33:41.452679
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = ['foo']
    assert conditional.evaluate_conditional(templar, dict(foo=True))

    # Test with a conditional that uses a variable
    conditional = Conditional()
    conditional.when = ['foo == "bar"']

# Generated at 2022-06-22 16:33:53.120839
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    templar = Templar(loader=None, variables=variable_manager)

    conditional = Conditional()
    conditional.when = ['foo == bar']

    assert conditional.evaluate_conditional(templar, variable_manager.get_vars())

    conditional.when = ['foo == baz']
    assert not conditional.evaluate_conditional(templar, variable_manager.get_vars())

    conditional.when = ['foo == baz', 'foo == bar']
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars())


# Generated at 2022-06-22 16:34:05.172315
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is undefined") == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]

# Generated at 2022-06-22 16:34:13.152312
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    pc = PlayContext()
    t = Templar(loader=None, variables={'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6, 'g': 7, 'h': 8, 'i': 9, 'j': 10, 'k': 11, 'l': 12, 'm': 13, 'n': 14, 'o': 15, 'p': 16, 'q': 17, 'r': 18, 's': 19, 't': 20, 'u': 21, 'v': 22, 'w': 23, 'x': 24, 'y': 25, 'z': 26})

    # Test with a single conditional
    c = Conditional()
    c.when = ['a == 1']


# Generated at 2022-06-22 16:34:23.985944
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined or bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:34:33.836809
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with a list of conditionals
    conditional = Conditional()
    conditional.when = ['foo', 'bar']
    assert conditional.evaluate_conditional(templar, dict(foo=True, bar=True))
    assert not conditional

# Generated at 2022-06-22 16:34:46.039161
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_inventory(None)
    play_context = PlayContext()
    templar = Templar(loader=None, variables=variable_manager, play_context=play_context)

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = ['foo == "bar"']
    all_vars = dict(foo='bar')
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test with a simple conditional with a variable
    conditional = Conditional()
    conditional.when = ['foo == var']
    all_vars = dict(foo='bar', var='bar')


# Generated at 2022-06-22 16:34:58.257657
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("a is defined") == [('a', 'is', 'defined')]
    assert conditional.extract_defined_undefined("a is not defined") == [('a', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("a is undefined") == [('a', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("a is not undefined") == [('a', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("a is defined and b is defined") == [('a', 'is', 'defined'), ('b', 'is', 'defined')]

# Generated at 2022-06-22 16:35:22.534613
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Test 1
    conditional = "hostvars['foo'] is defined and hostvars['bar'] is not defined"
    results = Conditional().extract_defined_undefined(conditional)
    assert results == [('hostvars[\'foo\']', 'is', 'defined'), ('hostvars[\'bar\']', 'is not', 'defined')]

    # Test 2
    conditional = "hostvars['foo'] is defined and hostvars['bar'] is not defined and hostvars['baz'] is defined"
    results = Conditional().extract_defined_undefined(conditional)

# Generated at 2022-06-22 16:35:32.889405
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-22 16:35:45.813380
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("") == []
    assert cond.extract_defined_undefined("a") == []
    assert cond.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert cond.extract_defined_undefined("a is not defined") == [("a", "is not", "defined")]
    assert cond.extract_defined_undefined("a is undefined") == [("a", "is", "undefined")]
    assert cond.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]

# Generated at 2022-06-22 16:35:54.223912
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('tests/inventory'))
    templar = Templar(loader=loader, variables=variable_manager)

    class TestConditional(Conditional):
        def __init__(self):
            super(TestConditional, self).__init__(loader=loader)

    test_conditional = TestConditional()
    test_conditional.when = ['foo is defined', 'bar is defined']
    all_vars = variable_manager.get_vars(loader=loader, play=None)

# Generated at 2022-06-22 16:36:06.369596
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:36:18.188116
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'username'
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.accelerate = False
    play_context.accelerate_port = 5099
    play_context.accelerate_ipv6 = False
    play

# Generated at 2022-06-22 16:36:29.759343
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = ['foo']
    all_vars = dict(foo=True)
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test with a complex conditional
    conditional = Conditional()
    conditional.when = ['foo and bar or not baz']
   

# Generated at 2022-06-22 16:36:43.260673
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = Host(name='localhost')
    group = Group(name='ungrouped')
    group.add_host(host)
    inventory.add_group(group)
    inventory.add_host(host)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play

# Generated at 2022-06-22 16:36:58.552576
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("") == []
    assert cond.extract_defined_undefined("foo") == []
    assert cond.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert cond.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert cond.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert cond.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]

# Generated at 2022-06-22 16:37:05.030167
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('localhost'))
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple conditional
    conditional = 'foo is defined'
    all_vars = dict(foo='bar')
    assert Conditional().evaluate_conditional(templar, all_vars)

    # Test with a simple conditional that should fail
    conditional = 'foo is defined'
    all_vars = dict()
    assert not Conditional().evaluate_conditional(templar, all_vars)

    # Test with a simple conditional that should

# Generated at 2022-06-22 16:37:31.293829
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader, playcontext=play_context)

    # test with a simple string
    conditional = Conditional()
    conditional.when = 'foo'
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    assert conditional