

# Generated at 2022-06-22 16:27:37.077195
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # test setup
    play_context = PlayContext()
    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager)

    # test data

# Generated at 2022-06-22 16:27:48.787472
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("") == []
    assert conditional.extract_defined_undefined("foo") == []
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]

# Generated at 2022-06-22 16:27:56.165717
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    templar = Templar(loader=loader, variables=variable_manager)

    # test with a simple string
    conditional = Conditional(loader=loader)
    conditional.when = 'foo'
    assert conditional.evaluate_conditional(templar, dict(foo='bar'))

    # test with a simple string that doesn't exist
    conditional = Conditional(loader=loader)
    conditional.when = 'foo'
    assert not conditional.evaluate

# Generated at 2022-06-22 16:28:05.618093
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Conditional):
        def __init__(self):
            self._ds = None
            self._loader = None
            self._when = None

    test_conditional = TestConditional()

# Generated at 2022-06-22 16:28:16.326243
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = ['foo']
    all_vars = dict(foo=True)
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test with a conditional containing a variable
    conditional = Conditional()
    conditional.when = ['foo == bar']
    all_vars = dict(foo='bar')
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test with a conditional containing a variable and

# Generated at 2022-06-22 16:28:24.733533
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:28:35.240849
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class TestConditional(Conditional):
        def __init__(self, loader):
            self._loader = loader


# Generated at 2022-06-22 16:28:45.228709
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("hostvars['foo'] is defined") == [("hostvars['foo']", "is", "defined")]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not defined") == [("hostvars['foo']", "is not", "defined")]
    assert conditional.extract_defined_undefined("hostvars['foo'] is undefined") == [("hostvars['foo']", "is", "undefined")]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not undefined") == [("hostvars['foo']", "is not", "undefined")]
    assert conditional.extract_defined_undefined("hostvars['foo'] is defined or hostvars['bar'] is defined")

# Generated at 2022-06-22 16:28:55.744529
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined('foo is defined and bar is defined') == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:29:09.230903
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:29:26.305619
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("hostvars['foo'] is defined") == [('hostvars[\'foo\']', 'is', 'defined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not defined") == [('hostvars[\'foo\']', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is undefined") == [('hostvars[\'foo\']', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not undefined") == [('hostvars[\'foo\']', 'is not', 'undefined')]

# Generated at 2022-06-22 16:29:41.019042
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:29:50.929967
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # create a mock object to pass in
    class ObjectWithConditional(object):
        def __init__(self):
            self.when = []
            self.when.append('foo is defined')
            self.when.append('bar is defined')
            self.when.append('baz is defined')
            self.when.append('qux is defined')
            self.when.append('quux is defined')
            self.when.append('corge is defined')
            self.when.append('grault is defined')
            self.when

# Generated at 2022-06-22 16:29:58.864026
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsVarsVars
    from ansible.vars.hostvars import HostVarsVarsVarsVars
    from ansible.vars.hostvars import HostVarsVarsVarsVarsVars
    from ansible.vars.hostvars import HostVarsVarsVarsVarsVarsVars

# Generated at 2022-06-22 16:30:08.634909
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class TestConditional(Conditional):
        pass

    class TestPlayContext(PlayContext):
        def __init__(self):
            self.vars = dict(
                foo='bar',
                baz='qux',
                quux='corge',
                grault='garply',
                waldo='fred',
                plugh='xyzzy',
                thud='wibble',
                fred='plugh',
                corge='thud',
                garply='waldo',
                wibble='foo',
                xyzzy='bar',
            )


# Generated at 2022-06-22 16:30:20.980903
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test with undefined variable
    conditional = Conditional()
    conditional.when = [ 'foo is defined' ]
    assert conditional.evaluate_conditional(templar, dict()) == False

    # test with defined variable
    conditional = Conditional()
    conditional.when = [ 'foo is defined' ]
    assert conditional.evaluate_conditional(templar, dict(foo='bar')) == True

# Generated at 2022-06-22 16:30:32.352771
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class TestConditional(Conditional):
        def __init__(self):
            self._loader = None
            self._ds = None
            self.when = []

    test_conditional = TestConditional()

# Generated at 2022-06-22 16:30:43.693836
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Conditional):
        def __init__(self, loader, variable_manager, play_context):
            self._loader = loader
            self._templar = Templar(loader=loader, variables=variable_manager.get_vars(play=play_context, include_hostvars=True))
            self._variable_manager = variable_manager
            self._play_context = play_context


# Generated at 2022-06-22 16:30:50.046559
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("hostvars['foo'] is defined") == [("hostvars['foo']", "is", "defined")]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not defined") == [("hostvars['foo']", "is not", "defined")]
    assert conditional.extract_defined_undefined("hostvars['foo'] is undefined") == [("hostvars['foo']", "is", "undefined")]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not undefined") == [("hostvars['foo']", "is not", "undefined")]
    assert conditional.extract_defined_undefined("hostvars['foo'] is defined and hostvars['bar'] is defined")

# Generated at 2022-06-22 16:31:01.092870
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)
    conditional.when = "{{ test_var }}"
    variable_manager.set_nonpersistent_facts(dict(test_var=True))
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars())
    variable_manager.set_nonpersistent_facts(dict(test_var=False))

# Generated at 2022-06-22 16:31:30.089575
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with a simple string
    conditional = Conditional()
    conditional.when = ['foo']
    assert conditional.evaluate_conditional(templar, dict(foo='bar'))

    # Test with a boolean
    conditional = Conditional()
    conditional.when = [True]
    assert conditional.evaluate_conditional(templar, dict())

    # Test with a boolean

# Generated at 2022-06-22 16:31:41.061696
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(a=1, b=2, c=3))

    templar = Templar(loader=None, variables=variable_manager)

    conditional = Conditional()
    conditional.when = ['a == 1', 'b == 2', 'c == 3']

    assert conditional.evaluate_conditional(templar, variable_manager.get_vars(loader=None, play=None, host=None, task=None))

    conditional.when = ['a == 1', 'b == 2', 'c == 4']

# Generated at 2022-06-22 16:31:54.195512
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:32:06.584383
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # Create a play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'username'
    play_context.connection = 'ssh'
    play_context.timeout = 10
    play_context.shell = '/bin/sh'
    play_context.executable = None
    play_context.verbosity = 0
    play_context.only_tags = []

# Generated at 2022-06-22 16:32:15.755890
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Conditional):
        def __init__(self, loader, play_context, variable_manager):
            self._loader = loader
            self._play_context = play_context
            self._variable_manager = variable_manager

    # Create a play context
    play_context = PlayContext()

    # Create a variable manager
    variable_manager = VariableManager()

    # Create a loader
    loader = 'dummy'

    # Create a test conditional
    test_conditional = TestConditional(loader, play_context, variable_manager)

    # Create a templar

# Generated at 2022-06-22 16:32:26.090800
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    task = Task()

# Generated at 2022-06-22 16:32:38.892085
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("") == []
    assert cond.extract_defined_undefined("a") == []
    assert cond.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert cond.extract_defined_undefined("a is not defined") == [("a", "is not", "defined")]
    assert cond.extract_defined_undefined("a is undefined") == [("a", "is", "undefined")]
    assert cond.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]

# Generated at 2022-06-22 16:32:46.962167
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'username'
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.timeout = 10
    play_context.shell = '/bin/sh'
    play_context.executable = None

# Generated at 2022-06-22 16:32:57.531241
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)
    conditional.when = ['test_var is defined']
    variable_manager.extra_vars = {'test_var': 'test_value'}
    assert conditional.evaluate_conditional

# Generated at 2022-06-22 16:33:09.627357
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is not undefined") == [('foo', 'is', 'defined'), ('bar', 'is not', 'undefined')]

# Generated at 2022-06-22 16:33:56.357094
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Base, Conditional):
        pass

    # Test with a simple conditional
    test_conditional = TestConditional()
    test_conditional.when = [ 'foo' ]
    templar = Templar(loader=None, variables=VariableManager())
    assert test_conditional.evaluate_conditional(templar, dict(foo=True))
    assert not test_conditional.evaluate_conditional(templar, dict(foo=False))

    # Test with a complex conditional
    test_conditional = TestConditional()
    test_conditional.when = [ 'foo and bar or not baz' ]

# Generated at 2022-06-22 16:34:08.445431
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # Test case 1
    # Test when conditional is None
    # Expected result: True
    conditional = None
    templar = Templar(loader=None, variables=VariableManager())
    all_vars = dict()
    result = Conditional().evaluate_conditional(templar, all_vars)
    assert result

    # Test case 2
    # Test when conditional is empty string
    # Expected result: True
    conditional = ''
    templar = Templar(loader=None, variables=VariableManager())
    all_vars = dict()
    result = Conditional().evaluate_conditional(templar, all_vars)
    assert result

    # Test case 3
    # Test when conditional is a boolean
    # Expected result: True

# Generated at 2022-06-22 16:34:22.163749
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # test with a simple string
    conditional = "1 == 1"
    templar = Templar(loader=None, variables=VariableManager())
    assert Conditional().evaluate_conditional(templar, {})

    # test with a boolean
    conditional = True
    templar = Templar(loader=None, variables=VariableManager())
    assert Conditional().evaluate_conditional(templar, {})

    # test with a boolean
    conditional = False
    templar = Templar(loader=None, variables=VariableManager())
    assert not Conditional().evaluate_conditional(templar, {})

    # test with a string that evaluates to a boolean
    conditional = "1 == 1"

# Generated at 2022-06-22 16:34:29.499627
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    variable_manager.set_inventory(loader.load_from_file('tests/inventory'))
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with a simple string
    conditional = Conditional()
    conditional.when

# Generated at 2022-06-22 16:34:41.150680
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=False)

    # Test with a simple conditional
    conditional = 'foo == "bar"'
    all_vars = dict(foo='bar')
    task = Task()
    task.when

# Generated at 2022-06-22 16:34:53.330895
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("a is defined") == [('a', 'is', 'defined')]
    assert conditional.extract_defined_undefined("a is not defined") == [('a', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("a is undefined") == [('a', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("a is not undefined") == [('a', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("a is defined and b is defined") == [('a', 'is', 'defined'), ('b', 'is', 'defined')]

# Generated at 2022-06-22 16:35:02.556911
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:35:14.336396
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('localhost'))
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = ['test_var']
    all_vars = variable_manager.get_vars(loader=loader, play=None)
    all_vars['test_var'] = True
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test with a simple conditional that should fail
    conditional = Conditional()

# Generated at 2022-06-22 16:35:22.197079
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_from_file('tests/inventory'))
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test when conditional is None
    conditional = None
    result = Conditional(loader=loader).evaluate_conditional(templar, variable_manager.get_vars(play=None, host=None))
    assert result == True

    # Test when conditional is empty string
    conditional = ''
   

# Generated at 2022-06-22 16:35:32.750092
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test 1: simple conditional
    conditional = Conditional()
    conditional.when = ['foo']
    all_vars = dict(foo=True)
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test 2: simple conditional with a variable
    conditional = Conditional()
    conditional.when = ['foo == bar']
    all_vars = dict(foo='bar')
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test 3: simple conditional with a

# Generated at 2022-06-22 16:36:51.640818
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    task = Task()
    task._role = None
    task._play = None
    task._ds = None
    task._loader = None
    task._variable_manager = None
    task._block = None
    task._play_context = PlayContext()
    task._task_vars = dict()
    task._templar = Templar(loader=None, variables=task._task_vars)

    conditional = "hostvars['foo'] is defined and hostvars['bar'] is not defined"
    expected = [('hostvars[\'foo\']', 'is', 'defined'), ('hostvars[\'bar\']', 'is not', 'defined')]
    assert task.ext

# Generated at 2022-06-22 16:37:01.366320
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory(host_list='tests/inventory'))
    hostvars = HostVars(loader=loader, variable_manager=variable_manager)
    variable_manager.set_hostvars(hostvars)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=play_context, include_hostvars=True))

    conditional = Cond

# Generated at 2022-06-22 16:37:11.448136
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is not undefined") == [("foo", "is", "defined"), ("bar", "is not", "undefined")]

# Generated at 2022-06-22 16:37:23.637004
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # Create a fake hostvars object
    hostvars = HostVars(dict())