

# Generated at 2022-06-22 16:27:43.673514
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = ['foo']
    all_vars = dict(foo=True)
    assert conditional.evaluate_conditional(templar, all_vars)

# Generated at 2022-06-22 16:27:51.483522
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Conditional):
        pass

    test_conditional = TestConditional()

    # test with a simple string
    assert test_conditional.evaluate_conditional(Templar(VariableManager(), PlayContext()), dict(a=1, b=2, c=3)), "simple string should return True"

    # test with a simple string
    assert not test_conditional.evaluate_conditional(Templar(VariableManager(), PlayContext()), dict(a=1, b=2, c=3)), "simple string should return False"

    # test with a simple string

# Generated at 2022-06-22 16:28:03.083396
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.plugins.loader import get_all_plugin_loaders

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=get_all_plugin_loaders())

    conditional = Conditional(loader=loader)
    conditional._ds = None

    # test with undefined variable

# Generated at 2022-06-22 16:28:14.587783
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is undefined") == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]

# Generated at 2022-06-22 16:28:25.033163
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # test with a simple conditional
    conditional = Conditional(loader=loader)
    conditional.when = ['foo == bar']
    all_vars = dict(foo='bar')
    assert conditional.evaluate_conditional(templar, all_vars)

    # test with a simple conditional that should fail
    conditional = Conditional(loader=loader)

# Generated at 2022-06-22 16:28:37.480113
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert cond.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert cond.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert cond.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert cond.extract_defined_undefined("foo is defined and bar is undefined") == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]

# Generated at 2022-06-22 16:28:48.703584
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('a is defined') == [('a', 'is', 'defined')]
    assert conditional.extract_defined_undefined('a is not defined') == [('a', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('a is undefined') == [('a', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('a is not undefined') == [('a', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined('a is defined and b is defined') == [('a', 'is', 'defined'), ('b', 'is', 'defined')]

# Generated at 2022-06-22 16:28:57.658691
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("") == []
    assert conditional.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert conditional.extract_defined_undefined("a is not defined") == [("a", "is not", "defined")]
    assert conditional.extract_defined_undefined("a is undefined") == [("a", "is", "undefined")]
    assert conditional.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]
    assert conditional.extract_defined_undefined("a is defined and b is defined") == [("a", "is", "defined"), ("b", "is", "defined")]

# Generated at 2022-06-22 16:29:10.778309
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'username'
    play_context.port = 22
    play_context.connection = 'ssh'
    play_context.network_os = 'DefaultOS'
    play_context.timeout = 10
    play_context.shell = '/bin/sh'
    play_context.executable = None
    play_context.stdin_path

# Generated at 2022-06-22 16:29:22.811425
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = ['foo']
    templar = Templar(loader=None, variables=dict(foo=True))
    assert conditional.evaluate_conditional(templar, dict())

    # Test with a conditional that is not a string
    conditional = Conditional()
    conditional.when = [True]
    templar = Templar(loader=None, variables=dict())
    assert conditional.evaluate_conditional(templar, dict())

    # Test with a conditional that is a string
    conditional = Conditional()
    conditional.when = ['foo']

# Generated at 2022-06-22 16:29:35.656745
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

    # Test 1:
    # Test with a simple conditional
    conditional = "hostvars['foo'] is defined"
    result = cond.extract_defined_undefined(conditional)
    assert result == [('hostvars[\'foo\']', 'is', 'defined')]

    # Test 2:
    # Test with a simple conditional
    conditional = "hostvars['foo'] is not defined"
    result = cond.extract_defined_undefined(conditional)
    assert result == [('hostvars[\'foo\']', 'is not', 'defined')]

    # Test 3:
    # Test with a simple conditional
    conditional = "hostvars['foo'] is undefined"
    result = cond.extract_defined_undefined(conditional)

# Generated at 2022-06-22 16:29:42.167756
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("") == []
    assert conditional.extract_defined_undefined("a is defined") == [('a', 'is', 'defined')]
    assert conditional.extract_defined_undefined("a is not defined") == [('a', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("a is undefined") == [('a', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("a is not undefined") == [('a', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("a is defined and b is defined") == [('a', 'is', 'defined'), ('b', 'is', 'defined')]

# Generated at 2022-06-22 16:29:51.492449
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager)

    task = Task()
    task.when = ['a == b']
    variable_manager.set_nonpersistent_facts(dict(a='b'))

# Generated at 2022-06-22 16:30:00.862462
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'username'
    play_context.port = 22
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.timeout = 10
    play_context.shell = '/bin/sh'
    play_context.executable = None
    play_context.environment = dict()


# Generated at 2022-06-22 16:30:10.136689
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    # Test with a simple string
    conditional = Conditional()
    conditional.when = 'foo'
    assert conditional.evaluate_conditional(templar, play_context) == True

    # Test with a simple string
    conditional = Conditional()
    conditional.when = 'foo'
    assert conditional.evaluate_conditional(templar, play_context) == True

    # Test with a simple string
    conditional = Conditional()
    conditional.when = 'foo'
    assert conditional.evaluate_conditional(templar, play_context) == True

    # Test with a simple string
    conditional = Conditional()
    conditional.when

# Generated at 2022-06-22 16:30:11.531895
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional is not None


# Generated at 2022-06-22 16:30:20.536920
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Test 1:
    # Test string: "hostvars['foo'] is defined and hostvars['bar'] is not defined"
    # Expected result: [('hostvars[\'foo\']', 'is', 'defined'), ('hostvars[\'bar\']', 'is not', 'defined')]
    test_string = "hostvars['foo'] is defined and hostvars['bar'] is not defined"
    expected_result = [('hostvars[\'foo\']', 'is', 'defined'), ('hostvars[\'bar\']', 'is not', 'defined')]
    result = Conditional().extract_defined_undefined(test_string)
    assert result == expected_result, "Test 1 failed"

    # Test 2:
    # Test string: "hostvars['foo'] is defined and hostvars['

# Generated at 2022-06-22 16:30:32.024956
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert c.extract_defined_undefined("a is not defined") == [("a", "is not", "defined")]
    assert c.extract_defined_undefined("a is undefined") == [("a", "is", "undefined")]
    assert c.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]
    assert c.extract_defined_undefined("a is defined and b is not undefined") == [("a", "is", "defined"), ("b", "is not", "undefined")]

# Generated at 2022-06-22 16:30:43.677495
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:30:50.027520
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert cond.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert cond.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert cond.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert cond.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:31:08.546490
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('localhost'))
    templar = Templar(loader=loader, variables=variable_manager)

    # Test the case when the conditional is None
    conditional = None
    all_vars = dict()
    result = Conditional().evaluate_conditional(templar, all_vars)
    assert result

    # Test the case when the conditional is a boolean
    conditional = True
    all_vars = dict()
    result = Conditional().evaluate_conditional(templar, all_vars)
    assert result

    # Test the case when the conditional

# Generated at 2022-06-22 16:31:19.869741
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # Create a play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = None
    play_context.become_user = None
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'remote_user'
    play_context.port = 22
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.timeout = 10
    play_

# Generated at 2022-06-22 16:31:27.682293
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("") == []
    assert cond.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert cond.extract_defined_undefined("a is not defined") == [("a", "is not", "defined")]
    assert cond.extract_defined_undefined("a is undefined") == [("a", "is", "undefined")]
    assert cond.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]
    assert cond.extract_defined_undefined("a is defined and b is defined") == [("a", "is", "defined"), ("b", "is", "defined")]

# Generated at 2022-06-22 16:31:40.374332
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert conditional.extract_defined_undefined("a is not defined") == [("a", "is not", "defined")]
    assert conditional.extract_defined_undefined("a is undefined") == [("a", "is", "undefined")]
    assert conditional.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]
    assert conditional.extract_defined_undefined("a is defined and b is defined") == [("a", "is", "defined"), ("b", "is", "defined")]

# Generated at 2022-06-22 16:31:53.500273
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader, play_context=play_context)

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = ['test']
    assert conditional.evaluate_conditional(templar, dict(test=True))

   

# Generated at 2022-06-22 16:32:05.785760
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is defined and hostvars[inventory_hostname].ansible_ssh_host is defined') == [('hostvars[inventory_hostname]', 'is', 'defined'), ('hostvars[inventory_hostname].ansible_ssh_host', 'is', 'defined')]
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is defined and hostvars[inventory_hostname].ansible_ssh_host is not defined') == [('hostvars[inventory_hostname]', 'is', 'defined'), ('hostvars[inventory_hostname].ansible_ssh_host', 'is not', 'defined')]

# Generated at 2022-06-22 16:32:15.342691
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("") == []
    assert conditional.extract_defined_undefined("a is defined") == [('a', 'is', 'defined')]
    assert conditional.extract_defined_undefined("a is not defined") == [('a', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("a is undefined") == [('a', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("a is not undefined") == [('a', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("a is defined and b is defined") == [('a', 'is', 'defined'), ('b', 'is', 'defined')]

# Generated at 2022-06-22 16:32:19.883092
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # Test with valid loader
    conditional = Conditional(loader=loader)
    assert conditional is not None

    # Test with invalid loader
    try:
        conditional = Conditional()
        assert False
    except AnsibleError as e:
        assert "a loader must be specified" in to_text(e)

# Generated at 2022-06-22 16:32:30.492143
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Conditional):
        pass

    # Set up a test object
    test_conditional = TestConditional()

    # Set up a test variable manager
    test_variable_manager = VariableManager()
    test_variable_manager.set_nonpersistent_facts(dict(a=1, b=2, c=3))

    # Set up a test play context
    test_play_context = PlayContext()

    # Set up a test templar
    test_templar = Templar(loader=None, variables=test_variable_manager,
                           shared_loader_obj=None, playcontext=test_play_context)

    # Test with no when clauses


# Generated at 2022-06-22 16:32:42.195339
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with a boolean
    conditional = Conditional()
    conditional.when = True
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars(play=None, host=None, task=None))

   

# Generated at 2022-06-22 16:33:12.361314
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    c = Conditional()
    assert c._when == []

    c = Conditional(loader=None)
    assert c._when == []

    pc = PlayContext()
    t = Templar(loader=None, variables={})
    c = Conditional(loader=None)
    assert c.evaluate_conditional(t, pc)

# Generated at 2022-06-22 16:33:17.711489
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("") == []
    assert cond.extract_defined_undefined("a") == []
    assert cond.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert cond.extract_defined_undefined("a is not defined") == [("a", "is not", "defined")]
    assert cond.extract_defined_undefined("a is undefined") == [("a", "is", "undefined")]
    assert cond.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]

# Generated at 2022-06-22 16:33:29.265427
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'username'
    play_context.port = 22
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.timeout = 10
    play_context.shell = '/bin/sh'
    play_context.executable = None
    play_context.stdin = False
   

# Generated at 2022-06-22 16:33:40.114054
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    # Test 1: Test with a simple conditional
    conditional = Conditional()
    conditional.when = ['test_var == "test_value"']
    all_vars = dict(test_var='test_value')
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test 2: Test with a simple conditional that should fail
    conditional = Conditional()
    conditional.when = ['test_var == "test_value"']

# Generated at 2022-06-22 16:33:52.161339
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # This is a unit test for method evaluate_conditional of class Conditional.
    # It is not a full unit test for class Conditional.

    # Test 1:
    #   - conditional: 'foo is defined'
    #   - all_vars: {'foo': 'bar'}
    #   - expected result: True
    #   - expected all_vars: {'foo': 'bar'}
    #   - expected templar.available_variables: {'foo': 'bar'}
    #   - expected templar.template_data: {}
    #   - expected templar.template_vars: {}
    #   - expected templar.template_undefined: {}
    #   - expected templ

# Generated at 2022-06-22 16:34:01.739562
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)
    conditional.when = 'foo'
    conditional.when = ['foo', 'bar']
    conditional.when = ['foo', 'bar', 'baz']

# Generated at 2022-06-22 16:34:12.220791
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple string
    conditional = Conditional()
    conditional.when = ['foo']
    assert conditional.evaluate_conditional(templar, dict(foo='bar'))

    # Test with a boolean
    conditional = Conditional()
    conditional.when = [True]
    assert conditional.evaluate_conditional(templar, dict(foo='bar'))

    # Test with a boolean
    conditional = Conditional()
    conditional.when = [False]

# Generated at 2022-06-22 16:34:23.603522
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Conditional):
        def __init__(self, loader, variable_manager, play_context):
            self._loader = loader
            self._templar = Templar(loader=loader, variables=variable_manager, shared_loader_obj=play_context)
            self.when = ['a == b']


# Generated at 2022-06-22 16:34:33.744359
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # Create a variable manager
    variable_manager = VariableManager()
    variable_manager.set_variable('foo', 'bar')

    # Create a template
    templar = Templar(loader=None, variables=variable_manager)

    # Create a Conditional
    conditional = Conditional()

    # Test the method evaluate_conditional
    assert conditional.evaluate_conditional(templar, variable_manager._fact_cache) == True
    assert conditional.evaluate_conditional(templar, variable_manager._fact_cache, conditional='foo == "bar"') == True
    assert conditional.evaluate_conditional(templar, variable_manager._fact_cache, conditional='foo == "baz"') == False

# Generated at 2022-06-22 16:34:44.254483
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.prompt = (lambda *args, **kwargs: None)

    conditional = Conditional(loader=loader)
    conditional.evaluate_conditional(variable_manager, play_context, all_vars=dict())

# Generated at 2022-06-22 16:35:12.598415
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'username'
    play_context.connection = 'ssh'
    play_context.timeout = 10
    play_context.shell = '/bin/sh'
    play_context.executable = None
    play_context.stdin = False
    play_context.stdin_add_newline = True

# Generated at 2022-06-22 16:35:22.933765
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    play_context = PlayContext()
    templar = Templar(loader=None, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=None)

# Generated at 2022-06-22 16:35:33.078878
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # test with a simple string
    conditional = 'foo'
    all_vars = dict(foo='bar')
    c = Conditional()
    assert c.evaluate_conditional(templar, all_vars) is True

    # test with a simple string
    conditional = 'foo'
    all_vars = dict(foo='')
    c = Conditional()
    assert c.evaluate_conditional(templar, all_vars) is False

    # test with a simple string
    conditional = 'foo'
   

# Generated at 2022-06-22 16:35:43.976484
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class TestConditional(Conditional):
        def __init__(self, loader=None):
            super(TestConditional, self).__init__(loader=loader)

    test_conditional = TestConditional()

    # Test with a valid conditional
    test_conditional.when = ['1 == 1']
    play_context = PlayContext()
    templar = Templar(loader=None, variables=play_context.accelerate_variables)
    assert test_conditional.evaluate_conditional(templar, play_context.accelerate_variables)

    # Test with an invalid conditional
    test_conditional.when = ['1 == 2']
    play_context = PlayContext()

# Generated at 2022-06-22 16:35:50.728035
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    conditional = Conditional(loader=None)
    conditional.when = [True, False, 'test']
    conditional.evaluate_conditional(templar, variable_manager.get_vars(play=None, host=None, task=None))

# Generated at 2022-06-22 16:35:57.548575
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # Create a fake inventory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = Host(name='localhost')
    group = Group(name='group')
    group.add_host(host)
    inventory.add_group(group)
    inventory.add_host(host)

    # Create a fake variable manager
    variable_manager = Variable

# Generated at 2022-06-22 16:36:09.711877
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    conditional = Conditional()
    conditional.when = ["foo == 'bar'"]
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars(play=play_context))

    conditional = Conditional()
    conditional.when = ["foo == 'bar'"]
    variable_manager.set_nonpersistent_facts(dict(foo='baz'))
    assert not conditional.evaluate

# Generated at 2022-06-22 16:36:22.952209
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = [ "foo == 'bar'" ]
    all_vars = variable_manager.get_vars(loader=loader, play=None)
    all_vars['foo'] = 'bar'
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test with a simple conditional that should fail
    conditional = Conditional()
    conditional.when = [ "foo == 'bar'" ]
    all_vars = variable_manager.get

# Generated at 2022-06-22 16:36:31.955334
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Create a Conditional object
    conditional = Conditional()

    # Create a PlayContext object
    play_context = PlayContext()

    # Create a Templar object
    templar = Templar(loader=None, variables={})

    # Test with a simple conditional
    conditional.when = ['1 == 1']
    assert conditional.evaluate_conditional(templar, play_context)

    # Test with a simple conditional
    conditional.when = ['1 == 2']
    assert not conditional.evaluate_conditional(templar, play_context)

    # Test with a simple conditional
    conditional.when = ['1 == 1', '2 == 2']
    assert conditional.evaluate_conditional(templar, play_context)

    # Test with

# Generated at 2022-06-22 16:36:44.242579
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create a variable manager
    variable_manager = VariableManager()
    loader = DataLoader()

    # Create a host
    host = Host(name="localhost")

    # Create a group
    group = Group(name="ungrouped")

    # Create an inventory and add the host and group to it
    inventory = InventoryManager(loader=loader, sources='')
    inventory.add_group(group)
    inventory.add_host(host)

    # Add the inventory to the variable manager
    variable_manager.set_inventory(inventory)



# Generated at 2022-06-22 16:37:25.505371
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'username'
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.timeout = 10
