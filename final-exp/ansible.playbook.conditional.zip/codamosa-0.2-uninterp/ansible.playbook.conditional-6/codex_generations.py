

# Generated at 2022-06-22 16:27:44.083914
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class TestConditional(Conditional):
        def __init__(self, loader=None):
            super(TestConditional, self).__init__(loader=loader)

    # Test with a simple string
    test_conditional = TestConditional()
    test_conditional.when = ["test_string"]
    play_context = PlayContext()
    templar = Templar(loader=None, variables=play_context.acquire_lockfile())
    assert test_conditional.evaluate_conditional(templar, dict()) == True

    # Test with a simple string
    test_conditional = TestConditional()
    test_conditional.when = ["test_string"]
    play_context = PlayContext()

# Generated at 2022-06-22 16:27:51.651572
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context._set_vars_files(['/dev/null'])
    play_context._set_vars_prompts(dict())
    play_context._set_vars_files_params(dict())
    play_context._set_vars_files_as_is(list())
    play_context._set_vars_files_encoding(dict())
    play_context._set_vars_files_errors(dict())
    play_context._set_vars_files_ignore_errors(dict())
    play_context._set_vars_files_append_leading(dict())

# Generated at 2022-06-22 16:28:03.232986
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    templar = Templar(loader=loader, variables=variable_manager)

    # test with a list of conditionals
    c = Conditional()
    c.when = ['foo', 'bar']
    assert c.evaluate_conditional(templar, variable_manager.get_vars())

    # test with a single conditional
    c = Conditional()
    c.when = 'foo'
    assert c.evaluate_conditional(templar, variable_manager.get_vars())

    # test with a single conditional that is False

# Generated at 2022-06-22 16:28:14.171460
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    conditional = Conditional()

# Generated at 2022-06-22 16:28:24.717476
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is defined and hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined'), ('hostvars[inventory_hostname]', 'is', 'defined')]

# Generated at 2022-06-22 16:28:35.202684
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('localhost'))
    templar = Templar(loader=loader, variables=variable_manager)

    conditional = Conditional(loader=loader)
    conditional.when = ['foo is bar', 'foo is not bar']

    # test that the conditional is evaluated correctly
    assert conditional.evaluate_conditional(templar, dict(foo='bar')) == True
    assert conditional.evaluate_conditional(templar, dict(foo='not bar')) == False

    # test that the conditional is evaluated correctly when the conditional is a boolean

# Generated at 2022-06-22 16:28:43.749029
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert cond.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert cond.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert cond.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert cond.extract_defined_undefined('foo is defined and bar is not undefined') == [('foo', 'is', 'defined'), ('bar', 'is not', 'undefined')]

# Generated at 2022-06-22 16:28:54.728339
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()

# Generated at 2022-06-22 16:29:01.489699
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("") == []
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:29:13.187011
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("") == []
    assert conditional.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert conditional.extract_defined_undefined("a is not defined") == [("a", "is not", "defined")]
    assert conditional.extract_defined_undefined("a is undefined") == [("a", "is", "undefined")]
    assert conditional.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]
    assert conditional.extract_defined_undefined("a is defined and b is defined") == [("a", "is", "defined"), ("b", "is", "defined")]

# Generated at 2022-06-22 16:29:37.487194
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Create the objects needed to run the method
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # Create the object to test
    conditional = Conditional(loader=loader)

    # Test with a simple conditional
    conditional.when = [u'ansible_distribution == "Debian"']
    all_vars = dict(ansible_distribution=u'Debian')

# Generated at 2022-06-22 16:29:48.666586
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class FakeDS:
        pass

    class FakePlay:
        pass

    class FakeTask:
        def __init__(self):
            self._ds = FakeDS()
            self._play = FakePlay()

    class FakeConditional(Conditional):
        def __init__(self):
            self._ds = FakeDS()
            self._play = FakePlay()

    # Test with a single conditional
    fake_task = FakeTask()
    fake_task.when = ["ansible_distribution == 'Debian'"]
    fake_conditional = FakeConditional()
    fake_conditional.when = ["ansible_distribution == 'Debian'"]
    fake_play_context = PlayContext()

# Generated at 2022-06-22 16:29:57.278105
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("") == []
    assert conditional.extract_defined_undefined("hostvars['foo'] is defined") == [('hostvars[\'foo\']', 'is', 'defined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is defined and hostvars['bar'] is defined") == [('hostvars[\'foo\']', 'is', 'defined'), ('hostvars[\'bar\']', 'is', 'defined')]

# Generated at 2022-06-22 16:30:07.420012
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test with a simple conditional
    conditional = Conditional()
    conditional.when = ['test_var']
    all_vars = dict(test_var=True)
    assert conditional.evaluate_conditional(templar, all_vars)

    # test with a simple conditional that fails
    conditional = Conditional()
    conditional.when = ['test_var']

# Generated at 2022-06-22 16:30:14.349705
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert conditional.extract_defined_undefined("a is not defined") == [("a", "is not", "defined")]
    assert conditional.extract_defined_undefined("a is undefined") == [("a", "is", "undefined")]
    assert conditional.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]
    assert conditional.extract_defined_undefined("a is defined and b is undefined") == [("a", "is", "defined"), ("b", "is", "undefined")]

# Generated at 2022-06-22 16:30:22.494607
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'username'
    play_context.port = 22
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.timeout = 10
    play_context.shell = '/bin/sh'
    play_context.executable = None
    play_context.env = dict()


# Generated at 2022-06-22 16:30:33.050263
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)
    conditional.when = ["{{ test_var }}"]

    variable_manager.set_nonpersistent_facts(dict(test_var=True))
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars())

    variable_manager.set_nonpersistent_facts(dict(test_var=False))

# Generated at 2022-06-22 16:30:44.412106
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test 1: simple test
    conditional = Conditional()
    conditional.when = ['1 == 1']
    assert conditional.evaluate_conditional(templar, {})

    # Test 2: simple test
    conditional = Conditional

# Generated at 2022-06-22 16:30:50.625841
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:31:02.298136
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:31:27.114205
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Conditional):
        def __init__(self, loader, variable_manager, play_context):
            self._loader = loader
            self._templar = Templar(loader=loader, variables=variable_manager.get_vars(play=play_context, include_hostvars=True))
            self._variable_manager = variable_manager
            self._play_context = play_context

    # Test with a simple conditional
    conditional = TestConditional(loader=None, variable_manager=VariableManager(), play_context=PlayContext())
    conditional.when = ['1 == 1']

# Generated at 2022-06-22 16:31:39.909489
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined('foo is defined and bar is not undefined') == [('foo', 'is', 'defined'), ('bar', 'is not', 'undefined')]

# Generated at 2022-06-22 16:31:41.166195
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional is not None


# Generated at 2022-06-22 16:31:52.444324
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    # Setup
    play_context = PlayContext()
    variable_manager = VariableManager()
    hostvars = HostVars(loader=None, variables=dict())
    templar = Templar(loader=None, variables=variable_manager, hostvars=hostvars)

    # Test
    conditional = Conditional()

# Generated at 2022-06-22 16:32:04.836726
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:32:14.672252
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    # Test for empty conditional
    conditional = Conditional()
    conditional.when = []
    assert conditional.evaluate_conditional(templar, play_context)

    # Test for None conditional
    conditional = Conditional()
    conditional.when = [None]
    assert conditional.evaluate_conditional(templar, play_context)

    # Test for True conditional
    conditional = Conditional()
    conditional.when = [True]
    assert conditional.evaluate_conditional(templar, play_context)

    # Test for False conditional
    conditional = Conditional()
    conditional.when = [False]
    assert not conditional.evaluate_

# Generated at 2022-06-22 16:32:25.369178
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    conditional = Conditional(loader=loader)

# Generated at 2022-06-22 16:32:38.151405
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=False,
                      disable_lookups=False,
                      play_context=play_context)
    conditional = Conditional(loader=loader)
    conditional.when = ['1 == 1']

# Generated at 2022-06-22 16:32:45.634376
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Create a dummy inventory
    inventory = InventoryManager(loader=None, sources='')

    # Create a variable manager
    variable_manager = VariableManager(loader=None, inventory=inventory)

    # Create a dummy loader
    loader = 'dummy_loader'

    # Create a dummy context
    context = PlayContext()

    # Create a dummy templar
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=None)

    # Create a dummy conditional
    conditional = Conditional(loader=loader)

    # Create a dummy all_vars
    all_vars = dict()

# Generated at 2022-06-22 16:32:55.496858
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is not undefined") == [("foo", "is", "defined"), ("bar", "is not", "undefined")]

# Generated at 2022-06-22 16:33:23.017402
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    # Test with a simple condition
    cond = 'hostvars[inventory_hostname] is defined'
    res = conditional.extract_defined_undefined(cond)
    assert res == [('hostvars[inventory_hostname]', 'is', 'defined')]

    # Test with a complex condition
    cond = 'hostvars[inventory_hostname] is defined and hostvars[inventory_hostname].ansible_default_ipv4.address is defined'
    res = conditional.extract_defined_undefined(cond)
    assert res == [('hostvars[inventory_hostname]', 'is', 'defined'), ('hostvars[inventory_hostname].ansible_default_ipv4.address', 'is', 'defined')]

    # Test with a condition with a not

# Generated at 2022-06-22 16:33:34.592382
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    templar = Templar(loader=loader, variables=variable_manager)

    conditional = Conditional(loader=loader)

    # Test with a boolean
    conditional.when = True
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars())

    # Test with a string
    conditional.when = 'ansible_distribution == "CentOS"'

# Generated at 2022-06-22 16:33:45.795997
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined or bar is undefined") == [("foo", "is", "defined"), ("bar", "is", "undefined")]

# Generated at 2022-06-22 16:33:57.048894
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("") == []
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:34:09.028311
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Test with a simple conditional
    conditional = "hostvars['foo'] is defined"
    results = Conditional().extract_defined_undefined(conditional)
    assert results == [('hostvars[\'foo\']', 'is', 'defined')]

    # Test with a complex conditional
    conditional = "hostvars['foo'] is defined and hostvars['bar'] is not defined"
    results = Conditional().extract_defined_undefined(conditional)
    assert results == [('hostvars[\'foo\']', 'is', 'defined'), ('hostvars[\'bar\']', 'is not', 'defined')]

    # Test with a conditional without defined/undefined
    conditional = "hostvars['foo'] is bar"
    results = Conditional().extract_defined_undefined(conditional)

# Generated at 2022-06-22 16:34:18.655574
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)
    conditional.when = ['foo is defined']
    all_vars = dict(foo='bar')
    assert conditional.evaluate_conditional(templar, all_vars)

   

# Generated at 2022-06-22 16:34:25.709032
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test when conditional is None
    conditional = Conditional()
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars())

    # test when conditional is empty string
    conditional = Conditional()

# Generated at 2022-06-22 16:34:34.829508
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test for undefined variable
    conditional = Conditional()
    conditional.when = [
        'foo is defined',
        'bar is defined',
        'baz is defined',
        'qux is defined',
    ]
    all_vars = dict(
        foo=1,
        bar=2,
        baz=3,
    )
    assert conditional.evaluate_conditional(templar, all_vars) is False

    # Test for defined variable
    conditional = Conditional()

# Generated at 2022-06-22 16:34:47.086076
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context._set_task_and_variable_override('all', 'all')

    # Create a fake variable manager
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))

    # Create a fake templar
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    # Create a fake conditional object
    class FakeConditional(Conditional):
        def __init__(self):
            super(FakeConditional, self).__init__()
            self._ds = None
            self

# Generated at 2022-06-22 16:34:59.043260
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = ['foo is bar']
    all_vars = dict(foo='bar')
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test with a simple conditional with a variable
    conditional = Conditional()
    conditional.when = ['foo is {{ bar }}']
    all

# Generated at 2022-06-22 16:35:43.271311
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert cond.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert cond.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert cond.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert cond.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:35:52.364817
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("foo is defined and bar is not defined") == [('foo', 'is', 'defined'), ('bar', 'is not', 'defined')]
    assert cond.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert cond.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert cond.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert cond.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]

# Generated at 2022-06-22 16:35:58.621927
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)
    conditional.when = ["foo is defined"]
    assert conditional.evaluate_conditional(templar, dict(foo="bar")) == False

    conditional.when = ["foo is defined", "bar is defined"]
    assert conditional.evaluate_conditional(templar, dict(foo="bar")) == False


# Generated at 2022-06-22 16:36:03.627584
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context._set_variable_manager(variable_manager)

    # test with a simple conditional
    conditional = Conditional(loader=loader)
    conditional.when = ['ansible_os_family == "RedHat"']
    assert conditional.evaluate_conditional(variable_manager.templar, variable_manager.get_vars(play=play_context)) == True

    # test

# Generated at 2022-06-22 16:36:11.778915
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert c.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:36:24.568395
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # test with a simple conditional
    conditional = Conditional()
    conditional.when = ['foo']
    all_vars = dict(foo=True)
    assert conditional.evaluate_conditional(templar, all_vars)

    # test with a simple conditional that fails
    conditional = Conditional()
    conditional.when = ['foo']
    all_vars = dict(foo=False)
    assert not conditional.evaluate_conditional(templar, all_vars)

    # test with a complex conditional

# Generated at 2022-06-22 16:36:32.975301
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'username'
    play_context.port = 22
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.timeout = 10
    play_context.shell = '/bin/sh'
    play_context.executable = None
    play_context.stdin = False


# Generated at 2022-06-22 16:36:44.725396
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class TestConditional(Conditional):
        pass

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    test_conditional = TestConditional(loader=loader)
    test_conditional.when = ['{{ foo }}', '{{ bar }}']
    test_conditional.when[0].__UNSAFE__ = True
    test_conditional.when[1].__UNSAFE__ = True

    all_v

# Generated at 2022-06-22 16:36:58.595801
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple conditional
    conditional = 'ansible_os_family == "RedHat"'
    all_vars = dict(ansible_os_family='RedHat')
    assert Conditional().evaluate_conditional(templar, all_vars) == True

    # Test with a simple conditional

# Generated at 2022-06-22 16:37:05.075973
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    conditional = Conditional()

    # test with a simple string
    conditional.when = ['foo']
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars(play=play_context))

    # test with a simple string that should fail
    conditional.when = ['foo']
    variable_manager.set_nonpersistent_facts(dict(foo='baz'))
    assert not conditional