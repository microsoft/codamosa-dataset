

# Generated at 2022-06-22 16:27:36.135020
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    vars_mgr = VariableManager()
    vars_mgr.set_inventory(None)
    templar = Templar(loader=None, variables=vars_mgr)

    # test with a boolean
    conditional = Conditional()
    conditional.when = [True]
    assert conditional.evaluate_conditional(templar, {})

    # test with a string
    conditional = Conditional()
    conditional.when = ["True"]
    assert conditional.evaluate_conditional(templar, {})

    # test with a string
    conditional = Conditional()
    conditional.when = ["False"]
    assert not conditional.evaluate_conditional(templar, {})

    # test with a string
    conditional = Conditional()
    conditional

# Generated at 2022-06-22 16:27:44.200968
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with a simple string
    conditional = Conditional()
    conditional.when = "foo"
    all_vars = dict(foo=True)

# Generated at 2022-06-22 16:27:51.713107
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = ["foo"]
    variable_manager.set_nonpersistent_facts({"foo": True})
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars())

    # Test with a simple conditional that should fail
    conditional = Conditional()
    conditional.when = ["foo"]
    variable_manager.set_nonpersistent_facts({"foo": False})

# Generated at 2022-06-22 16:28:03.277039
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'username'
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.accelerate = False
    play_context.accelerate_port = 5099
    play_context.accelerate_ipv6 = False
    play_

# Generated at 2022-06-22 16:28:14.246615
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'username'
    play_context.port = 22
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.accelerate = False
    play_context.accelerate_port = 5099
    play_context.accelerate_ipv6 = False
    play

# Generated at 2022-06-22 16:28:24.759838
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager)

    task = Task()
    task._ds = dict(name='test')
    task._loader = loader
    task._variable_manager = variable_manager

    # Test 1: test that a conditional with a boolean value evaluates correctly
    task.when = [True]
    assert task.evaluate_conditional(templar, dict()) == True

    # Test 2: test that a conditional with a

# Generated at 2022-06-22 16:28:35.241087
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    conditional = Conditional()
    conditional.when = [
        'foo is defined',
        'bar is not defined',
        'baz is defined',
        'qux is not defined',
        'quux is defined',
        'corge is not defined',
        'grault is defined',
        'garply is not defined',
        'waldo is defined',
        'fred is not defined',
        'plugh is defined',
        'xyzzy is not defined',
        'thud is defined',
    ]

    # Test 1: all variables are defined

# Generated at 2022-06-22 16:28:40.944568
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert c.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:28:49.742195
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'username'
    play_context.port = 22
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.accelerate = False
    play_context.accelerate_port = 5099
    play_context.accelerate_ipv6 = False
    play

# Generated at 2022-06-22 16:28:58.189065
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is undefined") == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]

# Generated at 2022-06-22 16:29:24.315348
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple conditional
    conditional = 'foo == "bar"'
    all_vars = {'foo': 'bar'}
    assert Conditional().evaluate_conditional(templar, all_vars)

    # Test with a simple conditional that should fail
    conditional = 'foo == "bar"'
    all_vars = {'foo': 'baz'}
    assert not Conditional().evaluate_conditional(templar, all_vars)

    # Test with a simple conditional that should fail

# Generated at 2022-06-22 16:29:32.105788
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert c.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert c.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert c.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert c.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:29:44.164009
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a play context
    play_context = PlayContext()

    # Create a variable manager
    variable_manager = VariableManager()

    # Create a templar
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    # Create a Conditional object
    conditional = Conditional(loader=None)

    # Create a dictionary of variables
    all_vars = dict()

    # Test with a boolean value
    conditional.when = [True]
    assert conditional.evaluate_conditional(templar, all_vars) == True

    # Test with a string value
    conditional.when = ["True"]
    assert conditional.evaluate

# Generated at 2022-06-22 16:29:52.870888
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a Conditional object
    conditional = Conditional()

    # Create a PlayContext object
    play_context = PlayContext()

    # Create a VariableManager object
    variable_manager = VariableManager()

    # Create a Templar object
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    # Create a dict object
    all_vars = dict()

    # Test with a conditional that evaluates to True
    conditional.when = ['1 == 1']
    assert conditional.evaluate_conditional(templar, all_vars) == True

    # Test with a conditional that evaluates to False
    conditional.when = ['1 == 2']

# Generated at 2022-06-22 16:30:02.716984
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    conditional = Conditional(loader=loader)
    conditional.when = ['{{ foo }}']
    conditional.evaluate_conditional(variable_manager, play_context)

# Generated at 2022-06-22 16:30:11.300417
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # test data

# Generated at 2022-06-22 16:30:21.500271
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    # Create a fake hostvars object
    hostvars = HostVars(dict(localhost=dict(ansible_connection='local')))

    # Create a fake variable manager
    variable_manager = VariableManager()
    variable_manager.set_host_variable(host='localhost', varname='hostvars', value=hostvars)

    # Create a fake play context
    play_context = PlayContext()

    # Create a fake templar
    templar = Templar(loader=None, variables=variable_manager,
                      shared_loader_obj=None, play_context=play_context)

    # Create a

# Generated at 2022-06-22 16:30:32.770248
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is not undefined") == [('foo', 'is', 'defined'), ('bar', 'is not', 'undefined')]

# Generated at 2022-06-22 16:30:33.835172
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional is not None

# Generated at 2022-06-22 16:30:45.483463
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("a is defined") == [('a', 'is', 'defined')]
    assert conditional.extract_defined_undefined("a is not defined") == [('a', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("a is undefined") == [('a', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("a is not undefined") == [('a', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("a is defined and b is not defined") == [('a', 'is', 'defined'), ('b', 'is not', 'defined')]

# Generated at 2022-06-22 16:31:11.812697
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class TestConditional(Conditional):
        def __init__(self, loader):
            super(TestConditional, self).__init__(loader)
            self.when = ['test_conditional']

    class TestPlay(object):
        def __init__(self):
            self.hostvars = dict()
            self.vars = dict()

    class TestHost(object):
        def __init__(self):
            self.vars = dict()

    class TestLoader(object):
        def __init__(self):
            self.vars = dict()

    class TestInventory(object):
        def __init__(self):
            self.hosts = dict()


# Generated at 2022-06-22 16:31:22.922168
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    class TestConditional(Conditional):
        def __init__(self):
            super(TestConditional, self).__init__()
            self.when = ['foo', 'bar', 'baz']

    class TestPlayContext(PlayContext):
        def __init__(self):
            super(TestPlayContext, self).__init__()
            self.CLIARGS = dict(
                connection='local',
                module_path=None,
                forks=10,
                become=False,
                become_method=None,
                become_user=None,
                check=False,
                diff=False,
            )



# Generated at 2022-06-22 16:31:30.632458
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'username'
    play_context.port = 22
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.accelerate = False
    play_context.accelerate_port = 5099
    play_context.accelerate_ipv6 = False
    play

# Generated at 2022-06-22 16:31:41.317757
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=variable_manager)

    conditional = Conditional(loader=loader)
    conditional.when = ['test1', 'test2']

    # Test with a list of conditionals

# Generated at 2022-06-22 16:31:54.447590
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    Test method extract_defined_undefined of class Conditional
    '''
    conditional = Conditional()
    assert conditional.extract_defined_undefined("hostvars['foo'] is defined") == [('hostvars[\'foo\']', 'is', 'defined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not defined") == [('hostvars[\'foo\']', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is undefined") == [('hostvars[\'foo\']', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not undefined") == [('hostvars[\'foo\']', 'is not', 'undefined')]


# Generated at 2022-06-22 16:32:00.320430
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    conditional = Conditional()

# Generated at 2022-06-22 16:32:11.356173
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional()

    # Test with a boolean
    conditional.when = [True]
    assert conditional.evaluate_conditional(templar, {})

    conditional.when = [False]
    assert not conditional.evaluate_conditional(templar, {})

    # Test with a string
    conditional.when = ['True']

# Generated at 2022-06-22 16:32:21.898536
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)
    conditional.when = ["{{ foo }}"]
    conditional.evaluate_conditional(templar, variable_manager.get_vars())

# Generated at 2022-06-22 16:32:29.219882
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_include import BecomeInclude
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-22 16:32:41.320495
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    p = Conditional()
    assert p._when == []

    p = Conditional(loader=None)
    assert p._when == []

    p = Conditional(loader=None, when=['foo'])
    assert p._when == ['foo']

    p = Conditional(loader=None, when=['foo', 'bar'])
    assert p._when == ['foo', 'bar']

    p = Conditional(loader=None, when=['foo', 'bar', 'baz'])
    assert p._when == ['foo', 'bar', 'baz']

    p = Conditional(loader=None, when=['foo', 'bar', 'baz'])
    assert p

# Generated at 2022-06-22 16:33:25.221068
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class TestConditional(Conditional):
        def __init__(self, loader):
            self._loader = loader


# Generated at 2022-06-22 16:33:35.803143
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'username'
    play_context.port = 22
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.timeout = 10
    play_context.shell = '/bin/sh'
    play_context.executable = None
    play_context.env = dict()


# Generated at 2022-06-22 16:33:47.254701
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader)

    # test with a simple conditional
    conditional = Conditional()
    conditional.when = ['a == 1']
    variable_manager.set_nonpersistent_facts(dict(a=1))
    assert conditional.evaluate

# Generated at 2022-06-22 16:33:59.005333
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("") == []
    assert c.extract_defined_undefined("foo") == []
    assert c.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]

# Generated at 2022-06-22 16:34:10.463572
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("") == []
    assert c.extract_defined_undefined("foo") == []
    assert c.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert c.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert c.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert c.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]

# Generated at 2022-06-22 16:34:20.600230
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:34:28.391732
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is not undefined") == [("foo", "is", "defined"), ("bar", "is not", "undefined")]

# Generated at 2022-06-22 16:34:39.753294
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:34:51.350468
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('localhost'))
    templar = Templar(loader=loader, variables=variable_manager)

    # test with a simple string
    conditional = Conditional()
    conditional.when = 'foo'
    assert conditional.evaluate_conditional(templar, {}) is False

    # test with a simple string
    conditional = Conditional()
    conditional.when = 'foo'
    assert conditional.evaluate_conditional(templar, {'foo': 'bar'}) is True

    # test with a simple string
    conditional = Conditional()
    conditional.when

# Generated at 2022-06-22 16:35:01.750075
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:36:13.073908
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:36:25.379584
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert conditional.extract_defined_undefined("a is not defined") == [("a", "is not", "defined")]
    assert conditional.extract_defined_undefined("a is undefined") == [("a", "is", "undefined")]
    assert conditional.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]
    assert conditional.extract_defined_undefined("a is defined and b is defined") == [("a", "is", "defined"), ("b", "is", "defined")]

# Generated at 2022-06-22 16:36:33.518967
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # Create a Conditional object
    conditional = Conditional()

    # Create a PlayContext object
    play_context = PlayContext()

    # Create a VariableManager object
    variable_manager = VariableManager()

    # Create a Templar object
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    # Create a dict of variables
    all_vars = dict()

    # Test with a valid conditional
    conditional.when = ['1 == 1']
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test with an invalid conditional
    conditional.when = ['1 == 2']
    assert not conditional.evaluate_cond

# Generated at 2022-06-22 16:36:45.097796
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)
    conditional.when = ['foo is defined', 'bar is defined']
    variable_manager.set_nonpersistent_facts(dict(foo='foo'))

# Generated at 2022-06-22 16:36:58.638938
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader, playcontext=play_context)

    # Test with a boolean
    conditional = Conditional()
    conditional.when = True

# Generated at 2022-06-22 16:37:10.041357
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is undefined") == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]

# Generated at 2022-06-22 16:37:22.826585
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is not undefined") == [("foo", "is", "defined"), ("bar", "is not", "undefined")]