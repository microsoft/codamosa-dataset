

# Generated at 2022-06-22 16:27:39.390680
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple conditional
    conditional = Conditional(loader=loader)
    conditional.when = 'ansible_distribution == "CentOS"'
    assert conditional.evaluate_conditional(templar, dict(ansible_distribution='CentOS'))

# Generated at 2022-06-22 16:27:50.345499
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # Create a fake host
    host = type('Host', (object,), {'name': 'localhost'})()

    # Create a fake inventory
    inventory = type('Inventory', (object,), {'hosts': [host]})()

    # Create a fake play
    play = type('Play', (object,), {'hosts': [host], 'name': 'test_play'})()

    # Create a fake task
    task = type('Task', (object,), {'name': 'test_task'})()

    # Create a fake variable manager
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)

    # Create a fake loader

# Generated at 2022-06-22 16:28:02.166672
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:28:13.810087
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("hostvars['foo'] is defined") == [("hostvars['foo']", "is", "defined")]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not defined") == [("hostvars['foo']", "is not", "defined")]
    assert conditional.extract_defined_undefined("hostvars['foo'] is undefined") == [("hostvars['foo']", "is", "undefined")]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not undefined") == [("hostvars['foo']", "is not", "undefined")]

# Generated at 2022-06-22 16:28:24.594539
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class TestConditional(Conditional):
        def __init__(self):
            super(TestConditional, self).__init__()

    class TestPlayContext(PlayContext):
        def __init__(self):
            super(TestPlayContext, self).__init__()

    class TestTemplar(Templar):
        def __init__(self):
            super(TestTemplar, self).__init__()

    test_conditional = TestConditional()
    test_play_context = TestPlayContext()
    test_templar = TestTemplar()

    # Test with no conditional
    test_conditional.when = None

# Generated at 2022-06-22 16:28:35.124533
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory(host_list=['localhost']))
    variable_manager.set_host_variable('localhost', 'foo', 'bar')
    variable_manager.set_host_variable('localhost', 'baz', 'qux')
    variable_manager.set_host_variable('localhost', 'ansible_connection', 'local')

# Generated at 2022-06-22 16:28:47.883607
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class TestConditional(Conditional):
        pass

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    test_conditional = TestConditional()
    test_conditional.when = [
        'foo',
        'bar',
        'baz',
        'qux',
    ]

    assert test_conditional.evaluate_conditional(templar, {}) is False
    assert test_conditional.evaluate_conditional(templar, {'foo': True}) is False
    assert test_conditional.evaluate_conditional(templar, {'foo': True, 'bar': False}) is False

# Generated at 2022-06-22 16:28:57.012226
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    pc = PlayContext()
    t = Templar(loader=None, variables={})

    # Test with a simple conditional
    c = Conditional()
    c.when = [ 'foo' ]
    assert c.evaluate_conditional(t, {'foo': True}) == True
    assert c.evaluate_conditional(t, {'foo': False}) == False

    # Test with a simple conditional and a list
    c = Conditional()
    c.when = [ 'foo' ]
    assert c.evaluate_conditional(t, {'foo': [True]}) == True
    assert c.evaluate_conditional(t, {'foo': [False]}) == False

    # Test with a simple conditional and a list
    c = Conditional

# Generated at 2022-06-22 16:29:10.421144
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # Test case 1:
    #   when:
    #     - foo is defined
    #     - bar is not defined
    #     - baz is defined
    #   tasks:
    #     - debug: msg="all_vars['foo'] is defined"
    #     - debug: msg="all_vars['bar'] is not defined"
    #     - debug: msg="all_vars['baz'] is defined"
    #   expected result:
    #     all_vars['foo'] is defined
    #     all_vars['bar'] is not defined
    #     all_vars['baz'] is defined
    #
    # Test case 2:
    #   when:
    #     - foo is defined
    #    

# Generated at 2022-06-22 16:29:22.758839
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert c.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:29:42.738304
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with a simple string
    conditional = Conditional()
    assert conditional.evaluate_conditional(templar, dict(a=1)) == True

    # Test with a simple string
    conditional = Conditional()
    conditional.when = "a == 1"
    assert conditional.evaluate_conditional(templar, dict(a=1)) == True

    # Test with a simple string
   

# Generated at 2022-06-22 16:29:51.849990
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class MyConditional(Conditional):
        def __init__(self):
            super(MyConditional, self).__init__()
            self.when = ['foo', 'bar', 'baz']

    # test with a simple string
    c = MyConditional()
    pc = PlayContext()
    t = Templar(loader=None, variables={'foo': 'bar'})
    assert c.evaluate_conditional(t, pc)

    # test with a boolean
    c = MyConditional()
    pc = PlayContext()
    t = Templar(loader=None, variables={'foo': True})
    assert c.evaluate_conditional(t, pc)

    # test with a boolean
    c = MyConditional()
    pc

# Generated at 2022-06-22 16:30:03.885546
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    context = PlayContext()
    templar = Templar(loader=None, variables={})

    # test with a simple string
    conditional = Conditional()
    conditional.when = ['foo']
    assert conditional.evaluate_conditional(templar, context)

    # test with a boolean
    conditional = Conditional()
    conditional.when = [True]
    assert conditional.evaluate_conditional(templar, context)

    # test with a boolean
    conditional = Conditional()
    conditional.when = [False]
    assert not conditional.evaluate_conditional(templar, context)

    # test with a list
    conditional = Conditional()
    conditional.when = ['foo', 'bar']
    assert conditional.evaluate_conditional

# Generated at 2022-06-22 16:30:12.264889
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test with a simple conditional
    conditional = 'foo == "bar"'
    all_vars = dict(foo='bar')
    assert Conditional().evaluate_conditional(templar, all_vars)

    # test with

# Generated at 2022-06-22 16:30:21.949526
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    # test setup
    play_context = PlayContext()
    variable_manager = VariableManager()
    hostvars = HostVars(loader=None, variables=dict(foo='bar'))
    variable_manager.set_host_variable(host=None, varname='hostvars', value=hostvars)
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    # test cases

# Generated at 2022-06-22 16:30:32.930121
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class TestConditional(Conditional):
        def __init__(self):
            super(TestConditional, self).__init__()

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    test_conditional = TestConditional()
    test_conditional.when = ['foo']
    assert test_conditional.evaluate_conditional(templar, play_context.get_vars()) is False

    test_conditional.when = ['foo', 'bar']
    assert test_conditional.evaluate_conditional(templar, play_context.get_vars()) is False

    test_conditional.when = ['foo', 'bar', 'baz']
    assert test_cond

# Generated at 2022-06-22 16:30:44.331722
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:30:50.942647
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:31:02.543101
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    templar = Templar(loader=loader, variables=variable_manager)
    play_context = PlayContext()
    play_context.check_mode = False
    play_context.become = False
    play_context.become_method = None
    play_context.become_user = None
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22


# Generated at 2022-06-22 16:31:13.204967
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a test object
    class TestConditional(Conditional):
        def __init__(self):
            self._loader = None
            self._ds = None
            self.when = []

    # Create a test play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = None
    play_context.become_user = None
    play_context.remote_addr = None
    play_context.port = None
    play_context.remote_user = None
    play_context.connection = None
    play_context.timeout = 10
    play_context.shell = None
    play_context.exec

# Generated at 2022-06-22 16:31:40.375239
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class MyConditional(Conditional):
        def __init__(self):
            super(MyConditional, self).__init__()

# Generated at 2022-06-22 16:31:51.522870
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test with a simple string
    conditional = Conditional()
    conditional.when = 'foo'
    assert conditional.evaluate_conditional(templar, dict(foo='bar')) is True

    # test with a boolean
   

# Generated at 2022-06-22 16:32:03.533609
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # test with a simple string
    conditional = Conditional()
    conditional.when = 'foo'
    assert conditional.evaluate_conditional(templar, dict(foo=True)) is True
    assert conditional.evaluate_conditional(templar, dict(foo=False)) is False

    # test with a list
    conditional = Conditional()
    conditional.when = ['foo', 'bar']
    assert conditional.evaluate_conditional(templar, dict(foo=True, bar=True)) is True
    assert conditional.evaluate_conditional

# Generated at 2022-06-22 16:32:13.909974
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert cond.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert cond.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert cond.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert cond.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:32:24.789748
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_inventory(None)
    play_context = PlayContext()
    templar = Templar(loader=None, variables=variable_manager, play_context=play_context)

    conditional = Conditional()

# Generated at 2022-06-22 16:32:37.576273
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # create a dummy inventory
    inventory = InventoryManager(loader=None, sources='')
    host = inventory.get_host("test")
    host.set_variable("foo", "bar")
    host.set_variable("baz", "bam")

    # create a dummy play context
    play_context = PlayContext()
    play_context.prompt = None
    play_context.remote_addr = '127.0.0.1'
    play_context.connection = 'local'
    play_context.network_os = 'Default'
    play_context.become = False
    play_context.become_

# Generated at 2022-06-22 16:32:49.078225
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("") == []
    assert conditional.extract_defined_undefined("foo") == []
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]

# Generated at 2022-06-22 16:32:59.902658
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("") == []
    assert c.extract_defined_undefined("foo") == []
    assert c.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]

# Generated at 2022-06-22 16:33:10.772700
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Conditional):
        def __init__(self, loader):
            self._loader = loader

    # test with a simple conditional
    test_conditional = TestConditional(loader=None)
    test_conditional.when = ['foo']
    test_conditional._ds = None

    all_vars = dict(foo=True)
    templar = Templar(loader=None, variables=all_vars)
    assert test_conditional.evaluate_conditional(templar, all_vars)

    # test with a conditional that should fail
    test_conditional = TestConditional(loader=None)

# Generated at 2022-06-22 16:33:22.576957
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Create a play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'username'
    play_context.port = 22
    play_context.connection = 'ssh'
    play_context.network_os = 'DefaultOS'
    play_context.timeout = 10
    play_context.shell = '/bin/sh'
    play_context.executable = '/bin/sh'
    play_context.only_tags = ['tag1', 'tag2']
   

# Generated at 2022-06-22 16:34:23.571199
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class TestConditional(Conditional):
        def __init__(self):
            self.when = ['foo is defined', 'bar is defined', 'baz is defined']

    test_cond = TestConditional()
    play_context = PlayContext()
    templar = Templar(loader=None, variables={'foo': 'bar', 'bar': 'baz', 'baz': 'foo'})
    assert test_cond.evaluate_conditional(templar, play_context.get_vars())

    test_cond.when = ['foo is defined', 'bar is defined', 'baz is undefined']
    assert not test_cond.evaluate_conditional(templar, play_context.get_vars())


# Generated at 2022-06-22 16:34:33.713871
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a play context
    pc = PlayContext()
    pc.remote_addr = '127.0.0.1'
    pc.port = 22
    pc.remote_user = 'root'
    pc.connection = 'ssh'
    pc.become = False
    pc.become_method = 'sudo'
    pc.become_user = 'root'
    pc.check_mode = False
    pc.diff = False

    # Create a variable manager
    vm = VariableManager()
    vm.extra_vars = {'test_var': 'test_value'}

    # Create a templar

# Generated at 2022-06-22 16:34:46.039628
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake PlayContext
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'username'
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.timeout = 10
    play_context.shell = '/bin/sh'
    play_context.executable = None

# Generated at 2022-06-22 16:34:58.258126
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:35:10.477243
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple string
    conditional = "a == 1"
    all_vars = dict(a=1)
    assert Conditional().evaluate_conditional(templar, all_vars)

    # Test with a simple string
    conditional = "a == 1"
    all_vars = dict(a=2)
    assert not Conditional().evaluate_conditional(templar, all_vars)

    # Test with a simple string
    conditional = "a == 1"

# Generated at 2022-06-22 16:35:21.037132
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_user = None
    play_context.become_method = None
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'test'
    play_context.password = None
    play_context.port = 22
    play_context.private_key_file = None
    play_context.connection = 'ssh'
    play_context.timeout = 10
    play_context.shell = None
    play_context.env = dict()

# Generated at 2022-06-22 16:35:32.525132
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake inventory
    class FakeInventory(object):
        def __init__(self):
            self.hosts = {'localhost': {'vars': {'var1': 'value1', 'var2': 'value2'}}}
            self.groups = {'group1': {'hosts': ['localhost']}}

    # Create a fake loader
    class FakeLoader(object):
        def __init__(self):
            self.inventory = FakeInventory()

    # Create a fake variable manager
    class FakeVariableManager(VariableManager):
        def __init__(self):
            self.extra_vars = {'var3': 'value3'}

# Generated at 2022-06-22 16:35:45.492060
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # test for boolean
    conditional = Conditional()
    conditional.when = [True]
    assert conditional.evaluate_conditional(templar, {})

    # test for string
    conditional = Conditional()
    conditional.when = ['True']
    assert conditional.evaluate_conditional(templar, {})

    # test for string
    conditional = Conditional

# Generated at 2022-06-22 16:35:53.959511
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)
    conditional.when = [
        'foo',
        'bar',
        'baz'
    ]

    all_vars = {
        'foo': True,
        'bar': False,
        'baz': True
    }

    assert conditional.evaluate_conditional(templar, all_vars) == False

# Generated at 2022-06-22 16:36:06.058663
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    c = Conditional()
    assert c._when == []

    c = Conditional(loader=None)
    assert c._when == []

    c = Conditional(loader=None, when=['foo'])
    assert c._when == ['foo']

    c = Conditional(loader=None, when=['foo', 'bar'])
    assert c._when == ['foo', 'bar']

    c = Conditional(loader=None, when=['foo', 'bar'])
    c._when = ['baz']
    assert c._when == ['baz']

    c = Conditional(loader=None, when=['foo', 'bar'])

# Generated at 2022-06-22 16:37:11.263734
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Conditional):
        def __init__(self, loader=None):
            super(TestConditional, self).__init__(loader)

    # test with no conditional
    test_conditional = TestConditional()
    assert test_conditional.evaluate_conditional(Templar(loader=None, variables=VariableManager()), {})

    # test with a conditional that evaluates to True
    test_conditional = TestConditional()
    test_conditional._when = ["True"]
    assert test_conditional.evaluate_conditional(Templar(loader=None, variables=VariableManager()), {})

    # test with a conditional that evaluates to False
    test

# Generated at 2022-06-22 16:37:23.601990
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    # Test with a simple boolean
    conditional = Conditional()
    conditional.when = [True]
    assert conditional.evaluate_conditional(templar, play_context)

    # Test with a simple string
    conditional = Conditional()
    conditional.when = ['True']
    assert conditional.evaluate_conditional(templar, play_context)

    # Test with a simple string
    conditional = Conditional()
    conditional.when = ['False']
    assert not conditional.evaluate_conditional(templar, play_context)

    # Test with a simple string
    conditional = Conditional()