

# Generated at 2022-06-22 16:27:50.345762
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:28:02.125123
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = 'ansible_distribution == "CentOS"'
    assert conditional.evaluate_conditional(templar, {}) == False

    # Test with a complex conditional

# Generated at 2022-06-22 16:28:13.454534
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:28:24.510593
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is not defined') == [('hostvars[inventory_hostname]', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is undefined') == [('hostvars[inventory_hostname]', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is not undefined') == [('hostvars[inventory_hostname]', 'is not', 'undefined')]
    assert conditional.extract

# Generated at 2022-06-22 16:28:35.081887
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.base import Base
    from ansible.template import Templar

    class TestConditional(Base, Conditional):
        pass

    test_conditional = TestConditional()
    templar = Templar(loader=None, variables={})

    # Test 1
    conditional = "hostvars['foo'] is defined"
    results = test_conditional.extract_defined_undefined(conditional)
    assert results == [('hostvars[\'foo\']', 'is', 'defined')]

    # Test 2
    conditional = "hostvars['foo'] is not defined"
    results = test_conditional.extract_defined_undefined(conditional)
    assert results == [('hostvars[\'foo\']', 'is not', 'defined')]

    # Test 3

# Generated at 2022-06-22 16:28:47.883895
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_from_file("tests/inventory"))
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with a simple string
    conditional = Conditional()
    conditional.when = 'foo'
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars())

    # Test with a simple string
    conditional = Conditional()
    conditional.when = 'foo'
   

# Generated at 2022-06-22 16:28:53.560805
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('tests/inventory'))
    templar = Templar(loader=loader, variables=variable_manager)

    # test with a simple string
    conditional = Conditional(loader=loader)
    conditional.when = 'foo'
    assert conditional.evaluate_conditional(templar, dict(foo='bar'))

    # test with a boolean
    conditional = Conditional(loader=loader)
    conditional.when = True
    assert conditional.evaluate_conditional(templar, dict())

    # test with a boolean
    conditional = Conditional(loader=loader)

# Generated at 2022-06-22 16:29:08.641655
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined and bar is undefined") == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not defined and bar is not undefined") == [('foo', 'is not', 'defined'), ('bar', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]

# Generated at 2022-06-22 16:29:15.319244
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader, playcontext=play_context)

    # test with a simple conditional
    conditional = Conditional()
    conditional.when = [ '1 == 1' ]

# Generated at 2022-06-22 16:29:24.748407
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Conditional):
        def __init__(self, loader=None):
            super(TestConditional, self).__init__(loader)

    pc = PlayContext()
    t = Templar(loader=None, variables=VariableManager())
    c = TestConditional(loader=None)

    # Test with a boolean
    c.when = [True]
    assert c.evaluate_conditional(t, dict())

    # Test with a string
    c.when = ["foo"]
    assert not c.evaluate_conditional(t, dict())

    # Test with a string that evaluates to True
    c.when = ["True"]
    assert c.evaluate_conditional

# Generated at 2022-06-22 16:29:50.997959
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Conditional):
        def __init__(self, loader, variable_manager, play_context):
            self._loader = loader
            self._templar = Templar(loader=loader, variables=variable_manager.get_vars(play=play_context, include_hostvars=True))
            self._variable_manager = variable_manager
            self._play_context = play_context

    # Test with a simple conditional
    conditional = TestConditional(loader=None, variable_manager=VariableManager(), play_context=PlayContext())
    conditional.when = [ "foo == 'bar'" ]

# Generated at 2022-06-22 16:30:00.815351
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:30:11.405953
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("hostvars['foo'] is defined") == [("hostvars['foo']", "is", "defined")]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not defined") == [("hostvars['foo']", "is not", "defined")]
    assert conditional.extract_defined_undefined("hostvars['foo'] is undefined") == [("hostvars['foo']", "is", "undefined")]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not undefined") == [("hostvars['foo']", "is not", "undefined")]

# Generated at 2022-06-22 16:30:17.409535
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    # Test with a simple conditional
    conditional_str = "hostvars['foo'] is defined"
    assert conditional.extract_defined_undefined(conditional_str) == [('hostvars[\'foo\']', 'is', 'defined')]

    # Test with a conditional with multiple defined/undefined tests
    conditional_str = "hostvars['foo'] is defined and hostvars['bar'] is not defined"
    assert conditional.extract_defined_undefined(conditional_str) == [('hostvars[\'foo\']', 'is', 'defined'), ('hostvars[\'bar\']', 'is not', 'defined')]

    # Test with a conditional with multiple defined/undefined tests and other stuff

# Generated at 2022-06-22 16:30:29.158530
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_user = None
    play_context.become_method = None
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'test'
    play_context.connection = 'local'
    play_context.port = 22
    play_context.password = None
    play_context.private_key_file = None
    play_context.timeout = 10
    play_context.shell = None
    play_context.executor_path = None
    play_context.environment = dict()
    play_context.only_tags = []

# Generated at 2022-06-22 16:30:36.041545
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("") == []
    assert conditional.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert conditional.extract_defined_undefined("a is not defined") == [("a", "is not", "defined")]
    assert conditional.extract_defined_undefined("a is undefined") == [("a", "is", "undefined")]
    assert conditional.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]
    assert conditional.extract_defined_undefined("a is defined and b is defined") == [("a", "is", "defined"), ("b", "is", "defined")]

# Generated at 2022-06-22 16:30:47.917055
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()

    # Create a fake variable manager
    variable_manager = VariableManager()

    # Create a fake loader
    loader = 'fake loader'

    # Create a fake templar
    templar = Templar(loader=loader, variables=variable_manager)

    # Create a fake conditional object
    conditional = Conditional(loader=loader)

    # Create a fake all_vars

# Generated at 2022-06-22 16:30:55.228031
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:31:07.237165
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, shared_loader_obj=loader)

    conditional = Conditional(loader=loader)
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars(play=play_context)) == True

    conditional = Conditional(loader=loader)
    conditional.when = [True]
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars(play=play_context)) == True

   

# Generated at 2022-06-22 16:31:18.000113
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a Task
    task = Task()

# Generated at 2022-06-22 16:31:43.307616
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("") == []
    assert conditional.extract_defined_undefined("foo") == []
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]

# Generated at 2022-06-22 16:31:45.944513
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.base import Base
    class TestConditional(Base, Conditional):
        pass
    test_conditional = TestConditional()
    assert test_conditional.when == []


# Generated at 2022-06-22 16:31:53.612352
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = ['1 == 1']
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars())

    # Test with a simple conditional that

# Generated at 2022-06-22 16:32:05.884462
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is not undefined") == [('foo', 'is', 'defined'), ('bar', 'is not', 'undefined')]

# Generated at 2022-06-22 16:32:15.405261
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("hostvars['foo'] is defined") == [("hostvars['foo']", "is", "defined")]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not defined") == [("hostvars['foo']", "is not", "defined")]
    assert conditional.extract_defined_undefined("hostvars['foo'] is undefined") == [("hostvars['foo']", "is", "undefined")]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not undefined") == [("hostvars['foo']", "is not", "undefined")]
    assert conditional.extract_defined_undefined("hostvars['foo'] is defined and hostvars['bar'] is defined")

# Generated at 2022-06-22 16:32:23.279818
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class TestConditional(Conditional):
        def __init__(self, loader=None):
            super(TestConditional, self).__init__(loader=loader)

    class TestPlayContext(PlayContext):
        def __init__(self):
            super(TestPlayContext, self).__init__()
            self.prompt = None

    class TestTemplar(Templar):
        def __init__(self, loader=None, variables=None):
            super(TestTemplar, self).__init__(loader=loader, variables=variables)

    class TestLoader(object):
        def __init__(self):
            self.path_dwim = lambda x: x

    loader = TestLoader()
    tem

# Generated at 2022-06-22 16:32:30.275439
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class MyConditional(Conditional):
        def __init__(self, ds, loader):
            self._ds = ds
            self._loader = loader

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    # Test with a simple string
    my_conditional = MyConditional(ds=None, loader=None)
    my_conditional.when = ["foo"]
    assert my_conditional.evaluate_conditional(templar, play_context.acquire_lock())

    # Test with a simple string and a variable
    my_conditional = MyConditional(ds=None, loader=None)
    my_conditional.when = ["foo", "bar"]

# Generated at 2022-06-22 16:32:34.629911
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    conditional = Conditional()
    conditional.when = ['foo', 'bar']
    variable_manager.set_nonpersistent_facts(dict(foo=True, bar=True))
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars(play=play_context))

    conditional = Conditional()
    conditional.when = ['foo', 'bar']
    variable_manager.set_nonpersistent_facts(dict(foo=True, bar=False))

# Generated at 2022-06-22 16:32:44.238365
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Setup
    play_context = PlayContext()
    templar = Templar(loader=None, variables={})
    conditional = Conditional(loader=None)

# Generated at 2022-06-22 16:32:55.224719
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    templar = Templar(loader=loader, variables=variable_manager)

    # test with a boolean
    conditional = Conditional(loader=loader)
    conditional.when = True
    assert conditional.evaluate_conditional(templar, {}) == True

    # test with a string
    conditional = Conditional(loader=loader)
    conditional.when = "True"
    assert conditional.evaluate_conditional(templar, {}) == True

# Generated at 2022-06-22 16:33:34.057915
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is not undefined") == [("foo", "is", "defined"), ("bar", "is not", "undefined")]

# Generated at 2022-06-22 16:33:45.509621
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'username'
    play_context.port = 22
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.timeout = 10
    play_context.shell = '/bin/sh'
    play_context.executable = None

# Generated at 2022-06-22 16:33:56.696955
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert cond.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert cond.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert cond.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert cond.extract_defined_undefined("foo is defined and bar is not undefined") == [("foo", "is", "defined"), ("bar", "is not", "undefined")]

# Generated at 2022-06-22 16:34:08.740127
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:34:22.202756
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test with a simple string
    conditional = Conditional()
    conditional.when = ['test']
    assert conditional.evaluate_conditional(templar, {})

    # test with a boolean
    conditional = Conditional()

# Generated at 2022-06-22 16:34:32.735490
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert cond.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert cond.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert cond.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert cond.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:34:45.057532
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert c.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert c.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert c.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert c.extract_defined_undefined("foo is defined and bar is undefined") == [("foo", "is", "defined"), ("bar", "is", "undefined")]

# Generated at 2022-06-22 16:34:57.433122
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    p = PlayContext()
    t = Templar(loader=None, variables=VariableManager())
    c = Conditional(loader=None)

    assert c.when == []
    c.when = 'foo'
    assert c.when == ['foo']
    c.when = ['foo', 'bar']
    assert c.when == ['foo', 'bar']
    c.when = 'foo'
    assert c.when == ['foo']

    c.when = 'foo'
    assert c.evaluate_conditional(t, {}) == False

    c.when = 'foo'
    assert c.evaluate_conditional(t, {'foo': 'bar'}) == True

    c

# Generated at 2022-06-22 16:35:09.085471
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("") == []
    assert c.extract_defined_undefined("a") == []
    assert c.extract_defined_undefined("a is defined") == [('a', 'is', 'defined')]
    assert c.extract_defined_undefined("a is not defined") == [('a', 'is not', 'defined')]
    assert c.extract_defined_undefined("a is undefined") == [('a', 'is', 'undefined')]
    assert c.extract_defined_undefined("a is not undefined") == [('a', 'is not', 'undefined')]

# Generated at 2022-06-22 16:35:20.997947
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-22 16:36:04.800339
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("a is defined") == [('a', 'is', 'defined')]
    assert conditional.extract_defined_undefined("a is not defined") == [('a', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("a is undefined") == [('a', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("a is not undefined") == [('a', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("a is defined and b is defined") == [('a', 'is', 'defined'), ('b', 'is', 'defined')]

# Generated at 2022-06-22 16:36:15.042418
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'username'

    # Create a variable manager
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'a': '1', 'b': '2', 'c': '3'}

# Generated at 2022-06-22 16:36:26.173988
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test with a simple conditional
    conditional = Conditional()
    conditional.when = ['foo']
    all_vars = dict(foo=True)
    assert conditional.evaluate_conditional(templar, all_vars)

    # test with a conditional that evaluates to False
    conditional = Conditional()
    conditional.when = ['foo']

# Generated at 2022-06-22 16:36:33.927375
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is not undefined") == [("foo", "is", "defined"), ("bar", "is not", "undefined")]

# Generated at 2022-06-22 16:36:45.340496
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader, playcontext=play_context)

    conditional = Conditional()
    conditional.when = ['foo', 'bar']
    variable_manager.set_nonpersistent_facts(dict(foo=True, bar=True))
    assert conditional.evaluate

# Generated at 2022-06-22 16:36:52.782910
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Test with a simple conditional
    conditional = "foo == 'bar'"
    all_vars = dict(foo='bar')
    context = PlayContext()
    templar = Templar(loader=None, variables=all_vars, shared_loader_obj=None, context=context)
    assert Conditional().evaluate_conditional(templar, all_vars)

    # Test with a simple conditional that should fail
    conditional = "foo == 'bar'"
    all_vars = dict(foo='baz')
    context = PlayContext()
    templar = Templar(loader=None, variables=all_vars, shared_loader_obj=None, context=context)

# Generated at 2022-06-22 16:37:01.908580
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    # Test with a simple string
    conditional = Conditional()
    conditional.when = 'foo'
    assert conditional.evaluate_conditional(variable_manager.template, variable_manager.get_vars(play_context=play_context))

    # Test with a list
    conditional = Conditional()
    conditional.when = ['foo', 'bar']

# Generated at 2022-06-22 16:37:12.032711
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    conditional = Conditional()
    conditional.when = ['foo is defined', 'bar is defined']
    assert conditional.evaluate_conditional(templar, {}) is False
    assert conditional.evaluate_conditional(templar, {'foo': 'bar'}) is False
    assert conditional.evaluate_conditional(templar, {'foo': 'bar', 'bar': 'foo'}) is True

    conditional.when = ['foo is defined', 'bar is not defined']
    assert conditional.evaluate_conditional(templar, {}) is False
    assert conditional.evaluate_conditional(templar, {'foo': 'bar'})

# Generated at 2022-06-22 16:37:23.702410
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    conditional = Conditional()
    conditional.when = ['foo is defined']
    assert conditional.evaluate_conditional(templar, {}) is False

    conditional.when = ['foo is defined', 'bar is defined']
    assert conditional.evaluate_conditional(templar, {}) is False

    conditional.when = ['foo is defined', 'bar is defined', 'baz is defined']
    assert conditional.evaluate_conditional(templar, {}) is False

    conditional.when = ['foo is defined', 'bar is defined', 'baz is defined', 'qux is defined']

# Generated at 2022-06-22 16:37:31.319750
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert c.extract_defined_undefined('foo is defined and bar is undefined') == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]