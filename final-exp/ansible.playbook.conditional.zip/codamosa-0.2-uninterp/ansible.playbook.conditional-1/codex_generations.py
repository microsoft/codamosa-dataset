

# Generated at 2022-06-22 16:27:44.060030
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("a is defined and b is defined") == [('a', 'is', 'defined'), ('b', 'is', 'defined')]
    assert conditional.extract_defined_undefined("a is defined and b is not defined") == [('a', 'is', 'defined'), ('b', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("a is not defined and b is not defined") == [('a', 'is not', 'defined'), ('b', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("a is defined and b is undefined") == [('a', 'is', 'defined'), ('b', 'is', 'undefined')]

# Generated at 2022-06-22 16:27:51.651119
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Base, Conditional):
        pass

    # test with no loader
    try:
        c = TestConditional()
        assert False
    except AnsibleError:
        pass

    # test with loader
    c = TestConditional(loader=None)
    assert c._loader is None

    # test with loader and ds
    c = TestConditional(loader=None, ds=dict())
    assert c._loader is None
    assert c._ds == dict()

    # test with loader and ds and when
    c = TestConditional(loader=None, ds=dict(), when=['a'])
    assert c._loader is None

# Generated at 2022-06-22 16:28:03.238245
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple string
    conditional = Conditional()
    conditional.when = "ansible_distribution == 'Ubuntu'"
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars(loader=loader, play=None, host=None))

    # Test with a list of strings
    conditional = Conditional()
    conditional.when

# Generated at 2022-06-22 16:28:14.639902
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple conditional
    conditional = 'foo == "bar"'
    all_vars = dict(foo='bar')
    assert Conditional().evaluate_conditional(templar, all_vars)

    # Test with a simple conditional that fails
    conditional = 'foo == "bar"'
    all_vars = dict(foo='baz')
    assert not Conditional().evaluate_conditional(templar, all_vars)

    # Test with a simple conditional that fails
    conditional = 'foo == "bar"'
    all

# Generated at 2022-06-22 16:28:20.558271
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    conditional = Conditional()
    conditional.when = ['foo', 'bar']

    assert conditional.evaluate_conditional(templar, play_context) == True


# Generated at 2022-06-22 16:28:33.793798
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:28:42.980247
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("") == []
    assert c.extract_defined_undefined("foo") == []
    assert c.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert c.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert c.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert c.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]

# Generated at 2022-06-22 16:28:53.926026
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)
    conditional.when = ['foo', 'bar']
    assert conditional.evaluate_conditional(templar, {}) is False

    conditional.when = ['foo', 'bar', 'True']

# Generated at 2022-06-22 16:29:08.688126
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)
    conditional._when = [True, False]
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars(play=None, host=None, task=None)) == False
    conditional._when = [True, True]

# Generated at 2022-06-22 16:29:20.970232
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is not undefined") == [("foo", "is", "defined"), ("bar", "is not", "undefined")]

# Generated at 2022-06-22 16:29:47.805955
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("") == []
    assert c.extract_defined_undefined("foo") == []
    assert c.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert c.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert c.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert c.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]

# Generated at 2022-06-22 16:29:56.673479
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class TestConditional(Conditional):
        def __init__(self, loader=None):
            super(TestConditional, self).__init__(loader)
            self.when = []

    # test 1: simple boolean
    test_conditional = TestConditional()
    test_conditional.when = [True]
    assert test_conditional.evaluate_conditional(Templar(loader=None, variables={}), {})

    # test 2: simple boolean
    test_conditional = TestConditional()
    test_conditional.when = [False]
    assert not test_conditional.evaluate_conditional(Templar(loader=None, variables={}), {})

    # test 3: simple string
    test_cond

# Generated at 2022-06-22 16:30:07.135344
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test_var': 'test_value'}
    templar = Templar(loader=loader, variables=variable_manager)

    conditional = Conditional()

# Generated at 2022-06-22 16:30:20.949597
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('localhost'))
    templar = Templar(loader=loader, variables=variable_manager)

    # test for undefined variable
    conditional = 'foo is defined'
    all_vars = dict()
    assert not Conditional().evaluate_conditional(templar, all_vars)

    # test for defined variable
    conditional = 'foo is defined'
    all_vars = dict(foo='bar')
    assert Conditional().evaluate_conditional(templar, all_vars)

    # test for undefined variable with not

# Generated at 2022-06-22 16:30:32.311478
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert c.extract_defined_undefined('foo is defined and bar is undefined') == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]

# Generated at 2022-06-22 16:30:43.651720
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'username'
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.accelerate = False
    play_context.accelerate_port = 5099
    play_context.accelerate_ipv6 = False
    play

# Generated at 2022-06-22 16:30:50.007142
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:30:57.211693
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is not undefined") == [("foo", "is", "defined"), ("bar", "is not", "undefined")]

# Generated at 2022-06-22 16:31:04.338318
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    conditional = Conditional(loader=loader)
    assert conditional is not None
    assert conditional._loader == loader
    assert conditional._ds is None
    assert conditional._when == []

    conditional = Conditional(loader=loader, ds=dict(when=['test']))
    assert conditional is not None
    assert conditional._loader == loader

# Generated at 2022-06-22 16:31:13.329405
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is not defined') == [('hostvars[inventory_hostname]', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is undefined') == [('hostvars[inventory_hostname]', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is not undefined') == [('hostvars[inventory_hostname]', 'is not', 'undefined')]
    assert conditional.extract

# Generated at 2022-06-22 16:31:53.079516
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class TestConditional(Conditional):
        def __init__(self, loader, variable_manager, play_context):
            self._loader = loader
            self._variable_manager = variable_manager
            self._play_context = play_context

    test_conditional = TestConditional(None, None, PlayContext())

    # Test with a simple conditional
    test_conditional.when = ['foo']
    templar = Templar(loader=None, variables={'foo': True})
    assert test_conditional.evaluate_conditional(templar, {})

    # Test with a conditional that uses a variable
    test_conditional.when = ['foo == bar']

# Generated at 2022-06-22 16:32:05.494439
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'username'
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.accelerate = False
    play_context.accelerate_port = 5099
    play_context.accelerate_ipv6 = False
    play

# Generated at 2022-06-22 16:32:15.161961
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Create a Conditional object
    conditional = Conditional()

    # Create a PlayContext object
    play_context = PlayContext()

    # Create a Templar object
    templar = Templar(loader=None, variables={})

    # Create a dict of all variables
    all_vars = dict()

    # Test the method with a conditional that evaluates to True
    conditional.when = ['1 == 1']
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test the method with a conditional that evaluates to False
    conditional.when = ['1 == 2']
    assert not conditional.evaluate_conditional(templar, all_vars)

    # Test the method with a conditional that evaluates to True

# Generated at 2022-06-22 16:32:20.123849
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # test with a simple string
    conditional = 'foo'
    all_vars = dict(foo='bar')
    assert Conditional().evaluate_conditional(templar, all_vars)

    # test with a boolean
    conditional = True
    all_vars = dict(foo='bar')
    assert Conditional().evaluate_conditional(templar, all_vars)

    # test with a simple string
    conditional = 'foo'
    all_vars = dict(foo='bar')
    assert Conditional().evaluate_

# Generated at 2022-06-22 16:32:30.755081
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    conditional = Conditional(loader=None)
    conditional.when = [True]
    assert conditional.evaluate_conditional(templar, play_context)

    conditional.when = [False]
    assert not conditional.evaluate_conditional(templar, play_context)

    conditional.when = [True, False]
    assert not conditional.evaluate_conditional(templar, play_context)

    conditional.when = [False, True]
    assert not conditional.evaluate_conditional(templar, play_context)

    conditional.when = [True, True]

# Generated at 2022-06-22 16:32:42.383854
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)
    conditional.when = ['foo is defined', 'bar is not defined']
    variable_manager.set_nonpersistent_facts(dict(foo='foo'))
    assert conditional.evaluate_conditional

# Generated at 2022-06-22 16:32:54.525770
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    hostvars = HostVars(loader=loader, variable_manager=variable_manager)
    variable_manager.set_host_variable(host=None, varname='hostvars', value=hostvars)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)
    conditional = Conditional(loader=loader)

    # Test with a single conditional

# Generated at 2022-06-22 16:33:07.465112
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple string
    conditional = Conditional()
    conditional.when = ["foo"]
    assert conditional.evaluate_conditional(templar, dict(foo="bar"))

    # Test with a list of strings
    conditional = Conditional()
    conditional.when = ["foo", "bar"]
    assert conditional.evaluate_conditional(templar, dict(foo="bar", bar="baz"))

    # Test with a list of strings and a boolean
    conditional = Conditional()

# Generated at 2022-06-22 16:33:14.167771
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Test case 1
    conditional = "hostvars['foo'] is defined and hostvars['bar'] is not defined"
    expected = [('hostvars[\'foo\']', 'is', 'defined'), ('hostvars[\'bar\']', 'is not', 'defined')]
    actual = Conditional().extract_defined_undefined(conditional)
    assert actual == expected, "Expected %s, got %s" % (expected, actual)

    # Test case 2
    conditional = "hostvars['foo'] is defined and hostvars['bar'] is not defined and hostvars['baz'] is defined"

# Generated at 2022-06-22 16:33:19.596481
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context._set_task_and_variable_override('all', dict(a=1, b=2, c=3, d=4, e=5, f=6, g=7, h=8, i=9, j=10, k=11, l=12, m=13, n=14, o=15, p=16, q=17, r=18, s=19, t=20, u=21, v=22, w=23, x=24, y=25, z=26))

    # Create a fake variable manager
    variable_manager = VariableManager()
    variable_

# Generated at 2022-06-22 16:35:12.850826
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional()

    # Test with a list of conditionals
    conditional.when = [
        "ansible_os_family == 'RedHat'",
        "ansible_os_family == 'Debian'",
    ]
    all_vars = variable_manager.get_vars(play=None, host=None, task=None)

# Generated at 2022-06-22 16:35:21.712891
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-22 16:35:32.699242
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader, play_context=play_context)

    conditional = Conditional(loader=loader)

# Generated at 2022-06-22 16:35:45.619960
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'username'
    play_context.port = 22
    play_context.connection = 'ssh'
    play_context.network_os = 'DefaultOS'
    play_context.timeout = 10
    play_context.shell = '/bin/sh'
    play_context.executable = '/bin/sh'

# Generated at 2022-06-22 16:35:54.032313
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert c.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert c.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert c.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert c.extract_defined_undefined("foo is defined and bar is not undefined") == [("foo", "is", "defined"), ("bar", "is not", "undefined")]

# Generated at 2022-06-22 16:36:06.147683
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    conditional = Conditional()

# Generated at 2022-06-22 16:36:17.695162
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    conditional = Conditional()

# Generated at 2022-06-22 16:36:29.463533
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    hostvars = HostVars(loader=loader, variable_manager=variable_manager)
    variable_manager.set_host_variable(host='localhost', varname='hostvars', value=hostvars)
    variable_manager.set_host_variable(host='localhost', varname='inventory_hostname', value='localhost')
    variable_manager.set_host_variable(host='localhost', varname='inventory_hostname_short', value='localhost')
    variable_manager

# Generated at 2022-06-22 16:36:40.295088
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    conditional = Conditional(loader=loader)
    conditional.when = [{'test': 'test'}]
    conditional.evaluate_conditional(variable_manager, play_context)

# Generated at 2022-06-22 16:36:50.422490
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)
    conditional = Conditional(loader=loader)
    assert conditional is not None
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars(play=None, host=None, task=None)) is True
    conditional.when = [True]