

# Generated at 2022-06-22 16:27:43.904823
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    variable_manager.options_vars = {'baz': 'qux'}
    variable_manager.set_nonpersistent_facts({'fizz': 'buzz'})
    variable_manager.set_host_variable('localhost', 'ansible_all_ipv4_addresses', ['127.0.0.1'])
    variable_manager.set_host_variable('localhost', 'ansible_all_ipv6_addresses', ['::1'])

# Generated at 2022-06-22 16:27:51.541402
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    pc = PlayContext()
    templar = Templar(loader=None, variables={})
    c = Conditional(loader=None)
    c._when = [True]
    assert c.evaluate_conditional(templar, pc)

    c._when = [False]
    assert not c.evaluate_conditional(templar, pc)

    c._when = [True, False]
    assert not c.evaluate_conditional(templar, pc)

    c._when = [False, True]
    assert not c.evaluate_conditional(templar, pc)

    c._when = [False, False]
    assert not c.evaluate_conditional(templar, pc)


# Generated at 2022-06-22 16:28:03.122217
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = None
    play_context.become_user = None
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'remote_user'
    play_context.connection = 'local'
    play_context.network_os = None
    play_context.timeout = 10
    play_context.shell = None
    play_context.executor_path = None
    play_context.no_log = False

# Generated at 2022-06-22 16:28:14.641090
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, shared_loader_obj=loader)

    conditional = Conditional()

# Generated at 2022-06-22 16:28:25.069676
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Test case 1:
    #   when:
    #     - test1
    #     - test2
    #     - test3
    #   vars:
    #     test1: True
    #     test2: False
    #     test3: True
    #   expected: True
    #   reason: All conditions are True
    test_case_1 = dict(
        when=['test1', 'test2', 'test3'],
        vars=dict(
            test1=True,
            test2=False,
            test3=True,
        ),
        expected=True,
        reason='All conditions are True',
    )

    # Test case

# Generated at 2022-06-22 16:28:37.479743
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a Conditional object
    conditional = Conditional()

    # Create a PlayContext object
    play_context = PlayContext()

    # Create a VariableManager object
    variable_manager = VariableManager()

    # Create a Templar object
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    # Create a dictionary of variables
    all_vars = dict()

    # Test with a conditional that evaluates to True
    conditional.when = ['True']
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test with a conditional that evaluates to False
    conditional.when = ['False']
    assert not conditional

# Generated at 2022-06-22 16:28:47.984801
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Conditional):
        def __init__(self, loader=None):
            super(TestConditional, self).__init__(loader=loader)

    class TestPlayContext(PlayContext):
        def __init__(self):
            super(TestPlayContext, self).__init__()

    class TestVariableManager(VariableManager):
        def __init__(self):
            super(TestVariableManager, self).__init__()

    class TestTemplar(Templar):
        def __init__(self, loader=None, variables=None):
            super(TestTemplar, self).__init__(loader=loader, variables=variables)


# Generated at 2022-06-22 16:28:53.607319
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("hostvars['foo'] is defined") == [('hostvars[\'foo\']', 'is', 'defined')]
    assert cond.extract_defined_undefined("hostvars['foo'] is not defined") == [('hostvars[\'foo\']', 'is not', 'defined')]
    assert cond.extract_defined_undefined("hostvars['foo'] is undefined") == [('hostvars[\'foo\']', 'is', 'undefined')]
    assert cond.extract_defined_undefined("hostvars['foo'] is not undefined") == [('hostvars[\'foo\']', 'is not', 'undefined')]

# Generated at 2022-06-22 16:29:00.800156
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:29:12.791055
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:29:27.102043
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:29:41.023125
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # test with a single conditional
    conditional = Conditional()
    conditional.when = "ansible_distribution == 'Debian'"
    assert conditional.evaluate_conditional(templar, dict(ansible_distribution='Debian'))
    assert not conditional.evaluate_conditional(templar, dict(ansible_distribution='RedHat'))

    # test with a list of conditionals
    conditional = Conditional()

# Generated at 2022-06-22 16:29:51.102180
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a variable manager
    variable_manager = VariableManager()
    loader = DataLoader()
    # Create a template object
    templar = Templar(loader=loader, variables=variable_manager)

    # Create a Conditional object
    conditional = Conditional()

    # Test with a valid conditional
    conditional.when = ['ansible_os_family == "RedHat"']
    all_vars = variable_manager.get_vars(loader=loader, play=None)
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test with an invalid conditional

# Generated at 2022-06-22 16:30:00.815752
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy

    play_context = PlayContext()
    variable_manager = VariableManager()
    hostvars = HostVars(loader=None, variables=dict(a=1, b=2, c=3))
    variable_manager.set_host_variable(host=None, varname='hostvars', value=hostvars)
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)
    all_vars = variable_manager.get_vars(play=None, host=None)

    conditional

# Generated at 2022-06-22 16:30:06.877738
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-22 16:30:17.167782
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = Host(name='localhost')
    host.set_variable('ansible_connection', 'local')
    group = Group(name='ungrouped')
    group.add_host(host)
    inventory.add_group(group)
    inventory.add_host(host)

    variable_

# Generated at 2022-06-22 16:30:28.833209
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_user = None
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'root'
    play_context.connection = 'ssh'
    play_context.network_os = None
    play_context.timeout = 10
    play_context.shell = None
    play_context.executor_path = C.DEFAULT_EXECUTABLE
    play_context.become_method = 'sudo'
    play_context.become_

# Generated at 2022-06-22 16:30:38.893376
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    c = Conditional()
    assert c._when == []

    c = Conditional(loader=None)
    assert c._when == []

    c = Conditional(loader=None, when=['foo'])
    assert c._when == ['foo']

    c = Conditional(loader=None, when=['foo', 'bar'])
    assert c._when == ['foo', 'bar']

    c = Conditional(loader=None, when=['foo', 'bar'])
    assert c._when == ['foo', 'bar']

    c = Conditional(loader=None, when=['foo', 'bar'])
    assert c._when == ['foo', 'bar']

    c

# Generated at 2022-06-22 16:30:48.838587
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # Test when conditional is None
    conditional = Conditional(loader=loader)
    conditional.when = None
    assert conditional.evaluate_conditional(templar, {})

    # Test when conditional is empty string
    conditional = Conditional(loader=loader)
    conditional.when = ''
    assert conditional.evaluate_conditional(templar, {})

    #

# Generated at 2022-06-22 16:31:00.452831
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("") == []
    assert cond.extract_defined_undefined("foo") == []
    assert cond.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert cond.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert cond.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert cond.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]

# Generated at 2022-06-22 16:31:25.295473
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Conditional):
        pass

    test_conditional = TestConditional()

    # Test with empty conditional
    assert test_conditional.evaluate_conditional(Templar(VariableManager(), PlayContext()), {})

    # Test with a single conditional
    test_conditional.when = [True]
    assert test_conditional.evaluate_conditional(Templar(VariableManager(), PlayContext()), {})

    test_conditional.when = [False]
    assert not test_conditional.evaluate_conditional(Templar(VariableManager(), PlayContext()), {})

    # Test with multiple conditionals

# Generated at 2022-06-22 16:31:30.842115
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert c.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert c.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert c.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert c.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:31:41.349659
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    # Setup
    play_context = PlayContext()
    variable_manager = VariableManager()
    hostvars = HostVars(loader=None, variables=dict())
    variable_manager.set_host_variable(host=None, varname='hostvars', value=hostvars)
    templar = Templar(loader=None, variables=variable_manager)

    # Test
    conditional = Conditional()
    conditional.when = ['foo', 'bar']
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars(play=None, host=None, task=None)) == False

# Generated at 2022-06-22 16:31:54.437928
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    conditional = Conditional()
    conditional.when = [
        'foo is defined',
        'bar is not defined',
        'baz is defined',
        'qux is not defined',
        'quux is defined',
        'corge is not defined',
        'grault is defined',
        'garply is not defined',
        'waldo is defined',
        'fred is not defined',
        'plugh is defined',
        'xyzzy is not defined',
        'thud is defined',
    ]

    # test with empty variables
    assert conditional.evaluate_conditional(templar, {}) is False

    #

# Generated at 2022-06-22 16:32:06.828322
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    templar = Templar(loader=loader, variables=variable_manager)

    # test with a simple conditional
    conditional = Conditional()
    conditional.when = ['foo is bar']
    all_vars = dict(foo='bar')
    assert conditional.evaluate_conditional(templar, all_vars)

    # test with a simple conditional
    conditional = Conditional()
    conditional.when = ['foo is bar']
    all_

# Generated at 2022-06-22 16:32:15.907345
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)

# Generated at 2022-06-22 16:32:26.221410
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    # test with no when
    conditional = Conditional()
    assert conditional.evaluate_conditional(templar, play_context)

    # test with a single when
    conditional = Conditional()
    conditional.when = [True]
    assert conditional.evaluate_conditional(templar, play_context)

    # test with a single when
    conditional = Conditional()
    conditional.when = [False]
    assert not conditional.evaluate_conditional(templar, play_context)

    # test with multiple whens
    conditional = Conditional()
    conditional.when = [True, True]
    assert conditional.evaluate_conditional

# Generated at 2022-06-22 16:32:39.015571
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined or bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:32:47.010639
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("hostvars['foo'] is defined") == [('hostvars[\'foo\']', 'is', 'defined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is undefined") == [('hostvars[\'foo\']', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] not is defined") == [('hostvars[\'foo\']', 'not is', 'defined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] not is undefined") == [('hostvars[\'foo\']', 'not is', 'undefined')]

# Generated at 2022-06-22 16:32:57.531452
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    conditional = Conditional(loader=loader)
    assert conditional._loader == loader
    assert conditional._when == []

    conditional = Conditional(loader=loader, when=['test'])
    assert conditional._loader == loader
    assert conditional._when == ['test']

    conditional = Conditional(loader=loader, when=['test', 'test2'])
    assert conditional._loader == loader
   

# Generated at 2022-06-22 16:33:36.787499
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert c.extract_defined_undefined("foo is defined and bar is not undefined") == [('foo', 'is', 'defined'), ('bar', 'is not', 'undefined')]

# Generated at 2022-06-22 16:33:48.387958
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.task import Task
    task = Task()
    assert task.extract_defined_undefined("foo is defined and bar is not defined") == [('foo', 'is', 'defined'), ('bar', 'is not', 'defined')]
    assert task.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert task.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert task.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert task.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]

# Generated at 2022-06-22 16:34:00.417775
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    play_context = PlayContext()
    templar = Templar(loader=None, variables=VariableManager(loader=None, inventory=None), shared_loader_obj=None)
    templar._available_variables = HostVars(play_context, C.DEFAULT_HOST_LIST)

    conditional = Conditional()
    assert conditional.evaluate_conditional(templar, templar._available_variables)

    conditional = Conditional()
    conditional._when = [True]
    assert conditional.evaluate_conditional(templar, templar._available_variables)

    conditional = Conditional()

# Generated at 2022-06-22 16:34:11.509182
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Create a variable manager
    variable_manager = VariableManager()

    # Create a loader
    loader = DataLoader()

    # Create an inventory
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])

    # Create a variable manager
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a template
    templar = Templar(loader=loader, variables=variable_manager)

    # Create a conditional
    conditional = Conditional(loader=loader)

    # Test evaluate_conditional
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars()) == True

    # Test evaluate_conditional

# Generated at 2022-06-22 16:34:23.308460
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert cond.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert cond.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert cond.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert cond.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:34:30.228733
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={'foo': 'bar'})

    conditional = Conditional()
    assert conditional.evaluate_conditional(templar, play_context.CLIARGS)

    conditional = Conditional()
    conditional.when = [None]
    assert conditional.evaluate_conditional(templar, play_context.CLIARGS)

    conditional = Conditional()
    conditional.when = [True]
    assert conditional.evaluate_conditional(templar, play_context.CLIARGS)

    conditional = Conditional()
    conditional.when = [False]

# Generated at 2022-06-22 16:34:42.235785
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test_var': 'test_value'}
    play_context = PlayContext()
    templar = Templar(loader=None, variables=variable_manager, play_context=play_context)

    conditional = Conditional()

    # Test with a simple string
    conditional.when = ['test_var == "test_value"']
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars())

    # Test with a list of strings
    conditional.when = ['test_var == "test_value"', 'test_var == "test_value"']
    assert conditional.evaluate

# Generated at 2022-06-22 16:34:54.554982
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Conditional):
        pass

    test_conditional = TestConditional()
    test_conditional._loader = DictDataLoader({})
    test_conditional.when = ['foo']

    play_context = PlayContext()
    templar = Templar(loader=test_conditional._loader, variables=VariableManager(),
                      shared_loader_obj=None, context=play_context)

    all_vars = dict(foo=True)
    assert test_conditional.evaluate_conditional(templar, all_vars)

    all_vars = dict(foo=False)

# Generated at 2022-06-22 16:35:03.157623
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'username'
    play_context.port = 22
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.accelerate = False
    play_context.accelerate_port = 5099
    play_context.accelerate_ipv6 = False
    play_context.prompt = None

# Generated at 2022-06-22 16:35:14.335697
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)
    conditional._ds = dict()
    conditional._ds['when'] = 'foo'
    conditional.evaluate_conditional(templar, dict(foo='bar'))

# Generated at 2022-06-22 16:35:51.309701
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple conditional
    conditional = "foo == 'bar'"
    all_vars = dict(foo='bar')
    assert Conditional().evaluate_conditional(templar, all_vars) == True

    # Test with a simple conditional
    conditional = "foo == 'bar'"
    all_vars = dict(foo='baz')
    assert Conditional().evaluate_conditional(templar, all_vars) == False

    # Test with a simple conditional
    conditional = "foo == 'bar'"
    all_

# Generated at 2022-06-22 16:35:57.759987
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # test with a simple conditional
    conditional = 'foo == "bar"'
    all_vars = dict(foo='bar')
    templar = Templar(loader=None, variables=all_vars)
    conditional_obj = Conditional()
    assert conditional_obj.evaluate_conditional(templar, all_vars)

    # test with a simple conditional that fails
    conditional = 'foo == "bar"'
    all_vars = dict(foo='baz')
    templar = Templar(loader=None, variables=all_vars)
    conditional_obj = Conditional()
    assert not conditional_obj.evaluate_conditional(templar, all_vars)

    # test with a simple conditional that fails
   

# Generated at 2022-06-22 16:36:09.751054
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    p = PlayContext()
    t = Templar(loader=None, variables={})
    c = Conditional(loader=None)

    assert c.evaluate_conditional(t, p) == True

    c.when = [None]
    assert c.evaluate_conditional(t, p) == True

    c.when = [False]
    assert c.evaluate_conditional(t, p) == False

    c.when = [True]
    assert c.evaluate_conditional(t, p) == True

    c.when = ['foo']
    assert c.evaluate_conditional(t, p) == True

    c.when = ['False']
    assert c.evaluate_conditional(t, p) == False


# Generated at 2022-06-22 16:36:22.998182
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)
    conditional.when = ['foo']
    assert conditional.evaluate_conditional(templar, dict(foo=True))

# Generated at 2022-06-22 16:36:32.009006
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a mock object for the templar
    class MockTemplar(Templar):
        def __init__(self, loader, variables):
            self.loader = loader
            self.environment = loader.environment
            self.available_variables = variables

        def template(self, data, preserve_trailing_newlines=True, convert_data=True, escape_backslashes=True, fail_on_undefined=True, disable_lookups=False):
            return data

    # Create a mock object for the loader
    class MockLoader(object):
        def __init__(self):
            self.environment = None

    # Create a mock object for the variable manager
   

# Generated at 2022-06-22 16:36:44.242928
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.clean import module_response_deepcopy

    # Create a fake hostvars
    hostvars = HostVars(dict())

# Generated at 2022-06-22 16:36:52.317525
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test 1: simple boolean
    conditional = Conditional()
    conditional.when = [True]
    assert conditional.evaluate_conditional(templar, {})

    # test 2: simple string
    conditional = Conditional()
    conditional.when = ["True"]
    assert conditional.evaluate_conditional(templar, {})

    # test 3: simple string
    conditional = Conditional()

# Generated at 2022-06-22 16:36:57.205317
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    conditional = Conditional(loader=None)
    conditional.when = ['1==1']
    assert conditional.evaluate_conditional(templar, play_context.CLIARGS) == True

    conditional.when = ['1==2']
    assert conditional.evaluate_conditional(templar, play_context.CLIARGS) == False

    conditional.when = ['1==1', '2==2']
    assert conditional.evaluate_conditional(templar, play_context.CLIARGS) == True

    conditional.when = ['1==1', '2==3']

# Generated at 2022-06-22 16:37:03.805811
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined('foo is defined and bar is defined') == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:37:13.339619
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with undefined variable
    task = Task()
    task.when = ['not defined_var']
    assert not task.evaluate_conditional(templar, {})

   