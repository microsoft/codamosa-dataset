

# Generated at 2022-06-22 16:27:36.626848
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class TestConditional(Conditional, Base):
        pass

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with loader
    test_obj = TestConditional(loader=loader)
    assert test_obj._loader == loader

    # Test without loader
    try:
        test_obj = TestConditional()
    except AnsibleError:
        pass
    else:
        raise AssertionError('Conditional() without loader should raise AnsibleError')

    # Test with invalid when

# Generated at 2022-06-22 16:27:48.720531
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a play context
    play_context = PlayContext()
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'root'
    play_context.connection = 'ssh'
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.module_name = 'shell'
    play_context.module_args = 'ls'
    play_context.forks = 10
    play_context.timeout = 10

# Generated at 2022-06-22 16:28:00.533424
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    class TestConditional(Conditional):
        pass

    play_context = PlayContext()
    variable_manager = VariableManager()
    variable_manager.set_host_variable(HostVars(variable_manager, 'localhost'), 'localhost')
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    test_conditional = TestConditional()
    test_conditional.when = ['1 == 1', '1 == 2', '1 == 3']


# Generated at 2022-06-22 16:28:11.441055
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = ['1 == 1']
    assert conditional.evaluate_conditional(templar, {})

    # Test with a simple conditional that fails
    conditional = Conditional()
    conditional.when = ['1 == 2']
    assert not conditional.evaluate_conditional(templar, {})

    # Test with a simple conditional

# Generated at 2022-06-22 16:28:21.085292
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context._vars_per_host = dict()
    play_context._vars_per_host['test_host'] = dict()
    play_context._vars_per_host['test_host']['test_var'] = 'test_value'
    play_context._vars_per_host['test_host']['test_var_2'] = 'test_value_2'
    play_context._vars_per_host['test_host']['test_var_3'] = 'test_value_3'

# Generated at 2022-06-22 16:28:33.793584
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert cond.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert cond.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert cond.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert cond.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:28:43.533949
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert conditional.extract_defined_undefined("a is not defined") == [("a", "is not", "defined")]
    assert conditional.extract_defined_undefined("a is undefined") == [("a", "is", "undefined")]
    assert conditional.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]
    assert conditional.extract_defined_undefined("a is defined and b is defined") == [("a", "is", "defined"), ("b", "is", "defined")]

# Generated at 2022-06-22 16:28:54.474519
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('localhost'))
    variable_manager.set_host_variable('localhost', 'ansible_connection', 'local')
    variable_manager.set_host_variable('localhost', 'ansible_python_interpreter', '/usr/bin/python')
    variable_manager.set_host_variable('localhost', 'ansible_python_version', '2.7.5')

# Generated at 2022-06-22 16:28:57.754311
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    pc = PlayContext()
    templar = Templar(loader=None, variables={})
    conditional = Conditional(loader=None)

    assert conditional.evaluate_conditional(templar, pc)

# Generated at 2022-06-22 16:29:03.392365
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    conditional = Conditional(loader=loader)

    # test with a simple conditional
    conditional.when = ['foo']
    assert conditional.evaluate_conditional(templar, dict(foo=True))

    # test with a simple conditional that fails
    conditional.when = ['foo']
    assert not conditional.evaluate_conditional(templar, dict(foo=False))

    # test

# Generated at 2022-06-22 16:29:29.124433
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)
    conditional.when = [
        'ansible_os_family == "RedHat"',
        'ansible_os_family == "Debian"',
        'ansible_os_family == "Suse"',
    ]

    all_vars = variable_manager.get_vars(play=None, host=None, task=None)


# Generated at 2022-06-22 16:29:35.322367
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = ["foo"]
    all_vars = dict(foo=True)
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test with a conditional that uses a variable
    conditional = Conditional()
    conditional.when = ["foo == 'bar'"]
    all_vars = dict

# Generated at 2022-06-22 16:29:47.136142
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test 1: Test a simple conditional
    conditional = Conditional()
    conditional.when = ['foo is bar']
    all_vars = dict(foo='bar')

# Generated at 2022-06-22 16:29:56.271848
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with a single conditional
    conditional = Conditional(loader=loader)
    conditional.when = [ 'foo is defined' ]
    all_vars = dict(foo='bar')
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test with multiple conditionals
    conditional = Conditional(loader=loader)

# Generated at 2022-06-22 16:30:06.969220
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined('foo is defined and bar is not undefined') == [('foo', 'is', 'defined'), ('bar', 'is not', 'undefined')]

# Generated at 2022-06-22 16:30:17.203873
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("hostvars['foo'] is defined") == [('hostvars[\'foo\']', 'is', 'defined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not defined") == [('hostvars[\'foo\']', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is undefined") == [('hostvars[\'foo\']', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not undefined") == [('hostvars[\'foo\']', 'is not', 'undefined')]

# Generated at 2022-06-22 16:30:26.785217
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)
    conditional.when = [
        'foo',
        'bar',
        'baz'
    ]
    conditional.evaluate_conditional(templar, {})

# Generated at 2022-06-22 16:30:34.824954
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is not undefined") == [('foo', 'is', 'defined'), ('bar', 'is not', 'undefined')]

# Generated at 2022-06-22 16:30:46.382918
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)

# Generated at 2022-06-22 16:30:59.931466
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    conditional = Conditional()

# Generated at 2022-06-22 16:31:40.954566
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:31:52.207266
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("") == []
    assert conditional.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert conditional.extract_defined_undefined("a is not defined") == [("a", "is not", "defined")]
    assert conditional.extract_defined_undefined("a is undefined") == [("a", "is", "undefined")]
    assert conditional.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]
    assert conditional.extract_defined_undefined("a is defined and b is defined") == [("a", "is", "defined"), ("b", "is", "defined")]

# Generated at 2022-06-22 16:32:04.575509
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    c = Conditional()
    assert c._when == []

    c = Conditional(loader=None)
    assert c._when == []

    c = Conditional(loader=None, when=['test'])
    assert c._when == ['test']

    c = Conditional(loader=None, when=['test', 'test2'])
    assert c._when == ['test', 'test2']

    c = Conditional(loader=None, when=['test', 'test2'])
    assert c._when == ['test', 'test2']

    c = Conditional(loader=None, when=['test', 'test2'])

# Generated at 2022-06-22 16:32:14.475499
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'username'
    play_context.port = 22
    play_context.connection = 'ssh'
    play_context.check_mode = False
    play_context.no_log = False
    play_context.password = None
    play_context.private_key_file = None
    play_context.timeout = 10
    play

# Generated at 2022-06-22 16:32:25.129263
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined or bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:32:37.910616
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Conditional):
        pass

    # test with a single conditional
    test_conditional = TestConditional()
    test_conditional.when = [ "a == 1" ]
    test_play_context = PlayContext()
    test_variable_manager = VariableManager()
    test_variable_manager.set_nonpersistent_facts(dict(a=1))
    test_templar = Templar(loader=None, variables=test_variable_manager, shared_loader_obj=None)
    assert test_conditional.evaluate_conditional(test_templar, test_variable_manager.get_vars(play=test_play_context))

    #

# Generated at 2022-06-22 16:32:45.505265
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:32:55.413348
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("hostvars['foo'] is defined") == [('hostvars[\'foo\']', 'is', 'defined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not defined") == [('hostvars[\'foo\']', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is undefined") == [('hostvars[\'foo\']', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not undefined") == [('hostvars[\'foo\']', 'is not', 'undefined')]

# Generated at 2022-06-22 16:33:07.986622
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("") == []
    assert c.extract_defined_undefined("a") == []
    assert c.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert c.extract_defined_undefined("a is not defined") == [("a", "is not", "defined")]
    assert c.extract_defined_undefined("a is undefined") == [("a", "is", "undefined")]
    assert c.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]

# Generated at 2022-06-22 16:33:19.013152
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # test setup
    play_context = PlayContext()
    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager)

    # test data

# Generated at 2022-06-22 16:33:58.264234
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test 1:
    # Test a conditional with a single variable
    #
    # Expected result:
    #   True
    #
    # Explanation:
    #   The variable 'foo' is defined and has the value 'bar'
    #   The conditional is 'foo == "bar"'
    #   The conditional evaluates to True
    #
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))
    conditional = Conditional()
    conditional.when = ['foo == "bar"']
    result = conditional

# Generated at 2022-06-22 16:34:10.129576
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    p = PlayContext()
    t = Templar(loader=None, variables=VariableManager())
    c = Conditional(loader=None)

    assert c.evaluate_conditional(t, p) == True

    c._when = [False]
    assert c.evaluate_conditional(t, p) == False

    c._when = [True]
    assert c.evaluate_conditional(t, p) == True

    c._when = [True, False]
    assert c.evaluate_conditional(t, p) == False

    c._when = [True, True]
    assert c.evaluate_conditional(t, p) == True


# Generated at 2022-06-22 16:34:19.299933
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    class TestConditional(Conditional):
        def __init__(self, loader=None):
            super(TestConditional, self).__init__(loader=loader)

    class TestPlaybook:
        def __init__(self):
            self.variable_manager = VariableManager()
            self.loader = None

    class TestTask:
        def __init__(self):
            self.playbook = TestPlaybook()


# Generated at 2022-06-22 16:34:28.130794
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # Create a variable manager
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(host_list=['localhost']))

    # Create a templar
    templar = Templar(loader=None, variables=variable_manager)

    # Create a Conditional object
    conditional = Conditional()

    # Test with a boolean
    conditional.when = [True]
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars()) == True

    # Test with a string
    conditional.when = ['True']
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars()) == True

    # Test with a string
    conditional.when = ['False']
    assert conditional

# Generated at 2022-06-22 16:34:39.483733
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is undefined") == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]

# Generated at 2022-06-22 16:34:51.081723
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    conditional = Conditional()
    conditional.when = [
        'foo is defined',
        'bar is not defined',
        'baz is defined',
        'qux is not defined',
        'quux is defined',
        'corge is not defined',
        'grault is defined',
        'garply is not defined',
        'waldo is defined',
        'fred is not defined',
        'plugh is defined',
        'xyzzy is not defined',
        'thud is defined',
    ]

    # Test with all variables defined

# Generated at 2022-06-22 16:35:01.586941
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("") == []
    assert c.extract_defined_undefined("a") == []
    assert c.extract_defined_undefined("a is defined") == [('a', 'is', 'defined')]
    assert c.extract_defined_undefined("a is not defined") == [('a', 'is not', 'defined')]
    assert c.extract_defined_undefined("a is undefined") == [('a', 'is', 'undefined')]
    assert c.extract_defined_undefined("a is not undefined") == [('a', 'is not', 'undefined')]

# Generated at 2022-06-22 16:35:12.633588
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class TestConditional(Conditional):
        def __init__(self, loader=None):
            super(TestConditional, self).__init__(loader)
            self._ds = None

    # Test with a simple conditional
    test_conditional = TestConditional()
    test_conditional.when = ["ansible_os_family == 'RedHat'"]
    templar = Templar(loader=None, variables={'ansible_os_family': 'RedHat'})
    assert test_conditional.evaluate_conditional(templar, templar.available_variables)

    # Test with a complex conditional
    test_conditional = TestConditional()

# Generated at 2022-06-22 16:35:22.933198
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Create a play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = None
    play_context.become_user = None
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'remote_user'
    play_context.connection = 'ssh'
    play_context.network_os = None
    play_context.timeout = 10
    play_context.shell = None
    play_context.executor_path = None

# Generated at 2022-06-22 16:35:33.048712
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("a is defined") == [('a', 'is', 'defined')]
    assert conditional.extract_defined_undefined("a is not defined") == [('a', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("a is undefined") == [('a', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("a is not undefined") == [('a', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("a is defined and b is defined") == [('a', 'is', 'defined'), ('b', 'is', 'defined')]

# Generated at 2022-06-22 16:36:10.824180
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # Test 1: simple conditional
    conditional = Conditional(loader=loader)
    conditional.when = [True]
    assert conditional.evaluate_conditional(templar, {})

    # Test 2: simple conditional
    conditional = Conditional(loader=loader)
    conditional.when = [False]

# Generated at 2022-06-22 16:36:23.799710
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a play context
    play_context = PlayContext()

    # Create a variable manager
    variable_manager = VariableManager()

    # Create a templar
    templar = Templar(loader=None, variables=variable_manager)

    # Create a Conditional
    conditional = Conditional()

    # Create a list of variables
    all_vars = dict()

    # Test with a boolean
    conditional.when = [True]
    assert conditional.evaluate_conditional(templar, all_vars) == True

    # Test with a string
    conditional.when = ['1']
    assert conditional.evaluate_conditional(templar, all_vars) == True

# Generated at 2022-06-22 16:36:32.738467
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    class TestConditional(Conditional):
        def __init__(self):
            self._loader = None
            self._ds = None
            self.when = []

    test_conditional = TestConditional()
    test_conditional.when = ['foo is defined', 'bar is defined', 'baz is defined']

    play_context = PlayContext()
    variable_manager = VariableManager()
    variable_manager.set_host_variable(HostVars(variable_manager, 'localhost'), 'foo', 'bar')

# Generated at 2022-06-22 16:36:44.568817
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert cond.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert cond.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert cond.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert cond.extract_defined_undefined('foo is defined and bar is not defined') == [('foo', 'is', 'defined'), ('bar', 'is not', 'defined')]

# Generated at 2022-06-22 16:36:58.596203
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is not defined') == [('hostvars[inventory_hostname]', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is undefined') == [('hostvars[inventory_hostname]', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is not undefined') == [('hostvars[inventory_hostname]', 'is not', 'undefined')]
    assert conditional.extract

# Generated at 2022-06-22 16:37:05.095917
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert cond.extract_defined_undefined("a is not defined") == [("a", "is not", "defined")]
    assert cond.extract_defined_undefined("a is undefined") == [("a", "is", "undefined")]
    assert cond.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]
    assert cond.extract_defined_undefined("a is defined and b is not undefined") == [("a", "is", "defined"), ("b", "is not", "undefined")]
    assert cond.extract_defined_undefined("a is defined and b is not undefined and c is defined")

# Generated at 2022-06-22 16:37:15.265770
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class MyConditional(Conditional):
        def __init__(self, loader, when=None):
            self._loader = loader
            self.when = when

    # Test with a simple conditional
    my_conditional = MyConditional(loader=None, when='foo')
    templar = Templar(loader=None, variables={'foo': True})
    assert my_conditional.evaluate_conditional(templar, all_vars=dict()) is True

    # Test with a complex conditional
    my_conditional = MyConditional(loader=None, when='foo and bar')
    templar = Templar(loader=None, variables={'foo': True, 'bar': True})
    assert my_conditional.evaluate_conditional

# Generated at 2022-06-22 16:37:25.105246
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # test with a simple conditional
    conditional = "hostvars['foo'] is defined"
    c = Conditional()
    res = c.extract_defined_undefined(conditional)
    assert res == [('hostvars[\'foo\']', 'is', 'defined')]

    # test with a conditional containing multiple defined/undefined tests
    conditional = "hostvars['foo'] is defined and hostvars['bar'] is not undefined"
    c = Conditional()
    res = c.extract_defined_undefined(conditional)
    assert res == [('hostvars[\'foo\']', 'is', 'defined'), ('hostvars[\'bar\']', 'is not', 'undefined')]

    # test with a conditional containing multiple defined/undefined tests and other stuff