

# Generated at 2022-06-22 16:27:49.764028
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert conditional.extract_defined_undefined("a is not defined") == [("a", "is not", "defined")]
    assert conditional.extract_defined_undefined("a is undefined") == [("a", "is", "undefined")]
    assert conditional.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]
    assert conditional.extract_defined_undefined("a is defined and b is not defined") == [("a", "is", "defined"), ("b", "is not", "defined")]

# Generated at 2022-06-22 16:27:57.032528
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = None
    play_context.become_user = None
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'remote_user'
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.timeout = 10
    play_context.shell = '/bin/sh'
    play_context.exec

# Generated at 2022-06-22 16:28:06.118123
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is not undefined") == [('foo', 'is', 'defined'), ('bar', 'is not', 'undefined')]

# Generated at 2022-06-22 16:28:17.426087
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test with a simple string
    conditional = Conditional()
    conditional.when = ['foo']
    assert conditional.evaluate_conditional(templar, dict(foo='bar'))

    # test with a boolean
    conditional = Conditional()
    conditional.when = [True]
    assert conditional.evaluate_conditional(templar, dict(foo='bar'))

    # test with a

# Generated at 2022-06-22 16:28:26.385402
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Test 1:
    # Test with a string containing a single defined/undefined test
    # and check that the expected result is returned
    conditional = "hostvars['foo'] is defined"
    expected_result = [('hostvars[\'foo\']', 'is', 'defined')]
    c = Conditional()
    result = c.extract_defined_undefined(conditional)
    assert result == expected_result

    # Test 2:
    # Test with a string containing multiple defined/undefined tests
    # and check that the expected result is returned
    conditional = "hostvars['foo'] is defined and hostvars['bar'] is not undefined"
    expected_result = [('hostvars[\'foo\']', 'is', 'defined'), ('hostvars[\'bar\']', 'is not', 'undefined')]


# Generated at 2022-06-22 16:28:38.407493
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:28:48.182152
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    p = Conditional()
    assert p._when == []

    p = Conditional(loader=None)
    assert p._when == []

    p = Conditional(loader=None, when=['foo'])
    assert p._when == ['foo']

    p = Conditional(loader=None, when=['foo', 'bar'])
    assert p._when == ['foo', 'bar']

    p = Conditional(loader=None, when=['foo', 'bar'])
    assert p._when == ['foo', 'bar']

    p = Conditional(loader=None, when=['foo', 'bar'])
    assert p._when == ['foo', 'bar']

    p

# Generated at 2022-06-22 16:28:57.266704
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_host_variable('host1', 'foo', 'bar')
    variable_manager.set_host_variable('host1', 'baz', 'qux')
    variable_manager.set_host_variable('host1', 'spam', 'eggs')
    variable_manager.set_host_variable('host1', 'ansible_ssh_host', '127.0.0.1')
    variable_manager.set_host_variable('host1', 'ansible_ssh_port', '22')
    variable_manager.set_host_variable('host1', 'ansible_ssh_user', 'root')

# Generated at 2022-06-22 16:29:10.511189
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # Create a fake hostvars dict
    hostvars = HostVars(dict())

    # Create a fake variable manager
    variable_manager = VariableManager()
    variable_manager._fact_cache = dict()
    variable_manager._host_vars_plugins = [hostvars]

    # Create a fake play context
    play_context = PlayContext()

    # Create a fake templar
    templar = Templar(loader=None, variables=variable_manager,
                      shared_loader_obj=None, playcontext=play_context)

# Generated at 2022-06-22 16:29:22.759366
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:29:48.927730
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert conditional.extract_defined_undefined("a is not defined") == [("a", "is not", "defined")]
    assert conditional.extract_defined_undefined("a is undefined") == [("a", "is", "undefined")]
    assert conditional.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]
    assert conditional.extract_defined_undefined("a is defined and b is defined") == [("a", "is", "defined"), ("b", "is", "defined")]

# Generated at 2022-06-22 16:29:57.470553
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'a': 1, 'b': 2, 'c': 3}
    templar = Templar(loader=loader, variables=variable_manager)

    conditional = Conditional()
    conditional.when = ['a == 1', 'b == 2', 'c == 3']

    assert conditional.evaluate_conditional(templar, variable_manager.get_vars()) is True

    conditional.when = ['a == 1', 'b == 2', 'c == 4']
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars()) is False

    conditional

# Generated at 2022-06-22 16:30:07.577286
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:30:17.307664
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional()
    conditional.when = ['foo is defined', 'bar is defined', 'baz is defined']

    all_vars = dict(foo='foo', bar='bar')
    assert conditional.evaluate_conditional(templar, all_vars) == False

    all_vars = dict(foo='foo', bar='bar', baz='baz')

# Generated at 2022-06-22 16:30:29.022215
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined or bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:30:38.882332
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Conditional):
        def __init__(self, loader, variable_manager, play_context):
            super(TestConditional, self).__init__(loader)
            self._variable_manager = variable_manager
            self._play_context = play_context

    # Test with a simple conditional
    test_conditional = TestConditional(None, VariableManager(), PlayContext())
    test_conditional.when = ["ansible_os_family == 'RedHat'"]
    templar = Templar(loader=None, variables=dict(ansible_os_family='RedHat'))

# Generated at 2022-06-22 16:30:49.679668
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("") == []
    assert c.extract_defined_undefined("a") == []
    assert c.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert c.extract_defined_undefined("a is not defined") == [("a", "is not", "defined")]
    assert c.extract_defined_undefined("a is undefined") == [("a", "is", "undefined")]
    assert c.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]

# Generated at 2022-06-22 16:30:57.016436
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:31:08.470082
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("a is defined") == [('a', 'is', 'defined')]
    assert conditional.extract_defined_undefined("a is defined and b is defined") == [('a', 'is', 'defined'), ('b', 'is', 'defined')]
    assert conditional.extract_defined_undefined("a is defined and b is not defined") == [('a', 'is', 'defined'), ('b', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("a is defined and b is undefined") == [('a', 'is', 'defined'), ('b', 'is', 'undefined')]

# Generated at 2022-06-22 16:31:19.825808
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Conditional):
        def __init__(self, loader, variable_manager, play_context):
            self._loader = loader
            self._templar = Templar(loader=loader, variables=variable_manager.get_vars(play=play_context, include_hostvars=True))
            self._variable_manager = variable_manager
            self._play_context = play_context

    variable_manager = VariableManager()

# Generated at 2022-06-22 16:32:01.846525
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-22 16:32:07.830144
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    conditional = Conditional()

# Generated at 2022-06-22 16:32:16.456494
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    pc = PlayContext()
    t = Templar(loader=None, variables={})

    c = Conditional()

# Generated at 2022-06-22 16:32:22.014471
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    conditional = Conditional(loader=None)
    conditional._ds = dict()
    conditional.when = ["foo"]

    assert conditional.evaluate_conditional(templar, variable_manager) == True

# Generated at 2022-06-22 16:32:29.518611
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.become import Become
    from ansible.playbook.become_plugin import BecomePlugin
    from ansible.playbook.connection_plugin import ConnectionPlugin
    from ansible.plugins.loader import connection_loader, become_loader
    from ansible.plugins.loader import lookup_loader


# Generated at 2022-06-22 16:32:41.562156
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'username'
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.accelerate = False
    play_context.accelerate_port = 5099
    play_context.accelerate_ipv6 = False
    play

# Generated at 2022-06-22 16:32:54.486507
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = ['1 == 1']
    assert conditional.evaluate_conditional(templar, play_context)

    # Test with a simple conditional that evaluates to False
    conditional = Conditional()
    conditional.when = ['1 == 2']
    assert not conditional.evaluate_conditional(templar, play_context)

    # Test with a simple conditional that evaluates to False
    conditional = Conditional()
    conditional.when = ['1 == 2']
    assert not conditional.evaluate_conditional(templar, play_context)

    # Test with a simple conditional that evaluates

# Generated at 2022-06-22 16:33:07.421465
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined or bar is undefined") == [("foo", "is", "defined"), ("bar", "is", "undefined")]

# Generated at 2022-06-22 16:33:14.146034
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'username'
    play_context.port = 22
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.accelerate = False
    play_context.accelerate_port = 5099
    play_context.accelerate_ipv6 = False
    play

# Generated at 2022-06-22 16:33:25.999254
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert c.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert c.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert c.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert c.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:34:06.451838
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)

# Generated at 2022-06-22 16:34:17.219958
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("") == []
    assert cond.extract_defined_undefined("a") == []
    assert cond.extract_defined_undefined("a is defined") == [('a', 'is', 'defined')]
    assert cond.extract_defined_undefined("a is not defined") == [('a', 'is not', 'defined')]
    assert cond.extract_defined_undefined("a is undefined") == [('a', 'is', 'undefined')]
    assert cond.extract_defined_undefined("a is not undefined") == [('a', 'is not', 'undefined')]

# Generated at 2022-06-22 16:34:26.906644
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Create a Conditional object
    conditional = Conditional()

    # Create a PlayContext object
    play_context = PlayContext()

    # Create a Templar object
    templar = Templar(loader=None, variables={})

    # Create a list of variables
    all_vars = [{'foo': 'bar'}, {'baz': 'qux'}]

    # Test with a valid conditional
    conditional.when = ['foo == bar']
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test with an invalid conditional
    conditional.when = ['foo == baz']
    assert not conditional.evaluate_conditional(templar, all_vars)

    # Test with a valid conditional and

# Generated at 2022-06-22 16:34:34.913067
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class TestConditional(Conditional):
        def __init__(self):
            super(TestConditional, self).__init__()
            self._loader = None

    test_conditional = TestConditional()

    # Test with empty conditionals
    test_conditional.when = [None, '']
    assert test_conditional.evaluate_conditional(Templar(loader=None, variables={}), {})

    # Test with boolean conditionals
    test_conditional.when = [True, False]
    assert test_conditional.evaluate_conditional(Templar(loader=None, variables={}), {})
    test_conditional.when = [False, True]
    assert not test_conditional.evaluate_conditional

# Generated at 2022-06-22 16:34:40.577914
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.base import Base
    from ansible.parsing.dataloader import DataLoader

    class Test(Base, Conditional):
        pass

    loader = DataLoader()
    test = Test(loader=loader)

    assert test._when == []
    assert test._loader == loader

# Generated at 2022-06-22 16:34:52.431619
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert cond.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert cond.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert cond.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert cond.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:35:02.255348
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class DummyClass(Conditional):
        def __init__(self):
            self._loader = DataLoader()
            self._variable_manager = VariableManager()
            self._templar = Templar(loader=self._loader, variables=self._variable_manager.get_vars(loader=self._loader))

    dummy_class = DummyClass()
    dummy_class.when = ['{{ test_var }} == "test_value"']

    # test with test_var == test_value
    dummy_class._variable_manager.set_nonpersistent_facts(dict(test_var='test_value'))

# Generated at 2022-06-22 16:35:12.921326
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert c.extract_defined_undefined('foo is defined and bar is not defined') == [('foo', 'is', 'defined'), ('bar', 'is not', 'defined')]

# Generated at 2022-06-22 16:35:23.343147
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Test data

# Generated at 2022-06-22 16:35:33.202371
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=False)

    conditional = Conditional(loader=loader)
    conditional.when = ['foo']
    conditional.evaluate_conditional(templar, variable_manager.get_vars(play=play_context))

# Generated at 2022-06-22 16:36:43.208679
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'username'
    play_context.port = 22
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.timeout = 10
    play_context.shell = '/bin/sh'
    play_context.executable = None
    play_context.environment = dict()


# Generated at 2022-06-22 16:36:58.553784
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'username'
    play_context.port = 22
    play_context.connection = 'ssh'
    play_context.timeout = 10
    play_context.shell = '/bin/sh'
    play_context.executor_path = '/usr/bin/ansible-executor'

# Generated at 2022-06-22 16:37:05.030094
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    # Test case 1: conditional is None
    conditional = None
    all_vars = {}
    c = Conditional()
    assert c.evaluate_conditional(templar, all_vars) == True

    # Test case 2: conditional is empty string
    conditional = ''
    all_vars = {}
    c = Conditional()
    assert c.evaluate_conditional(templar, all_vars) == True

    # Test case 3: conditional is True
    conditional = True
    all_vars = {}
    c = Conditional()
    assert c.evaluate_conditional(templar, all_vars)

# Generated at 2022-06-22 16:37:14.232257
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("") == []
    assert conditional.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert conditional.extract_defined_undefined("a is not defined") == [("a", "is not", "defined")]
    assert conditional.extract_defined_undefined("a is undefined") == [("a", "is", "undefined")]
    assert conditional.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]
    assert conditional.extract_defined_undefined("a is defined and b is not undefined") == [("a", "is", "defined"), ("b", "is not", "undefined")]
    assert conditional.extract_defined_

# Generated at 2022-06-22 16:37:24.689750
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)

    # test with empty list
    conditional.when = []
    assert conditional.evaluate_conditional(templar, {})

    # test with list of empty strings
    conditional.when = [""]
    assert conditional.evaluate_conditional(templar, {})

    # test with list of empty strings and a True