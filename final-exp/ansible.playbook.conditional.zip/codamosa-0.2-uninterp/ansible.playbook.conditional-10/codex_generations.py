

# Generated at 2022-06-22 16:27:42.345338
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory(host_list='tests/inventory'))
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional()
    conditional.when = ['foo is defined']
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars(play=None, host=None, task=None)) is False

# Generated at 2022-06-22 16:27:54.973781
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    play_context = PlayContext()

    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional()
    conditional.when = ["foo == 'bar'"]

    assert conditional.evaluate_conditional(templar, variable_manager.get_vars())

    conditional.when = ["foo == 'baz'"]


# Generated at 2022-06-22 16:28:04.947567
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # test setup
    play_context = PlayContext()
    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager)

    # test data

# Generated at 2022-06-22 16:28:16.228088
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined('foo is defined or bar is defined') == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:28:23.753026
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.base import Base
    from ansible.template import Templar

    class TestConditional(Base, Conditional):
        pass

    test_conditional = TestConditional()
    test_conditional._ds = dict(name='test_conditional')
    test_conditional.when = ['foo', 'bar']

    templar = Templar(loader=None, variables={})
    all_vars = dict(foo=True, bar=False)

    assert test_conditional.evaluate_conditional(templar, all_vars) == False

# Generated at 2022-06-22 16:28:34.594603
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader)

    conditional = Conditional(loader=loader)
    conditional._ds = 'test'

    # test with empty conditional
    conditional.when = [None]

# Generated at 2022-06-22 16:28:44.637116
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # Create a play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'username'
    play_context.connection = 'ssh'
    play_context.timeout = 10
    play_context.shell = '/bin/sh'
    play_context.executable = None
    play_context.environment = dict()
    play_context.only_tags = []

# Generated at 2022-06-22 16:28:46.714346
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c._when == []


# Generated at 2022-06-22 16:28:56.376989
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert c.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert c.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert c.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert c.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:29:09.637860
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('tests/inventory'))
    variable_manager.extra_vars = {'test_var': 'test_value'}
    templar = Templar(loader=loader, variables=variable_manager)

    conditional = Conditional()
    conditional.when = ['test_var is defined', 'test_var == "test_value"']

    assert conditional.evaluate_conditional(templar, variable_manager.get_vars()) == True
    conditional.when = ['test_var is defined', 'test_var == "test_value_2"']

# Generated at 2022-06-22 16:29:41.068938
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader, play_context=play_context)

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = ["ansible_os_family == 'RedHat'"]
    all_vars = variable_manager.get_vars(play=None, host=None, task=None)
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test

# Generated at 2022-06-22 16:29:50.964731
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # test with a simple string
    conditional = 'foo'
    all_vars = dict(foo='bar')
    assert Conditional().evaluate_conditional(templar, all_vars)

    # test with a boolean
    conditional = True
    all_vars = dict(foo='bar')
    assert Conditional().evaluate_conditional(templar, all_vars)

    # test with a simple string
    conditional = 'foo'
    all_vars = dict(foo='bar')

# Generated at 2022-06-22 16:30:00.815306
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    # Create a fake hostvars object
    hostvars = HostVars(dict())
    hostvars.data = {
        'foo': 'bar',
        'baz': 'qux',
        'frobnicate': 'yes',
        'ansible_facts': {
            'distribution': 'Ubuntu',
            'distribution_version': '14.04',
            'os_family': 'Debian',
            'virtualization_role': 'guest'
        }
    }

    # Create a fake variable manager
    variable_manager = VariableManager()
    variable_manager.set_host

# Generated at 2022-06-22 16:30:11.365407
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Conditional):
        def __init__(self, loader):
            self._loader = loader

    test_conditional = TestConditional(loader=None)

    # test 1
    test_conditional.when = [
        'foo is defined',
        'bar is defined',
        'baz is defined',
    ]

    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(foo='foo', bar='bar'))
    play_context = PlayContext()
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    assert test_conditional.evaluate_cond

# Generated at 2022-06-22 16:30:21.529333
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = [ "ansible_distribution == 'CentOS'" ]
    all_vars = variable_manager.get_vars(loader=loader, play=None)
    assert conditional.evaluate_conditional(templar, all_vars) == True

    # Test with a simple conditional that

# Generated at 2022-06-22 16:30:32.803311
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('a is defined') == [('a', 'is', 'defined')]
    assert c.extract_defined_undefined('a is not defined') == [('a', 'is not', 'defined')]
    assert c.extract_defined_undefined('a is undefined') == [('a', 'is', 'undefined')]
    assert c.extract_defined_undefined('a is not undefined') == [('a', 'is not', 'undefined')]
    assert c.extract_defined_undefined('a is defined and b is not undefined') == [('a', 'is', 'defined'), ('b', 'is not', 'undefined')]
    assert c.extract_defined_undefined('a is defined and b is not undefined and c is defined')

# Generated at 2022-06-22 16:30:44.206924
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined and bar is not defined") == [('foo', 'is', 'defined'), ('bar', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined and baz is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined'), ('baz', 'is', 'defined')]

# Generated at 2022-06-22 16:30:50.898661
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # test for undefined variable
    conditional = 'foo is defined'
    all_vars = dict(foo='bar')
    assert Conditional().evaluate_conditional(templar, all_vars) == False

    # test for defined variable
    conditional = 'foo is defined'
    all_vars = dict(foo='bar')
    assert Conditional().evaluate_conditional(templar, all_vars) == False

    # test for undefined variable
    conditional = 'foo is undefined'

# Generated at 2022-06-22 16:31:02.491220
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    c = Conditional()
    assert c._when == []

    c = Conditional(loader=None)
    assert c._when == []

    c = Conditional(loader=None, when=['foo'])
    assert c._when == ['foo']

    c = Conditional(loader=None, when=['foo', 'bar'])
    assert c._when == ['foo', 'bar']

    c = Conditional(loader=None, when=['foo', 'bar'])
    assert c._when == ['foo', 'bar']

    c = Conditional(loader=None, when=['foo', 'bar'])
    assert c._when == ['foo', 'bar']

    c

# Generated at 2022-06-22 16:31:13.162499
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = ['1 == 1']
    assert conditional.evaluate_conditional(templar, play_context)

    # Test with a simple conditional that fails
    conditional = Conditional()
    conditional.when = ['1 == 2']
    assert not conditional.evaluate_conditional(templar, play_context)

    # Test with a simple conditional that fails
    conditional = Conditional()
    conditional.when = ['1 == 2']
    assert not conditional.evaluate_conditional(templar, play_context)

    # Test with a simple conditional that fails

# Generated at 2022-06-22 16:31:57.169527
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("hostvars['foo'] is defined") == [('hostvars[\'foo\']', 'is', 'defined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not defined") == [('hostvars[\'foo\']', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is undefined") == [('hostvars[\'foo\']', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not undefined") == [('hostvars[\'foo\']', 'is not', 'undefined')]

# Generated at 2022-06-22 16:32:09.106406
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Conditional):
        def __init__(self, loader=None):
            super(TestConditional, self).__init__(loader=loader)
            self.when = ['test_conditional']

    class TestPlayContext(PlayContext):
        def __init__(self):
            super(TestPlayContext, self).__init__()
            self.prompt = None

    class TestVariableManager(VariableManager):
        def __init__(self):
            super(TestVariableManager, self).__init__()
            self._vars_cache = dict()


# Generated at 2022-06-22 16:32:20.414607
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert c.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:32:27.780840
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    # create a variable manager and loader
    variable_manager = VariableManager()
    loader = DataLoader()

    # create a play context
    play_context = PlayContext()

    # create a templar
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # create a task
    task = Task()

    # create a conditional
    conditional = Conditional()

    # set the conditional
    conditional.when = ["ansible_os_family == 'RedHat'"]

    # set the templar
    conditional

# Generated at 2022-06-22 16:32:40.310409
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)

    assert conditional._when == []
    assert conditional.evaluate_conditional(templar, {}) == True

    conditional._when = [True]
    assert conditional.evaluate_conditional(templar, {}) == True

    conditional._when = [False]
    assert conditional.evaluate_conditional(templar, {}) == False

    conditional._

# Generated at 2022-06-22 16:32:50.761763
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader, play_context=play_context)

    # Test 1: simple boolean
    conditional = Conditional()
    conditional.when = [True]
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars(play=None, host=None, task=None))

    # Test 2: simple string
    conditional = Conditional()
    conditional.when = ["True"]
   

# Generated at 2022-06-22 16:32:58.090068
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("hostvars['foo'] is defined") == [('hostvars[\'foo\']', 'is', 'defined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not defined") == [('hostvars[\'foo\']', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is undefined") == [('hostvars[\'foo\']', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not undefined") == [('hostvars[\'foo\']', 'is not', 'undefined')]

# Generated at 2022-06-22 16:33:09.930358
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = ["foo"]
    variable_manager.set_nonpersistent_facts({"foo": True})
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars())

    # Test with a simple conditional that fails
    conditional = Conditional()
    conditional.when = ["foo"]
    variable_manager.set_nonpersistent_facts({"foo": False})

# Generated at 2022-06-22 16:33:21.946097
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional()

# Generated at 2022-06-22 16:33:32.879404
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    vars_manager = VariableManager()
    templar = Templar(loader=None, variables=vars_manager)

    # test with a simple string
    c = Conditional()
    c.when = "foo"
    vars_manager.set_nonpersistent_facts(dict(foo='bar'))
    assert c.evaluate_conditional(templar, dict())

    # test with a simple string
    c = Conditional()
    c.when = "foo"
    vars_manager.set_nonpersistent_facts(dict(foo='bar'))
    assert c.evaluate_conditional(templar, dict())

    # test with a simple string
    c = Conditional()
    c.when = "foo"
    v

# Generated at 2022-06-22 16:34:17.373131
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    conditional = Conditional(loader=loader)
    assert conditional._loader == loader
    assert conditional._when == []
    assert conditional._validate_when(None, '_when', 'test') == None
    assert conditional._when == ['test']
    assert conditional._validate_when(None, '_when', ['test1', 'test2']) == None
    assert conditional._when == ['test1', 'test2']
    assert conditional._validate_when(None, '_when', None) == None
    assert conditional._when == []
    assert conditional.evaluate_conditional(variable_manager, {}) == True
    assert conditional._when == []

# Generated at 2022-06-22 16:34:25.261535
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-22 16:34:34.668199
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # test with a simple conditional
    conditional = 'foo is defined'
    all_vars = dict(foo='bar')
    templar = Templar(loader=None, variables=VariableManager(loader=None, variables=all_vars))
    assert Conditional().evaluate_conditional(templar, all_vars)

    # test with a simple conditional
    conditional = 'foo is not defined'
    all_vars = dict(foo='bar')
    templar = Templar(loader=None, variables=VariableManager(loader=None, variables=all_vars))
    assert not Conditional().evaluate_conditional(templar, all_vars)

    # test with a simple conditional
    conditional = 'foo is defined'
    all_v

# Generated at 2022-06-22 16:34:46.926737
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variable_manager=variable_manager, play_context=play_context)

    # test with a simple string
    conditional = "1 == 1"
    all_vars = dict()
    assert Conditional().evaluate_conditional(templar, all_vars)

    # test with a simple string

# Generated at 2022-06-22 16:34:58.961126
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)
    conditional.when = ['1 == 1', '1 == 2']

# Generated at 2022-06-22 16:35:11.322749
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined('foo is defined and bar is defined') == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:35:21.085820
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('a is defined') == [('a', 'is', 'defined')]
    assert c.extract_defined_undefined('a is not defined') == [('a', 'is not', 'defined')]
    assert c.extract_defined_undefined('a is undefined') == [('a', 'is', 'undefined')]
    assert c.extract_defined_undefined('a is not undefined') == [('a', 'is not', 'undefined')]
    assert c.extract_defined_undefined('a is defined and b is defined') == [('a', 'is', 'defined'), ('b', 'is', 'defined')]

# Generated at 2022-06-22 16:35:28.562311
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:35:39.365580
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert cond.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert cond.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert cond.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert cond.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:35:47.147247
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, shared_loader_obj=loader, play_context=context)

    conditional = Conditional(loader=loader)
    conditional.when = [True]
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars())

    conditional.when = [False]
    assert not conditional.evaluate_conditional(templar, variable_manager.get_vars())

    conditional.when = [True, False]

# Generated at 2022-06-22 16:37:07.702299
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)
    conditional = Conditional(loader=None)
    conditional.when = ["{{ test }}"]
    variable_manager.set_nonpersistent_facts(dict(test=True))
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars(play=play_context, include_hostvars=True))

# Generated at 2022-06-22 16:37:19.993184
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert c.extract_defined_undefined('foo is defined or bar is defined') == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]