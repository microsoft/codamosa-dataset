

# Generated at 2022-06-22 16:27:35.755487
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is not undefined") == [('foo', 'is', 'defined'), ('bar', 'is not', 'undefined')]


# Generated at 2022-06-22 16:27:48.650679
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'username'
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.accelerate = False
    play_context.accelerate_port = 5099
    play_context.accelerate_ipv6 = False
    play

# Generated at 2022-06-22 16:28:00.489520
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    class TestConditional(Conditional):
        def __init__(self, loader, play_context, variable_manager, all_vars):
            self._loader = loader
            self._play_context = play_context
            self._variable_manager = variable_manager
            self.all_vars = all_vars
            self.when = ['test_conditional']

    class TestPlayContext(PlayContext):
        def __init__(self):
            self.remote_addr = '127.0.0.1'


# Generated at 2022-06-22 16:28:11.397006
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is not undefined") == [("foo", "is", "defined"), ("bar", "is not", "undefined")]

# Generated at 2022-06-22 16:28:21.256966
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Create a play context
    play_context = PlayContext()
    # Create a variable manager
    variable_manager = VariableManager()
    # Create a templar
    templar = Templar(loader=None, variables=variable_manager)
    # Create an inventory manager
    inventory_manager = InventoryManager(loader=None, sources=[])
    # Create a conditional object
    conditional = Conditional(loader=None)

    # Test with a boolean value
    assert conditional.evaluate_conditional(templar, True) == True
    assert conditional.evaluate_conditional(templar, False) == False

    # Test with a string value

# Generated at 2022-06-22 16:28:30.234308
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Conditional):
        def __init__(self, loader=None):
            super(TestConditional, self).__init__(loader)
            self.when = ['{{ test_var }}', '{{ test_var2 }}']

    class TestPlayContext(PlayContext):
        def __init__(self):
            super(TestPlayContext, self).__init__()
            self.test_var = True
            self.test_var2 = False

    class TestVariableManager(VariableManager):
        def __init__(self):
            super(TestVariableManager, self).__init__()

# Generated at 2022-06-22 16:28:39.986203
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test_var': 'test_value'}
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional()
    conditional.when = ['test_var == test_value']
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars())

    conditional = Conditional()

# Generated at 2022-06-22 16:28:49.203776
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = ['foo is bar']
    all_vars = dict(foo='bar')
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test with a conditional containing a variable
    conditional = Conditional()
    conditional.when = ['foo is {{ bar }}']

# Generated at 2022-06-22 16:28:57.910664
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # test with a simple string
    conditional = "foo"
    all_vars = dict(foo="bar")
    assert Conditional().evaluate_conditional(templar, all_vars)

    # test with a simple string that evaluates to False
    conditional = "foo"
    all_vars = dict(foo="")
    assert not Conditional().evaluate_conditional(templar, all_vars)

    # test with a simple string that evaluates to False
    conditional = "foo"
    all_vars = dict

# Generated at 2022-06-22 16:29:10.864634
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with a conditional that evaluates to True
    conditional = Conditional()
    conditional.when = ['foo == "bar"']
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars(play=None, host=None, task=None))

    # Test with a conditional that evaluates to

# Generated at 2022-06-22 16:29:26.752347
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert c.extract_defined_undefined('foo is defined and bar is defined') == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:29:33.907131
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('foo is defined and bar is not defined') == [('foo', 'is', 'defined'), ('bar', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]

# Generated at 2022-06-22 16:29:39.873717
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert c.extract_defined_undefined('foo is defined and bar is defined') == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:29:50.177304
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)
    conditional.when = ['foo is defined', 'bar is defined']

    all_vars = dict(foo='bar', bar='baz')

# Generated at 2022-06-22 16:29:58.313012
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    pc = PlayContext()
    v = VariableManager()
    t = Templar(loader=None, variables=v)

    c = Conditional(loader=None)
    c._loader = None
    c._templar = t
    c._play_context = pc

    assert c.evaluate_conditional(t, v) == True
    assert c.evaluate_conditional(t, v) == True
    assert c.evaluate_conditional(t, v) == True
    assert c.evaluate_conditional(t, v) == True
    assert c.evaluate_conditional(t, v) == True
    assert c.evaluate_conditional(t, v) == True

# Generated at 2022-06-22 16:30:08.226220
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'username'
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.accelerate = False
    play_context.accelerate_port = 5099
    play_context.accelerate_ipv6 = False
    play_

# Generated at 2022-06-22 16:30:20.980667
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)
    variable_manager.extra_vars = {'foo': 'bar'}
    variable_manager.host_vars = HostVars(loader=loader, variables=variable_manager.extra_vars)
    play_context = PlayContext()

# Generated at 2022-06-22 16:30:32.352987
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    templar = Templar(loader=loader, variables=variable_manager)

    # Test 1
    conditional = Conditional()
    conditional.when = [
        'ansible_distribution == "CentOS"',
        'ansible_distribution == "Ubuntu"',
        'ansible_distribution == "RedHat"',
    ]


# Generated at 2022-06-22 16:30:43.693687
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Create a Conditional object
    conditional = Conditional()

    # Create a PlayContext object
    play_context = PlayContext()

    # Create a Templar object
    templar = Templar(loader=None, variables={})

    # Create a list of variables

# Generated at 2022-06-22 16:30:50.781993
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("") == []
    assert conditional.extract_defined_undefined("a") == []
    assert conditional.extract_defined_undefined("a is defined") == [('a', 'is', 'defined')]
    assert conditional.extract_defined_undefined("a is not defined") == [('a', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("a is undefined") == [('a', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("a is not undefined") == [('a', 'is not', 'undefined')]

# Generated at 2022-06-22 16:31:14.252326
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("") == []
    assert conditional.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert conditional.extract_defined_undefined("a is not defined") == [("a", "is not", "defined")]
    assert conditional.extract_defined_undefined("a is undefined") == [("a", "is", "undefined")]
    assert conditional.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]
    assert conditional.extract_defined_undefined("a is defined and b is defined") == [("a", "is", "defined"), ("b", "is", "defined")]

# Generated at 2022-06-22 16:31:24.765834
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Conditional):
        def __init__(self):
            super(TestConditional, self).__init__()
            self._ds = dict()

    # Test with a simple conditional
    c = TestConditional()
    c.when = 'foo'
    v = VariableManager()
    v.set_variable('foo', True)
    p = PlayContext()
    t = Templar(loader=None, variables=v, shared_loader_obj=None)
    assert c.evaluate_conditional(t, v.get_vars(loader=None, play=None, host=None, task=None))

    # Test with a simple conditional that evaluates to False
   

# Generated at 2022-06-22 16:31:38.845567
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    conditional = Conditional()
    conditional.when = ['foo is defined']
    assert conditional.evaluate_conditional(templar, {}) is False

    conditional.when = ['foo is defined', 'bar is defined']
    assert conditional.evaluate_conditional(templar, {}) is False

    conditional.when = ['foo is defined', 'bar is defined', 'baz is defined']
    assert conditional.evaluate_conditional(templar, {}) is False

    conditional.when = ['foo is defined', 'bar is defined', 'baz is defined', 'qux is defined']

# Generated at 2022-06-22 16:31:52.372606
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert conditional.extract_defined_undefined("a is not defined") == [("a", "is not", "defined")]
    assert conditional.extract_defined_undefined("a is undefined") == [("a", "is", "undefined")]
    assert conditional.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]
    assert conditional.extract_defined_undefined("a is defined and b is defined") == [("a", "is", "defined"), ("b", "is", "defined")]

# Generated at 2022-06-22 16:32:04.785501
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test for issue #16071
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # Test for issue #16071
    conditional = Conditional(loader=loader)

# Generated at 2022-06-22 16:32:14.632677
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    play_context = PlayContext()
    variable_manager = VariableManager()
    hostvars = HostVars(loader=None, variables=dict())
    variable_manager.set_host_variable(host=None, varname='hostvars', value=hostvars)
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    conditional = Conditional(loader=None)
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]

# Generated at 2022-06-22 16:32:25.276204
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    # Create a variable manager
    variable_manager = VariableManager()

    # Create a host
    host = Host(name="testhost")

    # Create a group
    group = Group(name="testgroup")

    # Create an inventory
    inventory = InventoryManager(loader=None, sources=None)

    # Add the host to the group
    group.add_host(host)

    # Add the group to the inventory
    inventory.add_group(group)

    # Add the host to the inventory
    inventory.add_host(host)

    # Set variables for the host
    variable_manager.set_host_

# Generated at 2022-06-22 16:32:38.062447
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader, playcontext=play_context)

    conditional = Conditional(loader=loader)

    conditional.when = [
        'foo',
        'bar',
        'baz'
    ]


# Generated at 2022-06-22 16:32:45.584450
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert c.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:32:55.469873
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert c.extract_defined_undefined('foo is defined and bar is defined') == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:33:35.012385
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # test with a simple string
    conditional = 'foo'
    all_vars = dict(foo='bar')
    assert Conditional().evaluate_conditional(templar, all_vars)

    # test with a simple string
    conditional = 'foo'
    all_vars = dict(foo='bar')
    assert Conditional().evaluate_conditional(templar, all_vars)

    # test with a simple string
    conditional = 'foo'
    all_vars = dict(foo='bar')
    assert Conditional

# Generated at 2022-06-22 16:33:41.404603
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)

    # test when is None
    conditional._when = None
    assert conditional.evaluate_conditional(templar, {})

    # test when is empty list
    conditional._when = []
    assert conditional.evaluate_conditional(templar, {})

    # test when is empty string
    conditional._when = ''
    assert conditional.evaluate_cond

# Generated at 2022-06-22 16:33:53.075058
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with a simple string
    conditional = Conditional()
    conditional.when = 'foo'
    assert conditional.evaluate_conditional(templar, dict(foo='bar')) == True

    # Test with a simple string


# Generated at 2022-06-22 16:34:05.114993
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("") == []
    assert conditional.extract_defined_undefined("foo") == []
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]

# Generated at 2022-06-22 16:34:17.158004
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    conditional = Conditional()
    conditional.when = ["{{ foo }} == 'bar'"]

    # test with no variables
    assert conditional.evaluate_conditional(templar, {}) == False

    # test with variables
    assert conditional.evaluate_conditional(templar, {'foo': 'bar'}) == True

    # test with a list
    conditional.when = ["{{ foo }} in ['bar', 'baz']"]
    assert conditional.evaluate_conditional(templar, {'foo': 'bar'}) == True

    # test with a list and a variable

# Generated at 2022-06-22 16:34:25.203472
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    conditional = Conditional()

# Generated at 2022-06-22 16:34:34.643329
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    pc = PlayContext()
    templar = Templar(loader=None, variables={})

    # test with undefined variable
    conditional = 'foo is defined'
    c = Conditional()
    assert not c.evaluate_conditional(templar, pc.get_vars())

    # test with defined variable
    conditional = 'foo is defined'
    c = Conditional()
    c.when = [conditional]
    pc.set_variable_manager(dict(foo='bar'))
    assert c.evaluate_conditional(templar, pc.get_vars())

    # test with undefined variable
    conditional = 'foo is undefined'
    c = Conditional()
    c.when = [conditional]
    pc.set

# Generated at 2022-06-22 16:34:46.876508
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is undefined") == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]

# Generated at 2022-06-22 16:34:58.880776
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined('foo is defined or bar is defined') == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:35:05.339716
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class Test(Base, Conditional):
        pass

    t = Test()
    assert t._when == []

    t = Test(loader=None)
    assert t._when == []

    t = Test(loader=None, when=['a', 'b'])
    assert t._when == ['a', 'b']

    t = Test(loader=None, when='a')
    assert t._when == ['a']

    t = Test(loader=None, when=None)
    assert t._when == []

    t = Test(loader=None, when=[])
    assert t._when == []

    t = Test(loader=None, when=True)

# Generated at 2022-06-22 16:36:23.671228
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:36:32.444662
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)
    conditional._when = ['foo']
    conditional.evaluate_conditional(templar, variable_manager.get_vars(play=None, host=None, task=None))

# Generated at 2022-06-22 16:36:44.449217
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = 'a == 1'
    all_vars = dict(a=1)
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test with a simple conditional with a variable
    conditional = Conditional()
    conditional.when = 'a == b'
    all_vars = dict(a=1, b=1)

# Generated at 2022-06-22 16:36:50.448109
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager


# Generated at 2022-06-22 16:37:00.682934
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is undefined") == [("foo", "is", "defined"), ("bar", "is", "undefined")]

# Generated at 2022-06-22 16:37:11.073528
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("a is defined") == [('a', 'is', 'defined')]
    assert cond.extract_defined_undefined("a is not defined") == [('a', 'is not', 'defined')]
    assert cond.extract_defined_undefined("a is undefined") == [('a', 'is', 'undefined')]
    assert cond.extract_defined_undefined("a is not undefined") == [('a', 'is not', 'undefined')]
    assert cond.extract_defined_undefined("a is defined and b is defined") == [('a', 'is', 'defined'), ('b', 'is', 'defined')]

# Generated at 2022-06-22 16:37:23.603449
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    hostvars = HostVars(loader=loader, play=play_context)
    templar = Templar(loader=loader, variables=variable_manager, hostvars=hostvars)

    class TestConditional(Conditional):
        def __init__(self):
            self._loader = loader
            self._templar = templar
            self