

# Generated at 2022-06-22 16:27:43.730241
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a Conditional object
    conditional = Conditional()

    # Create a PlayContext object
    play_context = PlayContext()

    # Create a VariableManager object
    variable_manager = VariableManager()

    # Create a Templar object
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    # Create a dict object
    all_vars = dict()

    # Test with a conditional that evaluates to True
    conditional.when = ['1 == 1']
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test with a conditional that evaluates to False
    conditional.when = ['1 == 2']
   

# Generated at 2022-06-22 16:27:51.512414
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = '1 == 1'
    assert conditional.evaluate_conditional(templar, {})

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = '1 == 2'
    assert not conditional.evaluate_conditional(templar, {})

    #

# Generated at 2022-06-22 16:28:03.122096
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    class TestConditional(Conditional):
        def __init__(self, loader):
            self._loader = loader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    test_conditional = TestConditional(loader)

# Generated at 2022-06-22 16:28:14.639550
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    pc = PlayContext()
    templar = Templar(loader=None, variables=dict(a=1, b=2, c=3))
    hostvars = HostVars(loader=None, variables=dict(a=1, b=2, c=3))
    all_vars = dict(pc=pc, hostvars=hostvars)

    # Test with a simple conditional
    conditional = 'a == 1'
    c = Conditional()
    assert c.evaluate_conditional(templar, all_vars) == True

    # Test with a simple conditional
    conditional = 'a == 2'
    c = Conditional()

# Generated at 2022-06-22 16:28:25.068951
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Setup
    play_context = PlayContext()
    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    # Test
    conditional = Conditional()
    conditional.when = ["{{ test_var }}"]
    variable_manager.set_nonpersistent_facts({"test_var": "test_value"})
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars(play=play_context))

    # Test
    conditional = Conditional()
    conditional.when = ["{{ test_var }}"]
    variable_manager.set_nonpersistent_facts

# Generated at 2022-06-22 16:28:37.545785
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    class TestConditional(Conditional):
        def __init__(self):
            super(TestConditional, self).__init__()

    class TestPlayContext(PlayContext):
        def __init__(self):
            super(TestPlayContext, self).__init__()
            self.prompt = None

    class TestVariableManager(VariableManager):
        def __init__(self):
            super(TestVariableManager, self).__init__()
            self._hostvars = HostVars(loader=None, variables=dict())


# Generated at 2022-06-22 16:28:48.749410
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Conditional):
        def __init__(self):
            self._loader = DictDataLoader({})
            self._variable_manager = VariableManager()
            self._variable_manager.set_inventory(Inventory(host_list=[]))
            self._templar = Templar(loader=self._loader, variables=self._variable_manager.get_vars(play=None, host=None, task=None))
            self._ds = None

    # Test with a simple string
    test_conditional = TestConditional()
    test_conditional.when = ['test_string']

# Generated at 2022-06-22 16:28:57.690782
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    # Test with simple conditional
    c = Conditional()
    c.when = ["foo == 'bar'"]
    t = Templar(loader=None, variables={'foo': 'bar'})
    assert c.evaluate_conditional(t, {})

    # Test with simple conditional with undefined variable
    c = Conditional()
    c.when = ["foo == 'bar'"]
    t = Templar(loader=None, variables={})
    assert not c.evaluate_conditional(t, {})

    # Test with simple conditional with undefined variable and check_mode
    c = Conditional()
    c.when = ["foo == 'bar'"]
    t = Templar(loader=None, variables={})
    assert c.evaluate_conditional(t, {}, check_mode=True)

    # Test with simple

# Generated at 2022-06-22 16:29:10.779257
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("hostvars['foo'] is defined") == [('hostvars[\'foo\']', 'is', 'defined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not defined") == [('hostvars[\'foo\']', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is undefined") == [('hostvars[\'foo\']', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not undefined") == [('hostvars[\'foo\']', 'is not', 'undefined')]

# Generated at 2022-06-22 16:29:22.802127
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is undefined") == [("foo", "is", "defined"), ("bar", "is", "undefined")]

# Generated at 2022-06-22 16:29:42.846500
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("") == []
    assert c.extract_defined_undefined("a") == []
    assert c.extract_defined_undefined("a is defined") == [('a', 'is', 'defined')]
    assert c.extract_defined_undefined("a is not defined") == [('a', 'is not', 'defined')]
    assert c.extract_defined_undefined("a is undefined") == [('a', 'is', 'undefined')]
    assert c.extract_defined_undefined("a is not undefined") == [('a', 'is not', 'undefined')]

# Generated at 2022-06-22 16:29:52.044249
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined and bar is undefined") == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not defined and bar is not undefined") == [('foo', 'is not', 'defined'), ('bar', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is not undefined") == [('foo', 'is', 'defined'), ('bar', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not defined and bar is undefined") == [('foo', 'is not', 'defined'), ('bar', 'is', 'undefined')]

# Generated at 2022-06-22 16:30:04.069971
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test case 1:
    #   when:
    #     - test_var is defined
    #     - test_var is not defined
    #   vars:
    #     test_var: 'test_value'
    #
    # Expected result:
    #   True
    #
    # Explanation:
    #   The first condition is True, so the second condition is not evaluated.
    #   The result is True.
    test_case_1 = {
        'when': [
            'test_var is defined',
            'test_var is not defined'
        ],
        'vars': {
            'test_var': 'test_value'
        }
    }
    assert Conditional().evaluate_conditional(test_case_1)

    # Test case 2:
    #   when:
    #

# Generated at 2022-06-22 16:30:16.500166
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:30:21.172597
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)
    conditional.when = ['foo']
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars()) == False
    conditional.when = ['foo', 'bar']


# Generated at 2022-06-22 16:30:32.503987
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader, playcontext=play_context)

    conditional = Conditional()
    conditional.when = ['foo is defined', 'bar is defined']
    all_vars = dict(foo='foo', bar='bar')
    assert conditional.evaluate_conditional

# Generated at 2022-06-22 16:30:43.856105
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:30:50.805938
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert cond.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert cond.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert cond.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert cond.extract_defined_undefined("foo is defined or bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:31:02.441997
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_host_variable('localhost', 'foo', 'bar')
    variable_manager.set_host_variable('localhost', 'baz', 'qux')
    variable_manager.set_host_variable('localhost', 'spam', 'eggs')
    variable_manager.set_host_variable('localhost', 'ansible_ssh_host', 'localhost')
    variable_manager.set_host_variable('localhost', 'ansible_ssh_port', 22)
    variable_manager.set_host_variable('localhost', 'ansible_ssh_user', 'root')
    variable_manager.set_host_variable('localhost', 'ansible_ssh_pass', 'password')
    variable_manager.set_

# Generated at 2022-06-22 16:31:12.192578
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Conditional):
        def __init__(self, loader=None):
            super(TestConditional, self).__init__(loader=loader)

    # Test with undefined variable
    conditional = TestConditional()
    play_context = PlayContext()
    templar = Templar(loader=None, variables=VariableManager())
    conditional.when = [u"{{ undefined_var }}"]
    assert conditional.evaluate_conditional(templar, dict()) is False

    # Test with defined variable
    conditional = TestConditional()
    play_context = PlayContext()
    templar = Templar(loader=None, variables=VariableManager())

# Generated at 2022-06-22 16:31:39.737929
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a Conditional object
    conditional = Conditional()

    # Create a PlayContext object
    play_context = PlayContext()

    # Create a VariableManager object
    variable_manager = VariableManager()

    # Create a Templar object
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    # Test with a boolean value
    conditional.when = [True]
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars(play=play_context)) == True

    # Test with a string value
    conditional.when = ['True']

# Generated at 2022-06-22 16:31:50.150071
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("") == []
    assert conditional.extract_defined_undefined("a") == []
    assert conditional.extract_defined_undefined("a is defined") == [('a', 'is', 'defined')]
    assert conditional.extract_defined_undefined("a is not defined") == [('a', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("a is undefined") == [('a', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("a is not undefined") == [('a', 'is not', 'undefined')]

# Generated at 2022-06-22 16:31:57.251168
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("a is defined and b is defined") == [('a', 'is', 'defined'), ('b', 'is', 'defined')]
    assert conditional.extract_defined_undefined("a is defined and b is not defined") == [('a', 'is', 'defined'), ('b', 'is', 'not defined')]
    assert conditional.extract_defined_undefined("a is not defined and b is not defined") == [('a', 'is', 'not defined'), ('b', 'is', 'not defined')]
    assert conditional.extract_defined_undefined("a is defined and b is undefined") == [('a', 'is', 'defined'), ('b', 'is', 'undefined')]

# Generated at 2022-06-22 16:32:03.842899
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('localhost'))
    variable_manager.extra_vars = {'foo': 'bar'}
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = ['foo == bar']
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars())

    # Test with a conditional that uses a variable that is not defined
    conditional = Conditional()
    conditional.when = ['foo == baz']
    assert not conditional.evaluate_

# Generated at 2022-06-22 16:32:14.117872
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(host_list=['localhost']))
    variable_manager.extra_vars = dict(
        foo='bar',
        baz='qux',
        quux='corge',
        grault='garply',
        waldo='fred',
        plugh='xyzzy',
        thud='wibble',
        empty_string='',
        empty_list=[],
        empty_dict={},
        empty_set=set(),
        empty_tuple=()
    )

    templar = Templar(loader=None, variables=variable_manager)

    # Test with a boolean
    conditional = Conditional()

# Generated at 2022-06-22 16:32:24.833938
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    conditional = Conditional()
    conditional._loader = None
    conditional.when = ['ansible_os_family == "RedHat"', 'ansible_os_family == "Debian"']

    # Test with ansible_os_family == "RedHat"
    variable_manager.set_nonpersistent_facts(dict(ansible_os_family="RedHat"))
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars(play=play_context))

    # Test

# Generated at 2022-06-22 16:32:37.577483
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with a simple string
    conditional = '"foo" in "foobar"'
    all_vars = dict()
    assert Conditional().evaluate_conditional(templar, all_vars)

    # Test with a boolean
    conditional = True
    all_vars = dict()
    assert Conditional().evaluate_conditional(templar, all_vars)

    # Test

# Generated at 2022-06-22 16:32:45.309238
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is undefined") == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]

# Generated at 2022-06-22 16:32:55.413349
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with a boolean value
    conditional = Conditional()
    conditional.when = True
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars(play=None, host=None, task=None))



# Generated at 2022-06-22 16:33:07.986327
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()

    # Create a fake variable manager
    variable_manager = VariableManager()

    # Create a fake loader
    loader = None

    # Create a fake templar
    templar = Templar(loader=loader, variables=variable_manager)

    # Create a fake Conditional
    conditional = Conditional(loader=loader)

    # Create a fake all_vars
    all_vars = dict()

    # Test with a None conditional
    conditional._when = [None]
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test with a empty conditional

# Generated at 2022-06-22 16:33:48.996227
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=variable_manager)

    conditional = Conditional(loader=loader)
    conditional.when = ['foo is defined', 'bar is defined', 'baz is defined']
    all_vars = dict(foo='foo', bar='bar')
    assert conditional

# Generated at 2022-06-22 16:34:00.873249
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader)

    # Test 1:
    # Test case:
    #   - when: 1 == 1
    #   - when: 1 == 2
   

# Generated at 2022-06-22 16:34:11.732791
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name='localhost')

# Generated at 2022-06-22 16:34:20.336508
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:34:28.194062
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a play context and a templar
    play_context = PlayContext()
    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    # Create a Conditional object
    conditional = Conditional()

    # Test with a simple conditional
    conditional._when = ["ansible_os_family == 'RedHat'"]
    all_vars = variable_manager.get_vars(play=None, host=None)
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test with a conditional that uses a variable

# Generated at 2022-06-22 16:34:39.537342
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("a is defined") == [('a', 'is', 'defined')]
    assert conditional.extract_defined_undefined("a is not defined") == [('a', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("a is undefined") == [('a', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("a is not undefined") == [('a', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("a is defined and b is defined") == [('a', 'is', 'defined'), ('b', 'is', 'defined')]

# Generated at 2022-06-22 16:34:51.138618
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)
    conditional.when = ['foo is bar']

    # test with a variable that is defined
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))

# Generated at 2022-06-22 16:35:01.587697
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # Create a fake hostvars object
    hostvars = HostVars(loader=None, variables=dict())
    hostvars._data = dict(
        foo='bar',
        baz=dict(
            biz='buz',
            biz2=dict(
                biz3='buz3'
            )
        )
    )

    # Create a fake variable manager
    variable_manager = VariableManager()
    variable_manager._fact_cache = dict()

# Generated at 2022-06-22 16:35:12.633856
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("") == []
    assert cond.extract_defined_undefined("foo") == []
    assert cond.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert cond.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert cond.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert cond.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]

# Generated at 2022-06-22 16:35:17.837919
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('a is defined') == [('a', 'is', 'defined')]
    assert conditional.extract_defined_undefined('a is not defined') == [('a', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('a is undefined') == [('a', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('a is not undefined') == [('a', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined('a is defined and b is defined') == [('a', 'is', 'defined'), ('b', 'is', 'defined')]

# Generated at 2022-06-22 16:36:30.166555
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("a is defined") == [('a', 'is', 'defined')]
    assert cond.extract_defined_undefined("a is not defined") == [('a', 'is not', 'defined')]
    assert cond.extract_defined_undefined("a is undefined") == [('a', 'is', 'undefined')]
    assert cond.extract_defined_undefined("a is not undefined") == [('a', 'is not', 'undefined')]
    assert cond.extract_defined_undefined("a is defined or b is defined") == [('a', 'is', 'defined'), ('b', 'is', 'defined')]

# Generated at 2022-06-22 16:36:43.301637
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=variable_manager)

    # Test with a simple variable
    variable_manager.set_nonpersistent_facts(dict(foo='bar'))


# Generated at 2022-06-22 16:36:52.268476
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'username'
    play_context.port = 22
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.timeout = 10
    play_context.shell = '/bin/sh'
    play_context.executable = None
    play_context.environment = dict()


# Generated at 2022-06-22 16:37:01.660031
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert cond.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert cond.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert cond.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert cond.extract_defined_undefined('foo is defined and bar is not undefined') == [('foo', 'is', 'defined'), ('bar', 'is not', 'undefined')]

# Generated at 2022-06-22 16:37:11.852069
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a mock object for the templar
    class MockTemplar(Templar):
        def __init__(self):
            self.environment = None
            self.available_variables = None

        def is_template(self, data):
            return False

        def template(self, data, disable_lookups=False):
            return data

    # Create a mock object for the play context
    class MockPlayContext(PlayContext):
        def __init__(self):
            self.prompt = None
            self.connection = None
            self.remote_addr = None
            self.password = None
            self.port = None
            self.timeout = None
            self

# Generated at 2022-06-22 16:37:23.669840
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # test with a simple conditional
    conditional = 'foo == "bar"'
    all_vars = dict(foo='bar')
    templar = Templar(loader=None, variables=all_vars)
    assert Conditional().evaluate_conditional(templar, all_vars)

    # test with a conditional that uses a variable
    conditional = 'foo == "bar"'
    all_vars = dict(foo='bar')
    templar = Templar(loader=None, variables=all_vars)
    assert Conditional().evaluate_conditional(templar, all_vars)

    # test with a conditional that uses a variable and a jinja2 expression
   