

# Generated at 2022-06-22 16:27:48.754408
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class TestConditional(Conditional):
        def __init__(self):
            super(TestConditional, self).__init__()

    class TestPlay(object):
        def __init__(self):
            self.hostvars = dict()
            self.vars = dict()

    class TestTask(object):
        def __init__(self):
            self.play = TestPlay()

    class TestHost(object):
        def __init__(self):
            self.vars = dict()

    class TestInventory(object):
        def __init__(self):
            self.hosts = dict()


# Generated at 2022-06-22 16:28:00.625014
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional()
    conditional.when = ['foo']

    assert conditional.evaluate_conditional(templar, dict(foo=True))
    assert not conditional.evaluate_conditional(templar, dict(foo=False))


# Generated at 2022-06-22 16:28:11.569799
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is defined and hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined'), ('hostvars[inventory_hostname]', 'is', 'defined')]

# Generated at 2022-06-22 16:28:21.231770
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("hostvars['foo'] is defined") == [("hostvars['foo']", "is", "defined")]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not defined") == [("hostvars['foo']", "is not", "defined")]
    assert conditional.extract_defined_undefined("hostvars['foo'] is undefined") == [("hostvars['foo']", "is", "undefined")]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not undefined") == [("hostvars['foo']", "is not", "undefined")]

# Generated at 2022-06-22 16:28:33.793659
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional(loader=loader)

# Generated at 2022-06-22 16:28:42.955847
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'username'
    play_context.port = 22
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.accelerate = False
    play_context.accelerate_port = 5099
    play_context.accelerate_ipv6 = False
    play

# Generated at 2022-06-22 16:28:53.923628
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name="localhost")

# Generated at 2022-06-22 16:28:57.804622
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # test with a simple conditional
    conditional = "foo == 'bar'"
    all_vars = dict(foo='bar')
    templar = Templar(loader=None, variables=all_vars)
    assert Conditional().evaluate_conditional(templar, all_vars)

    # test with a simple conditional that fails
    conditional = "foo == 'bar'"
    all_vars = dict(foo='baz')
    templar = Templar(loader=None, variables=all_vars)
    assert not Conditional().evaluate_conditional(templar, all_vars)

    # test with a simple conditional that fails
    conditional = "foo == 'bar'"

# Generated at 2022-06-22 16:29:10.821293
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = [ "ansible_distribution == 'Ubuntu'" ]
    all_vars = variable_manager.get_vars(loader=loader, play=None)
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test with a simple conditional with a variable
    conditional = Conditional()
    conditional.when = [ "ansible_distribution == '{{ ansible_distribution }}'" ]
    all_vars = variable_manager

# Generated at 2022-06-22 16:29:22.810199
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple conditional
    conditional = "1 == 1"
    all_vars = dict()
    assert Conditional().evaluate_conditional(templar, all_vars)

    # Test with a simple conditional
    conditional = "1 == 2"
    all_vars = dict()
    assert not Conditional().evaluate_conditional(templar, all_vars)

    # Test with a simple conditional
    conditional = "1 == 2"
    all_vars = dict()
    assert not Conditional().evaluate_cond

# Generated at 2022-06-22 16:29:42.702414
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # Create a play context
    play_context = PlayContext()

    # Create a variable manager
    variable_manager = VariableManager()

    # Create a hostvars object
    hostvars = HostVars(loader=None, variables=dict())

    # Create a templar
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    # Create a Conditional object
    conditional = Conditional(loader=None)

    # Test evaluate_conditional with a conditional that is None

# Generated at 2022-06-22 16:29:53.417253
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    # Create a variable manager
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    # Create a template
    templar = Templar(loader=loader, variables=variable_manager)

    # Create a conditional object
    conditional = Conditional(loader=loader)

    # Create a play context
    play_context = PlayContext()

    # Test with a simple conditional
    conditional.when = ['1 == 1']
    assert conditional.evaluate_

# Generated at 2022-06-22 16:30:05.148438
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert c.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert c.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert c.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert c.extract_defined_undefined("foo is defined and bar is not undefined") == [("foo", "is", "defined"), ("bar", "is not", "undefined")]

# Generated at 2022-06-22 16:30:13.005955
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:30:22.201109
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:30:32.989551
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # test data

# Generated at 2022-06-22 16:30:44.371992
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple string
    conditional = Conditional()
    conditional.when = ['foo']
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars())

    # Test with a boolean
    conditional = Conditional()
    conditional.when = [True]
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars())

    # Test with a boolean
    conditional = Conditional()
    conditional

# Generated at 2022-06-22 16:30:50.962243
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'username'
    play_context.port = 22
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.timeout = 10
    play_context.shell = '/bin/sh'
    play_context.executable = None
    play_context.stdin = False
   

# Generated at 2022-06-22 16:30:58.539595
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("") == []
    assert c.extract_defined_undefined("foo") == []
    assert c.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]

# Generated at 2022-06-22 16:31:06.368448
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:31:28.469545
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined('foo is defined and bar is defined') == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:31:40.793862
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert c.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert c.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert c.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert c.extract_defined_undefined("foo is defined and bar is not undefined") == [("foo", "is", "defined"), ("bar", "is not", "undefined")]

# Generated at 2022-06-22 16:31:53.910195
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Test 1
    conditional = "hostvars['foo'] is defined"
    expected = [('hostvars[\'foo\']', 'is', 'defined')]
    result = Conditional().extract_defined_undefined(conditional)
    assert result == expected

    # Test 2
    conditional = "hostvars['foo'] is not defined"
    expected = [('hostvars[\'foo\']', 'is not', 'defined')]
    result = Conditional().extract_defined_undefined(conditional)
    assert result == expected

    # Test 3
    conditional = "hostvars['foo'] is undefined"
    expected = [('hostvars[\'foo\']', 'is', 'undefined')]
    result = Conditional().extract_defined_undefined(conditional)
    assert result == expected

   

# Generated at 2022-06-22 16:32:06.342044
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is undefined") == [("foo", "is", "defined"), ("bar", "is", "undefined")]

# Generated at 2022-06-22 16:32:15.598937
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    # test with a simple conditional
    conditional = Conditional()
    conditional.when = ['foo']
    assert conditional.evaluate_conditional(templar, {}) == False

    # test with a simple conditional
    conditional = Conditional()
    conditional.when = ['foo is defined']
    assert conditional.evaluate_conditional(templar, {}) == False

    # test with a simple conditional
    conditional = Conditional()
    conditional.when = ['foo is not defined']
    assert conditional.evaluate_conditional(templar, {}) == True

    # test with a simple conditional
    conditional = Conditional()

# Generated at 2022-06-22 16:32:25.957678
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple boolean
    conditional = Conditional()
    conditional.when = [True]
    assert conditional.evaluate_conditional(templar, {})

    # Test with a simple string
    conditional = Conditional()
    conditional.when = ['True']
    assert conditional.evaluate_conditional(templar, {})

    # Test with a simple string

# Generated at 2022-06-22 16:32:38.794013
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test for undefined variable
    conditional = Conditional()
    conditional.when = ['foo is defined']
    all_vars = dict()
    assert not conditional.evaluate_conditional(templar, all_vars)

    # Test for defined variable
    conditional = Conditional()
    conditional.when = ['foo is defined']
    all_vars = dict(foo='bar')

# Generated at 2022-06-22 16:32:45.971784
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    play_context = PlayContext()
    variable_manager = VariableManager()
    variable_manager.set_host_variable(HostVars(variable_manager, 'localhost'), 'localhost')
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    conditional = Conditional()

# Generated at 2022-06-22 16:32:57.531741
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    conditional = Conditional()
    conditional.when = ['foo is defined', 'bar is defined']

    all_vars = dict(foo='bar')
    assert conditional.evaluate_conditional(templar, all_vars) is False



# Generated at 2022-06-22 16:33:09.626603
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:33:44.937701
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.base import Base
    from ansible.parsing.dataloader import DataLoader

    class TestConditional(Base, Conditional):
        pass

    loader = DataLoader()
    c = TestConditional(loader=loader)
    assert c._loader == loader
    assert c._when == []



# Generated at 2022-06-22 16:33:56.208382
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("") == []
    assert c.extract_defined_undefined("a") == []
    assert c.extract_defined_undefined("a is defined") == [('a', 'is', 'defined')]
    assert c.extract_defined_undefined("a is not defined") == [('a', 'is not', 'defined')]
    assert c.extract_defined_undefined("a is undefined") == [('a', 'is', 'undefined')]
    assert c.extract_defined_undefined("a is not undefined") == [('a', 'is not', 'undefined')]

# Generated at 2022-06-22 16:34:02.358729
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert c.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert c.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert c.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert c.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-22 16:34:12.440791
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert c.extract_defined_undefined("a is not defined") == [("a", "is not", "defined")]
    assert c.extract_defined_undefined("a is undefined") == [("a", "is", "undefined")]
    assert c.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]
    assert c.extract_defined_undefined("a is defined and b is defined") == [("a", "is", "defined"), ("b", "is", "defined")]

# Generated at 2022-06-22 16:34:23.712366
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    templar = Templar(loader=loader, variables=variable_manager)

    conditional = Conditional(loader=loader)

    # test with a boolean
    conditional.when = True
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars())

    # test with a string
    conditional.when = 'foo'
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars())

    # test with a list
    conditional.when = ['foo', 'bar']
    assert conditional

# Generated at 2022-06-22 16:34:30.436731
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()

    # Create a fake variable manager
    variable_manager = VariableManager()

    # Create a fake loader
    loader = 'fake loader'

    # Create a fake templar
    templar = Templar(loader=loader, variables=variable_manager)

    # Create a fake conditional
    conditional = Conditional(loader=loader)

    # Create a fake all_vars

# Generated at 2022-06-22 16:34:42.507315
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    p = PlayContext()
    t = Templar(loader=None, variables=VariableManager())

    c = Conditional(loader=None)
    c._when = ['foo']
    assert c.evaluate_conditional(t, p.get_vars()) == True

    c = Conditional(loader=None)
    c._when = ['foo', 'bar']
    assert c.evaluate_conditional(t, p.get_vars()) == True

    c = Conditional(loader=None)
    c._when = ['foo', 'bar', 'baz']
    assert c.evaluate_conditional(t, p.get_vars()) == True


# Generated at 2022-06-22 16:34:47.425313
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'username'
    play_context.port = 22
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.accelerate = False
    play_context.accelerate_port = 5099
    play_context.accelerate_ipv6 = False
    play

# Generated at 2022-06-22 16:34:59.255820
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is not undefined") == [('foo', 'is', 'defined'), ('bar', 'is not', 'undefined')]

# Generated at 2022-06-22 16:35:11.668871
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined or bar is not defined") == [('foo', 'is', 'defined'), ('bar', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is defined or bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is not defined") == [('foo', 'is', 'defined'), ('bar', 'is not', 'defined')]

# Generated at 2022-06-22 16:36:25.657749
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test with a simple string
    conditional = 'foo'
    all_vars = dict(foo='bar')
    assert Conditional().evaluate_conditional(templar, all_vars)

    # test with a simple string

# Generated at 2022-06-22 16:36:33.641477
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('foo is defined and bar is not defined') == [('foo', 'is', 'defined'), ('bar', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]

# Generated at 2022-06-22 16:36:45.168568
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # Test with a simple conditional
    conditional = "ansible_os_family == 'RedHat'"
    all_vars = dict(ansible_os_family='RedHat')
    templar = Templar(loader=None, variables=VariableManager(loader=None, variables=all_vars))
    assert Conditional().evaluate_conditional(templar, all_vars)

    # Test with a simple conditional that fails
    conditional = "ansible_os_family == 'RedHat'"
    all_vars = dict(ansible_os_family='Debian')
    templar = Templar(loader=None, variables=VariableManager(loader=None, variables=all_vars))

# Generated at 2022-06-22 16:36:52.685068
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("") == []
    assert c.extract_defined_undefined("foo") == []
    assert c.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]

# Generated at 2022-06-22 16:37:01.863983
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("") == []
    assert conditional.extract_defined_undefined("a") == []
    assert conditional.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert conditional.extract_defined_undefined("a is not defined") == [("a", "is not", "defined")]
    assert conditional.extract_defined_undefined("a is undefined") == [("a", "is", "undefined")]
    assert conditional.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]

# Generated at 2022-06-22 16:37:11.997665
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = ['foo is bar']
    all_vars = dict(foo='bar')

# Generated at 2022-06-22 16:37:23.701888
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Create a Conditional object
    conditional = Conditional()

    # Create a PlayContext object
    play_context = PlayContext()

    # Create a Templar object
    templar = Templar(loader=None, variables={})

    # Create a dict with all variables
    all_vars = dict()

    # Test with an empty conditional
    conditional.when = ['']
    assert conditional.evaluate_conditional(templar, all_vars) == True

    # Test with a boolean conditional
    conditional.when = [False]
    assert conditional.evaluate_conditional(templar, all_vars) == False

    # Test with a string conditional
    conditional.when = ['foo']