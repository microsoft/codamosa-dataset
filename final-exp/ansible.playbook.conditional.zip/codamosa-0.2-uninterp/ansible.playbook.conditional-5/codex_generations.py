

# Generated at 2022-06-22 16:27:38.017487
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = {}
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test with a simple conditional
    conditional = Conditional()
    conditional.when = ['foo']
    all_vars = dict(foo=True)
    assert conditional.evaluate_conditional(templar, all_vars)

    # test with

# Generated at 2022-06-22 16:27:49.555000
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("hostvars['foo'] is defined") == [('hostvars[\'foo\']', 'is', 'defined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not defined") == [('hostvars[\'foo\']', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is undefined") == [('hostvars[\'foo\']', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not undefined") == [('hostvars[\'foo\']', 'is not', 'undefined')]

# Generated at 2022-06-22 16:28:01.190592
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'username'
    play_context.connection = 'ssh'
    play_context.network_os = 'default'
    play_context.accelerate = False
    play_context.accelerate_port = 5099
    play_context.accelerate_ipv6 = False
    play

# Generated at 2022-06-22 16:28:11.986892
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a fake play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = None
    play_context.become_user = None
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'remote_user'
    play_context.connection = 'ssh'
    play_context.network_os = None
    play_context.timeout = 10
    play_context.shell = None
    play_context.executor_path = None
    play_context.become_pass = None
    play_context

# Generated at 2022-06-22 16:28:23.665034
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with undefined variable
    conditional = Conditional()
    conditional.when = ["{{ foo }} == 'bar'"]
    assert not conditional.evaluate_conditional(templar, {})

    # Test with defined variable
    conditional = Conditional()
    conditional.when = ["{{ foo }} == 'bar'"]

# Generated at 2022-06-22 16:28:34.510478
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # Setup
    variable_manager = VariableManager()
    variable_manager.set_host_variable('host1', 'foo', 'bar')
    variable_manager.set_host_variable('host1', 'baz', 'qux')
    variable_manager.set_host_variable('host1', 'spam', 'eggs')
    variable_manager.set_host_variable('host1', 'ansible_ssh_host', '127.0.0.1')
    variable_manager.set_host_variable('host1', 'ansible_ssh_port', '22')
    variable_manager.set_host_variable('host1', 'ansible_ssh_user', 'root')

# Generated at 2022-06-22 16:28:44.502480
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert cond.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert cond.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert cond.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert cond.extract_defined_undefined("foo is defined and bar is not undefined") == [("foo", "is", "defined"), ("bar", "is not", "undefined")]

# Generated at 2022-06-22 16:28:55.217635
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    class TestConditional(Conditional):
        def __init__(self, loader=None):
            super(TestConditional, self).__init__(loader=loader)

    class TestModule:
        def __init__(self):
            self.params = dict()
            self.params['test_param'] = 'test_value'

    class TestPlay:
        def __init__(self):
            self.hostvars = dict()
            self.hostvars['test_host'] = dict()
            self.hostvars['test_host']['test_hostvar'] = 'test_hostvar_value'

    class TestHost:
        def __init__(self):
            self.vars = dict()

# Generated at 2022-06-22 16:29:01.803187
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is not undefined") == [('foo', 'is', 'defined'), ('bar', 'is not', 'undefined')]

# Generated at 2022-06-22 16:29:13.215434
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    p = Conditional()
    assert p._when == []

    p = Conditional(loader=None)
    assert p._when == []

    p = Conditional(loader=None, when=['foo'])
    assert p._when == ['foo']

    p = Conditional(loader=None, when=['foo', 'bar'])
    assert p._when == ['foo', 'bar']

    p = Conditional(loader=None, when=['foo', 'bar'])
    assert p._when == ['foo', 'bar']

    p = Conditional(loader=None, when=['foo', 'bar'])
    assert p._when == ['foo', 'bar']

    p

# Generated at 2022-06-22 16:29:30.455180
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = ['foo is bar']
    all_vars = dict(foo='bar')
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test with a simple conditional that fails
    conditional = Conditional()
    conditional.when = ['foo is bar']
   

# Generated at 2022-06-22 16:29:42.685516
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("") == []
    assert c.extract_defined_undefined("a") == []
    assert c.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert c.extract_defined_undefined("a is defined and b is defined") == [("a", "is", "defined"), ("b", "is", "defined")]
    assert c.extract_defined_undefined("a is defined and b is defined and c is defined") == [("a", "is", "defined"), ("b", "is", "defined"), ("c", "is", "defined")]

# Generated at 2022-06-22 16:29:53.416798
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:30:05.148941
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    conditional = Conditional()
    conditional.when = [
        'foo is defined',
        'bar is not defined',
        'baz is defined',
        'qux is not defined',
        'foo is not defined',
        'bar is defined',
        'baz is not defined',
        'qux is defined',
    ]


# Generated at 2022-06-22 16:30:16.683065
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.base import Base
    from ansible.template import Templar

    class TestConditional(Base, Conditional):
        pass

    # Test with a simple string
    test_conditional = TestConditional()
    test_conditional.when = "test"
    templar = Templar(loader=None, variables={})
    assert test_conditional.evaluate_conditional(templar, {})

    # Test with a boolean
    test_conditional = TestConditional()
    test_conditional.when = True
    templar = Templar(loader=None, variables={})
    assert test_conditional.evaluate_conditional(templar, {})

    # Test with a boolean
    test_conditional = TestConditional()
    test_conditional.when = False

# Generated at 2022-06-22 16:30:28.127944
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = ['foo']
    all_vars = dict(foo=True)
    assert conditional.evaluate_conditional(templar, all_vars)

   

# Generated at 2022-06-22 16:30:38.840991
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Test the method evaluate_conditional of class Conditional
    '''
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader)

    # Test with a valid conditional
    conditional = Conditional()
    conditional.when = ['ansible_distribution == "CentOS"']

# Generated at 2022-06-22 16:30:49.650419
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Create a Conditional object
    conditional = Conditional()

    # Create a PlayContext object
    play_context = PlayContext()

    # Create a Templar object
    templar = Templar(loader=None, variables={})

    # Create a dict of all variables
    all_vars = dict()

    # Test with a valid conditional
    conditional.when = ['1 == 1']
    assert conditional.evaluate_conditional(templar, all_vars)

    # Test with an invalid conditional
    conditional.when = ['1 == 2']
    assert not conditional.evaluate_conditional(templar, all_vars)

    # Test with a valid conditional
    conditional.when = ['1 == 1', '2 == 2']

# Generated at 2022-06-22 16:31:01.004041
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined('foo is defined and bar is not defined') == [('foo', 'is', 'defined'), ('bar', 'is not', 'defined')]

# Generated at 2022-06-22 16:31:11.699980
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    templar = Templar(loader=loader, variables=variable_manager)

    conditional = Conditional(loader=loader)

    # test with a string
    conditional.when = 'ansible_distribution == "CentOS"'
    assert conditional.evaluate_conditional(templar, dict())

    # test with a list
    conditional.when = ['ansible_distribution == "CentOS"', 'ansible_distribution == "Ubuntu"']

# Generated at 2022-06-22 16:31:40.491426
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = Host(name='localhost')
    group = Group(name='ungrouped')
    group.add_host(host)
    inventory.add_group(group)
    inventory.add_host(host)
    variable

# Generated at 2022-06-22 16:31:51.691171
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is undefined") == [("foo", "is", "defined"), ("bar", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is not undefined") == [("foo", "is", "defined"), ("bar", "is not", "undefined")]

# Generated at 2022-06-22 16:32:03.673331
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:32:13.991937
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={'foo': 'bar'})

    conditional = Conditional()
    conditional.when = ['foo is bar']
    assert conditional.evaluate_conditional(templar, play_context.get_vars())

    conditional.when = ['foo is not bar']
    assert not conditional.evaluate_conditional(templar, play_context.get_vars())

    conditional.when = ['foo is bar', 'foo is not bar']
    assert not conditional.evaluate_conditional(templar, play_context.get_vars())

    conditional.when = ['foo is bar', 'foo is bar']

# Generated at 2022-06-22 16:32:24.834003
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert cond.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert cond.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert cond.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert cond.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:32:31.216983
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test for undefined variable
    conditional = Conditional()
    conditional.when = [ 'foo is defined' ]
    assert conditional.evaluate_conditional(templar, {}) == False

    # test for defined variable
    conditional = Conditional

# Generated at 2022-06-22 16:32:42.730682
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    p = PlayContext()
    t = Templar(loader=None, variables=VariableManager())
    c = Conditional(loader=None)
    c._loader = None
    c._templar = t
    c._play_context = p

    assert c.evaluate_conditional(t, {}) == True
    c.when = [ 'foo' ]
    assert c.evaluate_conditional(t, {}) == False
    c.when = [ 'foo', 'bar' ]
    assert c.evaluate_conditional(t, {}) == False
    c.when = [ 'foo', 'bar', 'baz' ]
    assert c.evaluate_conditional(t, {})

# Generated at 2022-06-22 16:32:54.598456
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('tests/inventory'))
    templar = Templar(loader=loader, variables=variable_manager)

    # test with a simple string
    conditional = 'foo'
    all_vars = variable_manager.get_vars(loader=loader, play=None)
    assert Conditional().evaluate_conditional(templar, all_vars)

    # test with a simple boolean
    conditional = True
    assert Conditional().evaluate_conditional(templar, all_vars)

    # test with a simple boolean
    conditional = False

# Generated at 2022-06-22 16:33:07.511499
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    pc = PlayContext()
    t = Templar(loader=None, variables={})

    # test with a boolean
    c = Conditional()
    c.when = True
    assert c.evaluate_conditional(t, pc)

    # test with a string
    c = Conditional()
    c.when = "foo"
    assert not c.evaluate_conditional(t, pc)

    # test with a string that evaluates to True
    c = Conditional()
    c.when = "foo == 'foo'"
    assert c.evaluate_conditional(t, pc)

    # test with a string that evaluates to False
    c = Conditional()
    c.when = "foo == 'bar'"
    assert not c.evaluate_cond

# Generated at 2022-06-22 16:33:18.177068
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # create a dummy inventory
    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inv)

    # create a dummy task
    task = Conditional()
    task.when = ['foo is defined']

    # create a dummy play

# Generated at 2022-06-22 16:34:01.502383
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined or bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:34:12.101920
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert c.extract_defined_undefined('foo is defined and bar is defined') == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-22 16:34:23.541537
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('tests/inventory'))
    templar = Templar(loader=loader, variables=variable_manager)

    # test with a simple string
    conditional = 'foo'
    all_vars = variable_manager.get_vars(play=None, host=None, task=None)
    assert Conditional().evaluate_conditional(templar, all_vars)

    # test with a simple string
    conditional = 'foo'
    all_vars = variable_manager.get_vars(play=None, host=None, task=None)
   

# Generated at 2022-06-22 16:34:30.394875
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("a is defined") == [('a', 'is', 'defined')]
    assert conditional.extract_defined_undefined("a is not defined") == [('a', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("a is undefined") == [('a', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("a is not undefined") == [('a', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("a is defined and b is defined") == [('a', 'is', 'defined'), ('b', 'is', 'defined')]

# Generated at 2022-06-22 16:34:42.506868
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class TestConditional(Conditional):
        def __init__(self, loader):
            super(TestConditional, self).__init__(loader)
            self._ds = None

    test_conditional = TestConditional(loader=None)
    test_conditional._ds = None

    # Test with a valid conditional
    test_conditional.when = ['ansible_distribution == "RedHat"']
    templar = Templar(loader=None, variables={'ansible_distribution': 'RedHat'})
    assert test_conditional.evaluate_conditional(templar, templar._available_variables)

    # Test with an invalid conditional

# Generated at 2022-06-22 16:34:54.889864
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    hostvars = HostVars(loader=loader, variable_manager=variable_manager)
    variable_manager.set_host_variable(host='127.0.0.1', varname='hostvars', value=hostvars)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test 1:
    # Test a simple conditional
    conditional = Conditional()
   

# Generated at 2022-06-22 16:35:03.305366
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a play context
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = None
    play_context.become_user = None
    play_context.remote_addr = '127.0.0.1'
    play_context.port = 22
    play_context.remote_user = 'remote_user'
    play_context.connection = 'ssh'
    play_context.network_os = None
    play_context.timeout = 10
    play_context.shell = None
    play_context.executor_plugin = None
    play_context.become_pass = None

# Generated at 2022-06-22 16:35:14.374996
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    ################################################################################
    # Test 1: simple test of a conditional that should evaluate to True
    ################################################################################
    conditional = 'foo is defined'
    all_vars = dict(foo='bar')
    play_context = PlayContext()
    templar = Templar(loader=None, variables=all_vars)

    conditional_obj = Conditional()
    conditional_obj.when = [conditional]
    assert conditional_obj.evaluate_conditional(templar, all_vars) == True

    ################################################################################
    # Test 2: simple test of a conditional that should evaluate to False
    ################################################################################

# Generated at 2022-06-22 16:35:25.284705
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert c.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert c.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert c.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert c.extract_defined_undefined("foo is defined and bar is undefined") == [("foo", "is", "defined"), ("bar", "is", "undefined")]

# Generated at 2022-06-22 16:35:33.714043
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory(host_list='tests/inventory'))
    templar = Templar(loader=loader, variables=variable_manager)

    # Test with a simple conditional
    conditional = Conditional()
    conditional.when = ['foo']
    assert conditional.evaluate_conditional(templar, dict(foo=True))
    assert not conditional.evaluate_conditional(templar, dict(foo=False))

    # Test with a complex conditional
    conditional = Conditional()
    conditional.when = ['foo and bar']

# Generated at 2022-06-22 16:36:45.965770
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # Test with a boolean value
    conditional = Conditional()
    conditional.when = True
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars(play=None, host=None, task=None))



# Generated at 2022-06-22 16:36:53.059439
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    conditional = Conditional()
    conditional.when = [
        'foo is defined',
        'bar is not defined',
        'baz is defined',
        'qux is not defined',
        'quux is defined',
        'corge is not defined',
        'grault is defined',
        'garply is not defined',
        'waldo is defined',
        'fred is not defined',
        'plugh is defined',
        'xyzzy is not defined',
        'thud is defined',
    ]

    # test with no variables
    assert conditional.evaluate_conditional(templar, {}) is False

    #

# Generated at 2022-06-22 16:37:02.032516
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # test setup
    play_context = PlayContext()
    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager)

    # test data

# Generated at 2022-06-22 16:37:12.139431
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is undefined") == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]

# Generated at 2022-06-22 16:37:21.073271
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    conditional = Conditional()
    conditional.when = ['1 == 1']

    assert conditional.evaluate_conditional(templar, variable_manager.get_vars(play=play_context)) == True

    conditional.when = ['1 == 2']
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars(play=play_context)) == False

    conditional.when = ['1 == 1', '2 == 2']