

# Generated at 2022-06-25 05:03:36.611236
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar

    loader = action_loader
    conditional = Conditional(loader)
    templar = Templar(loader=loader)
    t_vars = dict(a='yes', my_hostname='test1.example.org')
    all_vars = dict(a='yes', my_hostname='test1.example.org')
    t_vars = templar._available_variables = all_vars

    conditional._when = [ 'a == "yes"', 'my_hostname == "test1.example.org"']

    res = conditional.evaluate_conditional(templar, t_vars)
    assert res == True

    conditional._when = [ 'a == "yes"', 'a == "no"']

# Generated at 2022-06-25 05:03:46.033058
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c0 = Conditional()
    c0_result = c0.extract_defined_undefined('''hostvars['xx.xx.xx.xx'].f5_virtual_server_pool_name == '' and hostvars['yy.yy.yy.yy'].f5_virtual_server_pool_name == ''''')
    expected_result = [('hostvars[\'xx.xx.xx.xx\'].f5_virtual_server_pool_name', '==', 'defined'), ('hostvars[\'yy.yy.yy.yy\'].f5_virtual_server_pool_name', '==', 'defined')]
    assert c0_result == expected_result

# Generated at 2022-06-25 05:03:50.168872
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_0.when = [ " ( jerry_var_2 is defined and jerry_var_2 != False and jerry_var_2 != 'False' ) " ]
    cond = conditional_0.when[0]
    results = conditional_0.extract_defined_undefined(cond)
    assert results == [('jerry_var_2', ' is', 'defined')]


# Generated at 2022-06-25 05:03:52.049788
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    templar = MagicMock()
    all_vars = {}
    assert conditional_1.evaluate_conditional(templar, all_vars) is True


# Generated at 2022-06-25 05:03:59.423699
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Variable 'ds' is an instance of class Ansible.playbook.block.Block
    # Variable 'result' is an instance of class bool
    # Variable 'res' is an instance of class bool
    # Variable 'conditional' is an instance of class str
    # Variable 'templar' is an instance of class Ansible.template.AnsibleTemplar
    # Variable 'all_vars' is an instance of class dict
    ds = Ansible.playbook.block.Block()
    result = True
    res = True
    conditional = str()
    templar = Ansible.template.AnsibleTemplar()
    all_vars = dict()
    result = True
    ansible = Conditional(ds)
    result = ansible.evaluate_conditional(templar, all_vars)
    assert result

# Generated at 2022-06-25 05:04:04.063735
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    templar = Templar(loader=None, variables=dict())
    all_vars = dict()
    conditional_ = Conditional()
    conditional = True
    conditional_._check_conditional = lambda x, y, z: conditional
    ret = conditional_.evaluate_conditional(templar, all_vars)
    assert ret == conditional


# Generated at 2022-06-25 05:04:10.738716
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()

    # Test when conditional is valid
    conditional = 'foo is defined or bar not is defined'
    result = conditional_0.extract_defined_undefined(conditional)
    assert result == [('foo', 'is', 'defined'), ('bar', 'not is', 'defined')]


# Generated at 2022-06-25 05:04:13.069262
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    assert conditional_1.extract_defined_undefined("a is defined and b is defined") == [('a', 'is', 'defined'), ('b', 'is', 'defined')]



# Generated at 2022-06-25 05:04:14.010149
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    assert False # TODO: implement your test here


# Generated at 2022-06-25 05:04:21.153456
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_1 = Conditional()
    conditional_2 = Conditional()
    conditional_3 = Conditional()
    conditional_4 = Conditional()
    conditional_5 = Conditional()
    conditional_6 = Conditional()
    conditional_7 = Conditional()
    conditional_8 = Conditional()
    conditional_9 = Conditional()
    conditional_10 = Conditional()
    conditional_11 = Conditional()
    conditional_12 = Conditional()
    conditional_13 = Conditional()
    conditional_14 = Conditional()
    conditional_15 = Conditional()
    conditional_16 = Conditional()
    conditional_17 = Conditional()
    conditional_18 = Conditional()
    conditional_19 = Conditional()
    conditional_20 = Conditional()
    conditional_21 = Conditional()
   

# Generated at 2022-06-25 05:04:32.133175
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = object()
    all_vars_0 = object()
    result = conditional_0.evaluate_conditional(templar_0, all_vars_0)
    a = True
    assert a == result

# Generated at 2022-06-25 05:04:34.082936
# Unit test for constructor of class Conditional
def test_Conditional():
    test_case_0()

if __name__ == '__main__':
    test_Conditional()

# Generated at 2022-06-25 05:04:41.199538
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Add a test for current error
    conditional_0 = Conditional()
    display_0 = Display()
    display_0.warning = MagicMock()
    conditional_0.evaluate_conditional(['foobar'], {})
    assert display_0.warning.call_count == 1
    conditional_0.evaluate_conditional(['foobar'], {'barfoo': None})
    assert display_0.warning.call_count == 2
    assert conditional_0.evaluate_conditional(['foobar'], {'barfoo': 'quux'}) is False
    assert conditional_0.evaluate_conditional(['foobar'], {'barfoo': 'foo'}) is False
    assert conditional_0.evaluate_conditional(['quux'], {}) is False
    conditional_0 = Conditional()
    assert conditional_0

# Generated at 2022-06-25 05:04:42.389338
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    # TODO: write unit test if evaluate_conditional is extended


# Generated at 2022-06-25 05:04:46.712433
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional_1 = Conditional()
    templar_1 = None
    all_vars_1 = None
    assert conditional_1.evaluate_conditional(templar_1, all_vars_1)

    conditional_2 = Conditional()
    conditional_2.when = ["test1", "test2", "test3"]
    templar_2 = None
    all_vars_2 = None
    assert conditional_2.evaluate_conditional(templar_2, all_vars_2)



# Generated at 2022-06-25 05:04:48.873419
# Unit test for constructor of class Conditional
def test_Conditional():
    test_case_0()

if __name__ == "__main__":
    test_Conditional()

# Generated at 2022-06-25 05:04:56.807568
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    test_value = conditional_1.extract_defined_undefined('something_else')
    assert test_value == []
    test_value = conditional_1.extract_defined_undefined('hello is defined or test_value is undefined')
    assert test_value == [('hello', 'is', 'defined'), ('test_value', 'is', 'undefined')]
    test_value = conditional_1.extract_defined_undefined('something_else and test_value is undefined or something_else')
    assert test_value == [('test_value', 'is', 'undefined')]
    test_value = conditional_1.extract_defined_undefined('something_else and test_value is undefined or something_else and test_value is not defined or something_else or test_value is undefined')


# Generated at 2022-06-25 05:05:01.835801
# Unit test for constructor of class Conditional
def test_Conditional():
    # Test normal case when the current environment is not C
    assert C.DEFAULT_KEEP_REMOTE_FILES is False, "C.DEFAULT_KEEP_REMOTE_FILES should be False."
    test_case_0()

# Generated at 2022-06-25 05:05:05.924495
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # creating an object of class Conditional with attributes for conditional
    conditional_obj = Conditional()
    conditional_obj._when = ['ansible_foo.bar != "hello world"']
    conditional_obj.evaluate_conditional(conditional_obj,conditional_obj._when)
# Test case for method evaluate_conditional of class Conditional

# Generated at 2022-06-25 05:05:10.315834
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Given
    conditional = Conditional()
    conditional.when = ['test1', 'test2']
    templar = None
    all_vars = {}

    # When
    result = conditional.evaluate_conditional(templar, all_vars)

    # Then
    assert result == True



# Generated at 2022-06-25 05:05:29.074613
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    C.ANSIBLE_FORCE_COLOR = False
    display.verbosity = True
    conditional = Conditional()
    all_vars = dict(a=dict(a=1))
    templar = object()
    conditional.evaluate_conditional(templar, all_vars)

    templar = object()
    C.ANSIBLE_FORCE_COLOR = True
    conditional.evaluate_conditional(templar, all_vars)



# Generated at 2022-06-25 05:05:37.568153
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

    assert ([('A', 'is', 'defined'), ('B', 'is not', 'defined'), ('C', 'is', 'defined')] ==
            cond.extract_defined_undefined(u"A is defined and B is not defined or C is defined"))

    assert ([('A', 'is not', 'defined')] ==
            cond.extract_defined_undefined(u'A is not defined'))

    assert ([('A', 'is', 'defined')] ==
            cond.extract_defined_undefined(u'should_die is defined'))

    assert ([('A', 'is not', 'defined')] ==
            cond.extract_defined_undefined(u"should_live is not defined"))


# Generated at 2022-06-25 05:05:46.059586
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    # Test 1
    conditional_1.when = "hostvars['foo'] is not defined"
    results_1 = conditional_1.extract_defined_undefined(conditional_1.when)
    assert results_1[0][0] == "hostvars['foo']"
    assert results_1[0][1] == 'is not'
    assert results_1[0][2] == 'defined'
    
    # Test 2
    conditional_2 = Conditional()
    conditional_2.when =  "hostvars['foo'] is defined and hostvars['foo'] is not undefined"
    results_2 = conditional_2.extract_defined_undefined(conditional_2.when)
    assert results_2[0][0] == "hostvars['foo']"


# Generated at 2022-06-25 05:05:56.122901
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    TODO: Update this unit test to use the method "evaluate_conditional"
    and the mixin class "Conditional" in this file.  For now, this only
    tests the "extract_defined_undefined" method of the mixin class.
    '''
    conditional_1 = Conditional()
    conditional_1.when = ['hostvars[inventory_hostname] is defined', 'hostvars[inventory_hostname] is not defined']

    # Check results
    (result_1, result_2) = conditional_1.extract_defined_undefined(conditional_1.when[0])
    assert result_1[0] == 'hostvars[inventory_hostname]'
    assert result_1[1] == 'is'
    assert result_1[2] == 'defined'
    assert result

# Generated at 2022-06-25 05:05:59.941017
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    cond = 'hostvars[foo] is not defined or "var" in hostvars[ansible_hostname]'
    def_undef = [('hostvars[foo]', 'not', 'defined'), ('hostvars[ansible_hostname]', 'not in', 'undefined')]
    assert(def_undef == c.extract_defined_undefined(cond))

# Generated at 2022-06-25 05:06:05.479224
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Create a mock object for templar
    with mock.patch('ansible.playbook.conditional.Templar', autospec=True) as mock_Templar:
        conditional_templar = mock_Templar.return_value
        conditional_templar.template.return_value = True
        # Create a mock object for Base
        with mock.patch('ansible.playbook.conditional.Base', autospec=True) as mock_Base:
            conditional_Base = mock_Base.return_value
            conditional_Base.when = ["1==1"]
            # Set the return value of evaluate_conditional()
            evaluate_conditional_return = True
            # Call method evaluate_conditional() of class Conditional

# Generated at 2022-06-25 05:06:13.571327
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_0.when = ["a == 1 and b == 2 and c == 3"]
    def_undef_0 = conditional_0.extract_defined_undefined(conditional_0.when[0])
    assert def_undef_0 == [('a', '==', 'defined'), ('b', '==', 'defined'), ('c', '==', 'defined')]
    conditional_0.when = ["a == 1 and b is undefined and c is not defined"]
    def_undef_0 = conditional_0.extract_defined_undefined(conditional_0.when[0])
    assert def_undef_0 == [('b', 'is', 'undefined'), ('c', 'is not', 'defined')]


# Generated at 2022-06-25 05:06:18.309343
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()

    # Test case 0
    conditional_0 = Conditional()
    assert conditional_0.extract_defined_undefined('a is defined') == [('a', 'is', 'defined')]


# Generated at 2022-06-25 05:06:28.361918
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # crete two class objects
    conditional_0 = Conditional()
    conditional_1 = Conditional()

    # conditional_0 will have one boolean type when_statement object
    # conditional_1 has a list of string type when_statement objects

    boolean_when_statement = True
    conditional_0.when = boolean_when_statement

    string_when_statement_0 = "var_0"
    string_when_statement_1 = "2 > 1"
    string_when_statement_2 = "var_0 == var_1"
    string_when_statement_3 = "var_0 >= var_1"
    string_when_statement_4 = "var_0 <= var_1"
    string_when_statement_5 = "var_0 is defined"
    string_when_statement_6 = "var_0 is undefined"

# Generated at 2022-06-25 05:06:29.727665
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional._when == []
    assert conditional._loader is None



# Generated at 2022-06-25 05:07:09.377527
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Host
    from ansible.inventory.group import Group

    # Note: We use a bare-bones class implementation here that has a constructor that sets
    # the attributes we use here so that we can create class instances in this test function
    # We do this because this template script is not executed as part of ansible's normal
    # execution, so we need to set up the environment manually here.
    # If an existing class is used, it's constructor will not be invoked.

    # Create the class instance
    conditional = Conditional()
    # Set the when attribute to a value that will make the conditional check come out as False
    conditional.when = [ "never" ]

    # Create the VariablesManager
    variable_manager = VariableManager()
    host = Host

# Generated at 2022-06-25 05:07:10.294390
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    test_case_0()
    assert True


# Generated at 2022-06-25 05:07:17.101277
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()

    # Test with a valid condition
    conditional_0._ds = {}
    conditional_0.when = ["foo is defined or bar not is undefined", "foobar is defined"]
    result_0 = conditional_0.extract_defined_undefined(conditional_0.when[0])
    assert len(result_0) == 2
    assert result_0[0] == ('foo', 'is', 'defined')
    assert result_0[1] == ('bar', 'not is', 'undefined')

    # Test with an invalid condition
    conditional_0.when.append("foobar is defined or not baz is undefined")
    result_1 = conditional_0.extract_defined_undefined(conditional_0.when[2])
    assert len(result_1) == 2
    assert result_

# Generated at 2022-06-25 05:07:27.965211
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("moo is defined") == [("moo", "is", "defined")]
    assert c.extract_defined_undefined("moo is not defined") == [("moo", "is not", "defined")]
    assert c.extract_defined_undefined("moo is undefined") == [("moo", "is", "undefined")]
    assert c.extract_defined_undefined("moo is not undefined") == [("moo", "is not", "undefined")]
    assert (c.extract_defined_undefined("moo is defined and meow is undefined")
            == [("moo", "is", "defined"), ("meow", "is", "undefined")])

# Generated at 2022-06-25 05:07:33.347597
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional = Conditional()
    all_vars = dict(a=True, b=False)

    assert conditional.evaluate_conditional(conditional, all_vars) == True
    assert conditional.evaluate_conditional(conditional, all_vars, dict()) == True

    conditional.when = "a"
    assert conditional.evaluate_conditional(conditional, all_vars) == True

    conditional.when.extend(['b == False', 'a == True'])
    assert conditional.evaluate_conditional(conditional, all_vars) == True

    conditional.when = "b"
    assert conditional.evaluate_conditional(conditional, all_vars) == False

    conditional.when = "c"
    assert conditional.evaluate_conditional(conditional, all_vars) == False

    conditional.when = dict

# Generated at 2022-06-25 05:07:44.161166
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    result = Conditional.extract_defined_undefined('a is defined and b is not defined and c is defined')
    assert result == [('a', 'is', 'defined'), ('b', 'is not', 'defined'), ('c', 'is', 'defined')]

    result = Conditional.extract_defined_undefined('a is defined or b is defined and c is defined')
    assert result == [('a', 'is', 'defined'), ('b', 'is', 'defined'), ('c', 'is', 'defined')]

    result = Conditional.extract_defined_undefined('a is undefined or b is not defined and c is defined')
    assert result == [('a', 'is', 'undefined'), ('b', 'is not', 'defined'), ('c', 'is', 'defined')]

    result = Conditional.extract_defined_

# Generated at 2022-06-25 05:07:49.022566
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_0.when = """hostvars['foo'] is defined"""
    extract_defined_undefined_0 = conditional_0.extract_defined_undefined(conditional_0.when)
    assert extract_defined_undefined_0 == [('hostvars[\'foo\']', 'is', 'defined')]

    conditional_1 = Conditional()
    conditional_1.when = """'foo' is defined"""
    extract_defined_undefined_1 = conditional_1.extract_defined_undefined(conditional_1.when)
    assert extract_defined_undefined_1 == [('\'foo\'', 'is', 'defined')]


# Generated at 2022-06-25 05:07:57.329268
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    expected_0 = [('defined', 'is', 'defined')]
    actual_0 = conditional_0.extract_defined_undefined('defined is defined')
    assert actual_0 == expected_0
    expected_1 = [('defined', 'is', 'defined'), ('defined', 'is', 'defined')]
    conditional_1 = Conditional()
    actual_1 = conditional_1.extract_defined_undefined('defined is defined and defined is defined')
    assert actual_1 == expected_1
    conditional_2 = Conditional()
    expected_2 = [('hostvars[inventory_hostname]', 'is', 'defined'), ('hostvars[inventory_hostname].ansible_eth0.speed', 'isnt', 'undefined')]
    actual_2 = conditional_2.ext

# Generated at 2022-06-25 05:08:03.956142
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Unit test for method evaluate_conditional of class Conditional
    '''

    class ConditionalTest(object):
        def __init__(self):
            self.when = [False]
            self._ds = {}
            self._loader = DictDataLoader({})

    class DictDataLoader(object):
        def __init__(self, data):
            self.data = data

        def get_basedir(self, play):
            return "."

        def path_dwim(self, x):
            return "%s/%s" % (self.get_basedir(None), x)

        def get_file_contents(self, path):
            return self.data[path]

    conditional_0 = ConditionalTest()
    conditional_1 = ConditionalTest()

# Generated at 2022-06-25 05:08:07.203324
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    display.v("test_Conditional_evaluate_conditional")
    cond = Conditional()
    templar = DummyTemplar("", False, False)
    res = cond.evaluate_conditional(templar, dict())

    assert res == True


# Generated at 2022-06-25 05:09:14.137414
# Unit test for constructor of class Conditional
def test_Conditional():
    try:
        test_case_0()
    except Exception as e:
        print('FAILURE: Conditional.__init__() raised exception unexpectedly!')


# Generated at 2022-06-25 05:09:20.429090
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    ds = dict(test_case='test_evaluate_conditional')
    conditional_0 = Conditional(ds)
    # Declare needed
    conditional_0._ds = None
    conditional_0.when = ['test_true']
    all_vars = dict()
    templar = None
    assert conditional_0.evaluate_conditional(templar, all_vars) == True


# Generated at 2022-06-25 05:09:28.849000
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    def check_conditional(conditional, expected_results):
        conditional_obj = Conditional()
        result = conditional_obj.extract_defined_undefined(conditional)
        assert result == expected_results, "extract_defined_undefined() returned %s but %s was expected" % (result, expected_results)

    conditional_expressions = [
        # Conditional with no defined
        "defined_var",
        # Conditional with defined and undefined
        "defined_var and not undefined_var or other_var",
        # Conditional with multiple defined, undefined and not is defined
        "defined_var or not defined_var2 and not is defined undefined_var",
    ]

# Generated at 2022-06-25 05:09:32.288952
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    (#8376) Fix some logic that breaks when the conditional statement is a boolean
    '''
    conditional_1 = Conditional()
    conditional_1.when = [True]
    assert conditional_1.evaluate_conditional(None, {}) is True
    conditional_1.when = False
    assert conditional_1.evaluate_conditional(None, {}) is False


# Generated at 2022-06-25 05:09:41.003082
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test if conditional is None
    test_obj = Conditional()
    test_obj.when = None
    assert test_obj.evaluate_conditional(None, None) == False
    # Test case when conditional is an empty list
    test_obj.when = []
    assert test_obj.evaluate_conditional(None, None) == False
    # Test case when conditional is valid and evaluates to True
    test_obj.when = [True]
    assert test_obj.evaluate_conditional(None, None) == True
    # Test case when conditional is valid and evaluates to False
    test_obj.when = [False]
    assert test_obj.evaluate_conditional(None, None) == False



# Generated at 2022-06-25 05:09:49.968443
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    cases = dict()
    cases['case_0'] = dict(
        all_vars=dict(),
        conditional='1 == 1',
        expected_result=True,
    )
    cases['case_1'] = dict(
        all_vars=dict(
            localhost='localhost',
        ),
        conditional='inventory_hostname == localhost',
        expected_result=True,
    )
    cases['case_2'] = dict(
        all_vars=dict(
            localhost='localhost',
        ),
        conditional='inventory_hostname == localhost2',
        expected_result=False,
    )

# Generated at 2022-06-25 05:09:56.231681
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # if no defined/undefined check is found, the empty list is returned
    defined_undefined_list = Conditional().extract_defined_undefined("host == 'foo.bar'")
    assert len(defined_undefined_list) == 0

    # if a single defined/undefined check is found, the method returns a list with a single element
    defined_undefined_list = Conditional().extract_defined_undefined("hostvars['foo.bar'] is defined")
    assert len(defined_undefined_list) == 1
    assert defined_undefined_list[0] == ("hostvars['foo.bar']", "is", "defined")

    # if multiple defined/undefined checks are found, the method returns a list with all items

# Generated at 2022-06-25 05:09:59.107186
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_0 = Conditional()
    assert (conditional_0._when == list())


# Generated at 2022-06-25 05:10:06.883202
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()

    all_vars_1 = {}
    all_vars_1['aa'] = None
    all_vars_1['bb'] = None
    all_vars_1['cc'] = None
    all_vars_1['dd'] = None
    all_vars_1['ee'] = None
    all_vars_1['ff'] = None
    all_vars_1['gg'] = None
    all_vars_1['hh'] = None
    all_vars_1['ii'] = None
    all_vars_1['jj'] = None
    all_vars_1['kk'] = None
    all_vars_1['ll'] = None
    conditional_1.when.append('jj is defined and kk is defined')

# Generated at 2022-06-25 05:10:12.989419
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    # valid type(conditional)
    # TODO: add type check
    templar = ""
    all_vars = ""
    conditional.evaluate_conditional(templar, all_vars)


# Generated at 2022-06-25 05:13:07.347959
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # test default case with empty conditional
    cond_1 = Conditional()
    assert cond_1.evaluate_conditional([], {})

    # test default case with empty conditional
    cond_3 = Conditional()
    cond_3.when = [None]
    assert cond_3.evaluate_conditional([], {})

    # test default case with empty conditional
    cond_4 = Conditional()
    cond_4.when = [""]
    assert cond_4.evaluate_conditional([], {})

    # test default case of single conditional
    cond_2 = Conditional()
    cond_2.when = ["foo"]
    assert cond_2.evaluate_conditional([], {"foo": True})



# Generated at 2022-06-25 05:13:18.089548
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    """
    Testing Conditional class extract_defined_undefined method
    """
    conditional_0 = Conditional()
    definition = conditional_0.extract_defined_undefined('hostvars[inventory_hostname] is defined')
    assert definition == [('hostvars[inventory_hostname]', 'is', 'defined')]

    definition = conditional_0.extract_defined_undefined('the_var is_not undefined')
    assert definition == [('the_var', 'is_not', 'undefined')]

    definition = conditional_0.extract_defined_undefined('the_var is_not undefined and other_var is defined')
    assert definition == [('the_var', 'is_not', 'undefined'), ('other_var', 'is', 'defined')]

    definition = conditional_0.extract_defined_