

# Generated at 2022-06-25 05:03:33.814955
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional0 = Conditional()
    result = conditional0.extract_defined_undefined("foo is not defined")
    assert isinstance(result, list)
    assert len(result) == 1
    assert isinstance(result[0], tuple)
    assert len(result[0]) == 3
    assert result[0][0] == "foo"
    assert result[0][1] == "is not"
    assert result[0][2] == "defined"


# Generated at 2022-06-25 05:03:44.350040
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = template.AnsibleTemplate(template=None, variables=dict())
    all_vars_0 = dict()
    conditional_1 = 'True'
    conditional_2 = 'False'
    conditional_3 = 'True'
    conditional_4 = 'False'
    conditional_5 = 'True'
    conditional_6 = 'False'
    conditional_7 = 'True'
    conditional_8 = 'False'
    conditional_9 = 'True'
    conditional_10 = 'False'
    conditional_11 = 'True'
    conditional_12 = 'False'
    conditional_13 = 'True'
    conditional_14 = 'False'
    conditional_15 = 'True'
    conditional_16 = 'False'
    conditional_17 = 'True'
    conditional_

# Generated at 2022-06-25 05:03:49.689542
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    res = conditional_1.extract_defined_undefined("a.b is defined or c.d is not defined")
    assert res == [('a.b', 'is', 'defined'), ('c.d', 'is not', 'defined')]

    conditional_2 = Conditional()
    res = conditional_2.extract_defined_undefined("a.b is not defined")
    assert res == [('a.b', 'is not', 'defined')]

    conditional_3 = Conditional()
    res = conditional_3.extract_defined_undefined("foo is defined")
    assert res == [('foo', 'is', 'defined')]

    conditional_4 = Conditional()
    res = conditional_4.extract_defined_undefined("foo is undefined")

# Generated at 2022-06-25 05:03:52.330736
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """
    Test evaluate_conditional method of the Conditional class.
    """
    conditional = Conditional()
    try:
        result = conditional.evaluate_conditional(conditional, None)
    except Exception as err:
        if str(err) != "The conditional check '' failed. The error was: error while evaluating conditional (): error while evaluating conditional (): int object has no attribute 'lower'":
            # Unexpected exception
            raise
        else:
            pass


# Generated at 2022-06-25 05:03:59.640764
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional = Conditional()

    # A variable with all values, which is looking for the variable 'me' to be True
    setattr(conditional, '_ds', {'line': 1, 'path': 'tests/units/parsing/yaml/conditional_0.yml'})
    setattr(conditional, 'when', ['{{ me is defined and me }}'])
    all_vars = {'me': 'me', 'also_me': 'also_me'}
    assert conditional.evaluate_conditional({}, all_vars)

    # A variable which does not exist, but we're looking to see if it does.
    # Should return False.

# Generated at 2022-06-25 05:04:01.677360
# Unit test for constructor of class Conditional
def test_Conditional():
    print("Testing Conditional() constructor")
    test_case_0()
    print("Constructor test successful in Conditional")


# Generated at 2022-06-25 05:04:07.646849
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    conditional_1_expression_1="(http_code != 200 and google != 'down')"
    conditional_1_output_1=[('http_code', '!=', '200'), ('google', '!=', 'down')]
    conditional_1_expression_2="(http_code != 200 and google != 'down') or my_var is defined"
    conditional_1_output_2=[('http_code', '!=', '200'), ('google', '!=', 'down'), ('my_var', 'is', 'defined')]
    conditional_1_expression_3="(http_code != 200 and google != 'down') or my_var is defined and my_var2 is undefined"

# Generated at 2022-06-25 05:04:14.178076
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    class test_0:
        def __init__(self, test_var):
            self.test_var = test_var

    templar = None
    all_vars = [test_0("test_var_0")]
    conditional = "valid"
    result_0 = conditional_1.evaluate_conditional(templar, all_vars)
    assert result_0 == True


# Generated at 2022-06-25 05:04:21.581341
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    cond1 = "var1 is defined"
    cond2 = "var2 is defined"
    cond3 = "var1 is undefined"
    cond4 = "var2 is undefined"
    cond5 = "var1 == var2"
    cond6 = "var1 != var2"
    
    # Set up conditional object
    conditional_1 = Conditional()
    conditional_1.when = [cond1, cond2]
    
    # Set up variables
    all_vars = {}
    the_vars = {}
    hostvars = {}
    the_vars['var1'] = "Var 1 is set"
    all_vars['var2'] = "Var 2 is set"
    hostvars['var3'] = "Var 3 is set"
    the_vars['hostvars'] = hostvars
    


# Generated at 2022-06-25 05:04:31.798934
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    display.verbosity = 4
    conditional_1 = Conditional()

    conditional_list = ['defined', 'something is defined', 'something is not defined', 'something not is defined',
                        'something not is not defined', 'something_new is defined', 'something_new_two is not defined',
                        'something_new_three not is defined']

    for conditional in conditional_list:
        results = conditional_1.extract_defined_undefined(conditional)
        for result in results:
            display.display('%s %s %s' % (result[0], result[1], result[2]))

    assert(conditional_1.extract_defined_undefined('something is defined'))



# Generated at 2022-06-25 05:04:55.103391
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # test with a None when value
    conditional_1 = Conditional()
    conditional_1._when.append(None)
    templar_1 = AnsibleTemplar()
    all_vars_1 = {'a':'1'}
    res_1 = conditional_1.evaluate_conditional(templar_1, all_vars_1)
    assert res_1 == True

    # test with a False when value
    conditional_2 = Conditional()
    conditional_2._when.append(False)
    templar_2 = AnsibleTemplar()
    all_vars_2 = {'a':'1'}
    res_2 = conditional_2.evaluate_conditional(templar_2, all_vars_2)
    assert res_2 == False

    # test with a

# Generated at 2022-06-25 05:05:06.694229
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    conditional._ds = {}
    class MyTemplar:
      def is_template(self, x):
         return False
      def template(self, x):
          return x
      template_vars = {}
    templar = MyTemplar()
    all_vars = {
      'foo': 'bar',
      'koo': 'meh',
      'zoo': 'baz',
      'blah': 'foo:bar'
    }
    assert conditional.evaluate_conditional(templar, all_vars) == True
    assert conditional.evaluate_conditional(templar, all_vars) == True
    conditional.when.append('blah in zoo')
    assert conditional.evaluate_conditional(templar, all_vars) == False
    conditional.when

# Generated at 2022-06-25 05:05:14.390041
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.plugins.loader import get_all_plugin_loaders

    # create the loader and inventory
    loader = DictDataLoader({})
    inventory = Inventory(loader, host_list=['dummy'])
    inventory.get_hosts('all')
    inventory.get_groups('all')
    play_context = PlayContext()

    # create a play and task to test with

# Generated at 2022-06-25 05:05:20.071268
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    # Use assignment to avoid variable 'templar' is assigned to before
    # global declaration error.
    C.DEFAULT_HASH_BEHAVIOUR = "replace"
    templar = ""
    all_vars = dict()
    assert(conditional_0.evaluate_conditional(templar, all_vars))


# Generated at 2022-06-25 05:05:30.896848
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    result_1 = conditional_1.extract_defined_undefined("defined test_var_1 and undefined test_var_2")
    assert result_1 == [('test_var_1', 'defined', 'is'), ('test_var_2', 'undefined', 'is')]
    result_2 = conditional_1.extract_defined_undefined("defined test_var_3 and not undefined test_var_4")
    assert result_2 == [('test_var_3', 'defined', 'is'), ('test_var_4', 'undefined', 'not')]
    result_3 = conditional_1.extract_defined_undefined("not defined test_var_5 and not undefined test_var_6")

# Generated at 2022-06-25 05:05:38.461348
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    Various tests for method extract_defined_undefined
    '''

    conditional = Conditional()

    # if we are testing multiple variables, they should be returned
    # in a list of tuples
    result = conditional.extract_defined_undefined("hostvars['foo'] is defined and hostvars['bar'] is defined")
    assert result == [('hostvars[foo]', 'is', 'defined'), ('hostvars[bar]', 'is', 'defined')]

    # if we are testing with the same variable twice, it should still return
    # the variable name in a list of tuples
    result = conditional.extract_defined_undefined("hostvars['foo'] is defined and hostvars['foo'] is defined")

# Generated at 2022-06-25 05:05:43.150704
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    # Test 0: Test with unknown variables
    try:
        print ("Test 0: Test with unknown variables")
        all_vars = dict()
        conditional_0.evaluate_conditional("v1 == v2", all_vars)
    except AnsibleUndefinedVariable as e:
        print(e)


# Generated at 2022-06-25 05:05:46.752822
# Unit test for constructor of class Conditional
def test_Conditional():
    print("Testing Constructor")
    conditional_0 = Conditional()
    conditional_0.when = ['yes']
    assert(len(conditional_0.when) == 1)
    assert(conditional_0.when == ['yes'])


# Generated at 2022-06-25 05:05:53.465548
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    str = 'hostvars[inventory_hostname] is defined and hostvars[inventory_hostname] is not undefined'
    expected_0 = conditional_0.extract_defined_undefined(str)
    assert expected_0 == [('hostvars[inventory_hostname]', 'is', 'defined'), ('hostvars[inventory_hostname]', 'is not', 'undefined')]


# Generated at 2022-06-25 05:05:55.772450
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar = ''
    all_vars = ''
    result = conditional_0.evaluate_conditional(templar, all_vars)


# Generated at 2022-06-25 05:06:29.597977
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_0.when = ['hostvars[inventory_hostname] is defined', 'hostvars[inventory_hostname] is undefined']
    assert conditional_0.extract_defined_undefined(conditional_0.when[0]) == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert conditional_0.extract_defined_undefined(conditional_0.when[1]) == [('hostvars[inventory_hostname]', 'is', 'undefined')]

    conditional_1 = Conditional()
    conditional_1.when = ['hostvars[inventory_hostname] is not defined', 'hostvars[inventory_hostname] is undefined']
    assert conditional_1.extract_defined_undefined(conditional_1.when[0])

# Generated at 2022-06-25 05:06:39.110259
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestConditional(Conditional):
        def __init__(self, name, loader, when=None):
            self._name = name
            self._when = when
            self._loader = loader
    conditional_0 = TestConditional('conditional_0', None, ['1 == 1'])
    templar_0 = mock_templar()
    all_vars_0 = {'hostvars': {'1': 1}}
    assert conditional_0.evaluate_conditional(templar_0, all_vars_0) == True
    conditional_1 = TestConditional('conditional_1', None, ['1 == 1', 'test.test_key == "test_value"'])
    templar_1 = mock_templar()

# Generated at 2022-06-25 05:06:40.891093
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    result = conditional_0.evaluate_conditional(conditional_0)
    assert result == None


# Generated at 2022-06-25 05:06:46.800660
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()

    # assertion test for extract_defined_undefined
    try:
        assert conditional_0.extract_defined_undefined("hostvars[inventory_hostname] is not defined") == [("hostvars[inventory_hostname]", "is not", "defined")]
    except AssertionError:
        raise AssertionError("Fail extract_defined_undefined: expected [('hostvars[inventory_hostname]', 'is not', 'defined')], got {}".format(str(conditional_0.extract_defined_undefined("hostvars[inventory_hostname] is not defined"))))


# Generated at 2022-06-25 05:06:54.770671
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    conditional_2 = Conditional()
    conditional_3 = Conditional()
    conditional_4 = Conditional()
    conditional_5 = Conditional()
    conditional_6 = Conditional()
    conditional_7 = Conditional()
    conditional_8 = Conditional()
    conditional_9 = Conditional()
    conditional_10 = Conditional()
    conditional_11 = Conditional()
    conditional_12 = Conditional()
    conditional_13 = Conditional()
    conditional_14 = Conditional()

    assert conditional_1.extract_defined_undefined('hostvars["foo"] is undefined') == [('hostvars["foo"]', 'is', 'undefined')]

# Generated at 2022-06-25 05:07:04.216475
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # test Conditional.evaluate_conditional() with no when defined.
    c = Conditional()
    assert c.evaluate_conditional({}, {})

    # test bad conditional type
    c = Conditional()
    c._when = 1
    assert not c.evaluate_conditional({}, {})

    # test empty conditional
    c = Conditional()
    c._when = ['']
    assert c.evaluate_conditional({}, {})

    # test boolean field (true)
    c = Conditional()
    c._when = [True]
    assert c.evaluate_conditional({}, {})

    # test boolean field (false)
    c = Conditional()
    c._when = [False]
    assert not c.evaluate_conditional({}, {})

    # test conditional with single non-template (true)
    c

# Generated at 2022-06-25 05:07:13.029293
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Test case 1
    conditional_1 = Conditional()
    conditional_1.when = [
        'foo is not defined',
        'bar is defined',
        'foo is not defined and bar is defined',
        'foo is not defined or bar is defined',
        'foo is not defined or bar is defined or baz is not defined',
        'foo is not defined and bar is defined and baz is not defined',
        'foo is defined and bar is not defined or baz is defined',
        'foo is not defined and (bar is defined or baz is not defined)',
        'foo is not defined and bar is defined or baz is not defined',
        '(foo is not defined and bar is defined) or baz is not defined',
        'foo is not defined and (bar is defined or baz is not defined)',
    ]
    expected_

# Generated at 2022-06-25 05:07:22.425424
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()

    conditional_1 = "test_condition"
    all_vars_1 = { "some_var": "some_value" }
    result_1 = conditional_0.evaluate_conditional(conditional_1, all_vars_1)
    assert result_1 == True

    conditional_2 = "some_var==some_value"
    all_vars_2 = { "some_var": "some_value" }
    result_2 = conditional_0.evaluate_conditional(conditional_2, all_vars_2)
    assert result_2 == True

    conditional_3 = "some_var==some_other_value"
    all_vars_3 = { "some_var": "some_value" }

# Generated at 2022-06-25 05:07:30.229851
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    conditional_1 = Conditional()
    conditional_1.when = [
        'undefined_var is undefined',
        'undefined_var is defined',
        '"foo" is defined',
        'defined_var is defined',
        'defined_var is not defined',
    ]
    results = conditional_1.extract_defined_undefined
    assert results == [
        ('undefined_var', 'is', 'undefined'),
        ('undefined_var', 'is', 'defined'),
        ('foo', 'is', 'defined'),
        ('defined_var', 'is', 'defined'),
        ('defined_var', 'is not', 'defined')
    ]

# Generated at 2022-06-25 05:07:37.851682
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # expect no match
    assert Conditional.extract_defined_undefined(None, 'conditional') == []
    assert Conditional.extract_defined_undefined(None, 'conditional not defined') == []

    # expect match
    assert Conditional.extract_defined_undefined(None, 'conditional is defined') == [(u'conditional', u'is', u'defined')]
    assert Conditional.extract_defined_undefined(None, 'conditional is not defined') == [(u'conditional', u'is not', u'defined')]
    assert Conditional.extract_defined_undefined(None, 'conditional is undefined') == [(u'conditional', u'is', u'undefined')]

# Generated at 2022-06-25 05:08:50.907050
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar = None
    all_vars = dict()
    assert conditional_0.evaluate_conditional(templar, all_vars)==True


# Generated at 2022-06-25 05:08:57.116968
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional_1 = Conditional()
    assert conditional_1.evaluate_conditional([], {}) == True

    conditional_2 = Conditional()
    conditional_2.when = None
    assert conditional_2.evaluate_conditional([], {}) == True

    conditional_3 = Conditional()
    conditional_3.when = list()
    assert conditional_3.evaluate_conditional([], {}) == True

    conditional_4 = Conditional()
    conditional_4.when = list()
    conditional_4.when.append("1 == 1")
    assert conditional_4.evaluate_conditional([], {}) == True

    conditional_5 = Conditional()
    conditional_5.when = list()
    conditional_5.when.append("1 == 0")
    assert conditional_5.evaluate_conditional([], {}) == False

    conditional

# Generated at 2022-06-25 05:09:02.196340
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    conditional_0.when = ['testvar']
    result = conditional_0.evaluate_conditional(templar, None)
    # TestAssertionError: Failed: Test 1 : conditional_0.evaluate_conditional() == True
    assert result == True, 'conditional_0.evaluate_conditional() == %s' % result


# Generated at 2022-06-25 05:09:05.503251
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_1 = Conditional()
    # conditional_0.extract_defined_undefined()
    # TODO replace assert with a proper test
    assert True


# Generated at 2022-06-25 05:09:14.851435
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """
    Test for method evaluate_conditional of class Conditional
    """
    conditional_0 = Conditional()
    conditional_0.when = [None]
    templar_0 = None
    all_vars_0 = dict()
    assert conditional_0.evaluate_conditional(templar_0, all_vars_0)

    conditional_1 = Conditional()
    conditional_1.when = ["'== False"]
    templar_1 = None
    all_vars_1 = dict()
    assert not conditional_1.evaluate_conditional(templar_1, all_vars_1)

    conditional_2 = Conditional()
    conditional_2.when = ["1 == 1"]
    templar_2 = None
    all_vars_2 = dict()
    assert conditional_2

# Generated at 2022-06-25 05:09:17.884008
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    assert conditional_1.evaluate_conditional(conditional_1, {}) == True


# Generated at 2022-06-25 05:09:23.336618
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Initialize a `Conditional` instance
    conditional_0 = Conditional()

    # Initialize a `list` object
    parameter_1 = []

    # Initialize a `dict` object
    parameter_2 = {}

    # Call method `evaluate_conditional` of `Conditional` class with
    # the specified parameters
    conditional_0.evaluate_conditional(parameter_1, parameter_2)



# Generated at 2022-06-25 05:09:28.498638
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    conditional_1.when = ['hostvars["x"] is defined or hostvars["y"] is not defined']
    results = conditional_1.extract_defined_undefined(conditional_1.when)
    expected = [('hostvars["x"]', 'is', 'defined'), ('hostvars["y"]', 'is not', 'defined')]
    assert results == expected, "Expected: %s, Actual: %s" % (expected, results)


# Generated at 2022-06-25 05:09:32.929535
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional_0 = Conditional()
    conditional_0.when = [None]
    templar_0 = MockTemplar('fake')
    all_vars_0 = {}
    try:
        result_0 = conditional_0.evaluate_conditional(templar_0, all_vars_0)
    except Exception as e:
        print("Unexpected Exception: %s" % e)
        assert False
    else:
        assert result_0 is True



# Generated at 2022-06-25 05:09:41.510432
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    conditional = Conditional()

    # Test 1
    conditionals = [ 'A == 1' ]
    for conditional in conditionals:
        result = conditional.extract_defined_undefined(conditional)
        assert result == []

    # Test 2
    conditionals = [ 'A is defined' ]
    for conditional in conditionals:
        result = conditional.extract_defined_undefined(conditional)
        assert result == [('A','is','defined')]

    # Test 3
    conditionals = [ 'A is not defined' ]
    for conditional in conditionals:
        result = conditional.extract_defined_undefined(conditional)
        assert result == [('A','is not','undefined')]

    # Test 4
    conditionals = [ 'A is undefined' ]
    for conditional in conditionals:
        result = conditional

# Generated at 2022-06-25 05:12:20.693960
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-25 05:12:22.056964
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_0 = Conditional()
    assert conditional_0._when == []

    conditional_1 = Conditional()
    assert conditional_1._when == []


# Generated at 2022-06-25 05:12:30.145378
# Unit test for constructor of class Conditional
def test_Conditional():
    # check default when
    conditional_0 = Conditional()
    assert conditional_0._when == []
    # check when populated
    conditional_1 = Conditional(when=[1])
    assert conditional_1._when == [1]
    # check when populated with a list
    conditional_2 = Conditional(when=[1, 2])
    assert conditional_2._when == [1, 2]
    # check when populated with a list, but set to a scalar value
    conditional_3 = Conditional(when=1)
    assert conditional_3._when == [1]
    # check when populated with a non-list and non-scalar
    conditional_4 = Conditional(when=set(1))
    assert conditional_4._when == []



# Generated at 2022-06-25 05:12:35.166763
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional(loader=None)
    #Checking with False condition
    if conditional_1.evaluate_conditional(templar=None, all_vars=None):
        raise AssertionError("condition is false")
    else:
        print("condition is false ")
    # Checking with True condition
    conditional_1._when = ['test']
    if not conditional_1.evaluate_conditional(templar=None, all_vars=None):
        raise AssertionError("condition is true")
    else:
        print("condition is true")


# Generated at 2022-06-25 05:12:40.635593
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    assert conditional_1.extract_defined_undefined("foo") == []
    assert conditional_1.extract_defined_undefined("foo and bar") == []
    assert conditional_1.extract_defined_undefined("foo is defined") == \
        [(u'foo', u'is', u'defined')]
    assert conditional_1.extract_defined_undefined("foo is not defined") == \
        [(u'foo', u'is not', u'defined')]
    assert conditional_1.extract_defined_undefined("foo bar is defined") == \
        [(u'foo bar', u'is', u'defined')]

# Generated at 2022-06-25 05:12:47.829803
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    conditional_0.when = [
        'C2',
        'c1 and C2',
        'a1',
        'c1 and c2 and a1',
    ]

    # Test for attribute '_ds' of class Conditional
    ds = 'abc'
    conditional_0._ds = ds
    # Test for method '_validate_when' of class Conditional
    ansible_vars = {
        'a1': True,
        'a2': False,
        'c1': True,
        'c2': False,
    }
    conditional_0._validate_when('_when', '_when', None)
    conditional_0._validate_when('_when', '_when', 'abc')

# Generated at 2022-06-25 05:12:58.437129
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    correct: When a conditional expression evaluates to True this method should return True.
    When a conditional expression evaluates to False this method should return False.
    correct: When a conditional expression is non-empty and non-boolean, this method should return True.
    correct: When a conditional expression is empty, this method should return True.
    correct: When a 'when' is None, this method should return True.
    '''
    #####################################################################################
    # Initialize Conditional object for testing with evaluate_conditional method
    #####################################################################################
    conditional_2 = Conditional()
    # set values to attributes of conditional_2 object
    conditional_2.when = [['hostvars', 'not is', 'undefined'], 'or', 'ansible_fqdn']
    #####################################################################################
    # call the evaluate_conditional

# Generated at 2022-06-25 05:13:07.699660
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    assert conditional_0.evaluate_conditional(conditional="bar_hostname == inventory_hostname", templar=templar_0)
    assert conditional_0.evaluate_conditional(conditional="'inventory_hostname' in group_names", templar=templar_0)
    assert conditional_0.evaluate_conditional(conditional='inventory_hostname in group_names', templar=templar_0)
    assert conditional_0.evaluate_conditional(conditional="inventory_hostname in group_names", templar=templar_0)
    assert conditional_0.evaluate_conditional(conditional="inventory_hostname in group_names", templar=templar_0)

# Generated at 2022-06-25 05:13:14.668161
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Prepare data structures for function
    conditional_0 = Conditional()
    templar_0 = None
    all_vars_0 = {}
    # Call function
    conditional_0.evaluate_conditional(templar_0, all_vars_0)
