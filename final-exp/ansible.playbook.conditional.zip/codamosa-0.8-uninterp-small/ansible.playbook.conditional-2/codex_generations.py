

# Generated at 2022-06-25 05:03:39.937063
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    conditional_0 = Conditional()

    vars_sample = dict(x=1,
                y='value1',
                z=[1, 2, 3])

    # With None as the conditional, it should return True
    assert conditional_0.evaluate_conditional(Templar(loader=None), vars_sample) is True

    # With boolean value as conditional, it should return the same
    for input_conditional in [True, False]:
        assert conditional_0.evaluate_conditional(Templar(loader=None),
            vars_sample, input_conditional) is input_conditional

    # With empty string as conditional, it should evaluate to True
    assert conditional_0.evaluate_conditional(Templar(loader=None), vars_sample,
        '') is True

    #

# Generated at 2022-06-25 05:03:48.553331
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Test the simple case
    conditional_0 = Conditional()
    conditional = """
    foo is not defined or
    bar is defined
    """
    result = conditional_0.extract_defined_undefined(conditional)
    assert result == [
            ('foo', 'is', 'undefined'),
            ('bar', 'is', 'defined'),
        ]

    # Combined with other boolean logic operators
    conditional = """
    (foo is not defined and bar is defined) or bar is not undefined
    """
    result = conditional_0.extract_defined_undefined(conditional)
    assert result == [
            ('foo', 'is', 'undefined'),
            ('bar', 'is', 'defined'),
            ('bar', 'is', 'undefined'),
        ]

    # Test for valid string variables

# Generated at 2022-06-25 05:03:54.686356
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_host_variable('host1', 'hostvars_host1')
    variable_manager.set_host_variable('host2', 'hostvars_host2')
    variable_manager.set_host_variable('host3', 'hostvars_host3')

    templar = Templar(loader=None, variables=variable_manager, shared_loader_obj=None)

    inventory_source = """
    [all:children]

    [group1]
    host1

    [group2]
    host2

    [group3]
    host3
    """


# Generated at 2022-06-25 05:04:03.635342
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
        Unit test for method extract_defined_undefined of class Conditional
    '''

    # test case 0: conditional is 'hostvars[inventory_hostname] is defined'
    conditional_0 = Conditional()
    (conditional_0.when).append('hostvars[inventory_hostname] is defined')
    assert conditional_0.extract_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]


# Generated at 2022-06-25 05:04:14.925426
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    display = Display()
    assert display
    conditional = Conditional()
    assert conditional, "Failed to make conditional"

    # Define variable set
    variable_0 = 'foo'
    variable_1 = 'fii'
    variable_2 = variable_1
    variable_3 = variable_0
    variable_4 = variable_2
    variable_5 = variable_3
    variable_6 = variable_5
    variable_7 = variable_6
    variable_8 = variable_7
    variable_9 = variable_8
    variable_10 = variable_9
    variable_11 = variable_10
    variable_12 = variable_11
    variable_13 = variable_12
    variable_14 = variable_13
    variable_15 = variable_14
    variable_16 = variable_15
    variable_17 = variable_16


# Generated at 2022-06-25 05:04:19.029840
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    conditional_1._ds = object()  # set up _ds to avoid error reporting
    templar_1 = object()
    all_vars_1 = dict()
    assert conditional_1.evaluate_conditional(templar_1, all_vars_1)


# Generated at 2022-06-25 05:04:22.646334
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    conditional_1.when = []
    assert conditional_1.evaluate_conditional(None, {}) == True


# Generated at 2022-06-25 05:04:29.993618
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Setup test data
    conditional_39 = Conditional()
    templar_40 = mock_templar()
    all_vars_41 = {}
    all_vars_41['foo'] = 'baz'

    # Invoke method
    res_42 = conditional_39.evaluate_conditional(templar_40, all_vars_41)

    # Test return value
    assert res_42 == True


# Generated at 2022-06-25 05:04:31.857554
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    a = Conditional()
    assert a.evaluate_conditional() == True


# Generated at 2022-06-25 05:04:41.050078
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    s = conditional_1.extract_defined_undefined('a is defined or b is undefined or (c is not defined and d is defined)')
    assert s == [('a', 'is', 'defined'), ('b', 'is', 'undefined'), ('c', 'is not', 'defined'), ('d', 'is', 'defined')]
    s = conditional_1.extract_defined_undefined('a is defined or b is undefined or (c is not defined and d is defined) or test')
    assert s == [('a', 'is', 'defined'), ('b', 'is', 'undefined'), ('c', 'is not', 'defined'), ('d', 'is', 'defined')]
    s = conditional_1.extract_defined_undefined('test')
    assert s == []

# Unit test

# Generated at 2022-06-25 05:05:06.359635
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # test_extract_defined_undefined_with_one_defined_undefined_condition_should_return_list_of_defined_undefined_conditions()
    conditional_0 = Conditional()
    conditional_0._ds = None

    # Parameters
    conditional = '{{ asd is not defined }}'

    # Actual Results
    actual_results = conditional_0.extract_defined_undefined(conditional)

    # Expected Results
    expected_results = [('asd', 'is not', 'defined')]

    assert actual_results == expected_results


# Generated at 2022-06-25 05:05:13.590762
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    ansible_vars = dict()
    ansible_vars["A"] = "B"
    ansible_vars["B"] = "C"
    all_vars = dict()
    all_vars["A"] = "B"
    all_vars["B"] = "C"
    conditional_0 = Conditional()
    assert conditional_0.evaluate_conditional(None, all_vars) == True

    ansible_vars = dict()
    ansible_vars["A"] = "B"
    ansible_vars["B"] = "C"
    all_vars = dict()
    all_vars["A"] = "B"
    all_vars["B"] = "C"
    conditional_0 = Conditional()

# Generated at 2022-06-25 05:05:23.300742
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = conditional_0
    all_vars_0 = dict()
    conditional_0.when = ["not foo is defined", "bar is defined", "hostvars['foo'] is defined"]
    all_vars_1 = dict(foo='bar')
    all_vars_2 = dict(foo='bar', baz='xyz')
    all_vars_3 = dict(baz='xyz', foo='bar')
    all_vars_4 = dict(bar='foo')
    all_vars_5 = dict()
    try:
        result = conditional_0.evaluate_conditional(templar_0, all_vars_0)
        assert False
    except AnsibleUndefinedVariable as e:
        assert "error while evaluating conditional" in to_

# Generated at 2022-06-25 05:05:33.501542
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_extract_defined_undefined = Conditional()
    assert [('hostvars[\"foo\"]', 'is', 'defined')] == conditional_extract_defined_undefined.extract_defined_undefined('hostvars["foo"] is defined')
    assert [('hostvars[\"foo\"]', 'is not', 'defined')] == conditional_extract_defined_undefined.extract_defined_undefined('hostvars["foo"] is not defined')
    assert [] == conditional_extract_defined_undefined.extract_defined_undefined('hostvars["foo"]')
    assert [] == conditional_extract_defined_undefined.extract_defined_undefined('beep boop bop')


assert Conditional._validate.__self__.__name__ == 'conditional'


# Generated at 2022-06-25 05:05:44.468418
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    results = conditional.extract_defined_undefined("")
    assert results == []

    results = conditional.extract_defined_undefined("test")
    assert results == []

    results = conditional.extract_defined_undefined("test is defined")
    assert results == [('test', 'is', 'defined')]

    results = conditional.extract_defined_undefined("a is undefined")
    assert results == [('a', 'is', 'undefined')]

    results = conditional.extract_defined_undefined("b not is defined")
    assert results == [('b', 'not is', 'defined')]

    results = conditional.extract_defined_undefined("c not is undefined")
    assert results == [('c', 'not is', 'undefined')]

    results = conditional.extract

# Generated at 2022-06-25 05:05:53.085132
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    conditional_0 = Conditional()

    # Test to assert that extract_defined_undefined returns expected list of tuples
    conditional_1 = "undefined_var is undefined and another_undefined_var is not defined or last_undefined_var is undefined"
    expected_1 = [('undefined_var', 'is', 'undefined'), ('another_undefined_var', 'is not', 'defined'), ('last_undefined_var', 'is', 'undefined')]
    actual_1 = conditional_0.extract_defined_undefined(conditional_1)
    assert expected_1 == actual_1

    # Test to assert that extract_defined_undefined returns expected list of tuples
    conditional_2 = "hostvars['hostname'] is not defined"

# Generated at 2022-06-25 05:05:59.943305
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    try:
        conditional_1.extract_defined_undefined('a is defined and b is defined')
    except Exception as e:
        print("FAILED - Conditional_extract_defined_undefined - exception raised: " + str(e) + '\n')
        return False

    try:
        conditional_1.extract_defined_undefined('')
    except Exception as e:
        print("FAILED - Conditional_extract_defined_undefined - exception raised: " + str(e) + '\n')
        return False


# Generated at 2022-06-25 05:06:01.195691
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    assert(True)

# Generated at 2022-06-25 05:06:09.181367
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    # Evaluate boolean expression without templating
    assert conditional_0.evaluate_conditional(conditional_0, True, '{{ ansible_distribution }}')
    # Evaluate string expression without templating
    assert conditional_0.evaluate_conditional(conditional_0, True, '{{ ansible_distribution }}')
    # Evaluate string expression with templating
    assert conditional_0.evaluate_conditional(conditional_0, True, '{{ ansible_distribution }}')
    # Evaluate string expression with templating that contains a Jinja2 delimiter
    assert conditional_0.evaluate_conditional(conditional_0, True, '{{ ansible_distribution }}')
    # Evaluate defined expression with templating

# Generated at 2022-06-25 05:06:15.301101
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    conditionalTest = "foo.bar is defined and foo.bar is not undefined"
    expected = [('foo.bar', 'is', 'defined'), ('foo.bar', 'is not', 'undefined')]
    result = conditional.extract_defined_undefined(conditionalTest)

    assert result == expected



# Generated at 2022-06-25 05:06:42.730491
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # create Conditional object
    conditional_0 = Conditional()

    # set attribute '_loader' of Conditional object
    setattr(conditional_0, '_loader', object())

    # create templar object 'templar_0'
    templar_0 = object()

    # create variable 'all_vars'
    all_vars = dict()

    # call method 'evaluate_conditional' of Conditional object
    result = conditional_0.evaluate_conditional(templar_0, all_vars)

    # check result
    assert result == True, "Failed to evaluate conditional"


# Generated at 2022-06-25 05:06:44.917082
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    conditional_1_test_string = 'foo is defined and bar is not undefined'
    assert conditional_1._check_conditional(conditional_1_test_string, None, None) == True



# Generated at 2022-06-25 05:06:48.421366
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = None
    all_vars_0 = None
    test_0 = conditional_0.evaluate_conditional(templar_0, all_vars_0)
    print(test_0)
    print(bool)
    assert test_0 == True


# Generated at 2022-06-25 05:06:58.159028
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    results = {
        'foo': True,
        'bar': True,
        'baz': True,
        'qux': False,
        'moo': False,
        'poo': True,
        'roo': False,
        'loo': False,
        'goo': True,
        'hoo': True,
        'boo': True,
        'coo': True,
        'doo': False
    }

    class Thing:
        pass



# Generated at 2022-06-25 05:07:03.163739
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    conditional._ds = {"foo": "bar"}
    assert Conditional.from_jsonable(conditional.to_jsonable()) == conditional

# Generated at 2022-06-25 05:07:11.208287
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    conditional._ds = None
    conditional.when = 'True'
    templar = object
    all_vars = object
    try:
        conditional.evaluate_conditional(templar, all_vars)
    except Exception as e:
        raise AssertionError('evaluate_conditional test failed for when=True. Error: %s' % e)

    conditional.when = 'False'
    try:
        conditional.evaluate_conditional(templar, all_vars)
        raise AssertionError('evaluate_conditional test failed for when=False')
    except AnsibleError:
        pass

    conditional.when = ['True', 'True']
    try:
        conditional.evaluate_conditional(templar, all_vars)
    except Exception as e:
        raise Assert

# Generated at 2022-06-25 05:07:14.587587
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    bool_test = True
    evaluate_conditional_ret = conditional_0.evaluate_conditional(bool_test, bool_test)

    assert evaluate_conditional_ret == True


# Generated at 2022-06-25 05:07:20.664488
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    expected_result = [('abc', 'is not', 'undefined'), ('xyz', 'is', 'defined')]
    conditional = Conditional()
    sample_conditional = 'abc is not undefined and xyz is defined'
    result = conditional.extract_defined_undefined(sample_conditional)
    assert len(expected_result) == len(result)
    for (expected, actual) in zip(expected_result, result):
        assert expected[0] == actual[0]
        assert expected[1] == actual[1]
        assert expected[2] == actual[2]


# Generated at 2022-06-25 05:07:29.680813
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    conditional_0 = Conditional()

    # Test case where there are no defined/undefined tests in the conditional
    conditional_0.when = ['foo and bar']
    assert conditional_0.extract_defined_undefined("foo and bar") == []

    # Test case where there is one defined/undefined test in the conditional
    conditional.when = ['foo is defined and bar is defined']
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined')]
    # Test case where there are multiple defined/undefined tests in the conditional
    conditional_0.when = ['foo is defined and bar is defined and baz is undefined']

# Generated at 2022-06-25 05:07:34.079317
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert Conditional().extract_defined_undefined('hostvars[inventory_hostname] is defined or lookup("foo").split() is defined') == [('hostvars[inventory_hostname]', 'is', 'defined'), ('lookup("foo").split()', 'is', 'defined')]


# Generated at 2022-06-25 05:08:27.985103
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional_1 = Conditional()

    # test logic with no condition
    res_1 = conditional_1.evaluate_conditional(None, None)
    assert res_1 == True

    assert conditional_1._check_conditional("foo == 'bar'", None, {}) == False
    assert conditional_1._check_conditional("foo != 'bar'", None, {}) == True
    assert conditional_1._check_conditional("foo == 'baz'", None, {'foo': 'baz'}) == True
    assert conditional_1._check_conditional("foo != 'baz'", None, {'foo': 'baz'}) == False
    assert conditional_1._check_conditional("foo != 'baz'", None, {'foo': 'baz'}) == False

# Generated at 2022-06-25 05:08:33.546622
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    all_vars_0 = dict()
    all_vars_0['var'] = 'foobar'
    res_0 = conditional_0.evaluate_conditional(conditional_0._loader, all_vars_0)
    assert res_0
    assert True

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:08:37.274188
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = 'hostvars["foo"]["bar"] is not defined'

    if conditional:
        # Defined or undefined check, or is/is not False boolean check
        conditional = conditional.replace('not', ' ')
        m = DEFINED_REGEX.search(conditional)
        assert m == conditional



# Generated at 2022-06-25 05:08:44.419256
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    # line 0, col 1
    conditional_1_arg_0 = 'a is defined or b is undefined'
    expected_result_0 = [('a', 'is', 'defined'), ('b', 'is', 'undefined')]
    actual_result_0 = conditional_1.extract_defined_undefined(conditional_1_arg_0)
    assert expected_result_0 == actual_result_0, 'Test failed for Conditional::extract_defined_undefined'

    # line 0, col 1
    conditional_1_arg_1 = 'a is defined'
    expected_result_1 = [('a', 'is', 'defined')]
    actual_result_1 = conditional_1.extract_defined_undefined(conditional_1_arg_1)
    assert expected_

# Generated at 2022-06-25 05:08:47.832396
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    conditional_1.when = [
        'test_host is defined',
        'foo.bar is not defined',
        'hostvars["foo.bar"] is undefined',
    ]
    assert conditional_1.extract_defined_undefined(conditional_1.when[0]) == [('test_host', 'is', 'defined')]


# Generated at 2022-06-25 05:08:51.310141
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Setup
    conditional_0 = Conditional()
    conditional_0._loader = None
    all_vars_0 = None

    # Think
    result = conditional_0.evaluate_conditional(None, all_vars_0)

    # Verify
    assert result == True



# Generated at 2022-06-25 05:08:59.882203
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-25 05:09:08.340664
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = Conditional()
    all_vars_0 = Conditional()
    conditional_1 = Conditional()
    templar_1 = Conditional()
    all_vars_1 = Conditional()
    conditional_2 = Conditional()
    templar_2 = Conditional()
    all_vars_2 = Conditional()
    conditional_3 = Conditional()
    templar_3 = Conditional()
    all_vars_3 = Conditional()
    conditional_4 = Conditional()
    templar_4 = Conditional()
    all_vars_4 = Conditional()
    conditional_5 = Conditional()
    templar_5 = Conditional()
    all_vars_5 = Conditional()
    conditional_6 = Conditional

# Generated at 2022-06-25 05:09:11.459073
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional = Conditional()
    conditional._when = ['a == True']
    templar = Templar()
    result = conditional.evaluate_conditional(templar, dict(a=True))
    assert result


# Generated at 2022-06-25 05:09:15.093307
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    assert conditional_0.extract_defined_undefined(conditional_0) is None

# Generated at 2022-06-25 05:11:03.066416
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # test basic evaluation
    assert Conditional().evaluate_conditional(None, None)

    # test using is/is not
    assert Conditional().evaluate_conditional(None, None) == True

    # test using is/is not
    assert Conditional().evaluate_conditional(None, None) == True
    assert Conditional().evaluate_conditional(None, None) == True
    assert Conditional().evaluate_conditional(None, None) == False

    # test using is/is not
    assert Conditional().evaluate_conditional(None, None) == True
    assert Conditional().evaluate_conditional(None, None) == True
    assert Conditional().evaluate_conditional(None, None) == False

    # test using is/is not
    assert Conditional().evaluate_conditional(None, None) == True

    # test using is/

# Generated at 2022-06-25 05:11:12.902236
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    # Single case
    conditional_1 = 'hostvars["foo"]["ansible_facts"]["os_family"] == "Debian" and hostvars["foo"]["ansible_facts"]["distribution"] == "Debian"'
    expected_result_1 = [('hostvars["foo"]["ansible_facts"]["os_family"]', '==', 'Debian')]
    actual_result_1 = conditional.extract_defined_undefined(conditional_1)
    assert expected_result_1 == actual_result_1

    # Test with multiple defined/undefined cases

# Generated at 2022-06-25 05:11:21.353602
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    print("test_Conditional_extract_defined_undefined")
    conditional = Conditional()
    conditional.when = ["hostvars['host5'].inventory_hostname is defined"]
    assert conditional.extract_defined_undefined("hostvars['host5'].inventory_hostname is defined") == [("hostvars['host5'].inventory_hostname", "is", "defined")]
    assert conditional.extract_defined_undefined("hostvars['host5'].inventory_hostname is not defined") == [("hostvars['host5'].inventory_hostname", "is not", "defined")]

# Generated at 2022-06-25 05:11:27.214870
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    test_0 = Conditional()
    test_0._loader = DictDataLoader({})
    test_0 = test_0.extract_defined_undefined('hostvars[inventory_hostname] is defined')
    if test_0 != [('hostvars[inventory_hostname]', 'is', 'defined')]:
        raise AssertionError()
    test_1 = Conditional()
    test_1._loader = DictDataLoader({})
    test_1 = test_1.extract_defined_undefined('hostvars[inventory_hostname] is not defined')
    if test_1 != [('hostvars[inventory_hostname]', 'is not', 'defined')]:
        raise AssertionError()
    test_2 = Conditional()
    test_2._loader = DictDataLoader({})


# Generated at 2022-06-25 05:11:31.663747
# Unit test for constructor of class Conditional
def test_Conditional():
    att_test = Conditional()._attributes['_when']
    assert att_test == 'list'
    check = Conditional()._validate_when('_when', 'name', [])
    assert check == None
    check2 = Conditional()._validate_when('_when', 'name', 'stuff')
    assert check2 == None


# Generated at 2022-06-25 05:11:38.336079
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_1 = conditional_0.extract_defined_undefined("hostvars[inventory_hostname].ansible_os_family is not defined")
    # condition_1 is expected to return [['hostvars[inventory_hostname].ansible_os_family', 'is not', 'defined']]

    conditional_2 = conditional_0.extract_defined_undefined("hostvars[inventory_hostname].ansible_os_family is defined")
    # condition_2 is expected to return [['hostvars[inventory_hostname].ansible_os_family', 'is', 'defined']]

    conditional_3 = conditional_0.extract_defined_undefined("hostvars[inventory_hostname].ansible_os_family is not undefined")
    # condition_3 is expected to return

# Generated at 2022-06-25 05:11:45.918262
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_fixture = Conditional()
    conditional_fixture._ds = Mock()
    conditional_fixture._ds.get_data = lambda x: 'hostvars["foo"]'
    conditional_fixture._loader = Mock()
    conditional_fixture._loader.load_from_file = lambda x, y: conditional_fixture._ds

    # Passing in both defined and undefined
    conditional_fixture.when = ['hostvars["foo"] is defined and hostvars["bar"] is not defined']
    result_0 = conditional_fixture.extract_defined_undefined(conditional_fixture.when[0])
    assert ['hostvars["foo"]', 'is', 'defined'] in result_0
    assert ['hostvars["bar"]', 'is not', 'defined'] in result_0

    # Passing in defined
   

# Generated at 2022-06-25 05:11:55.460002
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    result1 = conditional.extract_defined_undefined("hostvars['foo'] is defined")
    assert result1[0][0] == "hostvars['foo']"
    assert result1[0][1] == "is"
    assert result1[0][2] == "defined"

    result2 = conditional.extract_defined_undefined("ansible_facts['os']['family'] is undefined")
    assert result2[0][0] == "ansible_facts['os']['family']"
    assert result2[0][1] == "is"
    assert result2[0][2] == "undefined"

    result2 = conditional.extract_defined_undefined("hostvars['foo'] not is undefined")

# Generated at 2022-06-25 05:11:58.494833
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    print("HI")
    conditional_1 = Conditional()

    # TODO: write unit test
    #raise RuntimeError("No tests for this class yet")



# Generated at 2022-06-25 05:12:02.225817
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    test = Conditional()
    result = test.evaluate_conditional(None,None)
    assert (result == True)