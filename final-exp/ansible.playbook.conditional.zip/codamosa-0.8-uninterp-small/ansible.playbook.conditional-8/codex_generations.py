

# Generated at 2022-06-25 05:03:39.936790
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    # Create a new conditional with an undefined variable
    # conditional_0 = Conditional()

    # conditional_0.when = 'hostvars["foo"] is undefined'
    conditional.when = 'hostvars["foo"] is undefined'
    results = conditional.extract_defined_undefined(conditional.when)

    # Check the length of result
    assert len(results) is 1

    # Check the first item of results
    assert results[0][0] == 'hostvars["foo"]'

    # Check the second item of results
    assert results[0][1] == 'is'

    # Check the third item of results
    assert results[0][2] == 'undefined'

    # Create a new conditional with a defined variable
    conditional.when = 'hostvars["foo"] is defined'
   

# Generated at 2022-06-25 05:03:45.737853
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-25 05:03:56.505041
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    # Test case 1
    conditional_0 = conditional.extract_defined_undefined("")
    assert conditional_0 == []

    # Test case 2
    conditional_0 = conditional.extract_defined_undefined("(foo.bar == baz.blip)")
    assert conditional_0 == []

    # Test case 3
    conditional_0 = conditional.extract_defined_undefined("something_else_defined")
    assert conditional_0 == []

    # Test case 4
    conditional_0 = conditional.extract_defined_undefined("something_else_undefined")
    assert conditional_0 == []

    # Test case 5

# Generated at 2022-06-25 05:04:05.506385
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    assert conditional_0.extract_defined_undefined("hostvars['foo'] is defined and hostvars['bar'] is undefined") == [['hostvars[\'foo\']', 'is', 'defined'], ['hostvars[\'bar\']', 'is', 'undefined']]
    assert conditional_0.extract_defined_undefined("hostvars['foo'] not is defined and hostvars['bar'] is undefined") == [['hostvars[\'foo\']', 'not is', 'defined'], ['hostvars[\'bar\']', 'is', 'undefined']]

# Generated at 2022-06-25 05:04:15.014433
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    assert conditional_0.extract_defined_undefined("string") == []
    assert conditional_0.extract_defined_undefined("defined") == []
    assert conditional_0.extract_defined_undefined("not is defined") == []
    assert conditional_0.extract_defined_undefined("teststring is defined") == [('teststring', 'is', 'defined')]
    assert conditional_0.extract_defined_undefined("teststring is not defined") == [('teststring', 'is not', 'defined')]
    assert conditional_0.extract_defined_undefined("teststring is defined and teststring is not defined") == [('teststring', 'is', 'defined'), ('teststring', 'is not', 'defined')]
    assert conditional_0.extract_defined_undefined

# Generated at 2022-06-25 05:04:22.246911
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    res = conditional_1.extract_defined_undefined("'a' is defined")
    assert [('a', 'is', 'defined')] == res

    res = conditional_1.extract_defined_undefined("'a' not is undefined")
    assert [('a', 'not is', 'undefined')] == res

    res = conditional_1.extract_defined_undefined("'a' is not defined")
    assert [('a', 'is not', 'defined')] == res

    res = conditional_1.extract_defined_undefined("'a' and 'b' not is undefined")
    assert [('a', 'and', 'not is'), ('b', 'not is', 'undefined')] == res


# Generated at 2022-06-25 05:04:27.572668
# Unit test for constructor of class Conditional
def test_Conditional():
    try:
        conditional_0 = Conditional()
    except:
        display.error("Failed to create Conditional object")
        raise

    if not isinstance(conditional_0, Conditional):
        display.error("Failed to create Conditional object")
        raise


# Generated at 2022-06-25 05:04:36.941817
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    print("======= test_Conditional_extract_defined_undefined ========")

    conditional_1 = Conditional()

    results1 = conditional_1.extract_defined_undefined('foo is defined')
    # print(results1)
    assert len(results1) == 1
    assert results1[0][0] == 'foo'
    assert results1[0][1] == 'is'
    assert results1[0][2] == 'defined'

    results2 = conditional_1.extract_defined_undefined('{{ hostvars[inventory_hostname] }} is not defined')
    # print(results2)
    assert len(results2) == 1
    assert results2[0][0] == 'hostvars[inventory_hostname]'
    assert results2[0][1] == 'is not'
   

# Generated at 2022-06-25 05:04:43.612696
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Test Case 1:
    Tests the method evaluate_conditional with a single conditional containing just a variable.
    If the variable is defined and contains a True value, the conditional will be evaluated as True.
    '''
    conditional_1 = Conditional()
    conditional_1.when = ["ansible_os_family == 'Debian'"]
    variables = {'ansible_os_family': 'Debian'}
    result = conditional_1.evaluate_conditional(variables)
    assert result == True


# Generated at 2022-06-25 05:04:49.434388
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    cond = 'foo is defined and bar is not defined'
    assert conditional_0.extract_defined_undefined(cond) == \
        [('foo', 'is', 'defined'), ('bar', 'is not', 'defined')]



# Generated at 2022-06-25 05:05:15.826527
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0_ds_var = get_task_ds()
    conditional_0_ds_value0_var = get__ds_value0_ds()
    conditional_0_ds_value0_result_var = get__ds_value0_result_ds()
    conditional_0_ds_value1_var = get__ds_value1_ds()
    conditional_0_ds_value1_result_var = get__ds_value1_result_ds()
    conditional_0_ds_value2_var = get__ds_value2_ds()
    conditional_0_ds_value2_result_var = get__ds_value2_result_ds()
    conditional_0_ds_value3_var = get__ds_value3_ds()
    conditional_0_ds_value3_result_var = get__ds

# Generated at 2022-06-25 05:05:24.680955
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play import Play
    from ansible.template import Templar
    yaml_data = """
- hosts: all
  tasks:
    - debug:
        msg: this_msg
"""
    p = Play().load(yaml_data, variable_manager=None, loader=None)
    t = Templar(loader=None)
    conditional_0 = p.get_tasks()[0]
    all_vars = dict()
    res = conditional_0.evaluate_conditional(t, all_vars)
    assert(res)


# Generated at 2022-06-25 05:05:27.183449
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    templar_1 = Templar()

    assert conditional_1.evaluate_conditional(templar_1, {}) == True


# Generated at 2022-06-25 05:05:36.950354
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
	conditional = Conditional()
	assert conditional.extract_defined_undefined("hostvars['foo'] is defined") == [(u'hostvars[\'foo\']', u'is', u'defined')]
	assert conditional.extract_defined_undefined("(hostvars['foo'] is defined) and (hostvars['bar'] is not undefined)") == [(u'hostvars[\'foo\']', u'is', u'defined'), (u'hostvars[\'bar\']', u'is not', u'undefined')]
	assert conditional.extract_defined_undefined("(hostvars['foo'] is defined)") == [(u'hostvars[\'foo\']', u'is', u'defined')]

# Generated at 2022-06-25 05:05:42.170145
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_1 = 'default'
    all_vars_2 = 'default'
    result = conditional_0.evaluate_conditional(templar_1, all_vars_2)
    # Validate the results



# Generated at 2022-06-25 05:05:51.736906
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()


# Generated at 2022-06-25 05:05:59.417425
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Tests for when argument Supplied, with ansible_facts
    all_vars = [{'ansible_facts': {'uptime_seconds': 5678}}]
    conditional = Conditional()
    conditional.when = ['ansible_facts.uptime_seconds > 500']
    templar = 'None'
    assert conditional.evaluate_conditional(templar, all_vars)


# Generated at 2022-06-25 05:06:05.047001
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    a = [('hostvars["foo"]', 'not is', 'defined')]
    out = c.extract_defined_undefined('hostvars["foo"] not is defined')
    assert out == a

    b = [('hostvars["foo"]', 'is', 'defined'), ('hostvars["bar"]', 'is', 'defined')]
    out = c.extract_defined_undefined('hostvars["foo"] is defined or hostvars["bar"] is defined')
    assert out == b

    c = [('hostvars[\'foo\']', 'is', 'defined')]
    out = c.extract_defined_undefined("hostvars['foo'] is defined")
    assert out == c


# Generated at 2022-06-25 05:06:10.981605
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert Conditional().extract_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert Conditional().extract_defined_undefined('hostvars[inventory_hostname] not is undefined') == [('hostvars[inventory_hostname]', 'not is', 'undefined')]
    assert Conditional().extract_defined_undefined('hostvars[inventory_hostname]not is undefined') == [('hostvars[inventory_hostname]not', 'is', 'undefined')]

# Generated at 2022-06-25 05:06:20.735404
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    regex = DEFINED_REGEX

    # test case 1
    conditional_1 = Conditional()
    res_1 = conditional_1.extract_defined_undefined('foo is defined and bar is defined')
    assert res_1 == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

    # test case 2
    conditional_2 = Conditional()
    res_2 = conditional_2.extract_defined_undefined('baz is not defined')
    assert res_2 == [('baz', 'is not', 'defined')]

    # test case 3
    conditional_3 = Conditional()
    res_3 = conditional_3.extract_defined_undefined('foo is not defined and baz is undefined')

# Generated at 2022-06-25 05:07:09.268385
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # test without variable and without lookup
    conditional_0 = Conditional()
    assert conditional_0.evaluate_conditional('True', None)

    conditional_1 = Conditional()
    conditional_1.when = [ "foo == 'True'" ]
    assert conditional_1.evaluate_conditional('foo == "True"', {'foo': "True"})

    # test with a lookup
    def test_lookup(value):
        return "True"

    conditional_2 = Conditional()
    conditional_2.when = [ "lookup('test', foo, 'bar', wantlist=True)[0] == 'True'" ]

    conditional_2._loader.lookups.register('test', test_lookup)

# Generated at 2022-06-25 05:07:11.172342
# Unit test for constructor of class Conditional
def test_Conditional():
    assert 'conditional' == Conditional.__name__
    assert 'ansible.playbook.conditional' == Conditional.__module__



# Generated at 2022-06-25 05:07:18.004295
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = Templar(loader=MockLoader())
    # Missing required arguments: all_vars
    with pytest.raises(TypeError):
        conditional_0.evaluate_conditional(templar_0)


# Generated at 2022-06-25 05:07:25.212412
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    conditional_0.when = list()
    conditional_0.when.append('test')
    all_vars_0 = dict()
    all_vars_0['test'] = 'test'
    templar_0 = object()
    test_answer = conditional_0.evaluate_conditional(templar_0, all_vars_0)

    assert test_answer == True


# Generated at 2022-06-25 05:07:28.443179
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_0_str = conditional_0.extract_defined_undefined('hostvars[inventory_hostname] is undefined')
    assert not conditional_0_str, "this shouldn't be null"
    assert conditional_0_str == []


# Generated at 2022-06-25 05:07:30.953824
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_0._ds = "tasks/name: test_0"
    assert conditional_0.extract_defined_undefined("first_var is defined and second_var is undefined") == [("first_var","is","defined"),("second_var","is","undefined")]


# Generated at 2022-06-25 05:07:35.714498
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    testcase_1 = conditional_1.extract_defined_undefined("foo is defined and bar is undefined")
    expected_result_1 = [("foo", "is", "defined"), ("bar", "is", "undefined")]
    assert testcase_1 == expected_result_1

    conditional_2 = Conditional()
    testcase_2 = conditional_2.extract_defined_undefined("foo is defined or bar is undefined")
    assert testcase_2 == expected_result_1

    conditional_3 = Conditional()
    testcase_3 = conditional_3.extract_defined_undefined("foo is not defined or bar is not undefined")
    expected_result_3 = [("foo", "is not", "defined"), ("bar", "is not", "undefined")]
    assert test

# Generated at 2022-06-25 05:07:45.797801
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    conditional_1._loader = None
    conditional_1._ds = None

    conditional_1.when = ["hostvars['foo'] is defined"]
    assert conditional_1.extract_defined_undefined(conditional_1.when[0]) == [('hostvars[\'foo\']', 'is', 'defined')]

    conditional_1.when = ["hostvars[foo] is undefined"]
    assert conditional_1.extract_defined_undefined(conditional_1.when[0]) == [('hostvars[foo]', 'is', 'undefined')]

    conditional_1.when = ["hostvars['foo'] is defined and hostvars[bar] is undefined"]

# Generated at 2022-06-25 05:07:49.985861
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    conditional.when = ["test_case_0"] # Test when is set
    assert conditional.evaluate_conditional("test_case_0", {}) == True
    conditional.when = ["test_case_1"] # Test when is not set
    assert conditional.evaluate_conditional("test_case_1", {}) == False

# Generated at 2022-06-25 05:07:55.003061
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    conditional.when = ['(hostvars[inventory_hostname].foo == "bar") or (hostvars[inventory_hostname].foo is undefined)']
    assert conditional.extract_defined_undefined(conditional.when[0]) == [('hostvars[inventory_hostname].foo', 'is', 'undefined')]



# Generated at 2022-06-25 05:08:45.258932
# Unit test for constructor of class Conditional
def test_Conditional():
    obj = Conditional()


# Generated at 2022-06-25 05:08:52.955106
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()

    # Test 1
    conditional = 'ansible_fqdn is undefined'
    expected = [('ansible_fqdn', 'is', 'undefined')]
    actual = conditional_1.extract_defined_undefined(conditional)
    assert expected == actual

    # Test 2
    conditional = 'hostvars[inventory_hostname] is not defined'
    expected = [('hostvars[inventory_hostname]', 'is not', 'defined')]
    actual = conditional_1.extract_defined_undefined(conditional)
    assert expected == actual

    # Test 3
    conditional = 'hostvars is undefined'
    expected = []
    actual = conditional_1.extract_defined_undefined(conditional)
    assert expected == actual

    # Test 4
    conditional

# Generated at 2022-06-25 05:09:04.966170
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    var0 = 'var0'
    var1 = 'var1'
    templar_0 = Templar(loader=None, variables=None)
    var2 = None
    var3 = 'var3'
    var4 = 'var4'
    var5 = 'var5'
    var6 = 'var6'
    var7 = 'var7'
    var8 = 'var8'
    var9 = 'var9'
    var10 = 'var10'
    var11 = 'var11'
    var12 = 'var12'
    var13 = 'var13'
    var14 = 'var14'
    var15 = 'var15'
    var16 = 'var16'
    var17 = 'var17'
    var18 = 'var18'

# Generated at 2022-06-25 05:09:14.360273
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    The evaluate_conditional method of class Conditional
    '''
    if not isinstance(Conditional(), Conditional):
        raise TypeError("%s is not an instance of Conditional" % str(type(Conditional())))

    # Assign values/objects to instance variables
    #conditional_0._loader = 
    #conditional_0._templar = 
    #conditional_0._ds = 
    conditional_0._when = ['when_value']

    # Evaluate method evaluate_conditional under test
    returned_value = conditional_0.evaluate_conditional(Conditional, 'all_vars')
    assert conditional_0.evaluate_conditional(Conditional, 'all_vars') == False


# Generated at 2022-06-25 05:09:25.445303
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    conditional_1.when = u'defined(hostvars[\'foo\']) and (hostvars[\'foo\']|int > 0)'
    assert conditional_1.extract_defined_undefined(conditional_1.when) == [
        (u'hostvars[\'foo\']', u'is', u'defined')
    ]
    conditional_2 = Conditional()
    conditional_2.when = u'(type(a)|int < 1) and (type(b)|int > 0)'
    assert conditional_2.extract_defined_undefined(conditional_2.when) == []
    conditional_3 = Conditional()

# Generated at 2022-06-25 05:09:31.076327
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    results = cond.extract_defined_undefined("(test is defined or other_test is not defined) and "
                                             "(test is not defined or other_test is defined)")
    assert len(results) == 4


# Generated at 2022-06-25 05:09:38.004588
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # test 1
    conditional_1 = Conditional()
    conditional = 'hostvars[inventory_hostname] is defined'
    res = conditional_1.extract_defined_undefined(conditional)
    assert res == [(u'hostvars[inventory_hostname]', u'is', u'defined')]
    # test 2
    conditional_2 = Conditional()
    conditional = 'a is undefined'
    res = conditional_2.extract_defined_undefined(conditional)
    assert res == [(u'a', u'is', u'undefined')]
    # test 3
    conditional_3 = Conditional()
    conditional = 'not a is defined'
    res = conditional_3.extract_defined_undefined(conditional)

# Generated at 2022-06-25 05:09:43.772254
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    conditional_1.when = ['my_var']
    templar_1 = None
    all_vars_1 = {'my_var': True}
    test_result_1 = conditional_1.evaluate_conditional(templar_1, all_vars_1)
    assert test_result_1


# Generated at 2022-06-25 05:09:46.234649
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    test_Conditional = Conditional()
    result = test_Conditional.extract_defined_undefined("ansible_distribution is not defined")
    assert result == [("ansible_distribution", "is", "not defined")]


# Generated at 2022-06-25 05:09:47.898579
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    assert conditional.evaluate_conditional(None, None) == True


# Generated at 2022-06-25 05:11:54.608041
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestClass(Conditional):
        pass

    test0 = TestClass()
    # Test when unset
    assert test0.evaluate_conditional('')

    test1 = TestClass()
    test1._when = ['', '', '', '', '', '', '', '']
    assert test1.evaluate_conditional('')

    test2 = TestClass()
    test2._when = ['True', 'True', 'True', 'True', 'True', 'True', 'True', 'True']
    assert test2.evaluate_conditional('')

    test3 = TestClass()
    test3._when = ['False', 'False', 'False', 'False', 'False', 'False', 'False', 'False']
    assert not test3.evaluate_conditional('')

    test4 = TestClass()
    test

# Generated at 2022-06-25 05:12:00.713469
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    v1 = conditional_1.extract_defined_undefined("hostvars['foo'] is not defined and hostvars['hostvars[\"bar\"]'] is defined")
    assert v1 == [("hostvars['foo']", 'is not', 'defined'), ("hostvars['hostvars[\"bar\"]']", 'is', 'defined')]

    v2 = conditional_1.extract_defined_undefined("debug_var is defined")
    assert v2 == [("debug_var", 'is', 'defined')]

    v3 = conditional_1.extract_defined_undefined("debug_var is defined or debug_var is defined")
    assert v3 == [("debug_var", 'is', 'defined'), ("debug_var", 'is', 'defined')]

    v

# Generated at 2022-06-25 05:12:08.276297
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c1 = Conditional()
    c2 = Conditional()

    c1._ds = "Included in test_extract_defined_undefined_1"
    c2._ds = "Included in test_extract_defined_undefined_2"

    # Testcase 1:
    conditional_1 = "(name not is undefined)"

    assert c1.extract_defined_undefined(conditional_1) == ([('name', 'not is', 'undefined')], "")

    # Testcase 2:
    conditional_2 = "not defined foo and not defined bar"

    assert c2.extract_defined_undefined(conditional_2) == ([('foo', 'not is', 'defined'), ('bar', 'not is', 'defined')], "")


# Generated at 2022-06-25 05:12:11.859390
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    test_obj = Conditional()

    cond_0 = '"defaults_yaml" not in hostvars[inventory_hostname] or hostvars[inventory_hostname]["defaults_yaml"] is undefined'
    test_obj.extract_defined_undefined(cond_0)



# Generated at 2022-06-25 05:12:14.899020
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    assert conditional_0.evaluate_conditional(None, None) == True

# Generated at 2022-06-25 05:12:17.754948
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # test_case_1
    conditional_1 = Conditional()
    conditional_1.when = ["1 == 1"]
    templar_1 = None
    all_vars_1 = None
    assert conditional_1.evaluate_conditional(templar_1, all_vars_1) is True


# Generated at 2022-06-25 05:12:20.226477
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    assert True == False


# Generated at 2022-06-25 05:12:21.798167
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    test_Conditional_object = Conditional()
    test_Conditional_object.when = ['{{ foo }}']
    test_Conditional_object.all_vars = {'foo': 'bar'}



# Generated at 2022-06-25 05:12:30.551624
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional = "abc and def or not ghi"
    conditional_0.evaluate_conditional(conditional)
    conditional = "abc and def or not ghi and hostvars['foo_bar'] is defined and some_var is undefined"
    conditional = conditional_0.evaluate_conditional(conditional)
    conditional = "this_is_a_test_var is defined and foo_bar is undefined or some_var is defined"
    conditional = conditional_0.evaluate_conditional(conditional)
    conditional = "hostvars['abc_def'] is defined and other_var is undefined and hostvars['other_var'] is undefined"
    conditional = conditional_0.evaluate_conditional(conditional)

# Generated at 2022-06-25 05:12:32.854392
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    conditional.when = [True]
    templar = object()
    all_vars = None
    conditional.evaluate_conditional(templar, all_vars)
