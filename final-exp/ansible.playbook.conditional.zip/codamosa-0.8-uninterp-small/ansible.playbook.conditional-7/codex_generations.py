

# Generated at 2022-06-25 05:03:36.667704
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional(loader=None)
    conditional_1.when = ['instance_id is defined']
    assert conditional_1.extract_defined_undefined('instance_id is defined') == [('instance_id', 'is', 'defined')]

    conditional_2 = Conditional(loader=None)
    conditional_2.when = ['foo is undefined', 'bar not is defined']
    assert conditional_2.extract_defined_undefined('foo is undefined and bar not is defined') == [('foo', 'is', 'undefined'), ('bar', 'not is', 'defined')]

    conditional_3 = Conditional(loader=None)
    conditional_3.when = ['instance_id is defined and another undefined']

# Generated at 2022-06-25 05:03:38.555947
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    pl = Conditional()
    templar = None
    all_vars = None
    result = pl.evaluate_conditional(templar, all_vars)
    assert result == True


# Generated at 2022-06-25 05:03:47.575349
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional_1 = Conditional()
    templar_1 = None
    all_vars_1 = dict()

    conditional_2 = Conditional()
    templar_2 = None
    all_vars_2 = dict()

    conditional_3 = Conditional()
    templar_3 = None
    all_vars_3 = dict()

    conditional_4 = Conditional()
    templar_4 = None
    all_vars_4 = dict()

    conditional_5 = Conditional()
    templar_5 = None
    all_vars_5 = dict()

    conditional_6 = Conditional()
    templar_6 = None
    all_vars_6 = dict()

    conditional_7 = Conditional()
    templar_7 = None
    all_vars_7

# Generated at 2022-06-25 05:03:54.234575
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = dict()
    all_vars_0 = dict()
    result = conditional_0.evaluate_conditional(templar_0, all_vars_0)
    assert result == True


# Generated at 2022-06-25 05:04:05.118066
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional(loader=None)

    # test invalid input: conditional_1.evaluate_conditional(templar=1, all_vars=2)
    try:
        assert(False == conditional_1.evaluate_conditional(templar=1, all_vars=2))
    except TypeError:
        assert(True)
    except:
        assert(False)

    # test invalid input: conditional_1.evaluate_conditional(templar=1, all_vars=2)
    try:
        assert(False == conditional_1.evaluate_conditional(templar=1, all_vars=2))
    except TypeError:
        assert(True)
    except:
        assert(False)

    # test invalid input: conditional_1.evaluate_conditional(templar=cond

# Generated at 2022-06-25 05:04:15.541222
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test for when conditionals is empty
    conditional_1 = Conditional()
    templar_1 = 'templar_1'
    all_vars_1 = 'all_vars_1'
    assert conditional_1.evaluate_conditional(templar_1, all_vars_1)
    assert isinstance(conditional_1, Conditional)

    # Test for when conditionals is not empty
    conditional_2 = Conditional()
    templar_2 = 'templar_2'
    all_vars_2 = 'all_vars_2'
    conditional_2._when = 'conditional_2'
    assert conditional_2.evaluate_conditional(templar_2, all_vars_2)
    assert isinstance(conditional_2, Conditional)

    # Test for

# Generated at 2022-06-25 05:04:17.909206
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    conditional_1.when = ['not test_var is defined']
    test_expected_result = [('test_var', 'not is', 'defined')]
    assert conditional_1.extract_defined_undefined("not test_var is defined") == test_expected_result


# Generated at 2022-06-25 05:04:23.124789
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = Templar(loader=None)
    all_vars_0 = dict()
    assert conditional_0.evaluate_conditional(templar_0, all_vars_0) == True

# Generated at 2022-06-25 05:04:34.964657
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestClass(Conditional):
        pass

    tc = TestClass()
    hostvar_name = 'my_hostvar'
    val = 'my_val'
    conditional = '%s is defined' % hostvar_name
    hostvar = dict()
    hostvar[hostvar_name] = val
    vars_ = dict(hostvars=hostvar)
    r = tc.evaluate_conditional(conditional, vars_)
    assert r is True
    conditional = '%s is not defined' % hostvar_name
    r = tc.evaluate_conditional(conditional, vars_)
    assert r is False
    conditional = 'hostvars[\'%s\'] is defined' % hostvar_name
    r = tc.evaluate_conditional(conditional, vars_)
    assert r is True

# Generated at 2022-06-25 05:04:38.143157
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = Jinja2Template()
    all_vars_0 = dict()
    result_0 = conditional_0.evaluate_conditional(templar_0, all_vars_0)
    assert result_0 == True


# Generated at 2022-06-25 05:05:05.851274
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()

    conditional_1.when = ['a==b']

    templar = mock_ansible_module.AnsibleTemplate
    all_vars = 'fake_all_vars'
    try:
        conditional_1.evaluate_conditional(templar, all_vars)
    except SystemExit:
        pass
    except Exception as e:
        assert(False)

    conditional_2 = Conditional()

    conditional_2.when = ['a==b']

    templar = mock_ansible_module.AnsibleTemplate
    all_vars = 'fake_all_vars'
    try:
        conditional_2.evaluate_conditional(templar, all_vars)
    except SystemExit:
        pass
    except Exception as e:
        assert(False)

# Generated at 2022-06-25 05:05:07.744747
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    value_0 = conditional_0.evaluate_conditional([True, True, False], [''])
    assert value_0 == False

# Generated at 2022-06-25 05:05:15.849084
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class TestConditional(Conditional):
        def __init__(self, loader=None):
            self._loader = None

# Generated at 2022-06-25 05:05:26.788605
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    testtemplate_0 = DummyTemplate()
    inventory_vars_0 = DummyVars()
    testtemplate_0.vars = inventory_vars_0

    # Default test, this case is true always
    assert conditional_0.evaluate_conditional(testtemplate_0, None) is True

    # This case is false always
    setattr(conditional_0,"when",["False"])
    assert conditional_0.evaluate_conditional(testtemplate_0, None) is False

    # This case is true when inventory_vars.date is equal to "today"
    setattr(conditional_0,"when",["inventory_vars.date == 'today'"])
    assert conditional_0.evaluate_conditional(testtemplate_0, None) is True

    # This case is true

# Generated at 2022-06-25 05:05:36.538697
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    # Set when to include a number and a string
    conditional_1.when = [1, "test"]
    # Set the evaluate_conditional method to return the result of the evaluation of the conditionals set on the object
    result = conditional_1.evaluate_conditional()
    assert result is True, \
        "Expected: True, Actual: {}".format(str(result))
    
    # Set when to include a variable from the playbook
    conditional_2 = Conditional()
    conditional_2.when = "{{ ansible_distribution }} == 'Ubuntu'"
    # Set the evaluate_conditional method to return the result of the evaluation of the conditionals set on the object
    result = conditional_2.evaluate_conditional()

# Generated at 2022-06-25 05:05:45.834348
# Unit test for constructor of class Conditional
def test_Conditional():
    # Test when Conditional is used with no loader
    try:
        test_case_0()
        raise Exception("AnsibleError not raised")
    except AnsibleError:
        pass

    # Test when Conditional is used with a loader
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    conditional_1 = Conditional(loader=loader)
    assert conditional_1._loader == loader

    # Test when Conditional is used with a Base class
    import ansible.playbook.base
    class NewBaseClass(ansible.playbook.base.Base):
        pass
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    base = NewBaseClass()
    assert base._loader == loader


# Generated at 2022-06-25 05:05:56.087089
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Test that _check_conditional evaluates a conditional properly.
    '''

    # Instantiate and initialize objects
    conditional = Conditional()
    all_vars = {
        'first_var': '2',
        'second_var': '3',
        'third_var': '1',
        'fourth_var': '3',
        'fifth_var': '2',
        'sixth_var': '1',
        'seventh_var': '3',
        'eighth_var': '1'
    }
    templar = dict()
    conditional = Conditional()
    # test for conditions that should evaluate as True
    # Make sure that '2' > 1 evaluates True

# Generated at 2022-06-25 05:06:02.404134
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()

    # Test condition_1:
    conditional_1_extract_defined_undefined = conditional_1.extract_defined_undefined('hostvars[\'host_1\'] is defined')
    assert conditional_1_extract_defined_undefined == [('hostvars[\'host_1\']', 'is', 'defined')]

    # Test condition_2:
    conditional_2_extract_defined_undefined = conditional_1.extract_defined_undefined('hostvars[\'host_1\'] is undefined and hostvars[\'host_2\'] is not defined')

# Generated at 2022-06-25 05:06:09.957272
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test cases for Conditional.evaluate_conditional
    #
    # Input arguments:
    #    self        - Instance of the Conditional class
    #    templar     - Ansible Templar object that is a helper class to aid in
    #                  the transformation of data inside a template
    #    all_vars    - Dictionary containing all the variables
    # Expected return value:
    #    result      - Result of evaluating the conditional
    #
    # set up some environment
    display.verbosity = 3
    C.DEFAULT_DEBUG = True


# Generated at 2022-06-25 05:06:20.285549
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()

    # test for two defined conditions and two undefined conditions, testing for the
    # case where a variable will be defined in a later conditional
    conditional = "ansible_facts['foo'] is defined and ansible_facts['bar'] is not defined and (ansible_facts['baz'] is defined or hostvars['localhost']['qux'] is not defined)"
    results = conditional_0.extract_defined_undefined(conditional)
    assert results == [
        ('ansible_facts[\'foo\']', 'is', 'defined'),
        ('ansible_facts[\'bar\']', 'is', 'not'),
        ('ansible_facts[\'baz\']', 'is', 'defined'),
    ], results

    # test for an undefined condition followed by a defined condition

# Generated at 2022-06-25 05:06:37.485793
# Unit test for constructor of class Conditional
def test_Conditional():
    try:
        conditional_1 = Conditional()
        assert True
    except:
        assert False
    try:
        conditional_2 = Conditional(loader='a')
        assert True
    except:
        assert False


# Generated at 2022-06-25 05:06:40.994678
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    conditional_1 = Conditional()
    extract_defined_undefined_1 = conditional_1.extract_defined_undefined('hostvars[inventory_hostname] is undefined')
    assert extract_defined_undefined_1 == [('hostvars[inventory_hostname]', 'is', 'undefined')]



# Generated at 2022-06-25 05:06:47.909283
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    conditionals = ['item == 3', 'item == 4', 'item == 5']
    items = [3,4,5]
    for (conditional, item) in zip(conditionals, items):
        assert True == conditional._check_conditional(conditional, item)

    conditionals = ['item == 0', 'item == 1', 'item == 2']
    items = [3,4,5]
    for (conditional, item) in zip(conditionals, items):
        assert False == conditional._check_conditional(conditional, item)


# Generated at 2022-06-25 05:06:58.128003
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_object = Conditional()
    conditional_object._loader = {"_basedir": "/some/dir/that/doesnt/exist", "path_info": [{"basedir": "/ansible/dir/that/doesnt/exist"}]}
    cl = [True]
    when_0 = conditional_object.evaluate_conditional(conditional_object.templar, cl)
    assert when_0 == True
    conditional_object._loader = {"_basedir": "/some/dir/that/doesnt/exist", "path_info": [{"basedir": "/ansible/dir/that/doesnt/exist"}]}
    cl = [False]
    when_0 = conditional_object.evaluate_conditional(conditional_object.templar, cl)
    assert when_0 == False

# Generated at 2022-06-25 05:07:06.175118
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional = Conditional()

    conditional.when = [
        'myvar_1 == 1',
        'myvar_2 == 2',
        'myvar_3 == 3',
    ]

    templar = None
    all_vars = dict(myvar_1=1, myvar_2=2, myvar_3=3)

    res = conditional.evaluate_conditional(templar, all_vars)

    assert res


# Generated at 2022-06-25 05:07:17.588170
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-25 05:07:28.390940
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_0.when = [
        'test_case_0',
        'test_case_1',
        'test_case_2',
        'test_case_3',
        'test_case_4',
        'test_case_5'
    ]

# Generated at 2022-06-25 05:07:33.722609
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Object to test
    conditional_1 = Conditional()
    conditional_1.when = [None, '', '', '', '', 'a|b', 'a|b', 'a|b']
    conditional_1.when[0] = '', '', 'a|b', 'a|b', 'a|b', 'a|b'
    conditional_1.when[1] = 'a|b', 'a|b', 'a|b', 'a|b', 'a|b', 'a|b'
    conditional_1.when[2] = 'a|b', 'a|b', 'a|b', 'a|b', 'a|b', 'a|b'

# Generated at 2022-06-25 05:07:39.561351
# Unit test for constructor of class Conditional
def test_Conditional():
    # Instantiate Conditional
    try:
        conditional_0 = Conditional()
    except Exception as err:
        display.display("test_Conditional_0() failed: " + str(err))
    else:
        display.display("test_Conditional_0() passed")

if __name__ == '__main__':
    test_Conditional()

# Generated at 2022-06-25 05:07:46.905872
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.task import Task

    conditional = Conditional()

    # Test case #1
    conditional._ds = None
    class test_Task(Task):
        when = FieldAttribute(isa='list', default=list, extend=True, prepend=True)
    test_task = test_Task()
    test_task._loader = None
    test_conditional = 'False'
    test_all_vars = []
    try:
        conditional.evaluate_conditional(test_task, test_all_vars)
        assert False, "Error should be reported"
    except AnsibleError as e:
        assert (b'a loader must be specified when using Conditional() directly' in e.message)

    # Test case
    conditional._ds = None

# Generated at 2022-06-25 05:08:40.716816
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test fixture
    conditional_t = Conditional()
    templar_t = mock_ansible_module.AnsibleTemplar(loader=None, variables=dict())
    all_vars_t = dict(
        string_var='a string var',
        boolean_var=True,
        list_var=[1, 2, 3, 4, 5],
        dict_var=dict(
            a_dict_var1='a dict var 1',
            a_dict_var2=1234
        )
    )

# Generated at 2022-06-25 05:08:46.712113
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    conditional_0._when = ['0']
    conditional_0.when = []
    templar_0 = None
    all_vars_0 = [0, 0]
    actual = conditional_0.evaluate_conditional(templar_0, all_vars_0)
    expected = False
    assert actual == expected


# Generated at 2022-06-25 05:08:49.953575
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    all_vars_0 = {}
    templar_0 = None
    assert not conditional_0.evaluate_conditional(templar_0, all_vars_0)


# Generated at 2022-06-25 05:08:50.974945
# Unit test for constructor of class Conditional
def test_Conditional():
    assert True

if __name__ == "__main__":
    test_Conditional()

# Generated at 2022-06-25 05:08:51.587176
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_0 = Conditional()


# Generated at 2022-06-25 05:09:00.433392
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy

    t = Templar(vars={})
    conditional = Conditional()
    assert conditional.evaluate_conditional(t, {}) is True

    for v in [False, 'False', 'false', 'no', 'n', '0', 0, 0.0, '', 'None', 'none', None]:
        assert conditional.evaluate_conditional(t, {'var': v}) is False

    for v in [True, 'True', 'true', 'yes', 'y', '1', 1, 1.0]:
        assert conditional.evaluate_conditional(t, {'var': v}) is True


# Generated at 2022-06-25 05:09:08.662830
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    test_conditional_1 = 'var1 | int > var2'
    test_ds_1 = {'var1': '1.1', 'var2': '2.2'}
    test_context_1 = {'var1': '1.1', 'var2': '2.2'}
    test_env_1 = {'var1': '1.1', 'var2': '2.2'}


# Generated at 2022-06-25 05:09:18.978992
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_1 = Conditional()
    conditional_2 = Conditional()
    conditional_3 = Conditional()
    conditional_4 = Conditional()
    conditional_5 = Conditional()
    conditional_6 = Conditional()
    conditional_7 = Conditional()
    conditional_8 = Conditional()

    conditional_0.__init__()
    conditional_0._check_conditional(value="string", templar=conditional_1, all_vars=conditional_2)
    conditional_0._validate_when(attr=conditional_2, name="name", value="string")
    conditional_0.evaluate_conditional(templar=conditional_1, all_vars=conditional_2)
    conditional_0.extract_defined_undefined(conditional="string")

# Generated at 2022-06-25 05:09:28.045775
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()

    # test with valid conditional statements
    result = conditional_1.evaluate_conditional({}, "true")
    assert result == True

    result = conditional_1.evaluate_conditional({}, "false")
    assert result == False

    result = conditional_1.evaluate_conditional({"foo": True}, " foo ")
    assert result == True

    result = conditional_1.evaluate_conditional({"foo": True}, "foo and bar")
    assert result == False

    result = conditional_1.evaluate_conditional({"foo": True}, "foo or bar")
    assert result == True

    result = conditional_1.evaluate_conditional({"bar": True}, "foo and bar")
    assert result == False


# Generated at 2022-06-25 05:09:37.724596
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    conditional_0 = Conditional()
    conditional_0.when = "hostvars[inventory_hostname] == 'a.example.com' and hostvars[inventory_hostname] is defined"
    results = conditional_0.extract_defined_undefined(conditional_0.when)
    assert results == [('hostvars[inventory_hostname]', 'is', 'defined')]

    conditional_0.when = "hostvars[inventory_hostname] == 'a.example.com' and hostvars[inventory_hostname] is undefined"
    results = conditional_0.extract_defined_undefined(conditional_0.when)
    assert results == [('hostvars[inventory_hostname]', 'is', 'undefined')]


# Generated at 2022-06-25 05:11:17.082171
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    conditional_1.when = "this is empty"
    assert conditional_1.evaluate_conditional("templar", "all_vars") == True

# Generated at 2022-06-25 05:11:19.370391
# Unit test for constructor of class Conditional
def test_Conditional():
    try:
        test_case_0()
        print("Test Case 0: Constructor successful")
    except:
        print("Test Case 0: Constructor Failed")

if __name__ == "__main__":
    test_Conditional()

# Generated at 2022-06-25 05:11:25.238192
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # test case 0
    conditional_0 = Conditional()
    templar_0 = None
    all_vars_0 = dict()
    result_0 = conditional_0.evaluate_conditional(templar_0, all_vars_0)
    assert result_0 == True
    # test case 1
    conditional_1 = Conditional()
    conditional_1.when = [None]
    templar_1 = None
    all_vars_1 = dict()
    result_1 = conditional_1.evaluate_conditional(templar_1, all_vars_1)
    assert result_1 == True
    # test case 2
    conditional_2 = Conditional()
    conditional_2._loader = None
    conditional_2._ds = None
    conditional_2._attributes = dict()
    conditional

# Generated at 2022-06-25 05:11:28.680113
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class test_Conditional(Conditional):
        pass
    test_conditional = test_Conditional()
    test_conditional._when = ['2>3']
    test_conditional._loader = None
    templar = C.get_config(C.p, C.DEFAULTS, 'vars', secret=True)
    templar.set_available_variables(dict())
    test_conditional.evaluate_conditional(templar, dict())


# Generated at 2022-06-25 05:11:33.620900
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Test when var_name is not defined in ansible vars
    conditional_0 = Conditional()
    ansible_vars = {
            "var_name_1" : "var_value_1"
            }
    templar = Templar(loader=None, variables=ansible_vars)
    assert conditional_0.evaluate_conditional(templar, ansible_vars) == False

    # Test when var_name is defined in ansible vars
    ansible_vars = {
            "var_name_1" : "var_value_1",
            "var_name" : "var_value"
            }
    templar = Templar(loader=None, variables=ansible_vars)
    assert conditional_0.evaluate_conditional(templar, ansible_vars) == True



# Generated at 2022-06-25 05:11:37.007154
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Unit test for method evaluate_conditional of class Conditional
    '''

    conditional_0 = Conditional()
    templar_0 = Template()
    all_vars_0 = dict()
    assert conditional_0.evaluate_conditional(templar_0, all_vars_0)


# Generated at 2022-06-25 05:11:45.849264
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_1 = Conditional()
    conditional_2 = Conditional()
    conditional_3 = Conditional()
    conditional_4 = Conditional()
    conditional_5 = Conditional()

    # Test 1
    conditional_0.when = "hostvar['test'] not is defined or hostvar['test'] is defined"
    conditional_1.when = "hostvar['test'] not is defined or hostvar['test'] is not defined"
    conditional_2.when = "hostvar['test'] not is defined or hostvar['test'] is undefined"
    conditional_3.when = "hostvar['test'] not is defined or hostvar['test'] is not undefined"
    conditional_4.when = "hostvar['test'] is defined or hostvar['test'] is not defined"

# Generated at 2022-06-25 05:11:55.366009
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    result_1 = conditional_1.extract_defined_undefined("hostvars['foo'] is defined")
    assert [('hostvars[\'foo\']', 'is', 'defined')] == result_1, result_1
    result_2 = conditional_1.extract_defined_undefined("hostvars['foo'] not is undefined")
    assert [('hostvars[\'foo\']', 'not is', 'undefined')] == result_2, result_2
    result_3 = conditional_1.extract_defined_undefined("hostvars['foo'] is undefined and hostvars['bar'] not is defined")
    assert [('hostvars[\'foo\']', 'is', 'undefined'), ('hostvars[\'bar\']', 'not is', 'defined')]

# Generated at 2022-06-25 05:11:59.632093
# Unit test for constructor of class Conditional
def test_Conditional():
    try:
        test_case_0()
        res = True
    except Exception:
        res = False
    assert res, "Failed to construct a Conditional object"


# Generated at 2022-06-25 05:12:09.969070
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    conditional_0 = "foo and bar is defined"
    result = c.extract_defined_undefined(conditional_0)
    assert result[0][2] == 'defined'
    conditional_1 = "foo and bar is not defined"
    result = c.extract_defined_undefined(conditional_1)
    assert result[0][2] == 'undefined'
    conditional_2 = "foo and bar is defined or bar is defined"
    result = c.extract_defined_undefined(conditional_2)
    assert result[0][2] == 'defined'
    assert result[1][2] == 'defined'
