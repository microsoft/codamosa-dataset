

# Generated at 2022-06-25 05:03:36.610551
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = MockTemplar()
    all_vars_0 = dict()
    all_vars_0['hostvars'] = dict()
    conditional_1 = "hostvars['hostname'].stdout|bool"
    result_1 = conditional_0.evaluate_conditional(templar_0, all_vars_0)
    # assert result_1 == False
    conditional_2 = "hostvars['hostname'].stdout|bool and hostvars['hostname'].stdout|bool"
    result_2 = conditional_0.evaluate_conditional(templar_0, all_vars_0)
    # assert result_2 == False

# Generated at 2022-06-25 05:03:42.642400
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    l_0 = conditional_0.extract_defined_undefined("ansible_os_family  is  undefined  and  foo is defined")
    assert l_0 == [('ansible_os_family', 'is', 'undefined'), ('foo', 'is', 'defined')]
    l_0 = conditional_0.extract_defined_undefined("ansible_os_family  not  is  undefined  and  foo is defined")
    assert l_0 == [('ansible_os_family', 'not  is', 'undefined'), ('foo', 'is', 'defined')]
    l_0 = conditional_0.extract_defined_undefined("(ansible_os_family is undefined) and (foo is defined)")

# Generated at 2022-06-25 05:03:43.563059
# Unit test for constructor of class Conditional
def test_Conditional():
    test_case_0()


# Generated at 2022-06-25 05:03:51.147974
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.helpers import load_list_of_blocks
    conditional_1 = Conditional()
    conditional_1.when = load_list_of_blocks("""
    "{{ foo is defined and foo }}"
    "{{ bar is defined and bar }}"
    "{{ baz is undefined and not baz }}"
    """, [('condition', 1)])
    extr_1 = conditional_1.extract_defined_undefined(conditional_1.when[0])
    assert(extr_1[0][0] == 'foo')
    assert(extr_1[0][1] == 'is')
    assert(extr_1[0][2] == 'defined')
    assert(extr_1[1][0] == 'bar')

# Generated at 2022-06-25 05:04:01.256468
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-25 05:04:12.894934
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    # test "hostvars[inventory_hostname] not is defined"
    conditional_1 = Conditional()
    result_1 = conditional_1.extract_defined_undefined("hostvars[inventory_hostname] not is defined")
    assert result_1 == [('hostvars[inventory_hostname]', 'not', 'defined')]

    # test "hostvars[inventory_hostname] not is undefined"
    conditional_2 = Conditional()
    result_2 = conditional_2.extract_defined_undefined("hostvars[inventory_hostname] not is undefined")
    assert result_2 == [('hostvars[inventory_hostname]', 'not', 'undefined')]

    # test "hostvars[inventory_hostname] is defined"
    conditional_3 = Conditional()
    result_3

# Generated at 2022-06-25 05:04:17.203863
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    assert conditional_0.evaluate_conditional(templar=None, all_vars=None)


# Generated at 2022-06-25 05:04:26.698568
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    conditional_2 = Conditional()
    conditional_3 = Conditional()
    conditional_4 = Conditional()
    conditional_5 = Conditional()

    result_1 = conditional_1.extract_defined_undefined('{{ foo is defined and foo == "bar" }}')
    assert result_1 == [('foo', 'is', 'defined')]

    result_2 = conditional_2.extract_defined_undefined('{{ foo is not defined and bar == "baz" }}')
    assert result_2 == [('foo', 'is', 'undefined')]

    result_3 = conditional_3.extract_defined_undefined('{{ hostvars[play_hosts[0]] is defined }}')

# Generated at 2022-06-25 05:04:32.134691
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    mock_templar = type('', (), {})()
    conditional_0 = Conditional()
    conditional_0.when = ['foo']
    mock_templar.template = lambda x, y: 'foo';
    mock_templar.is_template = lambda x: False
    conditional_0.evaluate_conditional(mock_templar, {'foo': 'bar'})


# Generated at 2022-06-25 05:04:33.173239
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()

    # eval_conditional_0 = conditional_0.evaluate_conditional()



# Generated at 2022-06-25 05:04:54.262128
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    conditional_str = "foo.bar is defined or (lala is defined and not lala)"
    result = conditional_1.extract_defined_undefined(conditional_str)
    assert result[0][0] == 'foo.bar'
    assert result[0][1] == 'is'
    assert result[0][2] == 'defined'
    assert result[1][0] == 'lala'
    assert result[1][1] == 'is'
    assert result[1][2] == 'defined'


# Generated at 2022-06-25 05:05:05.887490
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # __init__() and _validate_when() are not covered here
    # because they are not called explicitly.
    conditional_1 = Conditional()
    conditional_1._when = ['defined foo or bar']

    test_conditional_1 = conditional_1.extract_defined_undefined('defined foo or bar')
    if test_conditional_1[0][0] == 'foo' and test_conditional_1[0][1] == 'is' and test_conditional_1[0][2] == 'defined' and len(test_conditional_1) == 1:
        test_case_1 = True
    else:
        test_case_1 = False

    conditional_2 = Conditional()

# Generated at 2022-06-25 05:05:07.769276
# Unit test for constructor of class Conditional
def test_Conditional():
    test_passed = False
    test_case_0()
    test_passed = True

# Generated at 2022-06-25 05:05:15.099439
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()

    conditional_0.when = ['{{ test1 == 3 }}']
    assert conditional_0.extract_defined_undefined("{{ test1 == 3}}") == []

    conditional_0.when = ['{{ test1 is defined }}']
    assert conditional_0.extract_defined_undefined("{{ test1 is defined}}") == [('test1', 'is', 'defined')]

    conditional_0.when = ['{{ test1 is not defined }}']
    assert conditional_0.extract_defined_undefined("{{ test1 is not defined}}") == [('test1', 'is not', 'defined')]

    conditional_0.when = ['{{ test1 is defined }} and {{ test2 is defined }}']

# Generated at 2022-06-25 05:05:26.081757
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditionals = [
        "a is undefined",
        "a is defined",
        "var is undefined",
        "var is not undefined",
        "var is defined",
        "var is not defined",
        "hostvars['inventory_hostname'] is undefined",
        "hostvars['inventory_hostname'] is defined",
        "hostvars['inventory_hostname'] is not undefined",
        "hostvars['inventory_hostname'] is not defined",
    ]


# Generated at 2022-06-25 05:05:28.260603
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    templar_1 = templar(loader)
    vars_1 = dict()
    conditional_1.evaluate_conditional(templar_1, vars_1)


# Generated at 2022-06-25 05:05:30.412319
# Unit test for constructor of class Conditional
def test_Conditional():
    assert test_case_0() == None, "test_case_0()"


# Generated at 2022-06-25 05:05:38.189258
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    templar_1 = Templar()
    all_vars_1 = {}
    conditional_1._check_conditional("{%raw%}variable{%endraw%} == 'test'", templar_1, all_vars_1)
    conditional_2 = Conditional()
    templar_2 = Templar()
    all_vars_2 = {}
    conditional_2._check_conditional("'test' == 'test'", templar_2, all_vars_2)      
    conditional_3 = Conditional()
    templar_3 = Templar()
    all_vars_3 = {}
    conditional_3._check_conditional("'test'|string == 'test'", templar_3, all_vars_3)
    conditional_4

# Generated at 2022-06-25 05:05:39.813200
# Unit test for constructor of class Conditional
def test_Conditional():
	conditional_0 = Conditional()
	assert conditional_0



# Generated at 2022-06-25 05:05:41.936085
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    mock_templar_0 = {}
    mock_all_vars_0 = {}
    var_ret_0 = conditional_0.evaluate_conditional(mock_templar_0, mock_all_vars_0)
    assert var_ret_0 == True

# Generated at 2022-06-25 05:06:15.446319
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    templar_1 = Conditional()
    all_vars_1 = Conditional()
    conditional_1.when = list()
    result_1 = conditional_1.evaluate_conditional(templar=templar_1, all_vars=all_vars_1)
    assert result_1



# Generated at 2022-06-25 05:06:22.501163
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # test without defining variable in conditional
    test_conditional_1 = Conditional()
    conditional = "localhost"
    assert test_conditional_1.extract_defined_undefined(conditional) == []

    # test with defined variable in conditional
    test_conditional_2 = Conditional()
    conditional = "localhost is defined"
    assert test_conditional_2.extract_defined_undefined(conditional) == [('localhost', 'is', 'defined')]
    conditional = "localhost is not defined"
    assert test_conditional_2.extract_defined_undefined(conditional) == [('localhost', 'is', 'not')]

    # test with undefined variable in conditional
    test_conditional_3 = Conditional()
    conditional = "localhost is undefined"
    assert test_conditional_3.extract_

# Generated at 2022-06-25 05:06:29.001134
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    # Setup test data
    conditional = Conditional()
    conditional.when = ["foo is defined", "bar not is undefined"]
    result = conditional.extract_defined_undefined(conditional.when[0])

    assert result[0][0] == 'foo'
    assert result[0][1] == 'is'
    assert result[0][2] == 'defined'

    result = conditional.extract_defined_undefined(conditional.when[1])

    assert result[0][0] == 'bar'
    assert result[0][1] == 'not is'
    assert result[0][2] == 'undefined'

# Generated at 2022-06-25 05:06:35.017037
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()

    conditional_1 = "hostvars['host_name'] is defined"
    result_1 = conditional_0.extract_defined_undefined(conditional_1)
    assert result_1 == [('hostvars[\'host_name\']', 'is', 'defined')]

    conditional_2 = "hostvars['host_name'] is undefined or hostvars['inventory_hostname'] is defined"
    result_2 = conditional_0.extract_defined_undefined(conditional_2)
    assert result_2 == [('hostvars[\'host_name\']', 'is', 'undefined'), ('hostvars[\'inventory_hostname\']', 'is', 'defined')]


# Generated at 2022-06-25 05:06:38.549203
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    class TestClass(object):
        pass

    tc = TestClass()
    conditional_1 = Conditional(loader=None)

    try:
        conditional_1.evaluate_conditional(tc, None)
    except Exception as e:
        assert(str(e) == "a loader must be specified when using Conditional() directly")


# Generated at 2022-06-25 05:06:44.563976
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    assert conditional_1.extract_defined_undefined('hostvars[inventory_hostname] is undefined') == [('hostvars[inventory_hostname]', 'is', 'undefined')]


# Generated at 2022-06-25 05:06:48.598126
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    # Create a Conditional object
    class B:
        pass
    conditional = Conditional(loader=B)

    # Test that the function returns the expected value
    assert conditional.extract_defined_undefined("(test1 is not defined) and (test2 is defined)") == [('test1', 'is not', 'defined'),
                                                                                                     ('test2', 'is', 'defined')]


# Generated at 2022-06-25 05:06:53.942648
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    #created class object
    conditional_0 = Conditional()
    ansible_1 = {'vars': {'var_0': 'a dummy value'}}
    assert conditional_0.evaluate_conditional(ansible_1, {'var_0': 'a dummy value'}) == True


# Generated at 2022-06-25 05:06:56.597354
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    assert(conditional.when is not None)


# Generated at 2022-06-25 05:07:03.822272
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Test Variables
    conditional_0 = Conditional()
    conditional_1 = Conditional()
    conditional_2 = Conditional()
    conditional_3 = Conditional()
    conditional_4 = Conditional()
    conditional_5 = Conditional()

    assert conditional_0.evaluate_conditional("True", False) == True
    assert conditional_1.evaluate_conditional("False", False) == False
    assert conditional_2.evaluate_conditional("a.b.c.d", True) == True
    assert conditional_3.evaluate_conditional("a.b.c.d", False) == False
    assert conditional_4.evaluate_conditional("None", True) == True
    assert conditional_5.evaluate_conditional("None", False) == False

# Generated at 2022-06-25 05:07:34.553137
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar = templar_0 = dict()
    all_vars = all_vars_0 = dict()
    assert conditional_0.evaluate_conditional(templar_0, all_vars_0) == True


# Generated at 2022-06-25 05:07:38.149662
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    assert conditional_0.evaluate_conditional(None, None) == True


# Generated at 2022-06-25 05:07:40.999191
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    try:
        instance = Conditional()

        templar = templar()
        instance.evaluate_conditional(templar)
        assert True
    except:
        assert False


# Generated at 2022-06-25 05:07:47.910779
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    conditional_0.when = ["var_0==False"]
    assert conditional_0.evaluate_conditional(self) == False
    conditional_0.when = ["var_0==False"]
    assert conditional_0.evaluate_conditional(self) == False
    conditional_0.when = ["var_0==False"]
    assert conditional_0.evaluate_conditional(self) == False
    conditional_0.when = ["var_1==False"]
    assert conditional_0.evaluate_conditional(self) == False
    conditional_0.when = ["var_0==False"]
    assert conditional_0.evaluate_conditional(self) == False
    conditional_0.when = ["var_1==False"]
    assert conditional_0.evaluate_conditional(self) == False
    conditional_0

# Generated at 2022-06-25 05:07:50.533992
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    all_vars = dict()
    result_1 = conditional_1.evaluate_conditional(templar={}, all_vars={})
    assert result_1 == True


# Generated at 2022-06-25 05:07:56.000523
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    try:
        conditional_0.evaluate_conditional(templar, all_vars)
    except:
        pass

    try:
        conditional_0.evaluate_conditional(templar, all_vars)
    except:
        pass

    try:
        conditional_0.evaluate_conditional(templar, all_vars)
    except:
        pass



# Generated at 2022-06-25 05:08:02.930863
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_0.extract_defined_undefined('hostvars[inventory_hostname] is defined and hostvars[inventory_hostname] == "test"')
    conditional_0.extract_defined_undefined('hostvars[inventory_hostname] is not defined')
    conditional_0.extract_defined_undefined('hostvars[inventory_hostname] is not undefined')
    conditional_0.extract_defined_undefined('hostvars[inventory_hostname] is undefined')
    conditional_0.extract_defined_undefined('rbac_role == "all"')
    conditional_0.extract_defined_undefined('rbac_role is defined and rbac_role == "all"')

# Generated at 2022-06-25 05:08:12.553422
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional = Conditional()

    # test_data is a list of tuples.
    #  In each tuple: First value is the when condition that should be tested,
    #  Second value is the value of the 'all_vars' parameter that should be
    #  used when calling method evaluate_conditional of class Conditional
    #  Third value is the expected output of the method evaluate_conditional
    #  when the given inputs are supplied.
    #
    # test_data is a list and not a dictionary, so that the tests can be run
    # in a deterministic order.

# Generated at 2022-06-25 05:08:19.634387
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_0.when = '{{ foo is defined and foo is not none and foo is not bar }}'
    conditional_0.evaluate_conditional(conditional_0, None)
    assert conditional_0.extract_defined_undefined('{{  foo  is  defined }}') == [('foo', 'is', 'defined')]
    assert conditional_0.extract_defined_undefined('{{ foo is not defined and x is y }}') == [('foo', 'is', 'defined'), ('x', 'is', 'y')]
    assert conditional_0.extract_defined_undefined('{{ foo is undefined and x is y }}') == [('foo', 'is', 'undefined'), ('x', 'is', 'y')]

# Generated at 2022-06-25 05:08:23.280566
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Check if the method evaluate_conditional of the Conditional class returns expected value
    instance = Conditional()
    if not isinstance(instance.evaluate_conditional(instance, instance), bool):
        raise AssertionError()


# Generated at 2022-06-25 05:09:31.075702
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    templar_1 = 'templar_1'
    all_vars_1 = 'all_vars_1'
    assert conditional_1.evaluate_conditional(templar_1, all_vars_1) == 1


# Generated at 2022-06-25 05:09:39.496767
# Unit test for constructor of class Conditional
def test_Conditional():
    print("Testing Conditional()")
    try:
        test_case_0()
    except Exception as e:
        print("Test Case 0 FAILED: " + str(e))
        return 1
    print("Test Case 0 PASSED")
    return 0

# Collect all test cases in this class
testcases_Conditional = [
    test_Conditional
]

# Collect all test classes in this file
testclasses_all = [
    Conditional
]


# Generated at 2022-06-25 05:09:48.685791
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Create instance of class Conditional
    conditional_0 = Conditional()

    # Retrieve data from ansible/test/units/modules/utilities/test_conditional.py
    data = dict(defined_0='defined_0')

    # Retrieve data from ansible/test/units/modules/utilities/test_conditional.py
    conditional_1 = 'defined_1'

    # Create instance of class Conditional
    conditional_2 = Conditional()

    # Call method extract_defined_undefined of class Conditional
    output = conditional_2.extract_defined_undefined(conditional_1)

    # Check that output from method extract_defined_undefined is equal to data from ansible/test/units/modules/utilities/test_conditional.py
    assert output == data


# Generated at 2022-06-25 05:09:51.019634
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    conditional_0.when = conditional_0.when + ["None"]
    conditional_0.evaluate_conditional()

# Generated at 2022-06-25 05:10:00.855545
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    c = Conditional()

    l = c.extract_defined_undefined("1 == 1")
    assert not l, "Failed test #0"

    l = c.extract_defined_undefined("foo is defined")
    assert len(l) == 1 and l[0] == ("foo", "is", "defined"), "Failed test #1"

    l = c.extract_defined_undefined("foo is defined and bar is not defined")
    assert len(l) == 2 and l[0] == ("foo", "is", "defined") and l[1] == ("bar", "is not", "defined"), "Failed test #2"

    l = c.extract_defined_undefined("hostvars['inventory_hostname'] is defined")

# Generated at 2022-06-25 05:10:05.992214
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    all_vars = {'var_2': 10, 'var_1': 10}
    all_vars['var_1'] = '1234'
    templar = templar_from_file('lib/ansible/playbook/conditional.py')
    conditional_0 = Conditional()
    conditional_0.when = ['{{ var_1 == var_2 }}']
    # given
    display.verbosity = 3
    # when
    result = conditional_0.evaluate_conditional(templar, all_vars)
    # then
    assert result



# Generated at 2022-06-25 05:10:11.009801
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()

    # settings for local test environment, need to be overwritten by TestRunner
    settings = {"loop_control": C.DEFAULT_LOOP_CONTROL, "magic_variables": C.MAGIC_VARIABLES}

    conditional._load_settings(settings)
    conditional._init_global_env()

    # test ordinary when condition
    conditional.when = ['true_var']
    all_vars = {'true_var': True}
    templar = conditional._templar
    result = conditional.evaluate_conditional(templar, all_vars)
    assert(result)

    conditional.when = ['true_var and true_var']
    all_vars = {'true_var': True}
    templar = conditional._templar
    result = conditional.evaluate

# Generated at 2022-06-25 05:10:18.793772
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test with no when clause.
    data = dict(test_data0, when=None)
    conditional_0 = Conditional()
    for key,value in data.items():
        setattr(conditional_0, key, value)
    assert conditional_0.evaluate_conditional(templar, all_vars)

    # Test with empty when clause
    data = dict(test_data0, when=list())
    conditional_1 = Conditional()
    for key,value in data.items():
        setattr(conditional_1, key, value)
    assert conditional_1.evaluate_conditional(templar, all_vars)

    # Test with conditional False
    data = dict(test_data0, when=[0])
    conditional_2 = Conditional()

# Generated at 2022-06-25 05:10:28.517686
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()

    templar_0 = Conditional.evaluate_conditional(conditional_0, "{{ (1, 1) | max }}", "{{ ((1, 1) | max) | from_json }}")
    assert templar_0 == True

    templar_1 = Conditional.evaluate_conditional(conditional_0, "{{ (1, 1) | max }}", "{{ (1, 1) | max }}")
    assert templar_1 == True

    templar_2 = Conditional.evaluate_conditional(conditional_0, "{{ (1, 1) | max }}", "{{ ((1, 1) | max) | to_json }}")
    assert templar_2 == True


# Generated at 2022-06-25 05:10:33.092520
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()

    templar = object()
    all_vars = object()
    res = conditional.evaluate_conditional(templar, all_vars)

    assert res == True
