

# Generated at 2022-06-25 05:03:31.949104
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar = AnsibleTemplar()
    var = {u"foo": u"bar"}
    result = conditional_0.evaluate_conditional(templar,var)
    # this assertion should work but does not pass
    assert result==True
    

# Generated at 2022-06-25 05:03:37.060582
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    templar = templar_to_use()
    all_vars = dict()

    conditional.when = ['foo == "bar"']
    all_vars['foo'] = "bar"
    assert conditional.evaluate_conditional(templar, all_vars) is True

    conditional.when = ['foo == "bar"']
    all_vars['foo'] = "not bar"
    assert conditional.evaluate_conditional(templar, all_vars) is False

    conditional.when = ['foo == "bar"']
    all_vars['foo'] = "not bar"
    assert conditional.evaluate_conditional(templar, all_vars) is False

    conditional.when = ['foo is not defined']
    all_vars['foo'] = "not bar"


# Generated at 2022-06-25 05:03:47.334718
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def_undef_0 = Conditional().extract_defined_undefined('foo is undefined')
    assert def_undef_0 == [('foo', 'is', 'undefined')]
    def_undef_1 = Conditional().extract_defined_undefined('foo not is undefined')
    assert def_undef_1 == [('foo', 'not is', 'undefined')]
    def_undef_2 = Conditional().extract_defined_undefined('foo is not undefined')
    assert def_undef_2 == [('foo', 'is not', 'undefined')]
    def_undef_3 = Conditional().extract_defined_undefined('foo is defined')
    assert def_undef_3 == [('foo', 'is', 'defined')]
    def_undef_4 = Conditional().ext

# Generated at 2022-06-25 05:03:58.376974
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    conditional_0 = Conditional()

    conditional_1 = conditional_0.extract_defined_undefined("foo is defined and bar is not defined")
    assert conditional_1 == [('foo', 'is', 'defined'), ('bar', 'is not', 'defined')]

    conditional_2 = conditional_0.extract_defined_undefined("foo is not defined and bar is defined")
    assert conditional_2 == [('foo', 'is not', 'defined'), ('bar', 'is', 'defined')]

    conditional_3 = conditional_0.extract_defined_undefined("foo is defined")
    assert conditional_3 == [('foo', 'is', 'defined')]

    conditional_4 = conditional_0.extract_defined_undefined("foo is not defined")

# Generated at 2022-06-25 05:04:05.253095
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    result_1 = conditional_1.evaluate_conditional(conditional_1, conditional_1)
    assert result_1 == True
    conditional_2 = Conditional()
    result_2 = conditional_2.evaluate_conditional(conditional_2, conditional_2)
    assert result_2 == True
    conditional_3 = Conditional()
    result_3 = conditional_3.evaluate_conditional(conditional_3, conditional_3)
    assert result_3 == True
    conditional_4 = Conditional()
    result_4 = conditional_4.evaluate_conditional(conditional_4, conditional_4)
    assert result_4 == True
    conditional_5 = Conditional()
    result_5 = conditional_5.evaluate_conditional(conditional_5, conditional_5)

# Generated at 2022-06-25 05:04:15.681697
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    # hostvars['hostname'].os == 'Ubuntu'
    conditional_1 = conditional_0.extract_defined_undefined("hostvars['hostname'].os == 'Ubuntu'")
    assert (conditional_1 == [])

    # hostvars['hostname'].os == 'Ubuntu' and foo.bar is defined
    conditional_1 = conditional_0.extract_defined_undefined("hostvars['hostname'].os == 'Ubuntu' and foo.bar is defined")
    assert (conditional_1 == [['foo.bar', 'is', 'defined']])

    # hostvars['hostname'].os == 'Ubuntu' or foo == 'test' and bar is defined and hostvars['example'].test is not undefined

# Generated at 2022-06-25 05:04:21.531047
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    ##########################################################################
    # when: foo
    ##########################################################################
    conditional_0 = Conditional()
    conditional_0.when = ["foo"]
    res = conditional_0.evaluate_conditional(templar=None, all_vars=None)
    assert res is False, res

    ##########################################################################
    # when: 1
    ##########################################################################
    conditional_1 = Conditional()
    conditional_1.when = [1]
    res = conditional_1.evaluate_conditional(templar=None, all_vars=None)
    assert res is True, res

    ##########################################################################
    # when: 0
    ##########################################################################
    conditional_2 = Conditional()
    conditional_2.when = [0]
    res = conditional_2.evaluate_conditional

# Generated at 2022-06-25 05:04:31.082881
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    conditional_1 = Conditional()
    conditional_2 = Conditional()
    conditional_3 = Conditional()
    conditional_4 = Conditional()

    # test evaluate_conditional
    assert conditional_0.evaluate_conditional() == True
    assert conditional_1.evaluate_conditional() == True
    assert conditional_2.evaluate_conditional() == True
    assert conditional_3.evaluate_conditional() == True
    assert conditional_4.evaluate_conditional() == True

if __name__ == "__main__":
    test_case_0()
    test_Conditional_evaluate_conditional()

# Generated at 2022-06-25 05:04:36.461809
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_result = conditional_0.extract_defined_undefined('( hostvars[inventory_hostname].os.distribution == "RedHat" ) and ( ansible_distribution_major_version | int >= 7 )')
    assert conditional_result == [('hostvars[inventory_hostname].os.distribution', '==', 'defined'), ('ansible_distribution_major_version', 'is', 'defined')]



# Generated at 2022-06-25 05:04:40.505290
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = MockTemplar()
    conditional_0.when = ['when_0']
    conditional_0._check_conditional = Mock__check_conditional()
    all_vars_0 = {('all_vars_0', 0): 'all_vars_1'}
    result = conditional_0.evaluate_conditional(templar_0, all_vars_0)


# Generated at 2022-06-25 05:05:00.550617
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    # Test extract defined_undefine for conditionals with defined/undefined varibales
    conditional_1 = Conditional()
    cond = "hostvars['ansible_default_ipv4']['address'] is defined or (ansible_fqdn is defined and 'autoscale' in ansible_fqdn)"
    result = conditional_1.extract_defined_undefined(cond)
    assert result == [(u"hostvars['ansible_default_ipv4']['address']", u'is', u'defined'), (u'ansible_fqdn', u'is', u'defined')]

    # Test extract defined_undefine for conditionals with defined/undefined varibales in parentheses
    conditional_2 = Conditional()

# Generated at 2022-06-25 05:05:10.031576
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    my_conditional = Conditional()

    # Test evaluate_conditional with empty variable
    if not my_conditional.evaluate_conditional("", {}):
        raise Exception("Conditional.evaluate_conditional() test 0 failed")

    # Test evaluate_conditional with existing variable
    if not my_conditional.evaluate_conditional("groups['foo']", {'groups': {'foo': True, 'bar': False}}):
        raise Exception("Conditional.evaluate_conditional() test 1 failed")

    # Test evaluate_conditional with non existing variable
    if not my_conditional.evaluate_conditional("groups['foo']", {'groups': {'bar': False}}):
        raise Exception("Conditional.evaluate_conditional() test 2 failed")

    # Test evaluate_conditional with non existing variable and undefined_var_behavior=allow_no_

# Generated at 2022-06-25 05:05:19.560131
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('a is defined') == [('a', 'is', 'defined')]
    assert conditional.extract_defined_undefined('a is not defined') == [('a', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('a is undefined') == [('a', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('a is not undefined') == [('a', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined('a is not defined and b is not defined') == [('a', 'is not', 'defined'), ('b', 'is not', 'defined')]

# Generated at 2022-06-25 05:05:27.507831
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    ensure any user variables, when templated in the conditional, work properly
    '''
    conditional_0 = Conditional()
    conditional_0.when = [u'{{ enable_backups }}']
    templar_0 = AnsibleMock()
    all_vars_0 = {}
    assert conditional_0.evaluate_conditional(templar_0, all_vars_0)
    templar_0 = AnsibleMock()
    all_vars_0 = {u'enable_backups': False}
    assert conditional_0.evaluate_conditional(templar_0, all_vars_0)


# Generated at 2022-06-25 05:05:31.044724
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    loaded_conditional = conditional
    assert conditional.evaluate_conditional(loaded_conditional, True) == True

# Generated at 2022-06-25 05:05:35.779840
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    conditional = "ansible_os_family == 'RedHat' and server_port is defined and (server_port is not defined or server_ssl is true)"
    expected_results = [
        ('server_port', 'is', 'defined'),
        ('server_port', 'is', 'undefined')
    ]
    assert expected_results == c.extract_defined_undefined(conditional)


# Generated at 2022-06-25 05:05:45.974094
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()

    assert [("hostvars", "is", "defined")] == conditional_0.extract_defined_undefined("hostvars is defined")
    assert [("hostvars['foo']['bar']", "is", "undefined")] == conditional_0.extract_defined_undefined("hostvars['foo']['bar'] is undefined")
    assert [("hostvars", "is", "defined")] == conditional_0.extract_defined_undefined("hostvars     is     defined")
    assert [("hostvars", "is", "defined"), ("something", "not is", "undefined")] == conditional_0.extract_defined_undefined("hostvars is defined and something not is undefined")


# Generated at 2022-06-25 05:05:56.115971
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # In case of AnsibleUndefinedVariable exception
    setattr(test_case_0, 'when', ['x'])
    try:
        conditional_0.evaluate_conditional(template, {'y'})
    except AnsibleUndefinedVariable as e:
        print(e)

    # In case of default True
    setattr(test_case_0, 'when', ['True'])
    assert conditional_0.evaluate_conditional(template, {'y'})

    # In case when is 'bool'
    setattr(test_case_0, 'when', [True])
    assert conditional_0.evaluate_conditional(template, {'y'})

    # In case of no hostvars
    setattr(test_case_0, 'when', ['hostvars'])

# Generated at 2022-06-25 05:05:59.190190
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar = None
    all_vars = None
    result = conditional_0.evaluate_conditional(templar, all_vars)
    assert result is True


# Generated at 2022-06-25 05:05:59.878994
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_0 = Conditional()


# Generated at 2022-06-25 05:06:32.721082
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    templar = Templar()
    conditional = Conditional()
    all_vars = dict()
    conditional.when = list()
    result = conditional.evaluate_conditional(templar, all_vars)
    expected_result = True
    assert result == expected_result, 'Expected: %s but got: %s' % (expected_result, result)

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-25 05:06:40.852297
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    templar_1 = Templar(loader=None, variables={'inventory_hostname': 'foo'})
    all_vars_1 = {u'inventory_hostname': u'foo'}
    result_1 = conditional_1.evaluate_conditional(templar_1, all_vars_1)
    assert result_1 == True



# Generated at 2022-06-25 05:06:42.771075
# Unit test for constructor of class Conditional
def test_Conditional():
    try:
        conditional_0 = Conditional()
        assert True == True
    except Exception as e:
        assert True == False, "unexpected Exception"


# Generated at 2022-06-25 05:06:45.289596
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    # assert evaluate_conditional of Conditional is True
    assert conditional_1.evaluate_conditional('', ''), True

if __name__ == '__main__':
    test_case_0()
    test_Conditional_evaluate_conditional()

# Generated at 2022-06-25 05:06:53.429920
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    test_os=C.DEFAULT_BECOME_METHOD
    test_dir=C.DEFAULT_LOCAL_TMP
    test_remote_user=C.DEFAULT_REMOTE_USER
    test_connection=C.DEFAULT_TRANSPORT
    test_inventory=None
    test_playbook_path=None
    test_loader=None
    test_variable_manager=None
    conditional = Conditional()
    jinja_tmpl = '{{ ansible_os_family }}'
    templar = None
    # Case 1
    all_vars = dict(ansible_os_family = test_os)
    assert(conditional.evaluate_conditional(templar, all_vars) == True)
    # Case 2
    all_vars = dict()

# Generated at 2022-06-25 05:07:01.509402
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    conditional._ds = {'name': 'test_Conditional'}
    mock_templar = MockTemplar()
    mock_templar.template = MagicMock(return_value=True)
    conditional.when = 'test_content'
    all_vars = {'test_key': 'test_value'}
    assert conditional.evaluate_conditional(mock_templar, all_vars)
    assert not conditional.evaluate_conditional(mock_templar, all_vars)

# Generated at 2022-06-25 05:07:09.863977
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    test_case_0_vars = {}
    test_case_0_vars['hostvars'] = {}
    test_case_0_vars['hostvars']['ansible_check_mode'] = True
    test_case_0_result = Conditional().evaluate_conditional(None, test_case_0_vars)
    assert test_case_0_result == False


# Generated at 2022-06-25 05:07:12.243239
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    # conditional_0 = Conditional()

    # assert conditional_0.evaluate_conditional() == expected
    assert True == True



# Generated at 2022-06-25 05:07:21.261046
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    def test_case_1():
        conditional_1 = Conditional()
        assert conditional_1.evaluate_conditional(None, [ 'True' ]) == True

    def test_case_2():
        conditional_2 = Conditional()
        assert conditional_2.evaluate_conditional(None, [ 'False' ]) == False

    def test_case_3():
        conditional_3 = Conditional()
        assert conditional_3.evaluate_conditional(None, [ '' ]) == True

    def test_case_4():
        conditional_4 = Conditional()
        try:
            assert conditional_4.evaluate_conditional(None, [ None ])
        except:
            pass


# Unit tests for Conditional.extract_defined_undefined method

# Generated at 2022-06-25 05:07:28.092546
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    # FIXME: Refactor the method.
    # test success when a valid condition
    # conditional.when = True
    assert conditional.evaluate_conditional(conditional, []) == True
    assert conditional.evaluate_conditional(conditional, {'a': 'a'}) == True
    assert conditional.evaluate_conditional(conditional, [{'a': 'a'}]) == True

# FIXME: Method should be refactored to make it unit testable.

# Generated at 2022-06-25 05:08:52.388157
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    ds = getattr(conditional_0, '_ds')
    templar = None
    all_vars = None
    test_eval_conditional = conditional_0.evaluate_conditional(templar, all_vars)
    assert test_eval_conditional is None


# Generated at 2022-06-25 05:09:00.308757
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    conditional_1._ds = None
    conditional_1.when.append(True)
    conditional_1.when.append(False)
    conditional_1.when.append(False)
    conditional_1.when.append(True)
    conditional_1.when.append(False)
    conditional_1.when.append(True)
    conditional_1.when.append(False)
    conditional_1.when.append(True)
    conditional_1.when.append(False)
    conditional_1.when.append(True)
    conditional_1.when.append(False)
    conditional_1.when.append(True)
    conditional_1.when.append(False)
    conditional_1.when.append(True)
    conditional_1.when.append(False)
   

# Generated at 2022-06-25 05:09:08.368214
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_1 = Conditional()
    # Assert that the class Conditional has a field _when
    assert hasattr(conditional_1, '_when')
    # Assert that the class Conditional has a field _validate_when
    assert hasattr(conditional_1, '_validate_when')
    # Assert that the class Conditional has a method evaluate_conditional
    assert hasattr(conditional_1, 'evaluate_conditional')
    # Assert that the class Conditional has a method extract_defined_undefined
    assert hasattr(conditional_1, 'extract_defined_undefined')
    # Assert that the class Conditional has a method _check_conditional
    assert hasattr(conditional_1, '_check_conditional')


# Generated at 2022-06-25 05:09:14.804337
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    res = conditional.extract_defined_undefined('x is defined')
    assert len(res) == 1
    assert res[0][0] == 'x'
    assert res[0][1] == 'is'
    assert res[0][2] == 'defined'

    res = conditional.extract_defined_undefined('x is defined and y is defined and z is defined')
    assert len(res) == 3
    assert res[0][0] == 'x'
    assert res[0][1] == 'is'
    assert res[0][2] == 'defined'
    assert res[1][0] == 'y'
    assert res[1][1] == 'is'
    assert res[1][2] == 'defined'
    assert res[2][0] == 'z'


# Generated at 2022-06-25 05:09:17.883358
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    result_1 = conditional_1.evaluate_conditional('True', 'myhost')


# Generated at 2022-06-25 05:09:20.468413
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    conditional_0.when = ['']
    print(conditional_0.evaluate_conditional(None, None))



# Generated at 2022-06-25 05:09:29.051173
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()
    test_case_25()

# Generated at 2022-06-25 05:09:33.089929
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    conditional_0.when = ['false']
    templar_0 = Conditional()
    all_vars_0 = {}
    ansible_variable_0 = None
    # ansible_variable is not defined, so evaluate_conditional returns False
    # even if conditional is True
    assert conditional_0.evaluate_conditional(templar_0, all_vars_0) == False


# Generated at 2022-06-25 05:09:41.526674
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    
    test_str_0 = 'hostvars[inventory_hostname] == "blackbox"'
    
    conditional_0 = Conditional()
    result = conditional_0.extract_defined_undefined(test_str_0)
    assert len(result) == 0, "Conditional.extract_defined_undefined - result is not empty."
    
    test_str_1 = 'hostvars[inventory_hostname] is not defined'
    
    conditional_1 = Conditional()
    result = conditional_1.extract_defined_undefined(test_str_1)
    assert result[0][0] == 'hostvars[inventory_hostname]' and result[0][1] == 'is not' and result[0][2] == 'defined', "Conditional.extract_defined_undefined - unexpected result."

# Generated at 2022-06-25 05:09:50.344845
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    templar = None

# Generated at 2022-06-25 05:12:50.562473
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    input_0 = 'hostvars[inventory_hostname] is not defined and ansible_suse_version is defined'
    output_0 = [('hostvars[inventory_hostname]', 'not is', 'defined'), ('ansible_suse_version', 'is', 'defined')]
    assert conditional.extract_defined_undefined(input_0) == output_0, 'Conditional.extract_defined_undefined() returned incorrect value.'


# Generated at 2022-06-25 05:12:52.208730
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional(loader=None)
    res = conditional_0.evaluate_conditional(None, None)
    assert res == True



# Generated at 2022-06-25 05:12:58.342863
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    conditional_0._loader = None
    conditional_0.when = ['False']
    templar_0 = None
    all_vars_0 = None
    try:
        actual_0 = conditional_0.evaluate_conditional(templar_0, all_vars_0)
        assert False, "expected an exception"
    except Exception as e_0:
        assert e_0.args[0] == "a loader must be specified when using Conditional() directly"
    conditional_0 = Conditional()
    conditional_0._loader = None
    conditional_0.when = ['False']
    templar_0 = None
    all_vars_0 = {}

# Generated at 2022-06-25 05:13:05.453480
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    conditional_1._when = "hostvars['foo'] is defined and hostvars['fooz'] is not defined and my_var is not defined"
    assert conditional_1.extract_defined_undefined(conditional_1._when) == \
                                                                           [('hostvars[\'foo\']', 'is', 'defined'),
                                                                            ('hostvars[\'fooz\']', 'is not', 'defined'),
                                                                            ('my_var', 'is not', 'defined')]

# Generated at 2022-06-25 05:13:10.684010
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional_1 = Conditional()
    templar_1 = Conditional()
    all_vars_1 = Conditional()
    assert conditional_1.evaluate_conditional(templar_1, all_vars_1) == True

    conditional_1 = Conditional()
    conditional_1.when = [True,False]
    templar_1 = Conditional()
    all_vars_1 = Conditional()
    assert conditional_1.evaluate_conditional(templar_1, all_vars_1) == False


# Generated at 2022-06-25 05:13:18.666401
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

    assert c.extract_defined_undefined("hostvars['foo'] is undefined") == [('hostvars[\'foo\']', 'is', 'undefined')]
    assert c.extract_defined_undefined("hostvars['foo'] is not defined") == [('hostvars[\'foo\']', 'is not', 'defined')]
    assert c.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]