

# Generated at 2022-06-25 05:03:34.782072
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    Test case - extract_defined_undefined is not able to identify defined and
    undefined strings which starts and ends with same word.
    '''

    conditional_1 = Conditional()
    conditional_1.when = ["foo is defined and \"foo\" is defined"]
    extracted_list = conditional_1.extract_defined_undefined(conditional_1.when[0])
    assert extracted_list == [('foo', 'is', 'defined'), ('"foo"', 'is', 'defined')]

    '''
    Test case - extract_defined_undefined is not able to identify defined and
    undefined strings which contains spaces and starting and ending with same word.
    '''

    conditional_2 = Conditional()
    conditional_2.when = ["foo is defined and \"foo has spaces\" is defined"]
    extracted_list = conditional

# Generated at 2022-06-25 05:03:45.789643
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()

    # Test cases that should pass.
    assert conditional_0.extract_defined_undefined('ansible_os_family is linux') == [('ansible_os_family', 'is', 'linux')]
    assert conditional_0.extract_defined_undefined('ansible_os_family not is linux') == [('ansible_os_family', 'not is', 'linux')]
    assert conditional_0.extract_defined_undefined('ansible_os_family is not linux') == [('ansible_os_family', 'is not', 'linux')]
    assert conditional_0.extract_defined_undefined('ansible_os_family is defined') == [('ansible_os_family', 'is', 'defined')]
    assert conditional_0.extract_defined_undefined

# Generated at 2022-06-25 05:03:56.509067
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # test normal case
    all_vars = dict(foo=1, bar=2)
    conditional_1 = Conditional()
    conditional_1._loader = 'loader'
    templar = 'test'
    ret = conditional_1.evaluate_conditional(templar, all_vars)
    assert True == ret

    # test with empty list as when
    conditional_2 = Conditional()
    conditional_2._loader = 'loader'
    conditional_2._when = list()
    ret = conditional_2.evaluate_conditional(templar, all_vars)
    assert True == ret

    # test with conditional as None
    conditional_3 = Conditional()
    conditional_3._loader = 'loader'
    conditional_3._when = [None]

# Generated at 2022-06-25 05:04:01.314033
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    #
    # AnsibleUndefinedVariable exception will be raised.
    #
    conditional_0 = Conditional()
    assert conditional_0.evaluate_conditional(templar, all_vars) == False

    #
    # ValueError exception will be raised.
    #
    conditional_1 = Conditional()
    assert conditional_1.evaluate_conditional(templar, all_vars) == False

    #
    # AttributeError -> NameError -> TypeError exception will be raised.
    #
    conditional_2 = Conditional()
    assert conditional_2.evaluate_conditional(templar, all_vars) == False

    #
    # AttributeError -> NameError -> TypeError exception will be raised.
    #
    conditional_3 = Conditional()

# Generated at 2022-06-25 05:04:12.919854
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    test_value_1 = conditional_1.extract_defined_undefined('hostvars[inventory_hostname] is defined')
    test_value_2 = conditional_1.extract_defined_undefined('hostvars[inventory_hostname] is not defined')
    test_value_3 = conditional_1.extract_defined_undefined('hostvars[inventory_hostname] is undefined')
    test_value_4 = conditional_1.extract_defined_undefined('hostvars[inventory_hostname] is not undefined')
    test_value_5 = conditional_1.extract_defined_undefined('"blah" is defined')
    test_value_6 = conditional_1.extract_defined_undefined('"blah" is not defined')
    test_value_

# Generated at 2022-06-25 05:04:21.640295
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    """
    Test for method conditional.extract_defined_undefined
    """
    conditional_0 = Conditional()
    conditional_1 = Conditional()
    conditional_2 = Conditional()
    conditional_3 = Conditional()
    conditional_4 = Conditional()
    conditional_5 = Conditional()
    conditional_6 = Conditional()
    conditional_7 = Conditional()
    conditional_8 = Conditional()
    conditional_9 = Conditional()
    conditional_10 = Conditional()
    conditional_11 = Conditional()
    conditional_12 = Conditional()
    conditional_13 = Conditional()
    conditional_14 = Conditional()

    # Setup test 1
    conditional_1._loader = None
    conditional_1._ds = None

# Generated at 2022-06-25 05:04:27.051969
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    conditional_0.when = ['foo']
    templar_0 = object()
    all_vars_0 = {}
    assert conditional_0.evaluate_conditional(templar_0, all_vars_0) == True



# Generated at 2022-06-25 05:04:36.535998
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = templar_1 = templar_2 = templar_3 = templar_4 = templar_5 = templar_6 = templar_7 = templar_8 = templar_9 = templar_10 = templar_11 = templar_12 = templar_13 = templar_14 = templar_15 = templar_16 = templar_17 = templar_18 = templar_19 = templar_20 = templar_21 = templar_22 = templar_23 = templar_24 = templar_25 = templar_26 = templar_27 = templar_28 = templar_29 = templar_30 = templar

# Generated at 2022-06-25 05:04:42.882598
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    conditional_1_string = 'foo is defined'
    conditional_2_string = 'bar isnt undefined'
    conditional_3_string = 'hostvars["foo"] is undefined'
    conditional_4_string = 'hostvars[foo] isnt defined'
    assert conditional_1.extract_defined_undefined(conditional_1_string) == [('foo', 'is', 'defined')]
    assert conditional_1.extract_defined_undefined(conditional_2_string) == [('bar', 'isnt', 'undefined')]
    assert conditional_1.extract_defined_undefined(conditional_3_string) == [('hostvars["foo"]', 'is', 'undefined')]

# Generated at 2022-06-25 05:04:45.212935
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_1 = Conditional()
    assert conditional_0.extract_defined_undefined(conditional_1) == [], 'Test to extract defined undefined failed'
    assert conditional_1.extract_defined_undefined(conditional_1) == [], 'Test to extract defined undefined failed'


# Generated at 2022-06-25 05:05:04.692548
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # unit test for a simple case where we have 1 define in the string
    x = Conditional()
    results = x.extract_defined_undefined("hostvars['hostname'] is defined")
    assert results == [("hostvars['hostname']", "is", "defined")]


# Generated at 2022-06-25 05:05:12.562796
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    print('Test for method evaluate_conditional of class Conditional: ')
    # Test 1: set when as 1, check if evaluate_conditional returns True
    conditional_0 = Conditional()
    conditional_0._ds = {
        "filename": "test.yml",
        "lineno": 10,
        "task": "test",
        "when": 1
    }
    conditional = conditional_0.when
    templar = None
    all_vars = None
    assert conditional_0.evaluate_conditional(templar, all_vars) == True, 'Error: evaluate_conditional should return True'
    # Test 2: set when as 0, check if evaluate_conditional returns False
    conditional_1 = Conditional()

# Generated at 2022-06-25 05:05:22.148117
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Ensure that the evaluate_conditional method is working properly
    '''
    conditional_0 = Conditional()
    templar_0 = templar_1 = templar_2 = templar_3 = templar_4 = templar_5 = templar_6 = Templar(loader=Loader())
    all_vars_0 = {
    }
    conditional_0._check_conditional('foo', templar_5, all_vars_0)
    all_vars_1 = {
    }
    conditional_0._check_conditional('foo', templar_6, all_vars_1)

# Generated at 2022-06-25 05:05:32.649336
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    conditional_0 = 'foo is defined and bar is defined and baz is defined'
    conditional_1 = 'first is defined and second is defined and third is not defined'
    conditional_2 = 'a is undefined or b is undefined or c is not undefined'
    conditional_3 = 'last is undefined or second_last is undefined or third_last is not undefined'
    conditional_4 = 'hostvars[inventory_hostname] != "" and hostvars[inventory_hostname] != "unreachable"'
    conditional_5 = 'hostvars["{{ inventory_hostname }}"] != "" and hostvars["{{ inventory_hostname }}"] != "unreachable"'

    results_0 = [('foo', 'is', 'defined'), ('bar', 'is', 'defined'), ('baz', 'is', 'defined')]


# Generated at 2022-06-25 05:05:33.804541
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_0 = Conditional()


# Generated at 2022-06-25 05:05:44.695612
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-25 05:05:48.050591
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = templar()
    all_vars_0 = all_vars()
    actual = conditional_0.evaluate_conditional(templar_0, all_vars_0)
    expected = True
    assert actual == expected


# Generated at 2022-06-25 05:05:57.021668
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Test with a defined, undefined and when
    conditional_0 = Conditional()
    conditional_0.when = 'ansible_distribution is defined or ansible_hostname is undefined or ansible_distribution == "Debian"'
    assert conditional_0.extract_defined_undefined(conditional_0.when) == [('ansible_distribution', 'is', 'defined'), ('ansible_hostname', 'is', 'undefined')]
    # Test with only a defined
    conditional_1 = Conditional()
    conditional_1.when = 'ansible_distribution is defined'
    assert conditional_1.extract_defined_undefined(conditional_1.when) == [('ansible_distribution', 'is', 'defined')]
    # Test with only a undefined
    conditional_2 = Conditional()
    conditional_

# Generated at 2022-06-25 05:06:08.551500
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-25 05:06:13.604110
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Condition is None simply return true
    assert Conditional().evaluate_conditional(None, None)

    # Condition is empty string simply return true
    assert Conditional().evaluate_conditional(None, None, "")

    # Condition is boolean simply return the boolean
    assert not Conditional().evaluate_conditional(None, None, False)

    # Invalid conditional simply swallow the exception
    assert Conditional().evaluate_conditional(None, None, 'invalid_conditional')

    # Condition is valid simply return the boolean
    assert Conditional().evaluate_conditional(None, None, 'a == 2')



# Generated at 2022-06-25 05:06:46.353952
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()

    # Conditional tring of input 1
    conditional_0.extract_defined_undefined("'foo' is defined and hostvars[inventory_hostname] is not defined")
    return True


# Generated at 2022-06-25 05:06:51.467094
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Validates the conditional property parsing
    '''

    c = Conditional()

    display.display("Testing conditional property parsing")

    assert c.evaluate_conditional(True, []) == True
    assert c.evaluate_conditional(False, []) == False
    assert c.evaluate_conditional("{{foo}}", dict(foo=True)) == True
    assert c.evaluate_conditional("{{foo}}", dict(foo=False)) == False
    assert c.evaluate_conditional('{{foo is defined}}', dict(foo=True)) == True
    assert c.evaluate_conditional('{{foo is undefined}}', dict(foo=True)) == False
    assert c.evaluate_conditional('{{foo is defined}}', dict(foo=False)) == False

# Generated at 2022-06-25 05:06:57.738844
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    templar = None
    all_vars = []

    try:
        result = conditional_1.evaluate_conditional(templar, all_vars)
    except AnsibleError as e:
        print("The test_Conditional_evaluate_conditional failed with error: {0}".format(to_native(e)))
        raise
    else:
        if result == False:
            print("The test_Conditional_evaluate_conditional passed.")
        else:
            print("The test_Conditional_evaluate_conditional failed.")



# Generated at 2022-06-25 05:07:03.084730
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()

    test_str_0 = 'hostvars[inventory_hostname] is defined and hostvars[inventory_hostname] != ""'

    test_cases = [(test_str_0, ['hostvars[inventory_hostname]', 'is', 'defined'])]

    for test_str, expected_result in test_cases:
        result = conditional_0.extract_defined_undefined(test_str)
        assert result == expected_result, "Test Case Failed: Case %s. Expected '%s' found '%s'" % (test_str, expected_result, result)


# Generated at 2022-06-25 05:07:12.711313
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()

# Generated at 2022-06-25 05:07:22.187910
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    # Check defined variable
    conditional_1 = Conditional()
    conditional_1.when = ['a == 1']
    assert conditional_1.extract_defined_undefined(conditional_1.when) == [('a', '==', 'defined')]

    # Check defined variable with space
    conditional_2 = Conditional()
    conditional_2.when = ['b == 1']
    assert conditional_2.extract_defined_undefined(conditional_2.when) == [('b', '==', 'defined')]

    # Check defined variable with multiple spaces
    conditional_3 = Conditional()
    conditional_3.when = ['c     ==     1']
    assert conditional_3.extract_defined_undefined(conditional_3.when) == [('c', '==', 'defined')]

    # Check defined variable with

# Generated at 2022-06-25 05:07:30.735935
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Test 1: when conditionals:
    # (1) is defined;
    # (2) is undefined;
    # (3) is '{{ var1 }}'
    conditional_1 = Conditional()
    conditional_1.when = [
        "var1 is defined",
        "var1 is undefined",
        "var1 is '{{ var1 }}'",
    ]
    definitions_1 = conditional_1.extract_defined_undefined(conditional_1.when[0])
    assert definitions_1 == [['var1', 'is', 'defined']], 'Unexpected result: %s' % definitions_1
    definitions_1 = conditional_1.extract_defined_undefined(conditional_1.when[1])

# Generated at 2022-06-25 05:07:34.001211
# Unit test for constructor of class Conditional
def test_Conditional():
    try:
        conditional_0 = Conditional()
        display.display("test_Conditional: PASS")
    except Exception as e:
        display.display("test_Conditional: FAIL")



# Generated at 2022-06-25 05:07:43.344179
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    conditional_str_0 = "a is defined"
    conditional_str_1 = 'a is undefined'
    conditional_str_2 = 'a not is defined'
    assert conditional_1.extract_defined_undefined(conditional_str_0) == [('a', 'is', 'defined')]
    assert conditional_1.extract_defined_undefined(conditional_str_1) == [('a', 'is', 'undefined')]
    assert conditional_1.extract_defined_undefined(conditional_str_2) == [('a', 'not is', 'defined')]
    del conditional_1


# Generated at 2022-06-25 05:07:46.072996
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = None
    all_vars_0 = None
    result_0 = conditional_0.evaluate_conditional(templar_0, all_vars_0)
    assert result_0 == True


# Generated at 2022-06-25 05:09:08.074751
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_1 = Conditional()
    conditional_1.when = ['hostvars[inventory_hostname] is defined']
    conditional_2 = Conditional()
    conditional_2.when = [
        'ansible_os_family == "RedHat" and (ansible_distribution_major_version | int > 6)',
        'ansible_facts["distribution_major_version"] > 6',
        'ansible_facts["distribution_major_version"] > 6 and ansible_facts["distribution"] == "RedHat"',
        'ansible_facts["distribution"] == "RedHat" and ansible_facts["distribution_major_version"] > 6'
    ]
    conditional_3 = Conditional()

# Generated at 2022-06-25 05:09:15.357410
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    displayed = None
    captured = []
    class CaptureDisplay(object):
        def vv(self, msg, host=None):
            captured.append(msg)

    # Display is normally a singleton, so override it to test globally
    old_display = display

# Generated at 2022-06-25 05:09:20.033808
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional = 'hostvars["ansible_default_ipv4"]["address"] == inventory_hostname'
    results = conditional_0.extract_defined_undefined(conditional)
    print(results)


test_Conditional_extract_defined_undefined()

# Generated at 2022-06-25 05:09:28.626734
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional1 = Conditional()
    conditional_str1 = 'hostvars[foo] is defined and hostvars[bar] is not defined'
    result1 =[('hostvars[foo]','is','defined'),('hostvars[bar]','is','not defined')]
    assert conditional1.extract_defined_undefined(conditional_str1) == result1

    conditional2 = Conditional()
    conditional_str2 = 'hostvars[foo] is not defined'
    result2 = [('hostvars[foo]','is','not defined')]
    assert conditional2.extract_defined_undefined(conditional_str2) == result2

    conditional3 = Conditional()
    conditional_str3 = 'hostvars[foo] is defined'

# Generated at 2022-06-25 05:09:31.109749
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    assert conditional_0.evaluate_conditional(conditional='a==b', templar=templar, all_vars=None) == True

# Generated at 2022-06-25 05:09:33.652453
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Define None value for conditional
    conditional_0 = None

    # Call method
    conditional_0 = extract_defined_undefined(conditional_0)

    # Assert
    assert conditional_0 == None

# Generated at 2022-06-25 05:09:38.029918
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()

    conditional_1.when = [u'a == 1']
    conditional_1.vars = {u'a' : '1'}
    conditional_1.evaluate_conditional(None, conditional_1.vars)


# Generated at 2022-06-25 05:09:43.516931
# Unit test for constructor of class Conditional
def test_Conditional():
    #tests case where no parameters are given
    conditional_0 = Conditional()
    #tests case where valid parameters are given
    conditional_1 = Conditional(loader=4)
    #tests case where invalid parameters are given
    try:
        conditional_2 = Conditional(loader="foo")
    except AnsibleError:
        pass


# Generated at 2022-06-25 05:09:45.383107
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    templar = FakeTemplar()
    results = conditional.evaluate_conditional(templar, {})
    assert results == ''



# Generated at 2022-06-25 05:09:50.415585
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    expected_result = [('hostvars[inventory_hostname]', 'is', 'defined')]
    conditional = Conditional().extract_defined_undefined('hostvars[inventory_hostname] is defined')
    assert conditional == expected_result, 'Extracted result %s does not match expected result %s'\
                                            %(conditional, expected_result)


# Generated at 2022-06-25 05:12:12.103717
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    conditional_1.when = ['testvar is defined']
    templar = None
    all_vars = {'testvar': 'defined'}
    conditional_1.evaluate_conditional(templar, all_vars)

test_case_0()
test_Conditional_evaluate_conditional()

# Generated at 2022-06-25 05:12:18.290733
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_2 = Conditional()
    # Error occured during verifying the conditional "1 < 2"
    # because of the error: '<' not supported between instances of 'int' and 'str'
    condition_2 = "1 < 2"

    try:
        conditional_2.evaluate_conditional(condition_2)
    except AnsibleError as e:
        print(e.message)

    # Error occured during verifying the conditional "{{ 2 < 3 }}"
    # because of the error: invalid literal for int() with base 10: 'True'
    condition_1 = "{{ 2 < 3 }}"

    try:
        conditional_2.evaluate_conditional(condition_1)
    except AnsibleError as e:
        print(e.message)


# Generated at 2022-06-25 05:12:23.300992
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-25 05:12:26.376712
# Unit test for constructor of class Conditional
def test_Conditional():
    try:
        test_case_0()
    except Exception as e:
        print('FAILURE: test_case_0()')
        raise


# Generated at 2022-06-25 05:12:35.663759
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test case 1: false condition
    variable_0 = dict()
    variable_0["name"] = "variable"
    variable_0["value"] = "value"
    variable_0["__ansible_unsafe__"] = True
    conditional_0 = Conditional()
    conditional_0.when = ["dummy"]
    result = conditional_0.evaluate_conditional(variable_0, variable_0)
    assert result == False

    # Test case 2: true condition
    variable_1 = dict()
    variable_1["name"] = "variable"
    variable_1["value"] = "value"
    variable_1["__ansible_unsafe__"] = True
    conditional_1 = Conditional()
    conditional_1.when = [""]

# Generated at 2022-06-25 05:12:38.224107
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Testing: Evaluate the conditional on the object and return a boolean

    # FIXME: This test is not yet implemented.

    # from ansible.playbook.role.include import Include
    # i = Include()
    # i.when = ["a == 'b'"]
    # i.evaluate_conditional()

    pass


# Generated at 2022-06-25 05:12:41.502581
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    conditional = Conditional()

    conditional.when = [
        'foo is defined',
        'bar is not defined',
        'baz not is defined',

    ]

    result = conditional.extract_defined_undefined(conditional.when)
    result_0 = [(u'foo', u'is', u'defined'), (u'bar', u'is not', u'defined'), (u'baz', u'not is', u'defined')]

    assert (result == result_0)

# Generated at 2022-06-25 05:12:48.089029
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()

    # These are just test cases from ansible/test/units/conditional.j2
    if len(C.AVAILABLE_VARS) < 1:
        test_vars = {"inventory_hostname": "localhost"}
    else:
        test_vars = C.AVAILABLE_VARS

    assert conditional_1._check_conditional("foo is bar", None, test_vars) is False
    assert conditional_1._check_conditional("foo == bar", None, test_vars) is False
    assert conditional_1._check_conditional("foo", None, test_vars) is False
    assert conditional_1._check_conditional("", None, test_vars) is True

# Generated at 2022-06-25 05:12:58.281832
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # instantiate a Conditional object
    conditional_0 = Conditional()
    # set its when attribute
    conditional_0.when = ['hostvars[hostname] is defined']
    # gather the variables
    all_vars = 'hostvars[hostname] is defined'
    # instantiate a jinja2 environment object
    templar = 'hostvars[hostname] is defined'
    # call the method with the required positional arguments
    result = conditional_0.evaluate_conditional(templar, all_vars)
    # assert the value returned matches the expected
    assert result == 'hostvars[hostname] is defined'
    # method name is evaluate_conditional
    assert conditional_0.method_name == 'evaluate_conditional'


# Generated at 2022-06-25 05:13:04.800706
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    # all_vars = {}
    # templar = {}

    # test successful scenario
    try:
        conditional_0.when = True
        # result_0 = conditional_0.evaluate_conditional(templar, all_vars)
    except Exception as e:
        assert False, "Unexpected exception raised: {}".format(e)
    else:
        assert True

