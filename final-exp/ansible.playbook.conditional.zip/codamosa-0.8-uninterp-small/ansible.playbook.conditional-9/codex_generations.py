

# Generated at 2022-06-25 05:03:38.324632
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    # Test normal conditions with no defined/undefined variables
    assert conditional.extract_defined_undefined('ansible_facts["distribution"] == "RedHat"') == []
    # Test normal conditions with defined variables
    assert conditional.extract_defined_undefined('ansible_os_family == "SunOS" and ansible_package_mgr == "pkgutil"') == []
    # Test normal conditions with undefined variables
    assert conditional.extract_defined_undefined("ansible_distribution == 'FreeBSD' and ansible_service_mgr == 'rc'") == []
    # Test condition with defined variable

# Generated at 2022-06-25 05:03:43.726969
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def check_defined_undefined(s):
        conditional = Conditional()
        return conditional.extract_defined_undefined(s)
    assert check_defined_undefined('hostvars[inventory_hostname] is not defined') == [('hostvars[inventory_hostname]', 'not is', 'defined')]
    assert check_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert check_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert check_defined_undefined('foo is not undefined') == [('foo', 'not is', 'undefined')]


# Generated at 2022-06-25 05:03:44.928171
# Unit test for constructor of class Conditional
def test_Conditional():
    # Constructor for Conditional should be implemented
    try:
        test_case_0()
    except NameError:
        assert False



# Generated at 2022-06-25 05:03:48.183491
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    conditional_0.when = ['abc', ['abc', 'def'], 'abc']

    try:
        templar = None
        all_vars = {'a': 1}
        if not conditional_0.evaluate_conditional(templar, all_vars):
            raise AssertionError("evaluation of true conditionals failed")
    except:
        raise AssertionError("evaluation of true conditionals failed")


# Generated at 2022-06-25 05:03:53.262382
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional = Conditional()

    templar = None
    all_vars = None
    result = conditional.evaluate_conditional(templar, all_vars)

    assert result is False

# Generated at 2022-06-25 05:03:56.553230
# Unit test for constructor of class Conditional
def test_Conditional():
    try:
        test_case_0()
    except AnsibleError as e:
        display.error("there was an error thrown from a test: %s" % to_text(e))



# Generated at 2022-06-25 05:03:57.734895
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    assert conditional_1.evaluate_conditional('1 == 1', dict()) is True


# Generated at 2022-06-25 05:04:05.214640
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    conditional_1 = Conditional()
    conditional_2 = Conditional()
    conditional_3 = Conditional()
    conditional_4 = Conditional()
    conditional_5 = Conditional()

    conditional_0.when = None or ''
    assert conditional_0.evaluate_conditional(text_type("{{ansible_distribution}}"), dict()) == True

    conditional_1.when = "not ansible_distribution=='Ubuntu'"
    assert conditional_1.evaluate_conditional(text_type("{{ansible_distribution}}"), dict()) == True

    conditional_2.when = ansible_distribution=='Ubuntu'

    conditional_3.when = ["not ansible_distribution=='Ubuntu'", "not ansible_distribution=='Debian'"]

    conditional_4.when

# Generated at 2022-06-25 05:04:06.405554
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Set up object to test
    conditional_0 = Conditional()

    # Evaluate conditional using parameters - test all code paths
    conditional_0.evaluate_conditional()


# Generated at 2022-06-25 05:04:15.069301
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''Test logic of defined/undefined conditional statement'''
    conditional = Conditional()
    conditional.when = "ansible_eth0 is not defined"
    all_vars = {'ansible_eth0': False, 'ansible_bond0': False}
    templar = None
    assert not conditional.evaluate_conditional(templar, all_vars)
    all_vars = {'ansible_eth0': True, 'ansible_bond0': False}
    assert conditional.evaluate_conditional(templar, all_vars)
    conditional.when = "ansible_eth0 is defined"
    assert conditional.evaluate_conditional(templar, all_vars)
    all_vars = {'ansible_eth0': False, 'ansible_bond0': False}


# Generated at 2022-06-25 05:04:37.229778
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    def run_test(cond, expect):
        conditional = Conditional()
        result = conditional.extract_defined_undefined(cond)
        assert result == expect

    run_test("", [])
    run_test("something", [])
    run_test("not defined", [("not", "not", "defined")])
    run_test("is undefined", [("is", "is", "undefined")])
    run_test("not is undefined", [("not is", "not is", "undefined")])
    run_test("is not undefined", [("is not", "is", "not undefined")])
    run_test("foobar is not undefined", [("foobar", "is", "not undefined")])
    run_test("not foobar is not undefined", [("not foobar", "is", "not undefined")])


# Generated at 2022-06-25 05:04:41.365180
# Unit test for constructor of class Conditional
def test_Conditional():
    try:
        conditional_0 = Conditional()
        print("test_constructor_0_passed")
    except:
        print("test_constructor_0_failed")


# Generated at 2022-06-25 05:04:46.732470
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    conditional_1.when = ['ansible_distribution is defined' , 'ansible_distribution is not undefined']
    defined_undefined_1 = conditional_1.extract_defined_undefined(conditional_1.when[0])
    defined_undefined_2 = conditional_1.extract_defined_undefined(conditional_1.when[1])
    # Each conditionals contains one defined/undefined variable
    assert len(defined_undefined_1) == 1
    assert len(defined_undefined_2) == 1
    # test that the extracted variable name is correct
    assert defined_undefined_1[0][0] == defined_undefined_2[0][0]
    assert defined_undefined_1[0][0] == 'ansible_distribution'
    #

# Generated at 2022-06-25 05:04:48.279231
# Unit test for constructor of class Conditional
def test_Conditional():
    try:
        test_case_0()
    except Exception as e:
        print ("FAILED test case: {}, Exception: {}".format("Conditional", e))


# Generated at 2022-06-25 05:04:58.906716
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test value for conditional
    conditional_0 = 'you'
    # Test value for templar
    templar_0 = 'lighthouse'
    # Test value for all_vars

# Generated at 2022-06-25 05:05:03.808178
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()


# Generated at 2022-06-25 05:05:13.424463
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-25 05:05:24.723344
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-25 05:05:27.296006
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    expected_result = [('a', 'is', 'defined')]
    conditional = Conditional()
    actual_result = conditional.extract_defined_undefined('a is defined')
    assert actual_result == expected_result


# Generated at 2022-06-25 05:05:36.233077
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    test_input_1 = "'foo' is defined"
    test_output_1 = [('foo', 'is', 'defined')] # TODO: improve
    test_expected_1 = conditional_0.extract_defined_undefined(test_input_1)
    if test_output_1 == test_expected_1:
        print("Test 1 passed!")
    else:
        print("Test 1 failed!")
        print("Expected: {}".format(test_expected_1))
        print("Got: {}".format(test_output_1))

if __name__ == "__main__":
    conditional_0 = Conditional()
    test_Conditional_extract_defined_undefined()

# Generated at 2022-06-25 05:06:09.696388
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    show_custom_stats = True
    summarize_verbosity = None
    loop_controls = {}
    templar_1 = Templar(['Conditional'], show_custom_stats, summarize_verbosity)
    all_vars = dict()
    all_vars.update({'_ansible_parsed': None})
    all_vars.update({'ansible_facts': None})
    all_vars.update({'_ansible_no_log': {'msg': None, 'pipeline': None}})
    all_vars.update({'ansible_play_batch': None})
    assert conditional_0.evaluate_conditional(templar_1, all_vars) == True


# Generated at 2022-06-25 05:06:20.252377
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    # print(conditional_1.extract_defined_undefined('defined main_vlan or hostvars["stack"]["service_config"]["config"]["main_vlan"] <= 300 and defined main_vlan'))
    assert conditional_1.extract_defined_undefined('defined main_vlan or hostvars["stack"]["service_config"]["config"]["main_vlan"] <= 300 and defined main_vlan') == [('main_vlan', 'is', 'defined'), ('main_vlan', 'is', 'defined')]
    # print(conditional_1.extract_defined_undefined('not defined main_vlan or hostvars["stack"]["service_config"]["config"]["main_vlan"] <= 300 and not defined main

# Generated at 2022-06-25 05:06:28.529894
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    # when not set.
    if conditional_0.evaluate_conditional(conditional=None, templar=None, all_vars=None):
        raise AssertionError("when not set, we should get False")
    # when set to True.
    if not conditional_0.evaluate_conditional(conditional=True, templar=None, all_vars=None):
        raise AssertionError("when set to True, we should get True")
    # when set to True.
    if conditional_0.evaluate_conditional(conditional=False, templar=None, all_vars=None):
        raise AssertionError("when set to False, we should get False")
    # when set to 1.

# Generated at 2022-06-25 05:06:32.679708
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = templar_0 = AnsibleTemplar()
    all_vars_0 = dict()
    assert conditional_0.evaluate_conditional(templar_0, all_vars_0)


# Generated at 2022-06-25 05:06:40.348266
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-25 05:06:42.832277
# Unit test for constructor of class Conditional
def test_Conditional():
    # condition: when is an empty list
    conditional_0 = Conditional()
    assert (conditional_0.when == []), "constructor for class Conditional is broken"

# unit test for method extract_defined_undefined() of class Conditional

# Generated at 2022-06-25 05:06:50.781720
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    conditional_1 = Conditional()
    conditional_2 = Conditional()

    assert conditional_1.extract_defined_undefined(conditional_1.when) == []
    assert conditional_2.extract_defined_undefined(conditional_2.when) == []

    # for valid conditional
    conditional_2.when = "{{ test is defined and test['test1'] is defined and test['test1']['test2'] is defined }}"
    assert conditional_2.extract_defined_undefined(conditional_2.when) == [('test', 'is', 'defined'), ('test[\'test1\']', 'is', 'defined'), ('test[\'test1\'][\'test2\']', 'is', 'defined')]

    # for valid conditional but with whitespaces

# Generated at 2022-06-25 05:06:53.323531
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_evaluate_conditional = Conditional()
    assert False == conditional_evaluate_conditional.evaluate_conditional("variable", "templar", "all_vars")


# Generated at 2022-06-25 05:07:01.013118
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Test for method evaluate_conditional for class Conditional
    '''

# Generated at 2022-06-25 05:07:02.152796
# Unit test for constructor of class Conditional
def test_Conditional():
    test_case_0()

# Generated at 2022-06-25 05:07:36.967344
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestConditional(Conditional):

        _when = FieldAttribute(isa='list', default=list, extend=True, prepend=True, include_snippets=False)

    # Test with no conditional
    conditional_1 = TestConditional()
    all_vars = dict()
    evaluated = conditional_1.evaluate_conditional(None, all_vars)
    assert evaluated is True

    # Test with conditional that evaluates to True
    conditional_2 = TestConditional()
    conditional_2._when = ['True']
    evaluated = conditional_2.evaluate_conditional(None, all_vars)
    assert evaluated is True

    # Test with conditional that evaluates to False
    conditional_3 = TestConditional()
    conditional_3._when = ['False']

# Generated at 2022-06-25 05:07:38.754518
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_0 = Conditional()
    assert conditional_0



# Generated at 2022-06-25 05:07:41.665952
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    assert not Conditional().evaluate_conditional(None, None)


# Generated at 2022-06-25 05:07:48.372030
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    valid_variable_names = [ '_' , 'a', 'A', 'Z', 'a1', 'a_1' ]
    invalid_variable_names = [ '1a', '_a', '$a', 'a#' ]

    for variable in valid_variable_names:
        value = variable
        variable_name = variable.replace('_', 'test_underscore') + '_test'
        conditional_0 = Conditional()
        conditional_0.when = ["{{ " + variable_name + " == '" + value + "' }}"]
        all_vars = { variable_name : value }
        assert conditional_0.evaluate_conditional(None, all_vars) is True

    for variable in invalid_variable_names:
        value = variable

# Generated at 2022-06-25 05:07:51.090178
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    templar_1 = ""
    all_vars_2 = ""
    conditional_1.evaluate_conditional(templar=templar_1, all_vars=all_vars_2)


# Generated at 2022-06-25 05:08:00.101796
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()

    # Set up mock ansible inventory, variables, module_utils and module params
    mock_all_vars = {
        'inventory_hostname': 'localhost',
        'groups': ['ungrouped']
    }
    # (src, dst, module_name, module_args, task_vars, loader)
    conditional_0._templar = Templar(mock_all_vars, None, None)

    # Set up a conditional which should evaluate to True
    mock_conditional = "'localhost' not in groups"
    # Set up the when attribute with our conditional
    conditional_0.when = [ mock_conditional ]
    # Call evaluate_conditional
    result_1 = conditional_0.evaluate_conditional(conditional_0._templar, mock_all_vars)


# Generated at 2022-06-25 05:08:09.238598
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # All test data is based on examples/playbooks/hackers_playbook2.yaml
    display.verbosity = 3

    conditional_ = Conditional()
    instance = conditional_

    C.HOST_KEY_CHECKING = False

    conditional_value = 'test'

    all_variables = {
        'ansible_ssh_common_args': "-C -o ControlMaster=auto -o ControlPersist=60s",
        'ansible_user': 'root',
        'ansible_ssh_host': 'localhost',
        'ansible_ssh_port': '22'}

    conditional_value = instance._check_conditional(conditional_value, templar, all_variables)
    assert conditional_value is False


# Generated at 2022-06-25 05:08:16.826972
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.plugins import module_loader

    loader = DataLoader()
    conditional_0 = Conditional(loader=loader)
    # TEST CASE: conditional is an empty string
    # EXPECTED OUTPUT: the method returns an empty list
    output_0 = conditional_0.extract_defined_undefined('')
    assert output_0 == []

    # TEST CASE: conditional is an empty list
    # EXPECTED OUTPUT: the method returns an empty list
    output_1 = conditional_0.extract_defined_undefined([])
    assert output_1 == []

    # TEST CASE: conditional is None
    # EXPECTED OUTPUT: the method returns an empty list
    output_2 = conditional_0.extract_defined_undefined(None)
    assert output_2 == []

    # TEST CASE: conditional includes a defined

# Generated at 2022-06-25 05:08:26.997687
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """
    Test case: Verify that when the condition is not a bool, the conditional
    is evaluated, and the result is returned.
    """
    conditional_1 = Conditional()

    # Create a template for testing
    template_vars = dict(
        x = 'ansible',
        y = 'hashicorp',
        z = 'vmware',
    )
    templar = Templar(loader=None, variables=template_vars)
    all_vars = dict(
        x = 'ansible',
        y = 'hashicorp',
        z = 'vmware',
        fail = 'false',
    )
    conditional = "{x} is ansible"
    conditional_1._ds = dict()
    result = conditional_1.evaluate_conditional(templar, all_vars)
    assert result == True

# Generated at 2022-06-25 05:08:36.023897
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_1 = conditional_0.extract_defined_undefined('hostvar[1] is defined or hostvar[2] is defined')
    assert conditional_1==[('hostvar[1]', 'is', 'defined'), ('hostvar[2]', 'is', 'defined')]
    conditional_2 = conditional_0.extract_defined_undefined('hostvar[1] is not defined or hostvar[2] is not defined')
    assert conditional_2==[('hostvar[1]', 'is not', 'defined'), ('hostvar[2]', 'is not', 'defined')]


# Generated at 2022-06-25 05:09:35.485363
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test case data
    conditional_1 = Conditional()
    templar_1 = ansible.template.Template()
    all_vars_1 = dict()
    ref = None
    # Perform the test
    res = conditional_1.evaluate_conditional(templar_1, all_vars_1)
    # Verify the results
    assert(res == ref)


# Generated at 2022-06-25 05:09:40.316290
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
   conditional_0 = Conditional()
   test_conditional_0 = "ansible_lsb['codename'] == 'trusty' and ansible_distribution == 'Ubuntu' or ansible_pkg_mgr == 'apt'"

   extract_defined_undefined_output_0 = conditional_0.extract_defined_undefined(test_conditional_0)
   assert extract_defined_undefined_output_0 == []

   test_conditional_1 = "ansible_lsb['codename'] == 'trusty' and ansible_distribution == 'Ubuntu' and ansible_pkg_mgr is defined"
   extract_defined_undefined_output_1 = conditional_0.extract_defined_undefined(test_conditional_1)

# Generated at 2022-06-25 05:09:49.128188
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional(loader=None)

    # Boundary case 1: conditional is None
    # Expected result: True
    cond = None
    templar = None
    all_vars = None
    assert conditional_1.evaluate_conditional(templar, all_vars) == True

    # Boundary case 2: conditional is ''.
    # Expected result: True
    cond = ''
    templar = None
    all_vars = None
    assert conditional_1.evaluate_conditional(templar, all_vars) == True

    # Boundary case 3: conditional is 'False'
    # Expected result: False
    cond = 'False'
    templar = None
    all_vars = None

# Generated at 2022-06-25 05:09:54.287821
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = AnsibleTemplar(all_vars=[])
    conditional_0.evaluate_conditional(templar_0, all_vars=[])
    pass


# Generated at 2022-06-25 05:10:02.408742
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_0._loader = None
    conditional_1 = Conditional()
    conditional_1._loader = None

    # case with an input string that does not contain defined or undefined
    conditional_1.extract_defined_undefined("hostname == 'host1'")
    if conditional_1.extract_defined_undefined("hostname == 'host1'") is not None:
        raise AssertionError("Conditional.extract_defined_undefined is not null with a valid input.")

    # case with an input string that contains defined and undefined
    conditional_1.extract_defined_undefined("hostvars[inventory_hostname].cloud_hostname is defined")

# Generated at 2022-06-25 05:10:07.401008
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    meta_vars = {'meta': {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}}
    hosts = {'host1': {'key1': 'value1', 'key2': 'value2'}, 'host2': {'key2': 'value2', 'key3': 'value3'}}
    all_vars = dict(meta_vars, **hosts)

    conditional_0 = Conditional()
    conditional_0._templar = DummyTemplar()


# Generated at 2022-06-25 05:10:13.969373
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Create a Conditional class object
    conditional_test = Conditional()

    # Create a templar class object
    templar_test = display.templar

    # Check the evaluate_conditional method
    conditional_0 = conditional_test.evaluate_conditional(templar_test, all_vars=dict())
    assert conditional_0 is True

# Generated at 2022-06-25 05:10:23.161067
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_0._loader = DummyLoader()
    # Call method extract_defined_undefined of Conditional with value of variable conditional equal to hostvars['test0'].test1
    result_0 = conditional_0.extract_defined_undefined("hostvars['test0'].test1")
    assert result_0 == [('hostvars[\'test0\']', 'is', 'defined')], "Test 0 failed"
    # Call method extract_defined_undefined of Conditional with value of variable conditional equal to hostvars[item0].test1
    result_1 = conditional_0.extract_defined_undefined("hostvars[item0].test1")
    assert result_1 == [('hostvars[item0]', 'is', 'defined')], "Test 1 failed"


# Generated at 2022-06-25 05:10:30.379562
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional_1 = Conditional()
    ds_1 = {'a': 1, 'b': 2}
    conditional_1.when = ['a == 1']
    assert conditional_1.evaluate_conditional(ds_1) == True

    conditional_2 = Conditional()
    ds_2 = {'a': 1, 'b': 2}
    conditional_2.when = ['a != 1']
    assert conditional_2.evaluate_conditional(ds_2) == False

# Generated at 2022-06-25 05:10:37.091811
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    
    cond_0 = Conditional()
    #cond_0.when = ['foo', 'bar', '']
    cond_0.when = ['foo.startsWith("bar")']
    #cond_0.when = ['foo is undefined']
    #cond_0.when = ['foo is defined']
    #cond_0.when = ['foo not is undefined']
    #cond_0.when = ['foo not is defined']

    templar = type('Templar', (object,), {'template':lambda _,x: x, 'is_template':lambda _,x: False})()
    vars = {'foo':'bar'}
    
    assert cond_0.evaluate_conditional(templar, vars)
   

# Generated at 2022-06-25 05:13:18.605824
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Tests if conditional evaluates to True when the variable is
    # indeed defined
    conditional = Conditional()
    conditional.when = ['zypperbackend is defined']
    setattr(conditional, '_ds', {'zypperbackend': 'zypper'})
    result = conditional.evaluate_conditional({}, {})
    assert result, "when the variable is defined"

    conditional1 = Conditional()
    conditional1.when = ['zypperbackend is defined']
    result = conditional1.evaluate_conditional({}, {})
    assert not result, "when the variable is not defined"

    # Tests if conditional evaluates to False when using "is not defined"
    # and the variable is not defined
    conditional = Conditional()
    conditional.when = ['zypperbackend is not defined']