

# Generated at 2022-06-25 05:03:29.974253
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # there's no way to unit test anything involving jinja2, since it is not threadsafe
    # and the test suite is threaded
    pass


# Generated at 2022-06-25 05:03:39.724556
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    # Create a Conditional object for testing
    conditional_0 = Conditional()

    # Test with a simple conditional string
    conditional_0.when = "something is defined"
    result = conditional_0.extract_defined_undefined(conditional_0.when)
    assert result == [('something', 'is', 'defined')]

    # Test with a conditional string with white spaces
    conditional_0.when = "  something   is   defined  "
    result = conditional_0.extract_defined_undefined(conditional_0.when)
    assert result == [('something', 'is', 'defined')]

    # Test with a conditional string with multiple tests
    conditional_0.when = "something is defined and something_else is not defined"

# Generated at 2022-06-25 05:03:43.647228
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # TODO: manually set up data structure under test
    conditional_0 = Conditional()

    conditional_0.when = [0, 1, 2]

    # TODO: manually set up remaining data dependencies
    templar_0 = None

    all_vars_0 = {}

    # Unit test for conditional when list contains {0, 1, 2}
    result = conditional_0.evaluate_conditional(templar_0, all_vars_0)

    # TODO: manually check assertions



# Generated at 2022-06-25 05:03:46.178834
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    conditional_1 = Conditional()

    # Test extract_defined_undefined
    conditional_1._check_conditional("{{ foo is defined }}", "", "")

    # Test extract_defined_undefined assert_equals
    assert conditional_1._check_conditional("{{ foo is defined }}", "", "")



# Generated at 2022-06-25 05:03:52.891224
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()

    assert conditional_0.extract_defined_undefined('hostvars[\'foo\'] not is defined') == [('hostvars[\'foo\']', 'not is', 'defined')]
    assert conditional_0.extract_defined_undefined('hostvars[\'foo\'] is defined') == [('hostvars[\'foo\']', 'is', 'defined')]
    assert conditional_0.extract_defined_undefined('hostvars[\'foo\'] is not defined') == [('hostvars[\'foo\']', 'is not', 'defined')]
    assert conditional_0.extract_defined_undefined('hostvars[\'foo\'] not is undefined') == [('hostvars[\'foo\']', 'not is', 'undefined')]
    assert conditional

# Generated at 2022-06-25 05:03:53.682251
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_0 = Conditional()


# Generated at 2022-06-25 05:04:05.092905
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Test evaluate_conditional method of class Conditional
    '''
    conditional_0 = Conditional()
    assert conditional_0.evaluate_conditional({}, {}) == True
    assert conditional_0.evaluate_conditional({}, {'a': 'b'}) == True
    assert conditional_0.evaluate_conditional({}, {'a': 'b', 'hostvars': {'a': 'b'}}) == True
    assert conditional_0.evaluate_conditional({}, {'a': 'b', 'hostvars': {'ansible_all_ipv4_addresses': 'b'}}) == True

# Generated at 2022-06-25 05:04:10.400950
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
      conditional_1 = Conditional()
      conditional_1.when = ["'2'<3"]
      assert conditional_1.evaluate_conditional(conditional_1,conditional_1) == True
 

# Generated at 2022-06-25 05:04:16.626051
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    conditional_1._loader = None
    conditional_1.when = "notx is defined"
    du_results = conditional_1.extract_defined_undefined(conditional_1.when)
    assert len(du_results) == 1
    assert du_results[0][0] == "notx"
    assert du_results[0][1] == "is"
    assert du_results[0][2] == "defined"
    conditional_1.when = "notx is not defined"
    du_results = conditional_1.extract_defined_undefined(conditional_1.when)
    assert len(du_results) == 1
    assert du_results[0][0] == "notx"
    assert du_results[0][1] == "is not"

# Generated at 2022-06-25 05:04:21.451765
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    assert isinstance(conditional_0, Conditional)
    # Test 0: 1 when
    all_vars_0 = dict(a=0)
    try:
        conditional_0.evaluate_conditional(templar=templar_0, all_vars=all_vars_0)
    except Exception as e:
        assert 0, "evaluate_conditional raised an exception: %s" % e


# Generated at 2022-06-25 05:04:34.315895
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_extract_defined_undefined = Conditional()
    conditional = "ansible_eth0 is defined and ansible_eth1 is not defined and ansible_eth2 is defined"
    expected = [('ansible_eth0', 'is', 'defined'), ('ansible_eth1', 'is not', 'defined'), ('ansible_eth2', 'is', 'defined')]
    result = conditional_extract_defined_undefined.extract_defined_undefined(conditional)
    assert result == expected

# Generated at 2022-06-25 05:04:41.110588
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()

    # test 1
    conditional_1._task = 'test_task'
    conditional_1.when = ['ansible_os_family == "RedHat"']
    all_vars = {'ansible_os_family': 'RedHat'}
    templar = AnsibleTemplar(loader=None)
    assert conditional_1.evaluate_conditional(templar, all_vars)

    # test 2
    conditional_1.when = ['missing_variable']
    all_vars = {'ansible_os_family': 'RedHat'}
    templar = AnsibleTemplar(loader=None)
    # FIXME: following test should not throw an exception, as it is not an invalid access
    #assert conditional_1.evaluate_conditional(templar, all

# Generated at 2022-06-25 05:04:47.171915
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    assert conditional_1.extract_defined_undefined("") == []
    assert conditional_1.extract_defined_undefined("foo") == []
    assert conditional_1.extract_defined_undefined("hostvars['foo'] is defined") == [("hostvars['foo']", "is", "defined")]
    assert conditional_1.extract_defined_undefined("hostvars['foo'] is undefined") == [("hostvars['foo']", "is", "undefined")]
    assert conditional_1.extract_defined_undefined("hostvars['foo'] not is defined") == [("hostvars['foo']", "not is", "defined")]

# Generated at 2022-06-25 05:04:56.052812
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    # Test case 0:
    conditional_1.when = "abc is defined and xyz is defined and abc is not undefined and xyz is not undefined"
    assert conditional_1.extract_defined_undefined(conditional_1.when) == [('abc','is','defined'), ('xyz','is','defined'), ('abc','is not','undefined'), ('xyz','is not','undefined')], "Extract defined or undefined failed to work"
    # Test case 1:
    conditional_1.when = "xyz is defined and abc is not undefined"
    assert conditional_1.extract_defined_undefined(conditional_1.when) == [('xyz','is','defined'), ('abc','is not','undefined')], "Extract defined or undefined failed to work"
    # Test case 2

# Generated at 2022-06-25 05:05:06.865430
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = Conditional()
    all_vars_0 = Conditional()

    # Test 1
    conditional_0.when = [
            'a == b',
            'b == c',
            'c == d',
            'd == e',
            'e == f'
    ]
    result = conditional_0.evaluate_conditional(templar_0, all_vars_0)
    assert result == True

    # Test 2
    conditional_0.when = [
            'a == b',
            'b == c',
            'c == d',
            False
    ]
    result = conditional_0.evaluate_conditional(templar_0, all_vars_0)
    assert result == False

    # Test 3

# Generated at 2022-06-25 05:05:14.510004
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    conditional_input_0 = 'hostvars[inventory_hostname] is undefined and hostvars[inventory_hostname] is not None'
    expected_result_0 = [('hostvars[inventory_hostname]', 'is', 'undefined')]
    assert conditional.extract_defined_undefined(conditional_input_0) == expected_result_0

    conditional_input_1 = 'something_else is defined or host_var[foo] is undefined'
    expected_result_1 = [('something_else', 'is', 'defined'), ('host_var[foo]', 'is', 'undefined')]
    assert conditional.extract_defined_undefined(conditional_input_1) == expected_result_1


# Generated at 2022-06-25 05:05:25.548740
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional = 'ansible_distribution is not defined and ansible_distribution_release is not defined and ansible_distribution_version is not defined and ansible_os_family is not defined'
    res = conditional_0.extract_defined_undefined(conditional)
    assert(res == [('ansible_distribution', 'not', 'defined'), ('ansible_distribution_release', 'not', 'defined'), ('ansible_distribution_version', 'not', 'defined'), ('ansible_os_family', 'not', 'defined')])

    conditional = 'ansible_distribution is defined and ansible_distribution_release is defined and ansible_distribution_version is defined and ansible_os_family is defined'
    res = conditional_0.extract_defined_undefined(conditional)

# Generated at 2022-06-25 05:05:34.412250
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    conditional_1.when = [
        "item_0 == True",
        "item_1 == True",
        "item_2 == 'item_2_value'",
        "item_3 == 'item_3_value'",
        "item_4 is undefined",
        "item_5 is defined",
        "item_6 not is undefined",
        "item_7 not is defined",
        "item_8 is defined or not item_9 is defined",
    ]
    result_1 = conditional_1.extract_defined_undefined(conditional_1.when[0])
    assert len(result_1) == 0
    result_2 = conditional_1.extract_defined_undefined(conditional_1.when[1])
    assert len(result_2) == 0


# Generated at 2022-06-25 05:05:40.601652
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Case 1:
    conditional_1 = Conditional()
    conditional_1._ds = None

    # Case 2:
    conditional_2 = Conditional()
    conditional_2._ds = None

    # Case 3: Invalid conditional error
    conditional_3 = Conditional()
    conditional_3._ds = None

    # Case 4:

    # Case 5:

    # Case 6:
    conditional_6 = Conditional()
    conditional_6._ds = None

    # Case 7:
    conditional_7 = Conditional()
    conditional_7._ds = None

    # Case 8:
    conditional_8 = Conditional()
    conditional_8._ds = None

    # Case 9:
    conditional_9 = Conditional()
    conditional_9._ds = None

    # Case 10:
    conditional_10 = Conditional()
   

# Generated at 2022-06-25 05:05:50.756971
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    assert conditional.extract_defined_undefined("1 == 1") == []
    assert conditional.extract_defined_undefined("foo == 1") == []
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]

# Generated at 2022-06-25 05:06:13.399046
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()

    result = conditional_1.extract_defined_undefined("foo is defined")
    assert result == [("foo", "is", "defined")]

    result = conditional_1.extract_defined_undefined("foo is not defined")
    assert result == [("foo", "is not", "defined")]

    result = conditional_1.extract_defined_undefined("foo is undefined")
    assert result == [("foo", "is", "undefined")]

    result = conditional_1.extract_defined_undefined("foo is not undefined")
    assert result == [("foo", "is not", "undefined")]

    result = conditional_1.extract_defined_undefined("hostvars['foo'] is defined")

# Generated at 2022-06-25 05:06:19.133311
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Test empty
    conditional_0 = Conditional()
    assert conditional_0.evaluate_conditional('', '')
    # Test invalid
    conditional_1 = Conditional()
    assert conditional_1.evaluate_conditional('', '1')
    # Test valid
    conditional_2 = Conditional()
    assert conditional_2.evaluate_conditional('', '0')


# Generated at 2022-06-25 05:06:28.431741
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Create an instance of class Conditional
    conditional = Conditional()

    # Create an instance of class FieldAttribute
    attr = FieldAttribute()

    # Create an instance of class base to pass as parameter to function _validate_when of class Conditional
    base = object()

    # Call method _validate_when of class Conditional with the created instance of class FieldAttribute
    conditional._validate_when(attr, "when", list)

    # instantiate the templar class
    templar = Templar()

    # Create an instance of class Attribute
    attr = Attribute()

    # Set attribute '_name' of class FieldAttribute to 'attr'
    attr._name = 'attr'

    # Set attribute '_ds' of class base to 'attr'
    base._ds = 'attr'

    # Set attribute '_loader'

# Generated at 2022-06-25 05:06:35.771046
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional = Conditional()

    # Test for when condition is None
    assert conditional.evaluate_conditional(None, None) == True

    # Test for when condition is an empty list
    assert conditional.evaluate_conditional([], None) == True

    # Test for when condition is an empty string
    assert conditional.evaluate_conditional("", None) == True

    # Test for when condition is a boolean value
    assert conditional.evaluate_conditional(True, None) == True
    assert conditional.evaluate_conditional(False, None) == False



# Generated at 2022-06-25 05:06:40.098732
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    conditional_0._ds = "target"
    conditional_0.when = ["var0", "var1"]

    assert conditional_0.evaluate_conditional(templar=None, all_vars=None)


# Generated at 2022-06-25 05:06:42.354314
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert(hasattr(conditional, 'when'))
    assert(conditional.when == [])
    assert(hasattr(conditional, 'evaluate_conditional'))


# Generated at 2022-06-25 05:06:46.442586
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    setattr(conditional_1, 'when', None)
    templar_1 = None
    all_vars_1 = None
    print(conditional_1.evaluate_conditional(templar_1, all_vars_1))


# Generated at 2022-06-25 05:06:54.072860
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    conditional_1._ds = dict()
    all_vars_1 = dict()
    conditional_1.when = ['', '', '']
    templar_1 = all_vars_1
    result_1 = conditional_1.evaluate_conditional(templar_1, all_vars_1)
    assert result_1 is True
    conditional_2 = Conditional()
    conditional_2._ds = dict()
    all_vars_2 = dict()
    conditional_2.when = ['', '', '']
    templar_2 = all_vars_2
    result_2 = conditional_2.evaluate_conditional(templar_2, all_vars_2)
    assert result_2 is True
    conditional_3 = Conditional()
    conditional

# Generated at 2022-06-25 05:06:58.693309
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_2 = Conditional()
    #print(conditional_2.evaluate_conditional(templar, all_vars))

# Generated at 2022-06-25 05:07:09.402632
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()

    conditional_0._validate_when("extract_defined_undefined", "when", "foo")
    conditional_0._validate_when("extract_defined_undefined", "when", ["foo", "bar"])
    conditional_0._validate("when", "foo")

    with pytest.raises(AnsibleError):
        conditional_0._validate("when", None)

    with pytest.raises(AnsibleError):
        conditional_0._validate("when", 1)

    with pytest.raises(AnsibleError):
        conditional_0._validate("when", 3.14)

    with pytest.raises(AnsibleError):
        conditional_0._validate("when", {"x": "y"})

    conditional_1 = Conditional

# Generated at 2022-06-25 05:07:36.333759
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    assert conditional_1.evaluate_conditional() == True


# Generated at 2022-06-25 05:07:45.850514
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-25 05:07:55.355193
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Success
    def test_0(conditional, templar, all_vars):
        assert conditional.evaluate_conditional(templar, all_vars)
    all_vars = {'a': 1, 'b': 2}
    conditional = Conditional()
    conditional._when = ['a == 1']
    templar = DummyTemplar()
    test_0(conditional, templar, all_vars)

    # Success
    def test_1(conditional, templar, all_vars):
        assert conditional.evaluate_conditional(templar, all_vars)
    all_vars = {'a': 1, 'b': 2}
    conditional = Conditional()
    conditional._when = []
    templar = DummyTemplar()

# Generated at 2022-06-25 05:08:00.384704
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    conditional.when = ["foo == 'bar'", "qux is defined", "foo == 'bar' and qux is undefined"]
    variables = dict(foo = "bar",
                     baz = dict(foo = "bar"),
                     qux = "abc")
    templar = Templar(loader=None, variables=variables)
    res = conditional.evaluate_conditional(templar, variables)
    print(res)

test_Conditional_evaluate_conditional()

# Generated at 2022-06-25 05:08:05.728841
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_0._when = [
        "hostvars['a'] is not defined or hostvars['b'] is not defined",
        "not hostvars['a'] is not defined and not hostvars['b'] is not defined"
    ]
    actual = conditional_0.extract_defined_undefined(conditional_0._when[0])
    expected = [('hostvars[\'a\']', 'is not', 'defined'), ('hostvars[\'b\']', 'is not', 'defined')]
    assert actual == expected
    actual = conditional_0.extract_defined_undefined(conditional_0._when[1])

# Generated at 2022-06-25 05:08:16.096128
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # Test case - 1
    test_case_0()

    # Test case - 2
    # create a variable manager object
    variable_manager = VariableManager()
    # create a templar object
    templar = Templar(loader=None, variables=variable_manager)

    # create the conditional object
    conditional_1 = Conditional(loader=templar)

    # check if the conditional evaluates as expected
    condition = 'ansible_distribution == "Ubuntu" and ansible_distribution_version == "14.04"'
    fact_data = dict(ansible_distribution='Ubuntu', ansible_distribution_version='14.04')

    result = conditional_1.evaluate_conditional(templar, fact_data)

# Generated at 2022-06-25 05:08:18.480674
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    all_vars = dict()
    conditional_1.when = ['foo == bar']
    assert conditional_1.evaluate_conditional(conditional_1, all_vars) == False
if __name__ == "__main__":
    test_Conditional_evaluate_conditional()

# Generated at 2022-06-25 05:08:27.266480
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-25 05:08:37.006159
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    assert conditional_1.extract_defined_undefined("") == []
    assert conditional_1.extract_defined_undefined("foo") == []
    assert conditional_1.extract_defined_undefined("foo not is defined") == [("foo", "not",  "defined")]
    assert conditional_1.extract_defined_undefined("foo is not defined") == [("foo", "is not",  "defined")]
    assert conditional_1.extract_defined_undefined("foo is defined") == [("foo", "is",  "defined")]
    assert conditional_1.extract_defined_undefined("(foo is undefined)") == [("foo", "is",  "undefined")]

# Generated at 2022-06-25 05:08:44.172067
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_1 = Conditional()
    conditional_2 = Conditional()
    conditional_3 = Conditional()
    conditional_4 = Conditional()
    conditional_5 = Conditional()
    conditional_6 = Conditional()
    conditional_7 = Conditional()
    conditional_8 = Conditional()
    conditional_9 = Conditional()
    conditional_10 = Conditional()

    var_0 = "hostvars['foobar'] not is undefined"
    var_1 = 'hostvars[\'foobar\'] not is undefined'

    result = conditional_0.extract_defined_undefined(var_0)
    expected = [('hostvars[\'foobar\']', 'not is', 'undefined')]
    assert result == expected

    result = conditional_1.extract_defined

# Generated at 2022-06-25 05:09:47.666910
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Test with empty list of when
    conditional = Conditional()
    res = conditional.evaluate_conditional(None, {})
    assert res

    # Test with None in list of when
    conditional = Conditional()
    setattr(conditional, '_when', [None])
    res = conditional.evaluate_conditional(None, {})
    assert res

    # Test with empty string in list of when
    conditional = Conditional()
    setattr(conditional, '_when', [''])
    res = conditional.evaluate_conditional(None, {})
    assert res

    # Test with True in list of when
    conditional = Conditional()
    setattr(conditional, '_when', [True])
    res = conditional.evaluate_conditional(None, {})
    assert res

    # Test with False in list of when


# Generated at 2022-06-25 05:09:55.238349
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    all_vars = dict()
    conditional_0 = Conditional()

    # Test with conditional that evaluates to true
    conditional = '1 == 1'
    result = conditional_0.evaluate_conditional(conditional, all_vars)
    assert result

    # Test with conditional that evaluates to false
    conditional = '1 == 2'
    result = conditional_0.evaluate_conditional(conditional, all_vars)
    assert result == False

    # Test with dict for all_vars
    all_vars = {'var_1': 1}
    conditional = 'var_1 == 1'
    result = conditional_0.evaluate_conditional(conditional, all_vars)
    assert result

    # Test with dict for all_vars
    all_vars = {'var_1': 1}

# Generated at 2022-06-25 05:10:02.627734
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    conditional.when = ['true', "true and not false", 'false or true', '1 > 0', '1 < 0']
    result = conditional.evaluate_conditional('', {})
    assert result == True
    conditional.when = ['0', "false", 'false or false', '1 < 1', '1 > 1']
    result = conditional.evaluate_conditional('', {})
    assert result == False
    conditional.when = ['true', "true and not false", 'false or true', '1 > 0', '1 < 0']
    result = conditional.evaluate_conditional('', {'foo': 'bar'})
    assert result == True
    conditional.when = ['true', "true and not false", 'false or true', '1 > 0', '1 < 0']
    result = conditional.evaluate_conditional

# Generated at 2022-06-25 05:10:07.604028
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Test case try to execute method evaluate_conditional of class Conditional with
    # conditional_1, when conditional_1 is found to be not defined, it throws an exception
    conditional_1 = Conditional()
    try:
        conditional_1.evaluate_conditional(None, None)
        assert False
    except AnsibleError as e:
        assert to_text(e) == "The conditional check '' failed. The error was: An unhandled exception occurred while templating '': UndefinedError: 'None' is undefined"

    # Test case try to execute method evaluate_conditional of class Conditional with
    # conditional_2, when conditional_2 is found to be empty, it returns True.

# Generated at 2022-06-25 05:10:17.628145
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Make sure the test is using the right constants
    assert(C.DEFAULT_UNDEFINED_VAR_BEHAVIOR == 'warn')

    conditional_1 = Conditional()
    conditional_1._ds = 'conditional from ansible.playbook.conditional'
    if conditional_1.evaluate_conditional('foo', {}):
        raise(AnsibleError("Unexpected True result from evaluate_conditional() on an empty conditional"))
    if conditional_1.evaluate_conditional('foo', {'foo': 'foo'}):
        raise(AnsibleError("Unexpected True result from evaluate_conditional() on an empty conditional"))

    conditional_1._when = ['foo']

# Generated at 2022-06-25 05:10:23.465655
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-25 05:10:31.441812
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    
    # test case 1 - when loop with one conditional
    #  --conditional is empty
    #  --templar is instance of Templar
    #  --all_vars is not empty
    
    # test case 2 - when loop with two conditional
    #  --conditional is not empty
    #  --templar is instance of Templar
    #  --all_vars is empty

    # test case 3 - check case when loop is empty
    #  --conditional is empty
    #  --templar is instance of Templar
    #  --all_vars is empty


# Generated at 2022-06-25 05:10:41.555090
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    conditional_1 = Conditional()
    conditional_1.when = ['a is defined',
                          'a != b',
                          'c is defined or d != e',
                          'f is defined and g != h',
                          '1 == foo']

    expected_result_1 = [['a', 'is', 'defined'],
                         ['a', '!=', 'undefined'],
                         ['c', 'is', 'defined'],
                         ['d', '!=', 'undefined'],
                         ['f', 'is', 'defined'],
                         ['g', '!=', 'undefined']]

    actual_result_1 = conditional_1.extract_defined_undefined('')

# Generated at 2022-06-25 05:10:45.519411
# Unit test for constructor of class Conditional
def test_Conditional():

    class ConditionalForTest():
        def __init__(self, when=None):
            self._when = when


    conditional_2 = ConditionalForTest(when=['1', "2"])
    assert conditional_2._when == ['1', "2"]

    conditional_2 = ConditionalForTest(when='1')
    assert conditional_2._when == ['1']


# Generated at 2022-06-25 05:10:48.456862
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    conditional = "{{ ansible_ssh_user }} == 'root' and {{ ansible_hostname }} == 'localhost'"
    templar_0 = conditional_0._templar
    all_vars = conditional_0._available_variables
    result = conditional_0.evaluate_conditional(templar_0, all_vars)
    assert result is True


# Generated at 2022-06-25 05:13:08.985089
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_0 = Conditional()


# Generated at 2022-06-25 05:13:18.183917
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_1 = Conditional()
    conditional_2 = Conditional()
    conditional_3 = Conditional()
    conditional_4 = Conditional()
    conditional_5 = Conditional()

    conditional_0.when = "foo is defined"
    conditional_1.when = "'foo' is defined"
    conditional_2.when = "foo is undefined"
    conditional_3.when = "'foo' is undefined"
    conditional_4.when = "hostvars['foo'] is defined"
    conditional_5.when = "hostvars['foo'] is undefined"

    assert conditional_0.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]