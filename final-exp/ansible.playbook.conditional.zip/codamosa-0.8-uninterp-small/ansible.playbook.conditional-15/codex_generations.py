

# Generated at 2022-06-25 05:03:33.538659
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional = 'hostvars[foo].bar is not defined and host is defined'
    results = conditional_0.extract_defined_undefined(conditional)
    assert(len(results) == 2)
    assert(results[0] == ('hostvars[foo].bar', 'is not', 'defined'))
    assert(results[1] == ('host', 'is', 'defined'))


# Generated at 2022-06-25 05:03:44.311302
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_class = Conditional()
    templar = conditional_class.template()
    all_vars = {}

    conditional_0 = "1 or 2"
    result = conditional_class.evaluate_conditional(templar, all_vars)
    print("result=%d" % (result))
    assert result == True

    # Test conditional_1 of type str
    conditional_1 = "not 1 or 2"
    result = conditional_class.evaluate_conditional(templar, all_vars)
    print("result=%d" % (result))
    assert result == True

    # Test conditional_2 of type bool
    conditional_2 = True
    result = conditional_class.evaluate_conditional(templar, all_vars)
    print("result=%d" % (result))
    assert result

# Generated at 2022-06-25 05:03:51.714889
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def_undef_0 = Conditional().extract_defined_undefined("hostvars['foo'] is defined")
    def_undef_1 = Conditional().extract_defined_undefined("hostvars['foo'] is undefined")
    def_undef_2 = Conditional().extract_defined_undefined("hostvars['foo'] not is defined")
    def_undef_3 = Conditional().extract_defined_undefined("hostvars['foo'] not is undefined")
    def_undef_4 = Conditional().extract_defined_undefined("foo is defined")
    def_undef_5 = Conditional().extract_defined_undefined("foo is undefined")
    def_undef_6 = Conditional().extract_defined_undefined("foo not is defined")

# Generated at 2022-06-25 05:03:55.249276
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = DummyTemplar()
    all_vars_0 = DummyAllVars()
    output_0 = conditional_0.evaluate_conditional(templar_0, all_vars_0)
    assert output_0 is True


# Generated at 2022-06-25 05:04:05.167323
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    loader = DictDataLoader({
        "myfile.yml": """
        ---
          - fail:
              msg: Fail
        """})
    mock_display = MockAnsibleDisplay()
    conditional = Conditional(loader=loader)

    conditional.when = [True]
    result = conditional.evaluate_conditional(loader.get_basedir(), mock_display)
    assert result is True

    conditional.when = [False]
    result = conditional.evaluate_conditional(loader.get_basedir(), mock_display)
    assert result is False

    conditional.when = ['1 == 1']
    result = conditional.evaluate_conditional(loader.get_basedir(), mock_display)
    assert result is True

    conditional.when = ['test_variable == "OK"']

# Generated at 2022-06-25 05:04:15.574676
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()

    # when value is not a string
    conditional_1.when = 1
    results = conditional_1.extract_defined_undefined(conditional_1.when)
    assert results == []

    # when value is empty
    conditional_1.when = ''
    results = conditional_1.extract_defined_undefined(conditional_1.when)
    assert results == []

    # when value is a string containing no defined/undefined tests
    conditional_1.when = 'some text'
    results = conditional_1.extract_defined_undefined(conditional_1.when)
    assert results == []

    # when value is a string containing two defined/undefined tests
    conditional_1.when = 'var1 is undefined and var2 is defined'
    results = conditional_1.ext

# Generated at 2022-06-25 05:04:22.621880
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # yum_repo_name is defined and repo_name is defined
    conditional = Conditional()
    conditional1 = conditional.extract_defined_undefined("yum_repo_name is defined and repo_name is defined")
    assert conditional1 == [('yum_repo_name', 'is', 'defined'), ('repo_name', 'is', 'defined')]

    # yum_repo_name is not defined or repo_name is defined
    conditional2 = conditional.extract_defined_undefined("yum_repo_name is not defined or repo_name is defined")
    assert conditional2 == [('yum_repo_name', 'is not', 'defined'), ('repo_name', 'is', 'defined')]

    # yum_repo_name is undefined and repo_name is undefined
    conditional3

# Generated at 2022-06-25 05:04:29.992858
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_obj = Conditional()
    assert conditional_obj.extract_defined_undefined("""(hostvars[item_to_test] is defined) and (hostvars[item_to_test]['sub_items'] is defined)""") == [('hostvars[item_to_test]', 'is', 'defined'), ('hostvars[item_to_test][\'sub_items\']', 'is', 'defined')]


# Generated at 2022-06-25 05:04:35.225984
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # initializing Conditional object
    conditional_1 = Conditional()
    # setting attribute when
    conditional_1.when = "0"
    # initializing variable templar
    templar = ""
    # initializing variable all_vars
    all_vars = ""
    conditional_1.evaluate_conditional(templar, all_vars)
    assert True


# Generated at 2022-06-25 05:04:37.548312
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    assert conditional_1._check_conditional(["hostvars['a'] is defined", "hostvars['b'] is undefined"], "a", "b")


# Generated at 2022-06-25 05:04:55.575281
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_obj = Conditional()
    conditional_obj.when = ['no fail']
    templar_obj = get_mock_templar()
    all_vars = {'var1': 'val1'}
    assert conditional_obj.evaluate_conditional(templar_obj, all_vars)


# Generated at 2022-06-25 05:04:59.684756
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_j2 = """
    {% if a is defined %}
    {{ a }}
    {% endif %}
    """
    conditional_j2_results = '''
    False
    '''
    conditional_j2_dict = {
            'a': 'hi',
        }

    conditional_0 = Conditional()
    conditional_0.when = [
        'a is undefined'
    ]

    res = conditional_0.evaluate_conditional(conditional_j2, conditional_j2_dict)
    assert res is False, "Should return False for {'a': 'hi'}"



# Generated at 2022-06-25 05:05:09.437523
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()

    conditional_1.when = ["a == 'test' and hostvars[inventory_hostname] is defined"]
    de = conditional_1.extract_defined_undefined("a == 'test' and hostvars[inventory_hostname] is defined")
    assert(de == [("hostvars[inventory_hostname]", "is", "defined")])

    conditional_1.when = ["hostvars[inventory_hostname] is defined"]
    de = conditional_1.extract_defined_undefined("hostvars[inventory_hostname] is defined")
    assert(de == [("hostvars[inventory_hostname]", "is", "defined")])

    conditional_1.when = ["hostvars[inventory_hostname] is defined and a == 'test'"]

# Generated at 2022-06-25 05:05:19.513788
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # if variable_0 is any variable
    variable_0 = 'defined'

    # if conditional_0 is a string
    conditional_0 = 'hostvars[hostname] is defined'

    # if conditional_1 is a string
    conditional_1 = 'hostvars[hostname] is defined'

    # if conditional_2 is a string
    conditional_2 = 'hostvars[hostname] is defined'

    # if conditional_3 is a string
    conditional_3 = 'hostvars[hostname] is defined'

    # if conditional_4 is a string
    conditional_4 = 'hostvars[hostname] is defined'

    # if conditional_5 is a string
    conditional_5 = 'hostvars[hostname] is defined'

    # if conditional_6 is a string

# Generated at 2022-06-25 05:05:30.315997
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test case
    conditional_1 = Conditional()
    all_vars_1 = {}

    # Test case 2
    conditional_2 = "variable1 == variable2"
    all_vars_2 = {"variable1": "value1", "variable2": "value2"}

    # Test case 3
    conditional_3 = "variable1 is defined"
    all_vars_3 = {"variable1": "value1"}

    # Test case 4
    conditional_4 = "variable1 is defined or variable2 is defined"
    all_vars_4 = {"variable2": "value2"}

    # Test case 5
    conditional_5 = "variable1 is definedand variable2 is defined"
    all_vars_5 = {"variable2": "value2"}

    # Test case 6

# Generated at 2022-06-25 05:05:38.128241
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional_0 = Conditional()
    conditional_1 = Conditional()

    conditional_0.when.append('True')

    # when_item_0 = 'True'
    #
    # result_0 = conditional_0.evaluate_conditional(templar=templar_0,
    #                                                all_vars=all_vars_0)
    #
    # print(result_0)
    #
    # assert result_0 == True
    #
    # conditional_0.when.append(when_item_0)
    #
    # result_1 = conditional_0.evaluate_conditional(templar=templar_0,
    #                                                all_vars=all_vars_0)
    #
    # print(result_1)
    #
    # assert result

# Generated at 2022-06-25 05:05:46.233569
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()

    # Testcase 0: Check if evaluate_conditional() returns correct output
    templar_0 = "templar"

    all_vars_0 = {'hostvars': {'host1': 'hostvars_host1'}, 'hostvars_host1': 'hostvars_host1_value', 'host1': 'host1_value', 'hostvars_host0': 'hostvars_host0_value', 'host0': 'host0_value', 'hostvars_host2': 'hostvars_host2_value', 'host2': 'host2_value', 'localhost': 'localhost_value'}

    result_0 = conditional_0.evaluate_conditional(templar_0, all_vars_0)
    assert result_0 == True


#

# Generated at 2022-06-25 05:05:50.944197
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Create a Conditional class instance passing a None value in for 'loader'
    conditional = Conditional(None)
    # Call the Conditional class method extract_defined_undefined passing it a string as a parameter
    result = conditional.extract_defined_undefined('hostvars[inventory_hostname] is defined')
    # Test that the result is type list and contains the expected value
    assert type(result[0]) == tuple
    assert result[0] == ('hostvars[inventory_hostname]', 'is', 'defined')


# Generated at 2022-06-25 05:05:53.094417
# Unit test for constructor of class Conditional
def test_Conditional():
    try:
        conditional_0 = Conditional()
    except Exception as ex:
        assert(False), "Unexpected exception raised: " + str(ex)    
    assert(True)



# Generated at 2022-06-25 05:05:55.365054
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar = [][0]
    all_vars = [][0]
    conditional_0.evaluate_conditional(templar, all_vars)


# Generated at 2022-06-25 05:06:25.395852
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    templar = {'is_template': lambda str: True}
    vars = {}
    assert conditional.evaluate_conditional(templar, vars)

# Generated at 2022-06-25 05:06:29.105628
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """
    Test that when a conditional is set to True, function returns true
    """
    conditional_0 = Conditional()
    conditional_0.when = [True]
    assert conditional_0.evaluate_conditional("templar", "all_vars") == True


# Generated at 2022-06-25 05:06:32.720341
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    conditional._ds = None
    conditional.when = [u'True', u'True']
    conditional.name = 'test'

    templar = conditional._get_templar()
    templar.available_variables = {}
    try:
        result = conditional.evaluate_conditional(templar, None)
        assert result == True
    except AssertionError:
        raise
    except Exception:
        raise

# Generated at 2022-06-25 05:06:39.043760
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
  conditional_0 = Conditional()
  assert conditional_0.extract_defined_undefined("described.zhigui.is_defined") == [('described.zhigui', 'is', 'defined')]


# Generated at 2022-06-25 05:06:46.359414
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # File tests/test_conditional.py, line 15
    expected = []
    conditional_0 = Conditional()
    # Call method Conditional.extract_defined_undefined
    cond = conditional_0.extract_defined_undefined('')
    assert cond == expected, 'Return of method Conditional.extract_defined_undefined do not match'
    # File tests/test_conditional.py, line 16
    expected = [('hostvars[\'blah\']', 'is', 'defined')]
    conditional_0 = Conditional()
    # Call method Conditional.extract_defined_undefined
    cond = conditional_0.extract_defined_undefined('blah is defined')
    assert cond == expected, 'Return of method Conditional.extract_defined_undefined do not match'
    # File tests

# Generated at 2022-06-25 05:06:47.424081
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional is not None, "Failed to create Conditional"


# Generated at 2022-06-25 05:06:58.097695
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # test no variable to found
    conditional_0 = Conditional()
    expected_result_0 = []
    result_0 = conditional_0.extract_defined_undefined("")
    assert result_0 == expected_result_0

    # test match one
    conditional_1 = Conditional()
    expected_result_1 = [('var', 'not is', 'defined')]
    result_1 = conditional_1.extract_defined_undefined("var not is defined")
    assert result_1 == expected_result_1

    # test match two
    conditional_2 = Conditional()
    expected_result_2 = [('var', 'not is', 'defined'), ('var1', 'is', 'undefined')]
    result_2 = conditional_2.extract_defined_undefined("var not is defined var1 is undefined")

# Generated at 2022-06-25 05:07:07.996872
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
        # Test the case when conditional is not a string but a int
        conditional_int = 5
        conditional = Conditional()
        try:
            conditional.extract_defined_undefined(conditional_int)
        except Exception:
            assert True
        # Test the case when conditional is a string
        conditional_string = "myvar is defined or myvar2 is undefined"
        conditional = Conditional()
        ret = conditional.extract_defined_undefined(conditional_string) 
        assert ret == [('myvar', 'is', 'defined'), ('myvar2', 'is', 'undefined')]


# Generated at 2022-06-25 05:07:13.742756
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Try call the evaluate_conditional method
    conditional = Conditional()
    templar = _Templar()
    all_vars = {'test_var':'test_var_val'}
    if conditional.evaluate_conditional(templar, all_vars):
        print("evaluate_conditional is working fine")
    else:
        print("evaluate_conditional is has a problem")


# Generated at 2022-06-25 05:07:14.262797
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_0 = Conditional()


# Generated at 2022-06-25 05:08:29.303837
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    templar = None
    all_vars = dict()

    # Call method
    evaluate_conditional = conditional_1.evaluate_conditional(templar, all_vars)
    if evaluate_conditional != True:
        raise AssertionError()


# Generated at 2022-06-25 05:08:32.257207
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    conditional_1.when = ["True"]
    assert conditional_1._check_conditional(True, None, None) == True



# Generated at 2022-06-25 05:08:36.407331
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_0.when = ["test_0", "test_1", "test_2", "test_3"]

    str_0 = "test variable and variable_1"
    conditional_0.extract_defined_undefined(str_0)


# Generated at 2022-06-25 05:08:43.585805
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    assert conditional_0.extract_defined_undefined("") is not None
    assert conditional_0.extract_defined_undefined("sdfsdfsdfsdfsdf") is not None
    assert conditional_0.extract_defined_undefined("a") is not None
    assert conditional_0.extract_defined_undefined(" ") is not None
    assert conditional_0.extract_defined_undefined("'hostvars[hostname]' is defined")[0][0] == 'hostvars[hostname]'
    assert conditional_0.extract_defined_undefined("'hostvars[hostname]' is defined")[0][1] == 'is'

# Generated at 2022-06-25 05:08:46.545203
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()

    conditional_value = 'test'
    templar = None
    all_vars = 'test'

    result = conditional.evaluate_conditional(templar, all_vars)
    if result:
        print("Test 0 PASSED: Conditional.evaluate_conditional()")
    else:
        print("Test 0 FAILED: Conditional.evaluate_conditional()")


# Generated at 2022-06-25 05:08:54.226600
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # src: https://github.com/ansible/ansible/blob/devel/test/units/modules/core/test_async.py
    import jinja2
    template = jinja2.Template(u"{{ foo }}")

    class MyVarsModule():
        def __init__(self, ds):
            self.params = dict(
                foo=True,
            )

    my_vars_module = MyVarsModule({})

    my_conditional = Conditional()
    my_conditional._loader = jinja2.DictLoader(dict(
        as_bool=template,
    ))
    my_conditional.when = [u"{{ foo | bool }}"]

    my_conditional.evaluate_conditional(my_vars_module, my_vars_module.params)

# Generated at 2022-06-25 05:09:01.016922
# Unit test for constructor of class Conditional
def test_Conditional():
    try:
        from units.mock.loader import DictDataLoader
        loader = DictDataLoader({})
        conditional = Conditional(loader)
        display.display("%s test passed" % test_case_0.__name__)
    except Exception as err:
        display.display("%s test failed." % test_case_0.__name__)
        display.display(err)


# Generated at 2022-06-25 05:09:08.027148
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    conditional_1._loader = None
    conditional_1._ds = 'test_value'
    conditional_1.when = [
        'test_when_1',
        'test_when_2'
    ]

    templar_2 = 'test_templar_2'
    all_vars_3 = 'test_all_vars_3'

    # Invoke method
    result = conditional_1.evaluate_conditional(templar_2, all_vars_3)

    assert isinstance(result, bool)
    assert result is True



# Generated at 2022-06-25 05:09:13.172184
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Initialize Conditional class instance
    conditional_0 = Conditional()
    # initialize templar
    templar_0 = Templar(loader=None)
    # initialize all_vars
    all_vars_0 = dict()
    # initialize conditional
    conditional_1 = conditional_0.evaluate_conditional(templar=templar_0, all_vars=all_vars_0)
    # assert equality
    assert conditional_1 == True


# Generated at 2022-06-25 05:09:18.279937
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # test when is empty
    conditional = Conditional()
    assert conditional.evaluate_conditional(None, None)

    # test when is False
    conditional = Conditional()
    conditional._when = [False]
    assert not conditional.evaluate_conditional(None, None)

    # test when is True
    conditional = Conditional()
    conditional._when = [True]
    assert conditional.evaluate_conditional(None, None)

    # test when is False and True
    conditional = Conditional()
    conditional._when = [False, True]
    assert conditional.evaluate_conditional(None, None)

    # test when is True and False
    conditional = Conditional()
    conditional._when = [True, False]
    assert not conditional.evaluate_conditional(None, None)

    # test when is False and False
    conditional = Cond

# Generated at 2022-06-25 05:12:05.542446
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_ = Conditional()

    if conditional_.extract_defined_undefined('hostvars["some_host"]["some_var"] is not defined') != [('hostvars["some_host"]["some_var"]', 'is not', 'defined')]:
        raise AssertionError('Failed to extract defined undefined correctly')



# Generated at 2022-06-25 05:12:15.500926
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()

    # Test extracting defined/undefined from a conditional
    result = conditional_1.extract_defined_undefined('(hostvars["foo"] is defined) and (hostvars["bar"] is undefined)')
    assert result == [('hostvars["foo"]', 'is', 'defined'), ('hostvars["bar"]', 'is', 'undefined')], "Unexpected result: %s" % result

    # Test extracting defined/undefined with non-quoted var names
    result = conditional_1.extract_defined_undefined('(hostvars[foo] is not defined) and (hostvars[bar] is undefined)')

# Generated at 2022-06-25 05:12:21.415398
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_2 = Conditional()
    conditional_2.when = [
        "True",
        "False"
    ]
    with pytest.raises(Exception):
        conditional_2.evaluate_conditional()

# Generated at 2022-06-25 05:12:30.526689
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # define test vars
    test_var0 = "abc"
    test_var1 = "def"
    test_var2 = 123
    test_var3 = 456
    test_var4 = "123"
    test_var5 = "456"
    test_var6 = True
    test_var7 = False
    test_var8 = [1,2,3]
    test_var9 = [4,5,6]
    test_var10 = "True"
    test_var11 = "False"
    test_var12 = {1:'one',2:'two',3:'three'}

    # define test conditional

# Generated at 2022-06-25 05:12:33.905525
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    conditional_1 = "abc is defined and xyz is defined and bcd is undefined"
    assert conditional.extract_defined_undefined(conditional_1) == \
        [('abc', 'is', 'defined'), ('xyz', 'is', 'defined'), ('bcd', 'is', 'undefined')]


# Generated at 2022-06-25 05:12:40.967462
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    conditional_2 = Conditional()
    conditional_3 = Conditional()
    conditional_4 = Conditional()
    conditional_5 = Conditional()
    conditional_6 = Conditional()
    assert conditional_1.extract_defined_undefined("foo1 is defined") == [("foo1", "is", "defined")]
    assert conditional_2.extract_defined_undefined("foo2 is not undefined") == [("foo2", "is not", "undefined")]
    assert conditional_3.extract_defined_undefined("'foo3' is not undefined") == [("foo3", "is not", "undefined")]
    conditional_4.when = "'test' not in hostvars[inventory_hostname]['base_packages']"
    assert conditional_4.extract_defined

# Generated at 2022-06-25 05:12:44.215499
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Init a task instance
    conditional = Conditional()
    conditional.when = ['test.test1']

    templar = object
    all_vars = object

    result = conditional.evaluate_conditional(templar, all_vars)


# Generated at 2022-06-25 05:12:52.335689
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # c = conditional object
    c = Conditional()
    # templar = templar object
    templar = 'something'
    # all_vars = vars object
    all_vars = 'something'

    # test the exception
    # raises AnsibleError
    with pytest.raises(AnsibleError):
        c.evaluate_conditional(templar, all_vars)

    # test the successful evaluation
    from ansible.playbook.play_context import PlayContext
    pc = PlayContext()
    c.when = False
    c.evaluate_conditional(templar, all_vars)

    # test the return value of c.evaluate_conditional()
    # r = c.evaluate_conditional()
    # assert r == False


# Generated at 2022-06-25 05:12:58.474823
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Test evaluate conditional method of the Conditional class
    Test the evaluate_conditional method in the cond.py file

    Parameters:
    None

    Returns:
    None

    Test results:
    test_Conditional_evaluate_conditional[True-True].................................................. ok
    test_Conditional_evaluate_conditional[True-False]................................................. ok
    test_Conditional_evaluate_conditional[True-True-False]............................................. ok
    test_Conditional_evaluate_conditional[True-True-False-True]........................................ ok
    '''

# Generated at 2022-06-25 05:13:04.915878
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    expected = [('hostvars', 'is not', 'undefined'), ('hostvars', 'not is', 'defined'), ('defined_var', 'is', 'defined'), ('undefined_var', 'is', 'undefined')]
    assert expected == conditional_0.extract_defined_undefined("hostvars is not undefined or hostvars not is defined or defined_var is defined or undefined_var is undefined")
