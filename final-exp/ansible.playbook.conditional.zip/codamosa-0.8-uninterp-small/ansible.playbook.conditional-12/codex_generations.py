

# Generated at 2022-06-25 05:03:44.271593
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    conditional_0 = conditional.extract_defined_undefined('hostvars[\'foo\'] is undefined')
    assert conditional_0 == [('hostvars[\'foo\']', 'is', 'undefined')]

    conditional_1 = conditional.extract_defined_undefined('hostvars[\'foo\'] is defined')
    assert conditional_1 == [('hostvars[\'foo\']', 'is', 'defined')]

    conditional_2 = conditional.extract_defined_undefined('foo not is undefined')
    assert conditional_2 == [('foo', 'not is', 'undefined')]

    conditional_3 = conditional.extract_defined_undefined('foo is not undefined')
    assert conditional_3 == [('foo', 'is not', 'undefined')]


# Generated at 2022-06-25 05:03:51.650798
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    class ConditionalTest(Conditional):
        pass

    conditional_0 = ConditionalTest(loader=None)

    conditional_1 = 'version_compare(ansible_version, "2.5") is defined'
    vars_1        = {'version': '1.5.1', 'ansible_version': '2.4.2.0'}
    result_1      = False

    conditional_2 = 'foo is defined'
    vars_2        = {'foo': 'bar'}
    result_2      = True

    conditional_3 = 'foo is not defined'
    vars_3        = {'foo': 'bar'}
    result_3      = False

    conditional_4 = 'foo is undefined'
    vars_4        = {'foo': 'bar'}

# Generated at 2022-06-25 05:03:53.616267
# Unit test for constructor of class Conditional
def test_Conditional():
    try:
        test_case_0()
        print("test case_0: Success")
    except:
        print("test case_0: Fails")


# Generated at 2022-06-25 05:04:00.279083
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    conditional_expression = "hostvars['my_group'] is defined and hostvars['my_group']['my_var'] is defined"
    def_undef = conditional.extract_defined_undefined(conditional_expression)
    assert def_undef[0][0] == "hostvars['my_group']"
    assert def_undef[0][1] == "is"
    assert def_undef[0][2] == "defined"
    assert def_undef[1][0] == "hostvars['my_group']['my_var']"
    assert def_undef[1][1] == "is"
    assert def_undef[1][2] == "defined"


# Generated at 2022-06-25 05:04:12.744874
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    """
    Unit test for:
     - Class Conditional
     - Method extract_defined_undefined
    """

    # Create instance of Conditional class
    conditional_2 = Conditional()

    # Test definition 1
    definition_1 = conditional_2.extract_defined_undefined('hostvars[inventory_hostname] is defined')
    definition_1_expected = [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert definition_1 == definition_1_expected

    # Test definition 2
    definition_2 = conditional_2.extract_defined_undefined('hostvars[inventory_hostname] is not defined')
    definition_2_expected = [('hostvars[inventory_hostname]', 'is not', 'defined')]
    assert definition_2 == definition_2_expected

   

# Generated at 2022-06-25 05:04:18.246684
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()

    conditional = 'False and (foo is defined or bar is not defined)'
    def_undef = conditional_0.extract_defined_undefined(conditional)
    assert def_undef == [('foo', 'is', 'defined'), ('bar', 'is not', 'defined')]

    conditional = 'True and (foo is defined or bar is undefined)'
    def_undef = conditional_0.extract_defined_undefined(conditional)
    assert def_undef == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]

    conditional = 'True and (hostvars[groups["all"][0]] is defined or bar is undefined)'
    def_undef = conditional_0.extract_defined_undefined(conditional)

# Generated at 2022-06-25 05:04:26.744183
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class my_ds:
        def __init__(self):
            self.__UNSAFE__ = 1

    show_content = False

    x = Conditional()
    x._ds = my_ds()
    templar = None

    # Get the variable dictionary
    all_vars = x._get_vars(loader=None)

    # Test the conditions

# Generated at 2022-06-25 05:04:28.397455
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    filtered_templar_0 = FilteredTemplate()
    all_vars_0 = {}
    conditional_0.evaluate_conditional(filtered_templar_0, all_vars_0)


# Generated at 2022-06-25 05:04:29.438935
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_0 = Conditional()


# Generated at 2022-06-25 05:04:38.269282
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-25 05:04:52.483539
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional_1 = Conditional()

    # Init return value from method evaluate_conditional of class Conditional
    # Return values initialized as if we got False from templar.is_template and True from _check_conditional
    ret = None

    # set up expected values
    expected = True

    # set up the mocks
    conditional_1._templar = MagicMock()
    check_conditional_mock = conditional_1._check_conditional = MagicMock(return_value=expected)

    # perform the test
    ret = conditional_1.evaluate_conditional(conditional_1._templar, None)

    # ensure that the mock was called as we expected
    check_conditional_mock.assert_called_with(conditional_1._check_conditional, conditional_1._templar, None)

   

# Generated at 2022-06-25 05:04:58.909502
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    conditional_1.when = ['foo is defined', 'bar is undefined']
    assert conditional_1.extract_defined_undefined('bar is defined') == []
    assert conditional_1.extract_defined_undefined('foo is defined and bar is undefined') == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]
    assert conditional_1.extract_defined_undefined('foobar is undefined') == []
    assert conditional_1.extract_defined_undefined('foo is defined or bar is undefined') == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]
    assert conditional_1.extract_defined_undefined('bar is defined or foo is defined') == []

# Generated at 2022-06-25 05:05:05.681563
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = None
    all_vars_0 = dict({u'localhost': dict({u'ipv4': dict({u'address': u'127.0.0.1'}), u'ipv6': dict({u'address': u'::1'})})})
    ret_0 = conditional_0.evaluate_conditional(templar_0, all_vars_0)
    assert ret_0


# Generated at 2022-06-25 05:05:10.991094
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    conditional_list_1 = conditional.extract_defined_undefined("test1 is defined")
    conditional_list_2 = conditional.extract_defined_undefined("test1 is not defined")
    conditional_list_3 = conditional.extract_defined_undefined("test1 not is defined")
    conditional_list_4 = conditional.extract_defined_undefined("test1 not is not defined")
    conditional_list_5 = conditional.extract_defined_undefined("test1 is undefined")
    conditional_list_6 = conditional.extract_defined_undefined("test1 is not undefined")
    conditional_list_7 = conditional.extract_defined_undefined("test1 not is undefined")
    conditional_list_8 = conditional.extract_defined_undefined("test1 not is not undefined")


# Generated at 2022-06-25 05:05:19.599476
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    conditional_1.when = "a == b"
    conditional_2 = Conditional()
    conditional_2.when = None
    conditional_3 = Conditional()
    conditional_3.when = ""
    conditional_4 = Conditional()
    conditional_4.when = []
    conditional_5 = Conditional()
    conditional_5.when = "host_var == 'value'"
    assert not conditional_1.evaluate_conditional(conditional_1, dict(a = 5, b = 10)), "Test condition: if a = b"
    assert conditional_2.evaluate_conditional(conditional_2, dict()), "Test condition: if condition is None"
    assert conditional_3.evaluate_conditional(conditional_3, dict()), "Test condition: if condition is empty"
    assert conditional

# Generated at 2022-06-25 05:05:30.412305
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    pattern_1 = 'hostvars[ inventory_hostname ].some_hostvar|d(efault(False)|int) is defined and hostvars[inventory_hostname].some_hostvar|d(efault(False)|int) == True and hostvars[inventory_hostname].some_hostvar|d(efault(False)|int) != False and inventory_hostname != manageiq_1 and inventory_hostname != manageiq_2'

# Generated at 2022-06-25 05:05:37.767187
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    conditional_0 = 'hostvars[inventory_hostname] is defined'
    conditional_1 = 'hostvars[inventory_hostname] is undefined'
    conditional_2 = 'hostvars[inventory_hostname] not is undefined'
    conditional_3 = 'foo is defined and hostvars[inventory_hostname] is undefined'
    conditional_4 = 'foo is defined and hostvars[inventory_hostname] is undefined or foo is defined'

    result_0 = [('hostvars[inventory_hostname]', 'is', 'defined')]
    result_1 = [('hostvars[inventory_hostname]', 'is', 'undefined')]
    result_2 = [('hostvars[inventory_hostname]', 'not is', 'undefined')]

# Generated at 2022-06-25 05:05:41.399745
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("hostvars['localhost'] is not defined") == [("hostvars['localhost']", 'is not', 'defined')]


# Generated at 2022-06-25 05:05:44.481668
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # TODO implement test_Conditional_evaluate_conditional
    return False


# Generated at 2022-06-25 05:05:51.995052
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()

    # Test with a valid conditional statement, condition is True
    conditional_1._when = ["bar == 'baz'"]
    assert conditional_1.evaluate_conditional(conditional_1_Template(), conditional_1_All_vars()) == True

    # Test with a valid conditional statement, condition is False
    conditional_1._when = ["bar == 'foo'"]
    assert conditional_1.evaluate_conditional(conditional_1_Template(), conditional_1_All_vars()) == False

    # Test with an invalid conditional statement
    conditional_1._when = ["foo == 'bar'"]
    try:
        conditional_1.evaluate_conditional(conditional_1_Template(), conditional_1_All_vars()) == True
    except Exception as ex:
        assert type(ex) == Ansible

# Generated at 2022-06-25 05:06:04.849923
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    result = conditional_0.extract_defined_undefined("'a' is defined or 'b' is not defined")
    assert result[0][0] == "'a'", "Fail: Conditional.extract_defined_undefined('a' is defined or 'b' is not defined)"
    assert result[0][1] == "is", "Fail: Conditional.extract_defined_undefined('a' is defined or 'b' is not defined)"
    assert result[0][2] == "defined", "Fail: Conditional.extract_defined_undefined('a' is defined or 'b' is not defined)"
    assert result[1][0] == "'b'", "Fail: Conditional.extract_defined_undefined('a' is defined or 'b' is not defined)"
    assert result

# Generated at 2022-06-25 05:06:10.846732
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Create test object
    conditional_0 = Conditional()

    # Initializing variables
    test_cond = "var1 is defined and var2 is not defined"

    # Expected result
    expected_result = [('var1', 'is', 'defined'), ('var2', 'is not', 'defined')]

    # Calling method under test
    result = conditional_0.extract_defined_undefined(test_cond)

    # Verifying result
    assert (result == expected_result)


# Generated at 2022-06-25 05:06:11.632813
# Unit test for constructor of class Conditional
def test_Conditional():
    Conditional()


# Generated at 2022-06-25 05:06:13.393366
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_0 = Conditional()
    assert conditional_0._when == []


# Generated at 2022-06-25 05:06:22.011211
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    hosts = {
        '127.0.0.1': {
            'ansible_connection': 'local',
            'ansible_loop_var': 'item',
            'inventory_hostname': 'localhost',
            'item': 'localhost',
            'key1': 'value1'
        },
        '127.0.0.2': {
            'ansible_connection': 'local',
            'ansible_loop_var': 'item',
            'inventory_hostname': 'otherhost',
            'item': 'otherhost',
            'key1': 'value1',
            'key2': 'value2'
        }
    }

# Generated at 2022-06-25 05:06:30.058231
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager._extra_vars = {'test_var': 'test_value'}
    variable_manager._hostvars = dict(HOSTVAR='HOSTVAR_VALUE')
    variable_manager._hostvars['HOSTNAME'] = {}
    variable_manager._hostvars['HOSTNAME']['hostvars_var'] = 'hostvars_value'
    variable_manager._hostvars['HOSTNAME']['hostvars_unused_var'] = 'hostvars_unused_value'
    templar = Templar(loader=None, variables=variable_manager)
    
    conditional = Conditional()

# Generated at 2022-06-25 05:06:39.188728
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Testing the case when "conditional" is None or ""
    conditional_0 = Conditional()
    templar_0 = DummyTemplar()
    all_vars_0 = DummyVars()
    result_0 = conditional_0.evaluate_conditional(templar_0, all_vars_0)
    assert result_0 is True

    conditional_1 = Conditional()
    templar_1 = DummyTemplar()
    all_vars_1 = DummyVars()
    result_1 = conditional_1.evaluate_conditional(templar_1, all_vars_1)
    assert result_1 is True

    # Testing the case when "conditional" is boolean value
    conditional_2 = Conditional()
    templar_2 = DummyTemplar()
   

# Generated at 2022-06-25 05:06:48.911175
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    a = Conditional()

    # No matches
    s = 'this is a string'
    assert [] == a.extract_defined_undefined(s)

    # Simple match
    s = 'hostvars[inventory_hostname] is defined'
    assert [('hostvars[inventory_hostname]', 'is', 'defined')] == a.extract_defined_undefined(s)

    # Multiple matches
    s = 'hostvars[inventory_hostname] is defined and [foo,bar] is not defined'
    assert [('hostvars[inventory_hostname]', 'is', 'defined'), ('[foo,bar]', 'is not', 'defined')] == a.extract_defined_undefined(s)


# Generated at 2022-06-25 05:06:58.221176
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

   test_inputs = [
      "foo not is defined",
      "this is bar",
      "foo is undefined",
      "foo is bar",
      "foo is defined",
      "foo not is undefined",
      "this is not defined",
      "this not is undefined",
      "this is not undefined",
      "this not is defined",
      "this not is not defined",
      "this is not not defined",
      "this not is not undefined",
      "this is not not undefined",
   ]

# Generated at 2022-06-25 05:07:09.376775
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    conditional_1.when = ["foo"]
    test_templar = templar_1
    test_all_vars = all_vars_1
    assert conditional_1.evaluate_conditional(test_templar, test_all_vars)
    conditional_1.when = ["bar"]
    assert not conditional_1.evaluate_conditional(test_templar, test_all_vars)
    conditional_1.when = ["foo or bar"]
    assert conditional_1.evaluate_conditional(test_templar, test_all_vars)
    conditional_1.when = ["foo and bar"]
    assert not conditional_1.evaluate_conditional(test_templar, test_all_vars)

# Generated at 2022-06-25 05:07:28.331062
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    given_conditional_0 = None
    expected_defined_undefined_0 = []
    returned_defined_undefined_0 = conditional.extract_defined_undefined(given_conditional_0)
    assert expected_defined_undefined_0 == returned_defined_undefined_0
    given_conditional_1 = 'hostvars["foo"] is defined'
    expected_defined_undefined_1 = [['hostvars["foo"]', 'is', 'defined']]
    returned_defined_undefined_1 = conditional.extract_defined_undefined(given_conditional_1)
    assert expected_defined_undefined_1 == returned_defined_undefined_1
    given_conditional_2 = 'hostvars["foo"] is not defined'
    expected_defined_undefined_

# Generated at 2022-06-25 05:07:30.422857
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    assert conditional.evaluate_conditional("1==1", None) == True


# Generated at 2022-06-25 05:07:37.931357
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """
    Method evaluate_conditional of class Conditional
    """
    # Basic setup
    host = "localhost"
    templar = Templar()
    templar._available_variables = dict()
    play_context = PlayContext()
    play_context.hostvars = dict()
    templar._play_context = play_context
    templar._play_context.hostvars[host] = dict()
    templar._play_context.hostvars[host]['ansible_default_ipv4'] = '127.0.0.1'
    top_level_vars = dict()
    top_level_vars['ansible_default_ipv4'] = '192.0.2.0'
    templar._available_variables['hostvars'] = templar._play_

# Generated at 2022-06-25 05:07:46.817389
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_from_file('tests/inventory'))
    templar = Templar(loader=loader, variables=variable_manager)
    
    conditional_0 = Conditional()
    conditional_0.when = ['test_case_0']
    all_vars_0 = dict()
    all_vars_0['test_case_0'] = 'test_value_0'
    result = conditional_0.evaluate_conditional(templar, all_vars_0)
    assert result == True
    
    conditional_1 = Conditional()
    conditional_1

# Generated at 2022-06-25 05:07:56.175817
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditionals = [
        "hostvars['localhost']['var_a'] is defined",
        "var_b is defined or var_c is defined",
        "var_d is not defined or var_e is not defined",
        "var_f is defined and var_g is defined",
        "var_h is defined and var_i is not defined",
        "var_j is not defined and var_k is defined",
        "var_l is not defined and var_m is not defined",
    ]


# Generated at 2022-06-25 05:07:56.910212
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_0 = Conditional()


# Generated at 2022-06-25 05:07:59.531873
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    conditional_1.when = [True]
    assert(conditional_1.evaluate_conditional({}, {}) is True)



# Generated at 2022-06-25 05:08:02.822117
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional(None)

# Generated at 2022-06-25 05:08:12.155758
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Create a Mock templar and all_vars
    templar = Mock_Templar()
    all_vars = Mock_Vars()

    # Create instance of Conditional
    conditional_1 = Conditional()
    conditional_1.when = [None]
    conditional_1.evaluate_conditional(templar, all_vars)
    # Verify conditional is True
    assert conditional_1.evaluate_conditional(templar, all_vars) == True

    # Create instance of Conditional
    conditional_2 = Conditional()
    conditional_2.when = ['', None]
    conditional_2.evaluate_conditional(templar, all_vars)
    # Verify conditional is True
    assert conditional_2.evaluate_conditional(templar, all_vars) == True

    # Create instance

# Generated at 2022-06-25 05:08:19.592848
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    conditional_0 = Conditional()

    conditional_0.when = [u"{{ x | default(1) }}==1", u"{{ y | default(1) }}==2"]

    conditional_0._loader = None

    def_undef_0 = conditional_0.extract_defined_undefined(conditional_0.when[0])

    assert def_undef_0 == [u"x is defined"], "extract_defined_undefined(conditional_0.when[0]) != [u\"x is defined\"]"

    def_undef_1 = conditional_0.extract_defined_undefined(conditional_0.when[1])


# Generated at 2022-06-25 05:08:44.076098
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Setup
    conditional_0 = Conditional()
    conditional_0._ds = 'lorem'
    conditional_0.when = ['lorem ipsum dolor sit amet, consectetur adipiscing elit.']
    templar = object
    all_vars = object

    # Exercise and verify
    try:
        conditional_0.evaluate_conditional(templar, all_vars)
        assert False, "AnsibleError not raised"
    except AnsibleError:
        assert True



# Generated at 2022-06-25 05:08:55.014373
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():


    def test_case( test_input, expected_output ):
        # Instantiate Conditional object to be tested
        conditional_0 = Conditional()

        #
        # invoke test method
        #

        # what is being tested
        result = conditional_0.extract_defined_undefined( test_input )

        # check that the result is as expected
        if result != expected_output:
            output_msg = "expected result: %s  actual result: %s" % ( expected_output, result )
            display.display( "test_case_0_test_case: " + output_msg)
            raise AssertionError( output_msg )


    #
    # test table
    #


# Generated at 2022-06-25 05:09:03.879762
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_0.set_loader(None)
    conditional_0._ds = None
    conditional_0._task = None
    conditional_0.when = ['cond0']
    conditional_0._ds = None
    conditional_0._task = None
    conditional_0._loader = None
    conditional_0.when = ['hostvars[inventory_hostname] is undefined']
    result = conditional_0.extract_defined_undefined(conditional_0.when[0])
    assert result == [('hostvars[inventory_hostname]', 'is', 'undefined')]


# Generated at 2022-06-25 05:09:12.699956
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """
    :param conditional: conditional is string
    :return: True or False
    """
    display.display("Use Case: Correct conditional statement")
    should_pass = True
    cond = Conditional()
    display.display("Condition: a == True")
    cond._when = ['a == True']
    display.display("Variable a : True")
    a = True
    try:
        if cond.evaluate_conditional(cond, {'a': a}):
            should_pass = True
    except:
        should_pass = False
    assert should_pass


# Generated at 2022-06-25 05:09:15.464022
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    #Initial
    conditional_0 = Conditional()
    conditional_0.when = ['hostvars[inventory_hostname] is defined']

    # Test
    result_0 = conditional_0.extract_defined_undefined(conditional_0.when[0])

    # Verification
    assert result_0 == [('hostvars[inventory_hostname]', 'is', 'defined')]


# Generated at 2022-06-25 05:09:25.586973
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    group = dict()
    group['groups'] = list()
    group['vars'] = dict()
    group['vars']['inventory_hostname'] = 'localhost'
    group['vars']['ansible_play_batch'] = '0'
    group['vars']['inventory_hostname_short'] = 'localhost'
    group['hosts'] = dict()
    group['hosts']['localhost'] = dict()
    group['hosts']['localhost']['ansible_play_batch'] = [0]
    group['hosts']['localhost']['ansible_play_hosts'] = 'localhost'
    group['hosts']['localhost']['ansible_play_hosts_all'] = ['localhost']

# Generated at 2022-06-25 05:09:29.178259
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    conditional.when = [
        "hostvars['foo'].bar is defined",
        "hostvars['bar'] not is undefined",
    ]
    expected_result = [
        ("hostvars['foo'].bar", 'is', 'defined'),
        ("hostvars['bar']", 'not is', 'undefined'),
    ]
    results = []
    for conditional in conditional.when:
        results += conditional.extract_defined_undefined(conditional)
    assert results == expected_result


# Generated at 2022-06-25 05:09:30.524755
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_0 = Conditional()
    assert conditional_0


# Generated at 2022-06-25 05:09:37.697227
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-25 05:09:45.644994
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    # Test with invalid argument passed
    try:
        assert(conditional_0.evaluate_conditional("{{ foo in bar }}") == False)
        assert(false)
    except AnsibleUndefinedVariable as e:
        # Expected failure
        assert(true)
    # Test with valid argument
    try:
        assert(conditional_0.evaluate_conditional("{{ foo in bar }}", dict(foo="foo", bar=["foo"])) == True)
    except AnsibleUndefinedVariable as e:
        # Expected failure
        assert(false)


# Generated at 2022-06-25 05:10:38.604281
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_string_0 = 'this and that or these and not those or the other'
    result_0 = conditional_0.extract_defined_undefined(conditional_string_0)
    assert result_0 == []

    conditional_1 = Conditional()
    conditional_string_1 = 'this and that or these and not hostvars[\'that\'] or the other'
    result_1 = conditional_1.extract_defined_undefined(conditional_string_1)
    assert result_1 == [(u'hostvars[\'that\']', u'not', u'is')]

    conditional_2 = Conditional()
    conditional_string_2 = 'this and that or these and not hostvars[\'that\'] is defined or the other'
    result_2 = conditional_

# Generated at 2022-06-25 05:10:39.515039
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_0 = Conditional()
    assert conditional_0 is not None
#

# Generated at 2022-06-25 05:10:47.732262
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()

    # test_var_0
    test_var_0 = list()
    test_var_0.append('False')
    test_var_0.append(True)
    test_var_0.append(0)
    test_var_0.append('str')
    test_var_0.append(list())
    test_var_0.append(dict())
    test_var_0.append(tuple())

    # test_var_1
    test_var_1 = list()
    test_var_1.append(True)

    # test_var_2
    test_var_2 = list()
    test_var_2.append(tuple())
    test_var_2.append(dict())
    test_var_2.append(0)
    test

# Generated at 2022-06-25 05:10:52.926084
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    conditional_1._when = [
        "hostvars[inventory_hostname].group_name != 'myhosts'",
        "hostvars[inventory_hostname].group_name is defined",
        "something is not defined",
        "something_else is undefined",
        "yet_another_thing is defined",
    ]

    m = conditional_1.extract_defined_undefined(conditional_1._when[0])

    assert m[0][0] == 'hostvars[inventory_hostname].group_name'
    assert m[0][1] == "!="
    assert m[0][2] == 'defined'

    m = conditional_1.extract_defined_undefined(conditional_1._when[1])


# Generated at 2022-06-25 05:10:58.394829
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Real test scenarios
    def test_conditional(conditional, result):
        conditional_0 = Conditional()
        assert(conditional_0.evaluate_conditional(conditional) == result)

    test_conditional("foo is defined", False)


# Generated at 2022-06-25 05:11:05.566347
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()

    # Actual test
    conditional_0._loader = C.get_config_loader()
    result_0 = conditional_0.extract_defined_undefined("ansible_distribution_release == \"7\" and ansible_pkg_mgr in ['yum', 'dnf'] and not ansible_distribution == \"Amazon Linux\"")
    result_1 = conditional_0.extract_defined_undefined("ansible_distribution_release is 7 and ansible_pkg_mgr is not undefined and ansible_distribution is not Amazon Linux")
    result_2 = conditional_0.extract_defined_undefined("somevar is defined")
    result_3 = conditional_0.extract_defined_undefined("somevar is not not defined")
    result_4 = conditional_0.extract_defined

# Generated at 2022-06-25 05:11:12.715572
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    test1 = cond.extract_defined_undefined(
        "defined is defined and (hostvars['localhost']['ansible_facts'] is defined)")
    assert test1 == [('hostvars[\'localhost\'][\'ansible_facts\']', 'is', 'defined')]

    test2 = cond.extract_defined_undefined(
        "defined is defined and (hostvars['localhost']['ansible_facts'] is not defined)")
    assert test2 == [('hostvars[\'localhost\'][\'ansible_facts\']', 'is not', 'defined')]



# Generated at 2022-06-25 05:11:18.824398
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-25 05:11:24.696061
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    conditional.when = "{{ (ansible_os_family == 'Debian' and ansible_distribution_version == '7') }}"
    conditional.when = "{{ (ansible_os_family == 'Debian' and ansible_distribution_version == '7') or {{ ansible_os_family == 'RedHat' }} }}"
    conditional.when = "{{ Inventory_hostname == 'node1' }}"
    conditional.when = "{{ Inventory_hostname == 'node1' or Inventory_hostname == 'node2' }}"
    conditional.when = "{{ (test1 == 'value1' and test2 == 'value2') or (test1 == 'value2' and test2 == 'value1') }}"
    conditional.when = "{{ 'value' in test1 }}"

# Generated at 2022-06-25 05:11:30.222133
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    hostvars = dict(stringvar1="test", stringvar2="test2", emptyvar="", boolvar=True, listvar=["testvar"])
    assert conditional.evaluate_conditional(None, hostvars)

    # check defined and undefined (using hostvars)
    assert conditional.evaluate_conditional(None, hostvars)
    assert not conditional.evaluate_conditional("stringvar1 is defined", hostvars)
    assert conditional.evaluate_conditional("stringvar1 is not defined", hostvars)
    assert not conditional.evaluate_conditional("stringvar2 is defined", hostvars)
    assert conditional.evaluate_conditional("stringvar2 is not defined", hostvars)
    assert not conditional.evaluate_conditional("emptyvar is defined", hostvars)
    assert conditional.evaluate

# Generated at 2022-06-25 05:12:58.480564
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-25 05:13:03.998100
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_0.when = ['foo is defined']
    dummy_var_0 = conditional_0.extract_defined_undefined(conditional_0.when)
    assert dummy_var_0 == [('foo', 'is', 'defined')]



# Generated at 2022-06-25 05:13:11.682313
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    ds = dict(
        x="foo",
        y="bar",
    )
    class unit_test(object):
        _ds = ds
        _loader = None
        _templar = None
        when = [u'{{ x == "foo" }}', u'{{ y == "bar" }}']
        evaluated = False
        def evaluate_conditional(self, templar, all_vars):
            try:
                self.evaluated = True
                super(unit_test, self).evaluate_conditional(templar, all_vars)
            except Exception as e:
                self.evaluated = False
                raise e

    obj = unit_test()
    Conditional.mixin(obj)
    obj._check_conditional(u'True', None, None)

# Generated at 2022-06-25 05:13:15.696099
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    conditional_1.when = []
    result = conditional_1.evaluate_conditional(templar, all_vars)
    assert result == True

# This test checks if pre-defined variables are properly detected

# Generated at 2022-06-25 05:13:23.256502
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = Undefined()
    all_vars_0 = Undefined()
    assert conditional_0.evaluate_conditional(templar_0, all_vars_0) is True
    templar_1 = Undefined()
    all_vars_1 = Undefined()
    assert conditional_0.evaluate_conditional(templar_1, all_vars_1) is True
    templar_2 = Undefined()
    all_vars_2 = Undefined()
    assert conditional_0.evaluate_conditional(templar_2, all_vars_2) is True
    templar_3 = Undefined()
    all_vars_3 = Undefined()