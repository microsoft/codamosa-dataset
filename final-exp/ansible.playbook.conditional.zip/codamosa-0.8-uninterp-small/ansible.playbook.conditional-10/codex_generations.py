

# Generated at 2022-06-25 05:03:30.587974
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    output = conditional.evaluate_conditional(
        "foo.bar == 'baz'",
        {
            'foo': {'bar': 'baz'}
        }
    )
    assert output == True


# Generated at 2022-06-25 05:03:35.403297
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    try:
        conditional.extract_defined_undefined(1)
    except:
        return True
    return False


# Generated at 2022-06-25 05:03:41.616910
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional_0 = Conditional()
    conditional_1 = Conditional()
    conditional_2 = Conditional()
    conditional_3 = Conditional()
    conditional_4 = Conditional()

    conditional_0._when = [
            "hostvars[inventory_hostname].os == 'Linux'",
            "hostvars[inventory_hostname].os == 'Darwin'"
        ]

    conditional_1._when = [
            "hostvars[inventory_hostname].os == 'Linux'",
            "hostvars[inventory_hostname].os == 'Darwin'"
        ]

    conditional_2._when = False

    conditional_3._when = True


# Generated at 2022-06-25 05:03:47.142117
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    #Setup:
    class MyClass:
        _ds = "ds"
        _loader = "loader"
        _templar = "templar"
        _all_vars = "all_vars"
        _result = False

        @property
        def when(self):
            return [
                "joe.firstname == 'Joe'",
                "joe.lastname == 'Smith'",
                "joe.level == 'Sr IT Director'"
            ]

        def __init__(self):
            self._ds = "ds"
            self._loader = "loader"
            self._templar = "templar"
            self._all_vars = "all_vars"
            self._result = False


# Generated at 2022-06-25 05:03:53.525037
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    assert conditional_0.extract_defined_undefined('hostvars["foo"] is defined') == [('hostvars["foo"]', 'is', 'defined')]
    assert conditional_0.extract_defined_undefined('hostvars["foo"] not is undefined') == [('hostvars["foo"]', 'not is', 'undefined')]
    assert conditional_0.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert conditional_0.extract_defined_undefined('not foo is defined') == []

# Generated at 2022-06-25 05:03:54.866241
# Unit test for constructor of class Conditional
def test_Conditional():

    # Test by calling the constructor of the class
    test_case_0()

if __name__ == "__main__":
    test_Conditional()

# Generated at 2022-06-25 05:04:00.590416
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional = 'a is defined and b not is undefined or c is defined'
    result = conditional_0.extract_defined_undefined(conditional)
    print(result)
    assert result == [('a', 'is', 'defined'), ('b', 'not is', 'undefined'), ('c', 'is', 'defined')]


# Generated at 2022-06-25 05:04:05.593288
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    templar_0 = DummyTemplar()
    all_vars_0 = dict()
    # call the method
    result = Conditional._check_conditional(conditional_0, templar_0, all_vars_0)
    assert result == False



# Generated at 2022-06-25 05:04:15.907957
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    conditional_string_0 = "ansible_os_family is defined"
    conditional_string_1 = "foo is not undefined"
    conditional_string_2 = "foo is not undefined or ansible_os_family is defined"
    conditional_string_3 = "{{ ansible_os_family }} is not undefined or foo is defined"
    conditional_string_4 = "{{ ansible_os_family }} is not undefined or foo is defined and bar is defined"
    conditional_string_5 = "{{ ansible_os_family }} is not defined or foo is not undefined or bar is not undefined"

    # Verify that extract_defined_undefined() returns a list
    result_0 = conditional.extract_defined_undefined(conditional_string_0)
    assert isinstance(result_0, list)

    #

# Generated at 2022-06-25 05:04:22.484739
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    templar_1 = templar_from_file("./templar_data_1.json")
    all_vars_1 = {}

    try:
        result_1 = conditional_1.evaluate_conditional(templar_1, all_vars_1)
    except Exception as e:
        print(e)
        assert(0)
    else:
        assert(result_1 == False)

    try:
        result_2 = conditional_1.evaluate_conditional(templar_1, all_vars_1)
    except Exception as e:
        print(e)
        assert(0)
    else:
        assert(result_2 == False)


# Generated at 2022-06-25 05:04:38.147850
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    conditional_2 = Conditional()
    conditional_3 = Conditional()
    conditional_4 = Conditional()
    conditional_5 = Conditional()
    conditional_6 = Conditional()
    conditional_7 = Conditional()
    conditional_8 = Conditional()
    conditional_9 = Conditional()

    # test no conditionals
    assert conditional_1.evaluate_conditional(None, None) is True

    # test with simple string
    conditional_2._when = ['foo']
    assert conditional_2.evaluate_conditional(None, None) is False

    # test with simple boolean true
    conditional_3._when = [True]
    assert conditional_3.evaluate_conditional(None, None) is True

    # test with simple boolean false
    conditional_4._when = [False]
   

# Generated at 2022-06-25 05:04:42.028156
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """
    Test evaluate_conditional method
    """
    # Case 0:
    # arg1 = conditional1, arg2 = templar, arg3 = all_vars
    # arg2 = templar  is None
    with pytest.raises(AnsibleError) as excinfo:
        test_case_0()
    assert "a loader must be specified" in str(excinfo.value)


# Generated at 2022-06-25 05:04:45.153466
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = mock_templar()
    assert(conditional_0.evaluate_conditional(templar_0, {}) == True)
    conditional_0._when = ['{{ ansible_os_family }} == "Debian"']
    assert(conditional_0.evaluate_conditional(templar_0, {}) == False)


# Generated at 2022-06-25 05:04:50.333918
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = None
    all_vars_0 = None
    test_Conditional_evaluate_conditional_result_0 = conditional_0.evaluate_conditional(templar_0, all_vars_0)


# Generated at 2022-06-25 05:04:54.261706
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    conditional_0 = Conditional()
    conditional_0.when = ['hostvars[\'hostname\'] is undefined']
    assert conditional_0.extract_defined_undefined(conditional_0.when[0]) == [['hostvars[\'hostname\']', 'is', 'undefined']]


# Generated at 2022-06-25 05:05:02.774864
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    test_result = conditional_1.extract_defined_undefined('foo is defined and bla is defined')
    assert test_result == [('foo', 'is', 'defined'), ('bla', 'is', 'defined')]

    test_result = conditional_1.extract_defined_undefined('foo is defined and bla is not defined')
    assert test_result == [('foo', 'is', 'defined'), ('bla', 'is', 'not defined')]



# Generated at 2022-06-25 05:05:09.585542
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional_1 = Conditional()
    conditional_2 = Conditional()

    #Test case 1: when content is not a list, should be converted to a list
    conditional_1.when = "2 == 3"
    assert isinstance(conditional_1.when, list)
    print("Test case 1 passed")

    #Test case 2: when content is already a list, should not be converted
    conditional_2.when = ["2 == 3"]
    assert isinstance(conditional_2.when, list)
    print("Test case 2 passed")

#Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-25 05:05:19.536935
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Make sure evaluate_conditional raises an exception when conditional condition is None or empty string
    conditional_0 = Conditional()
    conditional_0._ds = None # When you raise an exception, this will be the specified object
    conditional_0.when = None
    assert conditional_0.evaluate_conditional(None, {}) == True

    conditional_1 = Conditional()
    conditional_1._ds = None # When you raise an exception, this will be the specified object
    conditional_1.when = ''
    assert conditional_1.evaluate_conditional(None, {}) == True

    # Make sure evaluate_conditional works properly
    conditional_2 = Conditional()
    conditional_2._ds = None # When you raise an exception, this will be the specified object
    conditional_2.when = [True, False, '', None, 'some_string']

# Generated at 2022-06-25 05:05:24.460169
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    print("Testing evaluate_conditional")
    #########
    # Try true conditionals
    #########
    print("  Testing true condtional")
    templar = Templar(variables=dict())
    all_vars = dict(hostvars=dict())
    test_obj = Conditional()
    test_obj.when = ['True']
    assert test_obj.evaluate_conditional(templar, all_vars) == True

    #########
    # Try false conditionals
    #########
    print("  Testing false condtional")
    templar = Templar(variables=dict())
    all_vars = dict(hostvars=dict())
    test_obj = Conditional()
    test_obj.when = ['False']

# Generated at 2022-06-25 05:05:33.488551
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()

    conditional_1 = 'var_0 is defined and var_0 is defined'
    conditional_2 = 'var_0 is defined or var_1 is not defined'
    conditional_3 = 'var_1 is defined or not var_0'
    conditional_4 = 'var_0 is defined'
    conditional_5 = 'hostvars[host_0] is defined'
    conditional_6 = 'hostvars[host_0] is defined and hostvars[host_0] is defined'
    conditional_7 = 'hostvars[host_0] is defined or hostvars[host_1] is not defined'
    conditional_8 = 'hostvars[host_1] is defined or not hostvars[host_0]'

# Generated at 2022-06-25 05:05:50.757489
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    # Initialize instance of class Conditional
    conditional_1 = Conditional()

    # Test execution of method extract_defined_undefined of class Conditional
    # when the variable 'conditional' is not defined
    try:
        conditional_1.extract_defined_undefined(conditional)
    except NameError as ne:
        print("Testcase failed: variable conditional is not defined.")

    # Test execution of method extract_defined_undefined of class Conditional
    # when the variable 'conditional' is defined
    conditional_1.extract_defined_undefined("hostvars['foo'] is not defined")

    # Test execution of method extract_defined_undefined of class Conditional
    # when the variable 'conditional' is defined
    conditional_1.extract_defined_undefined("hostvars['foo'] is defined")

    #

# Generated at 2022-06-25 05:05:55.023751
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    conditional.when = [
        'foo',
        'bar in ["one", "two", "three", "four"]',
    ]

    result = conditional.evaluate_conditional({}, {'foo': 'True', 'bar': 'four'})


# Generated at 2022-06-25 05:06:01.442056
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    #Create Template
    templar = Templay()
    all_vars = dict()

    #Create Conditional object conditional
    conditional = Conditional()
    #Test 1
    conditional.when = "True"
    assert conditional.evaluate_conditional(templar, all_vars)

    #Test 2
    conditional.when = "False"
    assert not conditional.evaluate_conditional(templar, all_vars)

## Unit test for method _check_conditional() of class Conditional
#def test_Conditional__check_conditional():
#    #Create Template
#    templar = Templay()
#    all_vars = dict()
#
#    #Create Conditional object conditional
#    conditional = Conditional()
#
#    #Test 1
#    #Test 1.1
#    conditional

# Generated at 2022-06-25 05:06:09.372453
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    conditional_1._when = [
        'hostvars["host_play_3"]["var_play_3"] is not undefined',
        'result is not defined'
    ]
    def_undef_1 = [
        ('hostvars["host_play_3"]["var_play_3"]', 'is not', 'undefined'),
        ('result', 'is not', 'defined')
    ]
    assert conditional_1.extract_defined_undefined(conditional_1._when) == def_undef_1

    conditional_2 = Conditional()
    conditional_2._when = [
        'hostvars["host_play_4"]["var_play_4"] is undefined'
    ]

# Generated at 2022-06-25 05:06:13.423543
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # initialize a templar and a Conditional obj
    templar = Templar()
    my_vars = dict(var1="test")
    conditional_0 = Conditional()
    conditional_0._loader = DataLoader()
    conditional_0.when = ["var1 == 'test'"]

    # create the result we expect and compare it to the actual result returned
    my_result = True
    result = conditional_0.evaluate_conditional(templar, my_vars)
    assert result == my_result



# Generated at 2022-06-25 05:06:22.010997
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    assert conditional_1.evaluate_conditional(conditional_1, {}) == True
    #TODO: need to write test cases for isa:complex
    assert conditional_1._validate_when(FieldAttribute(isa=complex, default=complex), "when", "foo")
    assert conditional_1.evaluate_conditional(conditional_1, {}) == True
    #TODO: need to write test cases for isa:list
    assert conditional_1._validate_when(FieldAttribute(isa=list, default=list), "when", "foo")
    assert conditional_1.evaluate_conditional(conditional_1, {}) == True
    #TODO: need to write test cases for isa:raw

# Generated at 2022-06-25 05:06:29.541139
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    Unit test for Conditional.extract_defined_undefined
    '''
    conditional_test = Conditional()
    source_string_1 = "hostvars['foo'] is defined and hostvars['bar'] is not undefined"
    source_string_2 = "hostvars['foo'] is defined and hostvars['bar'] is not undefined and hostvars['baz'] is undefined"
    source_string_3 = "hostvars['foo']"
    source_string_4 = "hostvars['foo'] is undefined"
    source_string_5 = "hostvars['foo'] is undefined and hostvars['bar'] is not defined"
    source_string_6 = "defined_var is defined and undefined_var is not defined"

    extracted_string_1 = conditional_test.extract_defined_und

# Generated at 2022-06-25 05:06:36.658503
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    conditionals = ['ansible_os_family=="Windows"', 'not (ansible_os_family=="Red Hat" and ansible_distribution_major_version is version_compare("6", ">="))', None]

    for conditional_to_test in conditionals:
        result = conditional.evaluate_conditional(conditional_to_test)
        display.debug("Evaluated conditional (%s): %s" % (conditional_to_test, result))


# Generated at 2022-06-25 05:06:40.321101
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    conditional_0.when = [None]
    templar = None
    all_vars = dict()
    result = conditional_0.evaluate_conditional(templar, all_vars)
    assert result is True

# Generated at 2022-06-25 05:06:44.032796
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    template_0 = Template()
    templar_0 = Templar(template_0)
    all_vars_0 = dict()
    conditional_1 = 'True'
    conditional_0._when.append(conditional_1)
    assert conditional_0.evaluate_conditional(templar_0, all_vars_0)


# Generated at 2022-06-25 05:07:03.357153
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test case #0: Exact matches
    conditional_0 = Conditional()
    conditional_0._ds = {}
    conditional_0._values = {'when': ['a is b']}
    templar_0 = Templar(loader=DummyLoader())
    all_vars_0 = {}
    assert conditional_0.evaluate_conditional(templar=templar_0, all_vars=all_vars_0) is False
    conditional_1 = Conditional()
    conditional_1._ds = {}
    conditional_1._values = {'when': ['a == b']}
    templar_1 = Templar(loader=DummyLoader())
    all_vars_1 = {}

# Generated at 2022-06-25 05:07:12.741040
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    vars = dict(foo='a', bar=True, baz=['a', 'b', 'c', 'd'], foobar=dict(a='1', b='2', c='3'))
    # A conditional using a single variable
    assert Conditional().evaluate_conditional('bar', vars)
    # A conditional using a single undefined variable
    assert not Conditional().evaluate_conditional('baz.d', vars)
    # A simple comparison
    assert Conditional().evaluate_conditional('foo == "a"', vars)
    # A simple comparison with undefined variable
    assert not Conditional().evaluate_conditional('foo == baz', vars)
    # A simple comparison with undefined variable, with strict_undefined=False

# Generated at 2022-06-25 05:07:21.730323
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_0._handle_undefined_errors = "ignore"

    conditional_1 = '"{{ foo }}" is defined'
    conditional_idx_0 = 0
    conditional_result_1 = conditional_0.extract_defined_undefined(conditional_1)
    conditional_result_item_0_0 = conditional_result_1[conditional_idx_0]
    assert conditional_result_item_0_0[0] == 'foo'

    conditional_2 = '"{{ foo }}" is not defined'
    conditional_idx_0 = 0
    conditional_result_2 = conditional_0.extract_defined_undefined(conditional_2)
    conditional_result_item_0_0 = conditional_result_2[conditional_idx_0]

# Generated at 2022-06-25 05:07:26.447908
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    c = Conditional(loader=None)
    c.when = ['a', 'b']
    c._check_conditional = lambda x, y, z: x
    c.evaluate_conditional('t', 'a')
    assert c.when == ['b']


# Generated at 2022-06-25 05:07:27.930095
# Unit test for constructor of class Conditional
def test_Conditional():
    try:
        test_case_0()
    except TypeError as e:
        print(e)



# Generated at 2022-06-25 05:07:32.693688
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    conditional_1 = Conditional()
    conditional_1._loader = ""
    a = conditional_1.extract_defined_undefined("ansible_os_family == 'Debian'")
    print(a)





# Generated at 2022-06-25 05:07:37.125728
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    print("Test extract_defined_undefined")
    conditional_0 = Conditional()
    conditional_0.when = ['foo is defined', 'bar is undefined', 'a and b']
    assert conditional_0.extract_defined_undefined('foo is defined') == [['foo', 'is', 'defined']]
    assert conditional_0.extract_defined_undefined('bar is undefined') == [['bar', 'is', 'undefined']]
    assert conditional_0.extract_defined_undefined('a and b') == []


# Generated at 2022-06-25 05:07:45.902163
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    play_source = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    )

    # Create a playbook object, which automatically create a list of
    # tasks object, where each task is a Task object
    play = Play().load(play_source, variable_manager=VariableManager(), loader=Loader())

    # Now we create the actual Task objects
    tasks = [Task().load(task, variable_manager=play.get_variable_manager()) for task in play._entries]

    # Now we create the actual Conditional objects
    conditional_0 = Cond

# Generated at 2022-06-25 05:07:50.926003
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_0.when = ['1']
    conditional_0.when[0] = 'hostname=="foo" and hostvars[inventory_hostname][\'ansible_%s_interfaces\' | default(\'\')]|length > 1' % (C.DEFAULT_SYSTEM_FACTS)
    if conditional_0.evaluate_conditional():
        assert False


# Generated at 2022-06-25 05:07:55.876671
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    assert conditional_0 is not None
    conditional_0.when = "test"
    templar_0 = None
    all_vars_0 = None
    assert conditional_0.evaluate_conditional(templar_0, all_vars_0) is False
    assert conditional_0.when is "test"


# Generated at 2022-06-25 05:08:39.948142
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Prepare the execution environment
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)
    # Prepare the test object
    conditional_0 = Conditional(loader=loader)
    conditional_0.when = ['should_succeed']
    # Execute test
    assert conditional_0.evaluate_conditional(Templar(loader=loader, variables=variable_manager.get_vars(play=None, host=None)), variable_manager.get_vars(play=None, host=None))


# Generated at 2022-06-25 05:08:46.774992
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Note:
    # Templates used in the tests are adapted from the module_utils/facts/facts.py
    # They have to be valid python code else the compiler will throw exception.
    # See https://docs.python.org/2/library/ast.html for more information about AST.
    # We use ast.dump to remove the code indentation

    # Test 1:
    # Basic usage of "when"
    conditional_1 = Conditional()
    setattr(conditional_1, '_loader', 'test_loader')
    setattr(conditional_1, '_ds', 'test_ds')
    setattr(conditional_1, '_templar', 'test_templar')
    setattr(conditional_1, 'when', 'test_when')

# Generated at 2022-06-25 05:08:52.177223
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    conditional = 'hostvars["host1"]["ansible_all_ipv4_addresses"] == hostvars["host1"]["my_ipv4_addr"]'
    templar_0 = templar_init()
    all_vars_0 = all_vars_init()
    conditional_0.when = [conditional, ]
    verify_result(conditional_0, templar_0, all_vars_0)


# Generated at 2022-06-25 05:08:58.161406
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
   # Test 0 - simple test
   conditional_0 = Conditional()
   conditional = "not foo is defined and hostvars[inventory_hostname]['a']|d() is defined"
   result = conditional_0.extract_defined_undefined(conditional)
   expected_result = [('foo', 'is not', 'defined'), ('hostvars[inventory_hostname][\'a\']', 'is', 'defined')]
   assert result == expected_result

   # Test 1 - empty string
   conditional_1 = Conditional()
   conditional = ""
   result = conditional_1.extract_defined_undefined(conditional)
   expected_result = []
   assert result == expected_result

   # Test 2 - simple test 2
   conditional_1 = Conditional()

# Generated at 2022-06-25 05:09:03.980181
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    cond = "hostvars['hostname'] is not defined and hostvars['hostname'] is not defined"
    extracted_cond = conditional_1.extract_defined_undefined(cond)
    assert extracted_cond == [('hostvars[\'hostname\']', 'is not', 'defined'), ('hostvars[\'hostname\']', 'is not', 'defined')]


# Generated at 2022-06-25 05:09:09.376073
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()

    # Simulate evaluate_conditional() function when conditional_0._when is empty
    if (not conditional_0._when):
        return True


# Generated at 2022-06-25 05:09:12.033457
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    #test_case_0
    conditional_0 = Conditional()
    templar_0 = conditional_0._templar
    assert conditional_0.evaluate_conditional(templar_0, {}) == True


# Generated at 2022-06-25 05:09:15.449866
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional_0 = Conditional()
    assert conditional_0.evaluate_conditional('foo.bar', {'foo': {'bar': 42}})


# Generated at 2022-06-25 05:09:18.635711
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    templar = None
    all_vars = None
    assert conditional.evaluate_conditional(templar, all_vars) == True


# Generated at 2022-06-25 05:09:27.874514
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    conditional_1._ds = {}

    # Test case with an 'is_template' condition
    conditional_1.when = ['{{ foo }}']
    templar = Templar(loader=None)
    templar.basedir = '.'
    all_vars = dict()
    all_vars['foo'] = False
    assert conditional_1.evaluate_conditional(templar, all_vars) == False
    all_vars['foo'] = True
    assert conditional_1.evaluate_conditional(templar, all_vars) == True

    # Test case with an 'is defined' condition
    conditional_1.when = ['foo is defined']
    assert conditional_1.evaluate_conditional(templar, all_vars) == True
    all_vars.pop

# Generated at 2022-06-25 05:10:53.848819
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    try:
        conditional.extract_defined_undefined(None)
    except Exception:
        # AnsibleError exception is expected
        pass

    try:
        conditional.extract_defined_undefined({})
    except Exception:
        # AnsibleError exception is expected
        pass

    try:
        conditional.extract_defined_undefined([])
    except Exception:
        # AnsibleError exception is expected
        pass

    result = conditional.extract_defined_undefined('hostvars["foo"] is defined')
    assert result == [('hostvars["foo"]', 'is', 'defined')]

    result = conditional.extract_defined_undefined('hostvars["foo"] is not defined')
    assert result == [('hostvars["foo"]', 'is not', 'defined')]

# Generated at 2022-06-25 05:10:55.594930
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    cond = Conditional()
    result = cond.evaluate_conditional(None, {})
    assert result == True

# Generated at 2022-06-25 05:11:04.600027
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    display.display('TEST: test_Conditional_extract_defined_undefined()')
    conditional = Conditional()
    # test cases

# Generated at 2022-06-25 05:11:13.443027
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    cond = conditional_0._check_conditional('study > 80 and study < 90', None, None)
    assert(cond == False)
    cond = conditional_0._check_conditional('study > 80 and study < 90', None, None)
    assert(cond == False)
    cond = conditional_0._check_conditional(False, None, None)
    assert(cond == False)
    cond = conditional_0._check_conditional(True, None, None)
    assert(cond == True)
    cond = conditional_0._check_conditional('', None, None)
    assert(cond == True)
    cond = conditional_0._check_conditional(None, None, None)
    assert(cond == True)

# Generated at 2022-06-25 05:11:19.425276
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert Conditional().extract_defined_undefined("""
    (hostvars['foo'] is defined and hostvars['foo']['bar'] == 'baz') or
    (hostvars['boo'] is defined and hostvars['boo']['bar'] == 'baz')
    """) == \
    [
        ("hostvars['foo']", "is", "defined"),
        ("hostvars['boo']", "is", "defined"),
    ]


# Generated at 2022-06-25 05:11:25.292175
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # test 1
    conditional_1 = Conditional()
    conditional = "first is defined and hostvars['second'] is '{{ item }}'"
    result = conditional_1.extract_defined_undefined(conditional)
    assert result == [('first', ' is ', 'defined'), ('hostvars[\'second\']', ' is ', "'{{ item }}'")]

    # test 2
    conditional_2 = Conditional()
    conditional = "\"test\" is not defined or \"test\" is \"{{ item }}\""
    result = conditional_2.extract_defined_undefined(conditional)
    assert result == [('"test"', ' is not ', 'defined'), ('"test"', ' is ', '"{{ item }}"')]

    # test 3
    conditional_3 = Conditional()

# Generated at 2022-06-25 05:11:30.769585
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    conditional_0.when = ['a_b == b_a']
    conditional_0.vars = {'a_b': 'a_b'}
    conditional_0.all_vars = {'a_b': 'a_b', 'b_a': 'a_b'}
    result = conditional_0.evaluate_conditional(conditional_0.vars, conditional_0.all_vars)
    assert result == True
    conditional_0.when = ['a_b == b_a']
    conditional_0.vars = {'a_b': 'a_b'}
    conditional_0.all_vars = {'a_b': 'a_b', 'b_a': 'b_a'}

# Generated at 2022-06-25 05:11:40.024919
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    # if the following directories exist, they will be used in place of the default directories
    data = conditional.extract_defined_undefined(
        "hostvars['foo'] is defined or hostvars['bar'] is undefined"
    )
    assert data == [('hostvars[\'foo\']', 'is', 'defined'), ('hostvars[\'bar\']', 'is', 'undefined')]
    data = conditional.extract_defined_undefined(
        "hostvars['foo'] is not undefined or hostvars['bar'] is not defined"
    )
    assert data == [('hostvars[\'foo\']', 'is not', 'undefined'), ('hostvars[\'bar\']', 'is not', 'defined')]

# Generated at 2022-06-25 05:11:46.312584
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = display.templar
    all_vars_0 = {'inventory_hostname': 'localhost', 'playbook_dir': '.'}
    assert conditional_0.evaluate_conditional(templar_0, all_vars_0) == True


# Generated at 2022-06-25 05:11:51.321988
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_0 = Conditional()
    assert conditional_0 is not None

    # expected behavior: no error, since there are no when statements
    conditional_0.evaluate_conditional({}, [], [])
