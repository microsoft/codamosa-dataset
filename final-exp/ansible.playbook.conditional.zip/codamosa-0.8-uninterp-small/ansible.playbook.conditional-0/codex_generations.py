

# Generated at 2022-06-25 05:03:34.400561
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    test_list_0 = ['hostvars[inventory_hostname] is defined', ' {{ var1 }} is undefined', '', 'string1 is undefined']

    test_list_result_0 = [('hostvars[inventory_hostname]', 'is', 'defined'), ('var1', 'is', 'undefined'), ('string1', 'is', 'undefined')]

    conditional_0 = Conditional()

    assert conditional_0.extract_defined_undefined(test_list_0) == test_list_result_0



# Generated at 2022-06-25 05:03:35.708228
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    assert conditional_0.evaluate_conditional(conditional)

# Generated at 2022-06-25 05:03:47.248996
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_0._loader = None
    conditional_0.when = ['vault_password_file is defined', 'foo']
    ansible_vars = {}
    ansible_vault_passwords = {}
    ansible_python_interpreter = '/usr/local/bin/python'
    ansible_version = {'full': 'v2.3.0.0-1.el7.centos', u'full_string': '2.3.0.0-1.el7.centos'}
    ansible_included_var_files = {}
    ansible_connection = 'local'
    ansible_play_name = 'TESTPLAY'
    ansible_play_hosts = ['localhost']
    ansible_play_batch_size = 10
    ansible_

# Generated at 2022-06-25 05:03:50.187961
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    class MyCond(Conditional):
        def __init__(self):
            self._when = ["a"]

    mcond = MyCond()
    assert mcond.evaluate_conditional() == False


# Generated at 2022-06-25 05:03:55.693300
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional = 'hostvars[inventory_hostname] is defined and hostvars[inventory_hostname].ansible_default_ipv4.address'
    out = conditional_0.extract_defined_undefined(conditional)
    assert out == [('hostvars[inventory_hostname]', 'is', 'defined')]


# Generated at 2022-06-25 05:04:05.189623
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    display.debug("Evaluating conditional: '1.1 == 1.1'")
    assert Conditional._evaluate_conditional("1.1 == 1.1") == True
    display.debug("Evaluating conditional: '1.1 != 1.1'")
    assert Conditional._evaluate_conditional("1.1 != 1.1") == False

    display.debug("Evaluating conditional: '1 == 1'")
    assert Conditional._evaluate_conditional("1 == 1") == True
    display.debug("Evaluating conditional: '0 == 1'")
    assert Conditional._evaluate_conditional("0 == 1") == False
    display.debug("Evaluating conditional: '1.0 == 1'")
    assert Conditional._evaluate_conditional("1.0 == 1") == True

# Generated at 2022-06-25 05:04:11.192672
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    conditional_1.when = "test_case_1"
    templar_1 = Templar()
    # test_case_1 evaluates to "True"
    result = conditional_1._check_conditional(conditional_1.when, templar_1, {})
    assert result


# Generated at 2022-06-25 05:04:17.174904
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_0.when = ['defined_undefined_test_var is defined']
    result = conditional_0.extract_defined_undefined(conditional_0.when[0])
    assert result[0][0] == 'defined_undefined_test_var'
    assert result[0][1] == 'is'
    assert result[0][2] == 'defined'

    conditional_1 = Conditional()
    conditional_1.when = ['defined_undefined_test_var is not undefined']
    result = conditional_1.extract_defined_undefined(conditional_1.when[0])
    assert result[0][0] == 'defined_undefined_test_var'
    assert result[0][1] == 'is not'

# Generated at 2022-06-25 05:04:24.936443
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_1 = Conditional()

    conditional_0.when = 'hostvars[\'G2_host\'] is not defined'
    conditional_1.when = 'hostvars[\'G2_host\'] is not defined'
    conditional_0.extract_defined_undefined(conditional_0.when)
    conditional_1.extract_defined_undefined(conditional_1.when)
    assert (conditional_0.when == conditional_1.when)

# Generated at 2022-06-25 05:04:28.625543
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar = {}
    all_vars = {}
    conditional_0.evaluate_conditional(templar, all_vars)


# Generated at 2022-06-25 05:04:47.715136
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    test_success = 0
    test_fail = 0

    # Test-case 1 with valid defined/undefined condition.
    test_input_string = "ansible_eth0 is defined or ansible_tap0 is undefined and " \
                        "ansible_eth0 is not defined or ansible_lo is defined"

    # Expected Result test_case_1
    extracted_conditions = [['ansible_eth0', 'is', 'defined'],
                            ['ansible_tap0', 'is', 'undefined'],
                            ['ansible_eth0', 'is not ', 'defined'],
                            ['ansible_lo', 'is', 'defined']]

    conditional_1 = Conditional()

    test_out_string = conditional_1.extract_defined_undefined(test_input_string)

# Generated at 2022-06-25 05:04:56.395257
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    #
    # Test Conditional_evaluate_conditional for always false
    #
    conditional_0 = Conditional()
    conditional_0.when = [False]

    all_vars_0 = {"vars": {}}
    templar_0 = Conditional()._loader.templar
    result_0 = conditional_0.evaluate_conditional(templar_0, all_vars_0)
    assert result_0 == False
    #
    # Test Conditional_evaluate_conditional for always true
    #
    conditional_1 = Conditional()
    conditional_1.when = [True]

    all_vars_1 = {"vars": {}}
    templar_1 = Conditional()._loader.templar

# Generated at 2022-06-25 05:05:03.219110
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = None
    all_vars_0 = {}
    try:
        conditional_0.evaluate_conditional(templar_0, all_vars_0)
    except AnsibleError:
        pass
    except Exception as e:
        raise AssertionError("Unexpected Exception raised: %s" % type(e))


# Generated at 2022-06-25 05:05:08.843588
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    # Testcase1: to test if method will return empty list when no defined undefined check
    # is present in conditional check
    conditional_1 = Conditional()
    assert conditional_1.extract_defined_undefined(conditional_1) == []

    # Testcase2: to test if method will return correct list when defined undefined check
    # is present in conditional check
    conditional_2 = Conditional()
    assert conditional_2.extract_defined_undefined('cond_var1 is defined and cond_var2 is undefined') == \
           [('cond_var1', 'is', 'defined'), ('cond_var2', 'is', 'undefined')]

    # Testcase3: to test if method will return correct list when defined undefined check
    # is present in conditional check
    conditional_3 = Conditional()
    assert conditional_3.extract

# Generated at 2022-06-25 05:05:19.320737
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional_0 = Conditional()

    # Injecting a dummy templar and dummy all_vars.
    templar_0 = None
    all_vars_0 = {}

    # Test input: 'when': [set()]
    # Test expected output: None
    when_0_0 = set()
    conditional_0.run_once_when = when_0_0
    result_0 = conditional_0.evaluate_conditional(templar_0, all_vars_0)
    assert result_0 is None, 'result_0 did not return the expected value'

    # Test input: 'when': [dict()]
    # Test expected output: None
    when_0_0 = dict()
    conditional_0.run_once_when = when_0_0

# Generated at 2022-06-25 05:05:30.268435
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('foo not is defined') == [('foo', 'not is', 'defined')]
    assert conditional.extract_defined_undefined('foo not is undefined') == [('foo', 'not is', 'undefined')]
    assert conditional.extract_defined_undefined('foo is defined or bar is defined') == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-25 05:05:34.002707
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar = mock.MagicMock()
    all_vars = dict()
    conditional = 'yes'
    result = conditional_0.evaluate_conditional(templar, all_vars, conditional)
    assert result is True


# Generated at 2022-06-25 05:05:40.326154
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    conditional_0 = Conditional()
    var_conditional_0 = 'failed_when: foo not in bar'
    conditional_0.when = [ var_conditional_0 ]

    # expecting a empty list as foo is not defined or undefined
    var_expected_0 = []
    var_results_0 = conditional_0.extract_defined_undefined(var_conditional_0)

    assert var_results_0 == var_expected_0

    # expecting a empty list as foo is not defined or undefined
    var_expected_1 = []
    var_results_1 = conditional_0.extract_defined_undefined('hostvars["foo"] not in bar')

    assert var_results_1 == var_expected_1

    # expecting a empty list as foo is not defined or undefined
    var_expected_2 = []
   

# Generated at 2022-06-25 05:05:50.726264
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Test if the method can correctly return a list of strings
    results = Conditional().extract_defined_undefined("a is defined and b is not undefined")
    assert results[0][0] == 'a'
    assert results[0][1] == 'is'
    assert results[0][2] == 'defined'
    assert results[1][0] == 'b'
    assert results[1][1] == 'is not'
    assert results[1][2] == 'undefined'
    # Test if the method can correctly return a list of strings with a "lookup" in the conditional
    results = Conditional().extract_defined_undefined("a is defined and b is not undefined and {{ lookup('ini','some_key') }}")
    assert results[0][0] == 'a'

# Generated at 2022-06-25 05:05:52.471191
# Unit test for constructor of class Conditional
def test_Conditional():
    test_case_0()


# Generated at 2022-06-25 05:06:18.623191
# Unit test for constructor of class Conditional
def test_Conditional():
    test_case_0()

if __name__ == '__main__':
    test_Conditional()

# Generated at 2022-06-25 05:06:28.398077
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
     setattr(C, 'DEFAULT_KEEP_REMOTE_FILES', True)
     setattr(C, 'DEFAULT_MAX_FAIL_PERCENTAGE', 10)
     setattr(C, 'DEFAULT_UNTAR_OPTIONS', '-C')
     setattr(C, 'DEFAULT_LOCAL_TMP', '/tmp/ansible')
     setattr(C, 'DEFAULT_UNDEFINED_VAR_BEHAVIOR', 'warn')
     setattr(C, 'DEFAULT_DEBUG', True)
     setattr(C, 'DEFAULT_HASH_BEHAVIOUR', 'replace')
     setattr(C, 'DEFAULT_JINJA2_NATIVE', False)
     setattr(C, 'DEFAULT_INVENTORY_IGNORE', None)
     setattr

# Generated at 2022-06-25 05:06:38.240483
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    def f_true(a):
        return True

    def f_false(a):
        return False

    # make sure evaluate_conditional returns False when no conditionals are specified
    conditional_0 = Conditional()
    result_0 = conditional_0.evaluate_conditional(f_true, f_true)
    assert result_0 == True

    # make sure evaluate_conditional returns False on the first False conditional
    conditional_1 = Conditional()
    conditional_1._when = [True, True, False, True]
    result_1 = conditional_1.evaluate_conditional(f_true, f_true)
    assert result_1 == False

    # make sure evaluate_conditional returns True if no False conditional is found
    conditional_2 = Conditional()
    conditional_2._when = [True, True, True]
    result

# Generated at 2022-06-25 05:06:45.229853
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    conditional_1.when = "defined foo"
    def_undef = conditional_1.extract_defined_undefined(conditional_1.when)
    assert def_undef[0][0] == "foo"
    assert def_undef[0][1] == "is"
    assert def_undef[0][2] == "defined"

    # test with multiple def_undef entries
    conditional_2 = Conditional()
    conditional_2.when = "defined foo and not bar is undefined"
    def_undef = conditional_2.extract_defined_undefined(conditional_2.when)
    assert def_undef[0][0] == "foo"
    assert def_undef[0][1] == "is"

# Generated at 2022-06-25 05:06:49.098215
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional = '''(a == b and (c is defined or c is undefined)) or (d is defined or d is not undefined)'''
    assert conditional_0.extract_defined_undefined(conditional) == [('c', 'is', 'defined'), ('c', 'is', 'undefined'), ('d', 'is', 'defined'), ('d', 'is', 'not'), ('d', 'is', 'undefined')]

if __name__ == '__main__':

    pass

# Generated at 2022-06-25 05:06:58.221637
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert Conditional().extract_defined_undefined("hostvars[inventory_hostname].inventory_hostname is defined") == [('hostvars[inventory_hostname].inventory_hostname', 'is', 'defined')]
    assert Conditional().extract_defined_undefined("hostvars[inventory_hostname].inventory_hostname is not defined") == [('hostvars[inventory_hostname].inventory_hostname', 'is not', 'defined')]
    assert Conditional().extract_defined_undefined("hostvars[inventory_hostname].inventory_hostname not is defined") == [('hostvars[inventory_hostname].inventory_hostname', 'not is', 'defined')]

    # Test that define/undefined checks are also handled when they are not the only part of the conditional
    assert Conditional().extract_defined_

# Generated at 2022-06-25 05:07:04.343845
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    all_vars = dict()
    conditional_0.when = ["True"]
    assert conditional_0.evaluate_conditional(conditional_0, all_vars) == True


# Generated at 2022-06-25 05:07:06.770544
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_1 = Conditional()
    assert conditional_1


# Generated at 2022-06-25 05:07:17.681083
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    _for_unit_test_extract_defined_undefined(
        "test_1 is defined",
        [("test_1", "is", "defined")]
    )

    _for_unit_test_extract_defined_undefined(
        "test_4 not is a defined",
        [("test_4", "not is", "a defined")]
    )

    _for_unit_test_extract_defined_undefined(
        "test_2 is not undefined",
        [("test_2", "is not", "undefined")]
    )

    _for_unit_test_extract_defined_undefined(
        "test_3 is a undefined",
        [("test_3", "is", "a undefined")]
    )

    _for_unit_test_extract_defined_und

# Generated at 2022-06-25 05:07:20.396948
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_0 = Conditional()

if __name__ == "__main__":
    test_Conditional()

# Generated at 2022-06-25 05:08:37.179442
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional_1 = Conditional()

    conditional_1._ds = {'name': 'Conditional'}

    conditional_1.when = ['test1', 'test2', 'test3']

    def _check_conditional(conditional, templar, all_vars):
        return True

    conditional_1._check_conditional = _check_conditional

    assert conditional_1.evaluate_conditional(None, None) is True


# Generated at 2022-06-25 05:08:40.896816
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    conditional_0_templar = None
    conditional_0_all_vars = None
    try:
        __result__ = conditional_0.evaluate_conditional(conditional_0_templar, conditional_0_all_vars)
        assert(False)
    except TypeError:
        assert(True)


# Generated at 2022-06-25 05:08:45.834619
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_exists = Conditional()
    # base case where we have a variable being undefined
    conditional_exists.when = ['test_var is defined']
    conditional_exists.evaluate_conditional(conditional_exists, {})



# Generated at 2022-06-25 05:08:51.175339
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    conditional_1._when.extend([True,False,True])
    assert conditional_1.evaluate_conditional("error","error") == True


# Generated at 2022-06-25 05:08:52.729036
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    # This is how you would add attributes to the conditional
    #conditional.when = ["<condition>"]


# Generated at 2022-06-25 05:08:57.922275
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = conditional_0._loader.get_basedir()
    all_vars_0 = { 'test_var': 'something', 'test_var_2': 'something_else', 'test_var_3': 'something_else_else' }
    boolean_0 = conditional_0.evaluate_conditional(templar_0, all_vars_0)
    assert boolean_0 == True


# Generated at 2022-06-25 05:09:07.304385
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # {'_ds': {}, '_loader': <ansible.parsing.dataloader.DataLoader object at 0x7f23f14c69b0>, '_variable_manager': <ansible.vars.manager.VariableManager object at 0x7f23f14c61d0>}
    args = {}
    args['_ds'] = {}
    args['_loader'] = 'dummy_loader'
    args['_variable_manager'] = 'dummy_variable_manager'
    x = Conditional(**args)

    # {'conditional': 'foo', 'templar': <ansible.template.Templar object at 0x7f23f14c62b0>, 'all_vars': {}}
    args = {}
    args['conditional'] = 'foo'

# Generated at 2022-06-25 05:09:15.016178
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test case 1: test if the condition is boolean
    # Create a ansible block
    conditional_1 = Conditional()
    # Set when condition to true
    conditional_1.when = "True"
    # Check if the condition is True
    assert conditional_1.evaluate_conditional(None, None)
    # Set when condition to false
    conditional_1.when = "False"
    # Check if the condition is False
    assert not conditional_1.evaluate_conditional(None, None)

    # Test case 2: test if the condition is a boolean variable
    # Create a ansible block
    conditional_2 = Conditional()
    # Set when condition to a boolean variable
    # Create all_vars for the test
    all_vars = dict()
    all_vars['var'] = True

# Generated at 2022-06-25 05:09:25.543751
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_0.when = ['hostvars["foo"] is defined or hostvars["foo"] not in hostvars["bar"]', 'hostvars["bar"] is not defined']
    expected_0 = [('hostvars["foo"]', 'is defined', 'defined'), ('hostvars["foo"]', 'not in', 'undefined'), ('hostvars["bar"]', 'is not', 'undefined')]
    actual_0 =  conditional_0.extract_defined_undefined(conditional_0.when)
    assert expected_0 == actual_0
    conditional_1 = Conditional()
    conditional_1.when = ['hostvars["foo"] is defined and hostvars["bar"] is defined']

# Generated at 2022-06-25 05:09:30.509607
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    templar_1     = None
    all_vars_1    = None

    try:
        display.display('Testing evaluate_conditional method of Conditional class')
        conditional_1.evaluate_conditional(templar_1, all_vars_1)
        return True
    except Exception as e:
        display.display('The following exception was thrown when testing Conditional.evaluate_conditional:\n %s' % str(e))
        return False


# Generated at 2022-06-25 05:12:14.366619
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Create instances of required classes
    conditional_0 = Conditional()
    loader_0 = AnsibleLoader(None, None)
    templar_0 = Templar()

    # Assign values to the class variables of conditional_0

    # Assign values to the class variables of templar_0

    # Assign values to the class variables of loader_0
    #Templar class uses _loader to load variables from inventory file into memory
    loader_0._loader = conditional_0._loader
    conditional_0._loader = loader_0
    templar_0._loader = loader_0

    # Create an instance of AnsibleVars, function name is evaluate_conditional
    ans_0 = AnsibleVars()
    ans_0.evaluate_conditional(templar_0, conditional_0._loader)

# Generated at 2022-06-25 05:12:17.926972
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    conditional_1_result = conditional_1.extract_defined_undefined(u"hostvars['foo'] is not defined")
    expected = [(u"hostvars['foo']", u"is not", u"defined")]
    assert conditional_1_result == expected, "Output: %s" % conditional_1_result
test_Conditional_extract_defined_undefined()


# Generated at 2022-06-25 05:12:24.678839
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()

    # in evaluate_conditional, the templar is the only one that matter.
    # all_vars is used in the method, but it's ok if it's not a dict
    templar = None
    all_vars = None

    # when = []
    # result = conditional_0.evaluate_conditional(templar, all_vars)
    # assert result is True

    # when = [0]
    # result = conditional_0.evaluate_conditional(templar, all_vars)
    # assert result is False

    when = [1]
    result = conditional_0.evaluate_conditional(templar, all_vars)
    assert result is True

    when = [0, 1]

# Generated at 2022-06-25 05:12:33.905858
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    print('\n')
    if len(conditional_0.extract_defined_undefined('foo is undefined')) == 0:
        print('Test 0 Extract Defined Undefined: PASS')
    else:
        print('Test 0 Extract Defined Undefined: FAILED')
    if len(conditional_0.extract_defined_undefined('foo is defined')) == 0:
        print('Test 1 Extract Defined Undefined: PASS')
    else:
        print('Test 1 Extract Defined Undefined: FAILED')
    if len(conditional_0.extract_defined_undefined('foo not is undefined')) == 0:
        print('Test 2 Extract Defined Undefined: PASS')
    else:
        print('Test 2 Extract Defined Undefined: FAILED')

# Generated at 2022-06-25 05:12:38.891035
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    c=Conditional()
    templar = type('Templar', (), {"is_template": lambda self, x: False,
                                   "template": lambda self, x, disable_lookups: x})()
    assert c.evaluate_conditional(templar, [])
    assert c.evaluate_conditional(templar, ["foo"])


# Generated at 2022-06-25 05:12:47.730790
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_1 = Conditional()
    conditional_2 = Conditional()
    conditional_3 = Conditional()
    conditional_4 = Conditional()
    conditional_5 = Conditional()

    # Test case 0: 'hostvars["{{ ansible_hostname }}"] is not defined'
    assert conditional_0.extract_defined_undefined('hostvars["{{ ansible_hostname }}"] is not defined') == [('hostvars["{{ ansible_hostname }}"]', 'is not', 'defined')]

    # Test case 1: 'hostvars["{{ ansible_hostname }}"] is defined'

# Generated at 2022-06-25 05:12:52.536579
# Unit test for constructor of class Conditional
def test_Conditional():
    try:
        conditional_0 = Conditional()
    except Exception as err:
        assert(False)


# Generated at 2022-06-25 05:12:58.626908
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    # This test is to test the case when the conditional is not defined:
    # expected value: []
    conditional_1 = Conditional()
    result_1 = conditional_1.extract_defined_undefined(None)
    assert result_1 == []

    # This test is to test the case when the conditional is empty:
    # expected value: []
    conditional_2 = Conditional()
    result_2 = conditional_2.extract_defined_undefined("")
    assert result_2 == []

    # This test is to test the case when the conditional doesn't include any defined undefiend:
    # expected value: []
    conditional_3 = Conditional()
    result_3 = conditional_3.extract_defined_undefined("(1 or 2) and 3")
    assert result_3 == []

    # These test are to

# Generated at 2022-06-25 05:13:01.730717
# Unit test for constructor of class Conditional
def test_Conditional():

    obj = Conditional()
    assert isinstance(obj, Conditional)


# Generated at 2022-06-25 05:13:09.441474
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    conditional.when = [
        "foo is defined and (bar is defined or baz is defined)",
        "foo is undefined or bar is not defined"
    ]
    res = conditional.extract_defined_undefined(conditional.when[0])
    assert res == [('bar', 'is', 'defined'), ('baz', 'is', 'defined'), ('foo', 'is', 'defined')]
    res = conditional.extract_defined_undefined(conditional.when[1])
    assert res == [('bar', 'is', 'not defined'), ('foo', 'is', 'undefined')]
