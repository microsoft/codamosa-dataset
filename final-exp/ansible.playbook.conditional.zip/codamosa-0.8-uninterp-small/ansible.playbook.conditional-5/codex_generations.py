

# Generated at 2022-06-25 05:03:32.519306
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    templar_2 = Object()
    all_vars_3 = Object()
    assert conditional_1.evaluate_conditional(templar_2, all_vars_3) == True


# Generated at 2022-06-25 05:03:37.303617
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('hostvars["foo"] is defined') == [('hostvars["foo"]', 'is', 'defined')]
    assert conditional.extract_defined_undefined('hostvars["foo"] is defined and hostvars["foo"] is defined') == [('hostvars["foo"]', 'is', 'defined'), ('hostvars["foo"]', 'is', 'defined')]
    assert conditional.extract_defined_undefined('hostvars["foo"] is defined and hostvars["foo"] is not defined') == [('hostvars["foo"]', 'is', 'defined'), ('hostvars["foo"]', 'is not', 'defined')]

# Generated at 2022-06-25 05:03:47.323351
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    c = Conditional()

    # Variables for test
    all_vars = dict(a=1)
    templar = templar_class()

    # Use real objects
    assert c.evaluate_conditional(templar, all_vars) == True

    # Use errors
    assert c.evaluate_conditional(0, all_vars) == False
    assert c.evaluate_conditional("", all_vars) == False
    assert c.evaluate_conditional(None, all_vars) == False
    assert c.evaluate_conditional(templar_class(), None) == False
    assert c.evaluate_conditional(templar_class(), "") == False
    assert c.evaluate_conditional(templar_class(), 0) == False


# Generated at 2022-06-25 05:03:56.856975
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-25 05:04:05.554220
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_0.when = [
        'some_var != some_other_var',
        'some_var is defined',
        '\'not defined\' not in somelist',
        'somelist is undefined',
        'some_var is not defined'
    ]

    assert conditional_0.extract_defined_undefined(conditional_0.when[0]) == []
    assert conditional_0.extract_defined_undefined(conditional_0.when[1]) == [('some_var', 'is', 'defined')]
    assert conditional_0.extract_defined_undefined(conditional_0.when[2]) == [('somelist', 'not in', 'undefined')]

# Generated at 2022-06-25 05:04:12.919438
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()

    # Test passing only required parameters
    # Test return value from evaluate_conditional and assert it is True
    assert conditional_0.evaluate_conditional(templar=None, all_vars=None) == True

    # Test passing some other value for required paremters
    # Test return value from evaluate_conditional and assert it is False
    assert conditional_0.evaluate_conditional(templar="templar", all_vars="all_vars") == False

# Generated at 2022-06-25 05:04:21.026187
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional_1 = Conditional()

    all_vars = {'foo': 'bar'}
    test_case_1 = conditional_1.evaluate_conditional(conditional_1._templar, all_vars)
    assert test_case_1 == True

    all_vars = {}
    test_case_2 = conditional_1.evaluate_conditional(conditional_1._templar, all_vars)
    assert test_case_2 == True

    all_vars = {'foo': 'bar'}
    conditional_1._when = ['foo is bar']
    test_case_3 = conditional_1.evaluate_conditional(conditional_1._templar, all_vars)
    assert test_case_3 == True


# Generated at 2022-06-25 05:04:27.132488
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

# Generated at 2022-06-25 05:04:32.452484
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_0.when = ['foo is defined or bar is undefined']
    conditional_0.evaluate_conditional(conditional_0.when[0])

    result = conditional_0.extract_defined_undefined(conditional_0.when[0])
    assert result == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]


# Generated at 2022-06-25 05:04:40.187758
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    result = conditional_1.extract_defined_undefined("ansible_facts['os']['distribution'] is 'Debian'")
    if len(result) != 0:
        assert False

    result = conditional_1.extract_defined_undefined("hostvars[inventory_hostname]['ansible_facts']['os']['distribution'] is 'Debian'")
    if len(result) != 0:
        assert False

    result = conditional_1.extract_defined_undefined("hostvars[inventory_hostname]['ansible_facts']['os']['distribution'] is not defined")

# Generated at 2022-06-25 05:04:56.553224
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_0 = Conditional()


# if __name__ == "__main__":
#     test_case_0()

# Generated at 2022-06-25 05:05:00.609912
# Unit test for constructor of class Conditional
def test_Conditional():
    if test_case_0() == None:
        print("Unit test OK")
    else:
        print("Unit test FAILED")

if __name__ == '__main__':
    test_Conditional()

# Generated at 2022-06-25 05:05:05.600928
# Unit test for constructor of class Conditional
def test_Conditional():
    if not os.path.exists(C.DEFAULT_LOCAL_TMP) or not os.access(C.DEFAULT_LOCAL_TMP, os.W_OK):
        C.DEFAULT_LOCAL_TMP = '/tmp'
        sys.stdout.write("Using /tmp as a tmp dir")

    test_case_0()

if __name__ == '__main__':
    test_Conditional()

# Generated at 2022-06-25 05:05:13.545945
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

# Generated at 2022-06-25 05:05:19.431985
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Setup
    conditional_0 = Conditional()
    conditional_0._loader = DummyLoader()
    conditional_0.when = []
    templar_0 = DummyTemplar()
    all_vars_0 = {}

    # Invocation
    result = conditional_0.evaluate_conditional(templar_0, all_vars_0)

    # Verification
    assert result


# Generated at 2022-06-25 05:05:20.907602
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    conditional_1.when = ['\'asd\' in "aasd"']
    cond_result = conditional_1.evaluate_conditional(None, {})
    assert cond_result == True


# Generated at 2022-06-25 05:05:31.611610
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    cond_0 = Conditional()
    cond_0.when = ['(0 == 1)', '(1 == 1)']
    cond_0.when = ['(0 == 1)', '(1 == 1)']
    cond_0.when = ['(0 == 1)', '(1 == 1)']
    cond_0.when = ['(0 == 1)', '(1 == 1)']
    cond_0.when = ['(0 == 1)', '(1 == 1)']
    cond_0.when = ['(0 == 1)', '(1 == 1)']
    cond_0.when = ['(0 == 1)', '(1 == 1)']
    res_0_0 = cond_0.evaluate_conditional(None, None)
    assert res_0_0 is True


# Generated at 2022-06-25 05:05:38.887494
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar = Object()
    templar.is_template = Mock()
    templar.template = Mock()
    templar.template.return_value = "False"
    templar.available_variables = dict()
    all_vars = dict()
    conditional_0.when = [None, ""]
    conditional_0.when_eval = "True"

    # set @patch decoration here
    with patch('ansible.playbook.conditional.AnsibleError') as mock_error:
        assert conditional_0.evaluate_conditional(templar, all_vars) is False
        assert mock_error.called is True

# Generated at 2022-06-25 05:05:42.694059
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_extract_defined_undefined = Conditional()
    conditional_extract_defined_undefined.when = 'result|success'
    conditional_extract_defined_undefined.extract_defined_undefined('{{upgrade_result.changed}} | {{upgrade_result.success}} is success')


# Generated at 2022-06-25 05:05:49.454738
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    '''
    Test evaluate conditional with the following params:
        * Conditional
        * templar=dict
        * all_vars=dict
        * conditional=None
    This test should return the following:

    '''
    conditional_1 = Conditional({ '_ds': { 'name': 'test', 'when': [ 'True' ], 'register': 'test' } }, None)
    templar_1 = {}
    all_vars_1 = {}
    conditional_1 = None
    assert conditional_1.evaluate_conditional(templar_1, all_vars_1) == None


# Generated at 2022-06-25 05:06:13.449653
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    # Input and expected results
    i = [
        "moo is defined",
        "foo is not defined",
        "bar is undefined",
        "foo is defined or bar is undefined or hostvars['localhost'] == none",
        "wibble is undefined or foo is defined and bar == 'moo'"
    ]

# Generated at 2022-06-25 05:06:22.085355
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    conditional_1.when = [None]
    assert conditional_1.evaluate_conditional()

    conditional_2 = Conditional()
    conditional_2.when = [""]
    assert conditional_2.evaluate_conditional()

    conditional_3 = Conditional()
    conditional_3.when = "true"
    assert conditional_3.evaluate_conditional()

    conditional_4 = Conditional()
    conditional_4.when = "false"
    assert not conditional_4.evaluate_conditional()

    conditional_5 = Conditional()
    conditional_5.when = "1 == 1"
    assert conditional_5.evaluate_conditional()

    conditional_6 = Conditional()
    conditional_6.when = "1 == 2"
    assert not conditional_6.evaluate_conditional()

    conditional

# Generated at 2022-06-25 05:06:30.121435
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # create a Conditional object
    conditional_1 = Conditional()

    # extract_defined_undefined(conditional)
    conditional = 'hostvars[inventory_hostname] is undefined'
    results = conditional_1.extract_defined_undefined(conditional)
    assert results == [('hostvars[inventory_hostname]', 'is', 'undefined')]

    conditional = 'inventory_hostname is defined and hostvars[inventory_hostname] is not defined'
    results = conditional_1.extract_defined_undefined(conditional)
    assert results == [('inventory_hostname'  , 'is', 'defined'),
                       ('hostvars[inventory_hostname]', 'is not', 'defined')]


# Generated at 2022-06-25 05:06:37.549755
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'),('bar', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("bar is not defined") == [('bar', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("bar is undefined") == [('bar', 'is', 'undefined')]


# Generated at 2022-06-25 05:06:41.723909
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    templar_1 = templar_0()
    all_vars_1 = dict()

    # Calling evaluate_conditional with arguments (templar_0, dict)
    # evaluate_conditional() returns True
    assert conditional_1.evaluate_conditional(templar_1, all_vars_1) == True



# Generated at 2022-06-25 05:06:43.851267
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    
    # TODO: Implement
    pass


# Generated at 2022-06-25 05:06:49.795423
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_0.when = ["'9' == '9'", '1 == 1', 'not 1 == 1', "'foo' is defined", '"bar" is defined', "'baz' is undefined", '"qux" is undefined', "1 == 1 and 'foo' is defined", "1 == 1 or 'foo' is not defined"]

    keys = ['1 == 1', '"bar" is defined', '"baz" is undefined', '"qux" is undefined']
    values = ['1 == 1', '1', 'defined', 'undefined']
    expected_0 = list(zip(keys, values))
    expected_0 = [(["'foo'"], 'is'), (['defined'], ''), (["'baz'"], 'is'), (['undefined'], '')]

# Generated at 2022-06-25 05:06:58.279274
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    Tests the extract_defined_undefined method of the Conditional class.
    '''

# Generated at 2022-06-25 05:07:04.670715
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar = None
    all_vars = {'foo': 'bar'}

    conditional = "'bar' == foo"
    assert conditional_0.evaluate_conditional(templar, all_vars) == True


# Generated at 2022-06-25 05:07:13.145131
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    conditional_0 = Conditional()

    assert conditional.extract_defined_undefined("1") == []
    assert conditional.extract_defined_undefined("not 1") == []
    assert conditional.extract_defined_undefined("1 not") == []
    assert conditional.extract_defined_undefined("hostvars['hostname'] not is defined") == [('hostvars[\'hostname\']', 'not is', 'defined')]
    assert conditional.extract_defined_undefined("hostvars['hostname'] not is undefined") == [('hostvars[\'hostname\']', 'not is', 'undefined')]

# Generated at 2022-06-25 05:07:32.991951
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    #assert conditional_0.evaluate_conditional() == expected
    #assert conditional_0.evaluate_conditional() == expected
    #assert conditional_0.evaluate_conditional() == expected
    #assert conditional_0.evaluate_conditional() == expected
    #assert conditional_0.evaluate_conditional() == expected



# Generated at 2022-06-25 05:07:35.825521
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    try:
        conditional_1 = Conditional()
        attribs = {"when": "test_var"}
        conditional_1.set_attributes_from_dict(attribs)
        assert conditional_1.evaluate_conditional(None, None) == False
    except:
        assert False


# Generated at 2022-06-25 05:07:45.300153
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(
        foo="bar",
        baz=True,
        undef=None,
    )

    conditional = Conditional()
    assert conditional.evaluate_conditional(
        variable_manager.get_vars_loader(loader_name='lines', path_name='ansible/vars/manager.yml', class_name='VariableLoader')
    ) is True

    conditional.when.append("undef is defined")
    assert conditional.evaluate_conditional(
        variable_manager.get_vars_loader(loader_name='lines', path_name='ansible/vars/manager.yml', class_name='VariableLoader')
    ) is False

    conditional.when = []
    conditional

# Generated at 2022-06-25 05:07:54.766243
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    class DummyPlay:
        pass
    class Dummy(Conditional):
        pass

    # Base class has no _ds attribute but Conditional derives from Base
    test_case_0()

    conditional_1 = Conditional()
    conditional_1.when = ['foobar']
    loader = DataLoader()
    templar = Templar(loader=loader)
    play = DummyPlay()
    play.hostvars = dict()
    play._variable_manager = VariableManager(loader=loader, inventory=Inventory(loader=loader))
    all_vars = play._variable_

# Generated at 2022-06-25 05:07:56.204238
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    # Check if the object is initialized
    if conditional is None:
        print('Failed to instantiate Conditional')



# Generated at 2022-06-25 05:08:03.110207
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    assert conditional_1.extract_defined_undefined("foo is defined") == [("foo", "is", 'defined')]
    assert conditional_1.extract_defined_undefined("foo is not defined") == [("foo", "is not", 'defined')]
    assert conditional_1.extract_defined_undefined("foo is undefined") == [("foo", "is", 'undefined')]
    assert conditional_1.extract_defined_undefined("foo is not undefined") == [("foo", "is not", 'undefined')]
    assert conditional_1.extract_defined_undefined("foo is not bar and bar is not defined") == [("foo", "is not", 'bar'), ("bar", "is not", 'defined')]
    assert conditional_1.extract_defined_und

# Generated at 2022-06-25 05:08:12.008685
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    # Test case 0
    conditional_0 = Conditional(loader=conditional._loader)
    conditional_0.when = ['(a==1) and (b==2) and (c==3) and (d==4)']
    expected = [
        ('a', '==', '1'),
        ('b', '==', '2'),
        ('c', '==', '3'),
        ('d', '==', '4'),
    ]
    res = conditional_0.extract_defined_undefined(conditional_0.when[0])
    assert res == expected

    # Test case 1
    conditional_1 = Conditional(loader=conditional._loader)

# Generated at 2022-06-25 05:08:18.532046
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    assert conditional_0.extract_defined_undefined('hostvars[inventory_hostname] is defined') == \
        [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert conditional_0.extract_defined_undefined('') == []
    assert conditional_0.extract_defined_undefined(
        '"{{ inventory_hostname }}" is not defined and hostvars[inventory_hostname] is undefined') == \
        [('hostvars[inventory_hostname]', 'is', 'undefined')]


# Generated at 2022-06-25 05:08:23.206630
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-25 05:08:31.862873
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    result_1 = conditional_1.extract_defined_undefined(u'(ansible_ssh_user is defined)')
    assert result_1 == [(u'ansible_ssh_user', u'is', u'defined')]
    result_2 = conditional_1.extract_defined_undefined(u'(ansible_ssh_user is defined) and (foo is not undefined)')
    assert result_2 == [(u'ansible_ssh_user', u'is', u'defined'), (u'foo', u'is not', u'undefined')]
    result_3 = conditional_1.extract_defined_undefined(u'ansible_ssh_user is defined')
    assert result_3 == []


# Generated at 2022-06-25 05:09:08.310748
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()

    conditional_1 = "os == 'Darwin'"
    expected_result_1 = []
    actual_result_1 = conditional_0.extract_defined_undefined(conditional_1)
    assert actual_result_1 == expected_result_1

    conditional_2 = "os == 'Darwin' and hostvars['a']['a'] is defined and hostvars['a']['a']['b'] is defined"
    expected_result_2 = [('hostvars[a][a]', 'is', 'defined'), ('hostvars[a][a][b]', 'is', 'defined')]
    actual_result_2 = conditional_0.extract_defined_undefined(conditional_2)
    assert actual_result_2 == expected_result_2

    conditional

# Generated at 2022-06-25 05:09:14.757290
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    conditional_1 = Conditional()
    # Test if the defined_undefined method detects and extracts variables defined undefined tests
    assert conditional_1.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert conditional_1.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert conditional_1.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert conditional_1.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert conditional_1.extract_defined_undefined('foo and bar is defined') == [('foo', 'and', 'bar is defined')]
    assert conditional_1.ext

# Generated at 2022-06-25 05:09:16.374704
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_1 = Conditional()

# Generated at 2022-06-25 05:09:23.380366
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    ########################################################################
    # Setup
    ########################################################################
    conditional_0 = Conditional()

    conditional_0.when = "test_conditional"
    all_vars_0 = {'test_conditional': True}

    ########################################################################
    # Test
    ########################################################################
    conditional_0.evaluate_conditional(None, all_vars_0)

    ########################################################################
    # Verify
    ########################################################################


# Generated at 2022-06-25 05:09:31.476802
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_good = Conditional()
    assert conditional_good.extract_defined_undefined("A is defined or B is defined") == [('A', 'is', 'defined'), ('B', 'is', 'defined')]
    assert conditional_good.extract_defined_undefined("C is undefined or D is undefined") == [('C', 'is', 'undefined'), ('D', 'is', 'undefined')]
    assert conditional_good.extract_defined_undefined("A is not undefined or B is not undefined") == [('A', 'is not', 'undefined'), ('B', 'is not', 'undefined')]
    assert conditional_good.extract_defined_undefined("C is not defined or D is not defined") == [('C', 'is not', 'defined'), ('D', 'is not', 'defined')]

# Generated at 2022-06-25 05:09:38.128906
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    test_case_0()
    kwargs = dict()
    kwargs['templar'] = test_case_0.templar
    kwargs['all_vars'] = test_case_0.templar
    test_case_0.evaluate_conditional(**kwargs)


# Generated at 2022-06-25 05:09:40.145998
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # setup
    conditional_0 = Conditional()
    ne_result = conditional_0.evaluate_conditional(templar, all_vars)

    assert expected == ne_result



# Generated at 2022-06-25 05:09:49.127658
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    # Test Undefined
    conditional_0 = Conditional()
    value_0 = conditional_0.extract_defined_undefined('hostvars[inventory_hostname] is undefined')
    value_1 = conditional_0.extract_defined_undefined('hostvars[inventory_hostname] is not undefined')
    value_2 = conditional_0.extract_defined_undefined('server is undefined')
    value_3 = conditional_0.extract_defined_undefined('server is not undefined')
    value_4 = conditional_0.extract_defined_undefined('hostvars[inventory_hostname] is undefined and hostvars[inventory_hostname] is undefined')

    assert value_0 == [('hostvars[inventory_hostname]', 'is', 'undefined')]

# Generated at 2022-06-25 05:09:53.711386
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('myvar is defined and thatvar is defined') == [('myvar', 'is', 'defined'), ('thatvar', 'is', 'defined')]
    assert conditional.extract_defined_undefined('myvar is defined and thatvar is defined and myvar is undefined') == [('myvar', 'is', 'defined'), ('thatvar', 'is', 'defined'), ('myvar', 'is', 'undefined')]


# Generated at 2022-06-25 05:09:59.343770
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.module_utils.six import PY3
    from ansible.template import Templar
    from ansible.vars import VariableManager
    # Create Conditional object
    conditional_0 = Conditional()
    # Create VariableManager object
    variableManager_0 = VariableManager()
    # Create Templar object
    templar_0 = Templar(variableManager_0, None)
    # Create dict object
    all_vars_0 = {}
    # Set the attribute _ds of conditional_0
    # to None
    conditional_0._ds = None
    # Set the attribute when of conditional_0
    # to a single value
    # NOTE: We manually set the attribute instead
    #       of calling setattr to avoid changing the
    #       state of the original object

# Generated at 2022-06-25 05:11:35.981932
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_eval = Conditional()

    conditional_stripped = "{{ foo }} != 'bar'"
    conditional_with_newlines = "{{ foo }} != 'bar' \n {% if blah %} blah {% else %} blah {% endif %}"
    conditional_with_jinja = "{{ foo }} != {{ bar }}"
    conditional_with_jinja2 = "{% if foo %} False {% else %} True {% endif %}"
    conditional_with_jinja2_2 = "{% if foo %} True {% else %} False {% endif %}"
    conditional_with_jinja2_3 = "{% if foo %} True {% endif %}"
    conditional_with_jinja2_4 = "{% if foo %} False {% endif %}"


# Generated at 2022-06-25 05:11:43.888693
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional = Conditional()

    # Test 0: None conditional
    res = conditional.evaluate_conditional(None, None)
    assert res is True

    # Test 1: Empty string conditional
    res = conditional.evaluate_conditional(None, None)
    assert res is True

    # Test 2: True conditional
    res = conditional.evaluate_conditional(None, None)
    assert res is True

    # Test 3: False conditional
    res = conditional.evaluate_conditional(None, None)
    assert res is False



# Generated at 2022-06-25 05:11:51.540692
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-25 05:11:59.010885
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()


# Generated at 2022-06-25 05:12:08.143822
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    # Test positive results

# Generated at 2022-06-25 05:12:15.631865
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    print("Testing Conditional.evaluate_conditional")

    conditional_0 = Conditional()

    setattr(conditional_0, "_ds", None)
    setattr(conditional_0, "when", ["today == 'May'", True, "1 > 2"])

    setattr(conditional_0, "_loader", None)
    templar_0 = conditional_0._loader.shared_loader_obj.templar

    all_vars_0 = {"hostvars": {}, "groups": {}}
    print(conditional_0.evaluate_conditional(templar_0, all_vars_0))

    setattr(conditional_0, "_loader", None)
    templar_1 = conditional_0._loader.shared_loader_obj.templar


# Generated at 2022-06-25 05:12:22.443990
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = Conditional()
    conditional_1.when = [True]
    templar_1 = None
    all_vars_1 = dict()
    assert conditional_1.evaluate_conditional(templar_1, all_vars_1) == True
    assert not hasattr(conditional_1, '_ds')


# Generated at 2022-06-25 05:12:27.545123
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    results = conditional.extract_defined_undefined("(ansible_os_family is defined)")
    assert len(results) == 1
    assert results[0][0] == 'ansible_os_family'
    assert results[0][1] == 'is'
    assert results[0][2] == 'defined'



# Generated at 2022-06-25 05:12:35.031604
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    def test_case_1(condition, expected_result):
        conditional_1 = Conditional()
        conditional_1.when = condition
        result = conditional_1._check_conditional(conditional_1.when, templar, all_vars)
        assert result == expected_result

    def test_case_2(condition, expected_result):
        conditional_2 = Conditional()
        conditional_2.when = condition
        result = conditional_2._check_conditional(conditional_2.when, templar, all_vars)
        assert result == expected_result

    all_vars = {
        'var_1': 'True',
        'var_2': 'True',
        'var_3': 'False',
        'var_4': 'False'
    }

    from ansible.template import Templar

# Generated at 2022-06-25 05:12:37.438236
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    conditional = "ansible_architecture is not defined"
    expected = [(u'ansible_architecture', u'is not', u'defined')]
    actual = conditional_1.extract_defined_undefined(conditional)
    assert actual == expected
