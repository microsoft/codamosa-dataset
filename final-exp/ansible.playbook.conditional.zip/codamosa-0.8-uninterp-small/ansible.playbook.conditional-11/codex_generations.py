

# Generated at 2022-06-25 05:03:34.180163
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    tuple_0 = ()
    conditional_0 = Conditional()
    conditional_0.when = ['hostvars[inventory_hostname] is defined']
    conditional_0.evaluate_conditional(conditional_0.when, tuple_0)
    assert tuple_0[0][0] is 'hostvars[inventory_hostname]'
    assert tuple_0[0][1] is 'is'
    assert tuple_0[0][2] is 'defined'


# Generated at 2022-06-25 05:03:40.640634
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    import pylint
    import pylint_plugin_utils
    import ansible.template.safe_eval

    # Test conditions:
    # case-0:
    # Verify the method returns a boolean value

    # case-1:
    # Verify the method returns a boolean value

    # case-2:
    # Verify the method returns a boolean value

    # case-3:
    # Verify the method returns a boolean value

    # case-4:
    # Verify the method returns a boolean value

    # case-5:
    # Verify the method returns a boolean value

    # case-6:
    # Verify the method returns a boolean value

    # case-7:
    # Verify the method returns a boolean value

    # case-8:
    # Verify the method returns a boolean value

    # case-

# Generated at 2022-06-25 05:03:49.047207
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    tuple_0 = (1, 1)
    s_0 = '"yI@7vx8@;W4'
    tuple_1 = (1, 1)
    s_1 = 'N6Uy"/Ei%c/;'
    tuple_2 = (1, 1)
    s_2 = '7ZuCw>p.aqSz'

    conditional_0 = Conditional()
    conditional_1 = Conditional()
    conditional_2 = Conditional()
    conditional_3 = Conditional()
    conditional_4 = Conditional()
    conditional_5 = Conditional()
    conditional_6 = Conditional()
    conditional_7 = Conditional()
    conditional_8 = Conditional()
    conditional_9 = Conditional()
    conditional_10 = Conditional()

    # Test setting when

    conditional

# Generated at 2022-06-25 05:03:58.513676
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    the_vars = dict()
    the_vars['inventory_hostname'] = "ansible_inventory_hostname_value"
    the_vars['group_names'] = "ansible_group_names_value"
    the_vars['groups'] = "ansible_groups_value"
    the_vars['omit'] = "ansible_omit_value"

    # Replace these values with real data
    conditional_0.when = ["ansible_inventory_hostname_value in group_names", "ansible_group_names_value in groups", "ansible_groups_value in inventory_hostname"]
    templar_0 = ansible.parsing.dataloader.Loader()
    # End replace

    # Return the value returned by the function
    return conditional

# Generated at 2022-06-25 05:04:04.180712
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    from ansible.template import Templar

    templar_0 = Templar(loader=None, variables={})
    all_vars_0 = {}

    returned_value_0 = conditional_0.evaluate_conditional(templar_0, all_vars_0)
    print(returned_value_0)
    assert type(returned_value_0) == bool


# Generated at 2022-06-25 05:04:09.926102
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    tuple_0 = ()
    conditional_0 = Conditional()
    conditional_0.extract_defined_undefined('hostvars[inventory_hostname] is defined')


# Generated at 2022-06-25 05:04:17.678431
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test with a tuple as conditional
    # tuple_0 = ()
    # conditional_0 = Conditional()
    tuple_0 = ()
    conditional_0 = Conditional()
    templar_0 = templar_0_instance = AnsibleTemplate(template=tuple_0, all_vars={})
    all_vars_0 = {}
    assert conditional_0.evaluate_conditional(templar_0, all_vars_0) == True


# Generated at 2022-06-25 05:04:25.816419
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Instantiate conditional_0 object
    tuple_0 = ()
    conditional_0 = Conditional()
    # Assign value to variable
    conditional_0.when = tuple_0
    # Instantiate templar_0 object
    tuple_1 = ()
    templar_0 = tuple_1
    # Assign value to variable
    all_vars_0 = tuple_0
    # Call method evaluate_conditional of conditional_0
    try:
        conditional_0.evaluate_conditional(templar_0, all_vars_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 05:04:29.657936
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = None
    all_vars_0 = None
    ret_val = conditional_0.evaluate_conditional(templar_0, all_vars_0)
    assert ret_val is False


# Generated at 2022-06-25 05:04:38.422779
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    tuple_0 = (1, "a")
    tuple_1 = (tuple_0, 2, ("a", "a"))
    tuple_2 = (tuple_0, 2, ("a", "a"))
    tuple_3 = (tuple_1, 2, tuple_2)
    dict_4 = {'a': 'a'}
    dict_5 = {'a': 'a'}
    dict_6 = {'a': 'a', 'b': dict_4}
    dict_7 = {'a': 'a', 'b': dict_4}
    dict_8 = {'a': 'a', 'b': dict_4}
    dict_9 = {'a': 'a', 'b': dict_4, 'c': dict_5}

# Generated at 2022-06-25 05:04:55.393351
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    conditional_1 = Conditional()
    conditional_2 = Conditional()
    conditional_3 = Conditional()
    conditional_4 = Conditional()
    conditional_5 = Conditional()
    conditional_6 = Conditional()
    conditional_7 = Conditional()
    conditional_8 = Conditional()
    conditional_9 = Conditional()
    conditional_10 = Conditional()
    conditional_11 = Conditional()
    conditional_12 = Conditional()
    conditional_13 = Conditional()
    conditional_14 = Conditional()
    conditional_15 = Conditional()
    conditional_16 = Conditional()
    conditional_17 = Conditional()
    conditional_18 = Conditional()
    conditional_19 = Conditional()
    conditional_20 = Conditional()
    conditional_21 = Conditional()
   

# Generated at 2022-06-25 05:05:06.764822
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional = Conditional()

    when_0 = [None]
    templar_0 = object()
    all_vars_0 = dict()
    result_0 = conditional.evaluate_conditional(templar_0, all_vars_0)
    assert result_0


    when_1 = ['']
    templar_1 = object()
    all_vars_1 = dict()
    result_1 = conditional.evaluate_conditional(templar_1, all_vars_1)
    assert result_1


    when_2 = [True]
    templar_2 = object()
    all_vars_2 = dict()
    result_2 = conditional.evaluate_conditional(templar_2, all_vars_2)
    assert result_2

    when_3

# Generated at 2022-06-25 05:05:08.872275
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_0 = Conditional()
    assert conditional_0._when == list
    assert conditional_0._loader == None


# Generated at 2022-06-25 05:05:12.868783
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_0 = Conditional()
    assert conditional_0 is not None


# Generated at 2022-06-25 05:05:24.391352
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Conditional variable "xxx" is defined.
    def test_evaluate_conditional_0():
        conditional_0 = Conditional()

        conditional_0._ds = "test_Conditional_evaluate_conditional_0"
        conditional_0.when = [{ "foo": "bar" }]

        all_vars_0 = dict()
        all_vars_0["foo"] = "bar"
        all_vars_0["xxx"] = "bar"

        templar_0 = Templar(loader=None)

        result = conditional_0.evaluate_conditional(templar_0, all_vars_0)

        assert result == True

    test_evaluate_conditional_0()

    # Conditional variable "xxx" is not defined

# Generated at 2022-06-25 05:05:33.488686
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test case 0: Conditional.__init__(loader=None)
    conditional_0 = Conditional()

    # Test case 1: Conditional.evaluate_conditional(templar=None, all_vars=None)
    conditional_1 = Conditional()
    conditional_1.when = ['ansible_os_family == "RedHat"']

# Generated at 2022-06-25 05:05:43.073121
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
   c = Conditional()
   valid_conditional = 'foo'
   invalid_conditional = 'hostvars["foo"]'
   display.debug('Evaluating valid conditional')
   test_result = c.evaluate_conditional(valid_conditional, {})
   assert test_result == True, "Failed to evaluate conditional: %s" % valid_conditional
   display.debug('Evaluating invalid conditional')
   test_result = c.evaluate_conditional(invalid_conditional, {})
   assert test_result == False, "Failed to evaluate conditional: %s" % invalid_conditional


# Generated at 2022-06-25 05:05:50.919764
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
	conditional_0 = Conditional()
	conditional_1 = Conditional()
	conditional_2 = Conditional()
	conditional_3 = Conditional()
	conditional_4 = Conditional()
	conditional_5 = Conditional()
	conditional_6 = Conditional()
	conditional_7 = Conditional()
	conditional_8 = Conditional()

	result_0 = conditional_0.extract_defined_undefined('')
	result_1 = conditional_1.extract_defined_undefined('hostvars[inventory_hostname] is defined')
	result_2 = conditional_2.extract_defined_undefined('hostvars[\'xyz\'] is not defined')
	result_3 = conditional_3.extract_defined_undefined('hostvars[A] is not defined')


# Generated at 2022-06-25 05:06:01.149699
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_0.when = ['foo is defined or bar is undefined or baz is not defined', 'foo is defined', 'bar is defined']

    assert conditional_0.extract_defined_undefined('foo is defined or bar is undefined or baz is not defined') == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined'), ('baz', 'is not', 'defined')]
    assert conditional_0.extract_defined_undefined('hello world') == []
    assert conditional_0.extract_defined_undefined('hello is undefined') == [('hello', 'is', 'undefined')]
    assert conditional_0.extract_defined_undefined("'hello' is undefined") == [('hello', 'is', 'undefined')]
    assert conditional_0.extract_

# Generated at 2022-06-25 05:06:03.755773
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional_1 = Conditional()

    all_vars = dict()
    all_vars['1'] = 1

    conditional_1._when = [ '1 == 1' ]

    templar = Conditional()

    print(conditional_1.evaluate_conditional(templar, all_vars))


# Generated at 2022-06-25 05:06:22.972557
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()

    conditional = "abc is undefined or def is not defined"
    result = conditional_1.extract_defined_undefined(conditional)
    assert result == [('abc', 'is', 'undefined'), ('def', 'is not', 'defined')]

    conditional = "not (abc is defined or def is undefined)"
    result = conditional_1.extract_defined_undefined(conditional)
    assert result == [('abc', 'is', 'defined'), ('def', 'is', 'undefined')]

    conditional = "abc is defined and def is defined"
    result = conditional_1.extract_defined_undefined(conditional)
    assert result == [('abc', 'is', 'defined'), ('def', 'is', 'defined')]


# Generated at 2022-06-25 05:06:30.680284
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # set up our objects for the test
    conditional_1 = Conditional()
    conditional_1.when = 'verbosity > 0'
    conditional_2 = Conditional()
    conditional_2.when = 'verbosity > 1'
    conditional_3 = Conditional()
    conditional_3.when = 'verbosity > 10'
    conditional_4 = Conditional()
    conditional_4.when = 'verbosity > 1'
    conditional_5 = Conditional()
    conditional_5.when = 'verbosity > 1'
    conditional_6 = Conditional()
    conditional_6.when = 'verbosity > 1'
    conditional_7 = Conditional()
    conditional_7.when = 'verbosity > 1'

    # create a dict of all_vars

# Generated at 2022-06-25 05:06:39.385767
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    conditional_1.when = 'var1 is defined'
    assert conditional_1.extract_defined_undefined(conditional_1.when) == [('var1', 'is', 'defined')]
    conditional_2 = Conditional()
    conditional_2.when = 'var1 is undefined'
    assert conditional_2.extract_defined_undefined(conditional_2.when) == [('var1', 'is', 'undefined')]
    conditional_3 = Conditional()
    conditional_3.when = 'var1 not is defined'
    assert conditional_3.extract_defined_undefined(conditional_3.when) == [('var1', 'not is', 'defined')]
    conditional_4 = Conditional()

# Generated at 2022-06-25 05:06:45.789738
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    conditional.when = 'foo'
    # Should return False
    assert conditional.evaluate_conditional(conditional, {'foo': True}) == False

    conditional.when = 'foo'
    # Should return False
    assert conditional.evaluate_conditional(conditional, {'foo': False}) == False



# Generated at 2022-06-25 05:06:53.718037
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    all_vars = {}
    templar = Ansible()

    # Test evaluate_conditional() with parameters.
    #
    # This should raise an AnsibleError exception.
    #

    # This is the test data for this test case.
    #
    #  conditional | conditional template | expected result
    #  ---------------------------------------------------
    #  1           | True                 | True
    #  2           | False                | False
    #  3           | 1                    | True
    #  4           | 0                    | False
    #  5           | ""                   | Empty string (false)
    #  6           | '""'                 | Empty string (false)
    #  7           | None                 | None (false)
    #  8           | '"{{MYSTRING}}"'     | Empty string (false)

# Generated at 2022-06-25 05:07:03.060682
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-25 05:07:12.710429
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Since class Conditional is a mix-in, need to instantiate a class that contains Conditional
    # as a mix-in. Using class Base for this purpose
    conditional_1 = Conditional()

    # Note: These tests are is a follow-on of the Ansible test_conditional_evaluation.py tests
    #       which were extracted out of Ansible 2.2.0.0
    conditional_1.when = "foo is defined"
    conditional_1.evaluate_conditional(0,0)
    assert conditional_1.extract_defined_undefined("foo is defined")[0][0] == "foo"

    conditional_1.when = "['a', 'b'] is defined"
    conditional_1.evaluate_conditional(0,0)

# Generated at 2022-06-25 05:07:22.187276
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_1 = Conditional()
    assert [] == conditional_1.extract_defined_undefined('foo is defined')

    conditional_2 = Conditional()
    assert [('a', 'is not', 'defined')] == conditional_2.extract_defined_undefined('a is not defined')

    conditional_3 = Conditional()
    assert [('a', 'is not', 'defined'),
            ('a', 'not is', 'undefined')] == conditional_3.extract_defined_undefined('a is not defined and a not is undefined')

    conditional_4 = Conditional()
    assert [('a', 'not is', 'undefined'),
            ('a', 'is not', 'defined')] == conditional_4.extract_defined_undefined('a not is undefined and a is not defined')


# Generated at 2022-06-25 05:07:28.388219
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = conditional_0.loader._templar
    templar_1 = conditional_0.loader._templar
    all_vars = {"all_vars": set()}
    print("INPUT: ", "all_vars", )
    print("OUTPUT: ", conditional_0.evaluate_conditional(templar_0, all_vars, ))


# Generated at 2022-06-25 05:07:33.029038
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = Templar()
    all_vars_0 = dict()
    Conditional_evaluate_conditional_ret_0 = conditional_0.evaluate_conditional(templar_0, all_vars_0)

# Generated at 2022-06-25 05:08:16.770673
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_0 = FixtureTemplar()
    # set up the all_vars dictionary
    all_vars = dict()
    all_vars['hostvars'] = dict()
    all_vars['hostvars']['localhost'] = dict()
    all_vars['hostvars']['localhost']['ansible_hostname'] = 'localhost'
    # call method
    conditional_0.set_loader(templar_0)
    result_1 = conditional_0.evaluate_conditional(templar_0, all_vars)
    assert result_1 == True, 'Conditional.evaluate_conditional did not return expected result'


# Generated at 2022-06-25 05:08:26.943574
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_1 = Conditional()

    # Positive Testing

# Generated at 2022-06-25 05:08:36.964913
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-25 05:08:44.139964
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = dict(
        become=True,
        become_method='sudo',
        become_user='root',
        diff=False,
        remote_addr='127.0.0.1',
        remote_user='vagrant',
        roles_path='/usr/share/ansible/roles:/etc/ansible/roles',
        verbosity=2,
    )
    host = inventory

# Generated at 2022-06-25 05:08:55.383286
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    expected_0 = [
        (u'hostvars[inventory_hostname]', u'is', u'defined'),
        (u'hostvars[inventory_hostname]', u'is', u'undefined'),
        (u'hostvars[inventory_hostname]', u'is not', u'undefined'),
        (u'hostvars[inventory_hostname]', u'not is', u'defined'),
        (u'var_1', u'is', u'defined'),
        (u'var_1', u'is', u'undefined'),
        (u'var_1', u'is not', u'undefined'),
        (u'var_1', u'not is', u'defined')]

# Generated at 2022-06-25 05:09:06.210679
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    test_conditional_0 = "((a or b) and (c and d))"

    result = conditional.extract_defined_undefined(test_conditional_0)
    assert result == []

    test_conditional_1 = "a or b == 'test' and c and d is defined"

    result = conditional.extract_defined_undefined(test_conditional_1)
    assert result == [('d', 'is', 'defined')]

    test_conditional_2 = "a or b == 'test' and c and d is not defined"

    result = conditional.extract_defined_undefined(test_conditional_2)
    assert result == [('d', 'is not', 'defined')]


# Generated at 2022-06-25 05:09:14.862159
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Evaluate conditionals and return true or false
    '''

    conditional_1 = Conditional()
    conditional_1._ds = {'test', 'test'}
    # conditionals = ['1+1==2', '2+2==3']
    conditionals = ['{{ 1+1 }} == 2', '{{ 2+2 }} == 3']
    result_1 = conditional_1.evaluate_conditional(conditionals)
    assert result_1 is True

    conditional_2 = Conditional()
    conditionals = ['{{ 1+1 }} == 2', '{{ 2+2 }} == 4']
    result_2 = conditional_2.evaluate_conditional(conditionals)
    assert result_2 is False

if __name__ == '__main__':
    test_case_0()
    test_Conditional_evaluate_

# Generated at 2022-06-25 05:09:19.552196
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    conditional_str_0 = "hostvars['foo'] is not defined"
    conditional_str_1 = "hostvars['foo'] is defined"
    conditional_str_2 = "hostvars['foo'] not is undefined"
    conditional_str_3 = "hostvars['foo'] is not undefined"
    conditional_str_4 = "hostvars['foo'].bar is defined"

    conditional_str_5 = "hostvars['foo'] is undefined or hostvars['bar'] is defined"

    conditional_str_6 = "hostvars['foo'] is undefined or (hostvars['bar'] is defined and hostvars['baz'] is undefined)"

    cond_0 = conditional.extract_defined_undefined(conditional_str_0)
    cond_1 = conditional.extract

# Generated at 2022-06-25 05:09:28.316594
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    conditional_0._ds = {
        'name': 'localhost',
        'hostvars': dict(test1=1, test2=2, test3=3)
    }
    templar_0 = conditional_0._loader.load_basedir('/')

# Generated at 2022-06-25 05:09:31.109731
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar = jinja2.environment.Environment()
    all_vars = dict()
    result = conditional_0.evaluate_conditional(templar, all_vars)


# Generated at 2022-06-25 05:10:59.971175
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    assert (conditional_0.evaluate_conditional('undefined is defined', {}) == True)



# Generated at 2022-06-25 05:11:07.681450
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # set up and test
    conditional_1 = Conditional()
    conditional_1_test = conditional_1.extract_defined_undefined("test is defined or true")
    assert conditional_1_test == [("test", "is", "defined")]


# Generated at 2022-06-25 05:11:16.357640
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Test case where condition has undefined variable
    test_case_1_conditional_string = "ansible_distribution is defined"
    test_case_1_conditional_object = Conditional()
    test_case_1_conditional_object.when = [text_type(test_case_1_conditional_string)]
    test_case_1_variables = dict()

# Generated at 2022-06-25 05:11:22.463472
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_1 = True
    conditional_2 = False
    conditional_3 = "{{ inventory_hostname == 'localhost'}}"
    conditional_4 = "{{ inventory_hostname == 'meow'}}"
    conditional_5 = "{{ inventory_hostname == 'meow'}} and {{ inventory_hostname == 'meow'}}"
    conditional_6 = "{{ inventory_hostname == 'meow'}} and {{ inventory_hostname != 'meow'}}"
    conditional_7 = "{{ inventory_hostname == 'meow'}} or {{ inventory_hostname == 'meow'}}"
    conditional_8 = "{{ inventory_hostname == 'meow'}} or {{ inventory_hostname != 'meow'}}"

# Generated at 2022-06-25 05:11:28.270292
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    Tests extract_defined_undefined method of class Conditional

    :CaseLevel: Unit

    ..note::  This function requires internet access
    '''
    conditional_0 = Conditional()
    conditional_1 = "hostvars['localhost']['ansible_service_mgr'] == 'systemd' and hostvars['localhost']['ansible_service_mgr'] is defined"
    conditional_2 = "hostvars['localhost']['ansible_service_mgr'] is defined and hostvars['localhost']['ansible_service_mgr'] == 'systemd'"
    conditional_3 = "hostvars['localhost']['ansible_service_mgr'] == 'systemd' and hostvars['localhost']['ansible_service_mgr'] is not defined"

# Generated at 2022-06-25 05:11:31.142615
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    templar_1 = Conditional()
    all_vars_0 = Conditional()

    assert conditional_0.evaluate_conditional(templar_1, all_vars_0) == True


# Generated at 2022-06-25 05:11:36.795214
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_0 = Conditional()
    conditional_0.when = ['hostvars[inventory_hostname] is not defined']
    assert conditional_0.extract_defined_undefined("hostvars[inventory_hostname] is not defined") == [("hostvars[inventory_hostname]", "is not", "defined")]


# Generated at 2022-06-25 05:11:39.984105
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_0 = Conditional()
    assert conditional_0.evaluate_conditional() is None


# Generated at 2022-06-25 05:11:47.325887
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional(): # temp_dir
    # Setup of test case
    conditional_1 = Conditional()
    conditional_1.when = [("item.skipped==True or item.skipped=='True'"), ("item.skipped==True or item.skipped=='True'")]
    templar = 'templar'
    all_vars = dict()

    # Exercise
    conditional_1.evaluate_conditional(templar, all_vars)



# Generated at 2022-06-25 05:11:56.290349
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    global display

    class FakeTemplar:
        def __init__(self, template_text):
            self.template_text = False
            self.undefined_string = False
            self.defined_string = False
            self.template_text = template_text

        def template(self, template_text, fail_on_undefined=True, disable_lookups=False):
            if self.template_text == 'undefined':
                return self.undefined_string
            elif self.template_text == 'defined':
                return self.defined_string
            else:
                return self.template_text

        def is_template(self, template_text):
            return self.template_text == 'template'

    class FakePlay:
        def __init__(self):
            self.vars = dict()
            self.host