

# Generated at 2022-06-23 06:03:22.021837
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Sample data
    conditional_str = 'a is defined or b is not defined'
    expected_results = [('a', 'is', 'defined'), ('b', 'is not', 'defined')]
    conditional_test = Conditional()

    # Call method
    results = conditional_test.extract_defined_undefined(conditional_str)

    # Compare results
    assert len(results) == len(expected_results)
    assert results == expected_results



# Generated at 2022-06-23 06:03:33.715123
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar

    class MyClass(Conditional):
        def __init__(self):
            pass

    myclass = MyClass()

    myclass.when = [
        "ansible_os_family == 'RedHat' and not ansible_distribution_major_version is defined",
        "ansible_os_family == 'RedHat' and ansible_distribution_major_version != '7'",
        "ansible_os_family == 'RedHat' and ansible_distribution_major_version is not defined"]

    templar = Templar(loader=None)


# Generated at 2022-06-23 06:03:44.044456
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

    # this conditional should contain three 'defined' and three 'undefined'
    conditional = "a is defined and b is not defined and c is undefined and d is not undefined and e is defined and f is undefined"
    def_undef_list = c.extract_defined_undefined(conditional)

    assert len(def_undef_list) == 6
    assert def_undef_list[0] == ('a', 'is', 'defined')
    assert def_undef_list[1] == ('b', 'is not', 'defined')
    assert def_undef_list[2] == ('c', 'is', 'undefined')
    assert def_undef_list[3] == ('d', 'is not', 'undefined')

# Generated at 2022-06-23 06:03:52.675109
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

    tests = {
        'foo is defined and not bar is defined': [('foo', 'is', 'defined'), ('bar', 'not is', 'defined')],
        'foo is defined or bar_baz is undefined': [('foo', 'is', 'defined'), ('bar_baz', 'is', 'undefined')],
        'not foo is defined': [('foo', 'not is', 'defined')],
    }

    for conditional, expected in tests.items():
        result = cond.extract_defined_undefined(conditional)
        assert result == expected, "Expected '%s', Got '%s'" % (expected, result)



# Generated at 2022-06-23 06:04:03.443078
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Setup for the test
    inv_manager = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inv_manager)

    # Make a mock class to use Conditional methods
    class TestConditional(Conditional):
        def __init__(self, loader, variable_manager=variable_manager, all_vars=dict()):
            self._loader = loader
            self._variable_manager = variable_manager
            self.available_variables = all_vars

    # Example for all_vars equal to dict({u'ansible_all_ipv4_addresses': [u'10.0.2.15'], u'my_

# Generated at 2022-06-23 06:04:13.414199
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.variable_manager import VariableManager
    from ansible.template import Templar

    c = Conditional(loader=None)
    assert c._when == list

    pc = PlayContext()
    vm = VariableManager()
    c = Conditional(play_context=pc, loader=None, variable_manager=vm)
    assert isinstance(c.templar, Templar)
    assert c.templar._available_variables == vm.get_vars(loader=None, play=c._play, host=c._host)
    assert c.templar._fail_on_undefined_errors

    pc = PlayContext()
    vm = VariableManager()

# Generated at 2022-06-23 06:04:21.748634
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    cond = Conditional()

    assert cond.extract_defined_undefined('string') == []
    assert cond.extract_defined_undefined('') == []

    assert cond.extract_defined_undefined('a is defined') == [('a', 'is', 'defined')]
    assert cond.extract_defined_undefined('a not is defined') == [('a', 'not is', 'defined')]
    assert cond.extract_defined_undefined('a is not defined') == [('a', 'is not', 'defined')]
    assert cond.extract_defined_undefined('a not is not defined') == [('a', 'not is not', 'defined')]
    assert cond.extract_defined_undefined('a is undefined') == [('a', 'is', 'undefined')]


# Generated at 2022-06-23 06:04:32.204822
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("random_var is defined") == [("random_var", "is", "defined")]
    assert cond.extract_defined_undefined("random_var not is undefined") == [("random_var", "not is", "undefined")]
    assert cond.extract_defined_undefined("hostvars['foo'] is defined") == [("hostvars['foo']", "is", "defined")]
    assert cond.extract_defined_undefined("hostvars[\"foo\"] not is undefined") == [("hostvars[\"foo\"]", "not is", "undefined")]
    assert cond.extract_defined_undefined("\"foo\" is defined") == [("\"foo\"", "is", "defined")]
    assert cond.ext

# Generated at 2022-06-23 06:04:34.360968
# Unit test for constructor of class Conditional
def test_Conditional():
    # 'loader' is only required for direct use of Conditional class
    c = Conditional(loader=None)
    assert c

# Generated at 2022-06-23 06:04:44.354306
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """
    Test only method evaluate_conditional of class
    Conditional

    :return:
    """
    # add an entry to the variable_manager that would otherwise be
    # set by the PlayContext
    variable_manager = VariableManager()
    variable_manager._extra_vars = dict()

    # create a mock inventory object which we'll use to create a
    # variable manager
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-23 06:04:54.000634
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert Conditional().extract_defined_undefined("hostvars[inventory_hostname] is not defined") \
        == [("hostvars[inventory_hostname]", "is not", "defined")]
    assert Conditional().extract_defined_undefined("hostvars[inventory_hostname] is defined") \
        == [("hostvars[inventory_hostname]", "is", "defined")]
    assert Conditional().extract_defined_undefined("hostvars[inventory_hostname] is not undefined") \
        == [("hostvars[inventory_hostname]", "is not", "undefined")]

# Generated at 2022-06-23 06:05:06.331726
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

# Generated at 2022-06-23 06:05:16.910009
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    # if a variable is defined
    conditional_defined = "a is defined "
    # if a variable is not defined
    conditional_undefined = "b is undefined "
    # if a variable is not defined but not used the not
    conditional_neg_undefined = "c is undefined "
    # if a variable is not defined but with a preceding not
    conditional_not_undefined = "d is not undefined "
    # if a variable is defined but with a preceding not and not used is
    conditional_neg_defined = "e is not defined "
    # if a variable is defined with hostvars
    conditional_hostvars_defined = "hostvars['asdfgh'] is defined "
    # if a variable is not defined with the hostvars

# Generated at 2022-06-23 06:05:29.231724
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.role_include import IncludeRole
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # test with a class that has the conditional property
    i_r = IncludeRole(loader=loader, variable_manager=None, path='dummy')
    i_r.when = [ 'dummy', '{{ dummy|d() }}', '{{ dummy|d()|__unsafe__ }}' ]
    t = Templar(loader=loader, variables={'dummy':'ok'})

    # test that every conditional returns True
    assert i_r.evaluate_conditional(templar=t, all_vars={'dummy':'ok'})

    # test that every conditional returns False
    assert not i_r.evaluate_conditional

# Generated at 2022-06-23 06:05:40.203585
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-23 06:05:51.298592
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

    assert(cond.extract_defined_undefined("{{ true }}") == [])
    assert(cond.extract_defined_undefined("{{ true and true }}") == [])
    assert(cond.extract_defined_undefined("{{ true or true }}") == [])
    assert(cond.extract_defined_undefined("{{ foo is defined }}") == [("foo", "is", "defined")])
    assert(cond.extract_defined_undefined("{{ foo is not defined }}") == [("foo", "is not", "defined")])
    assert(cond.extract_defined_undefined("{{ foo is defined or true }}") == [("foo", "is", "defined")])

# Generated at 2022-06-23 06:06:01.733115
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.playbook.base import Base
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    host = Host(name='test')
    host.vars = HostVars(host=host, variables={'test_var': "bla"})
    inventory = InventoryManager(loader=DataLoader(), sources=[])
    inventory.add_host(host=host, group='test_group')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    my_vars = {'test_var': "bla"}


# Generated at 2022-06-23 06:06:11.931342
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    ##############
    # define some variables to test with
    #############
    truthy = 1
    falsey = 0
    # The variables defined below are from a host in the inventory.
    # They are a subset of the variables available in a standard
    # playbook run. An actual playbook run may have some different
    # values for some of these variables.

# Generated at 2022-06-23 06:06:13.152599
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c._when == []

# Generated at 2022-06-23 06:06:24.981915
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    host_vars = HostVars(dict())
    loader = DictDataLoader({})
    templar = Templar(loader=loader, variables=host_vars)

    # Default value for when:
    when = []
    # Here should be True, because when is empty.
    result = Conditional._check_conditional(when, templar, host_vars)
    assert result

    # When is a string but not a boolean.
    when = 'true'
    result = Conditional._check_conditional(when, templar, host_vars)
    assert result

    # When is a string and a boolean.
    when = 'yes'

# Generated at 2022-06-23 06:06:34.171994
# Unit test for constructor of class Conditional
def test_Conditional():
    print ('Test Conditional() empty')
    c = Conditional()
    print ('Test Conditional() with empty when')
    c = Conditional(None)
    print ('Test Conditional() with when')
    c = Conditional(None, when=True)
    print ('Test Conditional() with when: [True, False]')
    c = Conditional(None, when=[True, False])
    print ('Test Conditional() with when: str')
    c = Conditional(None, when='True or False')


# Generated at 2022-06-23 06:06:45.337151
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    def get_variable(varname):
        if varname == 'my_var':
            return 'my_value'

    class TestClass(object):
        __metaclass__ = Conditional

    class TestTemplar(object):
        @staticmethod
        def template(s, **kwargs):
            return s

        @staticmethod
        def is_template(s, **kwargs):
            return s

        def set_available_variables(self, variables):
            self.variables = variables

    class TestLoader(object):
        def __init__(self):
            tc = TestClass()
            tc._loader = self
            self.tc = tc

        def get_basedir(self, hostname):
            return '.'

    # test 1
    tl = TestLoader()
    tt = TestTemplar

# Generated at 2022-06-23 06:06:53.335712
# Unit test for constructor of class Conditional
def test_Conditional():
    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class TestConditional(Conditional):
        pass

    with pytest.raises(AnsibleError):
        TestConditional()

    var_manager = VariableManager()
    tc = TestConditional(DataLoader())
    assert var_manager == tc._variable_manager

# Generated at 2022-06-23 06:07:02.701211
# Unit test for constructor of class Conditional
def test_Conditional():

    from ansible.playbook.play_context import PlayContext

    class TestIt:
        def __init__(self):
            self._when = []
            self._loader = None
            self._ds = None
            self._parent = None

    t = TestIt()

    # Test with loader
    c = Conditional(loader=t._loader)

    import collections
    assert isinstance(c, Conditional)
    assert isinstance(c, collections.Iterable)

    # Test without loader
    try:
        Conditional()
        # Should not get here
        assert False
    except Exception:
        # Expected
        assert True

    # Test when not set and valid
    assert c._validate_when('_when', '_when', False)
    assert c._when == [False]

    # Test when already set and valid


# Generated at 2022-06-23 06:07:14.031866
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

# Generated at 2022-06-23 06:07:21.484762
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    fake_conds = ['a is b', 'b is a', 'bar is defined', 'bar is not defined', 'foo is bar', 'foo is not bar']

    # When 'bar' is defined, we expect all to be True except the second one
    all_vars = dict(a='a', b='b', foo='foo', bar='bar')
    result = dict(zip(fake_conds, [True] * len(fake_conds)))
    result['b is a'] = False

    # Variable manager is used by template engine
    variable_manager = VariableManager()

    # The templar instance is used to evaluate the conditions
    templar = Templar(loader=None, variable_manager=variable_manager, shared_loader_obj=None)



# Generated at 2022-06-23 06:07:33.285799
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    display = Display()

    class MyClass(Conditional):
        pass

    ########################################################################################################################

    myClass = MyClass()
    myClass._ds = dict()
    myClass.when = ['foo is bar']

    all_vars = dict()

    try:
        myClass.evaluate_conditional(None, all_vars)
        assert False
    except Exception as e:
        assert isinstance(e, AnsibleError)
        assert e.message == "a loader must be specified when using Conditional() directly"

    ########################################################################################################################

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    myClass = MyClass(loader=DataLoader())
    myClass._ds = dict()
    myClass.when = ['foo is bar']

   

# Generated at 2022-06-23 06:07:42.001960
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("test_var is defined") == [('test_var', 'is', 'defined')]
    assert cond.extract_defined_undefined("test_var is not defined") == [('test_var', 'is not', 'defined')]
    assert cond.extract_defined_undefined("test_var is defined or test_var2 is undefined") == [('test_var', 'is', 'defined'), ('test_var2', 'is', 'undefined')]


# Generated at 2022-06-23 06:07:52.794118
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():


    class ConditionalTestObject(Conditional):
        _when = FieldAttribute(isa='list', default=list, extend=True, prepend=True)
        _loader = FieldAttribute(isa='bool')

        def __init__(self, conditional_list, loader):
            self._when = conditional_list
            self._loader = loader
            super(ConditionalTestObject, self).__init__(loader=loader)

    test_pre_var = ConditionalTestObject(['{{ ansible_distribution }} == pre_var'], None)
    test_pre_var_true = ConditionalTestObject(['{{ ansible_distribution }} == pre_var', 'variable_is_defined'], None)

# Generated at 2022-06-23 06:07:59.551607
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    failmsg = "Variable 'hoge' is undefined"

    class TestConditional(Conditional):
        def __init__(self, loader=None):
            super(TestConditional, self).__init__(loader)
            self.when = ['foo and bar', 'hoge', 'fuga or piyo']

    tc = TestConditional()
    templar = None
    all_vars = dict(foo=True, bar=True, piyo=True)

    with pytest.raises(AnsibleUndefinedVariable) as excinfo:
        tc.evaluate_conditional(templar, all_vars)

    assert excinfo.value.message == failmsg

    all_vars['hoge'] = False


# Generated at 2022-06-23 06:08:07.640828
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestConditional(Conditional):
        pass

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    def _test_evaluate_conditional(tc, variable_manager, conditional, result, **kwargs):
        variable_manager.extra_vars = kwargs
        assert(tc.evaluate_conditional(variable_manager.get_vars(loader=DataLoader()), variable_manager.get_vars(play=None)) == result)

    # Create and play with a TestConditional object
    tc = TestConditional()

    # Create loader, variable manager and template objects
    loader = DataLoader()
    variable_manager = VariableManager()
    templar = variable_manager.get_vars(loader, 'dummy')

    # The test
    tc

# Generated at 2022-06-23 06:08:20.542557
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Set up the objects that evaluate_conditional needs
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=None, variable_manager=variable_manager, play_context=play_context)

    # some testing conditional strings with known results

# Generated at 2022-06-23 06:08:23.230447
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    # Test return value of method 'evaluate_conditional'
    assert conditional.evaluate_conditional(conditional, conditional)



# Generated at 2022-06-23 06:08:34.311127
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('a is undefined') == [('a', 'is', 'undefined')]
    assert c.extract_defined_undefined('a not is undefined') == [('a', 'not is', 'undefined')]
    assert c.extract_defined_undefined('a is defined') == [('a', 'is', 'defined')]
    assert c.extract_defined_undefined('a not is defined') == [('a', 'not is', 'defined')]

# Generated at 2022-06-23 06:08:45.018685
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('') == []
    assert c.extract_defined_undefined('a==1') == []
    assert c.extract_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert c.extract_defined_undefined('hostvars[inventory_hostname] is not defined') == [('hostvars[inventory_hostname]', 'is not', 'defined')]
    assert c.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]

# Generated at 2022-06-23 06:08:56.914384
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    def test(cond, expect_success, expect_error=None, expect_result=None):
        actual_result = Conditional().extract_defined_undefined(cond)
        assert type(actual_result) == list
        if expect_success:
            assert actual_result == expect_result, "Expected: %s, Actual: %s, Conditional: %s" % (expect_result, actual_result, cond)
        else:
            assert actual_result == expect_result, "Expect error: %s, Conditional: %s" % (expect_result, cond)
            assert type(expect_error) == str
            assert expect_error in str(actual_result), "Expect error: %s, Conditional: %s" % (expect_error, cond)

    # Test: calling with a value that is not

# Generated at 2022-06-23 06:09:04.745695
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("something") == []
    assert c.extract_defined_undefined("something is defined") == [('something', 'is', 'defined')]
    assert c.extract_defined_undefined("something foo is defined") == [('something', 'is', 'defined')]
    assert c.extract_defined_undefined("something is not defined") == [('something', 'is not', 'defined')]
    assert c.extract_defined_undefined("something is foo defined") == [('something', 'is', 'defined')]
    assert c.extract_defined_undefined("something is not foo defined") == [('something', 'is not', 'defined')]

# Generated at 2022-06-23 06:09:16.043534
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    c = Conditional()

    context = PlayContext()
    context._prompt = {}
    context._prompt_method = 'cli'
    templar = Templar(variables=VariableManager())
    templar._available_variables = {}
    templar._available_variables['foo'] = "bar"
    templar._available_variables['empty'] = ""
    templar._available_variables['a'] = 1
    templar._available_variables['b'] = 2
    templar._available_variables['this_does_not_exist'] = '{{this_does_not_exist}}'

    #test failure

# Generated at 2022-06-23 06:09:19.152298
# Unit test for constructor of class Conditional
def test_Conditional():
    try:
        Conditional()
    except Exception as e:
        assert 'loader must' in to_native(e), "%s: Exception msg '%s' does not contain 'loader must'." %(type(e), to_native(e))



# Generated at 2022-06-23 06:09:29.890454
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext

    variable_manager = PlayContext()
    variable_manager._options = {'no_log': True, 'syntax': 'yaml'}
    variable_manager._play_context = variable_manager
    variable_manager.set_options({'no_log': True, 'syntax': 'yaml'})

    path = '/path/to/playbook.yml'
    data = """
    ---
    - hosts: localhost
      tasks:
      - action: ping
        when: foo is defined and foo != 1
    """

    # initialize the modules
    Playbook.load_callbacks()

    # load the play and create the tasks
    loader, inventory, variable_manager = Playbook.load_playbook_from_data

# Generated at 2022-06-23 06:09:33.092913
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c._when == [], "_when should be empty list"
    assert c._loader is None, "_loader should be None"


# Generated at 2022-06-23 06:09:38.954730
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    class MockPlaybook(object):
        class Options(object):
            def __init__(self):
                self.no_log = False
                self.no_log_conditions = []

        def __init__(self):
            self.options = self.Options()
            self.extra_vars = {}
            self.no_log_values = []

    class MockLoader(object):
        def __init__(self):
            pass

        def load_from_file(self, file_path):
            return MockModule(myparam="test")

    class MockTemplar(object):
        def __init__(self):
            self.loader = MockLoader()
            self.environment = None
            self

# Generated at 2022-06-23 06:09:50.757820
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Resetting ansible configuration for the testing
    C.DEFAULT_HASH_BEHAVIOUR='replace'
    C.DEFAULT_KEEP_REMOTE_FILES=False
    C.DEFAULT_REMOTE_TMP=None
    C.DEFAULT_SUDO=False
    C.DEFAULT_SUDO_EXE=None
    C.DEFAULT_SUDO_FLAGS=None
    C.DEFAULT_SUDO_USER=None
    C.DEFAULT_SYSLOG_FACILITY=None
    C.DEFAULT_SYSLOG_PATH=None
    C.DEFAULT_VARIABLE_INTERPOLATION='Jinja2'
    C.DEFAULT_VERSION_WARNING=True
    C.DEFAULT_WARNING_FACILITY=None
    C.DEFAULT

# Generated at 2022-06-23 06:10:01.086926
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class Play(object):
        def __init__(self, vars=None):
            self.vars = vars
    class Task(object):
        def __init__(self, play=None, when=None):
            self.play = play
            self.when = when
    class PlayContext(object):
        def __init__(self):
            self.vars = {}
    class HostVars(object):
        def __init__(self):
            self.hostvars = {}
    class Runner(object):
        def __init__(self, host, magic_variables):
            self.host = host
            self.magic_variables = magic_variables

    class MyConditional(Conditional):
        def __init__(self):
            pass

    runner = Runner('localhost', HostVars())

    my

# Generated at 2022-06-23 06:10:03.496824
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert isinstance(conditional,Conditional)


# Generated at 2022-06-23 06:10:13.386172
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestClass(Conditional):
        def __init__(self):
            self._loader = DictDataLoader({})
    class TestTemplar:
        def __init__(self, env, data):
            self._available_variables = data
            self._environment = env
            self._disable_lookups = False

        def is_template(self, data):
            return False

        @property
        def available_variables(self):
            return self._available_variables

        @available_variables.setter
        def available_variables(self, val):
            self._available_variables = val

        def set_available_variables(self, variables):
            for k,v in variables.items():
                self.available_variables[k] = v


# Generated at 2022-06-23 06:10:24.882672
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class Loader(object):
        def __init__(self):
            self._basedir = 'test_dir'
            self.cur_path = 'current_path'

    class MyClass(Conditional):
        def __init__(self, loader):
            self._ds = 'test_ds'
            self._loader = loader

    loader = Loader()
    obj = MyClass(loader=loader)
    try:
        obj.when = ['test']
        obj.evaluate_conditional('test')
    except Exception:
        pass
    try:
        obj.when = ['test']
        obj._check_conditional('test')
    except Exception:
        pass
    try:
        obj.when = ['test']
        obj._check_conditional('test','test','test')
    except Exception:
        pass



# Generated at 2022-06-23 06:10:37.724034
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook import PlayContext
    from ansible.template import Templar

    # ---------------------------------------------
    # when_items evaluates to False if any of the
    # list members evaluate to False
    # ---------------------------------------------
    conditional = Conditional()

    when_items = ['a', 'b', 'c']
    setattr(conditional, 'when', when_items)
    templar = Templar(loader=None, variables={})
    pc = PlayContext()
    pc.prompt = lambda x,y,z: "foo"

    try:
        res = conditional.evaluate_conditional(templar, pc)
        assert res == True, "when_items evaluates to False if any of the list members evaluate to False"
    except:
        assert False, "when_items evaluates to False if any of the list members evaluate to False"

   

# Generated at 2022-06-23 06:10:49.359509
# Unit test for constructor of class Conditional
def test_Conditional():
    def test_init_method_with_loader():
        c = Conditional(loader=True)
        assert c

    def test_init_method_without_loader():
        try:
            c = Conditional()
            assert False
        except Exception as e:
            assert 'must be specified when using Conditional() directly' in to_text(e)

    def test_validate_when():
        c = Conditional(loader=True)
        c._validate_when(None, '_when', ['foo', 'bar'])
        assert c._when == ['foo', 'bar']
        c._validate_when(None, '_when', 'baz')
        assert c._when == ['baz']

    test_init_method_with_loader()
    test_init_method_without_loader()
    test_validate

# Generated at 2022-06-23 06:10:59.665298
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class FakeConditional(Conditional):
        def __init__(self):
            super(FakeConditional, self).__init__()
    # test case 1
    cond_obj = FakeConditional()
    cond = 'result|success and (not result|failed and result|rc != 5) and (ansible_facts["os_family"] == "RedHat" and ansible_facts["distribution_major_version"] != "7")'
    result = cond_obj.extract_defined_undefined(cond)
    assert result == [
        ('ansible_facts["os_family"]', '==', 'defined'),
        ('ansible_facts["distribution_major_version"]', '!=', 'defined')
    ]
    # test case 2

# Generated at 2022-06-23 06:11:11.392467
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # pylint: disable=too-few-public-methods
    class TestConditional(Conditional):
        pass
    c = TestConditional()
    assert c.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert c.extract_defined_undefined("a is not defined") == [("a", "is not", "defined")]
    assert c.extract_defined_undefined("a is undefined") == [("a", "is", "undefined")]
    assert c.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]
    assert c.extract_defined_undefined("b is defined") == [("b", "is", "defined")]
    assert c.extract_defined_und

# Generated at 2022-06-23 06:11:14.003129
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    loader = DictDataLoader({})
    templar = Templar(loader=loader)
    conditional = Conditional(loader=loader)
    assert conditional.evaluate_conditional(templar, {'foo': 'bar'})

# Generated at 2022-06-23 06:11:22.578167
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    variable_manager.set_inventory(loader.load_from_file('tests/inventory'))

    variable_manager.set_variable('foo', True)
    variable_manager.set_variable('bar', True)
    variable_manager.set_variable('baz', 1)

    assert Conditional(loader=loader).evaluate_conditional(variable_manager, dict())

# Generated at 2022-06-23 06:11:31.749006
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import ansible.plugins.loader as plugin_loader
    from ansible.playbook.play_context import PlayContext

    mock_loader = plugin_loader.ActionModuleLoader(None, None)
    play_context = PlayContext()

    # normal op
    vars = dict(foo='bar', bar='baz')
    c = Conditional(loader=mock_loader)
    c.when = 'foo == "bar"'
    assert c.evaluate_conditional(play_context, vars)

    # undefined
    vars = {}
    c = Conditional(loader=mock_loader)
    c.when = 'foo in hostvars'
    assert not c.evaluate_conditional(play_context, vars)

    # undefined
    vars = {}
    c = Conditional(loader=mock_loader)
   

# Generated at 2022-06-23 06:11:41.026356
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-23 06:11:48.142688
# Unit test for constructor of class Conditional
def test_Conditional():
    class TestConditional(Conditional):
        pass
    # The test requires a loader to instantiate Conditional class.
    # We don't have a loader here so we test with specific _when attributes
    test_task = TestConditional()
    assert test_task._when == [], test_task._when
    # Test when attribute is a list
    test_task.when = ['foo', 'bar', 'baz']
    assert test_task._when == ['foo', 'bar', 'baz'], test_task._when
    # Test when attribute is not a list
    test_task.when = 'not a list'
    assert test_task._when == ['not a list'], test_task._when

# Generated at 2022-06-23 06:12:00.263578
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    class TestModule(object):
        def __init__(self):
            self.params = {'a':True,'b':True,'c':True}
            self.playbook_dir = ''

    class TestPlaybook(object):
        def __init__(self):
            self.basedir = ''

    class TestHost(object):
        def __init__(self):
            self.name = 'testhost'

    class TestTask(Conditional):
        pass

    class TestLoader(object):
        def __init__(self):
            self.basedir = ''

    # Set up a context with a few variables defined
    display.verbosity = 3
    t = TestTask()
    t._loader = TestLoader()
    t._host = TestHost()
    t._play = TestPlaybook()
    t._task = TestTask

# Generated at 2022-06-23 06:12:05.645560
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    def_undef = cond.extract_defined_undefined("cond1 and cond2 and (cond3 or cond4 and cond5 or cond6) or not cond7")

    assert def_undef == [('cond1', 'is', 'defined'), ('cond2', 'is', 'defined'), ('cond3', 'is', 'defined'),
                         ('cond4', 'is', 'defined'), ('cond5', 'is', 'defined'), ('cond6', 'is', 'defined'),
                         ('cond7', 'is', 'defined')]


# Generated at 2022-06-23 06:12:10.762927
# Unit test for constructor of class Conditional
def test_Conditional():
    try:
        Conditional()
        assert False # Conditional should raise an exception if no loader is passed in
    except AnsibleError:
        pass
    base = Base()
    assert type(base) is Base
    c = Conditional(base)
    assert type(c) is Conditional
    assert type(c._loader) is Base

# Generated at 2022-06-23 06:12:15.624338
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook import Playbook
    c = Playbook().load('./test/unittest_conditional.yml', variable_manager=None, loader=None)
    assert c
    assert 'play' in c

# Generated at 2022-06-23 06:12:23.751879
# Unit test for constructor of class Conditional
def test_Conditional():
    """
    Test constructor of class Conditional
    """
    class MockPlay(Conditional):
        def __init__(self):
            super(MockPlay, self).__init__()

    try:
        play_obj = MockPlay()
    except Exception as e:
        msg = "Conditional.__init__() requires a loader, " \
              "but no loader was specified"
        assert str(e) == msg, 'Expected exception: {0}, actual: {1}'.format(msg, str(e))



# Generated at 2022-06-23 06:12:24.449325
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    assert(False)

# Generated at 2022-06-23 06:12:25.798293
# Unit test for constructor of class Conditional
def test_Conditional():
    assert hasattr(Conditional, 'when')

# Generated at 2022-06-23 06:12:34.077934
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    """
    Test the method extract_defined_undefined of class Conditional
    """
    conditional = Conditional()
    assert conditional.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo not is defined') == [('foo', 'not is', 'defined')]
    assert conditional.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('foo not is undefined') == [('foo', 'not is', 'undefined')]
    assert conditional.extract_defined_undefined('hostvars["foo"] is defined') == [('hostvars["foo"]', 'is', 'defined')]
    assert conditional.extract_defined_und

# Generated at 2022-06-23 06:12:36.115768
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c.when == []


# Tests for method evaluate_conditional of class Conditional

# Generated at 2022-06-23 06:12:45.581241
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert Conditional().extract_defined_undefined('hostvars[foo] is undefined') == [('hostvars[foo]', 'is', 'undefined')]
    assert Conditional().extract_defined_undefined('hostvars[foo] is not undefined and '
                                                   '(hostvars[fuu] is undefined)') == [('hostvars[foo]', 'is', 'undefined'),
                                                                                       ('hostvars[fuu]', 'is', 'undefined')]

# Generated at 2022-06-23 06:12:46.876502
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()

# Generated at 2022-06-23 06:12:51.779351
# Unit test for constructor of class Conditional
def test_Conditional():
    print('Testing constructor of class Conditional')
    conditional = Conditional()
    assert conditional._when != None, "Failed to validate required arguments with _when not set"
    assert conditional._when == list, "Failed to validate required arguments with _when not set"


# Generated at 2022-06-23 06:13:02.143181
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("variable is defined or variable2 is defined") == [('variable', 'is', 'defined'), ('variable2', 'is', 'defined')]
    assert conditional.extract_defined_undefined("variable1 is undefined") == [('variable1', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("variable1 is not undefined and variable2 is not undefined") == [('variable1', 'is not', 'undefined'), ('variable2', 'is not', 'undefined')]

    # a number of incorrect definitions
    assert conditional.extract_defined_undefined("variable1 not defined") == []
    assert conditional.extract_defined_undefined("variable1 is defined1") == []

# Generated at 2022-06-23 06:13:03.953963
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional('loader')
    assert hasattr(conditional, '_loader') == True


# Generated at 2022-06-23 06:13:13.509497
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """ Test the method evaluate_conditional of class Conditional """
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    play = Play()
    play._variable_manager = VariableManager()
    play._loader = DataLoader()
    play_context = PlayContext()
    play.set_loader(play._loader)
    play.set_variable_manager(play._variable_manager)

    host = Host(name='ansible', play=play)
    host._variable_manager = play._variable_manager

    conditional = Conditional()
    conditional._loader = play._loader
    conditional._templar = Templar(loader=conditional._loader, variables=conditional._get_vars(play_context, host))
