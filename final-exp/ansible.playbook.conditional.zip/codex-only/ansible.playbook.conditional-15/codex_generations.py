

# Generated at 2022-06-23 06:03:21.544619
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    ansible_vars = dict(var1='var1', var2=2)

    m = Conditional()
    m.when = ['var1 is defined', 'var2 is not defined', 'var3 is not defined']
    templar = Templar(loader=DictDataLoader({}))

    assert m.evaluate_conditional(templar, ansible_vars) is False



# Generated at 2022-06-23 06:03:30.156128
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Test case 1:
    # When valid variables are passed to evaluate_conditional,
    # then the result should be True or False according to the
    # conditional statement
    input1 = {'a': 1, 'b': 2, 'c': 3}
    conditional1 = "a == 1"
    obj1 = Conditional()
    assert obj1.evaluate_conditional(input1, input1, conditional1)

    # Test case 2:
    # When invalid variables are passed to evaluate_conditional,
    # then the result should be False
    input2 = {'a': 1, 'b': 2, 'c': 3}
    conditional2 = "d == 1"
    obj2 = Conditional()
    assert not obj2.evaluate_conditional(input2, input2, conditional2)

    # Test case 3:
    # When

# Generated at 2022-06-23 06:03:38.120786
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.variables import VariableManager
    from ansible.template import Templar

    mock_loader = DictDataLoader({
        "test_evaluate_conditional.j2": "{{ a }} {{ b }} {{ c }}",
    })
    mock_variable_manager = VariableManager()
    mock_variable_manager.set_nonpersistent_facts(dict(
        hostvars=dict(
            a=dict(
                b=1,
                d=dict(
                    e=2,
                ),
            ),
        )
    ))
    mock_play_context = PlayContext()

    # Test all conditionals evaluate as true
    conditional = Conditional(loader=mock_loader)

# Generated at 2022-06-23 06:03:49.539051
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class FakeConditional():
        cond = ("hostvars['foo'] is not undefined or hostvars['foo']['bar'] is not undefined and "
                "hostvars['foo']['bar']['baz'] is not undefined and hostvars['foo']['bar']['baz']['qux'] "
                "is not undefined")
    c = Conditional()
    def_undef = c.extract_defined_undefined(c.cond)
    assert def_undef[0] == ("hostvars['foo']", 'is not', 'undefined')
    assert def_undef[1] == ("hostvars['foo']['bar']", 'is not', 'undefined')

# Generated at 2022-06-23 06:03:52.056839
# Unit test for constructor of class Conditional
def test_Conditional():
    test_conditional = Conditional()
    assert isinstance(test_conditional, Conditional)


# Generated at 2022-06-23 06:03:59.205380
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play import Play

    play1 = Play.load(dict(
        name='test',
        hosts=[],
        gather_facts='no',
        vars={'foo': 'success'},
        tasks=[dict(action='shell', when=['foo != success'])]
    ), loader=None)

    assert play1._tasks[0].evaluate_conditional(play1.loader, dict(foo='success'), fail_on_undefined=False) == False

# Generated at 2022-06-23 06:04:05.394100
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars import AnsibleVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import wrap_var
    templar = Templar(loader=None, variables=dict())
    c = Conditional()

    # tests to run:
    #   normal test with no templating (evaluates to True)
    #   test with templating, no variables (evaluates to True)
    #   test with templating and variables, evaluating to True
    #   test with templating and variables, evaluating to False
    #   test with templating and variables, evaluating to string (False)
    #   test with templating and variables, evaluating to integer (True)
    #   test with templating and variables, evaluating to

# Generated at 2022-06-23 06:04:17.765645
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class MyConditional(Conditional):
        def __init__(self):
            pass

    m = MyConditional()

    # Create a fake host
    host = object()
    host.name = "localhost"
    host.vars = dict()
    host.vars['hostvar'] = 'hostvar_value'
    host.vars['defined'] = ['defined']

    # Create a fake task
    task = object()
    task.loop = None

    # Create a loader
    loader = DataLoader()

    # Create var manager for host and task
    variable_manager = VariableManager()

# Generated at 2022-06-23 06:04:30.101955
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

    def test(conditional, expected_result):
        result = c.extract_defined_undefined(conditional)
        assert result == expected_result

    test("'a' is defined", [("'a'", 'is', 'defined')])
    test("'a' is defined ", [("'a'", 'is', 'defined')])
    test("'a'is defined", [("'a'", 'is', 'defined')])
    test("'a' isnot defined", [("'a'", 'isnot', 'defined')])
    test("'a' not is defined", [("'a'", 'not is', 'defined')])
    test("'a' is'b' is defined", [("'a'", 'is', 'defined')])

# Generated at 2022-06-23 06:04:31.239892
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()

# Generated at 2022-06-23 06:04:42.069764
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.templating import Templar
    from ansible.vars.manager import VariableManager

    class FakeDS:
        pass

    fake_ds = FakeDS()
    fake_ds._ds = fake_ds
    fake_ds._ds._ds = fake_ds._ds
    fake_ds._ds._ds._ds = fake_ds._ds._ds

    class FakePlay:
        pass

    fake_play = FakePlay()

    class FakeTask(Conditional):
        def __init__(self):
            pass

    fake_task = FakeTask()

# Generated at 2022-06-23 06:04:49.922366
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    assert Conditional._check_conditional(None, "0 == 0", None, None) == True
    assert Conditional._check_conditional(None, "0 != 1", None, None) == True
    assert Conditional._check_conditional(None, "1 == 1", None, None) == True
    assert Conditional._check_conditional(None, "0 == 1", None, None) == False
    assert Conditional._check_conditional(None, "0 == 0 and 1 == 1", None, None) == True
    assert Conditional._check_conditional(None, "'abc' == 'abc'", None, None) == True
    assert Conditional._check_conditional(None, "'abc' == 'def'", None, None) == False

# Generated at 2022-06-23 06:04:59.731265
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    test_obj = Conditional()
    assert test_obj.extract_defined_undefined('hostvars[\'foo\'] is defined') == [('hostvars[\'foo\']', 'is', 'defined')]
    assert test_obj.extract_defined_undefined('hostvars[\'foo\'] is not defined') == [('hostvars[\'foo\']', 'is not', 'defined')]
    assert test_obj.extract_defined_undefined('hostvars[\'foo\'] is undefined') == [('hostvars[\'foo\']', 'is', 'undefined')]
    assert test_obj.extract_defined_undefined('hostvars[\'foo\'] is not undefined') == [('hostvars[\'foo\']', 'is not', 'undefined')]
    assert test_

# Generated at 2022-06-23 06:05:10.468725
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

    conditional = "meh is defined"
    assert c.extract_defined_undefined(conditional) == [('meh', 'is', 'defined')]

    conditional = "meh is not defined"
    assert c.extract_defined_undefined(conditional) == [('meh', 'is not', 'defined')]

    conditional = "hostvars[foo] is not defined"
    assert c.extract_defined_undefined(conditional) == [('hostvars[foo]', 'is not', 'defined')]

    conditional = "hostvars[foo] is defined"
    assert c.extract_defined_undefined(conditional) == [('hostvars[foo]', 'is', 'defined')]


# Generated at 2022-06-23 06:05:20.568155
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.template import Templar

    # preparing test data
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,',])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(variable_manager, loader=loader)

    all_vars = dict()

    # unit test for conditional like a and b, a is True and b is False
    c = Conditional()
    c.when = ["{{a == 1}} and {{b == 0}}", "{{c}}"]
    all_vars['a'] = 1
    all_vars['b'] = 0
    all_

# Generated at 2022-06-23 06:05:31.824440
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-23 06:05:40.572417
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("") == []
    assert c.extract_defined_undefined("hostvars['hostname'] == 'somename'") == []
    assert c.extract_defined_undefined("hostvars['hostname'] is defined") == [("hostvars['hostname']", "is", "defined")]
    assert c.extract_defined_undefined("hostvars['hostname'] is defined and something_else is defined") == \
        [("hostvars['hostname']", "is", "defined"), ("something_else", "is", "defined")]



# Generated at 2022-06-23 06:05:51.854120
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Test Conditional method evaluate_conditional

    Note: ansible.utils.unsafe_proxy is needed to pass the test
    '''
    import ansible.utils.unsafe_proxy
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    d = DataLoader()
    pc = PlayContext()
    t = Templar(loader=d, shared_loader_obj=d, variables=dict(a="some_string", b=4), play_context=pc)

    c = Conditional()

# Generated at 2022-06-23 06:06:03.354200
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # all_vars is where we can pass a test list of variables to be used in the template
    # it is set equal to the 'vars' that are going to be passed in
    all_vars = {'foo': 'bar', 'baz': 'xyz', 'asdf': 123, 'undef': None, 'xyzzy': '', 'cat': 'meow', 'dog': 'bark'}
    # set up the variables and the jinja environment
    templar = DummyTemplar(loader=DummyLoader())
    conditionals = Conditional(loader=DummyLoader())
    # if we are going to pass in variables to the conditional or play, we can add them here
    # this is also where we set the conditional in particular

# Generated at 2022-06-23 06:06:13.875230
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # empty or None
    assert Conditional().extract_defined_undefined('') == []
    assert Conditional().extract_defined_undefined(None) == []

    # single or multiple defined undefined
    assert Conditional().extract_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert Conditional().extract_defined_undefined('hostvars[inventory_hostname] is defined and ping is not undefined') == [('hostvars[inventory_hostname]', 'is', 'defined'), ('ping', 'not is', 'undefined')]

# Generated at 2022-06-23 06:06:25.318845
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook import Playbook
    pb = Playbook()
    pb.vars = {'foo': 'foo_value'}
    c = Conditional(loader=pb)
    assert c.when == []
    assert c.evaluate_conditional(pb.variable_manager.extra_vars, pb.vars) == True
    c.when = [1]
    assert c.when == [1]
    assert c.evaluate_conditional(pb.variable_manager.extra_vars, pb.vars) == True
    c.when = [0]
    assert c.evaluate_conditional(pb.variable_manager.extra_vars, pb.vars) == False
    c.when = ['foo', 'bar']
    assert c.when == ['foo', 'bar']
    assert c

# Generated at 2022-06-23 06:06:36.303120
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.plugins.loader import module_loader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    # variables is a dict of dict
    # every dict in this dict represent variables available in the context of a machine

    variables = dict()
    dummy_loader = module_loader._find_plugin('dummy')
    host1 = dict(name="testhost", ansible_ssh_host="testhost")
    host2 = dict(name="testhost2", ansible_ssh_host="testhost2")
    variables["all"] = dict(hostvars=dict(testhost=host1, testhost2=host2))
    variables['hostvars'] = dict(testhost=host1, testhost2=host2)
    variables['group_names'] = ["ungrouped"]

# Generated at 2022-06-23 06:06:46.716386
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    all_vars = {
        "a": 1,
        "b": 2,
    }

    conditional = "a == b"
    pc = PlayContext()
    templar = Templar(loader=None, variables=all_vars, shared_loader_obj=None, fail_on_undefined=False, disable_lookups=False)
    conditionalObj = Conditional(loader=None)

    assertion = conditionalObj.evaluate_conditional(templar, all_vars)
    assert not assertion

    host = Host("hostname")

# Generated at 2022-06-23 06:06:53.941082
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.task import Task
    t = Task()
    defined_undefined = t.extract_defined_undefined('defa is defined')
    assert defined_undefined == [('defa', 'is', 'defined')]
    defined_undefined = t.extract_defined_undefined('abcdefg is not defined')
    assert defined_undefined == [('abcdefg', 'is not', 'defined')]
    defined_undefined = t.extract_defined_undefined('defa is defined and abcdefg is not defined')
    assert defined_undefined == [('defa', 'is', 'defined'), ('abcdefg', 'is not', 'defined')]

# Generated at 2022-06-23 06:07:02.984549
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    fake_loader = DictDataLoader({})
    display = Display()
    context = PlayContext()
    context.CLIARGS = {}

    conditional = Conditional(loader=fake_loader)

# Generated at 2022-06-23 06:07:14.272389
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    a = dict()
    a['a'] = dict()
    a['a']['b'] = dict()
    a['a']['b']['c'] = dict()
    a['a']['b']['c']['d'] = dict()
    a['a']['b']['c']['d']['true'] = 'abcdefg'

    c = Conditional()


# Generated at 2022-06-23 06:07:18.863601
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins import module_loader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager,  host_list='tests/inventory')
    variable_manager.set_inventory(inventory)
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='{{foo}}')))
            ]
        )

    play

# Generated at 2022-06-23 06:07:28.156871
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    conditional = '''not test_defined is defined or (test_not_defined is not defined and test_2 not in groups['a'])'''
    expected = [('test_defined', 'not', 'defined'), ('test_not_defined', 'is', 'not defined'), ('test_2', 'not in', 'groups[\'a\']')]
    actual = Conditional().extract_defined_undefined(conditional)
    assert actual == expected, actual

    conditional = '''not test_defined is defined or (test_not_defined is not defined and test_2 not in groups['a'] and test_3 not in groups['b'])'''

# Generated at 2022-06-23 06:07:30.050912
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook import Playbook
    pb = Playbook()
    Conditional(pb)


# Generated at 2022-06-23 06:07:40.170298
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    display.verbosity = 3
    display._verbosity = 4  # pylint: disable=protected-access

    templar = Templar(loader=None, variables={})

    def test_conditional(conditional, expected_result, extra_vars={}, skip_undef=False):
        all_vars = dict()
        all_vars.update(templar._available_variables)
        all_vars.update(extra_vars)

        conditional_obj = Conditional()
        conditional_obj._loader = templar._loader  # pylint: disable=protected-access
        conditional_obj.when.append(conditional)

        result = conditional_obj.evaluate_conditional(templar, all_vars)
        if result != expected_result:
            raise

# Generated at 2022-06-23 06:07:51.392464
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

# Generated at 2022-06-23 06:08:01.385832
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.plugins.loader import get_all_plugin_loaders

    module_loader, lookup_loader, filter_loader = get_all_plugin_loaders()
    c = Conditional(loader=module_loader)

    assert c.extract_defined_undefined('foo not is defined and bar is defined') == \
           [('foo', 'not is', 'defined'), ('bar', 'is', 'defined')]

    assert c.extract_defined_undefined('foo not is undefined and bar is undefined') == \
           [('foo', 'not is', 'undefined'), ('bar', 'is', 'undefined')]

    assert c.extract_defined_undefined('foo is defined and bar is not defined') == \
           [('foo', 'is', 'defined'), ('bar', 'is not', 'defined')]


# Generated at 2022-06-23 06:08:11.022361
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Setup
    class MyVarsModule:
        def __init__(self, vars):
            self.vars = vars

        def get_vars(self, loader, play, host, task):
            return self.vars

    my_vars_module = MyVarsModule(vars={
        'foo_is_defined': True,
        'foo_is_not_defined': False,
        'false_value': False,
        'true_value': True,
        'str_hostvars_key': '"bar"',
        'str_hostvars_key_space': '"b ar"',
        'str_hostvars_complex_key': '"b ar"',
        'empty_string': '""'
    })
    my_loader = DictDataLoader({})
    my_

# Generated at 2022-06-23 06:08:13.835302
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional(loader=None)
    assert c._when is None
    assert c._loader is None


# Generated at 2022-06-23 06:08:24.565355
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    c = Conditional()

    result = c.extract_defined_undefined('result|failed and (changed or not (changed and not changed))')
    assert result == [], 'failed to extract defined/undefined from string: %s' % result

    result = c.extract_defined_undefined('result|failed and (changed or not (changed and not (changed and (foo is not defined))))')
    assert result == [('foo', 'is not', 'defined')], 'failed to extract defined/undefined from string: %s' % result

    result = c.extract_defined_undefined('(toclean is not defined) and (to_clean is defined)')

# Generated at 2022-06-23 06:08:30.332839
# Unit test for constructor of class Conditional
def test_Conditional():

    def assert_is_instance_of(actual, expected):
        assert isinstance(actual, expected)

    assert_is_instance_of(Conditional(), Conditional)
    assert_is_instance_of(Conditional(loader=None), Conditional)

    try:
        assert_is_instance_of(Conditional(), Conditional)
    except AnsibleError as e:
        assert str(e) == "a loader must be specified when using Conditional() directly"


# Generated at 2022-06-23 06:08:42.499080
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

# Generated at 2022-06-23 06:08:47.512254
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = "test1 is defined and test2 is not defined and test3 is defined or test4 is not defined"
    data = Conditional()
    result = data.extract_defined_undefined(conditional)
    assert result == [('test1', 'is', 'defined'), ('test2', 'is not', 'defined'), ('test3', 'is', 'defined'), ('test4', 'is not', 'defined')]


# Generated at 2022-06-23 06:08:57.973677
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    context = PlayContext()
    context._set_vars_cache({'foo': 'bar'})
    context._set_vars_files_cache([])
    context._set_vars_files_cache_stack([])
    templar = Templar(loader=loader, variables={'foo': 'bar'})
    hostvars = templar._available_variables
    hostvars['inventory_hostname'] = 'test_hostname'

    conditional_obj = Conditional(loader=loader)
    # hostvars conditional

# Generated at 2022-06-23 06:09:08.236966
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Unit test for method evaluate_conditional of class Conditional
    '''
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    dl = DataLoader()
    var_mgr = VariableManager()
    var_mgr.extra_vars = {'aaa': 'foobar', 'bbb': 'bar'}
    var_mgr.set_inventory(dl.load('tests/inventory'))
    templar = Templar(loader=None, variable_manager=var_mgr, shared_loader=dl)

    test_conditional = 'true'
    assert Conditional().evaluate_conditional(templar, {}) == True

# Generated at 2022-06-23 06:09:15.935022
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert c.extract_defined_undefined('foo is not defined or hostvars[inventory_hostname] is defined') == [('foo', 'is not', 'defined'), ('hostvars[inventory_hostname]', 'is', 'defined')]
    assert c.extract_defined_undefined('') == []


# Generated at 2022-06-23 06:09:27.947514
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:09:41.143935
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class ConditionalTester(object, Conditional):
        pass

    c = ConditionalTester()
    c._loader = None
    c._ds = [1,2,3]
    all_vars = dict()

    # we're just testing evaluate_conditional, so no need for real template
    # we're also using _check_conditional, so we need to cheat a bit
    # python2.7's mock can't mock a @property, so we have to create a fake
    # class that mimics our templar
    class Templar(object):
        @staticmethod
        def template(conditional, disable_lookups=False):
            return conditional

        @staticmethod
        def is_template(conditional):
            return conditional.startswith('{{')

    templar = Templar()


# Generated at 2022-06-23 06:09:42.974972
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    assert Conditional().evaluate_conditional(None, all_vars=dict())



# Generated at 2022-06-23 06:09:52.542716
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is not defined') == [('hostvars[inventory_hostname]', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is undefined') == [('hostvars[inventory_hostname]', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is not undefined') == [('hostvars[inventory_hostname]', 'is not', 'undefined')]
    assert conditional.extract

# Generated at 2022-06-23 06:10:03.393057
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Defaults
    test_loader = None
    test_conditional = None
    test_templar = None
    test_all_vars = None
    correct_result = None
    # Test case 1
    # Input
    test_loader = None
    test_conditional = 'foo'
    test_templar = None
    test_all_vars = None
    # Output
    correct_result = None
    # Test case 2
    # Input
    test_loader = None
    test_conditional = 'foo'
    test_templar = None
    test_all_vars = None
    # Output
    correct_result = None
    # Test case 3
    # Input
    test_loader = None
    test_conditional = 'foo'
    test_templar = None
    test_

# Generated at 2022-06-23 06:10:14.305288
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Test empty conditionals
    c = Conditional()
    assert c.extract_defined_undefined(None) == []
    assert c.extract_defined_undefined('') == []
    assert c.extract_defined_undefined([]) == []
    # Test wrong conditionals
    assert c.extract_defined_undefined(42) == []
    assert c.extract_defined_undefined(['a', 'b']) == []
    assert c.extract_defined_undefined('a is') == []
    assert c.extract_defined_undefined('is a') == []
    assert c.extract_defined_undefined('is is') == []
    assert c.extract_defined_undefined('is not') == []
    assert c.extract_defined_undefined('not is') == []

# Generated at 2022-06-23 06:10:25.492400
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._options = {'fact_caching': 'memory'}
    fact_cache = variable_manager.fact_cache
    variable_manager.set_loader(loader)
    variable_manager._fact_cache = fact_cache

    conditional = Conditional(loader=loader)
    print(conditional.__dict__)

    conditional.when = True
    assert conditional.when == [True]

    conditional.when = [True]
    assert conditional.when == [True]

    conditional.when = "True"
    assert conditional.when == ["True"]

    conditional.when = [True, "True"]

# Generated at 2022-06-23 06:10:37.995330
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

# Generated at 2022-06-23 06:10:49.565606
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

# Generated at 2022-06-23 06:10:57.615834
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined(' a is defined or b is undefined') == [('a', 'is', 'defined'), ('b', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('a not is defined or b not is undefined') == [('a', 'not is', 'defined'), ('b', 'not is', 'undefined')]
    assert conditional.extract_defined_undefined('a is not undefined or b is not defined') == [('a', 'is not', 'undefined'), ('b', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('a is defined') == [('a', 'is', 'defined')]

# Generated at 2022-06-23 06:11:10.385248
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    arr_one_defined = [('adam', 'is', 'defined'), ('bob', 'is not', 'defined')]
    arr_one_undefined = [('bob', 'is not', 'defined')]
    arr_no_defined_undefined = [('adam', 'is', 'awesome')]

    # test extraction of one conditional
    result = Conditional().extract_defined_undefined("{{ adam is defined and bob is not defined }}")
    assert result == arr_one_defined, 'failed to extract one conditional'

    # test extraction of one conditional that ends in defined/undefined
    result = Conditional().extract_defined_undefined("{{ adam is defined }}")
    assert result == arr_one_defined[:1], 'failed to extract one conditional that is defined'
    result = Conditional().extract_defined

# Generated at 2022-06-23 06:11:14.461192
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    assert Conditional().evaluate_conditional(None, None)
    assert Conditional().evaluate_conditional(None, [1])
    assert Conditional().evaluate_conditional(None, [0])
    assert not Conditional().evaluate_conditional(None, [0, 1])
    assert Conditional().evaluate_conditional(None, [1, 0])

# Generated at 2022-06-23 06:11:16.117965
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert [('foo', 'is', 'defined')] == Conditional().extract_defined_undefined('foo is defined')


# Generated at 2022-06-23 06:11:27.379823
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    # list of items to test, with the expected result after calling extract_defined_undefined

# Generated at 2022-06-23 06:11:34.271271
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.module_utils.six import StringIO

    import ansible.parsing.yaml.loader
    import ansible.parsing.vault
    import ansible.vars.unsafe_proxy


# Generated at 2022-06-23 06:11:45.165010
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import jinja2
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    host = InventoryManager(loader=DataLoader(), sources=['localhost,'])

    # create a variable manager and pass in the host
    # and the template dir
    v = VariableManager(loader=DataLoader(), inventory=host)

    test = Conditional(loader=v._loader)
    test.when = [ "test", "test2" ]
    template = """
    {% if groups['ungrouped'] is defined %}
        '{{ groups['ungrouped'] }}'
    {% else %}
        '{{ hostvars['localhost'].ansible_version.full }}'
    {% endif %}
    """
    jin

# Generated at 2022-06-23 06:11:47.114437
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional._when == []
    return conditional

# Generated at 2022-06-23 06:11:58.983387
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('b1 is defined and b2 is undefined') == [('b1', 'is', 'defined'), ('b2', 'is', 'undefined')]
    assert c.extract_defined_undefined('') == []
    assert c.extract_defined_undefined('a and b') == []
    assert c.extract_defined_undefined('c1 and c2 is defined') == [('c2', 'is', 'defined')]
    assert c.extract_defined_undefined('d1 is not defined or d2 is defined') == [('d1', 'is not', 'defined'), ('d2', 'is', 'defined')]

# Generated at 2022-06-23 06:12:06.858749
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    context = PlayContext()
    context._hostvars = dict(localhost=dict(ansible_hostname='localhost', val=True))
    templar = Templar(loader=None, variables=context.get_vars())
    conditional = Conditional(loader=None)

    assert conditional.evaluate_conditional(templar, all_vars=context.get_vars())

    conditional.when = [u'val is defined', u'val is not defined', u'val is not defined']
    assert not conditional.evaluate_conditional(templar, all_vars=context.get_vars())

    conditional.when = [u'val is defined', u'val is undefined', u'val is not defined']

# Generated at 2022-06-23 06:12:16.134655
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert (cond.extract_defined_undefined("today not is defined") ==
             [("today", "not is", "defined")])
    assert (cond.extract_defined_undefined("today    not    is    defined") ==
             [("today", "not is", "defined")])
    assert (cond.extract_defined_undefined("a is defined or b is undefined") ==
             [("a", "is", "defined"), ("b", "is", "undefined")])
    assert (cond.extract_defined_undefined("a is defined and b not is undefined") ==
             [("a", "is", "defined"), ("b", "not is", "undefined")])

# Generated at 2022-06-23 06:12:28.679188
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    class TestConditional(Conditional):
        pass

    # Check if the variable is defined or not
    # Expected result: True if variable is defined, otherwise False

# Generated at 2022-06-23 06:12:30.013686
# Unit test for constructor of class Conditional
def test_Conditional():
    Cond = Conditional()
    assert Cond != None, "failed to create Conditional object"

# Generated at 2022-06-23 06:12:41.263787
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.role.definition import RoleDefinition
    rd = RoleDefinition()
    expected = [('fruits', 'is', 'defined'), ('foo', 'is', 'undefined'), ('bar', 'is', 'defined'), ('baz', 'not is', 'defined')]
    assert rd.extract_defined_undefined(to_text("fruits is defined and foo not is defined and bar is defined and baz is not defined")) == expected
    assert rd.extract_defined_undefined(to_text("fruits is defined and (foo is undefined or bar is defined) and baz is not defined")) == expected
    assert rd.extract_defined_undefined(to_text("fruits is defined or foo is undefined or bar is defined or baz is not defined")) == expected

# Generated at 2022-06-23 06:12:45.996463
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.vault import VaultLib

    c = Conditional()
    assert c._when == []
    assert c._loader == None

    p  = PlayContext()
    v = VaultLib("password")
    c = Conditional(loader=p, vault_password=v)
    assert c._when == []
    assert c._loader == p
    assert c.vault_password == v

# Generated at 2022-06-23 06:12:58.265797
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText, wrap_var
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    data = dict(a=10, b=20, result=30)
    variable_manager = VariableManager()
    variable_manager.extra_vars = data
    loader = DataLoader()
    templar = Templar(loader=loader, variables=variable_manager)

    # test with a string that does not have a templating delimiter
    cond = Conditional()
    result = cond.evaluate_conditional(templar, data)
    assert result == True, "Invalid result from evaluate_conditional() (1)"

    # test with a string that uses templating delimiters


# Generated at 2022-06-23 06:13:00.161394
# Unit test for constructor of class Conditional
def test_Conditional():
    with pytest.raises(AnsibleError):
        Conditional()

# Generated at 2022-06-23 06:13:07.137090
# Unit test for constructor of class Conditional
def test_Conditional():
    # when used directly, this class needs a loader, but we want to
    # make sure we don't trample on the existing one if this class
    # is used as a mix-in with a playbook base class
    from ansible.playbook import Playbook
    from ansible.plugins import module_loader
    loader = module_loader._find_plugin(Playbook(), 'copy')
    test_Conditional = Conditional(loader)
    assert test_Conditional._loader == loader
    return test_Conditional


# Generated at 2022-06-23 06:13:16.456849
# Unit test for method extract_defined_undefined of class Conditional