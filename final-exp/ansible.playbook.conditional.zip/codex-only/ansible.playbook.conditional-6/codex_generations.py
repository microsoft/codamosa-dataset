

# Generated at 2022-06-23 06:03:22.016857
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    data = {
        "results": {
            "item2": {
                "result": False,
            },
            "item3": {
                "result": True,
            }
        }
    }

    from ansible.template import Templar

    templar = Templar(variables=data)

    class testobj(object):
        when = ["{{ results.item1.result }}",
                "{{ results.item2.result }}"]

    obj = testobj()
    obj.evaluate_conditional(templar, data)



# Generated at 2022-06-23 06:03:30.618591
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-23 06:03:31.380175
# Unit test for constructor of class Conditional
def test_Conditional():

    c = Conditional()
    assert c._when == []


# Generated at 2022-06-23 06:03:38.926368
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    def _eval_conditional(cond_val, val, res):
        mc = MockConditional(when=cond_val)
        mc.templar = MagicMock()
        mc.templar.is_template = lambda x: False
        mc.templar.template = lambda x, y: val
        assert mc.evaluate_conditional(mc.templar, dict()) == res
    _eval_conditional(None, None, True)
    _eval_conditional('', None, True)
    _eval_conditional(True, None, True)
    _eval_conditional(False, None, False)
    _eval_conditional(True, 'True', True)
    _eval_conditional(True, 'False', False)
    _eval_conditional(True, 'true', True)
    _eval_

# Generated at 2022-06-23 06:03:48.250416
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # setup
    from ansible.playbook.play_context import PlayContext
    from ansible.template.template import Templar
    c = Conditional()
    class FakeLoader():
        def __init__(self):
            self.list_templates = lambda: return_value['env']['templates']
        def get_basedir(self):
            return '.'
    loader = FakeLoader()
    templar = Templar(loader=loader)
    play_context = PlayContext(become_method=None, become_user=None)
    templar.set_available_variables(play_context.get_vars(), loader)

    # run the test
    return_value = {'env': {'templates': []}}
    assert(c.evaluate_conditional(templar, {}))

# Generated at 2022-06-23 06:03:57.439362
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Tests for extract_defined_undefined
    # Create an instance of Conditional
    conditional = Conditional()

    extract = conditional.extract_defined_undefined
    assert extract("hostvars['foo'] is not defined") == [("hostvars['foo']", 'is not', 'defined')]
    assert extract("hostvars['foo'] is not defined and hostvars['bar'] is defined") == [("hostvars['foo']", 'is not', 'defined'), ("hostvars['bar']", 'is', 'defined')]
    assert extract("hostvars['foo']['bar'] is not defined") == [("hostvars['foo']['bar']", 'is not', 'defined')]

# Generated at 2022-06-23 06:04:08.072008
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    Test method extract_defined_undefined of class Conditional
    '''

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    all_vars = dict()

    class MyConditional(Conditional):
        pass
    myconditional = MyConditional()

    class MyHost:
        name = 'testhost'
        vars = dict()
        port = 22
    class MyTask:
        name = 'testtask'
        vars = dict()
        loop = 'host'
        _variable_manager = None
    class MyPlayContext(PlayContext):
        def __init__(self):
            super(MyPlayContext, self).__init__()
            self.remote_addr = '1.2.3.4'

# Generated at 2022-06-23 06:04:18.827242
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    display = Display()
    display.verbosity = 6

    # test case 1: Basic variable lookup
    # test case 2 : variable lookup in string
    # test case 3 : Negation
    # test case 4 : negative is_defined and blanks
    # test case 5 : negative is_undefined and blanks
    # test case 6 : lookup with none value
    # test case 7 : multiple conditionals
    # test case 8 : undefined variable in conditional
    # test case 9 : complex boolean expression - AND
    # test case 10: complex boolean expression - OR
    # test case 11: complex boolean expression - NOT
    # test case 12: complex boolean expression - nested
    # test case 13: complex boolean expression - parentheses
    # test case 14: complex boolean expression - undefined vars

    from ansible.template import Templar
    from ansible.vars import VariableManager


# Generated at 2022-06-23 06:04:30.064818
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    context = PlayContext(variable_manager=variable_manager)

    templar = Templar(loader, variable_manager, context)

    cond = Conditional()
    cond.when = ['{{ foo }}']

    # Fail
    res = cond.evaluate_conditional(templar, dict())
    assert not res

    # Succeed
    res = cond.evaluate_conditional(templar, dict(foo=1))
    assert res


# Generated at 2022-06-23 06:04:40.470634
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # NOTE: This unit test is only a first test to check that when statements with
    # undefined variables can be evaluated.
    # See https://github.com/ansible/ansible/issues/46505
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    # this dict contains the variable named in the condition defined
    # in the tasks
    all_vars = dict(foo=True, bar=None, hostvars=dict(foo=False))

    cond = '"{{ foo }}" == "{{ bar }}"'
    templar = Templar(loader=None, shared_loader_obj=None, variables=all_vars, vault_secrets=VaultLib())
    assert Conditional().evaluate_conditional(templar, all_vars) is True


# Generated at 2022-06-23 06:04:53.090709
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:05:04.858880
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("foo") == []
    assert c.extract_defined_undefined("undefined") == []
    assert c.extract_defined_undefined("is undefined") == []
    assert c.extract_defined_undefined("not is defined") == [("not", "not", "defined")]
    assert c.extract_defined_undefined("foo is undefined") == [("foo","is","undefined")]
    assert c.extract_defined_undefined("foo is not undefined") == [("foo","is not","undefined")]
    assert c.extract_defined_undefined("foo is defined") == [("foo","is","defined")]

# Generated at 2022-06-23 06:05:07.591730
# Unit test for constructor of class Conditional
def test_Conditional():
    assert '_when' in Conditional.__dict__
    assert '_when' in Conditional.__dict__.get('_get_attributes')()

# Generated at 2022-06-23 06:05:16.074432
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestClass(object):
        class Mixin(Conditional):
            _when = FieldAttribute(isa='list', default=list, extend=True, prepend=True)
        when = [{'test1': 2, 'test2': 3}, {'test1': 3, 'test2': 4}, 'test3']
    tc = TestClass()
    m = TestClass.Mixin()
    class MockTemplar(object):
        def template(self, value, disable_lookups):
            return value
        def is_template(self, value):
            return False

# Generated at 2022-06-23 06:05:28.860530
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    my_play_context = PlayContext()
    myplay = Play()
    myplay.vars = dict(var1=True, var2=False)
    myplay._ds = {}
    myplay._play_context = my_play_context

    templar = Templar(loader=None, variables=myplay.vars)
    conditional = Conditional(loader=None)

    assert conditional.evaluate_conditional(templar, myplay.vars) == True
    #assert conditional._check_conditional(templar, myplay.vars, "var1") == True
    #assert conditional._check_conditional(templar, myplay.vars, "var2") == False
    #assert conditional._check_cond

# Generated at 2022-06-23 06:05:37.426493
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible import constants as C
    from ansible.playbook.play_context import PlayContext

    # create a play context
    play_context = PlayContext()
    play_context.become = True
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'

    # create variables for the host and the play
    variables_for_host = dict()
    variables_for_host['foo'] = 'bar'
    variables_for_play = dict()
    variables_for_play['bar'] = 'foo'

    # create a Conditional object
    conditional = Conditional()
    conditional.when = ['not bar', 'foo']

    # run the object as a unit test

# Generated at 2022-06-23 06:05:47.022388
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar, HostVars

    play_context = PlayContext()
    templar = Templar(loader=None, variables={}, shared_loader_obj=None, disable_lookups=False,
                      fail_on_lookup_errors=False, initial_variables=None, use_hostvars=True,
                      environment=None)
    all_vars = dict()

    conditional = Conditional()
    # Test with empty when list
    conditional.when = list()
    result = conditional.evaluate_conditional(templar, all_vars)
    assert result
    # Test with singleton true value
    conditional.when = list([True])
    result = conditional.evaluate_conditional(templar, all_vars)
    assert result

# Generated at 2022-06-23 06:05:58.314794
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    playbook_conditional = Conditional(loader=None)

    # test empty conditionals
    run_conditional_test(playbook_conditional, [], True)

    # test truthy conditionals
    run_conditional_test(playbook_conditional, [True], True)
    run_conditional_test(playbook_conditional, ["foo"], True)
    run_conditional_test(playbook_conditional, [True, "foo"], True)
    run_conditional_test(playbook_conditional, ["foo", "foo"], True)
    run_conditional_test(playbook_conditional, [True, "foo", "foo"], True)
    run_conditional_test(playbook_conditional, ["foo", "foo", True], True)

# Generated at 2022-06-23 06:06:09.541699
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

# Generated at 2022-06-23 06:06:16.094954
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.taggable import Taggable
    from ansible.plugins.loader import fragment_loader
    from ansible.template import Templar

    class MyRole(RoleDefinition):
        def __init__(self, *args, **kwargs):
            super(MyRole, self).__init__(*args, **kwargs)
            self.__class__.__name__ = "Role"

    class MyYAML(AnsibleBaseYAMLObject, Taggable):
        pass

    # Variables are not needed, just something to get past __init__ of Templar.
    templar = Templar(loader=None, variables={})

    # Test an empty conditional

# Generated at 2022-06-23 06:06:26.310918
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar  # FIXME: workaround for circular imports, Templar should be injected
    from ansible.vars import VariableManager  # FIXME: workaround for circular imports, VariableManager should be injected

    class TestClass: pass

    testclass = TestClass()
    testclass.when = [
        'a is defined',  # correct variable
        'is defined',  # variable missing
        'a in hostvars',  # correct expression involving variable
        'is defined',  # correct result, but expression is missing
        'defined_var is defined',  # correct variable
        'defined_var is unknown',  # correct variable
        'unknown_var is defined',  # incorrect variable
        'unknown_var is not defined',  # incorrect variable
        'in hostvars',  # expression is missing
    ]

    variable_manager = VariableManager

# Generated at 2022-06-23 06:06:33.952578
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class ConditionalDummy(Conditional):
        def __init__(self):
            super(ConditionalDummy, self).__init__()

    c = ConditionalDummy()

# Generated at 2022-06-23 06:06:45.166381
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    res = c.extract_defined_undefined('  hello  not is defined or foo')
    assert res == [('hello', 'not is', 'defined'), ('foo', 'is', 'undefined')]
    res = c.extract_defined_undefined('  hello  not is defined and foo is undefined')
    assert res == [('hello', 'not is', 'defined'), ('foo', 'is', 'undefined')]
    res = c.extract_defined_undefined('  hello  not is defined and (foo is undefined or bar)')
    assert res == [('hello', 'not is', 'defined'), ('foo', 'is', 'undefined'), ('bar', 'is', 'undefined')]

# Generated at 2022-06-23 06:06:50.439733
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c.when == []
    c = Conditional(loader=None)
    assert c.when == []

# Generated at 2022-06-23 06:06:57.306250
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

    assert c.extract_defined_undefined('foo not is defined and bar is defined') == [('foo', 'not is', 'defined'), ('bar', 'is', 'defined')]
    assert c.extract_defined_undefined('foo is undefined or bar is defined') == [('foo', 'is', 'undefined'), ('bar', 'is', 'defined')]
    assert c.extract_defined_undefined('foo is undefined and bar is undefined') == [('foo', 'is', 'undefined'), ('bar', 'is', 'undefined')]
    assert c.extract_defined_undefined('foo is undefined and bar is defined') == [('foo', 'is', 'undefined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-23 06:07:06.632725
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    result = cond.extract_defined_undefined("foo is defined or bar is defined")
    assert result == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]
    result = cond.extract_defined_undefined("foo is defined or bar is undefined")
    assert result == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]
    result = cond.extract_defined_undefined("foo is undefined or bar is defined")
    assert result == [('foo', 'is', 'undefined'), ('bar', 'is', 'defined')]
    result = cond.extract_defined_undefined("foo is undefined or bar is undefined")
    assert result == [('foo', 'is', 'undefined'), ('bar', 'is', 'undefined')]


# Generated at 2022-06-23 06:07:16.848045
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def check(conditional, expected):
        conditional = Conditional()
        results = conditional.extract_defined_undefined(conditional)
        assert results == expected

    check("", [])
    check("this is undefined", [])
    check("defined or undefined", [])
    check("foo is defined", [('foo','is','defined')])
    check("foo is not defined", [('foo','is not','defined')])
    check("foo is undefined", [('foo','is','undefined')])
    check("foo is not undefined", [('foo','is not','undefined')])
    check("foo is not defined or foo is not undefined", [('foo','is not','defined'),('foo','is not','undefined')])

# Generated at 2022-06-23 06:07:22.563838
# Unit test for constructor of class Conditional
def test_Conditional():
    # Test case 1 : Conditional class without loader
    try:
        obj = Conditional()
    except AnsibleError:
        obj = None
    assert obj is None

    # Test case 2 : Conditional class with loader
    obj = Conditional(loader=True)
    assert obj is not None


# Generated at 2022-06-23 06:07:33.485638
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars
    import ansible.constants as C

    variable_manager = VariableManager()
    variable_manager.extra_vars = combine_vars(loader=None, variables=variable_manager.get_vars(play=None, host=None, task=None))

    class TestConditional(Conditional):
        def __init__(self):
            self._loader = None
            self._variable_manager = variable_manager
            super(TestConditional, self).__init__(loader=None)

    display.verbosity = 3
    display.always_verbose = True

    def test_evaluate_conditional_failed(when, variable_manager):
        C.DEFAULT_HASHED_HOST_KEYS = False
        tc

# Generated at 2022-06-23 06:07:39.796753
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    display.display("Test Conditional extract_defined_undefined")
    d = Conditional()
    conditional = 'hostvars[inventory_hostname] is defined and hostvars[inventory_hostname].foo is not undefined'
    exp = [('hostvars[inventory_hostname]', 'is', 'defined'), ('hostvars[inventory_hostname].foo', 'is not', 'undefined')]
    result = d.extract_defined_undefined(conditional)
    assert result == exp

# Generated at 2022-06-23 06:07:46.933790
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    def_vars = dict(
        ansible_distribution="Debian",
    )
    templar = Templar(loader=None, variables=def_vars)


# Generated at 2022-06-23 06:07:57.199825
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = "hostvars['foo'] is defined or hostvars['foo'] is undefined or bar is defined or bar is undefined or (bar is defined and bar is undefined)"
    expected = [('hostvars[\'foo\']', 'is', 'defined'), ('hostvars[\'foo\']', 'is', 'undefined'), ('bar', 'is', 'defined'), ('bar', 'is', 'undefined'), ('bar', 'is', 'defined'), ('bar', 'is', 'undefined')]
    actual = Conditional().extract_defined_undefined(conditional)
    assert expected == actual


# Generated at 2022-06-23 06:08:07.284692
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    expected_results = [('"foo"', 'is not', 'defined'),
                        ('foo', 'not is', 'defined'),
                        ('foo', 'is', 'undefined'),
                        ('bar', 'is not', 'defined'),
                        ('bar', 'is', 'undefined')]
    cond = '"foo" is not defined or foo not is defined or foo is undefined or (bar is not defined and bar is undefined)'
    cond_obj = Conditional()
    result = cond_obj.extract_defined_undefined(cond)
    assert result == expected_results, \
        "extract_defined_undefined did not return expected result: %s" % result

# Generated at 2022-06-23 06:08:09.252297
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional._when == []
    assert conditional._loader == None

# Generated at 2022-06-23 06:08:21.375820
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    hostvars = dict(
        foo='bar',
        foo2=True
    )
    all_vars = dict(
        localhost=dict(
            ansible_connection='local',
            ansible_python_interpreter='/usr/bin/python',
            ansible_hostname='localhost',
            foo='bar',
            foo2=True
        )
    )
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
   

# Generated at 2022-06-23 06:08:22.700306
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional.when == []

# Generated at 2022-06-23 06:08:23.175922
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()

# Generated at 2022-06-23 06:08:28.705951
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert Conditional().extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert Conditional().extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert Conditional().extract_defined_undefined("foo is not defined and bar is defined") == [("foo", "is not", "defined"), ("bar", "is", "defined")]


# Generated at 2022-06-23 06:08:41.155436
# Unit test for constructor of class Conditional
def test_Conditional():
    import sys
    import os
    import unittest
    import ansible.playbook
    import ansible.playbook.task
    import ansible.playbook.role
    import ansible.template
    import ansible.inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    class Options(object):
        def __init__(self):
            self.connection = 'local'
            self.module_path = [os.getcwd()]

# Generated at 2022-06-23 06:08:49.514073
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    errors = []

    cond = "a and b and c and d is defined and e is not defined and f == 'g'"
    exp = [
        ('a', 'and', 'defined'),
        ('b', 'and', 'defined'),
        ('c', 'and', 'defined'),
        ('d', 'is', 'defined'),
        ('e', 'is not', 'defined'),
        ('f', '==', 'defined')
    ]
    ret = Conditional().extract_defined_undefined(cond)
    if exp != ret:
        errors.append('FAILED: Conditional().extract_defined_undefined() returned %s instead of %s when cond is \'%s\'' % (ret, exp, cond))


# Generated at 2022-06-23 06:08:59.398504
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    regex = re.compile(r'(hostvars\[.+\]|[\w_]+)\s+(not\s+is|is|is\s+not)\s+(defined|undefined)')

    # test the positive case with 2 defined/undefined tests
    assert conditional.extract_defined_undefined('foo is defined and bar not is undefined') == [('foo', 'is', 'defined'), ('bar', 'not is', 'undefined')]
    # test the negative case with empty string
    assert conditional.extract_defined_undefined('') == []
    # test the negative case with just a string
    assert conditional.extract_defined_undefined('ansible') == []
    # test the negative case with a normal conditional

# Generated at 2022-06-23 06:09:05.550728
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import os

    class ConditionalTest(Conditional):
        def __init__(self):
            super(ConditionalTest, self).__init__()
            self.when = ['ansible_local', 'ansible_foobar']

        def _validate_when(self, attr, name, value):
            if not isinstance(value, list):
                setattr(self, name, [value])

        def _evaluate_conditional(self, templar, all_vars):
            return self.evaluate_conditional(templar, all_vars)

        def _check_conditional(self, conditional, templar, all_vars):
            return self._check_conditional(conditional, templar, all_vars)

    test = ConditionalTest()

# Generated at 2022-06-23 06:09:16.678619
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # IMPORTANT: this method is used inside the unit test
    # of the class Conditional called test_Conditional_evaluate_conditional
    # which is why it is outside the scope of the class
    # Conditional and inside the scope of the module
    # playbook.
    # It is defined as a global method, so it can
    # be called inside the unit test in order to test
    # the method evaluate_conditional of the class Conditional.
    # Unit tests for a method inside a class must be outside
    # the scope of the class.
    from ansible.playbook.block import Block
    from ansible.template import Templar

    _loader = DictDataLoader({})


# Generated at 2022-06-23 06:09:28.309676
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert Conditional().extract_defined_undefined('a is defined') == [('a', 'is', 'defined')]
    assert Conditional().extract_defined_undefined('a is not undefined') == [('a', 'is not', 'undefined')]
    assert Conditional().extract_defined_undefined('a is not defined') == [('a', 'is not', 'defined')]
    assert Conditional().extract_defined_undefined('a is undefined') == [('a', 'is', 'undefined')]
    assert Conditional().extract_defined_undefined('a is not') == []
    assert Conditional().extract_defined_undefined('is not a') == []

# Generated at 2022-06-23 06:09:41.179247
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    # Skip the test if an environment variable is set
    if C.DEFAULT_VAULT_ID_MATCH:
        if 'C' in list(globals()):
            print('SKIPPING TEST: environment variable "ANSIBLE_VAULT_PASSWORD_FILE" set')
            return

    # Get a sample valid conditional statement

# Generated at 2022-06-23 06:09:51.299556
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.errors import AnsibleUndefinedVariable, AnsibleError
    from ansible.template import Templar

    # test with invalid conditional expression - should raise AnsibleError
    assert_raises(AnsibleError, Conditional().evaluate_conditional, Templar('/', convert_data=False), dict(a=1))

    # test with valid conditional expression - should return True
    assert Conditional().evaluate_conditional(Templar('/', convert_data=False), dict(a=1))

    # test with invalid conditional expression which should raise AnsibleUndefinedVariable - should return False
    assert_raises(AnsibleUndefinedVariable, Conditional().evaluate_conditional, Templar('/', convert_data=False), dict(a=1))

# Generated at 2022-06-23 06:09:53.180024
# Unit test for constructor of class Conditional
def test_Conditional():
    assert Conditional is not None
    c = Conditional(loader=None)
    assert c is not None

# Generated at 2022-06-23 06:10:04.413216
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    display = Display()
    def mock_display(warning):
        # we need to save the warning somehow, and print it to stderr.
        display.warning(warning)
    display.warning = mock_display
    conditional = Conditional()
    templar = MockTemplar()
    all_vars = dict()
    conditional.evaluate_conditional(templar, all_vars)

    conditional = Conditional()
    conditional.when = [False]
    templar = MockTemplar()
    all_vars = dict()
    assert(not conditional.evaluate_conditional(templar, all_vars))

    conditional = Conditional()
    conditional.when = [True]
    templar = MockTemplar()
    all_vars = dict()

# Generated at 2022-06-23 06:10:13.931575
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    host_vars = dict()
    host_vars['ansible_ssh_user'] = 'testuser'
    host_vars['ansible_ssh_pass'] = 'testpass'
    all_vars = {'hostvars': host_vars, 'var1': 'val1'}
    templar = CustomTemplar()
    conditional = Conditional()
    # test to validate the variable
    res = conditional.evaluate_conditional(templar, all_vars)
    assert res is True
    # test to validate the fact db
    res = conditional.evaluate_conditional(templar, all_vars)
    assert res is True
    # test to validate the variable ansible_ssh_pass
    cond = 'ansible_ssh_pass'

# Generated at 2022-06-23 06:10:24.965406
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    import pytest

    source = "hostvars[inventory_hostname] is undefined and hostvars['foo'] is not defined"
    conditional = Conditional()
    res = conditional.extract_defined_undefined(source)
    assert res == [
        ('hostvars[inventory_hostname]', 'is', 'undefined'),
        ('hostvars[\'foo\']', 'is not', 'defined'),
    ]

    source = 'inventory_hostname == "foo" and hostvars[inventory_hostname] is undefined and hostvars[\'foo\'] is not defined and "foo" not in hostvars'
    conditional = Conditional()
    res = conditional.extract_defined_undefined(source)

# Generated at 2022-06-23 06:10:31.923089
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    display.verbosity = 3
    c = Conditional()
    c.when = {
        "var1 == 1 or var2 is defined or foo.bar is not undefined or var3|default('') == 42",
        "bar is defined and (var1 == 0 or var2 == 'foo' or var3 is undefined)",
    }
    results = [
        ['var1', '==', '1'],
        ['var2', 'is', 'defined'],
        ['foo.bar', 'is', 'not', 'undefined'],
        ['var3', '==', '42'],
        ['bar', 'is', 'defined'],
        ['var1', '==', '0'],
        ['var2', '==', 'foo'],
        ['var3', 'is', 'undefined'],
    ]

# Generated at 2022-06-23 06:10:43.152346
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond1 = 'not (foo is defined and bar is defined)'
    cond2 = 'not (foo is defined and bar is defined and baz is defined)'
    cond3 = 'not (foo is defined and bar is undefined)'
    cond4 = 'not (foo is undefined and bar is defined)'
    cond5 = 'not (foo is not defined and bar is not defined)'

    c = Conditional()

    assert c.extract_defined_undefined(cond1) == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]
    assert c.extract_defined_undefined(cond2) == [('foo', 'is', 'defined'), ('bar', 'is', 'defined'), ('baz', 'is', 'defined')]

# Generated at 2022-06-23 06:10:51.771955
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class FakeTemplar(object):
        def __init__(self, variables):
            self.available_variables = variables
            self.is_template = lambda x: False

        def template(self, data, disable_lookups=False):
            if disable_lookups:
                raise Exception(data)
            else:
                return data

    class FakePlay(object):
        def __init__(self, loader=None, variables=None):
            self.hosts = ['host1', 'host2', 'host3']
            self.vars = variables
            self.get_variable = lambda x, y: variables[y]


# Generated at 2022-06-23 06:11:02.477673
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.six import PY3
    from ansible.template import Templar

    # Extract defined/undefined
    assert [(u'foo', u'is', u'defined')] == Conditional().extract_defined_undefined(u"foo is defined")
    assert [(u'foo', u'not is', u'undefined')] == Conditional().extract_defined_undefined(u"foo not is undefined")
    assert [(u'foo', u'is', u'undefined'), (u'bar', u'is', u'undefined')] == Conditional().extract_defined_undefined(u"foo is undefined and bar is undefined")
    assert [(u'foo', u'is', u'undefined')] == Conditional().extract_defined

# Generated at 2022-06-23 06:11:04.280853
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional(loader=None)
    assert(conditional)

# Generated at 2022-06-23 06:11:15.731149
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:11:19.333475
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    conditional_obj = Conditional(loader)
    assert conditional_obj

# Generated at 2022-06-23 06:11:29.298667
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert c.extract_defined_undefined('foo is defined or bar is defined') == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-23 06:11:30.417119
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c._when == []


# Generated at 2022-06-23 06:11:38.229435
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional
    assert hasattr(conditional, 'when')
    assert not conditional.when
    assert not hasattr(conditional, '_loader')
    assert not conditional.evaluate_conditional({}, {})

    conditional = Conditional('loader')
    assert conditional
    assert hasattr(conditional, 'when')
    assert not conditional.when
    assert hasattr(conditional, '_loader')
    assert conditional._loader == 'loader'
    assert not conditional.evaluate_conditional({}, {})

    conditional = Conditional()
    conditional.when = 'a'
    assert conditional.when == ['a']



# Generated at 2022-06-23 06:11:42.673281
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    conditional = "1 == 2 and (hostvars['localhost'].name is not defined or hostvars['localhost'].name == 'localhost') and (hostvars['127.0.0.1'].name is not defined or hostvars['127.0.0.1'].name == 'localhost')"
    display.display(cond.extract_defined_undefined(conditional))


# Generated at 2022-06-23 06:11:51.908344
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.plugins.loader import include_role_tasks_vars
    from ansible.template import Templar
    from ansible import variables
    from ansible.vars.manager import VariableManager

    # init some ansible objects
    variable_manager = VariableManager()

# Generated at 2022-06-23 06:12:02.589673
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from jinja2 import Environment
    from ansible.vars import VariableManager

    # Create a mock environment
    env = Environment()
    # Create a mock loader
    loader = DictDataLoader({
        'roles/foo/tasks/main.yml': """
        - name: some task
          debug: msg="hello world"
        """,
        'roles/bar/tasks/main.yml': """
        - name: some other task
          debug: msg="hello world"
        """,
        'playbook.yml': """
        - hosts: localhost
          roles:
            - { role: foo }
            - { role: bar, when: False }
        """})

    # Create a mock variable manager
    variable_manager = VariableManager()
    variable_

# Generated at 2022-06-23 06:12:13.700367
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = """hostvars['group1_host1'] is undefined and (hostvars['group2_host1'] is defined or group_names | count >1)"""
    c = Conditional()
    cond_list = c.extract_defined_undefined(conditional)
    assert [("hostvars['group1_host1']", "is", "undefined")] == cond_list

    conditional = """hostvars['group1_host1'] is defined or hostvars['group1_host1'] is undefined"""
    c = Conditional()
    cond_list = c.extract_defined_undefined(conditional)
    assert [("hostvars['group1_host1']", "is", "defined"), ("hostvars['group1_host1']", "is", "undefined")] == cond_list

   

# Generated at 2022-06-23 06:12:15.771529
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c._when
    assert isinstance(c._when, list)

# Generated at 2022-06-23 06:12:28.048155
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestConditional(Conditional):
        def __init__(self, conditional):
            self.when = conditional

    class TestVarManager:
        def __init__(self, var_dict):
            self.vars = var_dict

    # test 1: defined or undefined variables
    templar = TestVarManager({'foo': 'bar'})
    print("When: %s" % [("hostvars['foo']", "is", "defined"), ("hostvars['bar']", "is", "undefined")])
    result = TestConditional([("hostvars['foo']", "is", "defined"), ("hostvars['bar']", "is", "undefined")]).evaluate_conditional(all_vars=templar)
    if result:
        print("Test 1 OK")

# Generated at 2022-06-23 06:12:29.545655
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional is not None


# Generated at 2022-06-23 06:12:41.023067
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    # test valid input
    c = Conditional()
    assert c.extract_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')], \
        'extract_defined_undefined failed for valid input'

    assert c.extract_defined_undefined('hostvars[inventory_hostname] is not defined') == [('hostvars[inventory_hostname]', 'is not', 'defined')], \
        'extract_defined_undefined failed for valid input'


# Generated at 2022-06-23 06:12:48.254414
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar

    simple_play = [
        {"name": "simple_play", "hosts": ["all"], "gather_facts": "no"}
    ]
    single_host = ['localhost']
    template_variables = {'status': True}
    loader = DataLoader()

    vm = VariableManager()
    inventory = InventoryManager(loader=loader, sources=single_host)
    templar = Templar(loader=loader, variables=template_variables)
    full_vars = vm.get_vars()
    full_vars.update(inventory.get_host_variables(single_host[0]))
   

# Generated at 2022-06-23 06:13:00.074981
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from units.mock.loader import DictDataLoader

    mock_loader = DictDataLoader({
        "main.yml": "{value}",
        "sub.yml": "{{ foo }}",
        "sub2.yml": "{{ hostvars[inventory_hostname].foo }}",
        "sub3.yml": "{{ hostvars[inventory_hostname]['foo'] }}",
    })

    class TestConditional(Conditional):
        pass

    playbook = TestConditional(mock_loader)

    def run_test_scenario(conditional, data, result):
        playbook.when = conditional
        return playbook.evaluate_conditional(data, data) == result

    assert run_test_scenario("foo", {}, False)

# Generated at 2022-06-23 06:13:10.068428
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar

    # Create a mock loader for the templar
    class MyLoader:
        pass

    # Create a mock datastructure for the templar
    class MyDS:
        pass

    # Create a Conditional object and fill it with test data
    conditional = Conditional(loader=MyLoader())
    conditional._ds = MyDS()
    conditional._ds._data = dict()

    # Fill the templar with the conditional
    templar = Templar(loader=MyLoader())
    templar.set_available_variables(conditional._ds._data)

    # Define test strings
    test_var = dict()
    test_var['name'] = 'first'
    test_var['value'] = 'success'

# Generated at 2022-06-23 06:13:18.702016
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class MyConditional(Conditional):
        def __init__(self, condition, result):
            self.when = [condition]
            self.result = result

        def check_condition(self, templar, all_vars):
            res = self._check_conditional(self.when[0], templar, all_vars)
            assert res == self.result

    from ansible.template import Templar
