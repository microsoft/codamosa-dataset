

# Generated at 2022-06-23 06:03:18.152711
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert '_when' in c.__dict__
    assert c._when == []

    c2 = Conditional()
    c2._when = ['foo', 'bar']
    c2.validate()
    assert c2._when == ['foo', 'bar']


# Generated at 2022-06-23 06:03:26.987838
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    _hostvars = 'hostvars'
    conditional = "{0}.password is {1}".format(_hostvars, 'undefined')
    match = DEFINED_REGEX.search(conditional)
    if match is None:
        raise AssertionError('_extract_defined_undefined: FAIL')

    _hostname = 'hostname'
    conditional = "{0} is {1}".format(_hostname, 'undefined')
    match = DEFINED_REGEX.search(conditional)
    if match is None:
        raise AssertionError('_extract_defined_undefined: FAIL')

    _hostname = 'hostname'
    conditional = "{0} is not {1}".format(_hostname, 'undefined')
    match = DEFINED_REGEX.search(conditional)

# Generated at 2022-06-23 06:03:36.014562
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    def _all_vars_from_dict(d):
        return dict([(x,to_text(d[x])) for x in d])

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables=dict(), shared_loader_obj=None)

    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    raw_dict = dict(
        a=dict(
            b='ok',
        ),
        c=dict(
            d=dict(
                e=dict(
                    f='ok',
                ),
            ),
        ),
        g='ok',
        h=['ok'],
    )

    # Test with simple strings
   

# Generated at 2022-06-23 06:03:46.480332
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    variable_manager.options_vars = {'ansible_ssh_user': 'some_user'}
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    templar = Templar(loader=loader, variables=variable_manager)

    conditional = Conditional()

    assert conditional.evaluate_conditional(templar, variable_manager.get_vars()) is True
    conditional._when = [False]

# Generated at 2022-06-23 06:03:48.736050
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert isinstance(conditional, Conditional)
    assert conditional._when == []
    conditional = Conditional(loader=None)
    assert isinstance(conditional, Conditional)
    assert conditional._when == []
    assert conditional._loader is None

# Generated at 2022-06-23 06:03:58.041167
# Unit test for constructor of class Conditional
def test_Conditional():
    # since this is a mix-in, it may not have an underlying datastructure
    # associated with it, so we pull it out now in case we need it for
    # error reporting below
    ds = None
    if hasattr(self, '_ds'):
        ds = getattr(self, '_ds')

    result = True


# Generated at 2022-06-23 06:04:08.507398
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext

    mock_play_context = PlayContext(play=None)
    mock_play_context._remote_pass = ""
    mock_play_context._remote_user = ""
    mock_play_context.deprecation_warnings = ""
    mock_play_context.diff = ""
    mock_play_context.forks = ""
    mock_play_context.hostvars = {}
    mock_play_context.password_satisfies_policy = ""
    mock_play_context.prompt = ""
    mock_play_context.sftp_extra_args = ""
    mock_play_context.connection = ""
    mock_play_context.timeout = ""
    mock_play_context.update_vault_secrets = ""
    mock_play_context

# Generated at 2022-06-23 06:04:19.079534
# Unit test for constructor of class Conditional
def test_Conditional():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    p = PlayContext()
    t = Templar(loader=None, variables={})

    c = Conditional(loader=None)

    c.when = [True]
    assert c.evaluate_conditional(t, p)

    c.when = [False]
    assert not c.evaluate_conditional(t, p)

    c.when = [None]
    assert c.evaluate_conditional(t, p)

    c.when = [""]
    assert c.evaluate_conditional(t, p)

    c.when = [[]]
    assert c.evaluate_conditional(t, p)

    c.when = ["1==1"]
    assert c.evaluate_conditional(t, p)


# Generated at 2022-06-23 06:04:26.151282
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class MyClass():
        when = []
        def __init__(self):
            self._loader = None

    my_class = MyClass()
    my_class.when = [Undefined()]
    if not my_class.evaluate_conditional(None, None):
        print("Unit test passed!")
    else:
        print("Unit test failed!")



# Generated at 2022-06-23 06:04:39.411416
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    # test invalid conditionals
    c1 = Conditional(loader)
    try:
        c1.evaluate_conditional(templar, dict())
        raise AssertionError("expected error not raised")
    except AnsibleError as e:
        pass
    c1.when = [None]
    c1.evaluate_conditional(templar, dict())

    # test valid conditionals

# Generated at 2022-06-23 06:04:41.192102
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_obj = Conditional('loader')
    assert conditional_obj._loader == 'loader'

# Generated at 2022-06-23 06:04:48.856419
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.task import Task
    conditional = Conditional()


# Generated at 2022-06-23 06:04:59.489530
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class AnsibleModuleMock:
        def __init__(self, **kwargs):
            pass

    class AnsibleFileMock:
        def __init__(self, path, **kwargs):
            self.path = "/path/to/" + path

    class AnsibleTemplateMock:
        def __init__(self, **kwargs):
            pass

    class AnsibleLoaderMock:
        def __init__(self, **kwargs):
            pass
        def get_basedir(self, path):
            return "/path/to/"
        def is_file(self, path):
            if path == "/path/to/test.yml":
                return False
            return True
        def path_dwim(self, path):
            if path == "test.yml":
                return path, True

# Generated at 2022-06-23 06:05:10.276460
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    Test method extract_defined_undefined from class Conditional.
    This method extracts defined and undefined tests within
    conditional statements, e.g. 'not test_var|default("") is defined'
    '''

# Generated at 2022-06-23 06:05:20.389989
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    conditional_str = "foo == 'bar' and (baz is defined or foz is undefined)"
    assert sorted(conditional.extract_defined_undefined(conditional_str)) == sorted(
        [("baz", "is", "defined"), ("foz", "is", "undefined")]
    )

    conditional_str = "not foo == 'bar' and not (baz is defined or foz is not undefined)"
    assert sorted(conditional.extract_defined_undefined(conditional_str)) == sorted(
        [("baz", "is", "defined"), ("foz", "is not", "undefined")]
    )

    conditional_str = "hostvars['foo'] is defined and hostvars['bar'] is not defined"

# Generated at 2022-06-23 06:05:31.189635
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # helper class to mock the base class of Conditional
    class MockBase:
        def __init__(self):
            self.when = []

    # object on which to test the evaluate_conditional method
    test_obj = Conditional()
    test_obj.__class__ = MockBase

    # empty when
    assert test_obj.evaluate_conditional(None, {}) == True

    # when with a boolean value
    test_obj.when = [True]
    assert test_obj.evaluate_conditional(None, {}) == True

    test_obj.when = [False]
    assert test_obj.evaluate_conditional(None, {}) == False

    # when with a non-empty string
    test_obj.when = ['something']
    assert test_obj.evaluate_conditional(None, {}) == False

   

# Generated at 2022-06-23 06:05:38.563017
# Unit test for constructor of class Conditional
def test_Conditional():

    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=None, host=None))

    c = Conditional(loader=loader)

    # Testing extract_defined_undefined()
    conditional = "hostvars['foo'] is defined"
    result = c.extract_defined_undefined(conditional)
    assert result == [("hostvars['foo']", 'is', 'defined')]


# Generated at 2022-06-23 06:05:45.965025
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional(loader=None)
    assert cond.extract_defined_undefined('foo is not defined and bar is defined') == \
            [('foo', 'not is', 'defined'), ('bar', 'is', 'defined')]
    assert cond.extract_defined_undefined('foo is not defined or bar is defined') == \
            [('foo', 'not is', 'defined'), ('bar', 'is', 'defined')]
    assert cond.extract_defined_undefined('foo is not defined or bar is  defined') == \
            [('foo', 'not is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-23 06:05:57.092454
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    Test the method extract_defined_undefined of class Conditional
    '''
    test_conditional = Conditional()
    assert test_conditional.extract_defined_undefined("") == []
    assert test_conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert test_conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert test_conditional.extract_defined_undefined("foo is not defined and bar is undefined") == \
        [('foo', 'is not', 'defined'), ('bar', 'is', 'undefined')]

# Generated at 2022-06-23 06:06:08.841022
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook import Playbook
    from ansible.utils.vars import combine_vars

    # create the variable manager and objects needed for the conditional's templar
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory/host_vars/hostvars.yml'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    display.verbosity = 2

    # create a dummy playbook object, which should be acceptable for Conditional's templar
    playbook = Playbook()
    playbook._loader = loader
    playbook._tqm = None

    # create a Conditional object directly, which

# Generated at 2022-06-23 06:06:11.422368
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    assert Conditional().evaluate_conditional(None,None) == True

    assert Conditional(loader=None).evaluate_conditional(None,None) == False

    assert Conditional(loader=None).evaluate_conditional(None,None) == False



# Generated at 2022-06-23 06:06:13.744542
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()

# Generated at 2022-06-23 06:06:15.657955
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional is not None


# Generated at 2022-06-23 06:06:18.414997
# Unit test for constructor of class Conditional
def test_Conditional():
    test_object = Conditional()
    assert test_object._when == list()

# Generated at 2022-06-23 06:06:30.430853
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    ''' test_Conditional_evaluate_conditional()
    This function tests the evaluate_conditional method of Conditional class.
    '''
    # test case 1:
    # run first conditional statement when all_vars are empty
    class Conditionalc1(Conditional):
        def __init__(self, all_vars=dict()):
            super(Conditionalc1, self).__init__()
            self.when = [
                "a == b"
            ]

    c1 = Conditionalc1()
    res = c1.evaluate_conditional(None, dict())

    assert res is False, 'the method evaluate_conditional of class Conditional should return False'

    # test case 2:
    # run first conditional statement when all_vars contains the variables

# Generated at 2022-06-23 06:06:31.964535
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c._when == []


# Generated at 2022-06-23 06:06:36.237183
# Unit test for constructor of class Conditional
def test_Conditional():

    from ansible.playbook.base import Base

    class MyTest(Conditional, Base):
        pass

    a = MyTest()
    # This should not raise any exception
    return a

# Generated at 2022-06-23 06:06:47.088298
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    # creating all the required objects
    data_loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=data_loader, variables=variable_manager,
                      shared_loader_obj=data_loader)

    # creating the Conditional object
    condition = Conditional(loader=data_loader)
    condition._loader = data_loader

    # populating the when field of the object
    condition.when.append('test1')
    condition.when.append('test2')

    # creating the data structures and
    # initializing the variable manager
   

# Generated at 2022-06-23 06:06:48.856515
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional is not None
    assert conditional._when == []
    assert conditional.when == []


# Generated at 2022-06-23 06:06:49.831491
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional(loader=None)
    assert conditional

# Generated at 2022-06-23 06:06:57.023432
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from jinja2 import Environment
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    env = Environment()
    env.loader = loader
    dummy = Conditional(loader=loader)

    name = "test"

# Generated at 2022-06-23 06:07:00.949117
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c.when is not None
    assert c._loader is None
    assert str(c) is not None
    assert repr(c) is not None


# Generated at 2022-06-23 06:07:12.541464
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('foo or not bar is defined') == [('bar', 'not', 'defined')]
    assert c.extract_defined_undefined('foo or not bar is defined or not baz is defined') == [('bar', 'not', 'defined'), ('baz', 'not', 'defined')]
    assert c.extract_defined_undefined('foo or bar is not defined or baz is defined') == [('bar', 'is', 'not defined'), ('baz', 'is', 'defined')]
    assert c.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined('not foo is undefined') == [('foo', 'is', 'undefined')]

# Generated at 2022-06-23 06:07:20.852903
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    class MyConditional(Conditional):
        pass

    obj = MyConditional()

    conditional = "string"
    assert obj.extract_defined_undefined(conditional) == []
    conditional = "string and hostvars['foo'] is defined"
    assert obj.extract_defined_undefined(conditional) == [('hostvars[\'foo\']', 'is', 'defined')]
    conditional = "hostvars['bar'] is not defined and foo is defined"
    assert obj.extract_defined_undefined(conditional) == [('hostvars[\'bar\']', 'is not', 'defined'), ('foo', 'is', 'defined')]
    conditional = 'string and hostvars["baz"] is not undefined'

# Generated at 2022-06-23 06:07:25.689340
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    pc = PlayContext()
    t = Templar(loader=None, variables={})

    display.verbosity = 3

    c = Conditional(loader=None)
    c.when = ['cond1', 'cond2']

    assert not c.evaluate_conditional(t, pc.get_vars())

# Generated at 2022-06-23 06:07:32.266002
# Unit test for constructor of class Conditional
def test_Conditional():
        # Testing to make sure that when an attribute has default as list,
        # the initialization with a non-list value will default to a list
        # with single item.
        c = Conditional()
        assert c._when == list

        # Testing to make sure that when an attribute has default as list,
        # the initialization with a list will keep the value as a list.
        c1 = Conditional()
        c1._when = ['True']
        assert c1._when == ['True']

# Generated at 2022-06-23 06:07:41.699462
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    """
    Tests that the regex to extract 'is defined' and 'is undefined'
    conditions works as expected
    """
    def test(s, expected):
        result = Conditional.extract_defined_undefined(None, s)
        assert result == expected, "Invalid result for regex applied to string \"%s\"" % (s,)

    test("", [])
    test("some_var is defined", [("some_var", "is", "defined")])
    test("another_var is not defined", [("another_var", "is not", "defined")])
    test("something is undefined", [("something", "is", "undefined")])
    test("another thing is not undefined", [("another thing", "is not", "undefined")])

# Generated at 2022-06-23 06:07:52.614044
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.base import Base
    class TestingConditional(Base, Conditional):
        pass
    import ansible.template.template as template
    import ansible.template.jinja2 as jinja2
    templar = template.Templar(loader=jinja2.AnsibleJ2TemplateLoader(None))
    obj = TestingConditional()
    obj.when = "localhost"
    all_vars = dict(ansible_ssh_host="localhost")
    assert obj.evaluate_conditional(templar, all_vars) is True
    obj.when = "not localhost"
    all_vars = dict(ansible_ssh_host="localhost")
    assert obj.evaluate_conditional(templar, all_vars) is False
    obj.when = "somevar is defined"

# Generated at 2022-06-23 06:08:01.861633
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Use with AnsibleModulesTestCase inside tests/unit/modules
    from ansible.inventory import Host
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    def vars_loader(self):
        return dict(a=True, b=False)

    variable_manager = VariableManager(loader=vars_loader)
    variable_manager.extra_vars = dict(c=True, d=False)

    templar = Templar(loader=variable_manager)

    host = Host('some_host')
    play = Play().load({}, variable_manager=variable_manager, loader=variable_manager)

# Generated at 2022-06-23 06:08:11.298163
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    ctx = PlayContext()
    ctx._variable_manager = VariableManager()
    ctx.hostvars = {}

    templar = Templar(loader=None, variables=ctx.hostvars)

    conditional = Conditional(loader=None)
    result = conditional.evaluate_conditional(templar, ctx.hostvars)
    assert result is True

    conditional = Conditional(loader=None)
    conditional.when = ""
    result = conditional.evaluate_conditional(templar, ctx.hostvars)
    assert result is True

    conditional = Conditional(loader=None)
    conditional.when = None

# Generated at 2022-06-23 06:08:22.690370
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import ansible.playbook.playbook

    m = ansible.playbook.playbook.Base(loader=None)

    # test unitialized conditional
    m._ds = []
    m.when = []

    res = m.evaluate_conditional(None, None)
    assert res is True

    # test conditional
    m._ds = []
    m.when = ['a', 'b']

    res = m.evaluate_conditional(None, None)
    assert res is True

    # test conditional
    m._ds = []
    m.when = ['a', 'b', None]

    res = m.evaluate_conditional(None, None)
    assert res is True

    # test conditional
    m._ds = []
    m.when = ['a', 'b', None, False]

    res = m.evaluate

# Generated at 2022-06-23 06:08:29.003022
# Unit test for constructor of class Conditional
def test_Conditional():
    class cond(object):
        _when = FieldAttribute(isa='list', default=list, extend=True, prepend=True)
        _loader = None

    a = cond()
    assert isinstance(a, Conditional)

    try:
        b = Conditional()
        assert False, 'should have raised error'
    except AnsibleError:
        pass

    try:
        b = Conditional(loader='loader')
    except AnsibleError:
        assert False, 'failed improperly'



# Generated at 2022-06-23 06:08:41.490217
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    hostvars = {'group_names': ['foo', 'bar'],
                'inventory_hostname': 'localhost',
                'inventory_hostname_short': 'localhost'}
    loader = DictDataLoader({'var1': 'val1',
                             'var2': 'val2',
                             'group_names': 'group_names',
                             'host_names': 'host_names'})
    t = Template(loader=loader, variables=hostvars)

    c = Conditional(loader=loader)

    assert c.extract_defined_undefined('') == []
    assert c.extract_defined_undefined(None) == []

    # single item, no logic, defined
    assert c.extract_defined_undefined('a is defined') == [('a', 'is', 'defined')]


# Generated at 2022-06-23 06:08:49.683958
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert c.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]
    assert c.extract_defined_undefined("a not is undefined") == [("a", "not is", "undefined")]
    assert c.extract_defined_undefined("a not is undefined or b is undefined or c is defined") == [("a", "not is", "undefined"), ("b", "is", "undefined"), ("c", "is", "defined")]

# Generated at 2022-06-23 06:08:59.495820
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class C(Conditional):
        _loader = None

    # Testing value of conditional variable
    variable = {
        'test': "Hello World",
        'foo': [],
        'test_1': {"key": "value"}
    }

    c = C()
    c._ds = 'test'
    c.when = [
        'test == "Hello World"',
        'test_1.key == "value"',
        '(test == "Hello World") and (test_1.key == "value")'
    ]

    assert c.evaluate_conditional(variable) == True


# Generated at 2022-06-23 06:09:00.424184
# Unit test for constructor of class Conditional
def test_Conditional():

    conditional = Conditional()

    assert isinstance(conditional, Conditional)

# Generated at 2022-06-23 06:09:09.499561
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible import constants as C
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import lookup_loader
    from ansible.template import Templar

    # Create test object and variables
    conditional = Conditional()

# Generated at 2022-06-23 06:09:18.910298
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class MockConditional(Conditional):
        when = []

    class MockTemplar:
        def __init__(self):
            self.environment = MockEnvironment()

        def is_template(self, data):
            return False

        def template(self, data, disable_lookups=False):
            return data

        def template_string(self, data, disable_lookups=False):
            return data

    class MockEnvironment:
        def getattr(self, undefined, data):
            raise UndefinedError('value of %s is undefined' % undefined)

        def parse(self, data, undefined, undefined1, undefined2):
            raise UndefinedError('value of %s is undefined' % data)

        def __contains__(self, key):
            return False

    class MockVariables:
        pass


# Generated at 2022-06-23 06:09:28.885212
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    for test_str in (
        'hostvars["x"] is defined and hostvars["y"] is not defined',
        'hostvars[inventory_hostname] is not defined',
        'hostvars[inventory_hostname] is defined',
        'hostvars[inventory_hostname] is undefined',
        'x is defined',
        'x is not defined',
        'x is undefined',
        'x is not undefined',
    ):
        result = Conditional.extract_defined_undefined(Conditional, test_str)
        expected_result = [tuple(e.split(' ')) for e in test_str.split(' and ')]
        assert result == expected_result


# Generated at 2022-06-23 06:09:42.226956
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    # Create an instance of Conditional
    c = Conditional()

    # Create a variable for the test
    conditional = """
    (
    (not variable1 is defined)
    or
    (variable2 not is defined)
    or
    (not variable3 is undefined)
    or
    (variable4 not is undefined)
    )
    and
    (
    (hostvars['host1'] is undefined)
    or
    (hostvars['host2'] is not defined)
    or
    (hostvars['host3'] not is defined)
    or
    (hostvars['host4'] not is undefined)
    )
    """

    # perform the test
    results = c.extract_defined_undefined(conditional)

    # perform manual tests
    assert ('variable1', 'not is', 'defined')

# Generated at 2022-06-23 06:09:52.322229
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:10:02.218327
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    run_me = Conditional()

# Generated at 2022-06-23 06:10:13.716603
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    import ansible.template.template as template

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play().load(dict(
        name='test',
        hosts='all',
        gather_facts='no',
        tasks=[]
    ), variable_manager=variable_manager, loader=loader)

    the_conditional = Conditional(loader)
    the_conditional._ds = play

# Generated at 2022-06-23 06:10:24.925522
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # I would have preferred to do this as a unit test, but I couldn't figure out a way to
    # create a self._loader with a valid tasks/main.yml in it that I could then load
    # with the templar below to actually test things

    # I'm also using this as a way of figuring out how variables get merged in. For example,
    # the first variable is an actual variable, but the second one is a variable that doesn't
    # exist, so it can't be templated without an error. The third variable is an extra variable
    # when rendering the template, which does get merged in. I need this info to make my unit
    # test for AnsibleUndefinedVariable
    c = Conditional()

# Generated at 2022-06-23 06:10:37.764378
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    The test case for method evaluate_conditional
    of class Conditional
    '''

    class MyConditional(Conditional):
        '''
        A class for testing
        '''

        def __init__(self, loader, when=None):
            self._loader = loader
            self._when = when

        def _check_conditional(self, conditional, templar, all_vars):
            '''
            A method for testing
            '''
            raise Exception("Testing")

    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader=loader)

# Generated at 2022-06-23 06:10:49.412380
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    d = 'foo is defined'
    u = 'bar is undefined'
    n = 'foo is not defined'
    a = 'foo and bar are defined'
    o = 'foo or bar is defined'
    q = 'foo is undefined and bar is undefined'
    r = 'foo is not defined and bar is not defined'
    e = 'foo is not defined and bar is defined'
    f = 'foo is defined and bar is not defined'
    g = 'foo is undefined or bar is undefined'
    h = 'foo is not defined or bar is not defined'
    i = 'foo is not defined or bar is defined'
    j = 'foo is defined or bar is not defined'
    k = 'foo is defined and bar is not defined or baz is not undefined'

# Generated at 2022-06-23 06:10:50.885641
# Unit test for constructor of class Conditional
def test_Conditional():
    cond = Conditional()
    assert isinstance(cond, Conditional)
    cond.evaluate_conditional(None, None)



# Generated at 2022-06-23 06:10:58.152684
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    all_vars = {'ansible_host': 'localhost', 'foo': 'bar'}
    templar = Templar(loader=DictDataLoader({}))

    obj = Conditional()
    obj.when = [False, True, None, True, 'foo', 'foo == bar']
    assert obj.evaluate_conditional(templar, all_vars) is True

    obj = Conditional()
    obj.when = [False, True, None, True, 'foo', 'foo == "bar"']
    assert obj.evaluate_conditional(templar, all_vars) is True

    obj = Conditional()
    obj.when = [False, True, None, True, 'foo', 'foo == "bah"']
    assert obj.evaluate_conditional(templar, all_vars) is False

   

# Generated at 2022-06-23 06:11:05.880729
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    templar = Templar(loader=None, variables=None)
    c = Conditional(loader=templar)
    assert c

# Generated at 2022-06-23 06:11:11.521221
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    conditional1 = 'hostname is defined'
    conditional2 = 'hostname is defined and not hostname is undefined'
    conditional3 = 'hostname is defined or hostname is undefined'
    conditional4 = 'hostname is defined and port is undefined'
    conditional5 = 'hostname is defined and port is defined'
    conditional6 = 'foreman_certname is defined and foreman_url is defined'
    conditional7 = 'foreman_certname is defined and foreman_url is not defined'
    conditional8 = 'foreman_certname is not defined or foreman_url is defined'
    conditional9 = 'foreman_certname is defined and foreman_url is defined or foreman_url is defined and foreman_url is not defined'

# Generated at 2022-06-23 06:11:18.555575
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("") == []
    assert cond.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert cond.extract_defined_undefined("foo not is defined") == [("foo", "not is", "defined")]
    assert cond.extract_defined_undefined("foo not is defined and bar not is defined") == [("foo", "not is", "defined"), ("bar", "not is", "defined")]
    assert cond.extract_defined_undefined("foo not is defined and bar not is defined and xyz is undefined") == [("foo", "not is", "defined"), ("bar", "not is", "defined"), ("xyz", "is", "undefined")]
    assert cond.extract_defined

# Generated at 2022-06-23 06:11:28.800914
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.conditional import Conditional

    cond = Conditional()

    # Test 1
    result = cond.extract_defined_undefined('hostvars[inventory_hostname] is not defined')
    assert(result == [('hostvars[inventory_hostname]', 'is not', 'defined')])

    # Test 2
    result = cond.extract_defined_undefined('hostvars[inventory_hostname] is defined')
    assert(result == [('hostvars[inventory_hostname]', 'is', 'defined')])

    # Test 3
    result = cond.extract_defined_undefined('hostvars[inventory_hostname] not is defined')
    assert(result == [('hostvars[inventory_hostname]', 'not is', 'defined')])

    # Test 4
   

# Generated at 2022-06-23 06:11:39.176909
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # arrange
    conditional_list = {
        "foo": [("foo", "is not", "undefined")],
        "foo is not defined": [("foo", "is not", "defined")],
        "foo == 'xyz' and bar is defined and baz is not undefined": [("bar", "is", "defined"), ("baz", "is not", "undefined")],
        "foo == 'xyz' and bar == 'abc'": [],
        "foo and bar is not undefined": [("bar", "is not", "undefined")],
        "foo == 'xyz' and var in hostvars[inventory_hostname] and bar is not none": [("var", "is", "defined"), ("bar", "is not", "undefined")],
    }

    # act

# Generated at 2022-06-23 06:11:40.035791
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional(loader=None)

# Generated at 2022-06-23 06:11:43.464200
# Unit test for constructor of class Conditional
def test_Conditional():
    # Create a Conditional with loader (as it is abstract)
    conditional_inst = Conditional(loader=object)
    assert conditional_inst
    assert 'loader' in conditional_inst.__dict__

    # Create a Conditional with a loader
    conditional_inst = Conditional()
    assert conditional_inst
    assert 'loader' in conditional_inst.__dict__


# Generated at 2022-06-23 06:11:51.941249
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def ex_du(conditional):
        c = Conditional()
        return c.extract_defined_undefined(conditional)

    # Test 1
    test_str = "hostvars['foo'] is defined and hostvars['bar'] is not defined"
    assert ex_du(test_str) == [('hostvars[\'foo\']', 'is', 'defined'), ('hostvars[\'bar\']', 'not is', 'defined')]

    # Test 2
    test_str = "my_var is defined"
    assert ex_du(test_str) == [('my_var', 'is', 'defined')]

    # Test 3
    test_str = "my_var is not defined"
    assert ex_du(test_str) == [('my_var', 'is not', 'defined')]

# Generated at 2022-06-23 06:12:02.590702
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    #
    # Function to get variable values(vars) from variable names(var_name)
    #
    def get_vars(var_name, templar, all_vars):
        try:
            vars = templar.template(var_name, disable_lookups=not templar.is_template(var_name))
        except:
            vars = None
        return vars

    #
    # Function to test evaluate_conditional for given condition and variable values(vars)
    #
    def test_evaluate_conditional(templar, all_vars, conditional, expected_result):
        result = False

# Generated at 2022-06-23 06:12:08.388422
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.mod_args import ModuleArgsParser

    module_parser = ModuleArgsParser(None, None)
    loader = DictDataLoader({})
    test_object = Conditional(loader)
    test_object._ds = {}
    if test_object.when is None:
        fail("test_Conditional failed")


# Generated at 2022-06-23 06:12:13.284488
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest
    from ansible.vars.manager import VariableManager

    class TestPlaybookObject(Conditional):

        def __init__(self):
            pass

    def set_loader(self, loader):
        pass

    TestPlaybookObject._loader = property(None, set_loader)

    class TestCase(unittest.TestCase):
        def test_nested_conditional(self):
            '''
            test nested conditionals
            '''
            play_context = PlayContext()


# Generated at 2022-06-23 06:12:14.729238
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert isinstance(conditional, Conditional)


# Generated at 2022-06-23 06:12:20.522341
# Unit test for constructor of class Conditional
def test_Conditional():
    """
    This is a unit test for class Conditional
    This test will also serve as a unit test for class FieldAttribute, Base as well
    """
    class TestAnsibleConditional(Conditional):
        def __init__(self, testattr):
            self.testattr = testattr
            super(TestAnsibleConditional, self).__init__()

    test_obj = TestAnsibleConditional(testattr='initstring')
    assert test_obj.testattr == 'initstring'
    assert test_obj.when == []
    assert test_obj.evaluate_conditional(None, None) == True
    print("test_Conditional completed successfully")


# Generated at 2022-06-23 06:12:24.852253
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert conditional.extract_defined_undefined("a is defined and b is undefined") == [("a", "is", "defined"), ("b", "is", "undefined")]
    assert conditional.extract_defined_undefined("a is defined and b is undefined and not c is undefined") == [("a", "is", "defined"), ("b", "is", "undefined"), ("c", "not is", "undefined")]
    assert conditional.extract_defined_undefined("a is defined and b is defined") == [("a", "is", "defined"), ("b", "is", "defined")]

# Generated at 2022-06-23 06:12:33.698384
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_source =  dict(
            name = "Ansible Play 0",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='ping', args='')),
                dict(action=dict(module='debug', args=dict(msg='{{foo}}')))
            ]
        )


# Generated at 2022-06-23 06:12:35.146763
# Unit test for constructor of class Conditional
def test_Conditional():
  conditional = Conditional()
  assert conditional is not None


# Generated at 2022-06-23 06:12:45.120288
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext

    cond = Conditional(loader=None)
    assert cond.when == list()
    assert cond._when == list()

    cond._when = 'foo'
    assert cond._when == ['foo']

    cond.when = 'foo'
    assert cond.when == ['foo']

    cond.when = ['foo', 'bar']
    assert cond.when == ['foo', 'bar']

    # when = None
    cond.when = None
    cond._loader = True  # needed by evaluate_conditional
    assert cond.evaluate_conditional(templar=None, all_vars=dict())

    # Test _validate_when
    cond = Conditional(loader=None)
    cond._validate_when('', 'when', 'huh')

# Generated at 2022-06-23 06:12:57.430927
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    class FakeVarsModule:

        class FakeVars(object):

            def __init__(self, data):
                self.data = data

            def __getattr__(self, name):
                return self.data.get(name)

        def __init__(self, data):
            self.vars = self.FakeVars(data)

    context = PlayContext()
    context.network_os = 'ios'
    templar = Templar(loader=None, variables=dict(), shared_loader_obj=None)

# Generated at 2022-06-23 06:13:07.343064
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Empty conditionals
    assert Conditional().extract_defined_undefined(None) == []
    assert Conditional().extract_defined_undefined('') == []
    # Multiple conditionals
    assert Conditional().extract_defined_undefined('foo is defined or bar is undefined') \
        == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]
    # Switching from defined to undefined
    assert Conditional().extract_defined_undefined('foo is defined and bar is not undefined') \
        == [('foo', 'is', 'defined'), ('bar', 'is not', 'undefined')]
    # Switching from undefined to defined

# Generated at 2022-06-23 06:13:13.988681
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.base import Base
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
