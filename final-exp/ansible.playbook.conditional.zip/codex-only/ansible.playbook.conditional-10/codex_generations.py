

# Generated at 2022-06-23 06:03:25.822095
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-23 06:03:35.917931
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:03:46.388760
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    C.HOST_VARS = {
        '127.0.0.1': { 'foo': 'lemur' },
        '192.168.2.2': { 'foo': 'tarsier' },
        '192.168.5.5': { 'foo': 'rhesus' },
    }
    C.GROUP_VARS = {
        'primate': { 'foo': 'monkey' },
        'mammal': { 'foo': 'platypus' },
    }
    C.INVENTORY_HOSTVARS = { 'foo': 'prosimian' }

# Generated at 2022-06-23 06:03:56.022696
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """
    Unit test for method evaluate_conditional of class Conditional
    """
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    templar = Templar(loader=loader)
    all_vars = VariableManager()
    setattr(all_vars, 'hostvars', dict())
    context = PlayContext()

    setattr(context, 'vars', all_vars)
    templar._available_variables = all_vars

    # case when condition is undefined
    res = Conditional().evaluate_conditional(templar, all_vars)
    assert res

    # case when condition is empty


# Generated at 2022-06-23 06:03:59.203457
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    play = Conditional()
    templar = Templar(play._loader)
    assert play.evaluate_conditional(templar, dict(a=2))


# Generated at 2022-06-23 06:04:09.224750
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    import ansible.constants as C

    class TestModule(object):
        def __init__(self):
            self.params = {
                'a': 'foo',
                'b': 'bar',
                'c': 'baz',
                'd': 'qux',
                'e': 'quux',
                'f': 'quuz'
            }
            self.play_context = {
                'play_uuid': 'uuid',
                'play': 'play'
            }

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=[])
    variable_manager = Variable

# Generated at 2022-06-23 06:04:19.397365
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class SimpleObj(object):
        def __init__(self, ds):
            self._ds = ds
    test_obj = SimpleObj('test_ds')
    cond = "foo is bar"
    result = Conditional(loader=None)._check_conditional(cond, templar=None, all_vars=None)
    assert result is False, "Result should be False because there is no templar object available"

    class Templar(object):
        def is_template(self, data):
            if data == cond:
                return True
            else:
                return False
        def template(self, template, disable_lookups=True):
            return template

    templar = Templar()

# Generated at 2022-06-23 06:04:26.161825
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook import Playbook
    pb = Playbook()
    c = Conditional()
    c._loader = pb.loader
    assert c.extract_defined_undefined("foo") == []
    assert c.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined(" not foo is defined") == []
    assert c.extract_defined_undefined("'foo' is defined") == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined("'foo' is not defined") == [('foo', 'is not', 'defined')]

# Generated at 2022-06-23 06:04:39.398433
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible import template

    def _ds_noop():
        pass

    def _loader_noop():
        pass

    ds = _ds_noop
    ds.name = "foo"
    ds.path = "bar"

    templar = template.AnsibleTemplar(loader=_loader_noop)
    test_conditional = Conditional(loader=_loader_noop)

    try:
        test_conditional.evaluate_conditional(templar=templar, all_vars={})
    except Exception as err:
        assert(err.__class__.__name__ == 'AnsibleError')

    conditional = test_conditional
    conditional._ds = ds


# Generated at 2022-06-23 06:04:48.324780
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    class ConditionalObject(Conditional, AnsibleBaseYAMLObject):
        pass
    conditional_obj = ConditionalObject()

    play_context = PlayContext()
    templar = Templar(loader=None, variables={}, play_context=play_context)

    test_hostvars = {'hostname1': {'foo': 'bar'}, 'hostname2': {'foo': 'bar'}}

    # test empty string
    conditional_obj._when = ['']
    def_undef = conditional_obj.extract_defined_undefined(conditional_obj.when[0])
    assert(not def_undef)



# Generated at 2022-06-23 06:04:49.043438
# Unit test for constructor of class Conditional
def test_Conditional():
    assert issubclass(Conditional, object)

# Generated at 2022-06-23 06:04:59.523044
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from units.mock.loader import DictDataLoader

    all_vars = HostVars(loader=DictDataLoader())
    templar = Templar(loader=DictDataLoader(), variables=all_vars)
    task_include = TaskInclude()

    context = PlayContext()
    context._vars = all_vars
    task_include._play_context = context

    assert task_include.evaluate_conditional(templar, all_vars)

    task_include._task.when = "foo"

# Generated at 2022-06-23 06:05:06.535923
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    class TestConditional(Conditional):
        def __init__(self):
            pass

    tc = TestConditional()
    # generate random named vars
    var_name = ''.join([chr(i) for i in range(97, 123)])
    var_name = var_name.replace('e', '').replace('i', '') + 'e'

    # test with variable, defined or not defined
    for logic in ['is', 'is not']:
        for state in ['defined', 'undefined']:
            # test with variable
            cond = '%s %s %s' % (var_name, logic, state)
            res = tc.extract_defined_undefined(cond)
            assert res[0][0] == var_name
            assert res[0][1] == logic

# Generated at 2022-06-23 06:05:16.946532
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    my_conditional = Conditional()
    templar = Templar(loader=None, shared_loader_obj=None, variables=dict(foo='bar', baz='pong'))
    # Test positive cases
    assert my_conditional._check_conditional('foo == "bar"', templar, dict())
    assert my_conditional._check_conditional('foo == "bar" and baz == "pong"', templar, dict())
    assert my_conditional._check_conditional('foo != "nope"', templar, dict())
    assert my_conditional._check_conditional('foo != "nope" and baz != "nope"', templar, dict())

# Generated at 2022-06-23 06:05:29.220158
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class DataHolder(Conditional):
        pass

    d = DataHolder()
    setattr(d, '_ds', None)
    setattr(d, '_loader', None)
    d.when = ["{{ (ansible_os_family == 'RedHat' and ansible_distribution_major_version <= '6') or (ansible_os_family == 'Debian' and ansible_distribution_major_version <= '7') }}", '{{ ansible_os_family == "Debian" and ansible_distribution_major_version == "8" }}']
    # test_var = '{{ "Hello" }}'
    test_var = 'Hello'
    test_vars = {"ansible_os_family": "Debian", "ansible_distribution_major_version": "8"}

# Generated at 2022-06-23 06:05:37.780375
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

  ##############
  #### Setup ####
  ##############

  class test_class(Conditional):
      def __init__(self):
          super(test_class, self).__init__()

  test_class = test_class()
  

  ###############
  #### Tests ####
  ###############

  ## Test case extraction of "hostvars[inventory_hostname] is defined"
  conditional = "hostvars[inventory_hostname] is defined"
  result = test_class.extract_defined_undefined(conditional)
  assert len(result) == 1
  assert result[0][0] == "hostvars[inventory_hostname]"
  assert result[0][1] == "is"
  assert result[0][2] == "defined"

  ## Test case extraction

# Generated at 2022-06-23 06:05:39.047340
# Unit test for constructor of class Conditional
def test_Conditional():

    print(Conditional().evaluate_conditional())

# Generated at 2022-06-23 06:05:48.251014
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()


# Generated at 2022-06-23 06:05:54.722949
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar


# Generated at 2022-06-23 06:06:07.082298
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()

    # Instantiate needed objects
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=["/dev/null"])
    variable_manager.set_inventory(inventory)

    display.verbosity = 3

    # Create object of class Conditional
    conditional = Conditional(loader=loader)

    # Assign when attribute a valid value
    conditional.when = 'ansible_username is test'

    # Assert when attribute has assigned value 'ansible_username is test'
    assert conditional.when[0] == "ansible_username is test"

    # Evaluate conditional
    res = conditional.evaluate_cond

# Generated at 2022-06-23 06:06:14.174229
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    host_vars = dict(ansible_ssh_host='localhost')
    all_vars = {'hostvars': {'localhost': host_vars}}
    t = Task()
    t._play_context = play_context
    c = Conditional()
    c._loader = None

    res = c.evaluate_conditional(t._templar, all_vars)
    assert res is True

# Generated at 2022-06-23 06:06:25.531757
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import sys
    import os
    import pytest
    # This hack is necessary so that we can import modules from the
    # 'test' directory
    sys.path.insert(0, os.path.abspath("test"))

    from ansible_module_meta import AnsibleModuleMock
    from ansible.template import Templar

    class Play:
        vars = dict()

    class Playbook:
        def __init__(self):
            self.set_variable_manager()

        def set_variable_manager(self):
            self.variable_manager = VariableManager()

        def reset_variable_manager(self):
            self.set_variable_manager()

    class VariableManager:
        def __init__(self):
            self.vars = dict()


# Generated at 2022-06-23 06:06:36.303069
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    y = Conditional()

    defs = y.extract_defined_undefined("one and (two or three or four) and five")
    assert len(defs) == 0

    defs = y.extract_defined_undefined("hostvars['one'] is defined or two is undefined or hostvars[three] is not defined")
    assert len(defs) == 3
    assert defs[0] == ('hostvars[\'one\']', 'is', 'defined')
    assert defs[1] == ('two', 'is', 'undefined')
    assert defs[2] == ('hostvars[three]', 'is not', 'defined')

    defs = y.extract_defined_undefined("one")
    assert len(defs) == 1

# Generated at 2022-06-23 06:06:47.180828
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    import os
    import sys
    import tempfile
    import yaml
    from ansible.galaxy.api import GalaxyAPI
    import ansible.constants as C
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VarManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import plugin_loader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils._text import to_bytes
    from ansible.playbook.play_context import PlayContext

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display

# Generated at 2022-06-23 06:06:52.608791
# Unit test for constructor of class Conditional
def test_Conditional():

    from ansible.playbook.task import Task

    mytask = Task()
    mytask._ds = dict()
    mytask._attributes = dict()

    mytask.when = "{{ somevar }}"
    assert mytask.when == ["{{ somevar }}"]
    mytask.when = "{{ somevar }} is defined"
    assert mytask.when == ["{{ somevar }} is defined"]
    mytask.when = [ "{{ somevar }}", "{{ someothervar }} is defined"]
    assert mytask.when == ["{{ somevar }}", "{{ someothervar }} is defined"]

# Generated at 2022-06-23 06:06:53.756378
# Unit test for constructor of class Conditional
def test_Conditional():
    Conditional()

# Generated at 2022-06-23 06:07:02.904724
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """
      Test case for method evaluate_conditional of class Conditional
      This test case checks the following scenarios:
        - simple when condition
        - when condition with a nested condition
        - when condition with a OR operation
        - when condition with a AND operation
        - when condition with a defined_undefined operation
      """

    # initialize the Conditional class
    cond = Conditional()

    # Test case 1: simple when condition
    task_data = { "when": "failed == 0" }
    templar = {}
    all_vars = { 'ansible_failed': 0 }
    cond.load_data(task_data, templar)
    assert cond.evaluate_conditional(templar, all_vars) == True


    # Test case 2: when condition with a nested condition

# Generated at 2022-06-23 06:07:14.225537
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_host_variable('tester', dict(
        foo='bar'
    ))
    templar = Templar(loader=loader, variables=variable_manager)

    conditional = Conditional(loader=loader)

# Generated at 2022-06-23 06:07:21.572437
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = 'hostvars[inventory_hostname] == "localhost"'
    all_vars = {'hostvars': {'localhost': 'localhost'}}
    assert Conditional().evaluate_conditional(conditional, all_vars)

    conditional = 'hostvars[inventory_hostname] == "127.0.0.1"'
    all_vars = {'hostvars': {'localhost': 'localhost'}}
    assert not Conditional().evaluate_conditional(conditional, all_vars)

    conditional = 'hostvars[inventory_hostname] is defined'
    all_vars = {'hostvars': {'localhost': 'localhost'}}
    assert Conditional().evaluate_conditional(conditional, all_vars)

    conditional = 'hostvars[inventory_hostname] is not defined'
   

# Generated at 2022-06-23 06:07:33.276978
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=None, connection=None, play_context=play_context)

    # use the conditional class instantiated by itself
    mytest = Conditional(loader=loader)
    mytest.when = [False, "myvar == 'foo'", "myvar2 == 'bar'"]

    # set the variable for the test
    variable_manager

# Generated at 2022-06-23 06:07:42.472856
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class MyConditional(Conditional):
        def __init__(self, when=None):
            self._when = when

    def _test_evaluate_conditional(s, when, vars_in, expected):
        if s != expected:
            raise AssertionError("expected %s got %s" % (expected, s))

    mycond = MyConditional()
    mycond._when = when
    mycond.evaluate_conditional(MyTemplar(), vars_in)

    mycond = MyConditional()
    mycond._when = when
    if expected:
        mycond.evaluate_conditional(MyTemplar(), vars_in)

# Generated at 2022-06-23 06:07:43.295433
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c

# Generated at 2022-06-23 06:07:53.358975
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

    assert c.extract_defined_undefined("None") == []
    assert c.extract_defined_undefined("None is defined") == []
    assert c.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert c.extract_defined_undefined("defined(foo)") == []

# Generated at 2022-06-23 06:08:00.788407
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional(loader=None)
    assert conditional.evaluate_conditional(None, None) == True
    conditional.when = [
        "1",
        0,
        None,
        "",
        [],
        [1, 2],
        False,
        True,
        ['foo', 'bar'],
        "{{ 1 }}",
        "{{ 0 }}",
    ]
    assert conditional.evaluate_conditional(None, None) == False


# Generated at 2022-06-23 06:08:08.411934
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:08:17.254820
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    res = Conditional().extract_defined_undefined('True and not hostvars[inventory_hostname + "_" + "a"] is undefined and hostvars[inventory_hostname] is not undefined and true')
    assert len(res) == 2
    assert res[0] == ('hostvars[inventory_hostname + "_" + "a"]', 'is', 'undefined')
    assert res[1] == ('hostvars[inventory_hostname]', 'is not', 'undefined')


# Generated at 2022-06-23 06:08:23.709128
# Unit test for constructor of class Conditional
def test_Conditional():
    # Test without a loader
    try:
        Conditional()
    except AnsibleError:
        pass
    else:
        raiseAssertionError("Conditional() without loader should raise AnsibleError.")

    # Test with a loader
    Conditional(loader=None)
    Conditional(loader=False)
    Conditional(loader=True)
    Conditional(loader='')
    Conditional(loader='string')



# Generated at 2022-06-23 06:08:24.544243
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional._when == []

# Generated at 2022-06-23 06:08:34.845498
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    test_cases = [
        ("a is defined and b is defined", [('a', 'is', 'defined'), ('b', 'is', 'defined')]),
        ("a is defined", [('a', 'is', 'defined')]),
        ("a is not defined", [('a', 'is not', 'defined')]),
        ("a is undefined", [('a', 'is', 'undefined')]),
    ]
    for test_case, expected_result in test_cases:
        actual_result = Conditional().extract_defined_undefined(test_case)
        assert actual_result == expected_result, "test_case: %s" % test_case


# Generated at 2022-06-23 06:08:45.281054
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

# Generated at 2022-06-23 06:08:47.609252
# Unit test for constructor of class Conditional
def test_Conditional():
    module = Conditional()
    assert hasattr(module, 'when')

# Generated at 2022-06-23 06:08:51.900001
# Unit test for constructor of class Conditional
def test_Conditional():
    # Check that class Conditional raises an error when initialized without a loader
    try:
        Conditional()
    except AnsibleError:
        pass
    # Check that correct initialization without parameters
    try:
        Conditional(loader=True)
    except AnsibleError:
        assert False

# Generated at 2022-06-23 06:08:58.494062
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    result = cond.extract_defined_undefined(
        "test1 is defined and test2 is undefined and test3.test4 is not defined and test5.test6.test7 is undefined"
    )
    assert result == [
        ('test1', 'is', 'defined'),
        ('test2', 'is', 'undefined'),
        ('test3.test4', 'is not', 'defined'),
        ('test5.test6.test7', 'is', 'undefined')
    ]



# Generated at 2022-06-23 06:09:08.380403
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Test a conditional that fails
    conditional = ['a']
    templar = "template"
    all_vars = "variables"
    test_conditional = Conditional()
    result = test_conditional.evaluate_conditional(templar, all_vars)
    assert result is False

    # Test a conditional that succeeds
    conditional = ['b']
    test_conditional = Conditional()
    result = test_conditional.evaluate_conditional(templar, all_vars)
    assert result is True

    # Test a conditional that succeeds but with a templar error
    class Templar():
        def template(self, conditional, disable_lookups):
            raise AnsibleError("Template error")
    templar = Templar()
    conditional = ['b']
    all_vars = "variables"
   

# Generated at 2022-06-23 06:09:15.013146
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    obj = Conditional()

    # in the following tests, 'foo' is set to true, 'bar' and 'baz' are undefined
    variables = {'foo': True, 'bar': None}
    templar = DummyTemplar(variables)

    # test 1: True
    setattr(obj, 'when', ['foo'])
    assert obj.evaluate_conditional(templar, variables)

    # test 2: False
    setattr(obj, 'when', ['bar'])
    assert not obj.evaluate_conditional(templar, variables)

    # test 3: True
    setattr(obj, 'when', ['bar is not defined'])
    assert obj.evaluate_conditional(templar, variables)

    # test 4: False

# Generated at 2022-06-23 06:09:26.951612
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    context = PlayContext()
    context._vars = dict()
    templar = Templar(VariableManager(), loader=None, shared_loader_obj=None, variables=context._vars)

    conditional = Conditional(loader=None)

    # Test evaluation of True
    conditional.when = True
    assert conditional.evaluate_conditional(templar, context._vars) == True

    # Test evaluation of False
    conditional.when = False
    assert conditional.evaluate_conditional(templar, context._vars) == False

    # Test evaluation of True with string
    conditional.when = "True"

# Generated at 2022-06-23 06:09:34.369646
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    c = Conditional()

    assert c.extract_defined_undefined(None) == []
    assert c.extract_defined_undefined('') == []
    assert c.extract_defined_undefined('init_sone_string') == []

    assert c.extract_defined_undefined('hostvars["hostname"] is defined') == [('hostvars["hostname"]', 'is', 'defined')]
    assert c.extract_defined_undefined('hostvars["hostname"] is not defined') == [('hostvars["hostname"]', 'is not', 'defined')]

# Generated at 2022-06-23 06:09:40.108339
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    b = Conditional(loader=DataLoader())
    assert isinstance(b, Conditional)
    assert isinstance(b, Play)
    assert b._loader is not None
    assert b._when == list()


# Generated at 2022-06-23 06:09:43.617232
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c._when == []
    c = Conditional(loader = 'loader')
    assert c._when == []


# Generated at 2022-06-23 06:09:52.856512
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    conditional_string = "hostvars['foo'].bar is defined and hostvars['bar'].foo is undefined"
    assert conditional.extract_defined_undefined(conditional_string) == \
        [("hostvars['foo'].bar", "is", "defined"), ("hostvars['bar'].foo", "is", "undefined")]

    conditional_string = 'foo is defined and bar is defined'
    assert conditional.extract_defined_undefined(conditional_string) == \
        [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

    conditional_string = 'foo is defined and bar is not defined'

# Generated at 2022-06-23 06:09:59.765366
# Unit test for constructor of class Conditional
def test_Conditional():
    # Test a scenario when 'when' attribute is passed as a list
    c = Conditional()
    c.when = ['abc', 'def']
    assert type(c.when) is list, c.when

    # Test a scenario when 'when' attribute is passed as a single value
    c = Conditional()
    c.when = 'abc'
    assert type(c.when) is list, c.when
    assert c.when == ['abc']


# Generated at 2022-06-23 06:10:01.217006
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional is not None

# Generated at 2022-06-23 06:10:09.599528
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    extendable = Conditional(loader=loader)
    assert extendable._loader == loader
    assert extendable._when == list()
    # _validate_when method should not be called in order for _when to be set
    setattr(extendable, '_when', [])
    assert extendable._when == list()

# Generated at 2022-06-23 06:10:17.044429
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.template import Templar

    play = Play().load({'name': 'test_play', 'hosts': 'all'}, variable_manager={}, loader=None)
    templar = Templar(loader=None, variables={})
    block = Block.load(dict(when=['test_conditional']), play=play, task_include=None, role=None, use_handlers=False,
                       loader=None, variable_manager=play.get_variable_manager(), block=None)
    context = PlayContext(play=play)

# Generated at 2022-06-23 06:10:28.012764
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    play_context = PlayContext()
    variable_manager = VariableManager()

    class MockTask:
        def __init__(self, when):
            self.when = when

    task = MockTask("var1 == 1")
    templar = Templar(loader=None, variables=variable_manager)
    result = task.evaluate_conditional(templar, [])
    assert result is False

    task = MockTask("var1 == 1")
    variable_manager.extra_vars = dict(var1=1)
    result = task.evaluate_conditional(templar, [])
    assert result is True

    task = MockTask("not var1 == 1")
   

# Generated at 2022-06-23 06:10:36.032523
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    val = 'not foo.bar|default("") is defined and (not foo.bar|default("")'
    val += ' is defined or "")'
    assert conditional.extract_defined_undefined(val) == \
           [('foo.bar|default("")', 'not', 'defined'),
            ('foo.bar|default("")', 'not', 'defined')]


# Generated at 2022-06-23 06:10:40.204021
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional._when == []
    conditional = Conditional(2)
    assert conditional._when == []
    del conditional._loader
    try:
        conditional = Conditional()
    except AnsibleError:
        assert 1 == 1
    del conditional

# Generated at 2022-06-23 06:10:49.596325
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # this is a mock for the HostVariable class that is used for setting
    # host variables on a host
    class HostVariable:
        pass

    # this is a mock for the Host class that is used for setting
    # host variables on a host
    class Host:
        pass

    # this is a mock for the PlayContext class that is used for
    # setting variables in the context of a play
    class Play:
        pass

    # this is a mock for the Task class that is used for setting
    # variables in the context of a play
    class Task:
        pass

    # this is a mock for

# Generated at 2022-06-23 06:10:57.616364
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Mock the templar class
    class TestTemplar:
        def __init__(self):
            self.environment = None

        def template(self, conditional):
            return conditioned

        def is_template(self, conditional):
            return False

    test_templar = TestTemplar()

    test_Conditional = Conditional(loader=None)

    # Test case 1: conditional is None
    test_conditional = None
    test_all_vars = None
    assert test_Conditional.evaluate_conditional(test_templar, test_all_vars) is True

    # Test case 2: conditional has no template
    test_conditional = 'loopback01 is not in the space loopback'
    test_all_vars = None

# Generated at 2022-06-23 06:11:10.386352
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    host = dict(name='some-host')
    variable_manager = VariableManager()
    variable_manager.set_host_variable(host=host, varname='some_var', value=True)
    variable_manager.set_host_variable(host=host, varname='some_var_str', value='some-str')
    variable_manager.set_host_variable(host=host, varname='none_var', value=None)
    variable_manager.set_host_variable(host=host, varname='nested_var', value=dict(nested=True))

    templar = Templar(loader=None, variable_manager=variable_manager, host=host)

    cond = Conditional()


# Generated at 2022-06-23 06:11:12.131053
# Unit test for constructor of class Conditional
def test_Conditional():
    loader = None
    conditional = Conditional(loader)
    assert conditional.when == []

# Generated at 2022-06-23 06:11:14.528104
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext

    c = Conditional()
    assert c

    c = Conditional(play_context=PlayContext())
    assert c

# Generated at 2022-06-23 06:11:18.968019
# Unit test for constructor of class Conditional
def test_Conditional():
    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_files_dir = os.path.normpath(os.path.join(test_dir, '..', '..', 'test_files', 'conditional'))
    loader = DataLoader()
    loader.set_basedir(test_files_dir)
    condt = Conditional(loader)
    assert isinstance(condt, Base)
    assert condt._when == list

# Generated at 2022-06-23 06:11:21.044505
# Unit test for constructor of class Conditional
def test_Conditional():
    '''
    Unit test for Conditional class
    '''
    # instantiate Conditional
    Conditional()

# Generated at 2022-06-23 06:11:31.656092
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class Object:
        def __init__(self):
            self.name = None
            self._ds = None
            self._when = []
            self._loader = None

    obj = Object()

    # test various conditional formats
    assert Conditional(None).evaluate_conditional(None, dict(a=1, b=2))
    obj._when = ["a == 1"]
    assert Conditional(None).evaluate_conditional(None, dict(a=1, b=2))
    obj._when = ["a == 1 and b == 2"]
    assert Conditional(None).evaluate_conditional(None, dict(a=1, b=2))
    obj._when = ["a == 1 or b == 2"]
    assert Conditional(None).evaluate_conditional(None, dict(a=1, b=2))
    obj._

# Generated at 2022-06-23 06:11:39.963493
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class MockConditional(Conditional):
        pass

    mock_conditional = MockConditional()
    test_conditional = "".join(["host in group['foo']",
                                " and hostvars[host]['bar'] is defined",
                                " and hostvars[host]['baz'] is not defined"])
    expected = [('host in group[\'foo\']',),
                ('hostvars[host][\'bar\']', 'is', 'defined'),
                ('hostvars[host][\'baz\']', 'is not', 'defined')]

    result = mock_conditional.extract_defined_undefined(test_conditional)

    assert result == expected


# Generated at 2022-06-23 06:11:48.432062
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    c = Conditional(loader=DataLoader())

    c._ds = "test"
    c._loader = DataLoader()
    c._variable_manager = VariableManager()

    try:
        c.evaluate_conditional(c._loader.loaders[0], Inventory(c._loader, c._variable_manager, host_list='/dev/null').get_hosts())
        assert False, "should have failed with no defined when"
    except:
        pass

    c._when = list()
    c._when.append('foo')

# Generated at 2022-06-23 06:12:00.702745
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = "var1 is undefined or (var2 is undefined and var3 is defined) or var5 is 'something'"
    expected = [
        ("var1", "is", "undefined"),
        ("var2", "is", "undefined"),
        ("var3", "is", "defined"),
        ("var5", "is", "undefined"),
    ]
    actual = Conditional().extract_defined_undefined(conditional)

    #
    # test if the number of defined and undefined clauses is correct
    #
    assert len(expected) == len(actual), "extract_defined_undefined returned a list of size %s, but expected list of size %s" % (len(actual), len(expected))


# Generated at 2022-06-23 06:12:06.778134
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    whens = [
        "{{ test_var }} == 1",
        "{{ test_var }} != 1",
        "{{ test_var }} == 'a'",
        "{{ test_var }} != 'a'",
        "test_var == 1",
        "test_var != 1",
        "test_var == 'a'",
        "test_var != 'a'"
    ]
    test_vars = {
        "test_var": "a"
    }
    expected = [
        False,
        True,
        True,
        False,
        False,
        True,
        True,
        False
    ]

    play_context = PlayContext()

# Generated at 2022-06-23 06:12:16.105896
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.vars import VariableManager

    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader, variables=VariableManager())
    inventory = InventoryManager(loader=loader, sources=["localhost"])

    class TestConditional(Conditional):
        def __init__(self):
            super(Conditional, self).__init__()
            self.when = []

    conditional = TestConditional()


    #assert hasattr(self, '_loader')

    # Test with an empty string
    conditional.when.append('')
    assert conditional.evaluate_conditional(templar, inventory.get_hosts('localhost'))

    # Test with a boolean

# Generated at 2022-06-23 06:12:26.069266
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Set up a playbook with a single conditional
    playbook = Playbook()
    conditional = '{{ hostname is defined }}'
    playbook.add_task(ConditionalTestTask(when=conditional))

    # For the method's output, expect the conditional to be extracted and returned as list
    # of tuple with the following items:
    expected_defined_undefined = [
        ('hostname', ' is ', 'defined'),
    ]

    # Execute method and compare output
    conditional_obj = playbook.tasks[0]
    assert conditional_obj.extract_defined_undefined(conditional) == expected_defined_undefined


# Generated at 2022-06-23 06:12:30.027916
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    fake_conditional = Conditional()
    conditional = 'a is defined or b is undefined or (c is not defined and d is undefined)'
    extracted = fake_conditional.extract_defined_undefined(conditional)
    assert extracted == [('a', 'is', 'defined'), ('b', 'is', 'undefined'), ('c', 'is', 'not defined'), ('d', 'is', 'undefined')]



# Generated at 2022-06-23 06:12:41.681855
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from jinja2 import Environment
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar


# Generated at 2022-06-23 06:12:48.585060
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-23 06:13:00.159687
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    display.verbosity = 3
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    conditional = Conditional()
    conditional.when = [ u'inventory_hostname is localhost',
                         u'inventory_hostname is not localhost',
                         u'inventory_hostname is defined',
                         u'inventory_hostname is not defined',
                         u'inventory_hostname is undefined',
                         u'inventory_hostname is not undefined',
                         u'inventory_hostname',
                         u'inventory_hostname and inventory_hostname',
                         u'inventory_hostname and "check_hostname" in inventory_hostname',
                         u'inventory_hostname and "check_hostname" not in inventory_hostname',
                         u'inventory_hostname or inventory_hostname' ]

    templ

# Generated at 2022-06-23 06:13:10.114033
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    c = Conditional()

    # FIXME: Regex with lookups and single quotes
    # FIXME: Regex with filters
    # FIXME: Regex with complex conditions


# Generated at 2022-06-23 06:13:18.701804
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("foo is not defined") == [("foo", "is", "not defined")]
    assert conditional.extract_defined_undefined("foo not is defined") == [("foo", "not", "is defined")]
    assert conditional.extract_defined_undefined("foo not is not defined") == [("foo", "not", "is not defined")]
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]