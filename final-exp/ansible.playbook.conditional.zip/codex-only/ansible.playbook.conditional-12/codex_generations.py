

# Generated at 2022-06-23 06:03:23.880828
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    conditional = dict()
    conditional['hostvars[plays[0].hosts[0]] is defined'] = [('hostvars[plays[0].hosts[0]]', 'is', 'defined')]
    conditional['hostvars[plays[0].hosts[0]] isnot defined'] = [('hostvars[plays[0].hosts[0]]', 'isnot', 'defined')]
    conditional['hostvars[plays[0].hosts[0]] not is defined'] = [('hostvars[plays[0].hosts[0]]', 'not is', 'defined')]
    conditional['hostvars[plays[0].hosts[0]] not isnot defined'] = [('hostvars[plays[0].hosts[0]]', 'not isnot', 'defined')]

# Generated at 2022-06-23 06:03:32.251180
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # setup test
    conditional = Conditional(loader=None)

    # create test
    # first test
    test1 = "ansible_os_family is defined or ansible_os_family is not defined"
    result1 = conditional.extract_defined_undefined(test1)
    expected_result1 = [("ansible_os_family", "is", "defined"), ("ansible_os_family", "is not", "defined")]
    assert result1 == expected_result1

    # second test
    test2 = "ansible_os_family not is defined or ansible_os_family is defined and not ansible_os_family is not defined"
    result2 = conditional.extract_defined_undefined(test2)

# Generated at 2022-06-23 06:03:36.135285
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    def check_list(list1, list2):
        return sorted(list1) == sorted(list2)

    conditional = Conditional()
    test_str = 'failure'
    conditional.when = [test_str]
    assert check_list(conditional.extract_defined_undefined(test_str), ['failure', 'is', 'undefined'])



# Generated at 2022-06-23 06:03:46.832421
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar

    play = Play.load(dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='Hello World')))
        ]
    ))
    task = play.get_tasks()[0]

    # legacy style: each task can define a 'when' attribute
    task.when = "ansible_os_family == 'RedHat'"
    result = task.evaluate_conditional(Templar(play=play), dict(ansible_os_family='RedHat'))
    assert result is True

# Generated at 2022-06-23 06:03:47.416740
# Unit test for constructor of class Conditional
def test_Conditional():
    pass


# Generated at 2022-06-23 06:03:55.629701
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    play_context = PlayContext()
    templar = Templar(loader=loader, inventory=inventory,
                      variable_manager=variable_manager, loader_basedir="")

    cond = Conditional()
    assert cond.extract_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]

# Generated at 2022-06-23 06:04:06.069280
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    tests = [
        ("var is defined", [('var', 'is', 'defined')]),
        ("var is not defined", [('var', 'is not', 'defined')]),
        ("var is defined and var2 is defined", [('var', 'is', 'defined'), ('var2', 'is', 'defined')]),
        ("var is defined or var2 is not defined", [('var', 'is', 'defined'), ('var2', 'is not', 'defined')]),
        ("var is defined and other is foo and var2 is not defined",
         [('var', 'is', 'defined'), ('var2', 'is not', 'defined')]),
        ("hostvars['var'] is defined", [('hostvars[\'var\']', 'is', 'defined')]),
    ]

# Generated at 2022-06-23 06:04:13.744660
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.base import Base
    from ansible.playbook.attribute import FieldAttribute

    class TestClass(Base, Conditional):

        _testattr1 = FieldAttribute(isa='str', default=dict())

        def __init__(self):
            super(TestClass, self).__init__()

    test_obj = TestClass()
    assert test_obj._testattr1 == {}


# Generated at 2022-06-23 06:04:21.951457
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.base import PlaybookBase
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.vars import VariableManager

    v = VariableManager()
    p = PlaybookBase()
    t = Task()
    b = Block()
    r = Role()

    # Conditional task
    t.when = ['bar is defined']
    t._loader = 'loader'
    results = t.evaluate_conditional(p._variable_manager, v.get_vars(play=p))
    assert results

    # Conditional block
    b.when = ['bar is defined']
    b._loader = 'loader'

# Generated at 2022-06-23 06:04:32.324049
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    class ConditionalTest(Conditional):
        pass

    test = ConditionalTest()

    # Test undefined variable raise error
    def templar_mock(data):
        if 'var_not_defined' in data:
            raise AnsibleUndefinedVariable(data)
        elif 'condition' in data:
            if data.find('hostvars[inventory_hostname]') != -1:
                return 'hostvars[inventory_hostname]'
            elif data.find('hostvars[inventory_hostname_short]') != -1:
                return 'hostvars[inventory_hostname_short]'
            elif data.find('hostvars[ansible_hostname]') != -1:
                return 'hostvars[ansible_hostname]'
        return 'True'


# Generated at 2022-06-23 06:04:42.180304
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # define fixtures we will use to run our test cases
    fixture_conditional = "set_fact: ansible_docker_packages='{{ ansible_distribution_major_version | int < 8 and ansible_pkg_mgr in [ \"yum\", \"dnf\" ] | ternary(\"docker\", \"docker-engine\") }}'"

    # test cases we expect to return a def_undef list with single
    # element ansible_pkg_mgr is defined
    test_cases = [(r"ansible_pkg_mgr is defined",["ansible_pkg_mgr", "is", "defined"]),
                  (r"ansible_docker_packages is not defined", ["ansible_docker_packages", "is", "not defined"])]
    # expected result when conditional contains a single defined/undefined test

# Generated at 2022-06-23 06:04:49.620263
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class MyConditional(Conditional):
        def __init__(self):
            super(MyConditional, self).__init__()


    def make_context():
        context = PlayContext()
        context._vars_cache = {}
        context.shared = {}
        context.vars = {}
        return context

    context = make_context()
    context.vars = {'foo': 'foo', 'bar': 'bar', 'bam': 'bam'}
    context.hostvars = {'host_a': {'foo': 'foo'}, 'host_b': {'foo': 'foo', 'bar': 'bar'}}
    context.all_hosts

# Generated at 2022-06-23 06:04:56.394274
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test evaluate_conditional function, test for parameter 'conditional' is True
    conditional = Conditional()
    conditional_value = True
    templar = Templar(loader=None, variables={})
    all_vars = dict(a="a", b="b", c="c")
    result = conditional.evaluate_conditional(templar, all_vars)
    assert result is True

    # Test evaluate_conditional function, test for parameter 'conditional' is False
    conditional = Conditional()
    conditional_value = False
    templar = Templar(loader=None, variables={})
    all_vars = dict(a="a", b="b", c="c")
    result = conditional.evaluate_conditional(templar, all_vars)
    assert result is False

    # Test evaluate_conditional function,

# Generated at 2022-06-23 06:05:08.021813
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    theclass = Conditional()
    theclass._loader = None

    # Tests with defined/undefined statements
    conditional = 'v is defined'
    if theclass.extract_defined_undefined(conditional) != [('v', 'is', 'defined')]:
        raise Exception("failed: %s" % conditional)

    conditional = 'v not is undefined'
    if theclass.extract_defined_undefined(conditional) != [('v', 'not is', 'undefined')]:
        raise Exception("failed: %s" % conditional)

    conditional = 'a is defined and b is defined and not c is defined'
    if theclass.extract_defined_undefined(conditional) != [('a', 'is', 'defined'), ('b', 'is', 'defined'), ('c', 'not is', 'defined')]:
        raise

# Generated at 2022-06-23 06:05:17.045102
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # test the base case of a valid conditional
    conditional = 'ansible_facts["distribution"] == "CentOS"'
    templar = DummyTemplar()
    all_vars = {"ansible_facts": {"install_mode": "yum", "distribution": "CentOS"}}
    res = Conditional().evaluate_conditional(templar, all_vars)
    assert res == True
    # test the base case of an invalid conditional
    conditional = 'ansible_facts["distribution"] == "RedHat"'
    templar = DummyTemplar()
    all_vars = {"ansible_facts": {"install_mode": "yum", "distribution": "CentOS"}}
    res = Conditional().evaluate_conditional(templar, all_vars)
    assert res == False
   

# Generated at 2022-06-23 06:05:29.695351
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    result = cond.extract_defined_undefined("some_var is defined and foo is not defined")
    assert result == [('some_var', 'is', 'defined'), ('foo', 'is not', 'defined')]
    result = cond.extract_defined_undefined("foo is defined or bar is undefined")
    assert result == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]
    result = cond.extract_defined_undefined("foo is defined or bar is not defined")
    assert result == [('foo', 'is', 'defined'), ('bar', 'is', 'not defined')]
    result = cond.extract_defined_undefined("foo is not defined or bar is undefined")

# Generated at 2022-06-23 06:05:40.456589
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    print("Testing method extract_defined_undefined")

# Generated at 2022-06-23 06:05:41.280738
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c.when == []

# Generated at 2022-06-23 06:05:52.953649
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from jinja2 import Environment, StrictUndefined
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    # Create a basic set of facts for our tests
    facts = dict(
        ansible_os_family="Debian",
        ansible_distribution="Debian"
    )
    # Create a basic set of vars
    variables = dict(
        test_var="test",
        empty_var="",
        zero_var=0,
    )
    # Create a basic set of vars that will be used as extra vars
    extra_vars = dict(
        extra_var="extra",
        empty_extra_var="",
        zero_extra_var=0,
    )
   

# Generated at 2022-06-23 06:06:02.497878
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    mgr = VariableManager()
    c = Conditional()
    t = Templar(mgr, loader=None)

    assert c.evaluate_conditional(t, dict()) == True
    assert c.evaluate_conditional(t, dict(a=1)) == True

    c._when = ["myvar"]
    c2 = dict(
        myvar=False,
        myvar2="Not value"
    )

    assert c.evaluate_conditional(t, c2) == False

    c2['myvar'] = True
    assert c.evaluate_conditional(t, c2) == True

# Generated at 2022-06-23 06:06:06.860992
# Unit test for constructor of class Conditional
def test_Conditional():
    class TestConditional(Conditional):
        _when = FieldAttribute(isa='list', default=list, extend=True, prepend=True)
    t = TestConditional()

    assert isinstance(t._when, list)
    assert not t.evaluate_conditional(None, {})


# Generated at 2022-06-23 06:06:17.145968
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

# Generated at 2022-06-23 06:06:29.209081
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

    assert c.extract_defined_undefined("a is defined and b is not defined") == [("a", "is", "defined"), ("b", "is not", "defined")]
    assert c.extract_defined_undefined("'a' is defined") == [("'a'", "is", "defined")]
    assert c.extract_defined_undefined("a|d() is defined") == [("a|d()", "is", "defined")]
    assert c.extract_defined_undefined("hostvars['test.example.com'] is defined") == [("hostvars['test.example.com']", "is", "defined")]

# Generated at 2022-06-23 06:06:37.104909
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # This method should not be called outside of the unit tests
    # and is only left here for documentation purposes
    class FakeTask:
        pass

    t = FakeTask()

# Generated at 2022-06-23 06:06:47.264645
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("a is defined and b is not defined") == [('a', 'is', 'defined'), ('b', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("a is undefined and b is not undefined") == [('a', 'is', 'undefined'), ('b', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined("a is undefined or b is defined") == [('a', 'is', 'undefined'), ('b', 'is', 'defined')]
    assert conditional.extract_defined_undefined("a is defined or b is undefined") == [('a', 'is', 'defined'), ('b', 'is', 'undefined')]

# Generated at 2022-06-23 06:06:52.775097
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # This unit test has been added manually and might not be exhaustive
    # fix the unit test if a bug is found in the regex
    cond = Conditional()
    assert [] == cond.extract_defined_undefined('')
    assert [('foo', 'is', 'defined')] == cond.extract_defined_undefined('foo is defined')
    assert [('foo', 'is', 'defined')] == cond.extract_defined_undefined(' foo is defined')
    assert [('foo', 'is', 'defined')] == cond.extract_defined_undefined(' foo is defined ')
    assert [('foo', 'is', 'defined')] == cond.extract_defined_undefined('foo is defined ')

# Generated at 2022-06-23 06:07:01.721843
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    This method tests evaluate_conditional of class Conditional
    '''
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    test_when = ['fake_when_con']
    test_play = Play()
    test_play.vars = {'additional_var': 'fake_additional'}
    test_task = Task()
    test_task.vars = {'task_var': 'fake_task'}
    test_task._when = test_when
    test_task._play = test_play

    test_task.evaluate_conditional('fake_templar', 'fake_all_vars')



# Generated at 2022-06-23 06:07:13.886807
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.template import Templar

    variable_manager = VariableManager()
    loader = DataLoader()

    host_vars = dict(ping='pong')
    group_vars = dict(foo='bar')
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    inventory.add_host('localhost')
    inventory.set_variable_manager(variable_manager)
    variable_manager.set_inventory(inventory)
    variable_manager.set_host_variable('localhost', host_vars)
    variable_manager.set_group_variable('webservers', group_vars)

   

# Generated at 2022-06-23 06:07:21.412731
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.helpers import load_list_of_tasks
    playbook = load_list_of_tasks('tests/conditional/test_meta_defined_undefined.yaml', loader=None)

    tasks = playbook[0]["tasks"]

    (task1_when, _) = tasks[0]
    assert Conditional.extract_defined_undefined(Conditional(), task1_when) == [('test1', ' not is', 'defined'), ('test2', ' is ', 'undefined')]

    (task2_when, _) = tasks[1]
    assert Conditional.extract_defined_undefined(Conditional(), task2_when) == [('test1', ' is not', 'defined'), ('test2', ' is ', 'undefined')]

    (task3_when, _)

# Generated at 2022-06-23 06:07:33.277171
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    tests = [
        ('a is defined', [('a', 'is', 'defined')]),
        ('a is not defined', [('a', 'is not', 'defined')]),
        ('a is defined or b is not defined', [('a', 'is', 'defined'), ('b', 'is not', 'defined')]),
        ('a is defined or b is not undefined', [('a', 'is', 'defined'), ('b', 'is not', 'undefined')]),
        ('''a is defined and b is undefined or "something" == "something else" and c is defined''',
         [('a', 'is', 'defined'), ('b', 'is', 'undefined'), ('c', 'is', 'defined')]),
    ]
    for test, expected in tests:
        conditional = Conditional()
        result = conditional.extract_defined_und

# Generated at 2022-06-23 06:07:42.472044
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    test_data='''
    "{{ ansible_managed|comment }}
    {% set install_root = '/opt/myapp' %}
    {% set data_root = install_root + '/data' %}

    {% if install_root is defined and sshkey is not defined %}
    {%   set sshkey = lookup('pipe','head -1 /root/.ssh/id_rsa.pub') %}
    {% endif %}

    {% if hostvars[inventory_hostname].ansible_host is defined %}
    {%   set host = hostvars[inventory_hostname].ansible_host %}
    {% else %}
    {%   set host = inventory_hostname %}
    {% endif %}
    "
    '''

# Generated at 2022-06-23 06:07:52.967101
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.template import Templar

    # Initialize variables
    vars_all = dict(a=1, b=2, c=3, d=4, e=5)
    # d, e are not defined in the first run
    vars_first = dict(a=1, b=2, c=3)
    # a is not defined in the second run
    vars_second = dict(b=2, c=3, d=4, e=5)

    # Set up host
    cond = Conditional()

    # First: verify that an all-true conditional has the expected result.
    # Also verify that logic involving always-true conditions work.
    cond._when = [True, True]

# Generated at 2022-06-23 06:08:00.214192
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class AnsibleModule:
        def __init__(self, **kwargs):
            self.params = kwargs

    # Create a simple test setup
    play = dict(
        hostvars = {
            'localhost': {
                'foo': '42'
            }
        }
    )
    templar = dict(
        variables = {
            'foo': 'foo'
        }
    )
    module = AnsibleModule(foo=42)
    play_context = dict(
        module_name=''
        )

    # Successful eval
    module.params['foo'] = 42

    # This is the signature of the actual function
    #def evaluate_conditional(self, templar, all_vars):

    conditional = Conditional()

    # no when, True
    assert conditional.evaluate_conditional

# Generated at 2022-06-23 06:08:10.644444
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # pylint: disable=import-error,too-many-locals,protected-access
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    task_include = TaskInclude()
    host_vars = dict(
        my_defined_var=True,
        my_other_var=False,
        my_string="foo",
        my_int=42,
        my_invalid_var=None,
        my_list=['foo', 42],
        my_dict=dict(val=42),
    )
    variable_manager = VariableManager(loader=None, variables=host_vars)

# Generated at 2022-06-23 06:08:20.026052
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

    # Test regular expression matching
    assert cond.extract_defined_undefined("not hostvars['hostname'] is undefined") == [("hostvars['hostname']", "not is", "undefined")]
    assert cond.extract_defined_undefined("'foo' is 'bar' and client is defined") == [("client", "is", "defined")]
    assert cond.extract_defined_undefined("'foo' is not 'bar' and hostname is undefined") == [("hostname", "is", "undefined")]

    # Test no matching
    assert cond.extract_defined_undefined("foo is bar") == []



# Generated at 2022-06-23 06:08:30.024023
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    data = (
        ('foo is defined', [(u'foo', u'is', u'defined')]),
        ('foo not is defined', [(u'foo', u'not is', u'defined')]),
        ('foo is not defined', [(u'foo', u'is not', u'defined')]),
        ('foo is defined or bar is undefined', [(u'foo', u'is', u'defined'), (u'bar', u'is', u'undefined')]),
        ('foo is defined and bar is not defined', [(u'foo', u'is', u'defined'), (u'bar', u'is not', u'defined')]),
    )
    for conditional, result in data:
        assert Conditional().extract_defined_undefined(conditional) == result


# Generated at 2022-06-23 06:08:32.870985
# Unit test for constructor of class Conditional
def test_Conditional():
    cond = Conditional()
    assert cond



# Generated at 2022-06-23 06:08:36.507897
# Unit test for constructor of class Conditional
def test_Conditional():
    cond = Conditional()
    assert cond.when == [], "unexpected attribute for 'when' defined"

# Unit tests for _validate_when method of class Conditional

# Generated at 2022-06-23 06:08:46.894977
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-23 06:08:57.634361
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task.include import Include
    from ansible.playbook.play import Play
    #from ansible.playbook.block import Block
    #from ansible.playbook.handler.include import HandlerInclude
    #from ansible.playbook.handler.handler import Handler


# Generated at 2022-06-23 06:09:04.241990
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    if getattr(conditional, '_loader'):
        raise AssertionError('Expected _loader to be None, got %s' % conditional._loader)
    conditional = Conditional(loader='test')
    if conditional._loader != 'test':
        raise AssertionError('Expected _loader to be test, got %s' % conditional._loader)

# Generated at 2022-06-23 06:09:15.668199
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''Test case for checking Conditional.extract_defined_undefined()'''
    conditional = \
        "ansible_net_version is not defined and ansible_os_family != 'NX-OS' and ansible_os_family != 'IOS-XR'"
    conditional_duplicate = \
        "ansible_net_version is not defined and ansible_os_family != 'NX-OS' and ansible_os_family != 'IOS-XR'" \
        + " and ansible_os_family != 'IOS-XR'"
    conditional_split = \
        '(' + conditional_duplicate + ') or ansible_net_version is defined'

# Generated at 2022-06-23 06:09:26.611759
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext

    fake_play = Play().load({
        'name': 'fakeplay',
        'hosts': 'fakehost',
    }, variable_manager={}, loader=None)
    fake_task = Conditional()
    templar = fake_play.get_variable_manager().get_vars(loader=None, play=fake_play)
    templar._options = {}
    fake_task._loader = fake_play._loader

    fake_task.when = ['fakehost in groups["fakegroup"]']
    fake_task.all_vars = templar
    fake_task.evaluate_conditional(templar, templar)

# Generated at 2022-06-23 06:09:34.093421
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Test evaluate_conditional() with fixture data
    '''
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task, TaskInclude
    from ansible.template import Templar

    playbook = Playbook()

    parent_block = Block()
    parent_block._play = playbook

    task_block = Block()
    task_block._play = playbook
    task_block._parent = parent_block

    task = Task()
    task._block = task_block

    ti = TaskInclude()
    ti._block = task_block


# Generated at 2022-06-23 06:09:44.776950
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    Validate method extract_defined_undefined of class Conditional.
    '''
    cond = Conditional()
    # simple test case
    expr = '{{ foo is defined }}'
    out = cond.extract_defined_undefined(expr)
    assert out == [('foo', 'is', 'defined')]
    # matches all of them
    expr = '{{ foo is defined }} and {{ bar is not undefined }}'
    out = cond.extract_defined_undefined(expr)
    assert out == [('foo', 'is', 'defined'), ('bar', 'is not', 'undefined')]
    # test for hostvars
    expr = '{{ hostvars[inventory_hostname] is defined }}'
    out = cond.extract_defined_undefined(expr)

# Generated at 2022-06-23 06:09:51.117801
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = """hostvars['hostname'] is defined and "IsNotDefined" not in hostvars['hostname']"""
    from ansible.playbook.task_include import TaskInclude
    cond = Conditional()
    test = cond.extract_defined_undefined(conditional)
    assert test == [('hostvars[\'hostname\']', 'is', 'defined')]

# unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-23 06:10:01.394552
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    # In case we use normal python interpreter to work with this file
    # and run tests from it, this import is required.
    from ansible.playbook.task import Task

    task = Task()
    conditional = "A is undefined and B is not defined"
    result = task.extract_defined_undefined(conditional)
    assert result == [("A", "is", "undefined"), ("B", "is not", "defined")]

    conditional = "A is undefined and B is not defined and C is defined"
    result = task.extract_defined_undefined(conditional)
    assert result == [("A", "is", "undefined"), ("B", "is not", "defined"), ("C", "is", "defined")]

    conditional = "A is undefined or B is not undefined"
    result = task.extract_defined

# Generated at 2022-06-23 06:10:03.446023
# Unit test for constructor of class Conditional
def test_Conditional():
    """Test the constructor"""
    conditional = Conditional()
    assert conditional



# Generated at 2022-06-23 06:10:13.349810
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import yaml
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.base import Base
    from ansible.vars.manager import VariableManager

    class HostVars(dict):
        pass

    class Play(Conditional, Base):
        pass

    class Task(Conditional, Base):
        pass


# Generated at 2022-06-23 06:10:24.884082
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import copy
    import yaml
    yaml.FullLoader = yaml.CLoader
    from ansible.playbook.play_context import PlayContext

    class MyConditional(Conditional):
        pass

    my_conditional = MyConditional()
    my_conditional._ds = dict()

    play_context = PlayContext()
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Simple strings, lists, dicts and dict-lists

# Generated at 2022-06-23 06:10:31.899765
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    variables = dict()
    variables['var1'] = ""
    variables['var2'] = "var"
    variables['var3'] = "bar"
    variables['var4'] = ""
    variables['var5'] = "var"
    variables['var6'] = ["var1", "var2", "var3"]
    variables['var7'] = ["var4", "var5", "var6"]
    variables['var8'] = ""
    variables['var9'] = "var"
    variables['var10'] = ["var8", "var9"]

    templar = DummyTemplar(variables)


    # test case 1
    # Test conditions: var is defined, var is not empty, var is not var3
    # Expected result: True

# Generated at 2022-06-23 06:10:42.971394
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    y = AnsibleUnsafeText(u'{{foo}}')

    module = type('FauxModule', (object,), {'params': {}})
    c = Conditional()
    assert c.evaluate_conditional('{{foo}}', module, dict(foo=1), True)
    assert c.evaluate_conditional('{{foo}}', module, dict(foo=0), False)
    assert c.evaluate_conditional(True, module, dict(), True)
    assert c.evaluate_conditional(False, module, dict(), False)
    assert c.evaluate_conditional(y, module, dict(foo=1), True)
    assert c.evaluate_conditional(y, module, dict(foo=0), False)

# Generated at 2022-06-23 06:10:54.109485
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:10:57.931128
# Unit test for constructor of class Conditional
def test_Conditional():
    assert(Conditional().when == [])
    conditional = Conditional()
    conditional.when = 'string variable test'
    assert(conditional.when == ['string variable test'])


# Generated at 2022-06-23 06:11:10.584185
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    loader = DictDataLoader({
        "conditional": dict(
            vars=dict(
                foo="bar",
                bar="baz",
                baz="foo",
                firstvar="one",
                secondvar="two",
            ),
            hostvars=dict(
                localhost=dict(
                    hostvars_firstvar="one",
                    hostvars_secondvar="two",
                    hostvars_foo="bar",
                    hostvars_bar="baz",
                ),
            ),
        ),
    })

    variable_manager = VariableManager(loader=loader)
    play_context = PlayContext()

# Generated at 2022-06-23 06:11:12.392292
# Unit test for constructor of class Conditional
def test_Conditional():
    test_obj = Conditional()
    assert test_obj != None


# Generated at 2022-06-23 06:11:23.846934
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:11:32.592488
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    # Create a temporary dummy class inheriting from Conditional
    class DummyConditional(Conditional):
        def __init__(self):
            super(DummyConditional, self).__init__(loader=None)

    # Create instance of DummyConditional
    dummy_conditional = DummyConditional()

    # Test empty conditional
    dummy_conditional.when = [None]
    assert dummy_conditional.evaluate_conditional(None, None) is True

    # Test list with empty str conditional
    dummy_conditional.when = [""]
    assert dummy_conditional.evaluate_conditional(None, None) is True

    # Test list with empty bool conditonal
    dummy_conditional.when = [False]

# Generated at 2022-06-23 06:11:41.622715
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    c = Conditional()
    b = Base()
    v = VariableManager()

    c.when = ['foo', 'foo == bar']

    res = c.evaluate_conditional(Templar(v, loader=None), dict())
    assert res is False

    res = c.evaluate_conditional(Templar(v, loader=None), dict(foo=True, bar=False))
    assert res is True

    c.when = ['foo', 'foo == bar']
    res = c.evaluate_conditional(Templar(v, loader=None), dict(foo=True, bar=True))
    assert res is False

    c.when = ['foo', 'foo == bar']


# Generated at 2022-06-23 06:11:48.044643
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext

    conditional = Conditional()
    conditional._loader = DictDataLoader({})

    conditional.when = ["item == 1"]
    conditional.when = ["item == 2"]

    display.verbosity = 3
    pc = PlayContext()
    pc.vars = {'item': 2}

    assert conditional.evaluate_conditional(pc.get_loader(), pc.vars) is True
    pc.vars['item'] = 3
    assert conditional.evaluate_conditional(pc.get_loader(), pc.vars) is False



# Generated at 2022-06-23 06:11:50.584998
# Unit test for constructor of class Conditional
def test_Conditional():
    t = Conditional()
    assert t is not None


# Generated at 2022-06-23 06:11:52.282133
# Unit test for constructor of class Conditional
def test_Conditional():
    class TestClass(Conditional):
        pass

    assert TestClass._when == list

# Generated at 2022-06-23 06:12:01.791191
# Unit test for constructor of class Conditional
def test_Conditional():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # create a simple play for testing
    play_context = PlayContext()
    play_context._variable_manager = VariableManager()
    templar = Templar(play_context._variable_manager, loader=FakeLoader())

    # TODO(v0.4.0): this test is likely to break if we do not provide when.
    #                It is not clear why when is required.
    test_cond = Conditional(loader=FakeLoader())
    test_cond.when = ["foobar"]

    assert test_cond.evaluate_conditional(templar, {})

    # TODO: add more tests

# Generated at 2022-06-23 06:12:07.504433
# Unit test for constructor of class Conditional
def test_Conditional():
    import pytest
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block

    pb1 = Play().load({'hosts': 'host1', 'tasks': [{'action': {'module': 'fake', 'args': 'a=1'}}]})
    pb2 = Play().load({'hosts': 'host1', 'tasks': [{'action': {'module': 'fake', 'args': 'a=1'}}, {'action': {'module': 'fake2', 'args': 'a=1'}}]})

# Generated at 2022-06-23 06:12:12.505624
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    # TODO: do a better job with inventory...
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    condition = Conditional(loader=loader)
    condition._when = ["'no_snapshots' in group_names and foo.bar == 'baz' and some_var != 'not_defined'"]

    variable_manager.set_host_variable("some_var", "defined")
    variable_manager.set_host_variable("group_names", ["no_snapshots"])

# Generated at 2022-06-23 06:12:20.327503
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader

    def TestClass(Conditional):
        pass

    loader = DataLoader()
    block = Block.load(dict(name="test"), loader=loader, play=None, task_include=None, role=None, use_handlers=False, task_errors='strict', variable_manager=None)
    task = Task.load(dict(action=dict(module="ping")), block=block, role=None)
    try:
        test = TestClass(loader=loader)
        raise Exception("Should not have reached this point")
    except:
        pass

    try:
        test = TestClass(loader=loader, when=True)
    except:
        raise Exception

# Generated at 2022-06-23 06:12:31.722578
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class Test(object):
        when = []

    o = Conditional()
    o._ds = dict(name='foo')
    o.when = ['when_cond']
    t = DictData()
    t.data = {'foo': 'foo', 'bar': 'bar', 'baz': 'baz'}

    # uncoditional
    assert o.evaluate_conditional(t, dict(foo='1', bar='1')) is True

    # negated conditional
    o.when = ['not when_cond']
    assert o.evaluate_conditional(t, dict(foo='1', bar='1')) is False

    # conditionals
    o.when = ['when_cond and when_cond2']
    o.when = ['when_cond or when_cond2']

# Generated at 2022-06-23 06:12:42.882898
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    ''' test running the module '''
    assert Conditional().evaluate_conditional("1==1", {}) == True
    assert Conditional().evaluate_conditional("1==0", {}) == False
    assert Conditional().evaluate_conditional("1==1", {"a":1}) == True
    assert Conditional().evaluate_conditional("a!=1", {"a":1}) == False
    assert Conditional().evaluate_conditional("1==1", {"a":1}) == True
    assert Conditional().evaluate_conditional("1==1", {"a":1}) == True
    assert Conditional().evaluate_conditional("1==1", {"a":1}) == True
    assert Conditional().evaluate_conditional("1==1", {"a":1}) == True



# Generated at 2022-06-23 06:12:43.987633
# Unit test for constructor of class Conditional
def test_Conditional():
    test = Conditional()
    assert isinstance(test, Conditional)



# Generated at 2022-06-23 06:12:48.949718
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    def_undef = conditional.extract_defined_undefined('foo not is defined and bar is defined')
    assert len(def_undef) == 2
    for du in def_undef:
        assert len(du) == 3


# Generated at 2022-06-23 06:13:00.451124
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    """
    Runs simple tests on method extract_defined_undefined of class Conditional
    """
    # Positive tests

# Generated at 2022-06-23 06:13:10.248071
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # no when should always return True
    test_obj = Conditional()
    # Python 3 returns True, Python 2 returns False
    assert test_obj.evaluate_conditional(None, None) in (True, False)

    # when with single 'True' should always return True
    test_obj = Conditional()
    test_obj._when = [True]
    assert test_obj.evaluate_conditional(None, None) == True

    # when with single 'False' should always return False
    test_obj = Conditional()
    test_obj._when = [False]
    assert test_obj.evaluate_conditional(None, None) == False

    # when with jinja2 templating should raise an error
    test_obj = Conditional()
    test_obj._when = ['{{ foo }}']