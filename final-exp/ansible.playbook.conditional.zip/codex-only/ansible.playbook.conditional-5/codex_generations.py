

# Generated at 2022-06-23 06:03:14.877990
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c._when is not None



# Generated at 2022-06-23 06:03:20.871353
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    p = Conditional()
    conditional = "foo is defined and (bar is not defined or baz is undefined)"
    results = p.extract_defined_undefined(conditional)
    assert results == [('foo', 'is', 'defined'),
                       ('bar', 'is not', 'defined'),
                       ('baz', 'is', 'undefined')]



# Generated at 2022-06-23 06:03:29.525941
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext

    # detailed test of the method _check_conditional

# Generated at 2022-06-23 06:03:39.796308
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Create an instance of class Conditional
    cond = Conditional()
    # We do not test the case with undefined variables as AnsibleUndefinedVariable exception is raised and
    # the program is terminated
    # Test the case where a variable is not defined
    test_str = "myvar is not defined"
    extracted = cond.extract_defined_undefined(test_str)
    assert len(extracted) == 1, "extract_defined_undefined does not work correctly when there's a single " + \
                                "non-defined variable"
    result = extracted[0]
    expected = ("myvar", "is not", "defined")
    assert result == expected, "extract_defined_undefined does not work correctly when there's a single " + \
                               "non-defined variable"
    # Test the case where a variable is defined


# Generated at 2022-06-23 06:03:51.163929
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class Test(Conditional):
        pass

    # Two variables, must all be true
    test = Test()
    test.when = ['{{a}} == 2 and {{b}} == 2']
    assert test.evaluate_conditional(None, dict(a=2, b=2))

    # One variable, not true
    test = Test()
    test.when = ['{{a}} == 2']
    assert not test.evaluate_conditional(None, dict(a=3, b=3))

    # One variable, true
    test = Test()
    test.when = ['{{a}} == 3']
    assert test.evaluate_conditional(None, dict(a=3, b=3))

    # Test the when statement "when:"
    test = Test()

# Generated at 2022-06-23 06:04:02.407476
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.vars.manager import VariableManager
    import os
    import json

    display.verbosity = 3

    # set some basic facts
    os.environ['ANSIBLE_INVENTORY'] = json.dumps(
        {"all": {"hosts": {"localhost": {"ansible_facts": {'fact_one': 'foo', 'fact_two': 'bar'}}}}}
    )
    os.environ['ANSIBLE_CONFIG'] = 'test/ansible.cfg'

    # set some basic variables
    fake_loader = DictDataLoader({
        'test/ansible.cfg': '# config file for testing\n',
    })
    # create a variable manager
    variable_manager

# Generated at 2022-06-23 06:04:15.974244
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    Unit test for method extract_defined_undefined of class Conditional
    '''

    c = Conditional()

    results = c.extract_defined_undefined('a.b.c is undefined')
    assert results == [('a.b.c', 'is', 'undefined')]

    results = c.extract_defined_undefined('a.b.c is not defined')
    assert results == [('a.b.c', 'is not', 'defined')]

    results = c.extract_defined_undefined('a.b.c is defined')
    assert results == [('a.b.c', 'is', 'defined')]

    results = c.extract_defined_undefined('a.b.c is defined and my_var not is undefined')

# Generated at 2022-06-23 06:04:17.538341
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional._when == []

# Generated at 2022-06-23 06:04:29.990199
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    def _test_conditional(input_cond, expected_output):
        actual = conditional.extract_defined_undefined(input_cond)
        assert expected_output == actual

    _test_conditional('a is defined', [ ('a', 'is', 'defined') ])
    _test_conditional('a is not defined', [ ('a', 'is not', 'defined') ])
    _test_conditional('a not is defined', [ ('a', 'not is', 'defined') ])
    _test_conditional('hostvars[inventory_hostname] is defined', [ ('hostvars[inventory_hostname]', 'is', 'defined') ])

# Generated at 2022-06-23 06:04:40.429617
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    play_context._lookup_loader = C.plugin_loader

    variable_manager = VariableManager()
    variable_manager._extra_vars = dict(
        var1='value1',
        var2=True,
        var3=False,
        var4=[
            dict(
                var4_1='value4_1',
                var4_2='value4_2',
            )
        ]
    )

    # No condition
    task = Conditional()
    task.when = list()
    result = task.evaluate_conditional(variable_manager.get_vars, variable_manager.get_vars, play_context)
    assert result

    # Empty

# Generated at 2022-06-23 06:04:48.318968
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    s = "my_var is defined and my_var is undefined"
    r = c.extract_defined_undefined(s)
    assert r[0][0] == "my_var"
    assert r[0][1] == "is"
    assert r[0][2] == "defined"
    assert r[1][0] == "my_var"
    assert r[1][1] == "is"
    assert r[1][2] == "undefined"

    s = "my_var is not defined or my_var is not undefined"
    r = c.extract_defined_undefined(s)
    assert r[0][0] == "my_var"
    assert r[0][1] == "is not"
    assert r[0][2] == "defined"

# Generated at 2022-06-23 06:04:55.888936
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # all these variables are defined
    vars = ['test_var', 'test_var1', 'test_var2']


# Generated at 2022-06-23 06:05:04.705442
# Unit test for constructor of class Conditional
def test_Conditional():
    '''
    Validate the base class sets sane defaults, and that an
    exception is raised if the loader parameter is not passed
    in when using the class directly.
    '''

    # check for missing loader
    try:
        x = Conditional()
        assert False
    except AnsibleError as e:
        assert "loader" in str(e)

    # check default attributes
    x = Conditional(loader=object())
    assert '_when' in dir(x)
    assert x._when is None
    assert '_loader' in dir(x)
    assert isinstance(x._loader, object)


# Generated at 2022-06-23 06:05:14.257542
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Create new instance of class Conditional for testing
    conditional = Conditional()

    # Test for conditional including is defined
    conditional_to_test = "cond_var is defined"
    cond_1 = conditional.extract_defined_undefined(conditional_to_test)
    assert cond_1 == [('cond_var', 'is', 'defined')]

    # Test for conditional including is undefined
    conditional_to_test = "cond_var is undefined"
    cond_2 = conditional.extract_defined_undefined(conditional_to_test)
    assert cond_2 == [('cond_var', 'is', 'undefined')]

    # Test for conditional including is not defined
    conditional_to_test = "cond_var not is defined"

# Generated at 2022-06-23 06:05:15.580803
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional(loader = None)
    assert conditional is not None


# Generated at 2022-06-23 06:05:22.143914
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    # Create loader
    loader = DataLoader()

    # Create dummy inventory
    inventory = Inventory(loader=loader, variable_manager=None, host_list=[])
    group = Group('all')
    host = Host(name='foohost')
    inventory.add_group(group)
    inventory.add_host(host)
    inventory.set_variable_manager()

    # Create context
    play_context = PlayContext()
    play_context.inventory = inventory
    play_context.variable_manager = inventory

# Generated at 2022-06-23 06:05:32.752938
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    C.HOST_VARS = {
        'localhost': {
            'foo': {
                'bar': 'baz'
            }
        },
        'example.org': {
            'foo': {
                'bar': 'baz'
            }
        }
    }

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={}, shared_loader_obj=None)

    assert Conditional().evaluate_conditional(templar, dict()) == True
    assert Conditional().evaluate_conditional(templar, dict(a=dict(b=dict(c='foo')))) == True

# Generated at 2022-06-23 06:05:42.849063
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars.reserved import Reserved
    from ansible.vars.manager import VariableManager
    from ansible.template.safe_eval import safe_eval

    reserved = Reserved()
    variable_manager = VariableManager(loader=None, variables=reserved.keys())

    c = Conditional()
    c._loader = 'foo'
    c._hosts = 'all'

    # Test evaluate_conditional
    templar = c._loader.get_basedir_loader('.')

    class FakeOptions():
        def __init__(self):
            self.tags = []
            self.skip_tags = []
            self.check = False

    class FakeInventory():
        def __init__(self):
            self.host_vars = {}
            self.groups = []


# Generated at 2022-06-23 06:05:54.344775
# Unit test for constructor of class Conditional
def test_Conditional():
    from units.mock.loader import DictDataLoader
    loader = DictDataLoader({
        "foo": """
        ---
        - hosts:
            - localhost
          tasks:
            - test1:
                - name: test1
                  when:
                    - "'localhost' in groups['local']"
                    - "'localhost' not in groups['local']"
        """
    })

    result = Conditional(loader=loader)
    assert 'test1' == result.name
    assert 'localhost' == result.inventory_hostname()
    assert 'localhost' not in result.inventory_hostname_short()
    assert len(result.when) == 2
    assert hasattr(result, '_ds')
    assert hasattr(result, '_loader')
    assert hasattr(result, "_play")

# Generated at 2022-06-23 06:05:56.244334
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c
    assert len(c._when) == 0


# Generated at 2022-06-23 06:06:00.970112
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.role_include import IncludeRole
    include = IncludeRole()
    results = include.extract_defined_undefined("foo is defined and bar is undefined")
    assert results == [("foo", "is", "defined"), ("bar", "is", "undefined")]

# Generated at 2022-06-23 06:06:11.607363
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    class TestConditional:
        _ds = None
        when = None
        _loader = None

        def __init__(self, when_value=None):
            self.when = when_value

    class TestHost:
        get_vars = None

        def __init__(self, get_vars_value=None):
            self.get_vars = get_vars_value

        def get_variable_data(self):
            return self.get_vars

        def get_name(self):
            return 'TestHost'

    class TestPlay:
        def __init__(self, get_vars_value=None):
            self.hosts = dict()
            self.hosts['TestHost'] = TestHost(get_vars_value)


# Generated at 2022-06-23 06:06:15.245768
# Unit test for constructor of class Conditional
def test_Conditional():
    cond = Conditional()
    assert(cond is not None)

# Unit test when property of class Conditional

# Generated at 2022-06-23 06:06:26.044998
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import ansible.playbook.play_context
    import ansible.template.template

    # simple play context for testing purposes

# Generated at 2022-06-23 06:06:29.755262
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional(loader='')
    assert conditional.when is not None



# Generated at 2022-06-23 06:06:31.443060
# Unit test for constructor of class Conditional
def test_Conditional():
    with pytest.raises(AnsibleError):
        c = Conditional()


# Generated at 2022-06-23 06:06:36.186362
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    conditional.when = ["Ansible"]
    assert len(conditional.when) == 1, "should have one conditional"
    assert conditional.when[0] == "Ansible"

# Generated at 2022-06-23 06:06:45.356800
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import pytest
    from ansible.playbook.base import Base

    # Mixin class Conditional with a dummy class
    class Test(Base, Conditional):
        pass

    # Make Test class conditional with the conditional statement
    Test._when = ['''{{ (ansible_os_family == 'RedHat' and ansible_distribution_major_version == '7') or (ansible_os_family == 'Debian' and ansible_distribution_major_version == '8') or (ansible_os_family == 'SUSE' and ansible_distribution_major_version == '12') }}''']
    # Dummy variable used for evaluating conditional
    test_vars = {'ansible_os_family': 'Debian', 'ansible_distribution_major_version': '8'}

    test_conditional = Test()

# Generated at 2022-06-23 06:06:48.184690
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    import ansible.template
    templar = ansible.template.Templar()
    all_vars = dict()
    conditional.evaluate_conditional(templar, all_vars)


# Generated at 2022-06-23 06:06:54.926404
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    This method tests the behavior of method extract_defined_undefined.
    '''
    conditional = Conditional()
    assert conditional.extract_defined_undefined('') == []
    assert conditional.extract_defined_undefined('hostvars[foo] is defined') == [['hostvars[foo]', 'is', 'defined']]
    assert conditional.extract_defined_undefined('bar is undefined') == [['bar', 'is', 'undefined']]
    assert conditional.extract_defined_undefined('hostvars[foo] is defined and foo is undefined') == [['hostvars[foo]', 'is', 'defined'], ['foo', 'is', 'undefined']]

# Generated at 2022-06-23 06:06:59.036570
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert hasattr(conditional, '_when')
    assert hasattr(conditional, '_loader')
    assert hasattr(conditional, 'when')
    assert conditional._when == []
    assert conditional.when == []


# Generated at 2022-06-23 06:07:10.431019
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

# Generated at 2022-06-23 06:07:19.558919
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.base import Base
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class Dummy(Conditional, Base):
        pass

    dummy = Dummy(play_context=PlayContext())
    all_vars = dict()
    dummy._templar = Templar(loader=None, variables=all_vars)

    assert dummy.evaluate_conditional(dummy._templar, all_vars) is True, 'Dummy should always return True'

    all_vars = dict(
        foo=10,
        bar=20,
    )
    dummy._templar = Templar(loader=None, variables=all_vars)

    dummy.when = '{{ foo == 10 }}'

# Generated at 2022-06-23 06:07:21.516312
# Unit test for constructor of class Conditional
def test_Conditional():
    loader = DictDataLoader({})
    conditional = Conditional(loader=loader)

    assert conditional._when == []

# Generated at 2022-06-23 06:07:33.284818
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    This method is called to test evaluate_conditional method of Conditional class.
    '''
    import unittest
    import tempfile
    import os

    try:
        from ansible.module_utils.six import StringIO
    except ImportError:
        from io import StringIO

    class TestConditional(Conditional):
        pass

    class TestConditional(unittest.TestCase):

        def setUp(self):
            self.d = TestConditional()

        def tearDown(self):
            pass

        def _write_test_templates(self, when_str='True', vars_str=None):
            d = tempfile.mkdtemp()
            when_path = os.path.join(d, 'when')

# Generated at 2022-06-23 06:07:44.024815
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestConditional(Conditional):
        _when = []
        _loader = None

    # Test values of self.when
    # Test 1: self.when contains a string with a boolean value
    test_1 = TestConditional()
    test_1.when = [True]
    result = test_1.evaluate_conditional(None, None)
    assert result

    # Test 2: self.when contains a string with a boolean value
    test_2 = TestConditional()
    test_2.when = ["True"]
    result = test_2.evaluate_conditional(None, None)
    assert result

    # Test 3: self.when contains a string with a boolean value
    test_3 = TestConditional()
    test_3.when = [False]

# Generated at 2022-06-23 06:07:51.512066
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('foo is defined and bar is defined') == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo is not defined and bar is defined') == [('foo', 'is not', 'defined'), ('bar', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo is undefined or bar is defined') == [('foo', 'is', 'undefined'), ('bar', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert conditional

# Generated at 2022-06-23 06:08:01.448229
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.module_utils.six import PY3

    class ConditionalClass(Conditional):
        def __init__(self, when="", vars=""):
            self._ds = None
            self._loader = None
            self._vars = vars
            self.when = when

    # test with a single string
    conditional = ConditionalClass(when="testvar")
    all_vars = dict(testvar="testvalue")
    templar = Templar(loader=None, variables=all_vars)
    result = conditional.evaluate_conditional(templar=templar, all_vars=all_vars)
    assert result

    # test with a

# Generated at 2022-06-23 06:08:04.158251
# Unit test for constructor of class Conditional
def test_Conditional():
    # Create a Conditional instance
    Conditional()
    # Create a Conditional instance with loader object
    Conditional(loader='test_loader')

# Generated at 2022-06-23 06:08:06.663545
# Unit test for constructor of class Conditional
def test_Conditional():
    '''
    Constructor of class `Conditional`
    '''

    obj = Conditional()
    assert hasattr(obj, '_when')



# Generated at 2022-06-23 06:08:13.444866
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    display = Display()
    c = Conditional()
    # this is a simple test case to help me test and
    # debug the code
    # NOTE: This is just a sample, not a full test suite
    #
    # class PlayContext:
    #     variables = {}
    #     def __init__(self):
    #         self.variables = {}
    #
    # c = Conditional()
    # c.when = ['a']
    # context = PlayContext()
    # context.variables = {'a':True, 'b':False}
    # #context.variables = {'b':False}
    # #context.variables = {'a':False}
    # print c.evaluate_conditional(context)


# Generated at 2022-06-23 06:08:24.248693
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:08:35.988518
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.plugins.loader import connection_loader
    from ansible.inventory.manager import InventoryManager
    import jinja2
    import os

    env = jinja2.Environment(loader=jinja2.DictLoader({'inventory_file': 'localhost ansible_connection=local ansible_python_interpreter=/usr/bin/python'}))
    host_vars = HostVars(play=None)
    host_vars.set_variable('hostvars', host_vars, priority=100)

# Generated at 2022-06-23 06:08:44.023261
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    class TestConditional(Conditional):
        pass

    p = PlayContext()
    v = VariableManager()
    t = Templar(vars=v, loader=None)

    try:
        tc = TestConditional()
        raise Exception("Constructor of class conditional did not throw exception for missing loader argument")
    except AnsibleError:
        pass

    tc = TestConditional(loader=None)

    p.update_vars({'test_var': 'test'})
    v.update_vars({"test_var": "test"})

    assert not tc.evaluate_conditional(t, p.get_all_vars())

# Generated at 2022-06-23 06:08:56.034310
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing import DataLoader

    # load from the unit tests YAML files
    loader = DataLoader()

    # Example data to test exceptions (subject to change)
    # dict(when=["{{ 'string_without_exception' in x }}"])
    # dict(when=["{{ 'string with exception' in x }}"])
    # dict(when=["{{ my_var.method_that_doesnt_exists() }}"])
    # dict(when=["{{ my_var['key_that_doesnt_exists'] }}"])
    # dict(when=["{{ my_list[12] }}"])
    # dict(when=["{{ 'my_string' | my_filter }}"])
    # dict(when=["{{ 'my_string' | my_filter_that_doesnt_

# Generated at 2022-06-23 06:09:07.493497
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    loader = None

    # True

    c = Conditional(loader=loader)
    c.when = "hello"
    ret = c.evaluate_conditional(c, dict(hello='world'))
    assert ret

    c = Conditional(loader=loader)
    c.when = 42
    ret = c.evaluate_conditional(c, dict())
    assert ret

    # False

    c = Conditional(loader=loader)
    c.when = ""
    ret = c.evaluate_conditional(c, dict())
    assert not ret

    c = Conditional(loader=loader)
    c.when = 0
    ret = c.evaluate_conditional(c, dict())
    assert not ret

    c = Conditional(loader=loader)
    c.when = "{{ undefined }}"
    ret = c.evaluate_

# Generated at 2022-06-23 06:09:08.336325
# Unit test for constructor of class Conditional
def test_Conditional():
    Conditional()

# Generated at 2022-06-23 06:09:17.617410
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.play import Play

    # test the different conditional types
    # test empty conditional
    t = Conditional()
    assert t.evaluate_conditional(None, None)

    # test a string conditional
    t = Conditional()
    t._when = FieldAttribute(isa='list', default=list, extend=True, prepend=True)
    t._when.append("foo")
    assert not t.evaluate_conditional(None, { "foo": False })
    assert not t.evaluate_conditional(None, { "foo": 0 })
    assert not t.evaluate_conditional(None, { "foo": "" })
    assert t.evaluate_conditional(None, { "foo": True })
    assert t.evaluate_conditional(None, { "foo": 1 })

# Generated at 2022-06-23 06:09:27.895366
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    myhost = inventory.get_host('localhost')
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=play_context, host=myhost))

    conditional = Conditional()

    # Testing evaluation of expression `'14' in list`
    conditional.when = ['14 in list']
    all_v

# Generated at 2022-06-23 06:09:41.143828
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._extra_vars = {"ansible_distribution": "Ubuntu", "ansible_distribution_version": "14.04", "ansible_os_family": "Debian"}

    templar = Templar(loader=loader, variables=variable_manager)
    c = Conditional(loader=loader)

    # test True variables
    assert c.evaluate_conditional(templar, variable_manager._extra_vars)

    # test False variables
    c = Conditional(when="ansible_os_family == \"Fedora\"")

# Generated at 2022-06-23 06:09:43.257904
# Unit test for constructor of class Conditional
def test_Conditional():
    cond = Conditional()
    assert cond._when is not None

# Generated at 2022-06-23 06:09:52.703263
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Test the function `evaluate_conditional`

    For now we only test invalid conditionals, valid conditionals are tested
    in `test_evaluate_conditional()`
    '''
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Host, Inventory

    # Reset display.verbosity to avoid false-positive when running this unit test
    display.verbosity = 0

    # Create the templar we'll use
    variable_manager = VariableManager()
    loader = variable_manager.loader
    # Create the inventory we'll use
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    # Templating will fail on these invalid conditionals

# Generated at 2022-06-23 06:10:02.563206
# Unit test for constructor of class Conditional
def test_Conditional():
    class TestConditionalClass(object):
        pass

    c = Conditional(TestConditionalClass())
    assert isinstance(c, Conditional)
    assert c.when == []
    assert c.evaluate_conditional(None, None)
    c.when = ['foo']
    assert not c.evaluate_conditional(None, None)
    c.when = []
    assert c.evaluate_conditional(None, None)
    c.when = [None]
    assert c.evaluate_conditional(None, None)
    c.when = [True]
    assert c.evaluate_conditional(None, None)
    c.when = [False]
    assert not c.evaluate_conditional(None, None)
    c.when = ['False']
    assert not c.evaluate_conditional(None, None)

# Generated at 2022-06-23 06:10:13.842826
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    results = Conditional().extract_defined_undefined('hostvars[inventory_hostname]["omero.host"] is undefined')
    assert len(results) == 1
    assert results[0] == ('hostvars[inventory_hostname]["omero.host"]', 'is', 'undefined')

    results = Conditional().extract_defined_undefined('hostvars[inventory_hostname]["omero.host"] is not undefined')
    assert len(results) == 1
    assert results[0] == ('hostvars[inventory_hostname]["omero.host"]', 'is not', 'undefined')

    results = Conditional().extract_defined_undefined('hostvars[inventory_hostname]["omero.host"] is defined')
    assert len(results) == 1

# Generated at 2022-06-23 06:10:24.965446
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

    assert cond.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert cond.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert cond.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert cond.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert cond.extract_defined_undefined('foo is bar is defined') == [('foo is bar', 'is', 'defined')]
    assert cond.extract_defined_undefined('foo not is bar is defined') == [('foo not is bar', 'is', 'defined')]

# Generated at 2022-06-23 06:10:29.161497
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """
    Test evaluate_conditional using the method Conditional.evaluate_conditional()

    These tests verify that evaluate_conditional returns the expected values for
    the various data types that can be passed to it.

    :param self:
    """
    from ansible.playbook.play_context import PlayContext

    from ansible.template import Templar

    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader


    class TestConditional:
        def __init__(self, tester):
            self._tester = tester
            self._loader = DataLoader()
            self._variable_manager = VariableManager()
            self._variable_manager.set_loader('vars', self._loader)
            self._variable_manager.set_loader('hostvars', self._loader)

# Generated at 2022-06-23 06:10:41.679541
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    task_ds = dict(
        when = ['ansible_distribution_version == "7"']
    )

    class FakeTask:
        def __init__(self, ds):
            self._ds = ds

    task = FakeTask(task_ds)

    cond = Conditional(loader=None)
    cond1 = cond._check_conditional(
        conditional='ansible_distribution_version == "7"',
        templar=Templar(loader=None),
        all_vars={ "ansible_distribution_version": "7" }
    )
    assert cond1


# Generated at 2022-06-23 06:10:43.152034
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional=Conditional()
    assert conditional is not None


# Generated at 2022-06-23 06:10:43.683978
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional is not None

# Generated at 2022-06-23 06:10:45.545028
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader

    c = Conditional(DataLoader())
    assert c


# Generated at 2022-06-23 06:10:55.334750
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.task import Task
    from StringIO import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    class TestTask(Conditional, Task):
        pass

    test_task = TestTask()
    test_task.when = ['test_var is true']
    test_task._ds = 'test_task'

    # Create a fake loader obj just to satisfy templating.
    fake_loader = DataLoader()

    # Create a fake inventory, just to satisfy templating.
    class FakeInventory():
        def __init__(self):
            self.hosts = ['localhost']
    fake_inventory = FakeInventory()

    # Create a fake variable manager, just to satisfy templating

# Generated at 2022-06-23 06:11:05.633981
# Unit test for constructor of class Conditional
def test_Conditional():
    # should require a loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task import Task

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager.set_inventory(inventory)
    task_ds = Task()

    # should still require a loader
    try:
        conditional = Conditional()
    except Exception as e:
        if 'a loader must be specified' not in str(e):
            raise Exception("Conditional constructor did not require a loader")
    conditional = Conditional(loader)

    # now, test the conditional in the context of a Task
    task

# Generated at 2022-06-23 06:11:11.337242
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    fake_conditional = Conditional()
    assert(fake_conditional.extract_defined_undefined(
        'dummy is defined or foo is defined and bar is undefined') == [
            ('dummy', 'is', 'defined'),
            ('foo', 'is', 'defined'),
            ('bar', 'is', 'undefined'),
    ])

    assert(fake_conditional.extract_defined_undefined(
        'dummy is not defined and foo is undefined') == [
            ('dummy', 'is not', 'defined'),
            ('foo', 'is', 'undefined'),
    ])


# Generated at 2022-06-23 06:11:23.238082
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    import mock
    import jinja2
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    pc = PlayContext()

    ds = AnsibleBaseYAMLObject()
    ds._ds = {'vars': {}, 'name': 'test_include'}

    with mock.patch('ansible.playbook.conditional.display') as display_mock:
        t = Templar(loader=None, variables={}, context=pc)
        c = Conditional(ds, loader=None)
        c.when = ['1 == 1', '1 == 2']
        # Test when there is no error
        assert c.evaluate_conditional(t, {})


# Generated at 2022-06-23 06:11:32.101127
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    # Test conditions:
    # 1. Evaluate a simple condition.
    # 2. Evaluate a condition in which a variable is an empty \n.
    # 3. Evaluate a condition in which a variable is an empty string.
    # 4. Evaluate a condition in which a variable is an empty string but
    #    the conditional evaluates it to False.
    # 5. Evaluate a condition in which a variable is an empty list.
    # 6. Evaluate a condition in which a variable is an empty list but
    #    the conditional evaluates it to False.
    # 7. Evaluate a condition in which a variable is an empty dictionary.
    # 8. Evaluate a condition in

# Generated at 2022-06-23 06:11:40.244378
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.utils.display import Display
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.template import Templar

    display = Display()

    module_parser = ModuleArgsParser(None, display)
    args = module_parser.parse_args(dict(a=1, b=2), '.name')
    assert args['a'] == 1
    assert args['b'] == 2
    templar = Templar(loader=None, variables=dict(name=args))
    cond = Conditional()
    cond._when = [ 'not a is defined' ]
    cond._templar = templar
    assert cond.evaluate_conditional(templar, dict())



# Generated at 2022-06-23 06:11:44.916188
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText as unsafe_text
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    conditional = Conditional(loader=loader)

    assert conditional._when == list
    assert conditional.when == []

    conditional = Conditional(loader=loader, when=True)

    assert conditional.when == [True]
    assert conditional._when == list

    conditional = Conditional(loader=loader, when=['foo', 'bar', 'baz'])

    assert conditional.when == ['foo', 'bar', 'baz']
    assert conditional._when == list

    # test that when is always a list
    conditional = Conditional(loader=loader, when='hello')

    assert conditional.when == ['hello']
    assert conditional._when == list

   

# Generated at 2022-06-23 06:11:46.907761
# Unit test for constructor of class Conditional
def test_Conditional():
    myConditional = Conditional()
    assert myConditional is not None

# Generated at 2022-06-23 06:11:58.625280
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook import Play
    from ansible.playbook.play import Play as Play_Datastructure
    play = Play.load(dict(
        name = 'test',
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(
                action = dict(
                    module = 'debug',
                    args = 'msg="hello"',
                )
            )
        ]
    ), loader=None, variable_manager=None)
    play_ds = play._entries[0]
    assert Conditional().extract_defined_undefined('hostvars[inventory_hostname] is undefined') == [('hostvars[inventory_hostname]', 'is', 'undefined')]

# Generated at 2022-06-23 06:12:06.729981
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.task_include import TaskInclude
    task_include = TaskInclude()
    task_include.when = ["not ('localhost' in inventory_hostname)"]
    assert (Conditional().extract_defined_undefined(task_include.when[0])) == \
           [("inventory_hostname", "in", "defined")]
    # Check cases when argument conditional is not a string
    task_include.when = [{'something': 'here'}]
    assert (Conditional().extract_defined_undefined(task_include.when[0])) == []
    # Check cases when no regex match is found
    task_include.when = ["hostvars['localhost'].name == 'localhost'"]

# Generated at 2022-06-23 06:12:16.079011
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    my_vars = dict(
        foo="world",
        bar="hello",
        baz="hello world",
        my_var=1,
    )
    variable_manager = VariableManager()
    variable_manager._extra_vars = my_vars
    loader = DataLoader()
    play_context = PlayContext()
    play_context.become_method = 'sudo'
    templar = Templar(loader=loader, variable_manager=variable_manager, shared_loader_obj=None, play_context=play_context)
    assert templar.template("{{ bar }}") == "hello"

# Generated at 2022-06-23 06:12:16.750402
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    assert False

# Generated at 2022-06-23 06:12:29.267833
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars.manager import VarManager

    vars_dict = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
        }
    }

    # generate host vars for host foo
    hostvars = {}
    for key in vars_dict:
        hostvars[key] = vars_dict[key]

    # generate group vars for group bar
    groupvars = {}
    groupvars['group_var'] = 'foo'

    # create VarManager
    var_manager = VarManager()
    var_manager._fact_cache = {'foo': {'ansible_facts': {'g_fact': 'bar'}}}
    var_manager.set_group_vars(groupvars)
   

# Generated at 2022-06-23 06:12:35.144581
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    assert Conditional().evaluate_conditional({'a': 1}, {'a': 1})
    assert not Conditional().evaluate_conditional(dict(), dict())
    assert Conditional().evaluate_conditional({'a': 1}, {'a': 2})
    assert Conditional().evaluate_conditional({'a': 1, 'b': 2}, {'a': 1, 'b': 2})



# Generated at 2022-06-23 06:12:36.018406
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_obj = Conditional()
    assert conditional_obj is not None


# Generated at 2022-06-23 06:12:45.552789
# Unit test for constructor of class Conditional
def test_Conditional():
    module_name = 'Conditional'
    module_path = 'ansible.playbook.%s' % module_name
    _import_module(module_path)
    importlib.invalidate_caches()
    module = import_module(module_path)
    cls = getattr(module, module_name)

    if not hasattr(cls, '_when'):
        print('[FAIL] %s is missing the `_when` attribute' % module_name)
    if not hasattr(cls, '__init__'):
        print('[FAIL] %s is missing the `__init__` method' % module_name)

# Generated at 2022-06-23 06:12:58.032342
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.task import Task

    test_task = Task()
    test_task.when = "{'test': True}"

    from ansible.template import Templar

    test_templar = Templar(variables={'test': True})
    assert test_task.evaluate_conditional(test_templar, {})

    test_templar = Templar(variables={'test': False})
    assert not test_task.evaluate_conditional(test_templar, {})

    test_task.when = ['{test}']

    test_templar = Templar(variables={'test': True})
    assert test_task.evaluate_conditional(test_templar, {})

    test_templar = Templar(variables={'test': False})
    assert not test_task.evaluate_cond

# Generated at 2022-06-23 06:12:59.556270
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional is not None

# Generated at 2022-06-23 06:13:09.710749
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    # test a simple conditional
    defined_undefined_vars = c.extract_defined_undefined('ansible_eth0 is defined')
    assert(1 == len(defined_undefined_vars))
    assert('ansible_eth0' == defined_undefined_vars[0][0])
    assert('is' == defined_undefined_vars[0][1])
    assert('defined' == defined_undefined_vars[0][2])
    # test a complex conditional
    defined_undefined_vars = c.extract_defined_undefined('ansible_eth0 is defined or ansible_eth1 is defined')
    assert(2 == len(defined_undefined_vars))

# Generated at 2022-06-23 06:13:15.127768
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
