

# Generated at 2022-06-23 06:03:10.124093
# Unit test for constructor of class Conditional
def test_Conditional():
    assert Conditional()


# Generated at 2022-06-23 06:03:24.619393
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from jinja2 import Environment

    class Host:
        def __init__(self, port):
            self.port = port

    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    play_context.port = 22
    env = Environment()
    # env.filters.update(C.DEFAULT_FILTERS)  # commented out in favor of direct import
    env.filters['match'] = filter_loader.get('match')
    env.filters['ipaddr'] = filter_loader.get('ipaddr')
    env.filters['netmask'] = filter_loader.get('netmask')
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template.template import Templar


# Generated at 2022-06-23 06:03:30.504233
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    C1 = Conditional()
    r1 = C1.extract_defined_undefined("hostvars[inventory_hostname] is defined")
    assert r1 == [('hostvars[inventory_hostname]', 'is', 'defined')]
    r2 = C1.extract_defined_undefined("hostvars[inventory_hostname] not is undefined and foo is defined")
    assert r2 == [('hostvars[inventory_hostname]', 'not is', 'undefined'), ('foo', 'is', 'defined')]


# Generated at 2022-06-23 06:03:38.406536
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.block import Block

    from ansible.template import Templar
    mock_ds = {
        'vars': {
            'foo': 'bar',
            'bar': 'biz',
            'baz': 'foo',
            'undefined': None,
        }
    }
    mock_vars = {
        'foo': 'bar',
        'bar': 'biz',
        'baz': 'foo',
        'hostvars': {
            'localhost': {
                'foo': 'not bar',
                'undefined': None,
            }
        },
    }
    test_obj = Block()

    test_obj._ds = mock_ds
    test_obj.when = []

    templar = Templar(loader=None, variables=mock_vars)

    # Here are

# Generated at 2022-06-23 06:03:46.089377
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader

    m = Conditional()
    assert m is not None
    from ansible.vars.manager import VariableManager
    vars_manager = VariableManager()
    loader = DataLoader()
    inventory = None
    hosts = [dict(name="example", vars=dict(ansible_connection='local'))]
    play = dict(hosts=hosts)
    tqm = None

    m2 = Conditional(loader)
    assert m2 is not None

# Generated at 2022-06-23 06:03:55.783334
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def test(conditional, expected_results):
        conditional_obj = Conditional()
        results = conditional_obj.extract_defined_undefined(conditional)
        assert results == expected_results, \
            'expected %s, got %s' % (expected_results, results)

    test("(a is defined) and (b is defined)", [('a', 'is', 'defined'), ('b', 'is', 'defined')])
    test("(a is not defined) or (c is defined)", [('a', 'is not', 'defined'), ('c', 'is', 'defined')])
    test("foo.bar is defined", [('foo.bar', 'is', 'defined')])

# Generated at 2022-06-23 06:04:03.382920
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # import some modules needed for unit tests
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    # define the unit tests

# Generated at 2022-06-23 06:04:16.539466
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block

    conditional = Conditional()
    assert conditional is not None
    assert conditional._when == list()

    assert conditional.when is not None
    assert conditional.when == list()

    # test the vars_prompt constructor option
    # conditional = Conditional(vars_prompt={'foo': {'prompt': 'bar', 'private': False}})
    # assert conditional is not None

    # test the vars_files constructor option
    # conditional = Conditional(vars_files=['foo'])
    # assert conditional is not None

    # test the vars_prom

# Generated at 2022-06-23 06:04:29.226468
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    import sys
    if sys.version_info >= (2, 7):
        from unittest import TestCase
    else:
        from unittest2 import TestCase

    # unit test imports
    from ansible.vars import VariableManager
    from ansible.template import Templar

    # test case imports
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.hardware.dmi import DMI
    from ansible.module_utils.facts.hardware.lspci import Lspci
    from ansible.module_utils.facts.network.base import NetworkCollector

    class TestConditional(TestCase):

        def setUp(self):
            self.variable_manager = VariableManager()


# Generated at 2022-06-23 06:04:41.295186
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:04:48.949949
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional(loader=None)
    assert c is not None
    assert c.when is not None
    assert c.when == []
    assert c.evaluate_conditional(None, None) is True
    assert c._check_conditional('foo == "bar"', None, None) is False
    assert c._check_conditional('foo == "foo"', None, None) is True
    assert c._check_conditional('foo.bar == "foo"', None, {'foo': {'bar': 'foo'}}) is True
    assert c._check_conditional('foo.bar == "foo"', None, {'foo': {'bar': 'bar'}}) is False

# Generated at 2022-06-23 06:04:59.521974
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    template_data = '''
    {% if a is defined or b is defined %}
    {% if a is not defined and b is not defined %}
    {% if a is undefined or b is undefined %}
    {% if a is not undefined and b is not undefined %}
    '''

    obj = Conditional()
    result = obj.extract_defined_undefined(template_data)
    assert len(result) == 8
    assert ('a', 'is', 'defined') in result
    assert ('b', 'is', 'defined') in result
    assert ('a', 'is', 'not defined') in result
    assert ('b', 'is', 'not defined') in result
    assert ('a', 'is', 'undefined') in result
    assert ('b', 'is', 'undefined') in result

# Generated at 2022-06-23 06:05:01.476172
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.task import Task

    t = Task()
    assert(t.run_once == False)

# Generated at 2022-06-23 06:05:03.201523
# Unit test for constructor of class Conditional
def test_Conditional():
    Conditional()

# Generated at 2022-06-23 06:05:13.133310
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._extra_vars = {'foo': 'foo_value'}
    inventory = InventoryManager(loader=loader, sources=["localhost"])
    variable_manager.set_inventory(inventory)
    mock_loader, mock_inventory,

# Generated at 2022-06-23 06:05:18.906388
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    import jinja2

    templar = Templar(loader=None, variables=dict())

    my_vars = VariableManager()
    my_vars.extra_vars = {'my_var': 'my_value'}

    # test all the conditions with my_value == "my_value"
    task = Task()

# Generated at 2022-06-23 06:05:21.915298
# Unit test for constructor of class Conditional
def test_Conditional():
    #class_ = Conditional()
    class_ = Conditional(loader=Mock())
    assert isinstance(class_, Conditional)



# Generated at 2022-06-23 06:05:32.594434
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test for boolean condition (True)
    conditional_object = Conditional()
    conditional_object._when = [True]
    vars = dict()
    templar = None
    assert conditional_object.evaluate_conditional(templar, vars) is True

    # Test for boolean condition (False)
    conditional_object = Conditional()
    conditional_object._when = [False]
    vars = dict()
    templar = None
    assert conditional_object.evaluate_conditional(templar, vars) is False

    # Test for None
    conditional_object = Conditional()
    conditional_object._when = [None]
    vars = dict()
    templar = None
    assert conditional_object.evaluate_conditional(templar, vars) is False

    # Test for empty string
   

# Generated at 2022-06-23 06:05:42.250397
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variable_manager=variable_manager, context=play_context)

    # Check whether the variable 'test_variable' is defined and return false (variable is not defined)
    var = {'hostvars': {}}
    result = Conditional().evaluate_conditional(templar, var)
    assert result == False

    # Check if the variable 'test_variable' is defined, and return true (variable is defined). Also check whether the variable 'test_variable2' is not

# Generated at 2022-06-23 06:05:50.434086
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert Conditional().extract_defined_undefined('a is defined and b is undefined') == [('a', 'is', 'defined'), ('b', 'is', 'undefined')]
    assert Conditional().extract_defined_undefined('a isnt defined and b isnt undefined') == [('a', 'isnt', 'defined'), ('b', 'isnt', 'undefined')]
    assert Conditional().extract_defined_undefined('a not is defined and b not is undefined') == [('a', 'not is', 'defined'), ('b', 'not is', 'undefined')]

# Generated at 2022-06-23 06:05:51.187620
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional._when == []

# Generated at 2022-06-23 06:06:02.883718
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test for simple conditional
    conditional = 'play_hosts == "abc"'
    all_vars = dict(play_hosts="abc")
    assert Conditional().evaluate_conditional(conditional, all_vars)

    # Test for simple conditional when variables are not defined
    conditional = 'play_hosts == "abc"'
    all_vars = dict(play_hosts="xyz")
    assert not Conditional().evaluate_conditional(conditional, all_vars)

    # Test for undefined variable in conditional
    conditional = 'play_hosts == "abc"'
    all_vars = dict()
    try:
        Conditional().evaluate_conditional(conditional, all_vars)
    except AnsibleUndefinedVariable as e:
        assert 'play_hosts' in str(e)

    # Test for

# Generated at 2022-06-23 06:06:04.197299
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    print(conditional)

test_Conditional()

# Generated at 2022-06-23 06:06:08.125974
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    # Check if default values work correctly
    assert c._when == list
    c2 = Conditional(loader=None)
    assert c2._when == list


# Generated at 2022-06-23 06:06:16.313569
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    ans = conditional.extract_defined_undefined('f1 is defined and f2 is not defined or f3 is undefined')
    assert ans == [('f1', 'is', 'defined'), ('f2', 'is not', 'defined'), ('f3', 'is', 'undefined')], ans
    ans = conditional.extract_defined_undefined('f1 is defined and f2  is   not  defined or f3 is undefined')
    assert ans == [('f1', 'is', 'defined'), ('f2', 'is not', 'defined'), ('f3', 'is', 'undefined')], ans
    ans = conditional.extract_defined_undefined('f1 is defined and ( f2  is   not  defined or f3 is undefined )')

# Generated at 2022-06-23 06:06:24.637132
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Verify we return all occurences of defined or undefined in a string
    conditional = 'hostvars[inventory_hostname] is defined and x is not defined'
    results = Conditional().extract_defined_undefined(conditional)
    assert results == [('hostvars[inventory_hostname]', 'is', 'defined'), ('x', 'is not', 'defined')]

    # Verify we return empty list if no defined or undefined occurences
    conditional = 'inventory_hostname == target_host'
    results = Conditional().extract_defined_undefined(conditional)
    assert results == []


# Generated at 2022-06-23 06:06:36.303120
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext

    c = Conditional(loader=None)
    # normal initialization, _when should be empty
    assert c._when == []

    # now try initializing with a skip value
    c = Conditional(loader=None, when="some var is defined")
    assert c._when == ['some var is defined']

    # the when value will be templated, so we need to make sure that
    # works as expected, using a 'magic' variable we know will exist
    # in any context
    fake_var = dict(
        magic=dict(
            ansible_python_interpreter=C.DEFAULT_BECOME_METHOD
        )
    )
    pc = PlayContext()
    pc.set_variable_manager(fake_var)

# Generated at 2022-06-23 06:06:47.181527
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    display.verbosity = 3

    class TestConditional(Conditional):
        pass

    tc = TestConditional()
    class TestTemplar:
        def template(self, data, disable_lookups=True, fail_on_undefined=True):
            if data == "TEST_CONDITIONAL":
                raise AnsibleUndefinedVariable("variable 'foobar' is undefined")
            return data
        def is_template(self, data):
            return False
    tt = TestTemplar()

    # test with templates
    tc._when = ["TEST_CONDITIONAL"]
    result = tc.evaluate_conditional(tt, [])
    assert result is False

    # test without templates
    tc._when = ["TEST_CONDITIONAL"]
    result = tc.evaluate_conditional(tt, [])

# Generated at 2022-06-23 06:06:50.741388
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    reducer_funcs = [
        conditional.extract_defined_undefined,
        conditional._check_conditional,
        conditional.evaluate_conditional
    ]
    for func in reducer_funcs:
        try:
            func(None)
            assert False
        except TypeError:
            pass

# Generated at 2022-06-23 06:07:02.391627
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Jinja template rendering
    class MyMockTemplate:
        def __init__(self, value):
            self.value = value
        def render(self, variables):
            if self.value == 'undefined':
                raise AnsibleUndefinedVariable('undefined is undefined')
            else:
                return self.value
    class MyTemplar:
        def __init__(self):
            self.template_class = MyMockTemplate
        def is_template(self, value):
            return True
        def template(self, value):
            return self.template_class(value).render(None)
        def environment(self):
            return None
        def set_available_variables(self, variables):
            pass

# Generated at 2022-06-23 06:07:13.982792
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # mocks
    class MockPlay(object):
        def __init__(self, all_vars):
            self.all_vars = all_vars
        def get_variable_manager(self):
            return self.all_vars
    class MockVariableManager():
        def __init__(self, all_vars):
            self.extra_vars = all_vars
        def get_vars(self, play=None, host=None, task=None, include_delegate_to=True):
            return self.extra_vars
    class MockTemplar():
        def __init__(self):
            self.available_variables = {}
            self.environment = None
        def is_template(self, conditional):
            return False

# Generated at 2022-06-23 06:07:21.461640
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = " ( hostvars['foo'] is defined ) and ( hostvars['bar'] is not defined ) "
    results = Conditional().extract_defined_undefined(cond)
    assert results == [('hostvars[\'foo\']', 'is', 'defined'), ('hostvars[\'bar\']', 'is not', 'defined')]
    cond = " ( hostvars['foo'] is not defined ) "
    results = Conditional().extract_defined_undefined(cond)
    assert results == [('hostvars[\'foo\']', 'is not', 'defined')]
    cond = " ( hostvars['foo'] is defined )  "
    results = Conditional().extract_defined_undefined(cond)
    assert results == [('hostvars[\'foo\']', 'is', 'defined')]

# Generated at 2022-06-23 06:07:33.282896
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import sys
    if sys.version_info < (2, 7):
        # Skip tests on Python 2.6 because unittest.skip doesn't support 'reason'
        return

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template.template import Templar

    from ansible.playbook.base import Base
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude


# Generated at 2022-06-23 06:07:44.024614
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.plugins.loader import module_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    # dummy variables for templar
    display = Display()
    variables = dict()
    loader = DataLoader()
    templar = Templar(loader, variables, hostvars=dict())

    # create test cases (conditional string, expected result)

# Generated at 2022-06-23 06:07:51.512090
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()


# Generated at 2022-06-23 06:08:01.449038
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # 1. Test when conditional contains no reference to defined, undefined
    conditional = "ansible_facts['os_family'] == 'RedHat'"
    c = Conditional()
    assert c.extract_defined_undefined(conditional) == []

    # 2. Test when conditional contains single reference to defined, undefined
    conditional = "hostvars[inventory_hostname]['my_var'] is defined"
    c = Conditional()
    expected_result = [("hostvars[inventory_hostname]['my_var']", "is", "defined")]
    assert c.extract_defined_undefined(conditional) == expected_result

    # 3. Test when conditional contains multiple reference to defined, undefined

# Generated at 2022-06-23 06:08:11.054499
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()


# Generated at 2022-06-23 06:08:22.505771
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()

    # test is_template method
    assert conditional.is_template(conditional)

    # test environment
    assert conditional.environment == None

    # test extract_defined_undefined method
    assert conditional.extract_defined_undefined('a b is defined') == [('a b', 'is', 'defined')]
    assert conditional.extract_defined_undefined('a b is not undefined') == [('a b', 'is not', 'undefined')]
    assert conditional.extract_defined_undefined('a b not is defined') == [('a b', 'not is', 'defined')]
    assert conditional.extract_defined_undefined('a b not is undefined') == [('a b', 'not is', 'undefined')]

    # test evaluate_conditional method
    assert conditional.evaluate_cond

# Generated at 2022-06-23 06:08:31.464953
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # NOTE: This is not a complete unit test, and it only tests successful evaluations
    #       of a conditional. A complete unit test would also include evaluating
    #       conditionals with undefined variables, invalid conditional syntax, etc.

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

    all_vars = dict()

    loader = DataLoader()
    inventory = Inventory(loader, host_list=[])
    templar = Templar(loader=loader, variables=all_vars)

    display.verbosity = 3

    # setup test inventory objects
    host1 = Host(name="host1")

# Generated at 2022-06-23 06:08:43.235717
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Here we test the method evaluate_conditional of class Conditional.
    '''
    import sys
    sys.path.append('/usr/share/ansible_plugins/callback/')
    from ansible.plugins.callback.default import CallbackModule
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar

    context = PlayContext()
    callback = CallbackModule()

    context = PlayContext()
    callback = CallbackModule()

    context.remote_addr = '127.0.0.1'
    context.connection = 'ssh'
    context.accelerate = 0
    context.network_os = 'default'

    context.become = False
    context.become_method = 'sudo'


# Generated at 2022-06-23 06:08:44.260905
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional.when == []

# Generated at 2022-06-23 06:08:56.383596
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.base import Base
    def Constructor():
        obj = Base()
        obj.__class__ = type('Condtional', (Conditional,), obj.__dict__)
        return obj

    conditional = Constructor()

    assert conditional.extract_defined_undefined('hostvars["foo"] is undefined') == [('hostvars["foo"]', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('hostvars["foo"] is defined') == [('hostvars["foo"]', 'is', 'defined')]
    assert conditional.extract_defined_undefined('hostvars["foo"] not is undefined') == [('hostvars["foo"]', 'not is', 'undefined')]

# Generated at 2022-06-23 06:09:04.267943
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # test value of variable
    class Options(object):
        preset_var = None
    options = Options()

    variable_manager = None
    loader = None
    inventory = None
    play_context = PlayContext(variable_manager=variable_manager, loader=loader, options=options, inventory=inventory)
    templar = Templar(loader=loader, variables=play_context.variables)

    # test class derived from Conditional
    class Test(Conditional):
        pass

    test = Test(loader=loader)

    # test variables
    all_vars = dict(
        test_string='test_string_value',
        test_boolean=True
    )

    # test conditionals
    assert test.evaluate_conditional

# Generated at 2022-06-23 06:09:05.181395
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c.when is None

# Generated at 2022-06-23 06:09:16.565788
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class MyTask(Conditional):
        def __init__(self):
            super(MyTask, self).__init__()
            self.when = ['b', 'd or e']
            self.when_not = ['c', 'a or e']

    loader = DataLoader()
    variables = VariableManager()
    templar = Templar(loader=loader, variables=variables)

    vars = {
        'a': [1,2,3],
        'b': [0],
        'c': [1,2,3],
        'd': '',
        'e': 'foo',
    }
    mytask = MyTask()
    mytask._

# Generated at 2022-06-23 06:09:28.230630
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    class TestClass(Conditional):
        def __init__(self, when):
            super(TestClass, self).__init__(None)
            self.when = when

    all_vars = dict(testvar='hello', testdict=dict(testvar=True), list=[])

    assert TestClass("testdict.testvar").evaluate_conditional(None, all_vars)
    assert TestClass("testvar == 'hello'").evaluate_conditional(None, all_vars)
    assert not TestClass("testdict.testvar == True").evaluate_conditional(None, all_vars)
    assert TestClass("not testdict.testvar").evaluate_conditional(None, all_vars)


# Generated at 2022-06-23 06:09:41.180401
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond_true = "var is defined"
    cond_false = "var1 is not defined"
    cond_false_not_defined = "var3 is undefined"
    cond_true_mixed = "var2 is not defined and var4 is defined"
    cond_false_mixed = "var5 is undefined and var6 is not defined"
    cond_false_mixed_not_defined = "var7 is defined and var8 is not undefined"
    cond_true_hostvars = "hostvars['example.com'] is defined"

    cond = Conditional()
    assert cond.extract_defined_undefined(cond_true) == [('var', 'is', 'defined')]
    assert cond.extract_defined_undefined(cond_false) == [('var1', 'is not', 'defined')]
    assert cond

# Generated at 2022-06-23 06:09:44.438649
# Unit test for constructor of class Conditional
def test_Conditional():

    class TestConditional(object):
        pass

    # Use a Conditional class as a mix-in class
    class TestCond1(Conditional,TestConditional):
        def __init__(self):
            super(TestCond1, self).__init__()
    x = TestCond1()

    class TestCond2(Conditional):
        def __init__(self):
            super(TestCond2, self).__init__()
    y = TestCond2()

    return None


# Generated at 2022-06-23 06:09:52.880393
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(Inventory(loader=loader))
    variable_manager.extra_vars = {'test': 0}
    # testing when conditional
    conditional = Conditional()
    conditional._when = [
        'a.b == 3',
        #'c.d == 4'
    ]
    conditional._loader = loader

    templar = Templar(loader=conditional._loader, variables=variable_manager)

    if condition.evaluate_conditional(templar, variable_manager.get_vars()):
        print("Condtion is true")
    else:
        print("Condtion is false")



# Generated at 2022-06-23 06:10:02.564061
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    def test_conditional(conditional, variables=None):
        '''
        Method for running tests on method evaluate_conditional of class Conditional.
        A fake play context is generated for play testing.
        Optional variables are added to the fake play context.
        '''
        zerodict = {}
        variables = variables if variables else zerodict
        C.DEFAULT_HASH_BEHAVIOUR = "merge"
        context = PlayContext()
        context._attributes['inventory'] = None
        context._attributes['name'] = 'fake'
        context._attributes['_use_task_vars'] = True
        context._attributes['_use_unsafe_shell'] = True

# Generated at 2022-06-23 06:10:03.946404
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional is not None

# Generated at 2022-06-23 06:10:07.954330
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    test_conditional = "a is defined and b is undefined"
    assert c.extract_defined_undefined(test_conditional) == [('a', ' is ', 'defined'), ('b', ' is ', 'undefined')]


# Generated at 2022-06-23 06:10:15.824459
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Unit test for method evaluate_conditional of class Conditional
    '''

    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=dict(test_var='test', test_list=['1', '2', '3']))

    cond = Conditional()
    cond.when = [dict(ansible_facts=dict(ansible_os_family='Debian'))]

    assert not cond.evaluate_conditional(templar, dict())

    cond = Conditional()

    cond.when = ['{{ test_var }}']

# Generated at 2022-06-23 06:10:22.984547
# Unit test for constructor of class Conditional
def test_Conditional():
    class TestClass:
        pass
    tc = TestClass()
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    loader = DataLoader()
    variable_manager = VariableManager()
    cond = Conditional(loader)
    cond.add_to_class(tc)
    assert not tc.evaluate_conditional(variable_manager, variable_manager.get_vars(loader=loader, play=None, include_cache=True), 'foo')

# Generated at 2022-06-23 06:10:34.844211
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("") == []
    assert cond.extract_defined_undefined("A is B") == []
    assert cond.extract_defined_undefined("A is defined") == [("A", "is", "defined")]
    assert cond.extract_defined_undefined("A is not defined") == [("A", "is not", "defined")]
    assert cond.extract_defined_undefined("A is undefined") == [("A", "is", "undefined")]
    assert cond.extract_defined_undefined("A is not undefined") == [("A", "is not", "undefined")]

# Generated at 2022-06-23 06:10:37.803180
# Unit test for constructor of class Conditional
def test_Conditional():
    try:
        Conditional()
    except Exception as e:
        assert 'a loader must be specified when using Conditional' in str(e)

# Generated at 2022-06-23 06:10:42.321916
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.play_context import PlayContext

    class Checker(object):
        def __init__(self, data):
            self.data = data

        def __getattr__(self, name):
            try:
                return self.data[name]
            except KeyError:
                raise AttributeError("Checker has no attribute %s" % name)

    class Base(Conditional):
        def __init__(self):
            self.when = []

    class Task(Base):
        pass

    class Play(Base):
        pass

    class Playbook(Base):
        pass

    import jinja2
    loader = jinja2.DictLoader({})

    # Basic check of booleans
    play_context = PlayContext()

# Generated at 2022-06-23 06:10:53.633894
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # setup
    conditional = Conditional()

    # test 1: simple undefined conditional
    res1 = conditional.evaluate_conditional('foo is undefined', {'foo': 'bar'})

    assert res1 is False

    # test 2: simple defined conditional
    res2 = conditional.evaluate_conditional('foo is defined', {'foo': 'bar'})

    assert res2 is True

    # test 3: multiple defined and undefined conditionals
    res3 = conditional.evaluate_conditional('foo is defined and bar is undefined', {'foo': 'bar'})

    assert res3 is False

    # test 4: a conditional that contains a parameter
    res4 = conditional.evaluate_conditional('item in {{test_list}}', {'test_list': ['item1', 'item2']})

    assert res4 is True

    # test 5: a conditional

# Generated at 2022-06-23 06:11:04.027990
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    vars = c.extract_defined_undefined(conditional="""
        a is defined and
        not (b is defined) and
        hostvars['c'] is defined and
        not (hostvars['d'] is defined and hostvars['e'] is not defined) and
        (f is defined or g is defined)
    """)
    assert vars == [
             ('a', 'is', 'defined'),
             ('b', 'is', 'defined'),
             ('hostvars[\'c\']', 'is', 'defined'),
             ('hostvars[\'d\']', 'is', 'defined'),
             ('hostvars[\'e\']', 'is', 'not defined'),
             ('g', 'is', 'defined')
    ], vars

# Generated at 2022-06-23 06:11:15.479883
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    tests = [
        ('hostvars[i] is undefined', [('hostvars[i]', 'is', 'undefined')]),
        ('hostvars[i] is not defined', [('hostvars[i]', 'is not', 'defined')]),
        ('hostvars[i] is not defined and hostvars["ansible_facts"]["ansible_eth0"]["address"] is not undefined',
            [('hostvars[i]', 'is not', 'defined'), ('hostvars["ansible_facts"]["ansible_eth0"]["address"]', 'is not', 'undefined')]),
    ]
    c = Conditional()
    for t in tests:
        assert c.extract_defined_undefined(t[0]) == t[1]



# Generated at 2022-06-23 06:11:27.107087
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Note: Set the following flag to True for verbose output
    do_debug = False
    #
    # AnsibleError should be raised for conditionals with invalid Jinja2 syntax
    #
    conditional = '{{ foo }'
    try:
        cond = Conditional()
        cond.when = [conditional]
        cond.evaluate_conditional(None, None)
        assert False, 'AnsibleErrorException not raised'
    except AnsibleError:
        if do_debug:
            print('Successfully caught AnsibleError exception')
    #
    # AnsibleError should be raised for conditionals with invalid 'defined/undefined' Jinja2 syntax
    #
    conditional = 'foo is defined'

# Generated at 2022-06-23 06:11:37.097373
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    # Test if it returns a dictionary which contains one key
    assert len(c.extract_defined_undefined('this_one is defined')) == 1
    # Test if it returns a dictionary which contains two keys
    assert len(c.extract_defined_undefined('this_one not is defined and this_two is defined')) == 2
    # Test if it returns a dictionary with a hostvar
    assert c.extract_defined_undefined('hostvars[inventory_hostname] is not defined') == [('hostvars[inventory_hostname]', 'is not', 'defined')]
    # Test if it returns a dictionary with a key not following the defined_vars pattern

# Generated at 2022-06-23 06:11:46.527748
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    from ansible.playbook.task_include import TaskInclude

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    t = Templar(loader=loader, variables=variable_manager.get_vars(play=None, host=inventory.get_hosts()[0]))

    t_none = TaskInclude()
    t_none.__dict__.update(
        {
            '_ds': {
                'key': 'value',
            },
        }
    )


# Generated at 2022-06-23 06:11:48.081230
# Unit test for constructor of class Conditional
def test_Conditional():
    # initial result
    assert '_when' in Conditional().__dict__

# Generated at 2022-06-23 06:12:00.221186
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.set_inventory(inventory)

    hostvars = variable_manager.get_vars(play=None, host=inventory.get_host("foobar"), include_hostvars=True)
    templar = Templar(loader=loader, variables=hostvars)

    conditional = Conditional()

    # Test valid and invalid inputs

# Generated at 2022-06-23 06:12:11.104141
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.plugins.loader import action_loader, lookup_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[constants.DEFAULT_HOST_LIST])
    variable_

# Generated at 2022-06-23 06:12:12.912423
# Unit test for constructor of class Conditional
def test_Conditional():
    assert type(Conditional(_loader=None)) == Conditional

# Generated at 2022-06-23 06:12:20.456832
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    # TODO: move this/these to a test class
    import unittest

    class TestExtractDefinedUndefined(unittest.TestCase):

        def test_classic_input(self):
            """Check that the classic input works fine."""

            cond = Conditional()

            # classic input
            conditional = '"foo" is defined'
            expected = [('foo', 'is', 'defined')]

            results = cond.extract_defined_undefined(conditional)

            self.assertEqual(results, expected,
                             "Extracted defined undefined from '{0}'. Got\n'{1}'\ninstead of\n'{2}'"
                             .format(conditional, results, expected))


# Generated at 2022-06-23 06:12:24.920466
# Unit test for constructor of class Conditional
def test_Conditional():
    # Make sure the constructor works
    from ansible.playbook.play_context import PlayContext
    c = Conditional(loader=None)
    assert c._loader is None
    c = Conditional(loader=PlayContext())
    assert c._loader is not None

# Generated at 2022-06-23 06:12:33.348190
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    p = PlayContext()
    t = Templar(loader=None, variables=dict(a='a'), play_context=p)

    # Test with an empty conditional
    x = Conditional()
    result = x.evaluate_conditional(t, dict())
    assert result == True
    x.when = ''
    result = x.evaluate_conditional(t, dict())
    assert result == True
    x.when = None
    result = x.evaluate_conditional(t, dict())
    assert result == True

    # Test with correct conditional
    x = Conditional()
    x.when = 'a == "a"'
    result = x.evaluate_conditional(t, dict())
    assert result == True

# Generated at 2022-06-23 06:12:43.868699
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

    assert c.extract_defined_undefined(None)                  == []
    assert c.extract_defined_undefined(False)                 == []
    assert c.extract_defined_undefined(True)                  == []
    assert c.extract_defined_undefined("")                    == []
    assert c.extract_defined_undefined("a")                   == []
    assert c.extract_defined_undefined("a is defined")        == [('a', 'is', 'defined')]
    assert c.extract_defined_undefined("a is not defined")    == [('a', 'is not', 'defined')]
    assert c.extract_defined_undefined("a is undefined")      == [('a', 'is', 'undefined')]
    assert c.extract_defined_und

# Generated at 2022-06-23 06:12:55.685526
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert c.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert c.extract_defined_undefined("foo       is         not        defined") == [("foo", "is not", "defined")]
    assert c.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-23 06:13:09.155720
# Unit test for method extract_defined_undefined of class Conditional