

# Generated at 2022-06-23 06:03:26.411770
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-23 06:03:36.539212
# Unit test for constructor of class Conditional
def test_Conditional():

    # b_obj is an object with a when attribute
    class b_obj():
        def __init__(self):
            self.when = []

    # The instantiation of class Conditional should store the loader in the _loader
    # attribute of the b_obj class. The return value of this should be the b_obj
    # object.
    loader = 'fake_loader'
    test_obj = Conditional(loader)
    assert test_obj.__class__.__name__ == 'Conditional'
    assert test_obj._loader == 'fake_loader'

    # Now lets just test the constructor of class Conditional (called in __init__).
    # This is for the case where a Conditional object is instantiated and it does
    # not have a loader passed to it (b_obj2). This should throw a AnsibleError.

# Generated at 2022-06-23 06:03:47.227182
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    conditional_str = "A is defined and B is defined or C not in list and D is defined"
    def_undef_list = conditional.extract_defined_undefined(conditional_str)
    assert def_undef_list == \
    [('A', 'is', 'defined'), ('B', 'is', 'defined'), ('C', 'not in', 'list'), ('D', 'is', 'defined')]
    conditional_str2 = "A is defined and B is defined or not (C not in list and D is defined)"
    def_undef_list2 = conditional.extract_defined_undefined(conditional_str2)

# Generated at 2022-06-23 06:03:53.888210
# Unit test for constructor of class Conditional
def test_Conditional():
    # create object which mixes in Conditional
    class ConditionalTest(Conditional):
        pass

    # dummy loader
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    templar = Templar(loader=None, variables={}, shared_loader_obj=None, vault_secrets=VaultLib())
    c = ConditionalTest(loader=templar)

    assert c._when == []

    # test when field
    c.when = 'some when condition'
    assert c._when == ['some when condition']
    c.when = ['some when condition']
    assert c._when == ['some when condition']

# Generated at 2022-06-23 06:03:55.055613
# Unit test for constructor of class Conditional
def test_Conditional():
    t = Conditional()
    assert t is not None

# Generated at 2022-06-23 06:04:05.752723
# Unit test for constructor of class Conditional
def test_Conditional():
    class BaseClass:
        def __init__(self):
            pass

    class ClassNeedLoader(BaseClass, Conditional):
        def __init__(self):
            super(ClassNeedLoader, self).__init__()

    class ClassHasLoader(BaseClass, Conditional):
        def __init__(self):
            super(ClassHasLoader, self).__init__(loader=None)
            self._loader = None

    loader = "abc"
    classNeedLoader = ClassNeedLoader()
    classHasLoader = ClassHasLoader()
    try:
        classNeedLoader.evaluate_conditional(loader, {})
    except:
        pass
    else:
        print("Fail")
    classNeedLoader = ClassNeedLoader(loader)

# Generated at 2022-06-23 06:04:17.923943
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    c = Conditional()

    def test_helper(cond, result):
        r = c.extract_defined_undefined(cond)
        assert r == result, "%s != %s" % (r, result)

    test_helper("foobar is defined", [('foobar', 'is', 'defined')])
    test_helper("foobar is not defined", [('foobar', 'is not', 'defined')])

    test_helper("foobar is undefined", [('foobar', 'is', 'undefined')])
    test_helper("foobar is not undefined", [('foobar', 'is not', 'undefined')])


# Generated at 2022-06-23 06:04:30.271262
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:04:31.958861
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c.when is not None


# Generated at 2022-06-23 06:04:33.240574
# Unit test for constructor of class Conditional
def test_Conditional():
    # TODO: write this
    pass

# Generated at 2022-06-23 06:04:43.387165
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    cond_defined  = "ansible_os_family is defined"
    cond_undefined = "ansible_os_family is undefined"
    cond_not_defined  = "ansible_os_family is not defined"
    cond_not_undefined = "ansible_os_family is not undefined"

    assert Conditional().extract_defined_undefined(cond_defined) == [ ('ansible_os_family','is','defined') ]
    assert Conditional().extract_defined_undefined(cond_undefined) == [ ('ansible_os_family','is','undefined') ]
    assert Conditional().extract_defined_undefined(cond_not_defined) == [ ('ansible_os_family','is not','defined') ]

# Generated at 2022-06-23 06:04:50.621899
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    class TestConditional(Conditional):
        pass

    tc = TestConditional()
    all_vars = dict(a='a', b='b', c='c')
    templar = PlayContext(variable_manager=dict())
    templar.set_available_variables(all_vars)


# Generated at 2022-06-23 06:04:52.847901
# Unit test for constructor of class Conditional
def test_Conditional():
    test_obj = Conditional()
    assert test_obj._when == list()


# Generated at 2022-06-23 06:05:04.611520
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    conditional = 'a is defined and b is not defined and c is defined'
    defined_undefined_list = c.extract_defined_undefined(conditional)
    assert(defined_undefined_list == [('a', 'is', 'defined'), ('b', 'is not', 'defined'), ('c', 'is', 'defined')])

    conditional = 'a is defined'
    defined_undefined_list = c.extract_defined_undefined(conditional)
    assert(defined_undefined_list == [('a', 'is', 'defined')])

    conditional = 'a is defined and a is defined'
    defined_undefined_list = c.extract_defined_undefined(conditional)

# Generated at 2022-06-23 06:05:14.181912
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class TestConditional(Conditional):
        pass


# Generated at 2022-06-23 06:05:15.322818
# Unit test for constructor of class Conditional
def test_Conditional():
   # Initialization of a conditional
   conditional = Conditional()
   return conditional

# Generated at 2022-06-23 06:05:16.333751
# Unit test for constructor of class Conditional
def test_Conditional():
    cond = Conditional()
    assert cond



# Generated at 2022-06-23 06:05:28.856854
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # generate various test case data sets
    test_data_set_1 = (
        "a is defined and b is defined",
        [('a', 'is', 'defined'), ('b', 'is', 'defined')]
    )
    test_data_set_2 = (
        "hostvars['a'] is undefined and b is defined",
        [('hostvars[\'a\']', 'is', 'undefined'), ('b', 'is', 'defined')]
    )
    test_data_set_3 = (
        "not (a is defined) and b is defined",
        [('a', 'is', 'defined'), ('b', 'is', 'defined')]
    )

# Generated at 2022-06-23 06:05:39.989954
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible import constants as C
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.module_utils.six import PY3
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Test hostvars
    hostvars = {
        "testhost": {
            "a": 1,
            "b": 2,
            "c": 3,
            "d": 4,
        }
    }

    # Test valid conditional string
    conditional = "[1 > 0, '1' != '2', 1 == 1]"
    context = PlayContext()
    templar = Templar(loader=None, variables=dict())
    assert Conditional()._check_conditional(conditional, templar, hostvars)

    # Test invalid conditional string

# Generated at 2022-06-23 06:05:49.215492
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext

    loader = DummyLoader()
    host = DummyHost()
    pc = PlayContext()

    # Test conditional expression with strict_undefined=False
    host.vars = dict(one=1, two=2, three=None)
    c = Conditional(loader)
    c._ds = dict(when="one == 1 and two == 2 and three == 3")

    # Test undefined vars
    assert not c.evaluate_conditional(pc.get_variable_manager().get_vars_loader(), host, pc)

    # Test defined vars using jinja templating
    host.vars = dict(one=1, two=2, three=3)
    c._ds = dict(when="one == 1 and two == 2 and three == 3")

# Generated at 2022-06-23 06:05:55.561625
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    display = Display()
    display.verbosity = 2

    # First, we test a case where a valid conditional statement is passed as parameter to the method
    conditional = "foo is defined and not var_bar is undefined and some_var_c is defined"
    expected_result = [('foo', 'is', 'defined'), ('var_bar', 'not is', 'undefined'), ('some_var_c', 'is', 'defined')]
    conditional_obj = Conditional()
    actual_result = conditional_obj.extract_defined_undefined(conditional)
    assert actual_result == expected_result, "Could not extract defined and undefined conditionals correctly (1)"

    # Second, we test a case where an invalid conditional statement is passed as parameter to the method
    conditional = "foo or var_bar or some_var_c"

# Generated at 2022-06-23 06:05:57.046551
# Unit test for constructor of class Conditional
def test_Conditional():
    assert issubclass(Conditional, object)
    c = Conditional()
    assert c

# Generated at 2022-06-23 06:06:06.117044
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test function signature
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    c = Conditional(loader)
    c.when = ["{{ foo }} == True"]
    play_context = PlayContext()
    play_context._variable_manager = variable_manager

# Generated at 2022-06-23 06:06:15.617929
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:06:17.120601
# Unit test for constructor of class Conditional
def test_Conditional():
    assert Conditional()



# Generated at 2022-06-23 06:06:25.335423
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = """
    ((hostvars['host1']['groups'] is defined)
     and ('aaa' in hostvars['host1']['groups']))
    """
    t1 = Conditional()
    results = t1.extract_defined_undefined(conditional)
    assert results == [
        ('hostvars[\'host1\'][\'groups\']', 'is', 'defined')
    ]


# Generated at 2022-06-23 06:06:29.061479
# Unit test for constructor of class Conditional
def test_Conditional():
    assert Conditional()

# Unit tests for extract_defined_undefined() function

# Generated at 2022-06-23 06:06:35.414637
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager

    def _mock_ds(self):
        return [
            {"key1": "value1", "key2": "value2", "key3": [{"foo": {"bar": "baz"}}]},
            {"key4": "value4", "key5": "value5", "key6": [{"foo": {"bar": "baz"}}]},
        ]
    Host._ds = _mock_ds


# Generated at 2022-06-23 06:06:42.751370
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

	test_conditional = Conditional()
	test_list = [
		('foo', 'is', "defined"),
		('bar', 'not is', "defined"),
		('baz', 'is', "undefined"),
		('foobar', 'is not', "undefined")
	]
	assert (test_conditional.extract_defined_undefined(
		"foo is defined and bar not is defined and baz is undefined and foobar is not undefined and bar is defined"
	) == test_list)

# Generated at 2022-06-23 06:06:51.096054
# Unit test for constructor of class Conditional
def test_Conditional():
    '''
      This is a testing stub for conditional.py
      To run the test execute: "python -m test.unit.test_conditional"
    '''
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    test_play_context = PlayContext()
    test_loader = None
    test_variable_manager = VariableManager()
    test_variable_manager.set_nonpersistent_facts(dict())
    test_variable_manager.set_variable('hostvars', {'host_one': {'var_1':'bla'}})
    test_variable_manager.set_host_variable('host_one', 'host_var', 'host_var_value')
    test_variable_manager.set_host_

# Generated at 2022-06-23 06:07:02.425783
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    class MyVars:
        def get_vars(self, play=None, host=None, task=None, include_hostvars=True):
            return {'a': 'something', 'b': 'something else', 'c': 'one more something'}

    class MyOptions:
        def __init__(self):
            self.tags = []
            self.skip_tags = []

    class Task(Conditional):
        __module__ = 'ansible.playbook'

        def __init__(self):
            super(Task, self).__init__()
            self._loader = None
            self._variable_manager = VariableManager()
            self._variable_manager.set_inventory

# Generated at 2022-06-23 06:07:11.056810
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def test_regex(conditional, result):
        # create a Conditional object to test
        conditional_object = Conditional()
        results = conditional_object.extract_defined_undefined(conditional)
        if results != result:
            print("extract_defined_undefined() failed with " + conditional)
            print("expected: " + str(result))
            print("got: " + str(results))

    test_regex("foo is defined", [('foo', 'is', 'defined')])
    test_regex("foo is not defined", [('foo', 'is', 'not defined')])
    test_regex("foo is undefined", [('foo', 'is', 'undefined')])
    test_regex("foo is not undefined", [('foo', 'is', 'not undefined')])

# Generated at 2022-06-23 06:07:19.962729
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.inventory.host import Host
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    host = Host(name='mock_host')
    display.verbosity = 3

    hostvars = dict(
        foo='1',
        bar='2',
        baz='',
        fred='nope',
        my_list_var=[1, 2, 3],
        my_dict_var={'foo': 'bar'},
        my_dict_var_with_none={'foo': 'bar', 'baz': None},
        my_empty_dict={},
        my_empty_list=[],
        my_tuple=(1, None, 2),
        my_set=set([1, None, 2]),
    )


# Generated at 2022-06-23 06:07:28.844234
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:07:40.910957
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.task_include import TaskInclude
    ti = TaskInclude.load(dict(
        name='test',
        when='{{ test_var}}'
    ))
    assert ti.when == '{{ test_var}}'

    ti = TaskInclude.load(dict(
        name='test',
        when=['{{test_var}}', 'test_var2']
    ))
    assert ti.when == ['{{test_var}}', 'test_var2'], ti.when

    # Check for errors on incorrect usage
    assert_raises(AnsibleError, Conditional)

    # Check for errors on invalid when

# Generated at 2022-06-23 06:07:52.289551
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    def test_check_conditional(conditional, templar, all_vars):
        from ansible.plugins.loader import find_plugin
        from ansible.template import Templar
        from ansible.parsing.yaml.objects import AnsibleUnicode

        plugin = find_plugin('plugin_loader', 'test')
        templar = Templar(loader=plugin._loader)
        if isinstance(conditional, str):
            conditional = AnsibleUnicode(conditional)
        if isinstance(all_vars, str):
            all_vars = AnsibleUnicode(all_vars)
        all_vars = eval(all_vars, {}, {})
        return Conditional()._check_conditional(conditional, templar, all_vars)


# Generated at 2022-06-23 06:07:54.572712
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert isinstance(c, Conditional)


# Generated at 2022-06-23 06:08:02.493635
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    skip_test = False
    try:
        import jinja2
    except ImportError:
        skip_test = True

    if not skip_test:
        class MyClass(object):
            def __init__(self):
                self.when = []
                self._ds = {}
                self._loader = jinja2.DictLoader({})

        my_conditional = MyClass()

        assert my_conditional.evaluate_conditional(my_conditional._loader.load_template('.').module._templar, dict(a=1, b=1))
        my_conditional.when = ['a == b']
        assert my_conditional.evaluate_conditional(my_conditional._loader.load_template('.').module._templar, dict(a=1, b=1))

        my_conditional

# Generated at 2022-06-23 06:08:05.173087
# Unit test for constructor of class Conditional
def test_Conditional():
    result = Conditional()
    assert isinstance(result, Conditional)
    assert result._when == []
    assert result._loader is None

# Generated at 2022-06-23 06:08:13.009492
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    class DummyClass:
        def __init__(self):
            self.vars = dict()
            self.when = ["some_condition"]

        def __getattr__(self, name):
            return self.vars.get(name, '')

        def __setattr__(self, name, value):
            self.vars[name] = value

    obj = DummyClass()

    # Test different types of conditional variables
    obj.some_condition = "myvar == 1"
    obj.myvar = 1
    assert Conditional().evaluate_conditional(Templar(loader=None, variables={}), obj.vars) == True

    obj.some_condition = "myvar == 1"
    obj.myvar = 2

# Generated at 2022-06-23 06:08:17.846819
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class TestConditional(Conditional):
        def __init__(self):
            pass

    c = TestConditional()

    # Valid conditions
    result = [
        ("hostvars['foo']", "not", "defined"),
        ("hostvars['foo']", "is", "undefined"),
        ("hostvars['foo']", "is not", "defined"),
        ("hostvars['foo']", "is", "defined"),
        ("hostvars['foo']", "not", "undefined"),
        ("foo", "not", "defined"),
        ("foo", "is", "undefined"),
        ("foo", "is not", "defined"),
        ("foo", "is", "defined"),
        ("foo", "not", "undefined"),
    ]

# Generated at 2022-06-23 06:08:25.977560
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    t = ' (( ( ( ( ( ( ( ( a is undefined ) and ( b is not defined ) ) or ( c is undefined ) ) and ( ( ( d is not defined ) ) ) ) or ( ( ( ( e is undefined ) ) ) ) ) or ( ( ( f is undefined ) or ( ( ( g is not defined ) ) ) ) ) ) and ( h is undefined ) ) and ( i is undefined ) )'
    c = Conditional()

# Generated at 2022-06-23 06:08:36.454872
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Test proper Conditional instantiation
    conditional = Conditional(loader=None)
    assert conditional.when == []

    # Test: Conditional instantiation with parameters
    conditional = Conditional(loader=None, when=['1=1'])
    assert conditional.when == ['1=1']

    # Test: TaskInclude inherits from Conditional
    include_task = TaskInclude(loader=None, when=['1=1'])
    assert include_task.when == ['1=1']


# Generated at 2022-06-23 06:08:38.593588
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert isinstance(conditional, Conditional)


# Generated at 2022-06-23 06:08:40.467079
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional is not None



# Generated at 2022-06-23 06:08:42.963435
# Unit test for constructor of class Conditional
def test_Conditional():
    class TestConditional(Conditional):
        pass
    c = TestConditional(None)
    assert isinstance(c, Conditional)
    assert c.when == []



# Generated at 2022-06-23 06:08:49.616372
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, shared_loader_obj=None, variables=dict(x=1))
    conditional = Conditional(loader=None)
    conditional.evaluate_conditional(templar=templar, all_vars=dict(x=1))



# Generated at 2022-06-23 06:08:59.463897
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

# Generated at 2022-06-23 06:09:08.916192
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """
    Tests the method Conditional.evaluate_conditional of the class Conditional.
    """

    # Create a Mock class to simulate the class Base.
    class Base:
        def __init__(self, loader=None):
            pass

    # Create a Mock class to simulate the class DataLoader.
    class DataLoader:
        def __init__(self):
            pass

        def get_basedir(self, host):
            return "/home/test"

    # Create a data structure (ds) to test.
    ds = Base(DataLoader())

    # Create a dictionary with the variables in the play (all_vars).
    all_vars = dict(a='11', b='22', c='33')

    # Create a Mock class to simulate the class Templar.

# Generated at 2022-06-23 06:09:13.357210
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = 'hostvars[inventory_hostname] is defined or hostvars[inventory_hostname] is undefined'
    c = Conditional()
    r = c.extract_defined_undefined(conditional)
    assert r == [('hostvars[inventory_hostname]', 'is', 'defined'), ('hostvars[inventory_hostname]', 'is', 'undefined')]



# Generated at 2022-06-23 06:09:15.707235
# Unit test for constructor of class Conditional
def test_Conditional():
    # Test initialization of a Conditional
    x = Conditional(loader='loader')
    assert x._loader == 'loader'
    assert x._when == list


# Generated at 2022-06-23 06:09:26.230630
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    # Test when
    c._when = "foo"
    assert(c._when == ["foo"])
    c._when = ["foo", "bar"]
    assert(c._when == ["foo", "bar"])
    c._when = c._when + ["baz"]
    assert(c._when == ["foo", "bar", "baz"])
    # Test evaluate_conditional
    # TODO: evaluate_conditional() throws exception
    # empty variable is not defined.
    #assert(c.evaluate_conditional(None, {}))
    # "foo" variable is defined.
    assert(c.evaluate_conditional(None, {"foo": "bar"}))

# Generated at 2022-06-23 06:09:33.761269
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.conditionals import Conditional
    assert Conditional().extract_defined_undefined('hostvars[inventory_hostname] is undefined') == [('hostvars[inventory_hostname]', 'is', 'undefined')]
    assert Conditional().extract_defined_undefined('hostvars[inventory_hostname] not is undefined') == [('hostvars[inventory_hostname]', 'not is', 'undefined')]
    assert Conditional().extract_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]

# Generated at 2022-06-23 06:09:35.711953
# Unit test for constructor of class Conditional
def test_Conditional():
    class MyClass:
        def __init__(self):
            self._when = list
            self._loader = ""
    mc = MyClass()
    assert isinstance(mc, Conditional)


# Generated at 2022-06-23 06:09:45.465152
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

    # test that the function returns empty when 'conditional' is not a string
    result = c.extract_defined_undefined(None)
    assert isinstance(result, list)
    assert len(result) == 0

    # test that the function returns an empty list when there are no defined/undefined tests in 'conditional'
    result = c.extract_defined_undefined("")
    assert isinstance(result, list)
    assert len(result) == 0


# Generated at 2022-06-23 06:09:51.248817
# Unit test for constructor of class Conditional
def test_Conditional():
    a = Conditional()
    assert a._when == []
    a = Conditional(loader=None)
    assert a._when == []


# Generated at 2022-06-23 06:10:01.538444
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from unit_tests.mock.loader import DictDataLoader
    from ansible.template import Templar

    # When templating the conditional fails, AnsibleUndefinedVariable should be raised
    # here we simply test that this is the case, and that the error message is correct
    test1 = dict(
        when='''{{ undefined_var }}''',
        all_vars=dict(undefined_vars=None)
    )

    loader = DictDataLoader({
        "hello.yml": """
        1
        2
        3
        """,
        "goodbye.yml": """
        1
        2
        3
        """
    })


# Generated at 2022-06-23 06:10:13.534675
# Unit test for constructor of class Conditional
def test_Conditional():
    '''
    test_Conditional
    '''

    #from units.mock.loader import DictDataLoader
    #from units.mock.path import MockPath
    #from ansible.playbook.play_context import PlayContext

    #loader = DictDataLoader({})
    #ctx = PlayContext()
    #ctx.CLIARGS = {'vault_password': 'secret'}
    #cond = Conditional(loader=loader)
    #cond._shared_loader_obj = True
    #cond._loader = loader
    #cond._templar = Templar(loader=loader, variables={}, fail_on_undefined=False)
    #cond._templar.environment.filters.update(F.filters())
    #cond._validate_when(FieldAttribute(), 'when', 'foo')
    #

# Generated at 2022-06-23 06:10:17.370825
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader

    results = []

    class TestConditional(Conditional):

        def __init__(self):
            super(TestConditional, self).__init__(loader=DataLoader())

        def evaluate_conditional(self, templar, all_vars):
            results.append("test")
            return True

    tc = TestConditional()
    tc.when = 'foo'
    tc.evaluate_conditional(None, None)
    assert results == ['test']



# Generated at 2022-06-23 06:10:18.539009
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional is not None

# Generated at 2022-06-23 06:10:29.552778
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    templar = DummyTemplar()
    cond = Conditional(DummyLoader())
    cond.when = [
        'ansible_default_ipv4.address is defined',
        'ansible_default_ipv4.address is defined and ansible_default_ipv4.gateway is defined',
        'ansible_default_ipv4.address is defined and not ansible_default_ipv4.gateway is defined',
        'ansible_default_ipv4.address is not defined and ansible_default_ipv4.gateway is defined',
        'ansible_default_ipv4.address is not defined and not ansible_default_ipv4.gateway is defined'
    ]

# Generated at 2022-06-23 06:10:41.835860
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    vars_manager = VariableManager()
    vault_secrets = {}
    vault = VaultLib(vault_secrets)

    loader = None
    templar = Templar(loader=loader, variables=vars_manager, vault_secrets=vault_secrets)

    # hostvars is a dict of dicts, which cannot be represented here

# Generated at 2022-06-23 06:10:53.263840
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()

    class FakePlay(object):
        def __init__(self, vars):
            self.vars = vars

    class FakeTask(object):
        def __init__(self, when):
            self._when = when

    class FakeHost(object):
        def __init__(self, vars):
            self.vars = vars

    class FakeInventory(object):
        def __init__(self):
            self.hosts = {}

        def get_hosts(self):
            return self.hosts

    class FakeTemplar(object):
        def __init__(self, host=None, task=None):
            self.host = host
            self.task = task
            self.loader = None
            self.available_variables = None
            self.environment = None


# Generated at 2022-06-23 06:11:04.071265
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

# Generated at 2022-06-23 06:11:15.480278
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    class MyVarsModule:
        def __init__(self, loader, path=None):
            pass

    class MyTemplar(Templar):
        def __init__(self, loader, variables=dict()):
            self.loader = loader
            self.relative_vars = dict()
            self.available_variables = variables


# Generated at 2022-06-23 06:11:17.318483
# Unit test for constructor of class Conditional
def test_Conditional():
    instance = Conditional()
    assert isinstance(instance, Conditional)


# Generated at 2022-06-23 06:11:22.179789
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    cond = Conditional(loader=loader)
    cond.when = [u'inventory_hostname == "baz"']
    cond.evaluate_conditional(None, {})

# Generated at 2022-06-23 06:11:25.166252
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert Conditional().extract_defined_undefined('a is defined or b is undefined or c is not defined') == [
        ('a', 'is', 'defined'), ('b', 'is', 'undefined'), ('c', 'is not', 'defined')
    ]

# Generated at 2022-06-23 06:11:33.485606
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestConditional(Conditional):
        pass

    tc = TestConditional()
    tc._set_loader(DictDataLoader({}))
    assert tc.evaluate_conditional(VariableManager(loader=DataLoader()).get_vars({}), {})
    tc.when = [False]
    assert tc.evaluate_conditional(VariableManager(loader=DataLoader()).get_vars({}), {}) == False
    tc.when = [True]
    assert tc.evaluate_conditional(VariableManager(loader=DataLoader()).get_vars({}), {})
    tc.when = [True, True]
    assert tc.evaluate_conditional(VariableManager(loader=DataLoader()).get_vars({}), {})
    tc.when = [True, False]

# Generated at 2022-06-23 06:11:44.804510
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    test_object = Conditional()
    test_object._loader = None # do not want to test that part
    test_object.when = [
        'item.count==5',
        'item.count is defined',
        'item.count != "pattern"',
        'item.count is not defined',
        'item.count <= 5'
    ]

    # Test with variables defined
    test_object._ds = None # do not want to test that part
    templar = None # do not want to test that part
    all_vars = dict(item=dict(count=5))
    result = test_object.evaluate_conditional(templar, all_vars)
    assert result, 'This conditional statement should return True'

    # Test with variables not defined
    test_object._ds = None # do not want to test

# Generated at 2022-06-23 06:11:50.880412
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    conditional = Conditional(loader=loader)
    conditional._ds = 'Test Conditional'
    conditional.when = ['one', 'two', 'three']
    conditional.when = ['four', 'five']
    conditional.when = 'six'
    conditional.when = 'seven'

    cond = Conditional(loader=loader)
    cond._ds = 'Invalid Conditional'
    cond.when = 'one'

    # test to make sure the initial set of conditionals work
    result = conditional.evaluate_conditional(loader, variable_manager)
    assert result == True

    # test to make sure the initial set of conditionals work
    result = conditional.evaluate

# Generated at 2022-06-23 06:12:01.878016
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''Unit test for method evaluate_conditional of class Conditional'''

    # We use a hook class to emulate a module that is installed
    class MockModule:
        '''Mock module for testing the conditional logic'''
        def __init__(self, **kwargs):
            self.params = kwargs
        def fail_json(self, **kwargs):
            pass
        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return executable

    # Create a mock module to test the conditional logic
    wu_obj = MockModule(a=1, b=1)

    # Define a variable that is used in the test
    wu_obj.key1 = 'hello'

    # Create a templar with the variable defined above

# Generated at 2022-06-23 06:12:04.962525
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.base import Base
    class C(Base, Conditional):
        pass
    c = C()
    assert isinstance(c, Base)
    assert isinstance(c, Conditional)
    assert c.when == c._attributes['when']
    assert c.when is not None
    assert isinstance(c.when, list)


# Generated at 2022-06-23 06:12:15.262527
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:12:18.586314
# Unit test for constructor of class Conditional
def test_Conditional():

    loader = DummyLoader()
    c = Conditional(loader=loader)

    assert c is not None
    assert hasattr(c, '_loader')
    assert hasattr(c, '_when')
    return


# Generated at 2022-06-23 06:12:30.774402
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = "ansible_distribution is defined or ansible_distribution_version is defined or (ansible_distribution == 'FreeBSD' and ansible_distribution_release == '10')"
    assert Conditional().extract_defined_undefined(cond) == [('ansible_distribution', 'is', 'defined'), ('ansible_distribution_version', 'is', 'defined'), ('ansible_distribution', '==', 'defined')]
    cond = "not ansible_distribution is defined or ansible_distribution_version is undefined or (ansible_distribution == 'FreeBSD' and ansible_distribution_release == '10')"

# Generated at 2022-06-23 06:12:42.578777
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.base import AnsibleBaseYAMLObject
    from ansible.playbook.block import Block
    from ansible.vars import VariableManager

    class TestConditional(AnsibleBaseYAMLObject, Conditional):
        # This is a test class inheriting from Conditional and AnsibleBaseYAMLObject
        # to unit test the method evaluate_conditional.

        def __init__(self, loader, variable_manager):
            self._loader = loader
            self._variable_manager = variable_manager
            self.when = []
            self._ds = None

    variable_manager = VariableManager()
    # variable_manager.set_variable_manager()  # TODO: not implemented

    test_conditional = TestConditional(loader=None, variable_manager=variable_manager)


# Generated at 2022-06-23 06:12:45.532370
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    conditional = Conditional('Test conditional', loader=loader)
    assert conditional.evaluate_conditional(loader.load_from_file('web.yml', False), {}) is True

# Generated at 2022-06-23 06:12:58.032466
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:13:05.308647
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("var is undefined") == [('var', 'is', 'undefined')]
    assert cond.extract_defined_undefined("var is not defined") == [('var', 'is not', 'defined')]
    assert cond.extract_defined_undefined("var_a is undefined and var_b is undefined") == [('var_a', 'is', 'undefined'),
                                                                                             ('var_b', 'is', 'undefined')]
    assert cond.extract_defined_undefined("var_a is not defined and var_b is not defined") == [('var_a', 'is not', 'defined'),
                                                                                                ('var_b', 'is not', 'defined')]
    assert cond.extract_defined_undefined

# Generated at 2022-06-23 06:13:14.179076
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.conditional import Conditional