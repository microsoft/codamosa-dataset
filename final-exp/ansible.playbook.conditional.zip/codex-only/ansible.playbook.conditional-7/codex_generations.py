

# Generated at 2022-06-23 06:03:24.070299
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    mgr = VariableManager()
    myvars = mgr.get_vars(loader=None, play=None, host=None)

    # a valid conditional should return true or false
    c = Conditional()
    c.when = ['1 > 2']
    t = Templar(loader=None, variables=myvars)
    r = c.evaluate_conditional(t, myvars)
    if not isinstance(r, bool):
        raise AssertionError("Conditional failed to evaluate to a boolean")

    # an invalid conditional should raise an error

# Generated at 2022-06-23 06:03:32.436448
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader, lookup_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-23 06:03:38.474189
# Unit test for constructor of class Conditional
def test_Conditional():
    '''
    Create and validate a Conditional object.
    '''
    # Create a Conditional object
    cond = Conditional()
    # Validate the _when attribute is created and is empty
    assert cond._when == [], "_when attribute was not created or is not empty"
    # Create a Conditional object with a list of _when attributes
    test_list = [1, 2]
    cond = Conditional()
    assert cond._when == [], "_when attribute was not created or is empty"
    # Create a Conditional object with a list of _when attributes
    test_list = [1, 2]
    cond = Conditional()
    cond._when = test_list
    assert cond._when, "_when attribute was given a list of items"
    assert cond._when == test_list, "_when attribute was given a list of items"


# Generated at 2022-06-23 06:03:49.912807
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Instantiate a Conditional()
    c = Conditional()

    # Test with defined
    conditional = "a.b.c is defined or a.b.c is not defined"
    assert c.extract_defined_undefined(conditional) == [('a.b.c', 'is', 'defined'),('a.b.c', 'is', 'defined')]

    # Test with undefined
    conditional = "a.b.c is undefined or a.b.c is not undefined"
    assert c.extract_defined_undefined(conditional) == [('a.b.c', 'is', 'undefined'),('a.b.c', 'is', 'undefined')]

    # Test with defined and undefined
    conditional = "a.b.c is defined or a.b.c is not undefined"
    assert c.ext

# Generated at 2022-06-23 06:03:56.856040
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class MyTask(Conditional):
        def __init__(self, play):
            super(MyTask, self).__init__()
            self._play = play

    t = MyTask(None)
    t.when = [ '{{ example_var }}' ]
    fake_templar = FakeTemplar(dict(example_var='foo'))
    assert t.evaluate_conditional(fake_templar, dict()) == True


# Generated at 2022-06-23 06:04:06.098721
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    statement = "foo is defined and bar is not undefined and baz is blah"
    list = conditional.extract_defined_undefined(statement)
    assert len(list) == 3, "Expected 3, got: %s" % list

    statement = "fooo is defined or bar is not undefined"
    list = conditional.extract_defined_undefined(statement)
    assert len(list) == 2, "Expected 2, got: %s" % list

    statement = "foo is defined"
    list = conditional.extract_defined_undefined(statement)
    assert len(list) == 1, "Expected 1, got: %s" % list



# Generated at 2022-06-23 06:04:18.153603
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:04:30.436860
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    mock_loader = MockLoader()
    mock_variable_manager = VariableManager(loader=mock_loader)

    # Mock task
    mock_task = MockTask(variable_manager=mock_variable_manager)
    mock_task.when.extend([
        '(test_fact1 is defined and test_fact1 is equal to 1) or (test_fact2 is defined and test_fact2 is equal to 2)'
    ])

    mock_host = MockHost()

    all_vars = HostVars(
        host=mock_host,
        variables=dict(
            test_fact1=1,
            test_fact2=2,
        )
    )

# Generated at 2022-06-23 06:04:34.652514
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    class TestClass(Conditional):
        pass

    class TestModule:
        def __init__(self, params):
            self.params = params

    import jinja2
    class TestTemplar:
        def __init__(self, loader, variables):
            self.environment = jinja2.Environment()
            self._loader = loader
            self.available_variables = variables

        def template(self, data, preserve_trailing_newlines=True,
                     convert_data=False, fail_on_undefined=True,
                     disable_lookups=False):
            t = self.environment.from_string(data)
            return t.render(self.available_variables)

        def is_template(self, data):
            return isinstance(data, text_type) and '{' in data


# Generated at 2022-06-23 06:04:44.605236
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()


# Generated at 2022-06-23 06:04:47.281030
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("var is defined") == [("var", "is", "defined")]


# Generated at 2022-06-23 06:04:55.417127
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.template import Templar

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='Hello World'))),
        ]
    )

    play = Play().load(play_source, variable_manager=VariableManager(), loader=DataLoader())
    templar = Templar(loader=DataLoader())

    conditional = Conditional(loader=DataLoader())
    conditional._ds = play_source
    # True
    ansible_facts

# Generated at 2022-06-23 06:05:07.182855
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert Conditional().extract_defined_undefined("hostvars['foo'] is not defined") == [("hostvars['foo']", "is not", "defined")]
    assert Conditional().extract_defined_undefined("hostvars['foo'] is undefined") == [("hostvars['foo']", "is", "undefined")]
    assert Conditional().extract_defined_undefined("hostvars['foo'] not is undefined") == [("hostvars['foo']", "not is", "undefined")]
    assert Conditional().extract_defined_undefined("hostvars['foo'].bar is not defined") == []
    assert Conditional().extract_defined_undefined("hostvars['foo'] is not define") == []

# Generated at 2022-06-23 06:05:16.980456
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional(loader=None)
    access = {}
    # test the following cases:
    # 1. if value is a list and items in the list are able to evaluate to true and false.
    # 2. if value is a list and list is a list of non-bool values.
    assert conditional.evaluate_conditional(templar=object, all_vars=[]) == True

    # test the following case:
    # 1. if value is not a list.
    # 2. if value is able to evaluate to true.
    access['item'] = 'value'
    assert conditional.evaluate_conditional(templar=object, all_vars=access, value=[access['item']]) == True

    # test the following case:
    # 1. if value is not a list.
    # 2. if value is able to

# Generated at 2022-06-23 06:05:29.261712
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class FakeLoader:
        pass

    class FakeInventory:
        def get_hosts(self):
            return ['host1']

        def get_host(self, name):
            return 'host1'

        def get_variable_manager(self):
            return FakeVariableManager()


# Generated at 2022-06-23 06:05:37.805798
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Host(name="foobar")
    variable_manager.add_group(Group('test_group'))
    variable_manager.add_host(inventory)
    variable_manager.set_host_variable(inventory, 'foobar', 'foo')
    variable_manager.set_host_variable(inventory, 'foorbar', 'foo')

    role_definition = RoleDefinition('test_role', '/tmp/test_role', loader=loader, variable_manager=variable_manager)
   

# Generated at 2022-06-23 06:05:47.432195
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """ Tests of method evaluate_conditional of class Conditional """
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    fake_play = dict(
        name = 'conditional_test',
        hosts = 'localhost',
        gather_facts = 'no',
        remote_user = 'local',
        tasks = [{
            'name':'conditional_test',
            'action':'shell',
            'args':'/bin/true'
        }]
    )


# Generated at 2022-06-23 06:05:48.573435
# Unit test for constructor of class Conditional
def test_Conditional():
    x = Conditional()
    assert x._when == []
    assert x.when == []


# Generated at 2022-06-23 06:05:59.419959
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.template import Templar
    import ansible.playbook.base

    loader = DictDataLoader({})
    play_context=ansible.playbook.base.PlayContext()
    templar = Templar(loader=loader, variables={}, play_context=play_context)
    conditional1=Conditional(loader)
    assert conditional1.evaluate_conditional(templar, {})
    conditional1.when="True"
    assert conditional1.evaluate_conditional(templar, {})
    conditional1.when=True
    assert conditional1.evaluate_conditional(templar, {})
    conditional1.when=False

# Generated at 2022-06-23 06:06:01.314883
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert not conditional.evaluate_conditional(object, object)


# Generated at 2022-06-23 06:06:11.909792
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_class = Conditional()
    conditional = "(hostvars['example.com']['inventory_hostname'] not is undefined)"
    results = conditional_class.extract_defined_undefined(conditional)
    assert results == [('hostvars[\'example.com\'][\'inventory_hostname\']', 'not is', 'undefined')]

    conditional = "('example.com' in groups['all']) and (hostvars['example.com']['inventory_hostname'] not is undefined)"
    results = conditional_class.extract_defined_undefined(conditional)
    assert results == [('hostvars[\'example.com\'][\'inventory_hostname\']', 'not is', 'undefined')]


# Generated at 2022-06-23 06:06:19.550071
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("hostvars[inventory_hostname] is undefined") == [('hostvars[inventory_hostname]', 'is', 'undefined')]
    assert cond.extract_defined_undefined("foo not is defined") == [('foo', 'not is', 'defined')]
    assert cond.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert cond.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert cond.extract_defined_undefined("hostvars[inventory_hostname] is defined") == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert cond.extract_

# Generated at 2022-06-23 06:06:24.784781
# Unit test for constructor of class Conditional
def test_Conditional():
    class Foo:
        def __init__(self):
            pass

    obj = Conditional()
    assert isinstance(obj, Conditional), 'Conditional() is not an instance of Conditional'


# Generated at 2022-06-23 06:06:36.304774
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.playbook import PlayBook
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(loader.load_inventory_from_file("tests/unit/inventory_v2"))


# Generated at 2022-06-23 06:06:47.181296
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    my_vars = dict()
    pc = PlayContext()
    templar = Templar(loader=None, variables=my_vars, shared_loader_obj=None, context=pc)
    conditional = Conditional(loader=templar._loader)

    # Defined_regex matches a variable, a logical operator and a state either defined or undefined
    # The method should return a list of var-logical operator-state
    assert conditional.extract_defined_undefined('somevar is defined') == [('somevar', 'is', 'defined')]
    assert conditional.extract_defined_undefined('somevar is not defined') == [('somevar', 'is not', 'defined')]
    assert conditional.extract_defined_und

# Generated at 2022-06-23 06:06:49.670153
# Unit test for constructor of class Conditional
def test_Conditional():

    conditional = Conditional()
    assert conditional._ds == None
    conditional = Conditional(loader=17)
    assert conditional._loader == 17
    # Test the parent class constructor of Conditional
    conditional = Conditional(loader=17)
    assert conditional._when == []



# Generated at 2022-06-23 06:06:50.287745
# Unit test for constructor of class Conditional
def test_Conditional():
    assert Conditional is not None

# Generated at 2022-06-23 06:06:54.104750
# Unit test for constructor of class Conditional
def test_Conditional():
    with pytest.raises(AnsibleError) as exc:
        c = Conditional(loader=None)

    assert "a loader must be specified when using Conditional() directly" in str(exc)

    with pytest.raises(AnsibleError) as exc:
        c = Conditional()

    assert "a loader must be specified when using Conditional() directly" in str(exc)

# Generated at 2022-06-23 06:07:03.085400
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('foo is defined or bar is not defined') == [('foo', 'is', 'defined'), ('bar', 'is not', 'defined')]
    assert c.extract_defined_undefined('foo is defined or bar is not defined and baz is defined') == [('foo', 'is', 'defined'), ('bar', 'is not', 'defined'), ('baz', 'is', 'defined')]
    assert c.extract_defined_undefined('foo is defined or bar is not defined and "baz" is defined') == [('foo', 'is', 'defined'), ('bar', 'is not', 'defined'), ('"baz"', 'is', 'defined')]

# Generated at 2022-06-23 06:07:08.836870
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    all_vars = VariableManager()
    templar = Templar(loader=None, variables=all_vars)
    conditional = Conditional(loader=None)

    conditional._when = ["1 == 2"]

    assert conditional.evaluate_conditional(templar, all_vars) == False

# Generated at 2022-06-23 06:07:18.539774
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def test(conditional, expected):
        actual = Conditional().extract_defined_undefined(conditional)
        if actual != expected:
            raise AssertionError("actual={}, expected={}".format(actual, expected))
    test("a is defined", [("a", "is", "defined")])
    test("a is not defined", [("a", "is not", "defined")])
    test("a is defined and b is undefined",
         [("a", "is", "defined"), ("b", "is", "undefined")])
    test("hostvars['a'] is not defined or a is defined and b is not defined",
         [("hostvars['a']", "is not", "defined"), ("a", "is", "defined"), ("b", "is not", "defined")])



# Generated at 2022-06-23 06:07:25.051042
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    def_undef = cond.extract_defined_undefined('"test" in test_var_name and hostvars["some_var"] is defined and test_var_name is not undefined')
    assert len(def_undef) == 3
    assert def_undef[0] == ('hostvars["some_var"]', 'is', 'defined')
    assert def_undef[1] == ('test_var_name', 'is not', 'undefined')


# Generated at 2022-06-23 06:07:36.632847
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-23 06:07:44.241692
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    test_conditional = Conditional()
    assert test_conditional.extract_defined_undefined("foo is defined")[0] == ('foo', 'is', 'defined')
    assert test_conditional.extract_defined_undefined("foo is not undefined")[0] == ('foo', 'is not', 'undefined')
    assert test_conditional.extract_defined_undefined("hostvars['foo'] is undefined")[0] == ('hostvars[\'foo\']', 'is', 'undefined')
    assert test_conditional.extract_defined_undefined("foo is not defined and bar is undefined") == [('foo', 'is not', 'defined'), ('bar', 'is', 'undefined')]


# Generated at 2022-06-23 06:07:47.480304
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    test_obj = Conditional()
    assert test_obj.extract_defined_undefined("cow is defined and horse is defined") == [("cow", "is", "defined"), ("horse", "is", "defined")]


# Generated at 2022-06-23 06:07:59.611895
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    import ansible.constants as C
    import os
    import yaml

    current_path = os.path.dirname(os.path.realpath(__file__))
    host_vars = current_path + '/host_vars.yml'
    (b_options, b_args) = Play().parse(args=['localhost', '-i', 'localhost,'])
    variable_manager

# Generated at 2022-06-23 06:08:07.699120
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:08:20.638998
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    class TestConditional(AnsibleBaseYAMLObject, Conditional):
        pass

    task = TestConditional()
    conditional = "hostvars['hostname'] is defined and hostvars['a'] is not undefined and hostvars['b'] is not defined"
    assert task.extract_defined_undefined(conditional) == [['hostvars[\'hostname\']', 'is', 'defined'], ['hostvars[\'a\']', 'is not', 'undefined'], ['hostvars[\'b\']', 'is not', 'defined']]

    conditional = "hostvars['a'] is not defined"

# Generated at 2022-06-23 06:08:30.533975
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-23 06:08:42.671185
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template.safe_eval import ansible_safe_eval

    class FakeTemplar:
        def __init__(self):
            self.environment = None
            self.is_template_result = True

        def is_template(self, data):
            return self.is_template_result

        def template(self, data, disable_lookups=None, variables=None):
            return data

    # mock
    display._display.verbosity = 2
    C.DEFAULT_UNDEFINED_VARIABLE_BEHAVIOR = "warn"

    def assert_evaluate_conditional(conditional, result):
        templar = FakeTemplar()
        if conditional is True or conditional is False:
            conditional = ast.literal_eval(conditional)
        assert Conditional(loader=None).evaluate_

# Generated at 2022-06-23 06:08:43.583453
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()

    assert c is not None

# Generated at 2022-06-23 06:08:55.635885
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

    simple_definition = 'test is defined'
    result = [('test', 'is', 'defined')]
    assert result == cond.extract_defined_undefined(simple_definition)

    multiple_definition = 'test is defined and another_test is not defined'
    result = [('test', 'is', 'defined'), ('another_test', 'is not', 'defined')]
    assert result == cond.extract_defined_undefined(multiple_definition)

    multiple_definition = 'test is defined and another_test is not defined'
    result = [('test', 'is', 'defined'), ('another_test', 'is not', 'defined')]
    assert result == cond.extract_defined_undefined(multiple_definition)

    pattern_with_defined = 'test\w+ is defined'

# Generated at 2022-06-23 06:09:03.140335
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    # Conditional.extract_defined_undefined returns a list
    #
    # The list contains tuples:
    #   - first item is the variable name to check
    #   - second item is the logic used for the check
    #   - third item is the state to check

    # pylint: disable=protected-access

    conditional = Conditional()

    def check_result(result, expect):
        assert len(result) == len(expect), "Expected %s elements in the result, got %s" % (len(expect), len(result))
        for i in range(len(result)):
            assert result[i][0] == expect[i][0], "Expected %s as first, got %s" % (expect[i][0], result[i][0])

# Generated at 2022-06-23 06:09:14.805893
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook import Playbook
    from ansible.playbook.task import Task

    playbook = Playbook()
    playbook.vars = dict(first=True, second=True)

    task = Task()
    task._parent = playbook
    assert task.evaluate_conditional("first", playbook.vars) is True
    assert task.evaluate_conditional("first and second", playbook.vars) is True
    assert task.evaluate_conditional("first and not second", playbook.vars) is False
    assert task.evaluate_conditional("first is not defined", playbook.vars) is False
    assert task.evaluate_conditional("first is defined", playbook.vars) is True
    assert task.evaluate_conditional("first is not true", playbook.vars) is False

# Generated at 2022-06-23 06:09:26.698545
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    def assert_x(x):
        l = Conditional()
        actual = l.extract_defined_undefined(x)
        assert actual == e, 'Failed to extract definition. Expected: %s. Actual: %s' % (e, actual)

    e = [('hostvars["foo"]', 'is', 'defined')]
    x = 'hostvars["foo"] is defined'
    assert_x(x)

    e = [('hostvars["foo"]', 'is', 'undefined')]
    x = 'hostvars["foo"] is undefined'
    assert_x(x)

    e = [('hostvars["foo"]', 'not is', 'defined')]
    x = 'hostvars["foo"] not is defined'
    assert_x(x)


# Generated at 2022-06-23 06:09:34.161632
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_inventory(Host('localhost'), Inventory(host_list=[Host('localhost')]))

# Generated at 2022-06-23 06:09:36.054853
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # TODO
    # test method evaluate_conditional of class Conditional
    pass

# Generated at 2022-06-23 06:09:45.597905
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:09:59.084666
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''Unit test for method evaluate_conditional of class Conditional'''
    from ansible.vars import VariableManager

    class MockPlay():
        def __init__(self):
            pass
        def basedir(self):
            return ''

    class MockLoader():
        def __init__(self):
            pass
        def get_basedir(self, play=None):
            return ''

    class MockTask():
        def __init__(self):
            self.play = MockPlay()


# Generated at 2022-06-23 06:10:11.523628
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    Test Conditional.extract_defined_undefined function
    '''
    conditional = Conditional()

    def _evaluate_assertion(condition, expected):
        result = conditional.extract_defined_undefined(condition)
        assert result == expected, "Result '%s' does not match expected value '%s'" % (result, expected)

    _evaluate_assertion('', [])
    _evaluate_assertion('foo', [])
    _evaluate_assertion('foo is undefined', [('foo', 'is', 'undefined')])
    _evaluate_assertion('foo is not undefined', [('foo', 'is not', 'undefined')])
    _evaluate_assertion('foo is defined', [('foo', 'is', 'defined')])

# Generated at 2022-06-23 06:10:17.694244
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Create a Conditional object (variable names have been shortened)
    obj = Conditional()

    # Verify that extract_defined_undefined returns a list (possibly empty)
    assert isinstance(obj.extract_defined_undefined(""), list)

    # Verify the results of different conditional statements on the extract_defined_undefined method
    assert obj.extract_defined_undefined("") == []
    assert obj.extract_defined_undefined("when: foo == 'bar'") == []
    assert obj.extract_defined_undefined("when: foo is defined") == \
        [('foo', 'is', 'defined')]
    assert obj.extract_defined_undefined("when: foo is not defined") == \
        [('foo', 'is', 'not defined')]

# Generated at 2022-06-23 06:10:28.535204
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Test normal usage
    assert Conditional().extract_defined_undefined('d is undefined') == [('d', 'is', 'undefined')]
    assert Conditional().extract_defined_undefined('d is not undefined') == [('d', 'is not', 'undefined')]
    assert Conditional().extract_defined_undefined('d is defined') == [('d', 'is', 'defined')]
    assert Conditional().extract_defined_undefined('d is not defined') == [('d', 'is not', 'defined')]

# Generated at 2022-06-23 06:10:34.668130
# Unit test for constructor of class Conditional
def test_Conditional():
    """Unit test for AnsibleConditional in ansible/playbook/__init__.py"""
    c = Conditional(loader='loader')
    # test that `when` is correctly initialized, and we don't introduce regression
    assert c._when == [], '_when should be initialized to an empty list'
    assert c.when == [], 'when should be initialized to an empty list'

# Generated at 2022-06-23 06:10:46.102475
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import unittest
    import ansible.parsing.yaml.objects
    from collections import namedtuple

    from ansible.vars.unsafe_proxy import SafeDict

    from ansible.plugins.loader import become_loader, action_loader, module_loader, strategy_loader, cache_loader
    from ansible.plugins.vars import vars_loader

    from ansible.template import Templar

    from ansible.inventory.manager import InventoryManager

    from ansible.executor.task_queue_manager import TaskQueueManager

    import ansible.playbook.play
    import ansible.playbook.play_context

    import ansible.playbook.role
    import ansible.playbook.block
    import ansible.playbook.task
    import ansible.playbook.included_file
    import ansible.play

# Generated at 2022-06-23 06:10:55.673462
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # test case 1
    conditional = "inventory_hostname is not defined and (reboot_required or service_stopped)"
    expected = [
        ['inventory_hostname', 'is not', 'defined']
    ]
    actual = Conditional().extract_defined_undefined(conditional)
    assert actual == expected

    # test case 2
    conditional = "not ansible_ssh_pass and not ansible_password"
    expected = []
    actual = Conditional().extract_defined_undefined(conditional)
    assert actual == expected

    # test case 3
    conditional = "ansible_ssh_user not in ['user', 'ubuntu'] and not (ansible_ssh_pass or ansible_password)"
    expected = []
    actual = Conditional().extract_defined_undefined(conditional)
    assert actual == expected

# Generated at 2022-06-23 06:11:00.893807
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.template import Templar

    class Test(object):
        pass
    test = Test()
    test.ds = {}
    test._loader = None

    conditional = Conditional(loader=None)
    conditional._ds = test.ds

    def test_when_validate():
        for i in (['a','b'], 'c', [], None):
            conditional._validate_when('attr', '_when', i)

    test_when_validate()



# Generated at 2022-06-23 06:11:12.166748
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:11:23.630891
# Unit test for constructor of class Conditional
def test_Conditional():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    try:
        Conditional()
        assert False, 'Conditional should raise an exception when not constructed with a loader'
    except Exception:
        pass

    loader = DictDataLoader({})
    inventory = DictInventory()
    play_context = PlayContext()
    play_context.network_os = 'default'
    play = Play().load(dict(name='test play', hosts=['all']), loader=loader, inventory=inventory)
    play._variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context._update_vars(play.get_vars())

    display.verbosity = 4

    # Test creating an instance of Conditional with a loader

# Generated at 2022-06-23 06:11:32.442030
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook import Playbook
    from ansible.template import Templar

    pb = Playbook.load(C.DEFAULT_PLAYBOOK_PATH, variable_manager={'name': 'ansible'})
    p = pb.get_plays()[0]

    # set up the test
    t = Templar(pb.basedir, p.get_variable_manager())
    all_vars = t.get_all_vars()

    # set the conditional and use the evaluate_conditional method to evaluate it
    conditional = 'name == "ansible"'
    assert p.evaluate_conditional(t, all_vars) == True

    # set the conditional and use the evaluate_conditional method to evaluate it
    conditional = 'name == "not-ansible"'

# Generated at 2022-06-23 06:11:33.809059
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c


# Generated at 2022-06-23 06:11:36.960475
# Unit test for constructor of class Conditional
def test_Conditional():
    event_test = Conditional(loader=None)
    return event_test


# Generated at 2022-06-23 06:11:46.411978
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:11:58.198574
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    import builtins
    builtins.__dict__.pop('CONFIG_WARNING_SKIPPED')
    conditional = Conditional()
    assert conditional.extract_defined_undefined('1 == 1') == []
    assert conditional.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]

# Generated at 2022-06-23 06:12:01.362327
# Unit test for constructor of class Conditional
def test_Conditional():
    # Create an object to be used for testing
    test_object = Conditional()

    assert test_object
    assert test_object._when == []


# Generated at 2022-06-23 06:12:07.393058
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class Conditional_tester(object, Conditional):
        __slots__ = ('_ds', 'when')

    # --------------
    # UNIT TEST CASE
    # --------------
    tester = Conditional_tester()
    tester._ds = 'host1'
    tester.when = ['ansible_os_family == "RedHat" and ansible_memory_mb.real.total > 2048', True]

    vars_to_test = {
        u'ansible_os_family': u'RedHat',
        u'ansible_memory_mb': {u'real': {u'total': 2 * 1024}}
    }

    display.__dict__.clear()
    result = tester.evaluate_conditional(tester._loader.get_basedir(), vars_to_test)
    assert result



# Generated at 2022-06-23 06:12:16.369207
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar

    # prepare the test environment
    all_vars = dict()
    all_vars['DEFAULT_CONDITIONAL'] = 'default_conditional'
    all_vars['ALSO_CONDITIONAL'] = 'also_conditional'
    all_vars['DANGER_CONDITIONAL'] = 'danger_conditional'
    all_vars['UNDEFINED_CONDITIONAL'] = None
    all_vars['TRUE_CONDITIONAL'] = True
    all_vars['FALSE_CONDITIONAL'] = False

    templar = Templar(loader=None, variables=all_vars)

    # test default behavior
    conditional = Conditional()
    assert conditional.evaluate_conditional(templar, all_vars) is True

   

# Generated at 2022-06-23 06:12:17.902324
# Unit test for constructor of class Conditional
def test_Conditional():

    class TestClass(Conditional):
        pass

    assert TestClass()



# Generated at 2022-06-23 06:12:30.264502
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # This method has fixed output and does not rely on any runtime variables
    # so the datastructure does not need to be populated

    conditional = Conditional()

    # Test for exact matches. No whitespaces allowed around symbols
    assert conditional.extract_defined_undefined("a is defined")
    assert conditional.extract_defined_undefined("a is not defined")
    assert not conditional.extract_defined_undefined("a defined")
    assert not conditional.extract_defined_undefined("a not defined")
    assert not conditional.extract_defined_undefined("a isnot defined")
    assert not conditional.extract_defined_undefined("a is undefined")

    # Test for whitespaces around symbols, before and after and with the symbol
    assert conditional.extract_defined_undefined("a is  defined")
    assert conditional.extract

# Generated at 2022-06-23 06:12:41.955940
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host

    yaml_data = """
    - hosts: localhost
      gather_facts: False
      tasks:
        - debug:
            msg: this message should be returned
            when: False
    """

    inventory = Playbook().set_inventory(Group(name='localhost')
        .set_variable('foo', 'bar')
        .add_host(Host(name='localhost'))
    )

    result = Play().load(yaml_data, variable_manager=inventory.get_variable_manager(), loader=inventory._loader)

    assert 'tasks' in result._entries[0]._ds, "Something went wrong with the playbook load."

# Generated at 2022-06-23 06:12:48.717709
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    # Load test data
    loader = DataLoader()
    data = loader.load_from_file("/home/ashish/ansible/test/unit/playbook/data/playbook.yml")
    var_manager = VariableManager()
    var_manager.extra_vars = data
    inventory = InventoryManager(loader=loader, sources="localhost")
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.set_inventory(inventory)
    variable_manager.set_playbook_basedir("/home/ashish/ansible/test/unit/playbook")
    variable_manager.set

# Generated at 2022-06-23 06:13:00.303253
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def testing_extract_defined_undefined(string, expected_result):
        """
            This is a helper method for unit testing which validates the
            output of Conditional.extract_defined_undefined against the
            given expected_result. The expected_result is a list of strings.
        """
        instance = Conditional(loader=None)
        result = instance.extract_defined_undefined(string)
        if len(result) == len(expected_result) and set(result) == set(expected_result):
            return True
        print("Result: %s\nExpected result: %s" % (result, expected_result))
        return False

    # A simple test to ensure the RegEx is working correctly.

# Generated at 2022-06-23 06:13:03.998004
# Unit test for constructor of class Conditional
def test_Conditional():
    cond = Conditional()
    assert isinstance(cond, Conditional)
    assert not hasattr(cond, '_loader')
    assert isinstance(cond._when, list)
    assert cond._when == []

# Generated at 2022-06-23 06:13:06.180955
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert isinstance(conditional, Conditional)


# Generated at 2022-06-23 06:13:14.924143
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('yumrepo_present and (foo is defined or bar is undefined)') == \
        [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]
    assert c.extract_defined_undefined('yumrepo_present and (foo not is defined or bar is undefined)') == \
        [('foo', 'not is', 'defined'), ('bar', 'is', 'undefined')]
    assert c.extract_defined_undefined('yumrepo_present and (foo is not defined or bar is undefined)') == \
        [('foo', 'is not', 'defined'), ('bar', 'is', 'undefined')]