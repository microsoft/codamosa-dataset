

# Generated at 2022-06-23 06:03:15.286644
# Unit test for constructor of class Conditional
def test_Conditional():
    display.display('Running test_Conditional')
    conditional = Conditional()
    assert conditional



# Generated at 2022-06-23 06:03:28.438843
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    loader = DictDataLoader({})
    t = PlayContext(loader=loader)
    assert Conditional(loader).evaluate_conditional(t, all_vars=dict(hostvars=dict(localhost=dict(ansible_host='127.0.0.1'))))
    assert not Conditional(loader).evaluate_conditional(t, all_vars=dict(hostvars=dict(localhost=dict(ansible_host='127.0.0.1'))))
    assert not Conditional(loader).evaluate_conditional(t, all_vars=dict(hostvars=dict(localhost=dict(ansible_host='127.0.0.1'))))

# Generated at 2022-06-23 06:03:36.060276
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    # Test string:
    # hostvars['ansible_distribution'] not is defined or hostvars['ansible_distribution_major_version'] is defined
    str1 = 'hostvars[\'ansible_distribution\'] not is defined or hostvars[\'ansible_distribution_major_version\'] is defined'
    results1 = [('hostvars[\'ansible_distribution\']',
                 'not is', 'defined'),
                ('hostvars[\'ansible_distribution_major_version\']',
                 'is', 'defined')]
    assert(Conditional().extract_defined_undefined(str1) == results1)

    # Test string with multiple whitespaces between tokens
    # hostvars['ansible_distribution'] not is defined and  hostvars['ansible_distribution_major

# Generated at 2022-06-23 06:03:37.016054
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional is not None

# Generated at 2022-06-23 06:03:47.762627
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    t = Conditional(loader)
    assert t
    assert t.when == []

    t.when.append("foo")
    assert t.when == ["foo"]

    t.evaluate_conditional(variable_manager, variable_manager.get_vars(loader=loader, play=None, task=None, include_hostvars=True))

    variable_manager.set_nonpersistent_facts({"ansible_runtime_version": "1.0"})

    assert C.DEFAULT_BECOME_PASS is not 'TEST'

# Generated at 2022-06-23 06:03:57.354370
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    a = Conditional()

    assert a.extract_defined_undefined("") == []
    assert a.extract_defined_undefined("a and b") == []
    assert a.extract_defined_undefined("a is defined") == [('a', 'is', 'defined')]
    assert a.extract_defined_undefined("a is defined or b is defined") == [('a', 'is', 'defined'), ('b', 'is', 'defined')]
    assert a.extract_defined_undefined("a is defined and b is defined") == [('a', 'is', 'defined'), ('b', 'is', 'defined')]

# Generated at 2022-06-23 06:04:08.034756
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook import Play
    from ansible.playbook.task import Task


# Generated at 2022-06-23 06:04:18.790462
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    # Test whether defined and undefined are extracted correctly
    conditional = Conditional()
    test_string = "var1 == 1 or var2 is defined or var3 is undefined and not var4 is undefined or var5 not in hostvars['var6']"
    expected_output = [('var2', 'is', 'defined'),
                       ('var3', 'is', 'undefined'),
                       ('var4', 'is not', 'undefined'),
                       ("hostvars['var6']", 'not in', 'hostvars[\'var6\']')]
    assert conditional.extract_defined_undefined(test_string) == expected_output

    # Test whether defined and undefined are extracted correctly
    conditional = Conditional()

# Generated at 2022-06-23 06:04:28.485375
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader

    # calling Conditional.__init__() directly, since this class
    # is normally used as a mix-in
    cond = Conditional(DataLoader())

    # test validate_when
    cond.when = [1, 2, 3]
    assert cond.when == [1, 2, 3]
    cond.when = 'foo'
    assert cond.when == ['foo']
    cond.when = None
    assert cond.when == []
    cond.when = 'foo'
    assert cond.when == ['foo']

# Generated at 2022-06-23 06:04:40.383069
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:04:48.258924
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    cond = Conditional()
    expected_result = dict()

    expected_result["{{ 1 > 1 }}"] = False
    expected_result["{{ 1 < 1 }}"] = False
    expected_result["{{ 1 == 1 }}"] = True
    expected_result["{{ 1 != 1 }}"] = False
    expected_result["{{ 1 == 1 && 1 > 1 }}"] = False
    expected_result["{{ 1 == 1 || 1 > 1 }}"] = True
    expected_result["{{ 1 != 1 or 1 < 1 or 1 > 1 }}"] = True
    expected_result["{{ 1 != 1 and 1 < 1 and 1 > 1 }}"] = False
    expected_result["{{ ansible_hostname == inventory_hostname }}"] = True
    expected_result["{{ ansible_hostname == 'foohost' }}"] = False

# Generated at 2022-06-23 06:04:55.867233
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template.template import Templar

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    the_host = "webserver"
    res = True
    conditional = 'ansible_eth1'
    res = res and Conditional()._check_conditional(conditional, templar, {'inventory_hostname': the_host})
    assert res

    conditional = 'not ansible_eth1'
    res = res and Conditional()._check_conditional(conditional, templar, {'inventory_hostname': the_host})
    assert not res

    conditional = 'ansible_eth0'

# Generated at 2022-06-23 06:04:57.547056
# Unit test for constructor of class Conditional
def test_Conditional():
    obj = Conditional()
    assert hasattr(obj, '_when')


# Generated at 2022-06-23 06:05:08.882445
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import os

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.playbook.includes import IncludedFile

    DATA_PATH = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', 'module_utils', 'basic.py')

    variable_manager = VariableManager()
    loader = DataLoader()

    hostname = "testhost"
    variable_manager.set_host_variable(hostname, {"ansible_python_interpreter": "/usr/local/bin/python"})

    included_file = IncludedFile(loader=loader, variable_manager=variable_manager, filename=DATA_PATH)

# Generated at 2022-06-23 06:05:13.796489
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    context = PlayContext()

    pc = Conditional()
    pc._templar = Templar(loader=None, variables={})

    assert pc.evaluate_conditional(pc._templar, context) is True
    assert pc.evaluate_conditional(pc._templar, {'a': 1, 'b': 2}) is True


# Generated at 2022-06-23 06:05:22.380742
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory())
    variable_manager.extra_vars = {'foo': 'bar'}
    loader = DataLoader()
    context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, flags=context.flags)

    test = Conditional(loader=loader)
    test.when = {'foo': 'bar'}
    assert test.evaluate_conditional(templar, variable_manager) is True

    test = Conditional(loader=loader)
    test.when = {'foo': 'not bar'}

# Generated at 2022-06-23 06:05:28.316485
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("x is defined") == [("x", "is", "defined")]
    assert c.extract_defined_undefined("x is not defined") == [("x", "is not", "defined")]
    assert c.extract_defined_undefined("x is undefined") == [("x", "is", "undefined")]
    assert c.extract_defined_undefined("x is not undefined") == [("x", "is not", "undefined")]
    assert c.extract_defined_undefined("x is defined and y is not defined") == [("x", "is", "defined"), ("y", "is not", "defined")]

# Generated at 2022-06-23 06:05:39.901636
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    display = Display()
    conditional = Conditional()
    assert conditional.extract_defined_undefined("fake_undefined_variable is defined") == []
    assert conditional.extract_defined_undefined("ansible_user is defined") == [('ansible_user', 'is', 'defined')]
    assert conditional.extract_defined_undefined("ansible_user not is defined") == [('ansible_user', 'not is', 'defined')]
    assert conditional.extract_defined_undefined("ansible_user is not defined") == [('ansible_user', 'is', 'not defined')]
    assert conditional.extract_defined_undefined("ansible_user not is not defined") == [('ansible_user', 'not is', 'not defined')]

# Generated at 2022-06-23 06:05:43.928605
# Unit test for constructor of class Conditional
def test_Conditional():
    """
    Test Conditional class construction
    """
    try:
        a = Conditional()
    except AnsibleError as e:
        assert str(e) == "a loader must be specified when using Conditional() directly"
    else:
        raise Exception("Conditional did not raise an AnsibleError exception when instantiated without a loader")



# Generated at 2022-06-23 06:05:51.920411
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = '''(hostvars['hostname'] is defined) and
                    (hostvars['hostname'] != '') and
                    (hostvars['hostname']|ipaddr('address') != '127.0.0.1') and
                    (not hostvars['hostname']|ipaddr('scope') == 'link') and
                    (hostvars['hostname'].vendor == 'juniper') or
                    (hostvars['hostname'] is undefined)'''
    expected = [('hostvars[\'hostname\']', 'is', 'defined'),
                ('hostvars[\'hostname\']', 'is', 'undefined'),
                ('hostvars[\'hostname\']', '!=', 'defined')]
    conditional_obj = Conditional()
    result = conditional_obj.extract_defined_

# Generated at 2022-06-23 06:06:03.420738
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert c.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert c.extract_defined_undefined("foo not is defined") == [("foo", "not is", "defined")]
    assert c.extract_defined_undefined("foo  not  is  undefined") == [("foo", "not is", "undefined")]
    assert c.extract_defined_undefined("foo not is undefined") == [("foo", "not is", "undefined")]
    assert c.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]

# Generated at 2022-06-23 06:06:10.249877
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    c = Conditional()
    c.when = "this is a when statement"
    assert c.when == ["this is a when statement"]
    c.when = "this is another when statement"
    assert c.when == ["this is a when statement","this is another when statement"]
    c.when = "another when statement"
    assert c.when == ["this is a when statement","this is another when statement","another when statement"]

# Generated at 2022-06-23 06:06:16.977301
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional(None)
    testCond = ("a is defined and b is undefined and c is not defined and "
                "d is defined or e is not defined or f is undefined or g is not undefined")
    testRes = [
        ("a", "is", "defined"),
        ("b", "is", "undefined"),
        ("c", "is not", "defined"),
        ("d", "is", "defined"),
        ("e", "is not", "defined"),
        ("f", "is", "undefined"),
        ("g", "is not", "undefined")
    ]
    assert cond.extract_defined_undefined(testCond) == testRes



# Generated at 2022-06-23 06:06:18.060920
# Unit test for constructor of class Conditional
def test_Conditional():
    assert type(Conditional()).__name__ == "Conditional"


# Generated at 2022-06-23 06:06:20.849876
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    ds = None
    loader = None
    c = Conditional(loader)
    templar = None
    all_vars = ''
    c.when = ['']
    assert True == c.evaluate_conditional(templar, all_vars)
    return True

# Generated at 2022-06-23 06:06:31.285379
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    class ConditionalMock(Conditional):
        def __init__(self, loader):
            super(ConditionalMock, self).__init__(loader)
            self._ds = DictMock()
            self.when = list()

    class DictMock(dict):
        def __init__(self, *args, **kwargs):
            super(DictMock, self).__init__(*args, **kwargs)
            self.vars = dict()

        def __getitem__(self, key):
            if key in self.vars.keys():
                return self.vars[key]
            raise KeyError


# Generated at 2022-06-23 06:06:43.992370
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.errors import AnsibleError
    from ansible.playbook.base import Base
    from ansible.template import Templar

    b = Base()
    c = Conditional()
    try:
        c.evaluate_conditional(Templar(loader=b._loader), {})
    except AnsibleError:
        pass
    else:
        assert False, "Failed to raise exception when conditional is missing"

    c = Conditional()
    c.when = True
    assert c.evaluate_conditional(Templar(loader=b._loader), {}) == True, "Failed to evaluate bool"

    c = Conditional()
    c.when = "True"
    assert c.evaluate_conditional(Templar(loader=b._loader), {}) == True, "Failed to evaluate bool"

    c = Conditional

# Generated at 2022-06-23 06:06:52.029810
# Unit test for constructor of class Conditional
def test_Conditional():

    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    p = Conditional(loader=DataLoader())
    assert p is not None

    # load some variables as if this was a task
    vars_manager = VariableManager()
    vars_manager._fact_cache = dict(foo='bar')
    vars_manager._fact_cache['ansible_fqdn'] = 'example.org'
    # load the play context
    play_context = PlayContext()
    play_context.network_os = 'ios'
    # create a dictionary of things that would be included in all_vars, usually populated
    # by the variable manager
    all_vars = dict()

# Generated at 2022-06-23 06:07:02.489493
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    """ Tests the extract_defined_undefined method of class Conditional """
    from ansible.playbook.conditional import Conditional

    conditional = Conditional()

    # Normal cases
    (var1, logic1, state1) = ('foo', 'is', 'defined')
    (var2, logic2, state2) = ('bar', 'is not', 'defined')
    (var3, logic3, state3) = ('baz', 'is', 'undefined')

# Generated at 2022-06-23 06:07:06.631659
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    ret = Conditional().extract_defined_undefined(
        'var1 is defined and ( var2 is undefined or var3 is defined )'
    )
    assert ret == [('var1', 'is', 'defined'), ('var2', 'is', 'undefined'), ('var3', 'is', 'defined')]


# Generated at 2022-06-23 06:07:13.660561
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Tests both is and is not operators
    conditional_1 = 'host_var is defined and other_host_var is not defined'
    c = Conditional()
    assert c.extract_defined_undefined(conditional_1) == [('host_var', 'is', 'defined'), ('other_host_var', 'is not', 'defined')]
    # Tests no defined/undefined in string
    conditional_2 = 'var_1 == var_2'
    assert c.extract_defined_undefined(conditional_2) == []
    # Tests multiple defined/undefined
    conditional_3 = 'host_var is not defined or other_host_var is defined'

# Generated at 2022-06-23 06:07:19.456743
# Unit test for constructor of class Conditional
def test_Conditional():
    # instantiate default conditional
    conditional = Conditional()
    assert conditional.when == [], "when set to default value"

    # instantiate conditional with when
    conditional = Conditional(when=["test"])
    assert conditional.when == ["test"], "when set to test"

    # conditional with undefined when
    try:
        Conditional(when=dict(a='fizz', b='buzz'))
    except:
        assert True, "Fails on parameter type mismatch"


# unit test for evaluate_conditional method

# Generated at 2022-06-23 06:07:28.531895
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-23 06:07:38.556309
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    The method evaluate_conditional is defined in a mixin class that can be used
    by any class that needs conditional execution.
    '''
    from ansible.vars.manager import VariableManager

    class TestClass:
        def __init__(self):
            self._loader = None
            self.variable_manager = VariableManager()

    test_class = TestClass()

    # no conditional
    assert test_class.evaluate_conditional({'var': 'value'}, None) is True

    # empty conditional
    test_class._when = ''
    assert test_class.evaluate_conditional({'var': 'value'}, None) is True

    # empty conditional
    test_class._when = []
    assert test_class.evaluate_conditional({'var': 'value'}, None) is True

    # conditional that evaluates

# Generated at 2022-06-23 06:07:44.142025
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.base import Base

    class TestConditional(Base, Conditional):
        pass

    a = TestConditional()
    assert a.when is None

    b = TestConditional(None, when=True)
    assert b.when == True

    c = TestConditional(None, when="test")
    assert c.when == "test"

    d = TestConditional(None, when=["test1", "test2"])
    assert d.when == ["test1", "test2"]


# Generated at 2022-06-23 06:07:53.835439
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Assert test conditionals
    conds = [
        "var1 is defined",
        "var1 is not defined",
        "var1 is not defined and var2 is not defined",
        "var1  is  defined",
        "var1\nis defined",
        "other is defined",
        "var1 or var2 or var3 is defined or var4 is defined",
        "var1 and var2 and var3 is not defined or var4 is defined",
        "var1 and var2 and var3 is not defined or var4 is defined",
        "var1 or var2 is defined"
    ]

    # Expected outputs from extract_defined_undefined method

# Generated at 2022-06-23 06:07:56.767597
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Run tests against evaluate_conditional method of Conditional class
    '''
    # TODO implement this when class Conditional is refactored
    pass



# Generated at 2022-06-23 06:08:08.954014
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import wrap_var

    ds = dict(
        when=None,
        when1=True,
        when2=False,
        when3={'a': 1},
        when4=[1,2],
        when5='',
        when6=0,
        when7='{{ foo }}',
        when8=wrap_var(42),
        when9=wrap_var(42, unsafe=False),
    )

    class TestClass(AnsibleBaseYAMLObject, Conditional):
        pass

    t = TestClass()
    t.load_data(ds)

    vars_manager = VariableManager()
    v

# Generated at 2022-06-23 06:08:21.188753
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("not var1 is defined") == [("var1", "not is", "defined")]
    assert cond.extract_defined_undefined("not var1 is defined and var2 is defined") == [("var1", "not is", "defined"), ("var2", "is", "defined")]
    assert cond.extract_defined_undefined("not var1 is defined and var2 is not defined") == [("var1", "not is", "defined"), ("var2", "is not", "defined")]
    assert cond.extract_defined_undefined("not var1 is defined and not var2 is not defined") == [("var1", "not is", "defined"), ("var2", "not is", "defined")]
    assert cond.extract_defined_und

# Generated at 2022-06-23 06:08:30.896346
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    def get_top_level_vars(cond):
        top_level_vars = re.findall(r'([\w_]+)', cond)
        return top_level_vars

    top_level_vars = get_top_level_vars(
        '{{ foo is defined  }} and {{ bar is defined}} and {{ baz is undefined}} and {{ other }} and {{ other1 }} and {{ other2 }}'
    )
    top_level_vars += get_top_level_vars(
        '{{ foo is defined or bar is defined or baz is undefined or other or other1 or other2 }}'
    )
    top_level_vars += get_top_level_vars(
        '{{ foo is defined and bar is defined and baz is undefined and other and other1 and other2 }}'
    )

# Generated at 2022-06-23 06:08:42.700107
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create play with a single task

# Generated at 2022-06-23 06:08:54.808098
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    import pytest

    test_conditional = "defined('inventory_hostname') and not (ansible_operatingsystem == 'Ubuntu')"
    test_conditional_results = [
        ("inventory_hostname", "defined", "defined"),
        ("ansible_operatingsystem", "is", "undefined")
    ]
    cond = Conditional()
    assert cond.extract_defined_undefined(test_conditional) == test_conditional_results

    test_conditional = "inventory_hostname is defined and ansible_operatingsystem is not undefined"
    test_conditional_results = [
        ("inventory_hostname", "is", "defined"),
        ("ansible_operatingsystem", "is", "defined")
    ]
    cond = Conditional()
    assert cond.extract_defined_

# Generated at 2022-06-23 06:09:02.802610
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    # Test with a good string
    conditional = "hostvars['testhost'].testvar is defined or testvar is defined"
    expected = [('hostvars[\'testhost\'].testvar', 'is', 'defined'), ('testvar', 'is', 'defined')]
    res = Conditional().extract_defined_undefined(conditional)
    assert len(res) == 2 and res == expected,\
        "extract_defined_undefined failed to extract correctly the definition/undefintion(" + \
        "expected to extract 2 definitions): " + str(res)

    # Test with a bad string
    conditional = "badisdefined"
    expected = []
    res = Conditional().extract_defined_undefined(conditional)

# Generated at 2022-06-23 06:09:04.611761
# Unit test for constructor of class Conditional
def test_Conditional():
    loader = DictDataLoader({})
    conditional = Conditional(loader)
    assert conditional is not None


# Generated at 2022-06-23 06:09:15.970774
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    # Expected result when a string contains only valid definitions or undefinitions
    def assert_valid_def_undef(conditional, expected_result):
        result = Conditional().extract_defined_undefined(conditional)
        assert result == expected_result

    # Expected result when a string contains invalid definitions or undefinitions
    def assert_invalid_def_undef(conditional, expected_result):
        result = Conditional().extract_defined_undefined(conditional)
        assert result == expected_result

    # Expected result when a string contains valid and invalid definitions or undefinitions
    def assert_valid_and_invalid_def_undef(conditional, expected_result):
        result = Conditional().extract_defined_undefined(conditional)
        assert result == expected_result

    assert_valid_def_

# Generated at 2022-06-23 06:09:27.947789
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    ''' test_Conditional_extract_defined_undefined()
        Test the extract_defined_undefined method of class Conditional.
    '''
    conditional = Conditional()

# Generated at 2022-06-23 06:09:41.144579
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    basic tests for evaluate_conditional.
    This will only test simple "True" or "False" conditionals.
    '''

    from ansible.template import Templar

    templar = Templar(loader=None)

    vars = dict()
    cond = Conditional()

    assert cond.evaluate_conditional(templar, vars)

    cond.when = [None]
    assert cond.evaluate_conditional(templar, vars)
    cond.when = [False]
    assert not cond.evaluate_conditional(templar, vars)
    cond.when = [True]
    assert cond.evaluate_conditional(templar, vars)
    cond.when = ['']
    assert cond.evaluate_conditional(templar, vars)

# Generated at 2022-06-23 06:09:52.428507
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    tests = {
        'foo is defined': [('foo', 'is', 'defined')],
        'foo is undefined': [('foo', 'is', 'undefined')],
        'foo not is undefined': [('foo', 'not is', 'undefined')],
        'foo is defined and bar is undefined': [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')],
        'bar not is undefined': [('bar', 'not is', 'undefined')],
        'hostvars[inventory_hostname] is defined': [('hostvars[inventory_hostname]', 'is', 'defined')],
        'hostvars[inventory_hostname] is not defined': [('hostvars[inventory_hostname]', 'is not', 'defined')]
    }


# Generated at 2022-06-23 06:09:56.894766
# Unit test for constructor of class Conditional
def test_Conditional():

    class ClassUnderTest(object):
        def __init__(self):
            self.when = []
            self.changed_when = []
            self.failed_when = []

    instance = ClassUnderTest()
    assert instance._when == []
    assert instance.changed_when == []
    assert instance.failed_when == []

# Generated at 2022-06-23 06:10:08.077638
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Test for method Conditional.evaluate_conditional
    '''
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    from jinja2.environment import Environment

    class Options:
        class AnsibleVault:
            def load_vault_id(self, _): return None
            def load_vault_password(self, _, vault_id): return None
    class Loader:
        class get_vault_secret:
            def __call__(self,_): return None

    # Loader for vault
    loader = Loader()
    # Playbook variables

# Generated at 2022-06-23 06:10:15.904963
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class FakeConditional(Conditional):
        def evaluate_conditional(self, templar, all_vars):
            pass

    cond = FakeConditional()

# Generated at 2022-06-23 06:10:20.394890
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.block import Block
    from ansible.template import Templar

    block  = Block()

    # testing with a non templable non variable ansible variable
    block.when = ["test"]
    block._loader = None
    my_vars = dict(test=True)
    templar = Templar(loader=block._loader, variables=my_vars)
    assert block.evaluate_conditional(templar=templar, all_vars=my_vars)

    # testing with a templable non variable ansible variable
    block.when = [u"{{ test }}"]
    block._loader = None
    my_vars = dict(test=True)
    templar = Templar(loader=block._loader, variables=my_vars)

# Generated at 2022-06-23 06:10:21.434951
# Unit test for constructor of class Conditional
def test_Conditional():
    """Unit test for constructor of class Conditional"""
    pass

# Generated at 2022-06-23 06:10:32.937503
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    class MyConditional(Conditional):
        pass

    class VariableManager:
        def __init__(self):
            self._vars_cache = dict()
        def get_vars(self, play=None, host=None, task=None, include_hostvars=True, include_delegate_to=True):
            return self._vars_cache

    class Host:
        def __init__(self, name):
            self.name = name

    class Task(MyConditional):

        def __init__(self, loader, variable_manager, host):
            self._loader = loader
            self._variable_manager = variable_manager
            self._host = host
            self.when = []

    # Setup the environment
    loaders = []
    variable_manager = VariableManager()
    host = Host("testhost")

   

# Generated at 2022-06-23 06:10:43.626626
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # setup
    conditional = Conditional()

    # test
    result_1 = conditional.extract_defined_undefined('var is defined')
    result_2 = conditional.extract_defined_undefined('var1 is undefined')
    result_3 = conditional.extract_defined_undefined('var2 not is undefined')
    result_4 = conditional.extract_defined_undefined('var3 is defined and var4 is undefined')
    result_5 = conditional.extract_defined_undefined('"abc" is defined')
    result_6 = conditional.extract_defined_undefined("'abc' is defined")
    result_7 = conditional.extract_defined_undefined("hostvar['abc'] is defined")

# Generated at 2022-06-23 06:10:45.511441
# Unit test for constructor of class Conditional
def test_Conditional():
    cond = Conditional()
    assert(cond.when == [])
    assert(isinstance(cond, Conditional))


# Generated at 2022-06-23 06:10:55.297860
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    host_vars = {}
    inven = {}
    play_context = {}
    loader = None
    collection_list = None
    play = Conditional(loader=loader)
    all_vars = {
        'hostvars': host_vars,
        'inventory_hostname': 'localhost',
        'inventory_hostname_short': 'localhost',
        'groups': {},
        'omit': '__omit_place_holder__1234567890'
    }
    templar = None
    ################################################################################################
    # pass in a good conditional
    conditional = 'inventory_hostname == "localhost"'
    result = play.evaluate_conditional(templar, all_vars)
    ################################################################################################
    # pass in a bad conditional

# Generated at 2022-06-23 06:11:05.574510
# Unit test for constructor of class Conditional
def test_Conditional():
        # test 1
        try:
            test1 = Conditional()
            raise AnsibleError("Failed: test1")
        except AnsibleError as e:
            print(e)

        # test 2
        try:
            test2 = Conditional(loader="AnsibleLoader")
            if test2._loader != "AnsibleLoader":
                raise AnsibleError("Failed: test2")
        except AnsibleError as e:
            print(e)

        # test 3
        try:
            test3 = Conditional(when="when")
            if test3.when != ["when"]:
                raise AnsibleError("Failed: test3")
        except AnsibleError as e:
            print(e)

        # test 4

# Generated at 2022-06-23 06:11:08.521384
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()

    conditional = Conditional(play_context)
    assert conditional.when is not None

# Generated at 2022-06-23 06:11:16.969536
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    # no defined/undefined
    assert conditional.extract_defined_undefined('foo') == []
    # a simple defined
    assert conditional.extract_defined_undefined('bar is defined') == [('bar', 'is', 'defined')]
    # a simple undefined
    assert conditional.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    # a not defined
    assert conditional.extract_defined_undefined('not bar is defined') == [('bar', 'is', 'defined')]
    # a not undefined
    assert conditional.extract_defined_undefined('not foo is not defined') == [('foo', 'is not', 'defined')]
    # a complex defined

# Generated at 2022-06-23 06:11:28.008947
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=None, variable_manager=variable_manager, host_list='tests/inventory'))
    variable_manager.extra_vars = load_extra_vars('tests/ansible.cfg')

    templar = Templar(loader=None, variables=variable_manager.get_vars(loader=None, play=None, host=None))


# Generated at 2022-06-23 06:11:34.580960
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Test case 1: test various conditional syntax
    conditional = "a is defined or b is undefined"
    conditional2 = "a is not defined and c is defined"
    conditional3 = "a is undefined"
    c = Conditional()
    res= c.extract_defined_undefined(conditional)
    assert (res == [('a', 'is', 'defined'), ('b', 'is', 'undefined')])
    res= c.extract_defined_undefined(conditional2)
    assert (res == [('a', 'is not', 'defined'), ('c', 'is', 'defined')])
    res= c.extract_defined_undefined(conditional3)
    assert (res == [('a', 'is', 'undefined')])

# Unit Tests for method _check_conditional of class Conditional

# Generated at 2022-06-23 06:11:40.779630
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_obj = Conditional()

    test_conditional = "ansible_os_family == 'RedHat' and A.B is defined and B.C is undefined"
    results = conditional_obj.extract_defined_undefined(test_conditional)

    assert results == [('A.B', 'is', 'defined'), ('B.C', 'is', 'undefined')]

# Generated at 2022-06-23 06:11:42.437020
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    pass
    # TODO
    #assert False, "No test written yet for Conditional_evaluate_conditional"



# Generated at 2022-06-23 06:11:51.893974
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-23 06:12:02.642771
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # The method under test
    mut = Conditional.extract_defined_undefined


# Generated at 2022-06-23 06:12:13.768889
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined('foo is not defined and bar is defined') == [('foo', 'is not', 'defined'), ('bar', 'is', 'defined')]
    assert c.extract_defined_undefined('foo is not defined and bar is undefined') == [('foo', 'is not', 'defined'), ('bar', 'is', 'undefined')]
    assert c.extract_defined_undefined('hostvars[inventory_hostname] is not defined and bar is undefined') == [('hostvars[inventory_hostname]', 'is not', 'defined'), ('bar', 'is', 'undefined')]


# Generated at 2022-06-23 06:12:20.828140
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    def _str_to_bool(s):
        return s.lower() == "true"

    test_name = 'test_Conditional_evaluate_conditional'

    # Import modules required for this test.
    import jinja2
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    # Create test data loader
    test_dl = DataLoader()

    # Create test template
    test_template = jinja2.Template("{{ test_var }}")

    # Create test templar
    test_templar = Templar(loader=test_dl, variables={'test_var': 'test_value'})

    # Create test instance of class Conditional
    test_conditional = Conditional()

    # Create test case data

# Generated at 2022-06-23 06:12:28.352735
# Unit test for constructor of class Conditional
def test_Conditional():
    # Test that Conditional raises an error when a loader object is not provided
    try:
        Conditional()
        raise Exception("Conditional did not raise an error when a loader object was not provided")
    except AnsibleError:
        pass

    # Test that Conditional does not raise an error when a loader object is provided
    try:
        Conditional(loader=None)
    except AnsibleError:
        raise Exception("Conditional raised an error when a loader object was provided")

# Generated at 2022-06-23 06:12:31.306711
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    conditional = Conditional(loader=loader)
    assert isinstance(conditional, Conditional)
    assert isinstance(conditional._loader, DataLoader)


# Generated at 2022-06-23 06:12:42.925666
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

    assert c.extract_defined_undefined("testvar is defined") == [("testvar", "is", "defined")]
    assert c.extract_defined_undefined("testvar is not defined") == [("testvar", "is not", "defined")]
    assert c.extract_defined_undefined("testvar is undefined") == [("testvar", "is", "undefined")]
    assert c.extract_defined_undefined("testvar is not undefined") == [("testvar", "is not", "undefined")]
    assert c.extract_defined_undefined("srv.testvar is undefined") == [("srv.testvar", "is", "undefined")]

# Generated at 2022-06-23 06:12:54.525700
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def assert_expected_results(conditional, expected_results):
        c = Conditional()
        results = c.extract_defined_undefined(conditional)
        for r in expected_results:
            if r not in results:
                raise AssertionError("Expected '%s' in results %s" % (r, results))
        for r in results:
            if r not in expected_results:
                raise AssertionError("Unexpected '%s' in results %s" % (r, results))

    assert_expected_results("ansible_distribution is defined and ansible_distribution == 'RedHat'", [('ansible_distribution', 'is', 'defined')])

# Generated at 2022-06-23 06:12:59.338478
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional.when == []



# Generated at 2022-06-23 06:13:05.867332
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # generate a fake play
    play = dict(
        name='fake_play',
        hosts='localhost',
        tasks=[],
    )
    from ansible.playbook.play import Play
    play = Play().load(play, loader=None)

    # generate a fake task
    task = dict(
        name='fake_task',
        action='fake_action',
    )

    # use an empty variable manager for testing
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()
    variable_manager.set_inventory(play.get_variable_manager().inventory)

# Generated at 2022-06-23 06:13:14.681735
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager._extra_vars = dict(a=1, b=2)
    variable_manager._hostvars = dict(test1=dict(c=3, d=4))

    play_context = PlayContext()
    play_context._variable_manager = variable_manager

    templar = Templar(loader=None, variables=variable_manager.get_vars(loader=None, play=None, host=None))

    c = Conditional(loader=None)
    c._loader = None

    # Simple test
    c.when = ['a == b']