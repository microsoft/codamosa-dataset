

# Generated at 2022-06-23 06:03:25.082739
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager

    conditional = Conditional()
    assert isinstance(conditional, Conditional)

    cond = Conditional()
    m = AnsibleMapping("test", loader=None)
    assert isinstance(cond._validate_when("test_attr", "_when", m), list)

    assert cond.evaluate_conditional(templar=None, all_vars=dict()) == True

    cond = Conditional()
    cond2 = Conditional()
    assert isinstance(cond._check_conditional("", templar=cond2, all_vars=dict()), bool)

    var_manager = VariableManager()
    task = Task(loader=None)
    task

# Generated at 2022-06-23 06:03:35.308813
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # defined as true when is defined
    c = Conditional()
    assert c.evaluate_conditional("{{ test_var is defined }}", {"test_var": True}) is True
    assert c.evaluate_conditional("{{ test_var is not defined }}", {"test_var": True}) is False
    assert c.evaluate_conditional("not test_var is defined", {"test_var": True}) is False
    assert c.evaluate_conditional("not test_var is not defined", {"test_var": True}) is True

    # defined as true when is undefined
    assert c.evaluate_conditional("{{ test_var is defined }}", {"test_var": False}) is False
    assert c.evaluate_conditional("{{ test_var is not defined }}", {"test_var": False}) is True

# Generated at 2022-06-23 06:03:45.828693
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    c = Conditional()


# Generated at 2022-06-23 06:03:46.716837
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    #a = Conditional()
    assert False

# Generated at 2022-06-23 06:03:56.252514
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    display = Display()
    display.verbosity = 3
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from jinja2 import DictLoader, Environment
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    env = Environment(loader=DictLoader({}), extensions=[])
    env.filters = {}
    env.tests = {}


# Generated at 2022-06-23 06:04:06.726570
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    Conditional_ins = Conditional(loader=None) # loader=None is a hack, but it works
    mocker = Mocker()
    templar_ins = mocker.replace("ansible.playbook.templar.Templar")()
    templar_ins.is_template("var == undefined")
    mocker.result(True)
    when_value = dict(
        key = "value",
        another_key = "another_value",
        var = "value",
        hostvars = dict(
            host_name = dict(
                host_var = "host_var_value"
            )
        )
    )
    templar_ins.template("var == undefined", disable_lookups = False)
    mocker.result("False")

# Generated at 2022-06-23 06:04:16.086162
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

# Generated at 2022-06-23 06:04:24.552733
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    class MockDS():
        _data = {}
        def __init__(self, data=None):
            self._data = data
    class MockPlayContext():
        def __init__(self, variables):
            self._vars = variables
        def set_var(self, variable, value):
            self._vars[variable] = value
        def get_vars(self):
            return self._vars
        def get_var(self, variable):
            return self._vars[variable]
    class MockPlaybook():
        def __init__(self, variables):
            self._variable_manager = variables
        def get_variable_manager(self):
            return self._variable_manager

# Generated at 2022-06-23 06:04:34.676057
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.template.safe_eval import safe_eval

    class TestConditional(Conditional):
        def __init__(self):
            self._loader = None

    C.DEFAULT_HASH_BEHAVIOUR = 'merge'

    # Test basic conditions
    assert TestConditional()._check_conditional('True', Templar(loader=None, variables={}), {})
    assert TestConditional()._check_conditional('true', Templar(loader=None, variables={}), {})

# Generated at 2022-06-23 06:04:39.348425
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = "cond1 and cond2 and cond3 and cond4 and cond5 and cond6 and hostvars['foo'] is defined and cond8 and cond9 and cond10"
    c = Conditional()
    results = c.extract_defined_undefined(conditional)
    assert results == [('hostvars[\'foo\']', 'is', 'defined')]

# Generated at 2022-06-23 06:04:47.818999
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    import os

    p = Conditional()
    hostvars = {
        '127.0.0.1': {
            'ansible_ssh_pass': 'vagrant',
            'ansible_ssh_user': 'vagrant',
            'ansible_ssh_host': '127.0.0.1',
            'group_names': ['ungrouped'],
            'inventory_dir': '.',
            'inventory_file': './hosts',
            'inventory_hostname': 'localhost',
            'foo': 'bar',
            'baz': '',
            'faz': '0',
            'ansible_ssh_port': 2222,
        }
    }
    templar = Templar

# Generated at 2022-06-23 06:04:55.635532
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:05:07.381109
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.template import Templar
    from ansible.vars import VariableManager

    class TestTask(AnsibleBaseYAMLObject):
        def __init__(self, loader, name, when=None):
            super(TestTask, self).__init__()
            self._name = name
            self._loader = loader
            self._ds = None
            if when is not None:
                self.when = when

    def _make_task(name, when=None):
        class Src(TestTask, Conditional):
            ''' a simple task object '''

# Generated at 2022-06-23 06:05:16.981011
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional_class_instance = Conditional()

    # unit tests
    # TODO: Fix tests so they work when more than one conditional is provided
    assert conditional_class_instance._check_conditional(conditional = 'a',
                                                         templar = None, all_vars = dict(a=False)) == False
    assert conditional_class_instance._check_conditional(conditional = 'a',
                                                         templar = None, all_vars = dict(a=True))  == True

    # using templar, string version of 'a' is coerced to boolean
    assert conditional_class_instance._check_conditional(conditional = 'a',
                                                         templar = None, all_vars = dict(a='False')) == True

# Generated at 2022-06-23 06:05:29.312361
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    context = PlayContext()
    context._play = dict()
    context._play['vars'] = dict()
    loader_mock = MagicMock()
    cond = Conditional(loader_mock)
    cond._play_context = context
    # Test _validate_when
    # Test cases where _validate_when has to do nothing
    cond._validate_when(None, '_when', [])
    cond._validate_when(None, '_when', [None, None])
    # Test case when _validate_when has to convert to list
    cond._validate_when(None, '_when', "when_this_is_true")
    assert cond._when == [u"when_this_is_true"]
    # Test _check_

# Generated at 2022-06-23 06:05:40.245054
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def check_conditional(conditional, expected):
        c = Conditional()
        got = c.extract_defined_undefined(conditional)
        if expected != got:
            raise AssertionError("got %s instead of %s when testing: %s" % (got, expected, conditional))

    check_conditional('', [])
    check_conditional('a or b and c', [])
    check_conditional('a and b or c', [])
    check_conditional('defined a', [('a', 'is', 'defined')])
    check_conditional('a and defined b', [('b', 'is', 'defined')])
    check_conditional('defined a and b', [('a', 'is', 'defined')])

# Generated at 2022-06-23 06:05:47.377924
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.parsing.dataloader import DataLoader

    # Data
    conditional = """
    {{ foo is defined and bar is defined and xyz is not defined }}
    """
    # Setup
    c = Conditional(DataLoader())

    # Test
    res = c.extract_defined_undefined(conditional)

    # Verify
    assert res == [('foo', 'is', 'defined'), ('bar', 'is', 'defined'), ('xyz', 'is not', 'defined')]


# Generated at 2022-06-23 06:05:53.878299
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

# Generated at 2022-06-23 06:06:06.369432
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:06:15.674908
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Mock up an AnsibleBase that derives from Conditional
    class AnsibleBase(object):
        def __init__(self):
            self.when = None
            self.registered_as = None
        def set_loader(self, loader):
            self._loader = loader
    class AnsibleTask(AnsibleBase, Conditional):
        pass
    class AnsiblePlay(AnsibleBase, Conditional):
        pass
    class AnsibleRole(AnsibleBase, Conditional):
        pass
    class AnsibleVariableManager:
        def __init__(self):
            self.extra_vars = dict()
    class AnsibleInventoryManager:
        def __init__(self):
            self.hostvars = dict()

    loader = None
    var_manager = AnsibleVariableManager()
    inv_manager = Ansible

# Generated at 2022-06-23 06:06:23.133337
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    class NoopConditional(Conditional):
        def __init__(self):
            super(NoopConditional, self).__init__()


# Generated at 2022-06-23 06:06:32.096643
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    yaml_conditional = "result|d({})|length > 0 and (" \
                        "foo.rc == 0 or " \
                        "foo.rc is undefined or " \
                        "foo.rc is not defined or " \
                        "foo.rc != 5 or " \
                        "(foo.stdout is defined and " \
                        "what_i_expect in foo.stdout) or " \
                        "(foo.stderr is defined and " \
                        "what_i_expect in foo.stderr))"
    c = Conditional()
    def_undef = c.extract_defined_undefined(yaml_conditional)


# Generated at 2022-06-23 06:06:43.725765
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.plugins.loader import role_resolver
    mycond = Conditional()
    mycond.when = ['undefined_var is defined']
    # Create a dict for test
    all_vars = dict(undefined_var='foo')
    # Create a role_resolver object
    role_params = dict(roles_path='./', playbooks_paths='.', role_namespace=None)
    role_res = role_resolver.RoleResolver(**role_params)
    # Create a templar object
    templar = role_res.templar
    # Call evaluate_conditional() function
    mycond.evaluate_conditional(templar, all_vars)

# Generated at 2022-06-23 06:06:50.636014
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    vars = VariableManager()
    vars.extra_vars = {'var1': 'var1'}

    templar = Templar(loader=None, variables=vars)

    obj = Conditional(loader=None)

    # test usage of evaluate_conditional
    #  - False should be returned if the conditional is not a boolean or a string
    #  - The conditional should be True when the variable is set in the extra_vars
    #  - The conditional should be False when the variable is not set in the extra_vars
    obj._when = [
        1,
        "var1",
        "var2"
    ]

# Generated at 2022-06-23 06:07:02.391948
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    loader = DictDataLoader({})
    mock_ds = MockData()
    mock_ds._loader = loader
    mock_ds._templar = Templar(loader=loader, variables=dict())

    v = text_type(True)
    mock_ds.evaluate_conditional('1 == 1', v)
    assert v == 'True'

    v = text_type(True)
    mock_ds.evaluate_conditional('1 == 2', v)
    assert v == 'False'

    # test defined/undefined
    v = text_type(True)
    mock_ds.evaluate_conditional('myvar is defined', v)
    assert v == 'False'

    v = text_type(True)
    mock_ds.evaluate_conditional('myvar is not defined', v)
    assert v == 'True'



# Generated at 2022-06-23 06:07:05.053004
# Unit test for constructor of class Conditional
def test_Conditional():
    data = 'VAR1'
    var = Conditional.Conditional(data)
    assert var._ds == data

# Generated at 2022-06-23 06:07:12.831936
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    class Base(object):
        def __init__(self):
            self._ds = None

    class CondTest(Conditional, Base):
        pass

    c = CondTest(loader=DataLoader())
    a = VariableManager()
    a.set_host_variable('host0', 'var1', 'ansible')
    a.set_host_variable('host0', 'var2', 'host0')


# Generated at 2022-06-23 06:07:14.561560
# Unit test for constructor of class Conditional
def test_Conditional():
    # Constructor
    c = Conditional()
    assert c.when == []

# Generated at 2022-06-23 06:07:21.715567
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.template.template import Templar
    from ansible.vars.manager import VariableManager

    class TestClass(Conditional):

        def __init__(self):
            super(TestClass, self).__init__()
            self._ds = {'name': 'testplay'}

    class TestModule:
        def __init__(self, params):
            self.params = params

    class TestTask(object):
        def __init__(self, module_args, when='True'):
            self._loader = None
            self.block = None
            self.action = module_args
            self._role = None
            self._parent = None
            self._role_params = None
           

# Generated at 2022-06-23 06:07:33.352975
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    C.DEFAULT_DEBUG = True
    conditional = Conditional()

# Generated at 2022-06-23 06:07:35.670769
# Unit test for constructor of class Conditional
def test_Conditional():
    assert issubclass(Conditional, object) is True
    conditional = Conditional()
    assert isinstance(conditional, Conditional) is True


# Generated at 2022-06-23 06:07:38.015034
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert isinstance(conditional, Conditional)
    assert isinstance(conditional, object)


# Generated at 2022-06-23 06:07:46.958905
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # setup new class that inherits from Conditional
    class TestConditionalClass(Conditional):
        def __init__(self, loader, variable_manager):

            self._loader = loader
            self._variable_manager = variable_manager

            self.when = []

    # create instances of the class and its members
    loader = DictDataLoader({})
    variable_manager = VariableManager(loader=loader)
    test_class = TestConditionalClass(loader, variable_manager)

    # create the tester function that checks the outputs
    def check_output(given_input, expected_output):
        test_class.when = [given_input]
        templar = Templar(loader=loader, variable_manager=variable_manager)

# Generated at 2022-06-23 06:07:56.052747
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

    results = c.extract_defined_undefined("hostvars['foo'] is defined")
    assert results == [('hostvars[\'foo\']', 'is', 'defined')]

    results = c.extract_defined_undefined("foo is defined or hostvars['bar'] is not undefined")
    assert results == [('foo', 'is', 'defined'), ('hostvars[\'bar\']', 'is not', 'undefined')]


# Generated at 2022-06-23 06:08:05.536712
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVarsVars

    loader = DataLoader()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=dict(omg="zomg"))
    hostvars = HostVarsVars(loader=loader, variables=dict(changed_when="yes"))
    task = Task()

    all_vars = hostvars

    conditional = Conditional(loader=loader)
    conditional_arg = 'not omg == "zomg"'


# Generated at 2022-06-23 06:08:13.188679
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assertion_failed = []

# Generated at 2022-06-23 06:08:15.893611
# Unit test for constructor of class Conditional
def test_Conditional():
    '''
    Conditional() returns an instance of Conditional
    '''
    conditional = Conditional(loader=None)
    assert isinstance(conditional, Conditional)

# Generated at 2022-06-23 06:08:23.231538
# Unit test for constructor of class Conditional
def test_Conditional():

    class TestConditional(Conditional):
        def __init__(self, loader, variable1=None, variable2=None, when=None):
            self._loader = loader
            self._variable1 = variable1
            self._variable2 = variable2
            self.when = when

    # given
    when = 'variable1 is undefined'

    # when
    testcond = TestConditional(loader=None, when=when)

    # then
    assert testcond is not None
    assert testcond.when == [when]

# Generated at 2022-06-23 06:08:23.729719
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    assert True



# Generated at 2022-06-23 06:08:25.586854
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional._validate_when(None, 'a', 'hello') == None


# Generated at 2022-06-23 06:08:32.975474
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class TestConditional(Conditional):
        def __init__(self):
            self._loader = None

    conditional = TestConditional()
    # Normal conditionals
    assert conditional.extract_defined_undefined('var1 is defined') == [('var1', 'is', 'defined')]
    assert conditional.extract_defined_undefined('var1 is not defined') == [('var1', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('var1 is undefined') == [('var1', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('var1 is not undefined') == [('var1', 'is not', 'undefined')]

    # Conditional contains another conditional

# Generated at 2022-06-23 06:08:44.436266
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class ConditionalTest(Conditional):
        _when = Conditional._when

    # check if conditional is True when hostvars['foo'] is defined
    conditional_test = ConditionalTest()
    conditional_test.when = ['hostvars["foo"] is defined']
    assert conditional_test.evaluate_conditional(None, {'hostvars': {'foo': 'bar'}})

    # check if conditional is False when hostvars['foo'] is not defined
    conditional_test = ConditionalTest()
    conditional_test.when = ['hostvars["foo"] is undefined']
    assert not conditional_test.evaluate_conditional(None, {'hostvars': {'foo': 'bar'}})

    # check if conditional is True when hostvars['foo'] is defined and hostvars['bar'] is undefined
    conditional_test

# Generated at 2022-06-23 06:08:46.974349
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c._when == []


# Generated at 2022-06-23 06:08:57.717030
# Unit test for constructor of class Conditional
def test_Conditional():
    import unittest
    import sys
    import os

    class ConditionalTestCase(unittest.TestCase):

        def setUp(self):
            self.conditional = Conditional()
            self.conditional_with_loader = Conditional(loader={})

        def test_init(self):
            self.assertEqual(self.conditional._when, [])
            self.assertEqual(self.conditional._loader, None)
            self.assertEqual(self.conditional_with_loader._loader, {})

        def test_validate_when(self):
            self.conditional._validate_when('attr', 'name', True)
            self.assertEqual(self.conditional.name, [True])
            self.conditional._validate_when('attr', 'name', [True])
            self

# Generated at 2022-06-23 06:09:08.237045
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.play_context import PlayContext
    pc = PlayContext()
    c = Conditional()
    pc.setup_cache()

    assert c.extract_defined_undefined("not foo is defined") == [("foo", "not is", "defined")]
    assert c.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert c.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert c.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert c.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert c.extract_defined_

# Generated at 2022-06-23 06:09:18.623612
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    templar = DummyTemplar()
    conditional = Conditional()
    test_result_should_be_true = dict(a='a')
    test_result_should_be_false = dict(a='b')

    assert conditional.evaluate_conditional(templar, test_result_should_be_true)
    assert not conditional.evaluate_conditional(templar, test_result_should_be_false)

    conditional.when = [ "{{ a }} == 'a'" ]
    assert conditional.evaluate_conditional(templar, test_result_should_be_true)
    assert not conditional.evaluate_conditional(templar, test_result_should_be_false)

    conditional.when = [ "a == 'a'", "a == 'b'" ]

# Generated at 2022-06-23 06:09:28.760461
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class FakeConditional:
        def __init__(self):
            self.when = ['my_var is defined']
            self.when.append('my_other_var is undefined')
            self.when.append('my_other_vars is not defined')
    conditional = FakeConditional()
    extracted = conditional.extract_defined_undefined(conditional.when[0])
    assert(extracted[0][0] == 'my_var')
    assert(extracted[0][1] == 'is')
    assert(extracted[0][2] == 'defined')
    extracted = conditional.extract_defined_undefined(conditional.when[1])
    assert(extracted[0][0] == 'my_other_var')
    assert(extracted[0][1] == 'is')

# Generated at 2022-06-23 06:09:36.054490
# Unit test for constructor of class Conditional
def test_Conditional():
    class Test(Conditional):
        def __init__(self):
            super(Test, self).__init__()
    expected = Test()
    actual = Test()
    assert id(expected) != id(actual)
    assert expected == actual
    pass

### END META CLASS


# define the type of when statements
argument_spec = {
    'when': dict(type='raw'),
}



# Generated at 2022-06-23 06:09:40.862788
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.conditional import Conditional
    cond = Conditional()
    assert [] == cond.extract_defined_undefined("something")
    assert [] == cond.extract_defined_undefined("some_other_thing")
    assert [("hostvars[foo]", "is", "undefined")] == cond.extract_defined_undefined("hostvars[foo] is undefined")
    assert [("hostvars[foo]", "is", "undefined")] == cond.extract_defined_undefined("hostvars[foo] is not defined")
    assert [("hostvars[foo]", "is", "defined")] == cond.extract_defined_undefined("hostvars[foo] is defined")
    assert [("hostvars[foo]", "is", "defined")] == cond

# Generated at 2022-06-23 06:09:43.206501
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert(conditional._when == [])

# Generated at 2022-06-23 06:09:52.676476
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    c = Conditional()
    t = object()

    (result, ex) = c.evaluate_conditional(t, {'myvar': 42})
    assert result is True and ex is None, ('evaluate_conditional({}, {{myvar: 42}}) should return (True, None)'
                                           'but return (%s, %s)' % (result, ex))

    (result, ex) = c.evaluate_conditional(t, {'myvar': 42})
    assert result is True and ex is None, ('evaluate_conditional({}, {{myvar: 42}}) should return (True, None)'
                                           'but return (%s, %s)' % (result, ex))

    (result, ex) = c.evaluate_conditional(t, {})

# Generated at 2022-06-23 06:10:03.863154
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DictDataLoader({
        "some_file": "",
        "another_file": ""
    })

    pc = PlayContext()
    templar = Templar(loader=loader, variables=dict(hostvars=[dict(foo="bar")]), shared_loader_obj=None, disable_lookups=False)
    c = Conditional(loader)

# Generated at 2022-06-23 06:10:13.640002
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.base import Base

    class Dummy(Conditional, Base):
        pass

    d = Dummy()
    # Testing undefine variable
    d.when = ['a is undefined']
    res = d.evaluate_conditional(None, {})
    assert res == True
    # Testing defined variable
    d.when = ['a is defined']
    res = d.evaluate_conditional(None, {'a': 1})
    assert res == True
    # Testing defined variable with double negation
    d.when = ['not a is not defined']
    res = d.evaluate_conditional(None, {'a': 1})
    assert res == True
    # Testing True
    d.when = [True]
    res = d.evaluate_conditional(None, {'a': 1})
    assert res

# Generated at 2022-06-23 06:10:24.925375
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    import jinja2
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()
    play_context.vars = dict(
        foo='bar',
        bar='foo',
        baz=None,
        asd=True,
        fds=False,
        asdf=1,
        fdsa=0,
        existing_file='/etc/ansible/ansible.cfg'
    )

    class Dummy(Conditional):
        pass

    d = Dummy()
    t = jinja2.Environment().from_string('{{ x }}').template
    p = jinja2.Environment().from_string('{{ x | lstrip }}').template


# Generated at 2022-06-23 06:10:37.764264
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.template.template import Templar
    from ansible.parsing.dataloader import DataLoader
    print("Testing Conditional evaluate_conditional")
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader)
    context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, shared_loader_obj=loader)
    conditional = Conditional()

# Generated at 2022-06-23 06:10:38.837398
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert isinstance(conditional,Conditional)

# Generated at 2022-06-23 06:10:50.115343
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # We need a loader to load templates.
    loader = DataLoader()
    # We need a variable manager for the templar to use
    variables = VariableManager()

    # Set some variables
    variables.set_variable("does_exist", "foo")
    variables.set_variable("does_not_exist", None)
    variables.set_variable("does_not_exist_2", None)

    # Create a templar with the loader and the variables
    templar = Templar(loader=loader, variables=variables)

    # Set some facts

# Generated at 2022-06-23 06:10:57.917475
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined(conditional="") == []
    assert cond.extract_defined_undefined(conditional="ipaddress is undefined") == [('ipaddress', 'is', 'undefined')]
    assert cond.extract_defined_undefined(conditional="hostname is defined") == [('hostname', 'is', 'defined')]
    assert cond.extract_defined_undefined(conditional="o is not defined or ipaddress is undefined") == [('o', 'is', 'not defined'), ('ipaddress', 'is', 'undefined')]

# Generated at 2022-06-23 06:11:10.583568
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    v = VariableManager()
    v.extra_vars = dict(
        foo='bar',
        baz='buzz',
        empty='',
        should_exist='foobar',
        should_not_exist='foobaz',
        ignore_case=dict(foo='bar')
    )

    c = Conditional()
    c.when = [
        '"bar" in foo and "buzz" in baz',
        'empty and "foobar" in should_exist',
        '"foobaz" not in should_not_exist',
        'ignore_case | lower in { foo: "lower_case" }',
        'ignore_case | upper in { FOO: "upper_case" }'
    ]

    assert c

# Generated at 2022-06-23 06:11:18.108441
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # This is a unit test for method evaluate_conditional of class Conditional
    # A simple dummy class is used for testing.
    class Conditional_dummy_class(Conditional):
        def __init__(self, data):
            self._ds = data
            self.when = data
            self._loader = None
            Conditional.__init__(self, loader=None)

    # Create a instance of Conditional_dummy_class
    c = Conditional_dummy_class("a == '1'")

    # Create a templar instance and a dict which contains the variables.
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    from ansible.template import Templar
    templar = Templar(loader=loader)
    test_vars = dict()
    test_vars

# Generated at 2022-06-23 06:11:19.280123
# Unit test for constructor of class Conditional
def test_Conditional():
    cond = Conditional()
    assert cond

# Generated at 2022-06-23 06:11:28.047208
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert cond.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert cond.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert cond.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert cond.extract_defined_undefined("foo is bar or bar is defined") == [("bar", "is", "defined")]


# Generated at 2022-06-23 06:11:38.185856
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

    stringA = """not (foo is defined)"""
    stringB = """not (foo is undefined)"""

    stringC = """(hostvars['foo'] is defined) and (hostvars['bar'] is defined)"""
    stringD = """(hostvars['foo'] is undefined) or (hostvars['bar'] is undefined)"""

    assert sorted(cond.extract_defined_undefined(stringA)) == sorted([('foo', 'is', 'defined')])
    assert sorted(cond.extract_defined_undefined(stringB)) == sorted([('foo', 'is', 'undefined')])

# Generated at 2022-06-23 06:11:47.316029
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    my_loader = DataLoader()
    my_inv = Inventory(loader=my_loader, variable_manager=VariableManager())
    my_play = Conditional(loader=my_loader)

    my_play._ds = dict()

    # Test None, True, False
    my_play.when = [None]
    assert my_play.evaluate_conditional(my_inv.get_variable_manager()._templar, all_vars=dict()) == True
    my_play.when = [True]
    assert my_play.evaluate_conditional(my_inv.get_variable_manager()._templar, all_vars=dict()) == True
    my_play

# Generated at 2022-06-23 06:11:51.284881
# Unit test for constructor of class Conditional
def test_Conditional():
    # Test to ensure constructor of class Conditional works
    c = Conditional()
    assert hasattr(c, '_when'), "Conditional object missing '_when' attribute"


# Generated at 2022-06-23 06:12:02.170104
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    display = Display()
    display.debugverbosity = 4

    class TestConditional(Conditional):
        pass

    class TestLoader(object):
        def load_from_file(self, filename):
            pass

        def load_from_file(self, filename):
            pass

        def load(self):
            pass

    class TestPlayContext(object):
        def __init__(self):
            self.become_user = "me"
            self.remote_addr = "127.0.0.1"
            self.check_mode = False
            self.prompt = {}

    t0 = TestConditional(loader=TestLoader())
    t0._play_context = TestPlayContext()
    t0._templar = None


# Generated at 2022-06-23 06:12:07.565914
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    test_input = """
        'a' is defined and b or not c
    """
    test_output = [('b', '', 'defined'), ('c', 'not', 'defined')]
    assert test_output == c.extract_defined_undefined(test_input)
    test_input = """
        foo is defined and foo in group_names
    """
    test_output = [('foo', '', 'defined'), ('group_names', '', 'defined')]
    assert test_output == c.extract_defined_undefined(test_input)
    test_input = """
        a is defined or b is defined and c is defined or not d is defined
    """

# Generated at 2022-06-23 06:12:16.438010
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager

    vars_manager = VariableManager()
    context = PlayContext()
    context._vars_files = []
    variables = combine_vars(loader=None, var_files=context._vars_files, inventory=None)
    templar = Templar(loader=None, variables=variables, fail_on_undefined=True)


# Generated at 2022-06-23 06:12:28.974049
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import merge_hash

    loader = DataLoader()

    conditional = Conditional(loader=loader)

# Generated at 2022-06-23 06:12:40.014277
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class FakeConditional(Conditional):
        pass
    c = FakeConditional()
    assert [('hostvars["foo"]', 'is', 'defined')] == c.extract_defined_undefined('hostvars["foo"] is defined')
    assert [('foo', 'is', 'defined')] == c.extract_defined_undefined('foo is defined')
    assert [('foo', 'is', 'defined')] == c.extract_defined_undefined('foo is defined and bar or xyzzy')
    assert [('foo', 'is', 'defined'), ('bar', 'is', 'defined')] == c.extract_defined_undefined('foo and bar is defined or xyzzy')
    assert [] == c.extract_defined_undefined('xyzzy and plugh')

# Generated at 2022-06-23 06:12:47.722479
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible import constants as C
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    class TestClass(object):
        '''
        dummy class to test Conditional
        '''
        def __init__(self, loader=None, args=None, datastructure=None):
            self._ds = datastructure
            self._loader = loader
            self._args = args

    def test_Conditional(args):
        '''
        test method for Conditional class
        '''

        loader = DataLoader()

        # assign the test args

# Generated at 2022-06-23 06:12:59.473335
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    # Test some basic cases
    assert c.extract_defined_undefined('test is defined') == [('test', 'is', 'defined')]
    assert c.extract_defined_undefined('test is not defined') == [('test', 'is not', 'defined')]
    assert c.extract_defined_undefined('test is undefined') == [('test', 'is', 'undefined')]
    assert c.extract_defined_undefined('test is not undefined') == [('test', 'is not', 'undefined')]
    # Test some more complex cases
    assert c.extract_defined_undefined('test is defined and foo is undefined') == [('test', 'is', 'defined'), ('foo', 'is', 'undefined')]

# Generated at 2022-06-23 06:13:09.662783
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class FakeLoader():
        def _get_basedir(self, host):
            return '/'

    loader = FakeLoader()
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict(inventory_hostname='testhost'))
    templar = Templar(loader=loader, variable_manager=variable_manager)

    # Test static boolean value
    conditional = Conditional()
    result = conditional.evaluate_conditional(templar, variable_manager.get_vars(host=variable_manager.get_vars()['inventory_hostname']))
    assert result == True
    conditional = Conditional()
    conditional.when = [ True ]

# Generated at 2022-06-23 06:13:11.776938
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert isinstance(conditional, Conditional)
    assert conditional.when == []
    assert conditional.evaluate_conditional(conditional, {}) == True
