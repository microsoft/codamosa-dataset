

# Generated at 2022-06-23 06:03:22.277865
# Unit test for constructor of class Conditional
def test_Conditional():
    # Testing for the constructor
    conditional_when_var = [
        'var',
        'var == "a"',
        'ansible_os_family=="RedHat"',
        'var is defined and not var',
        'var is defined and (var is not none or var is not none) and var == "a"'
    ]

    conditional = Conditional()
    assert conditional._when == list()

    for w in conditional_when_var:
        conditional.when = w

    assert conditional._when == conditional_when_var



# Generated at 2022-06-23 06:03:33.764767
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.templating import Templar
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.tasks import Tasks
    from ansible.playbook.handler.include import IncludeHandler
    from ansible.template import Templar

# Generated at 2022-06-23 06:03:41.941801
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # instantiate a Conditional
    loader = None
    conditional_object = Conditional(loader=loader)

    # get attributes from the Conditional object
    _when = conditional_object._when

    # instantiate the Templar
    templar_args = []
    templar_kwargs = {}
    templar = Templar(loader=loader, variables=None, *templar_args, **templar_kwargs)

    # instantiate the all vars dict (to be tested against)
    all_vars = {}

    # set the attributes on the Conditional object
    conditional_object._when = _when

    assert conditional_object.evaluate_conditional(templar, all_vars) is None

# Generated at 2022-06-23 06:03:51.010323
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    # Use the same template language for tests as for actual runs.
    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager,
                      play_context=play_context)

    all_vars = dict(
        foo=dict(bar=2)
    )

    conditional = Conditional(loader)

    # make sure bool values are evaluated correctly
    conditional._when = [False, True]
    assert conditional.evaluate_conditional(templar, all_vars) is True


# Generated at 2022-06-23 06:03:56.498805
# Unit test for constructor of class Conditional
def test_Conditional():

    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    t = Task.load(dict(when="test == foo"), loader=loader, base_class=Conditional)
    assert t.when == ['test == foo']


# Generated at 2022-06-23 06:04:06.872345
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    testObj = Conditional()
    assert testObj.extract_defined_undefined("") == []
    assert testObj.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert testObj.extract_defined_undefined("a != b") == []
    assert testObj.extract_defined_undefined("a is defined and b is not undefined") == [("a", "is", "defined"), ("b", "is not", "undefined")]
    assert testObj.extract_defined_undefined("a is defined and (b is not undefined and c is defined)") == [("a", "is", "defined"), ("b", "is not", "undefined"), ("c", "is", "defined")]

# Generated at 2022-06-23 06:04:16.219028
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """
    Some tests to verify the new features of the `evaluate_conditional` method
    in the `Conditional` class.

    Note:
    - The `evaluate_conditional` method is a method defined in the Ansible
      library that is imported by Ansible modules.
    - The `Conditional` class inherits from the Base class.
    - The `Conditional` class uses a `jinja2.compiler.Environment` object to
      compile the Jinja2 conditional.
    - The `jinja2.compiler.Environment` uses the `jinja2.lexer.TokenStream`
      class to tokenize the conditional.
    - The `jinja2.lexer.TokenStream` class uses a `jinja2.lexer.JinjaLexer`
      object to tokenize the conditional.
    """

    ############################################################################

# Generated at 2022-06-23 06:04:24.654589
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    display.verbosity = 3


# Generated at 2022-06-23 06:04:34.726837
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    function to test the behavior of method extract_defined_undefined of
    class ansible.playbook.Conditional.
    '''


# Generated at 2022-06-23 06:04:44.645901
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play import Play

    play = Play().load(dict(
        name = "TestConditional",
        hosts = "localhost",
        gather_facts = "no",
        tasks = [
            dict(action=dict(module="debug", args=dict(msg="Hello Tokyo"))),
        ]
    ), loader=None, variable_manager=None)

    task = play.get_tasks()[0]

    # Test the default value of when
    assert task._when == []
    assert not task.evaluate_conditional(None, {})

    # Test an empty and None value of when
    task._when = ['']
    assert task.evaluate_conditional(None, {})
    task._when = [None]
    assert task.evaluate_conditional(None, {})

    # Test a string and

# Generated at 2022-06-23 06:04:54.044139
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class Conditional_test(Conditional):
        def __init__(self):
            super(Conditional_test, self).__init__()
            self.when = [u'False', u'{{ False }}', u'{{ False }}', u'{{ False }}']

    my_conds = Conditional_test()
    res = my_conds._check_conditional("foo is defined and bar is not defined", None, dict())
    assert res == False

    res = my_conds._check_conditional("foo is defined and bar is not defined", None, dict(foo=1))
    assert res == False

    res = my_conds._check_conditional("foo is defined and bar is not defined", None, dict(foo=1, bar=1))
    assert res == False

    res = my_conds._check_conditional

# Generated at 2022-06-23 06:05:06.332653
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # do evaluation
    if conditional is None or conditional == '':
        res = True
    elif isinstance(conditional, bool):
        res = conditional
    else:
        res = self._check_conditional(conditional, templar, all_vars)

    # only update if still true, preserve false
    if result:
        result = res

    display.debug("Evaluated conditional (%s): %s" % (conditional, res))
    if not result:
        break

    """
    1) when is None or ''
    2) when is False
    3) when is True
    4) AnsibleUndefinedVariable
    5) Exception

    """
    c = Conditional()
    c.when = None
    if c.evaluate_conditional(1, 2) == True:
        print("OK")
   

# Generated at 2022-06-23 06:05:16.911384
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import sys
    if sys.version_info[:2] <= (2, 6):
        # can_compile_unicode=True added in 2.7
        # https://github.com/ansible/ansible/pull/38173#issuecomment-257931036
        import unittest2 as unittest
    else:
        import unittest

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class TestConditional(unittest.TestCase):
        def setUp(self):
            self.loader = DataLoader()
            self.variable_manager = VariableManager()
            self.templar = Templar(loader=self.loader, variables=self.variable_manager)


# Generated at 2022-06-23 06:05:28.938301
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()


# Generated at 2022-06-23 06:05:37.792805
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    conditional = 'hostvars[inventory_hostname] not is undefined and hostvars[inventory_hostname]["domain"] is "redhat.com" and hostvars[inventory_hostname]["domain"] is not "redhat.com"'
    assert Conditional().extract_defined_undefined(conditional) == [('hostvars[inventory_hostname]', 'not is', 'undefined'), ('hostvars[inventory_hostname]["domain"]', 'is', '"redhat.com"'), ('hostvars[inventory_hostname]["domain"]', 'is not', '"redhat.com"')]

# Generated at 2022-06-23 06:05:45.515961
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    c = Conditional()
    # import sys; print >> sys.stderr, dir(c), c.__dict__
    c.when = ['a_true_variable', False, '']
    assert c.evaluate_conditional(None, {'a_true_variable': 'true'}) == False
    assert c.evaluate_conditional(None, {'a_true_variable': ''}) == False
    assert c.evaluate_conditional(None, {'a_true_variable': 'some value'}) == True
    assert c.evaluate_conditional(None, {'a_true_variable': None}) == True
    assert c.evaluate_conditional(None, {'a_true_variable': 0}) == True
    assert c.evaluate_conditional(None, {'a_true_variable': []}) == True
    assert c

# Generated at 2022-06-23 06:05:56.674527
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

# Generated at 2022-06-23 06:06:08.803376
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=["/dev/null"])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.remote_addr = "127.0.0.1"
    variable_manager.extra_vars = {
        'hostvars': {
            '127.0.0.1': {
                'foo': True
            }
        }
    }


# Generated at 2022-06-23 06:06:16.977730
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:06:28.917896
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class TestClass:
        @classmethod
        def extract_defined_undefined(cls, conditional):
            return Conditional.extract_defined_undefined(conditional)

    for tc in TestClass, Conditional:
        assert tc.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
        assert tc.extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
        assert tc.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
        assert tc.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]

# Generated at 2022-06-23 06:06:37.046013
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # name of the task to test
    name = 'test_Conditional_evaluate_conditional'
    # create a fake loader
    loader = DictDataLoader({
        'fake_inventory': '# test inventory\n[test_host]\nlocalhost',
        'fake_playbook': '# test playbook: %s\n- hosts: test_host\ntasks: []' % name
    })
    # create a variable manager for inventory and play vars
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager, host_list='fake_inventory'))
    # create the test task
    task = Task()
    task._role = Role()
    task._role._role_path = os.path.dirname(__file__)
    task._role._

# Generated at 2022-06-23 06:06:47.185288
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class ShipIt(Conditional):
        def __init__(self, *args, **kwargs):
            super(ShipIt, self).__init__(*args, **kwargs)
            self._validate_when = Conditional._validate_when.fget(self)

    cond = ShipIt()

    for when_type in (text_type, bool):
        all_vars = {'penguins': 'exist'}
        for when_arg in ('penguins', 'exist', True):
            all_vars['when_arg'] = when_arg
            cond.when = when_type(when_arg)
            assert cond.evaluate_conditional(Conditional._loader, all_vars)


# Generated at 2022-06-23 06:06:51.674282
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.task import Task
    from ansible.vars.unsafe_proxy import wrap_var, AnsibleUnsafeText

    # Test True conditions
    assert Conditional().evaluate_conditional(None, None) is True
    assert Conditional(_when=[True]).evaluate_conditional(None, None) is True
    assert Conditional(_when={'test':True}).evaluate_conditional(None, None) is True
    assert Conditional(_when=[None]).evaluate_conditional(None, None) is True
    assert Conditional(_when=['foo']).evaluate_conditional(None, {'foo': True}) is True
    assert Conditional(_when=['foo']).evaluate_conditional(None, {'foo': 'bar'}) is True

# Generated at 2022-06-23 06:07:02.458819
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    test_data = [
        # when, always_run, ignore_errors, should_run, should_ignore_errors
        (False, False, False, False, False),
        (True, False, False, True, False),
        (True, True, True, True, True),
        (False, True, True, True, True),
        (False, False, True, False, True),
        ("foo", "bar", "baz", False, False),
        (1, 2, 3, False, False),
        (0, False, True, False, True),
        (1, [1, 2, 3], True, False, True),
    ]

    for data in test_data:
        conditional = Conditional()
        conditional.when = data[:1]
        conditional.always_run

# Generated at 2022-06-23 06:07:03.991198
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_obj = Conditional()
    assert isinstance(conditional_obj, Conditional)

# Generated at 2022-06-23 06:07:15.068582
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # These tests are run using the unittests infrastructure.
    #
    # Run tests with:
    #   PYTHONPATH=lib:lib/ansible python test/units/test_Conditional.py
    #
    # To run a single test:
    #   PYTHONPATH=lib:lib/ansible python test/units/test_Conditional.py ConditionalTestCase.test_assert_equal
    #

    import sys
    import os
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    class ConditionalTestCase(unittest.TestCase):

        def setUp(self):
            self.vault_password = VaultSecret(b'ansible')

# Generated at 2022-06-23 06:07:16.640444
# Unit test for constructor of class Conditional
def test_Conditional():
    assert hasattr(Conditional, 'evaluate_conditional')
    assert hasattr(Conditional, '_check_conditional')

# Generated at 2022-06-23 06:07:21.871674
# Unit test for constructor of class Conditional
def test_Conditional():
    '''
    verify init of class Conditional
    '''
    #Using class directly
    try:
        c = Conditional()
        assert c
    except Exception as e:
        raise Exception('Failed to instantiate Conditional directly')

# Generated at 2022-06-23 06:07:33.352506
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    my_base = Base.load({'when': ['1']})
    assert isinstance(my_base.when, list)

    my_base = Base.load({'when': '1'})
    assert isinstance(my_base.when, list)

    # add in some vars to evaluate
    my_base._variable_manager = VariableManager()
    my_base._variable_manager.extra_vars = dict(a='1', b='2')
    my_base._variable_manager.host_vars = dict(example_host=dict(c='3', d='4'))

    my_base._loader = DummyLoader()

# Generated at 2022-06-23 06:07:42.543606
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.module_utils.six.moves import StringIO
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins import module_loader
    from ansible.template import Templar

    module_loader.add_directory(C.DEFAULT_MODULE_PATH)

    class Options:
        connection = 'local'
        verbosity = 0
        module_path = None
        forks = 5
        become = None

# Generated at 2022-06-23 06:07:48.555506
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert [('hostvars["foo"]', 'is', 'undefined')] == conditional.extract_defined_undefined('hostvars["foo"] is undefined')
    assert [('hostvars["foo"]', 'is', 'undefined'), ('hostvars["bar"]', 'is', 'undefined')] == conditional.extract_defined_undefined('hostvars["foo"] is undefined and hostvars["bar"] is undefined')
    assert [('hostvars["foo"]', 'not is', 'undefined'), ('hostvars["bar"]', 'not is', 'undefined')] == conditional.extract_defined_undefined('hostvars["foo"] is not undefined and hostvars["bar"] not is undefined')

# Generated at 2022-06-23 06:07:57.154943
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    c = Conditional()

    # test class attribute construction
    conditional_list = ['foo', 'bar']
    c.when = conditional_list
    assert c.when == conditional_list

    # test init method
    c = Conditional(loader=None)



# Generated at 2022-06-23 06:08:09.042171
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-23 06:08:21.238623
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.task_include import TaskInclude

    conditional = Conditional()

    assert conditional.extract_defined_undefined("") == []
    assert conditional.extract_defined_undefined("hostvars['foo'] is defined") == [
        ('hostvars[\'foo\']', 'is', 'defined')
    ]

    assert conditional.extract_defined_undefined("hostvars['foo'] is defined and hostvars['bar'] is not defined") == [
        ('hostvars[\'foo\']', 'is', 'defined'),
        ('hostvars[\'bar\']', 'is not', 'defined')
    ]

    # test the combination of extract_defined_undefined with evaluate_conditional
    # Note: For this test we need a TaskInclude instance, because evaluate_conditional
    #

# Generated at 2022-06-23 06:08:30.927602
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # test object instantiation
    conditional = Conditional()

    # test with undefined variable in conditional
    conditional_string = '{{ my_variable }}'
    all_vars = {}
    with pytest.raises(AnsibleUndefinedVariable):
        conditional.evaluate_conditional(conditional_string, all_vars)

    # test with empty conditional
    conditional_string = ''
    all_vars = {'my_variable': True}
    assert conditional.evaluate_conditional(conditional_string, all_vars)

    # test with valid conditional
    # test with undefined variable in conditional
    conditional_string = '{{ my_variable }}'
    all_vars = {'my_variable': True}
    assert conditional.evaluate_conditional(conditional_string, all_vars)

    # test with boolean False in

# Generated at 2022-06-23 06:08:42.509397
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-23 06:08:54.808716
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional = Conditional()

    # test 1 - template as false, conditional as true
    jinja_mock = lambda x, disable_lookups: False
    templar = type('Templar', (object,), {'is_template': lambda self, x: True, 'template': jinja_mock})()
    all_vars = dict()
    conditional.when = [True]
    assert conditional.evaluate_conditional(templar, all_vars) == False

    # test 2 - template as false, conditional as false
    conditional.when = [False]
    assert conditional.evaluate_conditional(templar, all_vars) == False

    # test 3 - template as true, conditional as false
    jinja_mock = lambda x, disable_lookups: True

# Generated at 2022-06-23 06:09:02.720947
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.base import Base

    # NB. _when is a FieldAttribute, so we must get/set it via self._data
    class Mock(Conditional, Base):
        def __init__(self, data):
            super(Mock, self).__init__()
            self._data = data.copy()

    # TODO: Possible enhancement: It would be nice to have asserts like
    #       assert_conditions_equivalent("foo is defined", "defined(foo)")
    #       In theory, this case is covered by the jinja2 template engine,
    #       but since the jinja template engine works at the ast level,
    #       it will not be able to detect typos like the one below.
    #       If we can assert some equivalence between the two provided
    #       conditions, it could make it a

# Generated at 2022-06-23 06:09:14.363880
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()


# Generated at 2022-06-23 06:09:17.616400
# Unit test for constructor of class Conditional
def test_Conditional():
    try:
        C = Conditional()
    except AnsibleError as e:
        assert isinstance(e, AnsibleError)
        assert "loader" in to_native(e)

# Generated at 2022-06-23 06:09:27.895512
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    obj = Conditional(loader)
    conditional = "foo is defined and bar is not defined"
    res = obj.extract_defined_undefined(conditional)
    assert len(res) == 2
    assert res[0] == ('foo', 'is', 'defined')
    assert res[1] == ('bar', 'is not', 'defined')

    conditional = "foo is defined and foo is undefined"
    res = obj.extract_defined_undefined(conditional)
    assert len(res) == 2
    assert res[0] == ('foo', 'is', 'defined')
    assert res[1] == ('foo', 'is', 'undefined')


# Generated at 2022-06-23 06:09:41.144010
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VarsManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    from ansible.vars.hostvars import HostVars
    import ansible.constants as C
    import os
    import sys

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()
        display.verbosity = 1
        C.DEFAULT_LOG_PATH = '/dev/null'


# Generated at 2022-06-23 06:09:42.681173
# Unit test for constructor of class Conditional
def test_Conditional():
    a = Conditional()
    assert a

# Generated at 2022-06-23 06:09:52.371665
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    datadir = 'lib/ansible/playbook/data'

    play_context = PlayContext()
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager, host_list=['localhost']))
    variable_manager.extra_vars = load_fixture(datadir, 'vars_conditional.json')
    variable_manager.options_vars = load_fixture(datadir, 'vars_conditional.json')

    templar = Templar(loader=loader, variables=variable_manager)

    conditional = Conditional(loader=loader)


# Generated at 2022-06-23 06:09:54.073640
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional != None


# Generated at 2022-06-23 06:10:03.418278
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert len(Conditional().extract_defined_undefined('hostname is defined')) == 1
    assert len(Conditional().extract_defined_undefined('hostvars[inventory_hostname] is not defined')) == 1
    assert len(Conditional().extract_defined_undefined('hostvars["inventory_hostname"] is undefined')) == 1
    assert len(Conditional().extract_defined_undefined('foo is defined and hostvars["inventory_hostname"] is undefined and bar is not defined')) == 3
    assert len(Conditional().extract_defined_undefined('hostvars["inventory_hostname"] is undefined and foo is defined and bar is not defined')) == 3

# Generated at 2022-06-23 06:10:13.324280
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:10:24.882635
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    loader = unittest_loader()
    display = Display()

    display.verbosity = 3

    class taskA(object):
        _name = 'OK'

    class taskB(object):
        _name = 'FAIL'

    class taskC(object):
        _name = 'SKIP'

    class taskD(object):
        _name = 'SKIPPED'

    class taskE(object):
        _name = 'SKIP'

    class taskF(object):
        _name = 'FAIL'

    class taskG(object):
        _name = 'OK'

    class taskH(object):
        _name = 'OK'

    class taskI(object):
        _name = 'FAIL'

    class taskJ(object):
        _name = 'SKIP'


# Generated at 2022-06-23 06:10:26.086535
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional.when == []

# Generated at 2022-06-23 06:10:38.415790
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.block import Block
    from ansible.template import Templar

    b = Block()
    t = Templar(loader=None, variables={'users': [{'name': 'junko'}]})

    b._loader = t._loader

    b.when = ["'junko' in users | map(attribute='name')"]

    assert b.evaluate_conditional(t, templar._available_variables)

    b.when = ['users is defined']
    assert b.evaluate_conditional(t, templar._available_variables)

    b.when = ['users is not defined']
    assert not b.evaluate_conditional(t, templar._available_variables)

    b.when = ['users|length is defined']

# Generated at 2022-06-23 06:10:41.559946
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block

    pb = Playbook()
    b = Block(loader=pb._loader)

    assert b._when == []

# Generated at 2022-06-23 06:10:50.412314
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def _check(conditional, expected):
        assert expected == Conditional().extract_defined_undefined(conditional)

    def check(conditional, expected):
        _check(conditional, expected)
        _check(to_text(conditional), expected)

    # Some examples of good definitions
    check('a is not defined', [('a', 'is not', 'defined')])
    check('a is undefined', [('a', 'is', 'undefined')])
    check('a not is defined', [('a', 'not is', 'defined')])
    check('a not is undefined', [('a', 'not is', 'undefined')])
    check('hostvars[inventory_hostname] is not defined', [('hostvars[inventory_hostname]', 'is not', 'defined')])

    # A bad format


# Generated at 2022-06-23 06:10:57.984002
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    # deactivated, because we don't want to fail if we add new vars, so we just print them out
    # if len(Conditional.extract_defined_undefined.__code__.co_names) > 6:
    #     raise Exception("Do not add any var to the list. Place them in the else block, if needed. Currently the list contains: " + str(list(Conditional.extract_defined_undefined.__code__.co_names)))

    # simple, one var
    assert Conditional.extract_defined_undefined.__func__("foo is defined") == [('foo', 'is', 'defined')]
    assert Conditional.extract_defined_undefined.__func__("foo isnot defined") == [('foo', 'isnot', 'defined')]
    assert Conditional.extract_defined_undefined

# Generated at 2022-06-23 06:11:10.585485
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    c = Conditional(loader=loader)

    text = "var is defined or var2 is defined and var3 is undefined"
    assert c.extract_defined_undefined(text) == [
        ('var', 'is', 'defined'),
        ('var2', 'is', 'defined'),
        ('var3', 'is', 'undefined')
    ]

    text = "var1 is defined and var2 is defined and var3 is undefined and var4 is not defined"

# Generated at 2022-06-23 06:11:22.568619
# Unit test for constructor of class Conditional
def test_Conditional():
    import jinja2
    from ansible.template import Templar

    module_vars = dict()
    module_vars['foo'] = 'bar'
    module_vars['baz'] = 'foobar'
    module_vars['bam'] = 'foobam'

    module_vars_template = dict()
    module_vars_template['foo'] = 'bar'
    module_vars_template['baz'] = 'foo{{bam}}'
    module_vars_template['bam'] = 'foobam'

    class TestConditional(Conditional):
        def __init__(self, loader):
            self._loader = loader

    tc1 = TestConditional(loader=jinja2.DictLoader(module_vars))
    tc1.when = 'foo == "bar"'
   

# Generated at 2022-06-23 06:11:23.920499
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional.when == list()


# Generated at 2022-06-23 06:11:32.614627
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.plugins import module_loader
    from ansible.plugins.loader import module_utils_loader, connection_loader, fragment_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # Create play
    play = Play.load(dict(
        name="test play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls')),
            dict(action=dict(module='debug', args=dict(msg='{{play_hosts}}'))),
        ]
    ), variable_manager=VariableManager(), loader=DataLoader())

# Generated at 2022-06-23 06:11:41.658597
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # test all the conditions listed in the documentation,
    # i.e. the C.DEFAULT_UNDEFINED_VAR_BEHAVIOR setting

    res = True
    for c in ["a == b", "a is b"]:
        res = Conditional()._check_conditional(c, None, None)
        assert res == False
    for c in ["a != b", "a is not b"]:
        res = Conditional()._check_conditional(c, None, None)
        assert res == True
    for c in ["a | b == c"]:
        res = Conditional()._check_conditional(c, None, None)
        assert res == False
    for c in ["'a' | b == 'c'"]:
        res = Conditional()._check_conditional(c, None, None)


# Generated at 2022-06-23 06:11:51.813339
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestConditional(Conditional):
        def __init__(self, data):
            self._ds = data
            # we create a fake loader here but the real one should
            # be passed in when calling self.evaluate_conditional
            self._loader = None

    class TestPlay(object):
        def __init__(self, hostvars):
            self._ds = None
            self._loader = None
            self.hostvars = hostvars

    # first we run all of the normal tests

# Generated at 2022-06-23 06:11:56.811000
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    ansible_run_tags = ['all']

# Generated at 2022-06-23 06:12:07.130770
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    module_args = dict(
        ssh_host='127.0.0.1',
        ssh_port=22,
        remote_user='john',
        password='',
        sudo=True,
        sudo_pass='letmein',
        private_key_file='/home/admin/.ssh/id_rsa',
        group_name='test_group',
        group_description='test group',
        state='present',
        debug=True,
    )

    display.verbosity = 5
    templar = Templar(loader=None, variables=module_args)

    class TestConditional(Conditional):
        _when = FieldAttribute(isa='list', default=list)

    test = TestConditional(templar)


# Generated at 2022-06-23 06:12:16.292295
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    obj = Conditional()
    exp1 = [('hostvars["foo"]', 'is', 'defined')]
    cond1 = 'hostvars["foo"] is defined'
    obs1 = obj.extract_defined_undefined(cond1)
    assert exp1 == obs1

    exp2 = [('hostvars["foo"]', 'is', 'defined')]
    cond2 = 'hostvars["foo"] is defined and ansible_check_mode'
    obs2 = obj.extract_defined_undefined(cond2)
    assert exp2 == obs2

    exp3 = [('hostvars["foo"]', 'is', 'defined'), ('ansible_check_mode', 'is', 'undefined')]
    cond3 = 'hostvars["foo"] is defined and ansible_check_mode is undefined'
   

# Generated at 2022-06-23 06:12:28.876298
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # TODO: For now it is just a test stub until we have implemented the proper test.
    conditional = Conditional()

    # Test No.1
    sample_conditional = "foo is defined and baz is undefined"
    result = conditional.extract_defined_undefined(sample_conditional)
    assert result == [('foo', 'is', 'defined'), ('baz', 'is', 'undefined')]

    # Test No.2
    sample_conditional = "foo is undefined and bar not is defined"
    result = conditional.extract_defined_undefined(sample_conditional)
    assert result == [('foo', 'is', 'undefined'), ('bar', 'not is', 'defined')]

    # Test No.3
    sample_conditional = "foo is defined or baz is undefined and bar is not defined"
   

# Generated at 2022-06-23 06:12:35.258293
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-23 06:12:36.913663
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c._when == []

# Generated at 2022-06-23 06:12:46.058892
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager

    class FakePlay():
        def __init__(self):
            self._loader, self._inventory, self._variable_manager = (DataLoader(),
                                                                     FakeInventory(),
                                                                     VariableManager())

    class FakeTasks():
        def __init__(self):
            self.tasks = [FakeTask(), FakeTask()]

    class FakeTask():
        def __init__(self):
            self.when = u'is_linux and (ansible_distribution_major_version|int < 6 or ansible_distribution_major_version|int == 10)'
            self.when_v

# Generated at 2022-06-23 06:12:58.265810
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("{{ foo is defined }}") == [("foo", "is", "defined")]
    assert conditional.extract_defined_undefined("{{ foo is not defined }}") == [("foo", "is not", "defined")]
    assert conditional.extract_defined_undefined("{{ foo is defined and bar is not defined }}") == [("foo", "is", "defined"), ("bar", "is not", "defined")]
    assert conditional.extract_defined_undefined("{{ foo is defined or bar is not defined }}") == [("foo", "is", "defined"), ("bar", "is not", "defined")]
    assert conditional.extract_defined_undefined("{{ foo is foo }}") == []

# Generated at 2022-06-23 06:13:05.403548
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    c = Conditional()

    # 1 - extract_defined_undefined with different syntaxes
    conditional = 'hostvars["foo"] is undefined'
    res = c.extract_defined_undefined(conditional)
    assert res == [("hostvars[\"foo\"]", "is", "undefined")]

    conditional = 'hostvars[foo] is defined'
    res = c.extract_defined_undefined(conditional)
    assert res == [("hostvars[foo]", "is", "defined")]

    conditional = 'foo not is defined'
    res = c.extract_defined_undefined(conditional)

# Generated at 2022-06-23 06:13:12.926569
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class TestConditional(Conditional):
        pass

    named_base_cond_attr = FieldAttribute(isa='list', default=list)
    named_base_cond_attr.name = 'named_base_cond'
    named_base_cond_attr.parent = TestConditional
    setattr(TestConditional, '_named_base_cond', named_base_cond_attr)
    named_base_cond_attr.post_validate(TestConditional, '_named_base_cond')
    named_base_cond_attr.post_validate(TestConditional, 'named_base_cond')

    t = TestConditional()

    # No when clause defined