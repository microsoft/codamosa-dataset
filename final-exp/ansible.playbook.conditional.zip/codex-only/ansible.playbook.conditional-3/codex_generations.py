

# Generated at 2022-06-23 06:03:25.972501
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert Conditional().extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert Conditional().extract_defined_undefined("foo is not defined") == [("foo", "is not", "defined")]
    assert Conditional().extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert Conditional().extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")]
    assert Conditional().extract_defined_undefined("foo is defined or bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")]

# Generated at 2022-06-23 06:03:36.248007
# Unit test for constructor of class Conditional
def test_Conditional():
    class TestConditional(Conditional):
        def __init__(self, when=None):
            super(TestConditional, self).__init__()
            self.when = when
    l = []
    test_object = TestConditional(l)
    assert test_object.when == l
    assert test_object._when == l
    test_object._validate_when(None, None, True)
    assert test_object._when == [True]
    test_object._validate_when(None, None, False)
    assert test_object._when == [False]
    # Invalid arguments should throw an exception
    try:
        test_object._validate_when(None, None, None)
        assert False
    except:
        assert True
    test_object._when = [None]
    test_object._validate

# Generated at 2022-06-23 06:03:46.931517
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.task import Task

    t = Task()
    assert t.extract_defined_undefined('foobar') == []
    assert t.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert t.extract_defined_undefined('foo not is defined') == [('foo', 'not is', 'defined')]
    assert t.extract_defined_undefined('foo not is not defined') == [('foo', 'not is', 'not defined')]
    assert t.extract_defined_undefined('foo not is not defined and bar is undefined') == [('foo', 'not is', 'not defined'), ('bar', 'is', 'undefined')]

# Generated at 2022-06-23 06:03:55.247427
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    conditional_str = 'hostvars["foo"] is defined and hostvars["bar"] is not defined and hostvars["baz"] is undefined'
    assert conditional.extract_defined_undefined(conditional_str) == [('hostvars["foo"]', 'is', 'defined'), ('hostvars["bar"]', 'is not', 'defined'), ('hostvars["baz"]', 'is', 'undefined')]
    conditional_str = 'hostvars["foo"] is defined or hostvars["bar"] is not defined and hostvars["baz"] is undefined'

# Generated at 2022-06-23 06:03:59.730548
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cnd = Conditional()
    value = cnd.extract_defined_undefined('hostvars[host] is defined and hostvars[host].port is defined')
    assert value == [('hostvars[host]', 'is', 'defined'), ('hostvars[host].port', 'is', 'defined')]

# Generated at 2022-06-23 06:04:09.518176
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    playbook_path='~/proj/ansible/lib/ansible/playbook'
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[playbook_path + '/tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    task = Conditional()

    # Check if when is not list
    task.when = 'variable_defined'
    assert task.evaluate_conditional(variable_manager, {}) == False

    # Check if when is empty
    task.when = []
    assert task.evaluate_conditional(variable_manager, {}) == False

    # Check if when has only False condition
   

# Generated at 2022-06-23 06:04:19.607081
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert len(cond.extract_defined_undefined("")) == 0
    assert len(cond.extract_defined_undefined("hostvars[inventory_hostname] is defined")) == 1
    assert len(cond.extract_defined_undefined("hostvars[inventory_hostname] is not defined")) == 1
    assert len(cond.extract_defined_undefined("hostvars[inventory_hostname] is defined and hostvars[inventory_hostname] is not defined")) == 2
    assert len(cond.extract_defined_undefined("hostvars[inventory_hostname] is defined or ansible_ssh_user is undefined")) == 2

# Generated at 2022-06-23 06:04:30.756417
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-23 06:04:40.547698
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

    # Tests with well formed strings
    assert cond.extract_defined_undefined("foo is defined or bar not is undefined") == [('foo', 'is', 'defined'), ('bar', 'not is', 'undefined')]
    assert cond.extract_defined_undefined("foo is defined or bar not is undefined and foobar is undefined") == [('foo', 'is', 'defined'), ('bar', 'not is', 'undefined'), ('foobar', 'is', 'undefined')]

    # Tests with malformed strings
    assert cond.extract_defined_undefined("foo") == []
    assert cond.extract_defined_undefined("foo is defined and bar") == [('foo', 'is', 'defined')]

# Generated at 2022-06-23 06:04:48.494001
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    assert True == evaluate_conditional(
        'True',
        {'a': True, 'b': False},
        True
    )
    assert True == evaluate_conditional(
        'a',
        {'a': True, 'b': False},
        True
    )
    assert False == evaluate_conditional(
        'b',
        {'a': True, 'b': False},
        True
    )
    assert True == evaluate_conditional(
        'a and not b',
        {'a': True, 'b': False},
        True
    )
    assert False == evaluate_conditional(
        'a and b',
        {'a': True, 'b': False},
        True
    )

# Generated at 2022-06-23 06:04:50.286450
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert isinstance(conditional, Conditional)
    assert isinstance(conditional._when, list)
    assert conditional._when == []



# Generated at 2022-06-23 06:05:02.146925
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar

    loader_mock = mock()
    templar = Templar(loader=loader_mock)

    all_vars = dict(a=1)

    m = Conditional()
    m._loader = loader_mock
    m.when = list("{{a}}==1")

    # Result
    result = m.evaluate_conditional(templar, all_vars)

    # Should have called functions in Templar
    loader_mock.path_dwim.assert_called_with("{{a}}==1")

    # This assert will fail if the call of template() inside evaluate_conditional()
    # is not using the all_vars dict as the available variables

# Generated at 2022-06-23 06:05:12.193917
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    conditional = Conditional()
    # Setup the play_context required by the Templat object
    play_context = PlayContext()
    # Setup the VariableManager
    variable_manager = VariableManager()
    # Provide some values for variables required in the Templates
    c1 = 'item.name=="Host1"'
    c2 = 'myvar=="myvalue"'
    c3 = 'myvar2=="myvalue2"'

# Generated at 2022-06-23 06:05:21.217424
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible import template
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    def _get_host_vars(host):
        return dict()

    loader = DataLoader()
    loader._get_host_vars = _get_host_vars
    templar = template.AnsibleTemplate(loader=loader)

    # test without when
    obj = Conditional(loader=loader)
    host = Host()
    assert obj.evaluate_conditional(templar, host) is True

    # test with valid when
    obj = Conditional(loader=loader)
    obj._when = ["{{ foo }}"]
    assert obj.evaluate_conditional(templar, host) is False

    # test with invalid when

# Generated at 2022-06-23 06:05:32.151262
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.module_utils.six.moves import UserDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    # some test vars

# Generated at 2022-06-23 06:05:42.654104
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader =  DictDataLoader({})
    variable_manager.set_loader(loader)
    variable_manager.extra_vars = {}
    variable_manager.options_vars = {}

    c = Conditional(loader=loader)
    t = Templar(loader=loader, variable_manager=variable_manager)

    # Test case 1
    test_string = u'hostvars["foobar"] is defined'
    result = c.extract_defined_undefined(test_string)
    assert result == [('hostvars["foobar"]', 'is', 'defined')]

    # Test case 2
    test_string = u"hostvars['foobar'] is not defined"

# Generated at 2022-06-23 06:05:54.153715
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    test_Conditional_extract_defined_undefined
    '''


# Generated at 2022-06-23 06:06:06.561601
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

    conditional = 'foo not is defined'
    res = c.extract_defined_undefined(conditional)
    assert res == [('foo', 'not is', 'defined')]

    conditional = 'foo is defined or bar not is undefined and w is defined'
    res = c.extract_defined_undefined(conditional)
    assert res == [('foo', 'is', 'defined'), ('bar', 'not is', 'undefined'), ('w', 'is', 'defined')]

    conditional = 'not foo is defined'
    res = c.extract_defined_undefined(conditional)
    assert res == []

    conditional = 'not foo is defined or bar is defined'
    res = c.extract_defined_undefined(conditional)

# Generated at 2022-06-23 06:06:08.200557
# Unit test for constructor of class Conditional
def test_Conditional():
    assert hasattr(Conditional, '_when')

# Generated at 2022-06-23 06:06:12.037796
# Unit test for constructor of class Conditional
def test_Conditional():
   loader = DictDataLoader({
       "x": "true",
       "y": "1",
       "z": "2",
       "a": "bar"
   })
   condition = Conditional(loader)
   assert condition.evaluate_conditional(loader.get_basedir(), {}) is True

# Generated at 2022-06-23 06:06:22.504712
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    t = Conditional()
    # FIXME: How to dynamically add a loader to t ?
    # t.__init__(myloader)
    t.when = ['inventory_hostname == "foo"', 'inventory_hostname == "bar"']
    t.when = [True, 'inventory_hostname == "bar"']
    t.when = [True, False]
    # FIXME: How to "fake" templar ?
    # FIXME: How to provide all_vars in a testable way ?
    # FIXME: How to get the results of the evaluate ?
    # t.evaluate_conditional(templar, all_vars)


# Generated at 2022-06-23 06:06:31.806944
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-23 06:06:44.354680
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars.manager import VariableManager

    # setup test case
    variable_manager = VariableManager()
    variable_manager.set_inventory(variable_manager.loader.load_inventory('localhost'))
    host = variable_manager.get_host('localhost')
    templar = host.get_connection('local').set_host_overrides(host)
    data = {}

# Generated at 2022-06-23 06:06:52.227580
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def _test_extract_defined_undefined(conditional, expected_result):
        expected_result = expected_result
        conditional_obj = Conditional()
        extracted = conditional_obj.extract_defined_undefined(conditional)
        if not isinstance(expected_result, list):
            expected_result = [expected_result]
        if not isinstance(extracted, list):
            extracted = [extracted]
        assert expected_result == extracted

    # test
    _test_extract_defined_undefined("not is defined", (('ansible_distribution', 'not', 'defined'),))

# Generated at 2022-06-23 06:06:55.789555
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    assert Conditional().evaluate_conditional({}, {}) is True
    assert Conditional().evaluate_conditional({}, {'result': True}).__class__ == bool

# Generated at 2022-06-23 06:06:57.319938
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional(loader=None)

    assert isinstance(conditional, Conditional)

# Generated at 2022-06-23 06:07:04.416893
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """ this is a unit test for method 'evaluate_conditional' of class Conditional
    """

    from ansible.template import Templar

    # Create a simple inventory to look up variables
    inv = dict()
    inv['hosts'] = ['localhost']
    inv['_meta'] = dict()
    inv['_meta']['hostvars'] = dict()
    inv['_meta']['hostvars']['localhost'] = dict()
    inv['_meta']['hostvars']['localhost']['var1'] = 'a'
    inv['_meta']['hostvars']['localhost']['var2'] = 'b'
    inv['_meta']['hostvars']['localhost']['var3'] = 'c'

# Generated at 2022-06-23 06:07:12.329949
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    '''
    Generates a bunch of dictionaries representing simulated variables on a
    host and ensures that when conditions are evaluated correctly.
    '''

    # run through the various types of conditions, evaluating them based
    # on a set of variables
    def _test_cond(cond, expect, vars):

        actual = Conditional()
        actual.when = [cond]
        actual.post_validate()
        templar = Templar()
        actual = actual.evaluate_conditional(templar, vars)
        assert actual == expect, "'%s' expected to evaluate to %s, but got %s" % (cond, expect, actual)

    def _test_conds(conds, expect, vars):

        for (cond, result) in conds:
            _test_cond(cond, result, vars)

    # The

# Generated at 2022-06-23 06:07:20.717887
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestConditional(Conditional):
        _when = FieldAttribute(isa='list', default=list)
        _ds = "test_ds"

    test_func1 = lambda self: True
    test_func2 = lambda self: False

    # Test that with no conditional, the result is True
    assert TestConditional().evaluate_conditional(None, None) is True

    # Test that with a None conditional, the result is True
    assert TestConditional(test_func1, None).evaluate_conditional(None, None) is True

    # Test that with True conditional, the result is True
    assert TestConditional(test_func1).evaluate_conditional(None, None) is True

    # Test that with False conditional, the result is False
    assert TestConditional(test_func2).evaluate_conditional(None, None) is False

# Generated at 2022-06-23 06:07:29.156265
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined('wow and hostvars["foo"] is undefined and whatever') == [('hostvars["foo"]', 'is', 'undefined')]
    assert cond.extract_defined_undefined('wow and ipv4 is defined and whatever') == [('ipv4', 'is', 'defined')]
    assert cond.extract_defined_undefined('wow and (hostvars["foo"] is not defined or hostvars["foo"]["bar"] is not defined) and whatever') == [('hostvars["foo"]', 'is not', 'defined'), ('hostvars["foo"]["bar"]', 'is not', 'defined')]

# Generated at 2022-06-23 06:07:30.822531
# Unit test for constructor of class Conditional
def test_Conditional():
	c = Conditional()
	assert(c.when == list)

# Generated at 2022-06-23 06:07:34.425996
# Unit test for constructor of class Conditional
def test_Conditional():
    # when used directly, this class needs a loader, but we want to
    # make sure we don't trample on the existing one if this class
    # is used as a mix-in with a playbook base class
    conditional = Conditional()



# Generated at 2022-06-23 06:07:43.444085
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block

    # Test case with conditional variable is set to a random string
    test_str1 = "v1 is defined or v2 is not defined"
    p1 = PlayContext()
    t1 = Task()
    t1.name = 'Test Case 1'
    t1.when = test_str1
    r1 = RoleDefinition()
    r1.name = 'Test Role 1'
    r1.task_blocks = [ Block(role=r1.name, task_include=t1, role=r1.name, play=p1) ]

# Generated at 2022-06-23 06:07:53.453225
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

# Generated at 2022-06-23 06:08:03.657753
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    conditional = Conditional()

    # test "when" with a variable
    simple_dict = dict()
    simple_dict['name'] = "John Doe"

    simple_list_1 = list()
    simple_list_1.append("foo")
    simple_list_1.append("bar")
    simple_list_2 = list()
    simple_list_2.append("bar")
    simple_list_2.append("baz")

    complex_dict = dict()
    complex_dict['foo'] = 'bar'
    complex_dict['doo'] = 'dah'
    complex_dict['simple_dict'] = simple_dict
    complex_dict['simple_list_1'] = simple_list_1
    complex_dict['simple_list_2'] = simple_list_2

    # a simple test
    tem

# Generated at 2022-06-23 06:08:11.940302
# Unit test for constructor of class Conditional
def test_Conditional():
    # Test when is initialized by default
    c = Conditional()
    assert c._when == list()

    # Test when can be extended
    c = Conditional()
    c.when.append('foo')
    assert c._when == ['foo']

    # Test when is replaced when set
    c = Conditional()
    c.when = 'foo'
    assert c._when == ['foo']

    # Test when can be extended after it has been set
    c = Conditional()
    c.when = 'foo'
    c.when.append('bar')
    assert c._when == ['foo', 'bar']

    # Test when can be prepended
    c = Conditional()
    c.when.prepend('foo')
    assert c._when == ['foo']

# Generated at 2022-06-23 06:08:23.183195
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

    test1 = cond.extract_defined_undefined('hostvars[inventory_hostname] is defined')
    assert len(test1) == 1
    assert test1[0][0] == 'hostvars[inventory_hostname]'
    assert test1[0][1] == 'is'
    assert test1[0][2] == 'defined'

    test2 = cond.extract_defined_undefined('hostvars[inventory_hostname] is undefined')
    assert len(test2) == 1
    assert test2[0][0] == 'hostvars[inventory_hostname]'
    assert test2[0][1] == 'is'
    assert test2[0][2] == 'undefined'

    test3 = cond.extract_defined_undefined('myvar is defined')

# Generated at 2022-06-23 06:08:34.254942
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    results = Conditional.extract_defined_undefined("defined")
    assert len(results) == 1
    assert results[0] == ("True", "", "defined")

    results = Conditional.extract_defined_undefined("defined and true")
    assert len(results) == 1
    assert results[0] == ("True", "", "defined")

    results = Conditional.extract_defined_undefined("defined_var == 'foo'")
    assert len(results) == 1
    assert results[0] == ("defined_var", "", "defined")

    results = Conditional.extract_defined_undefined("not a and b")
    assert len(results) == 2, results
    assert "a" in str(results) and "b" in str(results)

    results = Conditional.extract_defined_und

# Generated at 2022-06-23 06:08:37.704121
# Unit test for constructor of class Conditional
def test_Conditional():
    import pytest
    from ansible.playbook.play_context import PlayContext
    conditional = Conditional(PlayContext())
    assert not conditional.evaluate_conditional(None, None)


# Generated at 2022-06-23 06:08:48.064372
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # tests for evaluate_conditional
    conditional = Conditional()
    vars_manager = VariableManager()
    templar = Templar(loader=None, variables=vars_manager)

    # test for evaluate_conditional without templar
    assert conditional.evaluate_conditional(templar=None, all_vars=dict()) is False

    # test for evaluate_conditional with empty template
    conditional.when = ""
    vars_manager.set_host_variable('host1', dict(var1=True))
    vars_manager.set_host_variable('host2', dict(var2=False))
    assert conditional.evaluate_conditional(templar=templar, all_vars=dict())

    # test for

# Generated at 2022-06-23 06:08:58.382189
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar


    # test that evaluate_conditional returns True when conditional contains a jinja2 templating delimiters
    pc = PlayContext()
    p  = Play().load({}, play_context=pc, variable_manager=None, loader=None)

    conditional = '{{hostvars[inventory_hostname][\'ansible_facts\'][\'distribution\']}}'
    conditional += 'in group_names'
    assert Conditional().evaluate_conditional(Templar(loader=None, variables=None), {})

    # test that evaluate_conditional returns True when conditional has a defined variable
    pc = PlayContext()

# Generated at 2022-06-23 06:09:08.379633
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    # Test 1: extract from a conditional
    conditional = "hostvars[inventory_hostname] is defined and hostvars[inventory_hostname]['myvar'] is defined"
    res = c.extract_defined_undefined(conditional)
    assert [('hostvars[inventory_hostname]', 'is', 'defined'), ('hostvars[inventory_hostname][\'myvar\']', 'is', 'defined')] == res

    # Test 2: extract from a conditional, with inverted logic
    conditional = "hostvars[inventory_hostname] is not defined or hostvars[inventory_hostname]['myvar'] is not defined"
    res = c.extract_defined_undefined(conditional)

# Generated at 2022-06-23 06:09:17.617171
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = {
        "a":{
            "hosts":["localhost"]
        },
        "b":{
            "hosts":["localhost"]
        }
    }
    variable_manager.set_inventory(inventory.copy())

    task_vars = variable_manager.get_vars(loader=loader, play=None)

    templar = Templar(loader=loader, variable_manager=variable_manager)


# Generated at 2022-06-23 06:09:23.368142
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.task import Task
    task = Task()
    conditional = "foo is not defined or some_var is defined or other_var is not defined"
    matches = task.extract_defined_undefined(conditional)
    assert 2 == len(matches), matches
    assert ("other_var", " is not", "defined") == matches[1], matches


# Generated at 2022-06-23 06:09:32.359442
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    ''' test_Conditional_extract_defined_undefined: test method extract_defined_undefined '''
    # pylint: disable=too-many-statements,too-many-locals,protected-access
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Prepare test environment
    t = TaskInclude()

    # make sure we don't overwrite variables
    t.when = ['a', 'b', 'c']

    # Make sure method is present
    assert hasattr(t, 'extract_defined_undefined')
    assert callable(t.extract_defined_undefined)

    # Prepare some test conditions
    tests = dict()


# Generated at 2022-06-23 06:09:33.752086
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c

# Generated at 2022-06-23 06:09:44.607821
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Setup
    class SomeClass(Conditional):
        _loader = None

        def __init__(self):
            self.when = ["[1,2,3] == [1,2,3]"]

    # Exercise

    some_class = SomeClass()

    # Verify
    assert some_class.evaluate_conditional({}, {})

    # Setup
    some_class.when = ["1 == 1", "'a' in 'abc'"]

    # Exercise

    # Verify
    assert some_class.evaluate_conditional({}, {})

    # Setup
    some_class.when = ["1 == 1", "'a' in 'abc'", "'a' in 'bcd'"]

    # Exercise

    # Verify
    assert not some_class.evaluate_conditional({}, {})

    # Setup
    some_class.when

# Generated at 2022-06-23 06:09:53.305818
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    conditional = """
    myvar is defined and
    hostvars['other_host']['myvar'] == 'good' and
    not hostvars[inventory_hostname]['myvar'] == anothervar and
    myvar == 'a' or (myvar is not None and myvar != 'a')
    """

    results = [
        ('myvar', 'is', 'defined'),
        ('hostvars[\'other_host\'][\'myvar\']', '==', 'defined'),
        ('hostvars[inventory_hostname][\'myvar\']', '==', 'defined'),
        ('myvar', '==', 'defined'),
        ('myvar', 'is', 'undefined'),
        ('myvar', '!=', 'defined'),
        ('myvar', 'is', 'defined')
    ]


# Generated at 2022-06-23 06:09:54.454249
# Unit test for constructor of class Conditional
def test_Conditional():
    Conditional()


# Generated at 2022-06-23 06:10:05.565893
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import jinja2.exceptions
    import ansible.playbook.play_context
    import ansible.template
    import ansible.vars

    loader = DictDataLoader({
        "./include_variables.yml": """
        foo: bar
        """
    })
    play_context = ansible.playbook.play_context.PlayContext()
    templar = ansible.template.Templar(loader=loader, variables={}, shared_loader_obj=None, play_context=play_context)
    templar._available_variables = ansible.vars.VarsModule(loader=loader).get_vars(loader=loader, play=None)
    conditional = Conditional(loader=loader)

    # noop

# Generated at 2022-06-23 06:10:12.902487
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Mock the base for a Conditional
    base = "ansible.playbook.play_context.PlayContext"

    # Mock the templar for a Conditional
    templar = "ansible.template.Templar"

    # Mock the all_vars for a Conditional
    all_vars = "all_vars"

    # Mock the conditional for a Conditional
    conditional = "ansible.playbook.task.Task"

    # Call the method
    Conditional.evaluate_conditional(
        base, templar, all_vars, conditional
    )

# Generated at 2022-06-23 06:10:14.740679
# Unit test for constructor of class Conditional
def test_Conditional():
    assert False, "No test for class Conditional"

# Generated at 2022-06-23 06:10:25.886901
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

# Generated at 2022-06-23 06:10:38.379121
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.vars.hostvars import HostVars

    variable_manager = VariableManager()
    variable_manager.set_host_variable(HostVars(variable_manager, 'localhost'))
    variable_manager.extra_vars = dict(one=1,two=2)
    play_context = PlayContext(variable_manager=variable_manager)
    templar = Templar(loader=None, variables=variable_manager.get_vars(loader=None, play=None, host=None))

    c = Conditional(loader=None)
    c.when = "{{ one == 1 }} and {{ two == 2 }}"

# Generated at 2022-06-23 06:10:49.859279
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('') == []
    assert conditional.extract_defined_undefined('foo') == []
    assert conditional.extract_defined_undefined('foo not is defined') == [('foo', 'not is', 'defined')]
    assert conditional.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo bar not is undefined') == [('foo', 'not is', 'undefined')]
    assert conditional.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]

# Generated at 2022-06-23 06:10:57.767514
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert conditional.extract_defined_undefined("a is defined or b is defined") == [("a", "is", "defined"), ("b", "is", "defined")]
    assert conditional.extract_defined_undefined("a_2 is not undefined") == [("a_2", "is not", "undefined")]
    assert conditional.extract_defined_undefined("a_3 not is defined") == [("a_3", "not is", "defined")]
    assert conditional.extract_defined_undefined("a_4 is not defined") == [("a_4", "is not", "defined")]

# Generated at 2022-06-23 06:11:10.538896
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

# Generated at 2022-06-23 06:11:18.082304
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    vars = VariableManager()
    hostvars = dict(
        foo='bar',
        baz=42,
        present=dict(
            first_key='first_value',
            second_key='second_value',
            third_key=[
                'first_item',
                'second_item',
                'third_item'
            ],
        ),
        absent=[],
    )
    vars.set_host_variable('localhost', hostvars)

    # Create a PlayContext to get the templar, and a loader
    loader = DictDataLoader({})
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=vars, play_context=play_context)

    all_vars

# Generated at 2022-06-23 06:11:28.457764
# Unit test for constructor of class Conditional
def test_Conditional():
    class TestPlaybook:
        def __init__(self):
            self.loader = None

    class TestHost:
        def __init__(self):
            self.vars = dict()

    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    test_playbook = TestPlaybook()
    test_host = TestHost()
    test_task = Task()

    test_task.loader = loader
    test_task.vars = test_host.vars
    test_task.when = []
    test_task.when.append('test_task.vars[\'test_var\'] == \'test_var_value\'')

# Generated at 2022-06-23 06:11:30.132575
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c is not None


# Generated at 2022-06-23 06:11:40.001001
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # Empty Conditional
    c = Conditional()
    assert c.evaluate_conditional(None, None)

    # Single Conditional
    c = Conditional()
    c.when = ["{{TestVar}} == 'foo'"]
    t = Task()
    t.vars = dict(TestVar='foo')
    var_manager = VariableManager()
    var_manager.set_host_variable(None, t.vars)
    assert c.evaluate_conditional(Templar(var_manager), all_vars=dict())

    # Multiple Conditionals
    c = Conditional()

# Generated at 2022-06-23 06:11:48.462627
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    all_vars = dict(
        a=1,
        b=2,
        c='foo',
        d=[1,2,3,4],
        e=dict(f=[1,2,3], g=dict(h=1)),
    )

    class FakeObj:
        pass

    conditional = Conditional()

    assert conditional.evaluate_conditional(Templar(PlayContext(variable_manager=dict(vars=all_vars))), all_vars)

    conditional.when = []
    assert not conditional.evaluate_conditional(Templar(PlayContext(variable_manager=dict(vars=all_vars))), all_vars)

    conditional.when = ["a == 1"]

# Generated at 2022-06-23 06:12:00.702259
# Unit test for constructor of class Conditional
def test_Conditional():
    def _module(**kwargs):
        return type('FooModule', (object,), kwargs)()

    def _ds(**kwargs):
        return type('FooDS', (object,), kwargs)()

    def _loader(**kwargs):
        return type('FooLoader', (object,), kwargs)()

    module = _module()
    ds = _ds(module=module)
    loader = _loader(path_exists=lambda x: True)

    def _conditional(**kwargs):
        return type('FooConditional', (Conditional,), kwargs)(loader=loader)

    # Valid when value
    result = _conditional(when=["foo"])._validate_when("_when", "_when", "foo")
    assert result is None
    assert _cond

# Generated at 2022-06-23 06:12:07.480052
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible import playbook
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    p=Play()
    cond = Conditional()
    cond._loader = p._loader
    cond._ds = p._ds

# Generated at 2022-06-23 06:12:08.396167
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()

# Generated at 2022-06-23 06:12:16.699754
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()


# Generated at 2022-06-23 06:12:29.217937
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Function to test method evaluate_conditional of class Conditional.
    '''
    class Test_Conditional():
        '''
        Class to test method evaluate_conditional of class Conditional.
        '''
        def __init__(self, conditional):
            self._ds = "ds"
            self.when = conditional

    conditional_test_run = Test_Conditional(["{{ 1 == 2 }}", "{{ 1 == 1 }}", "{{ 1 == 1 }} and {{ 2 == 1 }}", "{{ 1 == 1 and 2 == 1 }}"])

    assert conditional_test_run.evaluate_conditional(conditional_test_run, {"1": 1, "2": 2}) == False


# Generated at 2022-06-23 06:12:35.414290
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    extract_defined_undefined = conditional.extract_defined_undefined
    assert extract_defined_undefined("foo is defined or bar is not defined") == \
        [("foo", "is", "defined"), ("bar", "is not", "defined")]
    assert extract_defined_undefined("foo is defined or bar is defined") == \
        [("foo", "is", "defined"), ("bar", "is", "defined")]
    assert extract_defined_undefined("foo is defined and bar is defined") == \
        [("foo", "is", "defined"), ("bar", "is", "defined")]
    assert extract_defined_undefined("foo is defined and bar is not defined") == \
        [("foo", "is", "defined"), ("bar", "is not", "defined")]

# Generated at 2022-06-23 06:12:40.667520
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader, inventory, variable_manager = C.load_extra_vars(loader=None, inventory=None, variable_manager=None)
    sample_host = inventory.get_host("testhost")
    play_context = PlayContext(variable_manager=variable_manager, loader=loader)
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=play_context, host=sample_host, include_hostvars=True))

    c = Conditional(loader)
    conditional = "test_conditional"
    setattr(c, "when", [])
    setattr(c, "when", conditional)

# Generated at 2022-06-23 06:12:42.045737
# Unit test for constructor of class Conditional
def test_Conditional():
    assert hasattr(Conditional, '_when')


# Generated at 2022-06-23 06:12:48.758503
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    x1 = conditional.extract_defined_undefined("defined foo")
    assert x1 == [("foo", "is", "defined")]

    x2 = conditional.extract_defined_undefined("defined foo and defined bar")
    assert x2 == [("foo", "is", "defined"), ("bar", "is", "defined")]

    x3 = conditional.extract_defined_undefined("defined foo_bar")
    assert x3 == [("foo_bar", "is", "defined")]

    x4 = conditional.extract_defined_undefined("(defined foo)")
    assert x4 == [("foo", "is", "defined")]

    x5 = conditional.extract_defined_undefined("defined foo or defined bar and undefined baz")

# Generated at 2022-06-23 06:13:00.288554
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

# Generated at 2022-06-23 06:13:10.202944
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("a.b is not defined and c.d.e is undefined") == [("a.b", "is not", "defined"), ("c.d.e", "is", "undefined")]
    assert cond.extract_defined_undefined("a.b isnot defined and c.d.e is undefined") == []
    assert cond.extract_defined_undefined("hostvars['a'].b is not defined and c.d.e is undefined") == [("hostvars['a'].b", "is not", "defined"), ("c.d.e", "is", "undefined")]

# Generated at 2022-06-23 06:13:18.748374
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    mod = 'fail'
    msg = 'The conditional check failed'

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Check Boolean values in a list of conditional
    cond = Conditional()
    cond.when = [True, False, True, True]
    assert cond.evaluate_conditional(Templar(loader=None, variables={}), {}) == False

    # Check Boolean values in a list of conditional
    cond = Conditional()
    cond.when = [True, True, True]
    assert cond.evaluate_conditional(Templar(loader=None, variables={}), {}) == True

    # Check non-templated string values in a list of conditional
    cond = Conditional()
    cond.when = ['True', 'False', 'True', 'True']
   