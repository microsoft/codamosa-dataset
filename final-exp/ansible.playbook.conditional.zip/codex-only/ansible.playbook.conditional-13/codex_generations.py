

# Generated at 2022-06-23 06:03:24.834697
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    Test the extract_defined_undefined method of the Conditional class
    '''

    display.banner("TESTING CONDITIONAL EXTRACT DEFINED UNDEFINED")
    assert Conditional().extract_defined_undefined("foo.bar is defined") == [("foo.bar", "is", "defined")]
    assert Conditional().extract_defined_undefined("foo.bar is undefined") == [("foo.bar", "is", "undefined")]
    assert Conditional().extract_defined_undefined("foo.bar is not defined") == [("foo.bar", "is not", "defined")]
    assert Conditional().extract_defined_undefined("foo.bar is not undefined") == [("foo.bar", "is not", "undefined")]
    assert Conditional().extract_

# Generated at 2022-06-23 06:03:34.448712
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.base import Base
    b = Base()
    conditional = b.extract_defined_undefined('not foo.bar.endswith("y") and "TEST" is defined and (not hostvars[inventory_hostname]["TEST"] is defined or hostvars[inventory_hostname]["TEST"])')
    assert conditional == [['foo.bar', 'endswith', 'y'],
                           ['TEST', 'is', 'defined'],
                           ['hostvars[inventory_hostname]["TEST"]', 'is', 'defined'],
                           ['hostvars[inventory_hostname]["TEST"]', 'is', 'undefined']], 'Conditional.extract_defined_undefined() failed'

# Generated at 2022-06-23 06:03:44.756104
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = 'test1 == 1 and (test2 == 2 or test3 == 3) and test4 == 4'
    result = True
    test_play = 'play'
    play_vars = dict(test1=2, test2=2, test3=5, test4=4)

    # Parses the conditional and checks the value
    def mock_is_template(conditional):
        return True

    def mock_is_unsafe(conditional):
        return False

    def mock_template(conditional, disable_lookups=True):
        return 'test1 == 1 and (test2 == 2 or test3 == 3) and test4 == 4'

    conditional_base = Conditional()
    conditional_base.is_template = mock_is_template
    conditional_base.is_unsafe = mock_is_unsafe
   

# Generated at 2022-06-23 06:03:46.431712
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional


# Generated at 2022-06-23 06:03:55.690639
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # set up
    conditional = Conditional()

# Generated at 2022-06-23 06:04:06.130648
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    class TestConditional(Conditional):
        when = FieldAttribute(isa='list', default=list, extend=True, prepend=True)

    print('''
    Conditional Unit Test
    ---------------------
    ''')

    # The test below requires an inventory, so let's create a dummy one
    loader = DataLoader()
    inventory = loader.load_inventory_from_list(
        [{"hosts": ["testhost"], "vars": {"testvar": "testval"}}]
    )
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    display.verbosity = 2


# Generated at 2022-06-23 06:04:15.637546
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    display.verbosity = 3

    # Ideally we could test this on a class that inherits from Conditional,
    # but with the new class loading in 2.4, we cannot import any Ansible
    # internals from this directory.
    c = Conditional()

    # empty
    assert c.evaluate_conditional("", {})

    # basic string
    versions = {
        'ansible_facts': {
            'version': '2.4'
        }
    }
    assert c.evaluate_conditional("ansible_facts.version == '2.4'", versions)

    # basic string with env var
    versions = {
        'ansible_facts': {
            'version': '2.4'
        }
    }
    assert c.evaluate_conditional("version == '2.4'", versions)

    #

# Generated at 2022-06-23 06:04:16.471240
# Unit test for constructor of class Conditional
def test_Conditional():
    Conditional()

# Generated at 2022-06-23 06:04:24.739538
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import RoleInclude
    from ansible.template import Templar

    fake_loader = DictDataLoader({
        'test_conditional.yml': '',
        'test_conditional.j2': '{{ lookup("pipe", "echo yes") }}',
    })

    fake_task = Task()
    fake_task._role = RoleInclude()
    fake_task._role._role_path = '/path/to/fake'
    fake_task._role._role_name = 'fake'
    fake_task._role._parent_role = RoleInclude()
    fake_task._role._parent_role._role_path = '/path/to/parent/fake'
    fake

# Generated at 2022-06-23 06:04:25.587468
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()

# Generated at 2022-06-23 06:04:33.571620
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined") == [(u'foo', u'is', u'defined')]
    assert conditional.extract_defined_undefined("foo not is defined") == [(u'foo', u'not is', u'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [(u'foo', u'is', u'not defined')]
    assert conditional.extract_defined_undefined("foo is defined and bar is undefined") == [(u'foo', u'is', u'defined'), (u'bar', u'is', u'undefined')]

# Generated at 2022-06-23 06:04:37.503509
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    c = Conditional()
    context = PlayContext()
    templar = Templar(loader=None, variables={})
    assert not c.evaluate_conditional(templar, context)

# Generated at 2022-06-23 06:04:46.515273
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert c.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined('bar is undefined and baz is not defined') == [
        ('bar', 'is', 'undefined'),
        ('baz', 'is not', 'defined')
    ]

# Generated at 2022-06-23 06:04:48.432461
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert isinstance(conditional, Conditional)


# Generated at 2022-06-23 06:04:55.959268
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

    # test 01: None
    val = cond.extract_defined_undefined(None)
    assert val == []

    # test 02: empty
    val = cond.extract_defined_undefined("")
    assert val == []

    # test 03: no match
    val = cond.extract_defined_undefined("foo")
    assert val == []

    # test 04: no match
    val = cond.extract_defined_undefined("foo is undefined")
    assert val == []

    # test 05: simple match
    val = cond.extract_defined_undefined("foo is defined")
    assert val == [("foo", "is", "defined")]

    # test 06: simple match
    val = cond.extract_defined_undefined("foo is not undefined")

# Generated at 2022-06-23 06:04:57.742225
# Unit test for constructor of class Conditional
def test_Conditional():
    cond = Conditional()
    if cond is None:
        return False
    return True

# Generated at 2022-06-23 06:05:09.014153
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar

    # Set up data structures required by the Ansible module.
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Set up some variables.

# Generated at 2022-06-23 06:05:17.493102
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    c = Conditional(loader=loader)

    # defined
    assert c.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined('bar not is defined') == [('bar', 'not is', 'defined')]
    assert c.extract_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert c.extract_defined_undefined('hostvars[inventory_hostname] not is defined') == [('hostvars[inventory_hostname]', 'not is', 'defined')]
    assert c.extract_defined

# Generated at 2022-06-23 06:05:29.157432
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.task import Task

    c = Conditional()
    assert c._when == []
    assert c._validate_when == FieldAttribute.default_validate

    c = Conditional(loader=1)
    assert c._loader == 1
    assert c._when == []
    assert c._validate_when == FieldAttribute.default_validate

    c = Conditional(when="1")
    assert c._when == ["1"]
    assert c._validate_when == FieldAttribute.default_validate

    e = None
    try:
        c = Conditional()
    except Exception as ex:
        e = ex
    assert isinstance(e, AnsibleError)
    assert str(e) == "a loader must be specified when using Conditional() directly"

    t = Task()

# Generated at 2022-06-23 06:05:31.655156
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional(loader=None)
    assert c._loader is None


# Generated at 2022-06-23 06:05:41.552684
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Setup
    class TestConditional(Conditional):
        def __init__(self, loader):
            self.when = []
            self.name = 'test'
            self._loader = loader

    loader = DictDataLoader({'test1.yml': '', 'test2.yml': ''})
    obj = TestConditional(loader)
    obj._templar = Templar(loader=loader, variables={'one': 1, 'two': 'TWO', 'three': ['a', {'b': 'B'}], 'four': [1, 2]})
    obj._templar._available_variables = {'one': 1, 'two': 'TWO', 'three': ['a', {'b': 'B'}], 'four': [1, 2]}

    # Test conditional value, expect True
    obj.when

# Generated at 2022-06-23 06:05:53.104847
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("{{ foo }}") == []
    assert c.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert c.extract_defined_undefined("hostvars['foo'] is not undefined") == [('hostvars[\'foo\']', 'is not', 'undefined')]
    assert c.extract_defined_undefined("hostvars[\"foo\"] is not undefined") == [('hostvars[\"foo\"]', 'is not', 'undefined')]
    assert c.extract_defined_undefined("foo is not defined and baz is defined")

# Generated at 2022-06-23 06:06:05.057678
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    def assert_result(conditional, result):
        t = Templar(loader=None, variables={'a': 1, 'b': 2})
        r = Conditional().evaluate_conditional(templar=t, all_vars=t.available_variables)
        assert(result == r)

    # Test if it is possible to calculate simple boolean operations
    assert_result("a == 1", True)
    assert_result("b != 2", False)
    assert_result("a < b", True)
    assert_result("b > 1", True)
    assert_result("a <= 1", True)
    assert_result("a <= a", True)
    assert_result("b >= 2", True)
    assert_result("a != 1", False)

# Generated at 2022-06-23 06:06:14.973093
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    class TestConditional(Conditional):
        def __init__(self):
            super(TestConditional, self).__init__()

    c = TestConditional()

    cond = "a is defined"
    results = c.extract_defined_undefined(cond)
    assert(results[0][0] == "a")
    assert(results[0][1] == "is")
    assert(results[0][2] == "defined")

    cond = "a.b.c is defined"
    results = c.extract_defined_undefined(cond)
    assert(results[0][0] == "a.b.c")
    assert(results[0][1] == "is")
    assert(results[0][2] == "defined")

    cond = "foobar is undefined"
    results = c.ext

# Generated at 2022-06-23 06:06:25.930232
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

    # Test valid strings
    assert cond.extract_defined_undefined('v1 is defined and v2 is not undefined') == [
        ('v1', 'is', 'defined'), ('v2', 'is not', 'undefined')
    ]
    assert cond.extract_defined_undefined(' v1 is defined and v2 is not undefined ') == [
        ('v1', 'is', 'defined'), ('v2', 'is not', 'undefined')
    ]
    assert cond.extract_defined_undefined(' v1 is defined and v2 is not undefined or v3 is undefined ') == [
        ('v1', 'is', 'defined'), ('v2', 'is not', 'undefined'), ('v3', 'is', 'undefined')
    ]

    # Test invalid strings
    # -

# Generated at 2022-06-23 06:06:26.950400
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c != None


# Generated at 2022-06-23 06:06:34.323093
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    host_vars = dict(foo='bar')
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.set_host_variable(inventory.get_host('localhost'), 'hostvars', host_vars)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)

    c = Conditional(loader)
    all_vars = variable

# Generated at 2022-06-23 06:06:45.461510
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    try:
        import jinja2
    except:
        print("SKIP: jinja2 is not installed")
        import sys
        sys.exit(0)

    from ansible.playbook.base import Base
    from ansible.template import Templar

    class DummyTask(Base, Conditional):
        name = "test"

    t = DummyTask(dict(name="test"))
    t._loader = DummyLoader()
    t._templar = Templar(loader=t._loader)

    import pprint
    pp = pprint.PrettyPrinter(indent=4)


# Generated at 2022-06-23 06:06:46.675852
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional(loader=None)
    assert c is not None

# Generated at 2022-06-23 06:06:56.287198
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:07:00.231045
# Unit test for constructor of class Conditional
def test_Conditional():
    """
    Construct a new Conditional object with loader object as a parameter
    """
    # Loader object is needed for instantiating this class
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    cond = Conditional(loader)
    assert cond._loader is loader


# Generated at 2022-06-23 06:07:11.976901
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import ansible.playbook.play

    # Explanation of tests:
    #
    # The tests are defined as a list of dicts.
    # The dicts have the following keys:
    #Key              | What it represents
    #-----------------+----------------------------------------
    #when             | The 'when' statement to be evaluated (required)
    #extra_vars       | Extra vars (dict) to be used in the eval (optional)
    #host_vars        | Host vars (dict) to be used in the eval (optional)
    #group_vars       | Group vars (dict) to be used in the eval (optional)
    #register_vars    | Register vars (dict) to be used in the eval (optional)
    #playbook_dir     | Directory of the playbook (optional)
    #expected_results | List of

# Generated at 2022-06-23 06:07:20.519695
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # First, we need to create a dummy class which extends Conditional
    class DummyClass(Conditional):
        pass

    # Some tests for the same jinja2 error for the different versions
    # of jinja2 that we use
    # Note: We don't test for None here as we're not sure that it is
    # always undefined
    tests = {}
    tests['jinja2.exceptions.UndefinedError'] = "NameError: name 'undefined' is not defined"
    tests['jinja2.exceptions.UndefinedError:'] = "NameError: name 'undefined' is not defined"

# Generated at 2022-06-23 06:07:29.053862
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    # creating a task
    task = Task()
    # assert the default value of when is an empty list
    assert (task.when == [])

    task.when = "joe is defined"
    results = task.extract_defined_undefined("joe is defined")
    assert (results == [("joe", "is", "defined")])

    task.when = "joe is not defined"
    results = task.extract_defined_undefined("joe is not defined")
    assert (results == [("joe", "is not", "defined")])

    task.when = "joe is not defined or bar is defined"
    results = task.extract_defined_

# Generated at 2022-06-23 06:07:41.070368
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    tests for the Conditional class extract_defined_undefined method
    '''
    from ansible.playbook import Play

    data = {"foo": 42, "bar": 43, "baz": None}
    p = Play().load({}, loader=DictDataLoader({}), variable_manager=VariableManager(loader=DictDataLoader({}), inventory=Inventory(host_list=['dummy'])))
    c = Conditional(loader=DictDataLoader({}))

    # Test trivial case of no defined/undefined
    result = c.extract_defined_undefined("42 == 42")
    assert result == []

    # Test all possible combinations
    result = c.extract_defined_undefined("hostvars['foo'] is defined")

# Generated at 2022-06-23 06:07:52.279794
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader

    # Test constructor with a loader and empty when
    loader = DataLoader()
    conditional = Conditional(loader)
    assert(conditional.when == [])

    # Test constructor without loader
    try:
        conditional = Conditional()
        assert(False)
    except AnsibleError:
        assert(True)
        pass

    # Test _validate_when with list
    conditional = Conditional(loader)
    conditional._validate_when(None, None, [ 1, 2, 3 ])
    assert(conditional.when == [ 1, 2, 3 ])

    # Test _validate_when with single value
    conditional = Conditional(loader)
    conditional._validate_when(None, None, 4)
    assert(conditional.when == [ 4 ])

# Generated at 2022-06-23 06:07:54.016815
# Unit test for constructor of class Conditional
def test_Conditional():
    Conditional()


# Generated at 2022-06-23 06:08:02.285048
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Test cases, each test case is a tuple of the form:
    # (when, expected, raise_exception)

    # Test 1: when is not a list but a boolean, should convert to a list
    # and evaluate properly
    test1 = (True, True, False)

    # Test 2: when is not a list and not supported type, should raise exception
    test2 = ('string', False, True)

    # Test 3: when is a list but the elements are invalid types, should raise exception
    test3 = ([1,2,3], False, True)

    # Test 4: when is an empty list, should evaluate to True
    test4 = ([], True, False)

    # Test 5: when is a list with only one element, should evaluate properly

# Generated at 2022-06-23 06:08:11.448643
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.helpers import load_list_of_blocks
    from ansible.parsing.splitter import parse_kv
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()


# Generated at 2022-06-23 06:08:22.777495
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    def my_lookup(templar, item_name, **kwargs):
        return "my_lookup_result"

    test_class = Conditional()

    assert test_class.evaluate_conditional(
        Templar(loader=None, variables=VariableManager()), {}) is False
    test_class.when = ['foobar']
    assert test_class.evaluate_conditional(
        Templar(loader=None, variables=VariableManager()), {}) is False
    test_class.when = ['foobar is defined']
    assert test_class.evaluate_conditional(
        Templar(loader=None, variables=VariableManager()), {}) is False
    test_class.when = ['foobar is defined']
    assert test_class.evaluate

# Generated at 2022-06-23 06:08:33.649670
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import AnsibleJ2Template

    def _get_loader(module_paths, data):
        from ansible.parsing.dataloader import DataLoader
        from ansible.vars.manager import VariableManager

        loader = DataLoader()
        loader.set_basedir(path)
        vars_manager = VariableManager()
        vars_manager._extra_vars = data
        templar = AnsibleJ2Template(loader, vars_manager)
        return templar

    def _get_conditional(conditional, module_paths, data):
        class Obj(Conditional):
            _when = FieldAttribute(isa='list', default=list, extend=True, prepend=True)

        templar = _get_loader(module_paths, data)

# Generated at 2022-06-23 06:08:44.739609
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager)

    all_vars = dict(name='testuser')
    result = Conditional().evaluate_conditional(templar, all_vars)
    assert result is True

    all_vars = dict(name='testuser')
    result = Conditional().evaluate_conditional(templar, all_vars)
    assert result is True
    result = Conditional(_when=['name == "testuser"']).evaluate_conditional(templar, all_vars)
    assert result is True

# Generated at 2022-06-23 06:08:56.867237
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    module_utils_path = os.path.join(os.path.dirname(__file__), '../../module_utils')
    module_utils_path = os.path.abspath(module_utils_path)
    display.display("Using module_utils: %s" % module_utils_path)

    from ansible.module_utils.common.text.converters import to_text

    module_utils_loader = DataLoader()
    module_utils_loader.set_basedir(module_utils_path)
    module_utils_templar = Templar(loader=module_utils_loader)


# Generated at 2022-06-23 06:09:04.703959
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.base import Base
    a = Base()
    a.when = [ '"a" is defined', '"a" is undefined' ]
    b = Base()
    b.when = [ "item.key is defined", "item.key is not defined" ]
    c = Base()
    c.when = [ "q is defined", "z is undefined", "q not in foo" ]

    resA = a.extract_defined_undefined(a.when[0])
    assert(len(resA) == 1)
    assert(resA[0][0] == "a")
    assert(resA[0][1] == "is")
    assert(resA[0][2] == "defined")

    resB = b.extract_defined_undefined(b.when[0])
   

# Generated at 2022-06-23 06:09:16.042807
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("") == []
    assert c.extract_defined_undefined("a and b") == []
    assert c.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert c.extract_defined_undefined("a is not defined") == [("a", "is not", "defined")]
    assert c.extract_defined_undefined("a is undefined") == [("a", "is", "undefined")]
    assert c.extract_defined_undefined("a is not undefined") == [("a", "is not", "undefined")]
    assert c.extract_defined_undefined("not a is defined") == [("a", "is", "defined")]
    assert c.ext

# Generated at 2022-06-23 06:09:28.030351
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def check(conditional, expected):
        obj = Conditional()
        res = obj.extract_defined_undefined(conditional)
        assert res == expected, "Got %s, expected %s"%(res, expected)

    check('something else', [])
    check('defined', [])
    check('not defined', [])
    check('defined and not defined', [])
    check('not defined and defined', [])
    check('something else defined', [])
    check('something else not defined', [])
    check('defined and something else', [])
    check('something else and defined', [])
    check('defined and something else not defined', [])
    check('something else not defined and defined', [])
    check('defined and something else defined', [])
    check('not defined and something else', [])
    check

# Generated at 2022-06-23 06:09:30.258408
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()


# Generated at 2022-06-23 06:09:42.758705
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    templar = Templar(loader=loader)

    # there is no conditional, the result is True
    c = Conditional()
    assert c.evaluate_conditional(templar, dict()) is True

    c = Conditional()
    c._when = [None]
    assert c.evaluate_conditional(templar, dict()) is True

    # the condition is a boolean, the result is the same as the boolean
    c = Conditional()
    c._when = [True]
    assert c.evaluate_conditional(templar, dict()) is True

    c = Conditional()
    c._when = [False]

# Generated at 2022-06-23 06:09:52.430507
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    pc = PlayContext()
    tmplar = Templar(loader=None, variables=VariableManager())

    host_vars = HostVars(loader=None, variables=VariableManager())

    # test when is defined
    host_vars.data = {'my_var': 'my_value'}
    all_vars = {'hostvars': host_vars}
    conditional = Conditional()
    conditional.when = ['my_var is defined']
    assert conditional.evaluate_conditional(tmplar, all_vars)

    # test when is undefined

# Generated at 2022-06-23 06:10:02.278319
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    from ansible.playbook.task import Task

    task = Task()
    task.when = ["hostvars['foo1'].bar1 is defined and hostvars['foo2'] is undefined"]
    assert task.extract_defined_undefined(task.when[0]) == [
        ["hostvars['foo1'].bar1", "is", "defined"],
        ["hostvars['foo2']", "is", "undefined"]
    ]

    task.when = ["hostvars['foo1'].bar1 is not defined and hostvars['foo2'] is undefined"]

# Generated at 2022-06-23 06:10:12.391381
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    ''' test extract_defined_undefined'''
    conditional = Conditional()
    def_undef = conditional.extract_defined_undefined("<something> == 1 or foo is defined or foo is not defined or bar is undefined")
    assert len(def_undef) == 3
    assert "foo" in def_undef[0]
    assert def_undef[0][1] == "is"
    assert def_undef[0][2] == "defined"
    assert "foo" in def_undef[1]
    assert def_undef[1][1] == "is not"
    assert def_undef[1][2] == "defined"
    assert "bar" in def_undef[2]
    assert def_undef[2][1] == "is"

# Generated at 2022-06-23 06:10:23.913558
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    test_conditional = Conditional(loader=loader)
    # when is a list
    test_conditional.when = ["foo", "bar"]
    assert test_conditional._validate_when(None, "_when",
                                           test_conditional.when) is None
    # when is not a list
    test_conditional.when = "baz"
    assert test_conditional._validate_when(None, "_when",
                                           test_conditional.when) is None
    assert isinstance(test_conditional.when, list)
    # when is none
    test_conditional.when = None
    assert test

# Generated at 2022-06-23 06:10:28.704763
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestConditional(Conditional):
        _when = FieldAttribute(isa='list', default=list, extend=True, prepend=True)

        def __init__(self, when, **kwargs):
            self._when = when
            super(TestConditional, self).__init__(**kwargs)

    c = TestConditional(["false"])
    assert not c.evaluate_conditional("none", "none")



# Generated at 2022-06-23 06:10:34.441877
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    my_cond = "$foo is defined and $bar is undefined and $foo is defined"
    expect = [('foo', 'is', 'defined'), ('bar', 'is', 'undefined'),
              ('foo', 'is', 'defined')]
    assert Conditional().extract_defined_undefined(my_cond) == expect



# Generated at 2022-06-23 06:10:45.898607
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    pc = PlayContext()
    variable_manager.extra_vars = load_extra_vars('some_extra_variables', loader)

    conditional = Conditional(loader=loader)

    result = conditional.evaluate_conditional(variable_manager, pc.get_vars(), pc.get_all_vars())

    assert result is True


# Helper method to load extra variables from yaml or json files

# Generated at 2022-06-23 06:10:51.379880
# Unit test for constructor of class Conditional
def test_Conditional():
    # instantiating class with no loader should throw an exception
    try:
        Conditional()
    except AnsibleError as e:
        assert str(e) == "a loader must be specified when using Conditional() directly"

    # otherwise we should create the object successfully
    c = Conditional(loader=None)
    assert c._when == []
    assert c._loader is None


# Generated at 2022-06-23 06:11:02.063372
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    import os

    loader = DataLoader()

    # use test/test.* files on current path
    loader.set_basedir(os.getcwd())

    display = Display()
    display.verbosity = 0

    templar = Templar(loader, variables={}, display=display)
    vars_ = {}

    def normalize_ds(ds):
        ds = ds.replace(' ', '')
        ds = ds.replace('\n', '')
        return ds

    # succeeds
    c = Conditional()

# Generated at 2022-06-23 06:11:12.977224
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import ansible.playbook.play_context
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook import Play
    from ansible.executor.playbook_executor import PlaybookExecutor

    def _create_playbook_context(vars):
        loader = DataLoader()
        variable_manager = VariableManager()
        variable_manager.extra_vars = vars or {}

# Generated at 2022-06-23 06:11:24.361728
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook import Playbook
    from ansible.template import Templar

    inventory = Playbook.load_inventory('localhost,')
    inventory.set_variable_manager(inventory.get_variable_manager())
    templar = Templar(loader=None, inventory=inventory)

    conditional = Conditional()

    assert conditional.evaluate_conditional(templar, {}) == True

    conditional.when = ['a', 'b']
    assert conditional.evaluate_conditional(templar, {}) == False

    conditional.when = ['a', 'b', 'c']
    assert conditional.evaluate_conditional(templar, {}) == False

    conditional.when = ['1', '0', '0']
    assert conditional.evaluate_conditional(templar, {}) == False


# Generated at 2022-06-23 06:11:30.919848
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.base import Base
    from ansible.template import Templar

    loader = DictDataLoader({})
    templar = Templar(loader=loader)

    conditional = Conditional(loader=loader)

    # when used directly, this class needs a loader
    assert conditional._loader == loader

    # when used as mix-in, the class already has a loader
    myplay = Base.load(dict(
        name = 'testplay',
        hosts = 'all',
    ))
    assert myplay._loader != loader

# Generated at 2022-06-23 06:11:40.447073
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from collections import namedtuple

    # create the objects we need to test this method
    HostVarsVars = namedtuple('HostVarsVars', ['variable_manager', 'loader', 'templar'])
    module_vars = HostVarsVars(
        variable_manager=VariableManager(),
        loader=None,
        templar=Templar(loader=None)
    )
    module_vars.loader = module_vars.templar._loader

    # using a Conditional object to test the evaluated conditional
    class TestConditional(Conditional):
        def __init__(self, loader):
            self._when = None
            self._loader = loader

    # test evaluate_conditional with a conditional which evaluates to true


# Generated at 2022-06-23 06:11:45.041847
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    obj = Conditional()
    obj.when = ["Conditional", "Conditional2", "Conditional3", "Conditional4"]

    # Testing when the conditional statement fails
    res = obj.evaluate_conditional(None, {'Conditional': False, 'Conditional2': False, 'Conditional3': False, 'Conditional4': False})

    assert res == False

# Generated at 2022-06-23 06:11:50.972771
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    test_list = []
    test_list.append(("hostvars['test'] is defined",
                      [("hostvars['test']", "is", "defined")]))
    test_list.append(("hostvars['test'] is defined and hostvars['test2'] is defined",
                      [("hostvars['test']", "is", "defined"),
                      ("hostvars['test2']", "is", "defined")]))
    test_list.append(("hostvars['test'] is defined and hostvars['test2'] is not defined",
                      [("hostvars['test']", "is", "defined"),
                      ("hostvars['test2']", "is not", "defined")]))

# Generated at 2022-06-23 06:12:01.961806
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.role.definition import RoleDefinition
    cond = Conditional()
    role = RoleDefinition()
    rd = RoleDefinition()
    # Test to get tuple of (variable name, comparison logic, keyword defined/undefined)
    assert cond.extract_defined_undefined("hostvars['ansible_default_ipv4']['interface'] is defined") == [("hostvars['ansible_default_ipv4']['interface']", 'is', 'defined')]  # noqa
    assert cond.extract_defined_undefined("hostvars['ansible_default_ipv4'].interface is defined") == [("hostvars['ansible_default_ipv4'].interface", 'is', 'defined')]  # noqa

# Generated at 2022-06-23 06:12:13.130603
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.parsing.dataloader import DataLoader

    # Ansible 2.0 API
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()

    class Dummy(Conditional):
        def __init__(self):
            Conditional.__init__(self, loader)

    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory)

    templar = Templar(loader=loader, variable_manager=variable_manager)

    # prepare test data

# Generated at 2022-06-23 06:12:20.381971
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Extract defined/undefined tests from a string,
    # then convert them into a list of tuples and compare
    # it with a reference list of tuples.
    cond = (
        "foo is ansible_all_ipv4_addresses and foo is defined and bar is "
        "not ansible_all_ipv4_addresses and bar is undefined"
    )
    results = [
        ('foo', 'is', 'ansible_all_ipv4_addresses'),
        ('foo', 'is', 'defined'),
        ('bar', 'is', 'not ansible_all_ipv4_addresses'),
        ('bar', 'is', 'undefined')
    ]
    assert Conditional().extract_defined_undefined(cond) == results



# Generated at 2022-06-23 06:12:24.709201
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    my_fixture = dict(a=1, b=2, c=dict(d=3, e=4), f=5)
    my_conditional = 'c.d is defined'
    my_templar = Templar(loader=None, variables=my_fixture)
    my_conditional_instance = Conditional()
    result = my_conditional_instance.evaluate_conditional(my_templar, my_fixture)
    assert result

    # when used directly, this class needs a loader
    from ansible.parsing.dataloader import DataLoader
    my_loader = DataLoader()
    my_conditional_instance = Conditional(loader=my_loader)

# Generated at 2022-06-23 06:12:32.328805
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = None
    play_context = {}
    variable_manager.set_host_variable(inventory.get_host("localhost"), "ansible_python_interpreter", "python")

    cls = Conditional()
    cls._loader = loader
    cls.when = [
        "ansible_python_interpreter != '/usr/bin/python'"
    ]

    res = cls.evaluate_conditional(variable_manager, loader, play_context, inventory).strip()
    assert(res)

    cls.when = [
        "ansible_python_interpreter == '/usr/bin/python'"
    ]



# Generated at 2022-06-23 06:12:43.472607
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # setup
    cond = Conditional()
    test_conditional = ["foo is defined",
                        "hostvars['foo'] is defined",
                        "bar is not defined",
                        "hostvars['bar'] is not defined",
                        "baz is undefined",
                        "hostvars['baz'] is undefined",
                        "bam is not undefined",
                        "hostvars['bam'] is not undefined",
                        "is defined",
                        "is not defined",
                        "is undefined",
                        "is not undefined"
                        ]

    # test
    for i, cond_str in enumerate(test_conditional):
        m = cond.extract_defined_undefined(cond_str)
        if i % 2 == 0:
            assert m == [('foo', 'is', 'defined')]

# Generated at 2022-06-23 06:12:55.194811
# Unit test for constructor of class Conditional
def test_Conditional():
    '''
    Ensure that Params constructed by Conditional can be used for assertions
    '''
    from ansible.playbook.base import Base
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    class ConditionalExamples(Conditional, Base):
        pass

    loader = DataLoader()
    variable_manager = VariableManager()

    c = ConditionalExamples(loader=loader)
    c._validate_when('host1', 'host', 'host1')
    assert c.host == ['host1']
    c._validate_when('host2', 'host', ['host2'])
    assert c.host == ['host1', 'host2']

# Generated at 2022-06-23 06:13:00.015066
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert isinstance(conditional, Conditional)

# Generated at 2022-06-23 06:13:03.099425
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    test_obj = Conditional()
    result = test_obj.evaluate_conditional(None, {})
    assert result == True

# Generated at 2022-06-23 06:13:13.272033
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    p = Conditional()
    templar = DummyTemplar()
    all_vars = {'var1': 'foo', 'var2': 'bar'}

    assert p.evaluate_conditional(templar, all_vars)

    p.when = ['var1 == "foo" and var2 == "bar"']

    assert p.evaluate_conditional(templar, all_vars)
    all_vars['var2'] = 'baz'
    assert not p.evaluate_conditional(templar, all_vars)

    p.when = ['false']

    assert not p.evaluate_conditional(templar, all_vars)

    p.when = ['var1 is defined']
    assert p.evaluate_conditional(templar, all_vars)
