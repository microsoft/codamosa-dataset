

# Generated at 2022-06-23 06:03:14.877810
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c is not None
    assert c._when == []

# Generated at 2022-06-23 06:03:21.471337
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    result = cond.extract_defined_undefined("This or that and not foo is defined and bar is not defined")
    assert ([(u'foo', 'is', 'defined'), (u'bar', 'is not', 'defined')] == result)


# Generated at 2022-06-23 06:03:30.116488
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_str_1 = "test_var is defined"
    conditional_str_2 = "test_var is defined or test_var2 is undefined"
    conditional_str_3 = "test_var is defined or (test_var2 is undefined and test_var3 == 'something else')"
    conditional_str_4 = "test_var is defined or (test_var2 is undefined and test_var3 == 'something else') or test_var4 is not defined"

    cond = Conditional()

    assert cond.extract_defined_undefined(conditional_str_1) == [('test_var', 'is', 'defined')]
    assert cond.extract_defined_undefined(conditional_str_2) == [('test_var', 'is', 'defined'), ('test_var2', 'is', 'undefined')]


# Generated at 2022-06-23 06:03:38.097855
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional1 = "var1 not is undefined and var2 is defined and var3 not is defined and var4 is undefined and var5 not is defined"
    conditional2 = "\"{{var1}}\" not is undefined and '{{var2}}' is defined and 123 not is defined and \"{{var4}}\" is undefined and '{{var5}}' not is defined"
    conditional3 = "''"
    conditional4 = ""

    if Conditional().extract_defined_undefined(conditional1) != [('var1', 'not is', 'undefined'), ('var2', 'is', 'defined'), ('var3', 'not is', 'defined'), ('var4', 'is', 'undefined'), ('var5', 'not is', 'defined')]:
        raise Exception('extract_defined_undefined does not work with simple conditional')


# Generated at 2022-06-23 06:03:48.012979
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert Conditional().extract_defined_undefined(conditional=None) == []
    assert Conditional().extract_defined_undefined(conditional='') == []
    assert Conditional().extract_defined_undefined(conditional='hostvars["hostname"] is defined') == [('hostvars["hostname"]', 'is', 'defined')]
    assert Conditional().extract_defined_undefined(conditional='hostvars[hostname] is not defined') == [('hostvars[hostname]', 'is not', 'defined')]

# Generated at 2022-06-23 06:03:56.206422
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:04:06.696788
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook import PlayBook
    from ansible.template import Templar

    pb = PlayBook()
    t = Templar(pb._loader, None, pb.get_variable_manager())
    t.set_available_variables({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6, 'g': 7, 'h': 8, 'i': 9, 'j': 10, 'k': 11, 'l': 12, 'm': 13, 'n': 14, 'o': 15, 'p': 16, 'q': 17, 'r': 18, 's': 19})

# Generated at 2022-06-23 06:04:18.494949
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    tests = [
        ( "var is defined", [("var", "is", "defined")]),
        ( "var1 is not defined or var2 is defined", [("var1", "is not", "defined"), ("var2", "is", "defined")]),
        ( "var is defined and hostvars['var2'] is undefined and ansible_os_family is not undefined", [("var", "is", "defined"), ("hostvars['var2']", "is", "undefined"), ("ansible_os_family", "is not", "undefined")]),
        ( "hostvars['var'] is not defined", [("hostvars['var']", "is not", "defined")]),
    ]
    for test, expected in tests:
        result = conditional.extract_defined_undefined(test)


# Generated at 2022-06-23 06:04:30.566254
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    conditional = Conditional()
    templar = Templar(play_context=PlayContext())

    # Check that the expected result is returned for a variety
    # of test strings.
    test_strings = dict()
    test_strings['foo is defined'] = [('foo', 'is', 'defined')]
    test_strings['    foo is defined'] = [('foo', 'is', 'defined')]
    test_strings['foo is not defined'] = [('foo', 'is not', 'defined')]
    test_strings['    foo is not defined'] = [('foo', 'is not', 'defined')]
    test_strings['foo is undefined'] = [('foo', 'is', 'undefined')]

# Generated at 2022-06-23 06:04:34.747254
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    results = c.extract_defined_undefined('foo is not defined and bar is defined')
    assert results[0] == ('foo', 'not is', 'defined')
    assert results[1] == ('bar', 'is', 'defined')


# Generated at 2022-06-23 06:04:43.759682
# Unit test for constructor of class Conditional
def test_Conditional():
    from units.mock.loader import DictDataLoader
    from units.parsing.parser import Parser

    p = Parser()

# Generated at 2022-06-23 06:04:47.410216
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c._when == []
    assert c.when is c._when


# TODO: BELOW THIS POINT ARE ALL UNIT TESTS, FOR VARIOUS CONDITIONAL PARSING FUNCTIONS
#       WE'RE GOING TO WANT TO MOVE THEM TO A SEPARATE TEST FILES/MODULE



# Generated at 2022-06-23 06:04:55.467899
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = variable_manager.get_vars_loader()
    templar = Templar(loader=loader, variables=variable_manager)
    test_object = Conditional(loader=loader)
    test_object._ds = ''

    # Test case 1: '0 == 0' evaluates to True
    test_object.when = '0 == 0'
    assert test_object.evaluate_conditional(templar, {})

    # Test case 2: '0 == 0 and 0 == 1' evaluates to False
    test_object.when = '0 == 0 and 0 == 1'
    assert not test_object.evaluate_conditional(templar, {})

    # Test case 3: '0 == 0 and 0 == 0

# Generated at 2022-06-23 06:05:01.702318
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('a is defined or b is defined') == [['a', 'is', 'defined'], ['b', 'is', 'defined']]
    assert c.extract_defined_undefined('a is defined or b is not undefined') == [['a', 'is', 'defined'], ['b', 'is not', 'undefined']]


# Generated at 2022-06-23 06:05:03.299575
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()


# Generated at 2022-06-23 06:05:13.173433
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar


# Generated at 2022-06-23 06:05:20.464482
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    r = Conditional()

    c1 = "ansible_os_family == 'RedHat' and ansible_distribution_major_version != '7'"
    a1 = r.extract_defined_undefined(c1)
    assert a1 == []

    c2 = "ansible_os_family == 'RedHat' and ansible_distribution_major_version|int == 7 and not gitlab_ci_runner_installed"
    a2 = r.extract_defined_undefined(c2)
    assert a2 == [('ansible_os_family', 'is', 'defined'), ('ansible_distribution_major_version|int', 'is', 'defined'), ('gitlab_ci_runner_installed', 'not is', 'defined')]


# Generated at 2022-06-23 06:05:31.228757
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("") == []
    assert cond.extract_defined_undefined("foo.bar") == []
    assert cond.extract_defined_undefined("bar is defined") == [('bar', 'is', 'defined')]
    assert cond.extract_defined_undefined("bar not is defined") == [('bar', 'not is', 'defined')]
    assert cond.extract_defined_undefined("bar is undefined") == [('bar', 'is', 'undefined')]
    assert cond.extract_defined_undefined("bar not is undefined") == [('bar', 'not is', 'undefined')]

# Generated at 2022-06-23 06:05:40.720728
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Mock classes to unit test this class. This is bad.
    class MockTask(object):
        _ds = {'path': 'fake_path'}
        def _check_conditional(self, conditional, templar, all_vars):
            assert isinstance(conditional, str)
            assert isinstance(templar, object)
            assert isinstance(all_vars, dict)
            return True

    task = MockTask()

    assert task.evaluate_conditional(object(), dict())
    assert task.evaluate_conditional(object(), dict(a=dict(b=dict(c=True))))
    assert task.evaluate_conditional(object(), dict(a=dict(b=dict(c=False))))

# Generated at 2022-06-23 06:05:42.740133
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert isinstance(conditional, Conditional)
    assert conditional._when == []

# Generated at 2022-06-23 06:05:54.194794
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional(loader=None)

# Generated at 2022-06-23 06:06:06.611109
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    cond = Conditional()

# Generated at 2022-06-23 06:06:16.863196
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

# Generated at 2022-06-23 06:06:23.414823
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    class TestConditional(Conditional):
        pass

    # This sets conditions to be evaluated on the object
    # (different examples of conditions, some valid, some not)
    test_conditional = TestConditional()
    test_conditional.when = ["some_variable is defined", "some_variable is not defi"]

    # We create a variable
    variable_manager = Variables()
    variable_manager.extra_vars = dict()

    # We create a template
    template = Template()
    template.available_variables = variable_manager.get_vars()

    # Test evaluate_conditional method of class Conditional
    assert test_conditional.evaluate_conditional(template, variable_manager.get_vars()) == True

# Generated at 2022-06-23 06:06:27.568979
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    expected = [('hostvars["foo"]', 'is', 'defined'), ('bar', 'not is', 'undefined')]
    actual = conditional.extract_defined_undefined('hostvars["foo"] is defined and bar not is undefined')
    assert expected == actual


# Generated at 2022-06-23 06:06:34.676423
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:06:45.624155
# Unit test for constructor of class Conditional

# Generated at 2022-06-23 06:06:56.235719
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-23 06:07:04.007630
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    ansible_vars = dict()
    # basic test
    conditional = 'hostvars[inventory_hostname] is undefined and foo is defined'
    results = c.extract_defined_undefined(conditional)
    assert results == [('hostvars[inventory_hostname]', 'is', 'undefined'), ('foo', 'is', 'defined')]
    # test boolean
    conditional = 'my_var or (my_var2 and (my_var3 or (my_var4 and my_var5)))'
    results = c.extract_defined_undefined(conditional)
    assert results == []
    # test lookups
    conditional = 'lookup("whatever", foo) is undefined'
    results = c.extract_defined_undefined(conditional)

# Generated at 2022-06-23 06:07:08.558637
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    test_string = "a is defined or b is not undefined"
    expected_result = [('a', 'is', 'defined'), ('b', 'is not', 'undefined')]
    result = conditional.extract_defined_undefined(test_string)
    assert result == expected_result


# Generated at 2022-06-23 06:07:18.360827
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import os
    import sys
    import tempfile
    from ansible.template import Templar, VaultLib

    from ansible.plugins.loader import action_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.galaxy.collection_finder import CollectionFinder
    from ansible.cli.adhoc import AdHocCLI

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block

    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-23 06:07:19.572475
# Unit test for constructor of class Conditional
def test_Conditional():
    instance = Conditional()



# Generated at 2022-06-23 06:07:31.325154
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Unit test that tests the method evaluate_conditional of class Conditional
    '''
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.template import Templar
    from mock import MagicMock
    from ansible.vars import VariableManager
    from ansible.playbook.block import Block

    variable_manager = VariableManager()
    variable_manager._extra_vars = dict(
        val1='foo',
        val2='foobar',
        val3=dict(
            val4=42,
            val5=dict(
                val6='barbaz'
            )
        )
    )

# Generated at 2022-06-23 06:07:41.084588
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("this_var is defined") == [("this_var", "is", "defined")]
    assert c.extract_defined_undefined("this_var is defined or other_var is not defined") == [("this_var", "is", "defined"), ("other_var", "is not", "defined")]
    assert c.extract_defined_undefined("this_var is defined or (other_var is not defined and another_var is undefined)") == [("this_var", "is", "defined"), ("other_var", "is not", "defined")]  # noqa

# Generated at 2022-06-23 06:07:42.551836
# Unit test for constructor of class Conditional
def test_Conditional():
    cond = Conditional()
    assert cond

# Generated at 2022-06-23 06:07:50.545727
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    dump_res = Conditional().extract_defined_undefined
    assert dump_res("hostvars[inventory_hostname] is not defined") == [('hostvars[inventory_hostname]', 'is not', 'defined')]
    assert dump_res("hostvars[inventory_hostname] is undefined") == [('hostvars[inventory_hostname]', 'is', 'undefined')]
    assert dump_res("hostvars[inventory_hostname] is defined") == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert dump_res("hostvars[inventory_hostname] is not undefined") == [('hostvars[inventory_hostname]', 'is not', 'undefined')]

# Generated at 2022-06-23 06:08:00.914630
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Setup
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play = Play().load({'name': 'foobar', 'hosts': 'all'}, variable_manager=variable_manager, loader=loader)
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=play))
    playbook = Playbook

# Generated at 2022-06-23 06:08:10.713039
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    """
    A test for the _check_conditional method of the Conditional class.
    :return:
    """
    ###########################################################################
    # Simple case, where the conditional evaluates to True
    c = Conditional()
    c.when = "{{ (1 + 1) == 2 }}"
    j = {
        'a': 1,
        'b': 2,
        'c': [1,2,3],
        'd': {'a': 1, 'b': 2, 'c': 3},
        'z': {'a': {'b': {'c': 1}}},
        'int': 1,
        'true': True,
        'false': False
    }
    t = Templar(loader=None, variables=j)
    r = c.evaluate_conditional

# Generated at 2022-06-23 06:08:12.572244
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c


# Generated at 2022-06-23 06:08:17.057191
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    conditional = "a is defined or b is not defined and b is defined"
    assert c.extract_defined_undefined(conditional) == [('a', 'is', 'defined'), ('b', 'is not', 'defined'), ('b', 'is', 'defined')]


# Generated at 2022-06-23 06:08:22.305157
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = 'some_var is defined or other_var is not defined'
    results = Conditional().extract_defined_undefined(conditional)
    assert len(results) == 2
    assert ('some_var', 'is', 'defined') == results[0]
    assert ('other_var', 'is not', 'defined') == results[1]


# Generated at 2022-06-23 06:08:31.349171
# Unit test for constructor of class Conditional
def test_Conditional():
    # We need a fake task object to test whether Conditional
    # mix-in works correctly.
    class FakeTask:
        pass
    # Instatiate a fake task object
    fake_task = FakeTask()
    # Inherits from Conditional (mix-in)
    class Task(Conditional):
        def __init__(self, loader=None):
            self._loader = loader
            self._ds = None
            self._when = {}
            super(Task, self).__init__()
    # Instantiate the new class
    task = Task()
    # Assign a when key to our task
    task.when = ['test']
    # It should be a dictionary, with 'test' in it
    assert isinstance(task._when, dict)
    assert task._when['test'] == 'test'

# Generated at 2022-06-23 06:08:42.700670
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    # pylint: disable=too-many-locals
    # pylint: disable=import-error
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.hostvars import HostVars
    from jinja2 import Environment
    loader = Environment()

    conditional = Conditional(loader=loader)

    # Test _validate_when
    conditional._validate_when('fake_attr', 'fake_name', 'fake_value')
    # Test _validate_when on list
    conditional._validate_when('fake_attr', 'fake_name', ['a', 'b', 'c'])

    context = PlayContext()
    inventory = Inventory

# Generated at 2022-06-23 06:08:54.808281
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    display.display("TEST: method extract_defined_undefined of class Conditional")
    display.display("test with an undefined variable (result: [(hostvars[x], not is, undefined)])")
    test_str = "hostvars[x] not is undefined"
    display.display("string to test: %s" % test_str)
    display.display("result of conditional.extract_defined_undefined(%s): %s" % (test_str, Conditional.extract_defined_undefined(None,test_str)))
    assert Conditional.extract_defined_undefined(None,test_str) == [(u"hostvars[x]", u"not is", u"undefined")]


# Generated at 2022-06-23 06:09:02.638260
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    results = []

    class TestClass(Conditional):
        _when = FieldAttribute(isa='list', default=list, extend=True, prepend=True)

    # Test valid cases
    o = TestClass()
    o.when = [True, 1, '0', ['A', 'B', 'C'], {'A': 1, 'B': 2}, 'A and B']
    results.append(o.evaluate_conditional(None, None))

    # Test invalid cases
    o = TestClass()
    o.when = [False, 0, '', [], {}, '']
    results.append(o.evaluate_conditional(None, None))

    # Test exception handling

# Generated at 2022-06-23 06:09:06.797992
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = "foo is bar and bar is defined and baz is not defined"
    result = Conditional().extract_defined_undefined(conditional)
    assert result[0] == ('bar', 'is', 'defined')
    assert result[1] == ('baz', 'is not', 'defined')


# Generated at 2022-06-23 06:09:17.719159
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('') == []
    assert conditional.extract_defined_undefined('not defined ') == []
    assert conditional.extract_defined_undefined('not undefined ') == []
    assert conditional.extract_defined_undefined(' (defined and not undefined) ') == []
    assert conditional.extract_defined_undefined(' (defined and undefined) ') == []
    assert conditional.extract_defined_undefined(' (defined or undefined) ') == []

    assert conditional.extract_defined_undefined('foo is defined and other is defined') == [('foo', 'is', 'defined'), ('other', 'is', 'defined')]

# Generated at 2022-06-23 06:09:29.035709
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.template.vars import VarsModule
    from ansible.playbook.play import Play
    import pytest
    # basic test
    conditional = """1 == 1"""
    display = Display()
    play_context = PlayContext()
    templar = Templar(loader=None, variables=dict(),
                      shared_loader_obj=None, play_context=play_context)
    conditional_obj = Conditional(loader=None)
    vars_obj = VarsModule()

    assert conditional_obj.evaluate_conditional(templar=templar, all_vars=vars_obj.get_vars(loader=None, play=Play(), host=None))

    # test that literal strings without jinja

# Generated at 2022-06-23 06:09:42.335228
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.included_file import IncludedFile
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    yaml_data = dict(
        hosts='all',
        gather_facts=True,
        roles=["test_role"],
        become='yes',
        tasks=[
            dict(
                name="test_task",
                action=dict(
                    module="shell",
                    args="ls -al",
                )
            )
        ]
    )

    vault_password = 'secret'
    vault_secrets = [('default', VaultSecret(vault_password, 1))]


# Generated at 2022-06-23 06:09:52.197373
# Unit test for constructor of class Conditional
def test_Conditional():
    from collections import namedtuple
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.vars import VariableManager

    fake_loader = namedtuple('fake_loader', ['path_dwim', 'get_basedir'])

    # First, call constructor without loader specified
    try:
        mycond = Conditional()
        assert False
    except:
        assert True

    # Create fake loader
    loader = fake_loader('/tmp', '/tmp')

    # Create fake variable manager and datastructure
    vars_manager = VariableManager()
    datastructure = Base()
    datastructure._ds = dict

# Generated at 2022-06-23 06:10:03.033608
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # This method does the low-level evaluation of each conditional
    # set on this object, using jinja2 to wrap the conditionals for
    # evaluation.

    # We test the method with these parameters:
    # -- basic_conditional (the conditional to test)
    # -- templar (the jinja2 Templar to use to evaluate the string basic_conditional)
    # -- all_vars (the set of all variables to use in the evaluation of basic_conditional)
    # -- expected_result (the result that should be returned by evaluate_conditional)

    # We use the same templar and all_vars for all tests because we only use
    # templar for simple string substitution and all_vars is not used

    from ansible.template import Templar

    from ansible.vars import VariableManager

# Generated at 2022-06-23 06:10:14.094204
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-23 06:10:25.002622
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()


# Generated at 2022-06-23 06:10:28.765903
# Unit test for constructor of class Conditional
def test_Conditional():
    # sets when properly
    c = Conditional()
    assert c._when == []
    c = Conditional(when='foo')
    assert c._when == ['foo']

    # makes _ds available when used as a mixin
    c = Conditional(object())
    assert hasattr(c, '_ds')

    # fails without a loader
    try:
        c = Conditional()
        c.__init__()
        assert False
    except AnsibleError:
        pass

    # fails when the 'when' variable is not a list
    try:
        c = Conditional()
        c._validate_when(None, None, 'foo')
        assert False
    except AnsibleError:
        pass



# Generated at 2022-06-23 06:10:41.319002
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    # Test cases for extract_defined_undefined and _check_conditional
    # We expect the conditional to return False in each of these cases:
    # A) lookups are disallowed and a conditional calls a lookup plugin
    # B) lookups are disallowed and we attempt to access an attribute starting with two underscores
    # C) lookups are disallowed and a conditional calls a template including an attribute starting with two underscores
    # D) a conditional includes string literals which are not valid identifiers to prevent issues with safe_eval

# Generated at 2022-06-23 06:10:52.690178
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.errors import AnsibleError
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    vars_manager = VariableManager()

    # make a fake group with a host
    group1 = Group('group1')
    group1.hosts.append(Host('host1'))
    group1.set_variable('var1', '1')
    group1.set_variable('var2', '2')
    vars_manager.add_group(group1)

    # make another fake group with a host
    group2 = Group('group2')
    group2.hosts.append(Host('host2'))
    group2

# Generated at 2022-06-23 06:11:03.155739
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    ##########
    # TESTS #
    ##########

    def init(self):
        self._ds = 'test task'
        self._loader = DictDataLoader()

    class TestConditionalWhen(Conditional):
        def __init__(self, when=None):
            self._when = None
            self.when = when

    # When
    tmp = TestConditionalWhen()
    # Should return True
    assert tmp.evaluate_conditional(DictTemplate(DictDataLoader()), dict())

    # ##########
    # SETUP   #
    # ##########

    class DictTemplate:
        def __init__(self, loader):
            self.loader = loader
            self.available_variables = dict()


# Generated at 2022-06-23 06:11:13.574999
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    result = cond.extract_defined_undefined('a is defined')
    assert result == [('a', 'is', 'defined')]
    result = cond.extract_defined_undefined('a is undefined')
    assert result == [('a', 'is', 'undefined')]
    result = cond.extract_defined_undefined('a is not defined')
    assert result == [('a', 'is not', 'defined')]
    result = cond.extract_defined_undefined('a is not undefined')
    assert result == [('a', 'is not', 'undefined')]
    result = cond.extract_defined_undefined('a is defined and b is undefined')
    assert result == [('a', 'is', 'defined'), ('b', 'is', 'undefined')]
    result

# Generated at 2022-06-23 06:11:14.485228
# Unit test for constructor of class Conditional
def test_Conditional():

    assert Conditional(loader=None)

# Generated at 2022-06-23 06:11:16.238131
# Unit test for constructor of class Conditional
def test_Conditional():
    class TestConditional(Conditional):
        pass
    tc = TestConditional()

# Generated at 2022-06-23 06:11:27.492175
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.helpers import load_list_of_blocks

    b = load_list_of_blocks(["""
        - name: test
          hosts: all
          tasks:
            - name: debug task
              debug:
                msg: "debug task"
              when: 1 < 2 or 3 < 4 or 5 < 6
            - name: fail task
              fail: msg="fail task"
              when: 1 > 2 and 3 < 4 and 5 < 6
            - name: another fail task
              fail: msg="another fail task"
              when: 1 > 2 and 3 < 4 and 5 < 6
    """])

    # loop through each key of blocks
    for key in b.keys():
        # loop through each task
        for task in b[key]:
            c = Conditional(loader=None)
            setattr

# Generated at 2022-06-23 06:11:37.558790
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    display.verbosity = 4

    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

    # Create a fake host
    host = Host(
        name="foohost", inventory=Inventory(host_list=[])
    )
    group = Group(
        name="foogroup", inventory=Inventory(group_list=[])
    )
    host.set_variable('foovar', 'fooval')
    group.set_variable('foogvar', 'foogval')
    host.set_variable('foovar_defined', 'fooval_defined')

# Generated at 2022-06-23 06:11:46.898011
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.utils.vars import merge_hash
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='tests/inventory/hosts')
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=play_context))

    c = Conditional(loader=loader)
    c.when = ['my_var', 'my_var = 0']



# Generated at 2022-06-23 06:11:58.625278
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.parsing.vault import VaultLib
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    assert not Conditional().evaluate_conditional(templar=Playbook()._load_vars(), all_vars={})

    assert Conditional().evaluate_conditional(templar=Playbook()._load_vars(), all_vars={'a':'1'})
    assert not Conditional(when=['a != 1']).evaluate_conditional(templar=Playbook()._load_vars(), all_vars={'a': '1'})


# Generated at 2022-06-23 06:11:59.641820
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()

# Generated at 2022-06-23 06:12:03.710093
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    pc = PlayContext()
    c = Conditional(loader=loader)

    # Verify _when is initialized to an empty list
    assert c._when == []



# Generated at 2022-06-23 06:12:14.293008
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    import pytest
    c = Conditional()
    display.verbosity = 2


# Generated at 2022-06-23 06:12:21.078970
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Test for correct evaluation of all conditional types.
    '''

    # setup
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C
    C.HOST_KEY_CHECKING = False
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    inventory.set_variable_manager(variable_manager)

# Generated at 2022-06-23 06:12:32.019553
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert [] == Conditional().extract_defined_undefined('')
    assert [('var', 'is', 'defined')] == Conditional().extract_defined_undefined('var is defined')
    assert [('var', 'is not', 'defined')] == Conditional().extract_defined_undefined('var is not defined')
    assert [('var', 'is', 'undefined')] == Conditional().extract_defined_undefined('var is undefined')
    assert [('var', 'is not', 'undefined')] == Conditional().extract_defined_undefined('var is not undefined')
    assert [('var', 'is', 'defined')] == Conditional().extract_defined_undefined('var is defined and foo')

# Generated at 2022-06-23 06:12:43.308174
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    import sys
    import io
    from ansible.template import Templar

    class _Base:
        def __init__(self):
            self._loader = None
    class _Host(Conditional, _Base):
        def __init__(self):
            self._ds = None
            self._play_context = PlayContext()
            self._variable_manager = VariableManager()

    def _get_host():
        return _Host()

    def _get_variable_manager():
        return VariableManager()

    def _load_template(template_name, vars):
        return templar.template(template_name, convert_bare=True)

    def _get_loader():
        return DataLoader()


# Generated at 2022-06-23 06:12:54.976072
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined('') == []
    assert cond.extract_defined_undefined('a') == []
    assert cond.extract_defined_undefined('{') == []
    assert cond.extract_defined_undefined('}') == []
    assert cond.extract_defined_undefined('hostvars') == []
    assert cond.extract_defined_undefined('not is') == []
    assert cond.extract_defined_undefined('not is defined') == []
    assert cond.extract_defined_undefined('not is undefined') == []
    assert cond.extract_defined_undefined('is') == []
    assert cond.extract_defined_undefined('is defined') == []

# Generated at 2022-06-23 06:13:03.199149
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c._when == []
    # test that if we assign a list to a conditional, it is
    # not collapsed
    c._when = ['a', 'b']
    assert c._when == ['a', 'b']
    # teardown
    del c

# Generated at 2022-06-23 06:13:13.345794
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    c = Conditional(loader=DataLoader())
    t = Templar(loader=DataLoader())
    assert c._check_conditional(
        'true',
        t,
        dict()
    ) == True
    assert c._check_conditional(
        'true or false',
        t,
        dict()
    ) == True
    assert c._check_conditional(
        'false and true',
        t,
        dict()
    ) == False
    assert c._check_conditional(
        '1 < 2',
        t,
        dict()
    ) == True
    assert c._check_conditional(
        '1 > 2',
        t,
        dict()
    ) == False