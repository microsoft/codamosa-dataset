

# Generated at 2022-06-21 00:22:00.802748
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert not conditional
    assert conditional.evaluate_conditional(None, None)

# Generated at 2022-06-21 00:22:10.624059
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class C(Conditional):
        def __init__(self, loader):
            Conditional.__init__(self, loader)
            self.when = ['a and b', 'c and (d or e)']
    c = C(loader = None)

    assert c.evaluate_conditional({}, {'a': True, 'b': True, 'c': True, 'd': True, 'e': True}) == True
    assert c.evaluate_conditional({}, {'a': True, 'b': False, 'c': True, 'd': True, 'e': True}) == False
    assert c.evaluate_conditional({}, {'a': True, 'b': True, 'c': True, 'd': False, 'e': True}) == True

# Generated at 2022-06-21 00:22:12.458995
# Unit test for constructor of class Conditional
def test_Conditional():
    assert "Conditional" in globals()


# Generated at 2022-06-21 00:22:24.219483
# Unit test for constructor of class Conditional
def test_Conditional():
    import sys
    if sys.version_info < (2, 7):
        # Jinja2 in Python 2.6 doesn't support AST based checks
        return

    # make sure a loader is present when using this class directly
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    results = []
    inv_manager = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    play_context = PlayContext()

# Generated at 2022-06-21 00:22:32.369809
# Unit test for constructor of class Conditional
def test_Conditional():
    class TestClass(Conditional):
        pass

    # Verify that we must provide a loader when using Conditional directly
    try:
        TestClass()
        assert False, "Must provide a loader when using Conditional directly"
    except AnsibleError:
        pass

    # Verify that when used as a mix-in, the loader is present
    class TestClassWithLoader(Conditional):
        def __init__(self):
            super(TestClassWithLoader, self).__init__()

    try:
        TestClassWithLoader()
    except AnsibleError:
        assert False, "Loader must be provided when Conditional is used as a mix-in"

# Generated at 2022-06-21 00:22:39.368676
# Unit test for constructor of class Conditional
def test_Conditional():
    # pylint: disable=unused-variable
    # pylint: disable=too-few-public-methods
    class TestClass(Conditional):
        def __init__(self):
            super(TestClass, self).__init__()

    try:
        test = TestClass()
    except Exception as err:
        assert err.message == "a loader must be specified when using Conditional() directly"

# Unit tests for method _validate_when of class Conditional

# Generated at 2022-06-21 00:22:50.997874
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader

    class Dummy(Conditional):
        pass

    class DummyTemplar(object):
        def __init__(self):
            self._available_variables = dict()

        def template(self, tmpl, **kwargs):
            return tmpl

        def is_template(self, tmpl):
            return isinstance(tmpl, bool)

        @property
        def available_variables(self):
            return self._available_variables

        @available_variables.setter
        def available_variables(self, value):
            self._available_variables = value

    class DummyModuleUtilsPath(object):
        def __init__(self):
            self._paths = list()


# Generated at 2022-06-21 00:22:58.946788
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()


# Generated at 2022-06-21 00:23:10.106314
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    from ansible.playbook.block import Block


# Generated at 2022-06-21 00:23:11.928899
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.task import Task
    task = Task()
    assert isinstance(task, Conditional)

# Generated at 2022-06-21 00:23:31.012726
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert set(cond.extract_defined_undefined(conditional='host is defined')) == set([('host', 'is', 'defined')])
    assert set(cond.extract_defined_undefined(conditional='host is not defined')) == set([('host', 'is not', 'defined')])
    assert set(cond.extract_defined_undefined(conditional='host is undefined')) == set([('host', 'is', 'undefined')])
    assert set(cond.extract_defined_undefined(conditional='host is not undefined')) == set([('host', 'is not', 'undefined')])

# Generated at 2022-06-21 00:23:41.086086
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import jinja2

    display.verbosity = 3

    class FakeTemplar:
        def __init__(self, environment):
            self.environment = environment

        def is_template(self, conditional):
            return conditional != 'True'

        def template(self, conditional, disable_lookups=False):
            return jinja2.Template(conditional).render(self.available_variables)

    class FakeClass:

        def __init__(self, conditional, all_vars):
            self.when = [conditional]
            self.all_vars = all_vars

    with open('./test/units/lib/ansible/playbook/conditional.yml') as f:
        yaml_file = f.read()

    keys = yaml.load(yaml_file)

# Generated at 2022-06-21 00:23:42.645574
# Unit test for constructor of class Conditional
def test_Conditional():
    ds = {'hello': 'world'}
    c = Conditional(ds)
    assert c._loader == ds

# Generated at 2022-06-21 00:23:54.191978
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.module_utils.six.moves import StringIO
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    import ansible.parsing.dataloader

    conditional_obj = Conditional()

    all_vars = {
        "inventory_hostname": 'localhost',
        "group_names": ["ungrouped"],
        "groups": {"ungrouped": AnsibleSequence()},
        "omit": "__omit_place_holder__123456789",
        "play_hosts": AnsibleSequence()
    }

    # Test invalid conditional

# Generated at 2022-06-21 00:23:55.221671
# Unit test for constructor of class Conditional
def test_Conditional():
    cond = Conditional()

# Generated at 2022-06-21 00:23:59.984573
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    cond = Conditional()
    assert cond.evaluate_conditional(None, {})

    # check that the result is the same even when a variable is not defined
    assert cond.evaluate_conditional(None, {})

    # last check with a fake variable
    assert cond.evaluate_conditional(None, {'fake_var': True})

# Generated at 2022-06-21 00:24:00.918652
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    obj = Conditional()
    obj.when = list()
    assert obj.evaluate_conditional(None, None)


# Generated at 2022-06-21 00:24:08.295788
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Unit tests are written in YAML
    import yaml
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.playbook.block import Block

    # (1) test for boolean type
    module_args = dict(
        when = True,
    )
    display.verbosity = 3
    mock_block = Block()
    mock_block.vars = dict(
        foo = "foo",
        bar = "bar",
    )
    test = MockConditional(dict(
        name = 'test',
        args = module_args,
    ))
    assert test.evaluate_conditional(mock_block, mock_block.vars) is True
    assert test.evaluate_conditional(mock_block, dict()) is True

    # (2) test for invalid j

# Generated at 2022-06-21 00:24:19.960469
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from units.compat import unittest
    from ansible.plugins.loader import add_all_plugin_dirs
    add_all_plugin_dirs()

    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar

    class TestConditional(Conditional):
        pass

    class TestTask(Task):
        pass
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class TestRole(RoleDefinition):
        pass

    class TestNormalRole(RoleDefinition):
        pass

    class TestHandlerTask(Task):
        pass


# Generated at 2022-06-21 00:24:27.305754
# Unit test for constructor of class Conditional
def test_Conditional():
    import ansible.playbook.base
    class TestConditional(Conditional, ansible.playbook.base.Base):
        pass
    #test1: loader is None
    loader = None
    try:
        test_obj1 = TestConditional(loader)
        assert False
    except:
        assert True
    #test2: loader is not None
    loader = "This is a test"
    try:
        test_obj2 = TestConditional(loader)
        assert test_obj2._loader == "This is a test"
    except:
        assert False


# Generated at 2022-06-21 00:24:49.652259
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext

    c = Conditional()
    pc = PlayContext()
    pc.CLIARGS = dict(tags=[])
    pc.basedir = '.'
    pc.vars = dict()

    from ansible.template import Templar
    t = Templar(loader=c._loader, variables=pc.vars)

    # The test data is a list of tuples. Each tuple has the following elements:
    #  - a string containing the conditional to be tested
    #  - either a list of variables that should be available to the conditional's expression or a dictionary containing
    #    a list of expected results for each of the boolean values that can be returned by the expression
    #    - the dictionary is to be used when the expression is expected to return a boolean value
    #    - the list is to be used when

# Generated at 2022-06-21 00:25:01.353061
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Test 1
    conditional = "foo is defined"
    conditional_result = [['foo', 'is', 'defined']]
    result = Conditional().extract_defined_undefined(conditional)
    assert result == conditional_result

    # Test 2
    conditional = "bar is undefined"
    conditional_result = [['bar', 'is', 'undefined']]
    result = Conditional().extract_defined_undefined(conditional)
    assert result == conditional_result

    # Test 3
    conditional = "hostvars[inventory_hostname] is not defined"
    conditional_result = [['hostvars[inventory_hostname]', 'is', 'not defined']]
    result = Conditional().extract_defined_undefined(conditional)
    assert result == conditional_result

    # Test 4

# Generated at 2022-06-21 00:25:11.108867
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template.template import Templar

    p = PlayContext()
    t = Templar(loader=None, variables=dict())

    c = Conditional()
    c._templar = t
    c._loader = None
    c._play_context = p

    # These are not evaluated to True or False, but should not throw an exception either
    assert c._check_conditional("", t, {})
    assert c._check_conditional("(1,2)", t, {})

    # These are true
    assert c._check_conditional("True", t, {})
    assert c._check_conditional("{{ 1 == 1 }}", t, {})

    # These are false
    assert not c._check_conditional("False", t, {})

# Generated at 2022-06-21 00:25:17.152648
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()


# Generated at 2022-06-21 00:25:28.170511
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    expected_output = [('hostvars[inventory_hostname]', 'not is', 'defined')]
    test_conditional = "hostvars[inventory_hostname] not is defined"
    conditional = Conditional()
    output = conditional.extract_defined_undefined(test_conditional)
    assert output == expected_output
    test_conditional = "hostvars[inventory_hostname]  not is defined"
    output = conditional.extract_defined_undefined(test_conditional)
    assert output == expected_output
    test_conditional = "hostvars[inventory_hostname]  not is defined"
    output = conditional.extract_defined_undefined(test_conditional)
    assert output == expected_output
    test_conditional = "hostvars[inventory_hostname] is not undefined"

# Generated at 2022-06-21 00:25:37.556110
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('not (a or b)') == []
    assert conditional.extract_defined_undefined('(a or b) is defined') == [('a or b', 'is', 'defined')]
    assert conditional.extract_defined_undefined('(a or b) is not defined') == [('a or b', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('not ((a or b) is not defined)') == [('a or b', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('b is undefined and a is not undefined') == [('b', 'is', 'undefined'), ('a', 'is not', 'undefined')]

# Generated at 2022-06-21 00:25:49.195353
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    class MyGroup(Conditional):
        pass

    g = MyGroup()
    templar = Templar(loader=None, variables={'x':'1'})
    assert g.evaluate_conditional(templar, {'x':'1'}), "should succeed with variable defined"
    assert not g.evaluate_conditional(templar, {'y':'1'}), "should fail if variable not defined in the context"

    g._when = ['1']
    g._always_run = True
    assert g.evaluate_conditional(templar, {'y':'1'}), "should always succeed with always_run=True"

    g._when = ['x is defined']

# Generated at 2022-06-21 00:25:51.030391
# Unit test for constructor of class Conditional
def test_Conditional():
    cond = Conditional()
    assert isinstance(cond, Conditional)



# Generated at 2022-06-21 00:25:59.864962
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    import json
    import os

    from ansible.errors import AnsibleParserError
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    from ansible.playbook.play_context import PlayContext

    def _get_vars(loader, play_context):

        variable_manager = VariableManager()
        variable_manager.set_loader(loader)
        variable_manager.set_inventory(loader.inventory)
        variable_manager.set_play_context(play_context)

        templar = Templar(loader=loader,
                          variables=variable_manager.get_vars(play=play_context, include_hostvars=True))

        return templar.available_variables


# Generated at 2022-06-21 00:26:11.569539
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    in_data = [
        "'' not in my_var",
        "my_var1 is defined and my_var2 is defined",
        "my_var1 is not defined",
        "my_var1 is undefined",
        "my_var1 is defined and my_var2 is not defined",
        "my_var1 is defined and my_var2 is undefined",
        "my_var1 is not defined and my_var2 is not defined and my_var3 is defined and my_var4 is undefined",
        "hostvars['host1'] is not defined and my_var2 is defined",
        "hostvars['host1'] is undefined and my_var2 is not defined",
    ]

# Generated at 2022-06-21 00:26:50.844972
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # We test this function by using Ansible's unit test framework,
    # and running the same test_conditional function as originally
    # used to test the evaluate_conditional function.
    #
    # First we do all imports.
    import os
    import sys
    # The unit tests have been moved to separate directory, but
    # Ansible still uses the old relative import for importing
    # the unit tests.
    # path = os.path.dirname(os.path.dirname(__file__))
    # sys.path.append(path)
    from ansible.plugins.test.core import TestConditional
    from ansible.compat.tests import unittest


# Generated at 2022-06-21 00:26:54.339515
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # FIXME: The test case does not actually check anything yet.
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    display.verbosity = 4
    loader = DataLoader()
    t = Templar(loader=loader, variables={'a': {'b': 'c'}})
    tqm = None
    task = Task()
    task.when = ['{{ a.b in "abc" }}']
    task.evaluate_conditional(t, {})

# Generated at 2022-06-21 00:27:04.355570
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

# Generated at 2022-06-21 00:27:11.990039
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    test = Conditional()
    assert extract_defined_undefined("test") is None
    assert extract_defined_undefined("test is defined") == [("test", " is ", "defined")]
    assert extract_defined_undefined("test is defined and test2 is defined") == [("test", " is ", "defined"),("test2", " is ", "defined")]
    assert extract_defined_undefined("test is not defined or test2 is not defined") == [("test", " is not ", "defined"),("test2", " is not ", "defined")]
    assert extract_defined_undefined("test2 is defined and test2_2 is defined or test2_3 is defined)") == [("test2", " is ", "defined"),("test2_2", " is ", "defined"),("test2_3", " is ", "defined")]

# Generated at 2022-06-21 00:27:17.972760
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()

    # create a fake templar for conditional to use
    class fake_templar:
        class fake_environment:
            # create fake environment so that it can call jinja2 functions
            class fake_constructor:
                def __init__(self):
                    pass
                def from_string(self, template):
                    return template
            def __init__(self):
                self.block_start_string = '{%'
                self.block_end_string = '%}'
                self.variable_start_string = '{{'
                self.variable_end_string = '}}'
                self.template_class = self.fake_constructor()
        def __init__(self, environment):
            self.environment = environment
        def is_template(self, data):
            return re.search

# Generated at 2022-06-21 00:27:21.828493
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader

    class TestClass(Conditional):
        pass

    with pytest.raises(AnsibleError) as excinfo:
        TestClass()
 
    assert "a loader must be specified when using Conditional() directly" in to_text(excinfo.value)

    TestClass(loader = DataLoader())

# Generated at 2022-06-21 00:27:23.198420
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert type(conditional) == Conditional



# Generated at 2022-06-21 00:27:34.510851
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory('tests/inventory'))
    templar = Templar(loader=loader, variables=variable_manager.get_vars(loader=loader, play=None, host=None))
    c = Conditional(loader)
    all_vars = variable_manager.get_vars(loader=loader, play=None, host=None, include_hostvars=True)
    assert c.evaluate_conditional(templar, all_vars) == True
    c._when.append(False)

# Generated at 2022-06-21 00:27:44.301403
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-21 00:27:53.491693
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("some_var is defined") == [("some_var", "is", "defined")]
    assert c.extract_defined_undefined("hello is defined and world is defined") == [("hello", "is", "defined"), ("world", "is", "defined")]
    assert c.extract_defined_undefined("hello is not defined or world is not defined") == [("hello", "is not", "defined"), ("world", "is not", "defined")]
    assert c.extract_defined_undefined("hello is not defined or world is defined") == [("hello", "is not", "defined"), ("world", "is", "defined")]

# Generated at 2022-06-21 00:29:19.718058
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-21 00:29:20.446732
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c._when == []

# Generated at 2022-06-21 00:29:22.987962
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional(loader=None)
    assert c is not None

# Unit tests for _validate_when()

# Generated at 2022-06-21 00:29:32.548982
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.base import Base
    from ansible.playbook.play_context import PlayContext

    class Play(Base, Conditional):
        pass

    p = Play()
    p._loader = DictDataLoader({})
    p.vars = dict()

    pc = PlayContext()
    p._play_context = pc

    assert p.evaluate_conditional(all_vars=dict())

    p.when = ["a is defined"]
    assert not p.evaluate_conditional(all_vars=dict())

    p.when = ["a is undefined"]
    assert p.evaluate_conditional(all_vars=dict())

    p.when = ["a is defined", "b is defined"]
    assert not p.evaluate_conditional(all_vars=dict())


# Generated at 2022-06-21 00:29:40.710661
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude

    play_context = dict(
        foo='bar',
        bam='baz',
        bat=True,
        baa=False,
    )


# Generated at 2022-06-21 00:29:41.691256
# Unit test for constructor of class Conditional
def test_Conditional():
    assert True
    # should raise an error, if the loader isn't passed
    # conditional = Conditional()

# Generated at 2022-06-21 00:29:52.583854
# Unit test for constructor of class Conditional
def test_Conditional():
    class TestObject(object):
        def __init__(self, **kwargs):
            for k,v in kwargs.items():
                setattr(self, k, v)

    test_obj = TestObject()
    assert test_obj._validate_when('a', '_when', None) == ['a']
    assert test_obj._validate_when(None, '_when', 'b') == [None, 'b']
    assert test_obj._validate_when([None, 'a'], '_when', 'b') == [None, 'a', 'b']
    assert test_obj._validate_when('c', '_when', [None, 'a']) == ['c', None, 'a']

# Generated at 2022-06-21 00:29:59.990224
# Unit test for constructor of class Conditional
def test_Conditional():
    '''
    basic constructor test
    '''

    # NOTE: class Conditional only ever raises an error on initialization

    # trying to instantiate class directly raises AnsibleError
    from ansible.errors import AnsibleError
    from ansible.playbook.attribute import Attribute
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task
    for cls in [Attribute, Task, Base]:
        try:
            Conditional(cls)
        except AnsibleError:
            pass
        else:
            assert False, 'expected a raise'

    # trying to extend an object with no loader instance raises AnsibleError
    try:
        class EmptyTest(object):
            pass
        Conditional(EmptyTest)
    except AnsibleError:
        pass

# Generated at 2022-06-21 00:30:08.887021
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    '''
    This test is for method evaluate_conditional of class Conditional
    '''
    # create object of class Conditional
    obj_conditional = Conditional()

    # create object of class FieldAttribute
    obj_field_attribute = FieldAttribute()

    # set attribute of class Conditional called _when
    conditional_obj = obj_field_attribute._validate_when('attribute', 'set_when', True)
    setattr(obj_conditional, '_when', conditional_obj)

    # call method evaluate_conditional of class Conditional
    obj_conditional.evaluate_conditional(conditional_obj, [])

# Generated at 2022-06-21 00:30:18.933102
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    test_cases = [
        # test inputs and expected outputs
        ('a is defined and b is defined', [('a', 'is', 'defined'), ('b', 'is', 'defined')]),
        ('a is defined and b is undefined', [('a', 'is', 'defined'), ('b', 'is', 'undefined')]),
    ]

    for (test_input, expected_output) in test_cases:
        assert expected_output == Conditional().extract_defined_undefined(test_input)