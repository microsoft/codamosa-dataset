

# Generated at 2022-06-21 00:22:09.359715
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.attribute import Attribute
    from ansible.playbook.task import Task
    from ansible.template import Templar

    # NOTE: The Attribute class's _load_attr method will clear the _variables
    #       here because this object doesn't have a loader attached.
    task = Task()
    conditional = Conditional()

    # Trying to init with None raises an error
    try:
        conditional = Conditional(None)
        raise Exception('Conditional init with None loader should have raised AnsibleError')
    except (AnsibleError):
        pass

    # Trying to init with actual loader and then trying to init a Task that
    # uses this class as a mix-in should not raise any errors
    conditional = Conditional(Attribute())

    # Trying to init a Task that uses this class as a mix-in should not raise


# Generated at 2022-06-21 00:22:10.678205
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c


# Generated at 2022-06-21 00:22:22.879443
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class ConditionalClass(Conditional):
        def get_ds(self):
            return {'when': self.when}

    mock_templar = type('', (), {
        'template': lambda self, conditional, disable_lookups=False: conditional,
        'is_template': lambda self, conditional: False,
        'environment': type('', (), {
            'parse': lambda self, conditional, name, filename: conditional,
            'generate': lambda self, node, environment, name, filename: conditional,
        }),
    })()

# Generated at 2022-06-21 00:22:32.823786
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    c = Conditional(None)

    conditional = "ansible_os_family == 'RedHat' or ansible_os_family == 'Debian'"
    r = c.extract_defined_undefined(conditional)
    assert(r == [])

    conditional = "ansible_os_family is defined or ansible_os_family is not undefined"
    r = c.extract_defined_undefined(conditional)
    assert(r == [('ansible_os_family', 'is', 'defined')])

    conditional = ("ansible_os_family is defined or ansible_os_family is not undefined "
                   "or hostvars[inventory_hostname].os is defined")
    r = c.extract_defined_undefined(conditional)

# Generated at 2022-06-21 00:22:44.216335
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    assert extract_defined_undefined(conditional)
    '''
    cond = Conditional()

    #assertions for the positive case
    positive_result = [('git_src', 'is', 'defined')]
    conditional = 'git_src is defined'
    assert cond.extract_defined_undefined(conditional)[0] == positive_result[0]

    positive_result = [('version', 'is', 'undefined'), ('git_src', 'is', 'defined')]
    conditional = 'version is undefined and git_src is defined'
    assert cond.extract_defined_undefined(conditional)[-1] == positive_result[-1]

    positive_result = [('version', 'is', 'undefined'), ('git_src', 'is', 'defined')]

# Generated at 2022-06-21 00:22:55.510517
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_loader(loader)
    error_msg_prefix = 'Error evaluating conditional'


# Generated at 2022-06-21 00:23:06.639991
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Unit test for method evaluate_conditional
    # of class Conditional
    #
    # initializing the class

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    c = Conditional()
    pc = PlayContext()
    templar = Templar(loader=c._loader, variables=pc.variable_manager.get_vars(play=pc.play, host=pc.remote_addr, include_hostvars=True))

    # it should return false if condition is None
    assert c.evaluate_conditional(templar, {}) == True
    c.when = None
    assert c.evaluate_conditional(templar, {}) == False

    # it should return false if variable is undefined
    c.when = [ "not_defined" ]
    assert c.evaluate_

# Generated at 2022-06-21 00:23:11.975306
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    extracted = cond.extract_defined_undefined('hostvars[inventory_hostname] is not defined and not hostvars["host"].some_attr')
    assert extracted == [('hostvars[inventory_hostname]', 'is not', 'defined'), ('hostvars["host"]', 'not', 'is')]


# Generated at 2022-06-21 00:23:21.628390
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    module_data=dict(
        path='/path/to/something'
    )
    host_vars=dict(
        default=dict(
            ansible_path='/usr/bin:/opt/bin'
        )
    )
    inventory = {
        'default': 1,
        'non_default': 2,
        'group_a': 1,
        'group_b': 2,
        'group_c': 3,
    }
    loader=None
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-21 00:23:32.832148
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    def call_evaluate_conditional(conditional, templar, all_vars):
        test_obj = Conditional()
        test_obj.when = conditional
        return test_obj.evaluate_conditional(templar, all_vars)

    import ansible.template.template as template
    from ansible.template.vars import AnsibleJ2Vars
    from ansible.template.template import AnsibleJ2Template

    test_templar = template.AnsibleTemplate(basedir=C.DEFAULT_LOCAL_TMP, vars=AnsibleJ2Vars(), loader=None)

    test_conditional = 'True'
    assert(call_evaluate_conditional(test_conditional, test_templar, {}) is True)
    test_conditional = 'False'

# Generated at 2022-06-21 00:23:50.245694
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
     c = Conditional()
     assert c.extract_defined_undefined('name is defined and foo is defined') == [('name', 'is', 'defined'), ('foo', 'is', 'defined')]
     assert c.extract_defined_undefined('name not is defined and foo is defined and bar not is forced') == [('name', 'not is', 'defined'), ('foo', 'is', 'defined'), ('bar', 'not is', 'forced')]
     assert c.extract_defined_undefined('name is defined') == [('name', 'is', 'defined')]
     assert c.extract_defined_undefined('name not is defined') == [('name', 'not is', 'defined')]
     assert c.extract_defined_undefined('name is not defined') == [('name', 'is not', 'defined')]


# Generated at 2022-06-21 00:24:01.569973
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # TODO: Copied from test_Conditional_evaluate_conditional of ansible/playbook/conditional.py
    #       Remove this function and use the one in the Conditional class, if it's possible
    #       However, the Conditional class doesn't have _make_unsafe method

    # Set up the imports (used during the AST parsing)
    import os
    import __builtin__
    import datetime

    class TestConditional(Conditional):
        def __init__(self, loader):
            self._loader = loader

    # Set up the variables to be used while evaluating conditionals

# Generated at 2022-06-21 00:24:07.973005
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    var_manager = VariableManager()
    var_manager.set_inventory(DataLoader().load_inventory("/usr/local/share/ansible/inventory"))

    # Test Task
    t = Task()
    t._validate_when("test/test.yml", 'when', [
        {'cond1': 'true'},
        ['cond2', 'cond3']
    ])

    assert t.evaluate_conditional(var_manager.templar, var_manager.get_vars()) == True


# Generated at 2022-06-21 00:24:11.061258
# Unit test for constructor of class Conditional
def test_Conditional():
    """
    Constructor test
    """

    conditional = Conditional()

    assert conditional._when == list()
    assert conditional._loader is None



# Generated at 2022-06-21 00:24:22.236046
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars

    local_vars = dict()
    t = Templar(loader=None, variables=local_vars)
    v = VariableManager()
    all_vars = combine_vars(local_vars, dict(hostvars=dict(localhost=dict())))

    c = Conditional()

# Generated at 2022-06-21 00:24:24.314184
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.task import Task
    t = Task()
    assert isinstance(t, Conditional)


# Generated at 2022-06-21 00:24:24.959713
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional._attributes['when'] == ['default']

# Generated at 2022-06-21 00:24:31.847440
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.conditional import Conditional
    conditional = Conditional()
    assert conditional.extract_defined_undefined('foo not is undefined') == [('foo', 'not', 'undefined')]
    assert conditional.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('foo is undefined and bar is not defined') == [('foo', 'is', 'undefined'), ('bar', 'is not', 'defined')]

# Generated at 2022-06-21 00:24:34.418863
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c._when == [], "_when var is not empty!"



# Generated at 2022-06-21 00:24:44.927886
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    # test most simple case
    cond = conditional.extract_defined_undefined("foo is defined")
    assert cond == [("foo", "is", "defined")]

    # test with a "not"
    cond = conditional.extract_defined_undefined("foo is not defined")
    assert cond == [("foo", "is not", "defined")]

    # test with an undefined with a "not"
    cond = conditional.extract_defined_undefined("foo is not undefined")
    assert cond == [("foo", "is not", "undefined")]

    # test with an undefined
    cond = conditional.extract_defined_undefined("foo is undefined")
    assert cond == [("foo", "is", "undefined")]

    # test multiple
    cond = conditional.extract_defined_

# Generated at 2022-06-21 00:24:53.833958
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert isinstance(conditional, Conditional)

# Generated at 2022-06-21 00:25:05.390551
# Unit test for constructor of class Conditional
def test_Conditional():

    conditional = Conditional()
    obj = Base()

    # When: Condition is boolean True
    # Then: should return True
    conditional._when = True
    assert conditional.evaluate_conditional(obj)

    # When: Condition is boolean False
    # Then: should return False
    conditional._when = False
    assert not conditional.evaluate_conditional(obj)

    # When: Condition is string "True"
    # Then: should return True
    conditional._when = "True"
    assert conditional.evaluate_conditional(obj)

    # When: Condition is string "False"
    # Then: should return False
    conditional._when = "False"
    assert not conditional.evaluate_conditional(obj)

    # When: Condition is string "FALSE" (case insensitive)
    # Then: should return False

# Generated at 2022-06-21 00:25:14.017946
# Unit test for constructor of class Conditional
def test_Conditional():
    class TestConditional(Conditional):
        def __init__(self):
            super(TestConditional, self).__init__()

    # check that __init__ method is working properly, assertions in _validate_when
    # should be caught instead of failing the constructor
    try:
        test_conditional = TestConditional()
    except:
        assert 0, 'test_Conditional constructor is broken'

    # check that __init__ method is working properly, no assertions should be
    # raised in _validate_when
    try:
        test_conditional = TestConditional()
        test_conditional._when = ['test1', 'test2']
    except:
        assert 0, 'test_Conditional constructor is broken'

    # check to make sure _validate_when method is working properly, an assertion
    # should be raised


# Generated at 2022-06-21 00:25:26.003209
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from collections import namedtuple
    from ansible.executor.task_result import TaskResult
    import jinja2

    Conditional_obj = Conditional()

    class AttrDict(dict):
        def __init__(self, *args, **kwargs):
            super(AttrDict, self).__init__(*args, **kwargs)
            self.__dict__ = self
    class ResultCallback:
        def __init__(self):
            self._result = None
        def v2_runner_on_ok(self, result, *args, **kwargs):
            self._result = result

# Generated at 2022-06-21 00:25:36.141962
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    cond = Conditional(loader=loader)
    assert cond._loader == loader
    assert type(cond._when) == list
    assert cond._when == []

    cond = Conditional(loader=loader, when=['foo'])
    assert cond._when == ['foo']

    cond = Conditional(loader=loader, when=['foo', 'bar'])
    assert cond._when == ['foo', 'bar']

    cond = Conditional(loader=loader, when='foo')

# Generated at 2022-06-21 00:25:47.332634
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    c = Conditional()
    conditional = "a is defined and b is not defined"
    assert c.extract_defined_undefined(conditional) == [('a', 'is', 'defined'), ('b', 'is not', 'defined')]
    conditional = "a is defined and b is not defined and c is undefined"
    assert c.extract_defined_undefined(conditional) == [('a', 'is', 'defined'), ('b', 'is not', 'defined'), ('c', 'is', 'undefined')]
    conditional = "a is not defined and ( b is not defined or c is undefined or d is defined or e is not defined )"

# Generated at 2022-06-21 00:25:57.729922
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert list() == conditional.extract_defined_undefined(None)
    assert list() == conditional.extract_defined_undefined('')
    assert list() == conditional.extract_defined_undefined('foo is bar')
    assert list() == conditional.extract_defined_undefined('''"hostvars['foo'] is defined"''')
    assert list() == conditional.extract_defined_undefined('"hostvars[\'foo\'] is defined"')
    assert list() == conditional.extract_defined_undefined('"hostvars[\\"foo\\"] is defined"')
    assert list() == conditional.extract_defined_undefined('"hostvars[\\\'foo\\\'] is defined"')
    assert [('foo', 'is', 'defined')] == conditional.ext

# Generated at 2022-06-21 00:26:09.734028
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.base import Base
    from ansible.templating import Templar

    class TestClass(Base, Conditional):
        def __init__(self):
            self._ds = 'TestClass'
            super(TestClass, self).__init__()

    tc = TestClass()
    templar = Templar(loader=None, variables={})

    # basic tests
    assert tc.extract_defined_undefined('{{ myvar is defined }}') == [('myvar', 'is', 'defined')]
    assert tc.extract_defined_undefined('{{ myvar is not defined }}') == [('myvar', 'is not', 'defined')]
    assert tc.extract_defined_undefined('{{ myvar is undefined }}') == [('myvar', 'is', 'undefined')]

# Generated at 2022-06-21 00:26:20.426489
# Unit test for constructor of class Conditional
def test_Conditional():

    conditional = Conditional(None)

    # test _validate_when
    try:
        conditional._validate_when(conditional, '_when', 'True')
    except Exception:
        assert False, 'Unexpected exception raised'
    if conditional._when != ['True']:
        assert False, 'Did not set _when'

    # test extract_defined_undefined
    conditional = Conditional(None)
    result = conditional.extract_defined_undefined('hostvars is undefined')
    assert result == [('hostvars', 'is', 'undefined')]
    result = conditional.extract_defined_undefined('hostvars is undefined and foo is defined')
    assert result == [('hostvars', 'is', 'undefined'), ('foo', 'is', 'defined')]
    result = conditional.extract_defined

# Generated at 2022-06-21 00:26:26.224451
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Negative case for method extract_defined_undefined
    def test_extract_defined_undefined_negative():
        c = Conditional()
        result = c.extract_defined_undefined('foo is defined')
        assert result == list()

    # Positive case for method extract_defined_undefined
    def test_extract_defined_undefined_positive():
        c = Conditional()
        result = c.extract_defined_undefined('foo is defined and bar is not defined')
        assert result == [('foo', 'is', 'defined'), ('bar', 'is not', 'defined')]

    test_extract_defined_undefined_negative()
    test_extract_defined_undefined_positive()



# Generated at 2022-06-21 00:26:47.210615
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class MyConditional(object):
        _when = FieldAttribute(isa='complex')

    # Unit test case:
    #   when: foo is defined
    #  where, data passed to "evaluate_conditional" method is:
    #   templar: {foo:"bar"}
    #    all_vars: {foo="bar"}
    #
    #  The result is evaluated to true, since the conditions is valid
    m = MyConditional()
    m._when = ["foo is defined"]
    data = {"foo":"bar"}
    result = m.evaluate_conditional(data, data)
    assert result == True

# Generated at 2022-06-21 00:26:53.832478
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    import pytest

    # The class Block inherits from the class Conditional, so check if the constructor
    # without loader argument will raise an AnsibleError
    with pytest.raises(AnsibleError) as exc_info:
        block = Block()
    assert 'loader' in str(exc_info.value)

    # The class Block inherits from the class Conditional, so check if the constructor
    # with valid loader argument won't raise an AnsibleError
    play = Play().load(dict(name='test_play', hosts='all'))
   

# Generated at 2022-06-21 00:27:03.808462
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    host = {"name":"test"}
    class Conditional_tester(Conditional):
        def __init__(self):
            Conditional.__init__(self)
            self._loader = DictDataLoader({
                "test": "[ 'test' ]"
            })
    c = Conditional_tester()
    # Test case 1: no conditionals
    c.when = []
    assert c.evaluate_conditional("test", host) == True
    # Test case 2: no variables, only literal strings
    c.when = ["test"]
    assert c.evaluate_conditional("test", host) == True
    c.when = ["not test"]
    assert c.evaluate_conditional("test", host) == False
    # Test case 3: no variables, only literal strings and literals
    c.when = ["test or yes"]

# Generated at 2022-06-21 00:27:11.563358
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    p = Play()
    p._ds = dict(name="test play")
    p._loader = DataLoader()
    p._variable_manager = VariableManager(loader=p._loader, inventory=Inventory(loader=p._loader))
    p._templar = Templar(loader=p._loader, variables=p._variable_manager.get_vars(loader=p._loader, play=p))
    p.hosts = "all"
    p.tasks = []
    p.roles = []
    p.handlers

# Generated at 2022-06-21 00:27:17.581736
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    options = dict(connection='local', module_path=['/to/mymodules'], forks=10, become=None,
                   become_method=None, become_user=None, check=False, diff=False)
    loader = DataLoader()
    passwords = dict()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext(options=options, passwords=passwords)

    conditional = Conditional(loader)
    assert conditional is not None



# Generated at 2022-06-21 00:27:19.360539
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    conditional._loader = True
    assert conditional._loader is True


# Generated at 2022-06-21 00:27:21.048057
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional._when == []
    conditional = Conditional(loader=None)
    assert conditional._when == []

# Generated at 2022-06-21 00:27:25.960340
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.task import Task
    t = Task()
    c = Conditional()
    tests = {
        'a is defined': [('a','is','defined')],
        'a is not undefined': [('a','is','not undefined')],
        'a is defined and b is not undefined': [('a','is','defined'),('b','is','not undefined')],
    }
    for k in tests:
        if tests[k] != c.extract_defined_undefined(k):
            raise Exception('Failed test_Conditional_extract_defined_undefined %s' % k)

# Generated at 2022-06-21 00:27:37.923412
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-21 00:27:46.726453
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[], variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)

    #vars
    variable_manager.set_host_variable(inventory.get_host("127.0.0.1"), "key1", "value1")
    variable_manager.set_host_variable(inventory.get_host("127.0.0.1"), "key2", "value2")

    #hosts


# Generated at 2022-06-21 00:28:17.740876
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from nose.plugins.skip import SkipTest
    raise SkipTest("TODO: Write a unit test")



# Generated at 2022-06-21 00:28:26.039998
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conds = ['foo is defined or baz is defined',
             'bar is undefined or bar.foo is defined',
             'hostvars["foo"] is defined and "foo" in hostvars["bar"]',
             'hostvars["foo"] is defined and hostvars["bar"] is undefined']
    tests = {conds[0]: [('foo', 'is', 'defined')],
             conds[1]: [('bar', 'is', 'undefined'), ('bar.foo', 'is', 'defined')],
             conds[2]: [('hostvars["foo"]', 'is', 'defined'), ('hostvars["bar"]', 'is', 'defined')],
             conds[3]: [('hostvars["foo"]', 'is', 'defined'), ('hostvars["bar"]', 'is', 'undefined')]}
   

# Generated at 2022-06-21 00:28:27.767061
# Unit test for constructor of class Conditional
def test_Conditional():
    # pylint: disable=unused-variable
    C1 = Conditional(loader=None)

# Generated at 2022-06-21 00:28:28.941762
# Unit test for constructor of class Conditional
def test_Conditional():
    m = Conditional()
    assert m._when == []


# Generated at 2022-06-21 00:28:39.336678
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    class FakeClass(Conditional):
        pass

    class FakeTemplar(object):
        def __init__(self):
            self.environment = Environment()
            self.environ = dict()
            self.available_variables = dict()

        def is_template(self, data, validate_only=False, fail_on_undefined=True):
            return True

        def template(self, data, preserve_trailing_newlines=True, convert_data=False, escape_backslashes=True,
                     fail_on_undefined=True, disable_lookups=False):
            return data

    C.DEFAULT_HASH_BEHAVIOUR = 'replace'
    fake_loader = DictDataLoader({})
    fake_templar = FakeTemplar()

# Generated at 2022-06-21 00:28:40.903572
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional.when == []
    conditional = Conditional(loader=None)


# Generated at 2022-06-21 00:28:49.496041
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    Unit test for extract_defined_undefined
    '''


# Generated at 2022-06-21 00:28:55.858988
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    def _test_func(conditional, expected):
        test_obj = Conditional()
        results = test_obj.extract_defined_undefined(conditional)
        assert expected == results


# Generated at 2022-06-21 00:29:05.309461
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    # test valid conditional
    conditional = "is_windows is defined"
    all_vars = dict(
        is_windows=True
    )
    test_instance = Conditional()
    assert test_instance.evaluate_conditional(Templar(loader=None), all_vars)

    # test not valid conditional
    conditional = "is_windows is defined"
    all_vars = dict(
        is_fake=True
    )
    test_instance = Conditional()
    # FIXME: this needs to be fixed to return false
    assert not test_instance.evaluate_conditional(Templar(loader=None), all_vars)

   

# Generated at 2022-06-21 00:29:13.137388
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.base import Base
    from ansible.playbook.helpers import load_list_of_blocks

    class TestObj(Base, Conditional):
        pass

    yaml_data = """
- name: test
  connection: local
  hosts: testhost
  gather_facts: False
  tasks:
  - name: test
    fail:
      msg: 'should have failed'
    when: false
    ignore_errors: True

- hosts: testhost
  gather_facts: False
  tasks:
  - name: test
    fail:
      msg: 'should have failed'
    when: false
    ignore_errors: True
"""


# Generated at 2022-06-21 00:29:59.448958
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional(loader=None)

    assert c._when == []



# Generated at 2022-06-21 00:30:09.932829
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestConditional(Conditional):
        def __init__(self, *args, **kwargs):
            self._ds = None
            self._loader = None
            super(TestConditional, self).__init__()


# Generated at 2022-06-21 00:30:19.870832
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    # pylint: disable=import-error
    # pylint: disable=no-name-in-module
    from ansible.playbook.base import Base

    a = Base()
    assert [("hostvars['foo']", 'is', 'defined'), ('hostvars[inventory_hostname]', 'is', 'undefined')] == a.extract_defined_undefined('hostvars[\'foo\'] is defined and hostvars[inventory_hostname] is undefined')


# Unit tests for method extract_lookup_plugin_terms of class Conditional

# Generated at 2022-06-21 00:30:25.677237
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    result = Conditional().extract_defined_undefined('hostvars["ansible_enp0s8"] is defined')
    assert result == [('hostvars["ansible_enp0s8"]', 'is', 'defined')]


# Generated at 2022-06-21 00:30:33.198630
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    fakevars = dict(a=1, b=2, c=3, d="mystring")

    pc = PlayContext()
    templar = Templar(loader=None, variables=fakevars)

    # Test with numeric evaluation
    testobj = Conditional()
    testobj.when = [ "a<2" ]

    assert testobj.evaluate_conditional(templar, fakevars)

    testobj.when = [ "a<1" ]
    assert not testobj.evaluate_conditional(templar, fakevars)

    # Test with string evaluation
    testobj.when = [ "d=='mystring'" ]
    assert testobj.evaluate_conditional(templar, fakevars)

   

# Generated at 2022-06-21 00:30:39.550473
# Unit test for constructor of class Conditional
def test_Conditional():
    '''
    Some basic unit tests for Conditional class
    '''
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-21 00:30:52.524236
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.vars import VariableManager
    from ansible.template import Templar


# Generated at 2022-06-21 00:31:02.362007
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    class TestClass:
        when = None

        def __init__(self, when):
            self.when = when

        def evaluate_conditional(self, templar, all_vars):
            return Conditional.evaluate_conditional(self, templar, all_vars)

    def test(when, all_vars=dict()):
        # Allocate a dummy class that extends Conditional class
        tc = TestClass(when)
        # Allocate a dummy PlayContext class
        pc = PlayContext()
        # That class needs a few methods from the PlayContext class
        pc.CLIARGS = dict()
        # Allocate a Templar class extending the Play stuff

# Generated at 2022-06-21 00:31:09.891421
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    b = Conditional()
    b._ds = dict(
        foo='bar',
        baz='woz'
    )
    b._when = [ 'foo is bar', 'foo is baz', 'baz is woz', 'baz is blah' ]
    templar = MockTemplar()
    all_vars = dict()

    assert b.evaluate_conditional(templar, all_vars) is False


# Generated at 2022-06-21 00:31:13.950540
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    play_context = PlayContext()
    play_context._prompt = False

    conditional = Conditional()

    templar = Templar(loader=None, variables=VariableManager())

    all_vars = dict()

    assert conditional.evaluate_conditional(templar, all_vars) is True