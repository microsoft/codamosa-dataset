

# Generated at 2022-06-21 00:22:08.833015
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    test_host_vars = {
        'hostname-a': {
            'test_a': 'first value general'
        },
        'hostname-b': {
            'test_b': 'first value specific'
        }
    }

    test_vars = {
        'test_a': 'first value general',
        'test_b': 'first value specific'
    }

    def test_conditional(conditional, expected=True):

        assert conditional.evaluate_conditional(templar, variables) is expected

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')

# Generated at 2022-06-21 00:22:15.479283
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional(loader=None)

# Generated at 2022-06-21 00:22:27.432590
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # JINJA2_OVERRIDE = {
    #     'default_filters': ['str', 'reversed']
    # }

    # JINJA2_ADDONS = {
    #     'filters': {
    #         'humanize_bytes': humanize_bytes,
    #     },
    # }

    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.parsing.vault import VaultAware_parse_yaml

    #
    # Setup the testing environment
    #
    # We prepare a bunch of variables to emulate a basic configuration. For example,
    # a task that can be executed under two different scenarios with

# Generated at 2022-06-21 00:22:34.879429
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # empty string
    assert Conditional().extract_defined_undefined("") == []
    # no defined/undefined checks
    assert Conditional().extract_defined_undefined("foo") == []
    assert Conditional().extract_defined_undefined("foo | bar") == []
    assert Conditional().extract_defined_undefined("ansible_hostname == 'localhost'") == []
    assert Conditional().extract_defined_undefined("foo.bar in ['baz', 'bat']") == []
    # single defined/undefined check
    assert Conditional().extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert Conditional().extract_defined_undefined("foo not is undefined") == [("foo", "not is", "undefined")]
    # multiple defined

# Generated at 2022-06-21 00:22:46.310921
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():


    # parsing a string with a lookup function should raise an error
    c = Conditional()
    t = '{{ hostvars[inventory_hostname].ansible_distribution }}'
    assert_raises(AnsibleError, c.evaluate_conditional, t)

    # parsing a string with a lookup function should raise an error
    c = Conditional()
    t = '{{ lookup("template", "/tmp/foo") }}'
    assert_raises(AnsibleError, c.evaluate_conditional, t)

    # parsing a string with "True" should return True
    c = Conditional()
    t = 'True'
    assert c.evaluate_conditional(t) is True

    # parsing a string with "True or foo" should raise an error
    c = Conditional()
    t = 'True or foo'

# Generated at 2022-06-21 00:22:56.713423
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
  loader = None

  def mock_display():
    pass

  original_display = display.display
  display.display = mock_display

  def generate(self, source, name, filename=None):
    return "foo"

  templar = type('Templar', (object,), {
      'template': lambda s, conditional, disable_lookups=False: conditional,
      'environment': type('Environment', (object,), {'parse': lambda s, x, y, z: None}),
      'generate': generate
  })()

  conditional = Conditional(loader)

  assert conditional.evaluate_conditional(templar, {}) == True
  conditional.when = None
  assert conditional.evaluate_conditional(templar, {}) == True
  conditional.when = ''

# Generated at 2022-06-21 00:23:07.914379
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    p = Conditional()
    assert p._loader is None
    pc = PlayContext()
    m = VariableManager()
    t = Templar(loader=None, variables=m, shared_loader_obj=m)
    p = Conditional(loader=m)
    assert p._loader == m
    assert p._loader.module_loader is None

    assert p.evaluate_conditional(t, dict(a="foo")) is True
    assert p.evaluate_conditional(t, dict(a=None)) is True

    p._when = dict(a='foo')
    assert p.evaluate_conditional(t, dict(a=None)) is False


# Generated at 2022-06-21 00:23:16.503802
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    tests = [
        ('foo is defined and bar is not defined', [('foo', 'is', 'defined'), ('bar', 'is not', 'defined')]),
        ('foo is defined and bar is not defined or bam is undefined', [('foo', 'is', 'defined'), ('bar', 'is not', 'defined'), ('bam', 'is', 'undefined')]),
    ]

    for (conditional, result) in tests:
        if result != cond.extract_defined_undefined(conditional):
            raise AssertionError("test_Conditional_extract_defined_undefined failed, expected %s" % result)



# Generated at 2022-06-21 00:23:17.648075
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional._when == list

# Generated at 2022-06-21 00:23:24.557444
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    # test 1 : defined
    conditional = "var1 is defined and var2 is defined"
    expected = [ ('var1', 'is', 'defined'), ('var2', 'is', 'defined') ]
    results = cond.extract_defined_undefined(conditional)
    assert isinstance(results, list)
    assert expected == results

    # test 2 : undefined
    conditional = "var1 is not undefined or var2 is not undefined"
    expected = [ ('var1', 'is not', 'undefined'), ('var2', 'is not', 'undefined') ]
    results = cond.extract_defined_undefined(conditional)
    assert isinstance(results, list)
    assert expected == results

    # test 3 : defined and undefined
    conditional = "var1 is defined or var2 is undefined"


# Generated at 2022-06-21 00:23:37.804554
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    variable_manager.set_inventory(inventory)

    playbook = PlaybookExecutor(playbooks=[], inventory=inventory, variable_manager=variable_manager, loader=loader, passwords={})
    playbook.conditional = playbook

    conditional = 'is_debian'
    all_vars = [{'ansible_distribution': 'Debian'}]

# Generated at 2022-06-21 00:23:39.100156
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional(None)
    assert isinstance(c, Conditional)
# Unit test end



# Generated at 2022-06-21 00:23:45.053270
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

# Generated at 2022-06-21 00:23:56.716431
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.task import Task
    test_conditional = Task()
    test_conditional.when = ['a is defined', 'b is undefined', 'a is defined\nand b is undefined', 'hostvars[inventory_hostname] is defined']
    conds = test_conditional.extract_defined_undefined(test_conditional.when[0])
    assert conds == [('a', 'is', 'defined')]
    conds = test_conditional.extract_defined_undefined(test_conditional.when[1])
    assert conds == [('b', 'is', 'undefined')]
    conds = test_conditional.extract_defined_undefined(test_conditional.when[2])

# Generated at 2022-06-21 00:24:05.960278
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class MyConditional(Conditional):
        def __init__(self):
            self.when = []
            self.when.append(u"a and b")
            self.when.append(u"a or b")
            self.when.append(u"a in b")
            self.when.append(u"a not in b")
            self.when.append(u"'ansible' == 'ansible'")
            self.when.append(u"'ansible' != 'ansible'")
            self.when.append(u"'ansible' is 'ansible'")
            self.when.append(u"'ansible' is not 'ansible'")
            self.when.append(u"1 == 1")
           

# Generated at 2022-06-21 00:24:17.302355
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-21 00:24:27.593209
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    m = Conditional()

    assert m.extract_defined_undefined("a is defined") == [("a", "is", "defined")]
    assert m.extract_defined_undefined("a is not defined") == [("a", "is not", "defined")]
    assert m.extract_defined_undefined("a is defined or b is not defined") == [("a", "is", "defined"), ("b", "is not", "defined")]
    assert m.extract_defined_undefined("not(a is defined or b is not defined)") == [("a", "is", "defined"), ("b", "is not", "defined")]

# Generated at 2022-06-21 00:24:37.929644
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class TestConditional(Conditional):
        def __init__(self, test_conditional):
            self.test_conditional = test_conditional

    tc = TestConditional("foo.bar is defined and baz is not defined and "
                                 "false or not hostvars['localhost']['ansible_connection'] is undefined or "
                                 "quux or (x == 1 and y == 2)")
    assert tc.extract_defined_undefined(tc.test_conditional) == [
        ('foo.bar', 'is', 'defined'),
        ('baz', 'is not', 'defined'),
        ("hostvars['localhost']['ansible_connection']", 'is', 'undefined')
    ]

# Generated at 2022-06-21 00:24:47.315089
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing import PluginLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars

    p = PluginLoader('./lib/ansible/plugins/test_conditional').get('test_conditional', None)
    dirs = [p.get_dir()]
    pm = PluginLoader('./lib/ansible/plugins', './plugins', './module_utils', './inventory', './lookup_plugins', './cache')
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager, host_list='/dev/null'))

# Generated at 2022-06-21 00:24:58.615391
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

    conditional = 'cond1 and cond2 or cond3'
    def_undef = cond.extract_defined_undefined(conditional)
    assert def_undef == []

    conditional = 'cond1 and (cond2 or "cond3")'
    def_undef = cond.extract_defined_undefined(conditional)
    assert def_undef == []

    conditional = '"cond1" is not defined and "cond2" is defined or "cond3" is undefined'
    def_undef = cond.extract_defined_undefined(conditional)
    assert def_undef == [('"cond1"', 'is not', 'defined'), ('"cond2"', 'is', 'defined'), ('"cond3"', 'is', 'undefined')]


# Generated at 2022-06-21 00:25:14.351780
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional._when == []
    conditional._validate_when('attr', 'name', 'value')
    assert conditional._when == [ 'value' ]

# Generated at 2022-06-21 00:25:21.443625
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
	Conditional_test = Conditional()
	
	# test with no conditional, return False
	assert not Conditional_test.evaluate_conditional(None, None, None)
	
	# test with a conditional, return True
	conditional = "ansible_distribution == 'RedHat'"
	assert Conditional_test.evaluate_conditional(None, None, conditional) == True



# Generated at 2022-06-21 00:25:30.529340
# Unit test for constructor of class Conditional
def test_Conditional():
    '''
    Unit test for constructor of class Conditional
    '''

    # create a variable dictionary to pass into the Conditional
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'a': 1, 'b': 2, 'c': 3}

    # create the Conditional object
    condition_test = Conditional(loader=None)

    # assign a list of conditions to the Conditional object
    condition_test.when = ["a > 2", "b < 2", "c == 3"]

    # run the test
    results = condition_test.evaluate_conditional(variable_manager.extra_vars)

    # check the results
    assert results == 'skipped'



# Generated at 2022-06-21 00:25:39.123782
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    cond = Conditional()
    cond.when = ["false"]
    res = cond.evaluate_conditional(None, None)
    assert res is False, "should return false after 1st loop"

    cond.when = ["false", "false"]
    res = cond.evaluate_conditional(None, None)
    assert res is False, "should return false after 2nd loop"

    cond.when = ["false", "false", "false"]
    res = cond.evaluate_conditional(None, None)
    assert res is False, "should return false after 3rd loop"

    cond.when = ["false", "false", "true"]
    res = cond.evaluate_conditional(None, None)
    assert res is False, "should return false because False came before True"

    cond.when = ["false", "true", "true"]
   

# Generated at 2022-06-21 00:25:50.514226
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

    assert cond.extract_defined_undefined("") == []
    assert cond.extract_defined_undefined("hostvars is undefined") == [('hostvars', 'is', 'undefined')]
    assert cond.extract_defined_undefined("hostvars[inventory_hostname] is defined") == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert cond.extract_defined_undefined("hostvars[inventory_hostname] is not defined") == [('hostvars[inventory_hostname]', 'is not', 'defined')]

# Generated at 2022-06-21 00:25:59.571572
# Unit test for constructor of class Conditional
def test_Conditional():

    import pytest
    from ansible.playbook.play_context import PlayContext

    class LoaderObj():
        pass

    class ContextObj():
        pass

    class ConditionalObj():
        _loader = LoaderObj()
        _owner   = ContextObj()

        _when = FieldAttribute(isa='list', default=list, extend=True, prepend=True)

        def __init__(self):
            super(ConditionalObj, self).__init__()

    c = ConditionalObj()

    c.when = [ "hostvars['foo'].bar is defined and hostvars['foo'].bar == 'blah'" ]

    context = PlayContext()
    context._hosts = [ 'foo' ]
    context._vars = { 'foo': { 'bar': 'blah' } }
    #context._task_

# Generated at 2022-06-21 00:26:11.419417
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # No conditional
    cond = Conditional()
    assert not cond.extract_defined_undefined(None)

    # No "defined" expression
    no_defined = 'foo'
    assert not cond.extract_defined_undefined(no_defined)

    # Basic "defined" expression
    basic_defined = 'foo is defined'
    assert cond.extract_defined_undefined(basic_defined) == [('foo', 'is', 'defined')]

    # Ignore non "defined" expression
    basic_not = 'foo is not bar'
    assert not cond.extract_defined_undefined(basic_not)

    # Ignore syntax error
    syntax_error = "foo is defined baz is undefined"
    assert not cond.extract_defined_undefined(syntax_error)

    # Ignore non "defined" variable name

# Generated at 2022-06-21 00:26:21.460173
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    """
    Test Conditional class method Conditional.extract_defined_undefined()
    """
    conditional = Conditional()
    # Single detection test
    conditional_string = "foo is defined"
    expected = [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined(conditional_string) == expected
    # Single detection with spaces
    conditional_string = "    foo    is    defined   "
    expected = [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined(conditional_string) == expected
    # Multiple detections
    conditional_string = "foo is defined and bar not is not defined and baz is defined or qux is undefined"

# Generated at 2022-06-21 00:26:32.094361
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar

    ds = dict(one="foo", two="bar", three="baz", dict=dict(one=1, two=2, three=3), list=[1, 2, 3])
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory(host_list=C.DEFAULT_HOST_LIST))

# Generated at 2022-06-21 00:26:41.407387
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    host_vars = dict(
        foo="bar",
        ansible_distribution="Fedora",
        ansible_os_family="RedHat",
        ansible_pkg_mgr="yum",
        complex_dict=dict(hostvar1="hostvar1 value", hostvar2="hostvar2 value"),
        list=['1', '2', '3'],
    )
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])

# Generated at 2022-06-21 00:27:25.579131
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    to_test = "foo is defined and (bar is not defined or baz is defined)"
    c = Conditional()
    d_u = c.extract_defined_undefined(to_test)
    assert len(d_u) == 4
    assert 'foo' in [x[0] for x in d_u]
    assert 'bar' in [x[0] for x in d_u]
    assert 'baz' in [x[0] for x in d_u]
    assert 'not' in [x[1] for x in d_u]
    assert 'is' in [x[1] for x in d_u]
    assert 'defined' in [x[2] for x in d_u]
    assert 'undefined' in [x[2] for x in d_u]

comparison

# Generated at 2022-06-21 00:27:32.970792
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    try:
        Conditional()
    except AnsibleError as e:
        assert "loader must be specified" in to_native(e)

    c = Conditional(loader=DataLoader())
    c.when = ['foo', 'bar']
    assert c.when == ['foo', 'bar']

    c.when = True
    assert c.when == [True]


# Generated at 2022-06-21 00:27:42.965298
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from units.mock.loader import DictDataLoader

    loader = DictDataLoader({
        "playbook": { "hosts": "all",
                      "gather_facts": False,
                      "tasks": [{ "name": "setup", "setup": "" }]
                    }
    })
    conditional = Conditional(loader=loader)
    display.verbosity = 4 # avoid "ok" messages from the unit test output

    (result, msg) = conditional.extract_defined_undefined('test1 is defined')
    assert result == [ ('test1', 'is', 'defined') ]

    (result, msg) = conditional.extract_defined_undefined('test1 not is defined')
    assert result == [ ('test1', 'not is', 'defined') ]

    (result, msg) = conditional.extract_defined_

# Generated at 2022-06-21 00:27:49.995632
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    def test_extract(cond, expected):
        actual = conditional.extract_defined_undefined(cond)
        if actual != expected:
            raise AssertionError("actual:%s != expected:%s" % (actual, expected))

    test_extract('foo is defined', [('foo', 'is', 'defined')])
    test_extract('foo not is defined', [('foo', 'not is', 'defined')])
    test_extract('foo is not defined', [('foo', 'is not', 'defined')])
    test_extract('foo not is not defined', [('foo', 'not is not', 'defined')])
    test_extract('foo is undefined', [('foo', 'is', 'undefined')])

# Generated at 2022-06-21 00:27:57.110319
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    cond = Conditional(loader=loader)
    assert cond._loader is loader

# Generated at 2022-06-21 00:28:07.380233
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-21 00:28:14.846975
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test case: Evaluate conditional expressions
    class ClassA:

        def __init__(self):
            self.when = list()
            self.when.append("'a' in groups and 'b' in groups")
            self.when.append("ansible_os_family == 'Debian'")
            self.when.append("ansible_distribution == 'CentOS' and ansible_distribution_major_version == '7'")
            self.when.append("ansible_package_mgr == 'apt'")
            self.when.append("ansible_facts['os_family'] in ['Debian']")
            self.when.append("ansible_facts['distribution'] in ['Ubuntu']")
            self.when.append("ansible_facts['distribution_version'] in ['14.04']")

# Generated at 2022-06-21 00:28:17.878729
# Unit test for constructor of class Conditional
def test_Conditional():
    assert len(Conditional().when) == 0
    assert len(Conditional(loader='').when) == 0


# Generated at 2022-06-21 00:28:25.492198
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert Conditional().extract_defined_undefined('this is defined') == []
    assert Conditional().extract_defined_undefined('this is undefined') == []
    assert Conditional().extract_defined_undefined('this is defined and this is undefined') == []
    assert Conditional().extract_defined_undefined('this is defined is defined') == [('this', 'is', 'defined')]
    assert Conditional().extract_defined_undefined('this "is defined is defined"') == []
    assert Conditional().extract_defined_undefined('"this" is defined') == [('this', 'is', 'defined')]

# Generated at 2022-06-21 00:28:26.365621
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c._when == []


# Generated at 2022-06-21 00:29:59.264353
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar

    def _tmpl(cont):
        # helper method
        return Templar(MockPlay()).template(cont)

    # test cases are tuples of (condition, variable dictionary, expected result)
    #
    # Note: variable dictionary is a structure used by AnsibleModule to store the variables
    # so it's a bit complex here: { 'ansible_facts': { 'some_var': 'foo' } }


# Generated at 2022-06-21 00:30:00.029864
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    assert True



# Generated at 2022-06-21 00:30:10.304921
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    class TestClass(Conditional):

        def __init__(self):
            self._loader = DictDataLoader({})
            self._variable_manager = VariableManager()
            self._inventory = InventoryManager(loader=DictDataLoader({}),
                                               sources=['localhost,'])

        def evaluate_conditional(self, templar, variables):
            Conditional.evaluate_conditional(self, templar, variables)


# Generated at 2022-06-21 00:30:21.513975
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    """
    This method has a lot of options that needs to be checked, the idea
    of the unit testing was to create all possible combinations of
    conditional paramters and check it against the extracted tests
    """

    from ansible.playbook.task import Task

    # Create a conditional task
    ct = Task()

    # define all parameter variations for conditional
    parameters = ['',
                  'not ',
                  'not',
                  ' is ',
                  'is ',
                  'is',
                  ' is not ',
                  'is not ',
                  'is not',
                  ' ',
                  '  ',
                  '   ']

    # define all variable variations for conditional

# Generated at 2022-06-21 00:30:22.557958
# Unit test for constructor of class Conditional
def test_Conditional():
    assert Conditional

# Generated at 2022-06-21 00:30:30.553554
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext

    display = Display()
    display.verbosity = 3

    test = Conditional(loader=Playbook.loader)

    results = test.evaluate_conditional(
        templar=Playbook.variable_manager,
        all_vars={
            'ansible_check_mode': True,
            'ansible_version': {'full': '0'},
            'playbook_dir': '/home/alice/playbooks'
        },
    )
    assert results is True

# Generated at 2022-06-21 00:30:42.017493
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.vars.unsafe_proxy import UnsafeProxy

    display.verbosity = 3
    assert Conditional().evaluate_conditional(
        templar=None, all_vars=dict(a=1)
    )

    assert not Conditional().evaluate_conditional(
        templar=None, all_vars=dict(a=False)
    )

    assert Conditional(None, dict(a=1)).evaluate_conditional(
        templar=None, all_vars=dict(a=1)
    )

    assert Conditional(None, dict(a=False)).evaluate_conditional(
        templar=None, all_vars=dict(a=False)
    )


# Generated at 2022-06-21 00:30:43.450160
# Unit test for constructor of class Conditional
def test_Conditional():
    assert Conditional(loader=None)

# Generated at 2022-06-21 00:30:53.741576
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """
    Evaluate various tests to see if the methods works as expected
    """
    class DummyClass():
        pass

    # type when should be list
    d = DummyClass()
    d.when = ['true']
    d.evaluate_conditional('1')

    # type when should be list
    d = DummyClass()
    d.when = 'true'
    res = d.evaluate_conditional('1')
    assert res is False

    # type when should be list
    d = DummyClass()
    d.when = 'true'
    res = d.evaluate_conditional(0)
    assert res is True

    # type when should be list
    d = DummyClass()
    d.when = 1
    res = d.evaluate_conditional(0)
    assert res is True

    # when

# Generated at 2022-06-21 00:31:01.132086
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Create instance of class Conditional for testing
    c = Conditional()

    # Test result
    assert c.extract_defined_undefined('') == []
    assert c.extract_defined_undefined('foo') == []
    assert c.extract_defined_undefined('foo is defined') == []
    assert c.extract_defined_undefined('hostvars[x] is defined') == [('hostvars[x]', 'is', 'defined')]
    assert c.extract_defined_undefined('hostvars[x] is not defined') == [('hostvars[x]', 'is not', 'defined')]
    assert c.extract_defined_undefined('frodo is not defined') == [('frodo', 'is not', 'defined')]
    assert c.extract_defined