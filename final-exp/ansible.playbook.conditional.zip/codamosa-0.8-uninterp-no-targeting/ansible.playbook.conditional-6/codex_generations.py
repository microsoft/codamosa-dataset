

# Generated at 2022-06-21 00:22:10.273756
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

    assert c.extract_defined_undefined('') == []
    assert c.extract_defined_undefined('hostvars["foo"] is not defined') == \
        [['hostvars["foo"]', 'is not', 'defined']]
    assert c.extract_defined_undefined('hostvars["foo"] is not defined and hostvars["bar"] is undefined') == \
        [['hostvars["foo"]', 'is not', 'defined'], ['hostvars["bar"]', 'is', 'undefined']]
    assert c.extract_defined_undefined('1') == []
    assert c.extract_defined_undefined('1 and hostvars["foo"] is defined') == \
        [['hostvars["foo"]', 'is', 'defined']]



# Generated at 2022-06-21 00:22:12.508896
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional("HelloWorld")
    assert c._loader == 'HelloWorld'


# Generated at 2022-06-21 00:22:13.604176
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()


# Generated at 2022-06-21 00:22:25.239542
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined('foo is defined and bar is undefined') == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]
    assert c.extract_defined_undefined('foo is defined and bar is undefined or not baz is undefined') == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined'), ('baz', 'is', 'undefined')]
    assert c.extract_defined_undefined('foo is defined or bar is not undefined') == [('foo', 'is', 'defined'), ('bar', 'is', 'not undefined')]

# Generated at 2022-06-21 00:22:34.392425
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.utils.vars import combine_vars
    from ansible.vars import VariableManager
    from ansible.template import Templar

    variable_manager = VariableManager()
    variable_manager.extra_vars = combine_vars(loader=None, variables=dict(a=1), vault_password=None)
    templar = Templar(loader=None, variables=variable_manager)

    conditional = Conditional(loader=None, when=[True])
    assert conditional.evaluate_conditional(templar, variable_manager.get_vars(loader=None, play=None)) is True

    # Test non-existent variable
    conditional = Conditional(loader=None, when=[True, '{{ a }} == 1', '{{ b }} == 1'])

# Generated at 2022-06-21 00:22:45.638442
# Unit test for constructor of class Conditional
def test_Conditional():
    from jinja2 import Environment, DictLoader

    env = Environment(loader=DictLoader({'invalid_template.j2': """{{ undefined_var }}"""}))
    c = Conditional(loader=env)

    c._validate_when('1')
    assert c._when == [u'1']

    c._validate_when(['1', '2'])
    assert c._when == [u'1', u'2']

    c._validate_when(1)
    assert c._when == [u'1']

    c._validate_when(['1', 1])
    assert c._when == [u'1', u'1']

    c.when = '1'
    assert c.when == [u'1']

    c.when = ['1', '2']

# Generated at 2022-06-21 00:22:56.407321
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import ansible.playbook.play

    pb = ansible.playbook.play.Play()
    pb.connection = 'smart'
    class Host:
        def __init__(self, name):
            self.name = name
            self.vars = dict()
    pb._variable_manager = ansible.playbook.play._VariableManager()
    pb._variable_manager.extra_vars = dict(a=1, b="2")
    pb._variable_manager.host_vars = dict(s1=Host('s1'), s2=Host('s2'), s3=Host('s3'))

# Generated at 2022-06-21 00:23:07.548868
# Unit test for constructor of class Conditional
def test_Conditional():

    class FakeVarsModule(object):
        pass

    class FakeLoader(object):

        def get_basedir(self):
            return '/home/john/ansible'

        def load_from_file(self, path):
            return {
                'vars': {
                    'y': 1,
                    'z': 2
                },
                'a': 'foo'
            }

    class FakePlay(object):

        def __init__(self):
            self._ds = 'fake_play.yml'

    c = Conditional(loader=FakeLoader())
    c._loader = FakeLoader()
    c._play = FakePlay()
    c.vars_module = FakeVarsModule()
    c._datastore = {
        'x': 1,
        'y': 2,
        'z': 3
    }

# Generated at 2022-06-21 00:23:11.963426
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test with an empty when list
    # This is a hack to test evaluate_conditional without having a playbook, handler etc.
    # Should be replaced with a proper mock
    test_cond = Conditional()
    test_cond.when = []
    assert test_cond.evaluate_conditional([], {})


# Generated at 2022-06-21 00:23:21.628027
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude

    def _validate_conditional(conditional, templar, expect_true):
        if conditional is None or conditional == '':
            return True == expect_true
        elif isinstance(conditional, bool):
            return conditional == expect_true
        else:
            return templar._check_conditional(conditional, templar, all_vars)

    play = Play().load({}, loader=None)
    templar = play.set_loader(None)
    templar.set_available_variables(dict())
    task = TaskInclude().load({'when': 'not set'}, play=play)
    all_v

# Generated at 2022-06-21 00:23:49.840330
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.utils.vars import combine_vars

    class TestModule(object):
        def __init__(self, play_context):
            self.play_context = play_context

    class TestDS(Conditional):
        def __init__(self, loader, when_list):
            super(TestDS, self).__init__(loader)
            self.when = when_list

    class TestPlaybook(object):

        class TestPlay(object):
            pass

        class TestInventory(object):
            host_vars = {'foo': {'bar': "baz"}}


# Generated at 2022-06-21 00:23:52.525082
# Unit test for constructor of class Conditional
def test_Conditional():
    x = Conditional()
    assert x
    assert not x.evaluate_conditional(None, None)



# Generated at 2022-06-21 00:24:03.071036
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.base import Base

    class TestConditional(Conditional, Base):
        pass

    test_local = TestConditional()
    # basic case
    defined = "foo is defined"
    res = test_local.extract_defined_undefined(defined)
    assert (len(res) == 1)
    assert (res[0][0] == 'foo')
    assert (res[0][1] == 'is')
    assert (res[0][2] == 'defined')
    # more complex case
    defined = "hostvars[inventory_hostname] is not defined"
    res = test_local.extract_defined_undefined(defined)
    assert (len(res) == 1)
    assert (res[0][0] == 'hostvars[inventory_hostname]')

# Generated at 2022-06-21 00:24:04.634618
# Unit test for constructor of class Conditional
def test_Conditional():
    try:
        t = Conditional()
        raise Exception('Conditional() worked without loader!')
    except:
        pass

# Generated at 2022-06-21 00:24:10.046677
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-21 00:24:11.307177
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional.when == []

# Generated at 2022-06-21 00:24:13.118686
# Unit test for constructor of class Conditional
def test_Conditional():
    # Simple test, we should be able to create a Conditional object
    c = Conditional()
    assert c is not None

# Generated at 2022-06-21 00:24:24.183614
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    show_conditional = """
    test_def_conditional1 or test_def_conditional2 or test_undef_conditional
    or test_def_conditional3 and test_undef_conditional1 or test_def_conditional4
    and test_def_conditional5 and test_undef_conditional2
    """
    test_Conditional = Conditional()

# Generated at 2022-06-21 00:24:31.487899
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('a is defined') == [('a', 'is', 'defined')]
    assert c.extract_defined_undefined('a is not defined') == [('a', 'is not', 'defined')]
    assert c.extract_defined_undefined('a is foo') == []
    assert c.extract_defined_undefined('a is not b') == []
    assert c.extract_defined_undefined('a is defined or b is undefined') == [('a', 'is', 'defined'), ('b', 'is', 'undefined')]
    assert c.extract_defined_undefined('a is defined or c is not defined') == [('a', 'is', 'defined'), ('c', 'is not', 'defined')]


# Generated at 2022-06-21 00:24:42.917859
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    module = AnsibleModule(argument_spec={})
    conditional_inst = Conditional()
    conditional_inst._templar = Templar(loader=DataLoader(), variables={'hostvars': {'host1': {'foo': 'bar'}, 'host2': {'foo': 'bar'}, 'host3': {'foo': 'bar'}}})
    assert conditional_inst.evaluate_conditional(conditional_inst._templar, {}) == True
    assert conditional_inst.evaluate_conditional(conditional_inst._templar, {'foo': 'foo'}) == True
    assert conditional_inst.evaluate_conditional(conditional_inst._templar, {'foo': True}) == True
    assert conditional_inst.evaluate_conditional(conditional_inst._templar, {'foo': False}) == True
   

# Generated at 2022-06-21 00:25:29.169408
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class Fake_ds(object):
        _ds = None
        _wrapped = None
    class Fake_templar(object):
        def __init__(self):
            self.vars = {}
            self.environment = None
            self.template = None
            self.is_template = None
            self.available_variables = {}
        def template(self, conditional, disable_lookups=False):
            return conditional
    class Fake_ansible_play_context(object):
        def __init__(self):
            self._config = {
                "DEFAULT_ANSIBLE_MODULE_ARGS": {},
                "ANSIBLE_HOST_KEY_CHECKING": C.DEFAULT_HOST_KEY_CHECKING,
            }
            self.become = False
            self.become_user = None
           

# Generated at 2022-06-21 00:25:34.943219
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    play_context = PlayContext()
    play_context.network_os = 'ios'
    templar = Templar(loader=None, variables={},
                      shared_loader_obj=None,
                      disable_lookups=False,
                      fail_on_undefined=False,
                      keep_trailing_newline=False,
                      fail_on_lookup_errors=False,
                      convert_data=False,
                      environment=None,
                      play_context=play_context)

    class TestModule(object):
        def __init__(self):
            self.when = []
            self.when.append('ansible_network_os == "ios"')

# Generated at 2022-06-21 00:25:41.037294
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # I pass a templar object to _check_conditional
    class Templar():
        def __init__(self):
            self.available_variables = {}
        def template(self, content, disable_lookups):
            # return directly the content
            return content
        def is_template(self, content):
            # return directly a boolean if template or not
            return True if isinstance(content, text_type) else False

    # I pass a Conditional object with a mocked templar to evaluate_conditional

# Generated at 2022-06-21 00:25:52.162204
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.plugins import module_loader

    play_context = PlayContext()
    variable_manager = VariableManager()
    loader = DataLoader()
    play = Play()
    tqm = None
    play_context.variable_manager = variable_manager
    play_context.loader = loader
    play_context.CLIARGS = dict(module_path=C.DEFAULT_MODULE_PATH)

# Generated at 2022-06-21 00:26:00.502865
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-21 00:26:11.661508
# Unit test for constructor of class Conditional
def test_Conditional():
    test_cases = [
        # test the when statement
        {
            "name": "when: a == true",
            "kwargs": {"body": "a == true"},
            "expected": True,
        },
        {
            "name": "when: a == false",
            "kwargs": {"body": "a == false"},
            "expected": False,
        },
    ]


# Generated at 2022-06-21 00:26:21.644365
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # test non string or empty string:
    assert Conditional().extract_defined_undefined(None) == []
    assert Conditional().extract_defined_undefined('') == []
    # test simple use cases:
    assert Conditional().extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert Conditional().extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    # test use case with hostvars:
    assert Conditional().extract_defined_undefined('hostvars[foo] is not defined') == [('hostvars[foo]', 'is not', 'defined')]
    # test complex use cases:

# Generated at 2022-06-21 00:26:22.494097
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    raise NotImplementedError()


# Generated at 2022-06-21 00:26:33.217324
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import ansible.playbook.play_context
    import ansible.template
    import ansible.vars.unsafe_proxy

    class MockTemplar(ansible.template.AnsibleTemplar):
        def __init__(self, ds=None, variables=dict(), fail_on_undefined=False, convert_bare=True, convert_data=False,
                     disable_lookups=False, fail_on_lookup_errors=True, environment=None, **kwargs):
            self.ds = ds
            self.environment = environment
            self.available_variables = variables
            self.fail_on_undefined = fail_on_undefined
            self.convert_bare = convert_bare
            self.convert_data = convert_data
            self.disable_lookups = disable_lookups
           

# Generated at 2022-06-21 00:26:36.758991
# Unit test for constructor of class Conditional
def test_Conditional():
    cond = Conditional()
    assert isinstance(cond.when, list)
    assert len(cond.when) == 0
    cond = Conditional(loader=object())
    assert isinstance(cond.when, list)
    assert len(cond.when) == 0

# Generated at 2022-06-21 00:27:31.825555
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class ConditionalObject(Conditional):
        def __init__(self):
            pass

    obj = ConditionalObject()
    assert obj.extract_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert obj.extract_defined_undefined('hostvars[inventory_hostname] not is undefined') == [('hostvars[inventory_hostname]', 'not is', 'undefined')]
    assert obj.extract_defined_undefined('hostvars[inventory_hostname] not is undefined and ansible_version is defined') == [('hostvars[inventory_hostname]', 'not is', 'undefined'), ('ansible_version', 'is', 'defined')]
    assert obj.extract_defined_

# Generated at 2022-06-21 00:27:42.387031
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    print("Testing valid scenario")
    print(c.extract_defined_undefined("var is defined"))
    print(c.extract_defined_undefined("hostvars['foo'] is defined"))
    print(c.extract_defined_undefined("var is not defined"))
    print(c.extract_defined_undefined("hostvars['foo'] is not defined"))
    print(c.extract_defined_undefined("var is undefined"))
    print(c.extract_defined_undefined("hostvars['foo'] is undefined"))
    print(c.extract_defined_undefined("var is not undefined"))
    print(c.extract_defined_undefined("hostvars['foo'] is not undefined"))

# Generated at 2022-06-21 00:27:49.668829
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    c = Conditional(loader=loader)
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader, template_class=type(u''),
                      all_vars = variable_manager.get_vars(play=play_context, use_cache=True),
                      fail_on_undefined=True)


# Generated at 2022-06-21 00:28:00.412193
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    The test class is mocked because it needs self._loader
    :return:
    '''

    class m_loader(object):
        def __init__(self):
            self.path_exists = lambda x: False
            self.path_exists.__name__ = "path_exists"

            self.is_file = lambda x: False
            self.is_file.__name__ = "is_file"

            self.is_directory = lambda x: False
            self.is_directory.__name__ = "is_directory"

            self.list_directory = lambda x: []
            self.list_directory.__name__ = "list_directory"

    class m_templar(object):
        def __init__(self):
            self.template = lambda x, disable_lookups=None: x

# Generated at 2022-06-21 00:28:09.941461
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import json
    import yaml

    # Fixtures
    class TestModule(object):

        def __init__(self, *args, **kwargs):
            self.params = args[0]

    # Test "when" as a list
    class TestClass1(Conditional, object):
        def __init__(self, *args, **kwargs):
            self.name = 'MyTestClass'
            self.when = [ '"{{foo}}" == "bar"',
                          '1==1',
                          '"{{baz}}" == "qux"' ]
            super(TestClass1, self).__init__(*args, **kwargs)

    mytestclass1 = TestClass1()

# Generated at 2022-06-21 00:28:18.873915
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    vars_manager = VariableManager()
    templar = Templar(loader=None, variables=vars_manager)

    class Dummy(Conditional):
        def __init__(self):
            super(Dummy, self).__init__(loader=None)

    d = Dummy()
    d._validate_when(d, "_when", "a")
    assert(isinstance(d._when, list))
    d._when = []
    d._validate_when(d, "_when", ["a", "b"])
    assert(isinstance(d._when, list))

    # single quotes

# Generated at 2022-06-21 00:28:21.424164
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # evaluate_conditional returns False if there are any failed
    # conditions. Any error type other than AnsibleUndefinedVariable raises an exception.

    # This is a stub
    pass



# Generated at 2022-06-21 00:28:29.740700
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Hosts()
    inventory.add_host(Host("127.0.0.2"))
    inventory.add_host(Host("127.0.0.3"))
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    setattr(play_context, 'prompt', lambda x, y, z=None, a=None: (True, y, z))
    templar = Templar(loader=loader, variables=variable_manager,
                      shared_loader_obj=loader._shared_loader_obj, play_context=play_context)

   

# Generated at 2022-06-21 00:28:34.390667
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = "somevar is defined or ( hostvars['somemachine'] is not defined ) and somevar == 2 or othervar == 3"
    assert Conditional().extract_defined_undefined(conditional) == [
        ('somevar', 'is', 'defined'),
        ('hostvars[\'somemachine\']', 'is not', 'defined')
    ]

# Generated at 2022-06-21 00:28:44.178847
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    from ansible.playbook.base import Base

    class MyTask(Conditional, Base):
        def __init__(self):
            self._parent = None
            self._loader = DataLoader()
            self._variable_manager = VariableManager()
            self._inventory = InventoryManager(loader=self._loader, sources=[])
            self._tqm = None
            self._shared_loader_obj = None
            self._templar = Templar(loader=self._loader, variables=self._variable_manager)
            super(Conditional, self).__init__(loader=self._loader)


# Generated at 2022-06-21 00:30:27.744935
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional._when == []
    conditional = Conditional(loader='loader')
    assert conditional._when == []
    assert conditional._loader == 'loader'

# Generated at 2022-06-21 00:30:29.764584
# Unit test for constructor of class Conditional
def test_Conditional():
    obj = Conditional()
    assert obj._when == []


# Generated at 2022-06-21 00:30:37.167243
# Unit test for constructor of class Conditional
def test_Conditional():

    dummy_loader = object()

    conditional = Conditional(loader=dummy_loader)

    assert isinstance(conditional, Conditional)
    assert hasattr(conditional, '_when')
    assert conditional._when == []
    assert hasattr(conditional, '_loader')
    assert conditional._loader == dummy_loader


# Generated at 2022-06-21 00:30:40.418633
# Unit test for constructor of class Conditional
def test_Conditional():
    # explicitly creating an instance of Conditional class to
    # test methods in this class
    conditional = Conditional()
    # test the _validate_when method
    conditional._validate_when("", "", "")
    conditional._validate_when("", "", list())


# Generated at 2022-06-21 00:30:52.827876
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("a is defined") == [ ("a", "is", "defined") ]
    assert c.extract_defined_undefined("a not is undefined") == [ ("a", "not is", "undefined") ]
    assert c.extract_defined_undefined("a not is defined and b is undefined") == [ ("a", "not is", "defined"), ("b", "is", "undefined") ]
    assert c.extract_defined_undefined("a not is defined or b is undefined") == [ ("a", "not is", "defined") ]
    assert c.extract_defined_undefined("a.b not is defined or b.c is undefined") == [ ("a.b", "not is", "defined") ]
    assert c.extract_defined_und

# Generated at 2022-06-21 00:30:58.744889
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert(cond.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')])
    assert(cond.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')])
    assert(cond.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')])
    assert(cond.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')])
    assert(cond.extract_defined_undefined('a is defined or b is not defined') == [('a', 'is', 'defined'), ('b', 'is not', 'defined')])

# Generated at 2022-06-21 00:31:11.690904
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    data = dict(
        testvar = "yes",
        testvar2= "yes2",
    )
    fake_loader = DictDataLoader({})
    context = PlayContext()
    context._vars = data
    templar = Templar(loader=fake_loader, variables=data, context=context)

    cond_obj = Conditional()

    assert cond_obj._check_conditional('testvar', templar, data)

    # unquoted_value=True should not have been used since that was removed
    # context.CLIARGS = ImmutableDict(dict(unquoted_value=True))
    # context.CLIARGS._an_immutable_dict = True
    # assert cond_obj._

# Generated at 2022-06-21 00:31:20.455569
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Setup method
    conditional = Conditional()
    # Ensure the evaluate_conditional() method evaluates each conditional set on this object,
    # returning False if any of them evaluate as such.
    # Case 1: when conditional are None
    assert conditional.evaluate_conditional(None, None) is True
    # Case 2: when conditional are bool
    assert conditional.evaluate_conditional(None, True) is True
    # Case 3: when conditional are defined
    assert conditional.evaluate_conditional(None, 'ansible_os_family == "Debian"') is False


# Generated at 2022-06-21 00:31:22.794431
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c._when is not None


# Generated at 2022-06-21 00:31:32.024722
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

    assert c.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert c.extract_defined_undefined('foo is defined and bar is defined') == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]
    assert c.extract_defined_undefined('foo is not undefined or bar is not undefined') == [('foo', 'is not', 'undefined'), ('bar', 'is not', 'undefined')]