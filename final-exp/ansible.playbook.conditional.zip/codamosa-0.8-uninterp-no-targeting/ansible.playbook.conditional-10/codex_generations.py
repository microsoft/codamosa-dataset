

# Generated at 2022-06-21 00:22:00.550903
# Unit test for constructor of class Conditional
def test_Conditional():
    class Foo:
        pass
    b = Conditional()
    try:
        b.evaluate_conditional(Foo(), 'foo')
        assert False
    except:
        assert True

# Generated at 2022-06-21 00:22:10.433270
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar


# Generated at 2022-06-21 00:22:23.441445
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()


# Generated at 2022-06-21 00:22:33.219383
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("foobar") == []
    assert c.extract_defined_undefined("defined") == []
    assert c.extract_defined_undefined("undefined") == []
    assert c.extract_defined_undefined("a is defined") == [('a', 'is', 'defined')]
    assert c.extract_defined_undefined("a is undefined") == [('a', 'is', 'undefined')]
    assert c.extract_defined_undefined("a not is defined") == [('a', 'not is', 'defined')]
    assert c.extract_defined_undefined("a not is undefined") == [('a', 'not is', 'undefined')]

# Generated at 2022-06-21 00:22:44.694080
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()

    conditional.when = ['testvar']
    conditional.when = ['testvar == "testvar"']
    conditional.when = ['testvar != "anothervar"']
    conditional.when = ['testvar in testvar']
    conditional.when = ['testvar not in testvar']
    conditional.when = ['testvar is defined']
    conditional.when = ['testvar == "testvar" or testvar == "anothervar"']
    conditional.when = ['testvar == "testvar" and testvar == "anothervar"']
    conditional.when = ['testvar == "testvar" or testvar == "anothervar" or testvar2 == "testvar2"']
    conditional.when = ['testvar == "testvar" and testvar == "anothervar" or testvar2 == "testvar2"']
   

# Generated at 2022-06-21 00:22:55.712713
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    def _test_cond(conditional, all_vars, expected_result, t_result=None):
        c = Conditional()
        c.when = [conditional]
        r = c.evaluate_conditional(Templar(), all_vars)
        assert r == expected_result, \
            'evaluate_conditional failed: %r != %r' % (r, expected_result)

        if t_result:
            assert expected_result == t_result, \
                'evaluate_conditional invalid templated value %r != %r' % (t_result, expected_result)

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.inventory.host import Host

    # complex example from a real world

# Generated at 2022-06-21 00:23:07.046681
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    c = Conditional(DataLoader())
    assert c._loader is not None
    assert c._ds is None
    assert c.when == []

    c = Conditional(DataLoader(), dict())
    assert c._loader is not None
    assert c._ds == dict()
    assert c.when == []

    test_data = {'when': [dict()]}
    c = Conditional(DataLoader(), test_data)
    assert c._loader is not None
    assert c._ds == test_data

    test_data = {'when': dict()}
    c = Conditional(DataLoader(), test_data)
    assert c._loader is not None
    assert c._ds == test_data

    # Test

# Generated at 2022-06-21 00:23:08.310090
# Unit test for constructor of class Conditional
def test_Conditional():
    pass


# Generated at 2022-06-21 00:23:18.998013
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    conditional = Conditional()

    my_hostvars = dict(foo=dict(baz='bar'))

# Generated at 2022-06-21 00:23:25.155314
# Unit test for constructor of class Conditional
def test_Conditional():
    # Create a made-up class which has a conditional attribute. Create
    # a new instance of it, then evalutate the conditional in a dictionary
    # of variables.
    class ConditionalTester:

        _when = FieldAttribute(isa='list', default=list, extend=True, prepend=True)

        def __init__(self, loader=None, variable_manager=None, loader_basedir=None):
            self.name = 'Conditional Tester'
            self._loader = loader
            self._variable_manager = variable_manager
            self._loader_basedir = loader_basedir
            self._when = [ 'testing' ]

    condit = ConditionalTester()

    # Create a Tempalr object so we have a class which knows how
    # to evaluate a conditional

# Generated at 2022-06-21 00:23:43.144660
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.play_context import PlayContext

    conditional = Conditional()
    assert conditional.extract_defined_undefined(None) == []
    assert conditional.extract_defined_undefined(conditional) == []
    assert conditional.extract_defined_undefined("") == []
    assert conditional.extract_defined_undefined("foo") == []
    assert conditional.extract_defined_undefined("True") == []
    assert conditional.extract_defined_undefined("False") == []
    assert conditional.extract_defined_undefined("hostvars") == []
    assert conditional.extract_defined_undefined("hostvars is") == []
    assert conditional.extract_defined_undefined("hostvars is defined") == [('hostvars', 'is', 'defined')]
    assert conditional

# Generated at 2022-06-21 00:23:44.332836
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional is not None

# Generated at 2022-06-21 00:23:55.851318
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.block import Block
    conditional = Conditional()
    block = Block(loader=None, parent=None)
    block.when = [
        'defined_var',
    ]
    r = conditional.extract_defined_undefined(block.when[0])
    assert r == [('defined_var', 'is', 'defined')]

    block.when = [
        'defined_var.index(value_to_find)',
    ]
    r = conditional.extract_defined_undefined(block.when[0])
    assert r == [('defined_var', 'is', 'defined')]

    block.when = [
        'defined_var != undefined_var',
    ]
    r = conditional.extract_defined_undefined(block.when[0])

# Generated at 2022-06-21 00:24:05.356903
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    class TestConditional(Conditional):
        def __init__(self, loader=None):
            self._loader = loader
            self.when = ["not hostvars['testhost.example.com'].foo is defined and hostvars['testhost.example.com'].foo is undefined"]
            super(TestConditional, self).__init__(loader)

    class TestYamlObject(AnsibleBaseYAMLObject):
        yaml_loader = None
        yaml_tag = u'!test_yaml_obj'

        @staticmethod
        def to_yaml(self, representer, node):
            return representer.represent_data(node.value)


# Generated at 2022-06-21 00:24:16.388664
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert Conditional().extract_defined_undefined(u"false") == []
    assert Conditional().extract_defined_undefined(u"some_var.some_member is defined") == [('some_var.some_member', 'is', 'defined')]
    assert Conditional().extract_defined_undefined(u"some_var is defined and some_var2 is defined and some_var3 is undefined") == [('some_var', 'is', 'defined'), ('some_var2', 'is', 'defined'), ('some_var3', 'is', 'undefined')]

# Generated at 2022-06-21 00:24:26.493669
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    ds = {
            'name': "test",
            'when': [
                'a == 5',
                'b == 6'
            ]
    }

    c = Conditional()
    c.name = ds['name']
    c.when = ds['when']
    c._loader = DataLoader()
    t = Templar(c._loader)
    vars = dict(a=5, b=6, c=7)

    assert c.evaluate_conditional(t, vars)
    vars = dict(a=4, b=6, c=7)

    assert not c.evaluate_conditional(t, vars)


# Generated at 2022-06-21 00:24:32.422610
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    print('TEST EXTRACT DEFINED UNDEFINED')
    cond1 = '\'one\' is defined'
    cond2 = '\'one\' is not undefined and hostvars[\'one\']'
    cond3 = 'one is not undefined and hostvars[\'one\']'
    cond4 = 'hostvars[\'one\'] is not undefined'
    cond5 = '\'one\' is not undefined or \'two\' is not undefined'
    cond6 = 'not \'one\' is undefined or \'two\' is undefined'
    cond7 = 'not \'one\' is undefined or \'two\' is undefined and \'two\' is defined'
    cond8 = 'not \'one\' is undefined or \'two\' is undefined and \'two\' is not defined'


# Generated at 2022-06-21 00:24:43.905910
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    all_tests_passed = True

    c = Conditional()


# Generated at 2022-06-21 00:24:50.312632
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader

    class TestConditional(Conditional):
        pass

    # test error handling when no loader is specified
    try:
        TestConditional()
    except AnsibleError as ae:
        assert 'a loader must be specified when using Conditional() directly' in to_text(ae)
    else:
        raise Exception('an exception should have been raised!')

    # test error handling when invalid loader is specified
    try:
        TestConditional('invalid loader')
    except AnsibleError as ae:
        assert 'a loader must be specified when using Conditional() directly' in to_text(ae)
    else:
        raise Exception('an exception should have been raised!')

    # test successful instantiation
    loader = DataLoader()
    tc = TestConditional(loader)

# Generated at 2022-06-21 00:24:53.504059
# Unit test for constructor of class Conditional
def test_Conditional():
    C = Conditional(loader=None)
    assert isinstance(C, Conditional)


# Generated at 2022-06-21 00:25:22.850913
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestConditional(Conditional):
        def __init__(self, loader, when=None):
            self._loader = loader
            self.when = when

    # normalize for Python 2/3 differences
    try:
        basestring
    except NameError:
        basestring = str

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    ds = dict(
        when=None
    )

    loader = DataLoader()

    templar = Templar(loader)


# Generated at 2022-06-21 00:25:33.404898
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Unit test for method evaluate_conditional of class Conditional
    '''
    c = Conditional()

    # when = True must return True
    c.when = True
    assert c.evaluate_conditional(None, None) is True
    c.when = [True]
    assert c.evaluate_conditional(None, None) is True

    # when = False must return False
    c.when = False
    assert c.evaluate_conditional(None, None) is False
    c.when = [False]
    assert c.evaluate_conditional(None, None) is False

    # when = "good_var == 1" must return True when condition is true
    c.when = "good_var == 1"
    assert c.evaluate_conditional(None, dict(good_var=1)) is True
    c

# Generated at 2022-06-21 00:25:40.310790
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

# Generated at 2022-06-21 00:25:51.841473
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager

    def _create_play_context(connection, additional_vars):
        inventory = InventoryManager('', loader=load)
        vars = VariableManager(loader=load, inventory=inventory)
        for key, value in additional_vars.items():
            vars.set_variable(key, value)
        pc = PlayContext()
        pc.vars = vars
        pc.connection = connection
        return pc

    def setup(hostvars, additional_vars):
        load = DataLoader()

# Generated at 2022-06-21 00:25:53.472447
# Unit test for constructor of class Conditional
def test_Conditional():
    assert Conditional('loader')

# Generated at 2022-06-21 00:25:54.259096
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert getattr(conditional, 'when') == list()



# Generated at 2022-06-21 00:26:01.110424
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    # test a condition which does not contain a defined/undefined test
    c = Conditional()
    assert c.extract_defined_undefined("bla bla is not foo") == []

    # test a condition which contains a single defined/undefined test
    c = Conditional()
    assert c.extract_defined_undefined("bla bla is not defined") == [('bla bla', 'is not', 'defined')]

    # test a condition which contains multiple defined/undefined tests
    c = Conditional()
    assert c.extract_defined_undefined("bla bla is not defined or foo is defined") == [('bla bla', 'is not', 'defined'), ('foo', 'is', 'defined')]



# Generated at 2022-06-21 00:26:11.914670
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # set up some test objects
    class TestModule(object):
        def __init__(self):
            self._ds = dict(name=u'test_module')
            self._parent = dict(name=u'test_play')
            self.name = u'test_module'
        def _load_name(self):
            pass
    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars import VariableManager
    class TestPlay(Play):
        def __init__(self):
            self.variable_manager = VariableManager()
            self.name = u'test_play'
    class TestTask(Task):
        def __init__(self):
            self._ds = dict(name=u'test_task')
            self

# Generated at 2022-06-21 00:26:21.836615
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    templar = DummyTemplar()
    all_vars = DummyVars()
    conditional = Conditional()

    templar.template = lambda x, disable_lookups=False: x

    # test with conditionals
    conditional.when = ["hostvars[inventory_hostname].osvar != ''", "foo is defined", "bar is not defined"]

    res = conditional.evaluate_conditional(templar, all_vars)
    assert res == True

    conditional.when = ["", "foo is defined"]
    res = conditional.evaluate_conditional(templar, all_vars)
    assert res == True

    conditional.when = ["foo is defined", "bar is defined"]

# Generated at 2022-06-21 00:26:24.399901
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()
    cond = Conditional(loader=loader)
    assert cond is not None

# Generated at 2022-06-21 00:27:12.612446
# Unit test for constructor of class Conditional
def test_Conditional():
    assert hasattr(Conditional, '_when')
    assert hasattr(Conditional, '_loader')
    assert hasattr(Conditional, 'evaluate_conditional')


# Generated at 2022-06-21 00:27:16.580547
# Unit test for constructor of class Conditional
def test_Conditional():
    # test initialization of conditional object
    conditional = Conditional()
    assert isinstance(conditional, Conditional), 'conditional is not type Conditional'

    # test that when attribute is being properly initialized
    assert isinstance(conditional._when, list), 'when is not type list'

    # test that validate when works as expected
    conditional._validate_when(None, '_when', ['foo'])
    assert conditional._when == ['foo'], '_validate_when did not properly set the when attribute'


# Generated at 2022-06-21 00:27:25.377151
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    templar = DummyTemplar()
    cond = Conditional(DummyLoader())

    # Test for a boolean True
    assert True == cond.evaluate_conditional(templar, dict())

    # Test for a boolean False
    cond._ds = dict(when=False)
    assert False == cond.evaluate_conditional(templar, dict())

    # Test for a stringified boolean True
    cond._ds = dict(when='True')
    assert True == cond.evaluate_conditional(templar, dict())

    # Test for a stringified boolean False
    cond._ds = dict(when='False')
    assert False == cond.evaluate_conditional(templar, dict())

    # Test for an empty string
    cond._ds = dict(when='')

# Generated at 2022-06-21 00:27:37.544296
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import tempfile
    import shutil
    import ansible.constants
    import ansible.plugins
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    ansible.constants.HOST_KEY_CHECKING = False
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-21 00:27:46.354479
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    import pytest
    con = Conditional()
    test_cases = [("foo not is defined", [("foo", "not is", "defined")]),
                  ("foo is undefined", [('foo', "is", "undefined")]),
                  ("foo is defined and bar is undefined", [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]),
                  ('"foo" is defined', [('foo', 'is', 'defined')]),
                  ('"foo" not is defined', [('foo', 'not is', 'defined')]),
                  ('foo is defined or "bar" not is undefined', [('foo', 'is', 'defined'), ('bar', 'not is', 'undefined')])]

# Generated at 2022-06-21 00:27:55.828426
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-21 00:28:06.326376
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestConditionalClass(Conditional):
        def __init__(self, loader=None):
            super(TestConditionalClass, self).__init__(loader=loader)

    import unittest
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    cond = TestConditionalClass(loader=loader)
    templar = Templar(loader=loader, variables={})
    context = PlayContext()
    context._vars_per_host = {
        'hostvars': {
            'host1': {'result': False},
            'host2': {'result': True}
        }
    }

    # Test when is null
    _when = None
    assert cond._

# Generated at 2022-06-21 00:28:14.139328
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from jinja2 import Environment, StrictUndefined
    j2_env = Environment(undefined=StrictUndefined)
    from jinja2.sandbox import SandboxedEnvironment
    j2_env = SandboxedEnvironment(variable_start_string="{", variable_end_string="}", undefined=StrictUndefined)
    from ansible.parsing.dataloader import DataLoader

    from ansible.playbook.task import Task

    my_task = Task()
    my_task.when = ["{{ foo is defined and bar is defined }}",
                    "{{ foo == bar }}",
                    "{{ 'a' in 'abc'}}"]

    loader = DataLoader()
    my_task._loader = loader

    templar = loader.load_basedir("/tmp/ansible")
    templar._

# Generated at 2022-06-21 00:28:23.739506
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    ''' test_conditional_evaluate_conditional.py

    Demonstrates the usage and operation of the method Conditional.evaluate_conditional().

    :platform: Linux
    :author: Alan Rominger <arominger@redhat.com>
    '''


# Generated at 2022-06-21 00:28:33.239296
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # test case 1
    test_case = dict(
        cond = dict(
            all_vars = dict(
                a = 'a',
                b = 'b'
            ),
            class_obj = dict(
                when = ['a and b', 'c'],
                _loader = dict(
                    get_basedir = lambda x: x,
                    path_dwim = lambda x: x,
                    get_real_file = lambda x: x,
                    file_exists = lambda x: True,
                    is_file = lambda x: True
                )
            )
        ),
        expected = True
    )
    class_obj = Conditional()
    for attr, val in test_case['cond']['class_obj'].items():
        setattr(class_obj, attr, val)

    tem

# Generated at 2022-06-21 00:30:29.957373
# Unit test for constructor of class Conditional
def test_Conditional():
    '''
    Unit test for constructor of class Conditional
    '''
    from ansible.playbook.base import Base
    from ansible.parsing.dataloader import DataLoader

    class TestClass(Base, Conditional):
        def __init__(self, loader=None):
            super(TestClass, self).__init__()

    # no loader
    try:
        cond = Conditional()
    except AnsibleError:
        pass
    else:
        raise AssertionError("Failed to raise AnsibleError when no loader is given to Conditional() constructor")

    # loader
    loader = DataLoader()
    test_obj = TestClass(loader=loader)
    assert test_obj._loader is loader

    # test setting a when condition
    test_obj.when = []

# Generated at 2022-06-21 00:30:38.275919
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    pc = PlayContext()
    vc = VariableManager()
    c = Conditional(loader=vc)
    c.when = 'foo'
    c._validate_when(FieldAttribute, 'when', 'foo')

# Generated at 2022-06-21 00:30:40.383839
# Unit test for constructor of class Conditional
def test_Conditional():
    class test():
        __metaclass__ = Conditional

    assert test



# Generated at 2022-06-21 00:30:52.829867
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    def _setup_conditional_test(conditional, templar, all_vars, loader=None):
        obj = Conditional(loader)
        obj.when = conditional
        return obj.evaluate_conditional(templar, all_vars)

    from ansible.playbook import Play
    from ansible.template import Templar
    from ansible.parsing.yaml import DataLoader

    def _mock_getval(name, variable_manager=None, templar=None, all_vars=None):
        if variable_manager is None:
            variable_manager = variable_manager_mock
        if templar is None:
            templar = templar_mock
        if all_vars is None:
            all_vars = all_vars_mock


# Generated at 2022-06-21 00:31:02.466188
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test data
    ###########################################################################
    all_vars = dict(
        a = 1,
        b = False,
        c = True,
        d = 'a',
        e = dict(a = 0),
        f = [1,2,3],
        g = 'present',
        h = '',
        i = None,
        j = 0,
    )
    # For the below templates, meaning is as per Jinja2 documentation
    # https://jinja.palletsprojects.com/en/2.10.x/templates/#list-of-control-structures

# Generated at 2022-06-21 00:31:05.436685
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c._when == c.when
    assert c.when == []


# Generated at 2022-06-21 00:31:08.987502
# Unit test for constructor of class Conditional
def test_Conditional():
    class c(Conditional):
        def __init__(self, loader):
            super(c, self).__init__(loader)
    c(True)


# Generated at 2022-06-21 00:31:21.118493
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    inv_data_str = """
[testgroup1]
good1
bad1
bad2

[testgroup2]
good2
bad3
bad4
"""
    inv_str = InventoryManager(loader=DataLoader(), sources=inv_data_str)

    inv_data = inv_str.get_hosts()


# Generated at 2022-06-21 00:31:31.516177
# Unit test for constructor of class Conditional
def test_Conditional():
    import ansible.constants as C
    from ansible.playbook.attribute import FieldAttribute
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    # Create a dummy class that inherits from Base and Conditional and add a 'when'
    # attribute.
    class Dummy(Base, Conditional):
        _when = FieldAttribute(isa='list', default=list, extend=True, prepend=True)

    # Check that the when attribute works properly and is properly validated.
    #
    # In general, properties don't play nice with `super` so we have to set the
    # underlying attribute directly before running the test.
    d = Dummy()
    d._when = 'foo'
    assert d.when

# Generated at 2022-06-21 00:31:39.038102
# Unit test for constructor of class Conditional
def test_Conditional():
    # Test the constructor of Conditional.
    #
    # It should raise AnsibleError when loader is not provided.
    try:
        Conditional()
        assert False, 'Should have raised an exception'
    except AnsibleError:
        pass

    # This should not raise an exception.
    c = Conditional(loader=object())
    return c
