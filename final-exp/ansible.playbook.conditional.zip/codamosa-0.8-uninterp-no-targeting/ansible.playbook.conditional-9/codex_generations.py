

# Generated at 2022-06-21 00:21:59.227495
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    assert False, "No test implemented"

# Generated at 2022-06-21 00:22:09.613729
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task_include import TaskInclude

    loader = DataLoader()
    vars_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    display = Display()
    templar = Templar(loader=loader, variables=vars_manager, shared_loader_obj=False)

    # test with empty list
    ti = TaskInclude()
    ti._when = []
    assert ti.evaluate_conditional(templar, variable_manager) == True

    # test single true conditionals
    ti = TaskInclude

# Generated at 2022-06-21 00:22:21.557319
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    (var1, logic1, state1) = c.extract_defined_undefined("(hostvars[inventory_hostname] is defined) or (hostvars[inventory_hostname] is not defined)")[0] # nosec
    (var2, logic2, state2) = c.extract_defined_undefined("(hostvars[inventory_hostname] is not defined) or (hostvars[inventory_hostname] is defined)")[0] # nosec
    (var3, logic3, state3) = c.extract_defined_undefined("((hostvars[inventory_hostname] is not defined) or (hostvars['other_hostname'] is defined)) and (hostvars[inventory_hostname] is undefined)")[2] # nosec

# Generated at 2022-06-21 00:22:31.814928
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import copy

    c = Conditional()

    all_vars = copy.deepcopy(C.DEFAULT_VAULT_ID_MATCH)
    all_vars.update(C.DEFAULT_SYSTEM_DATE_FORMAT)
    all_vars.update(C.DEFAULT_SYSTEM_TIME_FORMAT)
    all_vars.update(C.DEFAULT_DEBUG)
    all_vars.update({"foo": "bar", "blah": "blah_value", "ansible_os_family": "RedHat"})

    # check for boolean values
    assert(c.evaluate_conditional(c._loader.loaders[0], all_vars) is True)
    c.when = False

# Generated at 2022-06-21 00:22:42.516024
# Unit test for constructor of class Conditional
def test_Conditional():
    display.warning = lambda x: x

# Generated at 2022-06-21 00:22:52.858359
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = 'hostvars[inventory_hostname] == "1" or hostvars[inventory_hostname] == "2" or hostvars[inventory_hostname] == "3" and hostvars[inventory_hostname] is undefined'
    c = Conditional()
    assert c.extract_defined_undefined(conditional) == [
        ('hostvars[inventory_hostname]', '==', '1'),
        ('hostvars[inventory_hostname]', '==', '2'),
        ('hostvars[inventory_hostname]', '==', '3'),
        ('hostvars[inventory_hostname]', 'is', 'undefined')
    ]



# Generated at 2022-06-21 00:22:59.651293
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    import jinja2
    import yaml

    # initialize basic objects
    context = PlayContext()
    loader = jinja2.DictLoader({})

    # initialize templar with loader and context
    templar = Templar(loader=loader, variables={}, context=context)

    # this is the when statement to test
    when_statement = '"{{lookup(\'pipe\', \'echo ABC\')}}" == "abc"'

    # build a basic task for testing
    task_dict = dict(
        name='test task',
        action='action name',
        when=when_statement
    )

    # initialize the object
    conditional = Conditional(loader=loader)

# Generated at 2022-06-21 00:23:10.723740
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    if cond.extract_defined_undefined("") != []:
        raise Exception("error testing simple_conditional.extract_defined_undefined")
    if cond.extract_defined_undefined("foo") != []:
        raise Exception("error testing simple_conditional.extract_defined_undefined")
    if cond.extract_defined_undefined("foo is bar") != []:
        raise Exception("error testing simple_conditional.extract_defined_undefined")
    if cond.extract_defined_undefined("foo is defined") != [("foo", "is", "defined")]:
        raise Exception("error testing simple_conditional.extract_defined_undefined")

# Generated at 2022-06-21 00:23:20.744053
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Prepare
    cond = Conditional()
    # Pre-condition
    assert(cond is not None)
    # Execute & Assert
    assert(len(cond.extract_defined_undefined('ansible_os_family is defined')) > 0)
    assert(len(cond.extract_defined_undefined('ansible_os_family is not undefined')) > 0)
    assert(len(cond.extract_defined_undefined('ansible_os_family not is undefined')) > 0)
    assert(len(cond.extract_defined_undefined('ansible_os_family is defined and ansible_facts["virtualization_type"] == "xen"')) > 0)

# Generated at 2022-06-21 00:23:23.035046
# Unit test for constructor of class Conditional
def test_Conditional():
    # pylint: disable=unused-variable
    conditional = Conditional()



# Generated at 2022-06-21 00:23:31.261134
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional(loader=None)
    return conditional

# Generated at 2022-06-21 00:23:41.257547
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.base import Base
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = AnsibleLoader(None, None, None)

    # target is used as a mock object of task
    class TestTask(Conditional, Base):
        pass

    # Test data used in test case (test_data)
    test_data = AnsibleMapping()
    test_data.yaml_set_attr('test_defined', 'result', 'yes')

# Generated at 2022-06-21 00:23:47.601267
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    objConditional = Conditional()
    strTemp = "hostvars['firstHost'] is defined or hostvars['secondHost'] is not defined"
    listResult = objConditional.extract_defined_undefined(strTemp)
    assert len(listResult) == 2
    assert listResult[0] == ("hostvars['firstHost']", "is", "defined")
    assert listResult[1] == ("hostvars['secondHost']", "is not", "defined")



# Generated at 2022-06-21 00:23:48.605315
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c

# Generated at 2022-06-21 00:23:56.884739
# Unit test for constructor of class Conditional
def test_Conditional():
    """
    This test will check how class Conditional behaves if we try to create instance of it directly
    """
    def _test():
        """
        Create instance of Conditional class directly
        """
        return Conditional()

    # As per the code, if we create instance of Conditional class directly, we should get error
    # as it takes a loader which is passed to its constructor but not received in constructor
    # of this class.
    import pytest
    with pytest.raises(AnsibleError):
        _test()

# Generated at 2022-06-21 00:23:58.301349
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert isinstance(conditional._when, list)

# Generated at 2022-06-21 00:24:06.983588
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('a is defined') == []
    assert c.extract_defined_undefined('a is NOT defined') == []
    assert c.extract_defined_undefined('a is defined or b is undefined') == [['a', 'is', 'defined'], ['b', 'is', 'undefined']]
    assert c.extract_defined_undefined('not a is defined or b is undefined') == [['a', 'is', 'defined'], ['b', 'is', 'undefined']]
    assert c.extract_defined_undefined('not (a is defined or b is undefined)') == [['a', 'is', 'defined'], ['b', 'is', 'undefined']]

# Generated at 2022-06-21 00:24:18.176491
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c1 = Conditional()
    c1_result = c1.extract_defined_undefined("foo is defined")
    assert c1_result == [('foo', 'is', 'defined')]

    c2 = Conditional()
    c2_result = c2.extract_defined_undefined("foo is not defined or bar is defined")
    assert c2_result == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

    c3 = Conditional()
    c3_result = c3.extract_defined_undefined("foo is undefined or bar is undefined")
    assert c3_result == [('foo', 'is', 'undefined'), ('bar', 'is', 'undefined')]

    c4 = Conditional()
    c4_result = c4.extract_defined_und

# Generated at 2022-06-21 00:24:28.263985
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    import ansible.vars.hostvars

    # The test cases are provided as a list of tuples. Each tuple has following elements:
    # 1. A list of when to test.
    # 2. A dictionary of variables to be used by Jinja2 templating.
    # 3. The expected result of evaluate_conditional.

# Generated at 2022-06-21 00:24:39.309750
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("hostvars[inventory_hostname] == 'server01'") == []
    assert c.extract_defined_undefined("hostvars[inventory_hostname] is defined") == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert c.extract_defined_undefined("hostvars['s3://foo/bar.py'] is undefined") == [("hostvars['s3://foo/bar.py']", 'is', 'undefined')]
    assert c.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]


# Generated at 2022-06-21 00:24:58.080231
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.base import Base
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.playbook.task import Task

    dummy_loader = DataLoader()
    dummy_inventory = InventoryManager(loader=dummy_loader, sources='localhost,')
    variable_manager = VariableManager(loader=dummy_loader, inventory=dummy_inventory)


# Generated at 2022-06-21 00:25:09.375053
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def_undef = Conditional()
    # test 'hostvars[inventory_hostname]'
    test_string = 'var1 is defined and hostvars[inventory_hostname] is undefined'
    def_undef_list = def_undef.extract_defined_undefined(test_string)
    assert len(def_undef_list) == 2
    assert isinstance(def_undef_list[0][0], str)
    assert isinstance(def_undef_list[0][1], str)
    assert isinstance(def_undef_list[0][2], str)
    assert def_undef_list[0][0] == 'var1'
    assert def_undef_list[0][1] == 'is'
    assert def_undef_list[0][2] == 'defined'

# Generated at 2022-06-21 00:25:16.303142
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest
    import ansible.playbook.base

    class TestPlaybookBase(ansible.playbook.base.Base, Conditional):
        pass

    class TestConditional(unittest.TestCase):

        def test_evaluate_conditional(self):
            pb_base = TestPlaybookBase()

            # test bare string
            pb_base.when = ["condition_string"]
            self.assertFalse(pb_base.evaluate_conditional(pb_base.accelerate, dict(condition_string=False)))
            self.assertTrue(pb_base.evaluate_conditional(pb_base.accelerate, dict(condition_string=True)))

            # test bare

# Generated at 2022-06-21 00:25:27.688490
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar

    class TestModule(object):

        def __init__(self):
            self.fail_json = lambda **kwargs: None

    module_args = dict()
    module_args['use_syslog'] = None
    module_args['no_log'] = None

    templar = Templar(loader=None, variables=module_args, shared_loader_obj=None)
    test_module = TestModule()
    test_module.args = module_args

    # We are going to test 4 conditionals, the expected result is always true
    conditional_test = [
        'True',
        'False is not True',
        '{{ 1 + 1 == 2 }}',
        '{{ 1 + 1 == 2 }} and not {{ 1 + 1 != 2 }}'
    ]

    test_obj = Conditional()

# Generated at 2022-06-21 00:25:32.739541
# Unit test for constructor of class Conditional
def test_Conditional():
    display = Display()
    display.verbosity = 3
    cond = Conditional('fake_loader')

    my_display = Display()
    my_display.verbosity = 3
    cond.display = my_display
    cond._ds = 'fake_ds object'
    cond.when = 'fake_when'



# Generated at 2022-06-21 00:25:39.966750
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    test = Conditional()
    assert test.extract_defined_undefined("{{ foo is undefined or foo == '' }}") == [("foo", "is", "undefined")]
    assert test.extract_defined_undefined("{{ (foo is undefined or foo == '') and bar is defined }}") == [("foo", "is", "undefined"), ("bar", "is", "defined")]
    assert test.extract_defined_undefined("{{ foo == 'session' or bar is defined }}") == [("bar", "is", "defined")]
    assert test.extract_defined_undefined("{{ foo is undefined and bar is defined }}") == [("foo", "is", "undefined"), ("bar", "is", "defined")]
    assert test.extract_defined_undefined("{{ foo is not defined and bar is defined }}")

# Generated at 2022-06-21 00:25:51.502675
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.playbook import Playbook

    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.become import Become
    from ansible.playbook.role.task import Task as RoleTask
    from ansible.playbook.play_context import PlayContext
    from units.mock.loader import DictDataLoader
    from units.mock import mock_tqm

    loader = DictDataLoader({})
    variable

# Generated at 2022-06-21 00:25:54.998768
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader

    c = Conditional(loader=DataLoader())
    c._loader.set_basedir('/path/to/foo')
    assert c != None
    assert c._loader != None

# Generated at 2022-06-21 00:26:07.252838
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    class DummyPlaybook:
        def __init__(self):
            self.loader = DummyLoader()
            self.variable_manager = DummyVariableManager()
            self.become_method = None

    class DummyLoader:
        def get_basedir(self):
            return '.'

    class DummyVariableManager:
        def get_vars(self):
            return {}

    pb = DummyPlaybook()
    play_context = PlayContext()
    templar = Templar(loader=pb.loader, variables=pb.variable_manager.get_vars(), play_context=play_context)
    conditional = Conditional(loader=pb.loader)

# Generated at 2022-06-21 00:26:09.232178
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c is not None
    assert c._when == []
    assert c.when == []
    assert repr(c) == "<ansible.builtin.Conditional (when=[])>"



# Generated at 2022-06-21 00:26:24.610635
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Dummy object that needs a loader to pass a test
    class DummyObject(object):
        _loader = None

    # Test case 1: when is None
    t_cond = None
    t_templar = None
    t_all_vars = None

    t_object = Conditional()
    t_type = type(t_object)
    t_type.when = [ t_cond ]
    t_object.when = [ t_cond ]
    t_result = t_type.evaluate_conditional(t_object, t_templar, t_all_vars)
    assert t_result == True

    # Test case 2: when is an empty list
    t_cond = []
    t_templar = None
    t_all_vars = None

    t_object = DummyObject()

# Generated at 2022-06-21 00:26:34.791019
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DummyLoader()
    pc = DummyPlayContext()
    templar = Templar(loader=loader, variables={'foo': 'bar'})

    # test with underscores
    c = Conditional()
    c._when = [dict(a='a', b='b')]
    try:
        c._validate_when('_when', '_when', c._when)
    except Exception as e:
        raise AssertionError('conditional task validation failed')

    # test with dashes
    c = Conditional()
    c.when = [dict(a='a', b='b')]

# Generated at 2022-06-21 00:26:41.207010
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    myPlay = Play().load({}, variable_manager=variable_manager, loader=loader)
    assert isinstance(myPlay, Conditional)

# Generated at 2022-06-21 00:26:42.560887
# Unit test for constructor of class Conditional
def test_Conditional():
    y = Conditional()
    assert y._when == []


# Generated at 2022-06-21 00:26:46.011323
# Unit test for constructor of class Conditional
def test_Conditional():
    def TestConditional(Conditional):
        _when = FieldAttribute(isa='list', default=list, extend=True, prepend=True)

    conditional = TestConditional()
    assert not conditional._when
    assert conditional._attributes['_when']
    assert conditional._attributes['_when'].data == []
    assert conditional._attributes['_when'].field_class == list



# Generated at 2022-06-21 00:26:52.112053
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    import os

    from collections import namedtuple

    fake_loader = namedtuple('fake_loader', ('path_exists'))

    class TestConditional(Base, Conditional):
        pass

    b_path = '/etc/ansible/roles/role1/tasks'
    c_path = '/etc/ansible/roles/role1/tasks' + os.sep

    # Test 1 - Positive Test
    #  test if evaluate_conditional method evaluate the conditions correctly.
    t = TestConditional()
    t.when = "test1 == 1"
    # magicmock the functions
    t._get_task_ds = lambda x: x
    t._fl

# Generated at 2022-06-21 00:27:01.518489
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class MyConditional(Conditional):
        when = [ 'foo', 'bar' ]

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_inventory(None)
    variable_manager._extra_vars = { 'foo': True, 'bar': True, 'unknown_var': True }
    templar = Templar(loader=None, variables=variable_manager)

    c = MyConditional()
    assert c.evaluate_conditional(templar, variable_manager.get_vars(loader=None, play=None)) == True

    c.when[0] = 'unknown_var'
    assert c.evaluate_conditional(templar, variable_manager.get_vars(loader=None, play=None)) == False

# Generated at 2022-06-21 00:27:09.820090
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.template import Templar
    from ansible.playbook.task import Task
    import pytest

    for test_input in [
        'foo is defined and bar is not undefined and foobar is defined',
        'not (foo is defined) and bar is not undefined',
        'hostvars["foo"] is not defined and hostvars["bar"] is defined'
    ]:
        t = Task()
        result = t.extract_defined_undefined(test_input)
        assert result == [('foo', 'is', 'defined'), ('bar', 'is not', 'undefined'), ('foobar', 'is', 'defined')]
    # Validates if input is None
    t = Task()
    assert t.extract_defined_undefined(None) == []


# Tests for method evaluate_conditional of class Conditional


# Generated at 2022-06-21 00:27:12.487773
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.base import Base

    class TestConditional(Base):

        def __init__(self, loader=None):
            super(TestConditional, self).__init__()

    o = TestConditional()
    assert o._when == []


# Generated at 2022-06-21 00:27:18.382469
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Init variables, objects and classes for testing
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=None)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = variable_manager.get_vars_templar()
    test_object = Conditional(loader)

    # Init test variables
    all_vars = dict(
        yum_repository=dict(
            test_repo=dict(
                file='test_repo.repo',
                name='test_repo',
                description='test_repo',
            )
        )
    )

    # Test

# Generated at 2022-06-21 00:27:44.183884
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.base import Base

    class Dummy(Conditional, Base):
        pass

    # set up a dummy configuration class
    class DummyConfig(object):
        pass

    config = DummyConfig()
    config.j2_native = True

    d = Dummy(loader=None, variable_manager=None, config=config)

    # test basic string and numeric values
    assert d._check_conditional('a == "foobar"', None, None) == False
    assert d._check_conditional('a != "foobar"', None, None) == True
    assert d._check_conditional('a < "foobar"', None, None) == True
    assert d._check_conditional('a > "foobar"', None, None) == False

# Generated at 2022-06-21 00:27:53.315166
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-21 00:28:03.717657
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]

    assert conditional.extract_defined_undefined("bar is undefined or foo") == [('bar', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("bar is defined and foo") == [('bar', 'is', 'defined')]
    assert conditional.extract_

# Generated at 2022-06-21 00:28:12.381923
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('hostvars[hostname] is undefined') == [('hostvars[hostname]', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('hostvars[hostname] is defined') == [('hostvars[hostname]', 'is', 'defined')]
    assert conditional.extract_defined_undefined('hostvars[hostname] not is defined') == [('hostvars[hostname]', 'not is', 'defined')]
    assert conditional.extract_defined_undefined('hostvars[hostname] is not defined') == [('hostvars[hostname]', 'is not', 'defined')]

# Generated at 2022-06-21 00:28:20.033528
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    used by:
      - test/units/playbook/test_attribute_handling.py
    '''

    from ansible.playbook.task import Task

    t = Task()
    t.when = ["myvar1 is defined and myvar2 is defined and myvar1 == 'foo' and myvar2 == 'bar'", "myvar3 is undefined"]
    assert t.evaluate_conditional(None, dict(myvar1='foo', myvar2='bar')) is True
    assert t.evaluate_conditional(None, dict(myvar1='foo', myvar2='bar', myvar3='baz')) is False
    assert t.evaluate_conditional(None, dict(myvar1='foo', myvar2='baz')) is False

# Generated at 2022-06-21 00:28:21.793896
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional(loader=None)
    assert conditional is not None


# Generated at 2022-06-21 00:28:27.770649
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    c = Conditional()
    assert c._when == []

    # test the default
    c = Conditional()
    assert c.when is c._when

    # test setting the value
    c = Conditional()
    c.when = ['name:foo', True]
    assert c.when == ['name:foo', True]
    assert c._when == ['name:foo', True]

    # test mixing in with a playbook base class
    class MyClass:
        def __init__(self, when=None):
            self._when = when or []
    myclass = MyClass()
    myclass.__class__ = type('myclass', (Conditional, MyClass), {})

# Generated at 2022-06-21 00:28:37.556871
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext

    pc = PlayContext()

    class TestConditional(Conditional):
        def __init__(self, data):
            super(TestConditional, self).__init__()
            self._ds = data
            self._loader = None

        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()
            return self.evaluate_conditional(self._templar, task_vars)

    # always true
    tc = TestConditional({'when': True})
    assert tc.run(task_vars=dict()) is True

    # always false
    tc = TestConditional({'when': False})
    assert tc.run(task_vars=dict()) is False

    #

# Generated at 2022-06-21 00:28:46.798549
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.base import Base
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    class Test(Base, Conditional):
        pass

    t = Test()
    assert t._validate_when('foo', 'name', 'bar') == None
    assert t._validate_when(['foo'], 'name', 'bar') == None
    with pytest.raises(TypeError):
        t._validate_when(1, 'name', 'bar')
    with pytest.raises(TypeError):
        t._validate_when('foo', 'name', 1)

    setattr(t, '_loader', 'loader')

    assert t.evaluate_conditional(None, None) == True
    t.when = 'foo'

# Generated at 2022-06-21 00:28:53.266238
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """
    Test evaluate_conditional method
    """
    cond1 = Conditional()
    cond1.when = [ 'test1', 'test2', 'test3' ]

    cond2 = Conditional()
    cond2.when = [ None, '', False ]

    cond3 = Conditional()
    cond3.when = [ True, True, True ]

    cond4 = Conditional()
    cond4.when = [ True, False, True ]

    cond5 = Conditional()
    cond5.when = [ 'var1 is defined', 'var2 is undefined', 'var3 is defined' ]

    cond6 = Conditional()
    cond6.when = [ 'var1 is defined', 'var2 is undefined' ]

    cond7 = Conditional()

# Generated at 2022-06-21 00:29:44.259047
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert extract_defined_undefined('a is defined') == [('a', 'is', 'defined')]
    assert extract_defined_undefined('a is undefined') == [('a', 'is', 'undefined')]
    assert extract_defined_undefined('a not is defined') == [('a', 'not is', 'defined')]
    assert extract_defined_undefined('a not is undefined') == [('a', 'not is', 'undefined')]
    assert extract_defined_undefined('a is defined or b is defined') == [('a', 'is', 'defined'), ('b', 'is', 'defined')]
    assert extract_defined_undefined('a is undefined and b is undefined') == [('a', 'is', 'undefined'), ('b', 'is', 'undefined')]

# Generated at 2022-06-21 00:29:46.243973
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_test = Conditional()
    assert conditional_test is not None


# Generated at 2022-06-21 00:29:57.726307
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Test evaluate_conditional method of class Conditional
    '''

    class TestConditional(Conditional):
        '''
        Test class for Conditional class
        '''
        def __init__(self):
            pass

    ##########################################################################
    #                                                                        #
    #              Test evaluate_conditional method of class Conditional     #
    #                                                                        #
    ##########################################################################
    # test for handle None, Empty string and boolean condition
    test_data = [
        (None, True, 'None'),
        ('', True, 'Empty String'),
        (True, True, ''),
        (False, False, '')
    ]

    for test in test_data:
        test = TestConditional()
        test._when = [test[0]]
        result = test.evaluate

# Generated at 2022-06-21 00:30:08.301348
# Unit test for constructor of class Conditional
def test_Conditional():
    """
        Conditional: return appropriate object
        when x is defined
        when: x is defined
        when x
        when: x

    """

    data = [
            "when x is defined",
            "when: x is defined",
            "when x",
            "when: x"
    ]

    for item in data:
        c = Conditional()
        c._validate_when("x is defined", "when", item)

        assert c.when == ["x is defined"], item

# Generated at 2022-06-21 00:30:20.883712
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template.template import Template

    mock_play_context = PlayContext()
    mock_templar = Template(play_context=mock_play_context)

    mock_task = Task()
    mock_task.when = "ansible_distribution == 'Fedora'"
    mock_task._load_vars(data=dict(ansible_distribution='Fedora'))

    test_conditional = Conditional()

    # Test positive condition
    result = test_conditional.evaluate_conditional(mock_templar, mock_task._task_vars)
    assert result == True

    # Test negative condition
    mock_task.when = "ansible_distribution == 'Ubuntu'"
    result = test_conditional.evaluate_conditional

# Generated at 2022-06-21 00:30:31.695491
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    # no variables tested at all
    assert c.extract_defined_undefined("") == []
    assert c.extract_defined_undefined("not defined") == []
    assert c.extract_defined_undefined("not is") == []
    assert c.extract_defined_undefined("not is not") == []
    assert c.extract_defined_undefined("not is defined") == []
    assert c.extract_defined_undefined("not is not defined") == []
    assert c.extract_defined_undefined("is defined") == []
    assert c.extract_defined_undefined("is not defined") == []
    assert c.extract_defined_undefined("is not") == []

    # one variable tested

# Generated at 2022-06-21 00:30:32.757038
# Unit test for constructor of class Conditional
def test_Conditional():
    a = Conditional(loader=None)
    assert isinstance(a, Conditional)


# Generated at 2022-06-21 00:30:38.513270
# Unit test for constructor of class Conditional
def test_Conditional():
    class Conditional_test(Conditional):
        def __init__(self):
            super(Conditional_test, self).__init__()

    conditional_test_obj = Conditional_test()
    
    assert conditional_test_obj._when == []
    return True


# Generated at 2022-06-21 00:30:45.541723
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    assert Conditional().extract_defined_undefined('var is defined') == [('var', 'is', 'defined')]
    assert Conditional().extract_defined_undefined('var is defined and bar is defined') == [('var', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-21 00:30:47.880692
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert isinstance(conditional, Conditional)