

# Generated at 2022-06-21 00:22:09.989847
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    C = Conditional()
    assert C.extract_defined_undefined('a is defined')[0][0] == 'a'
    assert C.extract_defined_undefined('a is defined')[0][1] == 'is'
    assert C.extract_defined_undefined('a is defined')[0][2] == 'defined'
    assert C.extract_defined_undefined('a is not defined')[0][0] == 'a'
    assert C.extract_defined_undefined('a is not defined')[0][1] == 'is not'
    assert C.extract_defined_undefined('a is not defined')[0][2] == 'defined'
    assert C.extract_defined_undefined('a is undefined')[0][0] == 'a'
    assert C.extract

# Generated at 2022-06-21 00:22:23.441232
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    class DummyTransformer(object):
        def __getitem__(self, key):
            raise AnsibleUndefinedVariable

    class DummyHost(object):
        def __init__(self):
            self.vars = DummyTransformer()

    class DummyModule(object):
        def __init__(self):
            self.params = {}
            self.host_vars = {}
            self.play_context = {}

    class DummyPlay(object):
        def __init__(self):
            self.vars = {}
            self.extra_vars

# Generated at 2022-06-21 00:22:27.966751
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.task import Task

    obj = Conditional()
    assert obj._when == []

    obj._when = 'some_string'
    assert obj._when == ['some_string']

    assert obj.evaluate_conditional(None, None) is True

    obj._when = [None, '']
    assert obj.evaluate_conditional(None, None) is True

    obj._when = [False, True]
    assert obj.evaluate_conditional(None, None) is False

    obj._when = [False, {}]
    assert obj.evaluate_conditional(None, None) is False

    obj._when = [True, {}]
    assert obj.evaluate_conditional(None, None) is True

    obj = Conditional()

# Generated at 2022-06-21 00:22:35.978683
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-21 00:22:37.638498
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional(loader=None)
    assert conditional is not None


# Generated at 2022-06-21 00:22:49.411253
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    test_conditional = Conditional()

    conditional = '{{ (foo is defined and bar is not undefined and baz == "xyz") or (qux is defined and quux == 42) }}'
    result = [('foo', 'is', 'defined'), ('bar', 'is not', 'undefined'), ('baz', '==', '"xyz"'), ('qux', 'is', 'defined'), ('quux', '==', '42')]
    assert result == test_conditional.extract_defined_undefined(conditional)

    conditional = '{{ (foo is defined and bar is not defined) or (qux is defined and quux == 42) }}'

# Generated at 2022-06-21 00:22:58.132250
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    c = Conditional()
    examples = {
        '1': [],
        '1 or 2': [],
        'a is defined': [('a', 'is', 'defined')],
        'b is undefined': [('b', 'is', 'undefined')],
        'c not is defined': [('c', 'not is', 'defined')],
        'd is not undefined': [('d', 'is not', 'undefined')],
        'e is defined and f is undefined': [('e', 'is', 'defined'), ('f', 'is', 'undefined')],
        'g is defined and h not is undefined': [('g', 'is', 'defined'), ('h', 'not is', 'undefined')]
    }

    for conditional, result in examples.items():
        assert result == c.extract_defined_undefined

# Generated at 2022-06-21 00:23:09.326324
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.task import Task

    t = Task()
    t._loader = DictDataLoader({})

    # test valid cases
    assert [("hostvars['foo']", 'is', 'defined')] == t.extract_defined_undefined("hostvars['foo'] is defined")
    assert [("bar", 'not is', 'undefined')] == t.extract_defined_undefined("bar not is undefined")
    assert [("baz", 'is not', 'defined')] == t.extract_defined_undefined("baz is not defined")
    assert [("baz", 'is not', 'defined')] == t.extract_defined_undefined("baz is not defined and bar is not defined")

# Generated at 2022-06-21 00:23:19.643493
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager._extra_vars = {}
    variable_manager._options_vars = {}
    variable_manager._options_vars['privatekey_file'] = '~/.ssh/id_rsa'
    templar = Templar(loader=loader, variables=variable_manager)

    conditional = Conditional(loader)

    # tests
    assert conditional.evaluate_conditional(templar, {'a': 'foo', 'b': 'bar'})
    assert conditional.evaluate_conditional(templar, {'a': 'foo', 'b': 'bar', 'c': False})

# Generated at 2022-06-21 00:23:20.339708
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c != None

# Generated at 2022-06-21 00:23:39.490847
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    context = PlayContext()
    task = Task()

    if not isinstance(task, Conditional):
        raise AssertionError("Expected task to be an instance of Conditional, got %s" % type(task))

    loader.load_from_file = lambda x: dict(foo="bar")
    context.prompt = lambda x, y: "y"
    task._loader = loader
    task._tqm = object()

    task.when = ["True if 'bar' in foo else False"]
    assert task.evaluate_conditional(task.templar, task.get_vars())

    context.ANS

# Generated at 2022-06-21 00:23:49.336590
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    c = Conditional()
    c._when = ['foo != bar']
    pc = PlayContext()
    v = VariableManager()
    t = Templar(loader=None, variables=v, shared_loader_obj=None)
    res = c.evaluate_conditional(t, {})
    assert res is False
    res = c.evaluate_conditional(t, {'foo': ['foo1']})
    assert res is False
    res = c.evaluate_conditional(t, {'foo': ['foo', 'bar']})
    assert res is True
    res = c.evaluate_conditional(t, {'foo': ['bar', 'foo']})
    assert res is False

# Generated at 2022-06-21 00:23:57.281533
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    results = {
        'foo': 'bar'
    }

    # _check_conditional test
    conditional = Conditional(loader=loader)
    conditional.when = [
        "{{ results['foo'] }}=='bar'",
        "{{ results['foo'] }}=='baz'"
    ]
    conditional.evaluate_conditional(Conditional.loader, results)

# Generated at 2022-06-21 00:24:06.335356
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    p = Conditional()

    vars_manager = VariableManager()
    vars_manager._fact_cache = dict(
        string_var='string',
        defined_var=dict(defined=True),
        undefined_var=dict(defined=False),
        list_var=['string', 1, 2, 3],
        task_var=dict(a=1, b=2, c=3),
    )

    templar = Templar(vars_manager=vars_manager)

    assert p.evaluate_conditional(templar, vars_manager._fact_cache)

    p.when = 'string_var'
    assert p.evaluate_conditional(templar, vars_manager._fact_cache)

    p.when

# Generated at 2022-06-21 00:24:17.789909
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar, vault

    template_data = """
    a: 1
    b: 2
    c: 3
    d:
      e: 4
    """

    def create_loader_mock():
        loader_mock = MagicMock()
        loader_mock.load_from_file.return_value.strip.return_value = template_data
        return loader_mock

    def create_vault_secrets_mock(vault_password):
        secrets_mock = MagicMock()
        secrets_mock.get_vault_password.return_value = vault_password
        return secrets_mock

    def create_all_vars(values):
        all_vars = MagicMock()

# Generated at 2022-06-21 00:24:27.983953
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional(loader=None)
    assert cond.extract_defined_undefined(conditional='') == list()
    assert cond.extract_defined_undefined(conditional='n1 is defined') == [('n1', ' is', 'defined')]
    assert cond.extract_defined_undefined(conditional='n1 is not defined') == [('n1', ' is not', 'defined')]
    assert cond.extract_defined_undefined(conditional='n1 is undefined') == [('n1', ' is', 'undefined')]
    assert cond.extract_defined_undefined(conditional='n1 is not undefined') == [('n1', ' is not', 'undefined')]

# Generated at 2022-06-21 00:24:39.317696
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_variable_defined_check(VALID_VAR_REGEX)

# Generated at 2022-06-21 00:24:40.478083
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert isinstance(conditional,Conditional)


# Generated at 2022-06-21 00:24:48.970171
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    Unit test for method extract_defined_undefined of class Conditional
    '''
    def test(conditional, expected_results):
        c = Conditional()
        res = c.extract_defined_undefined(conditional)
        if res != expected_results:
            raise AssertionError("Conditional.extract_defined_undefined did not return expected result for %s, expected %s, got %s" % (conditional, expected_results, res))

    # test simple defined
    test("hostvars[inventory_hostname] is defined and hostvars[inventory_hostname]['foo'] is defined",
         [('hostvars[inventory_hostname]', 'is', 'defined'), ('hostvars[inventory_hostname][\'foo\']', 'is', 'defined')])

# Generated at 2022-06-21 00:24:50.596767
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c._when == []



# Generated at 2022-06-21 00:25:14.440571
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class testCond:
        pass
    test = testCond()
    assert test.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert test.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert test.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert test.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert test.extract_defined_undefined("foo is defined or bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]
    assert test.extract_defined_undefined("foo is missing") == []


# Generated at 2022-06-21 00:25:26.489224
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    obj = Conditional()
    assert obj.extract_defined_undefined("test2 is defined or test3 is not defined") == [('test2', 'is', 'defined'), ('test3', 'is not', 'defined')]
    assert obj.extract_defined_undefined("test2 is defined or not (test3 is not defined)") == [('test2', 'is', 'defined'), ('test3', 'is not', 'defined')]
    assert obj.extract_defined_undefined("not (test1 is defined or test2 is not defined) and not (test3 is defined)") == [('test1', 'is', 'defined'), ('test2', 'is not', 'defined'), ('test3', 'is', 'defined')]

# Generated at 2022-06-21 00:25:31.045892
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook import PlayBook
    from ansible.template import Templar

    p = PlayBook()
    rd = RoleDefinition()
    rd.when = ['a', 'b']
    rd._loader = p._loader

    assert rd.when == ['a', 'b']

# Generated at 2022-06-21 00:25:39.446154
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-21 00:25:50.916923
# Unit test for constructor of class Conditional
def test_Conditional():

    # a task with a conditional that uses a lookup
    task_1 = dict(
        action=dict(
            module='command',
            args=dict(
                _raw_params='{{ lookup("url", "http://test.com") }}'
            )
        ),
        when=dict(
            _raw_params='lookup("url", "http://test.com") == "abc"'
        )
    )

    # a handler with a conditional that uses a lookup

# Generated at 2022-06-21 00:25:59.808756
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.base import Base
    from ansible.utils.display import Display
    import sys

    sys.stdout = open('/dev/null', 'w')  # cover up display.deprecated()

    b = Base('foo')
    b.vars = {'x': 'y'}
    c = Conditional(loader=b)

    c._check_conditional("1 < 2", b, b.vars)

    d = {}
    d['string'] = '"foo"|string|"bar"'
    d['boolean'] = 'True|bool|False'
    d['none'] = 'None'
    d['number'] = '1|int|2'
    d['nested'] = '"baz"|string|{{ nested }}|default("default")'

# Generated at 2022-06-21 00:26:11.568143
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    test_conditional = "hostvars['foo'] is defined or hostvars['foo']['bar'] is defined"
    res = c.extract_defined_undefined(test_conditional)
    assert res[0][0] == "hostvars['foo']"
    assert res[0][1] == "is"
    assert res[0][2] == "defined"
    assert res[1][0] == "hostvars['foo']['bar']"
    assert res[1][1] == "is"
    assert res[1][2] == "defined"

    test_conditional = "hostvars[inventory_hostname] is defined and hostvars[inventory_hostname].ansible_host is not defined"

# Generated at 2022-06-21 00:26:15.337421
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional


# the base class for objects that can be run, which is a mix-in class with
# Conditional so that each instance can be run conditionally.

# Generated at 2022-06-21 00:26:23.665729
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestConditional(Conditional):
        pass

    test_conditional = TestConditional()

    # Test with no when values
    assert test_conditional.evaluate_conditional(None, None) is True

    # Test with one when value
    test_conditional.when = None
    assert test_conditional.evaluate_conditional(None, None) is True

    # Test with no when values
    test_conditional.when = []
    assert test_conditional.evaluate_conditional(None, None) is True

    # Test with multiple when values
    test_conditional.when = [False, None, []]
    assert test_conditional.evaluate_conditional(None, None) is False

    # Test with multiple when values
    test_conditional.when = [True, False, []]

# Generated at 2022-06-21 00:26:33.044271
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variables = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    play_context = PlayContext()

    conditional_test = Conditional(loader=loader)
    conditional_test._ds = None
    conditional_test.when.append("{{ test1 }}")
    conditional_test.when.append("{{ test2 }}")

    assert conditional_test.evaluate_conditional(variables, inventory, play_context)

# Generated at 2022-06-21 00:27:13.865642
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()


# ===========================================


# Generated at 2022-06-21 00:27:15.276579
# Unit test for constructor of class Conditional
def test_Conditional():
    try:
        Conditional()
    except Exception as e:
        assert isinstance(e, AnsibleError)


# Generated at 2022-06-21 00:27:19.011573
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_test = Conditional(loader=None)
    assert conditional_test is not None

# Generated at 2022-06-21 00:27:25.827134
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-21 00:27:39.315679
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-21 00:27:47.836804
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    b_vars = dict(
        a=1,
        b='foo',
        c=None,
        d=True,
        e=False,
        f='',
        g=[],
        h=['foo', 'bar'],
    )

    assert Conditional().evaluate_conditional(FakeTemplar(dict(hostvars=b_vars)), dict(hostvars=b_vars))

    assert Conditional().evaluate_conditional(FakeTemplar(dict(hostvars=b_vars)), dict(hostvars=b_vars)), 'Simple boolean true'

    assert not Conditional('a==1').evaluate_conditional(FakeTemplar(dict(hostvars=b_vars)), dict(hostvars=b_vars)), 'Simple boolean false'


# Generated at 2022-06-21 00:27:51.359927
# Unit test for constructor of class Conditional
def test_Conditional():
    # Creating an instance of class Conditional
    m = Conditional()

    # Calling the instance method
    result = m.evaluate_conditional(None, None)

    # Since the output is not a boolean, we should get False here
    assert not result

# Generated at 2022-06-21 00:28:01.909413
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class DummyLoader:
        pass
    loader = DummyLoader()
    from ansible.template import Templar
    templar = Templar(loader=loader)


# Generated at 2022-06-21 00:28:11.099584
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    class TestConditional(Conditional):
        pass

    vars = dict(a=[1,2,3], b=dict(x='x',y='y',z='z'))
    t = Templar(loader=None, variables=vars)

    tc = TestConditional(loader=None)
    assert tc.evaluate_conditional(t, vars) is True

    tc._when = ['a is defined and b is defined']
    assert tc.evaluate_conditional(t, vars) is True
    tc._when = ['a is not defined and b is not defined']
    assert tc.evaluate_conditional(t, vars) is False

    tc._when = ['a == a and b == b']
    assert tc.evaluate_conditional(t, vars) is True
    tc._

# Generated at 2022-06-21 00:28:20.582242
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext

    conditional = Conditional()

    # Test conditionals which are expected to be evaluated to True
    assert conditional.evaluate_conditional(variable_manager=None, templar=None, all_vars={}, conditional='True')
    assert conditional.evaluate_conditional(variable_manager=None, templar=None, all_vars={}, conditional='False')
    assert conditional.evaluate_conditional(variable_manager=None, templar=None, all_vars={}, conditional='foo')
    assert conditional.evaluate_conditional(variable_manager=None, templar=None, all_vars={}, conditional='foo.bar')

# Generated at 2022-06-21 00:29:54.130912
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c._when == list


# Generated at 2022-06-21 00:29:59.509672
# Unit test for constructor of class Conditional
def test_Conditional():
    playbook = '''
---
- hosts: test_all
  serial: 3
  gather_facts: false
  tasks:
    - name: Task1
      debug:
        var: a
      when: a is not defined
'''
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    from ansible.playbook import Playbook
    pb = Playbook.load(playbook, loader=loader, variable_manager=None, loader_cache=False)
    t = pb.get_plays()[0].get_tasks()[0]
    assert t.evaluate_conditional is not None


# Generated at 2022-06-21 00:30:10.015182
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    assert Conditional().evaluate_conditional(None, dict()) == True

    class TestObj(Conditional):
        def __init__(self, when=None, loader=None):
            self._loader = loader
            self._when = when or list()

    assert TestObj(when=None, loader=None).evaluate_conditional(None, dict()) == True
    assert TestObj(when=1, loader=None).evaluate_conditional(None, dict()) == False
    assert TestObj(when=0, loader=None).evaluate_conditional(None, dict()) == False
    assert TestObj(when=[], loader=None).evaluate_conditional(None, dict()) == True
    assert TestObj(when=[1], loader=None).evaluate_conditional(None, dict()) == False
    assert TestObj(when=[0], loader=None).evaluate_

# Generated at 2022-06-21 00:30:21.425292
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-21 00:30:28.117426
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    result = cond.extract_defined_undefined("some_var is defined and some_variable is undefined and some_varaible is defined")
    assert result == [
        ('some_var', 'is', 'defined'),
        ('some_variable', 'is', 'undefined'),
        ('some_varaible', 'is', 'defined')]



# Generated at 2022-06-21 00:30:32.099360
# Unit test for constructor of class Conditional
def test_Conditional():
    class TestConditional(Conditional):
        def __init__(self):
            Conditional.__init__(self)

    test_conditional = TestConditional()



# Generated at 2022-06-21 00:30:42.414354
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined(u'foo is defined') == [(u'foo', u'is', u'defined')]
    assert conditional.extract_defined_undefined(u'foo is not defined') == [(u'foo', u'is not', u'defined')]
    assert conditional.extract_defined_undefined(u'foo is undefined') == [(u'foo', u'is', u'undefined')]
    assert conditional.extract_defined_undefined(u'foo is not undefined') == [(u'foo', u'is not', u'undefined')]
    assert conditional.extract_defined_undefined(u'foo and bar is defined') == [(u'bar', u'is', u'defined')]


# Generated at 2022-06-21 00:30:53.357274
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    def run_test(item,templar,all_vars,result):
        c=Conditional()
        c._when = item
        assert(c.evaluate_conditional(templar,all_vars) == result)

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    data = { 'foo': 'bar', 'bar': 'baz', 'local': 'example', 'baz': 2 }
    val_mgr = VariableManager()
    val_mgr.set_inventory(VariableManager())
    val_mgr.set_variable('hostvars', { 'localhost': data })

# Generated at 2022-06-21 00:30:59.987162
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

# Generated at 2022-06-21 00:31:12.239211
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    class TestConditional(Conditional):
        def __init__(self):
            super(TestConditional, self).__init__()
