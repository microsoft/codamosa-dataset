

# Generated at 2022-06-21 00:22:00.669574
# Unit test for constructor of class Conditional
def test_Conditional():
    m = Conditional()



# Generated at 2022-06-21 00:22:02.043100
# Unit test for constructor of class Conditional
def test_Conditional():
    a = Conditional(loader=None)
    assert a.when == []

# Generated at 2022-06-21 00:22:11.540458
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    c = Conditional()
    res = c.extract_defined_undefined("hostvars['localhost']['ansible_facts'] is defined and hostvars['localhost']['ansible_facts']['distribution'] == 'CentOS'")
    assert res == [('hostvars[\'localhost\'][\'ansible_facts\']', 'is', 'defined')]

    res = c.extract_defined_undefined("hostvars['localhost']['ansible_facts']['distribution'] == 'CentOS' and hostvars['localhost']['ansible_facts'] is defined")
    assert res == [('hostvars[\'localhost\'][\'ansible_facts\']', 'is', 'defined')]


# Generated at 2022-06-21 00:22:23.269352
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar

    # Setup the test
    class ConditionalTest:
        def __init__(self, when):
            self._when = when

    # Testing normal when
    #
    # Manage the case when the conditional is true
    c = ConditionalTest(when='True')
    t = Templar(loader=None)
    assert c.evaluate_conditional(templar=t, all_vars=None)

    # Manage the case when the conditional is false
    c = ConditionalTest(when='False')
    t = Templar(loader=None)
    assert not c.evaluate_conditional(templar=t, all_vars=None)

    # Testing list of when
    #
    # Manage the case when only one conditional element is true

# Generated at 2022-06-21 00:22:33.105204
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    from ansible.template import Templar

    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-21 00:22:44.694444
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    assert Conditional(None)._check_conditional('1 == 1', None, {})
    assert not Conditional(None)._check_conditional('1 == 2', None, {})
    assert Conditional(None)._check_conditional('foo.bar == "foobar"', None, {'foo': {'bar': 'foobar'}})
    assert not Conditional(None)._check_conditional('foo.bar == "foobar"', None, {'foo': {'bar': 'foobar2'}})
    assert Conditional(None)._check_conditional('foo.bar is defined', None, {'foo': {'bar': 'foobar'}})
    assert not Conditional(None)._check_conditional('foo.bar is defined', None, {'foo': {'bar': 'foobar2'}})


# Generated at 2022-06-21 00:22:47.426883
# Unit test for constructor of class Conditional
def test_Conditional():
    t = Conditional(Base())
    assert 'Base' == t.__class__.__mro__[-2].__name__


# Generated at 2022-06-21 00:22:57.245649
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext

    parser = ModuleArgsParser(None, None, None)
    variable_manager = VariableManager(loader=None, variable_manager=None)
    variable_manager.extra_vars = dict(
        foo=dict(
            bar=dict(
                baz=True
            )
        ),
        vvv="{{ inventory_hostname }}"
    )
    context = PlayContext()
    context.prompt = dict(
        private_key_file=dict(
            val=True,
            prompt='Private Key File',
            confirm=True
        )
    )

# Generated at 2022-06-21 00:23:08.407045
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert Conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert Conditional.extract_defined_undefined("foo not is defined") == [('foo', 'not is', 'defined')]
    assert Conditional.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert Conditional.extract_defined_undefined("foo is not defined and bar is defined") == [('foo', 'is not', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-21 00:23:19.082676
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    def test(conditional_string, expected_defined_undefined):

        conditional = Conditional()

        def_undef = conditional.extract_defined_undefined(conditional_string)

        if def_undef != expected_defined_undefined:
            assert def_undef == expected_defined_undefined, '%r != %r' % (def_undef, expected_defined_undefined)

    test("ansible_os_family == 'RedHat'", [('ansible_os_family', '==', 'RedHat')])
    test("ansible_os_family|lower == 'redhat'", [('ansible_os_family|lower', '==', 'redhat')])

# Generated at 2022-06-21 00:23:38.534111
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test boolean evaluation
    p = Conditional()
    assert p._check_conditional("{{ true }}", None, {})
    assert not p._check_conditional("{{ false }}", None, {})
    assert p._check_conditional("{{ true == true }}", None, {})
    assert not p._check_conditional("{{ true == false }}", None, {})
    assert p._check_conditional("true", None, {})
    assert not p._check_conditional("false", None, {})
    assert p._check_conditional("{{ (1 < 2) and (2 < 3) }}", None, {})
    assert not p._check_conditional("{{ (1 < 2) and (3 < 2) }}", None, {})

# Generated at 2022-06-21 00:23:47.890531
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    class TestConditional(Conditional):
        def __init__(self, when=None):
            self.when = when
            super(TestConditional, self).__init__()

    class TestLoader:
        def __init__(self):
            self.template = None


# Generated at 2022-06-21 00:23:58.836800
# Unit test for constructor of class Conditional
def test_Conditional():
    '''
    Basic unit test case for Conditional
    '''
    print("################### Conditional unit test start ###################")
    # Conditional class is a mixin class, and is used by Statement class.
    # Statement class is the base class of Block, Tasks, and Handler.
    # Here we use AnsibleRole to test if Conditional class works.
    from ansible.playbook.role import Role

    role = Role()
    role.when = [True]
    role.when = [False, True]
    role.when = ["some conditional", True]

    assert role.when == ["some conditional", True]
    print("################### Conditional unit test passed ###################")

if __name__ == "__main__":
    test_Conditional()

# Generated at 2022-06-21 00:24:07.251540
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.task import Task
    cond = Conditional()
    assert cond.extract_defined_undefined("var1 is defined and var2 is defined") == [("var1", "is", "defined"), ("var2", "is", "defined")]
    assert cond.extract_defined_undefined("var1 is not undefined and var2 is not undefined") == [("var1", "is not", "undefined"), ("var2", "is not", "undefined")]
    assert cond.extract_defined_undefined("var1 is defined") == [("var1", "is", "defined")]
    assert cond.extract_defined_undefined("var1 is not undefined") == [("var1", "is not", "undefined")]

# Generated at 2022-06-21 00:24:18.456873
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    test_conditional = Conditional()
    all_vars = dict(foo="bar", one=1, one_two=12, test_true=True, test_false=False, test_none=None,
                    test_zero=0, test_empty="", test_non_empty="test")
    templar = Templar(loader=None, variables=all_vars)

    #
    # Test the evaluation of the different methods of checking for the existence of a variable
    #

    # test with a simple string that evaluates to True
    result = test_conditional.evaluate_conditional(templar, all_vars)
    assert result

    # test with a simple string that evaluates to False
    test_conditional.when = "foo"
    result = test_conditional.evaluate_conditional

# Generated at 2022-06-21 00:24:28.435945
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("a is defined and b is defined") == [('a','is','defined'), ('b','is','defined')]
    assert conditional.extract_defined_undefined("a is not defined and b is not defined") == [('a','is not','defined'), ('b','is not','defined')]
    assert conditional.extract_defined_undefined("a is undefined and b is undefined") == [('a','is','undefined'), ('b','is','undefined')]
    assert conditional.extract_defined_undefined("a is not undefined and b is not undefined") == [('a','is not','undefined'), ('b','is not','undefined')]

# Generated at 2022-06-21 00:24:39.355505
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # We instanciate a Conditional class and a dictionnary of variables
    conditional = Conditional()

    # First we test with a string with no variable
    assert conditional.evaluate_conditional("True", {}) == True
    assert conditional.evaluate_conditional("False", {}) == False

    # Second we test with a string with a variable that exists
    assert conditional.evaluate_conditional("{{ test_variable }}", {"test_variable" : "True"}) == True
    assert conditional.evaluate_conditional("{{ test_variable }}", {"test_variable" : "False"}) == False
    assert conditional.evaluate_conditional("{{ test_variable }}", {"test_variable" : "{{ test_variable2 }}", "test_variable2" : False}) == False

    # Third we test with a string with a variable that does not exists
    #

# Generated at 2022-06-21 00:24:40.289603
# Unit test for constructor of class Conditional
def test_Conditional():
    #t = Conditional()

    return True


# Generated at 2022-06-21 00:24:48.835923
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    display.debug("test_Conditional_extract_defined_undefined()")

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    fake_loader = DictDataLoader({
        "/testing.yml": """
        - hosts: localhost
          connection: local
          task:
              ping:
                test: "{{ hostvars[inventory_hostname]['test'] | default('default') }}"
        """
    })

    # Create play and set the basedir to /testing.yml so Templar uses the right vars
    play_ds = DataLoader().load_from_file("/testing.yml")[0]
    play = Play().load(play_ds, variable_manager=VariableManager(), loader=fake_loader)
    play.basedir = "/testing.yml"

# Generated at 2022-06-21 00:25:00.608100
# Unit test for constructor of class Conditional
def test_Conditional():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_from_file('/etc/ansible/hosts'))

    # check using when as a list
    test_conditional = Conditional(loader=loader)
    assert test_conditional._when == [], \
        'value of attribute when (default value) is not equal to [], the expected value'

    test_conditional.when = [ 'foo == bar', 'cat == dog' ]

# Generated at 2022-06-21 00:25:17.198705
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()


# Generated at 2022-06-21 00:25:28.218938
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    conditional = Conditional()

    c1 = "foo is defined"
    e1 = [('foo', 'is', 'defined')]
    result1 = conditional.extract_defined_undefined(c1)
    assert (result1 == e1), \
        "extract_defined_undefined failed to extract correctly defined conditional (1)"

    c2 = "foo not is defined"
    e2 = [('foo', 'not is', 'defined')]
    result2 = conditional.extract_defined_undefined(c2)
    assert (result2 == e2), \
        "extract_defined_undefined failed to extract correctly defined conditional (2)"

    c3 = "foo is not defined"
    e3 = [('foo', 'is not', 'defined')]

# Generated at 2022-06-21 00:25:37.992164
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # TODO: move the tests to a dedicated tests file
    from ansible.template import Templar
    from ansible.vars import VariableManager

    t = Templar(VariableManager(loader=None))
    w = Conditional()
    w.when = ['test_conditional']
    vars = dict(test_conditional='1')
    assert w.evaluate_conditional(t, vars)

    w.when = ['test_conditional == 0']
    vars = dict(test_conditional='1')
    assert not w.evaluate_conditional(t, vars)

    w.when = ['test_conditional is defined']
    vars = dict(test_conditional='1')
    assert w.evaluate_conditional(t, vars)

    w.when = ['test_conditional is undefined']
    vars

# Generated at 2022-06-21 00:25:41.924434
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # just a check that the syntax is correct
    assert hasattr(Conditional, 'evaluate_conditional')
    assert callable(getattr(Conditional, 'evaluate_conditional'))



# Generated at 2022-06-21 00:25:53.462759
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = 'ansible_distribution is not defined and test[0] is one'
    res = Conditional().extract_defined_undefined(conditional)
    assert res == [('ansible_distribution', 'is not', 'defined'), ('test[0]', 'is', 'one')]

    conditional = 'ansible_distribution is not defined and test[0] is one and test[1] is one'
    res = Conditional().extract_defined_undefined(conditional)
    assert res == [('ansible_distribution', 'is not', 'defined'), ('test[0]', 'is', 'one'), ('test[1]', 'is', 'one')]

    conditional = 'ansible_distribution is not defined and test[0] is one and test[1] is one and test[2] is one'
   

# Generated at 2022-06-21 00:26:01.069005
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    class DummyPlay:
        def __init__(self):
            self.variable_manager = VariableManager()
            self.loader = DataLoader()

    class Dummy:
        def __init__(self, vars):
            self._loader = DataLoader()
            self._variable_manager = VariableManager()
            self._result = True
            self._variable_manager.set_nonpersistent_facts(vars)

        def evaluate_conditional(self, templar, all_vars):
            self._result = super(Dummy, self).evaluate_conditional(templar, all_vars)
            return self._result

        def set_conditional_value(self, value):
            self._variable_

# Generated at 2022-06-21 00:26:07.201728
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader

    class TestConditional1(Conditional):
        __slots__ = ()

    loader = DataLoader()
    assert TestConditional1(loader)

    class TestConditional2(Conditional):
        _loader = loader
        __slots__ = ()

    assert TestConditional2()


# ==============================================================
# PLUGIN LOADER FUNCTIONS


# Generated at 2022-06-21 00:26:18.121927
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Note: these tests are incomplete and just test a few random cases which
    # I added while writing the logic. More tests are needed.
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.vars import VariableManager

    vault_password = "vaultpassword"
    vault = VaultLib(vault_password)

    group_vars = dict(group_one=dict(group_var_one="one"))
    host_vars = dict(host_one=dict(host_var_one="host_one"))
    host_vars['host_two'] = vault.encrypt('host_two', str(host_vars))
    variable_manager = VariableManager()

# Generated at 2022-06-21 00:26:25.442294
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

# Generated at 2022-06-21 00:26:28.480781
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional is not None
    assert conditional._when == list()
    assert conditional._when[0] is None
    assert conditional._when[1] is None


# Generated at 2022-06-21 00:27:05.827418
# Unit test for constructor of class Conditional
def test_Conditional():
    assert Conditional()

# Generated at 2022-06-21 00:27:13.110031
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.template import Templar
    import ansible.vars

    items = {'a': 'a', 'b': 'b', 'c': 'c'}
    conditional = SetModule()
    conditional._ds = 'test'

    context = PlayContext()
    context._fact_cache = {}
    context._vars = {}
    context._hostvars = ansible.vars.hostvars
    context._hosts = MutableMapping()
    context._baseline_context = set()

    templar = Templar(loader=None, variables=None, shared_loader_obj=None)
    templar._available_variables = context.get_vars()

# Generated at 2022-06-21 00:27:18.905619
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    ''' test class Conditional evaluate_conditional method '''
    import jinja2

    class FakeLoader(object):
        ''' fake jinja2 template loader '''
        def __init__(self):
            self.templates = dict(test_template='test')

        def get_source(self, env, name):
            ''' fake jinja2 loader get_source method '''
            return (self.templates[name], name, lambda: False)

    class FakePlaybookBase(object):
        ''' fake playbook base class '''
        def __init__(self, loader=None):
            self._loader = loader

    class FakeConditionalPlaybookBase(Conditional, FakePlaybookBase):
        ''' fake playbook base class with conditional mixin '''

# Generated at 2022-06-21 00:27:25.788227
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_available_variables(hostvars={'foo': "bar"})

    c = Conditional(loader=loader)
    c.when = ["hostvars['foo'] == 'bar'"]
    assert c.evaluate_conditional(loader.load_from_file, variable_manager._fact_cache)

    c.when = ["hostvars['foo'] == 'bar'", "foo == 'bar'"]
    assert not c.evaluate_conditional(loader.load_from_file, variable_manager._fact_cache)


# Generated at 2022-06-21 00:27:39.315724
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    c = Conditional(loader=None)
    assert c._when is not None
    c = Conditional(loader=None, when=["a==b", "c==d"])
    assert c._when == ["a==b", "c==d"]
    context = PlayContext()
    context.vars = dict(e=2, f=3)
    c = Conditional(loader=None, when=["e==2", "f==3"], task_include=TaskInclude(loader=None, context=context))
    assert c._when == ["e==2", "f==3"]
    assert c.evaluate_conditional(templar=None, all_vars=dict(y=1))


# Generated at 2022-06-21 00:27:45.548360
# Unit test for constructor of class Conditional
def test_Conditional():
    host = 'localhost'
    hostvars = {'localhost': {'foo': 'bar'}}
    vault_password = None
    new_stdin = []

    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,',])

    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.set_host_variable(host, 'ansible_connection', 'local')

    from ansible.playbook.play_context import PlayContext
    play_context = PlayContext(remote_addr=host, password=vault_password, connection='local')

# Generated at 2022-06-21 00:27:46.228508
# Unit test for constructor of class Conditional
def test_Conditional():
    assert(Conditional())


# Generated at 2022-06-21 00:27:55.637438
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    import ansible.playbook.play_iterator

    test_host_vars = {'localhost': {'foo': 42, 'baz': 'hello world'}, 'otherhost': {'bar': 13, 'baz': 'goodbye'}}
    test_task_vars = {'foo': 42, 'bar': 13}
    test_play_vars = {'test_play_vars': 'test_value'}
    test_extra_vars = {'test_extra_vars': 'test_value'}
    test_templar = ansible.playbook.play_iterator.TaskIterator('test_play', PlayContext())

    test_conditional = Conditional()
    test_conditional._loader = ansible.parsing.dataloader

# Generated at 2022-06-21 00:28:00.284088
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = DataLoader()

    conditional = Conditional(loader)
    assert conditional


# Generated at 2022-06-21 00:28:08.199929
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Arrange
    class TestConditional(Conditional):
        pass
        
    test_obj = TestConditional()
    test_obj.when = ['test1', 'test2', None, False]

    templar = None
    all_vars = None

    def side_effect_of_method_check_conditional(conditional, templar, all_vars):
        return False

    # Act
    test_obj._check_conditional = side_effect_of_method_check_conditional
    result = test_obj.evaluate_conditional(templar, all_vars)

    # Assert
    assert result is False

# Generated at 2022-06-21 00:29:41.840448
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    import unittest
    from ansible.template import Templar

    class TestConditional(Conditional):
        def __init__(self, loader=None):
            super(TestConditional, self).__init__(loader)

    class MyLoader:
        pass

    class TestTemplar(Templar):
        def __init__(self):
            self.loader = MyLoader()
            self.environment = None
            self.basedir = None
            self.curr_basedir = None
            self.avail_variables = dict()
            self.template = dict()

        def is_template(self, data):
            return False

        def set_available_variables(self, variables):
            self.avail_variables = variables


# Generated at 2022-06-21 00:29:54.603488
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """
    Unit test to ensure that Conditional class can be used without a host
    """

    # Define the objects to be used
    the_loader = None
    the_variable_manager = None

    # Create a dummy class inheriting from Conditional
    class TestClass(Conditional):
        def __init__(self, loader, variable_manager):
            self._loader = loader
            self._variable_manager = variable_manager
            super(Conditional, self).__init__()

    # Create the object
    obj = TestClass(when = dict(
        condition = "True",
    ))

    # Create the template
    obj._templar = obj._variable_manager.get_vars_loader(loader = the_loader, play=None).get_template_class()()

    # Test evaluate_conditional
    assert obj.evaluate

# Generated at 2022-06-21 00:30:00.720385
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-21 00:30:10.593362
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is defined or hostvars[inventory_hostname]') == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo is defined or hostvars[inventory_hostname] is defined') == [('foo', 'is', 'defined'), ('hostvars[inventory_hostname]', 'is', 'defined')]

# Generated at 2022-06-21 00:30:19.894233
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    play_context = PlayContext()

    conditional = Conditional(loader=DataLoader())
    conditional.evaluate_conditional(variable_manager, play_context)

# Generated at 2022-06-21 00:30:31.170373
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    conditional = 'this is a test'
    conditional_1 = 'ansible_os_family is defined or ansible_distribution == "Ubuntu"'
    conditional_2 = 'ansible_os_family is    not defined and not ansible_distribution == "Ubuntu"'
    conditional_3 = 'var1 is not defined and var2 is not defined and var3 is not defined and var4 is not defined'
    conditional_4 = 'var1 == "example string" or var2 is undefined'
    conditional_5 = 'var1 == "example string" or var2 is not defined'
    conditional_6 = "var1 is defined and (var2 is defined or (lookup('pipe', 'echo foo')|d() is defined and var4 is defined))"

# Generated at 2022-06-21 00:30:42.018301
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    conditional = Conditional(loader=None)
    assert conditional

    conditional = Conditional(loader=Play())
    assert conditional

    conditional = Conditional(loader=Play())
    conditional.when = [1,2,3]
    assert conditional.evaluate_conditional(None, None)
    conditional.when=[]
    assert conditional.evaluate_conditional(None, None)
    conditional.when=[0]
    assert not conditional.evaluate_conditional(None, None)
    conditional.when=False
    assert conditional.evaluate_conditional(None, None)
    conditional.when="foobar"
    assert not conditional.evaluate_conditional(None, None)


# Generated at 2022-06-21 00:30:47.429286
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.template import Templar
    c = Conditional()
    assert c is not None
    assert c.when == []
    assert c._ds is None
    assert c._loader is None
    templar = Templar(loader=None, variables={})
    assert not c.evaluate_conditional(templar=templar, all_vars={})
    c.when = 'foo'
    assert c.evaluate_conditional(templar=templar, all_vars={})
    c.when = True
    assert c.evaluate_conditional(templar=templar, all_vars={})
    c.when = False
    assert not c.evaluate_conditional(templar=templar, all_vars={})

# Generated at 2022-06-21 00:30:55.046407
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """
    Test method evaluate_conditional of class Conditional:
    """
    class TestConditional(Conditional):
        def __init__(self):
            self.when = []
    import ansible.template as template

    tt = template.Template(loader=None, variables={})
    tc = TestConditional()
    tc._check_conditional = lambda x, y, z: True
    tc.when.append(None)
    assert tc.evaluate_conditional(tt, {}) is True
    tc.when.append(False)
    assert tc.evaluate_conditional(tt, {}) is False
    tc.when.append(True)
    assert tc.evaluate_conditional(tt, {}) is True
    tc.when.append("ansible_distribution == 'CentOS'")
    assert tc.evaluate_cond

# Generated at 2022-06-21 00:30:58.882614
# Unit test for constructor of class Conditional
def test_Conditional():
    loader = 'fake_loader'
    conditional = Conditional(loader=loader)
    assert conditional._loader == loader
    assert conditional._when == []

