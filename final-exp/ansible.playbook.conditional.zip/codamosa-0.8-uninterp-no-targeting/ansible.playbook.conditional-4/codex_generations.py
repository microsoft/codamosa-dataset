

# Generated at 2022-06-21 00:21:59.284812
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()

    assert c._loader is None
    assert c.when is not None
    assert len(c.when) == 0


# Generated at 2022-06-21 00:22:04.765604
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # there is a potential conflict between the module_utils.six
    # and ansible modules, so we need to do a bit of extra work
    # to ensure we are getting the correct one below
    try:
        from ansible.module_utils.six import StringIO
    except ImportError:
        from six import StringIO
    try:
        from ansible.module_utils.six.moves import cStringIO
    except ImportError:
        from six.moves import cStringIO
    # the playbooks we will use in the test
    # are the same as in the unit test of the
    # class Base of the module base, but with a
    # when clause

# Generated at 2022-06-21 00:22:05.736430
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional is not None

# Generated at 2022-06-21 00:22:12.925163
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    def_undef = cond.extract_defined_undefined("myvar is defined and myvar is not undefined")
    assert(def_undef == [("myvar", "is", "defined"), ("myvar", "is not", "undefined")])
    def_undef = cond.extract_defined_undefined("myvar is defined and myvar2 is not defined and test_hostvars['foo'] is undefined")
    assert(def_undef == [("myvar", "is", "defined"), ("myvar2", "is not", "defined"), ("test_hostvars['foo']", "is", "undefined")])


# Generated at 2022-06-21 00:22:24.773874
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # setup
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    import ast

    variable_manager = VariableManager()

# Generated at 2022-06-21 00:22:34.156420
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    class MockConditional:
        def __init__(self):
            self.when = []

    # Test with a single defined condition
    mock_conditional = MockConditional()
    conditional = '{{ foo is defined }}'
    mock_conditional.when.append(conditional)
    result = mock_conditional.extract_defined_undefined(conditional)
    assert result == [('foo', 'is', 'defined')]

    # Test with a single undefined condition
    mock_conditional = MockConditional()
    conditional = '{{ foo is undefined }}'
    mock_conditional.when.append(conditional)
    result = mock_conditional.extract_defined_undefined(conditional)
    assert result == [('foo', 'is', 'undefined')]

    # Test with a combination of defined and undefined conditions
   

# Generated at 2022-06-21 00:22:45.412883
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('foo') == []
    assert conditional.extract_defined_undefined('foo and bar') == []
    assert conditional.extract_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo and hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo and hostvars[inventory_hostname] is defined and bar') == [('hostvars[inventory_hostname]', 'is', 'defined')]

# Generated at 2022-06-21 00:22:52.810405
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert Conditional.extract_defined_undefined('foo is defined and bar is not undefined or bla is defined') == [('foo', 'is', 'defined'), ('bar', 'is not', 'undefined'), ('bla', 'is', 'defined')]
    assert Conditional.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert Conditional.extract_defined_undefined('foo is bar') == []


# Generated at 2022-06-21 00:22:57.656150
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play import Play
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    myplay = Play().load({}, variable_manager=VariableManager(), loader=None)
    mytask = Task().load(dict(when='{{ foo }}'), play=myplay, variable_manager=VariableManager(), loader=None)

    assert isinstance(mytask, Conditional)

# Generated at 2022-06-21 00:23:08.913471
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Create and instantiate Conditional object
    conditional = Conditional()

    # Check if function extract_defined_undefined is able to handle
    # correct and incorrect input
    assert(conditional.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")])
    assert(conditional.extract_defined_undefined("foo is not undefined") == [("foo", "is not", "undefined")])
    assert(conditional.extract_defined_undefined("foo is defined and bar is defined") == [("foo", "is", "defined"), ("bar", "is", "defined")])
    assert(conditional.extract_defined_undefined("foo is definedbar is defined") == [("foo", "is", "defined")])

# Generated at 2022-06-21 00:23:23.512425
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def test_Conditional_extract_defined_undefined(c, e):
        r = Conditional().extract_defined_undefined(c)
        if r != e:
            print("Conditional.extract_defined_undefined(%s) returned %s, expected %s" % (repr(c),repr(r),repr(e)))
            return False
        else:
            return True
    test1 = test_Conditional_extract_defined_undefined("foo is defined", [ ("foo", "is", "defined") ])
    test2 = test_Conditional_extract_defined_undefined(r"a_var is not defined and another_var is defined", [ ("a_var", "is not", "defined"), ("another_var", "is", "defined") ])
    test3 = test_Conditional_

# Generated at 2022-06-21 00:23:34.862233
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """Check if Conditional evaluate_conditional method works as expected."""

    # initialize
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    var_mgr = VariableManager()
    loader = DataLoader()
    loader.set_vault_password('ansible')

    def get_host_var(var):
        return var_mgr._fact_cache['all']['vars'].get(var)

    class TestClass(Conditional):
        pass

    test_obj = TestClass(loader=loader)

    # unit test

# Generated at 2022-06-21 00:23:36.862416
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c


# Generated at 2022-06-21 00:23:45.722589
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)
    play_context = PlayContext()

    # Test for undefined variable

# Generated at 2022-06-21 00:23:57.470669
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    res = cond.extract_defined_undefined('var is defined and not var2')
    assert (len(res) == 2)
    assert (res[0][0] == 'var')
    assert (res[0][1] == 'is')
    assert (res[0][2] == 'defined')
    assert (res[1][0] == 'var2')
    assert (res[1][1] == 'not is')
    assert (res[1][2] == 'defined')

    res = cond.extract_defined_undefined('var2 is undefined or var is defined')
    assert (len(res) == 2)
    assert (res[0][0] == 'var2')
    assert (res[0][1] == 'is')

# Generated at 2022-06-21 00:24:06.461838
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    p = PlayContext()
    p.vars = dict(a='foo', b='bar')
    t = Templar(loader=None, variables=p.vars)

    tests = [
        ('a == b', False),
        ('a == "foo"', True),
        ('a is defined', True),
        ('c is defined', False),
        ('a is not defined', False),
        ('c is not defined', True),
    ]
    c = Conditional()
    for test, expected in tests:
        c.when = test
        result = c.evaluate_conditional(t, p.vars)
        print('(%s) should be %s' % (test, expected))
        assert result == expected

# Generated at 2022-06-21 00:24:17.790028
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined(None) == []
    assert conditional.extract_defined_undefined('') == []
    assert conditional.extract_defined_undefined('foo') == []
    assert conditional.extract_defined_undefined('foo is defined') == []
    assert conditional.extract_defined_undefined('foo is defined and bar is defined') == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo is defined and bar is defined and baz is defined') == [('foo', 'is', 'defined'), ('bar', 'is', 'defined'), ('baz', 'is', 'defined')]

# Generated at 2022-06-21 00:24:27.983626
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.utils.vars import combine_vars

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.conditional import Conditional

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # This should raise an exception
    try:
        conditional = Conditional()
    except AnsibleError as e:
        print("Correctly raised exception: %s" % to_native(e))

    # This should work
    conditional = Conditional(loader=loader)

    # Conditional logic
    conditional.when = [ 'a == 1', 'a == 2' ]

# Generated at 2022-06-21 00:24:39.222193
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert sorted(cond.extract_defined_undefined("a is defined")) == [("a", "is", "defined")]
    assert sorted(cond.extract_defined_undefined("a is defined and \"a\" is defined and not b is defined and a is defined")) == [("a", "is", "defined"),("a", "is", "defined"),("b", "is", "defined"),("a", "is", "defined")]
    assert sorted(cond.extract_defined_undefined("not a is defined")) == [("a", "is", "defined")]
    assert sorted(cond.extract_defined_undefined("a is not defined")) == [("a", "is", "undefined")]

# Generated at 2022-06-21 00:24:45.203636
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # None tests
    assert not Conditional().extract_defined_undefined(None)
    # blank string
    assert not Conditional().extract_defined_undefined('')
    # simple empty string test
    assert not Conditional().extract_defined_undefined(' ')
    # test all logic operator combinations
    assert len(Conditional().extract_defined_undefined('a is defined and b is defined')) == 2
    assert len(Conditional().extract_defined_undefined('a is not defined or b is defined')) == 2
    assert len(Conditional().extract_defined_undefined('a is defined or b is defined')) == 2
    assert len(Conditional().extract_defined_undefined('a is not defined and b is defined')) == 2

    # test all 'is' combinations
    assert Conditional

# Generated at 2022-06-21 00:25:08.850617
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

# Generated at 2022-06-21 00:25:15.970919
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_variable('x', 10)
    variable_manager.set_variable('y', 20)
    variable_manager.set_variable('z', 'foo')
    variable_manager.set_variable('w', 'bar')

    t = Task()
    t.args = dict(when=["{{x}} == 10", "{{y}} is defined", "'foo' in {{z}}", "{{w}} is undefined"])
    t.when = t.args['when']
    t.post_validate(variable_manager=variable_manager, loader=None)

    assert isinstance(t.when, list)

# Generated at 2022-06-21 00:25:27.548888
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode  # pylint: disable=unused-variable
    from ansible.parsing.vault import VaultLib  # pylint: disable=unused-variable
    from ansible.parsing.vault import VaultSecret  # pylint: disable=unused-variable
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import get_all_plugin_loaders

    # Setup vault password
    vault_secrets = [('default', 'password')]

# Generated at 2022-06-21 00:25:28.279682
# Unit test for constructor of class Conditional
def test_Conditional():
    pass


# Generated at 2022-06-21 00:25:28.771836
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c

# Generated at 2022-06-21 00:25:39.335034
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

# Generated at 2022-06-21 00:25:44.349378
# Unit test for constructor of class Conditional
def test_Conditional():

    # Test without loader
    try:
        Conditional()
    except:
        pass
    else:
        assert False, "Failed to identify loader not provided"

    # Test with loader
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    Conditional(loader)


# Generated at 2022-06-21 00:25:55.620924
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    t = Task()
    result = t.extract_defined_undefined("abc is defined")
    assert result == [('abc', 'is', 'defined')]

    result = t.extract_defined_undefined("abc is not defined")
    assert result == [('abc', 'is not', 'defined')]

    result = t.extract_defined_undefined("abc is undefined")
    assert result == [('abc', 'is', 'undefined')]

    result = t.extract_defined_undefined("abc is not undefined")
    assert result == [('abc', 'is not', 'undefined')]

    result = t.extract_defined_undefined("abc is not undefined or abc is not defined")

# Generated at 2022-06-21 00:26:08.520562
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    Check if regex matches are found.
    '''
    conditional = Conditional()

# Generated at 2022-06-21 00:26:11.468326
# Unit test for constructor of class Conditional
def test_Conditional():
    # Test a Conditional object with a loader
    Conditional(loader=None)
    # Test a Conditional object with a ds
    Conditional(ds=None)

# Generated at 2022-06-21 00:26:46.347967
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert [] == cond.extract_defined_undefined(None)
    assert [] == cond.extract_defined_undefined('')
    assert [] == cond.extract_defined_undefined('foo')
    assert [] == cond.extract_defined_undefined('foo is undefined')

    assert [('foo', 'is', 'undefined')] == cond.extract_defined_undefined('foo is undefined')
    assert [('foo', 'is', 'undefined')] == cond.extract_defined_undefined('foo   is   undefined')
    assert [('foo', 'is', 'undefined')] == cond.extract_defined_undefined('foo is not defined')

# Generated at 2022-06-21 00:26:52.389802
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert Conditional().extract_defined_undefined(None) == []
    assert Conditional().extract_defined_undefined('') == []
    assert Conditional().extract_defined_undefined('foo') == []
    assert Conditional().extract_defined_undefined('foo bar') == []
    assert Conditional().extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert Conditional().extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert Conditional().extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert Conditional().extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]


# Generated at 2022-06-21 00:27:00.314071
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    conditional_string = '''
        a is undefined or
        not b is defined or
        (c is defined and d is not undefined) or
        (not e is not defined)
    '''
    result = [
        ['a', 'is', 'undefined'],
        ['b', 'not is', 'defined'],
        ['c', 'is', 'defined'],
        ['d', 'is not', 'undefined'],
        ['e', 'not is not', 'defined']
    ]
    assert result == conditional.extract_defined_undefined(conditional_string)


# Generated at 2022-06-21 00:27:06.850093
# Unit test for constructor of class Conditional
def test_Conditional():
    class TestConditional(Conditional):
        def __init__(self):
            super(TestConditional, self).__init__()

    tc = TestConditional()
    assert len(tc.when) == 0
    assert tc._validate_when('when', 'when', True) == None
    tc._validate_when('when', 'when', True)
    assert type(tc.when) == list
    assert tc.when == [True]
    assert hasattr(tc, 'when')
    assert tc._validate_when('when', 'when', None) == None
    assert tc.when == [None]

# Generated at 2022-06-21 00:27:13.806688
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class myConditional(Conditional):
        pass
    import os
    import sys
    import unittest

    class TestConditional(unittest.TestCase):
        def test_define_not_define(self):
            ConditionalObject = myConditional(loader=None)
            ConditionalObject._ds = None
            ConditionalObject._loader = None
            ConditionalObject.when = ['foo is defined and bar is not defined or baz is defined and '
                                      'faz is defined or foobar is defined and not foobaz is defined']
            # when:
            # - foo is defined
            #   and bar is not defined
            #   or baz is defined
            #     and faz is defined
            #   or foobar is defined
            #     and not foobaz is defined

# Generated at 2022-06-21 00:27:19.495408
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo not is defined") == [('foo', 'not is', 'defined')]
    assert conditional.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo not is undefined") == [('foo', 'not is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("foo is undefined and bar not is undefined") == [('foo', 'is', 'undefined'), ('bar', 'not is', 'undefined')]

# Generated at 2022-06-21 00:27:25.375962
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader

    # This should return a AnsibleError saying that a loader must
    # be specified when using Conditional() directly.
    try:
        c = Conditional()
    except AnsibleError as e:
        assert "a loader must be specified when using Conditional() directly" in str(e)
    else:
        raise Exception("should have raised an AnsibleError exception")

    # This should return a Conditional instance.
    c = Conditional(DataLoader())
    assert isinstance(c, Conditional)


# Generated at 2022-06-21 00:27:37.957879
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    ds = dict(
        name='foo',
        when=[
            'true',
            'true and false',
            'true and false and true',
            '1 == 1',
            '1 == 0',
            '1 == 1 and 2 == 2',
            '1 == 1 and 2 == 3',
            '1 == 0 or 2 == 2',
            '1 == 0 or 2 == 3',
            '1 == 0 or 2 == 2 or 3 == 3',
            '1 == 0 or 2 == 2 or 3 == 4',
            '1 == 0 or 2 == 3 or 3 == 3',
            '1 == 0 or 2 == 3 or 3 == 4',
        ]
    )


# Generated at 2022-06-21 00:27:43.184890
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    test_cases = dict()
    test_cases["1"] = [('ansible_user', 'is', 'defined')]
    test_cases["2"] = [('ansible_ips', 'is defined', 'defined')]
    test_cases["3"] = [('ansible_ips', 'is', 'not defined')]
    test_cases["4"] = [('ansible_ips', 'is', 'defined'), ('ansible_user', 'is not', 'defined')]
    test_cases["5"] = [('ansible_ips', 'is not', 'undefined')]

    test_cases["6"] = [('hostvars[host1]', 'is', 'defined')]
    test_cases["7"] = [('hostvars[host1]', 'is defined', 'defined')]

# Generated at 2022-06-21 00:27:43.999024
# Unit test for constructor of class Conditional
def test_Conditional():
    assert isinstance(Conditional(), Conditional)



# Generated at 2022-06-21 00:28:51.114972
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    pc = PlayContext()
    templar = Templar(loader=None, variables={})

    # Test for the handling of boolean results
    assert Conditional().evaluate_conditional(templar, dict(a=dict(b=True))) is True
    assert Conditional().evaluate_conditional(templar, dict(a=dict(b=False))) is False

    # Test for the handling of string results
    assert Conditional().evaluate_conditional(templar, dict(a=dict(b='True'))) is True
    assert Conditional().evaluate_conditional(templar, dict(a=dict(b='False'))) is False

# Generated at 2022-06-21 00:28:57.328610
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    task = Conditional()
    task._loader = DummyLoader()
    templar = DummyVars(task._loader)

    assert task.evaluate_conditional(templar, dict()) is True
    task._when = dict()
    assert task.evaluate_conditional(templar, dict()) is True
    task._when = []
    assert task.evaluate_conditional(templar, dict()) is True
    task._when = [None]
    assert task.evaluate_conditional(templar, dict()) is True
    task._when = [""]
    assert task.evaluate_conditional(templar, dict()) is True
    task._when = True
    assert task.evaluate_conditional(templar, dict()) is True
    task._when = False

# Generated at 2022-06-21 00:28:59.558684
# Unit test for constructor of class Conditional
def test_Conditional():
    assert hasattr(Conditional, 'evaluate_conditional')
    assert hasattr(Conditional, '_check_conditional')

# Generated at 2022-06-21 00:29:00.760600
# Unit test for constructor of class Conditional
def test_Conditional():
    assert(isinstance(Conditional, object))


# Generated at 2022-06-21 00:29:09.430722
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.plugins.loader import become_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars

    class Base(Conditional):
        def __init__(self):
            pass

    base = Base()
    templar = Templar(loader=DataLoader(), variables=VariableManager(), shared_loader_obj=False)
    become_loader.get('sudo').set_options({'become': True})
    become_loader.get('su').set_options({'become': True})

    # no when attributes set

# Generated at 2022-06-21 00:29:16.612509
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    "Test the method evaluate_conditional of class Conditional"
    # pylint: disable=import-error,no-name-in-module
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager

    t = Templar(loader=None, variables={})
    c = Conditional()

    # Test a simple true expression
    assert c.evaluate_conditional(t, dict(a=1, b=2, c=3))

    # Test a simple false expression
    assert not c.evaluate_conditional(t, dict(a=1, b=1, c=3))

    # Test a complex expression

# Generated at 2022-06-21 00:29:17.528288
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c.when is not None

# Generated at 2022-06-21 00:29:20.207518
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    conditional = Conditional()
    conditional.when = "{{ foo is defined }} and {{ bar is not defined }}"

    def_undef = conditional.extract_defined_undefined(conditional.when)
    assert def_undef == [('foo', 'is', 'defined'), ('bar', 'is not', 'defined')]


# Generated at 2022-06-21 00:29:22.436587
# Unit test for constructor of class Conditional
def test_Conditional():
    class TestClass(Conditional):
        pass
    tc = TestClass(loader=None)
    assert(tc._when == [])

# Generated at 2022-06-21 00:29:31.448324
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DataLoader()
    var_manager = VariableManager()
    inventory = InventoryManager(loader=loader)
    play_context = PlayContext()
    templar = Templar(loader=loader,
                      variables=var_manager,
                      loader_basedir='',
                      inventory=inventory,
                      play_context=play_context)
    new_conditional = Conditional(loader=loader)
    assert new_conditional is not None

# Generated at 2022-06-21 00:31:40.035414
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.plugins.loader import action_loader

    # Needs a path to a plugins/action/ subdir
    c = Conditional(loader=action_loader)
    assert isinstance(c, Conditional)

# Generated at 2022-06-21 00:31:51.112788
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext()

    # Mocks
    class MockTemplar:
        def template(self, data, **kwargs):
            return data

        def is_template(self, data):
            return True

        def environment(self):
            env = MockEnvironment()
            env.parse = lambda data, **kwargs: data
            return env

    class MockEnvironment:
        def __init__(self):
            pass

    # Tests
    conditional = Conditional()
    templar = MockTemplar()
    conditional.when = [True, False]
    assert conditional.evaluate_conditional(templar, play_context) == False
    conditional.when = [True, True]