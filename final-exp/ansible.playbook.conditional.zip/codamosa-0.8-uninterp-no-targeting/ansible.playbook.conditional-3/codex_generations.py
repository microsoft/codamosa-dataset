

# Generated at 2022-06-21 00:21:58.617649
# Unit test for constructor of class Conditional
def test_Conditional():
    pass

# Generated at 2022-06-21 00:22:02.695936
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader

    try:
        Conditional()
        raise Exception('Conditional() should have thrown an AnsibleError')
    except AnsibleError:
        pass

    cond = Conditional(loader=DataLoader())
    assert cond

# Generated at 2022-06-21 00:22:11.985597
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined("foo is not defined") == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined("foo is undefined") == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined("foo is not undefined") == [('foo', 'is not', 'undefined')]
    assert c.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-21 00:22:23.772362
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar

    variables = dict(a='a', b='b', c='c', d='d')

    # Set to True when test is done
    test_is_done = False

    class TestClass(Conditional):
        def __init__(self, templar=None, loader=None):
            self._ds = dict(a=1, b=2, c=3, d=4)
            super(TestClass, self).__init__(loader=loader)

    # Test is done here. Check result
    def test_is_done():
        assert test_class.evaluate_conditional(templar, variables) is True

    # Create test object
    test_class = TestClass(Templar(variables=variables))
    templar = Templar(variables=variables)

    #

# Generated at 2022-06-21 00:22:33.441347
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-21 00:22:35.545987
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c._when == [], "_when not set to default value"

# Generated at 2022-06-21 00:22:47.174720
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.base import Base

    from ansible.template import Templar

    from ansible import constants as C
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.vars.hostvars import HostVars

    import jinja2

    class MyVars(dict):

        def __init__(self, *args, **kwargs):
            super(MyVars, self).__init__(*args, **kwargs)
            self.update(dict(
                foo='bar',
                baz=dict(
                    one='two'
                ),
            ))

    class MyTask(Base, Conditional):
        pass

    my_vars = MyVars()

    class MyHostVars(HostVars):

        def _get_vars(self, host):
            self._vars

# Generated at 2022-06-21 00:22:52.574708
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext

    # Data
    conditional_obj = Conditional()
    new_loader = None
    play_context = PlayContext()

    # Test
    conditional_obj.Runner(new_loader, play_context)

    # Post-conditions
    assert True


# Generated at 2022-06-21 00:22:57.512791
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = 'not hostvars[inventory_hostname]["a"] is defined '
    conditional += 'or hostvars[inventory_hostname]["a"] is not defined'
    expected = [('hostvars[inventory_hostname]["a"]', 'not is', 'defined'),
                ('hostvars[inventory_hostname]["a"]', 'is not', 'defined')]
    assert expected == Conditional().extract_defined_undefined(conditional)


# Generated at 2022-06-21 00:23:00.015508
# Unit test for constructor of class Conditional
def test_Conditional():
    class MyClass(Conditional):
        pass

    mc = MyClass()

if __name__ == '__main__':
    test_Conditional()

# Generated at 2022-06-21 00:23:08.426427
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional(loader=None)
    assert conditional._when == list


# Generated at 2022-06-21 00:23:19.082446
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    conditional_obj = Conditional()

    # test undefined variable
    conditional_obj.when = ['foo is defined']
    play_context_obj = PlayContext()
    play_context_obj.prompt = 'None'
    play_obj = Play().load(dict(name='test_play', hosts='localhost', gather_facts='no'), loader=None, variable_manager=None)
    result = conditional_obj.evaluate_conditional(templar=play_obj._variable_manager.extra_vars_loader, all_vars=play_context_obj.get_vars(play=play_obj))
    assert(result == False)

    # test defined variable
    conditional_obj.when = ['foo is defined']


# Generated at 2022-06-21 00:23:25.193870
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def test_extract_defined_undefined(text, expected_output):
        module = Conditional()
        result = module.extract_defined_undefined(text)
        assert result == expected_output,\
            "extract_defined_undefined returned incorrect results."\
            "Expected: {0} Result: {1}".format(expected_output, result)

    test_extract_defined_undefined(
        "foo is undefined",
        [('foo', 'is', 'undefined')]
    )
    test_extract_defined_undefined(
        "foo is not defined",
        [('foo', 'is not', 'defined')]
    )
    test_extract_defined_undefined(
        "foo is defined",
        [('foo', 'is', 'defined')]
    )
   

# Generated at 2022-06-21 00:23:36.582350
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    playbook_path='tests/test_conditional.yaml'

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='/dev/null')

    variable_manager.set_inventory(inventory)
    variable_manager.extra_vars = {'foo': 'bar'}

    pbex = PlaybookExecutor(playbooks=[playbook_path], inventory=inventory, variable_manager=variable_manager, loader=loader)
    results = pbex.run()

# Generated at 2022-06-21 00:23:43.820171
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    Unit test for method extract_defined_undefined of class Conditional
    '''
    conditional = Conditional()

    def test_function(test_string, expected_result):
        '''
        Test method with string from arg test_string and compares result with result from arg
        expected_result.
        Print test results.
        '''

        result = conditional.extract_defined_undefined(test_string)
        if result == expected_result:
            display.display(u"PASS: %s" % test_string)
        else:
            display.display(u"FAIL: %s" % test_string)
            display.display(u"\t Expected: %s" % expected_result)
            display.display(u"\t Got: %s" % result)


# Generated at 2022-06-21 00:23:45.465223
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional(loader=None)
    assert c is not None
    assert c._loader is None



# Generated at 2022-06-21 00:23:57.225832
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    ModuleArgs = conditional_argument_spec()
    module = AnsibleModule(argument_spec=ModuleArgs, supports_check_mode=False)
    module.init_tmp_path()
    module.exit_json(changed=False)

    class ConditionalTest(Conditional):
        def __init__(self, loader):
            self.when = {
                'wrong_type': "defined",
                'test_true': "True",
                'test_false': "hostvar == 'hostvar'",
                'test_undefined': "somevar == 'somevalue'",
            }
            self._loader = loader

    # test call with undefined variable
    display.verbosity = 0

    all_vars = dict()
    class DummyLoader:
        def get_basedir(self):
            return "/"

    test = Conditional

# Generated at 2022-06-21 00:24:06.303024
# Unit test for constructor of class Conditional
def test_Conditional():
    def test_method():
        ''' Test docstring '''
        print("test_method() called")

    def test_method_with_args(arg1, arg2):
        ''' Test docstring '''
        print("test_method_with_args(" + arg1 + ", " + arg2 + ") called")


# Generated at 2022-06-21 00:24:07.856188
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional._when == list()

# Generated at 2022-06-21 00:24:19.218802
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    obj = Conditional()

# Generated at 2022-06-21 00:24:36.066824
# Unit test for constructor of class Conditional
def test_Conditional():
    test_obj = Conditional()
    assert isinstance(test_obj,Conditional)

# Generated at 2022-06-21 00:24:37.475401
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert(conditional._when == [])


# Generated at 2022-06-21 00:24:46.955720
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    class FakeRunner:
        def __init__(self):
            self.hostvars = {}
            self.hostvars['host1'] = {'X': 'A'}
            self.hostvars['host2'] = {'X': 'B'}

    class FakePlaybook:
        def __init__(self):
            self.extra_vars = {}
            self.extra_vars['X'] = 'C'
            self.extra_vars['Y'] = 'D'

        def set_variable_manager(self, var_manager):
            self.variable_manager = var_manager

    class FakeOptions:
        def __init__(self):
            self.module_path = None

    def mock_loader(module_name):
        def amodule():
            pass

# Generated at 2022-06-21 00:24:58.171301
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    class TestClass(Conditional):
        def __init__(self, loader):
            super(TestClass, self).__init__(loader)
            self.when = [
                AnsibleUnsafeText('1 + 1 == 2'),
                AnsibleVaultEncryptedUnicode('2 + 2 == 5'),
                '2 + 2 == 4',
                '1 + 1 != 2'
            ]
    loader = None
    test_obj = TestClass(loader)
    templar = Templar(loader=loader)
    all_vars = dict()

# Generated at 2022-06-21 00:25:08.310455
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test that instantiating the class and setting a variable works
    conditional = Conditional(loader=loader)
    conditional.when = [ "a=1" ]

    # test that evaluation of _check_conditional works
    assert conditional._check_conditional("a==1", variable_manager.template_class, variable_manager.get_vars())

# Generated at 2022-06-21 00:25:15.678997
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    loader = DummyLoader()
    display = DummyDisplay()
    templar = MockTemplar(loader=loader, display=display)


# Generated at 2022-06-21 00:25:27.357906
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    Test the Conditional.extract_defined_undefined method
    '''
    # example of valid conditional
    # with defined and undefined tests
    cond = '''"hostname" == {{ ansible_hostname }} and \
{{inventory_hostname}} in groups['webservers']\
and ( hostvars[inventory_hostname]['ansible_devices']['/dev/sda']['sectors'] \
is not defined or hostvars[inventory_hostname]['ansible_devices']['/dev/sda']['sectors'] < 20971520 )'''
    # we expect

# Generated at 2022-06-21 00:25:29.170363
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.task import Task
    t = Task()
    assert t.when == []

# Generated at 2022-06-21 00:25:38.244884
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    my_var = dict(foo='bar')
    variable_manager = VariableManager()
    variable_manager.set_variable("test_var", my_var)
    all_vars = variable_manager.get_vars(play=None)

    templar = Templar(loader=None, variables=all_vars)

    # Check if isinstance return False and evaluate_conditional return False
    test_obj = Conditional()
    assert test_obj.evaluate_conditional(templar, all_vars) is False

    # Check if isinstance return True and evaluate_conditional return False
    test_obj = Conditional()
    test_obj._when = "{{ test_var.foo == 'bar' }}"
    assert test_obj.evaluate

# Generated at 2022-06-21 00:25:49.683202
# Unit test for constructor of class Conditional
def test_Conditional():
    '''
    Unit test for constructor of class Conditional
    '''
    import yaml
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader

    # FIXME: this should really be a mock of a loader so we can verify it returns
    # the right things

    # test normal creation using an existing loader
    with open("test/test_conditionals.yml", 'r') as test_fd:
        test_data = yaml.load(test_fd, Loader=AnsibleLoader)

    conditional = test_data[0]
    assert isinstance(conditional, Conditional)

    # test normal creation using a passed-in loader
    loader = AnsibleLoader(None, None)
    conditional = Conditional.load

# Generated at 2022-06-21 00:26:28.438864
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    test = 'a is defined and b is defined'
    assert cond.extract_defined_undefined(test) == [('a', 'is', 'defined'), ('b', 'is', 'defined')]

    test = 'a is defined'
    assert cond.extract_defined_undefined(test) == [('a', 'is', 'defined')]

    test = 'a not is defined or b is undefined or c not is undefined'
    assert cond.extract_defined_undefined(test) == [('a', 'not is', 'defined'), ('b', 'is', 'undefined'), ('c', 'not is', 'undefined')]

    test = ''
    assert cond.extract_defined_undefined(test) == []

    test = 'a is defined and b is defined and something else'
   

# Generated at 2022-06-21 00:26:32.641319
# Unit test for constructor of class Conditional
def test_Conditional():
    """
    This function will test basic constructor for class Conditional.
    """
    conditional = Conditional()
    assert conditional._when == []
    assert conditional.environment == None
    assert conditional.globals == None
    assert conditional.loader == None
    del conditional


# Generated at 2022-06-21 00:26:37.366270
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader

    d = DataLoader()
    c = Conditional(loader=d)

    c.when = "this is a test"
    assert c.when == ['this is a test']

    c.when = "this is another test"
    assert c.when == ['this is a test', 'this is another test']

# Generated at 2022-06-21 00:26:45.875384
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Create a dummy loader and default shared templar
    loader = DictDataLoader({})

    # pylint: disable=protected-access
    shared_templar = loader._shared_loader_obj.templar

    class Object(Conditional):

        def __init__(self):
            self._loader = loader
            self._templar = shared_templar

    # Create a dummy host object
    host = DictDataLoader({
        'vars': {'var1': 'value1', 'var2': 'value2'}
    })

    # Create a dummy task object
    task = Object()

# Generated at 2022-06-21 00:26:51.981159
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    vars = VariableManager()
    vars.extra_vars = dict(
        a=5,
        b='foo',
        c=[1, 2, 3],
    )

    templar = Templar(loader=None, variables=vars)
    cond = Conditional(loader=None)


# Generated at 2022-06-21 00:26:53.534517
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional._when == []
    conditional = Conditional(loader=1)
    assert conditional._when == []


# Generated at 2022-06-21 00:27:03.703897
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    display = Display()


# Generated at 2022-06-21 00:27:08.678499
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.task_include import TaskInclude

    ti = TaskInclude()
    assert ti.evaluate_conditional(None, None), "conditional should be true by default"

    ti.when = []
    assert ti.evaluate_conditional(None, None), "conditional should be true with empty when"

    ti.when = ["asdf"]
    assert not ti.evaluate_conditional(None, None), "conditional should be false with invalid when"

# Generated at 2022-06-21 00:27:15.247361
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import sys
    import ansible.playbook.play
    import ansible.template
    import ansible.vars

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class MockVariableManager():
        def __init__(self):
            self.vars = ansible.vars.VariableManager()
            ansible.vars.VariableManager.__init__(self.vars)
            self._extra_vars = {}
            self.vars_files = []
            self.inventory = None
            self.all_vars = dict()
            self.all_vars['inventory_hostname'] = 'testhost'

    class TestConditional(unittest.TestCase):

        def setUp(self):
            self.play

# Generated at 2022-06-21 00:27:19.251502
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert isinstance(conditional, Conditional)


# Generated at 2022-06-21 00:28:23.739115
# Unit test for constructor of class Conditional
def test_Conditional():
    a = Conditional()
    assert a._when is not None

# Generated at 2022-06-21 00:28:25.234839
# Unit test for constructor of class Conditional
def test_Conditional():
    assert Conditional()

# Generated at 2022-06-21 00:28:30.493703
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager._fact_cache['foo'] = "bar"
    variable_manager._fact_cache['a'] = 1
    variable_manager._fact_cache['b'] = 0
    variable_manager._fact_cache['c'] = 2
    variable_manager._fact_cache['d'] = 3.14
    variable_manager._fact_cache['e'] = (1, 2, 3)
    variable_manager._fact_cache['f'] = (1, 2)
    variable_manager._fact_cache['g'] = ['foo', 'bar']
    variable_manager._fact

# Generated at 2022-06-21 00:28:40.045782
# Unit test for constructor of class Conditional
def test_Conditional():
    import json
    from copy import copy
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar', 'asdf': 1234, 'products': ['apples', 'oranges']}
    c = Conditional(loader=loader)

    assert c.when is None
    assert c.when_value(variable_manager) == []

    c.when = 'foo and asdf'
    assert c.when == ['foo and asdf']
    assert c.when_value(variable_manager) == ['foo and asdf']
    assert c.evaluate_conditional(variable_manager) is True

    c2 = copy(c)
    assert c2

# Generated at 2022-06-21 00:28:48.611333
# Unit test for constructor of class Conditional

# Generated at 2022-06-21 00:28:52.624198
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('foo is defined and bar is not defined and '
                                       'and baz is defined') == [('foo', 'is', 'defined'), ('bar', 'is not', 'defined'),
                                                                 ('baz', 'is', 'defined')], "Unexpected matches"
    assert c.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')], "Unexpected matches"


# Generated at 2022-06-21 00:29:01.896830
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # noinspection PyUnresolvedReferences
    assert [('v1', 'not is', 'defined')] == Conditional().extract_defined_undefined('v1 not is defined')
    # noinspection PyUnresolvedReferences
    assert [('v1', 'is', 'defined')] == Conditional().extract_defined_undefined('v1 is defined')
    # noinspection PyUnresolvedReferences
    assert [('v1', 'is', 'undefined')] == Conditional().extract_defined_undefined('v1 is undefined')
    # noinspection PyUnresolvedReferences
    assert [('v1', 'is not', 'undefined')] == Conditional().extract_defined_undefined('v1 is not undefined')
    # noinspection PyUnresolvedReferences

# Generated at 2022-06-21 00:29:08.195033
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    # first test the when constructor
    conditional_when = Conditional(when="something")
    assert conditional_when._when == ["something"]
    conditional_when = Conditional(when=["something", "else"])
    assert conditional_when._when == ["something", "else"]
    conditional_when = Conditional(when=set(["something", "else"]))
    assert conditional_when._when == set(["something", "else"])
    conditional_when = Conditional(when=("something", "else"))
    assert conditional_when._when == ["something", "else"]

# Generated at 2022-06-21 00:29:15.578149
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    pc = PlayContext()
    templar = Templar(loader=None, variables=dict())

    conditional = Conditional(loader=None)
    conditional._ds = dict(when=None)
    assert conditional.when is None

    conditional.when = ['ansible_distribution', 'CentOS']
    conditional._ds = None
    assert conditional.when == [['ansible_distribution', 'CentOS']]

    conditional.when = ['ansible_distribution', 'CentOS']
    conditional.when = ['ansible_distribution', 'Ubuntu']
    assert conditional.when == [['ansible_distribution', 'CentOS'], ['ansible_distribution', 'Ubuntu']]


# Generated at 2022-06-21 00:29:18.942405
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert [('ansible_distribution', 'is not', 'undefined')] == Conditional().extract_defined_undefined("(ansible_distribution is not undefined)")
    assert [('ansible_distribution', 'is not', 'undefined'), ('ansible_distibution_version', 'is', 'undefined')] == Conditional().extract_defined_undefined("(ansible_distribution is not undefined) and (ansible_distibution_version is undefined)")