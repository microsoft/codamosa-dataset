

# Generated at 2022-06-21 00:22:09.489202
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = "foo is defined and (not bar is defined or foobar is defined and barfoo not is undefined)"
    cond1 = "bar foo is defined"
    cond2 = "bar is defined foo"
    cond3 = "foo is defined not bar"
    cond4 = "foo is defined and not bar"
    cond5 = "foo is not defined"
    cond6 = "foo is defined and bar not is defined"
    cond7 = "foo is defined is bar"
    cond8 = "foo is defined is not bar"
    cond9 = "foo is defined and foobar is undefined"
    cond10 = "foo is defined not baz is defined and foobar not is undefined"
    cond11 = "foo is defined and baz is defined or foobar is undefined"
    cond12 = "foo is defined or bar not is defined or foobar is undefined"

# Generated at 2022-06-21 00:22:16.034404
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Simple test of method extract_defined_undefined
    # of class Conditional
    # without the use of ansible in a playbook context
    cond = Conditional()
    conditional = "{{ xxx is defined and yyy is not defined }}"
    res = cond.extract_defined_undefined(conditional)
    res_expected = [("xxx", "is", "defined"), ("yyy", "is not", "defined")]
    assert res_expected == res


# Generated at 2022-06-21 00:22:27.938351
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert cond.extract_defined_undefined('hostvars[inventory_hostname] is not defined') == [('hostvars[inventory_hostname]', 'is not', 'defined')]
    assert cond.extract_defined_undefined('hostvars[inventory_hostname] is undefined') == [('hostvars[inventory_hostname]', 'is', 'undefined')]
    assert cond.extract_defined_undefined('hostvars[inventory_hostname] is not undefined') == [('hostvars[inventory_hostname]', 'is not', 'undefined')]
    assert cond.extract

# Generated at 2022-06-21 00:22:35.575956
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestConditional(object):
        def __init__(self):
            self.when = []
            self.when_result = None
            self._loader = None
            self._ds = None
        def __repr__(self):
            return repr(self.__class__)
        def set(self, when):
            self.when = when
            self.when_result = self.evaluate_conditional(self._loader.loaders[0].get_basedir(), {})
        def get(self):
            return self.when_result
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from jinja2 import Environment, meta, lexer
    from jinja2.parser import Pars

# Generated at 2022-06-21 00:22:43.637349
# Unit test for constructor of class Conditional
def test_Conditional():
    import sys
    import StringIO

    # Test of conditional inheritance without loader set
    out = StringIO.StringIO()
    try:
        sys.stderr = out
        ansible.playbook.conditional.Conditional()
    except:
        # This is the expected exception
        print("passed")
    finally:
        sys.stderr = sys.__stderr__

    # Test of conditional inheritance with loader set
    c = ansible.playbook.conditional.Conditional(ansible.playbook.loader.Loader())
    print("passed")


# Generated at 2022-06-21 00:22:55.100990
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestObject:
        # This is an invalid test class, since it doesn't extend or implement Conditional or Base,
        # but it works here for simple unit testing via the function below
        pass

    class TestTemplar:
        def __init__(self):
            self.all_vars = {
                'var1': 'foo',
                'var2': 'bar',
                'var3': 42,
                'var4': False,
                'var5': [1, 2, 3, 4],
                'var6': {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'},
                'var7': {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
            }

# Generated at 2022-06-21 00:22:57.280866
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert hasattr(conditional, '_when')
    assert isinstance(conditional._when, list)

# Generated at 2022-06-21 00:23:08.453997
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-21 00:23:12.326425
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

# Generated at 2022-06-21 00:23:21.910192
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    try:
        from ansible.parsing.dataloader import DataLoader
        from ansible.vars import VariableManager
        from ansible.inventory.manager import InventoryManager
    except ImportError:
        raise SkipTest("conditional tests require ansible>=v2.4")

    from ansible.playbook.play import Play
    from ansible.plugins.strategy import StrategyBase

    class ModuleUtilsTest(object):
        def __init__(self):
            pass

        def _load_params(self):
            return dict()

        def _load_name(self):
            return "test"

        def _has_error(self):
            return False

        def _load_fail_json(self):
            pass

    class ModuleTest(object):
        def __init__(self):
            self.params = Module

# Generated at 2022-06-21 00:23:39.920223
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
        Test module Conditional.extract_defined_undefined
        Test success conditions, return values and errors
    '''

    def test_string(conditional, result):
        # construct a conditional object, to run the test
        c = Conditional()

        # run the test, compare the result
        if result != c.extract_defined_undefined(conditional):
            print("Test failed for string: %s" % conditional)
            return False

        # test passed
        return True

    # strings to test, result is always a list

# Generated at 2022-06-21 00:23:49.529562
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """
    Test method evaluate_conditional of class Conditional.
    """
    class TestClassInheritingConditional(Conditional):
        """
        Test class inheriting Conditional.
        """
        def __init__(self, loader, test_vars):
            self.when = ['foo', 'bar']
            self._loader = loader
            super(TestClassInheritingConditional, self).__init__()

# Generated at 2022-06-21 00:24:01.376701
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-21 00:24:08.551478
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

    conditional = "blah1 is defined and blah2 is undefined and blah3 is defined"
    expected = [('blah1', 'is', 'defined'), ('blah2', 'is', 'undefined'), ('blah3', 'is', 'defined')]
    result = c.extract_defined_undefined(conditional)
    assert result == expected

    conditional = "blah1 not is defined or blah2 not is undefined or blah3 not is defined"
    expected = [('blah1', 'not is', 'defined'), ('blah2', 'not is', 'undefined'), ('blah3', 'not is', 'defined')]
    result = c.extract_defined_undefined(conditional)
    assert result == expected


# Generated at 2022-06-21 00:24:20.200313
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('a and b') == []
    assert c.extract_defined_undefined('a and b and hostvars["x"] is defined') == [('hostvars["x"]', 'is', 'defined')]
    assert c.extract_defined_undefined('a and b and hostvars["x"] not is defined') == [('hostvars["x"]', 'not is', 'defined')]
    assert c.extract_defined_undefined('a and b and hostvars["x"] not is undefined') == [('hostvars["x"]', 'not is', 'undefined')]

# Generated at 2022-06-21 00:24:21.001077
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()

# Generated at 2022-06-21 00:24:29.746289
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    loader = DictDataLoader()
    variable_manager = VariableManager(loader=loader)
    templar = Templar(loader=loader, variable_manager=variable_manager)
    variable_manager.set_host_variable('test_host', {'foo': 'bar', 'bar': 'baz'})
    variable_manager.set_host_variable('test_host', {'baz': 'foo'})
    variable_manager.set_host_variable('test_host', {'qux': 'quux'})
    variable_manager.set_host_variable('test_host', {'other': 'foo'})


# Generated at 2022-06-21 00:24:40.446935
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    conditional = Conditional()

    # Test False case
    conditional.when = "item == 'test'"
    templar = Templar(loader=None, variables=VariableManager())

    res = conditional.evaluate_conditional(templar, dict(item='foo'))
    assert res == False

    # Test True case
    res = conditional.evaluate_conditional(templar, dict(item='test'))
    assert res == True

    # Test True case with non-string values
    conditional.when = "item == False"
    res = conditional.evaluate_conditional(templar, dict(item=False))
    assert res == True

    conditional.when = "item and True"

# Generated at 2022-06-21 00:24:48.943110
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    cond = Conditional()
    assert cond.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert cond.extract_defined_undefined('foo not is undefined') == [('foo', 'not is', 'undefined')]
    assert cond.extract_defined_undefined('foo not is undefined and bar is not defined') == [('foo', 'not is', 'undefined'), ('bar', 'is not', 'defined')]
    assert cond.extract_defined_undefined('foo not is undefined or bar is not defined') == [('foo', 'not is', 'undefined'), ('bar', 'is not', 'defined')]

# Generated at 2022-06-21 00:25:00.659184
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

# Generated at 2022-06-21 00:25:25.149841
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    # Test Extract of defined
    defineds = conditional.extract_defined_undefined("defined")
    assert len(defineds) == 1
    assert defineds[0][0] == ""
    assert defineds[0][1] == "is"
    assert defineds[0][2] == "defined"
    # Test Extract of defined using variable
    defineds = conditional.extract_defined_undefined("hostvars['ansible_default_ipv4'].ipv4")
    assert len(defineds) == 1
    assert defineds[0][0] == "hostvars['ansible_default_ipv4'].ipv4"
    assert defineds[0][1] == "is"
    assert defineds[0][2] == "defined"
    # Test Extract of defined with spaces

# Generated at 2022-06-21 00:25:35.495870
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # TODO: need a way to introspect methods from __init__ which only instantiates a mixin
    # class Conditional_test(Conditional):
    #     def __init__(self):
    #         Conditional.__init__(self)

    assert Conditional(None)._check_conditional('1 == 1', None, {})

    # Evaluate condition with a defined variable
    assert Conditional(None)._check_conditional('unix_var == "unix val"', None, {'unix_var': 'unix val'})

    # Evaluate condition with a undefined variable
    assert not Conditional(None)._check_conditional('unix_var == "unix val"', None, {'unix_var': 'unix value'})

    # Evaluate a condition with undefined variable and check for 'not defined'

# Generated at 2022-06-21 00:25:45.068059
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Predefine parameters
    conditional = 'not (a is undefined or b is undefined or c is undefined) or var_one is defined'

    # Define class
    c = Conditional()

    # Define expected result
    expected_result = [('a', 'is', 'undefined'), ('b', 'is', 'undefined'), ('c', 'is', 'undefined'), ('var_one', 'is', 'defined')]

    # Call function and test result
    result = c.extract_defined_undefined(conditional)
    assert result == expected_result, "extract_defined_undefined returned %s but expected %s" % (result, expected_result)


# Generated at 2022-06-21 00:25:46.777661
# Unit test for constructor of class Conditional
def test_Conditional():
    p = Conditional()
    assert(p)


# Generated at 2022-06-21 00:25:48.210380
# Unit test for constructor of class Conditional
def test_Conditional():
    # Conditional is a mix-in class, so nothing to test here
    pass

# Generated at 2022-06-21 00:25:58.290725
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]
    assert conditional.extract_defined_undefined("foo is undefined or bar is not defined") == [('foo', 'is', 'undefined'), ('bar', 'not is', 'defined')]
    assert conditional.extract_defined_undefined("foo is defined or bar is not defined") == [('foo', 'is', 'defined'), ('bar', 'not is', 'defined')]
    assert conditional.extract_defined_undefined("foo is not defined or bar is not defined") == [('foo', 'not is', 'defined'), ('bar', 'not is', 'defined')]

# Generated at 2022-06-21 00:26:02.253483
# Unit test for constructor of class Conditional
def test_Conditional():
    cond_obj = Conditional()
    assert cond_obj.when == []
    cond_obj = Conditional(loader=123)
    assert cond_obj._loader == 123


# Generated at 2022-06-21 00:26:03.353343
# Unit test for constructor of class Conditional
def test_Conditional():
    obj = Conditional()
    assert obj._when == []

# Generated at 2022-06-21 00:26:14.800265
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    v = VariableManager()
    t = Templar(vars=v, loader=None)
    t2 = Templar(vars=v, loader=None)
    t.available_variables = dict()

    # we populate the variable manager with variables for testing purposes
    v.extra_vars = dict(a=1, b="string", c=dict(a=1, b=2), d=[1, 2, 1], e=[dict(a=1, b=2), dict(a=3, b=4)], f=[1, 2, 3])
    t2.available_variables = v.extra_vars

    # we define a dummy class, which inherits from Conditional and Base, to test evaluate_conditional on

# Generated at 2022-06-21 00:26:23.311081
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestConditional(Conditional):
        def __init__(self, when):
            self.when = when
            self._loader = None
            self._ds = None

    t = TestConditional(["'a' in groups"])

    # If groups is not defined, using the vars will not contains groups,
    # and so the conditional will be evaluated to False
    assert t.evaluate_conditional(None, {}) is False

    # If groups is defined, but does not contains 'a', the conditional is
    # evaluated to False
    assert t.evaluate_conditional(None, {"groups": ["b", "c"]}) is False

    # If groups is defined, and contains 'a', the conditional is evaluated
    # to True
    assert t.evaluate_conditional(None, {"groups": ["a", "b"]}) is True




# Generated at 2022-06-21 00:27:04.935126
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook import Play

    pb = Play()
    pb.vars = dict(foo='bar')

    # Test empty
    assert pb.extract_defined_undefined('') == []

    # Test single condition
    assert pb.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]

    # Test multiple single conditions
    assert pb.extract_defined_undefined('foo is defined and bar is defined and baz is defined') == [('foo', 'is', 'defined'), ('bar', 'is', 'defined'), ('baz', 'is', 'defined')]

    # Test invalid conditions
    assert pb.extract_defined_undefined('foo is defined or') == [('foo', 'is', 'defined')]
    assert pb.extract

# Generated at 2022-06-21 00:27:12.429971
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DictDataLoader({
        "foo.yml": """
        - hosts: localhost
          tasks:
            - debug:
                msg: "{{ result }}"
              when: result
        """,
    })

    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    results = {'localhost': 'localhost'}
    variable_manager._hostvars = {'localhost': results}

    c = Conditional()
    setattr(c, '_loader', DataLoader())

# Generated at 2022-06-21 00:27:15.284515
# Unit test for constructor of class Conditional
def test_Conditional():
    class TestClass(Conditional):
        pass

    try:
        instance = TestClass()
        assert False, 'Instance of Conditional should raise an exception without a loader'
    except AnsibleError:
        pass

    instance = TestClass(loader=None)
    assert True, 'Instance of Conditional should not raise an exception with a loader'

# Generated at 2022-06-21 00:27:25.053670
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class TestConditional(Conditional):
        pass
    conditional = TestConditional()

    # test various cases
    # 0. test empty string
    assert not conditional.extract_defined_undefined("")

    # 1. test no conditional
    assert not conditional.extract_defined_undefined("hostvars['foo'] == 'bar'")

    # 2. test undefined
    assert conditional.extract_defined_undefined("hostvars['foo'] is undefined") == [("hostvars['foo']", 'is', 'undefined')]

    # 3. test defined with whitespace
    assert conditional.extract_defined_undefined("hostvars['foo']\tis\tdefined") == [("hostvars['foo']", 'is', 'defined')]

    # 4. test not defined
    assert conditional.extract_defined_

# Generated at 2022-06-21 00:27:37.100115
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-21 00:27:39.648573
# Unit test for constructor of class Conditional
def test_Conditional():
    # Test Constructor
    test_loader = object()
    test_conditional = Conditional(loader=test_loader)

    assert(test_conditional._loader == test_loader)


# Generated at 2022-06-21 00:27:48.073183
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    obj = Conditional()
    assert obj.extract_defined_undefined('') == []
    assert obj.extract_defined_undefined('"foo" is defined') == [('"foo"', 'is', 'defined')]
    assert obj.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert obj.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert obj.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert obj.extract_defined_undefined('foo is not defined and bar is not undefined') == [('foo', 'is not', 'defined'), ('bar', 'is not', 'undefined')]
    assert obj

# Generated at 2022-06-21 00:27:51.315353
# Unit test for constructor of class Conditional
def test_Conditional():
    """
    For testing:
    python -c 'import ansible.playbook.conditional; ansible.playbook.conditional.test_Conditional()'
    """
    Conditional(loader=None)



# Generated at 2022-06-21 00:28:01.870260
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

# Generated at 2022-06-21 00:28:11.060958
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager.set_inventory(inventory)

    conditional = Conditional(loader=loader)

    # test with an invalid when
    conditional.when = 3
    conditional._validate_when(conditional.when, 'when', conditional.when)
    assert conditional.when == [3]
    conditional.when = None
    conditional._validate_when(conditional.when, 'when', conditional.when)
    assert conditional.when == [None]

    # test with a valid when

# Generated at 2022-06-21 00:29:36.822216
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext

    def test(conditional, all_vars, should_evaluate):
        test_obj = Conditional()
        test_obj.when = [conditional, ]

        loader = DataLoader()
        variable_manager = VariableManager()
        play_context = PlayContext()
        templar = Templar(
            loader=loader,
            variables=variable_manager,
            shared_loader_obj=loader,
            template_path=[C.DEFAULT_TEMPLATE_PATH],
            playcontext=play_context
        )

# Generated at 2022-06-21 00:29:43.609776
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    class MockLoader(object):
        pass

    class MockTemplar(object):
        def template(self, data, **kwargs):
            return data


# Generated at 2022-06-21 00:29:51.712037
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()

    # Test 'when' field
    assert conditional._when == []
    assert conditional.when == []

    conditional.when = ['1 == 2']
    assert conditional._when == ['1 == 2']
    assert conditional.when == ['1 == 2']

    conditional.when = '1 == 2'
    assert conditional._when == ['1 == 2']
    assert conditional.when == ['1 == 2']


# Generated at 2022-06-21 00:29:59.773051
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
  from units.mock.loader import DictDataLoader

  loader = DictDataLoader({})
  conditional = Conditional(loader=loader)


# Generated at 2022-06-21 00:30:10.189591
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    # syntax error
    c = Conditional()
    assert c.evaluate_conditional(Templar(loader=DictDataLoader()), dict()) == False

    # false
    c = Conditional()
    c.when = set(['false'])
    assert c.evaluate_conditional(Templar(loader=DictDataLoader()), dict()) == False

    # true
    c = Conditional()
    c.when = set(['true'])
    assert c.evaluate_conditional(Templar(loader=DictDataLoader()), dict()) == True

    # defined
    c = Conditional()
    c.when = set(['foo is defined'])
    assert c.evaluate_conditional(Templar(loader=DictDataLoader()), dict()) == False
    assert c

# Generated at 2022-06-21 00:30:21.460143
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Object of class Conditional
    conditional = Conditional()
    # Conditionals that host is defined
    conditional_1 = "host is defined"
    # Conditionals that host is not defined
    conditional_2 = "host is not defined"
    # Conditionals that hostvars['hostname'] is defined
    conditional_3 = "hostvars['hostname'] is defined"
    # Conditionals that hostvars['hostname'] is not defined
    conditional_4 = "hostvars['hostname'] is not defined"
    # Conditionals that hostname is undefined
    conditional_5 = "hostname is undefined"
    # Conditionals that hostvars['hostname'] is undefined
    conditional_6 = "hostvars['hostname'] is undefined"
    # Conditionals that hostvars['hostname'] is undefined and hostname is undefined
    conditional

# Generated at 2022-06-21 00:30:31.886860
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined('hostvars[inventory_hostname] is undefined') == [('hostvars[inventory_hostname]', 'is', 'undefined')]
    assert cond.extract_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert cond.extract_defined_undefined('hostvars[inventory_hostname] not is defined') == [('hostvars[inventory_hostname]', 'not is', 'defined')]
    assert cond.extract_defined_undefined('hostvars[inventory_hostname] not is undefined') == [('hostvars[inventory_hostname]', 'not is', 'undefined')]

    assert cond.extract

# Generated at 2022-06-21 00:30:42.970164
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    def test(text, expected_result):
        result = Conditional.extract_defined_undefined(Conditional(), text)
        if result != expected_result:
            raise AssertionError("failed on: %s" % text)
    test("var is defined", [ ("var", "is", "defined") ])
    test("var is undefined", [ ("var", "is", "undefined") ])
    test("var not is undefined", [ ("var", "not is", "undefined") ])
    test("var not is defined", [ ("var", "not is", "defined") ])
    test("var  is  defined", [ ("var", "is", "defined") ])

# Generated at 2022-06-21 00:30:53.561772
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    assert Conditional()._check_conditional("somevar", None, {})
    assert Conditional()._check_conditional("not somevar", None, {})
    assert Conditional()._check_conditional("group in ('A', 'B')", None, {"group": "A"})
    assert not Conditional()._check_conditional("group in ('A', 'B')", None, {"group": "C"})

    assert Conditional()._check_conditional("group is defined", None, {"group": "A"})
    assert not Conditional()._check_conditional("group is undefined", None, {"group": "A"})
    assert Conditional()._check_conditional("group is undefined", None, {})
    assert not Conditional()._check_conditional("group is defined", None, {})

    assert Conditional()._check

# Generated at 2022-06-21 00:31:00.619417
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = """
        {{ foo.bar is defined and foo.bar is not none }}
        {{ foo.baz is not defined or foo.baz is none }}
        {{ 'bax' in foo }}
        {{ 'bax' not in foo }}
        {{ foo['bar'] is defined and foo['bar'] is not none }}
        {{ foo['baz'] is not defined or foo['baz'] is none }}
        """
    # The results should contain
    # (foo.bar, is, defined)
    # (foo.bar, is not, none)
    # (foo.baz, is not, defined)
    # (foo.baz, is, none)
    # (foo['bar'], is, defined)
    # (foo['bar'], is not, none)
    # (foo['baz'], is not,