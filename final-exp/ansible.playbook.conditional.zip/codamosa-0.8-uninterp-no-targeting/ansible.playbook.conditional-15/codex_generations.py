

# Generated at 2022-06-21 00:22:09.402995
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    assert conditional.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert conditional.extract_defined_undefined('foo not is undefined') == [('foo', 'not is', 'undefined')]
    assert conditional.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('foo is not defined and bar not is undefined') == [('foo', 'is not', 'defined'), ('bar', 'not is', 'undefined')]
    assert conditional.extract_defined_undefined('foo is not defined and bar') == [('foo', 'is not', 'defined')]
    assert conditional.extract_defined_undefined('foo') == []
    assert conditional

# Generated at 2022-06-21 00:22:16.941573
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    c = Conditional(loader=DataLoader())
    p = PlayContext()
    t = Templar(loader=c._loader, variables=dict(a=1), play_context=p)
    assert c.evaluate_conditional(t, dict(a=1)) == True
    assert c._check_conditional(t, dict(a=1), "a==1") == True

# Generated at 2022-06-21 00:22:18.170726
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional is not None

# Generated at 2022-06-21 00:22:29.664779
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """
    The method evaluates the conditional play.
    The test takes in a dictionary of all_vars and list of conditional statements as input.
    The test also takes in a list of expected boolean values.
    """
    module = AnsibleModule(argument_spec={'conditional_play': dict(type='dict')})
    conditional_list = module.params['conditional_play']['conditional']
    all_vars = module.params['conditional_play']['variables']
    expected_results = module.params['conditional_play']['expected_results']

    loader = DataLoader()
    templar = Templar(loader=loader, variables=all_vars)
    instance = Conditional(loader=loader)


# Generated at 2022-06-21 00:22:36.352704
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.play_context import PlayContext

    c = Conditional()
    play_context = PlayContext()  # needs empty play context
    # with 'and'
    conditional = "foo is defined and bar is undefined"
    res = c.extract_defined_undefined(conditional)
    assert res == [("foo", "is", "defined"), ("bar", "is", "undefined")], "extract_defined_undefined failed to return expected result"
    # with 'or'
    conditional = "foo is not defined or bar is defined"
    res = c.extract_defined_undefined(conditional)
    assert res == [("foo", "is not", "defined"), ("bar", "is", "defined")], "extract_defined_undefined failed to return expected result"
    # with parens


# Generated at 2022-06-21 00:22:48.275925
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook import PlayBook
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader, inventory, variable_manager = PlayBook.load_extra_vars([])
    variable_manager.set_inventory(inventory)

    # create a play with a task
    play_context = PlayContext()
    play_context.variable_manager = variable_manager
    loader.set_basedir("/tmp")
    conditional = Conditional(loader=loader)

    # set vars used in the tests
    variable_manager.set_nonpersistent_facts({"bar": 2})

# Generated at 2022-06-21 00:22:57.628261
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    conditional = "file1 is defined and file2 is not defined and file3 is not defined"
    results = c.extract_defined_undefined(conditional)

    # Make sure the len of the results returned by extract_defined_undefined
    # is 6, which is what we expect
    assert len(results) == 6
    assert results == [('file1', 'is', 'defined'),
                       ('file2', 'is not', 'defined'),
                       ('file3', 'is not', 'defined')]

    conditional = "file1 is defined and file2 is defined and file3 is not defined"
    results = c.extract_defined_undefined(conditional)

    # Make sure the len of the results returned by extract_defined_undefined
    # is 6, which is what we expect

# Generated at 2022-06-21 00:23:08.902585
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # test case
    conditional_test_case = [
        ("defined",
         [('defined', 'is', 'defined')]),
        ("'a' == 'a'",
         []),
        ("a is defined",
         [('a', 'is', 'defined')]),
        ("b is not defined",
         [('b', 'is', 'not defined')]),
        ("c is defined and d is undefined",
         [('c', 'is', 'defined'), ('d', 'is', 'undefined')]),
        ("(('a' == 'a') and (a is defined)) or (b is not defined)",
         [('a', 'is', 'defined'), ('b', 'is', 'not defined')]),
        ("'a' in 'a'",
         [])]


# Generated at 2022-06-21 00:23:13.658884
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Simple test to ensure that evaluate_conditional returns True when
    when is empty.
    '''
    from ansible.parsing.dataloader import DataLoader

    cond = Conditional()
    cond.when = None
    # cond.when = ''
    assert cond.evaluate_conditional(None, None)

# Generated at 2022-06-21 00:23:22.584967
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()


# Generated at 2022-06-21 00:23:52.877760
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    """
    Tests extraction of defined/undefined tests

    Partial test of method Conditional.extract_defined_undefined. Tests
    extraction of defined/undefined tests from various conditional
    strings.
    """

    import types
    from ansible.playbook.task import Task

    # test string that uses defined and undefined
    c = Conditional()
    assert c.extract_defined_undefined('something is defined') == [('something', 'is', 'defined')]
    assert c.extract_defined_undefined('something is not is not defined') == [('something', 'is not is not', 'defined')]
    assert c.extract_defined_undefined('something is undefined') == [('something', 'is', 'undefined')]

# Generated at 2022-06-21 00:23:56.841024
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('foo is defined and bar is not defined') == \
            [('foo', 'is', 'defined'), ('bar', 'is not', 'defined')]



# Generated at 2022-06-21 00:24:06.065405
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    class my_task(Conditional):
        pass

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # test that a simple string evaluates to true
    task = my_task()
    task.when = ['simple']
    assert task.evaluate_conditional(variable_manager.extra_vars, all_vars=variable_manager.get_vars(play=None))
    task.when = ['simple', None]

# Generated at 2022-06-21 00:24:17.447276
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-21 00:24:27.711720
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Test the method Conditional.evaluate_conditional
    '''
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # Initialize needed objects
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)
    variable_manager.extra_vars = {'foo': 'bar'}

    # create a simple task
    task = Conditional(loader=loader)

    # set a conditional to evaluate
    task.when = "foo == 'bar'"
    res = task.evaluate_conditional(variable_manager, variable_manager._final_debug_vals)
    assert res

# Generated at 2022-06-21 00:24:38.440877
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    cond = Conditional()
    cond.when = ['foo != bar', 'baz is not undefined']

    ds = dict(foo='foo', bar='bar', baz=None)
    loader = DataLoader()
    variable_manager = VariableManager()
    t = Templar(loader=loader, variables=variable_manager)
    variable_manager.set_available_variables(ds)

    assert cond.evaluate_conditional(t, ds)

    cond.when = ['foo == bar']

    assert not cond.evaluate_conditional(t, ds)



# Generated at 2022-06-21 00:24:44.126850
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    def test_evaluate_conditional(conditional, expected):
        class TestClass(Conditional):
            def __init__(self):
                self.when = conditional
                self.name = 'TestClass'
                self._ds = ['TestClass']
        tc = TestClass()
        res = tc.evaluate_conditional('fake templar', {})
        assert res == expected, "Evaluated conditional '%s' as %s instead of %s" % (conditional, res, expected)
    test_evaluate_conditional(None, True)
    test_evaluate_conditional('', True)
    test_evaluate_conditional(True, True)
    test_evaluate_conditional(False, False)

    # test undefined variable handling with a conditional

# Generated at 2022-06-21 00:24:55.017630
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    obj = Conditional()
    assert obj.extract_defined_undefined("a is defined and b is undefined") == [('a', 'is', 'defined'), ('b', 'is', 'undefined')]
    assert obj.extract_defined_undefined("a is defined or b is not defined") == [('a', 'is', 'defined'), ('b', 'is', 'not', 'defined')]
    assert obj.extract_defined_undefined("hostvars['foo'] is defined and b is undefined") == [("hostvars['foo']", 'is', 'defined'), ('b', 'is', 'undefined')]
    assert obj.extract_defined_undefined("a is defined") == [('a', 'is', 'defined')]

# Generated at 2022-06-21 00:25:06.644958
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.base import Base

    # -- Setup --
    class test_object(Base, Conditional):
        pass

    all_vars = dict(
        foo="abc",
        bar="def",
        baz="123",
        zed=["yyy", "zzz"],
        dict_var={"a": 1, "b": 2},
        list_of_dicts=[{"c": 3, "d": {"f": 5}}, {"g": None}],
        nested={"list": ["value"]}
    )

    display.verbosity = 4
    # -- Tests --
    result = True
    # Dict lookup
    test_object._when = [{"dict_var": {"a": 1, "b": 2}}]

# Generated at 2022-06-21 00:25:14.650468
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined('x is defined') == \
        [('x', 'is', 'defined')]
    assert conditional.extract_defined_undefined('x is undefined') == \
        [('x', 'is', 'undefined')]
    assert conditional.extract_defined_undefined('x not is defined') == \
        [('x', 'not is', 'defined')]
    assert conditional.extract_defined_undefined('x not is undefined') == \
    [('x', 'not is', 'undefined')]
    assert conditional.extract_defined_undefined('x is defined or y is defined') == \
        [('x', 'is', 'defined'), ('y', 'is', 'defined')]

# Generated at 2022-06-21 00:26:00.655090
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test a simple undefined var
    # FIXME - this test will fail as there is no templar to pass in
    if False:
        conditional = 'any_var is defined'
        templar = "some templar"
        all_vars = {}
        result = Conditional().evaluate_conditional(templar, all_vars)
        assert result is False
        conditional = 'any_var is undefined'
        result = Conditional().evaluate_conditional(templar, all_vars)
        assert result is True

    # Test a simple defined var
    if False:
        conditional = 'any_var is defined'
        templar = "some templar"
        all_vars = {'any_var': 1}

# Generated at 2022-06-21 00:26:05.810012
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert hasattr(c, 'when')
    assert isinstance(c.when, list)
    assert len(c.when) == 0
    c = Conditional()
    assert hasattr(c, 'when')
    assert isinstance(c.when, list)
    assert len(c.when) == 0

# Generated at 2022-06-21 00:26:09.603982
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    c = Conditional(loader, variable_manager)


# Generated at 2022-06-21 00:26:20.308547
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.task_include import TaskInclude
    task = TaskInclude()

    # empty string
    conditional = ''
    r = task.extract_defined_undefined(conditional)
    assert r == []

    # no conditional
    conditional = 'not defined foo'
    r = task.extract_defined_undefined(conditional)
    assert r == []

    # conditional without defined/undefined
    conditional = 'foo and not defined bar or defined xx'
    r = task.extract_defined_undefined(conditional)
    assert r == []

    # conditional with defined
    conditional = 'fruit is defined and fruit not in bar'
    r = task.extract_defined_undefined(conditional)
    assert r == [('fruit', 'is', 'defined')]

    # conditional with undefined


# Generated at 2022-06-21 00:26:30.253979
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # test the default logic of method extract_defined_undefined
    con = Conditional()
    conditional = 'c is undefined and d is defined'
    res = con.extract_defined_undefined(conditional)
    assert res == [('c', 'is', 'undefined'), ('d', 'is', 'defined')], "failed extract_defined_undefined test."
    # test multiple variables
    conditional = 'c is undefined and d is defined and e is defined'
    res = con.extract_defined_undefined(conditional)
    assert res == [('c', 'is', 'undefined'), ('d', 'is', 'defined'), ('e', 'is', 'defined')], "failed extract_defined_undefined test."
    # test space before and after the logic
    conditional = 'c is  defined and d is     not     defined'

# Generated at 2022-06-21 00:26:36.413319
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext

    # test with play context
    context = PlayContext()
    c = Conditional(context)
    assert type(c) == Conditional

    # test without play context
    try:
        c = Conditional()
    except AnsibleError:
        pass
    else:
        raise AssertionError("Conditional() without context should raised AnsibleError")

# Unit tests for extract_defined_undefined method of class Conditional

# Generated at 2022-06-21 00:26:44.927233
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-21 00:26:45.889231
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # FIXME: test this method

    # TODO: add tests
    pass

# Generated at 2022-06-21 00:26:47.362656
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    c = Conditional(loader=loader)
    assert c

# Generated at 2022-06-21 00:26:49.753433
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.vars import VariableManager
    # simple test to run when no loader is needed
    c = Conditional(loader=None)
    assert c._when == []

    # test to run with a loader
    c = Conditional(loader=VariableManager())
    assert c._when == []

# Generated at 2022-06-21 00:27:43.779480
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("") == []
    assert c.extract_defined_undefined("    ") == []
    assert c.extract_defined_undefined("test") == []
    assert c.extract_defined_undefined("test is defined") == [('test', 'is', 'defined')]
    assert c.extract_defined_undefined("test is defined and test2 is defined") == [('test', 'is', 'defined'), ('test2', 'is', 'defined')]
    assert c.extract_defined_undefined("test is not defined and test2 is not defined") == [('test', 'is not', 'defined'), ('test2', 'is not', 'defined')]

# Generated at 2022-06-21 00:27:50.445444
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext

    yaml_data = """
    - action: local_action
      args:
        chdir: somedir
        module: raw
        msg: hello world
        creates: notthere
      when: True
      register: local_result
    """

    import yaml
    #from ansible.playbook.play import Play

    tasks = yaml.load(yaml_data)
    assert len(tasks) == 1

    c = Conditional()
    for t in tasks:
        assert isinstance(t, dict)
        c.vars = t
        c.evaluate_conditional(PlayContext(vars=dict()), 'master')
        c.evaluate_conditional(PlayContext(vars=dict()), 'master')

# Generated at 2022-06-21 00:28:01.067507
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    # First, an assertion test
    test = conditional.extract_defined_undefined("testvar is defined and testvar2 is undefined")
    assert test == [('testvar', 'is', 'defined'), ('testvar2', 'is', 'undefined')]

    # Now, a test for our test :-D
    test = conditional.extract_defined_undefined("result is defined and result2 is undefined")
    assert test == [('result', 'is', 'defined'), ('result2', 'is', 'undefined')]

    # Test for a reverse conditional
    test = conditional.extract_defined_undefined("testvar is not defined and testvar2 is not undefined")
    assert test == [('testvar', 'is not', 'defined'), ('testvar2', 'is not', 'undefined')]

   

# Generated at 2022-06-21 00:28:10.486070
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    pb = Play().load({
        'name': 'test play',
        'connection': 'local',
        'hosts': 'localhost',
        'gather_facts': True,
        'tasks': [
            {'name': 'test task', 'action': {'module': 'debug', 'args': {'msg': 'hello world'}}},
        ]
    }, variable_manager=VariableManager(), loader=None)

    tqm = None

    pc = PlayContext()

# Generated at 2022-06-21 00:28:19.800867
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    extra_vars = {
        'a': 1,
        'b': 2,
        'b_key': 'b_value',
        'c': None,
        'd': True,
        'e': False,
        'f': [1,2,3],
        'g': {'g_key': 'g_value'},
    }

    t = Templar(loader=None, variables=extra_vars)

    # Test when entry is a boolean
    def _test_bool(boolean, expected_result):
        cond = Conditional()
        setattr(cond, 'when', [boolean])
        result = cond.evaluate_conditional(t, extra_vars)
        assert result == expected_result

    _test_bool(True, True)
    _test_

# Generated at 2022-06-21 00:28:20.798376
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional

# Generated at 2022-06-21 00:28:21.701276
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    return



# Generated at 2022-06-21 00:28:27.696551
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    import io
    import json
    import os

    fixture = os.path.join(
        os.path.dirname(__file__),
        'fixtures',
        'templates',
        'test_evaluate_conditional.json'
    )

    with open(fixture, 'r') as fd:
        test_cases = json.loads(fd.read())

    def create_task(when):
        class Task(Conditional):
            pass

        task = Task()
        task.when = when
        return task

    for test_case in test_cases:
        task = create_task(test_case['when'])
        variable_manager = VariableManager()
        loader = None
        display = Display()

# Generated at 2022-06-21 00:28:29.136009
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c != None


# Test cases for method EvaluateConditional of class Conditional

# Generated at 2022-06-21 00:28:39.336439
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # test is_defined_undefined()
    res = Conditional().extract_defined_undefined('foo is not defined or bar == 1')
    assert res == [['foo', 'is', 'defined'], ['bar', '==', '1']]
    res = Conditional().extract_defined_undefined('not foo is defined')
    assert res == [['foo', 'is', 'defined']]
    assert Conditional().extract_defined_undefined('1') == []
    assert Conditional().extract_defined_undefined('bar') == []

    # test _check_conditional()
    assert Conditional()._check_conditional('foo', None, dict(foo=True))
    assert not Conditional()._check_conditional('!bar', None, dict(bar=False))
    assert not Conditional()._check_cond

# Generated at 2022-06-21 00:30:29.100727
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    results = cond.extract_defined_undefined('this or that and the_other is defined and not this_one is defined')
    assert results == [('the_other', 'is', 'defined'), ('this_one', 'is', 'defined')]

# Generated at 2022-06-21 00:30:41.317350
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class MyConditional(Conditional):
        def __init__(self, loader):
            self._loader = loader
    class MyVars:
        my_host_name = "my_hostname"
        my_var = "my_var"
        my_dict = dict(a=1, b=2)


# Generated at 2022-06-21 00:30:53.115544
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    class Fake(Conditional):
        def __init__(self, loader=None):
            self._loader = loader

# Generated at 2022-06-21 00:31:02.556758
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    def _tmpl(vname, val):
        from ansible.template import Templar
        from ansible.vars.manager import VariableManager
        from ansible.inventory.manager import InventoryManager
        from ansible.playbook.play_context import PlayContext

        inventory = InventoryManager(loader=loader, sources='')
        variable_manager = VariableManager(loader=loader, inventory=inventory)
        play_context = PlayContext()
        templar = Templar(loader=loader, variables=variable_manager, play_context=play_context)
        if vname is not None:
            variable_manager.set_variable(vname, val)
        return templar

    inventory = InventoryManager(loader=loader, sources='')
    variable

# Generated at 2022-06-21 00:31:11.679301
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader

    class TestConditional(Conditional):
        def __init__(self, check_when=None):
            loader = DataLoader()
            super(TestConditional, self).__init__(loader=loader)
            self._loader = loader
            self.when = check_when

    test_cond = TestConditional(['1 > 0'])
    assert test_cond.when == ['1 > 0']

    test_cond = TestConditional(['1 gt 0'])
    assert test_cond.when == ['1 gt 0']

# Generated at 2022-06-21 00:31:21.995615
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-21 00:31:31.821370
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    c = Conditional(loader=DataLoader())

    # data structure not present
    try:
        c.evaluate_conditional(variable_manager=VariableManager(loader=DataLoader()), all_vars=dict())
    except AnsibleError as e:
        assert 'must be used as a mix-in' in to_text(e)

    # loader not present
    c = Conditional()
    try:
        c.evaluate_conditional(variable_manager=VariableManager(loader=DataLoader()), all_vars=dict())
    except AnsibleError as e:
        assert 'must be used as a mix-in' in to_text(e)

# Generated at 2022-06-21 00:31:33.704689
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    _test_when_positive()
    _test_when_negative()


# Generated at 2022-06-21 00:31:41.363404
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert [('hostvars[hostvars["inventory_hostname"]]', 'is not', 'defined')] == Conditional().extract_defined_undefined("hostvars[hostvars[\"inventory_hostname\"]] is not defined")
    assert [('hostvars[hostvars["hostvars"]]', 'is', 'undefined')] == Conditional().extract_defined_undefined("hostvars[hostvars[\"hostvars\"]] is undefined")


# Generated at 2022-06-21 00:31:48.583416
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing import DataLoader
    loader = DataLoader()
    conditional = Conditional(loader=loader)

    assert conditional._when == []

    # test when used as a mix-in with a playbook base class
    from ansible.playbook.base import Base
    base = Base(loader=loader)
    assert isinstance(base, Conditional)