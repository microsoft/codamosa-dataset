

# Generated at 2022-06-21 00:22:05.479149
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.utils.unsafe_proxy import wrap_var

    cond = Conditional()
    result = cond.extract_defined_undefined("host == 'localhost'")
    assert result == []

    cond = Conditional()
    result = cond.extract_defined_undefined("'foo' is defined and 'bar' is not defined")
    assert result == [("'foo'", "is", "defined"), ("'bar'", "is not", "defined")]

    cond = Conditional()
    result = cond.extract_defined_undefined("'foo' is undefined and 'bar' is not undefined")
    assert result == [("'foo'", "is", "undefined"), ("'bar'", "is not", "undefined")]

    cond = Conditional()

# Generated at 2022-06-21 00:22:06.494206
# Unit test for constructor of class Conditional
def test_Conditional():
    assert issubclass(Conditional, object)

# Generated at 2022-06-21 00:22:14.323910
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    class _TestConditional(Conditional):
        def __init__(self, loader, variables):
            self._loader = loader
            self._variable_manager = variables

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=[])

    # test the case insensitive part
    test_conditional = _TestConditional(loader=loader, variables=inventory.get_variable_manager())
    test_conditional.when = ['FOO_BAR is defined']
    inventory.get_variable_manager().set_host_variable(host=inventory.get_host("localhost"), varname='foo_bar', value='bar')
    assert test_

# Generated at 2022-06-21 00:22:26.014396
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext

    conditional = Conditional()
    conditional._ds = {}

    play_context = PlayContext()
    vars_manager = VariableManager()
    templar = Templar(vars_manager, play_context)

    all_vars = dict(
        a=1,
        b=2,
        c=10,
        d="5",
        e="15",
        g="",
        h=0,
        i=True,
        j=False,
        k="True",
        l="False",
        m="a",
        n="b",
        o=None,
        p=dict(
            x=1,
            y=2,
        )
    )

    #

# Generated at 2022-06-21 00:22:34.715755
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # set up a mock templar object to just do the minimal
    # variable expansion of this class
    class MockUtils:
        def __init__(self, vars):
            self.vars = vars

        def is_template(self, data):
            return False

        def template(self, data, *args, **kwargs):
            return self.vars.get(data, data)

        @property
        def environment(self):
            return None

    class ConditionalTest(Conditional):

        def __init__(self, loader=None, ds=None):
            self._ds = ds
            super(ConditionalTest, self).__init__(loader)


# Generated at 2022-06-21 00:22:46.156656
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import IncludeRole

    # when test_role_vars is not specified, the variable will be undefined

# Generated at 2022-06-21 00:22:48.940073
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional.when == []
    conditional.add_when(True)
    assert conditional.when == [True]

# Generated at 2022-06-21 00:22:51.062777
# Unit test for constructor of class Conditional
def test_Conditional():
    try:
        c = Conditional()
    except Exception as e:
        assert isinstance(e, AnsibleError)
        return

    assert False, "Conditional() did not raise an exception when called without a loader"

# Generated at 2022-06-21 00:22:58.970155
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    testclass = Conditional()


# Generated at 2022-06-21 00:23:10.102217
# Unit test for constructor of class Conditional
def test_Conditional():

    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook import base
    from ansible.playbook.play_context import PlayContext

    klass = Conditional()
    data = klass.dump()
    assert data['__ansible_when'] == []

    from ansible.utils.unsafe_proxy import wrap_var

    loader = DataLoader()
    loader.set_basedir('/home/test')
    templar = klass._loader.get_basedir_loader(loader).get_jinja2_environment().from_string('')
    templar.environment.filters['unsafe_proxy'] = wrap_var
    play_context = PlayContext()

    conditional = {'expression': 'True'}

# Generated at 2022-06-21 00:23:22.727104
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined(
        'foo is defined and (bar is not defined or bar.baz == '
        '"foobar" ) and bar.baz.something is defined or bar.baz.default is defined'
    ) == [
        ('foo', 'is', 'defined'),
        ('bar', 'is not', 'defined'),
        ('bar.baz', 'is', 'defined'),
        ('bar.baz.something', 'is', 'defined'),
        ('bar.baz.default', 'is', 'defined'),
    ]

# Generated at 2022-06-21 00:23:33.708162
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    cond = Conditional()
    templar = MockTemplar(dict(a=False, b=True, x=True))

    assert cond.evaluate_conditional(templar, dict(a=False, b=True, x=True))
    assert cond.evaluate_conditional(templar, dict(a=True, b=True, x=True))
    assert cond.evaluate_conditional(templar, dict(a=False, b=True, x=False))
    assert cond.evaluate_conditional(templar, dict(a=True, b=True, x=False))
    assert not cond.evaluate_conditional(templar, dict(a=False, b=False, x=True))

# Generated at 2022-06-21 00:23:42.731070
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestConditional(Conditional):
        pass
    import jinja2
    environment = jinja2.Environment(variable_start_string="{{", variable_end_string="}}")
    templar = TestConditional(loader=object(), environment=environment)
    templar.available_variables = dict()

    # Test comparing numbers, strings and boolean
    assert templar._check_conditional('1 == 2', templar, templar.available_variables) == False
    assert templar._check_conditional('2 == 2', templar, templar.available_variables) == True
    assert templar._check_conditional('"foo" == "foo"', templar, templar.available_variables) == True

# Generated at 2022-06-21 00:23:54.287065
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.template import Templar

    class FakeLoader(object):
        pass

    class FakePlay(Conditional):
        def __init__(self, loader=None):
            if loader is None:
                loader = FakeLoader()
            super(FakePlay, self).__init__(loader)

    # These variables are required to call evaluate_conditional
    templar = Templar(loader=FakeLoader())
    # We don't need to define _ds to call evaluate_conditional
    fake_play = FakePlay()
    all_vars = {}

    fake_play.when = ['1 == 1']
    assert fake_play.evaluate_conditional(templar, all_vars)

    fake_play.when = ['1 == 2']
    assert not fake_play.evaluate_conditional(templar, all_vars)

# Generated at 2022-06-21 00:23:58.074156
# Unit test for constructor of class Conditional
def test_Conditional():
    # test with loader subclass with and without Base
    testloader = DictDataLoader({})

    assert(isinstance(Conditional(testloader), Conditional))
    assert(Conditional(testloader)._loader is testloader)


# Generated at 2022-06-21 00:24:06.838115
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager.set_inventory(inventory)
    playbook_vars = dict(
        hostvars=dict(
            host1=dict(
                test=1234
            ),
            host2=dict(
                test=5678
            )
        ),
        test1=dict(
            test=4321
        )
    )
    variable_manager.set_vars(playbook_vars)
    play_context

# Generated at 2022-06-21 00:24:18.039922
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class DummyVars(object):
        def get(self, key, default=None):
            return str(default)
    class DummyTemplar(object):
        def __init__(self):
            self.environment = None
            self.available_variables = {}
        def template(self, data, disable_lookups=False, preserve_trailing_newlines=True, escape_backslashes=True, fail_on_undefined=True):
            return data
        def is_template(self, data):
            return False
    class DummyConditionalObject(object):
        def __init__(self):
            self.when = list()
        def extract_defined_undefined(self, conditional):
            return list()
    vars = DummyVars()
    templar = DummyTemplar()
   

# Generated at 2022-06-21 00:24:28.161082
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader, lookup_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    fake_loader = DictDataLoader({
        'test.yml': "{% if 1==1 %}True{% else %}False{%endif %}"
    })

    play_context = PlayContext()
    play_context._vars_plugins = list(action_loader.all()) + list(lookup_loader.all())
    variable_manager = VariableManager()
    templar = Templar(loader=fake_loader, variables=variable_manager, shared_loader_obj=fake_loader)


# Generated at 2022-06-21 00:24:39.310061
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined("foo is defined") == [("foo", "is", "defined")]
    assert c.extract_defined_undefined("foo isnot defined") == [("foo", "isnot", "defined")]
    assert c.extract_defined_undefined("foo is not defined") == [("foo", "is", "not", "defined")]
    assert c.extract_defined_undefined("foo is undefined") == [("foo", "is", "undefined")]
    assert c.extract_defined_undefined("foo isnot undefined") == [("foo", "isnot", "undefined")]
    assert c.extract_defined_undefined("foo is not undefined") == [("foo", "is", "not", "undefined")]
    assert c

# Generated at 2022-06-21 00:24:45.316185
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader

    # A simple test class that implements Conditional
    class ConditionalTest(Conditional):
        def __init__(self, loader=None):
            super(ConditionalTest, self).__init__(loader)

        def evaluate_conditional(self, templar, all_vars):
            return super(ConditionalTest, self).evaluate_conditional(templar, all_vars)

    loader = DataLoader()
    obj = ConditionalTest(loader)

    # A simple test class that implements Base
    class BaseTest(object):
        def __init__(self, loader=None):
            super(BaseTest, self).__init__()


# Generated at 2022-06-21 00:25:04.191268
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    inventory = lambda x: "inventory"
    t = Templar(loader=None, variables={'inventory': inventory}, shared_loader_obj=None)


# Generated at 2022-06-21 00:25:13.158688
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    '''
    Tests that the method evaluate_conditional correctly iterate over the conditions
    to evaluate.
    '''
    import sys

    sys.path.append('lib')

    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    from ansible.template import Templar

    templar = Templar(loader=loader, variables={})

    # TODO direcly call evaluate_conditional method w/o init
    c = Conditional(loader=loader)

    # no conditions
    c._when = None
    assert c.evaluate_conditional(templar, {})

    # test bool output
    c._when = True
    assert c.evaluate_conditional(templar, {})

    c._when = False

# Generated at 2022-06-21 00:25:24.911836
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditions = [
        'b == 1 or hostvars["foo"] is defined',
        'b == 10 or hostvars["foo"] is not defined',
        'b == 1 and (hostvars["foo"] is not defined or hostvars["foo"] != "bar")',
        'b == 1 and (hostvars["foo"] is not defined or hostvars["foo"] == 1)',
        'b == 10 and (hostvars["foo"] is defined or hostvars["foo"] != "bar")',
        'b == 10 and (hostvars["foo"] is defined or hostvars["foo"] == 1)',
        'b == 1 and (hostvars["foo"] is not defined or (hostvars["foo"] != "bar" and hostvars["bar"] == "foo")) or c == 1',
    ]
   

# Generated at 2022-06-21 00:25:35.292071
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class Control:
        pass

    control = Control()
    control.when = ['foo', 'bar', 'baz']
    control._validate_when('when', 'when', control.when)
    control._loader = object()
    control.evaluate_conditional = Conditional.evaluate_conditional

    assert control.evaluate_conditional(object(), {})

    control.when = False
    control._validate_when('when', 'when', control.when)
    assert not control.evaluate_conditional(object(), {})

    control.when = 'foo'
    control._validate_when('when', 'when', control.when)
    assert control.evaluate_conditional(object(), {'foo': True})
    assert not control.evaluate_conditional(object(), {'foo': False})

# Generated at 2022-06-21 00:25:36.674086
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c.when is None


# Generated at 2022-06-21 00:25:48.064546
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager

    def _task(cond, result, extravars=None, hostvars=None):
        templar = Templar(loader=None, variables=VariableManager(loader=None, extra_vars=extravars))

        all_vars = templar._available_variables
        if hostvars:
            all_vars['hostvars'] = hostvars

        # Test class needs a loader, but we want to
        # make sure we don't trample on the existing one if this class
        # is used as a mix-in with a playbook base class
        class Test(Conditional):
            pass
        test = Test(loader=None)
        test._ds = 'ds'
        test._when = [cond]
        return test.evaluate_

# Generated at 2022-06-21 00:25:58.187248
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    play = Conditional()
    assert play.extract_defined_undefined("hostvars[inventory_hostname] is defined") == [("hostvars[inventory_hostname]", "is", "defined")]
    assert play.extract_defined_undefined("hostvars[inventory_hostname] is not defined") == [("hostvars[inventory_hostname]", "is not", "defined")]
    assert play.extract_defined_undefined("hostvars[inventory_hostname] is undefined") == [("hostvars[inventory_hostname]", "is", "undefined")]
    assert play.extract_defined_undefined("hostvars[inventory_hostname] is not undefined") == [("hostvars[inventory_hostname]", "is not", "undefined")]
    assert play.extract

# Generated at 2022-06-21 00:26:01.282019
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c is not None

# Tests for method _check_conditional

# Generated at 2022-06-21 00:26:02.865166
# Unit test for constructor of class Conditional
def test_Conditional():
    c=Conditional(42)
    assert c._loader == 42


# Generated at 2022-06-21 00:26:14.082006
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    test_obj = Conditional()

# Generated at 2022-06-21 00:26:38.565200
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # TODO: This is a stupid test, needs redone
    class MockModule:
        def __init__(self, *args, **kwargs):
            self.params = kwargs

    class MockTask:
        def __init__(self, *args, **kwargs):
            self.module_args = MockModule(**kwargs)

    conditional = Conditional()

    templar = Templar(loader=None, variables={'first': {'a': 1, 'b': 2, 'c': 3}, 'second': {'a': 1, 'b': 2, 'c': 3}})
    assert conditional.evaluate_conditional(templar, dict())


# Generated at 2022-06-21 00:26:46.609814
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # create a test class
    class Test:
        def __init__(self):
            self.loader = DictDataLoader({})
            self.vars = {}

    testobj = Test()

    # create a templar for testing by adding needed attributes
    testobj.templar = DictDataLoader.Templar(loader=testobj.loader)
    testobj.templar.environment = Environment()
    testobj.templar.set_available_variables(testobj.vars)

    # add methods to the test class
    testobj.evaluate_conditional = Conditional.evaluate_conditional
    testobj._check_conditional = Conditional._check_conditional


# Generated at 2022-06-21 00:26:52.585156
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import pytest
    from ansible.template import Templar

    cond_obj = Conditional()
    cond_obj.when = ['var1 == "fi"', 'var2 == "fe"']

    # Test normal operation
    mock_loader = AnsibleFileMockLoader(path=['/dev/null'])
    mock_vars = dict(var1 = 'fi', var2 = 'fe')
    templar = Templar(loader=mock_loader, variables=mock_vars)
    assert cond_obj.evaluate_conditional(templar, mock_vars) == True

    # Test for failure on evaluation
    mock_loader = AnsibleFileMockLoader(path=['/dev/null'])
    mock_vars = dict(var1 = 'fi', var2 = 'fum')

# Generated at 2022-06-21 00:27:02.069037
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.plugins import module_loader, connection_loader
    from ansible.playbook.handler import Handler

    # The globals that run_handlers uses to ensure the
    # structure of the loaded objects is correct.
    # for this test to work, we need to:
    #  * create a module in the module_loader
    #  * create a connection in the connection_loader
    #  * add the module and connection to the global lists
    MODULE_NAME = 'test'
    CONNECTION = 'local'
    TASK_PATH = '/tmp/ansible_test_task'

# Generated at 2022-06-21 00:27:10.280890
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    vars = dict(
        test1="foo",
        test2="bar",
        test3="",
        test4="0",
        test5="1",
        test6=None,
        test7=dict(
            nested="baz",
        ),
        test8=[
            dict(
                nested="baz",
            ),
        ],
    )

# Generated at 2022-06-21 00:27:16.718817
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    class MyTask(object):
        _name = 'my_task'

        _loader = DataLoader()
        _variable_manager = VariableManager()

        def __init__(self, when=None):
            self._when = when

        def extract_defined_undefined(self, conditional):
            return Conditional.extract_defined_undefined(self, conditional)

        def evaluate_conditional(self, templar, all_vars):
            return Conditional.evaluate_conditional(self, templar, all_vars)


# Generated at 2022-06-21 00:27:17.605995
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    pass
    # TODO: implement your unit test here


# Generated at 2022-06-21 00:27:18.221768
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional

# Generated at 2022-06-21 00:27:25.256239
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-21 00:27:37.322315
# Unit test for constructor of class Conditional

# Generated at 2022-06-21 00:28:01.198653
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("hostvars['foo'] is defined") == [('hostvars[\'foo\']', 'is', 'defined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not defined") == [('hostvars[\'foo\']', 'is not', 'defined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is undefined") == [('hostvars[\'foo\']', 'is', 'undefined')]
    assert conditional.extract_defined_undefined("hostvars['foo'] is not undefined") == [('hostvars[\'foo\']', 'is not', 'undefined')]

# Generated at 2022-06-21 00:28:10.601566
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional_instance = Conditional()

# Generated at 2022-06-21 00:28:14.624220
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.task import Task

    # load a task that uses the Conditional mix-in
    fake_loader = DummyLoader({'tasks': [{'name': "test", 'when': 'fake'}]})
    t = Task.load(fake_loader, fake_loader.get('tasks')[0])

    # check that the when variable has been initialized
    assert t._when == [u'fake']



# Generated at 2022-06-21 00:28:25.234873
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

    import jinja2
    env = jinja2.Environment(loader=loader)
    from ansible.template import Templar
    tt = Templar(loader=loader, variables=variable_manager, shared_loader_obj=env)

    # construct a task and set some reasonable values
    from ansible.playbook.task import Task
    test_task = Task()

    test_task.when = []
    assert test_task.evaluate_conditional(tt, {})

    test_task.when = [None]

# Generated at 2022-06-21 00:28:34.704114
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.module_utils.six.moves import StringIO
    from ansible.template import Templar

    class MyVarsModule:
        def __init__(self, **kwargs):
            self.params = kwargs

    class MyTask(Conditional):
        def __init__(self, when=None, vars=None, loader=None):
            self._when = when
            self.vars = vars
            super(MyTask, self).__init__(loader)

    class MyTemplar(Templar):
        def __init__(self, variables):
            self.available_variables = variables

        def template(self, data, *args, **kwargs):
            return data


# Generated at 2022-06-21 00:28:44.465170
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-21 00:28:51.660516
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    results = c.extract_defined_undefined("foo is defined and bar is not defined")
    assert len(results) == 2
    assert results[0][0] == "foo"
    assert results[0][1] == "is"
    assert results[0][2] == "defined"
    assert results[1][0] == "bar"
    assert results[1][1] == "is not"
    assert results[1][2] == "defined"

    results = c.extract_defined_undefined("foo is defined")
    assert len(results) == 1
    assert results[0][0] == "foo"
    assert results[0][1] == "is"
    assert results[0][2] == "defined"


# Generated at 2022-06-21 00:28:57.658883
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Unit test for method evaluate_conditional of class Conditional
    '''
    import os
    import sys
    libdir = os.path.join(os.path.dirname(__file__), '..', '..', 'module_utils')
    if os.path.isdir(libdir):
        sys.path.append(libdir)
    from template import Templar

    ds = dict()
    ds['one'] = 1
    ds['two'] = 2
    ds['three'] = 3
    ds['four'] = 4
    ds['true'] = True
    ds['false'] = False
    ds['string'] = 'hello'
    ds['list'] = [1, 2, 3, 4]

# Generated at 2022-06-21 00:29:02.637000
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.task import Task
    from ansible.template import Templar

    t = Task()
    conditional = "{{ foo is defined and (bar is not defined or bam is defined) }}"
    assert t.extract_defined_undefined(conditional) == \
        [("foo", "is", "defined"), ("bar", "is not", "defined"), ("bam", "is", "defined")]

# Generated at 2022-06-21 00:29:10.936518
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Create a host with a group
    test_host = Host(name='test_host')
    test_group = Group(name='test_group')
    test_group.add_host(test_host)

    # Create a PlayContext with the host and variables
    test_play_context = PlayContext()

# Generated at 2022-06-21 00:29:35.972972
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert hasattr(conditional, '_when')
    assert conditional._when is not None
    assert isinstance(conditional._when, list)
    assert len(conditional._when) == 0


# Generated at 2022-06-21 00:29:38.485927
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task

# Generated at 2022-06-21 00:29:44.463180
# Unit test for constructor of class Conditional

# Generated at 2022-06-21 00:29:56.992441
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    def run_test(condition, variables, expected):
        tmp_conditional = Conditional()
        tmp_conditional.when = [ condition ]
        (templar, all_vars) = Fake_templar_and_all_vars(variables)
        actual = tmp_conditional.evaluate_conditional(templar, all_vars)
        assert actual == expected, "%s != %s for 'when: %s'" % (expected, actual, condition)

    # Test variables with all choice of values of different types

# Generated at 2022-06-21 00:30:09.701311
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.template import Templar


# Generated at 2022-06-21 00:30:21.326052
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-21 00:30:24.379860
# Unit test for constructor of class Conditional
def test_Conditional():
    cond = Conditional()
    assert isinstance(cond._when, list)


# Generated at 2022-06-21 00:30:32.779597
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    v1 = dict(os_family="ubuntu")
    v2 = dict(os_family="redhat")
    v3 = dict(os_family="centos")
    v4 = dict(os_family="redhat", os_version_major="7")


# Generated at 2022-06-21 00:30:38.598383
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.vault import VaultLib
    from ansible.template.template import Templar

    # create a templar for this test
    vault_password = 'secret vault password'
    vault = VaultLib(vault_password)
    templar = Templar(loader=None, variables={'the_answer': 42, 'the_string': 'string stuff'}, vault_secrets=vault)

    # create a Conditional object
    c = Conditional(loader=None)

    # when the_answer is 42, this works
    c.when = ['the_answer == 42']
    assert c.evaluate_conditional(templar, templar._available_variables)

    # when the_answer is 43, this doesn't work and we skip
    c.when = ['the_answer == 43']

# Generated at 2022-06-21 00:30:51.804874
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    obj = Conditional(loader=None)

    conditional = "hostvars['10.0.0.1']['ansible_facts']['os_family'] is 'RedHat'"
    obj.when = [conditional]

    context = PlayContext()
    templar = Templar(loader=None, variables=dict())
    all_vars = dict(templar._available_variables)

    res = obj.extract_defined_undefined(conditional)
    assert res == [('hostvars[\'10.0.0.1\'][\'ansible_facts\'][\'os_family\']', 'is', 'defined')], res



# Generated at 2022-06-21 00:31:15.041896
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # FIXME: Make this a proper unit test that doesn't need to use a temporary
    #        directory. This will require refactoring Conditional to not need
    #        a loader.
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    c = Conditional(loader=loader)
    c.when = ['true']
    assert c.evaluate_conditional(VariableManager(), dict()) is True

    c.when = ['false']
    assert c.evaluate_conditional(VariableManager(), dict()) is False


# Generated at 2022-06-21 00:31:18.127311
# Unit test for constructor of class Conditional
def test_Conditional():
    try:
        Conditional()
        assert False
    except AnsibleError:
        pass
    assert Conditional(loader=None)

# Generated at 2022-06-21 00:31:24.043563
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    """Conditional: test method extract_defined_undefined"""
    c = Conditional()
    expected = [('test1', 'is', 'defined')]
    assert c.extract_defined_undefined('test1 is defined') == expected
    expected = [('test2', 'is not', 'undefined')]
    assert c.extract_defined_undefined('test2 is not undefined') == expected
    expected = [('test1', 'is', 'defined'), ('test2', 'is not', 'undefined')]
    assert c.extract_defined_undefined('test1 is defined and test2 is not undefined') == expected
    expected = [('test1', 'is', 'defined'), ('test2', 'is not', 'undefined'), ('test3', 'is', 'defined')]
    assert c.extract_defined_und

# Generated at 2022-06-21 00:31:31.315813
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert Conditional().extract_defined_undefined('') == []
    assert Conditional().extract_defined_undefined('a not is undefined') == [('a', 'not is', 'undefined')]
    assert Conditional().extract_defined_undefined('a is defined and b not is undefined') == [('a', 'is', 'defined'), ('b', 'not is', 'undefined')]
    assert Conditional().extract_defined_undefined('a is defined and b is not defined') == [('a', 'is', 'defined'), ('b', 'is not', 'defined')]



# Generated at 2022-06-21 00:31:37.321098
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.task import Task
    class DummyClass():
        _when = None
        when = None

    d = DummyClass()
    assert d._when is None
    assert d.when is None

    d = Conditional()
    assert d._when is not None
    assert d.when is not None

# Generated at 2022-06-21 00:31:41.363531
# Unit test for constructor of class Conditional
def test_Conditional():
    import pytest

    class MyClass(object):
        pass

    # Test no loader
    with pytest.raises(AnsibleError) as error_message:
        Conditional()
    assert "a loader must be specified" in error_message

    # Test loader
    Conditional(MyClass())

# Generated at 2022-06-21 00:31:51.588405
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    def test(cond, result):
        print("[%s] [%s]" % (cond, result))
        c = Conditional()
        assert c.extract_defined_undefined(cond) == result

    test("a is defined", [(u"a", u"is", u"defined")])
    test("a is not defined", [(u"a", u"is not", u"defined")])
    test("a is undefined", [(u"a", u"is", u"undefined")])
    test("a is not undefined", [(u"a", u"is not", u"undefined")])
    test("hostvars['a'] is defined", [(u"hostvars['a']", u"is", u"defined")])