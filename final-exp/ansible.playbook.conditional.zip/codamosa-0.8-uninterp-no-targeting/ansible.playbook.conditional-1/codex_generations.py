

# Generated at 2022-06-21 00:22:01.394143
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    c = Conditional(loader)



# Generated at 2022-06-21 00:22:11.064581
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars import VariableManager

    try:
        import astor
    except ImportError:
        # python 2.6
        import unittest2 as unittest
    else:
        import unittest

    class TestConditional(unittest.TestCase, Conditional):
        def test_evaluate(self):
            play_context = dict(
                user='johndoe',
                password='ANSIBLE',
                connection='local',
                port=4444,
                become_user='root',
                become_password='ANSIBLE',
            )
            loader = 'some_path'
            templar = Templar(loader=loader, variables={})
            templar.available_variables = play_

# Generated at 2022-06-21 00:22:23.441386
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager._options = {'syntax': 'yaml', 'extravars': {'hostvars': {'localhost': {'myhost': 'myhost.home'}}}}
    pbex = PlaybookExecutor([{'hosts': 'localhost', 'roles': []}], inventory, variable_manager, loader, 'localhost', 'playbook')

# Generated at 2022-06-21 00:22:33.207660
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    DEFAULT_VA = {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'}


# Generated at 2022-06-21 00:22:40.473081
# Unit test for constructor of class Conditional
def test_Conditional():
    '''
        test1: test the initialization of Conditional class
        test2: test the initialization of Conditional class
    '''

    conditional = Conditional()

    try:
        conditional.__init__()
    except AnsibleError:
        pass
    else:
        raise AssertionError

    try:
        conditional.__init__(loader=1)
    except AnsibleError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-21 00:22:52.251479
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    conditional = Conditional()
    loader = DummyLoader()
    conditional._loader = loader
    templar = Templar(loader=loader, variables=VariableManager())
    conditional.when = ['1']
    assert conditional.evaluate_conditional(templar, {})
    conditional.when = [False]
    assert not conditional.evaluate_conditional(templar, {})
    conditional.when = ['1 == 1']
    assert conditional.evaluate_conditional(templar, {})
    conditional.when = ['1 != 1']
    assert not conditional.evaluate_conditional(templar, {})
    conditional.when = ['a != 1']
    assert conditional.evaluate_conditional(templar, {'a': 2})

# Generated at 2022-06-21 00:22:59.367496
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # setup
    c = Conditional()
    c.when = [
        'a.b.c is defined and a.b.c < 1',
        'a.b.d is not defined',
        'a.b.e is defined and a.b.e < 5',
    ]

    all_vars = VariableManager()
    all_vars.extra_vars = dict(
        a=dict(
            b=dict(
                c=1,
                d=[],
                e=4
            ),
        ),
    )

    templar = Templar(loader=None, variables=all_vars)
    templar._available_variables = all_v

# Generated at 2022-06-21 00:23:10.479738
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    obj = Conditional()
    assert obj.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert obj.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert obj.extract_defined_undefined('foo not is defined') == [('foo', 'not is', 'defined')]
    assert obj.extract_defined_undefined('bar is defined and foo is undefined') == \
           [('bar', 'is', 'defined'), ('foo', 'is', 'undefined')]
    assert obj.extract_defined_undefined('bar is defined or foo not is defined') == \
           [('bar', 'is', 'defined'), ('foo', 'not is', 'defined')]
    assert obj.extract_defined_

# Generated at 2022-06-21 00:23:20.633184
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class TestClass(): pass
    test_class = TestClass()
    test_class.extract_defined_undefined = Conditional.extract_defined_undefined
    res = test_class.extract_defined_undefined("foo is undefined")
    assert res == [('foo', 'is', 'undefined')]
    res = test_class.extract_defined_undefined("foo not is defined")
    assert res == [('foo', 'not is', 'defined')]
    res = test_class.extract_defined_undefined("foo is not defined")
    assert res == [('foo', 'is not', 'defined')]
    res = test_class.extract_defined_undefined("hostvars['foo'] is undefined")

# Generated at 2022-06-21 00:23:23.833489
# Unit test for constructor of class Conditional
def test_Conditional():
    # Test need not do anything useful, simply instantiate and
    # destroy the Conditional class with no args
    Conditional()

# Generated at 2022-06-21 00:23:42.209460
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    class TestConditional(Conditional):
        pass

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    tc = TestConditional()

    results = tc.evaluate_conditional(variable_manager.templar, variable_manager.get_vars())
    assert results == True

    tc.when.append('foo')
    results = tc.evaluate_conditional(variable_manager.templar, variable_manager.get_vars())
   

# Generated at 2022-06-21 00:23:53.506645
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Test Ansible Conditional in ansible.playbook.conditional
    '''
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    # dummy functions to be used as a mock for loaders
    def find_file(path):
        return path
    def path_exists(path):
        return True
    # defining a PlayContext() object here
    pc = PlayContext()
    # defining a templar() object here
    mytemplar = Templar(loader=None)
    mytemplar._available_variables = {}
    mytemplar.environment = None
    # initializing class Conditional()
    mycond = Conditional(loader=None)
    # initializing variables to be used for testing
    myvars = {'myvar': 'foo'}

# Generated at 2022-06-21 00:24:01.698436
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Looping over a list with different conditional statements
    for conditional in ['hostvars[inventory_hostname] is defined',
                        'hostvars[inventory_hostname] not is defined',
                        'hostvars[inventory_hostname] is undefined',
                        'hostvars[inventory_hostname] not is undefined',
                        'A is defined',
                        'B is undefined']:
        c = Conditional()
        # Assert statements for different conditional statements
        assert c.extract_defined_undefined(conditional) == [(conditional.split()[0], conditional.split()[1], conditional.split()[2])]

# Generated at 2022-06-21 00:24:08.707357
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    if C.DEFAULT_DEBUG:
        display.display("test_Conditional_extract_defined_undefined:")
        display.display("test_Conditional_extract_defined_undefined: test cases:")
        display.display("test_Conditional_extract_defined_undefined:   'status is changed'")
        display.display("test_Conditional_extract_defined_undefined:   'status is not changed'")
        display.display("test_Conditional_extract_defined_undefined:   'status is changed or some_var is defined'")
        display.display("test_Conditional_extract_defined_undefined:   'status is not changed or foo is registered'")
        display.display("test_Conditional_extract_defined_undefined:")

    conditional = Conditional()


# Generated at 2022-06-21 00:24:20.295477
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Create a Conditional object
    c = Conditional()
    # We should be able to define a list of whens.
    # The result of evaluate_conditional should be True only if all whens are True
    c.when = [True, True, True]
    assert c.evaluate_conditional(None, None) == True
    c.when = [True, False, True]
    assert c.evaluate_conditional(None, None) == False

    # the next tests are trying to reproduce #96680, ensure the method
    # fails gracefully

# Generated at 2022-06-21 00:24:29.431042
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    module_name = C.DEFAULT_MODULE_NAME
    module_args = {}

# Generated at 2022-06-21 00:24:40.165627
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from yaml import YAMLObject
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    class Play(AnsibleBaseYAMLObject):
        # We need to supply a loader class when using Conditional() directly
        def __init__(self, loader=None):
            super(Play, self).__init__()
            self._loader = loader
            self._ds = None
            self._parent = None
            self._role = None
            self._playbook = None
            self._block = None
            self._task = None
            self._connection = 'local'
            self._play_context = None
            self._task_vars = dict()
            self._search_paths = None
            self._loader_cache = None


# Generated at 2022-06-21 00:24:48.787101
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    class MyConditional(Conditional):

        def __init__(self, ds):
            super(MyConditional, self).__init__()
            self._ds = ds
            self.when = ds.get('when', [])

    def run_test(test):
        ds = {
            'task1': {'when': test.get('when', None)},
            'task2': {'when': test.get('when', None)},
        }
        play_context = dict(
            become_user='root',
            become_method='sudo'
        )
        variable_manager = VariableManager()
        templar = Templar(loader=None, variables=variable_manager)


# Generated at 2022-06-21 00:25:00.557146
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    Test method extract_defined_undefined of Conditional

    This validates that Conditional.extract_defined_undefined() properly extracts
    variables from the conditional string.
    '''
    from ansible.playbook.task import Task
    from ansible.template import Templar

    # validates that an empty conditional string returns an empty list
    assert Conditional().extract_defined_undefined('') == []

    # validates that a conditional string with no variables returns an empty list
    conditional = "test1 and test2"
    assert Conditional().extract_defined_undefined(conditional) == []

    # validates that a conditional string with a single defined/undefined variable returns a list with the
    # variables defined and the reference to the variable
    conditional = "var is defined"
    assert Conditional().extract_defined_

# Generated at 2022-06-21 00:25:06.359614
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """Tests calling Conditional.evaluate_conditional"""
    tc = Conditional()
    res = tc.evaluate_conditional("hostvar == 'hostvars[hostvar]'", 'hostvar', 'hostvars[hostvar]')
    assert(res)

    res = tc.evaluate_conditional("hostvar == 'hostvars'", 'hostvar', 'hostvars')
    assert(res)


# Generated at 2022-06-21 00:25:26.487915
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.task_include import TaskInclude
    task_include = TaskInclude()
    # Tests:
    #       when: myvar is undefined
    #       when: not (hostvars['host1']['ipv4']['address'] is defined) and hostvars['host1']['ipv6']['address'] is defined
    assert task_include.extract_defined_undefined('myvar is undefined') == [('myvar', 'is', 'undefined')]

# Generated at 2022-06-21 00:25:36.496188
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Test with variable
    for value in [True, False]:
            results = Conditional().evaluate_conditional(templar=MockTemplar(), all_vars={'foo': value}, conditional='foo')
            assert results == value

    # Test with variable that contains special characters
    for var in ['f"o\'o', u'f"o\'o']:
        for value in [True, False]:
            results = Conditional().evaluate_conditional(templar=MockTemplar(), all_vars={var: value}, conditional=var)
            assert results == value

    # Test with undefined variable (should fail)

# Generated at 2022-06-21 00:25:47.808799
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    conditional_extract_defined_undefined = conditional.extract_defined_undefined
    assert conditional_extract_defined_undefined('hostvar is undefined') == \
        [('hostvar', 'is', 'undefined')]
    assert conditional_extract_defined_undefined('hostvar is not defined') == \
        [('hostvar', 'is not', 'defined')]
    assert conditional_extract_defined_undefined('hostvar is defined') == \
        [('hostvar', 'is', 'defined')]
    assert conditional_extract_defined_undefined('hostvar is not undefined') == \
        [('hostvar', 'is not', 'undefined')]

# Generated at 2022-06-21 00:25:54.396922
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Prepare
    class TestConditional(Conditional):
        def __init__(self):
            pass
    test_obj = TestConditional()

    # Run
    function_result = test_obj.extract_defined_undefined("foo is defined and bar is not defined")
    # Verify
    function_expected_result = [
        ('foo', 'is', 'defined'),
        ('bar', 'is not', 'defined'),
    ]
    assert function_result == function_expected_result

# Generated at 2022-06-21 00:26:01.502654
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import json
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.extra_vars = {
        'user_a': 'John',
        'user_b': 'Alice',
        'users': ['John', 'Alice'],
        'key': 'value',
        'key2': 'value2',
        'key3': 'value3',
        'key4': 'value4',
    }

    # test with item in list
    context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager)

# Generated at 2022-06-21 00:26:09.130338
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    conditional = '''   (var1 is defined or var2 is defined) and var3 is not defined'''
    list_cond = ['var1', ' is ', 'defined']

    assert cond.extract_defined_undefined(conditional) == [['var1', 'is', 'defined'], ['var2', 'is', 'defined'], ['var3', 'is not', 'defined']]
    assert cond.extract_defined_undefined('') == []
    assert cond.extract_defined_undefined(list_cond) == []


# Generated at 2022-06-21 00:26:19.989210
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    host = inventory.get_host('localhost')
    variable_manager.set_host_variable(host, 'my_var', "a string")
    variable_manager.set_host_variable(host, 'my_var2', 42)
    variable_manager.set_host_variable(host, 'my_var3', True)

# Generated at 2022-06-21 00:26:29.830380
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    # testing for multiple defined/undefined and multiple logic operators

# Generated at 2022-06-21 00:26:32.689299
# Unit test for constructor of class Conditional
def test_Conditional():
    # make sure the constructed object has all the attributes defined
    # in the class
    c = Conditional()
    assert c._when == list
    assert c.when == []

# Generated at 2022-06-21 00:26:34.338345
# Unit test for constructor of class Conditional
def test_Conditional():

    # Just to test if the constructor works
    module = Conditional()
    assert isinstance(module, Conditional)

# Generated at 2022-06-21 00:27:03.042696
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    #--
    # test cases
    #--
    test_cases = [
        {
            'name': "basic",
            'when': "debug_var == True",
            'item': (True,  True),
            'item_name': "debug_var",
            'all_vars': { "debug_var": True },
            'res': True,
        },
        {
            'name': "failing",
            'when': "debug_var == True",
            'item': (False, False),
            'item_name': "debug_var",
            'all_vars': { "debug_var": True },
            'res': False,
        },
    ]

    #--
    # mock data for test
    #--
    class MockData:
        def __init__(self):
            self

# Generated at 2022-06-21 00:27:04.818443
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional_class_obj = Conditional()
    assert conditional_class_obj._when == [], "conditional class is not created with when list"

# Generated at 2022-06-21 00:27:12.342576
# Unit test for constructor of class Conditional
def test_Conditional():
    class MyConditional(Conditional):
        def __init__(self, loader=None):
            super(MyConditional, self).__init__(loader=loader)

    try:
        MyConditional()
    except AnsibleError as e:
        assert 'loader must be specified' in str(e)
    except Exception as e:
        pytest.fail("AnsibleError should have been raised but received %s instead" % repr(e))
    try:
        MyConditional(loader=None)  # noqa
    except AnsibleError as e:
        assert 'loader must be specified' in str(e)
    except Exception as e:
        pytest.fail("AnsibleError should have been raised but received %s instead" % repr(e))


# Tests for method evaluate_conditional

# Generated at 2022-06-21 00:27:18.247604
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class DummyObj(Conditional):
        def __init__(self, loader=None):
            super(DummyObj, self).__init__()
            self.when = []

    opts = {
        'no_log': True,
        'vault_password_file': C.DEFAULT_VAULT_PASSWORD_FILE,
    }
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    templar = Templar(loader=loader, variables=variable_manager, options=opts)
    var_manager = VariableManager()

    obj = DummyObj(loader)

    # Empty conditional
    obj.when = []


# Generated at 2022-06-21 00:27:25.283628
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    #from ansible.utils.unsafe_proxy import wrap_var

    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    # create variable manager
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'hostvars': {'localhost:5678': {'foo': 'bar'}}}
    variable_manager.set_nonpersistent_facts(dict(test_var=True))
    inventory = InventoryManager(loader=None, sources=[])
    variable_manager.set_inventory(inventory)

    # create jinja2 environment
    j2_env = variable_manager.get_templar().environment

    # create context
    context = PlayContext()

   

# Generated at 2022-06-21 00:27:37.958012
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    class TestClass(Conditional):
        pass

    c = TestClass()
    t = Templar(loader=None, variables={u'hostvars': {u'hostname': {u'key': u'value'}}})
    assert c.evaluate_conditional(t, {'foo': 'bar'}) == True
    c.when = [ None, False, '', 'True' ]
    assert c.evaluate_conditional(t, {'foo': 'bar'}) == False
    c.when = [ 'False' ]
    assert c.evaluate_conditional(t, {'foo': 'bar'}) == False
    c.when = [ 'True' ]
    assert c.evaluate_conditional(t, {'foo': 'bar'}) == True

# Generated at 2022-06-21 00:27:46.763076
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    all_vars = dict()
    templar = Templar(loader=None, variables=all_vars)

    # initialize the Conditional object
    c = Conditional()

    # test 1: check that all True values return True
    c._when = ["True", True, 1, "1", dict(), list(), tuple(), "something", "something else"]
    assert c.evaluate_conditional(templar, all_vars)

    # test 2: check that all False values return False

# Generated at 2022-06-21 00:27:51.904651
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.base import Base

    # Object of class Base
    b = Base()
    c = Conditional()

    assert c.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert c.extract_defined_undefined('foo is not defined') == [('foo', 'is not', 'defined')]
    assert c.extract_defined_undefined('foo is undefined') == [('foo', 'is', 'undefined')]
    assert c.extract_defined_undefined('foo is not undefined') == [('foo', 'is not', 'undefined')]
    assert c.extract_defined_undefined('foo and bar is defined') == [('foo', 'and', 'bar'), ('bar', 'is', 'defined')]
    assert c.ext

# Generated at 2022-06-21 00:27:57.447479
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    assert Conditional(loader)



# Generated at 2022-06-21 00:27:59.097655
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c


# Generated at 2022-06-21 00:28:46.259916
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = '''
    (hostvars['foo'] is defined) or
    ((hostvars['bar'] is defined) and (hostvars['baz'] is undefined))
    '''
    assert Conditional().extract_defined_undefined(conditional) == [
            ('hostvars[\'foo\']', 'is', 'defined'),
            ('hostvars[\'bar\']', 'is', 'defined'),
            ('hostvars[\'baz\']', 'is', 'undefined')
    ]

# Generated at 2022-06-21 00:28:53.406578
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestObj(object):
        pass

    # Create a simple templar object
    from ansible.template.template import Templar
    templar = Templar(loader=None, shared_loader_obj=None)

    # Create a simple Conditional object
    conditional = Conditional()

    # Simple valid conditional
    test_obj = TestObj()
    test_obj.when = None
    test_obj.ds = None
    result = conditional.evaluate_conditional(templar, test_obj)
    assert result is True

    test_obj.when = True
    result = conditional.evaluate_conditional(templar, test_obj)
    assert result is True

    test_obj.when = False
    result = conditional.evaluate_conditional(templar, test_obj)
    assert result is False


# Generated at 2022-06-21 00:28:56.775718
# Unit test for constructor of class Conditional
def test_Conditional():
    display = Display()
    display.verbosity = 3

    conditional = Conditional(loader=None)
    assert conditional.when == []

    conditional = Conditional(loader="foobar")
    assert conditional.when == []

# Generated at 2022-06-21 00:29:06.227550
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''
    unit test for method extract_defined_undefined of class Conditional

    :return: bool
    '''

# Generated at 2022-06-21 00:29:13.824870
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.module_utils.facts import Facts

    global_vars = {
        'inventory_hostname': 'foo',
        'groups': {
            'group1': ['foo'],
        },
        'group_names': ['group1']
    }

    host_vars = {
        'inventory_hostname': 'foo',
        'hostvar': 'bar'
    }

    facts = Facts({})

    m = Conditional()
    m._loader = None

    try:
        m.evaluate_conditional(facts, host_vars)
    except Exception as e:
        raise AssertionError(
            "An exception should not be raised if there is no conditional: %s" % to_native(e))

    m.when = None

# Generated at 2022-06-21 00:29:20.191038
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-21 00:29:24.970139
# Unit test for constructor of class Conditional
def test_Conditional():
    # Conditional instantiation without loader argument should fail
    assert Conditional() == "AnsibleError('a loader must be specified when using Conditional() directly')"
    # Conditional instantiation with mock loader should succeed
    assert Conditional(loader=None) == None


# Generated at 2022-06-21 00:29:34.897362
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("") == []
    assert cond.extract_defined_undefined("foo") == []
    assert cond.extract_defined_undefined("foo is defined") == [('foo', 'is', 'defined')]
    assert cond.extract_defined_undefined("foo not is undefined") == [('foo', 'not is', 'undefined')]
    assert cond.extract_defined_undefined("foo is defined and bar is defined") == [('foo', 'is', 'defined'),
                                                                                     ('bar', 'is', 'defined')]

# Generated at 2022-06-21 00:29:42.358850
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional(None)
    assert [] == c.extract_defined_undefined('')
    assert [('foo', 'is', 'defined')] == c.extract_defined_undefined('foo is defined')
    assert [('foo', 'is', 'undefined')] == c.extract_defined_undefined('foo is undefined')
    assert [('foo', 'not', 'defined')] == c.extract_defined_undefined('foo not defined')
    assert [('foo', 'not', 'undefined')] == c.extract_defined_undefined('foo not undefined')
    assert [('foo', 'is', 'defined')] == c.extract_defined_undefined('foo   is       defined')

# Generated at 2022-06-21 00:29:54.980375
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    task = Conditional()
    inventory = None
    templar = Templar(loader=None, variables={u'ansible_distribution': u'CentOS'})
    result = task.evaluate_conditional(templar, {})
    assert result == True
    result = task.evaluate_conditional(templar, {u'ansible_distribution': u'CentOS'})
    assert result == True
    task._when.extend([u'ansible_distribution == "CentOS"', u'ansible_distribution == "Ubuntu"'])
    result = task.evaluate_conditional(templar, {u'ansible_distribution': u'CentOS'})
    assert result == True
    result = task.evaluate_conditional(templar, {u'ansible_distribution': u'Ubuntu'})

# Generated at 2022-06-21 00:31:20.078664
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cnd = Conditional()
    s = "foo is defined and bar is defined"
    actual = cnd.extract_defined_undefined(s)
    assert(actual == [(u'foo', u'is', u'defined'), (u'bar', u'is', u'defined')])

# Generated at 2022-06-21 00:31:31.210375
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.task import Task
    from ansible.template import Templar

    module_loader = DictDataLoader({
        "noncond.yml": '''---
- hosts: localhost
  tasks:
    - name: foo
      debug:
        msg: "This should succeed"
    - name: bar
      debug:
        msg: "This should fail"
      when: false
'''
    })

    inventory = Inventory(loader=module_loader, variable_manager=VariableManager(), host_list=['localhost'])
    variable_manager = inventory.get_variable_manager()
    templar = Templar(loader=DataLoader(), variables=variable_manager.get_vars(play=Play.load(None, variable_manager, loader=module_loader, templar=templar)))
    pb = Play

# Generated at 2022-06-21 00:31:42.360278
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    try:
        from ansible.module_utils.six import PY2
    except ImportError:
        pass
    pass
    cond = Conditional()

# Generated at 2022-06-21 00:31:51.910367
# Unit test for method extract_defined_undefined of class Conditional