

# Generated at 2022-06-21 00:22:08.477041
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from datetime import datetime
    play_context = PlayContext()

# Generated at 2022-06-21 00:22:15.282444
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()


# Generated at 2022-06-21 00:22:27.232982
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # indirect call
    conditional_when = Conditional()
    # simple case of one condition
    conditional = "variable1 is defined"
    expected_results = [('variable1',' is','defined')]
    assert conditional_when.extract_defined_undefined(conditional) == expected_results
    # case of one condition with extra spaces
    conditional = "  variable1   is defined  "
    expected_results = [('variable1',' is','defined')]
    assert conditional_when.extract_defined_undefined(conditional) == expected_results
    # case of two conditions
    conditional = "variable1 is defined and variable2 is undefined"
    expected_results = [('variable1',' is','defined'),('variable2',' is','undefined')]
    assert conditional_when.extract_defined_undefined(conditional) == expected_results

# Generated at 2022-06-21 00:22:32.930001
# Unit test for constructor of class Conditional
def test_Conditional():
    # test requirement: ansible/test/units/test_ansible_module_include.py
    # test requirement: ansible/test/units/test_ansible_module_include_conditional_static.py
    try:
        from ansible.test.units.test_ansible_module_include import TestInclude as base
    except ImportError:
        return
    class TestInclude(base, Conditional):
        pass
    return TestInclude('test_conditional')

# Generated at 2022-06-21 00:22:44.579301
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    class TestConditional(Conditional):
        def __init__(self, loader=None):
            super(TestConditional, self).__init__(loader)

        def __getattr__(self, name):
            return None

        def __setattr__(self, name, value):
            pass

    import ansible.template.template as template

    display.verbosity = 3
    display.deprecation = "debug"


# Generated at 2022-06-21 00:22:55.631489
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # TODO: fix me
    data = {
        'foo': 'bar',
        'undef': None,
        'list': [ 'a', 'b', 'c' ],
        'dict': { 'a':1, 'b':2, 'c':3 },
        'nonempty': 'abc',
        'zero': 0,
        'one': 1,
    }

    for x in data:
        assert isinstance(x, text_type)

    # TODO these tests should not be using the global display object
    # display.verbosity = 3

    # Create a conditional object
    class Cond(object):
        def __init__(self):
            self._loader = MockVarsModuleLoader()
            self._ds = None
        def attribute(self, name, value):
            return value
    c = Conditional()


# Generated at 2022-06-21 00:22:56.772654
# Unit test for constructor of class Conditional
def test_Conditional():
    t = Conditional(loader=None)

# Generated at 2022-06-21 00:23:07.982440
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-21 00:23:18.701950
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert Conditional().extract_defined_undefined(''                  ) == []    # Empty string
    assert Conditional().extract_defined_undefined('foo'               ) == []    # A string w/o 'defined'
    assert Conditional().extract_defined_undefined('foo.bar'           ) == []    # A string w/o 'defined'
    assert Conditional().extract_defined_undefined('foo.bar is defined') == [('foo.bar', 'is',   'defined')] # A simple 'is defined'
    assert Conditional().extract_defined_undefined('foo.bar is not defined') == [('foo.bar', 'is not', 'defined')] # A simple 'is not defined'

# Generated at 2022-06-21 00:23:25.014116
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Setup
    conditional = 'test'
    loader = mock.create_autospec(Loader)
    templar = mock.create_autospec(Templar)
    templar.is_template.return_value = False
    templar.template.return_value = 1
    templar.environment.parse.return_value = mock.MagicMock()
    generate.return_value = conditional
    all_vars = {}
    Conditional_obj = Conditional(loader=loader)
    Conditional_obj._check_conditional = mock.MagicMock()

    # Test 1
    Conditional_obj.when = [conditional]
    Conditional_obj.evaluate_conditional(templar, all_vars)
    templar.is_template.assert_called_with(conditional)
   

# Generated at 2022-06-21 00:23:41.655723
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Test an empty string.
    result = Conditional().extract_defined_undefined('')
    assert result == [], "The result: %s is not an empty list." % result

    # Test a non-matching string.
    result = Conditional().extract_defined_undefined('a')
    assert result == [], "The result: %s is not an empty list." % result

    # Test a complex string with matches.
    result = Conditional().extract_defined_undefined('a is defined or b is not defined or c is defined')
    assert result == [('a', 'is', 'defined'), ('b', 'is', 'not defined'), ('c', 'is', 'defined')], "The result: %s is not as expected." % result


# Generated at 2022-06-21 00:23:52.580998
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

# Generated at 2022-06-21 00:23:56.761753
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    class TestClass(Conditional):
        pass

    loader = DictDataLoader({})
    templar = Templar(loader=loader, variables={"bar": "3"})

    t = TestClass()
    t.when = "foo"
    result = t.evaluate_conditional(templar)
    assert result == True

    t.when = "foo"
    result = t.evaluate_conditional(templar, {"foo": True})
    assert result == True

    t.when = "foo is defined"
    result = t.evaluate_conditional(templar, {"foo": True})
    assert result == True

    t.when = "foo is defined"
    result = t.evaluate_conditional(templar, {"foo": ""})
    assert result == True

    t.when = "foo is defined"

# Generated at 2022-06-21 00:24:05.996864
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    var = "hostvars['hostname_shorthand'] == undefined or (hostvars['hostname_shorthand'] | default(False)) == False"
    defined_undefined = conditional.extract_defined_undefined(var)
    assert defined_undefined == [("hostvars['hostname_shorthand']", '==', 'undefined'),
                                 ("hostvars['hostname_shorthand']", '|', 'default'),
                                 ('False', '==', 'False')]
    undefined = "hostvars['hostname_shorthand'] is undefined"
    defined_undefined = conditional.extract_defined_undefined(undefined)
    assert defined_undefined == [("hostvars['hostname_shorthand']", 'is', 'undefined')]
   

# Generated at 2022-06-21 00:24:17.350212
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    conditional = Conditional()
    conditional.when = ['foo and bar and baz']
    result = conditional.evaluate_conditional(None, dict(foo=True, bar=True, baz=True))
    assert result

    conditional.when = ['foo and bar and baz']
    result = conditional.evaluate_conditional(None, dict(foo=True, bar=True, baz=False))
    assert not result

    conditional.when = ['foo and bar or baz']
    result = conditional.evaluate_conditional(None, dict(foo='yes', bar='yes', baz=True))
    assert result

    conditional.when = ['foo and bar or baz']
    result = conditional.evaluate_conditional(None, dict(foo='yes', bar='yes', baz=False))
    assert result


# Generated at 2022-06-21 00:24:18.785090
# Unit test for constructor of class Conditional
def test_Conditional():
    """
    Test that the constructor of the class Conditional doesn't fail
    """
    pass

# Generated at 2022-06-21 00:24:28.617742
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    assert conditional.extract_defined_undefined("1") == []
    assert conditional.extract_defined_undefined("v is defined") == [("v", "is", "defined")]
    assert conditional.extract_defined_undefined("v is defined or v is undefined") == [("v", "is", "defined"), ("v", "is", "undefined")]
    assert conditional.extract_defined_undefined("v is defined and v is undefined") == [("v", "is", "defined"), ("v", "is", "undefined")]
    assert conditional.extract_defined_undefined("v is not defined") == [("v", "is not", "defined")]

# Generated at 2022-06-21 00:24:30.296218
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert isinstance(conditional, Conditional)


# Generated at 2022-06-21 00:24:40.992803
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-21 00:24:49.276531
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    ''' test conditional parsing '''

    cond = Conditional()

    results = cond.extract_defined_undefined(u'''
    a is defined and b is defined
    ''')
    assert results == [(u'a', u'is', u'defined'), (u'b', u'is', u'defined')]

    results = cond.extract_defined_undefined(u'''
    a not is undefined or b not is undefined
    ''')
    assert results == [(u'a', u'not is', u'undefined'), (u'b', u'not is', u'undefined')]

    results = cond.extract_defined_undefined(u'''
    a is defined and b is defined or
    c is defined and d is defined
    ''')

# Generated at 2022-06-21 00:25:00.503953
# Unit test for constructor of class Conditional
def test_Conditional():
    testObj = Conditional()
    assert testObj._when == []



# Generated at 2022-06-21 00:25:02.735295
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    data = DataLoader()

    m = Conditional()
    assert m._when == []

# Generated at 2022-06-21 00:25:07.653163
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined("(1 == 1) or (single_quote_var is defined) or (double_quote_var is defined)") == \
        [('single_quote_var', 'is', 'defined'), ('double_quote_var', 'is', 'defined')]



# Generated at 2022-06-21 00:25:15.247917
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.vars import VariableManager

    loader = '<string>'
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts({'test_facts': {'test_int_facts': 4}})
    variable_manager.extra_vars = {'test_extra_vars': {'test_int_extra_vars': 3}}
    variable_manager.host_vars = {'test_host_vars': {'test_int_host_vars': 2}}
    variable_manager.group_vars = {'test_group_vars': {'test_int_group_vars': 1}}

    # equality test
    conditional = Conditional(loader)

# Generated at 2022-06-21 00:25:26.923568
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    import unittest
    import mock

    class TestConditional(Conditional):
        def __init__(self):
            super(TestConditional, self).__init__()

    c = TestConditional()


# Generated at 2022-06-21 00:25:36.753466
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{ ansible_hostname }}')))
        ]
    )
    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    results = []
    result = play._match_hosts(pattern='localhost')
    assert result == results


# Generated at 2022-06-21 00:25:39.672548
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert hasattr(c, '_when')
    assert c._when == list
    assert hasattr(c, '_loader')


# Generated at 2022-06-21 00:25:48.818132
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.base import Base
    from ansible.plugins.loader import load_plugins

    load_plugins()
    base = Base()
    conditional = Conditional()
    conditional.when = "ansible_eth0.ipv6"
    all_vars = {
        "ansible_eth0": {
            "ipv6": [{
                "address": "2001:db8:1234::1",
                "prefix": "64",
                "scope": "link"
            }]
        }
    }
    assert conditional.evaluate_conditional(base.templar, all_vars)



# Generated at 2022-06-21 00:25:55.991896
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    to_test = "hostvars['foo'] is not defined or hostvars['bar'] is not defined or hostvars['baz'] is defined"
    results = conditional.extract_defined_undefined(to_test)
    assert results == [('hostvars[\'foo\']', 'not is', 'defined'),
                       ('hostvars[\'bar\']', 'not is', 'defined'),
                       ('hostvars[\'baz\']', 'is', 'defined')]

# Generated at 2022-06-21 00:26:07.968629
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext

    if not has_required_jinja2(2, 8):
        raise SkipTest

    templar = Templar(loader=DictDataLoader())
    play_context = PlayContext()
    assert play_context.evaluate_conditional('1 == 1', templar, {}) is True
    assert play_context.evaluate_conditional('1 == 2', templar, {}) is False
    play_context.check_conditional = True
    with pytest.raises(AnsibleError):
        play_context.evaluate_conditional('{{ 1 == 2 }}', templar, {})



# Generated at 2022-06-21 00:26:35.850666
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    c = Conditional()
    assert c.evaluate_conditional(None,{"a":1,"b":2}) == True

    c.when = ["a == 1"]
    assert c.evaluate_conditional(None,{"a":1,"b":2}) == True

    c.when = ["a == 3"]
    assert c.evaluate_conditional(None,{"a":1,"b":2}) == False

    c.when = ["b == 2"]
    assert c.evaluate_conditional(None,{"a":1,"b":2}) == True

    c.when = ["b == 3"]
    assert c.evaluate_conditional(None,{"a":1,"b":2}) == False

    c.when = ["a == 1","b == 2"]

# Generated at 2022-06-21 00:26:44.681506
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Unit test for method evaluate_conditional of class Conditional
    '''

    module_utils_path = ansible.module_utils.__path__[0]
    if not os.path.isdir(module_utils_path):
        print("ansible.module_utils path not found %s" % module_utils_path)
        sys.exit(1)

    if not os.path.isdir('/tmp/test/module_utils'):
        os.makedirs('/tmp/test/module_utils')
    shutil.copy(module_utils_path + '/urls.py', '/tmp/test/module_utils')

    ##################
    # Unit test for evaluate_conditional method of class Conditional
    ##################
    from ansible.module_utils.urls import open_url
   

# Generated at 2022-06-21 00:26:50.953478
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert [] == cond.extract_defined_undefined('True')
    assert [] == cond.extract_defined_undefined('f.bar')
    assert [(u'f', u'is', u'undefined')] == cond.extract_defined_undefined('f is undefined')
    assert [(u'f', u'not is', u'undefined')] == cond.extract_defined_undefined('f not is undefined')
    assert [(u'f', u'is', u'undefined')] == cond.extract_defined_undefined('f is undefined and False is False')
    assert [(u'f', u'is', u'undefined')] == cond.extract_defined_undefined('a and f is undefined')

# Generated at 2022-06-21 00:27:00.896634
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # Example 1
    TEST_EXAMPLE_1 = "foo is defined and bar is not defined"
    x = Conditional()
    assert x.extract_defined_undefined(TEST_EXAMPLE_1) == [('foo', 'is', 'defined'), ('bar', 'is', 'not defined')]

    # Example 2
    TEST_EXAMPLE_2 = "foo is defined and bar is undefined and foobar is defined and barfoo is not defined"
    x = Conditional()
    assert x.extract_defined_undefined(TEST_EXAMPLE_2) == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined'), ('foobar', 'is', 'defined'), ('barfoo', 'is', 'not defined')]

    # Example 3

# Generated at 2022-06-21 00:27:02.031456
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    assert Conditional.evaluate_conditional(None, None, {}) is True

# Generated at 2022-06-21 00:27:10.250561
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None)

    # load_callback_plugins()
    from ansible.plugins.loader import callback_loader
    callback_loader._load_plugins()

    # load_filter_plugins()
    from ansible.plugins.loader import filter_loader
    filter_loader._load_plugins()

    # load_test_plugins()
    from ansible.plugins.loader import test_loader
    test_loader._load_plugins()

    # load_lookup_plugins()
    from ansible.plugins.loader import lookup_loader
    lookup_loader._load_plugins()

    # load_action_plugins()

# Generated at 2022-06-21 00:27:16.718598
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    '''Unit test for method extract_defined_undefined of class Conditional'''
    cond = Conditional()
    if cond.extract_defined_undefined('defined') != []:
        raise AssertionError('condition does not match regex')
    if cond.extract_defined_undefined('defined defined') != []:
        raise AssertionError('condition does not match regex')
    if cond.extract_defined_undefined('hostvars["foo"] is defined') != \
            [('hostvars["foo"]', 'is', 'defined')]:
        raise AssertionError('condition does not match regex')

# Generated at 2022-06-21 00:27:23.484738
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.base import Base
    class TestBase(Base, Conditional):
        pass

    vars = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': 'abc',
        'e': [1,2,3,4],
        'f': {'a': 1, 'b': 2},
        'g': {'n1': {'b': 1, 'n2': {'c': 2}}, 'b': 2},
        'h': False,
        'i': True
    }
    templar = TestBase()
    templar._templar = templar

    # c == 3
    conditional = 'c == 3'
    assert templar.evaluate_conditional(conditional, vars)

    # a is 1

# Generated at 2022-06-21 00:27:30.558698
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined('not hostvars[inventory_hostname].ansible_ssh_host is defined or ( hostvars[inventory_hostname].ansible_ssh_host  is defined and hostvars[inventory_hostname].ansible_ssh_host  != "")') == [('hostvars[inventory_hostname].ansible_ssh_host', 'is', 'defined'), ('hostvars[inventory_hostname].ansible_ssh_host', 'is', 'defined')]


# Generated at 2022-06-21 00:27:41.961149
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    obj = Conditional()

# Generated at 2022-06-21 00:28:03.092239
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook import Play
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    import os

    c = Conditional()



# Generated at 2022-06-21 00:28:11.975855
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    # create fake playbooks
    test_playbook = [
        {'role_one': {
            'role_two': {
                'role_three': {
                    'role_four': {
                        'role_five': {}
                     }
                  }
               }
            }
         }
    ]

    # create fake play

# Generated at 2022-06-21 00:28:16.906163
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    condition = "foobar is defined or test is not defined or (test is undefined and ansible_net_version.stdout is not undefined)"
    o = Conditional()
    results = o.extract_defined_undefined(condition)
    assert ["foobar", "is", "defined"] in results
    assert ["test", "is", "not", "defined"] in results
    assert ["test", "is", "undefined"] in results
    assert ["ansible_net_version.stdout", "is", "not", "undefined"] in results


# Generated at 2022-06-21 00:28:17.363074
# Unit test for constructor of class Conditional
def test_Conditional():
    assert Conditional()

# Generated at 2022-06-21 00:28:25.905633
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.block import Block
    conditional = Conditional()
    b = Block()
    # Test for valid conditional
    result = conditional.extract_defined_undefined(b.when[0])
    assert result == [('hostvars["ansible_hostname"]', 'is', 'defined')]
    # Test for invalid conditional
    result = conditional.extract_defined_undefined(b.name)
    assert result == []
    # Test conditionals with mismatched quotes
    result = conditional.extract_defined_undefined('hostvars[\'ansible_hostname\'] is undefined')
    assert result == [('hostvars["ansible_hostname"]', 'is', 'undefined')]
    result = conditional.extract_defined_undefined('hostvars["ansible_hostname"] is undefined')

# Generated at 2022-06-21 00:28:27.672878
# Unit test for constructor of class Conditional
def test_Conditional():
    class_instance = Conditional(loader=None)
    assert isinstance(class_instance, Conditional)

# Generated at 2022-06-21 00:28:32.337374
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook import Playbook
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)

    # Test playbook constructor
    playbook = Playbook.load('test.yml', loader=loader, inventory=inventory)
    assert playbook._entries[0]._ds is not None
    assert playbook._entries[0].when[0] == 'fake_var == true'

# Generated at 2022-06-21 00:28:41.639079
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('bar is not defined') == [('bar', 'is not', 'defined')]
    assert c.extract_defined_undefined('bar is not defined and baz is defined') == [('bar', 'is not', 'defined'), ('baz', 'is', 'defined')]
    assert c.extract_defined_undefined('bar is not defined and baz not is defined') == [('bar', 'is not', 'defined'), ('baz', 'not is', 'defined')]
    assert c.extract_defined_undefined('bar is not defined and baz not is defined or cmp == 5') == [('bar', 'is not', 'defined'), ('baz', 'not is', 'defined')]

# Generated at 2022-06-21 00:28:50.080569
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    context = PlayContext(become=False)
    templar = Templar(loader=None, variables=dict())
    module = Conditional()

    # when
    conditional_w = "{{ ansible_facts['distribution'] == 'CentOS' }}"
    when_w = [conditional_w]
    module._when = when_w

    assert conditional_w in module._when

    # when_each
    conditional_we = "{{ ansible_facts['distribution'] == 'CentOS' }}"
    when_each_we = [conditional_we]
    module._when_each = when_each_we

    assert conditional_we in module._when_each

    # when_in

# Generated at 2022-06-21 00:28:56.387744
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.plugins.loader import lookup_loader

    def evaluate_conditional(conditional, vars):
        obj = Conditional()
        obj._loader = loader
        return obj.evaluate_conditional(templar, vars)

    class my_loader(object):
        def get_basedir(self, hostname):
            return '/dev/null'

        def path_dwim(self, cwd, source):
            return cwd + '/' + source

    loader = my_loader()
    lookup_plugin = lookup_loader._create_lookup_plugin()
    templar = lookup_plugin._templar

    # We do not want to trigger a deprecation warning since we are
    # testing the code path that triggers the warning.
    C.DEFAULT_HASH_BEHAVIOUR = 'merge'

# Generated at 2022-06-21 00:29:59.695785
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    x = Conditional()
    assert x.extract_defined_undefined('') == []
    assert x.extract_defined_undefined('foo') == []
    assert x.extract_defined_undefined('foo is defined') == [('foo', 'is', 'defined')]
    assert x.extract_defined_undefined('foo is defined and bar is undefined') == [('foo', 'is', 'defined'), ('bar', 'is', 'undefined')]
    assert x.extract_defined_undefined('foo is not defined and bar is undefined') == [('foo', 'is not', 'defined'), ('bar', 'is', 'undefined')]
    assert x.extract_defined_undefined('hostvars["host"] is undefined') == [('hostvars["host"]', 'is', 'undefined')]

# Generated at 2022-06-21 00:30:08.301591
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    # No loader specified
    cond = Conditional()
    assert cond, "Constructor did not create a Conditional object"
    # Test with a specified loader
    cond2 = Conditional(DistributionFactCollector())
    assert cond2, "Constructor did not create a Conditional object"


# Generated at 2022-06-21 00:30:20.883905
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    templar = Templar(loader=None, variables={})

    # case 1: check if defined variable
    all_vars = dict(foo='bar')
    c = Conditional()
    assert c.evaluate_conditional(templar, all_vars) is True
    c._when.extend(['foo is defined'])
    assert c.evaluate_conditional(templar, all_vars) is True
    c._when.extend(['foo not is defined'])
    assert c.evaluate_conditional(templar, all_vars) is False

    # case 2: check if undefined variable
    all_v

# Generated at 2022-06-21 00:30:31.697728
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import become_loader, vault_secrets_loader


# Generated at 2022-06-21 00:30:42.489379
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class ConditionalTest(object):
        _name = "test"
        _ds = "test"

        def __init__(self):
            pass

    class HostVars(dict):
        def __getattr__(self, attrname):
            try:
                return self[attrname]
            except KeyError:
                raise AttributeError

        def __setattr__(self, attrname, value):
            self[attrname] = value

        def __delattr__(self, attrname):
            try:
                del self[attrname]
            except KeyError:
                raise AttributeError

    test_conditionalTest = ConditionalTest()
    test_conditionalTest._loader = unittest.mock.Mock()

# Generated at 2022-06-21 00:30:53.483711
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    c = Conditional()
    templar = Templar(variables={'a':1, 'b':2, 'c':3, 'd':4, 'e':5})
    tests = [
        ('a|b', True),
        ('a|b==2', True),
        ('a|d', False),
        ('a|e', False),
        ('a|b and c|d', True),
        ('a|b and c|e', False),
        ('a|d or a|e', False),
    ]
    all_vars = templar.available_variables
    for test in tests:
        assert c.evaluate_conditional(templar, all_vars, test[0]) == test[1]



# Generated at 2022-06-21 00:31:00.307362
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """
    Tests for Conditional.evaluate_conditional
    """

    import ansible.plugins.loader
    from ansible.plugins.loader import add_all_plugin_dirs
    import ansible.vars.manager
    import ansible.template.template
    import ansible.playbook.play_context

    # Load plugins
    add_all_plugin_dirs()
    # Load plugins that are only used with thie test
    #import ansible.plugins.test.test_lookup.Test
    #import ansible.plugins.test.test_filter.Test
    #import ansible.plugins.test.test_filter.Test2

    # all_vars

# Generated at 2022-06-21 00:31:09.665498
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = '''
    server_name is not defined and ('server_name' not in group_names or (not(stages | selectattr('name', 'equalto', 'server_name') | list) and 'server_name' not in inventory_hostname))
    '''

    results = Conditional().extract_defined_undefined(conditional)

    assert len(results) == 2
    assert results[0][0] == 'server_name'
    assert results[1][0] == 'server_name'


# Generated at 2022-06-21 00:31:16.410622
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    aConditional = Conditional()
    test_data = [' zzz  not   is   defined ',
                 'aaaa is defined',
                 ' xxx  is not defined',
                 'bbbb is not defined',
                 'cccc is undefined',
                 'hostvars["foo"] not is defined',
                 'hostvars[\'foo\'] not is defined',
                 'hostvars["foo"] not is undefined',
                 'hostvars[\'foo\'] not is undefined'
                 ]

    result = aConditional.extract_defined_undefined(''.join(test_data))
    assert(len(result) == len(test_data))
    i = 0
    while i < len(result):
        assert(result[i] == test_data[i].strip().split())
        i += 1


# Generated at 2022-06-21 00:31:23.497322
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    conditional = Conditional()

    # Test case 01: No match
    conditional = "hostvars['foo']"
    results = conditional.extract_defined_undefined(conditional)
    assert results == []

    # Test case 02: One match
    conditional = "hostvars['foo'] is defined"
    results = conditional.extract_defined_undefined(conditional)
    assert results == [('hostvars[\'foo\']', 'is', 'defined')]

    # Test case 03: Two matches
    conditional = "hostvars['foo'] is defined and hostvars['foo'] is undefined"
    results = conditional.extract_defined_undefined(conditional)