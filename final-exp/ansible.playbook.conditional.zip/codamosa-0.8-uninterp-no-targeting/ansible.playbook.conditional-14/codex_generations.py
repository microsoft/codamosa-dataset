

# Generated at 2022-06-21 00:22:12.536448
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    import ansible.playbook
    import ansible.vars
    pb = ansible.playbook.PlayBook()
    loader = ansible.vars.VariableManager()
    pb._loader = loader
    # test extraction from a simple string
    t = ansible.playbook.TaskInclude()
    t._loader = loader
    c = Conditional()
    c._loader = loader
    # test extraction from a complex string
    d = c.extract_defined_undefined('(hostvars[inventory_hostname]["foo"] | default("bar")) is defined')
    e = {('hostvars[inventory_hostname]["foo"] | default("bar")', 'is', 'defined')}
    assert d == e
    # test extraction from a string with multiple defined/undefined references
    d = c.extract_

# Generated at 2022-06-21 00:22:24.262627
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    assert(conditional.extract_defined_undefined("false") == [])
    assert(conditional.extract_defined_undefined("vars[foo] is defined") == [("vars[foo]", "is", "defined")])
    assert(conditional.extract_defined_undefined("vars[foo] not is undefined") == [("vars[foo]", "not is", "undefined")])
    assert(conditional.extract_defined_undefined("not hostvars[foo] is defined") == [("hostvars[foo]", "is", "defined")])
    assert(conditional.extract_defined_undefined("not hostvars[foo] is undefined") == [("hostvars[foo]", "is", "undefined")])

# Generated at 2022-06-21 00:22:33.802729
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    result = cond.extract_defined_undefined("hostvars['foo'] is defined or fred is undefined")
    assert result == [('hostvars[\'foo\']', 'is', 'defined'), ('fred', 'is', 'undefined')]

    result = cond.extract_defined_undefined("(fred is defined and hostvars['foo'] is defined) or (fred is not defined and hostvars['foo'] is not defined)")
    assert result == [('fred', 'is', 'defined'), ('hostvars[\'foo\']', 'is', 'defined'), ('fred', 'is', 'not'), ('hostvars[\'foo\']', 'is not', 'defined')]

    result = cond.extract_defined_undefined("fred is defined and hostvars['foo'] is defined")


# Generated at 2022-06-21 00:22:35.790440
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c.when == []
    assert c._ds == ''



# Generated at 2022-06-21 00:22:47.427417
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # This test requires a full playbook to be parsed
    from ansible.playbook.play import Play
    play_name = 'test'

# Generated at 2022-06-21 00:22:53.539102
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    templar = Templar(variables={
        'a': 1,
        'b': False,
        'c': True,
        'd': "a string",
        'e': [],
        'f': ['a', 'b', 'c'],
        'g': "",
        'h': {},
        'i': {'k':'v'}
    })

    c = Conditional()

    # 1. Simple tests of a few jinja2 tests - test_evaluate_conditional_simple
    assert c.evaluate_conditional(templar, {'a': 1}) == True
    assert c.evaluate_conditional(templar, {'a': 2}) == False

# Generated at 2022-06-21 00:22:56.442944
# Unit test for constructor of class Conditional
def test_Conditional():

    class TestModule(object):
        pass

    m = TestModule()
    assert m._when == []

    # __init__() of class Conditional should have been called
    m = Conditional()
    assert m._when == []


# Generated at 2022-06-21 00:23:07.598606
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    '''
    Test the method evaluate_conditional of the class Conditional.
    '''

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    class TestConditional(Conditional):
        def __init__(self, loader=None):
            if loader is None:
                raise AnsibleError("a loader must be specified when using TestConditional() directly")
            else:
                self._loader = loader

    tc = TestConditional(DataLoader())

    vars = {'a': 'foo', 'b': 'bar'}
    t = Templar(None, variables=vars)
    result = tc.evaluate_conditional(t, vars)
    assert result is True

    tc._when = ['a == "foo"']

# Generated at 2022-06-21 00:23:18.398928
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-21 00:23:26.819764
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    result = True
    try:
        for conditional in self.when:

            # do evaluation
            if conditional is None or conditional == '':
                res = True
            elif isinstance(conditional, bool):
                res = conditional
            else:
                res = self._check_conditional(conditional, templar, all_vars)

            # only update if still true, preserve false
            if result:
                result = res

            display.debug("Evaluated conditional (%s): %s" % (conditional, res))
            if not result:
                break

    except Exception as e:
        raise AnsibleError("The conditional check '%s' failed. The error was: %s" % (to_native(conditional), to_native(e)), obj=ds)

    return True

# Generated at 2022-06-21 00:23:42.875034
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()

    assert conditional.extract_defined_undefined(u"hostvars[inventory_hostname] is defined") == [
        ("hostvars[inventory_hostname]", "is", "defined")
    ]
    assert conditional.extract_defined_undefined(u"hostvars[inventory_hostname] is not defined") == [
        ("hostvars[inventory_hostname]", "is not", "defined")
    ]
    assert conditional.extract_defined_undefined(u"hostvars[inventory_hostname] is undefined") == [
        ("hostvars[inventory_hostname]", "is", "undefined")
    ]

# Generated at 2022-06-21 00:23:53.556508
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

    teststr1 = "defined foo and bar is undefined"
    assert cond.extract_defined_undefined(teststr1) == [('foo','is','defined'), ('bar','is','undefined')]

    teststr2 = "defined foo or (bar is not undefined)"
    assert cond.extract_defined_undefined(teststr2) == [('foo','is','defined'), ('bar','not is','undefined')]

    teststr3 = "defined foo or (bar is not undefined) or (baz is defined)"
    assert cond.extract_defined_undefined(teststr3) == [('foo','is','defined'), ('bar','not is','undefined'), ('baz','is','defined')]


# Generated at 2022-06-21 00:24:03.790192
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('sdfsdf sdfsdfsdf') == []
    assert c.extract_defined_undefined('sdfsdf sdfsdfsdf  hostvars[\'sdfsdfdsf\'] is undefined') == [('hostvars[\'sdfsdfdsf\']', 'is', 'undefined')]
    assert c.extract_defined_undefined('sdfsdf sdfsdfsdf  hostvars[\'sdfsdfdsf\'] is not undefined') == [('hostvars[\'sdfsdfdsf\']', 'is not', 'undefined')]

# Generated at 2022-06-21 00:24:12.878440
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    assert Conditional().extract_defined_undefined('foo and bar is defined') == [('bar', 'is', 'defined')]
    assert Conditional().extract_defined_undefined('foo is defined and bar is defined') == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]
    assert Conditional().extract_defined_undefined('foo is defined and bar') == [('foo', 'is', 'defined')]
    assert Conditional().extract_defined_undefined('(foo is defined and bar) or baz') == [('foo', 'is', 'defined'), ('bar', 'is', 'defined')]

# Generated at 2022-06-21 00:24:23.867076
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    # Define some objects to use
    class ExistingAttribute:
        _data1 = FieldAttribute(isa='data1')
    class Data1Class:
        def __init__(self, data1=None):
            self.data1 = data1
    class Data2Class:
        def __init__(self, data2=None):
            self.data2 = data2
    class Data3Class:
        def __init__(self, data3=None):
            self.data3 = data3

    # Create a play to use

# Generated at 2022-06-21 00:24:26.374603
# Unit test for constructor of class Conditional
def test_Conditional():

    from ansible.playbook import Playbook
    conditional = Conditional(loader=Playbook.load(None))
    assert conditional._loader



# Generated at 2022-06-21 00:24:32.364365
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()

    conditional = 'hostvars["foo"] is defined and (hostvars["foo"] & mygroup_vars["foo"])'
    result = [('hostvars["foo"]', 'is', 'defined')]
    assert cond.extract_defined_undefined(conditional) == result

    conditional = 'hostvars["foo"] is defined or (hostvars["foo"] & mygroup_vars["foo"])'
    result = [('hostvars["foo"]', 'is', 'defined')]
    assert cond.extract_defined_undefined(conditional) == result

    conditional = 'myvar is defined or hostvars["foo"] is undefined and (hostvars["foo"] & mygroup_vars["foo"])'

# Generated at 2022-06-21 00:24:34.547680
# Unit test for method evaluate_conditional of class Conditional

# Generated at 2022-06-21 00:24:36.281691
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert(conditional is not None)

# Generated at 2022-06-21 00:24:38.076619
# Unit test for constructor of class Conditional
def test_Conditional():
    class MyConditional(object):
        __metaclass__ = Conditional
        pass

    assert True


# Generated at 2022-06-21 00:24:51.596620
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.base import Base

    class TestModule(Base, Conditional):
        pass

    t = TestModule()
    assert len(t.when) == 0
    assert t._when == []
    assert t.when == []

    t = TestModule(when="some_conditional")
    assert len(t.when) == 1
    assert t._when == [ "some_conditional" ]
    assert t.when == [ "some_conditional" ]


# Generated at 2022-06-21 00:25:03.066477
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    assert Conditional()._check_conditional(None, Templar({}), {}) is True
    assert Conditional()._check_conditional(True, Templar({}), {}) is True
    assert Conditional()._check_conditional(1, Templar({}), {})
    assert Conditional()._check_conditional(5, Templar({}), {})
    assert Conditional()._check_conditional(0, Templar({}), {}) is False
    assert Conditional()._check_conditional([], Templar({}), {}) is False
    assert Conditional()._check_conditional({}, Templar({}), {}) is False
    assert Conditional()._check_conditional('', Templar({}), {}) is False
    assert Conditional()._check_conditional('    ', Templar({}), {}) is False

# Generated at 2022-06-21 00:25:09.318264
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)

    c = Conditional()
    c.__init__(variable_manager)
    assert c._loader == variable_manager

# Generated at 2022-06-21 00:25:12.049860
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert False == conditional.evaluate_conditional(None, "a-string")
    assert True == conditional.evaluate_conditional(None, None)
    assert True == conditional.evaluate_conditional(None, "")

# Generated at 2022-06-21 00:25:23.835406
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.plugins.loader import action_loader, module_loader
    from ansible.playbook.base import Base

    class FakeVarsModule(Base):
        """Fake module for loading a vars file"""
        pass

    loader = FakeVarsModule()

    # (module_name, use_local_action, use_local_module)
    for m, ula, ulm in [
        ('conditional', False, True),
        ('when', False, False),
        ('conditional2', True, True),
        ('when2', True, False),
    ]:
        # Load the module
        fake_conditional = module_loader.get(m, class_only=True)

        # Load the module
        if ula:
            fake_module = action_loader.get(m, class_only=True)
       

# Generated at 2022-06-21 00:25:33.287193
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    tqm = TaskQueueManager(None, loader=loader, inventory=inventory, variable_manager=variable_manager, loader_callback=None, passwords=dict())
    conditional = Conditional(loader)
    assert conditional

# Generated at 2022-06-21 00:25:34.863792
# Unit test for constructor of class Conditional
def test_Conditional():
    assert hasattr(Conditional, '__init__'), "Class 'Conditional' should have an __init__"


# Generated at 2022-06-21 00:25:40.999660
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    conditional = Conditional()
    result_1 = conditional.extract_defined_undefined('var is not defined')
    assert result_1 == [('var', 'is', 'defined')], "Result 1 should be var is not defined"
    result_2 = conditional.extract_defined_undefined('var1 is not defined and var2 is defined')
    assert result_2 == [('var1', 'is', 'defined'), ('var2', 'is', 'defined')], "Result 2 should be var1 is not defined and var2 is defined"
    result_3 = conditional.extract_defined_undefined('var1 is not undefined and var2 is undefined')

# Generated at 2022-06-21 00:25:52.115219
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
        from ansible.playbook.task import Task
        task=Task()
        du_vars=task.extract_defined_undefined("cond1 and cond2 and cond3")
        assert du_vars==[], "extract_defined_undefined should return empty array when no match"

        du_vars=task.extract_defined_undefined("(cond1 and cond2) or (cond3 and cond4)")
        assert du_vars==[], "extract_defined_undefined should return empty array when no match"

        du_vars=task.extract_defined_undefined("cond1 and cond2 and hostvars[\"foo\"] is defined")

# Generated at 2022-06-21 00:25:59.602015
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext

    loader = None
    options = C.config_data_dir
    variable_manager = None
    loader = None
    inventory = None
    passwords = None
    connection_info = None
    play_context = PlayContext(
        options=options,
        variable_manager=variable_manager,
        loader=loader,
        inventory=inventory,
        passwords=passwords,
        connection_info=connection_info
    )

    conditional = Conditional(loader=loader)

    assert conditional._loader == loader
    assert conditional.evaluate_conditional(play_context.templar, "foo") == "foo"


# Generated at 2022-06-21 00:26:16.946800
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    test_conditional = Conditional()
    result = test_conditional.evaluate_conditional(None, {'a': 1, 'b': 2})
    assert result == True
    result = test_conditional.evaluate_conditional(None, {'a': 1, 'b': 2, })
    assert result == True

    result = test_conditional.evaluate_conditional(None, {'a': 1, 'b': 3, })
    assert result == False

    test_conditional = Conditional()
    result = test_conditional.evaluate_conditional(None, {'a': 0, 'b': 3, })
    assert result == True

    result = test_conditional.evaluate_conditional(None, {'a': 0, 'b': 2, })
    assert result == False

# Generated at 2022-06-21 00:26:19.122468
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    pc = PlayContext()

    c = Conditional(loader=pc)
    assert c

    Conditional(loader=pc)

# Generated at 2022-06-21 00:26:23.632549
# Unit test for constructor of class Conditional
def test_Conditional():
    loader = 'fake_loader'
    conditional = Conditional(loader)
    assert conditional._loader == loader
    assert conditional._ds is None
    assert conditional.when == []
    conditional = Conditional()
    try:
        assert conditional._loader is None
    except:
        raise Exception("Conditional() should set _loader as None when no arg is passed")

# Unit tests for method _validate_when() of class Conditional

# Generated at 2022-06-21 00:26:28.383720
# Unit test for constructor of class Conditional
def test_Conditional():
    class TestClass(Conditional):
        def __init__(self):
            super(Conditional, self).__init__()
            self._loader = DictDataLoader({})

    testclass = TestClass()

    # No when defined
    assert(testclass.when is None)

    # With when defined
    testclass.when = 'foo'
    assert(testclass.when[0] == 'foo')

    # when defined with list of items
    testclass.when = [ 'foo', 'bar' ]
    assert(testclass.when[0] == 'foo')
    assert(testclass.when[1] == 'bar')
    assert(len(testclass.when) == 2)

    # with when defined with list of items and extend
    testclass.when = [ 'baz' ]

# Generated at 2022-06-21 00:26:38.514211
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template.safe_eval import safe_eval

    class TestConditional(Conditional):
        pass

    testConditional = TestConditional()

    test_templar = safe_eval.AnsibleJ2Template("unit_tests", test_vars={})

    test_vars = dict(
        _comment=dict(
            hostvars=dict(
                foo=dict(
                    bar=True,
                    baz=2,
                    zippity_doodah=False,
                ),
            ),
        )
    )


# Generated at 2022-06-21 00:26:46.581867
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    class Base:
        pass

    class Conditional_class(Conditional, Base):
        pass

    conditional = Conditional_class()
    conditional.when = ''
    expected_result = []
    actual_result = conditional.extract_defined_undefined(conditional.when)
    assert actual_result == expected_result

    conditional.when = 'a is defined'
    expected_result = [('a', 'is', 'defined')]
    actual_result = conditional.extract_defined_undefined(conditional.when)
    assert actual_result == expected_result

    conditional.when = 'a is not defined'
    expected_result = [('a', 'is not', 'defined')]
    actual_result = conditional.extract_defined_undefined(conditional.when)
    assert actual_result == expected_result

   

# Generated at 2022-06-21 00:26:52.561622
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import ansible.plugins.loader

    loader = ansible.plugins.loader.PluginLoader(None)
    class TestClass(Conditional):
        name_ = "test"
        def __init__(self, loader=None):
            super(TestClass, self).__init__(loader=loader)
    test_obj = TestClass(loader=loader)

    test_obj._when = ["True"]
    result = test_obj.evaluate_conditional(None, None)
    assert result == True

    test_obj._when = ["False"]
    result = test_obj.evaluate_conditional(None, None)
    assert result == False

    class TestClass2(Conditional):
        name_ = "test"

# Generated at 2022-06-21 00:26:56.072816
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    expected = [ (u"hostvars['foo']", u'is', u'defined'), (u"bar", u'is not', u'undefined')]
    actual = Conditional().extract_defined_undefined("hostvars['foo'] is defined and bar is not undefined")
    assert actual == expected


# Generated at 2022-06-21 00:27:00.396398
# Unit test for constructor of class Conditional
def test_Conditional():
    # Test with a loader of None
    c = Conditional()
    assert c._when == []
    assert c._loader == None

    # Test without a loader
    c = Conditional(loader=None)
    assert c._when == []
    assert c._loader == None

# Generated at 2022-06-21 00:27:08.880831
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    """
    Test the return values of method evaluate_conditional in class Conditional
    """

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.attribute import Attribute
    from ansible.template import Templar

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    templar = Templar(loader=loader, variables=variable_manager)

    # test case 1: conditional is None
    c = Conditional(loader=loader)
    c._when = None

    res = c.evaluate_conditional(templar, dict())
    assert res

    # test case 2

# Generated at 2022-06-21 00:27:25.922593
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c is not None

# Generated at 2022-06-21 00:27:39.315885
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    class TestItem(Conditional):
        def __init__(self, when):
            self._loader = FakeVarsModuleLoader()
            self._ds = type('obj', (object,), {})()
            self.when = when

# Generated at 2022-06-21 00:27:46.763543
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    host_vars = dict(one='1', two='2')
    c = Conditional()
    # check for one undefined variable
    test_string = "one is undefined and two is defined"
    assert len(c.extract_defined_undefined(test_string)) == 1
    # check for two undefined variables
    test_string = "one is undefined, two is not defined and three is defined"
    assert len(c.extract_defined_undefined(test_string)) == 2
    # check for two defined variables
    test_string = "one is defined and two is defined"
    assert len(c.extract_defined_undefined(test_string)) == 2



# Generated at 2022-06-21 00:27:47.801726
# Unit test for constructor of class Conditional
def test_Conditional():
    conditional = Conditional()
    assert conditional is not None


# Generated at 2022-06-21 00:27:58.351823
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()

    test_cond = "foo is defined"
    assert c.extract_defined_undefined(test_cond) == [("foo", "is", "defined")]

    test_cond = "foo is not defined"
    assert c.extract_defined_undefined(test_cond) == [("foo", "is not", "defined")]

    test_cond = "foo is undefined"
    assert c.extract_defined_undefined(test_cond) == [("foo", "is", "undefined")]

    test_cond = "foo is not undefined"
    assert c.extract_defined_undefined(test_cond) == [("foo", "is not", "undefined")]

    test_cond = "bar is undefined or foo is defined or baz is not undefined"
    assert c.ext

# Generated at 2022-06-21 00:28:08.363081
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    # extract and assert defined/undefined conditions
    c = Conditional()
    assert c.extract_defined_undefined('hostvars[inventory_hostname] is defined') == [('hostvars[inventory_hostname]', 'is', 'defined')]
    assert c.extract_defined_undefined('hostvars[inventory_hostname] is defined and a is not undefined') == [('hostvars[inventory_hostname]', 'is', 'defined'), ('a', 'is not', 'undefined')]

# Generated at 2022-06-21 00:28:15.584117
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
  import sys
  if sys.version_info < (2, 7, 0):
    raise Exception("Code was written with python 2.7. Version being used: %s.%s.%s" %
                    (sys.version_info.major, sys.version_info.minor, sys.version_info.micro))

  class TestConditional:
    def __init__(self):
      pass

    def _validate_when(self, attr, name, value):
      if not isinstance(value, list):
        setattr(self, name, [value])

    def _check_conditional(self, conditional, templar, all_vars):
      pass

    def compare_lists(self, list1, list2):
      return sorted(list1) == sorted(list2)


# Generated at 2022-06-21 00:28:24.953736
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar

    my_vars = dict(
        a=1,
        b=2,
        c=3,
        mydict=dict(
            a="b"
        ),
        mylist=["a", "b", "c"],
    )

    templar = Templar(loader=None, variables=my_vars)


# Generated at 2022-06-21 00:28:25.834437
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c._when == []


# Generated at 2022-06-21 00:28:33.492229
# Unit test for constructor of class Conditional
def test_Conditional():
    c = Conditional()
    assert c._validate_when(None, None, None) is None
    assert c._when is None
    c = Conditional()
    assert c._validate_when(None, None, 'foo') is None
    assert c._when == ['foo']
    c = Conditional()
    assert c._validate_when(None, None, ['foo']) is None
    assert c._when == ['foo']
    c = Conditional()
    assert c._validate_when(None, None, ['foo', 'bar']) is None
    assert c._when == ['foo', 'bar']


# Generated at 2022-06-21 00:28:57.953189
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():

    from ansible.playbook.task_include import TaskInclude
    task_include = TaskInclude()

    def test_extract_defined_undefined(when_value, should_elements):
        task_include._when = when_value
        elements = task_include.extract_defined_undefined(str(task_include._when[0]))
        if set(elements) != set(should_elements):
            raise AssertionError("FAIL: when_value:%s elements:%s should:%s"
                                 % (when_value, elements, should_elements))

    test_extract_defined_undefined([[['my_var', 'is', 'defined']]],
                                   [['my_var', 'is', 'defined']])

# Generated at 2022-06-21 00:29:06.960184
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    inventory = InventoryManager(loader=loader)

    host_list = ['test_host']
    inventory.add_host(host='test_host')

    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    conditional = Conditional(loader=loader)
    results = conditional.extract_defined_undefined(conditional)
    assert len(results) == 0

    conditional = Conditional(loader=loader)
    results = conditional.extract_defined_undefined('hostvars[inventory_hostname] is defined')

# Generated at 2022-06-21 00:29:14.497007
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    p = Conditional(loader=DataLoader())
    assert p._loader is not None
    assert p._when == []

    vm = VariableManager()
    play_context = PlayContext()
    templar = Templar(loader=p._loader, variables=vm, play_context=play_context)
    all_vars = dict(one=1, two=2)

    p._when = ["one == 1"]
    assert p.evaluate_conditional(templar, all_vars) is True

    p._when = ["one == 2"]

# Generated at 2022-06-21 00:29:17.773710
# Unit test for constructor of class Conditional
def test_Conditional():
    # Test without loader
    try:
        Conditional()
        assert False, "Failed to detect missing loader"
    except AnsibleError as e:
        assert 'loader' in to_native(e)

    # Test with loader
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    Conditional(loader=loader)

# Generated at 2022-06-21 00:29:21.689070
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    from ansible.playbook.role.definition import RoleDefinition
    import os
    import sys
    data_file = os.path.join(os.path.dirname(sys.modules[__name__].__file__),
                             'playbook_definition_data.yml')
    role_definition = RoleDefinition.load(data_file)
    conditional = role_definition.get_children()[0]

    print(conditional.when)
    for i in conditional.when:
        print()
        print(i)
        print(conditional.extract_defined_undefined(i))

# Generated at 2022-06-21 00:29:31.595552
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():

    # Setup
    class TestConditional(Conditional):
        pass

    tc = TestConditional()
    setattr(tc, '_ds', dict())

    # Test: Check when statement with valid variable
    tc_when = 'valid'
    setattr(tc, 'when', tc_when)
    templar = {
        'available_variables': dict(valid='valid'),
        'template': lambda s, *args, **kwargs: s,
        'is_template': lambda s: False
    }
    all_vars = dict(valid='valid')
    assert tc.evaluate_conditional(templar, all_vars)

    # Test: Check when statement with invalid variable
    tc_when = 'invalid'
    setattr(tc, 'when', tc_when)

# Generated at 2022-06-21 00:29:36.427929
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    conditional = '\'foo\' is defined or \'foo\' is defined and \'bar\' is not defined'
    result = cond.extract_defined_undefined(conditional)
    assert result[0] == ("'foo'", "is", "defined")
    assert result[1] == ("'foo'", "is", "defined")
    assert result[2] == ("'bar'", "is not", "defined")



# Generated at 2022-06-21 00:29:43.349941
# Unit test for constructor of class Conditional
def test_Conditional():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = loader.load_from_file('../../../test/inventory')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager)

    conditional = Conditional(loader=loader)
    conditional.when = [
        'foo is defined',
        'thing.bar != "what"',
        'not (asdf != "asdf" or foo == "bar")',
        'ansible_distribution != "Fedora"'
    ]

    # NOTE:

# Generated at 2022-06-21 00:29:55.877121
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    all_vars = dict()
    all_vars['var'] = 'value'
    all_vars['foo'] = 'bar'
    all_vars['this_host'] = 'foo.example.com'
    all_vars['groups'] = dict(
        group1=['host1'],
        group2=['host2', 'host3']
    )
    all_vars['inventory_hostname'] = 'localhost'

    loader = DataLoader()

# Generated at 2022-06-21 00:30:01.505262
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Create a fake templar and all_vars data structure to run the method with
    templar = type('Templar', (object,), {'template': lambda s, t: t,
                                          'is_template': lambda s, t: False,
                                          'environment': type('Environment', (object,),
                                                             {'globals': dict(reload=reload,
                                                                              __import__=__import__,
                                                                              lookups=None,
                                                                              failif=None)})})
    all_vars = dict(junk='data')

    # Test a condition statement that is a string
    cond = type('Cond', (object,), {'_loader': None, 'when': ['some_var == foo']})

# Generated at 2022-06-21 00:30:42.694792
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    loader.set_basedir(C.DEFAULT_MODULE_PATH[0])

    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    inventory.subset('some_host')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    cond = Conditional(loader)

    all_vars = variable_manager.get_vars(play=None, host=inventory.get_host('some_host'))
    results = cond.evaluate_conditional(all_vars, all_vars)
    assert results is True


# Generated at 2022-06-21 00:30:53.461343
# Unit test for method extract_defined_undefined of class Conditional

# Generated at 2022-06-21 00:31:00.243577
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    c = Conditional()
    assert c.extract_defined_undefined('this is a defined test') == [('test', 'is', 'defined')]
    assert c.extract_defined_undefined('this is a not defined test') == [('test', 'is not', 'defined')]
    assert c.extract_defined_undefined('this is a undefined test') == [('test', 'is', 'undefined')]
    assert c.extract_defined_undefined('this is a not undefined test') == [('test', 'is not', 'undefined')]
    assert c.extract_defined_undefined('this is a defined or not test') == [('test', 'is', 'defined')]

# Generated at 2022-06-21 00:31:11.608452
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager
    result = ""
    constants = C
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_available_variables(loader.load_from_file('/tmp/ansible.cfg'))
    templar = Templar(loader=loader, variables=variable_manager)
    conditional = Conditional(loader=loader)
    conditional.when = ['{{ 1 > 2 }}']
    all_vars = {}
    result = conditional.evaluate_conditional(templar, all_vars)
    assert(result == False)

# Generated at 2022-06-21 00:31:15.678362
# Unit test for constructor of class Conditional
def test_Conditional():
    try:
        Conditional()
    except Exception as e:
        assert False, 'test_Conditional() constructor with empty parameter list failed. The error is %s' % str(e)

# Generated at 2022-06-21 00:31:23.244511
# Unit test for constructor of class Conditional
def test_Conditional():
    '''
    [description]
    '''
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.plugins.loader import find_plugin_loader

    Options = collections.namedtuple('Options', ['connection','module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'diff'])
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 00:31:26.621831
# Unit test for constructor of class Conditional
def test_Conditional():
    # just create a Conditional object to ensure no errors are thrown and
    # no memory leaks occur
    Conditional(None)


# Generated at 2022-06-21 00:31:33.071891
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    import unittest
    if PY3:
        import unittest.mock as mock
    else:
        import mock

    class Matcher:
        def __init__(self, target):
            self._target = target

        def __eq__(self, other):
            return other == self._target.replace("'", '"')

        def __str__(self):
            return self._target

    class ConditionalTestCase(unittest.TestCase):

        @mock.patch("ansible.playbook.conditional.Conditional._check_conditional", create=True)
        @mock.patch("ansible.playbook.play.Play.get_vars", create=True)
        def testPassConditions_evaluatesToTrue(self, mock_templar, mock_check_conditional):
            mock

# Generated at 2022-06-21 00:31:43.046805
# Unit test for method evaluate_conditional of class Conditional
def test_Conditional_evaluate_conditional():
    # Arrange
    from ansible.playbook import Playbook
    pb = Playbook()

    # Act
    res = pb._evaluate_conditional(None, None, None)

    # Assert
    assert res

    # Arrange
    res = pb._evaluate_conditional(None, '', None)

    # Assert
    assert res

    # Arrange
    res = pb._evaluate_conditional(None, '', [])

    # Assert
    assert res

    # Arrange
    res = pb._evaluate_conditional(None, '', [None])

    # Assert
    assert res

    # Arrange
    res = pb._evaluate_conditional(None, '', [False])

    # Assert
    assert not res

    # Arrange
    res = pb._evaluate_

# Generated at 2022-06-21 00:31:52.096697
# Unit test for method extract_defined_undefined of class Conditional
def test_Conditional_extract_defined_undefined():
    cond = Conditional()
    assert cond.extract_defined_undefined('bar not is defined') == [('bar', 'not is', 'defined')]
    assert cond.extract_defined_undefined('bar not is undefined') == [('bar', 'not is', 'undefined')]
    assert cond.extract_defined_undefined('bar is defined') == [('bar', 'is', 'defined')]
    assert cond.extract_defined_undefined('bar is undefined') == [('bar', 'is', 'undefined')]
    assert cond.extract_defined_undefined('bar is not defined') == [('bar', 'is not', 'defined')]
    assert cond.extract_defined_undefined('bar is not undefined') == [('bar', 'is not', 'undefined')]
    assert cond.extract_