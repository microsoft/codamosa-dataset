

# Generated at 2022-06-25 10:13:32.813139
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    var_obj = PluginLoader('ansible.plugins.action', 'ActionModule')
    test_case_0()


# Import and call tests that are contained in functions to
# avoid them being called from top-level during "python setup.py test"
if __name__ == '__main__':
    test_PluginLoader_get_with_context()

# Generated at 2022-06-25 10:13:36.117263
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    obj_0 = PluginLoader('')
    assert not 'None' in obj_0


# Generated at 2022-06-25 10:13:39.558840
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    var_0 = Jinja2Loader('ansible.plugins.filter', 'FilterModule')
    var_1 = var_0.get('plugin_name')


# Generated at 2022-06-25 10:13:41.263549
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    var_0 = PluginLoader('cache', 'CacheModule', 'ansible.plugins.cache', C.CACHE_PLUGIN_FILTER)
    test_case_0()


# Generated at 2022-06-25 10:13:44.379888
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():

    # Call method find_plugin of parent class PluginLoader
    # FIXME: support this in a branch
    #var_0 =
    #test_case_0()
    pass


# Generated at 2022-06-25 10:13:48.405230
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    var_1 = PluginLoader.__contains__
    var_2 = None
    var_3 = PluginLoader()
    var_4 = 'nonexistent'
    var_2 = var_3.has_plugin(var_4)
    var_5 = print(var_2)


# Generated at 2022-06-25 10:13:55.721014
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    #
    # Known bugs:
    #
    #     - known bug 0
    #
    #     - known bug 1
    #
    var_0 = PluginLoader(
        package=None,
        directories=None,
        config_type=None,
        class_name=None,
        name=None,
        aliases=None,
        required_base_class=None,
        config_base_name=None,
        config_base_class=None
    )
    var_1 = var_0.find_plugin(
        name=None
    )
    assert isinstance(var_1, PluginLoader) is False
    return var_1


# Generated at 2022-06-25 10:14:07.420100
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
  
    # Set up mock
    # Used for cache
    mock_path_exists = MagicMock()
    mock_path_exists.return_value = False
    with patch.dict(sys.modules, {'os.path.exists': mock_path_exists}):
        # Used for cache
        mock_makedirs = MagicMock()
        with patch.dict(sys.modules, {'os.makedirs': mock_makedirs}):
            # Used for cache
            mock_open = MagicMock(side_effect=mock_open_side_effects)
            mock_open(u'/tmp/ansible-plugin-lookup_loader-tmp.gz/ansible/plugins/lookup/__init__.py').return_value = mock_open_return_value

# Generated at 2022-06-25 10:14:15.356799
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Test with param: directory = 'blah'
    var_1 = add_directory('blah')
    # Test with param: directory = 'blah'
    var_2 = add_directory('blah')
    # Test with param: directory = 'blah'
    # Test with param: module_name = 'test'
    var_3 = add_directory('blah', 'test')


# Generated at 2022-06-25 10:14:17.355294
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    var_0 = PluginLoader()
    var_1 = var_0.__contains__()


# Generated at 2022-06-25 10:15:02.336251
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    var_0 = get_all_plugin_loaders()
    assert var_0 == [(name, obj) for (name, obj) in globals().items() if isinstance(obj, PluginLoader)], "Check if plugin dir is added to list"


# Generated at 2022-06-25 10:15:10.084970
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Create an instance of PluginLoader()
    plugin_loader = PluginLoader(package=None, base_class=None, class_name=None, package_errors=None, config=None, subdir=None, aliases=None, required_base_class=None)
    name = "name"
    kwargs = {"kwargs": "kwargs"}
    # Call the method
    try:
        plugin_load_context = plugin_loader.get_with_context(name, **kwargs)
        assert plugin_load_context is not None
    except AnsibleCollectionNotFound as e:
        assert True


# Generated at 2022-06-25 10:15:15.413053
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    args_0 = ( 'become' )
    args_1 = ('become_user')
    kwargs_1 = {'collection_list': None}
    var_2 = get_all_plugin_loaders()
    for tmp_3 in var_2:
        if tmp_3.package == 'become':
            tmp_1 = tmp_3.find_plugin(args_0, args_1)
            tmp_2 = tmp_3.find_plugin(args_0, args_1, **kwargs_1)

# Generated at 2022-06-25 10:15:16.914393
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    class_0 = PluginLoader()
    # TODO:
    assert False


# Generated at 2022-06-25 10:15:21.464907
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # Test whether the following statement throws an Exception or not
    # If no Exception, the statement is valid, and test passes
    paths = ['/a', '/b']
    add_dirs_to_loader('shell', paths)
    paths = ['/a', '/b']
    add_dirs_to_loader('connection', paths)
    paths = ['/a', '/b']
    add_dirs_to_loader('module_utils', paths)


# Generated at 2022-06-25 10:15:30.546167
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    collection_name = 'collection_name'
    deprecation = {'warning_text': 'warning_text', 'removal_date': 'removal_date', 'removal_version': 'removal_version'}
    name = 'name'
    warning_text = 'warning_text'
    removal_date = 'removal_date'
    removal_version = 'removal_version'
    plugin_load_context = PluginLoadContext()
    plugin_load_context.record_deprecation(name, deprecation, collection_name)
    assert plugin_load_context.deprecated == True
    assert plugin_load_context.deprecation_warnings == [warning_text]
    assert plugin_load_context.removal_date == removal_date
    assert plugin_load_context.removal_version == removal_version


# Generated at 2022-06-25 10:15:32.614305
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    cls = load_plugin_loader('action')
    plugin_loader = cls()
    plugin_loader.all()


# Generated at 2022-06-25 10:15:34.801289
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    t1 = PluginLoader(package='ansible.plugins.action', class_name='ActionBase')
    t1.find_plugin_with_context('shell')


# Generated at 2022-06-25 10:15:38.404939
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    var_1 = 'ansible.plugins.action.demo'
    var_2 = 'demo'
    plugin_loader = get_all_plugin_loaders()['action']
    var_3 = plugin_loader.find_plugin(var_2)
    assert var_3 == var_1, 'Expected: {0}, actual: {1}'.format(var_1, var_3)


# Generated at 2022-06-25 10:15:41.614456
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    # INPUTS:
    var_0 = "foo"
    var_1 = {
        'warning_text': "This is a warning text",
        'removal_date': "2018-01-01"
    }
    var_2 = "my_collection"
   
    # ARRANGE:
    ctx = PluginLoadContext()
    ctx.original_name = var_0

    # ACT:
    ctx.record_deprecation(var_0, var_1, var_2)

    # ASSERT:
    assert ctx.deprecated == True
    assert ctx.removal_date == "2018-01-01"


# Generated at 2022-06-25 10:16:07.727442
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    """
    :return: None
    """
    var_0 = PluginLoader(plugin_type='', package='ansible.plugins.action', subdir='', directories=[], aliases={}, base_class=None, class_name='', package_dir_name=None, package_dir_path=None, )
    var_1 = None
    var_2 = var_0.find_plugin(name='copy', collection_list=var_1)
    assert(var_2)


# Generated at 2022-06-25 10:16:10.722386
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    var_0 = PluginLoadContext()
    var_1 = []
    var_2 = var_0.record_deprecation("test_plugin",{"removal_date": "2020-06-01"}, "")



# Generated at 2022-06-25 10:16:13.658603
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    var_0 = Jinja2Loader('some_dir', 'filter', 'some_file')
    var_1 = var_0.find_plugin('some_name')
    assert var_1 == 'some_path'



# Generated at 2022-06-25 10:16:15.464173
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    add_all_plugin_dirs('/path/to/plugins/')
    add_all_plugin_dirs('')


# Generated at 2022-06-25 10:16:23.495228
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell_type = 'sh'
    executable = 'test_executable'
    ansible_error_obj = AnsibleError("Either a shell type or a shell executable must be provided ")
    ansible_error_obj2 = AnsibleError('Could not find the shell plugin required ({}).'.format(shell_type))

    # Case 1: test_case_0()
    var_0 = get_all_plugin_loaders()

    # Case 2: get_shell_plugin() - with arguments.
    shell = get_shell_plugin(shell_type, executable)

    # Case 3: get_shell_plugin() - without arguments.
    shell_obj = get_shell_plugin()

    # Case 4: get_shell_plugin() - executable is empty.
    #shell_obj2 = get_shell_plugin(shell_type, None)

# Generated at 2022-06-25 10:16:33.149561
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    obj = PluginLoader(package='ansible.plugins.action', base_class='ActionBase')

    # Test with undefined var_0
    var_0 = None
    var_1 = None
    # print('got', var_1)

    # Test with defined var_0
    var_0 = 'setup'
    var_1 = None
    # print('got', var_1)

    # Test with defined var_0
    var_0 = 'copy'
    var_1 = None
    # print('got', var_1)

    # Test with defined var_0
    var_0 = 'import_playbook'
    var_1 = None
    # print('got', var_1)

    # Test with defined var_0
    var_0 = 'include'
    var_1 = None
    # print('got',

# Generated at 2022-06-25 10:16:44.038383
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    host = Mock()
    host.name = 'localhost'
    host.has_variable = Mock(return_value=True)
    host.get_variable = Mock(return_value=['localhost'])
    setattr(host, 'vars', {})
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    loader = DataLoader()
    variable_manager = VariableManager()
    module = AnsibleModule(argument_spec={}, loader=loader, variable_manager=variable_manager, supports_check_mode=True)
    module.connection = ConnectionInfo(module)
    paths = ( b'lib/ansible/plugins/action', )
    name = 'copy'
    package = 'ansible.plugins.action'
    class_name = 'ActionModule'
    collection_

# Generated at 2022-06-25 10:16:46.225983
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    x = get_shell_plugin(shell_type="sh")
    assert(x.SHELL_NAME == 'sh')
    assert(x.COMPATIBLE_SHELLS == ['sh', 'bash'])


# Generated at 2022-06-25 10:16:52.078590
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    global var_0
    global var_1
    global var_2
    global var_3
    global var_4
    global var_5
    global var_6
    global var_7
    global var_8
    global var_9
    global var_10
    global var_11
    global var_12
    global var_13
    global var_14
    global var_15
    global var_16
    global var_17
    global var_18
    global var_19
    global var_20
    global var_21
    global var_22
    global var_23
    global var_24
    global var_25
    global var_26
    global var_27
    global var_28
    global var_29
    global var_30
    global var_31
    global var_32
   

# Generated at 2022-06-25 10:16:55.529432
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    plugin_loader_0 = PluginLoader("filter", "plugins", "ansible.plugins.connection")
    exception_0 = None
    try:
        plugin_loader_0.get("fake")
    except Exception as exception_1:
        exception_0 = exception_1
    assert exception_0 is not None


# Generated at 2022-06-25 10:17:36.886350
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    test_dir = os.path.dirname(__file__) + "/test_add_all_plugin_dirs/"
    test_dir = os.path.abspath(test_dir)
    b_test_dir = to_bytes(test_dir, errors='surrogate_or_strict')
    assert os.path.isdir(b_test_dir)
    add_all_plugin_dirs(test_dir)

    # get_all_plugin_loaders() should return (name, obj)
    all_pl = get_all_plugin_loaders()

    f_all_pl = get_all_plugin_loaders()

    for name, obj in all_pl:
        if obj.subdir == 'filter':
            assert obj.package_paths == [test_dir + '/filter']


# Generated at 2022-06-25 10:17:42.043068
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    var_0 = Jinja2Loader(1, 2)
    var_1 = var_0.find_plugin("filter", collection_list=["ansible.legacy"])
    var_2 = var_0.find_plugin("test", collection_list=["ansible.legacy"])
    var_3 = var_0.find_plugin("ansible.legacy.plugin_loader_test_plugin")



# Generated at 2022-06-25 10:17:47.574138
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    dict_0 = {}
    dict_0['removal_date'] = None
    dict_0['removal_version'] = None
    dict_0['warning_text'] = 'test'
    var_0 = PluginLoadContext()
    var_0.record_deprecation('test', dict_0, 'test')


# Generated at 2022-06-25 10:17:54.754728
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_0 = path.join(path.dirname(__file__), '../../.ansible_plugins/action_plugins')
    var_1 = path.join(path.dirname(__file__), './action_plugins')
    var_2 = PluginLoader('action', 'ActionModule', 'ansible.plugins.action', ['_', var_0, var_1], 'action_plugins')
    var_3 = var_2.all()
    var_3 = list(var_3)
    var_4 = len(var_3)
    assert(var_4 == 245)


# Generated at 2022-06-25 10:17:58.216899
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()


# Generated at 2022-06-25 10:18:00.327536
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    assert add_all_plugin_dirs("echo hi") == "hi"
    assert add_all_plugin_dirs("cat file") == open("file").read()


# Generated at 2022-06-25 10:18:02.938670
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell_type=None
    executable=None

    # Call function
    get_shell_plugin(shell_type,executable)

    # Test case 0
    test_case_0()


# Generated at 2022-06-25 10:18:04.836309
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():

    for var_0 in get_all_plugin_loaders():
        var_0.get_with_context()


# Generated at 2022-06-25 10:18:13.686844
# Unit test for method find_plugin_with_context of class PluginLoader

# Generated at 2022-06-25 10:18:20.467706
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    var_0 = PluginLoader('filter_loader', 'FilterModule', 'ansible.plugins.filter_plugins', 'ansible_collections.ansible.builtin')
    var_1 = var_0.find_plugin_with_context('_return')
    assert var_1.resolved
    assert var_1.plugin_resolved_name == '_return'
    assert var_1.plugin_resolved_path == os.path.join('ansible', 'plugins', 'filter_plugins', '_return.py')
    assert var_1.plugin_with_redirect == 'ansible.builtin._return'
    assert var_1.plugin_resolved_fqcr == 'ansible.builtin._return'
    assert not var_1.searched_paths

# Generated at 2022-06-25 10:18:44.535517
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    plugin_load_context = PluginLoadContext(
        plugin_name='',
        plugin_vars=dict(),
        config_options=dict(),
        aliases={},
        plugin_type='',
        )
    import ansible.plugins.loader
    plugin_loader = ansible.plugins.loader.PluginLoader(
        '',
        '',
        '',
        None,
        '',
        {},
        dict(),
        dict(),
        )

# Generated at 2022-06-25 10:18:54.663815
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    base_path = 'lib/ansible/plugins'
    package = 'my_plugins'
    class_name = 'MyPlugin'
    base_class = 'MyBasePluginClass'
    fqcr = 'ansible.plugins.my_plugins.MyPlugin'
    name = 'my_plugin'
    suffix = '.py'
    plugin_load_context = PluginLoadContext(package=package, fqcr=fqcr, name=name, suffix=suffix,
                                            class_name=class_name, base_class=base_class,
                                            base_path=base_path)
    obj = PluginLoader(package=package, class_name=class_name, base_class=base_class,
                       base_path=base_path)

# Generated at 2022-06-25 10:18:57.690018
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    '''
    Ensure there are no regressions in basic functionality of add_all_plugin_dirs
    '''
    add_all_plugin_dirs('/path/to/foo')
    add_all_plugin_dirs('/path/to/bar')


# Generated at 2022-06-25 10:18:59.159735
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_0 = PluginLoader('test_value_0')
    var_1 = PluginLoader.all(var_0)
    assert var_1 == None


# Generated at 2022-06-25 10:19:04.556050
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    l = PluginLoader('action_plugin')
    r = l.get_with_context('ping')
    assert type(r.context) is PluginLoadContext
    assert r.context.collection is None
    assert r.context.origin is None
    assert r.context.resolved is True
    assert r.context.plugin_resolved_path is None
    assert r.context.redirect_list == ['ansible.builtin.ping']
    assert r.object.__class__.__name__ == 'ActionModule'


# Generated at 2022-06-25 10:19:10.146173
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Create the plugin loaders
    var_0 = get_all_plugin_loaders()
    # Create the plugin load context
    var_1 = PluginLoadContext()
    # Try to find a filter with a name that equals 'to_yaml'
    var_2 = var_0['filter_loader'].find_plugin_with_context('to_yaml', plugin_load_context=var_1)
    # Check that the plugin load context is resolved
    assert var_2.resolved
    # Check that the plugin load context is resolved
    assert var_2.resolved


# Generated at 2022-06-25 10:19:17.228592
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test constructor
    plugin_loader = PluginLoader(
        'ansible.plugins',
        'Connection',
        'ansible.plugins.connection',
        'ConnectionBase',
        C.DEFAULT_CONNECTION_PLUGIN_PATH,
        required_base_class='ConnectionBase'
    )

    # Test method find_plugin_with_context of class PluginLoader
    name = 'local'
    collection_list = None
    plugin_load_context = plugin_loader.find_plugin_with_context(
        name,
        collection_list=collection_list
    )
    # Check if plugin_load_context.resolved is True
    assert plugin_load_context.resolved is True
    # Check if plugin_load_context.plugin_name == 'local'

# Generated at 2022-06-25 10:19:19.884594
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # TODO: test case for method find_plugin of class Jinja2Loader
    var_0 = Jinja2Loader('ansible.plugins.filter')
    var_1 = var_0.find_plugin('ansible.plugins.filter.foo')


# Generated at 2022-06-25 10:19:29.470889
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    my_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    print('\nStarting find_plugin_with_context test')
    print('\nCalling find_plugin_with_context for ping')
    print(my_loader.find_plugin_with_context('ping'))
    print('\nCalling find_plugin_with_context for wait_for')
    print(my_loader.find_plugin_with_context('wait_for'))
    print('\nCalling find_plugin_with_context for wait_for_connection')
    print(my_loader.find_plugin_with_context('wait_for_connection'))
    print('\nCalling find_plugin_with_context for shell')

# Generated at 2022-06-25 10:19:34.596768
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    # Declare the inputs
    shell_type = None
    executable = None
    # Declare the outputs
    p_shell_0 = None
    # Get the output
    try:
        p_shell_0 = get_shell_plugin(shell_type, executable)
    except Exception as e:
        raise e
    assert p_shell_0

    var_0 = get_all_plugin_loaders()


# Generated at 2022-06-25 10:20:23.002277
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    view = get_plugin_loader()

    # test 1
    try:
        output = view.find_plugin_with_context('foo')
        assert(False)
    except AnsibleError:
        pass

    # test 2
    view = get_plugin_loader()
    output = view.find_plugin_with_context('foo')
    assert(output)


# Generated at 2022-06-25 10:20:23.533217
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    assert True


# Generated at 2022-06-25 10:20:25.880837
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_0 = PluginLoader()
    for i in var_0.all():
        print(i)


# Generated at 2022-06-25 10:20:27.022582
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    assert False, 'Test Not Implemented'


# Generated at 2022-06-25 10:20:28.357379
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    var_1 = get_all_plugin_loaders()


# Generated at 2022-06-25 10:20:34.283414
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    lgr = logging.getLogger('ansible-test')
    lgr.setLevel(logging.DEBUG)
    lgr.addHandler(logging.StreamHandler(sys.stdout))
    
    plugin_loader = PluginLoader('action', '.', lgr)
    
    tests = ['test_PluginLoader_all']
    for t in tests:
        print('Running test %s' % t)
        func = globals()[t]
        func()



# Generated at 2022-06-25 10:20:35.174138
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    print('Test method: get_with_context')


# Generated at 2022-06-25 10:20:41.512943
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    if not isinstance(C._PLUGIN_PATH, list):
        raise AssertionError
    for item in C._PLUGIN_PATH:
        if not isinstance(item, str):
            raise AssertionError
    add_all_plugin_dirs(C._PLUGIN_PATH[0])
    """
    add_all_plugin_dirs(C._PLUGIN_PATH[0])
    result = {'add_directory': 1, 'subdir': ''}
    if get_all_plugin_loaders() != result:
        raise AssertionError
    """


# Generated at 2022-06-25 10:20:49.021263
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    var_0 = PluginLoader('foo', path=[])
    var_1 = var_0.find_plugin_with_context('foo')
    assert var_1
    assert var_1.plugin_resolved_name
    assert var_1.plugin_resolved_path
    assert isinstance(var_1, PluginLoadContext)
    var_2 = var_0.find_plugin_with_context('foo.bar')
    assert var_2
    assert var_2.plugin_resolved_name
    assert var_2.plugin_resolved_path
    assert isinstance(var_2, PluginLoadContext)
    var_3 = var_0.find_plugin_with_context('foo.bar', extension='.py')
    assert var_3
    assert var_3.plugin_resolved_name
    assert var_3

# Generated at 2022-06-25 10:20:53.104205
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    print("testing PluginLoader.__init__")
    if not isinstance(a, PluginLoader):
        raise Exception("PluginLoader.__init__ does not exist")

    print("testing PluginLoader.get_with_context")
    if not isinstance(a.get_with_context, PluginLoader):
        raise Exception("PluginLoader.get_with_context does not exist")
