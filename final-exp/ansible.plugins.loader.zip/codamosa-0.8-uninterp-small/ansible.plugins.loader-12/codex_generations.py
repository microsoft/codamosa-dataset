

# Generated at 2022-06-25 10:16:42.143478
# Unit test for method find_plugin of class PluginLoader

# Generated at 2022-06-25 10:16:44.754182
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    if False:
        var_0 = C.DEFAULT_TEMPLATE_EXTENSION
    if False:
        var_1 = C.DEFAULT_IGNORE_FILES


# Generated at 2022-06-25 10:16:55.453276
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    new_paths = C.DEFAULT_MODULE_PATH[:]
    # set up test paths
    new_paths.extend([location for location in new_paths if location])
    new_paths.append('/tmp/does/not/exist')
    new_paths.append('/tmp/also/does/not/exist')
    new_paths.append('/tmp/also/does/not/exist/from/a/different/list')
    # clear the plugins from PATH_CACHE and MODULE_CACHE
    clear_caches()
    # add the paths, checking for errors

# Generated at 2022-06-25 10:16:58.284793
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():

    assert(True) == (True)
    assert(False) == (False)
    #assert(True) == (False)



# Generated at 2022-06-25 10:17:01.577146
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    loader = PluginLoader('module_utils', 'AnsibleModule')
    modules = []
    for module in loader.all():
        modules.append(module)
    assert(modules != [])



# Generated at 2022-06-25 10:17:03.373491
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    var_0 = PluginLoader(package='ansible.plugins.strategy', subdir='module_utils')


# Generated at 2022-06-25 10:17:04.807217
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    var_1 = get_shell_plugin()
    var_2 = get_all_plugin_loaders()


# Generated at 2022-06-25 10:17:06.226618
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert callable(get_shell_plugin)
    assert get_shell_plugin() == None


# Generated at 2022-06-25 10:17:15.357016
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    var_0 = Jinja2Loader('.filter_loader', package='ansible.plugins.filter_loader', config={})
    var_0.add_directory('./')
    var_0.module_cache = {}
    var_0.module_count = 0
    var_0.class_name = 'FilterModule'
    var_0.base_class = 'FilterModule'
    var_0.paths = ['./']
    var_0.searched_paths = ['./']
    var_0.package = 'ansible.plugins.filter_loader'
    var_0.subdir = '.filter_loader'
    var_1 = var_0.get('ansible.builtin.ipaddr')
    var_2 = var_0.get('ansible.builtin.jinja2_template')

# Generated at 2022-06-25 10:17:21.962955
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    var_0 = get_shell_plugin()
    var_1 = dict()
    for var_2 in var_0.all():
        var_2.load()
        var_1[var_2] = var_2.plugin_path
    orig_len = len(var_0.all())
    var_3 = "/tesT/Path"
    add_all_plugin_dirs(var_3)
    var_4 = len(var_0.all())
    assert var_4 == orig_len, "add_all_plugin_dirs should not add any plugins, as the directory does not exist"
    var_3 = C.DEFAULT_CACHE_PLUGIN_PATH
    add_all_plugin_dirs(var_3)
    var_4 = len(var_0.all())
    assert var

# Generated at 2022-06-25 10:18:02.927502
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    fixture_data = {
        "rsa_private_key_file": "data/ansible_rsa_key",
        "rsa_public_key_file": "data/ansible_rsa_key.pub"
    }
    fixture_loader = TestLoader()
    fixture_args = {
        "name": fixture_data["rsa_private_key_file"]
    }
    fixture_obj = PluginLoader(
        "", "", "", fixture_args
    )

    fixture_obj.find_plugin()


# Generated at 2022-06-25 10:18:04.975986
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    example_path = '/home/sshuair/ansible/ansible_modules/shell'
    assert add_all_plugin_dirs(example_path) == None



# Generated at 2022-06-25 10:18:10.290692
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # This example loads a plugin called "foo" into the global cache.
    # As a result, the name of the plugin is "foo" and the plugin
    # is stored in a cache entry called "foo".
    assert add_all_plugin_dirs("foo") == {'name': 'foo', 'cache': {}, 'case_sensitive': False, 'class_name': None, 'directories': ['/path/to/plugins/foo'], 'subdir': None}
    
    
    
    
    

# Generated at 2022-06-25 10:18:11.643042
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    assert False  # TODO: implement your test here


# Generated at 2022-06-25 10:18:13.408286
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    var_0 = Jinja2Loader("", "", "")


# Generated at 2022-06-25 10:18:15.020384
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # Run just the code in the function
    test_case_0()



# Generated at 2022-06-25 10:18:21.492319
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    """
    Tests functionality of function add_all_plugin_dirs
    """
    class MockPluginLoader(object):
        subdir = 'subdir'

        @staticmethod
        def add_directory(path):
            print("add_directory called with: " + path)

    class constants(object):
        config_base_paths = ['~/.ansible']

    plugin_loaders = get_all_plugin_loaders()

    setattr(sys.modules[__name__], 'get_all_plugin_loaders', lambda: [(None, MockPluginLoader())])

    # Normal execution
    test_path = '/home/user/new_cpl_path/subdir'
    add_all_plugin_dirs(test_path)

    # Fail execution - path is not valid directory

# Generated at 2022-06-25 10:18:31.208935
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    TEST_DIR_NAME = 'test_adap'
    b_TEST_DIR_NAME = to_bytes(TEST_DIR_NAME, errors='surrogate_or_strict')
    TEST_DIR_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), b_TEST_DIR_NAME)
    os.makedirs(TEST_DIR_PATH)
    add_all_plugin_dirs(TEST_DIR_NAME)
    for name, obj in get_all_plugin_loaders():
        if obj.subdir:
            plugin_path = os.path.join(TEST_DIR_PATH, to_bytes(obj.subdir))
            assert(os.path.isdir(plugin_path))

# Generated at 2022-06-25 10:18:38.557033
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    cwd = os.getcwd()
    test_path = '/'.join(cwd.split('/')[:-2])
    exeee = os.path.join(test_path, 'test/sanity/code/unit/data/missing_plugin_dirs')
    add_all_plugin_dirs(exeee)
    var_0 = C.DEFAULT_MODULE_PATH
    cwd = os.getcwd()
    var_1 = '/'.join(cwd.split('/')[:-2])
    if var_0 == var_1:
        var_2 = 1
    else:
        var_2 = 0
    assert var_2 == 1


# Generated at 2022-06-25 10:18:41.785660
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():

    # Setup
    var_0 = PluginLoader('', '', '', '')

    # Expected arguments
    var_1 = "filter"

    # Actual arguments
    var_2 = None

    # Call to get_with_context of PluginGetter
    var_3 = get_with_context(var_0, var_1, var_2)

    # Asserts
    assert var_3 is None



# Generated at 2022-06-25 10:20:08.921344
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    var_0 = Jinja2Loader('ansible.legacy.plugins.lookup', 'LookupModule')
    var_1 = var_0.get("foo")
    if var_1:
        raise AssertionError("Expected None, got %s" % var_1)


# Generated at 2022-06-25 10:20:12.881875
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Make sure that the plugin directory is set and contains some plugins
    add_all_plugin_dirs(C.DEFAULT_MODULE_PATH)

    # Make sure that the plugin is empty, then that it can be filled from the default path
    for name, obj in get_all_plugin_loaders():
        assert obj.directories() == set(), "Fail: Initial plugin path list must be empty"
        obj.add_directory(C.DEFAULT_MODULE_PATH)



# Generated at 2022-06-25 10:20:15.141062
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    var_1 = PluginLoader('filter_plugins')
    var_2 = var_1.__contains__('set_fact')


# Generated at 2022-06-25 10:20:19.029398
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    all_plugin_loaders = get_all_plugin_loaders()
    assert len(all_plugin_loaders) == 4, 'Add all plugin dirs should have 4 plugins in it'


# Generated at 2022-06-25 10:20:20.588587
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():

    display.deprecated("")
    display.deprecated("")
    display.deprecated("")



# Generated at 2022-06-25 10:20:22.128574
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():

    # No test available, get_shell_plugin() has no return value
    pass


# Generated at 2022-06-25 10:20:31.722686
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Initialize the class
    pl = PluginLoader('ansible.shell', 'ShellModule')
    # Run the method
    # There should be no exceptions raised
    pl.all()
    # Initialize the class
    p2 = PluginLoader('ansible.shell', 'ShellModule', 'ansible.plugins.connection')
    # Run the method
    # There should be no exceptions raised
    p2.all()
    # Initialize the class
    p3 = PluginLoader('ansible.shell', 'ShellModule', 'ansible.plugins.connection', CUSTOM_PATH)
    # Run the method
    # There should be no exceptions raised
    p3.all()
    # Initialize the class
    p4 = PluginLoader('ansible.shell', 'ShellModule', 'ansible.plugins.connection', False)
    # Run the method
   

# Generated at 2022-06-25 10:20:36.225330
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    var_0 = PluginLoader(var_0='ansible.plugins.shell', var_1='ShellModule')
    var_1 = var_0.find_plugin_with_context(var_0='shell')
    var_2 = var_1.resolved
    var_3 = var_1.plugin_resolved_path
    var_4 = var_3.endswith(var_0='shell.py')


# Generated at 2022-06-25 10:20:37.073481
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    test_case_0()


# Generated at 2022-06-25 10:20:45.881318
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    var_0 = Jinja2Loader(class_name='Foo', package='ansible.plugins.filter')
    # Pass in kwarg: collection_list
    var_0.find_plugin(name='ansible.legacy.core.foo', collection_list=['asdf'])
    # Pass in kwarg: class_only
    var_0.get(name='ansible.legacy.core.foo', class_only=True)
    # Pass in kwarg: _load_context
    var_0.get(name='ansible.legacy.core.foo', _load_context=None)
    # Pass in kwarg: _enforce_requirements
    var_0.get(name='ansible.legacy.core.foo', _enforce_requirements=False)
    # Pass in kwarg