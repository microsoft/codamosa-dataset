

# Generated at 2022-06-25 10:13:55.233653
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # FIXME: This is really a test for the get_plugin method, not PluginLoader.get_with_context
    class_only = False
    collection_list = None

    class_name = 'FilterModule'
    plugin_load_context_0 = PluginLoadContext()
    plugin_load_context_0.resolved = True
    plugin_load_context_0.plugin_resolved_name = 'name'
    plugin_load_context_0.plugin_resolved_path = 'path'
    plugin_loader_0 = PluginLoader(class_name, 'package')

# Generated at 2022-06-25 10:14:06.736616
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    plugin_loader_0 = PluginLoader('test', 'ansible.plugins.testloader')

# Generated at 2022-06-25 10:14:09.363164
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    test_case_0()

if __name__ == '__main__':
    test_PluginLoader_get_with_context()

# Generated at 2022-06-25 10:14:18.273598
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Clear cache so we actually load the test plugin
    action = PluginLoader('action', 'ActionModule', 'action_plugins', 'module_utils.module_runner.ActionModule')
    action.package = 'action'
    action._module_cache = {}
    action._searched_paths = []

    # Check that get_with_context returns pong when called with name ping
    result = action.get_with_context('ping')

    assert result.plugin_load_context.plugin_resolved_name == 'ping'
    assert result.plugin_load_context.plugin_resolved_path == '<test_plugins>/ping.py'
    assert result.object.name == 'pong'


# Generated at 2022-06-25 10:14:24.048223
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    obj = test_case_0()
    test_func = add_dirs_to_loader(which_loader="", paths=obj.paths)
    assert '<ansible.utils.plugin_docs.add_dirs_to_loader.<locals>.test_case_0.<locals>.test_func object at 0x7fb91427f7b8>' == repr(test_func)


# Generated at 2022-06-25 10:14:28.873729
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    try:
        test_case_0()
    except Exception as e:
        display.error('Caught exception in test_get_shell_plugin: %s' % to_text(e, errors='surrogate_or_strict'))
        raise


# Generated at 2022-06-25 10:14:35.433437
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    directory_path = '/usr/share/ansible_collections/ansible/builtin/'
    plugin_load_context_0 = PluginLoadContext()
    add_all_plugin_dirs(directory_path)
    assert plugin_load_context_0 is True


# Generated at 2022-06-25 10:14:39.768966
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    test_case_0()


# Generated at 2022-06-25 10:14:48.138032
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test a specific plugin
    plugin_load_context_1 = PluginLoader(package='fixture_plugins', subdirs=['nonexistent'], base_class=None, class_name='NotAPlugin').get_with_context('fixture_plugins.not_a_plugin')
    assert plugin_load_context_1.resolved is False
    assert plugin_load_context_1.plugin_resolved_name is None
    assert plugin_load_context_1.plugin_name is 'fixture_plugins.not_a_plugin'
    assert plugin_load_context_1.plugin_search is None
    assert plugin_load_context_1.plugin_resolved_path is None
    assert plugin_load_context_1.plugin_load_context is None

# Generated at 2022-06-25 10:14:50.141520
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    pass


# Generated at 2022-06-25 10:15:20.579630
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    var_b_path = os.path.expanduser(to_bytes(path, errors='surrogate_or_strict'))
    if os.path.isdir(b_path):
        for name, obj in get_all_plugin_loaders():
            if obj.subdir:
                plugin_path = os.path.join(b_path, to_bytes(obj.subdir))
                if os.path.isdir(plugin_path):
                    obj.add_directory(to_text(plugin_path))
    else:
        display.warning("Ignoring invalid path provided to plugin path: '%s' is not a directory" % to_text(path))



# Generated at 2022-06-25 10:15:23.690545
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    var_1 = AnsiblePlugin(value='ansible.plugins.lookup.ansible_local')
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 10:15:24.376356
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    assert False


# Generated at 2022-06-25 10:15:26.000609
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    global _PLUGIN_PATHS
    plugin_name = 'i18n'
    return get_all_plugin_loaders()[0].find_plugin(plugin_name)


# Generated at 2022-06-25 10:15:27.606719
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    pass


# Generated at 2022-06-25 10:15:30.671199
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    loader = Jinja2Loader('ansible.plugins.test.test_loader', 'FilterModule')
    plugin = loader.get('bigip.jsonify')
    assert (plugin.FILTERS == ['jsonify'])


# Generated at 2022-06-25 10:15:38.637950
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():

    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.cache import CacheModule
    from ansible.plugins.cache.pkgng import Pkgng
    from ansible.plugins.cache.yum import Yum
    from ansible.plugins.cache.zypper import Zypper
    from ansible.plugins.cache.pacman import Pacman
    from ansible.plugins.cache.yum_cron import YumCron

    # Initialize a PluginLoader object
    var_1 = PluginLoader('cache', 'ansible.plugins.cache', 'CacheModule', 'cache/')

    # Test the all method
    var_2 = var_1.all('/foo/bar', 'bar', 'baz', path_only=True)

# Generated at 2022-06-25 10:15:41.582730
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    tc_0 = Jinja2Loader('', '', '', '', '')
    tc_0.find_plugin('')


# Generated at 2022-06-25 10:15:43.275913
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    plc_0 = PluginLoadContext()
    plc_0.record_deprecation()


# Generated at 2022-06-25 10:15:48.682527
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    var_0 = type(PluginLoader())
    var_1 = var_0.__contains__
    var_2 = PluginLoader()
    var_3 = to_text(var_2)
    var_4 = None
    var_5 = var_1(var_2, var_3, var_4)
    return var_5


# Generated at 2022-06-25 10:16:15.152605
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    parameter_0_deprecation_warning_text = ""
    parameter_0_removal_date = ""
    parameter_0_removal_version = ""
    parameter_0_name = ""
    parameter_0_deprecation = {"warning_text": parameter_0_deprecation_warning_text, "removal_date": parameter_0_removal_date, "removal_version": parameter_0_removal_version}
    parameter_1_collection_name = ""
    return_value_0 = PluginLoadContext.record_deprecation(parameter_0_name, parameter_0_deprecation, parameter_1_collection_name)


# Generated at 2022-06-25 10:16:16.745392
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    var_0 = PluginLoader()
    var_1 = PluginLoader()
    if var_1.__contains__( var_0):
        raise ValueError("foo")


# Generated at 2022-06-25 10:16:18.921778
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    assert add_all_plugin_dirs(0) == "Invalid path provided to plugin path: '0' is not a directory"


# Generated at 2022-06-25 10:16:27.466630
# Unit test for function add_dirs_to_loader

# Generated at 2022-06-25 10:16:30.625804
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    which_loader = 'shell'
    paths = '/home/vagrant/.ansible/tmp/ansible_test/test_collections/my_namespace/my_collection/plugins/modules'
    add_dirs_to_loader(which_loader, paths)


# Generated at 2022-06-25 10:16:38.169534
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    var_0 = get_all_plugin_loaders()
    var_1 = None
    var_2 = None
    var_3 = None

    try:
        var_1 = var_0[1]
    except IndexError:
        pass

    try:
        var_2 = var_1[1]
    except IndexError:
        pass

    try:
        var_3 = var_2[0]
    except IndexError:
        pass

    if (var_3 == 'callback_loader'):
        return True
    else:
        return False




# Generated at 2022-06-25 10:16:43.164873
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    obj_0 = Jinja2Loader('ansible.plugins.test.test_plugin_loader', 'TestLoaderJ2', 'tests')
    obj_0.add_directory(os.path.join(os.path.dirname(__file__), '..'))
    obj_0.get('get')


# Generated at 2022-06-25 10:16:46.795190
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    p = PluginLoadContext()
    name = 'name'
    deprecation = {'warning_text': 'warning_text', 'removal_date': 'removal_date', 'removal_version': 'removal_version'}
    p.record_deprecation(name, deprecation, 'collection_name')


# Generated at 2022-06-25 10:16:58.437520
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    var_1 = get_plugin_loader('connection')
    ansible_test.patch_for_test(var_1, '_load_module')
    var_2 = get_plugin_loader('action')
    ansible_test.patch_for_test(var_2, '_load_module')
    var_3 = get_plugin_loader('vars')
    ansible_test.patch_for_test(var_3, '_load_module')
    var_4 = get_plugin_loader('cache')
    ansible_test.patch_for_test(var_4, '_load_module')
    var_5 = get_plugin_loader('fragment')
    ansible_test.patch_for_test(var_5, '_load_module')

# Generated at 2022-06-25 10:17:04.094612
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():

    # Save a backup of the globals
    backup = globals().copy()

    # Create a new instance of class Jinja2Loader
    var_0 = Jinja2Loader('', '', '', '', '', '')

    # Invoke method 'get' of the newly created instance

    # Assert the invoked method is equal to a known value
    assert var_0.get('', '', '', '', '', '') == None


# Generated at 2022-06-25 10:17:39.130012
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type='sh', executable='abc')
    assert shell


# Generated at 2022-06-25 10:17:40.631255
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    var = get_shell_plugin(shell_type=None, executable=None)
    assert var == None


# Generated at 2022-06-25 10:17:41.887065
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    add_all_plugin_dirs('/home/python/ansible/lib/ansible/plugins/')


# Generated at 2022-06-25 10:17:44.568393
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    var_0 = get_all_plugin_loaders()
    print(var_0)


# Generated at 2022-06-25 10:17:51.105615
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    _loader_paths = get_all_plugin_loaders()
    _loader_paths_0 = _loader_paths.get('action')
    _fq_name_0 = 'ansible.builtin.ping'
    _plugin_load_context_0 = _loader_paths_0.find_plugin_with_context(_fq_name_0)
    _plugin_load_context_0 = _loader_paths_0.find_plugin_with_context('ansible_builtin_test_plugin')


# Generated at 2022-06-25 10:17:52.894212
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin('sh')
    print("shell.type = ", shell.type)



# Generated at 2022-06-25 10:18:02.738208
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    var_0 = Jinja2Loader()
    var_0.get(var_0)


# Generated at 2022-06-25 10:18:04.323932
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_0 = get_all_plugin_loaders()
    var_1 = var_0.all()
    return var_1


# Generated at 2022-06-25 10:18:10.549093
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    cls = PluginLoader("", "", "")
    var_1 = cls.get_with_context("")
    assert var_1 == None
    assert cls.package == ""
    assert cls.class_name == ""
    assert cls.base_class == ""
    assert cls.config_defaults == {}
    assert cls.aliases == {}
    assert cls.plugin_manager == {}
    assert cls._searched_paths == []
    assert cls._module_cache == {}
    assert cls._displayed_deprecation_messages == {}


# Generated at 2022-06-25 10:18:11.705116
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    var_0 = add_all_plugin_dirs('/test/test')


# Generated at 2022-06-25 10:18:41.446619
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    var_0 = get_shell_plugin()


# Generated at 2022-06-25 10:18:47.397942
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    var_0 = get_all_plugin_loaders()
    var_1 = var_0.__iter__()
    try:
        var_2 = next(var_1)
    except StopIteration:
        var_2 = None
    while (var_2 is not None):
        var_3 = var_2.find_plugin_with_context('debug')
        try:
            var_2 = next(var_1)
        except StopIteration:
            var_2 = None


# Generated at 2022-06-25 10:18:51.297214
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    var_0 = Jinja2Loader('action', 'core', b'some_directory')
    var_1 = 'some name'
    var_2 = var_0.get(var_1)
    assert var_2 is None


# Generated at 2022-06-25 10:18:59.769007
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    import ansible.plugins
    plugin_loader=PluginLoader("filter_loader", "FilterModule", C.DEFAULT_INTERNAL_PLUGIN_PATH, 'ansible.plugins.filter_plugins')
    plugin_loader.find_plugin_with_context("urldecode", collection_list=None)
    # Test to see if the PluginLoader object initialized correctly.
    assert plugin_loader.package == 'ansible.plugins.filter_plugins'
    assert plugin_loader.class_name == 'FilterModule'
    assert plugin_loader.paths == [C.DEFAULT_INTERNAL_PLUGIN_PATH]
    assert plugin_loader.subdir == 'filter_plugins'
    assert plugin_loader.collection_package == 'ansible.plugins'
    assert plugin_loader.aliases == {}
    assert plugin_loader.class_

# Generated at 2022-06-25 10:19:01.341063
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_1 = get_all_plugin_loaders()
    for var_0 in var_1:
        var_0.all()


# Generated at 2022-06-25 10:19:03.118998
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    print("Test find_plugin")
    var_0 = Jinja2Loader.find_plugin(var_0, var_1)
    print(var_0)



# Generated at 2022-06-25 10:19:04.773507
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # setup test
    x = Jinja2Loader('path')
    x.find_plugin(name = 'name')


# Generated at 2022-06-25 10:19:11.072785
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    a = PluginLoadContext()
    a1 = {'warning_text': 'test_warning_text', 'removal_date': 'test_removal_date', 'removal_version': 'test_removal_version'}
    a2 = a.record_deprecation('test_name', a1, 'test_collection_name')
    assert a2.deprecated == True
    assert a2.removal_date == 'test_removal_date'
    assert a2.removal_version == 'test_removal_version'
    assert a2.deprecation_warnings == ['test_name has been deprecated. test_warning_text']


# Generated at 2022-06-25 10:19:18.087110
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    print("test_PluginLoader_find_plugin_with_context")
    plugin_loader = PluginLoader("test.module")
    
    plugin_name = "set_fact"
    plugin_type = "module"
    
    plugin_name2 = "setup"
    plugin_type2 = "module"
        
    # Test Case 0
    # Test with plugin name and plugin type
    plugin_load_context = plugin_loader.find_plugin_with_context(name=plugin_name, class_name=plugin_type)
    try:
        plugin_load_context.get_plugin_resolved_name()
    except Exception as e:
        print("Error: " + str(e))
        assert False
    else:
        assert True
        print("Test Case 0: Success")
        
    # Test Case 1
    # Test

# Generated at 2022-06-25 10:19:24.497058
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    root_path = get_all_plugin_loaders()
    plugin_loader = PluginLoader(os.path.join(root_path, 'lookup'), 'LookupModule', 'ansible.parsing.plugin_docs_fragments', '_load_parsing_docs')
    plugin_name = 'fileglob'
    plugin_load_context = plugin_loader.find_plugin_with_context(plugin_name)
    if not plugin_load_context.resolved:
        # FIXME: this is probably an error
        return None
    plugin_resolved_path = plugin_load_context.plugin_resolved_path
    plugin_resolved_name = plugin_load_context.plugin_resolved_name
    plugin_class_name = plugin_load_context.plugin_class_name
    # test assert condition 1

# Generated at 2022-06-25 10:20:38.788828
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    var_0 = 'lookup_plugin'
    var_1 = '''/home/ubuntu/workspace/ansible/lib/ansible/plugins/lookup/hashivault.py'''
    var_2 = '''/home/ubuntu/workspace/ansible/lib/ansible/plugins/lookup/aws_parameter_store.py'''
    var_3 = '''/home/ubuntu/workspace/ansible/lib/ansible/plugins/lookup/azure_rm.py'''
    var_4 = '''/home/ubuntu/workspace/ansible/lib/ansible/plugins/lookup/gcp_secret_manager.py'''
    var_5 = '''/home/ubuntu/workspace/ansible/lib/ansible/plugins/lookup/aws_ssm.py'''

# Generated at 2022-06-25 10:20:43.061503
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    """Test case for find_plugin"""
    plugin_loader = PluginLoader(package=None, directories=None, class_name=None, config_options=None)
    assert plugin_loader.find_plugin(name=None, collection_list=None) is None
    assert plugin_loader.find_plugin_with_context(name=None, collection_list=None) is None


# Generated at 2022-06-25 10:20:48.933711
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # var_0 is a PluginLoader
    var_0 = PluginLoader('foo', 'bar')
    # var_1 is a str
    var_1 = 'baz'
    # var_2 is a PluginLoadContext
    var_2 = var_0.find_plugin_with_context(var_1)
    # var_3 is a PluginLoadContext
    var_3 = var_2.success(1)
    # var_4 is a PluginLoadContext
    var_4 = var_2.nope(1)
    # var_5 is a PluginLoadContext
    var_5 = var_2.fail(1)


# Generated at 2022-06-25 10:20:52.295609
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    plugin_loader = PluginLoader(package='ansible.plugins.dummy', class_name='Dummy', subdir='library', base_class='BASE')
    plugin_load_context = plugin_loader.find_plugin_with_context('name')


# Generated at 2022-06-25 10:21:00.953916
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    var_1 = AnsibleCollectionRef('ansible_collections.acme.example')
    var_2 = {'j2_collection': var_1}
    var_3 = PluginLoader('plugin_type', 'plugin_name', 'base_class', {'path': 'path'}, var_2)
    try:
        var_3.find_plugin('name', var_2)
    except Exception as exc:
        var_4 = exc
    else:
        var_4 = None
    if var_4 is not None:
        print(str(var_4))
    try:
        var_3.find_plugin('name', var_2)
    except Exception as exc:
        var_5 = exc
    else:
        var_5 = None

# Generated at 2022-06-25 10:21:01.958003
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    add_all_plugin_dirs("/tmp")


# Generated at 2022-06-25 10:21:03.911477
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    for var_0 in get_all_plugin_loaders():
        var_1 = var_0.__contains__(name = '_fixture_data')


# Generated at 2022-06-25 10:21:06.920516
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # More tests are needed
    for loader_name, loader in get_all_plugin_loaders().items():
        if 'terminal' in loader_name:
            assert loader.find_plugin('ansible.plugins.terminal.TerminalModule') == 'ansible.plugins.terminal.TerminalModule'


# Generated at 2022-06-25 10:21:09.581218
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    var_0 = PluginLoader('action', PackageFinder(['/etc/ansible/plugins/action']))
    var_1 = 'copy'
    var_2 = None
    var_0.__contains__(var_1, var_2)


# Generated at 2022-06-25 10:21:11.660142
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    var_0 = get_all_plugin_loaders()
    var_0 = get_all_plugin_loaders()
    var_0[0].has_plugin('')
