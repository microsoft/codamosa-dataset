

# Generated at 2022-06-25 10:13:23.623168
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    assert False


# Generated at 2022-06-25 10:13:26.853755
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    print("Calling function test_add_all_plugin_dirs")
    print("Path = /Users/daniel/playbooks/ansible/plugins/modules")
    add_all_plugin_dirs("/Users/daniel/playbooks/ansible/plugins/modules")


# Generated at 2022-06-25 10:13:35.003690
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    PLUGIN_LOADER_BASE = 'ansible.legacy'
    PLUGIN_PATH = 'ansible.plugins.action.builtin_action'
    PLUGIN_NAME = 'mock_plugin'
    PLUGIN_CLASS_NAME = 'ActionModule'

    finder = Jinja2Loader(PLUGIN_PATH, PLUGIN_CLASS_NAME)
    plugin_path = finder.find_plugin(PLUGIN_NAME)
    expected_result = PLUGIN_LOADER_BASE + os.sep + PLUGIN_PATH + os.sep + PLUGIN_NAME + '.py'
    if plugin_path == expected_result:
        pass

# Generated at 2022-06-25 10:13:35.621963
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    test_case_0()


# Generated at 2022-06-25 10:13:40.166252
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    var_1 = PluginLoader('module_utils', '_module_utils', 'custom', os.path.join(os.path.dirname(__file__), '../module_utils'))
    var_2 = var_1.__setstate__('module_utils', '_module_utils', 'custom', os.path.join(os.path.dirname(__file__), '../module_utils'))


# Generated at 2022-06-25 10:13:45.470857
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    var_0 = PluginLoader('filter', 'ansible.plugins.filter', C.DEFAULT_FILTER_PLUGIN_PATH, 'FilterModule')
    var_1 = {'*': set(['set_type'])}
    var_2 = None
    var_2 = var_0.__setstate__(var_1)
    assert var_2 == None


# Generated at 2022-06-25 10:13:48.906549
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    var_0 = get_all_plugin_loaders()
    for (name, obj) in var_0:
        if obj.subdir:
            if str(name):
                add_dirs_to_loader(str(name), "example/")


# Generated at 2022-06-25 10:13:56.973755
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    var_0 = [
        os.path.join(os.path.dirname(__file__), 'fixtures/test_loader/not_a_plugin'),
        os.path.join(os.path.dirname(__file__), 'fixtures/test_loader/not_a_dir'),
        os.path.join(os.path.dirname(__file__), 'fixtures/test_loader/test_valid_plugin'),
    ]

# Generated at 2022-06-25 10:14:07.973178
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    PluginLoader = get_plugin(PluginLoader, 'get_plugin')
    pl = PluginLoader('ansible.plugins.test_plugins')
    pl.__setstate__({})
    path_0 = pl.path_with_conf

# Generated at 2022-06-25 10:14:18.744109
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    var_0 = PluginLoader(package='ansible.plugins.action', subdir='action_plugins', namespaces=None, class_name='ActionModule')
    var_2 = AnsibleCollectionRef("ansible_collections.test.test_collection.plugins.test_action_plugin")
    var_4 = AnsibleCollectionRef("ansible_collections.test.test_collection.plugins.test_action_plugin")
    var_5 = AnsibleCollectionRef("ansible_collections.test.test_collection.plugins.test_action_plugin")
    var_6 = AnsibleCollectionRef("ansible_collections.test.test_collection_2.plugins.test_action_plugin")
    var_8 = var_0.find_plugin_with_context("action_plugins.test_action_plugin", collection_list=[var_2])


# Generated at 2022-06-25 10:14:45.653256
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # dir_name = './test_dir'
    # test_dir = os.path.dirname(dir_name)
    #
    # if not os.path.exists(dir_name):
    #     os.mkdir(dir_name)
    #     test_dir = os.path.dirname(dir_name)
    #
    # add_dirs_to_loader('shell', [test_dir])
    #
    test_case_0()



# Generated at 2022-06-25 10:14:49.017021
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    global var_0
    var_0 = Jinja2Loader('ansible.plugins.shell', subdir='', base_class='')
    test_Jinja2Loader_find_plugin__name_arg = ''
    test_Jinja2Loader_find_plugin__collection_list_arg = None
    var_1 = var_0.find_plugin(test_Jinja2Loader_find_plugin__name_arg, test_Jinja2Loader_find_plugin__collection_list_arg)
    var_2 = glob.glob(to_native(os.path.join(var_1, "*.py")))


# Generated at 2022-06-25 10:14:54.427872
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    var_0 = Jinja2Loader(class_name='TestCase0')
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_1 = var_0.find_plugin(var_1, var_2, var_3, var_4, var_5)
    assert var_1 is None


# Generated at 2022-06-25 10:15:01.577930
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    var_1 = PluginLoader(package='ansible.plugins.action', subdir=None, aliases=None)
    var_2 = 'raw'
    var_3 = None
    var_4 = var_1.find_plugin_with_context(var_2, collection_list=var_3)
    assert isinstance(var_4, PluginLoaderContext)



# Generated at 2022-06-25 10:15:10.012345
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    df = {}

    # Test normal case
    df['_module_cache'] = 'foo'
    df['searched_paths'] = 'foo'
    test_obj_0 = PluginLoader('foo', 'foo', None, False, False, False)
    if test_obj_0: test_obj_0.__setstate__(df)

    # Test raised exception
    df['_module_cache'] = 'foo'
    df['searched_paths'] = 'foo'
    test_obj_0 = PluginLoader('foo', 'foo', None, False, False, False)
    if test_obj_0: test_obj_0.__setstate__(df)



# Generated at 2022-06-25 10:15:14.357873
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # test case for unkown name plugin
    var_0 = PluginLoader('', '')
    var_1 = var_0.get_with_context('aa')
    assert (var_1.object is None)
    # test case for known name plugin
    var_2 = var_0.get_with_context('shell')
    assert (var_2.object is not None)


# Generated at 2022-06-25 10:15:15.602072
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    var_0 = PluginLoadContext()
    var_1 = var_0.record_deprecation()


# Generated at 2022-06-25 10:15:16.997364
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():

    var_0 = PluginLoader()
    var_1 = var_0.all()


# Generated at 2022-06-25 10:15:23.882703
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    # Create an instance of PluginLoader
    #for func_name, code in code_PluginLoader.items():
    #    exec(code)

    # set state
    var_0 = get_shell_plugin()

    # set state
    var_1 = None

    # Call method __setstate__ on instance var_0
    var_0.__setstate__(var_1)

    # Test succesful return of method __setstate__
    print('Test successful return of method __setstate__ for class PluginLoader')


# Generated at 2022-06-25 10:15:28.338545
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    var_0 = ['test/test_plugins/test_callback/notify', 'test/test_plugins/test_callback/test_callback_plugins']
    try:
        add_dirs_to_loader('callback', var_0)
    except Exception as e:
        if e.__class__.__name__ == "AttributeError":
            print("add_dirs_to_loader(): test case 1 failed")
        else:
            print("add_dirs_to_loader(): test case 1 failed")
    else:
        print("worked")

# Unit tests for function get_shell_plugin
# test case 1 : shell_type = 'sh'

# Generated at 2022-06-25 10:15:49.973253
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_0 = []
    var_1 = PluginLoader().all(var_0, var_0)


# Generated at 2022-06-25 10:15:51.524445
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    obj = PluginLoader('shell', package = 'ansible.shell_plugins')
    obj.find_plugin_with_context('shell')


# Generated at 2022-06-25 10:15:56.207438
# Unit test for method find_plugin of class Jinja2Loader

# Generated at 2022-06-25 10:16:05.839193
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test setup
    plugin_loader = PluginLoader()

    args = []
    kwargs = {}
    kwargs['_dedupe'] = True
    kwargs['path_only'] = False
    kwargs['class_only'] = False
    # Execute the method
    result = plugin_loader.all(**kwargs)
    # Verify that the result set is correct
    assert(result is not None)
    # Teardown


    # Test setup
    plugin_loader = PluginLoader()

    args = []
    kwargs = {}
    kwargs['_dedupe'] = True
    kwargs['path_only'] = False
    kwargs['class_only'] = False
    # Execute the method
    result = plugin_loader.all(**kwargs)
    # Verify that the result set

# Generated at 2022-06-25 10:16:11.807582
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    arg_0 = "/tmp/test_add_all_plugin_dirs"
    try:
        os.mkdir(arg_0)
    except OSError:
        pass
    add_all_plugin_dirs(arg_0)
    assert os.path.exists(arg_0)
    os.rmdir(arg_0)
    assert not os.path.exists(arg_0)



# Generated at 2022-06-25 10:16:19.334870
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Can be tested fully by running ansible-test sanity --test plugin_loader and ansible-test units -t test/units/module_utils/test_plugin_loader.py

    # Test with a regular directory
    test_dir = '/tmp/test_plugin_loader/test_add_all_plugin_dirs/'
    os.makedirs(test_dir)
    plugin_dir = test_dir + 'plugins'
    os.makedirs(plugin_dir)

    for loader in get_all_plugin_loaders():
        loader.clear_directory_cache()

    add_all_plugin_dirs(test_dir)

    for loader in get_all_plugin_loaders():
        assert not loader.has_directory(), 'The loader found a directory even though we did not add one.'

    add_all_plugin_dir

# Generated at 2022-06-25 10:16:20.900921
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    var_0 = get_lookup_plugin()
    var_0.__contains__("demo_lookup_plugin")


# Generated at 2022-06-25 10:16:26.071551
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():

    # save current plugin search path
    saved_plugin_path = get_shell_plugin().get_directory_list()

    # Add a directory
    add_all_plugin_dirs('/tmp/ansible_test')

    # Empty directory should not be added
    test_plugin_path = get_shell_plugin().get_directory_list()
    assert test_plugin_path == saved_plugin_path

    # Create an empty directory
    os.mkdir('/tmp/ansible_test')

    # Empty directory should not be added
    test_plugin_path = get_shell_plugin().get_directory_list()
    assert test_plugin_path == saved_plugin_path

    # Create a subdirectory with a shell action plugin
    os.mkdir('/tmp/ansible_test/shell_action')

# Generated at 2022-06-25 10:16:30.737858
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    '''
    Returns:
        bool: True if test passes, else False
    '''
    try:
        var_0 = PluginLoader(str(), str())
        var_1 = var_0.find_plugin(str())
    except:
        print("Error: PluginLoader.find_plugin() threw exception")
        return False
    return True


# Generated at 2022-06-25 10:16:42.142895
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    pl = PluginLoader(package='ansible.plugins.action', class_name='ActionBase', config_options=['STRING'])
    pl.find_plugin('shell')
    module = pl._load_module_source('ansible.plugins.action.shell', '/ansible/lib/ansible/plugins/action/shell.py')
    assert os.path.exists('/ansible/lib/ansible/plugins/action/shell.py'), 'The specified path does not exist'
    assert os.path.isfile('/ansible/lib/ansible/plugins/action/shell.py'), 'The specified path is not a file'
    assert os.access('/ansible/lib/ansible/plugins/action/shell.py', os.R_OK), 'The specified file is not readable'

# Generated at 2022-06-25 10:17:10.699419
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # var_0 contains arguments for method get of class Jinja2Loader
    var_0 = {
        'collection_list': None,
        'class_only': False,
        'name': '',
        'path_only': False
    }
    var_1 = Jinja2Loader('ansible.plugins.shell', 'ShellModule', ['.ansible/test/shell_plugins'], C.DEFAULT_DEBUG)
    # var_2 contains the type of the object returned by the method get
    # of the class Jinja2Loader
    var_2 = type(var_1.get(**var_0))
    assert var_2 == object


# Generated at 2022-06-25 10:17:12.577089
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # Test basic function
    # TODO: implement test for method Jinja2Loader_find_plugin in class Jinja2Loader
    pass


# Generated at 2022-06-25 10:17:19.379374
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    test_case_0()

# Loader for 'shell_plugins/powershell' plugin, name: 'Script'
#
# This is not a test of a method, but rather for the class of the same name.
#
# This class provides a loader for python modules, which is requested to load a shell plugin
# by name.  It is used by Ansible to load shell plugins, which are used by the module runners
# when executing shell commands.
#
# The default path list is ``./<plugin_dir>``, so if a loader is initialized with a plugin_dir of
# ``shell_plugins`` and the current working directory is ``/home/me/ansible``, then it will
# look for plugins in ``/home/me/ansible/shell_plugins``.
#

# Generated at 2022-06-25 10:17:20.796974
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    obj = Jinja2Loader()
    obj.__init__()
    obj.get('frob')


# Generated at 2022-06-25 10:17:22.443244
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    var_0 = get_shell_plugin()
    assert var_0 == 'sh', "assertion error"


# Generated at 2022-06-25 10:17:24.696221
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    plugins = callback_loader.all()
    assert len(plugins) > 0, "Expected number of plugins to be greater than 0"


# Generated at 2022-06-25 10:17:34.636083
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    from ansible.module_utils.common.collections import Mapping
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.utils.display import Display
    display = Display()
    var_1 = PluginLoadContext()
    var_2 = dict(zip(['warning_text', 'removal_date', 'removal_version'], [to_text(u'', errors='surrogate_or_strict'), to_text(u'', errors='surrogate_or_strict'), to_text(u'', errors='surrogate_or_strict')]))
    var_3 = to_text(u'', errors='surrogate_or_strict')
    var_1

# Generated at 2022-06-25 10:17:37.869424
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    var_0 = Jinja2Loader('', '', '', '', '', '',)
    var_1 = True
    var_2 = {}
    var_0.all(var_1, var_2,)


# Generated at 2022-06-25 10:17:44.157665
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # FIXME: this test should be refactored
    # FIXME: use a mock context, right now the test will break in an odd execution order
    # FIXME: this test is not complete and needs to have actual tests written
    var_0 = PluginLoader(name='shell', package='ansible.plugins.shells', configurable=True, directories=[])
    # mock_context = MagicMock()
    # with patch('ansible.plugins.loader.AnsibleLoader.find_collection_plugins', mock_context) as result:
    #     var_0.find_plugin_with_context(name='sh', plugin_load_context=mock_context)
    #     result.assert_called_with()


# Generated at 2022-06-25 10:17:53.894173
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    global _PLUGIN_FILTERS

# Generated at 2022-06-25 10:18:30.221602
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    var_0 = PluginLoader()
    var_1 = 'test'
    var_2 = var_0.find_plugin_with_context(var_1)
    assert isinstance(var_2, PluginLoadContext)


# Generated at 2022-06-25 10:18:32.346456
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # Check if exception is thrown if we try to load a non-existent plugin
    pass


# Generated at 2022-06-25 10:18:40.008614
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    var_0 = {'removal_date': None, 'warning_text': '', 'removal_version': None}
    var_1 = 'removal_version'
    var_2 = 'Removal date'
    var_3 = get_shell_plugin('sh')
    var_3.record_deprecation({},{})
    var_3.record_deprecation({},{'warning_text': 'should'})
    var_3.record_deprecation({},{'warning_text': 'should'}, collection_name='ns.col')
    var_3.record_deprecation({},{'warning_text': 'should', 'removal_version': '2.10'})

# Generated at 2022-06-25 10:18:42.217104
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    var_0 = PluginLoader('action_plugin')
    var_1 = var_0.find( 'ping')
    var_2 = get_plugin_class('ping')
    assert var_1 == var_2


# Generated at 2022-06-25 10:18:43.255856
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    var_0 = get_shell_plugin()


# Generated at 2022-06-25 10:18:47.708664
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    # Arrange
    deprecation_1 = {
        'warning_text': 'warning text',
        'removal_date': 'removal date',
        'removal_version': 'removal version'
    }
    deprecation_2 = {
        'warning_text': 'warning text',
        'removal_date': None
    }
    deprecation_3 = {
        'warning_text': 'warning text',
        'removal_date': None,
        'removal_version': 'removal version'
    }

    # Act
    loadcontext = PluginLoadContext()
    loadcontext.record_deprecation('test object', deprecation_1, None)
    loadcontext.record_deprecation('test object', deprecation_2, None)

# Generated at 2022-06-25 10:18:49.238847
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    pass


# Generated at 2022-06-25 10:18:58.334780
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    var_0 = PluginLoadContext()
    var_1 = {'warning_text': 'The REJECTED_EXCEPTION constant is deprecated.', 'removal_date': '', 'removal_version': ''}
    var_0.record_deprecation('REJECTED_EXCEPTION', var_1, '')
    var_0.deprecated
    var_2 = {'warning_text': 'The REJECTED_EXCEPTION constant is deprecated.', 'removal_date': '', 'removal_version': ''}
    var_0.record_deprecation('REJECTED_EXCEPTION', var_2, '')
    var_0.deprecated

# Generated at 2022-06-25 10:19:00.187350
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    var_0 = get_connection_plugin()
    var_1 = get_shell_plugin()
    var_2 = get_cliconf_plugin()
    var_3 = get_network_plugin()


# Generated at 2022-06-25 10:19:07.902416
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    print("")
    loader = PluginLoader()
    path = "random_path"
    found_in_cache = True
    class_only = True
    loader._display_plugin_load("something", "plugin", ["plugin_paths"], path, found_in_cache, class_only)

    print("Unit test for PluginLoader all method\n")

    print("Calling all() with a class_only argument\n")
    loader = PluginLoader("ansible.plugins.action.vars")
    for plugin in loader.all(class_only=True):
        print("Plugin class: " + str(plugin))

    print("\nCalling all() with a path_only argument\n")
    loader = PluginLoader("ansible.plugins.action.vars")

# Generated at 2022-06-25 10:20:08.776283
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # test 1:
    #
    # Path provided is a valid directory
    #
    # Expected result:
    #
    # Valid directories added to paths
    plugin_paths = os.path.join(os.getcwd(), 'tmp/plugins')
    valid_plugin_paths = ['filter_plugins', 'lookup_plugins', 'vars_plugins', 'action_plugins', 'connection_plugins',
                          'inventory_plugins', 'callback_plugins', 'modules']

# Generated at 2022-06-25 10:20:11.554850
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():

    assert False  # TODO: update this test case

    # Arrange
    var_0 = get_shell_plugin()
    var_0 = get_cache_plugin()

    # Act & Assert
    # assert var_0.get_with_context(name, *args, **kwargs) == expected
    assert False

# Generated at 2022-06-25 10:20:12.150546
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert 0 == test_case_0()



# Generated at 2022-06-25 10:20:15.887836
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    loader = Jinja2Loader()
    # Init of default class level variables
    assert loader.package == 'ansible.plugins.j2_filters'
    assert loader.subdir == 'filter_plugins'
    assert loader.base_class == 'FilterModule'
    assert loader.class_name == 'FilterModule'
    assert loader.plugins == []
    assert loader.plugin_paths == PLUGIN_PATH_CACHE['filter_plugins']
    assert isinstance(loader.plugin_paths, set)
    assert loader._searched_paths == []
    assert isinstance(loader._searched_paths, list)
    assert loader._module_cache == {}
    assert isinstance(loader._module_cache, dict)


# Generated at 2022-06-25 10:20:26.173619
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Ensure that PluginLoader.find_plugin_with_context correctly searches and finds a plugin
    # that exists in a collection and a builtin
    plugin_load_context = PluginLoader('shell', 'ActionModule').find_plugin_with_context('my-shell-plugin')
    assert plugin_load_context.plugin_resolved_fqcr == 'my_namespace.my_collection.shell.my_shell_plugin'
    assert os.path.normcase(os.path.normpath(plugin_load_context.plugin_resolved_path)).endswith(os.path.normcase(os.path.normpath(plugin_load_context.plugin_resolved_path)))
    # Ensure that the plugin can be found when explicitly requesting the collection's namespace
    plugin_load_context = PluginLoader('shell', 'ActionModule').find_plugin_with

# Generated at 2022-06-25 10:20:27.634308
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    var_0 = PluginLoader.find_plugin_with_context('lookup')
    assert var_0

# Generated at 2022-06-25 10:20:28.876850
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_0 = get_cache_plugin()


# Generated at 2022-06-25 10:20:36.700030
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    var_1 = 'ansible.plugins.shell'
    var_2 = 'osx'
    var_3 = PluginLoader(var_1, 'ActionModule', C.DEFAULT_MODULE_PATH)
    var_4 = var_3.find_plugin(var_2)
    var_5 = '/Users/jlarue/Dev/ansible/lib/ansible/plugins/shell/osx.py'
    var_6 = os.path.basename(var_4)
    var_7 = os.path.basename(var_5)
    if var_6 == var_7:
        return True
    else:
        raise Exception('Test failed: %s != %s' % (var_6, var_7))


# Generated at 2022-06-25 10:20:42.059537
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    var_1 = Jinja2Loader(
        class_name = 'Jinja2FilterModule',
        package = 'ansible.legacy.plugins.filter',
        )
    var_2 = var_1.get('to_yaml', ())
    assert var_2.__name__ == 'to_yaml'
    var_3 = var_1.get('to_yaml', ())
    assert var_3 == var_2



# Generated at 2022-06-25 10:20:43.892408
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Call function find_plugin with the appropriate args
    var_0 = get_shell_plugin()
    assert var_0 is not None
