

# Generated at 2022-06-25 10:13:48.108110
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    plugin_loader = PluginLoader(base_class=C.CACHE_BASE_CLASS, class_name=None, package='ansible.plugins.cache')
    plugin_loader.find_plugin('memory')


# Generated at 2022-06-25 10:13:56.438986
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Init instance of class PluginLoader
    PLUGIN_MODULES = "vars"
    PLUGIN_BASE_CLASSES = "vars1"
    LOADER_NAME = "vars2"
    PLUGIN_DIRECTORIES = "vars3"
    # Loader name 'vars2' is not correct.
    PLUGIN_CACHE_DIR = "vars4"
    _PLUGIN_PATH_CACHE = "vars5"
    instance = PluginLoader(PLUGIN_MODULES, PLUGIN_BASE_CLASSES, LOADER_NAME, PLUGIN_DIRECTORIES, PLUGIN_CACHE_DIR, _PLUGIN_PATH_CACHE)
    # Try to load plugin 'vars' without defining collection_list
    # Parameters

# Generated at 2022-06-25 10:14:03.377464
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    var_0 = get_shell_plugin()
    var_0.find_plugin_with_context('/home/pipeline/workspace/ansible/test/units/test_utils.py', 'ansible.plugins.action.copy')
    assert True


# Generated at 2022-06-25 10:14:04.723577
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    result = add_all_plugin_dirs('test_path')
    assert result == None


# Generated at 2022-06-25 10:14:12.236793
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    var_3 = PluginLoader('action_plugin', 'ansible.plugins.action', os.path.join(os.path.dirname(__file__), 'action_plugins'), 'ActionModule')
    var_9 = 'test_plugin.test_name'
    var_10 = 'py'
    # print(var_3.find_plugin_with_context(var_9, var_10))



# Generated at 2022-06-25 10:14:17.393873
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    global jinja2_loader
    # No collection passed
    jinja2_loader.get('test')

# Generated at 2022-06-25 10:14:18.531511
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    var_0 = PluginLoader()


# Generated at 2022-06-25 10:14:22.955575
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    var_1 = PluginLoader('module_utils', 'ModuleUtilsLoader', os.path.join('module_utils', 'basic.py'), 'Basic', C.MODULE_UTILS_PATH)
    var_2 = var_1.__contains__('basic')


# Generated at 2022-06-25 10:14:30.383007
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    obj = PluginLoadContext()
    deprecation = {'warning_text': 'foo', 'removal_date': '2020-01-01', 'removal_version': '2.10'}
    obj.record_deprecation('a', deprecation, 'collection')
    assert obj.deprecation_warnings == ['a has been deprecated. foo']
    assert obj.removal_date == '2020-01-01'
    assert obj.removal_version == '2.10'

test_case_0()


# Generated at 2022-06-25 10:14:35.804974
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    var_0 = PluginLoadContext()
    var_1 = {'removal_version': '2.9', 'warning_text': None}
    var_2 = 'test_val_2'
    var_3 = var_0.record_deprecation(var_2, var_1, 'test_val_3')
    assert var_0.deprecation_warnings == [] == var_3.deprecation_warnings
    assert var_0.deprecated == var_3.deprecated == False
    assert var_0.exit_reason == var_3.exit_reason == None
    assert var_0.removal_date == var_3.removal_date == None
    assert var_0.removal_version == var_3.removal_version == None
    assert var_0.plugin_resolved_collection

# Generated at 2022-06-25 10:15:03.303899
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    """Test function add_dirs_to_loader."""
    which_loader = 'action'
    paths = ('/Users/rocky/dev/hey-ansible/test/lookup_loader.py')

    loader = getattr(sys.modules[__name__], '%s_loader' % which_loader)
    for path in paths:
        loader.add_directory(path, with_subdir=True)



# Generated at 2022-06-25 10:15:08.470393
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():

    import tempfile


# Generated at 2022-06-25 10:15:10.005551
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    assert 1


# Generated at 2022-06-25 10:15:11.782684
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    var_0 = get_shell_plugin()
    var_1 = var_0.find_plugin('localhost')


# Generated at 2022-06-25 10:15:13.070622
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    local_var_0 = get_shell_plugin()


# Generated at 2022-06-25 10:15:17.270990
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    p = PluginLoader()
    assert p.find_plugin('copy')
    assert p.find_plugin('shell')
    assert p.find_plugin('ping')
    assert p.find_plugin('inventory_hr_tcp_allports')
    assert p.find_plugin('connection_local')
    assert p.find_plugin('file_stat')
    assert p.find_plugin('cache_dummy')
    assert p.find_plugin('test_ping')


# Generated at 2022-06-25 10:15:17.722502
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    assert True


# Generated at 2022-06-25 10:15:25.640818
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    var_0 = AnsibleShellModule.__name__
    var_1 = AnsibleShellModule.action_write
    var_2 = not AnsibleShellModule()
    var_3 = AnsibleShellModule
    var_4 = PluginLoader.__name__
    var_5 = PluginLoader.all
    attributes = [var_0, var_1, var_2, var_3, var_4, var_5, ]
    PluginLoader._has_plugin("test", attributes) == None
    var_6 = AnsibleShellModule.__name__
    var_7 = AnsibleShellModule.action_write
    var_8 = not AnsibleShellModule()
    var_9 = AnsibleShellModule
    var_10 = PluginLoader.__name__
    var_11 = PluginLoader.get

# Generated at 2022-06-25 10:15:29.658511
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    """Test PluginLoader.get_with_context"""
    var_0 = get_shell_plugin()
    var_1 = var_0.get_loader_with_context(None)
    var_2 = var_1.get_with_context('shell')


# Generated at 2022-06-25 10:15:32.451463
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    plugin_loader_0 = PluginLoader(package='ansible.plugins.action', config=None, subdir=None, class_name=None)
    plugin_loader_0.all()


# Generated at 2022-06-25 10:16:06.303887
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    path = '/etc/ansible'
    ret_va = add_all_plugin_dirs(path)





# Generated at 2022-06-25 10:16:08.678126
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    var_0 = module_cache
    add_all_plugin_dirs(var_0)


# Generated at 2022-06-25 10:16:15.839307
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_1 = PluginLoader('var_2', 'var_3', 'var_4')
    var_5 = var_1.all()
    var_6 = var_1.all(var_7='var_8')
    var_9 = var_1.all(var_10='var_11', var_12='var_13')
    var_14 = var_1.all(var_7='var_8', var_15=True)
    var_16 = var_1.all(var_17=True)
    var_18 = var_1.all(var_17=True, var_10='var_11', var_12='var_13')


# Generated at 2022-06-25 10:16:16.596946
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    test_case_0()



# Generated at 2022-06-25 10:16:23.663741
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    tmp = constants.DEFAULT_MODULE_PATH
    constants.DEFAULT_MODULE_PATH = C.config.get_config_value('DEFAULT_MODULE_PATH')
    # test
    test_module_paths = [
        '/usr/share/ansible/plugins/modules',
        '/usr/share/ansible/plugins/filter'
    ]
    add_dirs_to_loader(which_loader='filter', paths=test_module_paths)
    add_dirs_to_loader(which_loader='module', paths=test_module_paths)
    # restore
    constants.DEFAULT_MODULE_PATH = tmp



# Generated at 2022-06-25 10:16:33.298488
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    print('Testing PluginLoader.find_plugin_with_context')

    for loader in get_all_plugin_loaders():
        # Check that the plugin loader is a PluginLoader instance
        assert isinstance(loader, PluginLoader)

        # Check that collection_list is handled properly
        collection_list = ['ansible_collections.community.general', 'ansible_collections.community.general']
        test_name = 'copy'

# Generated at 2022-06-25 10:16:38.169785
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # param 0 is instance
    # param 1 is dirs
    paths = [
        '',
        'a',
        'b'
    ]
    loader = getattr(sys.modules[__name__], '%s_loader' % 'module')
    for path in paths:
        loader.add_directory(path, with_subdir=True)


# Generated at 2022-06-25 10:16:41.905815
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    assert add_all_plugin_dirs("./test") == None
    assert add_all_plugin_dirs("./test1") == None



# Generated at 2022-06-25 10:16:47.181316
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # Default case
    assert get_all_plugin_loaders() == []
    add_dirs_to_loader('shell', ['/tmp'])
    assert get_all_plugin_loaders() == []
    add_dirs_to_loader('shell', ['/tmp'])

# Generated at 2022-06-25 10:16:58.472215
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    var_0 = BL_ARGS(name='arg_0', required=True)
    var_1 = BL_ARGS(name='arg_1', required=True)
    var_2 = BL_ARGS(name='arg_2')
    var_3 = BL_ARGS(name='arg_3')
    var_4 = BL_ARGS(name='arg_4')
    var_5 = BL_ARGS(name='arg_5')

    # Test 1
    var_0.name = 'get_0'
    var_1.name = 'get_1'
    var_2.name = 'get_2'
    var_3.name = 'get_3'
    var_4.name = 'get_4'
    var_5.name = 'get_5'
    var_6 = Jin

# Generated at 2022-06-25 10:18:16.528228
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    var_0 = PluginLoader(package='ansible.plugins.action', search_path_env='ANSIBLE_ACTION_PLUGINS', subdir='action')
    var_1 = 'file'
    var_2 = 'win_tempfile'
    var_3 = var_0.find_plugin_with_context(var_1)
    assert var_3.resolved == True
    assert var_3.plugin_resolved_name == var_1
    assert var_3.plugin_resolved_path.endswith('/ansible_collections/ansible/builtin/plugins/action/file.py')
    var_4 = var_0.find_plugin_with_context(var_2)
    assert var_4.resolved == True
    assert var_4.plugin_resolved_name == var_2
   

# Generated at 2022-06-25 10:18:18.964187
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    var_4 = PluginLoader ( var_3, var_0, var_2 )
    var_6 = var_4.find_plugin ( var_5, var_1 )
    assert var_6 == var_7


# Generated at 2022-06-25 10:18:28.582330
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    var_0 = PluginLoader(
        'ActionModule',
        'ansible.plugins.action',
        'ActionBase',
        'action_plugins'
    )
    arg_0 = 'service'
    arg_1 = 'systemd'
    arg_2 = C.DEFAULT_SUDO_USER
    arg_3 = C.DEFAULT_SUDO_PASS
    arg_4 = 10
    arg_5 = False
    arg_6 = {}
    arg_7 = {}
    arg_8 = False
    arg_9 = [
        'log_path',
        'remote_tmp',
        'remote_uid'
    ]
    arg_10 = '/usr/lib/python2.7/site-packages/ansible/plugins/action'

# Generated at 2022-06-25 10:18:30.589962
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    obj_0 = PluginLoader()
    test_case_0()

    assert not obj_0.all()


# Description of test case

# Generated at 2022-06-25 10:18:33.328571
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # create an instance of Class Under Test
    cut = PluginLoader('cut')

    result = cut.find_plugin_with_context('abc')
    assert result.resolved is False


# Generated at 2022-06-25 10:18:37.053062
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    import ansible.plugins.loader
    plugin_loader_0 = ansible.plugins.loader.PluginLoader('callbacks', 'ActionModule', 'ansible.plugins.action')
    with pytest.raises(AnsibleError):
        plugin_loader_0.all(path_only=True, class_only=True)


# Generated at 2022-06-25 10:18:40.170025
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    var_0 = PluginLoader('test_var_0', subdir=None, package='test_var_0', run_once=True)
    var_1 = var_0.find_plugin_with_context('test_var_1', collection_list='test_var_2')


# Generated at 2022-06-25 10:18:40.926611
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    var_0 = PluginLoader()



# Generated at 2022-06-25 10:18:41.911416
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    #Test the PluginLoader.all() method
    pass


# Generated at 2022-06-25 10:18:42.974015
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    plugin_loader = PluginLoader('foo', 'bar', 'baz')


# Generated at 2022-06-25 10:19:54.552896
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    import collections
    import os
    var_0 = PluginLoader('ansible.plugins.cache', 'CacheModule', '_load_name', 'cache')
    var_1 = collections.namedtuple('PluginLoadContext', ['plugin', 'plugin_load_name', 'plugin_resolved_name', 'plugin_resolved_path', 'resolved', 'nope', 'redirect_list'])


# Generated at 2022-06-25 10:19:58.336444
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_0 = PluginLoader("", "", "")
    var_1 = var_0.all()
    var_2 = PluginLoader("", "", "", 1)
    var_3 = var_2.all()
    print('%s, %s' % (var_1, var_3))


# Generated at 2022-06-25 10:20:06.568690
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    var_0 = get_all_plugin_loaders()
    path_sep = os.path.sep
    var_1 = os.pathsep
    var_2 = os.name
    var_3 = os.sep
    var_4 = os.linesep
    var_5 = os.pathsep
    var_6 = os.curdir
    var_7 = os.pardir
    var_8 = os.getcwd()
    var_9 = os.fspath(var_8)
    var_10 = os.sep
    var_11 = os.pathsep
    var_12 = os.linesep
    var_13 = os.path.abspath('.')
    var_14 = os.getcwd()
    var_15 = os.path.abspath

# Generated at 2022-06-25 10:20:09.376797
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    display.info('Test: test_PluginLoader_add_directory')
    var_1 = PluginLoader('', 'Ignore')
    with pytest.raises(AttributeError): var_1.loaders
    var_1.add_directory('/path/to/plugins')
    with pytest.raises(AttributeError): var_1.loaders
    assert var_1._directory_mapping



# Generated at 2022-06-25 10:20:14.065603
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    var_0 = PluginLoader("module_utils", "module_utils")
    var_1 = var_0.find_plugin("failure")
    var_2 = var_0.find_plugin("failure")
    var_3 = var_0.find_plugin("failure")
    var_4 = var_0.find_plugin("failure")
    var_5 = var_0.find_plugin("failure")


# Generated at 2022-06-25 10:20:17.338856
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():

    # FIXME: Kind of a silly test, it doesn't really test anything

    var_0 = PluginLoader('action_plugin', 'ActionsModule')
    var_1 = var_0.find_plugin('ping')
    var_2 = var_0.find_plugin('ping')
    var_3 = var_0.find_plugin('ping')
    assert var_1 is None
    assert var_2 is None
    assert var_3 is None


# Generated at 2022-06-25 10:20:20.395922
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    fixture_0 = PluginLoader()
    plugin_name = 'name'
    var_0 = fixture_0.__contains__(plugin_name)


# Generated at 2022-06-25 10:20:22.300766
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    result = PluginLoader('').find_plugin()
    assert result is None


# Generated at 2022-06-25 10:20:31.847961
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    from ansible.errors import AnsibleError
    from ansible.errors import AnsibleOptionsError
    from ansible.module_utils.six import string_types
    from ansible.utils.collection_loader import _SuffixSelector
    from ansible.plugins.loader import _CachingPluginLoader
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.loader import discover_entry_points
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_filter_plugins
    from ansible.plugins.loader import get_module_loader
    from ansible.plugins.loader import get_plugin_loaders
    from ansible.plugins.loader import get_test_plugins
    from ansible.plugins.loader import init_plugin_loader_path

# Generated at 2022-06-25 10:20:34.471418
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    add_all_plugin_dirs('path')
    add_all_plugin_dirs('/home/admin')
    add_all_plugin_dirs('/home/admin/abc')
