

# Generated at 2022-06-25 10:13:17.231480
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    '''
    Unit test for method find_plugin of class PluginLoader
    '''
    plugin_loader = PluginLoader(class_name = 'Connection', package = 'ansible.plugins.connection')


# Generated at 2022-06-25 10:13:23.623241
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    deprecation = {'warning_text': "The 'shell' plugin has been deprecated in Ansible 2.5. Use 'command' or 'win_shell' instead.", 'removal_version': '2.9', 'removal_date': None}
    plc = PluginLoadContext()
    plc = plc.record_deprecation("shell", deprecation, "")


# Generated at 2022-06-25 10:13:31.622273
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    from os.path import join
    from imp import load_source
    from ansible.plugins import module_loader, filter_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display

    display = Display()
    module_loader.add_directory(join('test', 'test_utils', 'test_collection_loader', 'test_add_all_plugin_dirs_plugins'))
    assert set(module_loader.all()) == set(['test_add_all_plugin_dirs_plugins.test_file', 'test_add_all_plugin_dirs_plugins.test_module', 'test_add_all_plugin_dirs_plugins.test_fail'])

# Generated at 2022-06-25 10:13:33.456332
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    str_0 = "')~Y/"
    str_1 = "$)"
    var_1 = add_all_plugin_dirs(str_0)



# Generated at 2022-06-25 10:13:37.585945
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    obj_0 = find_plugin_loaders(Mock(), Mock(), Mock(), Mock(), Mock(), Mock(), Mock(), Mock(), Mock())


# Generated at 2022-06-25 10:13:46.864348
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    str_0 = "ngUIq'"
    str_1 = "&J gM"
    str_2 = "J!F)c"
    str_3 = "2n+U@"
    str_4 = "4k$HE"
    str_5 = "j)ZT6"
    str_6 = "hgj6T"
    lst_0 = [str_2, str_3, str_4, str_5, str_6]
    lst_1 = [str_5, str_6]
    lst_2 = [str_5]


# Generated at 2022-06-25 10:13:48.906193
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    str_0 = "i!x"
    var_0 = Jinja2Loader(str_0)
    var_1 = var_0.all()



# Generated at 2022-06-25 10:13:56.807767
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():

    # Mock out any external dependencies that would normally cause a test to fail
    import glob
    with mock.patch.object(glob, 'glob', return_value=['test.py'], create=True):

        # This is not a real plugin, so will be found only in the builtin path
        arg_0 = 'test'
        arg_1 = None
        arg_2 = 'fake_type'
        obj_0 = PluginLoader(arg_2, 'ansible.plugins.fake_type')
        try:
            var_0 = obj_0.find_plugin(arg_0, arg_1)
        except AttributeError as err:
            # The error message differs across Python versions
            assert str(err).startswith("'NoneType' object has no attribute")


# Generated at 2022-06-25 10:14:02.736198
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Set Config
    config = {}
    config['ANSIBLE_LIBRARY'] = "~/.ansible/plugins/modules"

    # Test Cases
    add_all_plugin_dirs(config)



# Generated at 2022-06-25 10:14:13.965100
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    str_0 = "')~Y/"
    var_0 = get_all_plugin_loaders()
    var_3 = var_0[0].__setstate__()
    var_4 = var_0[1].__setstate__()
    var_5 = var_0[2].__setstate__()
    var_6 = var_0[3].__setstate__()
    var_7 = var_0[4].__setstate__()
    var_8 = var_0[5].__setstate__()
    var_9 = var_0[6].__setstate__()
    var_10 = var_0[7].__setstate__()
    var_11 = var_0[8].__setstate__()
    var_12 = var_0[9].__setstate__()
    var_

# Generated at 2022-06-25 10:16:00.444173
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    test_dir = os.path.dirname(__file__)
    try:
        var_0 = PluginLoader('', '', '', '', '', '', '', '')
    except Exception as e:
        display.display(test_dir)
        display.display(str(e))
        assert False


# Generated at 2022-06-25 10:16:02.004616
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    print('Test of function get_shell_plugin()')
    test_case_0()

# Unit test

# Generated at 2022-06-25 10:16:04.362150
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    var_0 = Jinja2Loader(paths=[]).get(name='foo')
    assert var_0 is None


# Generated at 2022-06-25 10:16:09.476262
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    var_1 = (
        'ansible.plugins.connection',
        ['__empty_dir__'],
    )
    var_2 = 'connection'
    add_dirs_to_loader(var_2, var_1[1])
    assert var_1[0] == 'ansible.plugins.connection'


# Generated at 2022-06-25 10:16:16.243074
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    """
    Unit test for method find_plugin_with_context of class PluginLoader.
    """
    try:
        print("Unit test for method 'find_plugin_with_context' begins.")
        var_0 = test_case_0()
    except Exception as e:
        print("Error occured in Unit test for method 'find_plugin_with_context' : %s" %(e))
        return False
    else:
        print("Unit test for method 'find_plugin_with_context' completed.")
        return True

if __name__ == '__main__':
    test_PluginLoader_find_plugin_with_context()

# Generated at 2022-06-25 10:16:18.868958
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    for key_0 in [0]:
        if key_0 == 0:
            var_0 = AnsibleCollectionRef.is_valid_fqcr('/home/felipe/repos/ansible/development/playbooks')
            print(var_0)



# Generated at 2022-06-25 10:16:20.761923
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    var_4 = ['playbook']
    for var_5 in var_4:
        add_dirs_to_loader(var_5, [var_5])


# Generated at 2022-06-25 10:16:22.010777
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    plugin_path = '/usr/local/ansible/plugins'
    add_all_plugin_dirs(plugin_path)


# Generated at 2022-06-25 10:16:24.435030
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Make sure to load each test case in a separate process to
    # avoid problems with state that could be shared between test
    # cases.
    with create_process_for_test(test_case_0) as process:
        process.run()
        process.assert_output([''])


# Generated at 2022-06-25 10:16:33.972047
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    '''
    Unit test for method find_plugin of class PluginLoader
    '''
    var_0 = PluginLoader.find_plugin('shell')
    var_1 = PluginLoader.find_plugin('shell', collection_list=('ansible_collections.ansible.builtin',))
    var_2 = PluginLoader.find_plugin('shell', collection_list=('ansible_collections.test.test_collections.common_collections.test_fixtures.plugins',))
    var_3 = PluginLoader.find_plugin('shell', collection_list=('ansible_collections.test.test_collections.common_collections.test_fixtures.plugins', 'ansible_collections.ansible.builtin'))

# Generated at 2022-06-25 10:16:56.802220
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # N/A
    pass


# Generated at 2022-06-25 10:17:00.851189
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    var_0 = PluginLoader(var_package='ansible.plugins.connection', var_class_name='ConnectionBase', var_aliases={}, var_required_base_class='ConnectionBase', var_configurable=True, var_relative_to=None, var_package_errors=None)
    var_0.find_plugin_with_context(var_name='mechanism', var_collection_list=None)


# Generated at 2022-06-25 10:17:09.813069
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    
    # FIXME: a mock object should be used in tests
    p = PluginLoader('action_plugin')
    
    # Test the plugin type is not supported
    name = 'copy'
    with pytest.raises(ValueError) as error:
        plugin_type = 'invalid'
        p.find_plugin_with_context(name, plugin_type)
    assert error.match("'invalid' is an unsupported plugin type for find_plugin_with_context")

    # Test the plugin name is not found
    name = 'not_found'
    with pytest.raises(AnsibleError) as error:
        plugin_type = 'action'
        p.find_plugin_with_context(name, plugin_type)
    assert error.match("module/plugin not found in configured module paths")
    
    # Test

# Generated at 2022-06-25 10:17:15.145325
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():

    PLUGIN_PATH = u'/Volumes/HDD/Users/yoyo/Library/Preferences/PyCharm2018.2/scratches/scratch.py'
    PLUGIN_NAME = u'scratch'
    plugin_loader = PluginLoader(u'ansible.plugins.action', u'ActionModule')
    plugin_name = plugin_loader.find_plugin(PLUGIN_NAME)
    assert PLUGIN_PATH == plugin_name


# Generated at 2022-06-25 10:17:21.858993
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test case for when the plugin is already loaded
    already_loaded_plugin = PluginLoader.find_plugin_with_context('shell')
    assert already_loaded_plugin.resolved

    # Test case for when the plugin is not loaded
    not_loaded_plugin = PluginLoader.find_plugin_with_context('copy')
    assert not_loaded_plugin.resolved

    # Test cases for invalid plugin names
    invalid_plugin_1 = PluginLoader.find_plugin_with_context('z6UZD.tsmV0.YEJ9d')
    assert not invalid_plugin_1.resolved

    invalid_plugin_2 = PluginLoader.find_plugin_with_context('ansible.module_utils.z6UZD.tsmV0.YEJ9d')
    assert not invalid_plugin_2.resolved

   

# Generated at 2022-06-25 10:17:23.275026
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    test_case_0()


# Generated at 2022-06-25 10:17:27.790149
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    var_0 = Jinja2Loader(base_class=None, package='ansible.plugins.filter.core')
    var_1 = var_0.find_plugin('ansible.plugins.filter.core.json_query')
    assert var_1 == 'ansible/plugins/filter/core/json_query.py'



# Generated at 2022-06-25 10:17:36.422132
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    base_plugin_path = '/'
    plugin_path_0 = '/usr/local/lib/python2.7/dist-packages/ansible/plugins'
    plugin_path_1 = '/etc/ansible/plugins/connection'
    plugin_path_2 = '/etc/ansible/plugins/inventory'
    plugin_path_3 = '/etc/ansible/plugins/callback'
    plugin_path_4 = '/etc/ansible/plugins/action'
    plugin_path_5 = '/etc/ansible/plugins/strategy'
    plugin_path_6 = '/etc/ansible/plugins/cache'
    plugin_path_7 = '/etc/ansible/plugins/magic'
    plugin_path_8 = '/etc/ansible/plugins/lookup'

# Generated at 2022-06-25 10:17:39.425257
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    var_0 = get_shell_plugin()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 10:17:40.684455
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    obj = None
    with patch('ansible.plugins.loader.get_shell_plugin', return_value=obj):
        test_case_0()


# Generated at 2022-06-25 10:18:10.376318
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    shell_plugin = get_shell_plugin()
    arg_0 = 'zsh'
    arg_1 = os.path.expanduser('~/.zshrc')
    plugin_load_context = shell_plugin.get_with_context(arg_0, arg_1)

    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'zsh'
    assert os.path.expanduser(plugin_load_context.plugin_resolved_path) == os.path.abspath(os.path.expanduser('../../lib/ansible/plugins/shell/zsh.py'))


# Generated at 2022-06-25 10:18:19.098765
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    pl = PluginLoader('test_package', 'test_class', 'test_base_class', package_subdirs=['test_package_subdir'])
    pl.add_directory('/test_cwd/test_base_dir')
    pl.add_directory('/test_cwd/test_base_dir/test_package_subdir1')
    pl.add_directory('/test_cwd/test_base_dir/test_package_subdir2')

    fqcr1 = AnsibleCollectionRef.from_string('test_collection.test_namespace.test_package:test_name1')
    fqcr2 = AnsibleCollectionRef.from_string('test_collection.test_namespace.test_package:test_name2')

# Generated at 2022-06-25 10:18:28.669500
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    path_0 = 'C:\\Users\\admini\\.ansible\\plugins\\modules'
    var_0 = True
    var_1 = False

# Generated at 2022-06-25 10:18:32.471011
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    var_1 = PluginLoader('ShellModule', 'ansible.plugins.action', 'ActionModule', 'ansible.plugins.action.ActionModule', 'shell')
    assert 'ansible.builtin.shell' == var_1.find_plugin('shell')


# Generated at 2022-06-25 10:18:34.115722
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    '''Test case for PluginLoader'''
    var_0 = get_shell_plugin()


# Generated at 2022-06-25 10:18:41.410066
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # get a random path
    import random
    from ansible.utils.loader import get_path_distribution
    all_paths = get_path_distribution()
    path_list = all_paths['collections'] + all_paths['ansible'] + all_paths['module_utils']
    random_path = random.choice(path_list)

    # get Jinja2Loader
    loader = Jinja2Loader()
    filtered_paths = [path for path in path_list if path == random_path]
    loader.add_directory(filtered_paths)

    # get Jinja2Loader
    jinja2_loader = Jinja2Loader()
    jinja2_loader.add_directory(filtered_paths)

    # get random plugin in filtered_paths

# Generated at 2022-06-25 10:18:51.295871
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_0 = PluginLoader("module_utils")
    var_1 = PluginLoader("modules")
    var_2 = PluginLoader("lookup_plugins")
    var_3 = PluginLoader("filter_plugins")
    var_4 = PluginLoader("connection")
    var_5 = PluginLoader("shell")
    var_6 = PluginLoader("fragment")
    var_7 = PluginLoader("cache")
    var_8 = var_2.all()
    var_9 = var_7.all()
    var_10 = var_8()
    var_11 = var_9()
    var_12 = var_11()
    var_13 = var_10()
    var_14 = var_3.all()
    var_15 = var_5.all()
    var_16 = var_1.all()
    var

# Generated at 2022-06-25 10:18:58.258702
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    b_path = '/home/daniel/ansible/temp/ansible/plugins/cache/'
    if os.path.isdir(b_path):
        for name, obj in get_all_plugin_loaders():
            if obj.subdir:
                plugin_path = os.path.join(b_path, to_bytes(obj.subdir))
                if os.path.isdir(plugin_path):
                    obj.add_directory(to_text(plugin_path))
    else:
        display.warning("Ignoring invalid path provided to plugin path: '%s' is not a directory" % to_text(path))



# Generated at 2022-06-25 10:19:02.605383
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    mock_path = "/tmp/"
    with unittest.mock.patch('os.path.isdir') as isdir:
        isdir.side_effect = [True, False]
        with unittest.mock.patch('os.path.join') as join:
            join.return_value = mock_path
            from ansible.plugins.loader import add_all_plugin_dirs
            add_all_plugin_dirs(mock_path)


# Generated at 2022-06-25 10:19:09.773862
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    loader = PluginLoader('ansible.plugins.action')

    obj = loader.get_with_context('ping')
    assert obj.object.get_name() == 'ping'
    assert hasattr(obj.object, 'run')

    obj = loader.get_with_context('win_ping')
    assert obj.object.get_name() == 'win_ping'
    assert hasattr(obj.object, 'run')

    obj = loader.get_with_context('linux_ping')
    assert obj.object.get_name() == 'linux_ping'
    assert hasattr(obj.object, 'run')

    obj = loader.get_with_context('windows_ping')
    assert obj.object.get_name() == 'windows_ping'
    assert hasattr(obj.object, 'run')


# Generated at 2022-06-25 10:20:48.292734
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # Init
    jinjaloader = Jinja2Loader()

    def test_literal_string(name):
        # Invalid Argument Exception
        with pytest.raises(AssertionError):
            # Test
            jinjaloader.get(name)

    def test_valid_name(name):
        # Test
        result = jinjaloader.get(name)

        # Verification
        assert 'template' in result.__dict__
        assert 'name' in result.__dict__
        assert 'filter' in result.__dict__
        assert 'args' in result.__dict__
        assert 'kwargs' in result.__dict__

        # Cleanup
        del result

    # Testing with a literal string
    test_literal_string("abc")

    # Testing with a valid name


# Generated at 2022-06-25 10:20:49.723327
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    var_0 = Jinja2Loader()
    var_1 = var_0.get(arg_0)
    assert isinstance(var_1, jinja2.ext.Extension)


# Generated at 2022-06-25 10:20:53.981243
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    _PLUGIN_PATH = ['ansible.plugins.action.remote_user']
    # @TODO: when adding arguments to PluginLoader.get_with_context, update this test
    var_0 = PluginLoader(package='ansible.plugins.action', class_name='ActionModule').get_with_context('remote_user', collection_list=_PLUGIN_PATH)
    assert var_0


# Generated at 2022-06-25 10:20:56.775481
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    var_0 = get_shell_plugin()
    assert str(var_0) == "<module 'ansible.plugins.shell.sh' from '/home/user/ansible/lib/ansible/plugins/shell/sh.py'>"


# Generated at 2022-06-25 10:20:57.746026
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    var_0 = get_shell_plugin()



# Generated at 2022-06-25 10:21:02.290025
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    var_0 = PluginLoader(None, None, None)
    var_0.find_plugin = lambda name: False
    var_0.find_plugin_with_context = lambda name, collection_list=None: {'resolved': False}
    var_1 = var_0.get_with_context(None)
    var_2 = var_1.plugin_load_context.resolved
    assert var_2 == False


# Generated at 2022-06-25 10:21:04.227615
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    var_0 = PluginLoader('', 'yes', '', [])
    assert (var_0.__contains__('yes') == True)


# Generated at 2022-06-25 10:21:07.208901
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    var_0 = Jinja2Loader('ansible.plugins.filter').get('tests')
    var_1 = Jinja2Loader('ansible.plugins.test').get('tests')
    assert var_0._load_name == 'tests'
    assert var_1._load_name == 'tests'


# Generated at 2022-06-25 10:21:08.252699
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    var_1 = get_shell_plugin()


# Generated at 2022-06-25 10:21:14.976938
# Unit test for function get_shell_plugin
def test_get_shell_plugin():

    # First change the default shell type to sh
    shell_types = [('sh', 'sh'), ('csh', 'csh'), ('ksh', 'ksh')]
    for shell_type, returned_shell_type in shell_types:
        shell = get_shell_plugin(shell_type)
        correct = returned_shell_type
        wrong = 'sh' if correct == 'csh' else 'csh'
        assert shell.SHELL_FAMILY == correct, 'Expected %s'%correct
        assert shell.SHELL_FAMILY != wrong, 'Expected %s'%wrong

    # Test by providing an executable
    data = [('/bin/bash', 'sh'), ('/bin/csh', 'csh'), ('/bin/ksh', 'ksh')]