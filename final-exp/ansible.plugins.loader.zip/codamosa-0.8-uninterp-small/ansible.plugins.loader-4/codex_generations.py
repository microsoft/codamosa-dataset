

# Generated at 2022-06-25 10:13:49.746478
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    plugin_load_context_0 = PluginLoadContext()
    plugin_load_context_0.terms = ['test_case_0']
    assert PluginLoader.find_plugin_with_context(plugin_load_context_0) == plugin_load_context_0
    assert plugin_load_context_0.resolved == True
    assert plugin_load_context_0.plugin_resolved_name == 'test_case_0'
    assert plugin_load_context_0.plugin_resolved_path == '/data/1/'
    assert plugin_load_context_0.redirect_list == []

# Generated at 2022-06-25 10:13:57.305075
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    loader = PluginLoader('ansible.plugins.test.test_plugins', 'Tester')
    loader.add_directory('/a/path/that/does/not/exist')
    assert '/a/path/that/does/not/exist' in loader._get_paths()


# Generated at 2022-06-25 10:14:04.867623
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    plugin_load_context_0 = PluginLoadContext()
    which_loader = 'action'
    paths = []
    test_case_0()

    # We are not testing the if case here where we do not have the subdir
    loader = getattr(sys.modules[__name__], '%s_loader' % which_loader)
    for path in paths:
        loader.add_directory(path, with_subdir=True)



# Generated at 2022-06-25 10:14:11.292296
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    plugin_load_context_0 = PluginLoadContext()
    dict_0 = dict()
    dict_0['warning_text_0'] = 'warning_text_0'
    dict_0['removal_date_0'] = 'removal_date_0'
    dict_0['removal_version_0'] = 'removal_version_0'
    plugin_load_context_0.record_deprecation('', dict_0, '')
    if (not plugin_load_context_0.deprecated):
        print('AssertionError: false')
    if ((plugin_load_context_0.removal_date != 'removal_date_0') or (plugin_load_context_0.removal_version != 'removal_version_0')):
        print('AssertionError: false')

# Generated at 2022-06-25 10:14:15.999071
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    plugin_load_context_0 = plugin_load_context_0

    # Assign parameters
    which_loader_0 = 'filter'
    paths_0 = ['/var/log/syslog']

    # Call function
    return_value = add_dirs_to_loader(which_loader, paths)

    # Asserts
    assert return_value == None


# Generated at 2022-06-25 10:14:19.416085
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    plugin_load_context_0 = PluginLoadContext()
    str_0 = 'test'
    dict_0 = {}
    plugin_load_context_0.record_deprecation('test', {}, 'test')


# Generated at 2022-06-25 10:14:30.602201
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # expected to succeed
    add_dirs_to_loader("module", ['/Users/enmy/workspace/ansible-project/toshiba-legacy/ansible-modules-core'])

    # expected to fail
    add_dirs_to_loader("module", ['/Users/enmy/workspace/ansible-project/toshiba-legacy/ansible-modules-core/cloud'])
    add_dirs_to_loader("module", ['/Users/enmy/workspace/ansible-project/toshiba-legacy/ansible-modules-core/crypto'])
    add_dirs_to_loader("module", ['/Users/enmy/workspace/ansible-project/toshiba-legacy/ansible-modules-core/database'])
    add_dirs_to_

# Generated at 2022-06-25 10:14:31.663477
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    output = get_shell_plugin()
    assert output



# Generated at 2022-06-25 10:14:32.461896
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    test_case_0()


# Generated at 2022-06-25 10:14:42.832515
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    #test for plugin loader add directory
    plugin_load_context_1 = PluginLoadContext()
    assert not plugin_load_context_1.search_paths
    plugin_load_context_1.add_directory('test_path', False)
    assert len(plugin_load_context_1.search_paths) == 1
    plugin_load_context_1.add_directory('test_path', False)
    assert len(plugin_load_context_1.search_paths) == 1
    plugin_load_context_1.add_directory('test_path2', False)
    assert len(plugin_load_context_1.search_paths) == 2
    plugin_load_context_1.add_directory('test_path2', False, insert_first=True)

# Generated at 2022-06-25 10:15:55.493682
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    loader = PluginLoader('', 'C.base_class', 'C.module_utils', 'C.package')
    name = ''
    loader.has_plugin(name)



# Generated at 2022-06-25 10:16:04.978670
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    plugin_load_context_0 = PluginLoadContext()
    plugin_load_context_1 = PluginLoadContext()
    plugin_load_context_2 = PluginLoadContext()
    plugin_load_context_1.resolved = True
    plugin_load_context_2.candidate_name = 'shell'
    plugin_load_context_1.redirect_list = ['shell']
    plugin_load_context_2.resolved = True
    plugin_load_context_2.plugin_resolved_name = 'shell'
    plugin_load_context_2.plugin_resolved_path = '/home/circleci/.ansible/collections/ansible_collections/test_ns/test_coll/plugins/shell.py'
    plugin_load_context_0._methods_with_context['find_plugin'] = plugin_load

# Generated at 2022-06-25 10:16:07.322552
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    plugin_load_context_0 = test_case_0()
    assert (plugin_load_context_0.resolved)


# Generated at 2022-06-25 10:16:16.433107
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Get the array of available plugins
    available_plugins = get_all_plugin_loaders()

    # Initialize a plugin lookup by name
    plugin_loaders = {}
    for name, obj in available_plugins:
        plugin_loaders[name] = obj

    # Add plugin directories for all existing plugins
    add_all_plugin_dirs('test/unit/output/test_collections')
    add_all_plugin_dirs('test/unit/output/test_roles')

    # Add plugin directories for all non-existing plugins
    bad_plugin_loaders = []
    for name, obj in available_plugins:
        # Clone the plugin loader
        new_loader = obj.__class__.__new__(obj.__class__)
        new_loader.__dict__ = obj.__dict__.copy()
       

# Generated at 2022-06-25 10:16:20.934103
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    plugin_load_context_0 = PluginLoadContext()
    plugin_loader_1 = PluginLoader('', '', '', '', plugin_load_context_0)
    # Verify that method __contains__() of class PluginLoader returns an AnsibleCollectionRef
    assert(isinstance(plugin_loader_1.__contains__('ansible.builtin.async_status'), PluginLoadContext))


# Generated at 2022-06-25 10:16:29.570323
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    plugin_load_context_0 = PluginLoadContext()
    name_1 = 'name_1'
    deprecation_1 = {}
    collection_name_1 = 'collection_name_1'

    display_method_of_display_class = Display()
    deprecated_method_of_display_method_of_display_class = display_method_of_display_class.deprecated
    deprecated_method_of_display_method_of_display_class = getattr(deprecated_method_of_display_method_of_display_class, '_orig_func', deprecated_method_of_display_method_of_display_class)
    test_case_0.test_0 = deprecated_method_of_display_method_of_display_class
    test_case_0.test_1 = display_method_of_display_

# Generated at 2022-06-25 10:16:40.384625
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    '''
    Test get_with_context method for class PluginLoader:
    '''
    # Create a PluginLoader object and test if it can be successfully created
    pl = PluginLoader('', '', '', '', '', None, None, None, None)

    # Create a PluginLoadContext to be passed to get_with_context method
    plugin_load_context_1 = PluginLoadContext()
    plugin_load_context_1.collection_one.plugin_name = 'jason'
    plugin_load_context_1.collection_one.plugin_type = 'action'

    # Call get_with_context method and test if it returns the correct value
    plugin = pl.get_with_context('jason', plugin_load_context=plugin_load_context_1)
    assert plugin.object is None
    assert plugin.plugin_load

# Generated at 2022-06-25 10:16:42.215197
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    test_case_0()



# Generated at 2022-06-25 10:16:49.381786
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Pick a non-existent plugin name for testing
    plugin_name = "test_plugin"

    # Create new PluginLoader object so that its cache is empty:
    with tempfile.TemporaryDirectory() as temp_dir:
        with patch.dict(os.environ, ANSIBLE_COLLECTIONS_PATH=temp_dir):
            pl = PluginLoader(package='ansible.plugins.test_module')

            # Test find.plugin with non-existent name
            pl.find_plugin(plugin_name)

            # Create an empty test_module/__init__.py file and re-run find_plugin
            # This test verifies that initialize is correctly re-run to search for plugins
            # when the __init__.py file is created

# Generated at 2022-06-25 10:16:52.601832
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()


# Generated at 2022-06-25 10:17:12.199030
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert get_shell_plugin('sh')
    assert get_shell_plugin(executable='/bin/sh')
    assert get_shell_plugin(executable='/bin/bash')


# Generated at 2022-06-25 10:17:17.229850
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    plugin_load_context_0 = PluginLoadContext()
    str0 = 's'
    # AssertionError:
    #assert isinstance(add_all_plugin_dirs(str0), bool)
    bool0 = True
    # AssertionError:
    #assert not bool0
    # AssertionError:
    #assert not bool0
    # AssertionError:
    #assert isinstance(add_all_plugin_dirs(str0), bool)


# Generated at 2022-06-25 10:17:23.010745
# Unit test for method find_plugin_with_context of class PluginLoader

# Generated at 2022-06-25 10:17:24.730595
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    result_2 = get_shell_plugin(shell_type='sh')
    assert result_2 is not None



# Generated at 2022-06-25 10:17:34.704025
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():

    plugin_load_context_0 = PluginLoadContext()
    plugin_load_context_1 = PluginLoadContext()
    plugin_load_context_2 = PluginLoadContext()
    plugin_load_context_3 = PluginLoadContext()
    plugin_load_context_4 = PluginLoadContext()
    plugin_load_context_5 = PluginLoadContext()
    plugin_load_context_6 = PluginLoadContext()

    assert(plugin_load_context_0.__contains__('test_name') is None)
    assert(plugin_load_context_1.__contains__('test_name') is None)
    assert(plugin_load_context_2.__contains__('test_name') is None)
    assert(plugin_load_context_3.__contains__('test_name') is None)

# Generated at 2022-06-25 10:17:36.699485
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    if not hasattr(PluginLoadContext, 'record_deprecation'):
        raise Exception("PluginLoadContext class does not have method record_deprecation")



# Generated at 2022-06-25 10:17:44.434020
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    plugin_load_context_0 = PluginLoadContext()
    plugin_loader_0 = PluginLoader(
        package="ansible",
        class_name="win_ping",
        config_opts={}
    )
    ansible_loop_result_0 = plugin_loader_0.all()
    display.display("ansible_loop_result_0", ansible_loop_result_0)
    assert ansible_loop_result_0 is not None
    plugin_load_context_0.resolved = True
    plugin_load_context_0.plugin_resolved_path = "/path/to/plugin_file"
    plugin_load_context_0.plugin_resolved_name = "plugin_file"
    plugin_load_context_0.redirect_list = []
    plugin_load_context_0.collection_

# Generated at 2022-06-25 10:17:47.080740
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    add_all_plugin_dirs("/test/path")
    for obj in get_all_plugin_loaders():
        obj[1].plugin_paths = []


# Generated at 2022-06-25 10:17:53.283426
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    plugin_load_context_0 = PluginLoadContext()
    plugin_load_context_1 = PluginLoadContext()
    plugin_load_context_3 = PluginLoadContext()

    def test_case_1():
        # Call to all()
        test_case_0()
        test_case_1()
        test_case_2()

    def test_case_2():
        # Call to all()
        test_case_0()
        test_case_1()
        test_case_2()


# Generated at 2022-06-25 10:18:00.125835
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    jinja2_loader_0 = Jinja2Loader()
    name_0 = 'init.j2'
    args_0 = ['init.j2', 'init.j2', 'init.j2']
    kwargs_0 = {'_dedupe': False, 'path_only': False, 'class_only': False}
    assert_equal(jinja2_loader_0.get(name_0, *args_0, **kwargs_0), None)  # exclude: None


# Generated at 2022-06-25 10:18:28.657199
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    import ansible.plugins.loader as ploader

    # Simulate an environment variable that should point to our test plugin
    path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..', 'test', 'plugins')
    os.environ['MY_TEST_PLUGIN_PATH'] = path

    # Test that adding a non-dir to the plugin path results in a warning
    ploader.add_all_plugin_dirs(os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..', 'test', 'lib'))
    assert PLUGIN_PATH_CACHE['shell'] == []

    # Test that adding a directory that doesn't contain a subdir for one of the plugin types
    # results

# Generated at 2022-06-25 10:18:35.366562
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    plugin_load_context_0 = PluginLoadContext()
    plugin_load_context_0.plugin_resolved_path = plugin_load_context_0.nope('error during plugin load')
    plugin_load_context_0.nope('error during plugin load')
    plugin_load_context_0.plugin_resolved_path = plugin_load_context_0.nope('error during plugin load')

    result_0 = has_plugin(plugin_load_context_0, name, collection_list=None)
    assert result_0 is None


# Generated at 2022-06-25 10:18:37.824398
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    add_all_plugin_dirs(os.path.dirname(os.path.realpath(__file__)))
    for name, obj in get_all_plugin_loaders():
        assert obj.directory is not None



# Generated at 2022-06-25 10:18:39.431113
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    plugin_path = 'a/b/c/d/e'
    add_all_plugin_dirs(plugin_path)



# Generated at 2022-06-25 10:18:47.323976
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    ''' plugin_loader.PluginLoader.find_plugin unit-test '''

    plugin_load_context_0 = PluginLoadContext()
    plugin_load_context_1 = PluginLoadContext()
    path = ''
    plugin_load_context_1.validate = True
    plugin_load_context_0.validate = True
    plugin_load_context_1.searchpath = path
    plugin_load_context_1.collection_list = []
    plugin_load_context_0.searchpath = path
    plugin_load_context_0.collection_list = []

    # Testing an empty collection search-path
    plugin_load_context_1.collection_searchpath = {}

    # Testing an empty main search-path
    plugin_load_context_1.main_searchpath = {}

    # Testing an empty extension map
   

# Generated at 2022-06-25 10:18:49.910697
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    plugin_load_context_1 = PluginLoadContext()
    add_all_plugin_dirs('/var/cache/ansible_collections')


# Generated at 2022-06-25 10:18:54.508373
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    plugin_load_context_0 = PluginLoadContext()
    name = "plugin_name"
    deprecation = {"warning_text": ""}
    collection_name = "collection_name"
    deprecation = plugin_load_context_0.record_deprecation(name, deprecation, collection_name)
    return deprecation


# Generated at 2022-06-25 10:19:02.050500
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    plugin_load_context_0 = PluginLoadContext()
    plugin_load_context_0.fq_name = 'ansible.plugins.action.accelerate'
    plugin_load_context_0.search_paths = ['/home/centos/.ansible/plugins/action']
    plugin_load_context_0.searched_paths = []
    plugin_load_context_0.collection = None
    plugin_load_context_0.plugin_name = 'accelerate'
    plugin_load_context_0.package = 'ansible.plugins.action'
    plugin_load_context_0.suffix = '.py'
    plugin_load_context_0.resolved = False
    plugin_load_context_0.resolved_fqcn = None
    plugin_load_context_0.plugin_

# Generated at 2022-06-25 10:19:09.584441
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    plugin_load_context_0 = PluginLoadContext()
    assert plugin_load_context_0.deprecated == False
    assert plugin_load_context_0.removal_date == None
    assert plugin_load_context_0.removal_version == None
    assert plugin_load_context_0.deprecation_warnings == []
    test_deprecation = {'warning_text': 'test warning', 'removal_date': 'test date'}
    plugin_load_context_0.record_deprecation('test_name',test_deprecation,'test_collection_name')
    assert plugin_load_context_0.deprecated == True
    assert plugin_load_context_0.removal_date == 'test date'
    assert plugin_load_context_0.removal_version == None
    assert plugin_

# Generated at 2022-06-25 10:19:16.544295
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    # Assume deprecation does not have the key 'warning_text'
    plugin_load_context_0 = PluginLoadContext()
    deprecation_0 = dict()
    deprecation_0['removal_date'] = '02/01/2018'
    deprecation_0['removal_version'] = '2.5'
    collection_name_0 = ''
    plugin_load_context_0.record_deprecation('name_0', deprecation_0, collection_name_0)

    # Assume deprecation has the key 'warning_text'
    plugin_load_context_1 = PluginLoadContext()
    deprecation_1 = dict()
    deprecation_1['warning_text'] = 'warning text'

# Generated at 2022-06-25 10:20:09.936495
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    plugin_class_name = 'ActionModule'
    # Class PluginLoader has no member all
    with pytest.raises(AttributeError):
        loader = PluginLoader(plugin_class_name, 'module_utils')
    with pytest.raises(AttributeError):
        loader.all()


# Generated at 2022-06-25 10:20:13.918373
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # TODO: rewrite this to use a bug tracker issue and get a test module
    temp_dir = tempfile.mkdtemp()
    mod_path = os.path.join(temp_dir, "my_module.py")
    mod_file = open(mod_path, "w")

# Generated at 2022-06-25 10:20:23.729756
# Unit test for method __contains__ of class PluginLoader

# Generated at 2022-06-25 10:20:26.633329
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    all_cases = [0]
    for case in all_cases:
        func_name = f'test_case_{case}'
        globals()[func_name]()


# Generated at 2022-06-25 10:20:34.876690
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    plugin_load_context_1 = PluginLoadContext()
    test_path = 'Test path'
    test_subdir_0 = 'Test subdir'
    test_subdir_1 = 'Test subdir 1'
    test_subdir_dict = {test_subdir_0 : True, test_subdir_1 : True}
    plugin_load_context_1.subdir = test_subdir_dict
    plugin_load_context_1.add_directory = lambda dir: plugin_load_context_1.dir.append(dir)
    plugin_load_context_1.dir = []
    add_all_plugin_dirs(test_path)
    assert plugin_load_context_1.dir == []


# Generated at 2022-06-25 10:20:43.100320
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    plugin_load_context_0 = PluginLoadContext()
    plugin_load_context_0._plugin_args = ['foo', 'bar']
    plugin_load_context_0._plugin_kwargs = {'baz': 'qux'}
    plugin_load_context_0._plugin_name = 'my_plugin'
    plugin_load_context_0._plugin_package = 'foo.bar'
    plugin_load_context_0._collection_list = {}
    plugin_load_context_0._plugin_class_name = 'MyPlugin'
    plugin_load_context_0._plugin_class_weight = 1000
    plugin_load_context_0._plugin_class_type = 'my_type'
    plugin_load_context_0._plugin_base_class = 'BaseClass'
    plugin_load_context_0._

# Generated at 2022-06-25 10:20:50.080016
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    plugin_load_context_0 = PluginLoadContext()
    class_0 = PluginLoader(error_on_missing=False, package='action_plugins', subdir='action_plugins', directories=[])
    function_0 = class_0.find_plugin(name='copy', plugin_load_context=plugin_load_context_0)
    function_0 = class_0.find_plugin(name='copy', plugin_load_context=plugin_load_context_0)
    function_0 = class_0.find_plugin(name='copy', plugin_load_context=plugin_load_context_0)
    function_0 = class_0.find_plugin(name='copy', plugin_load_context=plugin_load_context_0)

# Generated at 2022-06-25 10:20:56.113862
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    plugin_load_context_0 = PluginLoadContext()
    # PLUGIN LOSS
    # PLUGIN LOSS
    # PLUGIN LOSS
    # PLUGIN LOSS
    # PLUGIN LOSS
    # PLUGIN LOSS
    # PLUGIN LOSS
    # PLUGIN LOSS
    # PLUGIN LOSS
    # PLUGIN LOSS
    # PLUGIN LOSS
    # PLUGIN LOSS
    # PLUGIN LOSS
    # PLUGIN LOSS
    # PLUGIN LOSS
    # PLUGIN LOSS
    # PLUGIN LOSS
    # PLUGIN LOSS
    # PLUGIN LOSS
    # PLUGIN LOSS
    return plugin_load_context_0


# Generated at 2022-06-25 10:21:04.074508
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    global _PLUGIN_FILTERS

    # - init
    _PLUGIN_FILTERS = init_filter()

    # - set test data
    # - create test objects
    loader_obj_0 = PluginLoader('action_plugins', 'ActionModule', C.DEFAULT_ACTION_PLUGIN_PATH, 'ansible.plugins.action')
    plugin_load_context_0 = PluginLoadContext()
    plugin_load_context_0.plugin_resolved_name = '__init__'
    plugin_load_context_0.plugin_resolved_path = '/path/to/collection/plugins/action/__init__.py'
    plugin_load_context_0.is_collection_item = False
    loader_obj_0._searched_paths = ['/path/to/collection/plugins/action']



# Generated at 2022-06-25 10:21:10.775092
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    plugin_load_context_0 = PluginLoadContext()
    # Unit test: init of class PluginLoader
    plugin_loader_0 = PluginLoader(package='ansible.plugins.test', directories=['/dummy/path'], class_name='test', base_class='base', config_options=['test_option'], config_prefix='test_prefix', aliases=['test_alias'])
    try:
        # NOTE: test parameter collection_list is not supported
        # Unit test: method find_plugin_with_context of class PluginLoader
        plugin_loader_0.find_plugin_with_context('test_plugin_name', collection_list=None)
    except Exception as exception:
        display.error('Failed to run test: unit test of method find_plugin_with_context of class PluginLoader')
        raise
