

# Generated at 2022-06-25 10:13:29.869968
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    pldr = PluginLoader('TestPluginLoader_get_with_context', package='ansible.plugins.test_PluginLoader',
                        config_loader=None, subclass_list=())
    subcl = pldr.get('test_module_1')
    assert(isinstance(subcl, TestModule1))


# Generated at 2022-06-25 10:13:39.045514
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    paths = None
    which_loader = 'action'
    test_func_result = add_dirs_to_loader(which_loader, paths)
    assert test_func_result is None

    paths = ['test']
    which_loader = 'action'
    test_func_result = add_dirs_to_loader(which_loader, paths)
    assert test_func_result is None

    paths = ['test']
    which_loader = 'none'
    try:
        test_func_result = add_dirs_to_loader(which_loader, paths)
    except AttributeError as e:
        pass



# Generated at 2022-06-25 10:13:44.210050
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    '''
    Test for method PluginLoader.find_plugin
    '''
    # Test with single path
    plugin_paths = [ '/home/vagrant/ansible/lib/ansible/plugins/cache' ]
    test_plugin_loader_0 = PluginLoader( 'ansible.plugins.cache.memory',
                                         'ansible.plugins.cache.memory.MemoryCacheModule',
                                         C.CACHE_PLUGIN_PATH,
                                         required_base_class='CacheModule',
                                         aliases=dict(),
                                         package_errors=False )
    test_plugin_loader_0._get_paths = lambda: plugin_paths
    plugin_load_context_0 = test_plugin_loader_0.find_plugin_with_context( 'inmem' )
    assert plugin_load_context_0
   

# Generated at 2022-06-25 10:13:49.258789
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    plugin_load_context_0 = PluginLoadContext()

    # verify that find_plugin_with_context(plugin_name, context)
    #  returns PluginLoadContext object
    plugin_loader_0 = PluginLoader()
    assert isinstance(plugin_loader_0.find_plugin_with_context('action_plugin', context=plugin_load_context_0), PluginLoadContext)


# Generated at 2022-06-25 10:13:57.291305
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    pl = PluginLoader(package='ansible.plugins.test.test_plugin_loader.test_package', subdir='test_subdir')
    pl.find_plugin('test_plugin_0', collection_list=[AnsibleCollectionRef(owner='test_owner', name='test_name')])
    pl.find_plugin('test_plugin_1', collection_list=[AnsibleCollectionRef(owner='test_owner', name='test_name')])
    pl.find_plugin('test_plugin_2', collection_list=[AnsibleCollectionRef(owner='test_owner', name='test_name')])
    pl.find_plugin('test_plugin_3', collection_list=[AnsibleCollectionRef(owner='test_owner', name='test_name')])

# Generated at 2022-06-25 10:14:02.902018
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    global _PLUGIN_PATH_CACHE
    _PLUGIN_PATH_CACHE = {}

    # AnsibleModule isn't available as a module name yet. Use the fact that it
    # is defined in its module to confirm that it is found and loaded.  This
    # tests the path to ansible plugins in the same dir as the executed ansible
    # script.
    ansible_module_loader = PluginLoader('ansible.plugins.module_utils', 'AnsibleModule')
    context = ansible_module_loader.get_with_context('basic', args=[], kwargs={})
    assert context.object.__name__ == 'AnsibleModule'
    assert context.plugin_resolved_path == os.path.join(os.path.dirname(__file__), 'module_utils', 'basic.py')

# Generated at 2022-06-25 10:14:04.883040
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    '''
    Tests PluginLoader.add_directory method
    '''
    plugin_load_context_0 = PluginLoadContext()
    plugin_loader_0 = PluginLoader('ansible.plugins.connection')
    plugin_loader_0.add_directory(plugin_load_context_0, '/etc')


# Generated at 2022-06-25 10:14:11.321051
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test if add_all_plugin_dirs will add all correct dirs
    add_all_plugin_dirs("test_dir")

# Generated at 2022-06-25 10:14:18.983998
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    plugin_load_context_0 = PluginLoadContext()
    plugin_loader_0 = PluginLoader('')
    plugin_load_context_1 = plugin_loader_0._PluginLoader__find_plugin_with_context('', plugin_load_context_0)
    assert plugin_load_context_1.resolved == False
    assert plugin_load_context_1.plugin_resolved_name == ''
    assert plugin_load_context_1.plugin_resolved_path == ''


# Generated at 2022-06-25 10:14:30.309431
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Initialize the plugin_load_context
    plugin_load_context_0 = PluginLoadContext()
    # Initialize the plugin_load_context
    plugin_load_context_1 = PluginLoadContext()

    # Load a plugin loader for test
    plugin_loader = PluginLoader('filter_plugins')
    # Use the test_case_0 to set the find_plugin_with_context()'s return value
    plugin_loader.test_case_0 = plugin_load_context_0
    # Use the test_case_1 to set the find_plugin_with_context()'s return value
    plugin_loader.test_case_1 = plugin_load_context_1
    # Invoke the method
    plugin_load_context = plugin_loader.find_plugin_with_context(name='valid', collection_list='valid')
    #

# Generated at 2022-06-25 10:14:57.312062
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    plugin_load_context_0 = PluginLoadContext()
    plugin_load_context_0.add_item('name',to_text('foo'))
    plugin_0 = PluginLoader('module_utils', 'ModuleUtilsCore', 'module_utils', 'module_utils', '_load_params', 'base', plugin_load_context_0)
    plugin_load_context_0 = plugin_0.find_plugin('foo',to_text('module_utils'))
    assert plugin_load_context_0.resolved
    assert plugin_load_context_0.plugin_resolved_name == 'foo'
    assert plugin_load_context_0.plugin_resolved_path == 'module_utils/foo.py'
    with pytest.raises(AttributeError):
        plugin_load_context_0.plugin_resolved_

# Generated at 2022-06-25 10:15:02.065576
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    plugin_load_context_0 = PluginLoadContext()
    plugin_load_context_0.record_deprecation('name_3', 'deprecation_4', 'collection_name_5')


# Generated at 2022-06-25 10:15:06.731818
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # Setup
    plugin_load_context_0 = PluginLoadContext('name', '_load_name', '_loader_name')

    # Exercise
    Jinja2Loader('package', 'base_class', 'class_name', 'config_class', 'subdir').get(plugin_load_context_0)

    # Verify
    assert False


# Generated at 2022-06-25 10:15:13.064204
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    print("START test_PluginLoader_all")
    # FIXME: implement

    #def test_case_0(self, testcase_id=None):

# Generated at 2022-06-25 10:15:22.942317
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():

    PLUGIN_LOAD_CONTEXT_UNRESOLVED = PluginLoadContext(resolved=False)
    PLUGIN_LOAD_CONTEXT_RESOLVED = PluginLoadContext(resolved=True)

    class MockAnsibleModule(object):
        def __init__(self, module_name, module_path, redirection_paths, expected_result):
            self.module_name = module_name
            self.module_path = module_path
            self.redirection_paths = redirection_paths
            self.expected_result = expected_result

    class MockAnsibleModuleSearcher(object):
        def __init__(self, search_path, modules):
            self.search_path = search_path
            self.modules = modules


# Generated at 2022-06-25 10:15:27.856212
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    """
    Testing get with:
        - name=ansible.module_utils.basic.__init__
        - args=None
        - kwargs={'path_only': False}
        - class_only=True
    """
    print('Testing get with:')
    print('    - name=ansible.module_utils.basic.__init__')
    print('    - args=None')
    print('    - kwargs={\'path_only\': False}')
    print('    - class_only=True')
    plugin_load_context_1 = PluginLoadContext()
    obj = Jinja2Loader(plugin_load_context_1).get(name='ansible.module_utils.basic.__init__', args=None, kwargs={'path_only': False}, class_only=True)
    print

# Generated at 2022-06-25 10:15:30.173955
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    test_path = './*/'
    add_all_plugin_dirs(test_path)
    len(get_all_plugin_loaders()) == 2


# Generated at 2022-06-25 10:15:35.453525
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    collection_name = 'magic_collection'
    test_collection_paths = [TEST_DIR, ]
    test_collection_paths.append('{}/{}'.format(TEST_DIR, collection_name))
    collection_paths = {collection_name: test_collection_paths}

    search_path = os.path.join('{0}/{1}/plugins'.format(collection_paths[collection_name][0], 'lookup_plugins'))
    plugin_loader_10 = PluginLoader('lookup_plugins', search_path, collection_paths)

    # 1. Test the PluginLoader.__init__ method to see if the '_searched_paths' has the correct search path
    assert plugin_loader_10._searched_paths == [search_path, ]

    # 2.

# Generated at 2022-06-25 10:15:46.005796
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    plugin_load_context_0 = PluginLoadContext()
    plugin_load_context_0.resolved = False
    plugin_load_context_0.redirect_list = None
    plugin_load_context_0.collection_loader = None
    plugin_load_context_0.collection_name = None
    plugin_load_context_0.plugin_resolved_name = None
    plugin_load_context_0.plugin_resolved_path = None
    plugin_load_context_0.plugin_resolved_collection_name = None
    plugin_load_context_0.plugin_resolved_collection_version = None
    plugin_load_context_0.plugin_resolved_fq_name = None
    plugin_load_context_0.plugin_resolved_fq_collection_name = None
    plugin_load_

# Generated at 2022-06-25 10:15:53.752990
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # no plugin_path set, should not raise exception
    add_all_plugin_dirs('/')
    # plugin_path set, is a directory
    ansible_path = os.path.expanduser(to_bytes('~/ansible'))
    os.makedirs(os.path.join(ansible_path, to_bytes('callback_plugins')))
    with open(os.path.join(ansible_path, to_bytes('callback_plugins'), to_bytes('test_plugin.py')), 'w') as f:
        f.write('#!/usr/bin/env python\n')
    os.chmod(os.path.join(ansible_path, to_bytes('callback_plugins'), to_bytes('test_plugin.py')), 0o755)

# Generated at 2022-06-25 10:16:27.264717
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    plugin_load_context_0 = PluginLoadContext()
    name = 'test_name'
    deprecation = {'warning_text': 'test'}
    collection_name = 'test_collection'
    plugin_load_context_0.record_deprecation(name, deprecation, collection_name)
    #TODO: Add code to test if the method behavior is as expected


# Generated at 2022-06-25 10:16:28.730747
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test with empty parameters
    config = PluginLoader.get_with_context()


# Generated at 2022-06-25 10:16:38.864767
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    plugin_load_context_0 = PluginLoadContext()
    plugin_load_context_1 = PluginLoadContext()
    plugin_load_context_2 = PluginLoadContext()
    plugin_load_context_3 = PluginLoadContext()
    # First function call
    class_object_0 = PluginLoader(
            'ansible.plugins.dummy',
            'Dummy')
    # Second function call
    class_object_1 = PluginLoader(
            'ansible.plugins.dummy',
            'Dummy')
    class_object_2 = PluginLoader(
            'ansible.plugins.dummy',
            'Dummy')

# Generated at 2022-06-25 10:16:47.986809
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    global _PLUGIN_PATH_CACHE
    global _PLUGIN_PATH_CACHE_PLUGIN_TYPE
    _PLUGIN_PATH_CACHE = temporarily_copy_dict(_PLUGIN_PATH_CACHE)
    _PLUGIN_PATH_CACHE_PLUGIN_TYPE = temporarily_copy_dict(_PLUGIN_PATH_CACHE_PLUGIN_TYPE)

    global _LOOKUP_PLUGIN_PATH_CACHE
    _LOOKUP_PLUGIN_PATH_CACHE = temporarily_copy_dict(_LOOKUP_PLUGIN_PATH_CACHE)

    global _PLUGIN_FILTERS
    _PLUGIN_FILTERS = temporarily_copy_dict(_PLUGIN_FILTERS)



# Generated at 2022-06-25 10:16:57.821971
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    plugin_load_context_0 = PluginLoadContext()
    plugin_load_context_0.plugin_name = 'url'
    plugin_load_context_0.plugin_type_name = 'lookup'
    plugin_load_context_0.collection_list = frozenset()
    plugin_load_context_0.display_path = False

    plugin_load_context_1 = PluginLoader('lookup', 'lookup', 'ansible.plugins.lookup').find_plugin_with_context(plugin_load_context_0.plugin_name, collection_list=plugin_load_context_0.collection_list)
    assert plugin_load_context_0 == plugin_load_context_1


# Generated at 2022-06-25 10:17:06.784915
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    plugin_load_context_0 = PluginLoadContext()

    # Set up objects required to test get
    package_0 = 'ansible.plugins.filter'
    base_class_0 = None
    class_name_0 = 'FilterModule'
    jinja2loader_0 = Jinja2Loader(package_0, base_class_0, class_name_0)

    # Call get with a known name and a known path
    name_0 = 'some_existing_file.py'
    path_0 = '/home/some_existing_file.py'
    assert jinja2loader_0.get(name_0, path_0, plugin_load_context_0=plugin_load_context_0) is None

    # Call get with a known name and a bad path

# Generated at 2022-06-25 10:17:15.957133
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    progress_callback = None
    search_path = None
    config_defs = {}
    collection_list = None
    name = 'lineinfile'
    expected_type = None

    class_name = 'ModuleReplacer'
    base_class = 'object'
    package = 'ansible.plugins.action'
    suffix = '.py'
    subdir = 'action'
    aliases = {}

    def mock_get_candidate_names_with_redirects(self, name, collection_list=None):
        print('mock_get_candidate_names_with_redirects')
        return [name]

    expected_value = None

# Generated at 2022-06-25 10:17:22.721678
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    my_plugin_loader = PluginLoader(
        class_name='UnitTestClassName',
        package='ansible.plugins.unit_testing_pkg',
        config_base='ansible.plugins.unit_testing_pkg',
        paths=[
        ],
        base_class='UnitTestBaseClass',
    )
    plugin_name = 'UnitTestPluginName'
    plugin_load_context = my_plugin_loader.get_with_context(plugin_name, collection_list=[])
    assert plugin_load_context.resolved is False
    assert plugin_load_context.resolved_permanent is False
    assert plugin_load_context.msg == 'no plugin found matching UnitTestPluginName'
    assert plugin_load_context.failed_candidate is None
    assert plugin_load_context.exception is None
    assert plugin_load

# Generated at 2022-06-25 10:17:31.983710
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    plugin_loader = PluginLoader('ansible.plugins.connection', 'ConnectionBase', 'connection')
    plugin_load_context = plugin_loader.find_plugin('smart')
    assert plugin_load_context.resolved is True
    assert plugin_load_context.plugin_resolved_name == 'smart'
    assert plugin_load_context.plugin_resolved_path == '/home/maple/.ansible/plugins/connection/smart.py'
    assert plugin_load_context.plugin_name == 'smart'
    assert plugin_load_context.redirect_list == []
    plugin_loader = PluginLoader('ansible.plugins.shell', 'ShellBase', 'shell')
    plugin_load_context = plugin_loader.find_plugin('csh')
    assert plugin_load_context.resolved is True
    assert plugin_load_context

# Generated at 2022-06-25 10:17:34.599372
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    loader = PluginLoader(package='test_PluginLoader___contains__')
    assert 'test_PluginLoader___contains__' in loader


# Generated at 2022-06-25 10:18:19.226675
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():

    from ansible.plugins.loader import _get_package_name_for_path

    expected_paths = {
        'inventory': ['/etc/ansible/inventory', '/usr/share/ansible/plugins/inventory/'],
        'net_os': ['/usr/share/ansible/plugins/net_os/']
    }

    plugin_load_context_0 = PluginLoadContext()

    paths = expected_paths['inventory']
    package = 'ansible.plugins.inventory'

    plugin_load_context_1 = PluginLoadContext(package=package, plugin_name='freeform', paths=paths, namespace='inventory')
    result_1 = PluginLoader.find_plugin_with_context('freeform', plugin_load_context=plugin_load_context_1)

    assert result_1.plugin_resolved_name

# Generated at 2022-06-25 10:18:21.371233
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    test_arg_0 = None
    test_arg_1 = None
    test_case_0()
    get_shell_plugin(test_arg_0, test_arg_1)


# Generated at 2022-06-25 10:18:23.183908
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    test_case_0()

# Generated at 2022-06-25 10:18:32.728987
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():

    # First test that if the plugin to be loaded is not explicitly specified in collections,
    # if it's a lookup plugin, then builtins will be searched, but if it's not a lookup plugin,
    # then builtins will not be searched.
    assert plugin_loader._find_fq_plugin('myns.mycoll.not_a_lookup.my_plugin', PluginLoadContext()) is not None
    assert plugin_loader._find_fq_plugin('myns.mycoll.not_a_lookup.my_plugin',
                                         plugin_load_context=PluginLoadContext(allow_builtin=False)) is None

    # Now test that the search order is correct, when accessing the plugin from within a task
    # and from a lookup plugin.
    plugin_loader_resolver = PluginLoaderResolver()
    plugin_loader_resolver.add

# Generated at 2022-06-25 10:18:40.356990
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    fact_plugins = PluginLoader('FactModule', 'facts', 'ansible.plugins.facts', C.DEFAULT_FACT_CACHE)
    fact_plugins.add_directory(C.FACT_MODULE_PATH)
    fact_plugins.add_directory(os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible_facts'))

    assert 'solaris' in fact_plugins

    # TODO : write a test for the default plugin case
    #
    # ACTION_PLUGIN_PATH = None
    #
    # action_plugins = PluginLoader('ActionModule', 'action_plugins',\
    #                               'ansible.plugins.action',\
    #                               C.ACTION_PLUGIN_PATH)
    #
    # assert 'chdir' in action_plugins

# Unit

# Generated at 2022-06-25 10:18:47.474229
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Initial state of PluginLoadContext object
    plugin_load_context_0 = PluginLoadContext()
    # Initial state of PluginLoader object
    plugin_loader_0 = PluginLoader('', '', '', '', '', '', '', '', '', '')

    # Call method PluginLoader.get_with_context with parameter name='name_0', plugin_load_context = plugin_load_context_0
    result = plugin_loader_0.get_with_context(name='name_0', plugin_load_context=plugin_load_context_0)
    assert result == get_with_context_result(None, plugin_load_context_0)
    

# Generated at 2022-06-25 10:18:53.355124
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    plugin_loader_0 = Jinja2Loader('filter_loader', 'ansible.plugins.filter_loader', 'FilterModule')
    name_0 = 'fqcr_0'
    collection_list_0 = ['ansible.legacy', 'bogus_collection_0']
    result_0 = plugin_loader_0.get(name_0, collection_list_0)


# Generated at 2022-06-25 10:18:56.878544
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    l = PluginLoader("", "", "", "")

    assert (l.find_plugin_with_context("invalid_plugin_name", collection_list=[]) is not None)
    assert (l._find_plugin("invalid_plugin_name", collection_list=[]) is None)



# Generated at 2022-06-25 10:19:03.855385
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    import collections
    import os
    import sys
    import types
    import unittest

    sys.path.append(os.path.join('..', 'lib'))
    from ansible.module_utils.six import PY3
    from ansible.plugins.loader import PluginLoader

    class TestPluginLoader(unittest.TestCase):

        def setUp(self):
            self.patcher = unittest.mock.patch('ansible.plugins.loader.DataLoader')
            self.patcher.start()

            self.loader = PluginLoader('action', 'ActionModule')
            self.loader.package = unittest.mock.Mock()
            self.loader.package.__name__ = 'ansible.plugins.something'
            self.loader.package.__path__ = []

# Generated at 2022-06-25 10:19:06.610092
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    PLUGIN_LOAD_CONTEXT_LIST = [
        PluginLoadContext("ansible.plugins.action")
    ]
    # TODO: Add unit tests for finding plugins and other parts of PluginLoader
    # that are not covered by the unit tests for InventoryPluginLoader and
    # StrategyPluginLoader


# Generated at 2022-06-25 10:19:34.734160
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    plugin_load_context_0 = PluginLoadContext()

    # Test Jinja2Loader._get on a simple plugin
    assert isinstance(Jinja2Loader("", "foo.py").get("foo"), AnsibleCollectionRef)

    # Test Jinja2Loader._get on a collection plugin
    assert isinstance(Jinja2Loader("", "foo.py").get("ansible.foo"), AnsibleCollectionRef)


# Generated at 2022-06-25 10:19:38.103319
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    plugin_load_context_0 = PluginLoadContext()
    name_0 = 'foo'
    deprecation_0 = {'removal_version': '2.12'}
    collection_name_0 = 'foo'
    plugin_load_context_0.record_deprecation(name_0, deprecation_0, collection_name_0)


# Generated at 2022-06-25 10:19:43.608686
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    plugin_load_context_0 = PluginLoadContext()
    plugin_loader_0 = PluginLoader('ping')
    plugin_loader_0.find_plugin_with_context("SuccessfulModule", plugin_load_context=plugin_load_context_0)
    assert plugin_load_context_0.resolved == True and plugin_load_context_0.plugin_resolved_name == "SuccessfulModule" and plugin_load_context_0.plugin_resolved_path == "./SuccessfulModule.py" and plugin_load_context_0.redirect_list == []
    plugin_loader_1 = PluginLoader('ping')
    plugin_loader_1.find_plugin_with_context("UnsuccessfulModule", plugin_load_context=plugin_load_context_0)
    assert plugin_load_context_0.resolved == False
   

# Generated at 2022-06-25 10:19:44.894133
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    loader = PluginLoader('foo', 'something.plugins', 'SomethingModule', 'something')
    assert 'test_case_0' in loader


# Generated at 2022-06-25 10:19:51.249643
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Set up mock inventory data
    test_inventory = {
        'plugins': {
            'plugin_loader': {
                'path_only': False,
                'dummy_path': 'fake/path'
            }
        },
        'collections': {}
    }

    # Test PluginLoader.all with path_only = False
    plugin_load_context_0 = PluginLoadContext()
    plugin_0 = PluginLoader('dummy_package', 'dummy_base_class', 'dummy_class_name',
                            'dummy_directories', 'dummy_name_only', 'dummy_package_errors',
                            plugin_load_context=plugin_load_context_0)

# Generated at 2022-06-25 10:20:00.391181
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    path = '~/.ansible'

# Generated at 2022-06-25 10:20:07.900536
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # pylint: disable=protected-access
    # If a plugin loader is instantiated with a base_class, then all
    # plugins must be subclasses of that class, otherwise, they will not
    # be returned by the all() method.

    # First, create a subclass of the base class
    @six.add_metaclass(PluginLoader)
    class PluginSubclass(object):
        pass

    # Add some plugins to the PluginLoader
    plugin_dir = tempfile.mkdtemp()

# Generated at 2022-06-25 10:20:15.057772
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    test_case_0()
    deprecation_0 = {'warning_text': 'warning text', 'removal_version': 'removal version', 'removal_date': 'removal date'}
    result_0 = plugin_load_context_0.record_deprecation('name', deprecation_0, 'collection_name')
    assert result_0 == plugin_load_context_0
    assert plugin_load_context_0.deprecated == True
    assert plugin_load_context_0.removal_version == 'removal version'
    assert plugin_load_context_0.removal_date == 'removal date'
    assert len(plugin_load_context_0.deprecation_warnings) == 1

# Generated at 2022-06-25 10:20:22.056660
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Create a PluginLoadContext object
    the_context = PluginLoadContext()

    # Create a PluginLoader object
    plugin_loader_obj = PluginLoader()

    # Call method find_plugin_with_context of class PluginLoader
    plugin_load_context_0 = plugin_loader_obj.find_plugin_with_context('name', collection_list=[])

    # Assert equality of the two objects
    assert the_context == plugin_load_context_0


# Generated at 2022-06-25 10:20:24.285461
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    print("In method test_Jinja2Loader_get")
    # Test instantiation
    plugin_load_context_0 = PluginLoadContext()
    loader_0 = Jinja2Loader(plugin_load_context_0)
    # Test using a method
    try:
        result = loader_0.get('foo')
    except Exception as e:
        print(e)


# Generated at 2022-06-25 10:21:15.377534
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():

    # Test 1
    plugin_load_context_0 = PluginLoadContext()
    plugin_load_context_1 = PluginLoadContext()
    helper__PluginLoader_0 = PluginLoader('ansible.plugins.vault', 'VaultLib', 'ansible.parsing.vault', 'VaultEditor')
    try:
        res_0 = helper__PluginLoader_0.get_with_context('foo')
        assert isinstance(res_0, get_with_context_result)
        plugin_load_context_2 = res_0.context
        assert isinstance(plugin_load_context_2, PluginLoadContext)
        obj_0 = res_0.object
        assert obj_0 is None
    except Exception as ex:
        display.error("Caught exception in plugin loader: %s" % to_text(ex))


# Generated at 2022-06-25 10:21:18.482313
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    print("Testing PluginLoader find_plugin")
    plugin_load_context_0 = PluginLoadContext()
    pl_0 = PluginLoader("foo", "bar", "baz")
    pl_0.find_plugin("foo", plugin_load_context=plugin_load_context_0)


# Generated at 2022-06-25 10:21:19.320640
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    test_case_0()


# Generated at 2022-06-25 10:21:27.128217
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    plugin_load_context_0 = PluginLoadContext()
    plugin_load_context_0._cache = {}
    plugin_load_context_0.package = 'ansible.plugins.filter.core'
    plugin_load_context_0.class_name = 'CoreFilters'
    plugin_load_context_0.paths = ['/usr/local/lib/python3.6/site-packages/ansible/plugins/filter/core']
    plugin_load_context_0.verbose = False
    plugin_load_context_0.debug = False
    plugin_load_context_0.base_class = 'FilterModule'
    plugin_load_context_0.collection_list = None
    plugin_load_context_0.subdir = 'filter_plugins'
    plugin_load_context_0.module_utils_loader