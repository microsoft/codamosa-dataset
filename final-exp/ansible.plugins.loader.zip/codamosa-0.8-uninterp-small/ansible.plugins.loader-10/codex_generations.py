

# Generated at 2022-06-25 10:13:58.005883
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    print('BEGIN TEST: calling plugin get for Jinja2Loader')
    var_0 = Jinja2Loader('type', 'class', '', '', '')
    # test_case_0
    try:
        var_1 = var_0.get('plugin_name', '*args')
        assert var_1 == 1
    except AssertionError:
        raise AssertionError('Expected '' but got ' + str(var_1))


# Generated at 2022-06-25 10:14:01.588670
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    assert True, 'Unit test failed: test_PluginLoader_all'

# Generated at 2022-06-25 10:14:03.135161
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    assert get_shell_plugin().name == 'shell', 'Failed to get a valid shell plugin'


# Generated at 2022-06-25 10:14:07.417442
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    var_1 = PluginLoader()
    var_2 = {}
    var_3 = var_1.__setstate__(var_2)
    var_4 = var_1.__getstate__()
    var_5 = 'package'
    var_6 = var_2.get(var_5)
    var_7 = "assertEqual(var_1.__getstate__()['%s'], %s)" % (var_5, var_6)
    assertEqual(var_1.__getstate__()['package'], var_2.get(var_5), var_7)
    var_8 = 'class_name'
    var_9 = var_2.get(var_8)

# Generated at 2022-06-25 10:14:18.244358
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    add_dirs_to_loader('module', [
        '/home/aubrey/ansible-cfg/lib/ansible/modules/cloud/amazon/cloudwatch_logs.py',
        '/home/aubrey/ansible-cfg/lib/ansible/modules/cloud/amazon/sqs.py',
        '/home/aubrey/ansible-cfg/lib/ansible/modules/cloud/amazon/s3_cors.py'
    ])

# Generated at 2022-06-25 10:14:19.202091
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    assert 1 == 1


# Generated at 2022-06-25 10:14:21.888172
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    ps = PluginLoader('', '', '')
    ps.__setstate__(None)


# Generated at 2022-06-25 10:14:22.827814
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert test_case_0() == None


# Generated at 2022-06-25 10:14:24.431269
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert callable(get_shell_plugin)
    assert test_case_0.__closure__


# Generated at 2022-06-25 10:14:29.869268
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():

    test_case_1_name = ' '.join(random.choice(string.ascii_letters + string.digits) for _ in range(10))
    test_case_1_path = ' '.join(random.choice(string.ascii_letters + string.digits) for _ in range(10))
    test_case_1_class_name = ' '.join(random.choice(string.ascii_letters + string.digits) for _ in range(10))
    test_case_1_plugin_loader = Jinja2Loader(test_case_1_name, test_case_1_path, test_case_1_class_name)
    test_case_1_name = ' '.join(random.choice(string.ascii_letters + string.digits) for _ in range(10))
    test

# Generated at 2022-06-25 10:15:11.978616
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    ctx = ansible_context()
    var_1 = PluginLoader('action', 'action', 'Test')

    if ctx.config.option.test_case == "0":
        test_case_0()


# Generated at 2022-06-25 10:15:12.918115
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    test_case_0()



# Generated at 2022-06-25 10:15:17.750469
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    assert add_all_plugin_dirs('./lib/ansible/plugins/lookup') == None
    assert add_all_plugin_dirs('/lib/ansible/plugins/shell') == None


# Generated at 2022-06-25 10:15:25.640480
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    var_0 = get_shell_plugin('sh')
    var_1 = get_shell_plugin('sh', '/bin/bash')
    var_2 = get_shell_plugin('sh', 'c:/windows/system32/cmd.exe')
    var_3 = get_shell_plugin('sh', 'c:/windows/system32/cmd.exe')
    var_4 = get_shell_plugin('sh', '/bin/bash')
    var_5 = get_shell_plugin()
    var_6 = get_shell_plugin()
    var_7 = get_shell_plugin('sh')
    var_8 = get_shell_plugin('sh', '/bin/bash')
    var_9 = get_shell_plugin()
    var_10 = get_shell_plugin()
    var_11 = get_shell_plugin('sh')


# Generated at 2022-06-25 10:15:30.962855
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    var_0 = plugin_load_context = PluginLoadContext()
    var_1 = plugin_load_context.record_deprecation(None,None,None)
    var_2 = True if var_0 == var_1 else False
    var_3 = "Assertion failed"
    if var_2:
        var_4 = "Assertion passed"
    print(var_4)


# Generated at 2022-06-25 10:15:32.663227
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Create an instance of PluginLoader for testing
    PL = PluginLoader(package='', class_name='', base_class='', config_base='')
    PL.all()


# Generated at 2022-06-25 10:15:39.215699
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    try:
        pl = PluginLoader('action_plugin', 'ActionBase', 'action', '_action')
        var_0 = pl.find_plugin_with_context('setup')
        assert var_0.plugin_resolved_name == 'setup'
        assert var_0.plugin_resolved_path == '/var/folders/qx/1mzvky653mzdwxzdhcj7l0r80000gn/T/ansible-temp-1537641391.899797-23377-187655404021222/ansible/plugins/action/setup.py'
        assert var_0.resolved == True
    except Exception:
        assert False


# Generated at 2022-06-25 10:15:42.090628
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Check behavior for string input
    for i in ['a','b','c','d','e','f','g','h']:
        path = i
        add_all_plugin_dirs(path)
    # Check behavior for int input
    for i in [1,2,3,4,5,6,7,8]:
        path = i
        add_all_plugin_dirs(path)


# Generated at 2022-06-25 10:15:44.036901
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():

    # Global variable to hold the test result
    result = True

    # Determine the test result
    if result is True:
        print(Fore.GREEN + "Test passed")
    else:
        print(Fore.RED + "Test failed")


# Generated at 2022-06-25 10:15:48.797883
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    var_0 = Jinja2Loader('ansible.plugins.cache', 'CacheModule', None)
    try:
        var_1 = var_0.get('base')
    except Exception as e:
        display.display('Exception in Jinja2Loader.get: Caught exception "%s"' % to_text(e))


# Generated at 2022-06-25 10:16:25.679227
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_0 = PluginLoader()

# Generated at 2022-06-25 10:16:27.377695
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    assert callable(PluginLoader.all)


# Generated at 2022-06-25 10:16:28.995753
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    mock_path = "/home/mock_path"
    add_all_plugin_dirs(mock_path)


# Generated at 2022-06-25 10:16:30.737335
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    for name, obj in get_all_plugin_loaders():
        assert obj.subdir is not None


# Generated at 2022-06-25 10:16:33.333447
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    var_0 = PluginLoader('action_plugin')
    var_1 = var_0.get_with_context('win_file')


# Generated at 2022-06-25 10:16:36.011885
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    try:
        test_case_0()
    except Exception as e:
        print(e.args)
        print('Exception raised in test_get_shell_plugin')
        return False

    return True

# main test

# Generated at 2022-06-25 10:16:38.424725
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    var_0 = PluginLoadContext()
    # var_0.record_deprecation()


# Generated at 2022-06-25 10:16:40.334642
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    var_0 = PluginLoader.__contains__()


# Generated at 2022-06-25 10:16:42.178647
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    var_0 = get_shell_plugin()


# Generated at 2022-06-25 10:16:43.888988
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell_loader = None
    shell_type=None
    executable=None
    test_case_0()


# Generated at 2022-06-25 10:17:59.967623
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():

    loader = PluginLoader(package='ansible.plugins.connection', base_class='ConnectionBase')

    path = loader.find_plugin('local')

    assert path.endswith('/ansible/plugins/connection/local.py')


# Generated at 2022-06-25 10:18:01.431190
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    assert isinstance(test_case_0(), PluginLoader)


# Generated at 2022-06-25 10:18:02.589630
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    assert (test_case_0() == None)


# Generated at 2022-06-25 10:18:03.865197
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    var_0 = get_shell_plugin()
    add_all_plugin_dirs(var_0)



# Generated at 2022-06-25 10:18:07.881072
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # return instance of class PluginLoader
    obj = PluginLoader(class_name='ActionModule', package='ansible.plugins.action', config_base=None, config_prefix=None, directories=None, aliases=None)

    # call method get_with_context of the class PluginLoader
    result = obj.get_with_context(name='copy')
    assert isinstance(result, object)


# Generated at 2022-06-25 10:18:10.022572
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    pl = PluginLoader(package='test_package')
    assert(pl.find_plugin('test_name') == None)


# Generated at 2022-06-25 10:18:12.149759
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    try:
        test_case_0()
    except Exception as e:
        print('Failed to load plugin: %s' % repr(e))
        raise


# Generated at 2022-06-25 10:18:15.533810
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    pl = PluginLoader(package='ansible_collections.test.test_fixtures.bar', class_name='TestBar')
    pl.find_plugin_with_context('test_bar')


# Generated at 2022-06-25 10:18:19.566222
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    p = PluginLoadContext()
    p.record_deprecation("plugin_name", deprecation={"warning_text": "Some warning",
                                                     "removal_date": "Some removal_date"},
                         collection_name="random_collection")
    assert isinstance(p.removal_date, str)
    assert isinstance(p.deprecation_warnings[0], str)


# Generated at 2022-06-25 10:18:28.656811
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    from ansible.plugins.test.test_module_utils import get_test_module_loader_plugin_loader
    var_0 = get_test_module_loader_plugin_loader()

    var_1 = "test_module_0"
    try:
        var_0.__contains__(var_1)
    except Exception as var_2:
        var_3 = var_2
        var_4 = False
        var_5 = isinstance(var_3, AnsibleError)
        var_6 = var_4
        var_7 = var_5
    else:
        var_8 = True
        var_6 = var_8
        var_7 = var_8

    assert var_6 is var_7


# Generated at 2022-06-25 10:19:26.540513
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    "Unit test method find_plugin"
    var_0 = PluginLoader(package='ansible.plugins.vars', class_name='VarsModule', base_class='VarsModule')
    var_1 = var_0.find_plugin(name='test')
    assert var_1 == None

    var_2 = var_0.find_plugin(name='test', collection_list='test')
    assert var_2 == None

    var_3 = var_0.find_plugin(name='test', collection_list='test')
    assert var_3 == None

    var_4 = var_0.find_plugin(name='test', collection_list='test')
    assert var_4 == None



# Generated at 2022-06-25 10:19:30.696417
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    try:
        test_case_0()
    except Exception as e:
        print('FAILURE: get_shell_plugin() raised exception: "%s"' % to_native(e))
    else:
        print('SUCCESS: get_shell_plugin() did not raise exception')



# Generated at 2022-06-25 10:19:33.155721
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    with pytest.raises(AnsibleError) as err:
        get_shell_plugin()

    assert "No code should call" in to_text(err.value)


# Generated at 2022-06-25 10:19:35.022868
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    answer_0 = 'sh'
    assert get_shell_plugin().SHELL_FAMILY == answer_0



# Generated at 2022-06-25 10:19:38.580449
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    var_0 = os.path.abspath('test')
    var_1 = add_all_plugin_dirs(var_0)
    var_2 = get_all_plugin_loaders()
    var_3 = [(var_4, var_5) for (var_4, var_5) in globals().items() if isinstance(var_5, PluginLoader)]
    


# Generated at 2022-06-25 10:19:44.022549
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    b_path = "~/test_s"
    try:
        f = open(os.path.expanduser(to_bytes(b_path, errors='surrogate_or_strict')), 'w')
        f.close()
        f = open(os.path.expanduser(to_bytes(b_path + "/test", errors='surrogate_or_strict')), 'w')
        f.close()
        add_all_plugin_dirs(b_path)
    finally:
        if os.path.exists(os.path.expanduser(to_bytes(b_path, errors='surrogate_or_strict'))):
            os.remove(os.path.expanduser(to_bytes(b_path, errors='surrogate_or_strict')))
       

# Generated at 2022-06-25 10:19:45.903435
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    var_0 = PluginLoader('', '', '', '', '', '')
    var_1 = None
    var_1 = var_0.get_with_context(var_1)


# Generated at 2022-06-25 10:19:50.599955
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():

    # globals defined in tests by calling:
    # from ansible.plugins.loader import *
    # from ansible.plugins.loader import _get_all_plugin_loaders
    global _plugin_loaders, _PLUGIN_PATH_CACHE

    _ = os.environ.pop('ANSIBLE_STRICT_COLLECTIONS', None)

    # init defaults
    loaders = _get_all_plugin_loaders()

    # init test context
    tmp_dir = tempfile.mkdtemp()

    # init plugin paths

# Generated at 2022-06-25 10:19:52.615412
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    var_1 = PluginLoader()
    var_2 = var_1.get_with_context(name='shell')
    assert isinstance(var_2, get_with_context_result)


# Generated at 2022-06-25 10:20:01.890657
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    from ansible.constants import COLLECTIONS_PATHS
    from ansible.utils.collection_loader import _get_collection_data_from_path

    # In this test method, we use /tmp/test_collection_1, /tmp/test_collection_2 as the collection path.
    # the collection paths should be removed after the test.
    if os.path.exists('/tmp/test_collection_1') or os.path.exists('/tmp/test_collection_2'):
        raise Exception("test_collection_1 or test_collection_2 exists, which conflicts with the unit test!")

    col1_root = '/tmp/test_collection_1'
    col2_root = '/tmp/test_collection_2'
    collection_name = 'test_namespace.test_collection'