

# Generated at 2022-06-25 10:13:52.468930
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    var_1 = to_bytes('path')
    var_2 = 'dirs'
    var_2 = filter(test_case_0, var_2)
    var_1 = any(var_2)
    return var_1


# Generated at 2022-06-25 10:14:00.940553
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.plugins.lookup.fileglob import LookupModule

    # add dir that contains collection
    collection_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..', '..', '..', 'test', 'sanity', 'collection', 'ansible_collections', 'test_ns', 'test_coll')
    AnsibleCollectionLoader().add_directory(collection_dir)

    # add dir that contains lookup plugin
    lookup_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..', '..', '..', 'lib', 'ansible', 'plugins', 'lookup')
    add_dirs_to_

# Generated at 2022-06-25 10:14:02.736426
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    var_5 = 'shell'
    add_dirs_to_loader(var_5, ['/etc/ansible/plugins'])


# Generated at 2022-06-25 10:14:03.763502
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    var_0 = test_case_0()
    var_1 = var_0.get('')


# Generated at 2022-06-25 10:14:10.590301
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert hasattr(sys.modules[__name__], '%s_loader' % 'cache')
    var_0 = getattr(sys.modules[__name__], '%s_loader' % 'cache')
    var_0.all
    var_0.add_directory
    assert hasattr(sys.modules[__name__], '%s_loader' % 'lookup')
    var_0 = getattr(sys.modules[__name__], '%s_loader' % 'lookup')
    var_0.all
    var_0.add_directory
    assert hasattr(sys.modules[__name__], '%s_loader' % 'shell')
    var_0 = getattr(sys.modules[__name__], '%s_loader' % 'shell')
    var_0.all

# Generated at 2022-06-25 10:14:13.237818
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    assert add_all_plugin_dirs() == "", True


# Generated at 2022-06-25 10:14:19.039294
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Ensure that the PluginLoader is working
    p = PluginLoader("action", "ActionModule", "#", 'plugins', required_base_class='ActionBase')
    p.add_directory("foo")
    p.add_directory("bar")
    p.get_with_context("ping")


# Generated at 2022-06-25 10:14:25.217486
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    path = './tests/unit/module_utils/basic.py'
    plugin = PluginLoader('module_utils', 'BasicModuleUtil', '', '.')
    obj = plugin.get_with_context(path)
    assert isinstance(obj, get_with_context_result)
    assert obj.plugin_load_context.resolved
    module = obj.object
    assert isinstance(module, BasicModuleUtil)


# Generated at 2022-06-25 10:14:28.707991
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    path = 'var_0/var_1/var_2'
    test_case_0()

    return True


# Generated at 2022-06-25 10:14:35.805683
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_1 = PluginLoader('action')
    var_5 = var_1.all()
    assert(isinstance(var_5, (types.GeneratorType, types.GeneratorType)))
    for var_6 in var_5:
        assert(isinstance(var_6, ActionModule))
        assert(var_6._load_name)
        assert(var_6._original_path)
        assert(var_6._redirected_names)
    var_7 = var_1.all(class_only=True)
    assert(isinstance(var_7, (types.GeneratorType, types.GeneratorType)))
    for var_6 in var_7:
        assert(isinstance(var_6, type))
    var_8 = var_1.all(path_only=True)

# Generated at 2022-06-25 10:15:01.114607
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    var_0 = get_shell_plugin()


# Generated at 2022-06-25 10:15:10.724783
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    var_0 = PluginLoadContext()

    deprecation_1 = { 'warning_text': "This will happen to your grandchildren." }
    result = var_0.record_deprecation('name_1', deprecation_1)


    assert not var_0.deprecated
    assert var_0.removal_date is None
    assert var_0.removal_version is None
    assert len(var_0.deprecation_warnings) == 0

    var_0.deprecated = True
    var_0.removal_date = 'some date'
    var_0.removal_version = 'some version'
    var_0.deprecation_warnings.append('Some warning text')

    deprecation_2 = { 'warning_text': "This is an extra warning." }
    result = var_0

# Generated at 2022-06-25 10:15:11.586706
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    var_0 = get_shell_plugin()
    assert var_0 is not None


# Generated at 2022-06-25 10:15:21.465780
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_0 = get_shell_plugin()
    var_1 = var_0.all()

    for var_2 in var_1:
        var_3 = var_2.run()
        var_4 = getattr(var_2, 'STDOUT')
        var_5 = var_4.splitlines()
        var_6 = getattr(var_2, 'STDERR')
        var_7 = var_5
        var_8 = len(var_7)
        var_9 = var_6.splitlines()
        var_10 = var_8

        # Get the sublist of lists [0:9]
        var_11 = var_7[0:10]
        var_12 = var_10
        var_13 = var_9[0:10]
        var_14 = var_12

        # Get

# Generated at 2022-06-25 10:15:23.261612
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    path = "/tmp"
    assert add_all_plugin_dirs(path) == None, "Expected function to return None"


# Generated at 2022-06-25 10:15:25.406590
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Needed to initialise PluginLoader with default values
    get_shell_plugin()
    assert PluginLoader.find_plugin('test_case_0') == test_case_0

# Generated at 2022-06-25 10:15:30.089893
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    from unittest import mock
    from ansible.plugins.loader import get_shell_plugin, Jinja2Loader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-25 10:15:34.176981
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    def test_case_0(obj):
        for i in obj.all():
            pass
        for i in obj.all(class_only=True):
            pass
        for i in obj.all(path_only=True):
            pass
    obj = PluginLoader('foo')
    test_case_0(obj)


# Generated at 2022-06-25 10:15:43.533142
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    global _PLUGIN_PATH_CACHE

    monkeypatch.delitem(sys.modules, 'ansible.plugins.filter.core', raising=False)
    monkeypatch.delitem(sys.modules, 'ansible.plugins.filter.core.abs', raising=False)
    monkeypatch.delitem(sys.modules, 'ansible.plugins.filter.file', raising=False)
    monkeypatch.delitem(sys.modules, 'ansible.plugins.filter.logic', raising=False)

    loader = Jinja2Loader('filter', 'ansible.plugins.filter')
    _PLUGIN_PATH_CACHE = {}

    # Call method all
    var_all_return_value = loader.all()

    # Test return value type
    assert isinstance(var_all_return_value, types.GeneratorType)

# Generated at 2022-06-25 10:15:46.781065
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    plugin_loader = get_cache_plugin()
    plugin_loader.all()
    print('Unit test for method all of class PluginLoader: PASSED')


# Generated at 2022-06-25 10:16:19.683761
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # FIXME: This fails on 2.7, why?
    if sys.version_info[0] == 2:
        pytest.skip("Test is currently known to fail in Python 2.7")

    try:
        import ansible.plugins.action.synchronize
    except ImportError:
        pytest.skip("Skipping test as synchronize plugin does not exist")
    # FIXME: Test assumes that synchronize plugin is implemented
    #   import ansible.plugins.action.synchronize
    #   Test is currently known to fail in Python 2.7
    plugin_load_context = ansible.plugins.action.synchronize.PluginLoader.get_with_context('synchronize')
    assert isinstance(plugin_load_context.object, ansible.plugins.action.synchronize.ActionModule)


# Generated at 2022-06-25 10:16:20.965870
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_0 = PluginLoader('ansible.playbook')
    var_0.all()



# Generated at 2022-06-25 10:16:25.077524
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    all_plugin_loaders = get_all_plugin_loaders()
    var_0 = all_plugin_loaders[0]
    var_1 = var_0.find_plugin_with_context('test', collection_list=None)
    var_2 = var_1.resolved
    var_3 = var_2()


# Generated at 2022-06-25 10:16:34.588516
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():

    # Definition of local variable 'plugin_load_context'
    plugin_load_context = AnsiblePluginLoader.PluginLoadContext()

    # Call to get_all_plugin_loaders() with arguments ()
    get_all_plugin_loaders()

    # Definition of local variable 'plugin_loader'
    var_0 = PluginLoader('connection', 'Connection', package='ansible.plugins.connection', config_base_class=None, base_class=None)

    # Declaration of variable 'name'
    var_1 = None

    # Call to find_plugin_with_context(...): (line 60)
    # Processing the call arguments (line 60)
    var_1 = 'salt'
    # Processing the call keyword arguments (line 60)
    kwargs_0 = {}
    # Getting the type of 'plugin_load_context' (

# Generated at 2022-06-25 10:16:44.237826
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # path_only and class_only are mutually exclusive
    plugin_loader = Jinja2Loader('ansible.plugins.filter.core', '/home/vagrant/python/plugins/filter/core/')
    name = 'core'
    args = []
    kwargs = {}
    kwargs['path_only'] = ''
    kwargs['class_only'] = ''
    with pytest.raises(AnsibleError) as excinfo:
        plugin_loader.get(name, *args, **kwargs)
    assert 'Do not set both path_only and class_only when calling PluginLoader.all()' in to_text(excinfo.value)


# Generated at 2022-06-25 10:16:50.608026
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    '''
    Unit test for method find_plugin of class PluginLoader
    '''

    # FIXME: this test is not sufficient to test the logic caching in case of error
    #        but it is hard to run into the cache, because it is short-lived

    # Plugins should not be found in the following two directories
    cache_dir = os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible_plugin_cache')
    os.makedirs(cache_dir, exist_ok=True)
    with open(os.path.join(cache_dir, 'dummy_plugin.py'), 'w') as f:
        f.write('import ansible.plugins\n')

# Generated at 2022-06-25 10:16:52.549866
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    loader = PluginLoader()

    assert loader.find_plugin('dummy') is None


# Generated at 2022-06-25 10:17:00.751879
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    jinja2loader = get_all_plugin_loaders()[1]

    # test_case_0
    var_1 = jinja2loader.find_plugin('ansible.legacy.plugins.filter.debug')
    # assert (str(var_1) == 'ansible.legacy.plugins.filter.debug')

    # test_case_1
    var_2 = jinja2loader.find_plugin('ansible.legacy.plugins.filter.debug',collection_list=None)
    # assert (str(var_2) == 'ansible.legacy.plugins.filter.debug')

    # test_case_2
    var_3 = jinja2loader.find_plugin('ansible.legacy.plugins.filter.debug',collection_list=None)
    # assert not (str(var_

# Generated at 2022-06-25 10:17:01.693606
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    assert True


# Generated at 2022-06-25 10:17:10.057505
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test 1: Instantiate PluginLoader class with empty params
    # Expect plugin_load_context.resolved=false
    var_1 = PluginLoader('filter_loader', 'ansible.plugins.filter_loader', C.DEFAULT_FILTER_PLUGIN_PATH, 'FilterModule')
    try:
        var_2 = var_1.find_plugin_with_context(plugin_name='', collection_list=None)
        assert False
    except Exception as ex:
        if isinstance(ex, AnsibleError):
            raise
        # log and continue, likely an innocuous type/package loading failure in collections import
        display.debug('find_plugin_with_context error: {0}'.format(to_text(ex)))



# Generated at 2022-06-25 10:18:20.901202
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    case_number = 2
    try:
        var_1 = PluginLoader(
            u'filter_loader',
            u'ansible.plugins.filter.core',
            'FilterModule',
            C.DEFAULT_FILTER_PLUGIN_PATH,
        )
        var_2 = PluginLoader(
            u'action_loader',
            u'ansible.plugins.action',
            'ActionModule',
            C.ACTION_PLUGIN_PATH,
        )
        var_3 = PluginLoader(
            u'connection_loader',
            u'ansible.plugins.connection',
            'Connection',
            C.CONNECTION_PLUGIN_PATH,
        )
    except Exception as var_4:
        display.display(u'Exception caught: {0}'.format(var_4))
        raise



# Generated at 2022-06-25 10:18:25.882079
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    v0 = PluginLoader('fake', config={})
    v1 = '/etc/ansible/collections/ansible_collections/netapp/ontap/plugins/modules'
    try:
        v2 = v0.add_directory(v1)
    except Exception:
        print(str(v2))


# Generated at 2022-06-25 10:18:27.564346
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    assert get_all_plugin_loaders() is not None


# Generated at 2022-06-25 10:18:36.348524
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    loader_0 = PluginLoader('action', 'ActionModule')
    loader_0.get_with_context('nonexistent.action')
    loader_1 = PluginLoader('filter', 'FilterModule')
    loader_1.get_with_context('nonexistent.filter')
    loader_2 = PluginLoader('cache', 'CacheModule')
    loader_2.get_with_context('nonexistent.cache')
    loader_3 = PluginLoader('lookup', 'LookupModule')
    loader_3.get_with_context('nonexistent.lookup')
    loader_4 = PluginLoader('netconf_connection', 'Connection')
    loader_4.get_with_context('nonexistent.netconf_connection')
    loader_5 = PluginLoader('connection', 'Connection')

# Generated at 2022-06-25 10:18:43.163847
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Initialize a PluginLoader object to test
    plugin_loader = PluginLoader('ansible.plugins.action')
    # Create a mock plugin
    class TestPlugin(object):
        def __init__(self, *args, **kwargs):
            pass
    path = '/tmp/test_plugin.py'
    name = 'test_plugin'
    plugin_loader._module_cache[path] = TestPlugin
    # Test if name is resolved correctly
    for plugin_path in plugin_loader._get_paths():
        plugin_loader._searched_paths.append(plugin_path)
    plugin_load_context = get_with_context_result(TestPlugin, plugin_load_context)
    plugin_load_context.plugin_resolved_name = name
    plugin_load_context.plugin_resolved_path = path


# Generated at 2022-06-25 10:18:45.376490
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    var_0 = PluginLoader("test")

    var_0.add_directory("test/dir")


# Generated at 2022-06-25 10:18:51.335808
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_0 = get_all_plugin_loaders()
    var_1 = var_0[0]
    var_2 = var_1.all(a=1, b='foo')
    var_3 = var_1.all(a=1, b='foo', path_only=True)
    var_4 = var_1.all(a=1, b='foo', class_only=True)

# Generated at 2022-06-25 10:18:55.505944
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    PL = PluginLoader('foo', package='ansible.plugins')
    PL._get_paths = get_all_plugin_paths
    assert PL.find_plugin('nop') == 'ansible.plugins.action.nop'
    assert PL.find_plugin('core') == 'ansible.plugins.core.nop'


# Generated at 2022-06-25 10:18:57.612070
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    var_1 = PluginLoadContext()
    var_1.record_deprecation('PluginCache', None, 'null')
    assert var_1.deprecated is False


# Generated at 2022-06-25 10:18:59.148196
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test for a case where plugin_load_context is None
    # Define var_1
    pass
