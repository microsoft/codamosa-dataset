

# Generated at 2022-06-25 10:12:39.030336
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell_type = None
    executable = None

    var_0 = get_shell_plugin()

    assert var_0 is not None

    var_1 = get_shell_plugin('')

    assert var_1 is not None




# Generated at 2022-06-25 10:12:41.939404
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_0 = PluginLoader('filter_loader', 'FilterModule', 'ansible.plugins.filter.core')
    var_1 = var_0.all()
    assert not inspect.isgenerator(var_1)
    var_1 = var_0.all(path_only=True)
    assert not inspect.isgenerator(var_1)


# Generated at 2022-06-25 10:12:49.173097
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    import ansible.parsing.dataloader
    import ansible.plugins.loader
    loader = ansible.plugins.loader.PluginLoader('shell', 'ansible.plugins.shells')
    loader.add_directory(os.path.join(os.path.dirname(__file__), 'shells'))
    test_case_0()



# Generated at 2022-06-25 10:12:52.328245
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    C.DEFAULT_DEBUG = False
    f = PluginLoader(None, '', '', '', '').find_plugin_with_context('')
    assert isinstance(f, PluginLoaderContext)


# Generated at 2022-06-25 10:12:56.255285
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    path = os.path.expanduser('~/.ansible/plugins/modules')
    if os.path.isdir(path):
        add_all_plugin_dirs(path)
    # Testing
    assert test_case_0()



# Generated at 2022-06-25 10:13:05.809347
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    var_0 = PluginLoadContext()
    var_1 = get_shell_plugin()
    var_2 = var_0.record_deprecation(var_1, None, None)
    var_3 = var_0.record_deprecation(var_1, {}, None)
    var_4 = var_0.record_deprecation(var_1, None, "")
    var_5 = var_0.record_deprecation(var_1, {'warning_text': None}, "")
    var_6 = var_0.record_deprecation(var_1, {'warning_text': ""}, "")
    var_7 = var_0.record_deprecation(var_1, {"warning_text": None}, "")

# Generated at 2022-06-25 10:13:10.691690
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    global var_1

    var_1 = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action', 'action_plugins')
    var_2 = var_1.get_with_context('copy')
    var_3 = var_1.get_with_context('script')
    var_4 = var_1.get_with_context('raw')
    var_5 = var_4.resolved
    var_6 = var_4.plugin_resolved_path
    var_7 = var_4.redirect_list
    var_8 = var_4.object
    var_9 = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action', 'action_plugins')
    var_10 = var_9.get_with_context('invalid')
    var_11 = var_

# Generated at 2022-06-25 10:13:17.347972
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    test_case_0()

__all__ = ('PluginLoader', 'get_all_plugin_loaders', 'get_cache_plugin', 'get_connection_plugin', 'get_action_plugin', 'get_module_plugin', 'get_module_utils_path', 'get_module_path', 'get_filter_plugin', 'get_test_plugin', 'get_shell_plugin', 'get_module_loader', 'get_module_utils', 'get_action_loader', 'get_lookup_loader', 'get_filter_loader', 'get_test_loader', 'get_shell_loader')

# Generated at 2022-06-25 10:13:25.855944
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    warning_text = 'This is a deprecation warning'
    deprecation = dict(removal_version=None, warning_text=warning_text)
    instance = PluginLoadContext()
    instance.record_deprecation(instance.plugin_resolved_name, deprecation, instance.plugin_resolved_collection)
    assert (instance.deprecation_warnings[-1] == warning_text)
    assert (instance.deprecated == True)
    assert (instance.removal_date == None)
    assert (instance.removal_version == None)


# Generated at 2022-06-25 10:13:29.385382
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    var_0 = Jinja2Loader('ansible.plugins.action', 'ActionModule', 'ActionBase', '/usr/lib/python2.7/site-packages/ansible/plugins/action')
    var_1 = 'lookup'
    var_2 = var_0.find_plugin(var_1)
    assert var_2 == '/usr/lib/python2.7/site-packages/ansible/plugins/action/lookup.py'


# Generated at 2022-06-25 10:15:20.385303
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_0 = PluginLoader('')
    var_1 = PluginLoader('', '')
    var_2 = PluginLoader('', '', '', '')
    var_3 = PluginLoader('', '', '', '', '')
    # Test for failure of all with unexpected arguments: ex)
    # v = TestClass()
    # v.all(1, 1, 2)
    # Test for failure of all with extra arguments: ex)
    # v = TestClass()
    # v.all(1, 2, 3, 4)


# Generated at 2022-06-25 10:15:27.348341
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    pl = PluginLoader('cache')
    plugin_load_context = pl.find_plugin_with_context('redis')

    assert pl.find_plugin('redis') == 'ansible.plugins.cache.redis'
    assert plugin_load_context.plugin_resolved_name == 'ansible.plugins.cache.redis'
    assert plugin_load_context.plugin_resolved_fqcr == 'ansible.plugins.cache.redis'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/cache/redis.py')


# Generated at 2022-06-25 10:15:36.013597
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # TODO: Test will fail in windows, add tests for windows
    def test_plugin_loader_path_not_in_directory(path_not_in_directory):
        if "ansible_collections" in path_not_in_directory:
            return False
        base_dir = os.path.abspath(path_not_in_directory)
        for _i in get_all_plugin_loaders():
            for _j in _i.get_directory_cache():
                if os.path.abspath(_j.resolved_path) == base_dir:
                    return True
        return False

    plug_loader: PluginLoader = get_plugin_loader(package='action')


# Generated at 2022-06-25 10:15:46.353023
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    suggest = ji['test_ansible_module_utils.basic']['test_ansible_module_utils']['test_plugin_loader']['test_add_all_plugin_dirs']
    var_0 = get_shell_plugin()
    var_1 = suggest[0]['plugin_path']
    var_2 = suggest[1]['plugin_path']
    var_3 = suggest[2]['plugin_path']
    var_0.add_directory(var_1)
    var_0.add_directory(var_2)
    var_0.add_directory(var_3)
    var_0.has_directory(var_1)
    var_0.has_directory(var_2)
    var_0.has_directory(var_3)
    var_0.print_path

# Generated at 2022-06-25 10:15:54.053308
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    var_0 =  PluginLoader(class_name='ActionBase', package='ansible.plugins.action')
    var_0 .find_plugin_with_context('template')
    var_0 =  PluginLoader(class_name='CacheModule', package='ansible.plugins.cache')
    var_0 .find_plugin_with_context('memory')
    var_0 =  PluginLoader(class_name='Cliconf', package='ansible.plugins.connection')
    var_0 .find_plugin_with_context('netconf')
    var_0 =  PluginLoader(class_name='Connection', package='ansible.plugins.connection')
    var_0 .find_plugin_with_context('netconf')
    var_0 =  PluginLoader(class_name='InventoryScript', package='ansible.plugins.inventory')
    var

# Generated at 2022-06-25 10:15:56.129433
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    pl = PluginLoader('_', '_')
    pl.add_directory('_')
    assert pl.package_path == ['_']


# Generated at 2022-06-25 10:16:02.980817
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.module_utils.six import StringIO

    class Obj(object):
        _io = StringIO()
        _io.write('foo')

    # This is just a sample test to validate the correctness of the unit test framework.
    # Please add real tests.
    def test(loader):
        all_plugins = loader.all()
        assert len(all_plugins) > 0
    loader = PluginLoader('shell_plugins', 'ShellModule', 'ansible.plugins.shell', use_cache=False, class_only=True)
    test(loader)


# Generated at 2022-06-25 10:16:13.278780
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Before we use a mock, we have to make sure that C.COLLECTIONS_PATHS is not set,
    # otherwise it will be used and we may not be able to make certain tests.
    # Collections will always be enabled during unit tests, but we want to make sure
    # that the plugin finds are tested against our mocked filesystem.
    #
    # For this particular test, we set ANSIBLE_COLLECTIONS_PATHS to a temp directory
    # which will be ignored by the plugins, but will be used by the collections loader
    # to perform a search there.
    #
    # Note that the above applies to all of the tests that perform plugin loading
    # (not only for this test).

    import tempfile
    col_path = tempfile.mkdtemp()
    C.COLLECTIONS_PATHS = [col_path]

# Generated at 2022-06-25 10:16:15.988011
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    try:
        test_case_0()
        display.vvvv('Passed test case: get_shell_plugin')
    except Exception as e:
        display.vvvv('Failed test case: get_shell_plugin')
        raise e



# Generated at 2022-06-25 10:16:17.539557
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # Tests for the base case
    test_case_0()
    # Tests for the errors case
    test_case_1()


# Generated at 2022-06-25 10:16:44.970049
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    global cache_mgr
    global shell_loader
    global var_0

    cache_mgr = ShellPluginsCacheManager(display)
    shell_loader = PluginLoader("ShellModule", "ansible.plugins.shells", C.DEFAULT_SHELL_PLUGIN_PATH, "shells")
    var_0 = get_shell_plugin(shell_type=None, executable=None)
    add_dirs_to_loader('shell', ['/usr/share/ansible/plugins/shell'])



# Generated at 2022-06-25 10:16:46.392705
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    # Test with mandatory parameters
    print(get_shell_plugin())



# Generated at 2022-06-25 10:16:52.956440
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # test_case_0, /etc/ansible/plugins/shell/__init__.py does not exist
    try:
        add_all_plugin_dirs('/etc/ansible/plugins')
    except Exception as e:
        print(e)
        ret = 1
    else:
        ret = 0
    assert ret == 0


# Generated at 2022-06-25 10:16:56.333889
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    args_0 = "shell"
    var_1 = None
    var_1 = get_all_plugin_loaders().__contains__(args_0)
    assert var_1 is not None, 'var_1 is None'


# Generated at 2022-06-25 10:17:02.630110
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    """Tests add_dirs_to_loader."""
    from ansible.module_utils.common.collections import FunctionLoader
    c = '%s_loader' % 'my_plugin_type'
    vars()[c] = FunctionLoader()
    l = getattr(sys.modules[__name__], c)
    assert isinstance(l, FunctionLoader)
    assert len(sys.modules[__name__]._ansible_collections) == 0
    assert len(sys.modules[__name__]._ansible_collections_paths) == 0
    ansible_dir = os.getenv('ANSIBLE_COLLECTIONS_PATHS')
    if not ansible_dir:
        os.environ['ANSIBLE_COLLECTIONS_PATHS'] = '.:'
    add_dirs_to_

# Generated at 2022-06-25 10:17:03.848372
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    var_0 = add_dirs_to_loader(a, paths=[])


# Generated at 2022-06-25 10:17:06.856732
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    pl = call_with_args(PluginLoader, 'ansible.plugins.filter.async_status', 'connection')
    pl.all(path_only=True, class_only=True)
    pl.all(path_only=False, class_only=True)


# Generated at 2022-06-25 10:17:16.007192
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():

    # this should not raise an exception
    result_0 = PluginLoader.find_plugin('core')
    assert isinstance(result_0, PluginLoader)

    # this should not raise an exception
    result_1 = PluginLoader.find_plugin('lookup')
    assert isinstance(result_1, PluginLoader)

    # this should not raise an exception
    result_2 = PluginLoader.find_plugin('_loader')
    assert isinstance(result_2, PluginLoader)

    # this should not raise an exception
    result_3 = PluginLoader.find_plugin('inventory')
    assert isinstance(result_3, PluginLoader)

    # this should not raise an exception
    result_4 = PluginLoader.find_plugin('connection')
    assert isinstance(result_4, PluginLoader)

    # this should not raise an exception
    result_

# Generated at 2022-06-25 10:17:20.174581
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    try:
        var_0 = PluginLoader( _name="doc_fragment", _paths=[], package="ansible.plugins.action", class_name="ActionModule", base_class="ActionBase")
        var_1 = var_0.find_plugin("mytest")
        assert var_1 == None
        assert var_1 == None
    except Exception as e:
        raise AssertionError("Raised Exception: {0}".format(str(e))) from e


# Generated at 2022-06-25 10:17:26.386713
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_0 = [{'BECOME': u'root', 'BECOME_PROXY_ALL': True, 'BECOME_USER': u'root', 'BECOME_THROUGH_PARENT_SUDO': True, 'BECOME_ALL': True, 'BECOME_METHOD': 'sudo', 'BECOME_PRIVILEGE_ESCALATION': False, 'BECOME_FLAGS': '-H', 'BECOME_ASK_PASS': False}]

# Generated at 2022-06-25 10:18:00.998318
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_0 = PluginLoader(var_1='', var_2='')
    for var_3 in var_0.all():
        pass



# Generated at 2022-06-25 10:18:03.645732
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    ld = PluginLoader
    try:
        var_0 = ld.all()
        assert False
    except NotImplementedError as e:
        assert isinstance(e, NotImplementedError)


# Generated at 2022-06-25 10:18:11.816485
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    from ansible import constants as C
    from ansible.plugins.loader import all_plugin_loaders

    with set_collection_info('ansible.somewhere_else', 'roles'):
        for plugin_loader in all_plugin_loaders:
            # verify find_plugin_with_context throws a PluginNotFoundException when the plugin cannot be found
            with pytest.raises(AnsibleError):
                plugin_loader.find_plugin_with_context('foobar')
            # we can't actually find a module inside a collection, since there are no roles that exist inside a collection
            # however, we can find a module inside ansible which must exist
            plugin_load_context = plugin_loader.find_plugin_with_context('all')
            assert plugin_load_context.resolved
            # verify that we can find plugins in collections

# Generated at 2022-06-25 10:18:15.630372
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    for p in get_shell_plugin().all():
        print(p)
        assert p is not None
    for p in get_connection_plugin().all():
        print(p)
        assert p is not None


# Generated at 2022-06-25 10:18:17.639063
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    var_0 = get_shell_plugin()
    add_all_plugin_dirs('/home/kamel/Workspace/ansible/lib/ansible/plugins/')
    return var_0


# Generated at 2022-06-25 10:18:26.396372
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.six.moves.urllib.request import url2pathname
    plugin_url_path = 'https://raw.githubusercontent.com/nephron/ansible-collection-test/master/plugins/' \
                      'action/test_0.py'
    urls = [plugin_url_path]
    for url in urls:
        display.info("Downloading %s" % url)

# Generated at 2022-06-25 10:18:27.997784
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    add_dirs_to_loader('wrapper', ['location'])


# Generated at 2022-06-25 10:18:29.378044
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    var_0 = get_shell_plugin(plugin_name='ash')


# Generated at 2022-06-25 10:18:32.178036
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    find_plugin_with_context(self, name, aliases=None, collection_list=None, include_core=None, plugin_load_context=None)


# Generated at 2022-06-25 10:18:39.905060
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    var_0 = add_dirs_to_loader()

# Loader object for shell plugins.
shell_loader = PluginLoader(
    'ShellModule',
    'ansible.plugins.shell',
    C.DEFAULT_SHELL_PLUGIN_PATH,
    'shell_plugins',
)

# Loader object for connection plugins.
connection_loader = PluginLoader(
    'Connection',
    'ansible.plugins.connection',
    C.DEFAULT_CONNECTION_PLUGIN_PATH,
    'connection_plugins',
)

# Loader object for cache plugins.
cache_loader = PluginLoader(
    'CacheModule',
    'ansible.plugins.cache',
    C.DEFAULT_CACHE_PLUGIN_PATH,
    'cache_plugins',
)

# Loader object for

# Generated at 2022-06-25 10:19:17.671866
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    var_1 = get_shell_plugin()


# Generated at 2022-06-25 10:19:19.274563
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_0 = PluginLoader('', '', '', '', '', '', '', '', '', '')


# Generated at 2022-06-25 10:19:25.511497
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():

    p = PluginLoader('.', 'test')
    l = p.find_plugin_with_context('test', collection_list=['test_namespace.test_collection'])
    assert l.resolved
    assert l.plugin_resolved_path is not None
    assert l.fqcr is not None
    assert l.fqcr == 'test_namespace.test_collection.test'
    assert l.redirect_list == []

    l = p.find_plugin_with_context('shell', collection_list=['test_namespace.test_collection'])
    assert l.resolved
    assert l.plugin_resolved_path is not None
    assert l.fqcr is not None
    assert l.fqcr == 'ansible.builtin.shell'

# Generated at 2022-06-25 10:19:28.218043
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    var_1 = PluginLoader('', '', '', '', '')

    var_2 = var_1.find_plugin('', '')
    assert var_2 != None, 'find_plugin returned None'



# Generated at 2022-06-25 10:19:32.390929
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    var_0 = PluginLoader('shell_plugins', 'ansible.plugins.shell', C.DEFAULT_SHELL_PLUGIN_PATH, 'shell_plugins')
    var_1 = 'stuff'
    var_0.add_directory(var_1)



# Generated at 2022-06-25 10:19:38.198471
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    if not os.path.isdir(os.path.join(C.DEFAULT_MODULE_PATH, to_bytes('shell'))):
        raise Exception("test_add_all_plugin_dirs:  Failed to find shell plugin directory")         
    add_all_plugin_dirs(C.DEFAULT_MODULE_PATH)
    try:
        test_case_0()
    except:
        raise Exception("test_add_all_plugin_dirs:  Failed to get 'shell' plugin.")
    display.display("test_add_all_plugin_dirs:  Passed")



# Generated at 2022-06-25 10:19:42.830231
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    var_0 = PluginLoader('ansible.plugins.connection')
    var_1 = var_0.find_plugin('local')
    # assert isinstance(var_1, obj)
    var_2 = var_0.find_plugin('network_cli')
    # assert isinstance(var_2, obj)
    var_3 = var_0.find_plugin('network_cli', collection_list=[])
    # assert isinstance(var_3, obj)
    var_4 = var_0.find_plugin('network_cli', collection_list=[], class_only=True)
    # assert isinstance(var_4, obj)


# Generated at 2022-06-25 10:19:48.831288
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    var_0 = get_shell_plugin()
    var_1 = get_shell_plugin()
    var_2 = get_shell_plugin()
    var_3 = get_shell_plugin()
    var_4 = get_shell_plugin()
    var_5 = get_shell_plugin()
    var_6 = get_shell_plugin()
    var_7 = get_shell_plugin()
    var_8 = get_shell_plugin()
    var_9 = get_shell_plugin()
    var_10 = get_shell_plugin()
    var_11 = get_shell_plugin()
    var_12 = get_shell_plugin()
    var_13 = get_shell_plugin()
    var_14 = get_shell_plugin()
    var_15 = get_shell_plugin()
    var_16 = get_

# Generated at 2022-06-25 10:19:50.410799
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    var_1 = C.DEFAULT_MODULE_PATH
    var_2 = add_all_plugin_dirs(var_1)
    assert var_2 == None


# Generated at 2022-06-25 10:19:52.284944
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    try:
        res = add_all_plugin_dirs(var_0)
    except Exception as exception:
        print('exception: ' + str(exception))
        raise
    assert True


# Generated at 2022-06-25 10:20:42.460789
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    var_0 = PluginLoader(package='ansible.plugins.action', directory='/etc/ansible/plugins/action')
    assert isinstance(var_0, object) == True
    var_1 = var_0.add_directory()
    assert  var_1 == None


# Generated at 2022-06-25 10:20:49.686591
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    collection_list = CollectionRequirementList.from_requirements(None)

    # test an unqualified name that is found
    context = PluginLoader('module_utils', package='ansible_collections.testns.subns1.plugins.module_utils').find_plugin_with_context('plugin_template', collection_list=collection_list)
    assert context.resolved
    assert context.plugin_resolved_name == 'plugin_template'
    assert context.plugin_resolved_path == os.path.join(paths.get_module_utils_path(), 'ansible_collections/testns/subns1/plugins/module_utils/plugin_template.py')
    assert context.collection_resolved is None
    assert context.collection is None

    # test an unqualified name that is not found

# Generated at 2022-06-25 10:20:55.160159
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    var_0 = PluginLoader(base_class='BaseFile', class_name='BaseFile', package='ansible.plugins.copy', subdir='files')
    var_1 = AnsibleCollectionRef.parse("ansible_collections.ns.coll_name.plugins.copy.files.test_file")
    var_2 = var_1.parts
    var_3 = var_0._find_fq_plugin(var_2, )
    if (var_3._found):
        var_4 = True
    else:
        var_4 = False
    assert var_4


# Generated at 2022-06-25 10:20:59.871347
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    set_collection_playbook_paths(['/code/ansible-collections/collection_name/dist/collection_name-0.1.0'])
    add_all_plugin_dirs('/code/ansible-collections/collection_name/dist/collection_name-0.1.0/ansible_collections/collection_name/plugins/module_utils')


# Generated at 2022-06-25 10:21:01.347688
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    path = "path"
    res = add_all_plugin_dirs(path)
    assert res is None


# Generated at 2022-06-25 10:21:02.631187
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    paths = []
    add_dirs_to_loader(paths)


# Generated at 2022-06-25 10:21:09.581028
# Unit test for method find_plugin_with_context of class PluginLoader

# Generated at 2022-06-25 10:21:13.215744
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    with mock.patch.object(Display, 'warning', autospec=True) as mocked_warning:
        path = '/mocked_path'
        with mock.patch('os.path.isdir') as mocked_isdir:
            mocked_isdir.return_value = False
            add_all_plugin_dirs(path)
            mocked_isdir.assert_called_once_with('/mocked_path')
            mocked_warning.assert_called_once_with("Ignoring invalid path provided to plugin path: '%s' is not a directory" % to_text(path))


# Generated at 2022-06-25 10:21:20.449961
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    """Check to see if the addition of two directories works"""
    assert len(get_all_plugin_loaders()) == 5 # Right now, the core has 5 plugin loaders.  Need to update this with
                                             # the addition of new plugins
    assert get_action_plugin()._directories == [C.DEFAULT_ACTION_PLUGIN_PATH]
    assert get_connection_plugin()._directories == [C.DEFAULT_CONNECTION_PLUGIN_PATH]
    assert get_cache_plugin()._directories == [C.DEFAULT_CACHE_PLUGIN_PATH]
    assert get_shell_plugin()._directories == [C.DEFAULT_SHELL_PLUGIN_PATH]

# Generated at 2022-06-25 10:21:27.381575
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    from ansible.utils.encrypt import has_pkcs7_key
    from ansible.utils.encrypt import has_key

    loader = PluginLoader("shell_interface", "ShellModule")
    assert loader.has_plugin('csh')
    assert loader.has_plugin('sh')
    assert not loader.has_plugin('invalid')

    loader = PluginLoader("action", "ActionModule")
    assert loader.has_plugin('command')

    assert not has_pkcs7_key(None)
    assert not has_key(None)


if __name__ == '__main__':
    test_PluginLoader_find_plugin_with_context()