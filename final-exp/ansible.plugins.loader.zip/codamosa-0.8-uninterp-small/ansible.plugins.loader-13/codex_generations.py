

# Generated at 2022-06-25 10:12:43.917413
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # TODO: Try to refactor test cases to make them more readable
    plugin_load_context_0 = PluginLoadContext(False)

    # Test case 1: PluginLoader.find_plugin with prefix ansible_collections.foo.bar.plugins.module_utils.
    # Test issue ANSIBLE_MODULE_UTILS_PATH is set to None.
    plugin_load_context_0.replace_attribute('plugin_resolved_name', 'ansible_collections.foo.bar.plugins.module_utils.foo')
    plugin_load_context_0.replace_attribute('plugin_resolved_path', '/bogus/path/to/foo/module_utils.py')
    plugin_load_context_0.replace_attribute('resolved', True)
    # The call to PluginLoader.find_plugin is expected to return plugin_

# Generated at 2022-06-25 10:12:56.127396
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    all_instance_loader = PluginLoader(package="ansible.plugins.action", base_class="ActionBase", class_name="ActionModule")
    all_instance_iter = all_instance_loader.all()
    next(all_instance_iter)

    all_class_loader = PluginLoader(package="ansible.plugins.action", base_class="ActionBase", class_name="ActionModule")
    all_class_iter = all_class_loader.all(class_only=True)
    next(all_class_iter)

    all_path_loader = PluginLoader(package="ansible.plugins.action", base_class="ActionBase", class_name="ActionModule")
    all_path_iter = all_path_loader.all(path_only=True)
    next(all_path_iter)



# Generated at 2022-06-25 10:13:06.792950
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():

    # Add missing 'tests' dir to sys.path so we can import test_utils
    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    test_utils_dir = os.path.join(base_dir, 'test', 'units')
    sys.path.append(test_utils_dir)

    from test_utils import wrap_var, wrap_text
    from test_utils import TestData
    from test_utils import TestFailure
    from test_utils import TestSuccess
    from test_utils import TestSkipped

    result = TestSuccess(wrap_var("test_PluginLoader.add_directory()"))
    result.add_test("PluginLoader class exists", "assert type(PluginLoader) == type")

# Generated at 2022-06-25 10:13:18.144426
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    plugin_load_context_0 = PluginLoadContext()
    mock_get_with_context_result_0 = get_with_context_result(None, plugin_load_context_0)
    mock_plugin_load_context_0 = PluginLoadContext()
    mock_str_0 = '<ansible_collections.ansible.netcommon.plugins.action.iosxr_command>'
    mock_str_1 = '<ansible_collections.ansible.netcommon.plugins.action.iosxr_command>'
    mock_str_2 = '<ansible_collections.ansible.netcommon.plugins.action.iosxr_command>'
    mock_str_3 = '<ansible_collections.ansible.netcommon.plugins.action.iosxr_command>'
    mock_str_

# Generated at 2022-06-25 10:13:23.473676
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    paths = ['/home/sam/project/ansible/lib/ansible/plugins/callback']
    which_loader = 'callback'
    add_dirs_to_loader(which_loader, paths)


# Generated at 2022-06-25 10:13:31.231354
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # FIXME: Fails if the environment variable is set:
    # ANSIBLE_CONFIG=ansible.cfg ansible-test sanity --docker -v --python 2.7 --test-module-path=test/modules
    # This would be fixed by changing the signature as discussed above
    # module_loader = PluginLoader('module_utils', 'module_name')
    # for plugin in module_loader.all():
    #    pass
    pass


# Generated at 2022-06-25 10:13:40.782461
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    test_dir = "/tmp/test_dir"
    try:
        os.makedirs(test_dir)
        try:
            test_file_path_1 = os.path.join(test_dir, "test_file_1")
            with open(test_file_path_1, "w") as f:
                f.write("hello")
            add_dirs_to_loader("action", [test_dir])
            assert action_loader.get("test_file_1")
        finally:
            os.remove(test_file_path_1)
            os.rmdir(test_dir)
    finally:
        action_loader = PluginLoader("Action", "ActionModule", C.DEFAULT_ACTION_PLUGIN_PATH, "action_plugins")


# Generated at 2022-06-25 10:13:43.884855
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    pr_0 = PluginLoader(None, None)
    pr_1 = PluginLoader(None, None)
    pr_1.__setstate__({})


# Generated at 2022-06-25 10:13:47.078650
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    plugin_loader_0 = PluginLoader(package='ansible.plugins.module_utils', class_name='ActionModule')
    assert plugin_loader_0.has_plugin(name='ping')


# Generated at 2022-06-25 10:13:55.541438
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    class TestPluginLoader(PluginLoader):
        def __init__(self, class_name, subdir, *args, **kwargs):
            self.class_name = class_name
            self.subdir = subdir
            super(TestPluginLoader, self).__init__(*args, **kwargs)

    class TestModulePluginLoader(TestPluginLoader):
        subdir = 'test-module-plugin-loader'

    module_plugin_loader = TestModulePluginLoader('TestModulePluginLoader', 'test-module-plugin-loader')

    class TestActionPluginLoader(TestPluginLoader):
        subdir = 'test-action-plugin-loader'

    action_plugin_loader = TestActionPluginLoader('TestActionPluginLoader', 'test-action-plugin-loader')


# Generated at 2022-06-25 10:17:11.083704
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    str_0 = '<NONE>'
    add_all_plugin_dirs(str_0)
    # assert that all mandatory plugin types are present
    dict_0 = dict()
    dict_1 = dict()
    for str_1, obj in get_all_plugin_loaders():
        dict_0[str_1] = obj
        # set_default(obj)：Returns the value for the given key if key is in the dictionary, else default.
        dict_1[str_1] = dict_1.setdefault(str_1, 0) + 1
    assert all(dict_1.values()) != 0


# Generated at 2022-06-25 10:17:13.983371
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    int_0 = 1355
    var_0 = get_shell_plugin(int_0)
    var_1 = var_0.all()
    test_0 = not var_1
    assert test_0


# Generated at 2022-06-25 10:17:16.285471
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    int_0 = 1356
    var_0 = PluginLoader("", "", "", "")
    assert var_0.__contains__("test_PluginLoader___contains__")


# Generated at 2022-06-25 10:17:21.976966
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # test_path = 'Ansible/ansible/plugins/action' # should be path to 'action' subdir of ansible/plugins
    test_path = './../ansible/plugins' # should be path to 'action' subdir of ansible/plugins

    add_all_plugin_dirs(test_path)
    # test
    b_test_path = to_bytes(test_path, errors='surrogate_or_strict')
    if os.path.isdir(b_test_path):
        for name, obj in get_all_plugin_loaders():
            if obj.subdir:
                plugin_path = os.path.join(b_test_path, to_bytes(obj.subdir))
                if os.path.isdir(plugin_path):
                    assert plugin_path == obj.get

# Generated at 2022-06-25 10:17:24.631378
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    obj_0 = PluginLoader(1355)
    #FIXME: needs better test data
    var_0 = obj_0.find_plugin('0')


# Generated at 2022-06-25 10:17:26.020842
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    int_0 = 566
    assert True


# Generated at 2022-06-25 10:17:28.296427
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    obj_0 = PluginLoader('ansible.plugins.action')
    obj_0.all()


# Generated at 2022-06-25 10:17:29.437710
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    function_initialization_0(1355)
    test_case_0()


# Generated at 2022-06-25 10:17:29.974850
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    pass


# Generated at 2022-06-25 10:17:31.932848
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    with pytest.raises(AnsibleError) as excinfo:
        pass    # ToDo: Test goes here

