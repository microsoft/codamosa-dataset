

# Generated at 2022-06-25 10:13:39.111932
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():

    var_0 = get_all_plugin_loaders()

    # Call method that contains one or more assertions to verify expected results.
    for item in var_0:
        test_case_0()


# Generated at 2022-06-25 10:13:42.792900
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    """
    Test all method of class PluginLoader
    """
    var_0 = PluginLoader('blah', 'ansible/plugins/blah')
    var_0.all(class_only=True)
    del var_0
    var_0 = PluginLoader('blah', 'ansible/plugins/blah')
    var_0.all(path_only=True)
    del var_0
    var_0 = PluginLoader('blah', 'ansible/plugins/blah')
    var_0.all()


# Generated at 2022-06-25 10:13:45.204893
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_0 = PluginLoader('name')
    var_1 = var_0.all()
    assert isinstance(var_1, types.GeneratorType)



# Generated at 2022-06-25 10:13:54.498723
# Unit test for method find_plugin of class Jinja2Loader

# Generated at 2022-06-25 10:13:55.708751
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():

    loader = _PluginLoader('ActionModule', 'action', 'ansible.plugins.action')
    return loader.all()


# Generated at 2022-06-25 10:14:00.597514
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    ansible_path = "/home/ansible/ansible_local/roles/osquery/tasks/"
    
    # case 0
    add_all_plugin_dirs(ansible_path)
    path = "/home/ansible/ansible_local/roles/osquery/tasks/python"
    if path in PATH_CACHE['module_utils']:
        pass
    else:
        assert False
    path = "/home/ansible/ansible_local/roles/osquery/tasks/callback"
    if path in PATH_CACHE['callback']:
        pass
    else:
        assert False
    path = "/home/ansible/ansible_local/roles/osquery/tasks/shell"
    if path in PATH_CACHE['shell']:
        pass

# Generated at 2022-06-25 10:14:02.989343
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    """
    Test the add_all_plugin_dirs function
    """

    # Test with a valid directory
    try:
        test_dir = os.mkdir('~/ansible_test_dir')
    except OSError:
        assert False, "Unable to create test directory"

    # Test with an invalid directory
    try:
        test_dir = os.mkdir('~/test_test_test')
    except OSError:
        assert True, "OSError thrown as expected"



# Generated at 2022-06-25 10:14:03.985139
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    add_dirs_to_loader('action', ['/usr/lib/ansible/plugins/action'])



# Generated at 2022-06-25 10:14:06.102561
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    plugin = get_shell_plugin(shell_type='sh')
    if plugin.executable is None:
        raise AssertionError("plugin.executable is None")


# Generated at 2022-06-25 10:14:08.175812
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_0 = [(loader.package, loader.subdir) for loader in get_all_plugin_loaders()]
    assert len(var_0) > 0


# Generated at 2022-06-25 10:14:41.205741
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    var_0 = add_all_plugin_dirs(" /etc/ansible/plugins")


# Generated at 2022-06-25 10:14:45.137447
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    filter_loader = PluginLoader('FilterModule', 'ansible.plugins.filter', 'FilterModule', required_base_class='FilterModule')
    my_filter = filter_loader.get('grep', '*')
    assert isinstance(my_filter, FilterModule)
    assert my_filter._load_name == 'grep'


# Generated at 2022-06-25 10:14:45.716499
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    pass


# Generated at 2022-06-25 10:14:55.487124
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():

    # create an object of the class PluginLoader
    obj = PluginLoader('', '', '')

    # Test case where the function calls itself

    # Test case where the function calls itself

    # Test case where the function calls itself

    # Test case where the function calls itself

    # Test case where the function calls itself

    # Test case where the function calls itself

    # Test case where the function calls itself

    # Test case where the function calls itself

    # Test case where the function calls itself

    # Test case where the function calls itself

    # Test case where the function calls itself

    # Test case where the function calls itself

    # Test case where the function calls itself

    # Test case where the function calls itself

    # Test case where the function calls itself

    # Test case where the function calls itself

    # Test case where the function calls itself

    # Test case where the

# Generated at 2022-06-25 10:15:04.574613
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    # Initializing a plugin context
    var_0 = PluginLoadContext()
    # Recording a deprecation warning
    var_0 = var_0.record_deprecation(name = "vars_plugins", deprecation = dict(warning_text = "Deprecated", removal_date = "2021-01-01"), collection_name = "collection_test")
    if (var_0.deprecation_warnings[0] != "vars_plugins has been deprecated. Deprecated"):
        raise ValueError('Unexpected value in deprecation_warnings[0]')
    if (var_0.removal_date != "2021-01-01"):
        raise ValueError('Unexpected value in removal_date')


# Generated at 2022-06-25 10:15:13.788181
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # Unit test for method find_plugin of class Jinja2Loader
    var_0 = '''def find_plugin(name, collection_list=None):\n        \n        if '.' in name:\n            return super(Jinja2Loader, self).find_plugin(name, collection_list=collection_list)\n        \n        # Nothing is currently using this method\n        raise AnsibleError(\'No code should call "find_plugin" for Jinja2Loaders (Not implemented)\')'''
    var_0 = callsite_wrapper(var_0)
    var_0.check_return_type(None)
    var_0.arg_count(2)
    var_0.check_arg_type(1, 'collection_list', 'NoneType')


# Generated at 2022-06-25 10:15:22.178562
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    var_0_0 = 'cipher ciphers'
    var_0_1 = 'module modules'
    var_0_2 = 'module modules'
    var_0_3 = 'module modules'
    var_0_4 = 'module modules'
    var_0_5 = 'module modules'
    var_0_6 = 'module modules'
    var_0_7 = 'module modules'
    var_0_8 = 'module modules'
    var_0_9 = 'module modules'
    var_0_10 = 'module modules'
    var_0_11 = 'module modules'
    var_0_12 = 'module modules'
    var_0_13 = 'module modules'
    var_0_14 = 'module modules'
    var_0_15 = 'module modules'
    var_0

# Generated at 2022-06-25 10:15:23.586532
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell_type = None
    executable = None
    result = get_shell_plugin(shell_type, executable)


# Generated at 2022-06-25 10:15:28.498259
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    p = PluginLoader('test', 'fake_class')
    with patch.object(p, '_get_paths', return_value=[]):
        with patch.object(p, '_load_module_source', side_effect=AnsibleError):
            with pytest.raises(AnsibleError):
                next(p.all)


# Generated at 2022-06-25 10:15:32.893772
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    var_1 = PluginLoadContext()
    var_2 = 'module'
    var_3 = {}
    var_4 = 'collection_name'
    var_5 = var_1.record_deprecation(var_2, var_3, var_4)
    test_case_0()

test_PluginLoadContext_record_deprecation()



# Generated at 2022-06-25 10:16:50.050201
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    import unittest

    from ansible.parsing.plugin_docs import read_docstring

    class PluginLoaderTestCase(unittest.TestCase):

        class Subclass(PluginLoader):
            """ used for testing that class inheritance works properly """
            class_name = 'Subclass '
            base_class = object
            package = 'ansible.plugins.test_case_0'

        def test_nonexistent_plugin_load(self):
            fake_plugin_loader = self.Subclass('fake', 'fake')
            with self.assertRaisesRegex(AnsibleError, r'^cannot find plugin fake in fake\(\)\'$'):
                fake_plugin_loader.find_plugin('fake')


# Generated at 2022-06-25 10:16:52.996344
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    Var_1 = PluginLoader('Var_1', 'Var_1', 'Var_1')
    assert isinstance(Var_1.all(), types.GeneratorType)
test_PluginLoader_all()


# Generated at 2022-06-25 10:16:58.400752
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test case for PluginLoader.get_with_context
    var_0 = PluginLoader(package='ansible.plugins.action', class_name='ActionBase', config_options='action_plugins', subclass_list=None, aliases=None, required_base_class='ActionBase')

# Generated at 2022-06-25 10:17:07.646515
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    global _PLUGIN_LOADERS
    if len(_PLUGIN_LOADERS) == 0:
        # Unit test was not given an initialized plugin cache, so populate it,
        # but with our mock path instead of the real one.
        _PLUGIN_LOADERS = PluginLoader.get_all_plugin_loaders(paths=[os.path.join(os.path.dirname(__file__),
                                                                                'mock_collections', 'ansible_collections')])
        # Add our mock path to the cache, so that any non-mocked plugin loaders
        # can also use it.
        path = os.path.join(os.path.dirname(__file__), 'mock_collections', 'ansible_collections')

# Generated at 2022-06-25 10:17:09.570187
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    assert get_all_plugin_loaders()['vars'].has_plugin(name = 'foo') == False
    assert get_all_plugin_loaders()['vars'].has_plugin(name = 'yum') == True


# Generated at 2022-06-25 10:17:13.982278
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    var_0 = PluginLoader(
        class_name = '',
        package = '',
        config = None,
        subdir = '',
        aliases = '',
        required_base_class = None,
        )
    var_1 = var_0.find_plugin_with_context(
        name = '',
        collection_list = '',
        )


# Generated at 2022-06-25 10:17:18.173669
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    plugin_loader = None
    path_only = True
    class_only = True
    _dedupe = True
    args = None
    kwargs = None
    try:
        # unit tests can't take kwargs, but we'll test the kwargs anyway
        # TODO: add kwargs unit tests
        plugin_loader.all(path_only, class_only, _dedupe, args, kwargs)
    except Exception as ex:
        print(ex)


# Generated at 2022-06-25 10:17:24.880843
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():

    plugin_loader = PluginLoader('test')
    plugin_loader.imported_paths = [os.path.join(os.path.split(__file__)[0], 'test_collection', 'test_plugins')]
    plugin_loader.package = 'test_collection.test_plugins'
    plugin_loader.class_name = 'test_class'
    plugin_loader.base_class = 'BaseClass'

    name = 'test_name'
    args = ['test_arg_0']
    kwargs = {'test_kwarg_0': 'test_kwarg_0'}

    result = plugin_loader.get_with_context(name, *args, **kwargs)
    assert result.resolved
    assert result.plugin_resolved_name == 'test_name'
    assert result.plugin_resolved_

# Generated at 2022-06-25 10:17:28.294460
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    loader = get_plugin_loader()
    obj = loader.get_with_context('setup')
    assert( isinstance(obj, get_all_plugin_loaders()[0]) )


# Generated at 2022-06-25 10:17:29.746975
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    path = 'home/ankita'
    assert os.path.isdir(path) == True



# Generated at 2022-06-25 10:18:21.440756
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    var_0 = PluginLoader('', '', '', '', '')
    var_0.find_plugin = Mock(return_value='test')
    var_0.get_with_context('test')
    assert var_0.find_plugin.call_args == call('test'), "Expected call to %s, but call was %s" % (call('test'), var_0.find_plugin.call_args)


# Generated at 2022-06-25 10:18:23.775690
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    assert(add_all_plugin_dirs('/home/ubuntu/Downloads/test_inventory_plugins'))


# Generated at 2022-06-25 10:18:27.652974
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    pl = PluginLoader('foo', 'bar')
    pl.find_plugin('baz', so_name='libbaz.so')
    pl.find_plugin('test.test_cases.test_PluginLoader_find_plugin.test_case_0')


# Generated at 2022-06-25 10:18:32.936694
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    b_path = os.path.expanduser(to_bytes('/usr/local/bin', errors='surrogate_or_strict'))
    test_case_0()
    res_0 = get_all_plugin_loaders()
    res_x = 0
    if res_0 == var_0:
        res_x = 1
    return res_x

test_add_all_plugin_dirs()



# Generated at 2022-06-25 10:18:40.483510
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Set up mock
    mock_plugin_load_context = MagicMock()
    mock_plugin_load_context.collection = None()
    mock_plugin_load_context.module = None()
    mock_plugin_load_context.name = None()
    mock_plugin_load_context.plugin_type = None()
    mock_plugin_load_context.paths = None
    mock_plugin_load_context.store_result = None
    mock_plugin_load_context.collection = None
    mock_plugin_load_context.plugin_resolved_name = None
    mock_plugin_load_context.plugin_resolved_path = None
    mock_plugin_load_context.nope = MagicMock(side_effect=lambda x: mock_plugin_load_context)


# Generated at 2022-06-25 10:18:48.906701
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Input Parameters
    name = 'None'
    collection_list = 'None'

    # the return of this function is a tuple of expected return and actual return
    # the first item of the tuple is the expected return value
    # the second item of the tuple is the return value of the function under test
    key = 'None'
    expected_return_value = (key,)
    expected_return_value = expected_return_value + (None,)
    
    # function under test
    actual_return_value = find_plugin(name=name,collection_list=collection_list)
    actual_return_value = (actual_return_value,) + (None,)
    
    assert expected_return_value == actual_return_value


# Generated at 2022-06-25 10:18:58.068447
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    fqcn = 'ansible.plugins.action.open_shell'
    my_obj = PluginLoader(package=fqcn)
    assert my_obj is not None

    # test with an invalid value
    result = my_obj.all(0)
    assert result is None

    # test with a valid value
    result = list(my_obj.all())
    assert result is not None

    assert result == []

    fqcn = 'ansible.plugins.action'
    my_obj = PluginLoader(package=fqcn)
    assert my_obj is not None

    # test with an invalid value
    result = my_obj.all(0)
    assert result is None

    # test with a valid value
    result = list(my_obj.all())
    assert result is not None


# Generated at 2022-06-25 10:18:59.769007
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    try:
        var_1 = PluginLoader(var_0)
        var_1.all()
    except Exception as var_2:
        print((str(var_2)))


# Generated at 2022-06-25 10:19:03.068941
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_0 = PluginLoader("ansible.plugins.module_utils", "ModuleUtils")
    var_1 = ""
    var_2 = True
    var_3 = False
    var_0.all(var_1, var_2, var_3)


# Generated at 2022-06-25 10:19:05.689668
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    func_name = sys._getframe().f_code.co_name
    try:
        test_case_0()
    except Exception as e:
        print(func_name, "with exception", e)

_ADDITIONAL_PLUGINS_PATH_CACHE = {}


# Generated at 2022-06-25 10:20:28.986574
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    try:
        get_shell_plugin()
    except Exception as e:
        assert 'must be provided' in str(e)

    try:
        get_shell_plugin(shell_type="sh")
    except Exception as e:
        assert 'must be provided' in str(e)

    try:
        get_shell_plugin(executable="sh")
    except Exception as e:
        assert 'must be provided' in str(e)

    try:
        get_shell_plugin(shell_type="zsh")
    except Exception as e:
        assert 'required' in str(e)

    try:
        get_shell_plugin(executable="sh", shell_type="zsh")
    except Exception as e:
        assert 'required' in str(e)


# Generated at 2022-06-25 10:20:30.588985
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    add_all_plugin_dirs()


# Generated at 2022-06-25 10:20:37.123944
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_0 = importlib_importer.find_module('ansible.plugins.action').load_module('ansible.plugins.action')
    var_1 = var_0.__loader__
    var_2 = None
    var_3 = None
    var_4 = var_1.all(class_only=var_3)
    for var_5 in var_4:
        var_6 = var_5
        var_7 = var_6.__name__
    var_8 = var_1.all(path_only=var_3)
    var_9 = list(var_8)
    var_10 = var_1.all()
    var_11 = list(var_10)


# Generated at 2022-06-25 10:20:38.536488
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    result = get_shell_plugin()


# Generated at 2022-06-25 10:20:44.613079
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    try:
        stdout = sys.stdout
        stdin = sys.stdin
        stderr = sys.stderr
        sys.stdout = StringIO()
        sys.stdin = StringIO('foo')
        sys.stderr = StringIO()
        p = PluginLoader(package='ansible_collections.testns.testcoll.plugins', subdir='filter_plugins')
        p.all()
    finally:
        sys.stdout = stdout
        sys.stdin = stdin
        sys.stderr = stderr


# Generated at 2022-06-25 10:20:46.905971
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    add_all_plugin_dirs('/home/zhouhao2/Desktop/Ansible/ansible/lib/ansible/plugins/connection')
    add_all_plugin_dirs('/home/zhouhao2/Desktop/Ansible/ansible/lib/ansible/plugins/modules')



# Generated at 2022-06-25 10:20:54.224154
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    var_1 = AnsiblePluginContext('connection', True, 'ansible.plugins.connection.winrm', None, None, 'winrm')
    var_2 = AnsiblePluginContext('connection', False, 'ansible.plugins.connection.winrm', None, 'tcp', 'tcp')
    var_3 = AnsiblePluginContext('connection', False, 'ansible.plugins.connection.ssh', 'ansible.plugins.connection.fabric', None, None)
    var_4 = AnsiblePluginContext('action', True, None, None, None, 'copy')
    var_5 = AnsiblePluginContext('action', False, None, None, None, 'copy')
    var_6 = AnsiblePluginContext('action', False, None, None, None, 'something_else')

# Generated at 2022-06-25 10:20:58.938082
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # TODO: Add unit test here
    context = None
    name = ''
    args = []
    kwargs = {}
    obj = PluginLoader.get_with_context(context, name, args, kwargs)
    assert obj
    assert obj.fqcr == "ansible.plugins.action.debug"


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-25 10:21:02.792298
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    obj = PluginLoader(
        "my.package",
        "my_class",
        "my.base",
        "my/subdir",
    )
    # START FUNCTION TEST
    actual_result = obj.find_plugin("my-plugin", collection_list=None)
    # END FUNCTION TEST
    assert actual_result is not None


# Generated at 2022-06-25 10:21:09.727675
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
	my_dict_0 = {}
	my_dict_0['ia5'] = 't'
	my_dict_0['time'] = '11:47:04'
	my_dict_0['err'] = 'a'
	my_dict_0['dns'] = 'c'
	my_dict_0['ipv6'] = 'c'
	my_dict_0['filename'] = 'o'
	my_dict_0['ascii'] = 'b'
	my_dict_0['base64'] = 'e'
	my_dict_0['ia5String'] = 'x'
	my_dict_0['printable'] = 'j'
	my_dict_0['basic_auth_unix'] = 's'
	my_dict_0['username'] = 'm'
	my_