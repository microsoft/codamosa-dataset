

# Generated at 2022-06-25 10:13:52.216991
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Create a test plugin_loader.
    all_plugin_loaders = get_all_plugin_loaders()
    assert len(all_plugin_loaders) > 0
    plugin_loader_name, plugin_loader_obj = all_plugin_loaders[0]
    assert isinstance(plugin_loader_obj, PluginLoader)

    # Create a test plugin_path.
    test_plugin_path = os.path.join('/tmp/test_case', plugin_loader_obj.subdir)

    # Create a test plugin.
    plugin_file = os.path.join(test_plugin_path, 'test_case.py')
    with open(plugin_file, 'w') as test_plugin:
        test_plugin.write('\n')

    # Create a test plugin_path_file.
    test_plugin_path

# Generated at 2022-06-25 10:13:57.780237
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    plugin_loader_0 = PluginLoader('CliOptions', '', C.DEFAULT_INTERNAL_ROLES_PATH, required_base_class='CliOptions')
    plugin_load_context_0 = plugin_loader_0.find_plugin_with_context('options')
    assert plugin_load_context_0.resolved
    assert plugin_load_context_0.redirect_list == []
    plugin_load_context_1 = plugin_loader_0.find_plugin_with_context('query')
    assert plugin_load_context_1.resolved
    assert plugin_load_context_1.redirect_list == ['options']


# Generated at 2022-06-25 10:14:01.934908
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    deprecation_dict = {'warning_text': 'The world is ending?', 'removal_date': '2020/12/31'}
    plugin_load_context = PluginLoadContext()
    plugin_load_context.record_deprecation('foo', deprecation_dict, 'namespace.name')
    assert plugin_load_context.deprecated == True
    assert plugin_load_context.removal_date == '2020/12/31'
    assert plugin_load_context.deprecation_warnings == ['foo has been deprecated. The world is ending?']


# Generated at 2022-06-25 10:14:13.198208
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    fake_plugins = [
        ('fake_plugin_0', None),
        ('fake_plugin_1', None)
    ]
    fake_plugin_loader = FakePluginLoader(fake_plugins, 0, 'ansible.plugins.action')
    fake_plugin_loader.add_directory('/fake/plugins/path')
    result_0 = fake_plugin_loader.all()

# Generated at 2022-06-25 10:14:18.537852
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell_type='sh'
    shell_type = 'sh'
    executable='/bin/bash'
    plugin_load_context_0 = PluginLoadContext()
    get_shell_plugin(shell_type, executable)



# Generated at 2022-06-25 10:14:22.956223
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    plugin_load_context_0 = PluginLoadContext()
    plugin_manager_0 = PluginLoader()
    plugin_manager_0.add_directory('/usr/lib/python3.6/site-packages/ansible_collections/ciscodevnet/aci')


# Generated at 2022-06-25 10:14:24.556707
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    new_dir = "./"
    add_all_plugin_dirs(new_dir)


# Generated at 2022-06-25 10:14:29.431254
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    fake_path = 'fake/path'
    plugin_loader_0 = PluginLoader()
    plugin_loader_0.add_directory(fake_path)
    if(plugin_loader_0.package_path != [fake_path]):
        print("ERROR 1")


# Generated at 2022-06-25 10:14:32.165408
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    filter_plugins_0 = PluginLoader('FilterModule', 'filter_plugins', '')
    plugin_load_context_0 = PluginLoadContext()
    actual_result_0 = filter_plugins_0.get("json_query.py", plugin_load_context=plugin_load_context_0)
    assert actual_result_0 is not None


# Generated at 2022-06-25 10:14:33.760004
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    try:
        shell_type = u'sh'
        executable = u'/bin/bash'
        get_shell_plugin(shell_type, executable)
    except Exception as e:
        print(e)



# Generated at 2022-06-25 10:15:14.295422
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    assert_raises(AnsibleError, PluginLoader, '', '', '').all(path_only=True, class_only=True)


# Generated at 2022-06-25 10:15:20.915726
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
   # test with no arguments
   plugin_load_context_1 = PluginLoader.find_plugin_with_context()
   # test with one argument
   plugin_load_context_2 = PluginLoader.find_plugin_with_context(name='plugins/group/dummy.py')
   assert plugin_load_context_1 != plugin_load_context_2
   # test with one named argument and one yaml argument
   plugin_load_context_3 = PluginLoader.find_plugin_with_context(name='plugins/group/dummy.py', collection_list=None)
   assert plugin_load_context_1 != plugin_load_context_3
   assert plugin_load_context_2 != plugin_load_context_3


# Generated at 2022-06-25 10:15:24.340525
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    plugin_load_context_0 = PluginLoadContext()
    plugin_loader_0 = PluginLoader('ansible.plugins.cache', 'BaseCacheModule')
    # all is an iterator that returns class objects
    # all is an iterator that returns instance objects
    # all is an iterator that returns path objects
    return


# Generated at 2022-06-25 10:15:29.116441
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    global _PLUGIN_FILTERS

    # Case 1: ansible.plugins.connection.ConnectionBase
    # Init plugin loader with package ansible.plugins.connection and
    # base_class ConnectionBase.
    plc = PluginLoader('ansible.plugins.connection', 'ConnectionBase')
    # In connection plugin loader, subdir is 'connection_plugins' and
    # class_name is 'ConnectionBase'.
    assert plc.subdir == 'connection_plugins'
    assert plc.class_name == 'ConnectionBase'
    # Case 1.1: Ansible file ansible/plugins/connection/ssh.py
    # The file name is 'ssh.py',  python module name is 'ssh' and
    # the class defined in the module is 'ConnectionBase'.
    py_file = 'ansible/plugins/connection/ssh.py'


# Generated at 2022-06-25 10:15:37.455578
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    plugin_load_context_10 = PluginLoadContext()
    plugin_load_context_10._loader_lock = threading.RLock()
    plugin_load_context_10.package = 'test'
    plugin_load_context_10.class_name = 'name'
    plugin_load_context_10._searched_paths = []
    plugin_load_context_10._module_cache = {}
    plugin_load_context_10.base_class = None
    plugin_load_context_10.aliases = {}
    plugin_load_context_10.all()
    plugin_load_context_10.all(_dedupe=True)
    plugin_load_context_10.all(_dedupe=False)
    plugin_load_context_10.all(path_only=True)
    plugin_load_context_

# Generated at 2022-06-25 10:15:48.451030
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # Note: Tests for __contains__ (and __getitem__) are different from
    # tests for has_plugin and find_plugin because we need to stub out
    # the _get_paths call and control where the plugins are in the
    # filesystem.  This allows us to confirm that we are getting the
    # right results for names that have multiple plugins with the same
    # name (e.g. action, filter, and test plugins).  The tests for
    # has_plugin and find_plugin can't do this because they use
    # AnsibleLoader which itself uses PluginLoader to find the
    # plugin paths.  AnsibleLoader's loaders are created statically
    # so we can't customize the search paths of one loader in the
    # context of another.
    plugin_load_context_0 = PluginLoadContext()

    # Expanded for this test

# Generated at 2022-06-25 10:15:53.158195
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    plugin_load_context_0 = PluginLoadContext()
    action_loader_0 = PluginLoader('ActionModule', 'ansible.plugins.action')
    str_0 = action_loader_0.get_with_context('shell', plugin_load_context_0)
    assert str_0 is not None
    str_1 = action_loader_0.get_with_context('setup', plugin_load_context_0)
    assert str_1 is not None


# Generated at 2022-06-25 10:16:03.058755
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # To test with a test directory we want to create in a temporary location
    # Use a mock FileModule to avoid having to create test files.
    with patch("ansible.utils.path.FileModule"):
        # No environment variables set, no plugin directories initially.
        loader = PluginLoader("test_plugins")
        assert 0 == len(loader._load_paths)
        # Create a temporary location for the test directory
        tmp_dir = tempfile.mkdtemp("ansible_test_PluginLoader_add_directory")
        # Test a simple addition.
        try:
            loader.add_directory(tmp_dir)
            assert 1 == len(loader._load_paths)
            assert tmp_dir in loader._load_paths
        finally:
            shutil.rmtree(tmp_dir)


# Generated at 2022-06-25 10:16:06.345750
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    plugin_loader = PluginLoader(package='foo')
    plugin_loader.add_directory(directory='foo')
    assert os.path.join('foo', 'bar') in plugin_loader.package_path


# Generated at 2022-06-25 10:16:10.837691
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    plugin_load_context_0 = PluginLoadContext()

    # Test with an invalid value for loader_name
    try:
        add_dirs_to_loader('foo', '')
    except Exception:
        pass
    else:
        raise AssertionError('Expected an exception')
    return



# Generated at 2022-06-25 10:18:19.879328
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    plugin_loader_0 = PluginLoader('foo.bar', 'fubar', 'path/to/nonexistent')
    assert not plugin_loader_0.all()
    plugin_loader_0.add_directory(C.DEFAULT_MODULE_PATH)
    assert plugin_loader_0.all()


# Generated at 2022-06-25 10:18:20.704337
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    test_case_0()


# Generated at 2022-06-25 10:18:25.288507
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Test passing in a relative path
    plugin_load_context_0 = PluginLoadContext()
    plugin_load_context_0.directories.add('./some/path')
    assert plugin_load_context_0.directories == set(['./some/path'])


# Generated at 2022-06-25 10:18:26.593681
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # FIXME: implement a real test here
    assert True


# Generated at 2022-06-25 10:18:35.960228
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    plugin_load_context_0 = PluginLoadContext()
    plugin_load_context_0.resolved = False
    plugin_load_context_0.plugin_resolved_name = 'ansible.plugins.test.test_plugin_loader.test_plugin_0'
    plugin_load_context_0.plugin_resolved_path = '/home/uv/ansible/lib/ansible/plugins/test/test_plugin_loader.py'
    plugins_loader_0 = PluginLoader(package='ansible.plugins.test', class_name='test_plugin_0', config=Config(), subdir='', aliases={'nope': 'nope'}, plugin_load_context=plugin_load_context_0)
    all_plugins_0 = plugins_loader_0.all(plugin_load_context=plugin_load_context_0)

# Generated at 2022-06-25 10:18:39.325786
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    plugin_load_context_0 = PluginLoadContext()
    assert plugin_load_context_0 is not None

    my_loader = PluginLoader(package="ansible", subdir="plugins/action")
    my_loader.add_directory("/foo/bar")
    assert my_loader.get_paths() == ['/foo/bar']


# Generated at 2022-06-25 10:18:43.606087
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    try:
        importlib.util.find_spec('ansible.module_utils.facts')
        plugin_load_context_0 = PluginLoadContext()
        add_dirs_to_loader('callback', ['/usr/lib/python2.7/site-packages/ansible/plugins/callbacks'])
        assert plugin_load_context_0.plugin_count == 13
    except ImportError:
        warnings.warn('Unable to import module ansible.module_utils.facts. Skipping unit tests for function add_dirs_to_loader')


# Generated at 2022-06-25 10:18:54.394476
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    loader = PluginLoader(package='ansible.builtin',
                          base_class='',
                          class_name='',
                          config_base_class='')
    # case 12
    plugin_load_context_12 = PluginLoader(package='ansible.plugins.action',
                                          base_class=None,
                                          class_name=None,
                                          config_base_class=None).find_plugin_with_context(name='ping', collection_list=[AnsibleCollectionRef.from_string('ansible.builtin')])
    assert plugin_load_context_12.resolved == True

# Generated at 2022-06-25 10:19:01.925471
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    os.environ["ANSIBLE_LOAD_CALLBACK_PLUGINS"] = "blah"
    os.environ["ANSIBLE_CALLBACK_PLUGINS"] = "blah"
    os.environ["ANSIBLE_ACTION_PLUGINS"] = "blah"
    os.environ["ANSIBLE_CONNECTION_PLUGINS"] = "blah"
    os.environ["ANSIBLE_LOOKUP_PLUGINS"] = "blah"
    os.environ["ANSIBLE_INVENTORY_PLUGINS"] = "blah"
    os.environ["ANSIBLE_VARS_PLUGINS"] = "blah"
    os.environ["ANSIBLE_FILTER_PLUGINS"] = "blah"
    os.environ["ANSIBLE_TEST_PLUGINS"]

# Generated at 2022-06-25 10:19:03.006168
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    test_case_0()



# Generated at 2022-06-25 10:19:29.522731
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    var_0 = get_all_plugin_loaders()


# Generated at 2022-06-25 10:19:32.463125
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_0 = PluginLoader(None, None, None, None)
    var_1 = var_0.all()
    assert isinstance(var_1, types.GeneratorType)


# Generated at 2022-06-25 10:19:39.794181
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    var_0 = PluginLoader(
        class_name='ActionModule',
        package='ansible.plugins.action',
        config_key='action_plugins',
        base_class='ActionBase',
        subdir=None)
    var_0.set_aliases({'setup': 'gather_facts'})
    var_0.push_path('/tmp/ansible_test', 'action_plugins')

    # Test with name with variable
    var_1 = var_0.find_plugin('setup')
    assert var_1 is not None

    # Test with name with variable
    var_1 = var_0.find_plugin('assemble')
    assert var_1 is not None

    # Test with name with variable

# Generated at 2022-06-25 10:19:41.409494
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Load tests
    ds = get_all_plugin_loaders()
    for k, v in ds.items():
        test_case_0()


# Generated at 2022-06-25 10:19:46.564539
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    os.environ['ANSIBLE_ACTION_PLUGINS'] = 'some_path'
    os.environ['ANSIBLE_CACHE_PLUGIN'] = 'some_path'
    os.environ['ANSIBLE_CALLBACK_PLUGINS'] = 'some_path'
    os.environ['ANSIBLE_CLICONF_PLUGINS'] = 'some_path'
    os.environ['ANSIBLE_CONNECTION_PLUGINS'] = 'some_path'
    os.environ['ANSIBLE_LOOKUP_PLUGINS'] = 'some_path'
    os.environ['ANSIBLE_NETCONF_PLUGINS'] = 'some_path'
    os.environ['ANSIBLE_STRATEGY_PLUGINS'] = 'some_path'

# Generated at 2022-06-25 10:19:47.652242
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_0 = get_all_plugin_loaders()


# Generated at 2022-06-25 10:19:50.643570
# Unit test for method add_directory of class PluginLoader

# Generated at 2022-06-25 10:19:54.293119
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    loader = PluginLoader('foo', 'bar', 'base')
    loader.add_directory(os.path.dirname(__file__))
    assert loader._get_paths() == [os.path.dirname(__file__)]


# Generated at 2022-06-25 10:19:55.546957
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    var_0 = get_shell_plugin()
    assert var_0 != None



# Generated at 2022-06-25 10:19:59.158868
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    plugin_load_context = Mock()
    plugin_load_context.plugin_name = 'foo'
    loader = PluginLoader('ansible.plugins', 'Plugin', '', 'action_plugins')
    loader.find_plugin_with_context(plugin_load_context.plugin_name)


# Generated at 2022-06-25 10:20:23.983635
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    pass

# Generated at 2022-06-25 10:20:26.031710
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    var_0 = get_all_plugin_loaders()


# Generated at 2022-06-25 10:20:27.491092
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    print('Test for find_plugin_with_context')
    test_case_0()


# Generated at 2022-06-25 10:20:31.468245
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    var_0 = PluginLoader()
    var_1 = var_0.__contains__("foo.bar")
    assert var_1 is False, "PluginLoader() contains 'foo.bar' should be of type %s" % type(False)


# Generated at 2022-06-25 10:20:36.740256
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    pl = PluginLoader('filter_loader', 'FilterModule', C.DEFAULT_FILTER_PATH, 'ansible.plugins.filter.core', 'CoreFilters', 'ansible.plugins.core_filter')
    all(pl)
    all(pl, path_only = True)
    all(pl, class_only = True)
    all(pl, _dedupe = False)
    all(pl, path_only = True, _dedupe = False)
    all(pl, class_only = True, _dedupe = False)


# Generated at 2022-06-25 10:20:40.910646
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell_type = None
    executable = None
    result = get_shell_plugin(shell_type, executable)
    # TODO: fix this unit test to not be dependent on the fixtures' state.
    # This unit test's result depends on the current directory.
    assert result.executable == "/usr/bin/sh"


# Generated at 2022-06-25 10:20:43.290467
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    var_0 = Jinja2Loader()
    var_1 = "Test"
    var_2 = var_0.find_plugin(var_1)


# Generated at 2022-06-25 10:20:46.620835
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_0 = get_all_plugin_loaders()
    ln = var_0['callback']
    for var_1 in ln.all():
        print(var_1)
        print(var_1._load_name)
        print(var_1._original_path)
        print(var_1._original_basename)
    for var_2 in ln.all(path_only=True):
        print(var_2)


# Generated at 2022-06-25 10:20:47.695700
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    get_shell_plugin(executable=None)


# Generated at 2022-06-25 10:20:54.926228
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Lazy initialization of constant
    if not '_PLUGIN_FILTERS' in globals():
        global _PLUGIN_FILTERS
        _PLUGIN_FILTERS = {}
        _PLUGIN_FILTERS['ansible.plugins.action'] = frozenset(['__init__.py'])
        _PLUGIN_FILTERS['ansible.plugins.action.network'] = frozenset(['__init__.py'])
        _PLUGIN_FILTERS['ansible.plugins.connection'] = frozenset(['__init__.py'])
        _PLUGIN_FILTERS['ansible.plugins.connection.network'] = frozenset(['__init__.py'])