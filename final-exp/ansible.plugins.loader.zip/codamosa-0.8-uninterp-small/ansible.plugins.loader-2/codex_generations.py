

# Generated at 2022-06-25 10:13:41.012592
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    plugin_load_context_0 = PluginLoadContext()

# Generated at 2022-06-25 10:13:48.696688
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():

    plugin_load_context_0 = PluginLoadContext()

    paths = ['/home/hmli/ansible/lib/ansible/modules/test', '/home/hmli/ansible/lib/ansible/modules']

    test_case_0(paths)
    #this is replaced by the below code
    result0 = plugin_load_context_0.all_files
    print(result0)
    print("-------------------------------")
    print("Test case 0")
    print("-------------------------------")
    print("Execution completed")
    print("-------------------------------")

# Unit test to verify testing of units

# Generated at 2022-06-25 10:13:49.822483
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert add_dirs_to_loader.__doc__ is not None



# Generated at 2022-06-25 10:13:57.095874
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    test_paths = ['/etc/ansible/test_dir', '/etc/ansible/test2_dir']
    add_dirs_to_loader('module', test_paths)
    assert(module_loader.get_directory_list() == test_paths)


# Generated at 2022-06-25 10:14:07.974542
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Create an instance of PluginLoader
    plugin_loader_0 = PluginLoader()

    # Create a list of dictionaries, each dictionary is an AnsibleCollectionRef
    collection_list_0 = [{'namespace': 'namespace_0',
                          'repository': 'repository_0',
                          'version': 'version_0'},
                         {'namespace': 'namespace_1',
                          'repository': 'repository_1',
                          'version': 'version_1'}]

    # Declare variable 'name' to be of type string
    # Assign value to variable 'name'
    name = 'name_0'

    # Call method 'find_plugin_with_context' of plugin_loader_0 with the given arguments

# Generated at 2022-06-25 10:14:18.667530
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():  # noqa: F811
    # Need to track the contents of PLUGIN_PATH_CACHE because add_all_plugin_dir
    # might have been called before the test starts running.
    original_plugin_cache = dict(PLUGIN_PATH_CACHE)

    b_path = to_bytes(C.DEFAULT_LOCAL_TMP, errors='surrogate_or_strict')
    assert not os.path.isdir(b_path)


# Generated at 2022-06-25 10:14:27.931553
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    """Test all method of PluginLoader"""
    p_loader = PluginLoader(package='', class_name='', base_class='', searched_paths=[])

    dedupe = True
    path_only = False
    class_only = False
    kwargs = {'_dedupe': dedupe, 'path_only': path_only, 'class_only': class_only}

    args = ()
    _all = p_loader.all(*args, **kwargs)

    for i in _all:
        if i is None:
            pytest.fail("Failed to run all method of PluginLoader")


# Generated at 2022-06-25 10:14:35.013536
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():

    #TODO: Add unit test

    #TODO: Write unit test that checks to make sure directories are being added
    path = os.path.expanduser(to_bytes(path, errors='surrogate_or_strict'))
    if os.path.isdir(b_path):
        for name, obj in get_all_plugin_loaders():
            if obj.subdir:
                plugin_path = os.path.join(b_path, to_bytes(obj.subdir))
                if os.path.isdir(plugin_path):
                    obj.add_directory(to_text(plugin_path))
    else:
        display.warning("Ignoring invalid path provided to plugin path: '%s' is not a directory" % to_text(path))


# Generated at 2022-06-25 10:14:42.313119
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    if hasattr(constants, 'DEFAULT_MODULE_PATH'):
        module_path = constants.DEFAULT_MODULE_PATH
    else:
        module_path = constants.DEFAULT_MODULES_PATH

    add_all_plugin_dirs(module_path)


# Generated at 2022-06-25 10:14:44.022321
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell_type=None
    executable='sh'
    shell_type = 'sh'
    executable='sh'
    assert get_shell_plugin(shell_type, executable) 


# Generated at 2022-06-25 10:15:35.156256
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    from ansible.template.safe_eval import get_safe_environment
    from ansible.template.vars import AnsibleJ2Vars
    from ansible.template.vars import AllExtraVars

    var_0 = AnsibleJ2Vars({})
    var_1 = Jinja2Loader.all(var_0)
    var_2 = AnsibleJ2Vars({'lookup': 'lookup', 'filter': 'filter'})
    var_3 = Jinja2Loader.all(var_2)


# Generated at 2022-06-25 10:15:37.752276
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    var_0 = PluginLoader('', '', '', 'path')
    var_1 = var_0.get_with_context('win_ping', '', '', '', '')
    assert var_1 is not None


# Generated at 2022-06-25 10:15:39.242698
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    var_0 = PluginLoader()
    var_1 = var_0.__setstate__()
    return var_1


# Generated at 2022-06-25 10:15:42.418694
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    p = PluginLoader(Display(), 'plugins')
    p.add_directory(os.path.abspath('plugins'))
    assert os.path.isdir('plugins')


# Generated at 2022-06-25 10:15:47.766693
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    kwargs = {}
    kwargs['base_class'] = 'BaseShell'
    kwargs['class_name'] = 'ActionBase'
    kwargs['package'] = 'ansible.plugins.action'
    kwargs['subdir'] = 'shell'
    var_0 = Jinja2Loader(**kwargs)
    var_1 = var_0.get('sh')


# Generated at 2022-06-25 10:15:50.276933
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    var_0 = PluginLoader('c', 'b')
    assert var_0.__contains__('b')


# Generated at 2022-06-25 10:15:55.694082
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    with pytest.raises(AnsibleError):
        name = None
        *args = None

# Generated at 2022-06-25 10:16:05.298546
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_1 = PluginLoader("shell_plugins", "ShellModule", "ansible_collections.ansible.community.plugins.module_utils.basic.argspec.AnsibleModule", "ansible_collections.ansible.community.plugins.module_utils.basic.AnsibleModule", "ansible_collections.ansible.community.plugins.module_utils.common.argspec", True, "ansible.plugins.shell", False)
    var_1.subdir = "shell_plugins"
    var_1.package = "ansible_collections.ansible.community.plugins.module_utils.basic"
    var_1.paths = PluginLoader._get_paths()
    var_1.aliases = {}
    var_1.class_name = "ShellModule"

# Generated at 2022-06-25 10:16:07.240359
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
  test = Jinja2Loader(None, None)
  test.all()


# Generated at 2022-06-25 10:16:10.998644
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    pl = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action')
    # Test 1
    pl.find_plugin('script')

    # Test 2
    pl.find_plugin('shell')


# Generated at 2022-06-25 10:16:36.160297
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    global var_0

    # initialize class
    var_0 = PluginLoader('action_plugin', 'ansible.plugins.action')

    # execute function
    var_0.find_plugin('ping')


# Generated at 2022-06-25 10:16:44.374644
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # create an instance of the plugin loader
    plugin_loader = PluginLoader(package='shell_plugins', class_name='ShellModule', base_class='ShellModule')
    # add the directories to search
    plugin_loader.add_directory('/home/pradeep/workspace/ansible/lib/ansible/plugins/shell_plugins')
    # get a named plugin
    var_0 = plugin_loader.all('dir','dir')

# Generated at 2022-06-25 10:16:45.892195
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    try:
        var_0 = PluginLoader('','')
        var_1 = var_0.find_plugin('','')
    except Exception as var_2:
        print(str(var_2))


# Generated at 2022-06-25 10:16:49.294851
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    var_0 = PluginLoader('', '', '', '')
    var_1 = get_shell_plugin()
    var_0.get = MagicMock(return_value = var_1)
    var_2 = to_text(randint(0, 10))
    var_0.find_plugin(var_2)
    assert var_1 == var_0.get.return_value


# Generated at 2022-06-25 10:16:57.419743
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():

    # Need to return an instance of the class.
    import ansible.plugins.loader
    plugin_loader = ansible.plugins.loader.PluginLoader("module_utils")
    test_vars = (
        { 'package': 'ansible.plugins', 'subdir': 'module_utils', 'class_name': '', 'path': [],
        'aliases': {}, 'display_name': 'ansible.plugins.module_utils' },
    )
    state_dict = dict(test_vars)
    plugin_loader.__setstate__(state_dict)
    return plugin_loader


# Generated at 2022-06-25 10:17:03.373684
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Set the environment variable for testing the path to the ansible plugins
    os.environ['ANSIBLE_LIBRARY'] = 'test/fixtures/ansible/plugins'
    # Create a PluginLoader object
    pl = PluginLoader('shell', 'ShellModule', 'ansible.plugins.shell', 'shell', 'ansible.plugins.shell.shell')
    ctx = pl.find_plugin_with_context('cowsay')
    assert ctx.resolved


# Generated at 2022-06-25 10:17:12.277009
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    if not is_local_ansible:
        pytest.skip('skipping PluginLoader unit tests, no local ansible install')

# Generated at 2022-06-25 10:17:13.807755
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    all_plugins = Jinja2Loader.all()


# Generated at 2022-06-25 10:17:16.575621
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    var_0 = PluginLoadContext()
    var_1 = 'name'
    var_2 = dict()
    var_3 = 'collection_name'
    var_0.record_deprecation(var_1, var_2, var_3)


# Generated at 2022-06-25 10:17:17.348568
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    pass
test_case_0()

# Generated at 2022-06-25 10:18:16.899090
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    var_0 = Jinja2Loader()


# Generated at 2022-06-25 10:18:18.748787
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    var_1 = get_shell_plugin()
    # Add ./plugins in the plugin search path.
    # var_0.add_directory('./plugins')


# Generated at 2022-06-25 10:18:28.302593
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    from ansible.utils.plugin_docs import get_docstring

    PLUGIN_LOADER = PluginLoader('ansible.plugins.test.test_a.module_utils', 'TestModuleUtil', 'ansible.plugins.module_utils')

    def check(name, **kwargs):
        ''' wrapper for PLUGIN_LOADER.find_plugin_with_context '''

        plugin_load_context = PLUGIN_LOADER.find_plugin_with_context(name, **kwargs)
        assert plugin_load_context, "name=%s, kwargs=%s: failed to find plugin" % (name, str(kwargs))
        assert plugin_load_context.resolved, "name=%s, kwargs=%s: plugin is not resolved" % (name, str(kwargs))
        assert plugin

# Generated at 2022-06-25 10:18:30.137304
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert get_shell_plugin() == get_shell_plugin()
    assert get_shell_plugin() is not get_shell_plugin()


# Generated at 2022-06-25 10:18:38.555893
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    var_0 = PluginLoader("action_plugins")
    var_1 = "test_action"
    var_0._get_paths = lambda: ['ansible/plugins/action_plugins']
    var_0._searched_paths = ['ansible/plugins/action_plugins']
    var_2 = os.path.join('ansible/plugins/action_plugins', 'test_action.py')
    var_0.get = lambda x, collection_list=None, class_only=False: None
    var_0._get_package_path = lambda x: 'ansible_collections.test_namespace.test_collection/plugins/actions'
    var_3 = var_0.find_plugin(var_1)
    # assert
    assert var_3==var_2
    pass


# Generated at 2022-06-25 10:18:43.021602
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    var_0 = PluginLoadContext()
    var_1 = 'ansible.plugins.test'
    var_2 = {
        'warning_text': 'foo',
        'removal_version': '1.0',
        'removal_date': '2022-12-31T12:00:00Z',
        'removed': True,
    }
    var_3 = 'test_collection'
    var_0.record_deprecation(var_1, var_2, var_3)


# Generated at 2022-06-25 10:18:45.696322
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    b_path = to_bytes('/root/ansible/lib/ansible/plugins/inventory')
    os.path.isdir(b_path) == True


# Generated at 2022-06-25 10:18:47.613300
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    var_0 = get_shell_plugin()
    add_all_plugin_dirs(var_0)


# Generated at 2022-06-25 10:18:49.156212
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    PL = PluginLoader()

# Generated at 2022-06-25 10:18:58.221648
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    test_path = os.path.join(C.DEFAULT_LOCAL_TMP, u'ansible_test_add_all_plugin_dirs_get_shell_plugin')
    test_system_plugin_path = os.path.join(test_path, u'action_plugins')
    test_shell_plugin_path = os.path.join(test_path, u'connection_plugins')
    shell_plugin_name = to_native(u'shell.py', errors=u'surrogate_or_strict')
    system_plugin_name = to_native(u'system.py', errors=u'surrogate_or_strict')
    test_system_plugin_file = os.path.join(test_system_plugin_path, system_plugin_name)
    test_shell_plugin_file = os

# Generated at 2022-06-25 10:19:58.122324
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    loader = PluginLoader('ansible.plugins.test.test_run', 'TestModule')
    for obj in loader.all():
        assert loader.has_plugin(obj._load_name)


# Generated at 2022-06-25 10:20:06.388422
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    plugin_load_context = PluginLoadContext()
    loader = PluginLoader('shell_plugin', 'WindowsshellModule', '', 'cache.py')

# Generated at 2022-06-25 10:20:09.637994
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    var_x = PluginLoader('var_x')
    var_y = None
    try:
        var_y = pickle.dumps(var_x)
    except:
        pass
    var_x.__setstate__(pickle.loads(var_y))
    var_z = var_x._searched_paths


# Generated at 2022-06-25 10:20:18.963972
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    var_1 = PluginLoadContext()

    # Deprecation message absent
    var_2 = {'warning_text': 'The module is deprecated.', 'removal_date': '2022-06-01', 'removal_version': '2.14'}
    var_3 = var_1.record_deprecation('test_module', None, 'acme.test')
    assert var_3.deprecation_warnings == []
    assert var_3.removal_date is None
    assert var_3.removal_version is None
    assert var_3.deprecated is False

    # Deprecation message present
    var_3 = var_3.record_deprecation('test_module', var_2, 'acme.test')

# Generated at 2022-06-25 10:20:26.315890
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    var_0 = None
    try:
        var_0 = PluginLoader('action_plugin', 'ansible.plugins.action')
        var_0._set_package_paths(['/home/neal/ansible/lib/ansible/plugins/action'])
        var_0.find_plugin('debug')
    except Exception as var_1:
        print(traceback.format_exc())
        print('test_PluginLoader_find_plugin FAILED: %s' % var_1)
    else:
        print('test_PluginLoader_find_plugin PASSED')


# Generated at 2022-06-25 10:20:32.193849
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    var_0 = PluginLoader(
        'action',
        'ansible.plugins.action',
        'ActionModule',
        C.DEFAULT_ACTION_PLUGIN_PATH
    )
    with pytest.raises(AnsibleError) as excinfo:
        var_0.all(
            path_only=False,
            class_only=False,
            _dedupe=True
        )
    assert 'Do not set both path_only' in to_text(excinfo.value)


# Generated at 2022-06-25 10:20:35.022752
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    var_0 = PluginLoader('', '', '', '')
    var_1 = dict(__s=1)
    var_0.__setstate__(var_1)


# Generated at 2022-06-25 10:20:36.384786
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    for name, obj in get_all_plugin_loaders():
        if obj.subdir:
            obj.add_directory(name)


# Generated at 2022-06-25 10:20:38.999807
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    var_0 = PluginLoader()
    var_1 = __contains__(var_0, ())
    del var_0, var_1


# Generated at 2022-06-25 10:20:42.006360
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():

    # empty
    collection_plugin_loader = PluginLoader('ansible.plugins.collection.vars', 'VarsModule', '_load_name')
    assert [] == list(collection_plugin_loader.all(path_only=True))