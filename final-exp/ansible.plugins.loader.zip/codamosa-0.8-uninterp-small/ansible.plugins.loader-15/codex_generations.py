

# Generated at 2022-06-25 10:12:57.031442
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    list_0 = []
    var_0 = add_all_plugin_dirs(list_0)
    case_0 = PluginLoader(var_0[0], var_0[2])
    assert case_0.all(class_only=True) == []


# Generated at 2022-06-25 10:12:57.944653
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Stub function to add a directory to the search path
    pass


# Generated at 2022-06-25 10:13:02.298067
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    context = PluginLoadContext()
    result = context.record_deprecation(1, 1, 1)
    assert result is context


# Generated at 2022-06-25 10:13:07.267207
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Assigning arguments:
    # self = <ansible.plugins.loader.PluginLoader object at 0x7f456867cb00>
    # name = 'action'
    # collection_list = None

    # Call method:
    ret_val = PluginLoader.find_plugin()

    # assert return value and type
    pass


# Generated at 2022-06-25 10:13:18.145254
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    var_0 = os.getcwd()
    var_1 = os.chdir("/Users/jovyan/workspace/ansible_test")
    var_2 = os.chdir("/Users/jovyan/workspace/ansible_test")
    var_3 = os.path.expanduser("/Users/jovyan/workspace/ansible_test")
    var_4 = to_bytes("/Users/jovyan/workspace/ansible_test", "surrogate_or_strict")
    list_0 = []
    list_0.append(var_4)
    var_5 = os.path.isdir(list_0)
    if var_5:
        var_6 = get_all_plugin_loaders()
        for var_7 in var_6:
            var

# Generated at 2022-06-25 10:13:19.682793
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    list_0 = []
    var_1 = PluginLoader('foo', 'bar', 'bas', list_0, 'qux')
    var_2 = var_1.find_plugin_with_context('baz')


# Generated at 2022-06-25 10:13:25.938338
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    list_0 = []
    add_all_plugin_dirs(list_0)
    var_0 = Jinja2Loader('ansible.plugins.filter.core')
    var_1 = var_0.get('regex_replace')
    assert var_1 is not None


# Generated at 2022-06-25 10:13:28.491397
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    list_0 = []
    # Setting up parameters and expected result for test case
    name = "test_value"
    collection_list = list_0
    # Calling method to test and verifying result
    result = Jinja2Loader.find_plugin(name, collection_list)
    # Verifying expected result
    assert result == None


# Generated at 2022-06-25 10:13:39.111289
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    which_loader = 'action'
    paths = 'var_1'
    assert add_dirs_to_loader(which_loader, paths) == None
    which_loader = 'test'
    paths = 'var_2'
    assert add_dirs_to_loader(which_loader, paths) == None
    which_loader = 'cliconf'
    paths = 'var_3'
    assert add_dirs_to_loader(which_loader, paths) == None
    which_loader = 'terminal'
    paths = 'var_4'
    assert add_dirs_to_loader(which_loader, paths) == None
    which_loader = 'vars'
    paths = 'var_5'
    assert add_dirs_to_loader(which_loader, paths) == None

# Generated at 2022-06-25 10:13:44.517461
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    loader = PluginLoader(package='ansible.plugins.action', base_class='ActionBase',
        class_name='ActionModule', config_prefix='ACTION')
    assert loader.has_plugin('ping')
    assert 'ping' in loader
    assert not loader.has_plugin('pingping')
    assert 'pingping' not in loader


# Generated at 2022-06-25 10:14:36.039448
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell_type = None
    executable = None
    var_0 = get_shell_plugin(shell_type, executable)
    print(var_0)

test_case_0()
test_get_shell_plugin()



# Generated at 2022-06-25 10:14:47.279079
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    args = []
    kwargs = {'path_only': False, 'class_only': False, '_dedupe': True}

# Generated at 2022-06-25 10:14:48.171300
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    assert True


# Generated at 2022-06-25 10:14:54.394294
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Init
    list_0 = []
    var_0 = add_all_plugin_dirs(list_0)
    var_1 = PluginLoader('action_plugin', 'ansible.plugins.action', C.DEFAULT_ACTION_PLUGIN_PATH, 'action_base', 'ActionBase')
    # Call
    var_2 = var_1.all()
    assert var_2, var_2


# Generated at 2022-06-25 10:14:57.187443
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    cache_name = 'test_name'
    list_0 = []
    args = list_0
    kwargs = {}
    for2_0 = Jinja2Loader(cache_name, list_0)
    for2_0.get(cache_name, args, kwargs)


# Generated at 2022-06-25 10:15:02.701723
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    list_0 = []
    var_0 = add_all_plugin_dirs(list_0)
    var_1 = PluginLoader('', '', '')
    var_2 = 'foo'
    var_3 = var_1.__setstate__(var_2)


# Generated at 2022-06-25 10:15:04.736689
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    a0 = PluginLoadContext()
    a2 = a0.record_deprecation('a1','a2','a3')


# Generated at 2022-06-25 10:15:10.390847
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    try:
        from imp import reload
    except ImportError:
        pass
    else:
        reload(sys).setdefaultencoding('UTF-8')
    test_case_0()
    try:
        shell_type = ""
        executable = None
        var_1 = get_shell_plugin(shell_type, executable)
    except Exception as e:
        print(e)



# Generated at 2022-06-25 10:15:12.918175
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # Verify execution of inline code
    jinja2loader = Jinja2Loader('', '', None, None)
    assert jinja2loader is not None

    test_case_0()


# Generated at 2022-06-25 10:15:16.269770
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert False



# Generated at 2022-06-25 10:16:28.731136
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Assign parameters
    name = 'str_0'
    class_only = var_0
    collection_list = 'collection'

    # Call the method
    obj = test_obj.get_with_context(name, class_only, collection_list)


# Generated at 2022-06-25 10:16:38.902653
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    def test_case_0():
        str_0 = 'ansible.plugins.action'
        var_0 = PluginLoader(str_0)
        str_1 = 'shell'
        var_1 = var_0.all(str_1)
        var_2 = next(var_1, None)
        var_3 = var_2.get_name()
        assert var_3 == 'shell' or var_3 == 'sh' or var_3 == 'bash' or var_3 == 'korn' or var_3 == 'zsh' or var_3 == 'csh' or var_3 == 'ksh'
        var_4 = next(var_1, None)
        var_5 = var_4.get_name()
        assert var_5 == 'shell' or var_5 == 'sh' or var_5

# Generated at 2022-06-25 10:16:41.906897
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    str_0 = '{'
    var_0 = get_shell_plugin(str_0)


# Generated at 2022-06-25 10:16:46.067465
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    # Declare the parameters
    str_0 = '/path0/to/plugins:/path1/to/plugins'
    try:
        # Call the function
        ret_val = PluginLoader.format_paths(str_0)
    except Exception as e:
        print("Function call format_paths(str_0) threw exception: " + str(e))
        raise


# Generated at 2022-06-25 10:16:48.071179
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    plugin_loader_0 = PluginLoader('action_plugin')
    str_0 = 'foo.py'
    var_0 = plugin_loader_0.get_with_context(str_0)


# Generated at 2022-06-25 10:16:58.789299
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    str_0 = '|'
    var_0 = get_shell_plugin(str_0)

    str_0 = '='
    var_0 = get_shell_plugin(str_0)

    str_0 = '}'
    var_0 = get_shell_plugin(str_0)

    str_0 = '-'
    var_0 = get_shell_plugin(str_0)

    str_0 = '{'
    var_0 = get_shell_plugin(str_0)

    str_0 = '-'
    var_0 = get_shell_plugin(str_0)

    str_0 = '='
    var_0 = get_shell_plugin(str_0)

    str_0 = '}'
    var_0 = get_shell_plugin(str_0)


# Generated at 2022-06-25 10:17:05.695149
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    str_0 = 'test_module'
    bool_0 = True
    var_0 = PluginLoader(path_1='test_module', subdir_1='test_module', package_1='ansible.plugins.test_module', class_name_1='test_module')
    var_1 = var_0.all(class_only_1=bool_0)
    var_2 = [var_3 for var_3 in var_1]
    var_4 = (var_2[0]).__class__
    assert var_4.__module__ == str_0


# Generated at 2022-06-25 10:17:08.059712
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    obj_0 = PluginLoader()
    var_1 = 'MAILHOST'
    obj_1 = obj_0.get_with_context(var_1)


# Generated at 2022-06-25 10:17:16.856459
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    plugin_loader = PluginLoader('/Users/jason/work/ansible/lib/ansible/plugins/module_utils', 'ansible.module_utils', 'ModuleUtilsCore')
    str_0 = 'ansible.module_utils.six'
    test_case_0(str_0, plugin_loader)

    plugin_loader = PluginLoader('/Users/jason/work/ansible/lib/ansible/plugins/action/__pycache__', '', 'ActionModule')
    str_0 = 'copy'
    test_case_0(str_0, plugin_loader)

    plugin_loader = PluginLoader('/Users/jason/work/ansible/lib/ansible/plugins/action/__pycache__', '', 'ActionModule')
    str_0 = 'download'

# Generated at 2022-06-25 10:17:19.733003
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    obj_1 = PluginLoader()
    assert obj_1.find_plugin('ansible.plugins.connection.local') == '/usr/lib/python2.7/site-packages/ansible-2.7.4-py2.7.egg/ansible/plugins/connection/local.py'


# Generated at 2022-06-25 10:17:48.559927
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    str_0 = '{'
    var_0 = get_shell_plugin(str_0)
    var_1 = var_0.get('a', '(k, v)')
    var_2 = var_1.get('b', '(k, v)')
    var_3 = var_2.get('c', '(k, v)')
    add_all_plugin_dirs(var_3)
    pass


# Generated at 2022-06-25 10:17:58.821138
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INTERNAL_TEMPLATE_MODULE_PATH, 'action_plugins', required_base_class='ActionBase')
    # FIXME: This test should take the config into account
    def test_case_0():
        str_0 = 'setup'
        var_0 = loader.get_with_context(str_0)
        if var_0.resolved:
            var_1 = var_0.plugin_resolved_name
            assert var_1 == 'setup.py', var_1
    def test_case_1():
        str_0 = 'shell'
        var_0 = loader.get(str_0)
        var_1 = var_0.__class__.__name__

# Generated at 2022-06-25 10:18:00.326444
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    str_0 = '{'
    var_0 = add_all_plugin_dirs(str_0)



# Generated at 2022-06-25 10:18:03.485345
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    collection_list = MockedCollectionList()

    res = PLUGIN_LOADER.find_plugin_with_context(str_0, collection_list)
    assert isinstance(res, PluginLoadContext)
    assert res.plugin_resolved_name == str_0


# Generated at 2022-06-25 10:18:08.194306
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Create a new instance of class PluginLoader
    PLUGIN_LOADER_0 = PluginLoader('')

    # Call method find_plugin of PLUGIN_LOADER_0
    PLUGIN_LOADER_0.find_plugin('', '', '')
    # Make sure this call is correct
    if PLUGIN_LOADER_0.find_plugin('', '', '') == None:
        PLUGIN_LOADER_0.find_plugin('', '', '')

# Generated at 2022-06-25 10:18:15.738023
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    assert 1 == 1
#    from ansible.config.manager import ConfigManager

#    cm = ConfigManager(['test/test_runner_integration/add_all_plugin_dirs/ansible.cfg'])
#    cm.set_options('configuration.plugins')
#    add_all_plugin_dirs('test/test_runner_integration/add_all_plugin_dirs/plugin_path')

#    get_all_plugin_loaders = [('powershell', Powershell())]

#    assert get_all_plugin_loaders == '({'


# Generated at 2022-06-25 10:18:17.815755
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():

    # Arrange
    path = ''
    var_0 = PluginLoader.find_plugin(path)
    path = 'test'
    var_0 = PluginLoader.find_plugin(path)
    return


# Generated at 2022-06-25 10:18:22.708799
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    str_0 = 'o'
    str_1 = 'h'
    dict_0 = {'collection_list': None, 'foo': 's'}
    obj_0 = PluginLoader(str_0)
    obj_1 = obj_0.get_with_context(str_1, dict_0)
    assert isinstance(obj_1, GetWithContextResult)


# Generated at 2022-06-25 10:18:25.023700
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    try:
        test_case_0()
    # Exception is raised.
    except Exception:
        pass
    else:
        raise Exception('Test failed')



# Generated at 2022-06-25 10:18:29.595473
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    var_1 = '.'
    var_2 = 'ansible_collections.nsbl.test.plugins.modules.test_plugins'
    var_3 = '{'
    var_1 = Jinja2Loader(var_1, var_2, 'FilterModule', None)
    var_2 = var_1.get(var_3)


# Generated at 2022-06-25 10:18:58.765987
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # Test first top level method in plugin, no base class
    str_0 = '{'
    var_0 = get_shell_plugin(str_0)
    var_1 = var_0.get('shell')
    # Compare source ast with expected source ast
    assert_ast_equals(var_1.__source_ast__, ParserPy().parses('def shell(arg):\n'
                                                             '    return ShellModule.run_command(str(arg))\n'))
    # Test second top level method in plugin, no base class
    str_1 = 'array'
    var_2 = get_shell_plugin(str_1)
    var_3 = var_2.get('shell')
    # Compare source ast with expected source ast

# Generated at 2022-06-25 10:18:59.945669
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    test_case_0()
    print('unit test for PluginLoader.find_plugin')


# Generated at 2022-06-25 10:19:07.859868
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    str_0 = '{'
    var_0 = get_shell_plugin(str_0)
    # Test the None return type
    assert(type(var_0) is None)
    print(var_0)
    # Test the failure return branch
    assert(var_0 == None)
    print(var_0)
    # Test the success return branch
    assert(var_0 == None)
    print(var_0)
    # Test the success return branch
    assert(var_0 == None)
    print(var_0)
    # Test the success return branch
    assert(var_0 == None)
    print(var_0)
    # Test the success return branch
    assert(var_0 == None)
    print(var_0)
    # Test the success return branch

# Generated at 2022-06-25 10:19:09.497952
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    str_1 = 'test.py'
    var_1 = add_all_plugin_dirs(str_1)



# Generated at 2022-06-25 10:19:10.278918
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # TODO
    assert True



# Generated at 2022-06-25 10:19:17.128591
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Setup
    str_0 = 'ansible_collections.acme.community.plugins.file_system.inventory.INI'
    str_1 = 'ansible_collections.acme.community.plugins.file_system.inventory.ini'
    str_2 = 'ansible_collections.acme.community.plugins.file_system.inventory.INI'
    # Exercise
    var_0 = PluginLoader._find_plugin(str_0)
    var_1 = PluginLoader._find_plugin(str_1)
    var_2 = PluginLoader._find_plugin(str_2)
    # Verify
    assert var_0 == str_2
    assert var_1 == str_2
    assert var_2 == str_2
    # Cleanup


# Generated at 2022-06-25 10:19:18.221695
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    test_case_0()

    assert 1 == 1


# Generated at 2022-06-25 10:19:19.547494
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    str_0 = '/usr/local/ansible/plugins/action'
    add_all_plugin_dirs(str_0)


# Generated at 2022-06-25 10:19:20.257913
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    test_case_0()


# Generated at 2022-06-25 10:19:21.752017
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    plugin_loader_0 = PluginLoader('action_plugins', 'ActionModule')
    plugin_0 = plugin_loader_0.get_with_context(module_utils_0)
    return plugin_0


# Generated at 2022-06-25 10:19:57.168826
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    str_0 = 'pipe'
    obj_0 = PluginLoader('', '', '', '', '')
    assert isinstance(obj_0.find_plugin_with_context(str_0), PluginLoadContext)


# Generated at 2022-06-25 10:20:05.460064
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    str_0 = '{'
    var_0 = get_shell_plugin(str_0)
    var_1 = get_shell_plugin(str_0)
    var_2 = get_shell_plugin(str_0)
    var_3 = get_shell_plugin(str_0)
    var_4 = get_shell_plugin(str_0)
    var_5 = get_shell_plugin(str_0)
    var_6 = get_shell_plugin(str_0)
    var_7 = get_shell_plugin(str_0)
    var_8 = get_shell_plugin(str_0)
    var_9 = get_shell_plugin(str_0)
    var_10 = get_shell_plugin(str_0)

# Generated at 2022-06-25 10:20:07.381710
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    str_0 = '-'
    var_0 = PluginLoader.__contains__(str_0)
    assert var_0 == '__contains__'


# Generated at 2022-06-25 10:20:12.103825
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    deprecation = {'warning_text': 'This plugin is deprecated.', 'removal_date': '2.9'}
    deprecation_text = 'This plugin is deprecated. It will be removed in version 2.9'
    case_0 = PluginLoadContext()
    case_0 = case_0.record_deprecation('name', deprecation, 'collection')
    assert case_0.deprecated == True
    assert case_0.removal_date == '2.9'
    assert case_0.removal_version == None
    assert case_0.deprecation_warnings[0] == deprecation_text


# Generated at 2022-06-25 10:20:14.218838
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    plugin_load_context = find_plugin_with_context(name=None, search_path=None, extension=None)
    # plugin_load_context = find_plugin_with_context(name=None, search_path=None, extension=None)


# Generated at 2022-06-25 10:20:16.996490
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():

    # Setup
    # TODO: implement

    # Testing
    # test_case_0()

    # Teardown
    # TODO: implement
    pass


# Generated at 2022-06-25 10:20:26.849805
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    print('test_add_all_plugin_dirs')
    if True:
        import ansible.plugins

        args = []
        if len(args) < 1:
            print('insufficient args, expected at least one')
        else:
            arg_0 = arg[0]
            arg_1 = arg[1]

            if type(arg_0) == bool:
                if arg_0:
                    arg_0 = True
                else:
                    arg_0 = False

            if type(arg_1) == bool:
                if arg_1:
                    arg_1 = True
                else:
                    arg_1 = False

            testfunc = 'add_all_plugin_dirs'

# Generated at 2022-06-25 10:20:35.642887
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    try:
        str_0 = '{'
        str_0 = get_shell_plugin(str_0)
    except SystemExit as var_0:
        # Unit test for method get of class PluginLoader
        test_PluginLoader_get()
        # Unit test for method get_plugin_path of class PluginLoader
        test_PluginLoader_get_plugin_path()
        # Unit test for method get_with_context of class PluginLoader
        test_PluginLoader_get_with_context()
        str_0 = '{'
        str_0 = get_shell_plugin(str_0)
    finally:
        # Unit test for method has_plugin of class PluginLoader
        test_PluginLoader_has_plugin()
        # Unit test for method all of class PluginLoader
        test_PluginLoader_all()
        # Unit test for method

# Generated at 2022-06-25 10:20:37.372179
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    path, subdir = Path("/opt/ansible/plugins"), ""
    add_all_plugin_dirs("/opt/ansible/plugins")



# Generated at 2022-06-25 10:20:46.309544
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    file_0 = open('/etc/passwd')
    str_0 = '{'
    list_0 = ['/etc/passwd', 'README.md']
    dict_0 = {}
    dict_1 = {}
    dict_1['1'] = file_0
    dict_0['0'] = dict_1
    str_1 = '{'
    var_0 = get_shell_plugin(str_1)
    var_1 = get_shell_plugin(str_0)
    var_2 = PluginLoader.all(str_1, str_0, str_0, str_1)
    str_2 = '{'
    var_3 = PluginLoader.all(str_2, str_0, True, False, list_0, None)