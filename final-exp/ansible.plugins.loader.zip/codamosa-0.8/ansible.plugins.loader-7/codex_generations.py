

# Generated at 2022-06-11 15:04:30.537276
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    import tempfile
    temp_plugindir_path = tempfile.mkdtemp()
    test_dir_list = []
    for item in PLUGIN_PATH_CACHE:
        test_dir_list.append(item)
    add_all_plugin_dirs(temp_plugindir_path)
    for item in PLUGIN_PATH_CACHE:
        try:
            test_dir_list.index(item)
        except Exception:
            raise AssertionError("test_add_all_plugin_dirs failed")



# Generated at 2022-06-11 15:04:43.046473
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    PL = PluginLoader('ansible.plugins.action', 'ActionModule')
    plugins_instances = PL.all()

    import ansible.plugins.action  # pylint: disable=redefined-outer-name,import-error
    import inspect  # pylint: disable=redefined-outer-name,import-error
    plugins_classes = dict(inspect.getmembers(ansible.plugins.action, inspect.isclass))

    for instance in plugins_instances:
        if inspect.isclass(instance):
            continue
        name = instance._load_name
        if name not in plugins_classes:
            pytest.fail("Instance of '%s' does not have a matching class" % name)

# Generated at 2022-06-11 15:04:54.594197
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    import os
    import tempfile
    from ansible.plugins import action_loader
    from ansible.plugins import connection_loader
    from ansible.plugins import shell_loader
    from ansible.plugins import filter_loader
    from ansible.plugins import lookup_loader
    from ansible.plugins import module_utils_loader
    from ansible.plugins import netconf_loader
    from ansible.plugins import terminal_loader
    from   ansible.plugins import cliconf_loader
    from ansible.plugins import strategy_loader
    from ansible.plugins import vars_loader
    from ansible.plugins import callback_loader
    from ansible.plugins import httpapi_loader
    from ansible.plugins import cache_loader
    from ansible.plugins import test_loader
    from ansible.plugins import fragments_loader

# Generated at 2022-06-11 15:04:56.563598
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    assert False, 'This test needs to be filled out'


# Generated at 2022-06-11 15:04:59.848977
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    PL = PluginLoader('Foo', 'Foo.plugins', C.CACHE_PLUGIN_FILENAME)
    assert PL.all() == []


# Generated at 2022-06-11 15:05:08.756942
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    # python 2 and python 3 have different ways of testing the code
    if sys.version_info[0] < 3:
        # python 2.x
        from ansible.module_utils.six.moves import builtins
        builtins.__dict__['_'] = str
    else:
        # python 3.x
        from ansible.module_utils.six import PY2
        PY2 = False

    shell = get_shell_plugin(shell_type='csh', executable='/bin/csh')
    assert shell.SHELL_TYPE == 'csh'
    assert shell.executable == '/bin/csh'
    shell = get_shell_plugin(shell_type='fish', executable='/bin/fish')
    assert shell.SHELL_TYPE == 'fish'

# Generated at 2022-06-11 15:05:20.079969
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    class Paths(object):
        def __init__(self, paths):
            self.paths = paths
        def all(self):
            return self.paths
    class DummyLoader(object):
        def __init__(self, paths):
            self.paths = paths
        def add_directory(self, path, with_subdir=True):
            self.paths.append(path)
    paths = Paths([])
    loader = DummyLoader(paths)
    add_dirs_to_loader(loader, ['/foo'])
    assert paths.paths == ['/foo']
    add_dirs_to_loader(loader, ['/bar', '/baz'])
    assert paths.paths == ['/foo', '/bar', '/baz']


# This is used to allow us to not break

# Generated at 2022-06-11 15:05:26.463679
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert str(get_shell_plugin('sh')) == '<ansible.plugins.shell.ShellModule object at 0x7f2b7f94d0b8>'
    assert str(get_shell_plugin('sh', 'sh')) == '<ansible.plugins.shell.ShellModule object at 0x7f2b7f94d198>'
    try:
        get_shell_plugin()
    except AnsibleError:
        pass
    else:
        raise AssertionError("AnsibleError not raised")



# Generated at 2022-06-11 15:05:33.974701
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    '''
    Unit test for method __contains__ of class PluginLoader
    '''
    loader = PluginLoader('', '', '', '', '')
    assert loader.has_plugin('name'), 'Plugins are not detected in the loader'
    assert not loader.has_plugin('name2'), 'Non existent plugin name2 should not exist'
    assert 'name' in loader, 'name in loader should be True'
    assert 'name2' not in loader, 'name2 not in loader should be True'


# Generated at 2022-06-11 15:05:43.622462
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    path_unused = __file__
    l = PluginLoader('foo', '', 'plugins')
    r = l.find_plugin('shell')
    assert r == 'shell'
    r = l.find_plugin('ansible_collections.acme.foo')
    if r is None:
        # if the collections framework is not available, skip unit test
        return
    assert r == 'shell'
    r = l.find_plugin('acme.foo')
    assert r == 'shell'
    r = l.find_plugin('ansible_collections.acme.foo.shell')
    assert r == 'shell'
    r = l.find_plugin('acme.foo.shell')
    assert r == 'shell'

# Generated at 2022-06-11 15:06:27.395739
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)
    os.makedirs(os.path.join(tmpdir, 'ansible', 'plugins', 'filter_plugins'))
    os.makedirs(os.path.join(tmpdir, 'ansible', 'plugins', 'action_plugins'))
    mock_filter_plugin = "def test_func(text):\n  return text\n"
    foo_filter_path = os.path.join(tmpdir, 'ansible', 'plugins', 'filter_plugins', 'foo.py')
    with open(foo_filter_path, "w") as f:
        f.write(mock_filter_plugin)

# Generated at 2022-06-11 15:06:38.167049
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    plugin_loaders = (
        Jinja2Loader('ansible.plugins.filter_loader', 'FilterModule', C.DEFAULT_FILTER_PLUGIN_PATH, 'filter_plugins'),
        Jinja2Loader('ansible.plugins.test_loader', 'TestModule', C.DEFAULT_TEST_PLUGIN_PATH, 'test_plugins'),
    )
    for loader in plugin_loaders:
        assert loader.find_plugin('core.match') is None
        assert loader.find_plugin('core.match', collection_list=['ansible.legacy']) == 'core/match.py'
        assert loader.find_plugin('core.match', collection_list=['my.collection']) == 'my_collection.core/match.py'

# Generated at 2022-06-11 15:06:43.080923
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    paths = ['/etc/ansible/colections/nsr',
             '/etc/ansible/colections/nsr/modules',
             ]
    for path in paths:
        if not os.path.isdir(path):
            os.makedirs(path)

# Generated at 2022-06-11 15:06:51.036997
# Unit test for function add_all_plugin_dirs

# Generated at 2022-06-11 15:07:03.467490
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # Remove directories from all plugin loaders to test plugin loaders are clean
    for name, obj in get_all_plugin_loaders():
        obj.directories = []

    # Test correct directories are added to correct plugin loaders
    # The directory structure is:
    # test_add_dirs_to_loader
    # ├── action
    # ├── cache
    # ├── connection
    # ├── shell
    # └── lookup
    #     └── acme
    #         ├── test_plugin.py
    #         └── test_readme.rst
    add_dirs_to_loader('action', ['./action'])
    add_dirs_to_loader('cache', ['./cache'])
    add_dirs_to_loader('connection', ['./connection'])
    add_dirs_to

# Generated at 2022-06-11 15:07:10.422685
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    system_plugin_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'plugins')
    user_plugin_path = os.path.join(os.path.expanduser('~'), '.ansible')
    custom_path = '/dev/null'

    # set ansible plugin path environment variable
    os.environ[C.DEFAULT_PLUGIN_PATH_ENV_VAR] = ':'.join((system_plugin_path, user_plugin_path, custom_path))

    add_all_plugin_dirs(system_plugin_path)

    for loader_name, loader in get_all_plugin_loaders():
        assert loader.directories == [to_bytes(system_plugin_path, errors='surrogate_or_strict')]

    add_

# Generated at 2022-06-11 15:07:17.673527
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    """Test the add_all_plugin_dirs function."""
    # Avoid modifying the existing global.
    old_collections_paths = C.DEFAULT_COLLECTIONS_PATHS
    old_plugin_dirs = get_all_plugin_loaders()

    C.DEFAULT_COLLECTIONS_PATHS = [os.path.join(os.path.dirname(__file__), '../../../test/support/ansible_collections/ansible_namespace/test_collections/library')]
    add_all_plugin_dirs('/dev/null')

    assert tuple(old_plugin_dirs) == tuple(get_all_plugin_loaders())

    # Restore the globals.
    C.DEFAULT_COLLECTIONS_PATHS = old_collections_paths


# Generated at 2022-06-11 15:07:26.794967
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    import sys
    import collections

    import pytest
    import ansible.errors as errors
    import ansible.plugins as plugins
    import ansible.utils.plugin_docs as plugin_docs

    pytestmark = pytest.mark.skipif(not HAS_IMPORTLIB, reason='has_importlib needs to be True')
    FakePluginLoader = collections.namedtuple('FakePluginLoader', ['package', 'subdir'])
    def fake_load_context(context, name, suffix=None, class_only=False, collection_list=None):
        return context.nope('{0} is not eligible for last-chance resolution'.format(name))

    # make sure this isn't already loaded from elsewhere, which can impact our tests

# Generated at 2022-06-11 15:07:38.281778
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Setup
    original_plugin_paths = frozenset(obj.plugin_path for name, obj in get_all_plugin_loaders() if obj.plugin_path)

    test_plugin_path = '/tmp/ansible_test_add_all_plugin_dirs'

    if not os.path.exists(test_plugin_path):
        os.makedirs(test_plugin_path)
    for plugin_loader in get_all_plugin_loaders():
        if plugin_loader[1].subdir:
            os.mkdir(os.path.join(test_plugin_path, plugin_loader[1].subdir))
    # Test
    add_all_plugin_dirs(test_plugin_path)
    # Verify
    for plugin_loader in get_all_plugin_loaders():
        name,

# Generated at 2022-06-11 15:07:46.575577
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    import ansible_collections.testns.testcoll.plugins.module_utils.basic

    test_loader = PluginLoader('testns.testcoll.plugins.module_utils.basic', 'BasicPlugin', 'ansible_collections.testns.testcoll.plugins.module_utils.basic')
    obj_iter = test_loader.all()
    obj_list = list(obj_iter)
    
    obj_count = len(obj_list)
    assert obj_count == 2
    assert isinstance(obj_list[0], BasicPlugin)
    assert isinstance(obj_list[1], BasicPlugin)



# Generated at 2022-06-11 15:08:35.316884
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    import ansible.collections.ansible_collections.community.general.plugins.action

    pl = PluginLoader(
        'ActionModule',
        'ansible_collections.community.general.plugins.action',
        'action_plugins',
    )

    rv = pl.get_with_context(
        name='ping',
        class_only=False,
        collection_list=None,
    )

    assert rv.plugin_resolved_name == 'ping'
    assert isinstance(rv.object, ansible_collections.community.general.plugins.action.ActionModule)
    assert rv.resolved
    assert rv.redirect_list == ['ping']



# Generated at 2022-06-11 15:08:37.268406
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    '''
    Unit test for method __contains__ of class PluginLoader
    '''
    # nothing to test



# Generated at 2022-06-11 15:08:46.402498
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    expected = [
        'AnsibleActionModule',
        'AnsibleCallbackModule',
        'AnsibleConnectionPlugin',
        'AnsibleFinderPlugin',
        'AnsibleFilterModule',
        'AnsibleLookupModule',
        'AnsibleModulePlugin',
        'AnsibleShellModule',
        'AnsibleTestPlugin',
        'AnsibleVarsModule',
        'LookupModule',
        'VarsModule',
    ]

    class_names = [plugin.__class__.__name__ for plugin in ActionLoader().all()]
    assert sorted(class_names) == expected



# Generated at 2022-06-11 15:08:50.725523
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    import ansible.plugins.loader
    dir(ansible.plugins.loader)
    test_PluginLoader_all_obj = ansible.plugins.loader.PluginLoader('action_plugin', 'ActionModule', C.DEFAULT_ACTION_PLUGIN_PATH, '')
    return (test_PluginLoader_all_obj, )



# Generated at 2022-06-11 15:09:02.103794
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    p = PluginLoadContext()
    name = 'plugin.name'
    collection_name = 'collection.name'
    warning_text = 'lol text'
    removal_date = 'today, today'
    removal_version = 'today'

    # None
    p.record_deprecation(name, None, collection_name)
    assert p.deprecation_warnings == []

    # empty dict
    p.record_deprecation(name, {}, collection_name)
    assert p.deprecation_warnings == []

    # without text
    p.record_deprecation(name, {'warning_text': ''}, collection_name)
    assert p.deprecation_warnings == [name + ' has been deprecated.']

    # with text

# Generated at 2022-06-11 15:09:14.793614
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    from ansible.plugins.loader.connection import ConnectionPluginLoader
    from ansible.plugins.loader.test import TestPluginLoader
    from ansible.plugins.loader.cache import CachePluginLoader
    from ansible.plugins.loader.netconf import NetconfPluginLoader
    from ansible.plugins.loader.callback import CallbackBasePluginLoader
    from ansible.plugins.loader.action import ActionPluginLoader
    from ansible.plugins.loader.shell import ShellPluginLoader
    from ansible.plugins.loader.lookup import LookupPluginLoader
    from ansible.plugins.loader.strategy import StrategyPluginLoader
    from ansible.plugins.loader.terminal import TerminalPluginLoader
    from ansible.plugins.loader.vars import VarsPluginLoader
    from ansible.plugins.loader.filter import FilterPluginLoader

# Generated at 2022-06-11 15:09:22.778040
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():

    # Run tests for correct return when plugin_load_context does not contain anything
    plugin_load_context = PluginLoadContext(None, None, None, None)
    assert plugin_load_context.plugin_resolved_path is None
    assert plugin_load_context.plugin_resolved_name is None
    assert plugin_load_context.resolved is None

    # Test 1: plugin_load_context contains the
    #         full path after resolution
    plugin_load_context = PluginLoadContext(None, None, True,
                                            'test_absolute_path')
    assert plugin_load_context.plugin_resolved_path is not None
    assert plugin_load_context.resolved is not None

    # Test 2: plugin_load_context contains the
    #         plugin name after resolution

# Generated at 2022-06-11 15:09:29.323259
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Check that if we add a directory to the PluginLoader it shows up in the path_list
    p = PluginLoader(package='ansible.plugins.test',
                     directories=[os.path.dirname(__file__) + '/plugins/test_plugins'])
    path_list = p._get_paths()
    assert path_list != [os.path.dirname(__file__) + '/plugins/test_plugins'], path_list

# Generated at 2022-06-11 15:09:39.213067
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    # check shell type
    test_shell = get_shell_plugin()
    assert test_shell.SHELL_FAMILY == 'sh'

    # check shell executable
    test_shell = get_shell_plugin(executable='/bin/csh')
    assert test_shell.executable == '/bin/csh'

    # check shell executable and file name
    test_shell = get_shell_plugin(executable='/bin/sh')
    assert test_shell.executable == '/bin/sh'
    test_shell = get_shell_plugin(executable='/bin/dash')
    assert test_shell.executable == '/bin/dash'
    test_shell = get_shell_plugin(executable='/usr/bin/ash')
    assert test_shell.executable == '/usr/bin/ash'



# Generated at 2022-06-11 15:09:48.765985
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # TODO: Some unit tests would be nice

    # __init__ is tested in test_find_plugin

    # get is tested in test_find_plugin

    # has_plugin is tested in find_plugin

    # get_collection_info is tested in find_plugin

    # find_plugin is tested in test_find_plugin

    pl = PluginLoader(package='ansible.modules.some_fake_package', subdir='no_such_subdir')
    # This will raise an error if there is a problem
    assert pl.all() is not None

    # _update_object is called in get, so don't need to test
    # _display_plugin_load is called in get, so don't need to test
    # _get_paths is called in get, so don't need to test

    # _load_module_source is called in

# Generated at 2022-06-11 15:10:57.824256
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    import os
    import tempfile
    temp_dir = tempfile.mkdtemp(prefix='ansible-plugin-loader-temp')
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    temp_file.write(b'class TestPlugin():\n')
    temp_file.write(b'    pass\n')
    temp_file.close()
    plugin_loader = PluginLoader(import_path=os.path.join(temp_dir, 'test_namespace'), package='ansible.plugins.test_namespace')

# Generated at 2022-06-11 15:11:00.345571
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    executable = "/bin/sh"
    shell_type = "sh"
    shell = get_shell_plugin(shell_type, executable)
    assert shell.executable == executable

# Generated at 2022-06-11 15:11:08.949346
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Create a basic plugin loader class
    class TestLoader(PluginLoader):
        class_name = 'TestPluginClass'
        base_class = 'base_class'
        package = 'test_test'
        subdir = 'test_test_test'
        def __init__(self):
            super(TestLoader, self).__init__()

    # Create a temp directory to load the plugins from
    plugin_dir = tempfile.mkdtemp()

    # Create a temp file to test deduplication
    temp_handle, temp_path = tempfile.mkstemp(suffix='test_test.py', dir=plugin_dir)
    os.close(temp_handle)

    # Create a temp file to test class_only

# Generated at 2022-06-11 15:11:14.278404
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    import ansible.utils.context_objects
    from ansible.utils.context_objects import AnsibleContext

    from ansible.cli.arguments import context_objects
    context_objects['ansible_context'] = AnsibleContext()
    context_objects['invocation'] = ansible.utils.context_objects.CLIArgs()

    args = {}
    obj = PluginLoader(b'', '', '', '', '', '', [], [], {}, {}, [], [])

    assert not (b'' in obj)
    assert not (b'invalid_name' in obj)
    assert not (b'ansible.modules.cloud.azure' in obj)

# Generated at 2022-06-11 15:11:24.894968
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    pass
