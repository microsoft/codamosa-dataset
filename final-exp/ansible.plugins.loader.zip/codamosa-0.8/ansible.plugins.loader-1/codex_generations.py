

# Generated at 2022-06-11 15:03:44.946383
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    pass

# Generated at 2022-06-11 15:03:56.649643
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.utils.path import unfrackpath
    from ansible.plugins.loader import load_callback_plugins

    callback_dir = os.path.dirname(unfrackpath(load_callback_plugins.__file__)) + os.sep + 'callback'
    output = list(CallbackModuleLoader().all(callback_dir))

    # This is likely going to be a fragile test, as it assumes the exact contents of the
    # 'callback' directory in the codebase.
    if len(output) != 25:
        raise AssertionError("Expected 25 plugins, got %d" % len(output))

    plugin_names = [os.path.basename(p._original_path)[:-3] for p in output]

    assert 'default' in plugin_names
    assert 'debug' in plugin_names

# Generated at 2022-06-11 15:04:05.964812
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    def test(path_only, class_only, _dedupe_plugin_names, _dedupe_ansible_file_names, expected):
        assert _dedupe_ansible_file_names == False
        assert _dedupe_plugin_names == True
        assert path_only == False
        assert class_only == False
        assert expected == expected

    C.PLUGIN_PATH_CACHE = []
    C.JINJA2_PLUGINS_PATH = []

    from ansible.plugins.loader import Jinja2Loader
    from ansible.plugins.loader import _find_plugin

    C.JINJA2_PLUGINS_PATH.extend(['/some/path/to/plugins/j2_plugins'])


# Generated at 2022-06-11 15:04:18.050717
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Configure the parameters that would be set by the game environment
    namespace = 'ansible.plugins'
    class_name = 'module_utils'
    subdirs = []
    package = 'ansible.plugins'

    # Create an instance of PluginLoader with the specified configuration
    plugin_loader = PluginLoader(namespace, class_name, subdirs, package)

    # Invoke the method with the parameters
    directory_list = ['/path/to/directory']
    plugin_loader.add_directory(directory_list)

# Generated at 2022-06-11 15:04:26.258261
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    import tempfile
    from ansible.plugins.loader import PluginLoader

    # Set up a temp dir and a subdir within it.  The subdir is the type of plugin we
    # want to test with.
    main_dir = tempfile.mkdtemp()
    subdir = 'test_dir'
    os.mkdir(os.path.join(main_dir, subdir))

    # Create a PluginLoader object with the subdir as its subdir and then add the
    # main dir to search.  This should result in the subdir being added to the
    # loader's search path.
    plugin_loader = PluginLoader(subdir)
    plugin_loader.add_all_plugin_dirs(main_dir)

    assert plugin_loader.directories == [os.path.join(main_dir, subdir)]

# TOD

# Generated at 2022-06-11 15:04:28.439473
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    ''' loader must have attribute add_directory'''
    if not hasattr('add_directory'):
        return False
    return True


# Generated at 2022-06-11 15:04:30.340212
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # TODO: implement unit test for find_plugin_with_context()
    pass

# Generated at 2022-06-11 15:04:42.942118
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    path = os.path.join(os.path.dirname(__file__), '..', 'test_utils', 'fixtures','test_loader','action_plugins','test_plugin.py')
    # Test case when plugin is already resolved
    plugin_load_context = PluginLoadContext(plugin_name="test",
                                            plugin_resolved_path=path,
                                            plugin_collection=None,
                                            plugin_load_source="core")
    assert plugin_load_context.resolved
    final_load_context = _PluginLoader(package="ansible.plugins.action")._find_fq_plugin(name="test_plugin", extension="py", plugin_load_context=plugin_load_context)
    assert final_load_context.plugin_resolved_name == "test_plugin"
    assert final_load_

# Generated at 2022-06-11 15:04:46.005181
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    assert Jinja2Loader(plugin_dirs=[]).get('foo.py') == None


# Generated at 2022-06-11 15:04:48.412819
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # Make a test plugin with supported version
    temp_dir = tempfile.mkdtemp()
    plugin_file = os.path.join(temp_dir, 'test_plugin.py')

# Generated at 2022-06-11 15:05:41.076852
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():

    PL = PluginLoader('ansible.plugins.inventory', 'InventoryModule')
    PL._add_directory(os.path.join(os.path.dirname(__file__), '..'))

    # Test with a basic plugin
    name = 'test_inventory'
    with pytest.raises(AnsibleError) as e:
        PL.find_plugin(name)
    e.match('has no plugin by the name of')

    # Test with a plugin that we have in the test directory but that the plugin loader does not know
    name = 'test_plugin'
    with pytest.raises(AnsibleError) as e:
        PL.find_plugin(name)
    e.match('has no plugin by the name of')

    # Test that an error is raised if the plugin loader does not know about a plugin
    #

# Generated at 2022-06-11 15:05:42.232151
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    pass


# Generated at 2022-06-11 15:05:43.569570
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    assert PluginLoader.find_plugin(name='ping') == 'ping'

# Generated at 2022-06-11 15:05:54.751666
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    path = 'test/path'
    os.path.isfile = Mock(return_value=False)
    globals()['os'] = Mock()
    with patch.object(globals()['os'], 'path') as mock_path:
        mock_path.isdir.return_value = True
        add_all_plugin_dirs(path)
        mock_path.isdir.assert_called_with(to_bytes(path, errors='surrogate_or_strict'))

        mock_path.isdir.return_value = True
        mock_path.join.return_value = 'test/path/filter_plugins'
        add_all_plugin_dirs(path)
        mock_path.isdir.assert_called_with('test/path/filter_plugins')


# Generated at 2022-06-11 15:05:58.790121
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
  plugin_loader = PluginLoader('action_plugins', 'ActionModule', 'ansible.plugins.action', C.DEFAULT_INVOCATION_PLUGIN_PATH, 'action_plugin')
  res = plugin_loader.get_with_context('copy')
  assert(res.object.__class__.__name__ == 'ActionModule')
  assert(res.plugin_resolved_name == 'copy')
  assert(res.resolved)


# Generated at 2022-06-11 15:06:00.540461
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    return add_dirs_to_loader('callback',['/test_path/ansible/callbacks'])


# Generated at 2022-06-11 15:06:08.612410
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    all_loaders = get_all_plugin_loaders()
    for loader_name, loader_instance in all_loaders:
        test_dir = '/tmp/%s' % loader_name
        loader_instance.add_directory(test_dir)
        # Assert that the directory was actually added
        assert test_dir in loader_instance.get_directory_list()
        # Assert that no other plugin loader contains this directory
        for check_name, check_instance in all_loaders:
            if check_name == loader_name:
                continue
            assert not test_dir in check_instance.get_directory_list()
        loader_instance.remove_directory(test_dir)



# Generated at 2022-06-11 15:06:19.438254
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    from ansible.plugins import callback_loader, connection_loader, module_loader
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.action import ActionBase
    from ansible.plugins.connection import ConnectionBase
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.module_utils import ModuleUtils
    # Testing get_with_context for actions
    assert isinstance(ActionBase, type)
    assert issubclass(ActionBase, object)
    assert isinstance(callback_loader, PluginLoader)
    assert isinstance(connection_loader, PluginLoader)
    assert isinstance(module_loader, PluginLoader)
    assert issubclass(CallbackBase, object)
    assert issubclass(ConnectionBase, object)
    assert issubclass(ModuleUtils, object)

# Generated at 2022-06-11 15:06:22.124700
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type="sh")
    assert shell.HAS_JINJA == False
    assert shell.__name__ == "ShellModule"


# Generated at 2022-06-11 15:06:24.349058
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    get_shell_plugin(shell_type='sh')
    get_shell_plugin(shell_type='sh', executable='/bin/sh')



# Generated at 2022-06-11 15:07:06.933268
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    PLUGIN_PATH_CACHE.clear()
    add_all_plugin_dirs("/some/path/")
    assert PLUGIN_PATH_CACHE == {}
    tmp = os.path.realpath(os.path.join(os.path.dirname(__file__), '..', 'test', 'units', 'utils', 'for_plugins', 'test_plugin_path'))
    add_all_plugin_dirs(tmp)
    assert to_text(tmp) + '/filter_plugins' in PLUGIN_PATH_CACHE
    assert to_text(tmp) + '/inventory' in PLUGIN_PATH_CACHE
    assert to_text(tmp) + '/lookup_plugins' in PLUGIN_PATH_CACHE
    assert to_text(tmp) + '/module_utils'

# Generated at 2022-06-11 15:07:12.313227
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    class PluginLoaderStub(PluginLoader):
        def _get_paths(self):
            return [u'/prj/myplugins']
        def _get_relative_paths(self):
            return []
        def _get_candidate_names(self, name):
            return ['{0}.py'.format(name)]
    plugin_loader = PluginLoaderStub(u'prj.myplugins', 'ActionModule', 'action_plugins')
    name = u'a-module.py'
    fq_name = u'prj.myplugins.a-module'
    expected_fq_name = u'prj.myplugins.a-module'
    expected_resolved_name = u'a-module.py'
    expected_resolved_path = u'/prj/myplugins/a-module.py'


# Generated at 2022-06-11 15:07:23.343978
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    p = PluginLoader('action_plugin', package='ansible', config={'DEFAULT_ACTION_PLUGIN_PATH': os.path.join(FILES_PATH, 'action_plugins')}, subdir=None, check_declared=False)
    action_plugin_path = os.path.join(FILES_PATH, 'action_plugins')

# Generated at 2022-06-11 15:07:33.249393
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # we are going to create a function in the "ansible.plugins" module as if it were
    # a dynamically loaded module
    mock_module = type('MockModule', (), {})

    # define a few functions, one with the proper signature
    def mock_function1():
        return 1

    def mock_function2():
        return 2

    def mock_function3():
        return 2

    mock_module.mock_function1 = mock_function1
    mock_module.mock_function2 = mock_function2
    mock_module.mock_function3 = mock_function3
    mock_module.__file__ = 'mock_path'

    mock_module.DOCUMENTATION = '---'
    mock_module.EXAMPLES = '---'
    mock_module.RETURN = '---'

   

# Generated at 2022-06-11 15:07:41.700786
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    pl = PluginLoader(package='dummy_package', subdir='dummy_subdir', base_class='dummy_base_class')
    pl._searched_paths = ['a', 'b', 'c']
    pl._load_config_defs = Mock(return_value=None)
    pl._update_object = Mock(return_value=None)
    pl._display_plugin_load = Mock(return_value=None)
    pl.all = Mock(return_value=['dummy_base_class', 'dummy_base_class'])

# Generated at 2022-06-11 15:07:45.801265
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    """Test PluginLoader.add_directory()"""
    path = '/path/to/plugin'
    self = PluginLoader('foo', 'plugins')
    self.add_directory(path)
    assert self.package_path == ['/path/to/plugin']

# Generated at 2022-06-11 15:07:50.753772
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    args = dict()

    cls = PluginLoader
    loader = cls(**args)
    assert False == ('g' in loader)
    assert False == ('-m' in loader)
    assert True == ('ping' in loader)
    assert True == ('async_status' in loader)
    assert False == ('async_status_foo' in loader)

# Generated at 2022-06-11 15:07:54.156947
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    """Test case for add_all_plugin_dirs"""
    assert add_all_plugin_dirs('/tmp') == None
    assert add_all_plugin_dirs('/tmp/') == None


# Generated at 2022-06-11 15:08:02.094182
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    pl = PluginLoader('test', '', None)
    def test_add_directory(path):
        pl.directories.update(set(path))

    pl.add_directory = test_add_directory
    pl.subdir = 'test'

    test_dir = '/path/to/test'
    valid_dir = '/path/to/valid'
    invalid_dir = '/path/to/invalid'

    orig_isdir = os.path.isdir
    def isdir_side_effect(path):
        if path == test_dir:
            return True
        if path == valid_dir:
            return True
        if path == invalid_dir:
            return False
        raise ValueError

    os.path.isdir = isdir_side_effect

    add_all_plugin_dirs(test_dir)



# Generated at 2022-06-11 15:08:05.687477
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    ''' this function needs a better unit test.
    A mock file system should be created that contains
    directories and files, then different calls should be
    made to the function to ensure it works properly
    '''
    return



# Generated at 2022-06-11 15:08:37.963261
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():

    # test with a list of directories
    test_directories = []
    test_directories.append(os.path.expanduser("~/.ansible/test_plugins/filter_plugins"))
    test_directories.append(os.path.expanduser("~/.ansible/test_plugins/test_plugins"))
    test_directories.append(os.path.expanduser("~/.ansible/test_plugins/action_plugins"))

    my_loader = Jinja2Loader(package='ansible.plugins.test', subdir='filter_plugins')
    my_loader.add_directories(test_directories, with_subdir=True)

    # Test all the plugins in one directory
    found_plugins = {}

# Generated at 2022-06-11 15:08:48.101878
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.config.manager import ConfigManager
    from ansible.cli import CLI
    from ansible.utils._loader import get_all_plugin_loaders
    from ansible.utils.display import Display
    config_manager = ConfigManager(['test/test_plugin_loader/ansible_test.cfg'])
    display = Display()

    class MockCLI:
        def __init__(self):
            self.options = None

    # mock out the cli options used by CLIDownloader
    class MockOptions:
        listtags = False
        listtasks = False
        listhosts = False
        syntax = False
        diff = False
        connection = 'ssh'
        module_path = None
        forks = 5
        remote_user = None
        private_key_file = None
        ssh_common_args = None

# Generated at 2022-06-11 15:08:50.635889
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # FIXME: Just a smoke test for now
    obj = PluginLoader('', '', '', '', '').get_with_context('')
    assert obj is None


# Generated at 2022-06-11 15:08:51.671025
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    assert True

# Generated at 2022-06-11 15:08:52.780716
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    pass


# Generated at 2022-06-11 15:08:55.276873
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    '''
    Test to ensure that plugins are found as expected
    '''
    pass  # nothing to test here



# Generated at 2022-06-11 15:09:00.474181
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    loader = PluginLoader(
        'ansible.plugins.lookup',
        'LookupModule',
        C.DEFAULT_LOOKUP_PLUGIN_PATH,
        'lookup_plugins',
        required_base_class='LookupBase'
    )
    loader.find_plugin('password')

# Generated at 2022-06-11 15:09:13.316545
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    import shutil
    plugin_loader = PluginLoader('shell_test', 'plugins/shell_test', 'ansible.plugins.shell_test', C.DEFAULT_SHELL_PLUGIN_PATH, 'shell', 'ANSIBLESHELL_PLUGIN')
    plugin_loader.add_directory('./plugins/shell_test')
    plugin = plugin_loader.all()
    executable = './plugins/shell_test/shell_test.py'
    os.chmod(executable, 0o700)
    plugin_loader.set_default_plugins(plugin)
    shutil.copy(executable, './ansible/plugins/shell_test')
    shell = get_shell_plugin(executable=executable)
    assert plugin[0]._load_name == shell._load_name

# Generated at 2022-06-11 15:09:14.351714
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    pass



# Generated at 2022-06-11 15:09:21.177570
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    ctx = PluginLoadContext()
    deprecation = dict()
    deprecation['warning_text'] = 'sample warning'
    deprecation['removal_date'] = 'sample date'
    deprecation['removal_version'] = 'sample version'
    ctx.record_deprecation('test', deprecation, 'test_module')
    assert ctx.deprecated == True
    assert ctx.removal_date == 'sample date'
    assert ctx.removal_version == 'sample version'
    assert ctx.deprecation_warnings == ['test has been deprecated. sample warning']


# Generated at 2022-06-11 15:09:49.923004
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    '''
    Unit test for the PluginLoader() class method add_directory()
    '''
    pl = PluginLoader('testpath')
    assert pl._searched_paths == ['/data/home/ansible/testdata/plugins/testpath']
    pl.add_directory(os.path.join(ROOT_PATH, 'test/units/plugins/testpath2'))
    assert pl._searched_paths == ['/data/home/ansible/testdata/plugins/testpath', '/data/home/ansible/test/units/plugins/testpath2']


# Generated at 2022-06-11 15:10:00.705282
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    _loader = PluginLoader("ansible_collections.test.test_loader.test_namespace", "test_thing")
    _loader.add_directory("/tmp/test_collection")
    _loader.add_directory("/tmp/test_collection2")
    _plugin = _loader.find_plugin("test_thing_a")
    assert _plugin == "/tmp/test_collection/test_thing_a.py"
    _plugin = _loader.find_plugin("test_thing_b")
    assert _plugin == "/tmp/test_collection/test_thing_b.py"
    _plugin = _loader.find_plugin("test_thing_c")
    assert _plugin == "/tmp/test_collection2/test_thing_c.py"


# Generated at 2022-06-11 15:10:11.217259
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    # test using shell type, as a fallback to version 2
    shell = get_shell_plugin('sh')
    assert shell.SHELL_FAMILY == 'sh'

    # test using shell type
    shell = get_shell_plugin(shell_type='sh')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'

    # test using shell executable
    for executable in ['/bin/bash', '/usr/bin/zsh', '/usr/bin/csh']:
        shell = get_shell_plugin(executable=executable)
        assert shell.SHELL_FAMILY == 'csh'
        assert shell.executable == executable

# Generated at 2022-06-11 15:10:14.727594
# Unit test for method all of class PluginLoader
def test_PluginLoader_all(): plugin_loader = PluginLoader('cache', 'CacheModule', '', 'ansible.plugins.cache')

# Generated at 2022-06-11 15:10:22.498697
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    plugin_load_context = PluginLoadContext()
    plugin_load_context_with_deprecation = plugin_load_context.record_deprecation(name='unit_test', deprecation={'warning_text': 'a warning', 'removal_date': '2099-01-01'},collection_name=None)
    assert plugin_load_context_with_deprecation.deprecated == True
    assert plugin_load_context_with_deprecation.removal_date == '2099-01-01'
    assert plugin_load_context_with_deprecation.removal_version == None
    assert plugin_load_context_with_deprecation.deprecation_warnings == ['unit_test has been deprecated. a warning']
    plugin_load_context_with_deprecation = plugin_load_context.record

# Generated at 2022-06-11 15:10:32.751753
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
     
    import sys
    sys.path.append('/home/mjablons/dev/ansible/lib/ansible/plugins/action/')
    sys.path.append('/home/mjablons/dev/ansible/lib/ansible/plugins/callback/')
    sys.path.append('/home/mjablons/dev/ansible/lib/ansible/plugins/connection/')
    sys.path.append('/home/mjablons/dev/ansible/lib/ansible/plugins/lookup/')
    sys.path.append('/home/mjablons/dev/ansible/lib/ansible/plugins/vars/')
    sys.path.append('/home/mjablons/dev/ansible/lib/ansible/plugins/filter/')

# Generated at 2022-06-11 15:10:40.432142
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    print('Testing method get_with_context')
    loader = PluginLoader('ansible.plugins.lookup', 'LookupBase', 'lookup_plugin')
    # TODO: if method doesn't raise exception, we could return True as well
    try:
        loader.get_with_context('test')
    except:
        pass
    # TODO: there is probably a better way to test this
    obj = loader.get_with_context('test')
    print('ok')



# Generated at 2022-06-11 15:10:48.245056
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    import types
    import os.path
    import tempfile
    from ansible.module_utils.six import PY3

    # We need a place to put our plugins.  Create a temporary directory and add it to the module_utils
    # path, which is the default search path for all plugins.
    plugin_dir = tempfile.mkdtemp()
    if os.path.isabs(plugin_dir):
        # If the path is absolute, we can safely append it to the module_utils path.
        module_utils_path = _MODULE_UTILS_PATH + [plugin_dir]
    else:
        # we need to make an absolute path and include the current directory.
        module_utils_path = _MODULE_UTILS_PATH + [os.path.join(os.getcwd(), plugin_dir)]

    # create a basic

# Generated at 2022-06-11 15:10:57.510781
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():

    # TODO: Output plugin loader will likely have to be added to the
    #       'packages' tuple when output plugins are implemented.
    packages = ('connection', 'cache', 'lookup', 'inventory',
                'vars', 'filter', 'callback', 'test', 'terminal',
                'shell', 'strategy', 'action', 'become', 'cliconf',
                'httpapi', 'netconf', 'doc_fragments')

    # TODO: Add tests for finding plugins that do NOT exist

    # Test a plugin that exists
    # pylint: disable=too-many-nested-blocks
    for package in packages:
        if package in ('callback', 'test', 'doc_fragments'):
            base_class = 'CallbackModule'
            class_name = 'CallbackModule'
        else:
            base_class

# Generated at 2022-06-11 15:11:06.354780
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell_type = 'sh'
    shell = get_shell_plugin(shell_type)
    assert isinstance(shell, ShellModule)
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.SHELL_TYPE == 'sh'
    assert shell.executable == '/bin/sh'
    assert shell.no_log == False

    shell_type = 'bash'
    shell = get_shell_plugin(shell_type)
    assert isinstance(shell, ShellModule)
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.SHELL_TYPE == 'bash'
    assert shell.executable == '/bin/bash'
    assert shell.no_log == False

    shell_type = 'csh'
    shell = get_shell_plugin(shell_type)