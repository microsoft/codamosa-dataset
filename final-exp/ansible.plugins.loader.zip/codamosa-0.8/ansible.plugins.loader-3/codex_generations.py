

# Generated at 2022-06-11 15:05:08.400493
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    module_loader = ModuleLoader()
    cli_loader = CLILoader()
    test_path = '/test/path'
    module_loader.add_directory = MagicMock()
    cli_loader.add_directory = MagicMock()
    with patch("os.path.isdir"):
        with patch("ansible.plugins.loader.ModuleLoader.subdir", 'module_utils'):
            with patch("ansible.plugins.loader.CLILoader.subdir", 'cli'):
                add_all_plugin_dirs(test_path)
    module_loader.add_directory.assert_called_with('/test/path/module_utils')
    cli_loader.add_directory.assert_called_with('/test/path/cli')



# Generated at 2022-06-11 15:05:13.547284
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    args = dict(
        class_name='test_class_name',
        package='test_package',
        config_base_class='test_config_base_class'
    )
    plugin_loader = PluginLoader(**args)
    ret = plugin_loader.__contains__()
    assert ret is False



# Generated at 2022-06-11 15:05:18.638563
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    test_dir = os.path.dirname(__file__)
    loader_dirs = []
    shell_dirs = []
    which_loader = 'action'
    for loader_dirs, loader in plugin_loaders:
        if loader.subdir and loader_dirs:
            assert which_loader in loader.subdir
            loader_dirs = [os.path.join(test_dir, loader.subdir)]
            shell_dirs.extend(loader_dirs)
    assert add_dirs_to_loader(which_loader, shell_dirs)



# Generated at 2022-06-11 15:05:25.344464
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    import ansible.plugins.loader as loader_ns
    loader = loader_ns.PluginLoader('.', '', C.DEFAULT_CACHE_PLUGIN_TIMEOUT, package='ansible.plugins.cache')
    assert loader.get('cache.yaml') is not None
    assert loader.get('ansible.plugins.cache.yaml') is not None
    assert loader.get('ansible.plugins.cache.yaml') is loader.get('cache.yaml')
    assert loader.get('foo', class_only=True) is not None
    assert loader.get('ansible.plugins.foo', class_only=True) is not None
    assert loader.get('ansible.plugins.foo', class_only=True) is loader.get('foo', class_only=True)


# Generated at 2022-06-11 15:05:36.447265
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    from ansible.utils.collection_loader._collection_finder import PluginFinder
    from ansible.utils.collection_loader._collection_finder import get_collection_playbook_paths

    # Save current instance of PluginFinder
    pf = PluginFinder._instance

    # Create a new instance of PluginFinder
    PluginFinder._instance = PluginFinder()

    assert PluginFinder._instance != pf

    # Save current instance of get_collection_playbook_paths
    gcpp = get_collection_playbook_paths

    # Create a new instance of get_collection_playbook_paths
    def fake_gcpp(*args, **kwargs):
        return '/home/user/path/to/ansible/collections/ansible_collections/namespace/collection/plugins/doc_fragments/'
    get

# Generated at 2022-06-11 15:05:46.323765
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    ar = AutoRewind(sys)
    PLUGIN_PATH_CACHE.clear()
    MODULE_CACHE.clear()
    PATH_CACHE.clear()
    plugin_type_path = to_text(get_fixture_path('test_plugin_types'))
    add_all_plugin_dirs(plugin_type_path)
    for plugin_type in PluginLoader.all_plugin_types:
        with open(os.path.join(plugin_type_path, plugin_type, 'test_plugin_loader_plugin.py'), 'r') as f:
            file_content = f.read()
        assert to_text(file_content) == PLUGIN_PATH_CACHE[plugin_type]['test_plugin_loader_plugin']



# Generated at 2022-06-11 15:05:50.742634
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    which_loader = 'callback'
    paths = ['/tmp']
    add_dirs_to_loader(which_loader, paths)
    assert getattr(sys.modules[__name__], '%s_loader' % which_loader)._directories == set(paths)



# Generated at 2022-06-11 15:05:55.869804
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    """
    Test PluginLoader.__contains__
    """
    lo = PluginLoader('ansible.plugins.filter', 'TestModule', C.DEFAULT_INTERNAL_PLUGINS_PATH, 'test_module')
    assert 'test_module' in lo
    assert 'test_module2' not in lo


# Generated at 2022-06-11 15:06:06.223506
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    some_path = MagicMock()

    class TestablePluginLoader(PluginLoader):
        def _get_paths(self):
            return [some_path]

        def _display_plugin_load(self, class_name, name, searched_paths, path, found_in_cache=None, class_only=None):
            return

    # Test without any arguments
    test_loader = TestablePluginLoader('package', 'base_class', 'class_name')

    glob.glob.return_value = ['a', 'b']
    test_loader._module_cache['a'] = 'modulea'
    test_loader._module_cache['b'] = 'moduleb'

    plugin_a = MagicMock()
    plugin_b = MagicMock()


# Generated at 2022-06-11 15:06:13.109621
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionModule', base_class='ActionBase', required_base_class=False)
    assert plugin_loader.find_plugin_with_context('setup.py').plugin_resolved_name == 'setup.py'
    assert plugin_loader.find_plugin_with_context('setup.py').plugin_resolved_path == '/home/kubevirt/.ansible/collections/ansible_collections/ansible/builtin/plugins/action/setup.py'
    assert plugin_loader.find_plugin_with_context('setup.py').resolved
    assert plugin_loader.find_plugin_with_context('setup.py').plugin_resolved_collection
    assert plugin_loader.find_plugin_with_context('setup.py').plugin_resolved

# Generated at 2022-06-11 15:06:50.651938
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    ''' Test if plugin dirs are added'''
    fake_path = './test'
    b_fake_path = to_bytes(fake_path, errors='surrogate_or_strict')
    # prepare mocks
    with mock.patch.object(os.path, 'isdir', return_value=True):
        with mock.patch.object(os.path, 'join', return_value=b_fake_path):
            with mock.patch.object(PluginLoader, 'add_directory') as patch_add_directory:
                # call the tested function
                add_all_plugin_dirs(fake_path)
                calls = [mock.call(fake_path), mock.call(to_text(b_fake_path))]
                patch_add_directory.assert_has_calls(calls)




# Generated at 2022-06-11 15:06:52.127948
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    add_all_plugin_dirs(__file__)



# Generated at 2022-06-11 15:07:01.435116
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    expected = 'ansible.plugins.lookup.env'
    # FIXME: This entire test is a hack, but it'll work for now
    loader = PluginLoader('lookup', package='ansible.plugins.lookup', configurable=True, min_subdir_count=1)
    loader.add_directory(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'unit'))
    assert loader.find_plugin_with_context('env').plugin_resolved_name == expected


# Generated at 2022-06-11 15:07:09.415251
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    from ansible.plugins.loader import add_all_plugin_dirs
    import tempfile

    def setup_test_tree():
        executor = tempfile.TemporaryDirectory()
        callback_dir = os.path.join(executor.name, "callback")

        os.mkdir(callback_dir)
        os.mkdir(os.path.join(callback_dir, "not_a_dir"))

        os.mkdir(os.path.join(callback_dir, "a_dir"))

        with open(os.path.join(callback_dir, "a_dir", "test_callback.py"), "w") as f:
            f.write("")

        os.mkdir(os.path.join(executor.name, "filter"))


# Generated at 2022-06-11 15:07:21.209285
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    def run_test(self, name, plugin_load_context, res, trace):
        for item in trace:
            self.assertEqual(item[0], 'find_plugin')
            self.assertEqual(item[1]['name'], name)
            self.assertEqual(item[1]['plugin_load_context'], plugin_load_context)
            self.assertEqual(item[1]['plugin_load_context'].plugin_name, item[1]['name'])
            self.assertIsNotNone(item[1]['plugin_load_context'].plugin_load_context_id)
            self.assertEqual(item[1]['res'], res)


# Generated at 2022-06-11 15:07:28.788201
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    cl = PluginLoader('ignore_me', 'ignore_me', 'ignore_me')
    cl.aliases = {'a':'b', 'c':'d'}
    cl.find_plugin = lambda x, y: 'yay!'
    cl.get_with_context = lambda x, y, z: ['b', 'd', 'e']
    assert list(cl.all(class_only=True, collection_list=['foo'])) == ['b', 'd', 'e']
    assert list(cl.all(path_only=True, collection_list=['foo'])) == ['yay!']

    cl = PluginLoader('ignore_me', 'ignore_me', 'ignore_me')
    cl.aliases = {'a':'b', 'c':'d'}

# Generated at 2022-06-11 15:07:38.206597
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Call method find_plugin_with_context of class PluginLoader
    plugin_loader = PluginLoader(b'', '', require_one_plugin=False)
    assert plugin_loader.find_plugin_with_context(b'') is not None
    assert plugin_loader.find_plugin_with_context(b'', require_one_plugin=True) is not None
    assert plugin_loader.find_plugin_with_context(b'', plugin_load_context=PluginLoadContext()) is not None
    assert plugin_loader.find_plugin_with_context(b'', require_one_plugin=True, plugin_load_context=PluginLoadContext()) is not None


# Generated at 2022-06-11 15:07:48.240098
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    PL = PluginLoader('Modules', 'module_utils')
    PL.module_utils_paths = ['/var/lib/awx/projects/my_project/library']
    PL.extra_dirs = None
    PL.package = 'module_utils'
    PL.paths = ['/var/lib/awx/projects/my_project/library/module_utils']
    PL.subdir = ''
    PL._searched_paths = ['/var/lib/awx/projects/my_project/library']
    PL.class_name = 'ModuleUtilBase'
    PL.base_class = 'ModuleUtilBase'
    PL.aliases = {}

    # Test with args and kwargs
    args = []
    kwargs = {}
    i = PL.all(*args, **kwargs)

# Generated at 2022-06-11 15:07:55.406655
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Set up the arguments
    name = 'foo'
    args = ['bar']
    kwargs = {'baz': 'qux'}
    ansible_collection_name = 'test_collection_name'
    class_only = True

    # Invoke the method under test
    result = PluginLoader.get_with_context(name, args=args, kwargs=kwargs, ansible_collections_name=ansible_collection_name, class_only=class_only)

    # Check the results
    assert result is None



# Generated at 2022-06-11 15:08:02.808060
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    loader = PluginLoader(
        package='ansible_collections.ansible.builtin',
        class_name='module_utils.module_index.ModuleIndex',
        base_class=None,
        path=[
            "/home/vagrant/.ansible/tmp/ansible-local-19646yOLlh1l/tmp8DBniY/ansible_module_manageiq_configuration/"
        ],
        collection_list=None,
        subdir=None,
        aliases={},
    )

    with patch.object(loader, '_get_paths', lambda *args, **kwargs: ['_get_paths_return_']):
        loader.find_plugin('module_utils/module_index')
        assert loader.find_plugin('module_utils/module_index', suffix='py') == loader.find_

# Generated at 2022-06-11 15:08:40.121588
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
	assert True != False


# Generated at 2022-06-11 15:08:48.772956
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    plc = PluginLoadContext()
    # deprecation warning is displayed only if deprecation dict is not None
    warning_msg = plc.record_deprecation('name', None, 'collection_name').deprecation_warnings
    assert len(warning_msg) == 0
    # if deprecation_warning is not empty, it is stored in PluginLoadContext.deprecation_warning
    # expected warning message
    expected_msg = ['name has been deprecated.']
    assert expected_msg == plc.record_deprecation('name', {'warning_text': ''}, 'collection_name').deprecation_warnings
    expected_msg = ['name has been deprecated. warning_text']

# Generated at 2022-06-11 15:08:59.920413
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    p = PluginLoader('.', 'foo')
    p._module_cache = {
    }
    p._searched_paths = []
    p.class_name = 'Foo'
    p.base_class = 'Bar'
    p.package = 'baz'
    p.subdir = 'qux'
    p.config_definitions = {}
    p.aliases = {}
    importlib = Mock()
    display = Mock()
    glob = Mock()
    C = Mock()
    sys = Mock()
    importlib.util.spec_from_file_location.return_value = 'spec'
    importlib.util.module_from_spec.return_value = 'module'
    glob.glob.return_value = ['foo.py', 'bar.py']
    p.C = C


# Generated at 2022-06-11 15:09:12.849973
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.loader import module_loader
    from ansible.plugins.connection.paramiko import Connection as ParamikoConnection
    from ansible.plugins.connection.ssh import Connection as SSHConnection
    from ansible.errors import AnsibleError
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-11 15:09:21.701271
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test that add_directory is called when the path is a dir and the subdir also exists
    b_path = '/some/random/path'
    subdir = 'subdir'
    plugin_path = '/some/random/path/subdir'
    MockPluginLoader = namedtuple('MockPluginLoader', ['subdir', 'add_directory'])
    mock_plugin_loaders = [MockPluginLoader(subdir, None), MockPluginLoader(subdir, None)]

    # patch globals()
    _globals = globals()
    _globals['mock_plugin_loaders'] = mock_plugin_loaders
    _globals['__package__'] = None

# Generated at 2022-06-11 15:09:33.843403
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test when package_name is 'ansible.plugins.action'
    # and class_name is 'ActionModule'
    pl = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins')

    # Ensure that all() method is working properly
    # when duplicated results are not handled
    l = list(pl.all(_dedupe=False))
    assert l[0]._load_name == 'async_wrapper'
    assert l[1]._load_name == 'async_wrapper'
    assert l[2]._load_name == 'debug'
    assert l[3]._load_name == 'debug'
    assert l[4]._load_name == 'include_role'
    assert l[5]._load_name == 'include_role'

    # Ensure that all() method is working properly


# Generated at 2022-06-11 15:09:36.334463
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    from ansible.plugins.loader import all_plugin_loaders
    pl = all_plugin_loaders[0]
    pl.find_plugin_with_context('debug')



# Generated at 2022-06-11 15:09:46.788686
# Unit test for method find_plugin of class PluginLoader

# Generated at 2022-06-11 15:09:57.484694
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    conf = configparser.ConfigParser()
    conf.read(os.path.join(os.path.dirname(__file__), 'test/integration/ansible.cfg'))
    # print ("\nCONFIG FILE : \n")
    # print (conf)
    # print ("\n")
    # print ("\n")
    # print ("\n")

    # print (conf['defaults'],'\n')
    # print ("\n")
    # print ("\n")
    # print ("\n")

    # print (conf['defaults']['action_plugins'])
    # print (conf['defaults']['action_plugins'].split(','))
    # print ("\n")
    # print ("\n")
    # print ("\n")

    # print (conf['defaults'

# Generated at 2022-06-11 15:09:58.927894
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # FIXME #7511, write unit test
    pass
