

# Generated at 2022-06-11 15:04:06.228606
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # Instantiate an empty object of class PluginLoader
    # First, an empty object of class PluginLoader is instantiated
    loader = PluginLoader()
    # Test for the presence of the 'call' filter
    # A filter named 'call' is requested from the loader and is expected to be found
    assert 'call' in loader

# Generated at 2022-06-11 15:04:18.465248
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    plc = PluginLoadContext()
    assert not plc.deprecated
    assert plc.removal_version is None
    assert plc.removal_date is None
    assert len(plc.deprecation_warnings) == 0

    deprecation = {
       'warning_text': 'This functionality is deprecated and will be removed in a later release',
       'removal_version': '2.12',
    }

    plc = plc.record_deprecation('foo', deprecation, 'ansible.legacy')
    assert plc.deprecated
    assert plc.removal_version == '2.12'
    assert plc.removal_date is None
    assert len(plc.deprecation_warnings) == 1

# Generated at 2022-06-11 15:04:26.433561
# Unit test for method all of class Jinja2Loader

# Generated at 2022-06-11 15:04:34.829736
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # mock responses for testing
    class MockProviderResponse:
        @staticmethod
        def get_context_variables():
            return dict()

        def get_collections_for_package(self, package_name):
            return dict()

        def get_variable(self, name):
            return False

    class MockPluginLoadContext(MockProviderResponse):
        def __init__(self, package_name, fq_name, suffix):
            self.package_name = package_name
            self.fq_name = fq_name
            self.suffix = suffix

        def nope(self, msg):
            raise ValueError(msg)

    class MockDisplay:
        @staticmethod
        def debug(msg):
            pass

    display = MockDisplay()
    provider = MockProviderResponse()

    # ------------------------------------------------------------
    #

# Generated at 2022-06-11 15:04:46.754024
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    my_collection_list = [{
        'name': 'Fakes.collection',
        'version': '0.1.0',
        'path': 'c:\\users\\marc\\fakes.collection',
        'local_path': 'c:\\users\\marc\\fakes.collection',
    }]

    my_config = ConfigParser()
    my_config._sections = {
        'defaults': {
            'fact_caching_connection': '',
            'fact_caching_timeout': '',
            'fact_caching_prefix': '',
        },
        'ssh_connection': {
            'scp_if_ssh': '',
        },
    }


# Generated at 2022-06-11 15:04:57.167012
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    """Test for __setstate__"""

    obj = PluginLoader(type='test_type', package='test_package')
    if getattr(obj, '_ConfigLoader__searched_paths_dict', None) is not None:
        setattr(obj, '_ConfigLoader__searched_paths_dict', {})
    obj.__setstate__({})
    fake_search_paths = {('foo', 1): 2}
    fake_search_paths_list = []
    for k, v in fake_search_paths.items():
        key = base64.b64encode(pickle.dumps(k))
        fake_search_paths_list.append((key, v))

# Generated at 2022-06-11 15:05:07.304859
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    """
    Unit test for method all of class Jinja2Loader.
    """
    from ansible.plugins import filter_loader, test_loader

    # Create two test plugins with two jinja2 filters each
    # The first jinja2 filter in each file has the same name and will be
    # overwritten at the end
    tempdir1 = tempfile.mkdtemp()
    tempdir2 = tempfile.mkdtemp()
    os.makedirs(os.path.join(tempdir1, 'ansible/legacy/plugins/filter_plugins'))
    os.makedirs(os.path.join(tempdir2, 'ansible/legacy/plugins/filter_plugins'))

# Generated at 2022-06-11 15:05:18.416287
# Unit test for method __setstate__ of class PluginLoader

# Generated at 2022-06-11 15:05:27.683219
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    from ansible.plugins.shell import PluginLoader as ShellPlugin
    from ansible.errors import AnsibleError
    from ansible.modules.shell.solaris import ShellModule as SolarisShell
    import pytest
    sh_plugin = get_shell_plugin('sh')
    csh_plugin = get_shell_plugin('csh')
    solaris_plugin = get_shell_plugin('sh', '/usr/bin/sh')
    assert isinstance(sh_plugin, ShellPlugin)
    assert isinstance(csh_plugin, ShellPlugin)
    assert isinstance(solaris_plugin, ShellPlugin)
    assert sh_plugin.module_args == '/bin/sh'
    assert csh_plugin.module_args == '/bin/csh'
    assert solaris_plugin.module_args == '/bin/sh'


# Generated at 2022-06-11 15:05:38.225771
# Unit test for method __setstate__ of class PluginLoader

# Generated at 2022-06-11 15:07:00.864619
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    c = configparser.ConfigParser()
    c.read_string("""
[defaults]
lookup_plugin_path = ./lookup_plugins
filter_plugin_path = ./filter_plugins
""")
    o = Options(cli=c)
    p = PluginLoader('LookupModule', 'lookup_plugins', o, 'lookup_plugins', 'ansible.plugins.lookup')
    assert len([path for path in p.all(path_only=True)]) == 2
    # Ensure that de-duplication is not happening
    assert len([obj for obj in p.all(path_only=True)]) == 2
    assert len([obj for obj in p.all(path_only=True)]) == 2


# Generated at 2022-06-11 15:07:04.600548
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # TODO: Unit test for method get of class Jinja2Loader
    # FIXME: This is not a functional unit test, it's just a stub
    # REF: https://github.com/ansible/ansible/issues/67322
    raise NotImplementedError

# Generated at 2022-06-11 15:07:12.769414
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    global shell_loader
    shell_loader = C.DEFAULT_SHELL_PLUGIN_PATH
    which_loader = 'shell'
    paths = ['shells']
    paths[0] = os.path.join(C.data.ansible_path, 'lib', 'ansible', paths[0])
    add_dirs_to_loader(which_loader, paths)
    global shell_loader
    assert type(shell_loader) == list
    for path in paths:
        assert path in shell_loader


# Generated at 2022-06-11 15:07:23.833686
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test function PluginLoader.all()
    #
    # When instantiating a plugin loader, the value of the subdir attribute will be used
    # to dynamically construct a path name.
    # This test creates a fake plugin method called 'bogus' and creates fake directories
    # to represent a valid 'module_utils' subdir and an invalid 'bogus' subdir.
    # The source of the test is then set to the valid 'module_utils' directory.
    #
    # It then instantiates an instance of PluginLoader with a subdir value of 'bogus'
    # and is then called with a call_method of 'all'
    #
    # The test should return a generator object, which is tested for, and not throw
    # an exception for a non-existent 'bogus' subdir.

    import os
    import ansible

# Generated at 2022-06-11 15:07:34.512691
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    for plugin_type in ('modules', 'module_utils', None):
        for loader_type in ('action', 'connection', 'shell', 'module_utils', 'fragment'):
            if plugin_type == 'module_utils':
                # some module_utils plugins have the default path set to 'module_utils'.
                # This is not great, but we can't fix anyything now as it would be a
                # backwards incompatible change.
                set_default_directories(loader_type=loader_type, directories=('module_utils', 'lib'))
            else:
                set_default_directories()

            loader = PluginLoader(plugin_type, package=loader_type, subdir=None, directories=None)

# Generated at 2022-06-11 15:07:42.123039
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    plugin_loaders = get_all_plugin_loaders()
    test_path = '/tmp/ansiballz-test-plugins'
    if os.path.exists(test_path):
        import shutil
        shutil.rmtree(test_path)
    os.mkdir(test_path)
    for name, loader in plugin_loaders:
        if loader.subdir:
            plugin_path = os.path.join(test_path, loader.subdir)
            os.mkdir(plugin_path)
            open(os.path.join(plugin_path, '__init__.py'), 'a').close()
            open(os.path.join(plugin_path, 'test_plugin%s.py' % loader.name), 'a').close()

# Generated at 2022-06-11 15:07:50.194356
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    path = "~/.ansible/test_plugin/"

    # print("current sys.path is %r" % sys.path)
    try:
        sys.path.remove(path)
    except:
        pass

    if not os.path.exists(path):
        os.makedirs(path)

    for name, obj in get_all_plugin_loaders():
        # create directories for plugin subtype
        # if subtype is not given, it is considered as empty string
        if obj.subdir:
            subpath = os.path.join(path, obj.subdir)
            os.makedirs(subpath)
            f = open(os.path.join(subpath, 'test.py'), 'a+')
            f.close()

    add_all_plugin_dirs(path)

    #

# Generated at 2022-06-11 15:07:54.863040
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    plugin_load_context = PluginLoadContext(directories=__file__)
    plugin_load_context.plugin_name = 'test_collection.test_plugins.test_plugin'
    result = PluginLoader().find_plugin(plugin_load_context=plugin_load_context)
    assert result == __file__

# Generated at 2022-06-11 15:07:58.349570
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    dirs = ('/test/module1','/test/module2')
    add_dirs_to_loader('module', dirs)
    loader = sys.modules[__name__].module_loader
    assert loader._get_paths() == dirs


# Generated at 2022-06-11 15:08:08.512615
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    '''
    Test add_all_plugin_dirs
    '''
    from ansible.plugins import action

    import shutil
    import tempfile
    import unittest

    class TestPluginLoader(unittest.TestCase):

        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

            self.plugin_dir = os.path.join(self.tempdir, 'plugins')
            os.mkdir(self.plugin_dir)

            self.subdir1 = os.path.join(self.plugin_dir, 'subdir1')
            os.mkdir(self.subdir1)
            self.subdir2 = os.path.join(self.plugin_dir, 'subdir2')
            os.mkdir(self.subdir2)

            self.fake_plugin = os

# Generated at 2022-06-11 15:08:38.279231
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.plugins.collection import ansible_collections

    test_collection = u'test_namespace.test_collection'

    collections_paths = [
        os.path.join(os.path.dirname(__file__), 'data', 'files', 'test_collections', 'ns', 'coll', 'plugins', 'modules'),
        os.path.join(os.path.dirname(__file__), 'data', 'files', 'test_collections', 'ns', 'coll', 'plugins', 'module_utils')
    ]

    paths = C.config.get_config_value('COLLECTIONS_PATHS', include_none=False)

# Generated at 2022-06-11 15:08:48.219119
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    '''
    Unit test function for lib/ansible/utils/plugin_docs

    This function tests the add_directory method of class PluginLoader
    '''

    def fake_get_collection_name(path):
        return 'test'

    def fake_warnings_simplefilter_is_magic(warnings, magic):
        return True

    def fake_warnings_warn(warnings, warning):
        return None

    def fake_getcwd():
        return '/path/to/cwd'

    def fake_os_path_exists(path):
        return True

    def fake_os_path_isdir(path):
        return True

    def fake_os_path_expanduser(path):
        return path

    def fake_os_path_normcase(path):
        return path

    #################################################################################################################

# Generated at 2022-06-11 15:08:59.056291
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    deprecation = {
        'removal_version': '4.4.0',
    }
    plc = PluginLoadContext()
    plc.record_deprecation(name='module', deprecation=deprecation, collection_name='foo.bar')
    assert plc.deprecated == True
    assert plc.removal_version == '4.4.0'

    deprecation = {
        'warning_text': 'this is a test',
        'removal_version': '4.4.0',
    }
    plc = PluginLoadContext()
    plc.record_deprecation(name='module', deprecation=deprecation, collection_name='foo.bar')
    assert plc.deprecated == True
    assert plc.removal_version == '4.4.0'


# Generated at 2022-06-11 15:09:10.624073
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():

    # Try to get a plugin for a non-existing lookup plugin
    mock_lookup_plugin_mgr = type('MockLookupPluginManager', (object,), {'package': 'ansible.plugins.lookup'})
    mock_display_mgr = type('MockDisplayManager', (object,), {'__eq__': lambda self, other: True, '__getitem__': lambda self, key: True})
    mock_display = type('MockDisplay', (object,), {'debug': lambda self, msg, *args, **kwargs: None})
    mock_config = type('MockConfig', (object,), {'get_config_value': lambda self, key, *args, **kwargs: None})

# Generated at 2022-06-11 15:09:13.107213
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert get_shell_plugin() == sh



# Generated at 2022-06-11 15:09:21.851889
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    print("test_PluginLoader_find_plugin_with_context")
    plugin_load_context = PluginLoaderFindWithContext()
    plugin_load_context.candidates.append(('ansible.plugins.test', 'test', 'test', 'test'))
    plugin_load_context.candidates.append(('ansible.plugins.test', 'test', 'test', 'test1'))
    plugin_load_context.candidates.append(('ansible.plugins.test', 'test', 'test', 'test2'))
    pl = PluginLoader(package='ansible.plugins.test', class_name='test', config={})

    pl._find_fq_plugin(fq_name= None, extension= None, plugin_load_context= plugin_load_context)
    assert plugin_load_context.nope_count == 3

# Generated at 2022-06-11 15:09:33.843425
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    from ansible.plugins.loader import plugin_loader, connection_loader, module_loader, callback_loader, fragment_loader
    from ansible.plugins.loader import lookup_loader, filter_loader, test_loader, cache_loader

    add_all_plugin_dirs("/path/to/nowhere")
    assert os.path.expanduser('~/.ansible/plugins/connection') not in connection_loader._get_paths()
    assert os.path.expanduser('~/.ansible/plugins/callback') not in callback_loader._get_paths()
    assert os.path.expanduser('~/.ansible/plugins/module_utils') not in module_loader._get_paths()
    assert os.path.expanduser('~/.ansible/plugins/modules') not in module_loader._get_paths()


# Generated at 2022-06-11 15:09:35.634783
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    assert Jinja2Loader.get() # FIXME: mock the class and implement your test

# Generated at 2022-06-11 15:09:46.012961
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    '''
    Unit test for method find_plugin_with_context of class PluginLoader
    '''
    context = PluginLoader.PluginLoadContext()
    class_loader = PluginLoader('ansible_collections.testns.apache', 'CollectionsTest')
    plugin_load_context = class_loader.find_plugin_with_context('apache_module', collection_list=['ansible_collections.testns.apache'])
    if not plugin_load_context.resolved:
        raise Exception("Unit test failed: {0}".format(to_text(plugin_load_context.error)))

# Generated at 2022-06-11 15:09:47.385585
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    assert isinstance(add_all_plugin_dirs, object)

# Generated at 2022-06-11 15:10:27.522750
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    for name, obj in get_all_plugin_loaders():
        obj.directories = []
    test_path1 = "../test/test_data/test_plugins"
    test_path2 = "../test/test_data/no_plugin_types"
    test_path3 = "../test/test_data/not_a_directory"
    test_path4 = "../test/test_data/test_plugins_subdir"
    add_all_plugin_dirs(test_path1)
    add_all_plugin_dirs(test_path2)
    add_all_plugin_dirs(test_path3)
    add_all_plugin_dirs(test_path4)
    for name, obj in get_all_plugin_loaders():
        if obj.subdir:
            test_path

# Generated at 2022-06-11 15:10:35.046815
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():

    # Simple test
    context = PluginLoadContext()
    context = context.record_deprecation('foo', {'warning_text': 'bar'}, 'collection')
    assert context.deprecated == True
    assert context.removal_date == None
    assert context.removal_version == None
    assert context.deprecation_warnings == ['foo has been deprecated. bar']

    # Test with a removal_version
    context = PluginLoadContext()
    context = context.record_deprecation('foo', {'removal_version': '2.4'}, 'collection')
    assert context.deprecated == True
    assert context.removal_date == None
    assert context.removal_version == '2.4'
    assert context.deprecation_warnings == ['foo has been deprecated. Will be removed in version 2.4']

# Generated at 2022-06-11 15:10:45.314604
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    tmp_plugin_dir = os.path.join(C.DEFAULT_LOCAL_TMP, 'old_plugin_dir')
    if os.path.exists(tmp_plugin_dir):
        shutil.rmtree(tmp_plugin_dir)
    os.makedirs(tmp_plugin_dir)
    for loader_name, loader in get_all_plugin_loaders():
        if loader.subdir:
            loader.directories = None
    add_all_plugin_dirs(tmp_plugin_dir)
    for loader_name, loader in get_all_plugin_loaders():
        if loader.subdir:
            assert len(loader.directories) == 1
            assert loader.directories[0] == os.path.join(tmp_plugin_dir, loader.subdir)



# Generated at 2022-06-11 15:10:45.789445
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    pass

# Generated at 2022-06-11 15:10:49.441325
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    pl = PluginLoader( 'ansible.plugins.connection', 'ConnectionBase', C.DEFAULT_CONNECTION_PLUGIN_PATH, 'connection')
    for plugin in pl.all():
        print("plugin: " + str(plugin))

# ------------------------------
# API to look for specific plugins
# ------------------------------

# Look for cache plugin

# Generated at 2022-06-11 15:10:50.410686
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    assert True

# Generated at 2022-06-11 15:10:59.898355
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    loader = PluginLoader.loaders['']
    # Test 1:
    # Test default find_plugin where argument 'name' is without 'ansible_collections'
    if not isinstance(loader.find_plugin('setup', collection_list=[], plugin_type=None, class_name=None), AnsibleNotFound):
        raise AssertionError('Setup could not be found with name=setup')

    # Test 2:
    # Test find_plugin if argument 'name' is with 'ansible_collections'
    if not isinstance(loader.find_plugin('ansible_collections.acme.test.setup', collection_list=[], plugin_type=None, class_name=None), AnsibleNotFound):
        raise AssertionError('Setup could not be found with name=ansible_collections.acme.test.setup')



# Generated at 2022-06-11 15:11:08.534239
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():

    class MockPluginLoader:
        def __init__(self, subdir):
            self.subdir = subdir
            self.dirs = []

        def add_directory(self, path):
            self.dirs.append(path)

    plugin_loader = MockPluginLoader(subdir='rundir')
    setattr(sys.modules[__name__], "MockPluginLoader", plugin_loader)

    path = '/path/to/inventory'
    add_all_plugin_dirs(path)
    assert not plugin_loader.dirs
    os.makedirs(path)
    add_all_plugin_dirs(path)
    assert not plugin_loader.dirs
    path_subdir = os.path.join(path, 'rundir')
    add_all_plugin_dirs(path)
   

# Generated at 2022-06-11 15:11:13.847202
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type='sh')

    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'

    shell = get_shell_plugin(executable='/bin/bash')

    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/bash'

    shell = get_shell_plugin(executable='C:\\Windows\\System32\\cmd.exe')

    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.executable == 'C:\\Windows\\System32\\cmd.exe'



# Generated at 2022-06-11 15:11:23.479220
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
  PLUGIN_LOADER = None
  COLLECTION_LIST = None

  PLUGIN_LOADER = PluginLoader(
    'ansible.plugins.test_plugin',
    'TestPlugin',
    'cache',
    C.DEFAULT_CACHE_PLUGIN_PATH,
    required_base_class='BaseCacheModule',
  ) 

  # test valid plugin path
  PLUGIN_LOADER.find_plugin('memory', collection_list=COLLECTION_LIST)
  # test existing ansible.builtin plugin
  PLUGIN_LOADER.find_plugin('copy')
  # test non-existing plugin
  PLUGIN_LOADER.find_plugin('non-existing-plugin', collection_list=COLLECTION_LIST)