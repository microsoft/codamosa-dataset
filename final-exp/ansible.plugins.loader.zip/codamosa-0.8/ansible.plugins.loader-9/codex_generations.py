

# Generated at 2022-06-11 15:03:39.993684
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.plugins.discovery.base import PluginLoader
    from ansible.plugins.loader import plugin_loader
    from ansible.utils.collection_loader import _get_collection_name
    from ansible.utils.collection_loader import _get_collection_name_from_fqcr
    from ansible.utils.collection_loader import collections_paths
    from ansible.config.manager import ConfigManager
    from ansible.utils.collection_loader import split_colon_var

    # Without collection
    plugin_loader._set_collection_paths(collections_paths())
    config_manager = ConfigManager()._instance
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.plugin_

# Generated at 2022-06-11 15:03:47.425055
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.plugins.loader import (shared_loader, filter_loader,
        test_loader, cache_loader, callback_loader)

    # Testing get_plugin_loader().
    assert isinstance(shared_loader, PluginLoader)
    assert shared_loader.package == 'ansible.plugins.shared_loader'
    assert shared_loader.class_name == 'ModuleLoader'

    assert isinstance(filter_loader, PluginLoader)
    assert filter_loader.package == 'ansible.plugins.filter'
    assert filter_loader.class_name == 'FilterModule'

    assert isinstance(test_loader, PluginLoader)
    assert test_loader.package == 'ansible.plugins.test'
    assert test_loader.class_name == 'TestModule'

    assert isinstance(cache_loader, PluginLoader)

# Generated at 2022-06-11 15:03:55.002743
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    my_class = Jinja2Loader('ansible.plugins.filter', 'FilterModule')
    assert isinstance(my_class, Jinja2Loader)
    with pytest.raises(AnsibleError) as excinfo:
        my_class.get('nonexistent')
    assert 'No plugin loaded for nonexistent' in to_text(excinfo.value)
    #TODO: put in a dummy filter plugin and test the results of get()



# Generated at 2022-06-11 15:04:04.941545
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    from ansible.playbook import Playbook
    from ansible.plugins.filter import filters
    from ansible.module_utils import six
    from ansible.module_utils.six.moves import configparser
    from ansible.plugins.loader import connection_loader, filter_loader, module_loader, lookup_loader, callback_loader
    from ansible.plugins.loader import module_utils_loader, inventory_loader, test_loader
    mocker_handle = MockTest(test_PluginLoader)
    class_name = 'Playbook'
    base_class = 'PlaybookBase'
    package = 'ansible.playbook'
    subdir = 'playbook'
    mocker_handle.start()
    mocker_handle.mocker.patch('ansible.playbook.Playbook')

# Generated at 2022-06-11 15:04:07.266140
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    l = PluginLoader('', '', '', '')
    assert isinstance(l.all(), types.GeneratorType)


# Generated at 2022-06-11 15:04:11.494985
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    for path in ['/tmp/asd/asd', '/tmp/fds']:
        assert add_dirs_to_loader(which_loader='action', paths=path)
        assert add_dirs_to_loader(which_loader='test', paths=path)


# Generated at 2022-06-11 15:04:12.219958
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    assert 0 == 1

# Generated at 2022-06-11 15:04:21.542653
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test with invalid type
    obj = PluginLoader("invalid.foo", 'base', 'class_name')
    with pytest.raises(AnsibleError) as excinfo:
        obj.all()
    assert to_text(excinfo.value) == 'invalid.foo is not a valid plugin type'

    # Test with valid type
    obj = PluginLoader("parsers", 'base', 'class_name')
    for i in obj.all():
        assert isinstance(i, PluginLoader)
        assert isinstance(i.all(), list)
        assert isinstance(i.packages, list)
        break


# Generated at 2022-06-11 15:04:27.770825
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    PL = PluginLoader('test_collection', 'test_plugins')
    PL.add_directory('test_root')
    PL.add_directory('test_root_2')
    assert 'test_plugin' in PL
    assert 'plugin_not_found' not in PL
    assert 'test_plugin_1' not in PL

# Generated at 2022-06-11 15:04:32.824267
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    import mock
    import sys

    args_list = []
    kwargs_dict_list = []
    def record_deprecation(name, deprecation, collection_name):
        args_list.append(name)
        args_list.append(deprecation)
        args_list.append(collection_name)

    plugin_load_context = PluginLoadContext()
    plugin_load_context.record_deprecation = record_deprecation
    plugin_load_context.record_deprecation("failure_class.failure", {"warning_text": "foo", "removal_date": "2017-02-01"}, "collection")

    assert args_list[0] == 'failure_class.failure'

# Generated at 2022-06-11 15:06:13.108888
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    result = get_shell_plugin()
    assert result is not None and result == 'sh'
    result = get_shell_plugin('sh')
    assert result is not None and result == 'sh'
    #result = get_shell_plugin(executable='/bin/bash')
    #assert result is not None and result == 'bash'
    result = get_shell_plugin(executable='/usr/bin/sh')
    assert result is not None and result == 'sh'
    result = get_shell_plugin(executable='/bin/pwsh')
    assert result is None and result != 'powershell'

module_cache = defaultdict(lambda: defaultdict(dict))
plugin_path_cache = defaultdict(dict)



# Generated at 2022-06-11 15:06:24.048026
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    '''
    Unit test for method get of class Jinja2Loader

    This test takes a subset of the unit tests for PluginLoader.get and adjusts
    for the fact that the Jinja2Loader is missing some of the functionality.
    '''

    def get_invalid_loader(name):
        # A loader that won't return any results
        class InvalidLoader(Jinja2Loader):
            def _get_paths(self):
                return []
        return InvalidLoader(name, subdir=C.DEFAULT_FILTER_PLUGIN_PATH)

    loader = get_invalid_loader('filter')
    # We can't use the get() method because the Jinja2Loader doesn't support it
    assert loader.find_plugin('not_a_real_name', collection_list=None) is None

# Generated at 2022-06-11 15:06:27.961004
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    '''
    :param which_loader:
    :param paths:
    :return:
    '''
    assert isinstance(sys.modules[__name__], PluginLoader)
    assert isinstance(sys.modules[__name__], PluginLoader)


# Generated at 2022-06-11 15:06:38.839283
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # Setup args and kwargs
    args = (1, 2)
    kwargs = {'kwarg1': 3, 'kwarg2': 4}
    # Instantiate an instance of Jinja2Loader
    jinja2_loader = Jinja2Loader('', '', '', '')

    # Try and except to handle AttributeError exception from instantiating a Mock object
    try:
        mock_name = Mock()
        mock_name.__contains__.side_effect = Exception
        mock_collection_list = Mock()
        result = jinja2_loader.get(mock_name, *args, **kwargs)
        # If a exception wasn't raised we should fail
        assert False, 'Exception not raised when a mock object did not have a attribute'
    except AttributeError:
        pass

    # Setup the mock

# Generated at 2022-06-11 15:06:44.809680
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    import ansible.tests.unit.utils.plugin_common
    pluginLoader = PluginLoader('/etc/ansible/ansible.cfg', 'ansible.plugins.cache', 'CacheModule', 'base')
    for plugin in pluginLoader.all():
        assert plugin.__class__.__name__ == plugin.__name__


# Generated at 2022-06-11 15:06:49.095565
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    get_shell_plugin(shell_type='sh')
    get_shell_plugin(shell_type='test')
    get_shell_plugin(shell_type=None, executable='/bin/sh')
    try:
        get_shell_plugin()
    except AnsibleError:
        pass
    else:
        raise AssertionError('get_shell_plugin() did not raise an AnsibleError')



# Generated at 2022-06-11 15:06:54.135224
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # create a fake namespace
    namespace = {}
    # assign a fake class to the var 'Jinja2Loader' in the namespace
    namespace['Jinja2Loader'] = class_factory(Jinja2Loader)
    # create a fake function to be used as a method of 'Jinja2Loader' in the namespace

    def fake_find_plugin(self, name, collection_list=None):
        return 'find_plugin: name: "{0}", collection_list: "{1}"'.format(name, collection_list)

    # assign the fake function to the method name find_plugin of the class Jinja2Loader in the namespace
    namespace['Jinja2Loader'].find_plugin = fake_find_plugin
    # execute the method find_plugin of class Jinja2Loader with the namespace.
    # this is equal to Jinja2

# Generated at 2022-06-11 15:07:02.346543
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    j = Jinja2Loader('', '', '', 'filter_loader')
    assert j.find_plugin("to_json") == ['ansible.legacy.plugins.filter.to_json']
    assert j.find_plugin("to_yaml") == ['ansible.legacy.plugins.filter.to_yaml']
    assert j.find_plugin("ipaddr.map") == ['ansible.legacy.plugins.filter.ipaddrmap']


# Generated at 2022-06-11 15:07:04.432078
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    p = PluginLoader('module_utils', '_utils', C.MODULE_UTILS_PATH)
    assert len(list(p.all())) == 0

# Generated at 2022-06-11 15:07:07.178950
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    # TODO: need shell plugins that actually return something.
    assert get_shell_plugin()



# Generated at 2022-06-11 15:07:53.243166
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():

    assert test_add_dirs_to_loader.__name__ == 'test_add_dirs_to_loader'


# Generated at 2022-06-11 15:07:55.076544
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    raise AnsibleError('No code should call "get" for Jinja2Loaders (Not implemented)')



# Generated at 2022-06-11 15:07:57.996501
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    loader = PluginLoader('callback', 'ansible.plugins.callback', C.DEFAULT_CALLBACK_WHITELIST, 'callback')
    assert loader.has_plugin('minimal')


# Generated at 2022-06-11 15:08:07.532661
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Setup
    loader = PluginLoader('foo_type', 'ansible.plugins.foo_type', C.DEFAULT_INVENTORY_ENABLED_FILE)
    loader._get_plugin_paths = lambda: ['/opt/ansible/plugins/foo_type']

    # Test when a plugin is found, but with unexpected suffix
    with pytest.raises(AnsibleError):
        loader.find_plugin("bar_plugin.txt")

    # Test when a plugin is not found
    with pytest.raises(AnsibleError):
        loader.find_plugin("nope")

    # Test when a plugin is found
    assert 'bar' == loader.find_plugin("bar")



# Generated at 2022-06-11 15:08:14.454641
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    add_dirs_to_loader("action", ["/path"])
    import ansible.plugins.action
    assert ansible.plugins.action.ActionModule._get_paths() == ["/path"]
    add_dirs_to_loader("action", ["/path2"])
    assert ansible.plugins.action.ActionModule._get_paths() == ["/path", "/path2"]

# TODO: add_plugin_dir should not be needed anymore, remove it once everything is using loaders

# Generated at 2022-06-11 15:08:24.463520
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    class myPlugin:
        class myPlug:
            DEPRECATION = {
                'warning_text': 'warn deprecation info',
                'removal_date': '2022-12-31',
                'removal_version': '999999',
            }
    # Default case
    plugin_load_context = PluginLoadContext()
    actual = plugin_load_context.record_deprecation('name', None, 'collection_name')
    assert actual == plugin_load_context
    assert plugin_load_context.deprecated == False

    # Same as actual case
    plugin_load_context_1 = PluginLoadContext()
    actual_1 = plugin_load_context_1.record_deprecation(
        'name', myPlugin.myPlug.DEPRECATION, 'collection_name')
    assert actual_1 == plugin_

# Generated at 2022-06-11 15:08:34.099255
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    plugin_loader = PluginLoader('connection', '', 'ansible.plugins.connection')

    class FakeContext():
        def nope(self, msg):
            print(msg)
            return self
        def searched_path(self, path):
            print('searched path: {0}'.format(path))
            return self
        def searched_collection(self, collection):
            print('searched collection: {0}'.format(collection))
            return self
        def set_resolved(self, fqcn, resolved_path):
            print('set_resolved: {0} -> {1}'.format(fqcn, resolved_path))

if __name__ == "__main__":
    test_PluginLoader_get_with_context()

# Generated at 2022-06-11 15:08:45.210102
# Unit test for function get_shell_plugin
def test_get_shell_plugin():

    #test for case when shell_type is provided
    sh = get_shell_plugin('sh')
    assert(sh.__class__.__name__ == 'ShellModule')

    #test for case when shell_type is not provided
    #and executable is provided
    sh = get_shell_plugin(executable='sh')
    assert(sh.__class__.__name__ == 'ShellModule')

    #test for case when shell_type is not provided
    #and executable is not provided
    try:
        get_shell_plugin()
    except AnsibleError:
        assert True

    #test for case when shell_type is not provided
    #and executable is provided
    bash = get_shell_plugin(executable='bash')
    assert(bash.__class__.__name__ == 'ShellModule')



# Generated at 2022-06-11 15:08:51.264944
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # prepare
    var = {'var': ['file']}
    cp = 'ansible.legacy'

    # run init
    j2l = Jinja2Loader(cp, '/usr/lib/python2.7/site-packages/ansible/plugins/filter/core.py')

    # check passing
    assert j2l.get('first', var) == 'file', 'test 1'

    # check failing
    assert j2l.get('second', var) is None, 'test 2'



# Generated at 2022-06-11 15:09:02.738717
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    context_class = AnsiblePluginContext
    p_dict = {
        'plugin_name': None,
        'plugin_resolved_name': None,
        'plugin_resolved_path': None,
        'redirect_list': [],
        'resolved': False,
        'resolved_with_redirect': False,
        'failed': False,
        'nope_reason': None,
        'resolved_with_redirect': False,
    }

    def make_context(**kwargs):
        obj = context_class(**p_dict)
        obj.__dict__.update(kwargs)
        return obj

    def nope_context(message):
        return make_context(nope_reason=message)


# Generated at 2022-06-11 15:10:07.855738
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    import tempfile
    import shutil
    import ansible.plugins, ansible.modules

    plugin_dir = tempfile.mkdtemp()
    plugin_paths = [plugin_dir, os.path.join(plugin_dir, 'modules')]
    # Create dirs to test modules, connection, lookup and module_utils
    for plugin_path in plugin_paths:
        os.mkdir(plugin_path)
    # Create plugins in module, connection and lookup directories
    for plugin_path in plugin_paths:
        plugin_file_path = os.path.join(plugin_path, 'test_plugin.py')
        with open(plugin_file_path, 'w+') as f:
            f.write('\n')

    # Setup ansible's plugin_path to include the temporary directory
    C.DEFAULT_MOD

# Generated at 2022-06-11 15:10:12.298014
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    PLUGIN_TYPES = C.DEFAULT_INTERNAL_PLUGINS_PATH


    # Build a list of plugin paths to set during init of PluginLoader for testing
    plugin_paths = []
    for plugin_type in PLUGIN_TYPES:
        for path in PLUGIN_TYPES[plugin_type]:
            if path not in plugin_paths:
                plugin_paths.append(path)

    # Initialize PluginLoader with plugin_paths for testing
    plugin_loader = PluginLoader(class_name='module_utils', package='ansible.module_utils', config=None,
                                 subdir=None, paths=plugin_paths)

    # Test with valid fqname

# Generated at 2022-06-11 15:10:21.933133
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert get_shell_plugin(shell_type='sh')
    assert get_shell_plugin(shell_type='sh',executable='/usr/bin/bash')
    assert get_shell_plugin(shell_type='csh',executable='/usr/bin/csh')
    assert get_shell_plugin(shell_type='fish',executable='/usr/bin/fish')
    assert get_shell_plugin(shell_type='ksh',executable='/usr/bin/ksh')
    assert get_shell_plugin(shell_type='ps',executable='/usr/bin/powershell')
    assert get_shell_plugin(shell_type='vbs',executable='/usr/bin/cscript')
    assert get_shell_plugin(shell_type='zsh',executable='/usr/bin/zsh')
    #

# Generated at 2022-06-11 15:10:28.324152
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    p = PluginLoader(plugin_type='connection')
    assert hasattr(p, 'find_plugin_with_context')
    if isinstance(p.find_plugin_with_context, types.MethodType):
        # if we don't set this, unbound method is returned
        p = p.find_plugin_with_context
    assert callable(p)
# PluginLoader.find_plugin_with_context(...)

# Generated at 2022-06-11 15:10:33.202213
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    from ansible.utils.path import unfrackpath

    p = PluginLoader(
        'ansible.plugins.lookup',
        'LookupModule',
        'lookup_plugins',
        required_base_class='LookupBase'
    )
    f = unfrackpath("$testdir/units/plugins/filter_plugins/test.py")
    assert p.has_plugin("test") == True



# Generated at 2022-06-11 15:10:40.511012
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    plugin_loader = PluginLoader('my_package',
                                 '',
                                 'c.f.MyBaseClass',
                                 'ansible.plugins.my_package',
                                 'my_package',
                                 'my_package')
    assert plugin_loader.find_plugin('my_plugin') == None
    assert plugin_loader.find_plugin('my_plugin') == None
    assert plugin_loader.find_plugin('my_plugin') == None

# Generated at 2022-06-11 15:10:43.182130
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    """
    PluginLoader.__contains___
    """
    PL = PluginLoader('ansible.plugins.module_utils', 'ModuleUtils')
    assert 'ansible.module_utils.basic' in PL

# Generated at 2022-06-11 15:10:47.173579
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    p = PluginLoader.all_plugin_paths
    try:
        PluginLoader.all_plugin_paths = []
        add_all_plugin_dirs('/tmp/invalid')
        assert PluginLoader.all_plugin_paths == [], "all_plugin_paths was modified unexpectedly"
    finally:
        PluginLoader.all_plugin_paths = p



# Generated at 2022-06-11 15:10:49.404208
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Parameters
    directory = '/path/to/plugin'
    with pytest.raises(AssertionError):
        PluginLoader.add_directory(directory)


# Generated at 2022-06-11 15:10:58.691224
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    plugin_load_context = PluginLoaderContext()