

# Generated at 2022-06-11 15:03:37.324795
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    loader = PluginLoader('test', 'foo', 'bar', 'baz')
    assert type(loader.all()) == types.GeneratorType


# Generated at 2022-06-11 15:03:45.441762
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    plugin_loader = PluginLoader(package='ansible.plugins.test_get_with_context',
                                 directories=[os.path.join(os.path.dirname(__file__), 'test_plugin_loader')],
                                 class_name="PluginTest")
    assert plugin_loader.get_with_context('PluginTest').object.__class__ == ansible.plugins.test_get_with_context.PluginTest
    assert plugin_loader.get_with_context('PluginTest').resolved.filename == os.path.realpath('test_plugin_loader/PluginTest.py')
    assert not plugin_loader.get_with_context('NotAPlugin').resolved

# Generated at 2022-06-11 15:03:49.759011
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
  loader = getattr(sys.modules[__name__], '%s_loader' % 'shell')
  for path in C.DEFAULT_PLUGIN_PATH:
    loader.add_directory(path, with_subdir=True)
  print(loader.all())


# Generated at 2022-06-11 15:04:01.211346
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    from tempfile import mkdtemp
    import shutil

    def get_plugin_paths(plugin_type):
        directory = os.path.join(mkdtemp(), to_bytes(plugin_type))
        os.makedirs(directory)
        return directory

    types = ['action', 'become', 'cache', 'callback', 'connection', 'filter', 'inventory', 'lookup',
             'module_build', 'modules', 'shell', 'strategy', 'test', 'vars']

# Generated at 2022-06-11 15:04:10.192049
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    test_load_context = PluginLoadContext()
    test_deprecation = {'warning_text': 'warning_text',
                        'removal_date': 'removal_date',
                        'removal_version': 'removal_version'}
    test_load_context.record_deprecation('name',
                                         test_deprecation,
                                         'collection_name')
    assert test_load_context.deprecated is True
    assert test_load_context.removal_date == 'removal_date'
    assert test_load_context.removal_version == 'removal_version'
    assert test_load_context.deprecation_warnings == ['name has been deprecated. warning_text']



# Generated at 2022-06-11 15:04:15.467635
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a wrong path
    v = PluginLoader('test', '', '').find_plugin('test')
    assert v is None
    # Test with a correct path
    v = PluginLoader('test', '', 'test').find_plugin('test')
    assert isinstance(v, PluginLoader)




# Generated at 2022-06-11 15:04:23.993851
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    '''
    Test the return value of PluginLoader.get_with_context method
    '''
    def test_get_with_context(module_name, expected_context, expected_object):
        '''
        Test the return value of PluginLoader.get_with_context method
        with specified module name and expected return value
        :arg: module name
        :arg: expected context
        :arg: expected object
        '''
        actual_result = PluginLoader.get_with_context(module_name, None, None)
        assert actual_result.context == expected_context
        assert actual_result.object == expected_object

    test_get_with_context('testmodule', None, None)


# Generated at 2022-06-11 15:04:24.778066
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    pass


# Generated at 2022-06-11 15:04:33.988660
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    plugin_loader = PluginLoader('ansible.plugins.test', 'TestModule')
    plugin_loader._searched_paths = []
    plugin_loader._get_paths = lambda: ['/home/user/ansible/ansible/plugins/test']
    plugin_loader._module_cache = {}
    plugin_loader._display_plugin_load = lambda class_name, name, searched_paths, path, found_in_cache=None, class_only=None: None
    plugin_loader._update_object = lambda obj, name, path, redirected_names: None
    builtins_module = sys.modules['__builtin__']
    setattr(sys.modules['__builtin__'], '__import__', lambda name: '__builtin__.' + name)

# Generated at 2022-06-11 15:04:37.081587
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # TODO: need to write this test
    raise RuntimeError('no test written for {0}'.format('PluginLoader.find_plugin'))


# Generated at 2022-06-11 15:04:56.633391
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert add_dirs_to_loader('action', 'playbooks/actions')



# Generated at 2022-06-11 15:05:04.428691
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Initialize
    find_plugin_loader = PluginLoader()
    name = "fallback"
    suffix = ".py"
    path_list = [
        "/home/nobody/ansible/lib/ansible/plugins/filter/fallback.py"
    ]
    # Execute
    result = find_plugin_loader.find_plugin(name=name)
    # Verify
    assert result.plugin_resolved_name == name
    assert result.plugin_resolved_path == path_list[0]


# Generated at 2022-06-11 15:05:15.022483
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # make sure we don't add duplicate paths
    add_all_plugin_dirs("/foo/bar")
    add_all_plugin_dirs("/foo/bar")

    assert '/foo/bar' not in ModuleLoader.get_paths()
    assert '/foo/bar' not in ActionModuleLoader.get_paths()
    assert '/foo/bar' not in CacheModuleLoader.get_paths()
    assert '/foo/bar' not in ConnectorModuleLoader.get_paths()
    assert '/foo/bar' not in CallbackModuleLoader.get_paths()
    assert '/foo/bar' not in LookupModuleLoader.get_paths()
    assert '/foo/bar' not in TestModuleLoader.get_paths()
    assert '/foo/bar' not in VarsModuleLoader.get_paths()
   

# Generated at 2022-06-11 15:05:15.923889
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
  pass # TODO: implement your test here


# Generated at 2022-06-11 15:05:25.132074
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    plugin_type = AnsiblePlugin(
        class_name='TestClass',
        base_class=None,
        package='ansible.plugins.test',
        subdir='test_plugins',
        collection_list=[],
    )
    plugin_loader = PluginLoader(plugin_type, 'non-existent')
    assert plugin_loader._get_paths() == []
    plugin_loader.add_directory(os.path.join(os.path.dirname(__file__), 'test_plugins'))
    assert os.path.join(os.path.dirname(__file__), 'test_plugins') in plugin_loader._get_paths()

# Generated at 2022-06-11 15:05:36.314652
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    fq_name = 'ansible.executor.task_executor.ActionModule'
    suffix = '.py'
    plugin_load_context = object()
    plugin_load_context_nope = object()

    manager = PluginLoader(
        'ansible.executor.task_executor',
        'ActionModule',
        C.DEFAULT_INVENTORY_ENABLED_FILE,
        'file',
        '',
    )

    # the method _find_fq_plugin is mocked, the mocked function doesn't return a plugin_load_context
    # which means the method find_plugin doesn't find the plugin with the given name

# Generated at 2022-06-11 15:05:40.033035
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    path = 'test_path'
    result = PluginLoader._add_directory(path)
    assert result == path + '/'


# Generated at 2022-06-11 15:05:48.121544
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # get a list of the plugin loaders
    ploader_names = [name for (name, obj) in globals().items() if isinstance(obj, PluginLoader) and obj.subdir]
    expected_names = [
        # The relevant loaders have subdirs set to the location of their plugins.
        'ModuleLoader',
        'ActionModuleLoader',
        'FilterModuleLoader',
        'LookupModuleLoader',
        'ConnectionLoader',
        'ShellLoader',
        'StrategyLoader',
        'CallbackModuleLoader',
        'TestLoader',
        'TerminalLoader',
        'VarsModuleLoader',
        'InventoryModuleLoader',
    ]
    # Make sure that we found loaders for all the plugin types.  If you add a new
    # plugin type, you need to add a corresponding PluginLoader and set its sub

# Generated at 2022-06-11 15:05:57.449938
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    def get_plugin(shell_type, expected_module_path):
        plugin = get_shell_plugin(shell_type)
        assert plugin.__module__ == expected_module_path

    # Test with shell_type
    get_plugin('sh', 'ansible.plugins.shell.sh')
    get_plugin('pwsh', 'ansible.plugins.shell.powershell')

    # Test with executable
    get_plugin('sh', 'ansible.plugins.shell.sh', '/bin/bash')
    get_plugin('pwsh', 'ansible.plugins.shell.powershell', '/opt/microsoft/powershell/6.0.0-alpha.9/pwsh')



# Generated at 2022-06-11 15:06:07.422035
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    '''
    Unit test for method get_with_context of class PluginLoader
    '''

    def test_get_with_context_1(mocker):
        # Input parameters
        name = 'plugin_name'
        class_only = False
        base_class = 'base_class'
        package = 'package'
        class_name = 'class_name'
        extra_dirs = ('extra_dirs', )
        subdir = 'subdir'
        aliases = {'alias_name': 'alias'}

        # Define testing environment
        # (1) mocker.patch.object(AnsibleError, '__init__')
        mocker.patch.object(PluginLoader, '__init__', return_value=None)
        # (2) mocker.patch.object(AnsibleError, '__init

# Generated at 2022-06-11 15:06:47.419293
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    for name, obj in get_all_plugin_loaders():
        obj.clear_directory_cache()
    assert not get_all_plugin_dirs()

    with warnings.catch_warnings(record=True) as warnings_catcher:
        # add_all_plugin_dirs() should warn when a path does not exists
        add_all_plugin_dirs('/invalid')
        assert len(warnings_catcher) == 1
        warning = warnings_catcher[0]
        assert 'Ignoring invalid path provided to plugin path' in to_text(warning.message)

    with tempfile.TemporaryDirectory() as path:
        path = os.path.join(path, 'plugins')
        os.makedirs(path)
        assert not get_all_plugin_dirs()
        add_all_plugin_dir

# Generated at 2022-06-11 15:06:57.904553
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    try:
        basedir = os.path.dirname(__file__)
        display.display('basedir = %s' % basedir)
        test_plugin_path = os.path.join(basedir, 'test_plugin_path')
        assert os.path.isdir(test_plugin_path)
        add_all_plugin_dirs(test_plugin_path)
        for name, obj in get_all_plugin_loaders():
            assert test_plugin_path in obj._directories
    finally:
        for name, obj in get_all_plugin_loaders():
            if test_plugin_path in obj._directories:
                obj.remove_directory(test_plugin_path)



# Generated at 2022-06-11 15:07:07.739717
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():

    # setup and assert pre-conditions
    collection = 'some.awesome.collection'
    name = 'some_awesome_plugin'
    plugin_load_context = PluginLoadContext()
    plugin_load_context.collection_list = [collection]

    # build mocks
    from ansible.utils.collection_loader import get_collection_name_from_fqcr
    def _get_collection_name_from_fqcr(fqcr):
        if fqcr == collection:
            return collection
        raise ValueError('mock to raise exception when not finding collection as expected')

# Generated at 2022-06-11 15:07:12.791686
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    def _test_plugin_load_context_nope_reason(test_case, load_context, reference_reason):
        test_case.assertTrue(load_context.is_nope())
        test_case.assertTrue(load_context.failed())
        test_case.assertFalse(load_context.is_resolved())
        test_case.assertFalse(load_context.is_redirect())
        test_case.assertIsInstance(load_context.reason, MutableSequence)
        test_case.assertEqual(load_context.reason, reference_reason)
        test_case.assertIsNone(load_context.plugin_resolved_name)
        test_case.assertIsNone(load_context.plugin_resolved_path)

# Generated at 2022-06-11 15:07:23.752365
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    import os
    from ansible.utils.collection_loader import AnsibleCollectionRef, get_collection_name
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.hashing import secure_hash_s


    collection_list = ['ansible_collections.my_namespace.my_collection', '/Users/brian/Documents/workspace/ansible/lib/ansible/plugins/filter/fancy.py']

    name = 'fancy'
    class_name = 'FilterModule'
    package = 'ansible.plugins.filter'


# Generated at 2022-06-11 15:07:34.409547
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # FIXME: Add some unit tests

    # unit tests by setting up the global cache, then setting up a plugin loader, then calling find_plugin_with_context
    # then mocking the context and doing comparisons

    class PluginLoadContext(object):
        ''' mock plugin load context class '''

        def __init__(self):
            self._collection_name = None
            self._namespace_name = None
            self._plugin_name = None
            self._resolved = False
            self._ok = False
            self._reason = None
            self._display_path = None
            self._plugin_resolved_path = None
            self._parent_collection_name = None
            self._parent_namespace_name = None
            self._parent_plugin_name = None
            self._parent_display_path = None
            self._redirect_

# Generated at 2022-06-11 15:07:42.121694
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.plugins.loader import filter_loader, module_loader, lookup_loader, callback_loader, fragment_loader, test_loader
    from ansible.plugins.filter import test_filter
    from ansible.plugins.connection import test_connection
    from ansible.plugins.callback import test_callback
    from ansible.modules.cloud.amazon import test_iam_facts
    from ansible.modules.system import test_ping
    from ansible.modules.system import test_ping2
    from ansible.modules.system import test_ping3
    from ansible.modules.system import test_ping4
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-11 15:07:50.193940
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # setup:
    # instantiate an object of the class under test
    print("In test_PluginLoader_get_with_context")
    plugin_loader = PluginLoader("action_plugin", package="ansible.plugins",
                                 config=dict(action_plugins=os.path.join("/my/path/to/fixtures", "action_plugins")),
                                 # TODO: USE CLASSES WHICH EXTEND PluginBase
                                 )

    # exception test:
    # ensure the proper exception is raised for an invalid action plugin
    print("test loading invalid plugin")
    with pytest.raises(AnsibleError) as excinfo:
        plugin_loader.get("shrug")

    print("test loading missing plugin")
    with pytest.raises((ImportError, AnsibleError)) as excinfo:
        plugin_loader.get

# Generated at 2022-06-11 15:07:57.123927
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    module_finder = Jinja2Loader()
    # Jinja2Loader find_plugin

    # test_find_plugin_returns_none_if_no_module_found_for_a_given_name

    # test_find_plugin_returns_path_to_module_if_module_is_found_for_a_given_name
    assert module_finder.find_plugin(name='ansible/plugins/filter/core.py') == 'ansible/plugins/filter/core.py'



# Generated at 2022-06-11 15:08:07.599173
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():  # R1710
    # __contains__() tests whether a plugin name exists in the current plugin_loader or not
    #
    # Note:  Because _get_paths() uses the configured set of collection paths, we must set C.COLLECTIONS_PATHS
    # to an empty list since we don't have any collections installed outside of the test system.
    #
    # :see: https://github.com/ansible/ansible/issues/66002
    C.COLLECTIONS_PATHS = []
    ploader = PluginLoader(
        'ansible.plugins.action',
        'ActionModule',
        C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS,
        'action_plugins'
    )

# Generated at 2022-06-11 15:08:53.183244
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    ansible_dir = os.path.dirname(os.path.dirname(__file__))
    classname = 'ActionModule'
    plugin_type = 'action'
    package = 'ansible.plugins.action'
    test_loader = PluginLoader(classname, os.path.join(ansible_dir, 'lib', 'ansible', plugin_type + '_plugins'), 'ansible.plugins.' + plugin_type + '.')
    try:
        # find an existing file
        plugin_name = 'file'
        found_plugin = test_loader.find_plugin(plugin_name)
    except AnsibleParserError as exc:
        # expecting no exception to be thrown for this test
        pytest.fail("unexpected AnsibleParserError exception: {0}".format(exc))
    assert found_plugin == os.path

# Generated at 2022-06-11 15:09:05.276178
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collection_list import AnsibleCollectionRefList
    import sys

    loader = PluginLoader('test_type', 'unittest', 'test_package')
    loader._searched_paths = []  # FIXME: found this during debugging

    test_collections = ['ns1.coll1', 'ns2.coll2']
    test_collections_loader = AnsibleCollectionLoader()
    test_collections_loader.update_collection_paths(test_collections)
    test_collections_refs = AnsibleCollectionRefList(loader.package)  # FIXME: to avoid testing the arg parsing, just initialize list with the package
    test_collections_refs.extend(test_collections)

    # Plugins with explicitly namespaced

# Generated at 2022-06-11 15:09:12.149892
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    '''Basic test to make sure add_all_plugin_dirs adds plugin paths to the loader'''
    class MyPluginLoader(PluginLoader):
        subdir = 'my_plugins'
        def __init__(self, *args, **kwargs):
            self.directories_added = False
            super(MyPluginLoader, self).__init__(*args, **kwargs)
        def add_directory(self, directory):
            self.directories_added = True

    my_plugin_loader = MyPluginLoader()
    test_dir = 'plu.g/i.n/p.a.t.h'
    add_all_plugin_dirs(test_dir)
    assert my_plugin_loader.directories_added



# Generated at 2022-06-11 15:09:21.547010
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # note - this is not an exhaustive test of the method, but covers the key logic.
    # This test is invoked when the tests/units/modules/test_PluginLoader.py file is executed.
    #
    # Mock objects are used for testing of the mechanism for resolving plugins
    #   - the loader for the plugin is mocked out, so the actual plugin file is not needed.
    #   - context.locations attribute is a list of tuples that are used as the set of paths
    #       to be searched.
    #   - context.nope() and context.yep() are methods used to track the progress of the logic execution.

    class MockLoader(object):
        ''' define loader methods needed for testing resolution of modules '''
        def __init__(self, name):
            self._name = name
            self._searched_paths = []

# Generated at 2022-06-11 15:09:24.923187
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    pluginloader = PluginLoader(package='ansible.plugins.testplugin', class_name='TestPlugin', base_class='TestClass')
    assert (True if "testplugin" in pluginloader else False)


# Generated at 2022-06-11 15:09:36.171958
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    obj = PluginLoader('ansible.errors', package='ansible')
    # call obj.all()
    assert(isinstance(obj.all(), types.GeneratorType))
    # call obj.all() with arbitrary arguments
    assert(isinstance(obj.all(path_only='path_only', class_only='class_only'), types.GeneratorType))
    # call obj.all() with arbitrary keyword arguments
    assert(isinstance(obj.all(basename='basename', _dedupe='_dedupe'), types.GeneratorType))
    # call obj.all() with arbitrary arguments and keyword arguments
    assert(isinstance(obj.all('path_only', class_only='class_only', basename='basename', _dedupe='_dedupe'), types.GeneratorType))

# Generated at 2022-06-11 15:09:46.703346
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    from ansible.plugins.loader import PluginLoader
    p = 'test_add_all_plugin_dirs'
    n = 'Plugin'
    s = 'Subdir'
    fake_class = type(n, (object,), {})
    fake_class.subdir = s
    globals()[n] = fake_class

# Generated at 2022-06-11 15:09:57.397404
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    my_tmp_dir = tempfile.mkdtemp()

    from ansible.plugins.loader import PluginLoader
    my_plugin_loader = PluginLoader(
        'ansible.plugins.action',
        'ActionModule',
        'action_plugins',
        C.DEFAULT_ACTION_PLUGIN_PATH,
    )

    assert isinstance(my_plugin_loader, PluginLoader)

    # Test if plugin loader throws an error if initialized without a package
    try:
        faulty_pl = PluginLoader(None, 'ActionModule', 'action_plugins', C.DEFAULT_ACTION_PLUGIN_PATH)
        assert False, 'Plugin loader must be initialized with a package name'
    except Exception:
        pass

    # Test if plugin loader throws an error if initialized without a class name

# Generated at 2022-06-11 15:09:59.542649
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    Jinja2Loader('ansible.plugins.test.test_plugin', 'TestJinja2').find_plugin('test_plugin')



# Generated at 2022-06-11 15:10:10.539184
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Create a temporary directory for the test, then move into it
    with tempfile.TemporaryDirectory() as tmpdir:
        os.chdir(tmpdir)
        tmpdir = os.getcwd()

        # Create a temporary directory structure
        tmpdir_module = os.path.join(tmpdir, "ansible")
        tmpdir_module_plugins = os.path.join(tmpdir_module, "plugins")
        tmpdir_module_plugins_lookup = os.path.join(tmpdir_module_plugins, "lookup")
        os.makedirs(tmpdir_module)
        os.makedirs(tmpdir_module_plugins)
        os.makedirs(tmpdir_module_plugins_lookup)

        # Create a temporary file
        tmpfile = NamedTemporaryFile()

# Generated at 2022-06-11 15:11:02.416542
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    for b_path in ['/path/to/playbooks', './path/to/playbooks', './plugins']:
        b_path = os.path.expanduser(to_bytes(b_path, errors='surrogate_or_strict'))
        yield _test_add_all_plugin_dirs, b_path


# Generated at 2022-06-11 15:11:07.374720
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    '''
    This test simply checks that this module properly recognises a valid and invalid directory.
    The specific behaviour of add_directory is tested in the relevant class PluginLoader.
    '''
    export_plugin_path = C.DEFAULT_MODULE_PATH
    assert add_all_plugin_dirs(export_plugin_path) == None
    assert add_all_plugin_dirs('/invalid/path') == None



# Generated at 2022-06-11 15:11:14.191772
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():

    loader = PluginLoader('whatever')
    # empty path
    result = loader.find_plugin_with_context('whatever')
    assert len(result.nope_msgs) == 1
    assert result.nope_msgs[0] == 'The first element of _get_paths() must be populated'
    assert result.nope_msgs[0] == 'The first element of _get_paths() must be populated'
    assert result.nope_msgs[0] == 'The first element of _get_paths() must be populated'

    # empty plugin
    result = loader.find_plugin_with_context('whatever', plugin_resolved_name='an empty plugin')
    assert len(result.nope_msgs) == 1

# Generated at 2022-06-11 15:11:24.784607
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # FIXME: update the tests to directly test the find_plugin_with_context method
    # FIXME: update the tests to directly test the get_with_context method
    global _PLUGIN_PATH_CACHE

    # NOTE: this test assumes that the context manager for 'with' is working to clean up the environment
    # The context manager for 'with' is only called when leaving a function by returning/finishing
    # if a function raises an exception, the context manager will not be called, and a tearDown
    # will not be run.  This can cause subsequent tests to fail.  So the following should be
    # avoided in this test:
    # 1.  Exceptions should not be raised, since they will not call the context manager to cleanup
    # 2.  There is no guaranteed order when the tests will be run, and some test cases depend on
   