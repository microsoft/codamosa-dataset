

# Generated at 2022-06-11 15:04:20.007735
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # set up test environment
    class Plugin:
        def __init__(self, name):
            self.name = name
    loader = PluginLoader(
        'test_package',
        # base_class   # None
        'test_class',
        'test_dir',
        # 'package'     # 'test_package'
        # class_name   # 'test_class'
        # package_path # None
        # 'plugin_dir'  # 'test_dir'
        'test_suffix',
        C.DEFAULT_INTERNAL_PLUGIN_PATH,
        C.DEFAULT_EXTERNAL_PLUGIN_PATH,
        'test_package_aliases'
    )

# Generated at 2022-06-11 15:04:20.896214
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin()


# Generated at 2022-06-11 15:04:32.701503
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Create a mock class to test find_plugin_with_context
    class TestLoader(PluginLoader):
        # Fixed values for testing
        package = 'ansible.plugins.module_utils'
        base_class = 'ModuleUtilsCore'


# Generated at 2022-06-11 15:04:41.619693
# Unit test for function get_shell_plugin
def test_get_shell_plugin():

    # Test with sh shell type
    sh_shell = get_shell_plugin(shell_type='sh')
    assert sh_shell.SHELL_FAMILY == 'sh'

    # Test with csh shell type
    csh_shell = get_shell_plugin(shell_type='csh')
    assert csh_shell.SHELL_FAMILY == 'csh'

    # Test with bash shell type
    bash_shell = get_shell_plugin(shell_type='bash')
    assert bash_shell.SHELL_FAMILY == 'bash'



# Generated at 2022-06-11 15:04:53.834306
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    import ansible.plugins
    add_all_plugin_dirs('/path/to/plugins')
    assert not ansible.plugins.action.__path__
    assert not ansible.plugins.cache.__path__
    assert not ansible.plugins.callback.__path__
    assert not ansible.plugins.connection.__path__
    assert not ansible.plugins.filter.__path__
    assert not ansible.plugins.inventory.__path__
    assert not ansible.plugins.lookup.__path__
    assert not ansible.plugins.netconf.__path__
    assert not ansible.plugins.shell.__path__
    assert not ansible.plugins.strategy.__path__
    assert not ansible.plugins.terminal.__path__
    assert not ansible.plugins.test.__path__

# Generated at 2022-06-11 15:04:59.076453
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    for name, obj in get_all_plugin_loaders():
        obj.directories = []
    assert len(get_all_plugin_loaders()) > 0
    # Insert some paths to dirs that don't exist
    add_all_plugin_dirs('/does/not/exist')
    # Make sure that didn't touch anything
    for name, obj in get_all_plugin_loaders():
        assert len(obj.directories) == 0



# Generated at 2022-06-11 15:05:08.491285
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    def create_plugin_loader(config, base_class, package, subdir=None):
        ''' helper method for creating a plugin loader for testing '''
        loader = PluginLoader(config, base_class, package=package, subdir=subdir)
        base_class_module = importlib.import_module(loader.package)
        base_class_module.__path__ = loader._load_paths
        return loader

    # Tests for each package and plugin type in order to ensure that the correct
    # plugins are loaded and returned.
    # In all of these tests, we need to create a temporary directory structure
    # that looks like the following (note that the subdir has been left out of
    # the diagrams as that is set when the plugin loader is created):
    # plugins/
    #   callback/
    #     foo.py
    #

# Generated at 2022-06-11 15:05:19.927266
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    import copy
    import types

    # This class and method are tested in conjunction with the 'test' package
    module_name = 'unit_test_module_name'
    class_name = 'UnitTestClassName'
    base_class = 'BaseClass'
    package = 'unit_test_package'
    subdir = 'unit_test_subdir'
    class_only = False
    path_only = False

    # Set up the module we will be using to test
    module = types.ModuleType(module_name)
    class_attributes = dict(NAME='test_plugin', VERSION=1)
    for attribute, value in class_attributes.items():
        setattr(module, attribute, value)

    # Set up the plugin class

# Generated at 2022-06-11 15:05:27.590003
# Unit test for method get of class Jinja2Loader

# Generated at 2022-06-11 15:05:38.163112
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():

    # Create an instance of PluginLoader for testing
    test_loader_instance = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins')

    # Test with an invalid name
    test_self = test_loader_instance
    test_name = 'invalid'
    test_args = []
    test_kwargs = {}
    validation_failed = False
    expected_result = None
    expected_plugin_load_context = PluginLoadContext(False, 'invalid has no eligible plugins', ('ansible.plugins.action.invalid',) if '.' not in test_name else ())

    result = test_self.get_with_context(test_name, *test_args, **test_kwargs)


# Generated at 2022-06-11 15:06:05.130421
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():

    # Testing that a warning is raised when calling get()
    mock_display = Mock()
    Jinja2Loader._display = mock_display
    loader = Jinja2Loader()
    loader.all()
    mock_display.warning.assert_called_once()



# Generated at 2022-06-11 15:06:12.649424
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    import unittest
    from ansible.module_utils.six.moves import builtins

    def mocked_ansible_collections_paths(self):
        return ['/usr/share/ansible/collections']

    class MockedModule(object):
        def __getattr__(self, name):
            if name == 'AnsibleModule':
                raise RuntimeError('Plugin module cannot be imported due to load error.')
            else:
                raise ImportError('Plugin module cannot be imported')

    class MockedPluginLoader(PluginLoader):
        def __init__(self, module_name, package, config, subdir):
            super(MockedPluginLoader, self).__init__(module_name, package, config, subdir)


# Generated at 2022-06-11 15:06:17.395209
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    args = dict(
        name='',
        path_only=False,
        class_only=False
    )
    pl = PluginLoader('', '', '', '', '', '')
    result = pl.__contains__(**args)
    assert result is False


# Generated at 2022-06-11 15:06:18.084303
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    pass


# Generated at 2022-06-11 15:06:26.817534
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    import os
    import tempfile
    # Create a temp file
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    temp_file.close()

    # Open temp file and write to it
    with open(temp_file.name, 'w') as f:
        f.write("#! /bin/bash")

    # Set permissions of the temp file to executable
    os.chmod(temp_file.name, 0o700)

    # Test with default shell
    shell = get_shell_plugin()
    assert shell.SHELL_FAMILY == "sh"

    # Test with executable
    shell = get_shell_plugin(executable=temp_file.name)
    assert hasattr(shell, 'executable')
    assert shell.executable

    # Test with invalid executable parameter

# Generated at 2022-06-11 15:06:37.524094
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    from ansible.plugins.loader import module_loader

    obj = module_loader.get_with_context('copy', class_only=True)
    assert obj is not None
    assert obj.module_utils == ['ansible.module_utils.basic']
    assert obj.redirected_names == []

    obj = module_loader.get_with_context('ping', class_only=True)
    assert obj is not None
    assert obj.module_utils == ['ansible.module_utils.basic']
    assert obj.redirected_names == ['ping']

    obj = module_loader.get_with_context('ansible.collections.foo.bar.baz', class_only=True)
    assert obj is not None
    assert obj.module_utils == ['ansible.module_utils.basic']
    assert obj.red

# Generated at 2022-06-11 15:06:39.050202
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    assert False, "Add test for function add_all_plugin_dirs"



# Generated at 2022-06-11 15:06:40.811444
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert callable(add_dirs_to_loader)



# Generated at 2022-06-11 15:06:44.809739
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Tests for the method all of class PluginLoader
    # TODO: Write a real unit test.  This is just a placeholder to prevent the build from
    # failing in tests.
    assert True

# Generated at 2022-06-11 15:06:51.808875
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    from ansible.utils.display import Display
    from ansible.plugins.loader import Jinja2Loader

    display = Display()

    jinja2_loader = Jinja2Loader('filter', display)
    jinja2_loader.add_directory(str(REGRESSION_DATA_ROOT / 'filter_plugins'))
    assert jinja2_loader.get('xor') is not None
    assert jinja2_loader.get('to_human') is not None

    jinja2_loader = Jinja2Loader('test', display)
    jinja2_loader.add_directory(str(REGRESSION_DATA_ROOT / 'filter_plugins'))
    assert jinja2_loader.get('xor') is not None

# Generated at 2022-06-11 15:08:04.682708
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    pass



# Generated at 2022-06-11 15:08:07.749060
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    add_dirs_to_loader(
        'shell',
        [
            '/home/a/ansible-community/ansible/plugins/shell',
            '/home/a/ansible-community/ansible/plugins/shell',
        ]
    )

# Generated at 2022-06-11 15:08:17.929383
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import PY3

    p = PluginLoader('test_plugins', 'TestPlugins', 'TestPlugin', 'ansible.plugins.test_plugins')
    all_plugins = p.all()
    plugins = [plugin for plugin in all_plugins]

    # Test the number of plugins
    assert len(plugins) == 2

    # Test plugin order of those plugins
    assert plugins[0].__class__.__name__ == 'TestPluginD'
    assert plugins[1].__class__.__name__ == 'TestPluginA'

    # Test some other api, but don't test all of them
    # as the base class 'PluginLoader' will be tested


# Generated at 2022-06-11 15:08:29.026623
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    """
    Test that add_dirs_to_loader correctly adds
    directories to the specified loader
    """

    from ansible.constants import DEFAULT_MODULE_PATH
    _config = AnsibleCollectionConfig()
    module_path = _config.get_config_value("DEFAULT_MODULE_PATH")
    if module_path:
        DEFAULT_MODULE_PATH = module_path
    paths = [
        'path1',
        'path2',
        'path3'
    ]
    add_dirs_to_loader('module', paths)
    assert len(module_loader._get_paths()) == 6

# Generated at 2022-06-11 15:08:32.485212
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():

    # I don't know if such a thing is possible, but if it is, it's a coding bug
    # I don't think we should throw an exception.
    # find_plugin(name)

    raise Exception('find_plugin is not implemented')


# Generated at 2022-06-11 15:08:35.824314
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert not shell_loader._directories.get()
    test_paths = ['test_modules', 'test_module_utils']
    add_dirs_to_loader('shell', test_paths)
    for path in test_paths:
        assert path in shell_loader._directories.get()



# Generated at 2022-06-11 15:08:46.589072
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    # test when only shell_type is provided.
    shell_plugin = get_shell_plugin(shell_type='sh')
    # when only shell_type is provided, it should be an instance of shell_loader.ShModule class.
    assert(isinstance(shell_plugin, shell_loader.ShModule))

    # test when both shell_type and executable are provided.
    shell_plugin = get_shell_plugin(shell_type='sh', executable='sh')
    assert(isinstance(shell_plugin, shell_loader.ShModule))

    # test when executable is provided, but shell_type is missing.
    try:
        shell_plugin = get_shell_plugin(executable='sh')
        assert(False)
    except AnsibleError:
        assert(True)

    # tests when both shell_type and executable are missing, but executable is

# Generated at 2022-06-11 15:08:48.266122
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    assert os.path.isdir(get_plugin_class('strategy')._base_path)


# Generated at 2022-06-11 15:08:55.748128
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    obj = PluginLoader(package='test_package', directories=['files', 'files2'], class_name='test_class')
    name = 'name.py'
    obj._searched_paths = os.path.join('files', 'name.py')
    obj._plugin_load_context = PluginLoadContext(plugin_resolved_name='name.py', plugin_resolved_path=os.path.join('files', 'name.py'), resolved=False)
    result = obj.get_with_context(name)
    assert result is None


# Generated at 2022-06-11 15:09:07.773216
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    name='hello'
    package='ansible.plugins.lookup'
    suffix='lookup'
    subdir='lookup_plugins'
    display_paths='lookup_plugins'
    config_def_paths='lookup_plugins'
    class_name='LookupModule'
    base_class='LookupBase'
    require_packages='ansible.plugins.lookup'
    cache=True
    class_only=False
    relative_to_caller=True
    path_only=False
    require_compat_version='2.4'
    aliases={}

# Generated at 2022-06-11 15:09:37.360264
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    '''
    test method get of Jinja2Loader
    '''
    loader = Jinja2Loader('ansible.plugins.action', 'ActionModule')

    name = 'random.notarealplugin'
    if loader.get(name) != None:
        raise AssertionError('%s should not be in the list of jinja2 plugins' % name)

    name = 'random'
    if loader.get(name) != None:
        raise AssertionError('%s should not be in the list of jinja2 plugins' % name)

    name = 'ansible.legacy.utils.random'
    if loader.get(name) != None:
        raise AssertionError('%s should not be in the list of jinja2 plugins' % name)

    name = 'utils.random'

# Generated at 2022-06-11 15:09:47.279614
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Create dummy PluginLoaders
    PLUGIN_LOADER_1_NAME = 'PLUGIN_LOADER_1'
    PLUGIN_LOADER_1 = PluginLoader(PLUGIN_LOADER_1_NAME, PLUGIN_LOADER_1_NAME, 'plugins', '.')
    globals()[PLUGIN_LOADER_1_NAME] = PLUGIN_LOADER_1
    PLUGIN_LOADER_2_NAME = 'PLUGIN_LOADER_2'
    PLUGIN_LOADER_2 = PluginLoader(PLUGIN_LOADER_2_NAME, PLUGIN_LOADER_2_NAME, None, '.')
    globals()[PLUGIN_LOADER_2_NAME] = PLUGIN_LOADER_2
    # Create a path to be added
   

# Generated at 2022-06-11 15:09:58.136346
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    plugin_loaders = defaultdict(list)
    for name, obj in get_all_plugin_loaders():
        plugin_loaders[obj.subdir].append(name)

    # Mock out globals()
    real_globals = globals()

# Generated at 2022-06-11 15:09:59.131515
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # TODO: test this
    pass

# Generated at 2022-06-11 15:10:10.121999
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type ='sh')
    assert type(shell) == ShellModule
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'

    shell = get_shell_plugin(executable ='/bin/csh')
    assert type(shell) == ShellModule
    assert shell.SHELL_FAMILY == 'csh'
    assert shell.executable == '/bin/csh'

    shell = get_shell_plugin(shell_type='csh')
    assert type(shell) == ShellModule
    assert shell.SHELL_FAMILY == 'csh'
    assert shell.executable == '/bin/sh'

    from ansible.utils.display import Display
    Display.verbosity = 4

# Generated at 2022-06-11 15:10:20.941614
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    from ansible.module_utils.six import PY2, PY3
    from six import unichr
    from ansible.plugins.loader import PluginLoader


# Generated at 2022-06-11 15:10:31.885257
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # add a temporary plugin directory to the 'ansible_paths' to test the function
    tmp_plugin_dir = './test_plugins'
    C.config.set_config_attr(tmp_plugin_dir, 'ansible_paths')
    # create the path and its subdirectories
    b_tmp_plugin_dir = os.path.expanduser(to_bytes(tmp_plugin_dir, errors='surrogate_or_strict'))
    if not os.path.isdir(b_tmp_plugin_dir):
        os.mkdir(b_tmp_plugin_dir)

# Generated at 2022-06-11 15:10:35.424210
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    loader = PluginLoader(
        package='ansible.plugins.test',
        class_name='TestPlugin'
    )
    for plugin in loader.all():
        plugin.func()


# Generated at 2022-06-11 15:10:45.376647
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    from ansible import errors
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = None  # type: DataLoader
    play_context = PlayContext()
    play_context.network_os = 'ios'
    templar = Templar(loader, variables=VariableManager())

# Generated at 2022-06-11 15:10:53.707166
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    '''
    Unit test for method find_plugin of class PluginLoader
    '''
    print('Testing find_plugin()...')

    plugin_loader = PluginLoader()

    try:
        plugin_loader.find_plugin(None)
        assert False
    except TypeError:
        pass

    try:
        plugin_loader.find_plugin('')
        assert False
    except TypeError:
        pass

    try:
        plugin_loader.find_plugin(True)
        assert False
    except TypeError:
        pass

    assert plugin_loader.find_plugin('echo') is not None
    assert plugin_loader.find_plugin('echo') == 'echo'

    assert plugin_loader.find_plugin('ansible.builtin.debug') is not None