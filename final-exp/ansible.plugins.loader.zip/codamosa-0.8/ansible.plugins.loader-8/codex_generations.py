

# Generated at 2022-06-11 15:03:26.125560
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    import tempfile
    try:
        path = tempfile.mkdtemp()
        os.mkdir(path + os.sep + 'subdir')
        add_all_plugin_dirs(path)
        assert to_text(path + os.sep + 'subdir') in get_plugin_class('subdir', 'plugin_name', 'plugin_type')._get_paths()
        add_all_plugin_dirs(path + os.sep + 'subdir')
        assert to_text(path + os.sep + 'subdir') in get_plugin_class('subdir', 'plugin_name', 'plugin_type')._get_paths()
    finally:
        shutil.rmtree(path)

# FIXME/TODO: need to either write tests for this or otherwise determine it's
#

# Generated at 2022-06-11 15:03:30.728652
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    from ansible.executor.module_common import RESTRICTED_RESOURCE_MAP

    loader = getattr(sys.modules[__name__], '%s_loader' % 'module')
    for path in RESTRICTED_RESOURCE_MAP.keys():
        loader.add_directory(path, with_subdir=True)


# Generated at 2022-06-11 15:03:38.754256
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    def _create_plugin_loader(path, module_name):
        class _FakeModule(object):
            pass

        class _FakePlugin(object):
            pass

        found_in_cache = False
        name = os.path.splitext(os.path.basename(path))[0]
        path = os.path.join(path, name + '.py')
        module = _FakeModule()
        module.NAME = name
        module.CLASS = _FakePlugin
        fake_module_cache = {path: module}

        def _load_module_source(self, name, path):
            raise AnsibleError('Loading of module should not be called in this test case.')


# Generated at 2022-06-11 15:03:47.750758
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    import doctest
    from unittest import mock
    from ansible.plugins.connection import ConnectionBase
    from ansible.plugins.test.test_connection import ConnectionModule, TestConnection
    from ansible.plugins.loader import PluginLoader

    mock_module = mock.MagicMock(spec=ConnectionModule, name='mock_connection_module')
    mock_connection_class = mock.MagicMock(spec=ConnectionBase, name='mock_connection_class')
    mock_obj = mock.MagicMock(spec=TestConnection, name='mock_obj')

    plugin_loader = PluginLoader('connection_loader', 'ansible.plugins.connection', 'ConnectionBase', 'ConnectionBase', 'ansible.plugins.connection')

# Generated at 2022-06-11 15:03:59.668721
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
        '''
        Unit test for method __contains__ of class PluginLoader
        '''
        # Create an instance of class PluginLoader
        # initialize variable 'package'
        package = 'Package'
        # initialize variable 'base_class'
        base_class = 'BaseClass'

        # initialize variable 'class_name'
        class_name = 'ClassName'

        # initialize variable 'subdir'
        subdir = 'Subdir'

        # initialize variable 'paths'
        paths = ['/etc']

        # initialize variable 'config'
        config = {}
        # initialize variable 'plugin_loader'
        plugin_loader = PluginLoader(package=package, base_class=base_class, class_name=class_name, subdir=subdir, paths=paths, config=config)

        # initialize variable 'name'
        name

# Generated at 2022-06-11 15:04:07.368599
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    paths = ['/etc/ansible/modules', '/usr/share/ansible/plugins']
    add_dirs_to_loader('filter', paths)
    plugin_paths = getattr(sys.modules[__name__], '%s_loader' % 'filter').package_paths
    assert plugin_paths == ['/etc/ansible/plugins/filter', '/usr/share/ansible/plugins/filter']
    mock_paths = ['/etc/ansible/mock_modules', '/usr/share/ansible/mock_plugins']
    add_dirs_to_loader('mock', mock_paths)
    mock_plugin_paths = getattr(sys.modules[__name__], '%s_loader' % 'mock').package_paths

# Generated at 2022-06-11 15:04:13.659484
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    """
    Test all() method of PluginLoader
    """
    loader = PluginLoader('callback_', 'ansible.plugins.callback', C.DEFAULT_CALLBACK_PLUGIN_PATH, 'callback')
    results = list(loader.all())
    # assert(len(results) > 0)
    assert(type(results) == list)
    # Write your own tests
    return



# Generated at 2022-06-11 15:04:23.814595
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    from ansible.plugins.action.copy import ActionModule as copy_action
    from ansible.plugins.loader import ActionModuleLoader
    from ansible.module_utils._text import to_text

    loader = ActionModuleLoader(config={})
    plugin_load_context = loader.find_plugin_with_context('copy', collection_list=None)
    assert plugin_load_context.resolved is True
    assert plugin_load_context.plugin_resolved_name == 'copy'
    assert plugin_load_context.plugin_resolved_path is not None
    assert plugin_load_context.redirect_list == []

    plugin_load_context = loader.find_plugin_with_context('ansible.builtin.copy', collection_list=None)
    assert plugin_load_context.resolved is True
    assert plugin_load_

# Generated at 2022-06-11 15:04:33.502998
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # test that we have the right loaders
    assert isinstance(connection_loader, PluginLoader)
    assert isinstance(module_loader, PluginLoader)
    assert isinstance(shell_loader, PluginLoader)
    # test that the connection_loader allows for subdirs by default
    assert connection_loader.subdir

    # test that we can add directories to the loaders
    temp_dir = tempfile.mkdtemp()
    test_files = [os.path.join(temp_dir, 'test_file_%s.py' % i) for i in range(0, 4)]
    for t in test_files:
        with open(t, 'w') as f:
            f.write('#')
    # test that the files have been created

# Generated at 2022-06-11 15:04:41.558476
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    path = '/home/s/s/s/s/s/s'
    b_path = os.path.expanduser(to_bytes(path, errors='surrogate_or_strict'))
    for name, obj in ((name, obj) for (name, obj) in globals().items() if isinstance(obj, PluginLoader)):
        if obj.subdir:
            plugin_path = os.path.join(b_path, to_bytes(obj.subdir))



# Generated at 2022-06-11 15:05:15.170134
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    path = 'test'
    if os.path.isdir(path):
        for name, obj in get_all_plugin_loaders():
            obj.add_directory(path)

# plugin loading mechanisms:
# - PLUGINS
#   - python
#     - {action,cache,callback,cliconf,connection,doc_fragments,filter,httpapi,inventory,lookup,netconf,shell,strategy,terminal,test,vars}
#   - modules
#   - module_utils
#   - action.plugins
#   - cache.plugins
#   - callback.plugins
#   - cliconf.plugins
#   - connection.plugins
#   - filter.plugins
#   - httpapi.plugins
#   - inventory.plugins
#   - lookup.plugins
#   - netconf.plugins
#

# Generated at 2022-06-11 15:05:25.921392
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    a = {'warning_text': 'Only deprecated', 'removal_date': '2019-05-31', 'removal_version': '2.9'}
    b = {'warning_text': 'Deprecated without any date or version', 'removal_date': None, 'removal_version': None}
    c = {'warning_text': 'Only deprecated with removal_date', 'removal_date': '2019-05-31', 'removal_version': None}
    d = {'warning_text': 'Only deprecated with removal_version', 'removal_date': None, 'removal_version': '2.9'}
    e = {'warning_text': 'Only deprecated with neither removal_date nor removal_version', 'deprecation': None}

# Generated at 2022-06-11 15:05:33.158022
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Add invalid paths
    assert 0 == len(PluginLoader.all_dirs)
    add_all_plugin_dirs("test_{path}")
    assert 0 == len(PluginLoader.all_dirs)

    # Add valid paths
    add_all_plugin_dirs("test_plugin_loader")
    assert 1 == len(PluginLoader.all_dirs)
    add_all_plugin_dirs("test_plugin_loader")
    assert 1 == len(PluginLoader.all_dirs)



# Generated at 2022-06-11 15:05:38.677201
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # get all cache plugins

    # plugin loader instance
    cache_loader = PluginLoader(
        'CacheModule',
        C.CACHE_PLUGIN_PATH,
        'CacheModule',
        'ansible.plugins.cache',
        'BaseCacheModule'
    )

    # get all cache plugins
    for plugin in cache_loader.all(class_only=True):
        print(plugin.__class__.__name__)

test_PluginLoader_all()


# Generated at 2022-06-11 15:05:47.905246
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    """Test if `deprecated` and `removal_date`/`removal_version` are recorded correctly in PluginLoadContext"""
    def _test(name, deprecation, collection_name, expected_deprecated, expected_removal_date, expected_removal_version):
        context = PluginLoadContext()
        context.record_deprecation(name, deprecation, collection_name)
        assert context.deprecated == expected_deprecated
        assert context.removal_date == expected_removal_date
        assert context.removal_version == expected_removal_version
        assert context.deprecation_warnings
    # pylint: disable=invalid-name
    _test('test', None, None, False, None, None)

# Generated at 2022-06-11 15:05:49.250854
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    all=PluginLoader


# Generated at 2022-06-11 15:06:00.329527
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    C.enable_debug()
    package = 'ansible.plugins.action'
    base_class = 'ActionBase'
    suffix = 'action'

    plugin_loader = PluginLoader(package, 'ActionModule', base_class, suffix)

    load_context = plugin_loader.find_plugin_with_context(name='ping', collection_list=[])
    display.display("load_context: %s" % load_context)
    #assert load_context.plugin_resolved_name == 'ansible.plugins.action.ping'
    assert load_context.plugin_resolved_path is None
    assert load_context.resolved is False
    assert load_context.collection_entry.collection is None
    assert load_context.plugin_resolved_name == 'ping'
    assert load_context.plugin_resolved_path is None

# Generated at 2022-06-11 15:06:07.645382
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    '''
    Unit test for function add_all_plugin_dirs
    '''
    # add plugin path for a non-existant path
    plugin_path = './non-existant-path'
    add_all_plugin_dirs(plugin_path)
    assert plugin_path not in PATH_CACHE

    # add plugin path for a valid path
    plugin_path = './test/unit/utils/test_loader'
    add_all_plugin_dirs(plugin_path)
    assert plugin_path in PATH_CACHE

# unit test for function add_directory

# Generated at 2022-06-11 15:06:17.441352
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    all_matches = None
    loaded_modules = set()
    class testPluginLoader(PluginLoader):
        def get(self):
            pass
        def _load_module_source(self, name, path):
            assert name == 'ansible.plugins.filter.jmespath.to_list'
            assert path == '/foo/bar/jmespath.py'
            return 'module_object'
        def _update_object(self, obj, name, path):
            assert obj == 'module_object'
            assert name == 'ansible.plugins.filter.jmespath.to_list'
            assert path == '/foo/bar/jmespath.py'
            return obj
        def _get_paths(self):
            global all_matches
            assert all_matches is None

# Generated at 2022-06-11 15:06:26.576338
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # Simple test to make sure we can return an instance of a Jinja2 FilterPlugin
    # This test is mostly to ensure that the 'base' code path is tested (base.py in each subpackage has 'wrapper' class)
    # For more comprehensive testing, see TestJinja2FilterPlugin

    # set up plugin loader and load plugin (filters)
    ldr = Jinja2Loader('FilterModule', 'ansible.plugins.filter', 'FilterModule')
    ldr.add_directory(os.path.join(os.path.dirname(__file__), '..', 'plugins', 'filter'))
    # ldr.filter_plugin has been deprecated in favour of ldr.find_plugin
    for p in ldr.all():
        if p.__name__ == 'AnsibleJinja2FilterModule':
            plugin = p



# Generated at 2022-06-11 15:06:53.874717
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    executable = "bash"
    shell = get_shell_plugin(executable=executable)
    assert shell.SHELL_NAME == "bash"
    assert shell.executable == executable


# Generated at 2022-06-11 15:07:05.666901
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    loader=PluginLoader("module_utils")
    name="i18n.py"
    suffix="py"
    collection_list=None
    plugin_load_context=loader.find_plugin_with_context(name,suffix,collection_list)
    assert plugin_load_context.conflict_collection_name == None, "conflict_collection_name must be None"
    assert plugin_load_context.conflict_collection_version == None, "conflict_collection_version must be None"
    assert plugin_load_context.resolved == False, "resolved must be False"
    assert plugin_load_context.plugin_resolved_name == name, "plugin_resolved_name must be "
    assert plugin_load_context.plugin_resolved_path == None, "plugin_resolved_path must be None"

# Generated at 2022-06-11 15:07:16.164963
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.plugins.action.normal import ActionModule as ActionModule_normal
    from ansible.plugins.action.copy import ActionModule as ActionModule_copy
    from ansible.plugins.action.file import ActionModule as ActionModule_file
    from ansible.plugins.action.yum_repository import ActionModule as ActionModule_yum_repository
    from ansible.plugins.action.script import ActionModule as ActionModule_script
    from ansible.plugins.action.jboss import ActionModule as ActionModule_jboss
    from ansible.plugins.action.systemd import ActionModule as ActionModule_systemd
    from ansible.plugins.action.known_hosts import ActionModule as ActionModule_known_hosts
    from ansible.plugins.action.synchronize import ActionModule as ActionModule_synchronize

# Generated at 2022-06-11 15:07:26.262908
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    """
    Test function add_all_plugin_dirs adding any existing plugin dirs.
    Ensure that a nonexistend path is ignored and a warning is printed.
    """
    import tempfile

    p = tempfile.mkdtemp()

# Generated at 2022-06-11 15:07:37.215298
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    class TestPluginLoader(PluginLoader):
        ''' Helper class for testing PluginLoader methods '''
        class_name = 'TestClass'
        package = 'test_package'

    # initialize
    test_loader = TestPluginLoader()

    # test all
    with pytest.raises(AnsibleError, match='Do not set both path_only and class_only when calling PluginLoader.all()'):
        list(test_loader.all(path_only=True, class_only=True))

    with pytest.raises(AnsibleError, match='not permitted when class_only is True'):
        list(test_loader.all(class_only=True, bogus='not permitted when class_only is True'))



# Generated at 2022-06-11 15:07:47.660033
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    from ansible.plugins import action
    from ansible.plugins.loader import action_loader, PluginLoader
    from ansible.module_utils.six import string_types
    import ansible.module_utils
    loader = PluginLoader(
        package='ansible.plugins.action',
        config={
            'CACHE_PLUGIN': False,
        },
        directories=action_loader._get_paths(),
        class_name='ActionModule',
        package_errors={},
        aliases={},
        check_permissions=True,
    )
    # Testing when path provided
    real_path = loader.find_plugin(name='debug', collection_list=None)
    assert isinstance(real_path, string_types)
    # Testing when name is provided

# Generated at 2022-06-11 15:07:56.056788
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    plugin_private_dirs = [os.path.dirname(__file__), os.path.dirname(os.path.dirname(__file__))]
    loader = PluginLoader('basic', 'ansible.plugins.basic', 'BasicModule', 'ansible.module_utils.basic', plugin_private_dirs)
    # Generate a list of all the plugins
    plugins = []
    for plugin in loader.all():
        plugins.append(plugin.__name__)
    assert sorted(plugins) == sorted([
        'Hello',
        'NoThrows',
        'ThrowsError',
        'ThrowsRuntimeError',
    ])


# Generated at 2022-06-11 15:08:00.576025
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    a = PluginLoader(package='ansible.plugins.action',
                     config={'_ansible_version': '2.8.0',
                             'module_utils': 'ansible.module_utils'},
                     subdir='action',
                     aliases={},
                     class_name='ActionModule',
                     base_class='ActionBase'
                     )

    for i in a.all():
        pass


# Generated at 2022-06-11 15:08:04.551187
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    '''
    Unit test for method __contains__
    '''
    # No testing needed for this method as it just calls the has_plugin method
    pass


# Generated at 2022-06-11 15:08:11.103526
# Unit test for method all of class PluginLoader

# Generated at 2022-06-11 15:08:45.130866
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Note that this test can't be a unittest since there aren't any entries in plugin_path yet.
    # This is a valid test for testing the iterative ability of the class.  If the all()
    # method does not iterate correctly, then the __iter__() method will not work correctly either.
    loader = PluginLoader(class_name='LookupModule', package='ansible.plugins.lookup', config=None, subdir=None, aliases=None)
    for i in loader:
        print(i)


# Generated at 2022-06-11 15:08:47.973018
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    words = ['joe','mary','sam','joe','bill','bob','sam','mary','bill','bob']
    from collections import Counter
    d = Counter(words)
    print(d)


# Generated at 2022-06-11 15:08:57.512636
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    plugin_path = '/tmp/unittests/'
    con = []
    for name, obj in get_all_plugin_loaders():
        con.append(obj)
    for plugin in con:
        os.mkdir(os.path.join(to_bytes(plugin_path, errors='surrogate_or_strict'), to_bytes(plugin.subdir)))
    add_all_plugin_dirs(plugin_path)
    for plugin in con:
        os.rmdir(os.path.join(to_bytes(plugin_path, errors='surrogate_or_strict'), to_bytes(plugin.subdir)))
    os.rmdir(plugin_path)


# Generated at 2022-06-11 15:09:08.866539
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    loader = PluginLoader(
        package='action_plugins',
        class_name='ActionModule',
        config_options=None,
        aliases=None,
        require_once=True,
        implicit=(),
    )

    try:
        loader.find_plugin_with_context('_missing')
    except AnsibleError as e:
        assert 'no plugin was found matching \'_missing\'' in e.message, e.message

    assert loader.find_plugin_with_context('ping')
    assert loader.find_plugin_with_context('ansible.builtin.ping')

    assert loader.find_plugin_with_context('gather') is None
    assert loader.find_plugin_with_context('gather_facts')
    assert loader.find_plugin_with_context('ansible.builtin.gather') is None

# Generated at 2022-06-11 15:09:12.158625
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    context = PluginLoader.find_plugin_with_context('ansible.module_utils.common')

# Generated at 2022-06-11 15:09:21.614795
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # We need to use a temporary value for
    # ansible/ansible/constants.py C.DEFAULT_MODULE_PATH
    # as that file is loaded before we have a chance to patch it.
    default_module_path = C.DEFAULT_MODULE_PATH

    def reset_module_utils_loader():
        ''' reset the state of the global module utils loader to prevent it from
            disrupting our tests of find_plugin_with_context '''
        module_utils._PLUGIN_PATHS = []
        module_utils._PLUGIN_PATH_CACHE = {}
        module_utils._PLUGINS = None

    # unit test for the default case
    def _default_case():
        # we are starting with an empty module_utils loader
        reset_module_utils_loader()

# Generated at 2022-06-11 15:09:33.691276
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    with patch('ansible.plugins.loader.PluginLoader._get_paths', lambda x: ['/path/to/plugin/dir']):
        loader = PluginLoader('module_utils', 'ModuleUtils', C.MODULE_UTILS_PATH, 'module_utils')
        # Test matching plugin
        plugin_load_context = loader.find_plugin('x')
        assert plugin_load_context.resolved
        assert plugin_load_context.plugin_resolved_name == 'x'
        assert plugin_load_context.plugin_resolved_path == '/path/to/plugin/dir/x/__init__.py'
        # Test non-matching plugin
        plugin_load_context = loader.find_plugin('y')
        assert not plugin_load_context.resolved



# Generated at 2022-06-11 15:09:38.176139
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    loader = PluginLoader('callback')
    try:
        loader.all(class_only=True, path_only=True)
    except AnsibleError:
        pass
    else:
        msg = ('PluginLoader.all() test for calling it with class_only and path_only set at the '
               'same time failed.')
        raise AssertionError(msg)


# Generated at 2022-06-11 15:09:47.971357
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Create 2 collections using test_collection_loader plugin
    test_collection_loader = PluginLoader('test_collection_loader', 'TestCollectionLoader', 'plugins', 'MyClass')
    test_plugin_loader = PluginLoader('test_plugin_loader', 'TestPluginLoader', 'plugins', 'MyClass')

    collection1_path = to_bytes(os.path.join(DATA_PATH, 'test_collection1'))
    collection2_path = to_bytes(os.path.join(DATA_PATH, 'test_collection2'))
    collection3_path = to_bytes(os.path.join(DATA_PATH, 'test_collection3'))
    collection4_path = to_bytes(os.path.join(DATA_PATH, 'test_collection4'))

    # Test find_plugin with no collection_list
    find_plugin

# Generated at 2022-06-11 15:09:52.502113
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    result = PluginLoader(
        'lookup',
        'lookup',
        C.DEFAULT_LOOKUP_PLUGIN_PATH,
        'ansible.plugins.lookup.lookup_loader'
    ).find_plugin('none')
    assert result is not None


# Generated at 2022-06-11 15:10:57.938271
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    from ansible.plugins.loader import ConnectionLoader
    from ansible.plugins.loader import LookupLoader
    from ansible.plugins.loader import ModuleLoader
    from ansible.plugins.loader import ActionLoader
    from ansible.plugins.loader import StrategyLoader
    from ansible.plugins.loader import TerminalLoader
    from ansible.plugins.loader import VarsLoader
    from ansible.plugins.loader import FilterLoader
    from ansible.plugins.loader import TestLoader
    from ansible.plugins.loader import CacheLoader
    from ansible.plugins.loader import CliLoader
    from ansible.plugins.loader import CallbackLoader
    from ansible.plugins.loader import InventoryLoader
    from ansible.plugins.loader import DocumentationLoader
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.loader import ModuleUtilsLoader
   

# Generated at 2022-06-11 15:10:58.929342
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    assert False, "Test not implemented."



# Generated at 2022-06-11 15:11:02.034721
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    assert PluginLoader('ansible.plugins.test.test_plugin_loader', 'TestPlug').find_plugin('test_file') == '/tmp/ansible_test_plugin_loader/test_plugin_loader/test_file.py'


# Generated at 2022-06-11 15:11:04.966832
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.utils.listify import listify_lookup_plugin_terms

    # list of all filters

# Generated at 2022-06-11 15:11:06.185162
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # FIXME: not implemented
    pass


# Generated at 2022-06-11 15:11:08.191170
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin('bash')
    assert shell is not None
    assert shell.SHELL_FAMILY == 'bash'



# Generated at 2022-06-11 15:11:14.551572
# Unit test for method all of class PluginLoader

# Generated at 2022-06-11 15:11:17.238296
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    plugin_loader = PluginLoader('', '', '', '', '', '', '', [])
    result = plugin_loader.get_with_context('')
    assert isinstance(result, object)



# Generated at 2022-06-11 15:11:27.535930
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    display = Display()
    display.v("TEST: test_PluginLoader_all")
    import ansible.plugins.action as action
    pluginloader = PluginLoader(
        'ActionModule',
        'ansible.plugins.action',
        C.DEFAULT_ACTION_PLUGIN_PATH,
        'action_',
        required_base_class='ActionBase'
    )
    all_actionplugins = list(pluginloader.all())
    display.vv("All Action Plugins found: %s" % str(all_actionplugins))