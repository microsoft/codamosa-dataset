

# Generated at 2022-06-11 15:04:02.020202
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():

    plugin_loader = PluginLoader()
    plugin_loader.subdir = 'test'
    orig_plugin_paths = plugin_loader.plugin_paths[:]

    # Test path that doesn't exist.
    add_all_plugin_dirs('/path/to/nowhere')
    # Make sure no extra plugin paths were added.
    assert plugin_loader.plugin_paths == orig_plugin_paths

    # Test directory.
    test_dir = '/tmp/ansible_test_module_utils_loader_add_all_plugin_dirs'
    os.makedirs(test_dir, exist_ok=True)
    os.makedirs(os.path.join(test_dir, 'test'), exist_ok=True)

    add_all_plugin_dirs(test_dir)

# Generated at 2022-06-11 15:04:12.340521
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    '''
    Unit test for method get_with_context of class PluginLoader

    This is the default implementation of a method from the class PluginLoader,
    this method will return a class object or module to use as a plugin. This
    is the default method.
    '''
    kwargs = {'name': 'my_filter', '*args': [1,2,3], '**kwargs': {'a': 'b'}}
    class_name = 'TEST'
    base_class = 'TEST'
    package = 'TEST'
    subdir = 'TEST'
    aliases = {'my_filter': 'my_filter'}
    class_only = False
    collection_list = None
    suffix = 'TEST'


# Generated at 2022-06-11 15:04:23.118949
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    deprecation_entry = {'warning_text': "It's deprecated, yo!",
                         'removal_date': 'Nowish',
                         'removal_version': '3.0.0'}
    plc = PluginLoadContext()
    plc = plc.record_deprecation('foo', None, None)
    assert plc.deprecation_warnings == []
    assert plc.removal_date is None
    assert plc.removal_version is None
    assert plc.deprecated is False

    plc = PluginLoadContext()
    plc = plc.record_deprecation('foo', {}, None)
    assert plc.deprecation_warnings == []
    assert plc.removal_date is None
    assert plc.removal_version is None
    assert plc.dep

# Generated at 2022-06-11 15:04:33.085910
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
  loader = PluginLoader(
      'ansible.plugins.action',
      'ActionModule',
      C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS,
      C.DEFAULT_INVENTORY_ENABLED_HOST_PATTERNS,
  )
  try:
    collection_list = [
      AnsibleCollectionRequirement.from_spec(
          'ansible.all-collections.all',
          '1.0.0',
      )
    ]
  except ValueError:
    collection_list = []
  try:
    loader.find_plugin(
        name='test.test',
        only_first=False,
        ignore_deprecated=True,
        collection_list=collection_list,
    )
  except AnsibleError:
    pass

# Generated at 2022-06-11 15:04:37.773472
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    plugin_loader = PluginLoader('test_package', 'test_base_class', 'test_class_name', 'test_path', 'test_module_regex')
    assert plugin_loader.has_plugin('test_name') == False
test_PluginLoader___contains__()


# Generated at 2022-06-11 15:04:48.476042
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    '''
    Test Function with the following cases:
    1. Test with shell_type(string)
    2. Test with executable(string)
    3. Test with None
    '''
    # Test case 1
    try:
        shell_plugin = get_shell_plugin(shell_type='sh', executable=None)
    except AnsibleError as e:
        shell_plugin = None
    assert(shell_plugin is not None)
    # Test case 2
    try:
        shell_plugin = get_shell_plugin(shell_type=None, executable='/bin/sh')
    except AnsibleError as e:
        shell_plugin = None
    assert(shell_plugin is not None)
    # Test case 3

# Generated at 2022-06-11 15:04:49.873101
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert add_dirs_to_loader is not None

# Generated at 2022-06-11 15:05:00.655444
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    import pytest
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collection_list import AnsibleCollectionRef
    import ansible.plugins.test.test as test_module
    import ansible.plugins.cache.base as cache_module

    class DummyCollection:
        def __init__(self, name, path):
            self.name = name
            self.path = path

    fake_plugin_path = os.path.join(os.path.dirname(test_module.__file__), 'test.py')
    with tempfile.TemporaryDirectory() as temp_path:
        # create a fake collection plugin tmp directory with a plugin file
        collection_name = 'my.awesome.collection'
        collection_path = os.path.join(temp_path, collection_name)
       

# Generated at 2022-06-11 15:05:09.262334
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Initialize a mock PluginLoader object that we can pass to test cases.
    pl = mock.Mock(spec=PluginLoader)

    # Test the path_only kwarg.
    paths = []
    pl.all.return_value = ['path1', 'path2']
    for path in pl.all(path_only=True):
        paths.append(path)
    assert paths == ['path1', 'path2']
    assert pl.all.call_count == 1
    assert pl.all.call_args == mock.call(path_only=True)

    # Test the class_only kwarg.
    pl.all.return_value = [
        mock.Mock(spec=['__init__']),
        mock.Mock(spec=['__init__']),
    ]
    classes = []

# Generated at 2022-06-11 15:05:09.919721
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    pass
# class PluginLoader end



# Generated at 2022-06-11 15:05:57.953897
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # FIXME: make a test

    # Create a PluginLoader object
    plugin_loader = PluginLoader('some_plugin_type', 'some_base_class', 'some_package',
                                 'some_rel_path')

    assert False, "FIXME: I don't know how to test this"



# Generated at 2022-06-11 15:06:07.761408
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    for name, obj in get_all_plugin_loaders():
        obj.directories = []

    add_all_plugin_dirs('/tmp/notarealdir')

    for name, obj in get_all_plugin_loaders():
        assert len(obj.directories) == 0

    add_all_plugin_dirs('../ansible/plugins')
    pattern = '../ansible/plugins/%s/*'

    for name, obj in get_all_plugin_loaders():
        for directory in obj.directories:
            assert os.path.isdir(directory)
            assert glob.glob(pattern % obj.subdir)

# TODO: make this be a data structure that other places can reference,
#       just need to make sure the data structure gets updated when
#       new plugin types are added
plugin_type

# Generated at 2022-06-11 15:06:17.644075
# Unit test for method find_plugin_with_context of class PluginLoader

# Generated at 2022-06-11 15:06:26.606715
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # pylint: disable=unused-variable,undefined-variable,unused-import
    import ansible.plugins.action.copy
    import ansible.plugins.action.synchronize
    import ansible.plugins.cache.redis
    import ansible.plugins.callback.default
    import ansible.plugins.connection.ssh
    import ansible.plugins.connection.winrm
    import ansible.plugins.filter.json
    import ansible.plugins.inventory.host_list
    import ansible.plugins.lookup.file
    import ansible.plugins.netutils.netutil
    import ansible.plugins.shell.bash
    import ansible.plugins.shell.sh
    import ansible.plugins.terminal.unix
    import ansible.plugins.vars.host_group_vars

# Generated at 2022-06-11 15:06:31.940205
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    """add dirs to loader test in ansible.plugins.loader."""
    from ansible.plugins.loader import add_dirs_to_loader

    add_dirs_to_loader('action', ['/etc/ansible/plugins/action'])
    assert '/etc/ansible/plugins/action' in sys.modules[__name__].action_loader.paths



# Generated at 2022-06-11 15:06:43.591841
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Assume that we have only the 'ansible.builtin.copy' module.
    # Also assume 'ansible_collections.foo.bar.baz' module exists

    # this finds an absolute path to a file in our testdata folder
    # ("ansible/test/units/lib/ansible_test/_data/plugins/action")
    # (the _data is added as a prefix by _data/__init__.py)
    test_plugin = os.path.join(collect_test_data_path(), 'test_plugin')

    # create a plugin loader
    a = PluginLoader('Test', '', 'ansible_collections.foo.bar', 'foo')

    # add 'ansible.builtin.copy' + test_plugin path to the search path

# Generated at 2022-06-11 15:06:46.683726
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Create a PluginLoader object
    obj = PluginLoader()
    # call method find_plugin
    fqcr = obj.find_plugin(name='my_module')
    assert fqcr is not None


# Generated at 2022-06-11 15:06:58.195580
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test valid plugin path
    plugin_path = 'valid_plugin_path'
    globals()['valid_plugin_path'] = True
    add_all_plugin_dirs(plugin_path)
    os.remove('valid_plugin_path')
    # Test invalid plugin path
    plugin_path = 'invalid_plugin_path'
    add_all_plugin_dirs(plugin_path)
    # Test path with subdir not a directory
    plugin_path = 'invalid_plugin_path'
    os.mkdir(plugin_path)
    add_all_plugin_dirs(plugin_path)
    # Test path with subdir a directory
    globals()['valid_plugin_path'] = True
    add_all_plugin_dirs(plugin_path)
    os.remove('valid_plugin_path')


# Generated at 2022-06-11 15:07:00.659162
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    assert isinstance(PluginLoader("", "", "").find_plugin(""), (type(None), object))

# Generated at 2022-06-11 15:07:09.089013
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():

    # AnsibleModule is a special case
    import ansible.module_utils
    loader = ansible.module_utils.plugins.module_loader.ModuleLoader()
    assert 'shell' in loader

    loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'ansible.plugins.action.ActionModule', 'action_plugins')
    assert 'setup' in loader

    loader = PluginLoader('ansible.plugins.cache', 'CacheModule', None, 'cache')
    assert 'memory' in loader

    loader = PluginLoader('ansible.plugins.callback', 'CallbackModule', None, 'callback_plugins')
    assert 'default' in loader

    loader = PluginLoader('ansible.plugins.connection', 'Connection', None, 'connection_plugins')
    assert 'local' in loader


# Generated at 2022-06-11 15:07:36.095596
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    print('===')
    pldr = PluginLoader('foo', 'bar', 'blar')
    print(pldr.__contains__('baz'))
    pass


# Generated at 2022-06-11 15:07:42.755066
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    plugin_name = 'test_add_all_plugin_dirs'
    for dir_name in ('filter_plugins', 'action_plugins', 'lookup_plugins', 'callback_plugins', 'vars_plugins',
                     'connection_plugins', 'shell_plugins', 'doc_fragments', 'terminal_plugins'):
        # Remove it if it's already there
        try:
            del globals()['_PLUGIN_PATH_CACHE'][dir_name]
        except KeyError:
            # It was already gone already
            pass

        # Create the plugin dir
        plugin_dir = os.path.join(C.DEFAULT_LOCAL_TMP, plugin_name, to_bytes(dir_name))
        os.makedirs(plugin_dir)

        # Verify the cache is empty before we start

# Generated at 2022-06-11 15:07:44.167947
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    #TODO
    #currently no test for this function
    pass



# Generated at 2022-06-11 15:07:50.987388
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin('sh')
    assert shell.shell_executable == 'sh'
    shell = get_shell_plugin('bash')
    assert shell.shell_executable == 'bash'
    shell = get_shell_plugin('sh', '/bin/bash')
    assert shell.shell_executable == '/bin/bash'
    shell = get_shell_plugin('bash', '/bin/bash')
    assert shell.shell_executable == '/bin/bash'
    shell = get_shell_plugin('sh', '/bin/sh')
    assert shell.shell_executable == '/bin/sh'
    shell = get_shell_plugin('bash', '/bin/sh')
    assert shell.shell_executable == '/bin/sh'
    shell = get_shell_plugin('sh', '/usr/bin/sh')

# Generated at 2022-06-11 15:08:00.607273
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    global _PLUGIN_FILTERS

    cwd = os.getcwd()
    temp_dir = tempfile.mkdtemp()
    test_loader = PluginLoader('cache', package=cwd, subdir=temp_dir, loaded_forced_via_cli=True)

    # Unsupported package.
    try:
        all_plugins = list(test_loader.all())
    except AnsibleError:
        assert 1

    # Test with invalid subdir.
    test_loader = PluginLoader('cache', package=cwd, subdir='invalid')
    try:
        all_plugins = list(test_loader.all())
    except AnsibleError:
        assert 1

    # Test with valid subdir.

# Generated at 2022-06-11 15:08:09.806618
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():

    from .collection_loader import _get_list_collection_roles_paths

    plugin_load_context = PluginLoadContext(plugin_name='foo', collection_list=None, package='ansible.plugins.foo')

    class _MockPluginLoader(PluginLoader):

        def _load_module_source(self, name, path):
            return name

        def _get_paths(self):
            return ['bar']

    l = _MockPluginLoader('foo', 'foo.plugins.bar', 'Baz')

    assert l._find_fq_plugin(name='baz', fq_name=None, extension='py', plugin_load_context=plugin_load_context) == plugin_load_context
    assert plugin_load_context.plugin_resolved_path == 'bar/baz.py'

    plugin_load

# Generated at 2022-06-11 15:08:15.317380
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    '''
    Unit test for method __contains__ of class PluginLoader
    '''
    def test_func():
        '''
        AnsiblePluginLoader.__contains__(self, name, collection_list=None):
        Checks if a plugin named name exists
        '''
        pass # TODO: implement your test here
    raise SkipTest # TODO: remove or comment out this line if test implemented


# Generated at 2022-06-11 15:08:26.102776
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    '''
    This is the test case for method find_plugin of class PluginLoader
    '''
    from ansible.plugins.action.normal import ActionModule
    from ansible.utils.collection_loader import AnsibleCollectionRef

    # Test case for plugin_type = 'action'
    plugin_type = 'action'
    package = 'ansible.plugins.%s' % plugin_type
    class_name = 'ActionModule'
    base_class = 'ActionBase'
    my_plugin_loader = PluginLoader(plugin_type, 'plugin', package, class_name=class_name, base_class=base_class)
    assert my_plugin_loader.find_plugin('normal') == ActionModule
    assert my_plugin_loader.find_plugin('normal.yaml') == ActionModule
    assert my_plugin_loader.find_plugin

# Generated at 2022-06-11 15:08:34.017046
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    """Test the PluginLoader method find_plugin"""
    # Arrange
    pl = PluginLoader('plugins', 'module_utils', 'collections')
    pl._module_cache = defaultdict(MagicMock())
    pl._searched_paths = MagicMock()
    pl._searched_paths.append = MagicMock()
    pl.package = 'ansible.plugins'
    pl.subdir = 'filter_plugins'

    # Act
    result = pl.find_plugin(name="a_file", suffix=".py", plugin_load_context=MagicMock())

    # Assert
    assert result is not None

# Generated at 2022-06-11 15:08:42.020146
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin('sh')
    assert shell.SHELL_FAMILY == 'sh'

    shell = get_shell_plugin(executable='/bin/sh')
    assert shell.SHELL_FAMILY == 'sh'

    shell = get_shell_plugin(executable='/bin/bash')
    assert shell.SHELL_FAMILY == 'sh'

    shell = get_shell_plugin(executable='/bin/ksh')
    assert shell.SHELL_FAMILY == 'sh'



# Generated at 2022-06-11 15:09:21.575492
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():

    # Make sure we don't match plugins we don't care about.
    from ansible.plugins.filter.debug import to_string
    from ansible.plugins.loader import filter_loader
    assert isinstance(filter_loader.all()[0], to_string.FilterModule)

    # Make sure we see all plugins that match.
    from ansible.plugins.filter.debug import run_applescript
    from ansible.plugins.filter.debug import to_json
    from ansible.plugins.filter.debug import to_nice_json
    assert to_string.FilterModule in filter_loader.all()
    assert to_json.FilterModule in filter_loader.all()
    assert to_nice_json.FilterModule in filter_loader.all()

    # Make sure we don't see plugins that don't match.
    assert run_applescript

# Generated at 2022-06-11 15:09:31.138868
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    remote_user = PluginLoadContext()
    remote_user.record_deprecation('remote_user',{'warning_text': 'Use become or become_user instead', 'removal_date': 'never'}, None)
    assert remote_user.deprecation_warnings[0] == 'remote_user has been deprecated. Use become or become_user instead'
    remote_user.record_deprecation('remote_user',{'warning_text': 'Use become or become_user instead', 'removal_version': 'never'}, None)
    assert remote_user.deprecation_warnings[0] == 'remote_user has been deprecated. Use become or become_user instead'



# Generated at 2022-06-11 15:09:40.313494
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    '''
    Test to get the plugin loader for a specific type of plugin.
    '''
    my_loader = PluginLoader('ansible.plugins.test', 'TestPlugin')

    result = my_loader.find_plugin_with_context('shell')
    assert result.plugin_resolved_name == 'shell'
    assert result.plugin_resolved_path == '/home/myhome/ansible/lib/ansible/plugins/test/shell.py'

    result = my_loader.find_plugin_with_context('shell', collection_list=['my_user.my_collection', 'my_user.my_other_collection'])
    assert result.plugin_resolved_name == 'shell'

# Generated at 2022-06-11 15:09:48.888717
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # FIXME: This method only accepts a path to a file, instead of a name.
    # But it will be left as-is for now.
    #
    # We also need to move these tests to unit/ for some plugins.
    # See #32570 for details

    # plugin_loader = PluginLoader('/test/data')
    # plugin_loader.find_plugin('/test/data/find_plugin_test.py')
    # plugin_loader.find_plugin('/test/data/find_plugin_test')
    # plugin_loader.find_plugin('/test/data/find_plugin_test.sh')
    # plugin_loader.find_plugin('/test/data/find_plugin_test')
    pass



# Generated at 2022-06-11 15:10:00.228305
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    obj = PluginLoader()
    assert isinstance(obj, PluginLoader)

    name = 'bar'
    collection_list = ['ansible.builtin']
    import ansible.plugins.loader
    from ansible.plugins.loader import PluginLoader
    loader = PluginLoader(class_name='str', base_class=str, package=ansible.plugins.loader, configurable=True)
    loader.add_directory(os.path.join(os.path.dirname(__file__), '../lib/ansible/plugins/connection'))
    loader.set_package_attributes('.', ['ansible.plugins.connection'])
    loader.has_plugin('network_cli')
    loader.has_plugin('network_cli', collection_list=collection_list)

# Generated at 2022-06-11 15:10:05.194648
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    '''
    Unit test for PluginLoader find_plugin method
    '''
    plugin_loader = PluginLoader('ansible.plugins.test_plugins', 'TestModule')
    name = 'TestModule'

    if not os.path.exists(os.path.join(os.path.dirname(__file__), 'plugins', 'test_plugins', '__init__.py')):
        raise Exception("Must run this test from inside the test/unit directory to locate the test plugin")

    plugin = plugin_loader.find_plugin(name)

    assert plugin is not None, "Plugin %s not found" % name
    assert os.path.basename(plugin) == "%s.py" % name, "Plugin %s not found" % name



# Generated at 2022-06-11 15:10:13.458196
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    plugin_path = '/path/plugins'
    all_plugin_loaders = get_all_plugin_loaders()
    all_plugin_loaders = dict(all_plugin_loaders)

    def reset_plugin_path():
        for name, obj in all_plugin_loaders.items():
            obj._directories = []

    add_all_plugin_dirs('/path/plugins')
    assert sorted(all_plugin_loaders['lookup']._directories) == [u'/path/plugins/lookup_plugins']
    assert sorted(all_plugin_loaders['action']._directories) == [u'/path/plugins/action_plugins']
    assert sorted(all_plugin_loaders['cache']._directories) == [u'/path/plugins/cache_plugins']

# Generated at 2022-06-11 15:10:22.343919
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    ###############################################################################################################
    # Create stubs
    module = MagicMock()
    module.task = {'name': 'Task', 'type': 'action', 'short_description': 'task description'}
    module.task_v2 = {'name': 'Task', 'type': 'action', 'short_description': 'task description'}
    module.test = {'name': 'Test', 'type': 'action', 'short_description': 'task description'}
    module.task_async = {'name': 'TaskAsync', 'type': 'action', 'short_description': 'task description'}
    module.my_task = {'name': 'MyTask', 'type': 'action', 'short_description': 'task description'}

# Generated at 2022-06-11 15:10:32.611758
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    ansible_lib_path = os.path.join(os.path.dirname(__file__), os.path.pardir, os.path.pardir, os.path.pardir, 'lib/ansible')

# Generated at 2022-06-11 15:10:38.399632
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    args = {}
    p = PluginLoader("TestLoader", "plugins", "Plugin", "", "path", "package", "", "", "", "")
    assert p.find_plugin("TestLoader", "plugins", "Plugin", "", "path") == False
    assert p.find_plugin("TestLoader", "plugins", "Plugin", "", "path") == False