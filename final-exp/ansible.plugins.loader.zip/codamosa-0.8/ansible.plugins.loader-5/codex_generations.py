

# Generated at 2022-06-11 15:04:23.744012
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    inventory_data_name = 'inv_loader'
    inventory_data_paths = ['test/units/modules/test_add_dirs_to_loader/inventory']
    add_dirs_to_loader(inventory_data_name, inventory_data_paths)
    inventory = InventoryManager(loader=DataLoader())
    assert inventory.get_plugin('group') == 'test_add_dirs_to_loader'
# Unit test ends here



# Generated at 2022-06-11 15:04:33.437139
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    # default shell_type == sh, mostly for backwards compat
    shell = get_shell_plugin()
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'

    # the next few tests try the different ways to grab the zsh shell
    shell = get_shell_plugin(shell_type='zsh')
    assert shell.SHELL_FAMILY == 'zsh'
    assert shell.executable == '/bin/zsh'

    shell = get_shell_plugin(executable='/bin/zsh')
    assert shell.SHELL_FAMILY == 'zsh'
    assert shell.executable == '/bin/zsh'

    shell = get_shell_plugin(executable='/usr/bin/zsh')

# Generated at 2022-06-11 15:04:38.945657
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test loading all plugins
    import ansible.plugins.action
    p = PluginLoader(package='ansible.plugins.action', class_name='ActionBase')
    plugins = list(p.all())
    assert len(plugins) == 100
    # verify some plugins get loaded
    assert 'copy' in p.all_plugin_names()



# Generated at 2022-06-11 15:04:49.236263
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    from ansible.errors import AnsibleError
    from ansible.utils.display import Display
    from ansible.utils.path import pushd
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.collection_loader import AnsibleCollectionRef, _resolve_collections_in_list
    from ansible.utils.display import ConfigurationWarning
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import PluginLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-11 15:05:00.213434
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    def fake_find_plugin(self, name, collection_list):
        return fake_find_plugin.return_value
    def fake_get_paths():
        return ['/some/path/']
    #
    # Test 1: case when we look for a plugin inside a collection
    #
    name = 'namespace.collection.filter.my_plugin'
    fake_find_plugin.return_value = (name, False)
    jinja2_loader = Jinja2Loader()
    with patch('ansible.plugins.loader.PluginLoader.find_plugin', new=fake_find_plugin):
        find_result = jinja2_loader.find_plugin(name, collection_list=None)
        # Assert that we did not search for the plugin in 'ansible.legacy'

# Generated at 2022-06-11 15:05:02.608612
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    obj = PluginLoader('action_plugin')
    obj.find_plugin('ping')


# Generated at 2022-06-11 15:05:13.249792
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping

    which_loader = 'module'
    paths = ['./tests', '/var/lib']
    loader = getattr(sys.modules[__name__], '%s_loader' % which_loader)

    for path in paths:
        loader.add_directory(path, with_subdir=True)

    assert isinstance(loader.paths, Mapping)
    assert isinstance(loader.package_paths, Mapping)
    assert isinstance(loader.dirs, Mapping)

    for path in paths:
        assert isinstance(loader.paths[path], bytes)
        assert isinstance(loader.package_paths[path], bytes)

# Generated at 2022-06-11 15:05:20.034296
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    import unittest
    import collections
    import datetime
    from ansible.module_utils.six import PY3

    if not PY3:
        DeprecationDict = collections.Mapping
    else:
        DeprecationDict = collections.abc.Mapping

    class TestPluginLoadContext(unittest.TestCase):
        def test_plugin_load_context_record_deprecation_no_deprecation(self):
            name = 'test_plugin'
            deprecation = None
            collection_name = None
            context = PluginLoadContext()
            self.assertFalse(context.deprecated)
            self.assertIsNone(context.removal_date)
            self.assertIsNone(context.removal_version)
            self.assertEqual(context.deprecation_warnings, [])

# Generated at 2022-06-11 15:05:28.476339
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # Create some fake plugin directory
    import tempfile
    from ansible.utils.collection_loader import _get_possible_collection_name
    from ansible.utils.collection_loader.get_collection_path import get_collection_path

    fake_namespace = 'ansible_collections.ansible.fake'
    fake_name = 'foo'
    fake_full_name = '%s.%s' % (fake_namespace, fake_name)
    fake_collection_path = os.path.join(tempfile.mkdtemp(), 'ansible_collections', fake_namespace, fake_name)

    plugin_types = ['action', 'connection', 'shell', 'cache', 'callback', 'doc_fragments', 'filter', 'lookup', 'module_utils', 'test', 'vars']


# Generated at 2022-06-11 15:05:37.072506
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    loader = PluginLoader('ansible.plugins.test.test_plugin_loader', 'PluginLoadTest', required_base_class='TestPluginBase')
    for plugin in loader.all(class_only=True):
        assert plugin.__name__.startswith('TestPlugin')
        break
    else:
        assert False, 'unable to find plugin from PluginLoadTest'

    for plugin in loader.all():
        assert plugin.__class__.__name__.startswith('TestPlugin')
        break
    else:
        assert False, 'unable to find plugin from PluginLoadTest'



# Generated at 2022-06-11 15:07:45.802445
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():

    assert __name__ == '__main__'

    class TestJinja2Loader(Jinja2Loader):
        pass

    j_loader = TestJinja2Loader()

    assert j_loader.find_plugin('hi') is None
    assert j_loader.find_plugin('hi.hi') is None
    assert j_loader.find_plugin('ansible.legacy.plugins.filter.hi') is None
    assert j_loader.find_plugin('ansible.legacy.plugins.filter.foo.bar') is None
    assert j_loader.find_plugin('ansible.legacy.plugins.filter.foo_bar') is None



# Generated at 2022-06-11 15:07:55.977577
# Unit test for function get_shell_plugin
def test_get_shell_plugin():

    import unittest
    import pytest

    try:
        import packaging.version
    except ImportError:
        pytest.skip(
            'Packaging is unavailable on this platform, skipping test_get_shell_plugin')

    class TestGetShellPlugin(unittest.TestCase):

        @staticmethod
        def _get_shell_plugin(shell_type=None, executable=None):
            try:
                return get_shell_plugin(shell_type=shell_type, executable=executable)
            except AnsibleError as e:
                # Python 2.6 does not allow the AnsibleError to be re-raised with the original
                # message so we have to do this.
                raise AnsibleError(e.message)


# Generated at 2022-06-11 15:07:59.745103
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():

    (errs, rc) = test_class(Jinja2Loader, 'Jinja2Loader',
        init_args=('filter_plugins', 'FilterModule', 'ansible.plugins.filter'),
        inst_methods=[
            ('get', ('fail'), {}),
        ] )
    assert not errs



# Generated at 2022-06-11 15:08:04.902789
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    '''
    Unit test for method find_plugin of class PluginLoader
    '''
    obj = PluginLoader('foo')
    assert obj.find_plugin('foo') is None

    # TODO: More!

# Unit tests for the class PluginLoader

# Generated at 2022-06-11 15:08:11.281710
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    args = {
        'package': 'ansible.plugins.lookup',
        'base_class': 'LookupBase',
    }
    plugin_loader = PluginLoader(**args)

    plugin_load_context = mock.MagicMock()
    plugin_load_context.package = 'ansible_collections.c_mckennan.bar'
    plugin_load_context.collection_ns = None
    plugin_load_context.collection_name = 'c_mckennan.bar'
    plugin_load_context.collection_version = None
    plugin_load_context.plugin_resolved_path = None
    plugin_load_context.plugin_resolved_name = None
    plugin_load_context.redirect_list = None
    plugin_load_context.nope.return_value = plugin_load_context

# Generated at 2022-06-11 15:08:21.288330
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    try:
        import jinja2
    except ImportError:
        raise SkipTest("jinja2 Python module needs to be installed to run the Jinja2 unit tests")

    try:
        import jinja2.ext
    except ImportError:
        raise SkipTest("jinja2.ext Python module needs to be installed to run the Jinja2 unit tests")

    with change_cwd('test/units/plugins/filter_loader'):
        loader = Jinja2Loader(jinja2.filters)

        # test cases of finding filters in importable / ansible default jinja2 namespaces
        # each of these should match a jinja2 filter for a valid test
        # importable ansible default namespace

# Generated at 2022-06-11 15:08:26.523558
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    which_loader = 'shell'
    paths=[r'C:\Ansible\ansible\lib\ansible\plugins\shell']
    loader = getattr(sys.modules[__name__], '%s_loader' % which_loader)
    for path in paths:
        loader.add_directory(path, with_subdir=True)


# Generated at 2022-06-11 15:08:35.824958
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    plugin_loader = PluginLoader(
        class_name='Network',
        package='ansible.plugins.connection')
    with pytest.raises(AnsibleError):
        plugin_loader.find_plugin_with_context(
            name='invalid_connection',
            collection_list=None)
    plugin_load_context = plugin_loader.find_plugin_with_context(
        name='network_cli',
        collection_list=None)
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_path
    assert plugin_load_context.plugin_resolved_name == 'network_cli'
    assert plugin_load_context.redirect_list == []
    plugin_loader = PluginLoader(
        class_name='ActionModule',
        package='ansible.plugins.action')

# Generated at 2022-06-11 15:08:46.588913
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    """ Check that PluginLoadContext.record_deprecation logs the correct deprecation warning and sets correct values of deprecation flags
       1. Remove the existing deprecation warning messages
       2. Create a plugin_load_context object
       3. If one of the deprecation warning is logged, check that the warning message contains the correct plugin name and deprecation message and flags
    """
    display.deprecations = []
    display.warnings = []
    context = PluginLoadContext()
    context.record_deprecation("my_plugin", {'warning_text': 'my_plugin deprecation warning'}, 'my_collection')
    # the plugin name, warning_text and removal_date are not present in the first deprecation message

# Generated at 2022-06-11 15:08:50.904638
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    '''
    Unit test for method __contains__ of class PluginLoader
    '''
    plugin_loader_instance = PluginLoader('action_plugins')
    assert True == plugin_loader_instance.__contains__('copy')
    assert False == plugin_loader_instance.__contains__('i_do_not_exist')


# Generated at 2022-06-11 15:09:27.041052
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    import os

    class TestPluginLoader(PluginLoader):
        def _get_paths(self):
            return self.plugin_paths

        def find_plugin(self, *args, **kwargs):
            return 'find_plugin'

    plugin_loader = TestPluginLoader('test_plugins')
    test_path = '/test_path'

    # dir is not None and doesn't exists
    prev_paths = plugin_loader.plugin_paths
    try:
        os.rmdir(test_path)
    except OSError:
        pass
    plugin_loader.add_directory(test_path)
    assert prev_paths == plugin_loader.plugin_paths

    # add dir and make sure it's added to plugin_paths
    os.mkdir(test_path)

# Generated at 2022-06-11 15:09:37.980841
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Initialize a PluginLoader.
    plugin_loader = PluginLoader()

    # Test case 1: plugin == 'shell'.
    name = 'shell'
    suffix = '_shell'
    context = plugin_loader._find_plugin_with_context(name, suffix)
    assert context.resolved
    assert context.plugin_resolved_name == name
    assert context.plugin_resolved_fqcr == 'ansible.builtin.shell'
    assert context.plugin_resolved_path == './lib/ansible/plugins/shell'
    # The following assertion depends on which version of Ansible is being run.
    # Check that the path matches the following glob.
    #   ./lib/ansible/plugins/shell_<...>/__init__.py

# Generated at 2022-06-11 15:09:44.406042
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    loader = PluginLoader('nonexistent', 'nonexistent', 'nonexistent')

    if getattr(loader, 'get_with_context', None) is None:
        pytest.skip("Skipping test because PluginLoader has no get_with_context method")

    loader.find_plugin = lambda name: 'path'

    context = loader.get_with_context('name')
    assert context.plugin_load_context.resolved
    assert context.object == 'path'

# Generated at 2022-06-11 15:09:45.520488
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    pass


# Generated at 2022-06-11 15:09:55.993976
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    collection_name = 'test.collection'
    PLUGIN_NAME = 'test'
    display.deprecated = MagicMock()

    warning_text = 'test deprecation'

    deprecation = dict(
        warning_text=warning_text,
        removal_date=None,
        removal_version='1.3.2'
    )
    plc = PluginLoadContext().record_deprecation(PLUGIN_NAME, deprecation, collection_name)
    assert plc.deprecated == True
    assert plc.removal_date == None
    assert plc.removal_version == '1.3.2'
    assert plc.deprecation_warnings == [warning_text]

# Generated at 2022-06-11 15:10:07.129858
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # FIXME: this test is far to complex and far too low level - it would be better to test at the pluginapi level, which
    # is what users actually consume, rather than here, where users don't actually consume it
    try:
        os.remove("/tmp/test_plugin_finder/ansible.cfg")
    except OSError:
        pass

    config = ConfigParser(constants.DEFAULTS)
    config.set("defaults", "action_plugins", "/tmp/test_plugin_finder/action_plugins")
    config.set("defaults", "cache_plugins", "/tmp/test_plugin_finder/cache_plugins")
    config.set("defaults", "callback_plugins", "/tmp/test_plugin_finder/callback_plugins")

# Generated at 2022-06-11 15:10:13.237730
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    pc = PluginLoadContext()
    deprecation = dict()
    deprecation['warning_text'] = "This module is deprecated"
    deprecation['removal_version'] = "2.9"
    deprecation['removal_date'] = "2022-01-01"
    print ("The plugin context name is " + pc.resolved_fqcn)
    pc.record_deprecation("action plugin", deprecation, "testing")
    print ("The plugin context name is " + pc.resolved_fqcn)
# End of Unit test for method record_deprecation of class PluginLoadContext



# Generated at 2022-06-11 15:10:18.810671
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    '''Unit tests for function add_dirs_to_loader'''
    # create a temporary directory
    import tempfile
    dir = tempfile.mkdtemp()
    # create a temporary module

# Generated at 2022-06-11 15:10:30.733741
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # Setup: create a mock plugin loader
    # TODO: use unittest.mock.patch.dict

    # test _dedupe=False -- items are always added
    test_plugin_paths = [
        '/home/JohnDoe/ansible/plugins/filter_plugins/test.py',
        '/home/JohnDoe/ansible/plugins/filter_plugins/test2.py',
        '/home/JohnDoe/ansible/plugins/filter_plugins/test3.py',
    ]


# Generated at 2022-06-11 15:10:41.742283
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    import ansible.plugins.loader

    # list is required for os.path.dirname() to return a valid string for path
    class TestJinja2Loader(ansible.plugins.loader.Jinja2Loader):
        pass

    # main test
    TestJinja2Loader._searched_paths = ['ansible/plugins/test']
    TestJinja2Loader._count_paths = 1
    TestJinja2Loader._module_cache = {'test': 'test'}
    TestJinja2Loader.class_name = 'test'
    TestJinja2Loader.package = 'ansible.plugins.test'
    TestJinja2Loader.base_class = 'test'
