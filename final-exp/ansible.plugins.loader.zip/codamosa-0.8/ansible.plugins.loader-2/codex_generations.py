

# Generated at 2022-06-11 15:03:57.769992
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    obj = PluginLoader({'cache_key': 'ansible.plugins.cache.CacheModule'})

# Generated at 2022-06-11 15:04:02.285641
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method PluginLoader.__setstate__
    '''
    loader = PluginLoader('module.name')
    state = {'_searched_paths': [], '_caching_priorities': {}}
    loader.__setstate__(state)


# Generated at 2022-06-11 15:04:12.987540
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    # Test case with passing a shell_type
    shell = get_shell_plugin('sh')
    assert shell_loader.get('sh') == shell

    # Test case with passing a executable that is not in standard location
    executable = '/bin/bash'
    shell = get_shell_plugin(executable=executable)
    assert getattr(shell, 'executable', None) == executable

    # Test case with passing a executable
    executable = '/usr/bin/bash'
    shell = get_shell_plugin(executable=executable)
    assert getattr(shell, 'executable', None) == executable

    # Test case with passing a executable that is not in standard location
    executable = '/bin/bash'
    shell = get_shell_plugin(executable=executable)
    assert getattr(shell, 'executable', None) == executable

# Generated at 2022-06-11 15:04:19.209245
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    from ansible.plugins.loader import Jinja2Loader
    path = "/home/kchoudha/.ansible/collections/ansible_collections/test/test_filter_plugins"
    # We don't use the 'name' keyword, so it will just be an empty string
    plugin = Jinja2Loader.get(path)
    print(plugin)



# Generated at 2022-06-11 15:04:27.364434
# Unit test for function get_shell_plugin
def test_get_shell_plugin():

    try:
        shell = get_shell_plugin(shell_type='sh')
    except Exception as e:
        assert False, e.message
    assert shell

    try:
        shell = get_shell_plugin(shell_type='sh', executable='/bin/sh')
    except Exception as e:
        assert False, e.message
    assert shell

    try:
        shell = get_shell_plugin(shell_type='csh', executable='/bin/csh')
    except Exception as e:
        assert False, e.message
    assert shell

    try:
        shell = get_shell_plugin(shell_type='powershell', executable='/usr/bin/powershell')
    except Exception as e:
        assert False, e.message
    assert shell


# Generated at 2022-06-11 15:04:35.300774
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    class ExamplePlugin(object):
        pass
    class ExamplePluginLoader(PluginLoader):
        def _get_paths(self):
            return ['/example/path']
        def find_plugin(self, name, collection_list=None):
            return '/example/path/example.py'
    test_obj =  ExamplePluginLoader('/example/path', 'example.py', 'example', ExamplePlugin)
    assert_equal(next(test_obj.all()), ExamplePlugin())
    assert_equal(next(test_obj.all(class_only=True).__iter__()), ExamplePlugin)
    assert_equal(next(test_obj.all(path_only=True).__iter__()), '/example/path/example.py')

# Generated at 2022-06-11 15:04:47.118961
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    from ansible.utils.path import mk_tmp_path
    from random import randint

    plugin_loader_name = 'Loader_{0}'.format(randint(1000, 9999))
    plugin_loader_package = 'Package_{0}'.format(randint(1000, 9999))
    plugin_loader_class_name = 'Class_{0}'.format(randint(1000, 9999))

    temp_dir = mk_tmp_path()
    searchpath = []
    searchpath.append(temp_dir)

    by_name_cache = {}
    by_name_cache['cache_{0}'.format(randint(1000, 9999))] = randint(1000, 9999)
    by_name_cache['cache_{0}'.format(randint(1000, 9999))] = randint(1000, 9999)

# Generated at 2022-06-11 15:04:48.468889
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # FIXME: figure out how to test this in an isolated manner
    pass



# Generated at 2022-06-11 15:04:58.168761
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    loader = Jinja2Loader(name='test_Jinja2Loader', class_name='test_Jinja2Loader', package='test_Jinja2Loader')
    loader.add_directory(__file__)
    # get method
    name = 'test_Jinja2Loader.py'
    result = loader.get(name)
    assert result is not None
    # get method with redirects
    name = 'test_Jinja2Loader'
    result = loader.get(name)
    assert result is not None
    # get method with different name
    name = 'test_Jinja2Loader1'
    result = loader.get(name)
    assert result is None


# Generated at 2022-06-11 15:05:00.257329
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    p = PluginLoader('')
    p.__setstate__(1)


# Generated at 2022-06-11 15:05:47.875470
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    paths_to_mock = (
        'ansible.plugins.cache.base',
        'ansible.plugins.cache.jsonfile',
    )

    with patch.object(PluginLoader, 'get_all_plugin_loaders') as mock_galpl:
        mock_galpl.return_value = [
            PluginLoader('ansible.plugins.cache', 'CacheModule', 'cache')
        ]

        with patch.object(PluginLoader, 'get_plugin_path_by_name') as mock_gppbn:
            mock_gppbn.return_value = None

            with patch.object(PluginLoader, '_get_package_paths') as mock_gpp:
                mock_gpp.return_value = 'ansible/plugins/cache'


# Generated at 2022-06-11 15:05:59.022386
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    class TestPluginLoadContext(PluginLoadContext):
        def __init__(self):
            super(TestPluginLoadContext, self).__init__()
    ctx = TestPluginLoadContext()
    assert not ctx.deprecated
    assert ctx.deprecation_warnings == []

    ctx = ctx.record_deprecation(name='test_plugin',
                                 deprecation={'warning_text': 'you should not use me',
                                              'removal_date': '2021-10-18'},
                                 collection_name='')
    assert ctx.deprecated
    assert ctx.removal_date == '2021-10-18'
    assert ctx.deprecation_warnings == ['test_plugin has been deprecated. you should not use me']



# Generated at 2022-06-11 15:05:59.850115
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    pass

# Generated at 2022-06-11 15:06:05.431998
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # We expect the function to raise a ValueError if the directory is not valid
    with pytest.raises(ValueError) as execinfo:
        path = "/abc/def/ghi"
        PluginLoader.add_directory(path)

    # The path must be a string
    with pytest.raises(TypeError) as execinfo:
        path = "{"
        PluginLoader.add_directory(path)


# Generated at 2022-06-11 15:06:09.514048
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():

    class Base:
        pass

    class A(Base):
        pass

    class B(Base):
        def __init__(self, *args, **kwargs):
            raise RuntimeError("I'm broken")

    class C(Base):
        def __init__(self, *args, **kwargs):
            raise TypeError("I'm an abstract base class")

    class D(A):
        pass

    class E(A):
        pass

    class AnsiblePluginLoaderTest(PluginLoader):
        class_name = 'AnsiblePlugin'
        base_class = 'Base'
        package = 'AnsiblePluginLoaderTest'

    class AnsiblePluginLoaderTest2(PluginLoader):
        class_name = 'AnsiblePlugin'
        package = 'AnsiblePluginLoaderTest'


# Generated at 2022-06-11 15:06:10.681751
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert get_shell_plugin()



# Generated at 2022-06-11 15:06:13.282054
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell_filename = os.path.basename("/bin/sh")
    shell = get_shell_plugin(executable="/bin/sh")
    assert shell_filename == shell.NAME
# end unit test



# Generated at 2022-06-11 15:06:23.223257
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    action_paths = [
        os.path.join(os.path.dirname(__file__), 'fixtures/plugins/action1'),
        os.path.join(os.path.dirname(__file__), 'fixtures/plugins/action2'),
    ]
    add_dirs_to_loader('action', action_paths)

    assert len(list(action_loader.all())) == 4
    assert len(list(action_loader.all(include_parents=True))) == 7
    assert len(list(action_loader.all(include_builtin=True))) == 5
    assert len(list(action_loader.all(include_builtin=True, include_parents=True))) == 8



# Generated at 2022-06-11 15:06:33.994492
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    import os
    import tempfile
    data ="""
plugin: ansible.posix.system
deprecation:
  warning_text: this is a test.
  removal_date: 2018-02-18
  removal_version: 2.8
"""
    # create a collection
    test_dir = tempfile.mkdtemp()
    collection_dir = os.path.join(test_dir,'ns1-col1')
    os.makedirs(collection_dir)
    target_dir = os.path.join(collection_dir,'plugins')
    os.makedirs(target_dir)
    target_file = os.path.join(target_dir,'system.yml')

# Generated at 2022-06-11 15:06:45.729576
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    from ansible.plugins import filter_loader, module_loader
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_bytes
    from tempfile import mkdtemp, mkstemp
    from ansible.utils.path import makedirs_safe
    import shutil
    import os

    plugin_loader = filter_loader
    k, v = next(iter(ansible_collections['collection_one']['plugins']['filter_plugins'].items()))
    collection_search_paths = [to_bytes(path, errors='surrogate_or_strict') for path in v]

    # Create a temp directory and populate it with plugins.  These plugins
    # will be added to the front of the search path for the collection that
    # we've selected in the test.

# Generated at 2022-06-11 15:07:16.752229
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():

    import __main__
    global __main__

    class Test_Module(object):
        def __init__(self, *args, **kwargs):
            pass

        def __new__(cls, *args, **kwargs):
            return super(Test_Module, cls).__new__(cls)


# Generated at 2022-06-11 15:07:23.091085
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    global _filter_plugin_manager
    assert _filter_plugin_manager is not None
    assert 'compare' in _filter_plugin_manager.get('compare')
    assert 'compare' in _filter_plugin_manager.get('ansible.legacy.filter_plugins.compare')
    assert 'compare' in _filter_plugin_manager.get('ansible_collections.ansible.builtin.compare')


# Generated at 2022-06-11 15:07:32.937630
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Confirm default value for all()
    loader = PluginLoader(package='foo', class_name='Foo')
    assert loader.all() == loader.all(path_only=False, class_only=False, _dedupe=True)

    # Make sure _dedupe is not a keyword parameter
    with pytest.raises(TypeError):
        loader = PluginLoader(package='foo', class_name='Foo')
        loader.all(_dedupe=True)

    # Make sure path_only and class_only are mutually exclusive
    with pytest.raises(AnsibleError):
        loader = PluginLoader(package='foo', class_name='Foo')
        list(loader.all(path_only=True, class_only=True))

    # Confirm that class_only works

# Generated at 2022-06-11 15:07:36.307015
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    plugin_loader = PluginLoader(package=None, searchpath=None)
    assert isinstance(plugin_loader.all(), types.GeneratorType)


# Generated at 2022-06-11 15:07:42.883969
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    loader =  PluginLoader(package='', subdir='', class_name='', base_class='', DEBUG=False)
    expected = [('/test/path/plugins', True), ('/test/path/test_plugins', False), ('/test/path/modules', False), ('/test/path/module_utils', False), ('/test/path/filter_plugins', False)]
    actual = list(loader._get_paths())
    assert expected == actual, 'Expected: {0}\nActual:   {1}'.format(expected, actual)

    # Test special case where paths is an empty sequence
    loader.paths = []
    expected = []
    actual = list(loader._get_paths())
    assert expected == actual, 'Expected: {0}\nActual:   {1}'.format(expected, actual)


# Generated at 2022-06-11 15:07:50.504739
# Unit test for method find_plugin of class PluginLoader

# Generated at 2022-06-11 15:08:00.176485
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # Jinja2Loader.get(name, class_only=False, path_only=False, config=None, args=None, kwargs=None, require_module=True)

    from ansible.plugins.loader import Jinja2Loader

    jinja2_loader = Jinja2Loader() # package='ansible.plugins.jinja2')

    def mock_get_all_file_paths(self, subdir):
        if subdir == 'filter_plugins':
            return ['ansible/plugins/filter_plugins/core.py']
        elif subdir == 'test_plugins':
            return ['ansible/plugins/test_plugins/core.py']
    jinja2_loader.get_all_file_paths = MethodType(mock_get_all_file_paths, jinja2_loader)

# Generated at 2022-06-11 15:08:07.355356
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # we test that it can add a directory
    loader = PluginLoader('', '', '', '', '', '', '', '')
    assert len(loader._get_paths()) == 0
    loader.add_directory('/tmp')
    assert len(loader._get_paths()) == 1

    # we also test that it won't add the same directory twice
    loader.add_directory('/tmp')
    assert len(loader._get_paths()) == 1



# Generated at 2022-06-11 15:08:17.684410
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    name = 'name'
    collection_list = 'collection_list'
    obj = PluginLoader('name')
    with patch.object(AnsibleInventoryCLI, '__init__') as mock_init:
        mock_init.return_value = None
        with patch.object(AnsibleInventoryCLI, 'parse') as mock_parse:
            mock_parse.return_value = None
            with patch.object(AnsibleInventoryCLI, 'run') as mock_run:
                mock_run.return_value = None
                with patch.object(AnsibleInventoryCLI, 'get_host_variables') as mock_ghv:
                    mock_ghv.return_value = None

# Generated at 2022-06-11 15:08:23.174807
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    """ add_dirs_to_loader should add directories to the loader """
    loader = getattr(sys.modules[__name__], 'test_loader')
    test_plugins = ['/test/test_plugin/', '/test/test_plugin1/']
    add_dirs_to_loader('test', test_plugins)
    assert loader.get_dirs() == test_plugins



# Generated at 2022-06-11 15:09:09.817250
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    import sys
    import types
    import unittest2 as unittest

    class Test_PluginLoader_all(unittest.TestCase):
        def _create_loader(self):
            class Fake(object):
                pass
            class FakeModule(object):
                pass

            fake = Fake()
            fake.class_name = 'class_name'
            fake.package = 'package'
            fake.subdir = 'subdir'
            fake.base_class = 'base_class'
            fake.aliases = {}

            fake.collection_list = None
            fake._searched_paths = []
            fake._module_cache = {}

            this_module = sys.modules[__name__]
            fake.path = this_module.__path__[0]

            def _get_paths():
                return fake

# Generated at 2022-06-11 15:09:20.876217
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    from collections import namedtuple
    testcase = namedtuple('testcase', ['description', 'mock_m_find_plugin_results', 'mock_find_plugin_fq_names',
                                       'mock_find_plugin_resolved_name', 'expected_find_plugin_result'])


# Generated at 2022-06-11 15:09:32.849019
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    import re
    import tempfile
    import shutil

    p = re.compile(r'ansible\.legacy\.plugins\.')
    pl = Jinja2Loader()
    assert isinstance(pl, Jinja2Loader)

    # test with file under ansible.legacy.plugins
    with tempfile.NamedTemporaryFile('w') as f:
        c = f.write("from ansible.errors import AnsibleFilterError\ndef from_yaml(arg):\n    raise AnsibleFilterError('x')")
        f.flush()
        d = os.path.dirname(f.name)
        m = 'ansible.legacy.plugins.test'
        for x in pl._get_paths(d):
            assert x == d
        pname = os.path.basename(f.name)

# Generated at 2022-06-11 15:09:40.498683
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    #Check if function add_all_plugin_dirs works fine or not
    import tempfile
    import shutil
    import os

    temp_plugin_dirs = '/tmp/plugins'
    os.makedirs(temp_plugin_dirs)
    sub_dir =  os.path.join(temp_plugin_dirs,"action")
    os.makedirs(sub_dir)
    f = tempfile.NamedTemporaryFile(delete=False, dir=sub_dir)
    plugin_name = f.name.split('/')[-1]
    f.close()
    add_all_plugin_dirs(temp_plugin_dirs)
    #Check if the plugin was added or not
    assert(plugin_name in dir(ActionModuleLoader))


# Generated at 2022-06-11 15:09:46.272194
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert isinstance(get_shell_plugin(shell_type='sh'), AnsibleShellModule)
    assert isinstance(get_shell_plugin(shell_type='powershell', executable='powershell_executable'), AnsiblePowerShell)
    assert isinstance(get_shell_plugin(executable='bash_executable'), AnsibleShellModule)
    assert isinstance(get_shell_plugin(executable='powershell_executable'), AnsiblePowerShell)



# Generated at 2022-06-11 15:09:46.929198
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    assert True

# Generated at 2022-06-11 15:09:57.761885
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    loader = PluginLoader('foo')

    with patch.object(loader, '_get_paths', return_value=['/bar/bar/bar/']):
        with patch.object(os.path, 'exists', return_value=False):
            assert loader.find_plugin('baz') is None

        with patch.object(os.path, 'exists', return_value=True):
            loader.package = 'ansible'
            with patch.object(loader, '_get_plugin_path_by_package', return_value=None):
                assert loader.find_plugin('shell_common_args') is None

            with patch.object(loader, '_get_plugin_path_by_package', return_value='/bar/bar/bar/shell_common_args.py'):
                loader.aliases = {}
               

# Generated at 2022-06-11 15:10:08.864963
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Add an extra plugin type to test
    class TestPluginLoader(PluginLoader):
        subdir = 'test'
    # Add initial directories to test
    for name, obj in get_all_plugin_loaders():
        if obj.subdir:
            obj.add_directory(os.path.join(C.DEFAULT_LOCAL_TMP, obj.subdir))
    # Test addition of a path that doesn't exist
    nonexistent_dir = os.path.join(C.DEFAULT_LOCAL_TMP, 'test', 'q')
    add_all_plugin_dirs(nonexistent_dir)
    for name, obj in get_all_plugin_loaders():
        if obj.subdir:
            assert nonexistent_dir not in obj.get_directories()
    # Test addition of a file to the test plugin dir

# Generated at 2022-06-11 15:10:11.315343
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Sample package
    name = 'collection_loader'
    # Load it
    pl = PluginLoader(name)
    # Try its method all
    for _ in pl.all():
        pass


# Generated at 2022-06-11 15:10:19.869926
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Set up some dummy class to use as a plugin loader
    class TestLoader(PluginLoader):
        subdir = 'test_subdir'

    # Cleanup previous tests
    if 'TestLoader' in globals():
        del globals()['TestLoader']

    # Test without subdir
    TestLoader.subdir = 'test_subdir'
    add_all_plugin_dirs('/tmp/invalid_dir')

    # Test with subdir
    TestLoader.subdir = 'test_subdir'
    add_all_plugin_dirs('/tmp/invalid_dir')



# Generated at 2022-06-11 15:11:10.778433
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    assert 'foo' == 'foo'

# Generated at 2022-06-11 15:11:12.826339
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
	#
	# PluginLoader.all() not tested
	#
	return True


# Generated at 2022-06-11 15:11:13.805027
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():

    assert True == True


# Generated at 2022-06-11 15:11:16.464301
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    pl = PluginLoader(package='ansible.plugins', config=dict(), directories=[], class_name='ActionModule')
    assert 'ping' in pl
    assert 'broken' not in pl


# Generated at 2022-06-11 15:11:26.714578
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    def clear_vars():
        if 'shell_type' in globals():
            del shell_type
        if 'executable' in globals():
            del executable

    # If a shell type is not given, default to sh
    # Also, for backwards compat, check for the executable file
    clear_vars()
    shell = get_shell_plugin()
    assert (shell.SHELL_NAME == 'sh')
    assert (not hasattr(shell, 'executable'))

    clear_vars()
    shell = get_shell_plugin('bash')
    assert (shell.SHELL_NAME == 'bash')
    assert (not hasattr(shell, 'executable'))

    clear_vars()
    shell = get_shell_plugin(executable='/bin/bash')