

# Generated at 2022-06-11 15:03:45.555900
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    pl = PluginLoader('ansible.plugins.test.test_plugin_loader', 'Test', 'test_plugins')
    plugin_classes = pl.all(class_only=True)
    assert sorted(pl.all(class_only=True)) == [FakePlugin2, FakeTestPlugin]

    plugin_instances = pl.all()
    assert isinstance(plugin_instances, types.GeneratorType)
    plugin_instances = sorted(plugin_instances, key=lambda plugin: plugin.__class__.__name__)
    assert plugin_instances[0].__class__.__name__ == 'FakeTestPlugin'
    assert plugin_instances[1].__class__.__name__ == 'FakePlugin2'

    plugin_paths = sorted(pl.all(path_only=True))

# Generated at 2022-06-11 15:03:57.251099
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # change paths to test if they are exist
    old_paths = C.DEFAULT_MODULE_PATH
    plugin_paths = ['/usr/local/lib/foo_plugins', '/usr/lib/bar_plugins']
    for plugin_path in plugin_paths:
        add_all_plugin_dirs(plugin_path)
    assert C.DEFAULT_MODULE_PATH == old_paths + plugin_paths
    # change paths to test if they are not exist
    old_paths = C.DEFAULT_MODULE_PATH
    plugin_paths = ['/usr/local/lib/foo_plugins_not_exist',
                    '/usr/lib/bar_plugins_not_exist']
    for plugin_path in plugin_paths:
        add_all_plugin_dirs(plugin_path)

# Generated at 2022-06-11 15:04:06.260770
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # create the mock plugin dirs
    plugin_dir = 'test/test_add_all_plugin_dirs'
    cache.makedirs(plugin_dir, exist_ok=True)
    cache.makedirs(os.path.join(plugin_dir, 'module_utils'), exist_ok=True)
    cache.makedirs(os.path.join(plugin_dir, 'lookup_plugins'), exist_ok=True)
    cache.makedirs(os.path.join(plugin_dir, 'action_plugins'), exist_ok=True)
    cache.makedirs(os.path.join(plugin_dir, 'cache_plugins'), exist_ok=True)
    cache.makedirs(os.path.join(plugin_dir, 'connection_plugins'), exist_ok=True)
    cache.makedirs

# Generated at 2022-06-11 15:04:09.014780
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    for pld in _PLUGIN_LOADERS:
        assert isinstance(pld.all(), types.GeneratorType)


# Generated at 2022-06-11 15:04:16.280228
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    PL = PluginLoader("", "", "")
    # Test when an error is raised in the find_plugin() method
    with pytest.raises(Exception):
        PL.find_plugin("foo")
    # Test when find_plugin() returns a path
    def get_paths():
        yield "test_plugins"
    PL.get_paths = get_paths
    assert PL.find_plugin("foo") == "test_plugins/foo"


# Generated at 2022-06-11 15:04:25.391431
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    """
    This method is used to test the record_deprecation method in the
    PluginLoadContext class.
    :return:
    """
    deprecation_warning = dict(
        warning_text="Warning text",
        removal_date="2030-01-01"
    )
    context = PluginLoadContext()
    # Test if deprecation message is printed correctly when deprecation warning is given
    assert context.record_deprecation("test", deprecation_warning, "ansible.test").deprecation_warnings[0] == "test has been deprecated. Warning text"
    # Test if warning message is printed correctly when removal_date is given
    assert context.record_deprecation("test", deprecation_warning, "ansible.test").removal_date == "2030-01-01"
    # Test if

# Generated at 2022-06-11 15:04:34.363943
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test that the method all of class PluginLoader can be called with the following argument types and combinations
    import sys
    import tempfile
    from ansible.module_utils.common._collections_compat import Mapping

    PROVIDED_ARGS = [
    ]

    PROVIDED_KWARGS = {
        'class_only': [True, False],
        '_dedupe': [True, False],
        'path_only': [True, False],
    }

    # TODO: Modify this to support more complex argument types
    class ArgObj:
        def __init__(self, val):
            self.val = val

    class KwargObj:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs


# Generated at 2022-06-11 15:04:43.787450
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    from ansible.plugins.shell import ShellModule

    assert isinstance(get_shell_plugin(shell_type='sh'), ShellModule)

    class SillyShellModule(ShellModule):
        SHELL_FAMILY = 'test_shell'
        COMPATIBLE_SHELLS = ['silly-shell']

    assert get_shell_plugin(executable='/tmp/silly-shell') is None
    shell_loader.add(SillyShellModule)
    assert isinstance(get_shell_plugin(executable='/tmp/silly-shell'), SillyShellModule)
del test_get_shell_plugin



# Generated at 2022-06-11 15:04:51.760679
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
  PL = PluginLoader('collection')
  assert PL.find_plugin('calico') == None
  assert PL.find_plugin('Calico') == None
  assert PL.find_plugin('calico') == None
  assert PL.find_plugin('Calico') == None
  assert PL.find_plugin('calico') == None
  assert PL.find_plugin('Calico') == None
  assert PL.find_plugin('calico') == None
  assert PL.find_plugin('Calico') == None
  assert PL.find_plugin('calico') == None
  assert PL.find_plugin('Calico') == None
  assert PL.find_plugin('calico') == None
  assert PL.find_plugin('Calico') == None
  assert PL.find_plugin('calico') == None

# Generated at 2022-06-11 15:05:02.619128
# Unit test for function get_shell_plugin
def test_get_shell_plugin():

    # use an explicit shell plugin
    pl = get_shell_plugin(shell_type = 'powershell')

    # use a shell binary as the hint
    pl = get_shell_plugin(executable = '/bin/sh')
    pl = get_shell_plugin(executable = '/bin/bash')
    pl = get_shell_plugin(executable = '/bin/csh')
    pl = get_shell_plugin(executable = '/bin/ksh')
    pl = get_shell_plugin(executable = '/bin/tcsh')
    pl = get_shell_plugin(executable = '/bin/zsh')

    # let the shell plugin guess
    pl = get_shell_plugin()

    # try a bad hint

# Generated at 2022-06-11 15:05:38.533401
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
  jinja2_loader = Jinja2Loader('ansible.plugins.test.test_loader.test_Jinja2Loader_get.ABSENT_PACKAGE', 'ABSENT_CLASS', 'ABSENT_BASE', [])
  assert isinstance(jinja2_loader, PluginLoader)
  if PY2:
    expected = 'No module named ABSENT_PACKAGE'
  else:
    expected = 'No module named \'ABSENT_PACKAGE\''
  pytest.raises(AnsibleError, jinja2_loader.get, 'ABSENT_NAME')
  print('%s OK' % __name__)


# Generated at 2022-06-11 15:05:41.630796
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    p = PluginLoader('foo')

    assert 'foo' in p
    # tests that the __contains__ call to find_pl

# Generated at 2022-06-11 15:05:52.639531
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # create some expected values
    expected_dict = {
        'resolved': True,
        'plugin_resolved_name': 'smile',
        'plugin_resolved_path': '/tmp/somewhere',
        'plugin_resolved_fqcr': 'ansible.plugins.smile',
        'redirect_list': ['smile', 'laugh', 'chuckled']
    }

    # create a fake AnsiblePLuginLoader to use
    class FakePLuginLoader:
        def find_plugin(self, *args, **kwargs):
            return expected_dict['plugin_resolved_name']

        def has_plugin(self, *args, **kwargs):
            return True


# Generated at 2022-06-11 15:06:00.242420
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    class dummy_plugin(object):
        def __init__(self):
            self.option = 'option'

    class DummyPluginLoader(object):
        def find_plugin_with_context(self):
            return get_with_context_result(dummy_plugin(), None)

    plugin = 'test'
    options = {'option': 'option'}
    plugin_loader = DummyPluginLoader()
    plugin_with_context = plugin_loader.get_with_context(plugin, **options)
    assert plugin_with_context.object.option == 'option'

# Generated at 2022-06-11 15:06:04.369469
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    test_paths = ['test_path_1', 'test_path_2', 'test_path_3']

    add_dirs_to_loader('test_loader', test_paths)
    assert test_loader.plugin_paths == test_paths
    assert test_loader.count() == 0


# Generated at 2022-06-11 15:06:12.023930
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import add_dirs_to_loader

    paths = ['/tmp', '/tmp']

    # testing connection plugins
    add_dirs_to_loader('connection', paths)
    loader = getattr(sys.modules[__name__], 'connection_loader')
    assert '/tmp/connection' in loader._get_paths()
    assert '/tmp/connection' in loader._get_paths()

    # testing module_utils plugins
    add_dirs_to_loader('module_utils', paths)
    loader = getattr(sys.modules[__name__], 'module_utils_loader')
    assert '/tmp/module_utils' in loader._get_paths()
    assert '/tmp/module_utils' in loader._get_paths()

# Generated at 2022-06-11 15:06:22.743060
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    '''
    Unit test for method add_directory of class PluginLoader
    '''

    # Create a test PluginLoader object
    plugin_loader = PluginLoader(
        package='test',
        subdir='subdir',
        directories=[],
        class_name='class_name'
    )

    # Call method
    plugin_loader.add_directory('/users/jsmith/.ansible/test/subdir')

    # Check result
    assert plugin_loader._searched_paths == ['/users/jsmith/.ansible/test/subdir']
    assert plugin_loader._paths == ['/users/jsmith/.ansible/test/subdir']
    assert os.path.exists('/users/jsmith/.ansible/test/subdir') is True


# Generated at 2022-06-11 15:06:29.542146
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    """
    Test for function add_dirs_to_loader
    """
    add_dirs_to_loader('action',['./test/units/module_utils/test_utils'])
    shell = get_shell_plugin(shell_type="sh")
    executable = 'ciao'
    shell = get_shell_plugin(shell_type=None, executable=executable)
    executable = None
    shell = get_shell_plugin(shell_type=None, executable=executable)


# Generated at 2022-06-11 15:06:40.381481
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    PluginLoader.clear()
    test_loader = PluginLoader('test_loader', 'Test Module', None, 'fake_load',
                               'fake_path', 'fake_package', 'fake_directories')

    test_loader.add_directory('/root/ansible/test_plugins/')
    my_paths = test_loader._get_paths()
    assert '/root/ansible/test_plugins/test.py' in my_paths
    assert '/root/ansible/test_plugins/test/test.py' in my_paths
    assert '/root/ansible/test_plugins/test.ps1' in my_paths
    assert '/root/ansible/test_plugins/test/test.ps1' in my_paths
    assert '/root/ansible/test_plugins/test.bat' in my

# Generated at 2022-06-11 15:06:46.923681
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    import tempfile
    import shutil
    which_loader = 'shell'
    paths = [tempfile.mkdtemp()]
    os.mkdir(os.path.join(paths[0], which_loader))
    add_dirs_to_loader(which_loader, paths)
    assert os.path.join(paths[0], which_loader) in loader.directories
    shutil.rmtree(paths[0])



# Generated at 2022-06-11 15:07:12.042537
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
  """
  Test for method __contains__ on class PluginLoader
  """
  pl = PluginLoader( '', '', '', '', '', '', None )
  assert pl.__contains__( 'foo' ) == False


# Generated at 2022-06-11 15:07:18.623892
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    if isinstance(__loader__, PluginLoader):
        # unit tests should use default MuckMucks plugin loader
        __loader__ = None

    # Make a temporary directory and put a module inside it
    import tempfile
    from shutil import rmtree
    from ansible.modules.system import MuckMucks

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-11 15:07:27.400223
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    mock_context = Mock(**{
        'resolved': True,
        'plugin_resolved_name': 'plugin_resolved_name',
        'plugin_resolved_path': 'plugin_resolved_path',
        'redirect_list': [],
        'nope.return_value': None
    })
    def load_module_source(x, y):
        return {
            'name': 'name',
            'base_class': None,
            'class_name': 'class_name',
            '_original_path': '_original_path',
            '_load_name': '_load_name',
            '_redirected_names': [],
        }

    # force the find_plugin_with_context mock to always return the mock_context

# Generated at 2022-06-11 15:07:38.739944
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():

    #create a plain vanilla PluginLoadContext object
    plugin_load_context = PluginLoadContext()

    #record a valid warning
    plugin_load_context = plugin_load_context.record_deprecation('z', {'warning_text': 'message warning_text', 'removal_date': '2020-12-31'}, 'from_collection')

    #assert that the plugin_load_context is now marked as deprecated
    assert plugin_load_context.deprecated

    #assert that the plugin_load_context received the expected warning_text
    assert plugin_load_context.deprecation_warnings == ['z has been deprecated. message warning_text']

    #assert that the plugin_load_context received the expected removal_date
    assert plugin_load_context.removal_date == '2020-12-31'

    #assert that the plugin_

# Generated at 2022-06-11 15:07:47.984801
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    """Unit test for method __contains__ of class PluginLoader"""

    class TestPluginLoader(PluginLoader):
        pass

    pl = TestPluginLoader('TestModule', "path")
    pl.aliases = {'name': 'value'}
    pl.package = 'pkg'
    pl.base_class = 'base'
    pl.class_name = 'class'
    pl._searched_paths = []
    pl._module_cache = {}

    # plugin with name exists
    assert pl.has_plugin("name")

    # plugin with name does not exist
    assert not pl.has_plugin("name1")

    # plugin with name not in aliases
    assert not pl.has_plugin("value")



# Generated at 2022-06-11 15:07:58.155973
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    global _PLUGINS_PATHS
    _PLUGINS_PATHS['cache'] = [os.path.join(os.path.dirname(__file__), 'test/unit/test_utils/test_plugins/cache')]
    _PLUGINS_PATHS['callback'] = [os.path.join(os.path.dirname(__file__), 'test/unit/test_utils/test_plugins/callback')]
    _PLUGINS_PATHS['connection'] = [os.path.join(os.path.dirname(__file__), 'test/unit/test_utils/test_plugins/connection')]

# Generated at 2022-06-11 15:08:02.891192
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    test_loader = PluginLoader('', package='', config=dict(), class_name='TestPlugin', base_class='',
                               subdir='subdir')
    test_loader.add_directory(path='path')
    assert(len(test_loader._searched_paths) == 1)


# Generated at 2022-06-11 15:08:10.617864
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    from ansible.utils.display import Display
    old_display = Display()
    plugin_load_context = PluginLoadContext()
    deprecation = {"warning_text": "aaa", "removal_version": "2.11"}
    plugin_load_context.record_deprecation(name="test", deprecation=deprecation, collection_name=None)
    assert plugin_load_context.deprecated == True
    deprecation = {"warning_text": "aaa", "removal_version": "2.11"}
    plugin_load_context.record_deprecation(name="test", deprecation=deprecation, collection_name=None)
    assert plugin_load_context.deprecated == True
    deprecation = {"warning_text": "aaa", "removal_date": "2022-12-31"}


# Generated at 2022-06-11 15:08:20.249399
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")

        context = PluginLoadContext()
        # Empty deprecation dict
        context = context.record_deprecation('plugin_name', {}, 'collection_name')
        assert context.deprecated is False
        assert len(w) is 0
        context = context.record_deprecation('plugin_name', {'warning_text': None, 'removal_date': None, 'removal_version': None}, 'collection_name')
        assert context.deprecated is False
        assert len(w) is 0

        # Not empty deprecation dict

# Generated at 2022-06-11 15:08:31.477383
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # test for #32040
    my_plugin_dir = 'my_plugin_dir'
    for loader_name, loader_obj in get_all_plugin_loaders():
        loader_obj.module_utils_paths.insert(0, my_plugin_dir)
        loader_obj.plugins = dict()
    assert 'my_plugin_dir' in action_loader.module_utils_paths
    assert 'my_plugin_dir' in connection_loader.module_utils_paths
    assert 'my_plugin_dir' in lookup_loader.module_utils_paths
    assert 'my_plugin_dir' in filter_loader.module_utils_paths
    assert 'my_plugin_dir' not in cache_loader.module_utils_paths
    assert 'my_plugin_dir' in test_loader.module_utils

# Generated at 2022-06-11 15:09:08.117708
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    pldr = None
    import ansible.plugins.loader
    for fqcr in AnsibleCollectionRef.fqcr_for_all_plugins():
        if '._init' in fqcr:
            # FIXME: remove this when we remove the BackwardsCompatibilityFileLoader
            continue
        pldr = ansible.plugins.loader._load_collection(fqcr)
        try:
            pldr = pldr.find_plugin(pldr.class_name)
            pldr = pldr.get_with_context(pldr.class_name)
        except Exception as ex:
            if isinstance(ex, AnsibleError):
                raise
            # log and continue, likely an innocuous type/package loading failure in collections import

# Generated at 2022-06-11 15:09:19.871794
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    import ansible.plugins.action.copy, ansible.plugins.action.synchronize
    assert isinstance(PluginLoader("action").all(), types.GeneratorType)
    assert isinstance(PluginLoader("action").all("/tmp"), types.GeneratorType)
    assert isinstance(PluginLoader("action", "CopyModule").all(), types.GeneratorType)
    assert isinstance(PluginLoader("action", "CopyModule").all("/tmp"), types.GeneratorType)
    assert isinstance(PluginLoader("action", "CopyModule").all("/tmp", "/tmp"), types.GeneratorType)
    assert isinstance(PluginLoader("action", "CopyModule").all(path_only=True), types.GeneratorType)

# Generated at 2022-06-11 15:09:30.884107
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # NOTE: Ansible's 'PluginLoader' is an extension of the 'PluginLoaderBase' class.
    # To test the 'PluginLoaderBase.all' method, we will create a PluginLoaderBase
    # object, which will act as an instance of PluginLoader.
    mock_package = "ansible_collections.acme.collection.plugins"
    mock_base_class = 'BaseClass'
    mock_class_name = 'MockClass'
    mock_subdir = 'mock_subdir'
    mock_plugin_dirs = ["/ansible/plugins/mock_subdir/foo", "/ansible/plugins/mock_subdir/bar"]
    mock_aliases = {"alias_one": "real_one", "alias_two": "real_two"}

# Generated at 2022-06-11 15:09:40.159113
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    plugin_loader = PluginLoader(
        package='ansible_collections.my.my_namespace.my_collection.plugins.modules',
        class_name='MyModule',
        directory='.',
        base_class=None
    )
    assert plugin_loader.get_with_context('my_module') is None

    try:
        import ansible_collections.my.my_namespace.my_collection.plugins.modules.my_module
        assert plugin_loader.get_with_context('my_module').object.__class__.__name__ == 'MyModule'

    finally:
        try:
            del sys.modules['ansible_collections.my.my_namespace.my_collection.plugins.modules.my_module']
        except KeyError:
            pass



# Generated at 2022-06-11 15:09:42.694634
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    """
    unit test for add_all_plugin_dirs
    """
    assert get_all_plugin_loaders()



# Generated at 2022-06-11 15:09:50.575400
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    import ansible.plugins
    pc = PluginLoader('cache', 'ansible.plugins.cache', 'BaseCacheModule', required_base_class='CacheModule')
    plc = pc.find_plugin_with_context('lookup', 'lookup')
    assert plc.plugin_resolved_path is not None
    assert plc.resolved
    assert plc.redirect_list is None
    assert plc.missing_collections == []
    assert plc.plugin_resolved_name == 'lookup'

    plc = pc.find_plugin_with_context('lookup', None)
    assert plc.plugin_resolved_path is None
    assert not plc.resolved

    plc = pc.find_plugin_with_context('notfound', 'notfound')
    assert plc.plugin_resolved_

# Generated at 2022-06-11 15:10:01.491398
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    def test_data_factory(data_definitions):
        """
        Returns a test data structure:
            [
                {
                    'description': 'test case description',
                    'plugin_load_context': instance of PluginLoadContext,
                    'name': plugin name to test for,
                    'collection_list': list of collections to test for,
                    'expected_resolved_name': expected resolved name,
                    'expected_resolved_path': expected resolved path,
                    'expected_searched_paths': list of expected searched paths
                },
                ...
            ]
        """
        test_data = []
        no_collections_found = []
        all_collections = []
        for collection_name, collection_path in data_definitions['collections'].items():
            all_collections.append(collection_name)


# Generated at 2022-06-11 15:10:07.757253
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    host = FakeHost()
    add_plugin_dir(
        os.path.join(os.path.dirname(__file__), '..', 'units', 'action_plugins')
    )
    pl = PluginLoader('ActionModule', 'action', C.DEFAULT_ACTION_PLUGIN_PATH)
    assert 'command' in pl
    assert 'commmand' not in pl


# Generated at 2022-06-11 15:10:11.993488
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    """
    Test of PluginLoader.all method
    """
    _from = 'ansible.plugins.action'
    pyl = PluginLoader(_from, 'ActionModule', 'async_wrapper', required_base_class='ActionBase')
    for i in pyl.all():
        assert i.__class__.__name__ != "ActionBase"


# Generated at 2022-06-11 15:10:21.918896
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    import ansible.plugins.loader
    from ansible.plugins.loader import PluginLoader

    test_module_paths = [sys.prefix + '/test/test_plugins']
    test_modules = [
        {
            'fq_name': 'ansible.test_plugins.test_1',
            'spec': {
                'version': (1, 0, 0),
                'namespace': 'ansible.test_plugins'
            }
        },
        {
            'fq_name': 'ansible.test_plugins.test_2',
            'spec': {
                'version': (1, 0, 0),
                'namespace': 'ansible.test_plugins'
            }
        }
    ]


# Generated at 2022-06-11 15:11:04.821295
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    ldr = PluginLoader('cluster', 'ansible.plugins.cluster', 'ClusterModule')
    assert ldr.find_plugin('redhat_lvm')
    # not a cluster module
    assert not ldr.find_plugin('copy')


# Generated at 2022-06-11 15:11:05.795961
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
  pass


# Generated at 2022-06-11 15:11:13.336579
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    module = collections.namedtuple('module', ['module_utils', 'action_loader', 'filter_loader', 'lookup_loader', 'callback_loader', 'connection_loader', 'shell_loader', 'module_loader', 'fragment_loader'])
    # Init namedtuple class module
    module = module(module_utils=None, action_loader=None, filter_loader=None, lookup_loader=None, callback_loader=None, connection_loader=None, shell_loader=None, module_loader=None, fragment_loader=None)
    # Init namedtuple class class_result
    class_result = collections.namedtuple('class_result', ['object', 'resolved', 'redirected'])
    # Init plugin_load_context

# Generated at 2022-06-11 15:11:19.246520
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    import tempfile

    # Create a sample file
    (tmpfd, tmpfname) = tempfile.mkstemp(suffix='.py')
    test_module_1 = 'fq_module.test_module_1'
    test_module_2 = 'fq_module.test_module_2'
    test_module_2_alt = 'other_fq_module.test_module_2'