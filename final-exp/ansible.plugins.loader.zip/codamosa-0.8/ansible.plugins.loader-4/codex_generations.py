

# Generated at 2022-06-11 15:03:00.615042
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    pl = PluginLoader(package='ansible.plugins.testplugin', class_name='TestPlugin', config_base='')
    pl.__setstate__()
    assert pl._module_cache == {}

# Generated at 2022-06-11 15:03:04.971089
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    loader = get_plugin_loader('action')
    assert len(loader.plugin_paths) == 0
    add_all_plugin_dirs('/does/not/exist')
    assert len(loader.plugin_paths) == 0
    add_all_plugin_dirs('')
    assert len(loader.plugin_paths) == 0



# Generated at 2022-06-11 15:03:16.718608
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    ansible_path = '/usr/share/ansible'
    jinja2_loader = Jinja2Loader(ansible_path)

    # Set up mocks
    class MockedJinja2(object):
        def __init__(self):
            self.name = None

        def __call__(self, *args, **kwargs):
            return self

    # Ensure that something that is not a jinja2_plugin is not loaded
    # Set up mock instance
    mocked_jinja2 = MockedJinja2()
    mocked_jinja2.name = 'date_time'
    jinja2_loader._module_cache = {}
    jinja2_loader._module_cache['./test/ansible/plugins/filter/date_time.py'] = mocked_jinja2
    # Call method

# Generated at 2022-06-11 15:03:26.412595
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    import tempfile
    import shutil
    import errno

    def mock_isdir(path):
        return 'isdir' in path

    def mock_isfile(path):
        return 'isfile' in path

    def mock_os_walk(path):
        if 'os.walk' not in path:
            raise OSError(errno.ENOENT, 'No such file or directory')

        dirs = ['ansible.builtin', 'ansible.builtin.isdir']
        for d in dirs:
            if d in path:
                return [(path, [], ['isfile.py'])]
        return []

    def mock_listdir(path):
        return ['dirlist']

    def mock_exists(path):
        return 'doesnotexist' not in path


# Generated at 2022-06-11 15:03:35.147066
# Unit test for function get_shell_plugin
def test_get_shell_plugin():

    # Test that when given shell_type, AnsibleError is raised if shell plugin is not found
    assert get_shell_plugin(shell_type='this_shell_type_does_not_exist')
    # Test that AnsibleError is raised when shell_type is not given and executable is not provided
    assert get_shell_plugin()

    # Test that executable is set when provided one
    executable = 'test_exec'
    shell = get_shell_plugin(shell_type='test_shell', executable=executable)
    assert shell.executable == executable

    # Test that shell_type is set with the one that is compatible with the provided executable
    executable = '/usr/bin/bash'
    shell_type = 'sh'
    shell = get_shell_plugin(executable=executable)
    assert shell.SHELL_FAMILY == shell_

# Generated at 2022-06-11 15:03:40.610811
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    from ansible.plugins.filter.timestamp import timestamp
    test_paths = [os.path.dirname(timestamp.__file__)]
    add_dirs_to_loader('filter', test_paths)
    plugin = filter_loader.get('timestamp')
    assert plugin.__name__ == 'timestamp'
    assert plugin.__file__ == timestamp.__file__



# Generated at 2022-06-11 15:03:48.569648
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():

    with pytest.raises(AnsibleError) as e:
        # test non-existent path
        PluginLoader('foo.bar').add_directory('/path/does/not/exist')
    assert e.value.message == 'Could not find plugins directory /path/does/not/exist'

    with pytest.raises(AnsibleError) as e:
        # test not a directory
        PluginLoader('foo.bar').add_directory('/dev/random')
    assert e.value.message == 'Could not find plugins directory /dev/random'

    with pytest.raises(AnsibleError) as e:
        # test path for directory that is too long
        PluginLoader('foo.bar').add_directory('/'+('a'*200)+'/')

# Generated at 2022-06-11 15:04:00.331472
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    from ansible.utils.collection_loader import _get_collection_metadata
    test_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    test_dir = os.path.join(test_dir, 'test', 'units', 'lib', 'ansible_test_mock_collections', 'mazer_library')
    add_dirs_to_loader('module', [test_dir])
    assert module_loader.has_plugin('mazer_library.test_playbook')
    assert not module_loader.has_plugin('mazer_library')
    col_name, col_version = _get_collection_metadata(test_dir)
    collection_ref = AnsibleCollectionRef.create(col_name, col_version)

# Generated at 2022-06-11 15:04:09.446642
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    """Test if add_dirs_to_loader adds files in a directory to the appropriate loader
    """
    paths = [
        '/path/to/fake',
        '/path/to/also/fake'
        ]
    which_loader = 'connection'
    # Assert that the connection_loader has no paths defined
    for path in getattr(sys.modules[__name__], which_loader + '_loader')._directories:
        assert False
    add_dirs_to_loader(which_loader, paths)
    # Assert that the connection_loader has two paths defined now
    i = 0
    for path in getattr(sys.modules[__name__], which_loader + '_loader')._directories:
        i += 1
    assert i == 2



# Generated at 2022-06-11 15:04:13.246211
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    test_path = '../lib/ansible/plugins/action/'
    add_all_plugin_dirs(test_path)
    assert ActionModuleLoader.get_directory_dictionary() == [test_path]


# Generated at 2022-06-11 15:04:43.603312
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    def test_return_true():
        _loader = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action')
        _loader.aliases = dict()

        _loader.find_plugin = MagicMock(return_value=2)

        assert 'a' in _loader

    def test_return_false():
        _loader = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action')
        _loader.aliases = dict()

        _loader.find_plugin = MagicMock(return_value=None)

        assert 'b' not in _loader

    test_data = [test_return_true, test_return_false]
    for t in test_data:
        t()


# Generated at 2022-06-11 15:04:51.627053
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.module_utils.common.collections import AnsibleCollectionRef

    # TODO: convert this into a proper unit test
    def find_plugin_with_context(self, name, plugin_load_context, collection_list=None):
        plugin_load_context.name = name
        plugin_load_context.resolved = True
        plugin_load_context.plugin_resolved_name = name
        plugin_load_context.plugin_resolved_path = os.path.join(os.path.dirname(__file__), 'data', name)
        plugin_load_context.redirect_list = []
        return plugin_load_context


# Generated at 2022-06-11 15:05:02.558620
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    path = "/home/shiyanlou/ansible/lib/ansible/plugins/action"
    suffix = ""
    name = "debug"
    class_name = "ActionModule"
    package = "ansible.plugins.action"
    base_class = "ActionBase"
    aliases = {'debugme': 'debug', 'debugger': 'debug'}
    subdir = "action"
    aliases = {'debugme': 'debug', 'debugger': 'debug'}
    subdir = "action"
    class PluginLoader(PluginLoader):
        def _load_module_source(self, name, path):
            if name.startswith('ansible_collections.'):
                full_name = name
            else:
                full_name = '.'.join([self.package, name])

# Generated at 2022-06-11 15:05:09.969791
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    pl = PluginLoader('ansible.plugins.action', 'ActionModule', 'ansible.plugins.action.ActionModule')
    pl.list_classes_with_context()
    pl.list_classes_with_context()
    pl.get_with_context('ping')
    pl.get_with_context('ping')
    pl.get_with_context('ping')
    pl.get_with_context('ping')
    pl.get_with_context('ping', class_only=True)
    pl.get_with_context('ping', class_only=True)
    pl.get_with_context('ping', class_only=True)
    pl.get_with_context('ping', class_only=True)
    pl.get_with_context('ping', collection_list=['Test'])
    pl.get_with

# Generated at 2022-06-11 15:05:21.162437
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    runner = RunnerMock()
    options = MagicMock()
    options.connection = None
    options.become = None
    options.become_method = None
    options.become_user = None
    options.diff = None
    options.check = None
    options.inventory = None
    options.module_path = None
    options.module_paths = None
    options.remote_user = None
    options.other_vars = {}
    options.subset = None
    options.vault_ids = None
    options.vault_password_files = None
    options.vault_password = None
    options.ask_pass = None
    options.private_key_file = None
    options.force_handlers = False
    options.flush_cache = None
    options.listhosts = None
   

# Generated at 2022-06-11 15:05:29.103025
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Test method PluginLoader::__setstate__.
    '''
    loader = PluginLoader(
        'Test',
        'ansible.plugins.test',
        'TestPlugin',
        'TestClass',
        C.DEFAULT_INTERNAL_PLUGIN_PATH,
        'test_plugins',
        required_base_class='ansible.plugins.test.TestBaseClass'
    )

    if sys.version_info >= (3, 4, 0):
        loader.set_class_loader(importlib.util.find_spec("test_sample_class"))
    else:
        loader.set_class_loader("test_sample_class")

    # We do not test that the output of the method matches our expectation
    # since the method is only used to pickle/unpickle the object
    # we test

# Generated at 2022-06-11 15:05:34.849775
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    import tempfile

    # Set up a temporary directory
    tmpdir = tempfile.mkdtemp()
    test_dir = os.path.join(tmpdir, 'test')
    os.makedirs(test_dir)


# Generated at 2022-06-11 15:05:36.043764
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    pytest.skip("plugin_loader is an internal class, so it does not have unit tests")


# Generated at 2022-06-11 15:05:45.945183
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert get_shell_plugin(shell_type="sh")
    assert get_shell_plugin(shell_type="sh", executable="/bin/sh")
    assert get_shell_plugin(shell_type="sh", executable="/bin/bash")
    assert get_shell_plugin(shell_type="csh")
    assert get_shell_plugin(shell_type="csh", executable="/bin/csh")
    assert get_shell_plugin(shell_type="csh", executable="/bin/tcsh")
    assert get_shell_plugin(shell_type="ps")
    assert get_shell_plugin(shell_type="ps", executable="/bin/ps")
    assert get_shell_plugin(shell_type="ps", executable="/usr/bin/powershell.exe")


# Generated at 2022-06-11 15:05:57.041881
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    loader = PluginLoader("test")
    state = (loader._package, loader._pseudo_package, loader._suffix, loader._paths, loader._aliases, loader._class_name, loader._subdir, loader._base_class, loader._module_cache, loader.package_errors)
    loader.__setstate__(state)
    assert loader._package == "test"
    assert loader._pseudo_package == ""
    assert loader._suffix == "py"
    assert loader._paths == []
    assert loader._aliases == {}
    assert loader._class_name == ""
    assert loader._subdir == ""
    assert loader._base_class == ""
    assert loader._module_cache == {}
    assert loader.package_errors == set()
    assert loader.package == "test"



# Generated at 2022-06-11 15:06:19.838670
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # TODO
    pass

# Generated at 2022-06-11 15:06:22.783249
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    instance = Jinja2Loader('ansible.plugins.filter', 'FilterModule', 'filter_plugins', config_def_class='FilterModule')
    assert instance.get('to_json') == None


# Generated at 2022-06-11 15:06:33.498497
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():

    import pytest
    import unittest
    from ansible.plugin.loader import Jinja2Loader

    class TestJinja2Loader(unittest.TestCase):
        """ ansible.plugin.loader.Jinja2Loader """

        def test_all(self):
            # NOTE: this is not a full test of 'all', it only checks the parts
            # that are overridden by Jinja2Loader

            # NOTE: This only tests 'ansible.legacy' plugin paths.  Files from collections
            # are not tested with this method.

            # We test the Jinja2Loader because it does not get tested as a part of the PluginLoader tests

            import sys
            import glob
            import os

            class DummyModule(object):
                def __init__(self, *args, **kwargs):
                    if args:
                        dir

# Generated at 2022-06-11 15:06:45.137701
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    class FakePluginLoader():
        subdir = 'test'

        @staticmethod
        def add_directory(_):
            return True

    PLUGIN_PATH_CACHE.clear()
    old_pld_path = PluginLoader.add_directory
    old_plugin_loaders = globals()['get_all_plugin_loaders']

    def test_get_all_plugin_loaders():
        return [(FakePluginLoader.subdir, FakePluginLoader())]


# Generated at 2022-06-11 15:06:46.142288
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    assert False, "Not implemented"


# Generated at 2022-06-11 15:06:57.848503
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.plugins.loader import PluginLoader
    from ansible.utils import context_objects as co

    runner_path = '/usr/lib/python2.7/site-packages/ansible/runner/cache_plugins'
    action_path = '/usr/lib/python2.7/site-packages/ansible/runner/action_plugins'
    callback_path = '/usr/lib/python2.7/site-packages/ansible/runner/callback_plugins'
    connection_path = '/usr/lib/python2.7/site-packages/ansible/runner/connection_plugins'
    lookup_path = '/usr/lib/python2.7/site-packages/ansible/runner/lookup_plugins'
    shell_path = '/usr/lib/python2.7/site-packages/ansible/runner/shell_plugins'

# Generated at 2022-06-11 15:07:07.675074
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    pass

    ## PluginLoader
    # Tests for class PluginLoader in module ansible.plugins.loader
    ##

    ##
    ## Subclass of unittest.TestCase for testing
    ###

    class TestCase_PluginLoader(unittest.TestCase):
        def test_ratchet_aliases(self):
            self.assertTrue(False, 'This test needs an actual implementation')

        def test_cleanup_tmp_file(self):
            self.assertTrue(False, 'This test needs an actual implementation')

        def test_filter_paths_and_files(self):
            self.assertTrue(False, 'This test needs an actual implementation')

        def test_format_paths(self):
            self.assertTrue(False, 'This test needs an actual implementation')

        def test_has_plugin(self):
            self

# Generated at 2022-06-11 15:07:16.605730
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    from UnitTest import AnsiblePluginTestSuite
    from UnitTest import AnsiblePluginTestCase
    from collections import namedtuple
    class_name = 'MyPlugin'
    package = 'mypackage'
    suffix = '.py'
    config_defs = dict()
    base_class = namedtuple('base_class', 'class_name')

    class TestPluginLoader(PluginLoader):
        class_name = class_name
        package = package
        suffix = suffix
        config_defs = config_defs
        base_class = base_class
    loader = TestPluginLoader()

    name = 'my_plugin'
    collection_list = None
    class_only = False
    path = '/my/path'
    suffix = '.py'

# Generated at 2022-06-11 15:07:26.489409
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    PLUGIN_PATH_CACHE.clear()
    import shutil
    from tempfile import mkdtemp

# Generated at 2022-06-11 15:07:32.886826
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Test if method __setstate__ of class PluginLoader works as expected
    '''
    # Create an object of PluginLoader class for testing
    plugin_loader = PluginLoader(None, None, None, None)
    # Test if attribute 'aliases' of class PluginLoader is set as expected
    assert plugin_loader.aliases == {u'module': u'action'}



# Generated at 2022-06-11 15:08:20.588534
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    target = PluginLoader('TestPluginLoader') # ensure initialized
    # Testing with target and args
    # args: (name, module_manager)
    # expected: None
    target.__setstate__('foo', [object()])
    # Testing with target and args
    # args: (name, module_manager)
    # expected: None
    target.__setstate__('foo', [object()])
    # Testing with target and args
    # args: (name, module_manager)
    # expected: None
    target.__setstate__('foo', [object()])


# Generated at 2022-06-11 15:08:31.860897
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    from ansible.plugins.action import ActionBase
    from ansible.playbook.play_context import PlayContext
    import ansible.plugins.loader as plugins
    from ansible.plugins.action.normal import ActionModule
    import ansible.inventory.host

    class TestedClass():
        def __init__(self, name):
            self.name = name

    inventory = ansible.inventory.host.Host('test')
    play_context = PlayContext()
    loader = plugins.action_loader

    test_case = TestedClass("test_name")


    loader_res = loader.get_with_context("test_name", inventory=inventory, play_context=play_context)


# Generated at 2022-06-11 15:08:41.544598
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    collection = _COLLECTION_TEST
    plugin_name = 'my_test_plugin'

    # Test find_plugin_with_context
    loader = PluginLoader('action_plugins', 'ActionModule', collection_list=[collection.local_dir])
    if not loader.find_plugin(plugin_name, collection_list=[collection.local_dir]):
        raise AssertionError('Error finding plugin: {0}'.format(plugin_name))

    # Test get_with_context
    collection = CollectionRequirement(collection.name)
    loader = PluginLoader('action_plugins', 'ActionModule', collection_list=[collection])
    get_with_context_result = loader.get_with_context(plugin_name, collection_list=[collection])
    plugin_load_context = get_with_context_result.plugin_load_context
   

# Generated at 2022-06-11 15:08:49.272738
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    path = os.path.abspath(os.path.join(__file__, '../../../lib/ansible'))
    add_all_plugin_dirs(path)
    assert 'action' in PATH_CACHE
    assert 'cache' in PATH_CACHE
    assert 'filter' in PATH_CACHE
    assert 'lookup' in PATH_CACHE
    assert 'module_utils' in PATH_CACHE
    assert 'shell' in PATH_CACHE
    assert 'terminal' in PATH_CACHE
    assert 'vars' in PATH_CACHE
    assert 'become' in PATH_CACHE
    assert 'connection' in PATH_CACHE
    assert 'inventory' in PATH_CACHE
    assert 'callback' in PATH_CACHE



# Generated at 2022-06-11 15:08:55.231913
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    loader = PluginLoader('test_package', 'test_path', 'test_class_name')
    state = {"package": "test_package", "path": "test_path", "class_name": "test_class_name"}
    loader.__setstate__(state)
    assert loader.package == state['package']
    assert loader.path == state['path']
    assert loader.class_name == state['class_name']


# Generated at 2022-06-11 15:09:07.271465
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    import os
    import sys
    import glob
    import logging
    import shutil
    import tempfile

    from ansible import constants as C

    # Logger
    logger = logging.getLogger('TestPluginLoader_all')

    # Setup paths and init class
    tmpdir = tempfile.mkdtemp()
    test_dir = '%s/' % tmpdir
    sys.path.insert(0, test_dir)
    plugin_dir = '%s/%s' % (tmpdir, 'plugins')

    os.mkdir(plugin_dir)
    C.DEFAULT_LOAD_CALLBACK_PLUGINS = True
    cls = PluginLoader('callback', 'CallbackModule', C.DEFAULT_CALLBACK_PLUGIN_PATH, '_', required_base_class='CallBackBase')
    dummy_

# Generated at 2022-06-11 15:09:14.804958
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.errors import AnsibleError
    import glob
    import os
    import os.path
    import sys
    import textwrap
    from ansible.module_utils.six import PY3
    from ansible.plugins import connection_loader

    if not PY3:
        raise Exception('Tests require Python 3')

    try:
        import importlib.util
        spec = importlib.util.find_spec('ansible.plugins.connection.local')
        local_path = spec.origin
    except ImportError:
        local_path = None

    def test_gen():
        yield 'test_plugin_1'
        yield 'test_plugin_2'
        yield 'test_plugin_3'

    # Setup inventory plugin path

# Generated at 2022-06-11 15:09:22.777858
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    from ansible.utils.vars import combine_vars

    ##################################################
    # PluginLoader.__setstate__: direct assignment

    PL = PluginLoader('foo')

    # 'modules' : {'module.path':'module.object'}
    PL._module_cache = {'module.path':'module.object'}
    # 'package' : 'foo'
    PL.package = 'foo'
    # 'paths' : 'path'
    PL._searched_paths = 'path'
    # 'aliases' : {'alias':'name'}
    PL.aliases = {'alias':'name'}
    # 'class_name' : 'name'
    PL.class_name = 'name'
    # 'base_class' : 'name'

# Generated at 2022-06-11 15:09:24.252214
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    assert add_all_plugin_dirs('/foo/bar') == None



# Generated at 2022-06-11 15:09:33.250505
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    mock_name = MagicMock(name='name')
    mock_collection_list = MagicMock(name='collection_list')
    mock_has_plugin = MagicMock(name='has_plugin')

    test_obj = PluginLoader()
    test_obj.has_plugin = mock_has_plugin

    test_obj.__contains__(mock_name, collection_list=mock_collection_list)

    mock_has_plugin.assert_called_once_with(mock_name, collection_list=mock_collection_list)