

# Generated at 2022-06-11 15:03:27.851349
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    func = lambda file_path: "mocked"
    with pytest.raises(AnsibleError):
        PluginLoader('./', 'mocked', config=None, package='mocked', directories=('mocked',), name_priorities={})._PluginLoader__setstate__(file_path=func)

# Generated at 2022-06-11 15:03:32.255528
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    loader = PluginLoader('', '', '')
    with patch.object(loader, '_get_paths'):

        with pytest.raises(AnsibleError) as excinfo:
            loader.__setstate__({})
        assert 'Not supported to load a PluginLoader from a pickled state' in to_text(excinfo.value)

# Generated at 2022-06-11 15:03:39.720197
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    p = PluginLoader('foo', 'bar', 'baz')
    test_list = ['/foo/bar/baz/playbook_plugins/a.py', '/foo/bar/baz/playbook_plugins/b.py', '/foo/bar/baz/playbook_plugins/c.py']
    real_glob = glob.glob
    def mockReturn(x):
        return test_list

    glob.glob = mockReturn

    t = p.all('dummy')
    assert next(t) == '/foo/bar/baz/playbook_plugins/a.py'
    assert next(t) == '/foo/bar/baz/playbook_plugins/b.py'
    assert next(t) == '/foo/bar/baz/playbook_plugins/c.py'

    glob.glob

# Generated at 2022-06-11 15:03:40.401076
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    pass

# Generated at 2022-06-11 15:03:48.446653
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Set up a fake dir to test with
    import tempfile
    import shutil
    import ansible.constants as constants
    old_plugin_path = constants.DEFAULT_PLUGIN_PATH

    test_plugin_dir = tempfile.mkdtemp()
    for subdir in [x for x in constants.DEFAULT_PLUGIN_PATH if os.path.isdir(x)]:
        os.makedirs(os.path.join(test_plugin_dir, subdir))

    constants.DEFAULT_PLUGIN_PATH = [test_plugin_dir]
    add_all_plugin_dirs(test_plugin_dir)

    # Make sure we added the plugin dirs

# Generated at 2022-06-11 15:03:53.243572
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    obj = PluginLoader('test')
    obj.__setstate__({'test': 1})
    assert obj.__dict__ == {'test': 1}


# Generated at 2022-06-11 15:03:57.097623
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    PL = ansible_collections.ansible.builtin.plugins.module_utils.modules.PluginLoader
    assert True is PL.__setstate__({'package': 'ansible.builtin.modules'})


# Generated at 2022-06-11 15:04:02.659987
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert (get_shell_plugin(shell_type='sh') is not None)
    assert (get_shell_plugin(shell_type='sh', executable='/bin/sh') is not None)
    assert (get_shell_plugin(executable='/bin/bash') is not None)
    try:
        get_shell_plugin()
        assert False
    except AnsibleError:
        assert True


# Generated at 2022-06-11 15:04:13.312748
# Unit test for method all of class PluginLoader

# Generated at 2022-06-11 15:04:16.116302
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    args = dict()
    args['package'] = 'filter_plugins'
    pl = PluginLoader(**args)
    return pl


# Generated at 2022-06-11 15:04:56.664674
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    # Test function of method __setstate__
    pass # Tests not yet written


# Generated at 2022-06-11 15:05:07.014586
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    # Init a pluginloader obj
    #
    # Ensure that PluginLoader.__setstate__() properly handles being
    # passed 'None' for the 'self' parameter and does not cause a
    # 'TypeError: expected string or bytes-like object'
    #
    # Create an empty dict for setstate()
    setstate_dict = {}

    # Make a copy of the class's __dict__
    setstate_dict['__dict__'] = save_dict = PluginLoader.__dict__.copy()

    # Set the 'self' object to 'None'
    setstate_dict['self'] = None

    # Now attempt to call __setstate__ on a PluginLoader class object
    # and ensure that a 'TypeError: expected string or bytes-like object'
    # is not thrown

# Generated at 2022-06-11 15:05:12.423422
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():

    # Check for 'ansible.legacy' prefix
    assert Jinja2Loader.find_plugin('ansible.legacy.filter.x') == 'x'
    assert Jinja2Loader.find_plugin('ansible.legacy.filter.x', collection_list='') == 'x'

    # Check for 'ansible.legacy' prefix with 'ansible.legacy' collection_list
    assert Jinja2Loader.find_plugin('ansible.legacy.filter.x', collection_list='ansible.legacy') == 'x'
    assert Jinja2Loader.find_plugin('ansible.legacy.filter.x', collection_list='ansible.legacy') == 'x'

    # Check for 'ansible.legacy' prefix with 'ansible.legacy' collection_list
    assert Jinja2Loader.find

# Generated at 2022-06-11 15:05:19.452562
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # Test with empty paths
    add_dirs_to_loader('shell', [])
    add_dirs_to_loader('action', [])
    add_dirs_to_loader('lookup', [])

    # Test with non existing path
    add_dirs_to_loader('shell', ('/path/does/not/exists',))
    add_dirs_to_loader('action', ('/path/does/not/exists',))
    add_dirs_to_loader('lookup', ('/path/does/not/exists',))

    # Test with simple directory
    add_dirs_to_loader('shell', ('/bin',))
    add_dirs_to_loader('action', ('/bin',))
    add_dirs_to_loader('lookup', ('/bin',))



# Generated at 2022-06-11 15:05:28.238388
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # ---
    # Return type
    # ---
    PLUGIN_LOADER_ARGS = dict(
        class_name='TestClass',
        package='package_name',
        subdir='test/'
    )
    plugin_loader = PluginLoader(**PLUGIN_LOADER_ARGS)

    # test a load that returns a valid plugin
    plugin_load_context = mock.MagicMock()
    plugin_load_context.resolved = True
    plugin_load_context.plugin_resolved_path = 'path/to/plugin.py'
    plugin_load_context.plugin_resolved_name = 'test_name'
    plugin_load_context.plugin_module = mock.MagicMock()
    plugin_load_context.plugin_class = mock.MagicMock()

# Generated at 2022-06-11 15:05:38.562906
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    host = 'localhost'
    connection = 'smart'
    port = 22
    user = 'testuser'
    key_file = '/test/path/file'
    password = 'password'
    classobj = 'autoadapt'
    fork = 'yes'
    timeout = '5'
    mkdir = True
    remote_tmp = '$HOME/.ansible/tmp'
    module_name = 'setup'
    config_name = 'ansible'
    config_extension = 'cfg'
    config_path = '/test/path/file'
    plugin_type = 'vars'
    create_file = False
    create_dir = False
    module_path = '$HOME/.ansible/modules/core'
    module_name = 'ping'
    module_classname = 'ping'


# Generated at 2022-06-11 15:05:47.905482
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    plc = PluginLoadContext()
    assert not plc.deprecated
    assert plc.removal_date is None
    assert plc.removal_version is None
    assert not plc.deprecation_warnings

    plc2 = plc.record_deprecation("foo", {"warning_text": "this is deprecated",
                                          "removal_date": "2.12"}, None)
    assert plc2 is plc
    assert plc.deprecated
    assert plc.removal_date == "2.12"
    assert plc.removal_version is None
    assert plc.deprecation_warnings == ["foo has been deprecated. this is deprecated"]


# Generated at 2022-06-11 15:05:59.061589
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    """
    Unit test for method all of class Jinja2Loader

    No collection - basic
    No collection - with path
    No collection - with one base and one collection path
    With collection - basic
    With collection - with path
    With collection - with one base and one collection path
    """

    # Setup for all tests
    test_dir = os.path.dirname(os.path.abspath(__file__))
    collection_dir = os.path.join(test_dir, 'fixtures', 'ansible_collections', 'my_namespace', 'test_collection')

    # Set some paths to test with
    #   * Basic path - only ansible legacy
    #   * Basic path - with collection path
    #   * Both paths - with ansible legacy and collection path

# Generated at 2022-06-11 15:06:08.577113
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    # PluginLoader.__setstate__(state)

    pl = PluginLoader(package='ansible.plugins.test', class_name='TestPlugin')
    assert isinstance(pl, PluginLoader)
    assert pl.package == 'ansible.plugins.test'
    assert pl.class_name == 'TestPlugin'
    assert pl.base_class is None
    assert pl.subdir is None
    assert pl._package_path is None
    assert pl.paths is None
    assert pl.CONFIG_CACHE_LOCK is None
    assert pl.CONFIG_CACHE is None
    assert pl._searched_paths is None
    assert pl._module_cache is None
    assert pl._config_cache is None
    assert pl._extra_dirs is None
    assert pl.aliases is None
    assert pl.col

# Generated at 2022-06-11 15:06:18.991781
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    from ansible.plugins.shell import ShellBase
    assert get_shell_plugin(shell_type='cmd') is not None, \
        "Could not find the shell plugin required (cmd)."
    assert get_shell_plugin(shell_type='cmd').SHELL_FAMILY == 'cmd'
    assert get_shell_plugin(shell_type='sh').SHELL_FAMILY == 'sh'
    assert get_shell_plugin(shell_type='powershell').SHELL_FAMILY == 'powershell'
    shell_plugin = get_shell_plugin(shell_type='cmd')
    assert issubclass(shell_plugin, ShellBase)
    shell_plugin = get_shell_plugin(shell_type='sh')
    assert issubclass(shell_plugin, ShellBase)

# Generated at 2022-06-11 15:07:28.099315
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    from ansible.plugins.loader import test_plugins
    test_plugins_path = os.path.dirname(test_plugins.__file__)
    os.environ['ANSIBLE_REMOVE_EXPIRED_RESOURCES'] = 'False'

# Generated at 2022-06-11 15:07:30.921930
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    loader = PluginLoader('ansible.plugins.action', 'ActionModule')
    assert ('ping' in loader) is True


# Generated at 2022-06-11 15:07:37.078064
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    from ansible.errors import AnsibleError
    args = []
    kwargs = {"_dedupe": False}
    loader = Jinja2Loader("legacy_plugin_name", "legacy_plugin_path", ["collection_plugin_paths"])
    with pytest.raises(AnsibleError):
        loader.get('name', *args, **kwargs)


# Generated at 2022-06-11 15:07:44.866460
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    PLUGIN_PATH_CACHE.clear()
    assert not PLUGIN_PATH_CACHE.keys()  # The cached plugin paths are cleared before test
    all_plugin_loaders = get_all_plugin_loaders()
    for key, val in all_plugin_loaders:
        val.add_directory('/dev/null')
    add_all_plugin_dirs('/dev/null')
    for key, val in all_plugin_loaders:
        assert len(val.directories) == 2



# Generated at 2022-06-11 15:07:54.772381
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    def return_object_mock(cls, path):
        return path

    ansible_mock = Mock(return_value='ansible')
    jinja2_mock = Mock(return_value='jinja')
    object_mock = Mock(return_value=return_object_mock)
    class_mock = Mock(return_value=jinja2_mock)
    module_mock = Mock(return_value=object_mock)
    get_directory_mock = Mock(return_value='/path/to/ansible')
    plugin_loader_mock = Mock(spec_set=['_get_paths'], _get_paths=get_directory_mock)

    # Using a with statement to make this test more isolated, we really don't care if the plugin loader
    # looks at

# Generated at 2022-06-11 15:08:02.416782
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    """
    Tests get_shell_plugin function with normal invocation

    :return:
    """
    # find the plugin with no args, should default to sh
    plugin = get_shell_plugin()
    assert plugin.do_transform_command('pwd') == 'pwd'

    # find the plugin with shell_type arg, should use csh
    plugin = get_shell_plugin(shell_type='csh')
    assert plugin.do_transform_command('pwd') == 'pwd'

    # try to find a shell plugin that doesn't exist
    # should throw an Exception
    try:
        plugin = get_shell_plugin(shell_type='unknown_shell')
        assert test_get_shell_plugin
    except Exception:
        pass

    # find the plugin with executable arg using sh,
    # should be able to find the plugin

# Generated at 2022-06-11 15:08:07.319260
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    a = PluginLoader()
    assert a._get_paths() == []
    a.add_directory("plugins/action")
    assert a._get_paths() == ["plugins/action"]
    a.add_directory("plugins/become")
    assert a._get_paths() == ["plugins/action", "plugins/become"]

# Generated at 2022-06-11 15:08:17.644350
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    from collections import namedtuple
    import copy
    import imp
    import os
    import sys
    import tempfile
    import types
    from ansible.utils.path import unfrackpath
    from ansible.compat.tests import unittest

    if imp is None:
        import importlib.util
        import importlib.machinery

    def _get_default_executor_path():
        module_name = 'ansible.executor.executor'
        module_spec = importlib.util.find_spec(module_name)
        module_path = module_spec.loader.get_filename()
        assert module_path.endswith('.py')
        return os.path.dirname(module_path)

    def _create_module(module_name, module_code):
        assert not '.' in module_

# Generated at 2022-06-11 15:08:28.799109
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    from ansible.utils._text import to_bytes

    # PY2+PY3
    if sys.version_info[0] == 2:
        reload(sys)
        sys.setdefaultencoding('utf8')

    def get_instance(obj, *args, **kwargs):
        """ Jinja2 plugins do not use __init__ """
        return obj

    class Jinja2Plugin(object):
        pass

    class FakeModuleCache(object):
        def __init__(self):
            self.called = []
            self.current_obj = None

        def clear(self):
            self.called = []
            self.current_obj = None

        def update(self, obj):
            self.called.append(obj)
            self.current_obj = obj


# Generated at 2022-06-11 15:08:37.289679
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    debug_output = list()
    def fake_display_debug(msg):
        debug_output.append(msg)

    # 1. for invalid 'package'
    pl = PluginLoader('invalid_package', '.', 'invalid_class', 'invalid_base_class', 'invalid_prefix')
    plugin_load_context = pl.find_plugin_with_context('name')
    assert plugin_load_context.failed
    assert plugin_load_context.path is None
    assert plugin_load_context.name is None
    assert 'package invalid_package cannot be found' in plugin_load_context.exception

    # 2. for valid 'package', existing and non-existing plugin
    pl = PluginLoader('module_utils', '.', 'invalid_class', 'invalid_base_class', 'invalid_prefix')


# Generated at 2022-06-11 15:09:07.768562
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():

    import ansible.module_utils.six as six
    from ansible.utils.vars import combine_vars

    # FIXME: other plugin types would be better tested here for broader coverage
    pl = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action', subdir='action_plugins', aliases={}, required_base_class='ActionBase' )

    assert pl.find_plugin('copy') == 'ansible.plugins.action.copy'

    # aliases
    assert pl.find_plugin('copy') == 'ansible.plugins.action.copy'
    pl.aliases = { 'copy': 'copy2' }
    assert pl.find_plugin('copy') == 'ansible.plugins.action.copy2'

    # not found
    assert pl.find_plugin('foo') is None

    # reference to plugin outside

# Generated at 2022-06-11 15:09:08.849323
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    pass

# Generated at 2022-06-11 15:09:10.072653
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    loader = Jinja2Loader()


# Generated at 2022-06-11 15:09:21.014592
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    '''
    Unit test for method get_with_context of class PluginLoader
    '''
    def assert_get_with_context_result_contents(result, expected_object, expected_return_value, expected_resolved, expected_plugin_resolved_name, expected_plugin_resolved_path):
        assert result.object == expected_object
        assert result.return_value == expected_return_value
        assert result.resolved == expected_resolved
        assert result.plugin_resolved_name == expected_plugin_resolved_name
        assert result.plugin_resolved_path == expected_plugin_resolved_path


# Generated at 2022-06-11 15:09:33.056268
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.template import Templar
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.utils.plugin_docs import get_docstring
    from ansible.parsing.plugin_docs import read_docsting

    # default verbosity is 3 for unit tests, we bump it up to 4 for the plugin loader to display the plugin loading info
    C.verbosity = 4

    # Monkey patch the stringc function to avoid the colorization
    stringc_org = stringc
    stringc = lambda x, **kwargs: x


# Generated at 2022-06-11 15:09:36.672665
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    loader = PluginLoader('callback_plugins', 'callback_plugins')
    context = loader.find_plugin_with_context('foo')
    assert not context.resolved
    context = loader.find_plugin_with_context('bar')
    assert not context.resolved



# Generated at 2022-06-11 15:09:42.407416
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    plugin_loader = PluginLoader()

    # Try nonexistent plugin
    nonexistent_plugin = 'whatever'
    assert nonexistent_plugin not in plugin_loader

    # Try existing plugin
    existing_plugin = 'setup'
    assert existing_plugin in plugin_loader

    # Try plugin from collection
    collection_plugin = 'mycollection.mymodule.myplugin'
    assert collection_plugin in plugin_loader



# Generated at 2022-06-11 15:09:50.439329
# Unit test for method get_with_context of class PluginLoader

# Generated at 2022-06-11 15:10:00.229814
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    cl = PluginLoader('/tmp/c', 'c.C', 'c', 'c')
    cl._searched_paths = ['/tmp/c']
    def load_plugin(name):
        if name == 'C':
            return 'c.C'
        return None
    cl.load_plugin = load_plugin
    obj, context = cl.get_with_context('C')
    assert context.resolved
    assert context.plugin_resolved_name == 'C'
    assert context.plugin_resolved_path == '/tmp/c'
    assert context.redirect_list == []
    assert context.reason == ''
    assert obj == 'c.C'


# Generated at 2022-06-11 15:10:05.454245
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    test_context = PluginLoadContext()
    test_context.original_name = 'this_is_the_great_test_context'
    assert 'this_is_the_great_test_context' == test_context.original_name

    test_context.record_deprecation('foo', {'warning_text': None}, None)
    assert 'foo has been deprecated.' == test_context.deprecation_warnings[0]

    test_context.record_deprecation('foo', {'warning_text': 'bar'}, None)
    assert 'foo has been deprecated. bar' == test_context.deprecation_warnings[1]

    test_context.record_deprecation('foo', {'removal_version': 'bar'}, None)
    assert 'foo has been deprecated. Removal of this feature is scheduled for bar'

# Generated at 2022-06-11 15:10:42.114130
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    x = PluginLoader.__contains__()
    assert x == None, "Return value of PluginLoader.__contains__() is not correct"

# Generated at 2022-06-11 15:10:49.074767
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    for plugin_type, plugin_loader in get_all_plugin_loaders():
       # Reset plugin lists
       plugin_loader.clear()
    # Add all the plugin subdirs function
    add_all_plugin_dirs('/tmp/path')
    for plugin_type, plugin_loader in get_all_plugin_loaders():
       assert plugin_loader.paths == []
    # Create a test dir
    os.mkdir('/tmp/path/one')
    # Create one plugin subdir
    os.mkdir(os.path.join('/tmp/path', 'cache'))
    # Test if plugin subdirs with path 'one' is not added to plugin_loader
    add_all_plugin_dirs('/tmp/path')
    assert PATH_CACHE.paths == ['/tmp/path/cache']

# Generated at 2022-06-11 15:10:53.708026
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    plugin_loader = PluginLoader(
        class_name='class_name',
        package='package',
        config=None,
        subdir='subdir',
        aliases={'foo'},
        required_base_class=None,
        invocation_order=0,
    )
    assert plugin_loader.get_with_context is not None



# Generated at 2022-06-11 15:11:02.859548
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():

    # test answers
    answers = namedtuple('Answers', ['name', 'path'])
    answers_dict = {'name': {}, 'path': {}}

# Generated at 2022-06-11 15:11:11.272689
# Unit test for method find_plugin_with_context of class PluginLoader

# Generated at 2022-06-11 15:11:17.320351
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    args = dict(name="syslog_events", package='callback',suffix='', class_name='SystemdSyslog', base_class='CallbackModule', config_base=[])
    obj = PluginLoader(**args)
    name = 'syslog_events'
    collection_list = None
    expected = None
    actual = obj.find_plugin(name, collection_list=collection_list)
    assert actual == expected, "Expected:{0} Actual:{1}".format(expected, actual)
