

# Generated at 2022-06-11 15:04:00.159460
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    '''
    Unit test for method __contains__ of class PluginLoader
    '''
    inventory_file_loader = InventoryFileLoader
    path = '/path/to/inventory'
    localhost = 'localhost'

# Generated at 2022-06-11 15:04:06.624871
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    fake_collection = "fake_collection"
    plugin_loader = PluginLoader(
        package="fake_pkg",
        subdir='fake_subdir',
        base_path=['/fake_path'],
        aliases=None,
        class_name='fake_class_name',
        base_class='fake_base_class',
    )
    plugin_loader.add_directory(fake_collection, '/fake_collection_path')
    assert plugin_loader._package_path_with_prefix(fake_collection) == "/fake_collection_path/fake_pkg/fake_subdir"



# Generated at 2022-06-11 15:04:18.569122
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    filenames = [b'sample.py']
    for filename in filenames:
        file_content = load_data_from_file(os.path.join('test/units/utils/plugin_loader/', filename))
        temp_dir = tempfile.mkdtemp()
        try:
            with open(os.path.join(temp_dir, filename), 'wb') as f:
                f.write(file_content)

            loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', 'action')

            loader._get_paths = lambda: [temp_dir]
            assert 'sample' in loader
            assert 'invalid' not in loader

        finally:
            shutil.rmtree(temp_dir)

# Generated at 2022-06-11 15:04:26.540688
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():

    from ansible.plugins import connection
    pl = PluginLoader('connection', 'ConnectionModule', C.DEFAULT_CONNECTION_PLUGIN_PATH, '', required_base_class='ConnectionBase')

    import pytest

    # test that calling with both path_only and class_only returns nothing
    # python3 raises a TypeError, while python2 just ignores one of the args
    with pytest.raises((TypeError, StopIteration)):
        next(pl.all(class_only=True, path_only=True))

    # test that calling with class_only does not instantiate
    for i in pl.all(class_only=True):
        assert not isinstance(i, connection._ConnectionBase)

    # test that calling normally does instantiate

# Generated at 2022-06-11 15:04:34.897157
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Set up parameters for the test
    base_class = 'ActionModule'
    package = 'ansible.plugins'
    subdir = 'action'
    aliases = {'foo_bar': 'foo_bar'}
    # Instantiate a PluginLoader object for the test
    plugin_loader = PluginLoader(base_class, package, subdir, aliases)
    # Actual test of the find_plugin_with_context method
    name = 'foo_bar'
    plugin_load_context = plugin_loader.find_plugin_with_context(name)
    # Expected result
    result = {'redirect_list': [], 'resolved': True, 'plugin_resolved_name': 'foo_bar', 'plugin_resolved_path': 'ansible/plugins/action/foo_bar.py'}
    # Compare the result of the

# Generated at 2022-06-11 15:04:40.618299
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert not module_loader.has_directory('/foo')
    assert not module_loader.has_directory('/bar')
    paths = ['/foo', '/bar']
    add_dirs_to_loader('module', paths)
    assert module_loader.has_directory('/foo')
    assert module_loader.has_directory('/bar')



# Generated at 2022-06-11 15:04:44.202061
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    obj = PluginLoadContext()
    obj.record_deprecation('a','b','c')

# Generated at 2022-06-11 15:04:47.363702
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    with pytest.raises(AssertionError):
        PluginLoader("", "", "", "").find_plugin_with_context("module")


# Generated at 2022-06-11 15:04:56.188721
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # Test fixtures
    test_paths = [
        '/test/path/',
        '/test/path2/',
    ]
    expected_paths = [
        os.path.join(C.DEFAULT_MODULE_PATH, path) for path in test_paths
    ] + test_paths

    # Test functions
    for path in test_paths:
        add_dirs_to_loader(path)

    assert len(expected_paths) == len(PATH_CACHE['module_utils'])
    for result, expected in zip(PATH_CACHE['module_utils'], expected_paths):
        assert result == expected



# Generated at 2022-06-11 15:04:59.801880
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    loader = PluginLoader('ansible.plugins.action', package='ansible')
    assert 'shell' in loader
    assert 'fail' in loader
    assert 'unittest_dummy' not in loader

# Generated at 2022-06-11 15:05:52.539534
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    emitter = DefaultInventoryScript()
    loader = PluginLoader(emitter, 'action_plugin', 'ActionModule', 'ansible.plugins.action')
    result = loader.get_with_context('ping')
    assert result.object
    assert result.object.__class__.__name__ == 'ActionModule'
    assert result.plugin_resolved_name == 'ping'


# Generated at 2022-06-11 15:06:03.020299
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    """
    Test function for method get_with_context of class PluginLoader to verify if it returns the correct plugin object.
    """
    plugin_loader = PluginLoader("ansible.plugins.test_plugin", 'Foo', C.get_config(None, {}))
    plugin_load_context = plugin_loader.find_plugin_with_context("test_plugin.test_plugin")
    if plugin_load_context.resolved and plugin_load_context.plugin_resolved_path:
        name = plugin_load_context.plugin_resolved_name
        path = plugin_load_context.plugin_resolved_path
        redirected_names = plugin_load_context.redirect_list or []
        module_source = plugin_loader._load_module_source(name, path)

# Generated at 2022-06-11 15:06:04.970103
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    u = ansible.utils.plugins.PluginLoader(None, None)
    assert hasattr(u, 'add_directory')


# Generated at 2022-06-11 15:06:12.456902
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell_type = 'sh'
    executable = '/bin/sh'
    shell_plugin = get_shell_plugin(shell_type, executable)
    assert shell_plugin.SHELL_FAMILY == 'sh'


# ********************************************************************************
#
# Plugin Loading code
#
# ********************************************************************************

# ********************************************************************************
#
# PLUGIN SPECIFICATION
#
# Syntax:
#
#    PluginLoader.register(plugin_type, plugin_name, plugin_class, subdir, handler)
#
#    plugin_type - an internal type for the plugin, will be used for finding plugins later
#    plugin_name - a name used to create a class in the module, and a dictionary in the __init__.py file.  This
#                  is usually the same as the plugin_class name, but is sometimes different to support multiple


# Generated at 2022-06-11 15:06:15.062408
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    plugin_loader = PluginLoader('foo')
    assert plugin_loader.__contains__('foo') == True


# Generated at 2022-06-11 15:06:25.045057
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    mocker = MockFixture(spec=PluginLoader)
    name = mocker.param()
    *args = mocker.param()
    class_only = mocker.param.optional('class_only', None)
    collection_list = mocker.param.optional('collection_list', None)
    result = mocker.result(get_with_context_result(Mock(spec=None), plugin_load_context=Mock(spec=PluginLoader.plugin_load_context)))

    mocker.patch.object(PluginLoader, "get_with_context", return_value=result)

    # call the method we are testing
    return_value = PluginLoader.get_with_context(name, *args, class_only=class_only, collection_list=collection_list)

    # make sure the right thing happened
    PluginLoader.get

# Generated at 2022-06-11 15:06:33.947743
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    loader = PluginLoader(
        'unit_test',
        'test_PluginLoader_add_directory',
        'test_PluginLoader_add_directory',
        'test_PluginLoader_add_directory',
        'test_PluginLoader_add_directory'
    )
    loader.add_directory(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'testcases', 'unit_test', 'plugins'))
    assert(loader._get_paths() == [os.path.join(os.path.dirname(os.path.realpath(__file__)), 'testcases', 'unit_test', 'plugins')])


# Generated at 2022-06-11 15:06:45.678334
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    if not os.path.exists(tempfile.gettempdir() + os.sep + "ansible_test_plugins" + os.sep + "action_plugins" + os.sep + "ping.py"):
        with open(tempfile.gettempdir() + os.sep + "ansible_test_plugins" + os.sep + "action_plugins" + os.sep + "ping.py", "w") as file:
            file.write('from ansible.plugins.action import ActionBase')
            file.write('class ActionModule(ActionBase): \n pass')


# Generated at 2022-06-11 15:06:57.188254
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # Setup test
    config = ConfigParser()
    config.optionxform = str
    config.add_section(u'DEFAULT')
    config.set(u'DEFAULT', u'DEFAULT_ROLES_PATH',  u'/tmp')
    config.set(u'DEFAULT', u'DEFAULT_ROLES_PATH',  u'/tmp')
    config.set(u'DEFAULT', u'DEFAULT_TEST_FILTER_PLUGIN',  u'/tmp')
    config.set(u'DEFAULT', u'DEFAULT_ACTION_PLUGIN',  u'/tmp')
    config.set(u'DEFAULT', u'DEFAULT_CACHE_PLUGIN',  u'/tmp')

# Generated at 2022-06-11 15:07:07.293838
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    from ansible.utils.collection_loader import _get_collection_metadata
    import yaml
    warning_deprecation_yaml = """deprecation:
      warning_text: 'Plugin foo has been deprecated. Please use bar instead'
      removal_date: '2031-12-31'
      removal_version: '1.3'
    """
    warning_deprecation_yaml_dict = yaml.safe_load(warning_deprecation_yaml)
    warning_deprecation_yaml_dict['deprecation']['warning_text'] = None
    warning_deprecation_yaml_dict['deprecation']['removal_version'] = None
    c = PluginLoadContext()

# Generated at 2022-06-11 15:08:15.563848
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # FIXME: This is just a placeholder for a test
    # assertEqual( expected, PluginLoader.find_plugin_with_context( name ) )
    raise SkipTest 


# Generated at 2022-06-11 15:08:18.862329
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    """
    This function tests the functionality of get_shell_plugin function
    """
    shell = get_shell_plugin(shell_type="sh")
    assert shell.__class__.__name__ == "ShellModule"
    assert shell.SHELL_FAMILY == "sh"



# Generated at 2022-06-11 15:08:30.392144
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Init args
    class_name = 'ActionModule'
    config_base_class = 'ModuleReplacer'
    package = 'ansible.plugins.action'
    min_subdir_count = 0
    base_class = 'ActionBase'
    aliases = {}
    subdir = 'action_plugins'
    _args = [class_name, config_base_class, package, min_subdir_count, base_class, aliases, subdir]

    # Init PluginLoader
    _plugin_loader = PluginLoader(*_args)

    # Add the directory
    add_directory_result = _plugin_loader.add_directory(['/home/user/myplugins'])

    # Check if add_directory method returns the correct value
    assert add_directory_result == ['/home/user/myplugins']

    # Check if the added directory

# Generated at 2022-06-11 15:08:33.444145
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
  PL = PluginLoader( 'ActionModule', 'ansible.plugins.action', C, 'action_plugins' )
  # FIXME: Implement test for method find_plugin of class PluginLoader
  raise NotImplementedError

# Generated at 2022-06-11 15:08:36.162868
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():

    # _global_context = PluginLoaderContext()

    expected = '{0}'
    result = '{1}'
    assert result == expected, 'Expected {0}, but got {1}'.format(expected, result)



# Generated at 2022-06-11 15:08:46.803376
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    from ansible.plugins.shell import ShellBase

    class TestShell(ShellBase):
        pass

    shell_loader.add(TestShell, 'sh')
    shell_loader.add(TestShell, 'csh')

    shell = get_shell_plugin('sh')
    assert isinstance(shell, TestShell)
    assert shell.SHELL_FAMILY == 'sh'

    shell = get_shell_plugin('csh')
    assert isinstance(shell, TestShell)
    assert shell.SHELL_FAMILY == 'csh'

    shell = get_shell_plugin()
    assert isinstance(shell, TestShell)
    assert shell.SHELL_FAMILY == 'sh'

    shell = get_shell_plugin(executable='/bin/zsh')
    assert isinstance(shell, TestShell)

# Generated at 2022-06-11 15:08:47.887339
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
  pass



# Generated at 2022-06-11 15:08:58.646591
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Save the current paths to restore them later
    saved_paths = C.DEFAULT_MODULE_PATH[:]
    C.DEFAULT_MODULE_PATH[:] = []
    for name, obj in get_all_plugin_loaders():
        obj.directories = []
    test_path = os.path.realpath(os.path.join(os.path.dirname(__file__), os.path.pardir))
    add_all_plugin_dirs(test_path)
    assert C.DEFAULT_MODULE_PATH == [os.path.join(test_path, 'lib', 'ansible', 'modules')]
    assert ModuleLoader.directories == C.DEFAULT_MODULE_PATH

# Generated at 2022-06-11 15:09:04.141292
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Creating test object
    plugin_loader = PluginLoader('./test_plugins/', 'myplugins')
    # Adding directory
    plugin_loader.add_directory('./test_plugins/foo_plugins')
    # Checking if the directory exists
    assert 'foo_plugins' in plugin_loader._get_paths()

# Generated at 2022-06-11 15:09:16.685599
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
	# Load ansible collections
	ansible_collections = [os.path.expanduser('~/ansible_collections'), '/usr/share/ansible/collections']
	for collection_dir in ansible_collections:
		if os.path.isdir(collection_dir):
			sys.path.insert(0, collection_dir)

	# PluginLoader.find_plugin(name)
	# Load modules under 'module_utils'
	loader = PluginLoader(
		'_internal',
		'ansible.module_utils',
		'module_utils',
		C.MODULE_UTILS_PATH
	)
	def find_module(name):
		try:
			return loader.find_plugin(name)
		except AnsibleError as e:
			display

# Generated at 2022-06-11 15:09:51.374021
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Does nothing if path doesn't exist
    for name, obj in get_all_plugin_loaders():
        with warnings.catch_warnings(record=True) as w:
            # Because we are using add_all_plugin_dirs from test_module_finder, we have to expect
            # deprecation warnings as well.
            warnings.simplefilter('always')
            add_all_plugin_dirs('/some/nonexistent/directory')
            assert len(w) == 1
            assert issubclass(w[0].category, DeprecationWarning)
            assert 'get_all_plugin_loaders' in str(w[0].message)

            obj.add_directory('/some/nonexistent/directory')
            assert len(w) == 2

# Generated at 2022-06-11 15:10:02.018590
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    from ansible.launcher.plugins import LookupModuleLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import connection_loader
    # create a fake dir to test the function
    testdir = 'test_dir'
    # testdir is the current file's directory name
    os.chdir(os.path.dirname(testdir))
    # create the testdir
    os.mkdir(testdir)
    # create a fake subdir
    # the subdir name is one of the subdirs whose corresponding PluginLoader is in get_all_plugin_loaders()
    os.mkdir(os.path.join(testdir,'lookup_plugins'))
    # test the function
    add_all_plugin_dirs(testdir)
    # remove the fake dirs
    os

# Generated at 2022-06-11 15:10:12.065165
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    import pytest
    # assuming you've run the setup.py script, which should create the following files

# Generated at 2022-06-11 15:10:21.904541
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    """
    Unit test for Jinja2Loader().get(name)
    """

    collection_name = 'spam'
    collection_plugin_name = 'somename'
    class_name = 'MyPlugin'

    # Issue #47497: check for correct handling of local plugins in collections
    p = Jinja2Loader(class_name, path=[os.path.join(collection_name, collection_plugin_name)], package='ansible.legacy')
    assert p.find_plugin(collection_name + '.spam') == {'name': collection_name, 'type': class_name}
    assert p.find_plugin(collection_plugin_name) == {'name': collection_plugin_name, 'type': class_name}

# Generated at 2022-06-11 15:10:30.237551
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    from ansible.plugins import Jinja2Loader, filter_loader

    loader = Jinja2Loader('filter_plugins', 'filter_loader')
    plugin = loader.find_plugin('regex_replace')
    assert os.path.basename(plugin.path) == 'regex.py'
    assert plugin.name == 'regex_replace'
    assert plugin.plugin_type == 'filter_loader'

    # TODO: test name of plugin that is inside of a collection in 'ansible.legacy'
    # TODO: test name of plugin that is inside of a collection that is not 'ansible.legacy'

# Generated at 2022-06-11 15:10:31.943189
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # TODO: Implement test
    raise SkipTest


# Generated at 2022-06-11 15:10:42.604275
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    from units.mock.loader import DictDataLoader


# Generated at 2022-06-11 15:10:49.357456
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell_types = ['sh', 'csh', 'fish', 'powershell', 'bash', 'zsh']
    executables = ['/bin/sh', '/bin/csh', '/bin/fish', '/bin/powershell', '/bin/bash', '/bin/zsh']
    for shell_type, executable in zip(shell_types, executables):
        shell = get_shell_plugin(shell_type)
        assert shell.SHELL_FAMILY == shell_type
        shell = get_shell_plugin(executable=executable)
        assert shell.SHELL_FAMILY == shell_type
        shell = get_shell_plugin(shell_type, executable)
        assert shell.SHELL_FAMILY == shell_type
    assert get_shell_plugin()
    for shell_type in shell_types:
        shell = get

# Generated at 2022-06-11 15:10:55.546781
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    from ansible.plugins import module_loader
    from ansible.utils.collection_list import CollectionList
    plugin_load_context = PluginLoadContext()
    package_name='ansible_collections.other.ns.plugins.action'
    name='all'
    collection_list=CollectionList()
    plugin_load_context = module_loader._find_fq_plugin(package_name,name,collection_list=collection_list)
    assert plugin_load_context.resolved


# Generated at 2022-06-11 15:11:00.345882
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    loader = PluginLoader(
        'ansible.plugins.cache',
        'CacheModule',
        'ansible.plugins.cache.directory',
    )
    for obj in loader.all():
        assert hasattr(obj, '_original_path')
        assert hasattr(obj, '_load_name')
        assert hasattr(obj, '_redirected_names')

