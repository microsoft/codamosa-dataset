

# Generated at 2022-06-11 15:03:07.260668
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_ACTION_PLUGIN_PATH, 'action_plugins', required_base_class='ActionBase')
    name = 'ping'
    collection_list = dict()
    collection_list[('foo', 'bar')] = ('/tmp/ansible_collections/', ['/tmp/ansible_collections/foo/bar/plugins/modules/'])
    plugin_load_context = loader.get_with_context(name, collection_list=collection_list).plugin_load_context
    assert plugin_load_context.collection_name == 'foo.bar'
    assert plugin_load_context.plugin_resolved_name == 'ping'

# Generated at 2022-06-11 15:03:18.709131
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Make sure the class exists
    assert PluginLoader
    # Create an instance of the class
    # FIXME: does not test anything about the 'self' parameter because it is ignored for now
    plugin_loader = PluginLoader()
    # Test the find_plugin method
    module_name = 'shell'
    plugin_load_context = plugin_loader.find_plugin_with_context(module_name)
    real_module_name = plugin_load_context.plugin_resolved_name
    real_module_path = plugin_load_context.plugin_resolved_path
    if not real_module_name:
        # The plugin was not found
        # FIXME: In this case, we should not return the error, but rather raise it
        #assert real_module_name == None  # FIXME: This is useless
        assert plugin_load_

# Generated at 2022-06-11 15:03:22.056392
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    import ansible.plugins.action

    # Setup
    fake_action_plugin_loader_instance = ansible.plugins.action.ActionBase()

    # Test
    fake_action_plugin_loader_instance.get(name=None)


# Generated at 2022-06-11 15:03:25.899408
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    jinja_loader = Jinja2Loader()
    assert jinja_loader.find_plugin('ansible.') is None
    assert jinja_loader.find_plugin('ansible.collection.') is None

# Generated at 2022-06-11 15:03:27.424176
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    raise SkipTest # no code to test


# Generated at 2022-06-11 15:03:32.807706
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    obj = PluginLoader()
    # setstate should set the correct attributes
    setstate_dict = dict(module_cache=dict(), class_name='foo', package='bar', base_class=None, aliases=dict())
    obj.__setstate__(setstate_dict)
    assert obj.module_cache == dict()
    assert obj.class_name == 'foo'
    assert obj.package == 'bar'
    assert obj.base_class is None
    assert obj.aliases == dict()



# Generated at 2022-06-11 15:03:40.016625
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    """Test function add_all_plugin_dirs()"""
    os_path_expanduser_old = os.path.expanduser
    os_path_isdir_old = os.path.isdir
    os_path_join_old = os.path.join
    add_directory_old = PluginLoader.add_directory

# Generated at 2022-06-11 15:03:43.261061
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    plugin_loader = Jinja2Loader()
    args = {}
    args['collection_list'] = None
    data = plugin_loader.find_plugin('fqcn', *[], **args)
    assert data is None

# Generated at 2022-06-11 15:03:49.762446
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    import tempfile
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.action import ActionModule
    from ansible.plugins.filter import FilterModule
    from ansible.plugins.lookup import LookupModule
    from ansible.plugins.module_utils import ModuleUtils
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.terminal import TerminalModule
    from ansible.plugins.callback import CallbackModule

    # We need to use some plugin subdirs so we can ensure only added subdirs are added, not all
    # plugin subdirs

# Generated at 2022-06-11 15:03:50.464101
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    pass

# Generated at 2022-06-11 15:05:11.442684
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
#
# Test find_plugin()
#
    pl = PluginLoader(
        package="ansible.plugins.action",
        directories=["/home/goneri/git/ansible/lib/ansible/plugins/action"],
    )
    name = 'debug'
    collection_list = None
    result = pl.find_plugin(name, collection_list=collection_list)
    if not isinstance(result, ansible.plugins.action.debug.ActionModule) and not isinstance(result, ansible.plugins.action.debug.ActionModule):
        raise AssertionError('result is not ansible.plugins.action.debug.ActionModule, is %s' % (type(result)))

# Generated at 2022-06-11 15:05:22.868599
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    """Test PluginLoader.find_plugin"""
    PLUGIN_NAME = 'lookup'

    # FIXME:  To test this, we need to mock all the functions below (so they don't do any actual work)
    # and also add a parameter to find_plugin that allows us to inject a list of paths to try.
    # Some answers to questions you may have:
    # 1. Why not just mock those functions?  They use a lot of global state (eg, _PLUGIN_PATH_CACHE)
    #    that we can't safely mock out.
    # 2. Why not just make the paths be parametric?  Because in order to make sure we actually
    #    search the paths, we'd have to modify the behavior of _get_package_paths, _get_paths.
    #
    # For the time being, this will

# Generated at 2022-06-11 15:05:24.637972
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    assert add_all_plugin_dirs('test_invalid_path') is None



# Generated at 2022-06-11 15:05:35.651590
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    clean_module_cache()
    class MockPluginLoader_1():
        subdir = 'MockPluginLoader_1'
        def __init__(self):
            self.directories = []
        def add_directory(self, path):
            self.directories.append(path)
    
    class MockPluginLoader_2():
        subdir = 'MockPluginLoader_2'
        def __init__(self):
            self.directories = []
        def add_directory(self, path):
            self.directories.append(path)

    class MockPluginLoader_3():
        subdir = 'MockPluginLoader_3'
        def __init__(self):
            self.directories = []
        def add_directory(self, path):
            self.directories.append(path)

    pl1 = MockPlugin

# Generated at 2022-06-11 15:05:42.674592
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    class_name = "TestClass"
    base_class = "TestBaseClass"
    package = "package"
    subdir = "subdir"
    test_PluginLoader_obj = PluginLoader(class_name, package, subdir, base_class)

    args = []
    kwargs = {}

    # Call the function
    result = test_PluginLoader_obj.all(*args, **kwargs)

    expected_result = None
    assert expected_result == result


# Generated at 2022-06-11 15:05:53.730720
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    from ansible.plugins.loader import action_loader, connection_loader
    from ansible.module_utils.six.moves import builtins

    try:
        dirname = os.path.dirname(__loader__.path)
    except NameError:
        dirname = os.path.dirname(__file__)

    real_glob = builtins.glob
    fake_glob = lambda x: {to_bytes(os.path.join(dirname, u'connection')), to_bytes(os.path.join(dirname, u'action'))}
    builtins.glob = fake_glob

    # Start with no directories added
    assert len(connection_loader.all()) == 0
    assert len(action_loader.all()) == 0
    builtins.glob = real_glob
    add_

# Generated at 2022-06-11 15:05:55.712100
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # TODO: implement test_PluginLoader_find_plugin
    # assert False, "Test if implemented"
    pass


# Generated at 2022-06-11 15:06:06.177507
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    yaml_path = get_data_path(os.path.join("plugins", "test_plugins", "lookup_plugins"))
    plugin_loader = PluginLoader("lookup", "lookup_plugins", "LookupModule", C.DEFAULT_LOOKUP_PLUGIN_PATH,
                                 'lookup_plugins', required_base_class="LookupBase")
    for name in ("uncommon", "do_not_exist"):
        try:
            plugin_load_context = plugin_loader.get_with_context(name)
        except AnsibleError as err:
            assert "has no plugin named" in str(err)

    plugin_load_context = plugin_loader.get_with_context("spline_reticulate")
    assert plugin_load_context.resolved

# Generated at 2022-06-11 15:06:13.075533
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import callback_loader
    import tempfile
    tmp_dir = tempfile.mkdtemp()
    add_dirs_to_loader('action', [tmp_dir])
    add_dirs_to_loader('connection', [tmp_dir])
    add_dirs_to_loader('lookup', [tmp_dir])
    add_dirs_to_loader('filter', [tmp_dir])
    add_dirs_to_loader('module', [tmp_dir])

# Generated at 2022-06-11 15:06:24.047782
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    """
    Unit test for PluginLoader.get_with_context()
    """
    # Create a class to be used in instantiating a PluginLoader
    class TestPluginLoaderClass(object):
        pass
    # Create a PluginLoader object
    plugin_loader = PluginLoader('test_path', 'test_package', 'test_class', 'test_base_class', TestPluginLoaderClass)
    # Test for an invalid plugin name (no plugin with such name exists)
    plugin_load_context = plugin_loader.get_with_context('InvalidTestPluginName')
    assert plugin_load_context.error == "InvalidTestPluginName"
    # Test for a valid plugin name
    plugin_load_context = plugin_loader.get_with_context('ValidTestPluginName')
    # Assert that the plugin was found
    assert plugin_load_context.res

# Generated at 2022-06-11 15:07:07.365596
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    '''
    This function tests the add_all_plugin_dirs function.
    It tests the functionality of the function under 3 conditions:
    (1) When the path provided is a valid path and has all the plugin subdirectories.
    (2) When the path provided is a valid path and has some of the plugin subdirectories.
    (3) When the path provided is not a directory.
    '''

    # create a new module with no subdirectory
    class NewModule(object):
        module_utils = None
        subdir = None
        package = None

    # create a new module with subdirectory
    class NewModule2(object):
        module_utils = None
        subdir = 'new_module'
        package = None

    # create a new pluginloader with the module created

# Generated at 2022-06-11 15:07:15.803873
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    d = display.Display()
    p = plugins.PluginDirectory()
    if os.path.isdir(os.path.expanduser(d.vars['ansible_plugins'])):
        sys.path.append(os.path.expanduser(d.vars['ansible_plugins']))
        add_all_plugin_dirs(d.vars['ansible_plugins'])
    else:
        display.warning("Ignoring invalid path provided to plugin path: '%s' is not a directory" % d.vars['ansible_plugins'])

#register the plugin loader(s) with the main PluginDirectory object

# We need this for run_once behavior across restarts

# Generated at 2022-06-11 15:07:25.715036
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Used to test the PluginLoader.add_directory method
    PLUGIN_LOADER = PluginLoader('tests.unit.module_loader', 'TestModuleLoaderPlugin')
    MODULE_PATH = os.path.join(DATA_PATH, 'test_plugins', 'module_utils')
    # Add a new path to module_utils directory to the PLUGIN_LOADER object
    PLUGIN_LOADER.add_directory(MODULE_PATH)
    # Checks that the path is added to searched_paths and the plugindir in the PLUGIN_LOADER object
    assert MODULE_PATH in PLUGIN_LOADER._searched_paths
    assert MODULE_PATH.replace('module_utils', 'modules') in PLUGIN_LOADER._searched_paths


# Generated at 2022-06-11 15:07:26.272599
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    pass



# Generated at 2022-06-11 15:07:29.874371
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    if 'all' not in dir(PluginLoader) or type(PluginLoader.all) != types.MethodType:
        raise AssertionError("PluginLoader does not have method all")

# Generated at 2022-06-11 15:07:34.615582
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    PL = PluginLoader('module_utils', 'ModuleUtilBase', C.DEFAULT_MODULE_UTILS_PATH, 'module_utils')
    assert (PL.__contains__('diff') == True)
    assert (PL.__contains__('nonexistent') == False)



# Generated at 2022-06-11 15:07:41.601680
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    loader = PluginLoader(package='foo.bar',
                          class_name='baz',
                          config_base=None)
    loader.add_directory(os.path.join(loader._get_package_path('foo.bar'), "directory"))
    loader.add_directory(os.path.join(loader._get_package_path('foo.bar'), "directory2"))
    loader.add_directory(os.path.join(loader._get_package_path('foo.bar'), "directory3"))
    assert_equals(loader.find_plugin("Plugin1"), os.path.join(loader._get_package_path('foo.bar'), "directory3", "plugin1.py"))
    

# Generated at 2022-06-11 15:07:43.915300
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():

    assert add_dirs_to_loader("action", ["path1", "path2"])


# Generated at 2022-06-11 15:07:49.398943
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    # default to sh
    shell = get_shell_plugin()
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'
    # set shell and executable
    shell = get_shell_plugin('sh', '/bin/bash')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/bash'
    # shell not found
    try:
        shell = get_shell_plugin('shell_not_found')
        assert shell
    except:
        pass



# Generated at 2022-06-11 15:07:59.158326
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    paths = ['test/test_collections/ns1/col1', 'test/test_collections/ns2/coll2']
    add_dirs_to_loader('action', paths)
    # FIXME: Results of loading plugins are cached so we need to clear caches
    # before this test runs. We can't clear just the plugin path cache
    # though because we're testing global results, not just cached results.
    # So this test should be run after all other tests which rely on plugins
    # have run so that we don't affect anything else.
    # Ideally, we'd have a way to create a project that can be populated with
    # fixtures, the plugin loader cache can be primed, and then we can run this
    # test and other tests that rely on plugins without having to clear the
    # cache.
    MODULE_CACHE.clear()
   

# Generated at 2022-06-11 15:09:13.643594
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():

    # Create valid PluginLoader object
    pl = PluginLoader(
        class_name='ShellModule',
        package='ansible.modules.shell',
        config=None,
        subdir='shell',
        aliases=None,
        required_base_class='AnsibleModule'
    )
    valid_return = pl.all(path_only=True)
    valid_return = pl.all(path_only=False)

    # Create valid PluginLoader object
    pl = PluginLoader(
        class_name='ShellModule',
        package='ansible.modules.shell',
        config=None,
        subdir='shell',
        aliases=None,
        required_base_class='AnsibleModule'
    )
    valid_return = pl.all(path_only=True)

# Generated at 2022-06-11 15:09:17.705104
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    class_only = True
    _kwargs = {'class_only': class_only}
    _kwargs.update(kwargs)
    test_obj = A(_kwargs)
    assert test_obj.all() == [B, B]


# Generated at 2022-06-11 15:09:25.092340
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    plugin_loader = PluginLoader('module_utils', 'ansible.module_utils')

    # test basic alias
    plugin_class = plugin_loader.find_plugin("basic")
    assert plugin_class._load_name == 'basic'

    # test dotted alias
    plugin_class = plugin_loader.find_plugin("dotted.alias")
    assert plugin_class._load_name == 'dotted_alias'

    # test subdir alias
    plugin_class = plugin_loader.find_plugin("subdir.alias")
    assert plugin_class._load_name == 'subdir_alias'

# Generated at 2022-06-11 15:09:36.633115
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    test_cases = [
        # cond, path_only, class_only, expected_return, input_args
        # standard
        [False, False, False, {"path": "/tmp/test"}, []],
        # path_only, class_only
        [True, True, False, '/tmp/test', []],
        [True, False, True, object, []],
        # dedupe, class_only
        [True, False, True, object, []],
        # dedupe, path_only
        [True, True, False, '/tmp/test', []],
        # dedupe, path_only, class_only
        [True, True, True, False, []],
        # dedupe
        [True, False, False, False, []],
    ]


# Generated at 2022-06-11 15:09:38.666307
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    assert PluginLoader().find_plugin_with_context('lookup').resolved is False


# Generated at 2022-06-11 15:09:39.374092
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():

    pass

# Generated at 2022-06-11 15:09:45.658343
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test with invalid directory path
    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")
        add_all_plugin_dirs('~/does_not_exist')
        # Verify some things
        assert len(w) == 1
        assert "Ignoring invalid path provided to plugin path: '~/does_not_exist' is not a directory" in str(w[-1].message)



# Generated at 2022-06-11 15:09:56.374234
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    ''' PluginLoader - test find_plugin method '''
    loader = PluginLoader('ansible.plugins.lookup', 'LookupBase', 'lookup_plugins', required_base_class='LookupBase', required_subclass_methods=['run'], import_paths=[], main_path_only=True)
    # 1 - try to check if lookup plugin exists
    if not loader.has_plugin('map'):
        raise AssertionError()
    # 2 - try to check if lookup plugin does not exist (but it has a valid name)
    if loader['map']:
        raise AssertionError()
    # 3 - try to check if lookup plugin does not exist (and it has an invalid name)
    if loader['doesnotexist']:
        raise AssertionError()
    # 4 - try to check if module lookup plugin exists

# Generated at 2022-06-11 15:10:07.381582
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test with a subclass of PluginLoader which provides a base class.
    class TestPluginLoader(PluginLoader):
        def __init__(self, package, subdir, aliases):
            super(TestPluginLoader, self).__init__('ansible.plugins.test_plugin', 'module_utils', 'TestModule', aliases,
                                                   required_base_class='BaseTestModule')
    # Test with a subclass of PluginLoader which doesn't provide a base class.
    class TestPluginLoader2(PluginLoader):
        def __init__(self, package, subdir, aliases):
            super(TestPluginLoader2, self).__init__('ansible.plugins.test_plugin2', 'module_utils', 'TestModule', aliases)


# Generated at 2022-06-11 15:10:08.337139
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    pass

# Generated at 2022-06-11 15:10:54.037807
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")
        # Trigger a warning.
        plc = PluginLoadContext()
        plc.record_deprecation("dummy_name", {'warning_text':'this is dummy warning text'}, None)
        # Verify some things
        assert len(w) == 1
        assert issubclass(w[-1].category, DeprecationWarning)



# Generated at 2022-06-11 15:11:03.145860
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin('sh', '/usr/bin/sh')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/usr/bin/sh'
    shell = get_shell_plugin('bash', '/usr/bin/bash')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/usr/bin/bash'
    try:
        shell = get_shell_plugin(executable='/usr/bin/bash')
        assert False, "Shouldn't be able to get a shell without specifying type"
    except AnsibleError:
        pass

# Generated at 2022-06-11 15:11:08.608165
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    package = 'ansible.legacy'
    subdir  = 'filter_plugins'
    class_name  = 'FiltersModule'
    base_class  = None
    jinja2_loader = Jinja2Loader(package, subdir, class_name, base_class)
    name = 'random'
    ret = jinja2_loader.get(name)
    assert ret.__name__ == 'FiltersModule_random'


# Generated at 2022-06-11 15:11:12.603498
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert "sh" == get_shell_plugin().SHELL_FAMILY
    assert "csh" == get_shell_plugin(shell_type="csh").SHELL_FAMILY
    assert "sh" == get_shell_plugin(executable="/bin/sh").SHELL_FAMILY
    assert "csh" == get_shell_plugin(executable="/usr/bin/tcsh").SHELL_FAMILY



# Generated at 2022-06-11 15:11:17.243727
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    module = 'action'
    package = 'ansible.plugins.%s' % module
    base_class = 'ActionBase'
    class_name = 'ActionModule'
    plugin_loader = PluginLoader(module, package, base_class, class_name)
    plugin_objects = plugin_loader.all(path_only=True)
    assert plugin_objects is not None
    print(plugin_objects)

# Generated at 2022-06-11 15:11:18.849437
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    '''Test the methods of the PluginLoader class'''
    pass


# Generated at 2022-06-11 15:11:27.881659
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    display.verbosity = 4
    # Test case 1:
    try:
        get_shell_plugin()
    except AnsibleError as e:
        assert "Either" in e.message

    # Test case 2:
    import sys
    # As sys.executable is not set in virtualenv
    if sys.executable:
        try:
            get_shell_plugin(executable=sys.executable)
        except AnsibleError as e:
            assert "Cannot determine the shell family" in e.message
        else:
            assert True

    # Test case 3:
    try:
        get_shell_plugin(shell_type="csh")
    except AnsibleError as e:
        assert "Could not find" in e.message

