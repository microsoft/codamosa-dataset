

# Generated at 2022-06-21 05:35:54.174287
# Unit test for constructor of class PluginLoader
def test_PluginLoader():

    # Tests the type of the returned object of the constructor.
    assert isinstance(PluginLoader(), PluginLoader)


# Generated at 2022-06-21 05:35:58.215124
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    # Test for default constructor
    with pytest.raises(AnsibleError):
        loader = Jinja2Loader("invalid_package", "invalid_class")

    with pytest.raises(AnsibleError):
        loader = Jinja2Loader("ansible.errors", "invalid_class")

    with pytest.raises(AnsibleError):
        loader = Jinja2Loader("ansible.plugins", "invalid_class")

    loader = Jinja2Loader("ansible.plugins.filter", "FilterModule")
    # Test for custom constructors
    with pytest.raises(AnsibleError):
        loader = Jinja2Loader("invalid_package", "invalid_class", "base_class", "config_base_class")

    with pytest.raises(AnsibleError):
        loader

# Generated at 2022-06-21 05:36:07.846692
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    mock = CallableMock()
    format_paths = PluginLoader.format_paths
    PluginLoader.format_paths = mock
    obj = PluginLoader(package='ansible.plugins.action')
    obj.get_with_context('copy')
    format_paths.assert_called_once_with(['/data/workspace/ywang/ansible/lib/ansible/plugins/action/copy.py',
                                 '/data/workspace/ywang/ansible/lib/ansible/plugins/action/copy'])
    PluginLoader.format_paths = format_paths


# Generated at 2022-06-21 05:36:18.288707
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    import pathlib
    import tempfile
    tempdir = tempfile.mkdtemp()
    p = pathlib.Path(tempdir) / 'ansible_test_plugins' / 'test_dir'
    p.mkdir(parents=True)
    (p / 'test_plugin.py').touch()
    (p / '__init__.py').touch()
    with p.as_cwd():
        pl = PluginLoader('test_dir', 'test_plugin', 'TestPlugin', None, 'ansible_collections.test.test_plugin', '.')
        assert 'test_plugin' in pl



# Generated at 2022-06-21 05:36:31.873858
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    class MyPluginLoadContext(PluginLoadContext):
        def __init__(self):
            super(MyPluginLoadContext, self).__init__()
            self.test_redirect = None
            self.test_exit_reason = None

        def _redirect(self, redirect_name):
            self.test_redirect = redirect_name
            self.test_exit_reason = 'pending redirect resolution from {0} to {1}'.format(self.original_name, redirect_name)
            self.resolved = False
            return self

    plugin_load_context = MyPluginLoadContext()
    plugin_load_context.original_name = 'my.collection.my_plugin'
    plugin_load_context.redirect('my.collection.my_plugin_redirect')

# Generated at 2022-06-21 05:36:39.182885
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    args = dict(
        name='name',
        collection_list=None,
        subdir=None
    )
    p = PluginLoader('ansible.plugins.test', **args)
    # Call method find_plugin of class PluginLoader
    # TODO: not implemented yet
    # assert False


# Generated at 2022-06-21 05:36:52.261556
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
  PL = PluginLoader(
      package='ansible.plugins.connection',
      class_name='ConnectionBase',
      base_class='ConnectionBase',
      config_base='config',
      subdir='connection_plugins',
      aliases={}
  )
  print(PL.get('local') is PL.get('local'))  # True
  print(PL.has_plugin('local'))  # True
  print(PL.all())  # '<generator object PluginLoader.all at 0x7fba8937a840>'
  print(PL.find_plugin('bad'))  # <ansible.utils.plugin_docs.PluginLoadContext object at 0x7fba8938b080>
  print(PL.all().__next__().get_option('host'))  # localhost

# Generated at 2022-06-21 05:37:03.804290
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # noinspection PyTypeChecker
    class _FakeModule(object):
        _original_path = "some/path"

        def __init__(self):
            raise NotImplementedError()

    loader = PluginLoader("ansible.plugins.action", "ActionModule", C.DEFAULT_INVENTORY_PLUGIN_PATH, 'action_plugins', 'action')
    # noinspection PyProtectedMember
    loader._module_cache = {}
    loader._module_cache["some/path/name.py"] = _FakeModule()
    # noinspection PyProtectedMember
    loader._module_cache["some/path/another_name.py"] = _FakeModule()
    assert loader.find_plugin("name") == _FakeModule()



# Generated at 2022-06-21 05:37:06.075788
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell_type = 'sh'
    sh = get_shell_plugin()
    assert shell_type == sh.SHELL_FAMILY


# Generated at 2022-06-21 05:37:15.005664
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    # FIXME: these should be doctest tests
    assert repr(PluginLoader('module_utils')) == "ansible.module_utils.PluginLoader(package='ansible.module_utils', class_name='_base', config_base_path=None, aliases=None, package_errors=True, required_base_class=None)"
    assert repr(PluginLoader('module_utils', required_base_class="PluginBase")) == "ansible.module_utils.PluginLoader(package='ansible.module_utils', class_name='_base', config_base_path=None, aliases=None, package_errors=True, required_base_class='PluginBase')"

# Generated at 2022-06-21 05:38:22.158011
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.errors import AnsibleError
    from ansible.utils.display import Display
    from ansible.plugins.loader import PluginLoader
    display = Display()
    try:
        assert isinstance(PluginLoader(display), PluginLoader)
    except AssertionError:
        pass
    else:
        try:
            assert isinstance(PluginLoader(display).all(path_only=True), bool)
        except AssertionError:
            pass
        else:
            try:
                PluginLoader(display).all(class_only=True)
            except AnsibleError:
                pass
            else:
                assert False, "Shouldn't get to this line."

# Generated at 2022-06-21 05:38:26.242045
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    pl = PluginLoader('test')
    o = object()
    pl.all = o
    assert o == pl.__getstate__()['all']

# Generated at 2022-06-21 05:38:34.985949
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    # Instance of class Jinja2Loader to be used in testing
    jinja2_loader = Jinja2Loader('filter_plugins', 'FilterModule')

    jinja2_loader._get_paths = lambda: ['./test/unit/plugins/filter_plugins']
    files = jinja2_loader.all()
    for f in files:
        pass


# Generated at 2022-06-21 05:38:41.743079
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    import ansible.plugins.loader as loader
    import ansible.plugins as plugins
    import ansible.plugins.action as action

    import ansible.modules.cloud.amazon as amazon
    import ansible.plugins.cache as cache

    # This is a lot of setup to test one little thing.  It might be able to be simplified
    # TODO: find a way to init the loader without the actual filesystem (maybe mock it)
    module_loader = loader.ModuleLoader()
    _ = module_loader.find_plugin('cloud.amazon.aws_s3')

    plugin_loader = loader.PluginLoader(package='ansible.plugins.action', class_name='ActionModule', config_path=C.DEFAULT_ACTION_PLUGIN_PATH)
    act1 = plugin_loader.find_plugin('cloud.amazon.aws_s3')



# Generated at 2022-06-21 05:38:51.357157
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    context = PluginLoadContext()
    assert not context.resolved
    assert context.error_list == []
    assert context.load_attempts == []
    assert context.pending_redirect == None
    assert context.exit_reason == None
    assert context.plugin_resolved_path == None
    assert context.plugin_resolved_name == None
    assert context.plugin_resolved_collection == None
    assert not context.deprecated
    assert context.removal_date == None
    assert context.removal_version == None
    assert context.deprecation_warnings == []


# Generated at 2022-06-21 05:39:02.772321
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    ctx = PluginLoadContext()
    assert ctx.original_name is None
    assert ctx.redirect_list == []
    assert ctx.error_list == []
    assert ctx.import_error_list == []
    assert ctx.load_attempts == []
    assert ctx.pending_redirect is None
    assert ctx.exit_reason is None
    assert ctx.plugin_resolved_path is None
    assert ctx.plugin_resolved_collection is None
    assert ctx.plugin_resolved_name is None
    assert ctx.deprecated is False
    assert ctx.removal_date is None
    assert ctx.removal_version is None
    assert ctx.deprecation_warnings == []
    assert ctx.resolved is False



# Generated at 2022-06-21 05:39:05.665697
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    # Code should not use 'find_plugin' for Jinja2 plugins
    with pytest.raises(AnsibleError):
        YamlFilterLoader().find_plugin('name')

    # Code should not use 'get' for Jinja2 plugins
    with pytest.raises(AnsibleError):
        YamlFilterLoader().get('name')

# Generated at 2022-06-21 05:39:19.785570
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    '''
    Test for get_with_context method in PluginLoader class.
    
    Parameters
    ----------
    
    Returns
    -------
    '''
    # Replace the get_plugin_paths method of the plugin_loader
    global get_plugin_paths_replaced
    if not get_plugin_paths_replaced:
        plugin_loader.get_plugin_paths = lambda self: [os.path.join(ANSIBLE_TEST_DATA_ROOT, 'test_plugin_loader')]
        get_plugin_paths_replaced = True
    
    # Test for method get_with_context
    # case 1. return_value of get_plugin is None
    plugin_loader.get_plugin = lambda self, name: None

# Generated at 2022-06-21 05:39:32.296245
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    import collections
    import os
    import sys

    module_path = os.path.join(os.path.dirname(sys.executable), 'ansible')
    if os.path.exists(os.path.join(module_path, '__init__.py')):
        sys.path.insert(0, module_path)

    # test cases:
    test_cases = collections.namedtuple('TestCase', ['directories', 'existing_path', 'new_path'])

    existing_path = os.path.dirname(os.path.abspath(os.path.expanduser(__file__)))
    new_path = os.path.dirname(os.path.abspath(__file__))

    test_cases.first = test_cases([], [existing_path], new_path)
   

# Generated at 2022-06-21 05:39:43.617429
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    PluginLoader = utils.plugins.PluginLoader
    name = None
    package = 'package'
    subdir = 'subdir'
    class_name = 'class_name'
    base_class = 'base_class'
    aliases = {'mock_alias': 'mock_name'}

    valid = dict(name=name, package=package, subdir=subdir, class_name=class_name, base_class=base_class, aliases=aliases)
    for key in valid:
        kwargs = valid.copy()
        del kwargs[key]
        if key != 'name' and key != 'aliases':
            with pytest.raises(AnsibleError) as excinfo:
                PluginLoader(**kwargs)
            assert key in str(excinfo)

# Generated at 2022-06-21 05:40:17.992493
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    # The default module_utils path should be "ansible.module_utils.<name>"
    assert PluginLoader('module_utils', 'ansible.module_utils').package == 'ansible.module_utils'
    # The module_utils path in a custom package.
    assert PluginLoader('module_utils', 'custom_package.module_utils').package == 'custom_package.module_utils'



# Generated at 2022-06-21 05:40:21.535153
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    return

    # test when collections is available
    # test when collections is not available
    # test when collections is missing
    # test when collections are not valid


# Generated at 2022-06-21 05:40:24.363481
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    # Create fixture
    paths = ['/foo', '/bar']
    # Execute test code
    result = PluginLoader.format_paths(paths)
    # Verify
    assert result == '/foo, /bar'

# Generated at 2022-06-21 05:40:29.506132
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    obj = PluginLoader('ansible.plugins.loader', '', '', 'ansible.plugins.lookup')
    assert obj.__contains__('template') == False


# Generated at 2022-06-21 05:40:38.475975
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():

    '''
    Unit test for method __repr__ of class PluginLoader
    '''
    pl =  PluginLoader('ansible.plugins', 'ActionModule', 'my_action')
    assert repr(pl) == "PluginLoader<ansible.plugins my_action>" or repr(pl) == "PluginLoader<ansible.plugins.my_action>"
    pl =  PluginLoader('ansible_collections.ns.subns.my_collection', 'ActionModule', 'my_action')
    assert repr(pl) == "PluginLoader<ansible_collections.ns.subns.my_collection my_action>" or repr(pl) == "PluginLoader<ansible_collections.ns.subns.my_collection.my_action>"


# Generated at 2022-06-21 05:40:48.766056
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    import pytest
    from ansible.utils.collection_loader import Jinja2Loader, AnsibleCollectionRef

    def test_func(collection_name, plugin_name, expected_fqcr):
        method_name = 'find_plugin'
        collection_list = None
        if collection_name:
            collection_name = AnsibleCollectionRef.parse_fqcr(collection_name)
            collection_list = [collection_name]
        plugin_loader = Jinja2Loader(collection_list)
        method_parameters = dict(
            name=plugin_name
        )
        if collection_name:
            method_parameters['collection_list'] = collection_list
        fqcr = getattr(plugin_loader, method_name)(**method_parameters)
        assert fqcr == expected_fqcr

    test_func

# Generated at 2022-06-21 05:40:51.517131
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    C.config.init(args=[])

    result_1 = get_with_context_result(u'token')
    result_2 = get_with_context_result(u'token', context=u'context')

    assert result_1 is not None
    assert result_2 is not None

    assert result_1.result() == u'TOKEN'
    assert result_2.result() == u'TOKEN_CONTEXT'



# Generated at 2022-06-21 05:41:00.876114
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    #should return sh plugin
    assert get_shell_plugin().SHELL_FAMILY == 'sh'
    #should return shell type provided
    assert get_shell_plugin(shell_type='powershell').SHELL_FAMILY == 'powershell'
    #should return shell plugin based on exec
    assert get_shell_plugin(executable='/bin/bash') == get_shell_plugin(shell_type='sh')
    assert get_shell_plugin(executable='/bin/sh') == get_shell_plugin(shell_type='sh')
    assert get_shell_plugin(executable='/usr/bin/sh') == get_shell_plugin(shell_type='sh')
    assert get_shell_plugin(executable='/usr/bin/bash') == get_shell_plugin(shell_type='sh')
    assert get_

# Generated at 2022-06-21 05:41:06.130389
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    context = PluginLoadContext()
    assert not context.resolved
    context.redirect("name")
    assert not context.resolved
    assert context.plugin_resolved_name == "name"
    assert context.exit_reason == "pending redirect resolution from to name"


# Generated at 2022-06-21 05:41:19.028915
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    from ansible.plugins.loader import PluginLoader

    # State that 'test_data' is available to PluginLoader
    example_plugin_dir = '/test/test_data/test_data/test_plugins'
    directory_list = [example_plugin_dir]
    plugin_loader = PluginLoader(
        'ansible.plugins.test_plugins',
        'TestPlugins',
        directory_list,
        'none'
    )
    test_plugin_name = 'test_module'
    test_plugin_name_in_collection = 'test_collection.test_module'
    test_plugin_name_in_collection_with_ns = 'test_namespace.test_collection.test_module'

# Generated at 2022-06-21 05:42:22.938068
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    plugin = PLUGIN_LOADER.get('helloworld', class_only=True)
    plugin_fd, plugin_path = mkstemp(dir=C.DEFAULT_LOCAL_TMP)
    plugin_file = os.fdopen(plugin_fd, 'wb')
    try:
        pickle.dump(plugin, plugin_file)

        plugin_file.seek(0)
        ppPlugin = pickle.load(plugin_file)

        ppPlugin.run()
    finally:
        plugin_file.close()
        os.remove(plugin_path)
