

# Generated at 2022-06-21 05:35:23.889202
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    p = PluginLoader('foo', 'bar')
    assert p.format_paths([]) == "(none)"
    assert p.format_paths(['test1', 'test2']) == "test1, test2"


# Generated at 2022-06-21 05:35:30.472393
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    TITLE = "PluginLoader.__contains__"

    class MyClass:

        def my_methods(self, arg):
            return arg

    def my_func(arg):
        return arg

    obj1 = MyClass()
    obj2 = MyClass()

    PL = PluginLoader(package='',
                      config={},
                      subdir='',
                      base_class=None,
                      class_name='',
                      aliases={})
    PL.add(obj1, name='my_data')
    PL.add(my_func, name='my_data')
    PL.add(obj2, name='my_data')

    if not (obj1 in PL and obj2 in PL and my_func in PL):
        return False, F"{TITLE} failed - found unexpected plugin"


# Generated at 2022-06-21 05:35:34.896522
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    context = PluginLoadContext()
    exit_reason = 'nope for class PluginLoadContext'
    result = context.nope(exit_reason)
    assert(result.pending_redirect is None)
    assert(result.exit_reason == exit_reason)
    assert(result.resolved is False)



# Generated at 2022-06-21 05:35:44.951899
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Variables
    args = None
    kwargs = None
    name = None
    path = None

    # Setup
    path = ''
    name = ''
    kwargs = {}
    args = ()

    # Testing
    # Return value
    get_with_context_ = plugin_loader.get_with_context(name, *args, **kwargs)
    # Tests
    assert get_with_context_ == None


# Generated at 2022-06-21 05:35:52.461691
# Unit test for method format_paths of class PluginLoader

# Generated at 2022-06-21 05:35:56.923108
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    # Test for an existing module
    plugin_loader = PluginLoader('test_plugin', 'test')
    plugin_loader.aliases = {'test_alias': 'test'}
    plugin_loader.collection_packages = {}
    plugin_loader.collections_paths = []
    plugin_loader.collection_list = []
    plugin_loader.data = {
        'types': ['test'],
        'paths': [['{0}/data/ansible_collections/ansible_collections/collection_data/ansible_collection/plugins/test_plugin/test.py'.format(os.getcwd())]],
    }
    plugin_loader.package = 'test_plugin'
    plugin_loader.suffix = ''
    plugin_loader.class_name = 'Test'

# Generated at 2022-06-21 05:36:05.700667
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert get_shell_plugin(shell_type='sh') == get_shell_plugin(executable='/bin/sh')
    assert get_shell_plugin(shell_type='csh') == get_shell_plugin(executable='/bin/csh')
    assert get_shell_plugin(shell_type='csh') != get_shell_plugin(executable='/bin/sh')



# Generated at 2022-06-21 05:36:15.100576
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    from ansible.collections.foo.bar.plugins.modules import mymodule
    plugin = PluginLoader('module_utils', 'MyUtils', '', 'myutils')
    assert plugin._module_cache[mymodule.__file__] == mymodule
    assert plugin.__repr__() == "<ansible.plugins.module_utils.MyUtils loader for '/home/travis/build/ansible/ansible/lib/ansible/collections/foo/bar/plugins/module_utils/myutils.py'>"

# Generated at 2022-06-21 05:36:21.224252
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    loader = PluginLoader(
        'ansible.plugins.filter',
        'FilterModule',
        C.DEFAULT_FILTER_PLUGIN_PATH,
        'filter_plugins',
        required_base_class='FilterModule'
    )
    assert(loader.package == 'ansible.plugins.filter')
    assert(loader.class_name == 'FilterModule')
    assert(loader.base_class == 'FilterModule')
    assert(loader.subdir == 'filter_plugins')
    assert(loader.paths == C.DEFAULT_FILTER_PLUGIN_PATH)

# Generated at 2022-06-21 05:36:26.459260
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    path = u"/path/to/plugin/directory"
    internal = True
    plugin_path_context = PluginPathContext(path, internal)
    assert plugin_path_context.path == path
    assert plugin_path_context.internal == internal


# Generated at 2022-06-21 05:37:11.384999
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    # init
    plugin_load_context = PluginLoadContext()
    # test
    redirect_name = ''
    plugin_load_context.redirect(redirect_name)
    # assert
    assert plugin_load_context.plugin_resolved_name == None
    assert plugin_load_context.plugin_resolved_path == None
    assert plugin_load_context.plugin_resolved_collection == None
    assert plugin_load_context.exit_reason == 'pending redirect resolution from None to '
    assert plugin_load_context.pending_redirect == ''
    assert plugin_load_context.resolved == False


# Generated at 2022-06-21 05:37:23.545244
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    '''
    find_plugin of class PluginLoader
    '''
    # Create the class instance
    pl = PluginLoader("foo")

    # Create the return values
    class ReturnVals():
        '''
        Mock class to act as a container for return vals of mocked functions
        '''

        def get_plugin_paths(self, plugin_type, subdir, required):
            '''
            Mock for PluginLoader._get_plugin_paths

            :return: return_get_plugin_paths
            '''
            return self.return_get_plugin_paths

        def path_exists(self, path):
            '''
            Mock for os.path.exists

            :return: return_path_exists
            '''
            return self.return_path_exists

    # Set up the return values


# Generated at 2022-06-21 05:37:32.672301
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Declare the arguments
    args_dict = dict()
    args_dict['directories'] = 'directories'
    args_dict['with_subdir'] = 'with_subdir'
    # Declare the class
    args_dict['class_name'] = 'class_name'
    # Declare the package
    args_dict['package'] = 'package'
    # Declare the suffix
    args_dict['suffix'] = 'suffix'
    # Declare the subdir
    args_dict['subdir'] = 'subdir'
    # Declare the base_class
    args_dict['base_class'] = 'base_class'

    path = os.path.dirname(os.path.realpath(__file__)).replace('test/unit/test_plugin_loader.py', '')

# Generated at 2022-06-21 05:37:46.528744
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    # Verify redirect
    p1 = PluginLoadContext()
    p1.original_name = 'old_name'
    p2 = p1.redirect('new_name')
    assert not p1.resolved
    assert p2.resolved is False
    assert p2.original_name == 'old_name'
    assert p2.exit_reason == 'pending redirect resolution from old_name to new_name'
    assert p2.pending_redirect == 'new_name'
    assert p2.plugin_resolved_path is None
    assert p2.plugin_resolved_name is None
    assert p2.plugin_resolved_collection is None
    # Verify if original object is not affected
    assert p1.exit_reason is None
    assert p1.pending_redirect is None

# Generated at 2022-06-21 05:37:55.301597
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    all_plugins_paths = PluginLoader("ansible.plugins", "ActionModule").all(path_only=True)
    for path in all_plugins_paths:
        assert os.path.exists(path)
        assert path.endswith("ActionModule.py")
    # Make sure we find some but not all, since that would be a problem with the glob
    assert len(list(all_plugins_paths)) > 0
    assert len(list(all_plugins_paths)) < 100

# Generated at 2022-06-21 05:38:08.090683
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    '''
    Test PluginLoader.find_plugin()
    '''
    _PluginLoader = PluginLoader(
        'Library',
        'ansible.plugins',
        C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS,
        'ansible.plugins.library',
    )

    # load from a single path, no conflicts
    test_paths = ['test/twice']
    _PluginLoader._get_paths = lambda _: test_paths
    _PluginLoader._find_plugin = lambda *args, **kwargs: PluginLoader.NotFound()
    _PluginLoader._find_template_plugin = lambda *args, **kwargs: PluginLoader.NotFound()
    assert _PluginLoader.find_plugin('once') == 'test/twice/once.yml'

# Generated at 2022-06-21 05:38:10.524757
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    plc = PluginLoadContext()
    plc.nope("reason")
    assert plc.pending_redirect == None
    assert plc.exit_reason == 'reason'
    assert not plc.resolved


# Generated at 2022-06-21 05:38:17.492570
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
   # Creating a new class instance
   loader_obj = PluginLoader("module_utils", "module_utils", '', 'ansible.module_utils')
   display.display("test_PluginLoader_print_paths")
   # Calling function print_paths
   loader_obj.print_paths()

test_PluginLoader_print_paths()


# Generated at 2022-06-21 05:38:29.739285
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    plc = PluginLoadContext()
    assert not plc.resolved
    assert not plc.plugin_resolved_name
    assert plc.exit_reason is None

    with warnings.catch_warnings(record=True) as w:
        plc.resolve('resolved_name', 'resolved_path', 'resolved_collection', 'exit_reason')
        assert plc.resolve('resolved_name', 'resolved_path', 'resolved_collection', 'exit_reason')
        assert plc.resolved
        assert plc.plugin_resolved_name == 'resolved_name'
        assert plc.plugin_resolved_collection == 'resolved_collection'
        assert plc.plugin_resolved_path == 'resolved_path'
        assert plc.exit_reason == 'exit_reason'

# Generated at 2022-06-21 05:38:37.111409
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    """Unit test
    """
    plugin_load_context = PluginLoadContext()
    plugin_load_context.resolved = True
    plugin_load_context = plugin_load_context.nope('exit_reason')
    assert plugin_load_context.resolved == False
    assert plugin_load_context.exit_reason == 'exit_reason'

    return

# Generated at 2022-06-21 05:39:35.063590
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.plugins import module_loader
    from ansible.plugins.loader import module_loader as mod_loader
    from ansible.plugins.filter.core import FilterModule
    path_only_value = mod_loader.all(path_only=True)
    path_only_isinstance = True
    for i in path_only_value:
        path_only_isinstance = isinstance(i, str)
        break
    assert path_only_isinstance == True
    class_only_values = mod_loader.all(class_only=True)
    class_only_first_isinstance = False
    class_only_second_isinstance = False
    for i in class_only_values:
        if not class_only_first_isinstance:
            class_only_first_isinstance = isinstance(i, FilterModule)

# Generated at 2022-06-21 05:39:43.498321
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    p = PluginLoadContext()

    assert p.original_name is None
    assert p.redirect_list == []
    assert p.load_attempts == []
    assert p.pending_redirect is None
    assert p.exit_reason is None
    assert p.plugin_resolved_path is None
    assert p.plugin_resolved_name is None
    assert p.plugin_resolved_collection is None
    assert p.deprecated is False
    assert p.removal_date is None
    assert p.removal_version is None
    assert p.deprecation_warnings == []
    assert p.resolved is False


# Generated at 2022-06-21 05:39:54.651127
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    import ansible.plugins.shell.sh
    shell_loader.clear()
    shell_loader._set_shells([ansible.plugins.shell.sh.ShellModule])
    shell = get_shell_plugin()
    assert len(shell.COMPATIBLE_SHELLS) == 3
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.CACHE.has_key('')
    assert shell.get_option('not_an_option') is None

    shell_loader.clear()
    shell_loader._set_shells([ansible.plugins.shell.sh.ShellModule])
    shell = get_shell_plugin('not_defined')
    assert len(shell.COMPATIBLE_SHELLS) == 3
    assert shell.SHELL_FAMILY == 'sh'

# Generated at 2022-06-21 05:40:01.246817
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    _loader = PluginLoader(
        'callback',
        'ansible.plugins.callback',
        'CallbackModule',
        'callback_plugins',
        C.DEFAULT_CALLBACK_WHITELIST,
    )
    assert _loader.__contains__('default')



# Generated at 2022-06-21 05:40:08.546920
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    from ansible.plugins.loader import Jinja2Loader
    args = (False,)
    kwargs = {'_dedupe': False}
    ansible_libraries = '/path/to/ansible/lib/ansible/plugins/action'
    paths = [ansible_libraries]
    collected_paths = []
    for path in paths:
        path = path.replace('/path/to/ansible', '~')
        collected_paths.append(path)
    collected_paths.extend(['/path/to/ansible/lib/ansible/plugins/action/'])
    collected_paths = sorted(set(collected_paths))
    name = 'template'
    class_name = 'ActionModule'
    package = 'ansible.plugins.action'

# Generated at 2022-06-21 05:40:12.381869
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell_plugin = get_shell_plugin()
    if shell_plugin is None:
        assert False
    elif shell_plugin.SHELL_FAMILY != "sh":
        assert False



# Generated at 2022-06-21 05:40:25.612171
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    plugin_loader = PluginLoader(
            class_name='CollectionFinder',
            package='ansible.plugins.collection_finder',
            config=None,
            subdir=None,
            aliases={},
            required_base_class=AnsiblePlugin)
    plugin_loader._searched_paths = []
    expected_result = ''
    returned_result = plugin_loader.format_paths(plugin_loader._searched_paths)
    assert expected_result == returned_result
    plugin_loader._searched_paths = ['test1', 'test2', 'test3']
    expected_result = 'test1, test2, test3'
    returned_result = plugin_loader.format_paths(plugin_loader._searched_paths)
    assert expected_result == returned_result

#

# Generated at 2022-06-21 05:40:37.690803
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    global _PLUGIN_FILTERS

    # We need a valid plugin name to determine the load path.
    # We use the value we're testing against because it's valid and
    # it will be available if the test is done from the root directory.
    plugin_name = 'my_extras_path.name'

    # Normally, the calling code would do the following.
    # We're simulating that here.
    #
    # type_loader = Jinja2Loader(
    #     'ansible.plugins.filter',
    #     'FilterModule',
    #     'filter_plugins',
    #     'FilterModule'
    # )
    #
    # plugin_loaders = {
    #     'filter_loader': type_loader,
    #     'test_loader': type_loader,
    #     'module_loader

# Generated at 2022-06-21 05:40:41.098662
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    context = PluginPathContext('/some/path', False)
    assert '/some/path' == context.path
    assert False == context.internal



# Generated at 2022-06-21 05:40:48.065331
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    from ansible.plugins.loader import get_all_plugin_loaders

    plugin_loader = None
    for loader in get_all_plugin_loaders():
        if loader.package == 'ansible.plugins.cache':
            plugin_loader = loader
            break

    with pytest.raises(AnsibleError) as excinfo:
        plugin_loader.get('does_not_exist')

    assert 'is not eligible for last-chance resolution' in str(excinfo.value)
    assert 'has_plugin error:' in str(excinfo.value)


# Generated at 2022-06-21 05:41:42.764551
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():

    import ansible.plugins.filter.core
    base_class = 'FilterModule'
    package = 'ansible.plugins.filter'

    def set_paths():
        jinja_filter_loader = getattr(ansible.plugins.filter, 'FilterModule')
        jinja_filter_loader.package_path = 'ansible/plugins'
        jinja_filter_loader._search_paths = [jinja_filter_loader.package_path]
        jinja_filter_loader._searched_paths = jinja_filter_loader._search_paths[:]

    set_paths()
    loader = Jinja2Loader(base_class, package)

    # Test init
    assert loader.base_class == base_class
    assert loader.package == package
    # Test class_name

# Generated at 2022-06-21 05:41:53.600531
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    resolved_name = 'AnsibleActionModule'
    resolved_path = '/Users/robin/test/test_ansible/lib/ansible/plugins/action'
    resolved_collection = 'ansible.builtin'
    exit_reason = 'Found at /Users/robin/test/test_ansible/lib/ansible/plugins/action/AnsibleActionModule.py'
    new_context = PluginLoadContext()
    new_context.original_name = 'AnsibleActionModule'
    new_context.redirect_list = ['AnsibleActionModule']
    new_context.error_list = []
    new_context.import_error_list = []

# Generated at 2022-06-21 05:41:55.078137
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    assert callable(PluginLoader)



# Generated at 2022-06-21 05:42:02.642581
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert get_shell_plugin('sh').SHELL_FAMILY == 'sh'
    assert get_shell_plugin(shell_type='sh', executable='/bin/sh').executable == '/bin/sh'
    assert get_shell_plugin(shell_type='sh', executable='/bin/bash').executable == '/bin/bash'
    assert get_shell_plugin(executable='/bin/sh').SHELL_FAMILY == 'sh'
    assert get_shell_plugin(executable='/bin/bash').SHELL_FAMILY == 'sh'



# Generated at 2022-06-21 05:42:13.205716
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.plugins.loader import Jinja2Loader

    collection_name = 'foo.bar'
    collection_base_path = os.path.join(sys.path[0], 'test/support/files/ansible_collections/%s/' % collection_name)
    collection_paths = [os.path.join(collection_base_path, "filter_plugins"),
                        os.path.join(collection_base_path, "test_plugins")]

    AnsibleCollectionRef.add_collection_path(collection_name, collection_paths)

    filter_loader = Jinja2Loader('filter_plugins', 'filters', C.DEFAULT_FILTER_PLUGIN_PATH)

# Generated at 2022-06-21 05:42:22.274971
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    args = dict()
    obj = PluginLoader(**args)
    serialized_obj = obj.__getstate__()
    assert isinstance(serialized_obj, dict)
    assert serialized_obj == dict(
        package='',
        entries={},
        class_name='',
        base_class='',
        config_defs=dict(),
        dir_paths=list(),
        root_dir='',
        aliases={},
        plugin_dirs=list(),
        )

# Generated at 2022-06-21 05:42:34.335109
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    """
    test data for plugins is located in the test/units/lib/ansible_test/_data/collection_loader directory
    """
    from ansible.errors import AnsibleError
    from ansible_collections.ansible.legacy.plugins.loader import Jinja2Loader
    from ansible_collections.ansible.legacy.tests.unit.compat.mock import patch
    from ansible_collections.ansible.legacy.tests.unit.compat.magicmock import MagicMock
    from ansible_collections.ansible.legacy.plugins.action import ActionModule
    from ansible_collections.ansible.legacy.plugins.filter import FilterModule
    from ansible_collections.ansible.legacy.plugins.test import TestModule
