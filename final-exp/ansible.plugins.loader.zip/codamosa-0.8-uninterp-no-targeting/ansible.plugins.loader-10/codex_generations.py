

# Generated at 2022-06-21 05:35:24.465666
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    p = PluginLoader('')    
    assert ['/abcd'] == p.format_paths(['/abcd'])
    assert ['/abcd','/efgh'] == p.format_paths(['/abcd','/efgh'])
    assert ['/abcd/efgh'] == p.format_paths(['/abcd/efgh'])
    assert ['/abcd/efgh','/ijkl'] == p.format_paths(['/abcd/efgh','/ijkl'])

# Generated at 2022-06-21 05:35:35.552002
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    import tempfile
    import shutil

    paths = []

    try:
        for i in range(0, 2):
            paths.append(tempfile.mkdtemp())
            plugin_filename = 'shell.py'
            fh, filename = tempfile.mkstemp(prefix='%s_' % plugin_filename)
            os.close(fh)
            plugin_path = os.path.join(paths[i], plugin_filename)
            shutil.copy(filename, plugin_path)
            add_dirs_to_loader('shell', paths)
    finally:
        for path in paths:
            shutil.rmtree(path)


# Generated at 2022-06-21 05:35:49.490710
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    TEST_DIRS = [
        ['/home/me/.ansible', '/etc/ansible'],
        ['/foo'],
        ['/home/me/.ansible', '/usr/share/ansible', '/usr/local/share/ansible'],
        ['/bar/', '/var/lib/awx/venv/awx/lib/python2.7/site-packages/ansible'],
        ['/home/me/.ansible', '/usr/share/ansible', '/usr/local/share/ansible', '/home/me/.ansible/plugins/modules']
        ]

# Generated at 2022-06-21 05:35:59.423494
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plugin_load_context = PluginLoadContext(original_name="foo")
    assert plugin_load_context.resolved
    assert plugin_load_context.original_name == "foo"
    assert plugin_load_context.redirect_list == []
    assert plugin_load_context.error_list == []
    assert plugin_load_context.import_error_list == []
    assert plugin_load_context.load_attempts == []
    assert plugin_load_context.pending_redirect is None
    assert plugin_load_context.exit_reason is None
    assert plugin_load_context.plugin_resolved_path is None
    assert plugin_load_context.plugin_resolved_name is None
    assert plugin_load_context.plugin_resolved_collection is None
    assert not plugin_load_context.deprecated


# Generated at 2022-06-21 05:36:00.446680
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type='sh')
    return True


# Generated at 2022-06-21 05:36:01.388715
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():

    test_class = PluginLoadContext()
    test_class.resolve()



# Generated at 2022-06-21 05:36:05.696845
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    # test initialization
    get_with_context_result = GetWithContextResult()
    assert_equal(get_with_context_result.name, "")
    assert_equal(get_with_context_result.path, "")
    assert_equal(get_with_context_result.plugin_type, "")
    assert_equal(get_with_context_result.plugin_class, None)
    assert_equal(get_with_context_result.plugin_config_class, None)
    assert_equal(get_with_context_result.plugin_obj, None)
    assert_equal(get_with_context_result.plugin_config_obj, None)
    assert_equal(get_with_context_result.init_config, None)

    # test class methods
    # to_dict
    get_with_context_

# Generated at 2022-06-21 05:36:17.649335
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    #Test 1
    plugin_loader = PluginLoader("ansible.plugins.action", "ActionModule", require_type='class', package_error_text='Invalid')
    plugin_loader.add_directory(os.path.join(ANSIBLETOWER_BASE_DIR, "ansible/plugins/action"))
    result = plugin_loader.get("async_wrapper")
    assert result == None

    #Test 2
    plugin_loader = PluginLoader("ansible.plugins.action", "ActionModule", require_type='class', package_error_text='Invalid')
    plugin_loader.add_directory(os.path.join(ANSIBLETOWER_BASE_DIR, "ansible/plugins/action"))
    assert plugin_loader.find_plugin("async_wrapper") == None

    #Test 3

# Generated at 2022-06-21 05:36:31.753196
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    jinja2_loader = Jinja2Loader(
        'ansible.legacy.plugins.filter',
        'FilterModule',
        C.DEFAULT_FILTER_PLUGIN_PATH,
    )
    assert jinja2_loader.package == 'ansible.legacy.plugins.filter'
    assert jinja2_loader.base_class == 'FilterModule'
    assert jinja2_loader.class_name == 'FilterModule'
    assert jinja2_loader._package_path == C.DEFAULT_FILTER_PLUGIN_PATH
    assert jinja2_loader.subdir == 'filter_plugins'
    assert jinja2_loader._searched_paths == [C.DEFAULT_FILTER_PLUGIN_PATH]
    assert jinja2_loader._paths

# Generated at 2022-06-21 05:36:43.847013
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    ldr = Jinja2Loader('ansible.legacy.filter_plugins')

    ldr.add_directory('/tmp/ansible_test_data/jinja2_loader')

    # Calling code expects to iterate this result.  We need to use a list() to force this to happen.
    plugins = list(ldr.all('', '', '', collections_paths=[]))
    assert len(plugins) == 3

    # Check that some files were deduplicated and others were not.  This is because we have a few
    # files with the same name but different jinja2 plugins inside of those files.
    assert plugins[1] != plugins[2]
    assert plugins[0] == plugins[1]

    # Test that type of plugins is always a list of tuples (name, plugin)

# Generated at 2022-06-21 05:37:23.325002
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    """Test _PluginLoader.get"""

    _PluginLoader = ansible_collections.ibm.spectrumcomputing.plugins.module_utils.common.PluginLoader
    # test load a class
    obj = _PluginLoader(package='ansible_collections.ibm.spectrumcomputing.plugins.module_utils.common.plugin',
                        subdir='filter_plugins',
                        class_name='FilterModule')
    obj.load_plugins()
    assert obj.get('core') == ansible_collections.ibm.spectrumcomputing.plugins.module_utils.common.filter_plugins.core.FilterModule
    assert obj.get('core', 'path_only') == ansible_collections.ibm.spectrumcomputing.plugins.module_utils.common.filter_plugins.core.FilterModule
    # test loader fail to load

# Generated at 2022-06-21 05:37:25.923821
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    mpd = "test/test_test_test"
    add_all_plugin_dirs(mpd)
    assert mpd in PLUGIN_PATH_CACHE, "did not add subdir"



# Generated at 2022-06-21 05:37:34.037693
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    from ansible import constants as C
    from ansible.utils.path import parse_kv
    from ansible.plugins.loader import PluginLoader
    pl = PluginLoader("action")

# Generated at 2022-06-21 05:37:40.567908
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    assert PluginLoadContext().nope('exit_reason').pending_redirect is None
    assert PluginLoadContext().nope('exit_reason').exit_reason == 'exit_reason'
    assert PluginLoadContext().nope('exit_reason').resolved is False


# Generated at 2022-06-21 05:37:44.862602
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    loader = PluginLoader(os.path.join('/usr/lib/python2.7/site-packages/ansible/plugins/lookup'))
    assert loader.get_with_context('vault')


# Test for method has_plugin of class PluginLoader

# Generated at 2022-06-21 05:37:53.574382
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():

    j = Jinja2Loader('filter_plugins')
    assert(j.base_class is None)
    assert(j.class_name == 'FilterModule')
    assert(j.package == 'ansible.plugins.filter')
    assert(j.subdir == 'filter_plugins')
    assert(j.class_only is False)
    assert(j.caching is True)

# Generated at 2022-06-21 05:38:06.859920
# Unit test for function add_all_plugin_dirs

# Generated at 2022-06-21 05:38:13.793972
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    p = PluginLoader('fixture_plugins', 'FixturePlugin', 'ansible.plugins.fixture_plugins', C.DEFAULT_INTERNAL_PLUGINS_PATH, '', required_base_class='FixtureBaseClass')
    # collection_name
    #   name
    #     suffix
    #       resolved_name
    #       resolved_path
    #     name_only
    #     collection_name
    #     path
    #     suffixes
    #     collection_name
    #   collection_list
    class plugin_load_context:
        def __init__(self):
            self.suffix = 'json'
            self.resolved_name = 'my_fixture'
            self.resolved_path = '/test/test/test/test.json'
            self.name_only = 'test'


# Generated at 2022-06-21 05:38:17.116587
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    loader = PluginLoader('module_utils', 'ModuleUtilsCore')
    assert 'copy' in loader
    assert 'asdf' not in loader


# Generated at 2022-06-21 05:38:18.115551
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    pass

# Generated at 2022-06-21 05:39:15.373786
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    import ansible.module_utils.basic
    def result(context):
        return dict(
            stdout=dict(
                test=dict(context=context, name='test')
            ),
            stderr=dict(
                test=dict(context=context, name='test')
            )
        )
    m = dict(
        result1=ansible.module_utils.basic.get_with_context_result(result, 'context1'),
        result2=ansible.module_utils.basic.get_with_context_result(result, 'context2')
    )
    assert m['result1']['stdout']['test']['context'] == 'context1'
    assert m['result1']['stderr']['test']['context'] == 'context1'

# Generated at 2022-06-21 05:39:24.095063
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():

    # Importing at the end of the file so we can patch the path
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_bytes, to_text

    with patch.dict(os.path.exists.__dict__, {"return_value": True}):
        with patch.dict(os.path.isdir.__dict__, {"return_value": True}):
            with patch.object(PluginLoader, '_get_paths', return_value=['/path/to/plugins']):
                # create plugin source files
                names = ['test_plugin1', 'test_plugin2']
                # if we use tempfile.gettempdir for these tests, there's a chance it will be
                # on another filesystem than the current directory, which will make the
                # test fail.

# Generated at 2022-06-21 05:39:29.048328
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    plugin_load_context = PluginLoader.find_plugin_with_context("foobar")

    assert plugin_load_context is not None
    assert isinstance(plugin_load_context, PluginLoader.PluginLoadContext)



# Generated at 2022-06-21 05:39:42.720164
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    def remove_plugin_path(plugin_load_context):
        plugin_load_context.plugin_searched_paths.pop()
        return plugin_load_context

    # noinspection PyShadowingNames
    def test_scenario(loader, expected_resolved_name, expected_resolved_path, expected_redirect_list):
        # noinspection PyProtectedMember
        plugin_load_context = loader.find_plugin_with_context('my_plugin')
        assert_equal(expected_resolved_name, plugin_load_context.plugin_resolved_name)
        assert_equal(expected_resolved_path, plugin_load_context.plugin_resolved_path)
        assert_equal(expected_redirect_list, plugin_load_context.redirect_list)

# Generated at 2022-06-21 05:39:51.947167
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    '''Test function to ensure that get_all_plugin_loaders() is called'''

    _get_all_plugin_loaders = globals()['get_all_plugin_loaders']
    globals()['get_all_plugin_loaders'] = lambda: [('_', '_')]
    try:
        add_all_plugin_dirs('no_such_dir/')
    finally:
        globals()['get_all_plugin_loaders'] = _get_all_plugin_loaders


# Generated at 2022-06-21 05:40:05.418656
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    basedir = 'test/unit/plugins/filter_plugins/testdir_dedupe_test'
    pattern = '*.py'
    package = 'ansible.plugins.filter_loader.testdir_dedupe_test'

    jinja2_loader = Jinja2Loader(paths=[basedir], package=package, filter_name='filters')

    plugin_list = jinja2_loader.all()
    # we have 2 files and 3 jinja2 plugins
    assert len(plugin_list) == 2
    for plugin_instance in plugin_list:
        assert plugin_instance.__name__ == 'TestDedupeFilters'

    # This is what we get if we use the base PluginLoader.all()
    # Base PluginLoader dedupes the files and returns one plugin of each name
    # The calling code is then overw

# Generated at 2022-06-21 05:40:16.928462
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    
    #1
    deprecation = {}
    collection_name = ''
    name = 'hoge'
    plc = PluginLoadContext()
    plc.record_deprecation(name, deprecation, collection_name)
    assert plc.deprecated == True
    assert plc.removal_date == None
    assert plc.removal_version == None
    #print(plc.deprecation_warnings[0])
    assert plc.deprecation_warnings[0] == 'hoge has been deprecated.'

    #2
    del plc.deprecation_warnings[0]
    deprecation = {'warning_text': 'hoge has been deprecated.'}
    collection_name = ''
    name = 'hoge'

# Generated at 2022-06-21 05:40:26.836545
# Unit test for function get_shell_plugin
def test_get_shell_plugin(): # pragma: no cover
    sample_path = os.path.join(C.ansible_test_data_root, 'units', 'shell_plugins')
    shell_loader.add_directory(sample_path)
    shell = get_shell_plugin('fish', 'fish')
    assert shell.executable == 'fish'
    shell = get_shell_plugin('sh', '/path/bash')
    assert shell.executable == '/path/bash'
    shell = get_shell_plugin(executable='/path/zsh')
    assert shell.executable == '/path/zsh'
    shell = get_shell_plugin(executable='/path/ksh')
    assert shell.executable == '/path/ksh'
    shell = get_shell_plugin(executable='/path/dash')

# Generated at 2022-06-21 05:40:30.715330
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    pl = PluginLoader('foo', 'bar', 'baz', 'bam')
    assert repr(pl) == '<PluginLoader foo.bar.baz.bam>'


# Generated at 2022-06-21 05:40:32.897341
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    assert get_all_plugin_loaders()
# ---



# Generated at 2022-06-21 05:41:01.797692
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    """
    Test to ensure that the correct paths are being added to the correct loaders in add_dirs_to_loader.

    This test is dependent on the order of the LOADER_PLUGINS constant - it is vital that this test be executed
    prior to any other tests that populate PLUGIN_PATH_CACHE[key] to ensure that this unit test is actually testing
    add_dirs_to_loader.
    """
    # Empty the PLUGIN_PATH_CACHE
    PLUGIN_PATH_CACHE.clear()

    # PY3: Make sure the structure that PLUGIN_PATH_CACHE uses is set up
    PLUGIN_PATH_CACHE['lookup'] = []

    # Add our data

# Generated at 2022-06-21 05:41:11.381195
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    plc = PluginLoadContext()
    assert plc.original_name is None
    assert plc.redirect_list is []
    assert plc.error_list is []
    assert plc.import_error_list is []
    assert plc.load_attempts is []
    assert plc.pending_redirect is None
    assert plc.exit_reason is None
    assert plc.plugin_resolved_path is None
    assert plc.plugin_resolved_name is None
    assert plc.deprecated is False
    assert plc.removal_date is None
    assert plc.removal_version is None
    assert plc.deprecation_warnings is []
    assert plc.resolved is False
    assert plc.resolved_fqcn is None
    plc.nope

# Generated at 2022-06-21 05:41:20.244415
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    # Test Case 1 - shell_type=None, executable=None
    try:
        get_shell_plugin()
    except AnsibleError:
        pass
    else:
        raise AssertionError('AnsibleError expected')

    # Test Case 2 - shell_type='sh', executable='/bin/sh'
    assert get_shell_plugin(shell_type='sh', executable='/bin/sh')

    # Test Case 3 - shell_type=None, executable='/bin/sh'
    assert get_shell_plugin(executable='/bin/sh')

    # Test Case 4 - shell_type='csh', executable='/bin/csh'
    assert get_shell_plugin(shell_type='csh', executable='/bin/csh')

    # Test Case 5 - shell_type=None, executable='/bin/c

# Generated at 2022-06-21 05:41:30.795608
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    pl = PluginLoader("vars_plugins")
    # test with 2 elements in the list
    paths = ["/a", "/b"]
    expected = "/a:/b"
    assert pl.format_paths(paths) == expected

    # test with 3 elements in the list with a ~
    paths = ["/a", "/b", "/var/lib/awx/~/test"]
    expected = "/a:/b:/var/lib/awx/~/test"
    assert pl.format_paths(paths) == expected

    # test with 3 elements in the list with a ~
    paths = ["/a", "/b", "/var/lib/awx/~/test"]
    expected = "/a:/b:/var/lib/awx/~/test"
    assert pl.format_paths(paths) == expected



# Generated at 2022-06-21 05:41:34.589369
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    plugin_loader = PluginLoader('filter_loader', 'FilterModule')
    assert repr(plugin_loader) == "<PluginLoader filter_loader:FilterModule>"


# Generated at 2022-06-21 05:41:39.896199
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    plugin_loader = PluginLoader(
        'ansible.plugins.action',
        'ActionModule',
        C.DEFAULT_INVENTORY_ENABLED_PLUGINS,
        'action_plugins',
    )
    assert 'systemd' in plugin_loader
    assert 'not_found' not in plugin_loader

# Generated at 2022-06-21 05:41:49.527321
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():

    class FakePluginLoader(PluginLoader):
        # In C.BASE_MODULE_PATH, we have ansible/plugins/connection/file.py, which
        # should be found.
        package = 'ansible.plugins.connection'
        base_class = 'ConnectionBase'
        search_paths = C.BASE_MODULE_PATH
        class_name = 'Connection'

    assert FakePluginLoader.all() is not None


# Generated at 2022-06-21 05:41:55.711783
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    plugin_loader = PluginLoader('')
    assert repr(plugin_loader) == '<ansible.utils.plugin_docs.PluginLoader prefix_package=\'\' subdir=\'\' base_class=\'None\' class_name=\'\' package=\'\'>'


# Generated at 2022-06-21 05:42:01.945112
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    loader = PluginLoader(
        'LookupModule',
        'ansible.plugins.lookup',
        C.DEFAULT_LOOKUP_PLUGIN_PATH,
        'lookup_plugins',
        required_base_class='LookupBase',
    )

    plugin = loader.get_with_context('csvfile', '')
    assert(plugin.__class__.__name__ == 'Csvfile')



# Generated at 2022-06-21 05:42:10.251302
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():

    plugin_load_context = PluginLoadContext()
    deprecation = dict()
    deprecation["warning_text"] = "This is warning"
    deprecation["removal_date"] = "2019-11-12"
    deprecation["removal_version"] = "2.10"
    plugin_load_context.record_deprecation("name", deprecation, None)
    assert plugin_load_context.deprecated is True

