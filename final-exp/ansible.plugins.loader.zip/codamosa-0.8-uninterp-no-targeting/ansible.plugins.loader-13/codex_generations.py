

# Generated at 2022-06-21 05:34:24.963534
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    # This function is just a placeholder.
    # The (automated) tests for __repr__
    # are part of test_ansible_module_common.py
    pass

# Generated at 2022-06-21 05:34:38.491663
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    context_store = {}
    # Load plugins in the current directory
    types = ('action', 'cache', 'callback', 'cliconf', 'connection', 'httpapi', 'inventory', 'lookup', 'module_utils',
            'modules', 'shell', 'filter', 'vars', 'terminal', 'test')
    for ptype in list(types):
        context_store[ptype] = {}
        p = PluginLoader(ptype, '.', '_', C.DEFAULT_CACHE_PLUGIN_TIMEOUT)
        for plugin in p.all():
            context_store[ptype][plugin._load_name] = p.find_plugin_with_context(plugin._load_name)

    # Load our collection plugins
    context_store['collection_action'] = {}
    context_store['collection_connection'] = {}

# Generated at 2022-06-21 05:34:46.672706
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    cur_dir = os.path.dirname(os.path.realpath(__file__))
    parent_dir = os.path.split(cur_dir)[0]
    new_dir = os.path.join(parent_dir, "examples")
    new_dir2 = os.path.join(new_dir, 'plugins')
    plugin_loader = PluginLoader('./myplugins')
    plugin_loader.add_directory(new_dir)
    plugin_loader.add_directory(new_dir2)
    # This is just a simple test to see if it adds the directory to the
    # search paths
    assert os.path.normpath(plugin_loader._searched_paths[-1]) == os.path.normpath(os.path.join(new_dir, 'myplugins'))

# Generated at 2022-06-21 05:34:56.570905
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # These tests rely on the test plugins provided in this file.
    # If an environment is set to hit an in-repo collection the test may
    # return a false positive
    if os.environ.get('ANSIBLE_COLLECTIONS_PATH'):
        raise unittest.SkipTest('ANSIBLE_COLLECTIONS_PATH is set, c.f. #68299')
    # ANSIBLE_ROLES_PATH is only used by AnsibleRolePath
    # In Ansible 2.10, we'll add a new environment variable, ANSIBLE_LOOKUP_PLUGINS_PATH
    # to control lookup_loader. See https://github.com/ansible/ansible/issues/68068
    old_lookup_path = os.environ.pop('ANSIBLE_ROLES_PATH', None)

# Generated at 2022-06-21 05:35:09.248822
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    from ansible.plugins.loader import Jinja2Loader
    from unittest.mock import Mock
    import os
    import sys
    import tempfile

    loader = Jinja2Loader()

    assert '.' in 'namespace.collection.plugin_name'
    # check that we don't raise a ValueError when using find_plugin with a collection path
    with tempfile.TemporaryDirectory() as collection_path:
        try:
            loader.find_plugin(os.path.join(collection_path, 'namespace.collection.plugin_name'), collection_list=[])
        except ValueError:
            pytest.fail('Unexpected ValueError')

    # check that we don't raise a ValueError when using find_plugin with a collection name

# Generated at 2022-06-21 05:35:15.989145
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    print("test_PluginLoader_format_paths")
    p = PluginLoader("foobar")
    if p.format_paths(["/a", "/b/c", "/d/e/f"]) != "'/a', '/b/c', '/d/e/f'":
        exit(1)


# Generated at 2022-06-21 05:35:18.779246
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    redirect_obj = PluginLoadContext()
    doc = redirect_obj.redirect.__doc__
    assert doc == '''add a name to the pending redirect list and set the exit reason to pending redirect resolution'''

# Generated at 2022-06-21 05:35:24.833341
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():

    from ansible.utils.hashing import md5s

    def get_state(pl):
        return pl.__getstate__()

    pl = PluginLoader('test', '/fake')
    state = get_state(pl)

    assert state == {
        'cached_result': {},
        '_collections_paths': C.COLLECTIONS_PATHS,
        'package': 'test',
        '_searched_paths': ['/fake'],
        '_module_cache': {},
        'class_name': 'Test',
        'base_class': None,
    }

    # make sure caching works

    pl._searched_paths = [i + 'a' for i in pl._searched_paths]

# Generated at 2022-06-21 05:35:29.652050
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    c = PluginPathContext("/etc/ansible/plugins", True)
    assert c.path == "/etc/ansible/plugins"
    assert c.internal == True


# Generated at 2022-06-21 05:35:32.125161
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    _plugin_loader = PluginLoader('foo', 'bar', 'baz', 'qux')

    _instance = _plugin_loader.__repr__()

    assert _instance == '<ansible.utils.plugin_docs.PluginLoader foo.bar.baz.qux>'



# Generated at 2022-06-21 05:36:05.700966
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    class_name = 'test'
    base_class = 'test'
    package = 'test'
    config = 'test'

    plugin_loader = PluginLoader(class_name, base_class, package, config)
    result = plugin_loader.__repr__()
    assert result == "<plugin_loader (ansible.plugins.test.test)>"


# Generated at 2022-06-21 05:36:11.991215
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    mock_loader = PluginLoader('mock_type', 'mock_base_class', 'mock_package', 'mock_paths')
    mock_loader.aliases = dict(foo='bar')
    p = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action', 'action_plugins')
    def dict_plugin_finds(plugin_load_context):
        plugin_load_context.resolved = 'dictionaries'
        plugin_load_context.add_resolved_path('dictionaries')
        plugin_load_context.resolved_collection_ref = AnsibleCollectionRef('ansible.builtin')
        plugin_load_context.resolved_collection_spec = AnsibleCollectionRef.static_collection_spec_from_ref(plugin_load_context.resolved_collection_ref)
       

# Generated at 2022-06-21 05:36:16.486203
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    from ansible.plugins.loader import PluginLoader
    p = PluginLoader('*')
    data = p.__getstate__() # doctest: +IGNORE_EXCEPTION_DETAIL
    assert data == {'package': '*', 'class_name': '_'}


# Generated at 2022-06-21 05:36:20.902648
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    """
    This unit test confirms that the method all from PluginLoader class works properly
    """
    search_dir = '/home/user/ansible/lib/ansible/plugins/callback/custom_callback'
    for plugin in PluginLoader.all(search_dir, 'ansible.plugins.callback.custom_callback', 'callback', CUSTOM_CALLBACK_BASE):
        assert plugin.NAME in ['custom_callback']

# Generated at 2022-06-21 05:36:28.986800
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
  # '''Testcase for PluginLoader Class method get_with_context'''
  # set params
  name = 'file'
  collection_list = None
  # obj = AnsibleCollectionLoader()
  # obj.find_plugin_with_context(name, collection_list=collection_list)
  # return get_with_context_result(obj, plugin_load_context)
  pass

# Generated at 2022-06-21 05:36:36.907721
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    from ansible.plugins.loader import action_loader, connection_loader, filter_loader
    all_plugin_loaders = get_all_plugin_loaders()
    assert all_plugin_loaders == [('action_loader', action_loader), ('connection_loader', connection_loader), ('filter_loader', filter_loader)]

# fixme: does this need to be a class or not?

# Generated at 2022-06-21 05:36:40.024897
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    '''
    Unit test for method __getstate__ of class PluginLoader
    '''
    # TODO: create test



# Generated at 2022-06-21 05:36:53.712944
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    import ansible.utils.plugin_docs

    assert 'test_add_dirs_to_loader' not in sys.modules['ansible.plugins.test_plugin'].__dict__
    with warnings.catch_warnings(record=True) as w:
        add_dirs_to_loader('test_plugin', ['lib/ansible/plugins/test_plugin/'])
        assert 'test_add_dirs_to_loader' in sys.modules['ansible.plugins.test_plugin'].__dict__
    assert len(w) == 1
    assert issubclass(w[-1].category, AnsiblePluginRemovedError)
    assert "has been replaced by TestDeprecatedPlugin.  TestDeprecatedPlugin will be removed" in str(w[-1].message)



# Generated at 2022-06-21 05:36:57.865900
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    assert get_with_context_result([], {}, 'foo') == {}
    assert get_with_context_result(['foo'], {}, 'foo') == {'foo': {}}
    assert get_with_context_result(['foo', 'bar'], {}, 'foo') == {'foo': {'bar': {}}}
    assert get_with_context_result(['foo', 'bar'], {'bar': {'baz': 'qux'}}, 'foo') == {'foo': {'bar': {'baz': 'qux'}}}
    assert get_with_context_result(['foo', 'bar'], {'bar': {'baz': 'qux'}}, 'qux') == {'qux': []}
    with pytest.raises(AssertionError):
        get_with_

# Generated at 2022-06-21 05:37:09.458889
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    plugin_loader = PluginLoader("test", "", C)

    # Test for no paths
    test_paths = []
    assert plugin_loader.format_paths(test_paths) == "[]"
    assert plugin_loader.format_paths(test_paths, False) == "[]"

    # Test for one path
    test_paths = ["/blah/blah/blah"]
    assert plugin_loader.format_paths(test_paths) == "['/blah/blah/blah']"
    assert plugin_loader.format_paths(test_paths, False) == "['/blah/blah/blah']"

    # Test for more than one path
    test_paths = ["/blah/blah/blah", "/foo/foo/foo"]

# Generated at 2022-06-21 05:38:25.949838
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    """
    The function PluginLoader.__setstate__ should be an instance method,
    whose docstring contains the correct description of its functionality
    """
    #
    # Setup
    #
    if not hasattr(PluginLoader, '__setstate__'):
        #
        # Cleanup
        #
        raise TypeError('%r is not an instance method' % PluginLoader.__setstate__)

# Generated at 2022-06-21 05:38:39.419051
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    assert isinstance(get_with_context_result((1, 2)), tuple)
    assert get_with_context_result((1, 2)) == (1, 2)
    assert isinstance(get_with_context_result(None), tuple)
    assert get_with_context_result(None) == (None, None)
    assert isinstance(get_with_context_result(1), tuple)
    assert get_with_context_result(1) == (1, None)
    assert isinstance(get_with_context_result([1, 2]), tuple)
    assert get_with_context_result([1, 2]) == (1, [1, 2])
    assert isinstance(get_with_context_result(A(1, 2)), tuple)

# Generated at 2022-06-21 05:38:49.809994
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    cur_path = os.path.dirname(os.path.abspath(__file__))
    lib_path = os.path.abspath(os.path.join(cur_path, '../lib/ansible/plugins/action'))

    obj = PluginLoader('ActionModule', 'ansible.plugins.action', 'action_plugins', '_', 'action', lib_path)
    assert obj.__repr__() == "<ansible.utils.plugin_docs.PluginLoader object at 0x10f12b860>"


# Generated at 2022-06-21 05:39:02.047184
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    plc = PluginLoadContext()
    deprecation = {'warning_text': 'Deprecated warning', 'removal_date': '2020-01-01', 'removal_version': '2.11'}

    # Tests when deprecation is None
    plc.record_deprecation('plugin1', None, None)
    assert plc.deprecated == False
    assert plc.removal_date == None
    assert plc.removal_version == None
    assert plc.deprecation_warnings == []

    # Tests when both removal_date and removal_version are specified
    plc.record_deprecation('plugin1', deprecation, None)
    assert plc.deprecated == True
    assert plc.removal_date == '2020-01-01'
    assert plc.removal_version

# Generated at 2022-06-21 05:39:05.705752
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    pl = PluginLoader('foo', 'bar', '', 'baz')
    assert (pl.has_plugin('ansible.plugins.action.foo')) == True
    


# Generated at 2022-06-21 05:39:19.785658
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():

    test_dir = os.path.join(os.path.dirname(__file__), 'units')
    filter_loader = Jinja2Loader('ansible.plugins.filter_loader', os_paths=[test_dir], package='ansible.plugins')
    test_plugin = filter_loader.all(path_only=True)
    assert test_plugin == [os.path.join(test_dir, 'test_filter_plugins.py')]

    test_plugin = filter_loader.all(class_only=True)
    assert test_plugin == [MockAnsibleModule, MockAnsibleModule]

    test_plugin = filter_loader.all()
    assert isinstance(test_plugin, list)
    assert len(test_plugin) == 2
    assert isinstance(test_plugin[0], MockAnsibleModule)

# Generated at 2022-06-21 05:39:24.665945
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    paths = ['/some/dir/does/not/exist.']
    which_loader = 'action' # good
    add_dirs_to_loader(which_loader, paths)



# Generated at 2022-06-21 05:39:27.916901
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    obj = PluginPathContext("path", "internal")
    assert obj.path == "path"
    assert obj.internal == "internal"


# Generated at 2022-06-21 05:39:31.067349
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    PL = PluginLoader('ModuleDeprecationWarning', 'ansible.plugins.cache.deprecation_warnings')
    value = PL.__getstate__()
    assert value == (None, None, None, None)

# Generated at 2022-06-21 05:39:43.282402
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():

    PATH_CACHE[:] = []
    MODULE_CACHE.clear()

    plugin_paths = ['/path/to/fakes/', '/path/to/fakes2/']

    for path in plugin_paths:
        assert path not in PATH_CACHE
    for path in plugin_paths:
        assert path not in PLUGIN_PATH_CACHE

    add_dirs_to_loader('module', plugin_paths)

    for path in plugin_paths:
        assert path in PATH_CACHE
    for path in plugin_paths:
        assert path in PLUGIN_PATH_CACHE

    module_loader.all()

    fake_module_paths = glob.glob("/path/to/fakes/*.py")
    fake2_module_paths = glob