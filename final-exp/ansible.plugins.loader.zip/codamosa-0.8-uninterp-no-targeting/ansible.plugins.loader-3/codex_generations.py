

# Generated at 2022-06-21 05:33:55.133264
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    loader = PluginLoader(package='ansible.plugins.filter', class_name='FilterModule', config={}, subdir=None)
    # Test with empty paths
    paths = []
    expected_result = ''
    result = loader.format_paths(paths)
    assert result == expected_result, 'Expected: %s, but got: %s' % (expected_result, result)
    # Test with one path
    paths = ['/path/to/plugins']
    expected_result = '/path/to/plugins'
    result = loader.format_paths(paths)
    assert result == expected_result, 'Expected: %s, but got: %s' % (expected_result, result)
    # Test with two paths
    paths = ['/path/to/plugins', '/path/to/more/plugins']
   

# Generated at 2022-06-21 05:34:07.803514
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():

    loader = PluginLoader('ansible.plugins.cache.memory', 'CacheModule', '', 'memory')
    loader._searched_paths = []
    assert(loader.format_paths([]) == '<none>')
    loader._searched_paths.append('/path/to/first/dir')
    assert(loader.format_paths(['/path/to/first/dir']) == '/path/to/first/dir')
    loader._searched_paths.append('/path/to/second/dir')
    assert(loader.format_paths(['/path/to/first/dir', '/path/to/second/dir']) == '/path/to/first/dir, /path/to/second/dir')



# Generated at 2022-06-21 05:34:10.794150
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    plc = PluginLoadContext()
    plc1 = plc.nope(exit_reason='invalid')
    assert plc1.exit_reason == 'invalid'
    assert plc1.resolved is False


    # Unit test for method redirect of class PluginLoadContext

# Generated at 2022-06-21 05:34:18.877285
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    jinja2_loader = Jinja2Loader('ansible.plugins.filter', 'FilterModule')
    assert jinja2_loader.subdir == 'filter_plugins'
    assert jinja2_loader.package == 'ansible.plugins'
    assert jinja2_loader.base_class == 'FilterModule'
    assert jinja2_loader.class_name == 'FilterModule'
    assert jinja2_loader.base_path == 'lib/ansible/plugins/filter_plugins'
    assert jinja2_loader.cache_key.startswith('jinja2')
    assert jinja2_loader.cache == {}


# Generated at 2022-06-21 05:34:27.136355
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    loader = PluginLoader(
        'Test',
        'ansible.plugins.test_util.test_plugin',
        C.DEFAULT_MODULE_PATH,
        'ansible.plugins.test_util.test_plugin.Foo',
        required_base_class='ansible.plugins.test_util.test_plugin.Base'
    )

    # Test get a normal module
    load_context = loader.get_with_context('normal_module')
    assert load_context.resolved
    assert load_context.name == 'normal_module'
    assert isinstance(load_context.object, NormalModule)

    # Test get an abstract module
    load_context = loader.get_with_context('abstract_module')
    assert load_context.resolved
    assert load_context.name == 'abstract_module'

# Generated at 2022-06-21 05:34:30.186470
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    ctx = PluginLoadContext()
    assert not ctx.resolved
    assert not ctx.deprecated
    assert ctx.exit_reason is None
    assert ctx.removal_version is None
    assert ctx.removal_date is None
    assert not ctx.deprecation_warnings


# Generated at 2022-06-21 05:34:41.688211
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    # Instantiate a plugin loader for filter plugins
    filter_loader = PluginLoader("FilterModule", "filter_plugins", C.DEFAULT_FILTER_PLUGIN_PATH)

    # Make sure the plugin loader has the right class name and plugin path
    assert filter_loader.class_name == "FilterModule"
    assert filter_loader.package == "filter_plugins"
    assert filter_loader.subdir == "filter_plugins"
    assert filter_loader.base_class == "FilterModule"

    assert not filter_loader.has_plugin("non_existent_plugin")
    assert filter_loader.has_plugin("ascii_native")
    assert filter_loader.has_plugin("ascii_native", collection_list=[])

    # Make sure to_bytes works
    filter_loader.get("ascii_native")

    #

# Generated at 2022-06-21 05:34:53.572533
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    class mockedDisplay(object):
        def __init__(self):
            self.warning_text = None
            self.date = None
            self.version = None
            self.collection_name = None
        
        def deprecated(self, warning_text, **kwargs):
            self.warning_text = '{0}{1}{2}{3}'.format(warning_text, ' ' if kwargs['date'] or kwargs['version'] else '', kwargs['removal_date'] if kwargs['removal_date'] else '', kwargs['removal_version'] if kwargs['removal_version'] else '')
            self.date = kwargs['removal_date']
            self.version = kwargs['removal_version']
            self.collection_name = kwargs['collection_name']

# Generated at 2022-06-21 05:34:57.108161
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    loader = PluginLoader('', '', '', '', '', '')
    # plugin_name is string
    assert isinstance(loader.find_plugin('example'), AnsiblePlugin)

    # plugin_name is string
    assert isinstance(loader.find_plugin('example', collection_list=[]), AnsiblePlugin)


# Generated at 2022-06-21 05:35:07.144459
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    with pytest.raises(TypeError):
        _ = get_with_context_result()

    with pytest.raises(TypeError):
        _ = get_with_context_result('context')

    with pytest.raises(TypeError):
        _ = get_with_context_result('context', None)

    wcr = get_with_context_result('context', None, 'value')
    assert wcr.context == 'context'
    assert wcr.result is None
    assert wcr.value == 'value'

# Generated at 2022-06-21 05:36:33.650543
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    dirs = [
        '/path/does/not/exist',
        '/path/does/not/exist/modules',
        '/path/does/not/exist/lookup_plugins',
        '/path/does/not/exist/action_plugins',
    ]
    for dir in dirs:
        plugin_dirs = os.getenv("ANSIBLE_" + dir.upper().replace("/", "_").replace("-", "_") + "_PLUGIN") or ''
        if plugin_dirs:
            plugin_dirs = plugin_dirs.split(os.pathsep)
        for plugin_dir in plugin_dirs:
            if plugin_dir.strip():
                add_all_plugin_dirs(plugin_dir)



# Generated at 2022-06-21 05:36:39.757109
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    plugin_loader = PluginLoader('action_plugins', 'ActionModule', namespace='ansible')
    assert plugin_loader.get_with_context('shell') is not None
    assert plugin_loader.get_with_context('module_that_does_not_exist') is None



# Generated at 2022-06-21 05:36:53.713139
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    j2_loader = Jinja2Loader('ansible.plugins.filter', 'FilterModule', 'ansible.plugins.filter.core')

    import ansible.plugins.filter.core
    assert j2_loader.package == 'ansible.plugins.filter'
    assert j2_loader.class_name == 'FilterModule'
    assert j2_loader.base_class == ansible.plugins.filter.core.FilterModule
    assert j2_loader.subdir == 'filter_plugins'
    assert j2_loader._paths == C.DEFAULT_FILTER_PLUGIN_PATH + C.JINJA2_EXTENSIONS_PATHS


# Generated at 2022-06-21 05:37:00.285608
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    class MockLoader(object):
        def __init__(self):
            self.calls = 0
            self.paths = []

        def add_directory(self, *args, **kwargs):
            self.calls += 1
            self.paths.append(args[0])

    mock_loader = MockLoader()
    globals()['MockLoader'] = MockLoader
    # Dummy loader name to test
    globals()['mock_loader'] = mock_loader
    add_dirs_to_loader('mock', ['path1', 'path2'])
    assert mock_loader.calls == 2
    assert mock_loader.paths == ['path1', 'path2']
    del globals()['mock_loader']
    del globals()['MockLoader']



# Generated at 2022-06-21 05:37:05.839235
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    pl = PluginLoader(package='ansible.plugins.test', searchpath=[u'abc', u'def'])
    assert pl.format_paths(pl._get_paths()) == "(u'abc', u'def')"

# Generated at 2022-06-21 05:37:13.646761
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Always make sure module_utils is in the path so that we can make sure
    # module_utils plugin loading is already set up.
    # This is especially important when running unit tests in parallel
    import ansible.module_utils
    ansible.module_utils.__name__  # pylint: disable=pointless-statement
    import ansible.module_utils.facts
    ansible.module_utils.facts.__name__  # pylint: disable=pointless-statement

    import ansible.module_utils.system.uname
    ansible.module_utils.system.uname.__name__  # pylint: disable=pointless-statement

    # Test that we add a valid path
    temp_directory = os.path.realpath(tempfile.mkdtemp())

# Generated at 2022-06-21 05:37:14.890038
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    assert True # TODO: implement your test here


# Generated at 2022-06-21 05:37:24.536744
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Create the plugin loader with a mocked collection resolver
    mock_resolver = mock.MagicMock()

    plugin_loader = plugin_loader_class(_init_resolver=mock_resolver)

    # Setup mock data
    collection_1_fq_name = 'my_namespace.my_collection_1'
    collection_1_name = 'my_collection_1'
    collection_1_version = '1.0.0'
    collection_1_path = '/my/path/my_namespace/my_collection_1/1.0.0'

    collection_2_fq_name = 'my_namespace.my_collection_2'
    collection_2_name = 'my_collection_2'
    collection_2_version = '1.0.0'

# Generated at 2022-06-21 05:37:34.508469
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test without dedupe and without path_only and without class_only
    # obj.all() is an iterator
    obj = PluginLoader('_', '_', package='_')
    obj._searched_paths = ['/usr/share/ansible/plugins']
    obj._get_paths = lambda: obj._searched_paths
    obj._module_cache = {}
    obj.package = 'ansible.plugins.action'
    obj.class_name = '_'
    obj.base_class = '_'
    obj.subdir = '_'
    obj._display_plugin_load = lambda *args: None
    obj._update_object = lambda *args: None
    obj._load_module_source = lambda *args: None
    obj._load_config_defs = lambda *args: None
   

# Generated at 2022-06-21 05:37:47.120568
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    test_loaders = get_all_plugin_loaders()
    test_loaders = [l for l in test_loaders if l[1].subdir]
    test_loaders_names = [l[0] for l in test_loaders]

    if '_MODULE_CACHE' in globals():
        global _MODULE_CACHE
        del _MODULE_CACHE

    class Test:
        pass
    test_loaders = [Test() for l in test_loaders]
    test_loaders = dict(zip(test_loaders_names, test_loaders))

    for name, loader in test_loaders.items():
        loader.subdir = name
        loader.add_directory = lambda path: plugin_path_cache_add(name, path)

# Generated at 2022-06-21 05:39:21.858119
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    # FIXME: It would be best if the path to this plugin was already set in some global config.
    #        This would ensure that no one could create one of these objects without getting its
    #        list of paths from that global config.
    loader = PluginLoader(
        'LibYAML',     # name of the plugin subsystem
        'yaml_loader', # name of the attribute to find inside of a plugin
        'YAMLLoader',  # name of the base class to instantiate with matching name
        'ansible.parsing.yaml.loader',  # path to the subsystem of plugins
        'ansible.parsing.yaml.loader.base.AnsibleBaseYAMLLoader',  # the full import path to the base class
    )
    assert loader is not None

# Test for PluginLoader.get()

# Generated at 2022-06-21 05:39:31.225348
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    executable = './testcase/fixture/ansible/module_utils/basic.py'

    # Properly load a custom module_utils
    # which should override the copy of the same module
    # that is part of Ansible's core.
    add_dirs_to_loader('module_utils', ['testcase/fixture'])
    module_utils = loader.path_dwim_relative(executable, 'ansible', 'module_utils')
    assert os.path.exists(module_utils)
    assert os.path.samefile(module_utils, executable)


# Generated at 2022-06-21 05:39:43.314105
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
  PL.all()
PL = get_C(PluginLoader)
PL

#<class 'ansible.plugins.loader.PluginLoader'>
# Instance of PluginLoader
PL = get_instance(PluginLoader)
PL
#<ansible.plugins.loader.PluginLoader object at 0x7f6e0e092080>
# Methods of PluginLoader
PL = get_methods_dict(PluginLoader)
PL
#{'all': <function test_PluginLoader_all at 0x7f6e0e0f3f28>, 'get_plugin': <function test_PluginLoader_get_plugin at 0x7f6e0e0f3ea0>, 'find_plugin': <function test_PluginLoader_find_plugin at 0x7f6e0e0f3f70>, 'get': <function test_PluginLoader_get

# Generated at 2022-06-21 05:39:55.265068
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # test case data
    fq_name = 'ansible.plugins.action.vsphere_guest'
    plugin_load_context = PluginLoadContext(plugin_name=fq_name)
    # test execution
    pl = PluginLoader(package='ansible.plugins.action', class_name='ActionModule', config_options=C.config._sections)
    pl.find_plugin_with_context(fq_name, plugin_load_context)
    assert plugin_load_context.resolved == True
    assert plugin_load_context.plugin_resolved_name == 'ansible.plugins.action.vsphere_guest'
    assert plugin_load_context.plugin_resolved_path == 'plugins/actions/vsphere_guest.py'
    # test case data

# Generated at 2022-06-21 05:40:06.563448
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    print()
    print("Starting test of PluginLoader.print_paths")
    path_cache_key = "test_collection_loader_print_paths_paths_cache"
    if path_cache_key in CACHE:
        del CACHE[path_cache_key]

    fixture = MockPluginLoader()
    fixture.print_paths()
    for path in CACHE[path_cache_key]:
        assert path.endswith('/cache')
        assert 'collection' not in path

    del CACHE[path_cache_key]
    # Test that in the presence of collections we get the path to the
    # collection's cache
    C.COLLECTIONS_PATHS = [
        os.path.join(util.ansible_test_data_path(), 'collection_loader_print')
    ]

# Generated at 2022-06-21 05:40:16.806992
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import module_loader, action_loader

    original_module_plugin_paths = copy.deepcopy(module_loader.plugin_paths)
    original_action_plugin_paths = copy.deepcopy(action_loader.plugin_paths)
    vars = combine_vars(loader=None, variables={})
    path = vars['ansible_config_dir']
    add_all_plugin_dirs(path)

    assert len(module_loader.plugin_paths) > len(original_module_plugin_paths)
    assert len(action_loader.plugin_paths) > len(original_action_plugin_paths)

# Generated at 2022-06-21 05:40:26.809128
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    plugin_loader = PluginLoader(
        'ansible.plugins.callback', 'CallbackModule', C.DEFAULT_CALLBACK_WHITELIST, 'callback_plugins')
    assert plugin_loader
    assert plugin_loader.package == 'ansible.plugins.callback'
    assert plugin_loader.base_class == 'CallbackModule'
    assert plugin_loader.subdir == 'callback_plugins'
    assert plugin_loader.class_name == 'CallbackModule'

    plugin_loader = PluginLoader(
        'ansible.plugins.module_utils', '', '', 'module_utils', 'ModuleUtilsLoader')
    assert plugin_loader
    assert plugin_loader.base_class is None
    assert plugin_loader.subdir == 'module_utils'
    assert plugin_loader.class_name == 'ModuleUtilsLoader'

    plugin_

# Generated at 2022-06-21 05:40:38.116334
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():

    # 1. A simple plugin loader with no plugin
    def get_test_dir():
        return os.path.join(os.path.dirname(__file__), 'unit/utils')

    dir_path = get_test_dir()
    reset_search_path(dir_path)

    loader = PluginLoader(package='test_plugin',
                          searchpath=[dir_path],
                          config={'test_config': 'test_plugin'})

    plugins = [plugin for plugin in loader.all()]
    assert plugins == []

    # 2. A simple plugin loader with two plugins
    plugin_dirs = [os.path.join(dir_path, path)
                   for path in ('plugins', 'plugins_base.py')]


# Generated at 2022-06-21 05:40:41.021962
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    p = PluginLoader('test_plugins', package='ansible.plugins.test_plugins')
    assert p



# Generated at 2022-06-21 05:40:49.513453
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    import os
    from collections import namedtuple

    PluginLoaderMock = namedtuple('PluginLoader', ['cached_module_objs', 'PLUGIN_PATH', '_searched_paths'])
    plugin_loader = PluginLoaderMock(cached_module_objs={},
                                     PLUGIN_PATH=os.path.join('/', 'ansible-collections', 'awx', 'awx', 'plugins', 'modules'),
                                     _searched_paths=[os.path.join('/', 'ansible-collections', 'awx', 'awx', 'plugins', 'modules')])

    # mock set state
    def __setstate__(self, data):
        super(self.__class__, self).__setstate__(data)

# Generated at 2022-06-21 05:41:43.344135
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    # This test doesn't do much other than check that there are no syntax errors or typos.
    # The method that is tested contains so little logic that testing for actual behavior is less
    # work than writing the test.
    from ansible.plugins.loader import get_with_context_result
    from ansible.cli import CLI
    from ansible.config.manager import ConfigManager
    from ansible.context import context

    plugin_loader = PluginLoader('test_loader_type', 'test_loader_package', 'test_loader_directory', 'test_loader_subdir')
    plugin_loader._is_subdir_enabled = lambda x: True
    plugin_loader._is_plugin_enabled = lambda x: True

    plugin_loader.get_plugin_class = lambda x: x


# Generated at 2022-06-21 05:41:48.349890
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    instance = PluginLoader('')
    result = instance.__getstate__()
    assert result is not None


# Generated at 2022-06-21 05:41:54.887591
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    test_object = PluginLoadContext()
    resolve_parm1 = "resolved_name"
    resolve_parm2 = "resolved_path"
    resolve_parm3 = "resolved_collection"
    resolve_parm4 = "exit_reason"
    exists_parm1 = "plugin_resolved_name"
    exists_parm2 = "plugin_resolved_path"
    exists_parm3 = "plugin_resolved_collection"
    exists_parm4 = "exit_reason"
    exists_parm5 = "resolved"
    does_not_exist_parm1 = "pending_redirect"
    assert not hasattr(test_object, does_not_exist_parm1)

# Generated at 2022-06-21 05:42:01.844998
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    fake_plugin = type('fake_plugin', (PluginLoader,), {})
    fake_plugin_obj = fake_plugin()
    orig_globals = globals()
    globals()['fake_plugin_obj'] = fake_plugin_obj
    ret = get_all_plugin_loaders()
    globals().clear()
    globals().update(orig_globals)
    assert ret == [('fake_plugin_obj', fake_plugin_obj)]



# Generated at 2022-06-21 05:42:04.500523
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    p1 = PluginLoadContext()
    assert p1.redirect('test name') is not None


# Generated at 2022-06-21 05:42:13.862794
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    """
    Some unit tests for the Jinja2Loader.all method
    """
    import tempfile
    import shutil
    import pkg_resources

    from ansible.utils.display import Display
    from ansible.errors import AnsibleError

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    lookup_dir = os.path.join(temp_dir, 'lookup_plugins')
    filter_dir = os.path.join(temp_dir, 'filter_plugins')
    test_dir = os.path.join(temp_dir, 'test_plugins')
    os.makedirs(lookup_dir)
    os.makedirs(filter_dir)
    os.makedirs(test_dir)

    # Create a couple test files
    filter_file1 = os.path.join

# Generated at 2022-06-21 05:42:16.500272
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    loader = PluginLoader('', '', C.DEFAULT_INTERNAL_PLUGIN_PATH, 'foo.bar')
    loader._add_directory('/tmp/ansible/test_dummy_plugindir')
    assert '/tmp/ansible/test_dummy_plugindir' in loader._get_paths()


# Generated at 2022-06-21 05:42:19.217546
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    # This test is only a placeholder, to keep 'make test' happy
    assert True

# Generated at 2022-06-21 05:42:25.565261
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    test_dir = os.path.dirname(os.path.abspath(__file__))
    test = test_dir + "/test/test_data/test_utils"
    add_all_plugin_dirs(test)
    assert "shell" in sys.modules
    assert "collection_loader" in sys.modules
    assert "Runner" in sys.modules
    assert "ActionBase" in sys.modules
    assert "ModuleUtils" in sys.modules
    assert "Connections" in sys.modules
    assert "FilterModule" in sys.modules
    assert "LookupModule" in sys.modules
    assert "ShellModule" in sys.modules



# Generated at 2022-06-21 05:42:30.894625
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    '''
    Unit test for method __contains__ of class PluginLoader
    '''
    loader = PluginLoader('test_path')
    assert False == (1 in loader)
    assert True == ('a' in loader.aliases)
