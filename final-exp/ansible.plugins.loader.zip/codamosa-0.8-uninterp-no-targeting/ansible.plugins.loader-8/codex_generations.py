

# Generated at 2022-06-21 05:34:44.472146
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    context = PluginLoadContext()

    redirect_name = 'ansible.builtin.return'
    original_name = 'ansible.builtin.command'

    context.original_name = original_name
    context.redirect(redirect_name)

    assert context.pending_redirect == redirect_name
    assert context.plugin_resolved_name is None
    assert context.plugin_resolved_path is None
    assert context.plugin_resolved_collection is None
    assert context.exit_reason == 'pending redirect resolution from {0} to {1}'.format(original_name, redirect_name)
    assert context.resolved == False


# Generated at 2022-06-21 05:34:50.286918
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    context = PluginLoadContext()
    assert context.resolved == False
    assert context.pending_redirect == None
    context2 = context.nope('test')
    assert context2 == context
    assert context2.resolved == False
    assert context2.pending_redirect == None
    assert context2.exit_reason == 'test'


# Generated at 2022-06-21 05:34:58.060926
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    '''
    Test case for plugin_loader.__getstate__.
    
    
    '''
    class IsolatedClassLoader(PluginLoader):
        def _init_paths(self):
            self.package = 'ansible_collections.my.my_fqcr.tasks'
            self.paths = []
            self.subdir = 'tasks'
            self.name = 'my_plugin_name'

    loader = IsolatedClassLoader()
    with pytest.raises(AnsibleError) as context:
        loader.__getstate__()
    exception = context.value
    assert exception
    assert 'AnsibleError' in exception.__class__.__name__
    
    

# Generated at 2022-06-21 05:35:06.347053
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    from ansible.plugins.loader import get_all_plugin_loaders
    loader_list = get_all_plugin_loaders()
    assert isinstance(loader_list, list)
    assert len(loader_list) > 0
    for item in loader_list:
        assert isinstance(item, tuple)
        assert len(item) == 2
        assert isinstance(item[0], str)
        assert isinstance(item[1], type)



# Generated at 2022-06-21 05:35:19.384011
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    import copy
    import types
    import sys

    from ansible.errors import AnsibleError

    from ansible.plugins.loader import PluginLoader
    from ansible.utils.collection_list import CollectionList
    def _mock_find_plugin(x, collection_list):
        return None
    def _mock__get_paths(x):
        return []

    # This is needed because the paramiko library used by ssh tries to access the os.urandom function during import
    def _mock__urandom(num):
        return "1234"

    # _get_paths must be mocked before the class is instantiated because it accesses the 'package' variable during import

# Generated at 2022-06-21 05:35:25.252355
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    ''' test get_with_context_result '''

    with pytest.raises(AttributeError):
        get_with_context_result('', '')

    with pytest.raises(AttributeError):
        get_with_context_result(10, '')

    with pytest.raises(AttributeError):
        get_with_context_result('', 10)



# Generated at 2022-06-21 05:35:36.971072
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    fs = frozenset
    # Test condition: When the value of deprecation is None
    # Testation: 1.Deprecation should be false
    #            2.No removal_date or removal_version should be added
    #            3.The warning message should be empty
    context = PluginLoadContext()
    if context.deprecated:
        assert False
    if context.removal_date:
        assert False
    if context.removal_version:
        assert False
    if context.deprecation_warnings:
        assert False
    context = context.record_deprecation('test_plugin', None, 'test_plugin')
    if context.deprecated:
        assert False
    if context.removal_date:
        assert False
    if context.removal_version:
        assert False

# Generated at 2022-06-21 05:35:37.584272
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert not get_shell_plugin()



# Generated at 2022-06-21 05:35:46.171540
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    my_loader = PluginLoader(
        'ansible.plugins',
        'PluginName',
        'AnsiblePlugin',
        'ansible.plugins.action_plugins'
    )
    for plugin in my_loader.all():
        print(type(plugin))


# Load modules for all plugin packages and cache the results
_PLUGIN_PACKAGES = {}
_PLUGIN_PATH_CACHE = {}



# Generated at 2022-06-21 05:35:57.281854
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    collection_name = 'ansible_namespace.collection_name'
    name = 'module_name'
    deprecation = {'warning_text': 'Module "module_name" has been deprecated', 'removal_version': '2.8'}
    plc = PluginLoadContext()
    plc.record_deprecation(name, deprecation, collection_name)
    assert plc.deprecated == True
    assert plc.removal_version == '2.8'
    assert plc.deprecation_warnings == ['Module "module_name" has been deprecated']


# Generated at 2022-06-21 05:36:32.203062
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # Path of test_data/
    test_data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_data')
    # Path of test_data/ansible/legac/
    test_data_dir_ansible_legac = os.path.join(test_data_dir, 'ansible/legacy')

    kwargs = {'subdir': 'filter_plugins'}
    jinja_loader = Jinja2Loader('ansible.legacy', 'filter', 'ansible.plugins.filter.core', 'FilterModule', 'AnsibleCore', **kwargs)

    # Jinja2Loader.find_plugin does not support searching for AnsibleCollection plugins
    with pytest.raises(AnsibleError) as e:
        jinja

# Generated at 2022-06-21 05:36:40.711185
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    plugin_loader = PluginLoader('./unit_tests/base_subdir', './unit_tests/my_subdir')
    assert plugin_loader.package == 'base_subdir'
    assert plugin_loader.subdir == 'my_subdir'
    plugin_loader.add_directory('./unit_tests/dir2')
    assert './unit_tests/dir2' in plugin_loader._get_paths()


# Generated at 2022-06-21 05:36:43.573731
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    assert ('connection_loader' in dict(get_all_plugin_loaders()))



# Generated at 2022-06-21 05:36:52.201938
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    loader = PluginLoader(package='ansible.plugins.mypackage', class_name='MyClass', config=dict(), subdir=None, aliases={})
    loader.find_plugin = Mock(return_value=('fake_module', 'fake_path'))
    fake_module = Mock()
    loader._module_cache = {('fake_module', 'fake_path'): fake_module}
    fake_module.MyClass = Mock(return_value='foo')
    assert loader.get('fake_name') == 'foo'
    assert fake_module.MyClass.call_args[0] == (loader,)



# Generated at 2022-06-21 05:36:55.618310
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    loader = PluginLoader('action_plugin', 'Actions', None, 'action_plugins')
    name = 'copy'
    collection_list = None
    result = loader.find_plugin(name, collection_list)
    assert isinstance(result, (AnsibleActionModule,))
    assert result._load_name == 'copy'


# Generated at 2022-06-21 05:37:07.156522
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    '''
    Exercises the find_plugin_with_context method of the PluginLoader class
    with a mock collection that has a single path to look in.  It is not
    mocked at all, so the actual plugin loading and searching is exercised.
    '''
    temp_dir = tempfile.mkdtemp()
    plugin_dir = os.path.join(temp_dir, 'a', 'ansible_collections', 'mycollection', 'my_plugins', 'module_utils')
    os.makedirs(plugin_dir)
    file_path = os.path.join(plugin_dir, 'mylib.py')
    with open(file_path, 'w') as mylib:
        mylib.write('some content')


# Generated at 2022-06-21 05:37:17.738047
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    assert ('ActionModuleLoader', ActionModuleLoader) in get_all_plugin_loaders()
    assert ('LookupModuleLoader', LookupModuleLoader) in get_all_plugin_loaders()
    assert ('FilterModuleLoader', FilterModuleLoader) in get_all_plugin_loaders()
    assert ('ModuleUtilLoader', ModuleUtilLoader) in get_all_plugin_loaders()
    assert ('ConnectionLoader', ConnectionLoader) in get_all_plugin_loaders()
    assert ('ShellLoader', ShellLoader) in get_all_plugin_loaders()
    assert ('StrategyLoader', StrategyLoader) in get_all_plugin_loaders()
    assert ('CacheModuleLoader', CacheModuleLoader) in get_all_plugin_loaders()
    assert ('CallbackLoader', CallbackLoader) in get_all_plugin_loaders()

# Generated at 2022-06-21 05:37:25.261285
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    test_path = "/test/path"
    test_path_b = to_bytes(test_path, errors="surrogate_or_strict")
    test_conditions = (
        (os.path.isdir, False, False, None),
        (os.path.isdir, True, False, None),
        (os.path.isdir, True, True, to_text("/test/path/test_subdir")),
    )
    test_results = []

# Generated at 2022-06-21 05:37:33.752266
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    from ansible_collections.ansible.netcommon.tests.unit.compat import unittest
    from ansible_collections.ansible.netcommon.plugins.loader import PluginLoader
    from ansible_collections.ansible.netcommon.tests.unit.modules.utils import set_module_args, exit_json, fail_json, AnsibleExitJson
    from ansible_collections.ansible.netcommon.tests.unit.modules.network.common.facts.test_facts import TestFacts
    import ansible_collections.ansible.netcommon.plugins.module_utils.network.common.facts.facts as test_facts
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.connection import Connection

# Generated at 2022-06-21 05:37:46.852630
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    j2Loader = Jinja2Loader('ansible.plugins.filter_loader', 'FilterModule')
    assert j2Loader.package == 'ansible.plugins.filter_loader'
    assert j2Loader.class_name == 'FilterModule'
    assert j2Loader.subdir == 'filter_plugins'
    assert j2Loader.base_class == 'FilterModule'
    assert j2Loader.paths == _PLUGIN_PATHS[j2Loader.subdir]

    j2Loader = Jinja2Loader('ansible.plugins.test_loader', 'TestModule')
    assert j2Loader.package == 'ansible.plugins.test_loader'
    assert j2Loader.class_name == 'TestModule'
    assert j2Loader.subdir == 'test_plugins'

# Generated at 2022-06-21 05:38:11.878489
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    # First test if we can have a state dict
    loader_obj = PluginLoader('')
    state_dict = loader_obj.__getstate__()
    assert len(state_dict) == 5
    assert '_searchpath' in state_dict
    assert '_modules' in state_dict
    assert '_caches' in state_dict
    assert '_name' in state_dict
    assert '_basedir' in state_dict
    
    

# Generated at 2022-06-21 05:38:22.489743
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plc = PluginLoadContext()
    assert plc.original_name == None
    assert plc.redirect_list == []
    assert plc.error_list == []
    assert plc.import_error_list == []
    assert plc.load_attempts == []
    assert plc.pending_redirect == None
    assert plc.exit_reason == None
    assert plc.plugin_resolved_path == None
    assert plc.plugin_resolved_name == None
    assert plc.plugin_resolved_collection == None
    assert plc.deprecated == False
    assert plc.removal_date == None
    assert plc.removal_version == None
    assert plc.deprecation_warnings == []
    assert plc.resolved == False
    assert plc._res

# Generated at 2022-06-21 05:38:26.400654
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    path = "/path/to/plugin/directory"
    internal = True
    PluginPathContext(path, internal)



# Generated at 2022-06-21 05:38:38.716678
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    # We can initialize a PluginLoader object with a package name.
    # In this case, it will look for plugins in "ansible/plugins/module_utils".
    assert PluginLoader('module_utils', 'module_utils') is not None
    assert PluginLoader('module_utils', 'module_utils', subdir='module_utils') is not None
    # In this case, it will look for plugins in "ansible/plugins/cliconf".
    assert PluginLoader('cliconf', 'CliConf') is not None
    # In this case, it will look for plugins in "ansible/plugins/filter/something".
    assert PluginLoader('filter', 'FilterModule', subdir='filter/something') is not None


# Generated at 2022-06-21 05:38:47.670739
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    load_context = PluginLoadContext()
    new_exit_reason = 'new exit_reason'
    load_context = load_context.nope(new_exit_reason)
    assert load_context.exit_reason == new_exit_reason
    assert load_context.resolved == False


    # unit test case for PluginLoadContext.redirect(redirect_name)

# Generated at 2022-06-21 05:38:55.037160
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    """Test function of PluginLoader.__getstate__."""

    # Create an instance of PluginLoader(AnsiblePlugin)
    # plugin_loader = PluginLoader(AnsiblePlugin)

    # Test raise NotImplementedError
    # plugin_loader.__getstate__()



# Generated at 2022-06-21 05:38:58.282708
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    context = PluginPathContext("path", True)
    assert context.path == "path"
    assert context.internal


# Generated at 2022-06-21 05:39:04.764968
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    collection_name = 'collection_name'
    deprecation = None
    name = 'name'
    load_context = PluginLoadContext()
    load_context.record_deprecation(name, deprecation, collection_name)
    assert load_context.deprecated == False

    # Test for `removal_date`
    collection_name = 'collection_name'
    deprecation = {'removal_date': 'invalid_removal_date'}
    name = 'name'
    load_context = PluginLoadContext()
    load_context.record_deprecation(name, deprecation, collection_name)
    assert load_context.deprecated == False

    # Test for `removal_version`
    collection_name = 'collection_name'

# Generated at 2022-06-21 05:39:18.876971
# Unit test for method print_paths of class PluginLoader

# Generated at 2022-06-21 05:39:31.713129
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    paths = ["/a/b/c/d/e/f",
             "/a/b/c/d/e",
             "/a/b/c/d",
             "/a/b/c",
             "/a/b",
             "/a"]
    expected = "['/a/b/c/d/e/f', '/a/b/c/d/e', '/a/b/c/d', '/a/b/c', '/a/b', '/a']"
    assert expected == PluginLoader.format_paths(paths)
    paths.append("/a/b/c/d/e/g")
    paths.append("/a/b/c/d/e/h")
    paths.append("/a/b/c/d/e/i")

# Generated at 2022-06-21 05:40:13.009926
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    monitor_plugin = PluginLoader('ansible.plugins.callback', 'CallbackModule', C.CALLBACK_PLUGINS)
    monitor_plugin.__setstate__({'_paths': {}})
    assert monitor_plugin.__getstate__() == {'_paths': {}}


# Generated at 2022-06-21 05:40:24.829554
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    pluginLoadContextObj = PluginLoadContext()
    pluginLoadContextObj.original_name = 'original'
    pluginLoadContextObj.plugin_resolved_name = 'resolved'
    pluginLoadContextObj.pending_redirect = 'pending-redirect'
    pluginLoadContextObj.exit_reason = 'exit'
    pluginLoadContextObj.resolved = True
    returnedObj = pluginLoadContextObj.nope('NOPE')
    assert pluginLoadContextObj is returnedObj
    assert pluginLoadContextObj.pending_redirect is None
    assert pluginLoadContextObj.exit_reason == 'NOPE'
    assert pluginLoadContextObj.resolved is False

# Generated at 2022-06-21 05:40:37.568348
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():

    # initialize class instance
    obj = PluginLoader('action_plugins', 'ActionModule', 'ansible.plugins.action')
    # get the path to this module
    this_module_path = os.path.dirname(os.path.realpath(__file__))
    obj._searched_paths = [os.path.join(this_module_path, 'data', 'action_plugins')]
    
    # Test with an invalid plugin.
    # Returns a PluginLoadContext with loading_failed=True, resolved=False and
    # plugin_resolved_path=None.
    # FIXME: this is probably an error (eg removed plugin)
    assert obj.find_plugin_with_context('invalid_plugin').loading_failed == True
    assert obj.find_plugin_with_context('invalid_plugin').resolved == False

# Generated at 2022-06-21 05:40:42.942121
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    plc = PluginLoadContext()
    assert plc.resolve('plc', 'path', 'collection', 'exit reason') == plc
    assert plc.resolved_fqcn == 'collection.plc'



# Generated at 2022-06-21 05:40:47.819240
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    from ansible.errors import AnsibleError
    from ansible.plugins import connection_loader, module_loader
    from ansible.plugins.loader import get_all_plugin_loaders

    loaders = get_all_plugin_loaders()
    for loader in loaders:
        if loader._collection:
            continue
        try:
            loader.get('shell', login_password='password')
        except AnsibleError:
            continue


# Generated at 2022-06-21 05:40:59.241996
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    from ansible.galaxy.collection_loader import GalaxyCollectionLoader
    from ansible.plugins.loader import collection_loader

    # TODO: move this test to a more appropriate place once we have a unit test for GalaxyCollectionLoader
    # This is to verify a known issue with collection lookup when a collection exists in both galaxy_path
    # and collection_path, however, the collection_path version has no plugins at all to test.
    # When the GalaxyCollectionLoader is refactored to use the new PluginLoader the test will be moved to
    # there
    galaxy_loader = GalaxyCollectionLoader()
    collection_loader.add_directory(DATA_PATH)
    all_collections = galaxy_loader.all()
    assert len(all_collections) == 1, "Only one collection should be found: %s" % len(all_collections)

    fixture_data

# Generated at 2022-06-21 05:41:09.433599
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    plugin_loader = PluginLoader('_dummy_plugins', '_dummy_base_class', 'ansible_collections.ns.coll.plugins')
    assert plugin_loader
    assert hasattr(plugin_loader, 'package')
    assert hasattr(plugin_loader, 'class_name')
    assert hasattr(plugin_loader, 'base_class')
    assert hasattr(plugin_loader, 'entry_point')
    assert hasattr(plugin_loader, '_searched_paths')
    assert hasattr(plugin_loader, 'plugins')
    assert hasattr(plugin_loader, 'aliases')
    assert hasattr(plugin_loader, '_module_cache')


# Generated at 2022-06-21 05:41:11.891797
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    pass

# Generated at 2022-06-21 05:41:15.627860
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    plugin_loader = PluginLoader('ansible.plugins.filter_loader', 'FilterModule')
    expected = 'ansible.plugins.filter_loader.FilterModule'
    assert repr(plugin_loader) == expected



# Generated at 2022-06-21 05:41:21.541987
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    config = C(DEFAULT_CONFIG_DATA.copy())
    config.initialize_plugin_configuration()
    loader = PluginLoader(config, 'module_utils', 'ModuleUtils')
    # Test for module_utils of type ModuleUtils
    # 1) Test for ansible_collections.namespace.collection_name.module_utils.name.
    plugin_load_context = loader.find_plugin_with_context('ansible_collections.namespace.collection_name.module_utils.name', collection_filter_re=None)
    assert plugin_load_context.resolved is True
    assert plugin_load_context.found is True
    # 2) Test for namespace.collection_name.module_utils.name.

# Generated at 2022-06-21 05:41:54.401709
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    import ansible.plugins.loader
    plugin_list = sorted(list(ansible.plugins.loader.all('test_plugins')))
    assert plugin_list[0] == 'always_true'
    assert plugin_list[1] == 'always_false'

    plugin_list = sorted(list(ansible.plugins.loader.all('test_plugins', class_only=True)))
    assert plugin_list[0] == 'always_true'
    assert plugin_list[1] == 'always_false'

    plugin_list = sorted(list(ansible.plugins.loader.all('test_plugins', path_only=True)))
    assert plugin_list[0].endswith('test_plugin_symlink.py')
    assert plugin_list[1].endswith('test_plugins/test_plugin.py')

    plugin

# Generated at 2022-06-21 05:42:04.010898
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    """
    Unit test for method get_with_context of class PluginLoader

    :return:
    """
    # Initialize test objects

# Generated at 2022-06-21 05:42:13.698382
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    ''' Unit test for constructor of class PluginLoader '''

    class ExamplePlugin(object):
        pass

    class Test(unittest.TestCase):
        '''Unit test class for plugin loader'''
        def setUp(self):
            ''' setUp method '''
            self.tp = PluginLoader("unit_test.test_plugin_loader", "ExamplePlugin", "example_plugins", "ex_")

        def tearDown(self):
            ''' tearDown method '''
            pass

        def test_constructor(self):
            ''' Checks constructor of class PluginLoader '''
            self.assertEqual(self.tp.package, "unit_test.test_plugin_loader")
            self.assertEqual(self.tp.class_name, "ExamplePlugin")

# Generated at 2022-06-21 05:42:20.724046
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    '''
    Unit test for method __getstate__ of class PluginLoader
    '''
    obj = PluginLoader()
    data = obj.__getstate__()
    assert data == {'_aliases': obj._aliases, '_module_cache': obj._module_cache}


# Generated at 2022-06-21 05:42:27.323625
# Unit test for function get_shell_plugin
def test_get_shell_plugin():

    import tempfile

    # Test with an error
    with tempfile.NamedTemporaryFile() as f:
        # We let the exception be raised
        get_shell_plugin(shell_type=None, executable=f.name)

