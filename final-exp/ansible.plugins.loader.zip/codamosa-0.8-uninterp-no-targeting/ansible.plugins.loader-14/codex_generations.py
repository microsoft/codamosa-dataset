

# Generated at 2022-06-21 05:34:33.980952
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    load_context = PluginLoadContext()

    assert(load_context.original_name is None)
    assert(load_context.redirect_list == [])
    assert(load_context.error_list == [])
    assert(load_context.load_attempts == [])
    assert(load_context.pending_redirect is None)
    assert(load_context.exit_reason is None)
    assert(load_context.plugin_resolved_path is None)
    assert(load_context.plugin_resolved_name is None)
    assert(load_context.plugin_resolved_collection is None)
    assert(not load_context.deprecated)
    assert(load_context.removal_date is None)
    assert(load_context.removal_version is None)

# Generated at 2022-06-21 05:34:42.044466
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    plugin_loader = PluginLoader('module_utils', '_ansible_module_utils', C.MODULE_UTILS_PATH, 'module_utils')

    assert plugin_loader is not None
    assert hasattr(plugin_loader, '_search_paths')
    assert hasattr(plugin_loader, '_searched_paths')

# Generated at 2022-06-21 05:34:53.787059
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    import tempfile
    import shutil
    import imp

    # Create a temporary dir and file
    tmpdir = tempfile.mkdtemp()
    pluginfile = open(os.path.join(tmpdir, 'test_plugin.py'), 'w')
    pluginfile.write('test_plugin = "fake"')
    pluginfile.close()
    pluginfile = open(os.path.join(tmpdir, 'test_plugin2.py'), 'w')
    pluginfile.write('test_plugin = "fake"')
    pluginfile.close()

    # Create the Jinja2Loader
    jinjaloader = Jinja2Loader('filter_plugins', 'ansible_filter_plugins', C.DEFAULT_ANSIBLE_FILTER_PLUGINS, 'filter_loader')

    # Add our tmpdir to the loader
    j

# Generated at 2022-06-21 05:34:58.672323
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    # test cases:
    #  - no entry
    #  - exists

    # prepare inputs
    globals_values = {}
    # test case: no entry
    # execute
    result = get_all_plugin_loaders()

    # assert
    assert([] == result)

    # test case: exists
    # prepare inputs
    globals_values['PluginLoader'] = PluginLoader
    ext_loader = PluginLoader('ext_loader', '', '')
    globals_values['ext_loader'] = ext_loader

    # execute
    result = get_all_plugin_loaders()

    # assert
    assert(sorted([('ext_loader', ext_loader)]) == sorted(result))



# Generated at 2022-06-21 05:35:00.254636
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    assert  True

# Generated at 2022-06-21 05:35:03.067954
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():

    with pytest.raises(TypeError):
        get_with_context_result()



# Generated at 2022-06-21 05:35:11.800291
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    import os
    import sys
    import inspect
    import _collections_abc

    # Restore module state and data
    # This will fail if test was run under CPython
    if not isinstance(sys.modules.get('ansible_collections'), dict):
        import ansible_collections

        # Restore ansible_collections
        sys.modules['ansible_collections'] = ansible_collections

        # Restore ansible_collections._collection_finder and _collection_finder_cache
        ansible_collections._collection_finder = ansible_collections.__ansible_collections_test_module__._collection_finder
        ansible_collections._collection_finder_cache = ansible_collections.__ansible_collections_test_module__._collection_finder_cache

        # Restore ansible_collections.__ansible

# Generated at 2022-06-21 05:35:21.602814
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # Test Parameter: 'name'
    valid_name = 'name'
    invalid_name1 = ''
    invalid_name2 = None
    invalid_name3 = '~name'

    # Test Parameter: 'collection_list'
    valid_collection_list = []
    invalid_collection_list1 = None
    invalid_collection_list2 = ['~collection']

    # Testing valid values for parameter: 'name'
    valid_values = (valid_name,)
    for valid_value in valid_values:
        # Test Parameter: 'collection_list'
        # NOTE: this is wrong way to detect collection, see note above for example
        invalid_collection_list3 = ['collection.name']
        # Unit Tests

# Generated at 2022-06-21 05:35:28.420965
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    # Initialize the class
    obj = PluginLoader(
        'ansible.plugins.filter.core',
        'FilterModule',
        'ansible.plugins.filter',
        required_base_class='FilterModule'
    )

    # Call all with the parameters below.
    # A list of all Plugin modules should be returned
    result = obj.all()

    # Assert that the result actually is a list
    assert isinstance(result, list)
    # Assert that the result is reversed
    assert not result == list(reversed(result))
    # Assert that entries in the list are actually Plugin modules
    for i in result:
        assert isinstance(i, FilterModule)



# Generated at 2022-06-21 05:35:34.441451
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    test_loader = PluginLoader('test_collection.test_utils', 'TestClass')
    assert isinstance(test_loader, PluginLoader)
    assert test_loader.package == 'test_collection.test_utils'
    assert test_loader.subdir == ''
    assert test_loader.class_name == 'TestClass'
    assert test_loader.base_class is None



# Generated at 2022-06-21 05:36:20.072590
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    plc = PluginLoadContext()
    plc.original_name = 'original_name'
    plc.redirect_list = ['a', 'b', 'c', ]
    plc.error_list = ['e', 'f', 'g', ]
    plc.load_attempts = ['i', 'j', 'k', ]
    plc.exit_reason = 'l'
    plc.deprecated = True
    plc.removal_date = 'date'
    plc.removal_version = 'version'
    plc.deprecation_warnings = ['a', 'b', 'c', ]
    plc.resolved = True
    plc.plugin_resolved_name = 'plugin_resolved_name'

# Generated at 2022-06-21 05:36:32.230159
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    """Test PluginLoader.find_plugin_with_context"""

    # Verify that find_plugin_with_context works with bare module names
    for this_suffix in ('', '.foo', '.bar'):
        for this_name in ('foo', 'foo.bar', 'foo.bar.baz'):
            loader = PluginLoader("ansible.plugins.test_loader", "TestLoader", "", "")
            this_context = loader.find_plugin_with_context(this_name + this_suffix)
            assert this_context.resolved and this_context.plugin_resolved_name == "foo"

    # Verify that find_plugin_with_context works with fqcn

# Generated at 2022-06-21 05:36:33.173580
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
  pass

# Generated at 2022-06-21 05:36:41.091776
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    r = PluginLoadContext()
    assert not r.resolved
    assert not r.resolved_fqcn
    assert r.pending_redirect is None
    r.resolve('hi', 'hi_path', 'hi_collection', 'hi_reason')
    assert r.resolved
    assert r.resolved_fqcn == 'hi_collection.hi'
    assert r.pending_redirect is None



# Generated at 2022-06-21 05:36:43.818324
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    obj1 = GetWithContextResult()

    # Test that the default constructor is correct
    assert obj1.result is None
    assert obj1.context == {}

    obj2 = GetWithContextResult()

    # Test that the constructor with args is correct
    obj2.result = "test"
    obj2.context = {"test": "test"}
    assert obj2.result == "test"
    assert obj2.context == {"test": "test"}



# Generated at 2022-06-21 05:36:47.154661
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    """
    Test case for method all of class Jinja2Loader
    """
    loader = PluginLoader('ansible.plugins.test_plugin', C.get_config_value('DEFAULT_TEST_PLUGIN_PATH', ['test_plugins']), 'ModuleTestCase', 'test')
    assert(isinstance(loader.all(), list))


# Generated at 2022-06-21 05:36:55.539021
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    """ PluginLoader: test the all method """

    # get the all method of PluginLoader
    all_func = getattr(PluginLoader, 'all')
    # get the doc of all method
    all_doc = getattr(all_func, '__doc__')

    # verify the doc of all method
    assert 'Iterator returning all plugins of the type as specified in the constructor.' in all_doc

    # get all the PlaybookInventoryPlugin classes
    all_pip_classes = list(all_func(PluginLoader('ansible.plugins.inventory', 'PlaybookInventoryPlugin'), class_only=True))

    # assert count of all the PlaybookInventoryPlugin classes
    assert len(all_pip_classes) > 0

    # get all the ActionModule classes

# Generated at 2022-06-21 05:36:58.598684
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    # TODO: implement this
    import unittest
    unittest.fail()


# Generated at 2022-06-21 05:37:05.562643
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    """Test PluginLoader.__repr__"""
    class_instance = PluginLoader(
                '_TestClass_', 
                '_TestClass__attr_1', 
                '_TestClass__attr_2', 
                ['_TestClass__attr_3'], 
                ['_TestClass__attr_4']
            )
    assert repr(class_instance) == "<PluginLoader _TestClass_ '_TestClass__attr_1' '_TestClass__attr_2' ['_TestClass__attr_3'] ['_TestClass__attr_4']>"


# Generated at 2022-06-21 05:37:13.583467
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    base_path = '/usr/share/ansible_collections/foo/bar/plugins'
    files = [
        'filter_plugins/file_with_filter.py',
        'test_plugins/file_with_test.py',
        'filter_plugins/another_file_with_filter.py',
        'test_plugins/another_file_with_test.py',
    ]
    all_files = [os.path.join(base_path, filename) for filename in files]

    mock_load_source = MagicMock()
    mock_load_source.return_value = os.path.join(base_path, files[0])
    mock_display = MagicMock()

    # overload _display_plugin_load to ignore the call in this test
    old_display_plugin_load = Jinja2Loader._display

# Generated at 2022-06-21 05:38:11.547577
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # setup
    obj = AnsibleModule(argument_spec={
        'collection_list': {'type': 'list'},
    })
    test_plugin_loader = Jinja2Loader(package='ansible.plugins.action', class_name='ActionBase', namespace='ansible.plugins.action', config=None, subdir='plugins')
    test_plugin_loader.add_directory(os.path.join(os.path.dirname(__file__), u'sample_plugins'))
    test_plugin_loader.get = Mock(side_effect=lambda *args, **kwargs: test_plugin_loader.get(*args, **kwargs))
    test_plugin_loader.find_plugin = Mock(side_effect=lambda *args, **kwargs: test_plugin_loader.find_plugin(*args, **kwargs))

    test

# Generated at 2022-06-21 05:38:21.344218
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # pylint: disable=protected-access
    for name, obj in get_all_plugin_loaders():
        obj.clear()
        obj._directories = []
    test_dir = '/does/not/exist'
    assert len(get_all_plugin_loaders()) == 6
    add_all_plugin_dirs(test_dir)
    assert len(get_all_plugin_loaders()) == 6
    for name, obj in get_all_plugin_loaders():
        obj._directories = []
    test_dir = '/'
    assert len(get_all_plugin_loaders()) == 6
    add_all_plugin_dirs(test_dir)
    assert len(get_all_plugin_loaders()) == 6
    for name, obj in get_all_plugin_loaders():
        obj

# Generated at 2022-06-21 05:38:26.092557
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    context = PluginPathContext('/home/ansible/plugins', True)
    assert context is not None
    assert context.path == '/home/ansible/plugins'
    assert context.internal is True


# Generated at 2022-06-21 05:38:32.336135
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    context = PluginLoadContext()
    context.record_deprecation(name='test', deprecation={'warning_text':'test text'}, collection_name='test collection')
    assert context.deprecated == True


# Generated at 2022-06-21 05:38:37.513888
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    # get_all_plugin_loaders should return a list of tuples with plugin type (type) as first entry and loader as second one
    assert isinstance(get_all_plugin_loaders(), list)
    for plugin_type, loader in get_all_plugin_loaders():
        assert isinstance(plugin_type, string_types)
        assert isinstance(loader, PluginLoader)



# Generated at 2022-06-21 05:38:50.942083
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    def _get_tested(namespace):
        module = AnsibleCollectionLoader().load_collection_to_memory('testcoll', '/nonexistent')
        return getattr(module, namespace)
    all_filter = _get_tested('FilterModule').all()
    # reverse the list to duplicate how the calling code would expect to see it
    all_filter.reverse()
    assert len(all_filter) == 3

    # ensure the templar code can find the filter in the list of all filters
    new_filter = _get_tested('FilterModule').get('uniq')
    assert new_filter is not None

    # test multiple args and kwargs
    all_filter = _get_tested('TestModule').all('foo', bar='baz')


# Generated at 2022-06-21 05:38:57.466500
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert get_shell_plugin(shell_type='sh', executable='/bin/sh')
    assert get_shell_plugin(shell_type='sh')
    assert get_shell_plugin(executable='/bin/sh')


# Generated at 2022-06-21 05:38:58.821698
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    assert False, 'Not implemented'

# Generated at 2022-06-21 05:39:06.239144
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    context = PluginLoadContext()
    context.resolve("resolved_name",None,None,"exit_reason")
    assert context.plugin_resolved_name == "resolved_name"
    assert context.plugin_resolved_path == None
    assert context.plugin_resolved_collection == None
    assert context.exit_reason == "exit_reason"
    assert context.resolved == True

# Generated at 2022-06-21 05:39:17.488033
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():

    loader = LoaderModule()
    assert loader.format_paths(['/a', '/b']) == ': /a, /b'
    assert loader.format_paths(['/a/b', '/c/d']) == ': /a/b, /c/d'
    assert loader.format_paths(['/a', '/b/c']) == ': /a, /b/c'
    assert loader.format_paths(['/a/b', '/a/c']) == ': /a/{b,c}'



# Generated at 2022-06-21 05:39:54.210958
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    load_context = PluginLoadContext()
    load_context.original_name = 't2'
    load_context = load_context.resolve('t1', '/path/to/t1.py', 'my.collection', 'success')
    assert load_context.original_name == 't2'  # no change
    assert load_context.redirect_list == []
    assert load_context.error_list == []
    assert load_context.import_error_list == []
    assert load_context.load_attempts == []
    assert load_context.pending_redirect is None
    assert load_context.exit_reason == 'success'
    assert load_context.plugin_resolved_path == '/path/to/t1.py'
    assert load_context.plugin_resolved_name == 't1'

# Generated at 2022-06-21 05:39:59.671886
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plc = PluginLoadContext()
    assert plc.original_name == None
    assert plc.redirect_list == []
    assert plc.error_list == []
    assert plc.import_error_list == []
    assert plc.load_attempts == []
    assert plc.pending_redirect == None
    assert plc.exit_reason == None
    assert plc.plugin_resolved_path is None
    assert plc.plugin_resolved_name is None
    assert plc.plugin_resolved_collection is None
    assert plc.deprecated is False
    assert plc.removal_date is None
    assert plc.removal_version is None
    assert plc.deprecation_warnings == []
    assert plc.resolved is False


# Generated at 2022-06-21 05:40:05.193070
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    from ansible.plugins.loader.pscp_plugin import PscpPluginLoader
    from ansible.plugins.loader.connection_plugin import ConnectionPluginLoader

    plugin_loader = PscpPluginLoader()
    plugin_loader.print_paths()

    plugin_loader = ConnectionPluginLoader()
    plugin_loader.print_paths()

    print('\nPluginLoader.print_paths() tests passed')


# Generated at 2022-06-21 05:40:16.808006
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    plc = PluginLoadContext()

    assert not plc.redirect
    assert not plc.resolved
    assert not plc.resolved_fqcn

    plc.resolve('name', 'path', 'collection', 'exit_reason')

    assert plc.plugin_resolved_name == 'name'
    assert plc.plugin_resolved_path == 'path'
    assert plc.plugin_resolved_collection == 'collection'
    assert plc.exit_reason == 'exit_reason'
    assert plc.resolved
    assert plc.resolved_fqcn == 'collection.name'

    plc.resolve('name', 'path', '', 'exit_reason')

    assert plc.plugin_resolved_name == 'name'

# Generated at 2022-06-21 05:40:26.779959
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    ''' test add_all_plugin_dirs() '''
    ldr = PluginLoader('test_type_for_unittest', 'test_dir', 'test_package', 'test_class.py')
    pb = PluginLoader('test_type_for_unittest', '', 'test_package', 'test_class.py')
    globals()['test_type_for_unittest'] = ldr
    plugin_path = os.path.expanduser(os.path.join(os.path.dirname(__file__), u'test_add_all_plugin_dirs'))
    assert ldr.directories == [to_text(plugin_path, errors='surrogate_or_strict')], \
        "Expected plugin_path not found for PluginLoader: %s" % plugin_path


# Generated at 2022-06-21 05:40:36.389727
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    plugin_loader = PluginLoader(package="ansible.plugins.test_plugins")
    plugin_loader.add_directory(test_data_path)
    assert len(plugin_loader._directories) == 1
    # Test on duplicate entries.
    plugin_loader.add_directory(test_data_path)
    assert len(plugin_loader._directories) == 1
    # Test on invalid type.
    with pytest.raises(Exception):
        plugin_loader.add_directory(1)

# Note: pytest is unable to test class base PluginLoader as it is an abstract class and hence not instantiated

# Generated at 2022-06-21 05:40:47.413650
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type='sh')
    assert shell.SHELL_FAMILY == 'sh'
    shell = get_shell_plugin(shell_type='csh')
    assert shell.SHELL_FAMILY == 'csh'
    shell = get_shell_plugin(shell_type='fish')
    assert shell.SHELL_FAMILY == 'fish'
    shell = get_shell_plugin(shell_type='powershell')
    assert shell.SHELL_FAMILY == 'powershell'
    shell = get_shell_plugin(shell_type='sh', executable='/bin/bash')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/bash'



# Generated at 2022-06-21 05:40:48.445834
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    assert True



# Generated at 2022-06-21 05:40:59.573145
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    loader = PluginLoader('', '', '', 'connection')
    path = '/home/runner/work/ansible/ansible/lib/ansible/plugins/connection/chroot.py'
    name = 'chroot'
    obj = 'Chroot'
    redirect_list = []
    obj = loader._load_module_source(name, path)
    loader._update_object(obj, name, path, redirect_list)
    assert '_original_path' in dir(obj) and obj._original_path == path
    assert '_load_name' in dir(obj) and obj._load_name == name
    assert '_redirected_names' in dir(obj) and obj._redirected_names == redirect_list
    assert '_load_name' in dir(obj) and obj._load_name == name

# Generated at 2022-06-21 05:41:10.428828
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    """Test for method `__setstate__` of class `PluginLoader` """

    Display().display("Starting test for method `__setstate__` of class `PluginLoader` ")

    # Starting test for method `__setstate__` of class `PluginLoader` 

    # Test for method `__setstate__` of class `PluginLoader` 
    #   Test that __setstate__ can restore the class.
    display.display("Test that __setstate__ can restore the class.")

    #   __setstate__ with missing keys
    #       Test that __setstate__ can restore with missing values.
    display.display("Test that __setstate__ can restore with missing values.")
    #   Test that __setstate__ can restore with invalid values.
    display.display("Test that __setstate__ can restore with invalid values.")
    #   Test that __

# Generated at 2022-06-21 05:42:14.577756
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    import ansible.plugins.test.loader  # noqa
    import ansible.plugins.filter.loader  # noqa
    j2_loader = Jinja2Loader('plugins.test', 'TestModule', 'ansible.plugins.test')

    assert j2_loader._aliases == []
    assert j2_loader._searched_paths == ['plugins/test']
    assert j2_loader._package == 'ansible.plugins.test'
    assert j2_loader._subdir == 'test_plugins'
    assert j2_loader._paths == ['plugins/test']
    assert j2_loader.package == 'ansible.plugins.test'
    assert j2_loader.top_level_path == 'plugins/test'
    assert j2_loader.class_name == 'TestModule'
    assert j2_loader

# Generated at 2022-06-21 05:42:19.644889
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    result = get_with_context_result("action plugin", "ThisTest", "a", "b", "c", "d")
    assert result == "action plugin is a b c d"



# Generated at 2022-06-21 05:42:26.978510
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    # This is a test to ensure that the constructor of class PluginLoader
    # works properly and does not raise any exceptions.
    #
    # This test isn't useful to verify the correctness of the code of
    # constructor, as it is not possible to write tests that verify that
    # the code of constructor is not broken.  Rather, this test ensures
    # that the code of constructor is tested regularly.  This prevents
    # the code of constructor from being broken by a casual change in
    # the code base.

    pl = PluginLoader(
        'ActionModule',
        'ansible.plugins.action',
        'ActionModule',
        'action_plugins',
        required_base_class='ActionBase'
    )

    assert pl
    assert pl.package == 'ansible.plugins.action'
    assert pl.class_name == 'ActionModule'


# Generated at 2022-06-21 05:42:32.296164
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    obj = PluginLoader(base_class=None, package=None, searchpath=None, class_name=None)
    # Testing if exceptions raised in the try block are caught by the except block
    with pytest.raises(AttributeError):
        obj.__getstate__()
