

# Generated at 2022-06-21 05:35:58.802944
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    '''
    The testbed for the unit tests, setUp is run before every test_ method
    '''
    p = PluginLoader()
    p.add_directory(os.path.join(os.path.dirname(__file__), '..', '..', 'lib', 'ansible', 'modules'), with_subdir=True)

    # Test 1: Can we find the ping module?
    assert p.find_plugin("ping")

    # Test 2: Can we find the shell module?
    assert p.find_plugin("shell")

    # Test 3: Can we find a missing module?
    assert p.find_plugin("xyzzy") == None

    # Test 4: Does module_utils.template_filters exist?
    assert p.find_plugin("module_utils.template_filters")

    # Test 5: Does module

# Generated at 2022-06-21 05:36:04.440563
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    fixtures = {}
    params = []
    res = False

    results = [True, False]
    for arg in results:
        load_result = PluginLoader.all(results)
        if load_result != arg:
            res = False
    assert res


# Generated at 2022-06-21 05:36:06.753452
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    # Just dummy test to see if the function is called or not
    get_shell_plugin()



# Generated at 2022-06-21 05:36:11.663157
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
  myobj = Jinja2Loader()

# Generated at 2022-06-21 05:36:19.905546
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    all_filters = filter_loader.all()
    plugin_names = [o._load_name for o in all_filters]
    assert 'to_bool' in plugin_names
    assert 'to_yaml' in plugin_names
    assert 'ipaddr' in plugin_names

    # We don't want to add a new dependency on Jinja2, so we'll just make a dummy class as an example
    class Foo:
        pass

    class FooLoader(PluginLoader):
        class_name = 'Plugin'
        base_class = 'Foo'

    foo_loader = FooLoader('/foo', 'foo.plugins')
    foo_loader._module_cache = {'/foo/bar.py': type('Bar', (Foo,), {})}

    all_foos = foo_loader.all()

# Generated at 2022-06-21 05:36:24.616731
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # FIXME: Add your test here
    dummy = PluginLoader(package='ansible.plugins.connection', class_name='ConnectionBase')
    dummy.find_plugin(name='ssh', collection_list=None)

# Generated at 2022-06-21 05:36:31.827783
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    pl = PluginLoader("x", "y", "z", package="ansible.plugins.testplugin")
    pl._searched_paths = [to_bytes(u'/path/to/dir1'), to_bytes(u'/path/to/dir2')]
    assert pl.format_paths(pl._searched_paths) == 'ansible.plugins.testplugin.y.z.dir1:ansible.plugins.testplugin.y.z.dir2'


# Generated at 2022-06-21 05:36:40.791986
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    '''
    Unit test for method find_plugin_with_context of class PluginLoader
    '''
    plugin_loader = PluginLoader("ansible.plugins.shell_plugins")
    name = 'script'
    collection_list = None
    plugin_result = plugin_loader.find_plugin_with_context(name,collection_list=collection_list)
    plugin_result.resolved
    os.path.isfile(plugin_result.plugin_resolved_path)



# Generated at 2022-06-21 05:36:43.060407
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    assert True # TODO: implement your test here


# Generated at 2022-06-21 05:36:54.059187
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    inst = PluginLoadContext()
    assert inst.plugin_resolved_name is None
    assert inst.plugin_resolved_path is None
    assert inst.exit_reason is None
    assert inst.pending_redirect is None
    assert not inst.deprecated
    assert inst.removal_date is None
    assert inst.removal_version is None
    assert inst.deprecation_warnings == []
    assert not inst.resolved

    inst.resolve('name', 'path', 'collection', 'exit_reason')
    assert inst.plugin_resolved_name == 'name'
    assert inst.plugin_resolved_path == 'path'
    assert inst.plugin_resolved_collection == 'collection'
    assert inst.exit_reason == 'exit_reason'
    assert inst.pending_redirect is None
   

# Generated at 2022-06-21 05:37:33.464130
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plc = PluginLoadContext()
    assert plc.original_name is None
    assert not plc.redirect_list
    assert not plc.error_list
    assert not plc.import_error_list
    assert not plc.load_attempts
    assert plc.pending_redirect is None
    assert plc.plugin_resolved_path is None
    assert plc.plugin_resolved_name is None
    assert plc.exit_reason is None
    assert not plc.deprecated
    assert plc.removal_date is None
    assert plc.removal_version is None
    assert not plc.deprecation_warnings
    assert not plc.resolved


# Generated at 2022-06-21 05:37:35.126958
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    obj = PluginLoadContext()
    assert(obj.nope('fail') == obj)
    assert(obj.pending_redirect == None)
    assert(obj.exit_reason == 'fail')
    assert(obj.resolved == False)


# Generated at 2022-06-21 05:37:38.526271
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # FIXME: Write a unit test for find_plugin
    raise NotImplementedError()


# Generated at 2022-06-21 05:37:45.389707
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # Setup loader
    loader = Jinja2Loader()
    # Call function under test
    result = loader.find_plugin('foo')
    # Check if result is an instance of the expected type
    assert isinstance(result, tuple)
    # Check if tuple has the expected number of elements
    assert len(result) == 3
    # Check if expected tuple values match
    assert result == (None, False, None)
    return



# Generated at 2022-06-21 05:37:47.217849
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    """Test the success case of PluginLoader"""
    assert PluginLoader.__contains__('myname') is not None

# Generated at 2022-06-21 05:37:55.644764
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    def test_func():
        pass

    globals()['test_func'] = test_func
    # also all the module level PluginLoaders
    assert sorted([name for (name, obj) in get_all_plugin_loaders()]) == ['action', 'cache', 'connection', 'cliconf', 'doc_fragments', 'filter', 'inventory', 'lookup', 'netconf', 'terminal', 'callback', 'shell', 'strategy', 'vars', 'test_func']



# Generated at 2022-06-21 05:38:08.165633
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():

    # see below for the data this helper class will return and what we expect
    class FakePluginLoader(object):
        def __init__(self, data):
            self.data = data

        def all(self, *args, **kwargs):
            return self.data

    # This data is used to populate the FakePluginLoader class.
    # In this example the list is the files, and each file contains the list of plugins it defines.
    # The calling code will have already deduped the jinja2 plugin names, we just need to make sure
    # the ordering will not be a problem.  Looking at how calling code works, it adds the jinja2 plugins
    # from one file to a dict, and then adds the jinja2 plugins from the next file, overwriting any
    # jinja2 plugins it encounters with the same name (encaps

# Generated at 2022-06-21 05:38:10.891196
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    plugin_loaders = get_all_plugin_loaders()
    assert isinstance(plugin_loaders, list)
    for name, obj in plugin_loaders:
        assert isinstance(name, str)
        assert isinstance(obj, PluginLoader)


# Generated at 2022-06-21 05:38:19.783253
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # create object
    jl = Jinja2Loader('filter_loader', 'ansible.plugins.filter.foo')
    returned = jl.find_plugin('foo')
    assert returned[0] == 'filter_loader'
    assert returned[1] == 'ansible/plugins/filter/foo.py'
    assert returned[2] is True
    assert returned[3] == 'foo.py'
    assert returned[4] == 'foo'
    assert returned[5] == 'ansible/plugins/filter/foo.py'
    assert returned[6] == 'foo'


# Generated at 2022-06-21 05:38:20.356120
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
  pass

# Generated at 2022-06-21 05:38:55.247005
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    """Test the function add_dirs_to_loader accepts a list of paths and adds the paths to the loader."""
    # Test case 1: Check to see if the path is added to the loader
    old_paths = getattr(sys.modules[__name__], '%s_loader' % 'action')._get_paths()
    test_path = '/tmp/test/path'
    add_dirs_to_loader('action', [test_path])
    new_paths = getattr(sys.modules[__name__], '%s_loader' % 'action')._get_paths()
    assert new_paths==old_paths + [test_path]
    # Test case 2: Verify that the path is not added if it already exists

# Generated at 2022-06-21 05:39:01.019939
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    for typ in ('action_plugin', 'become_plugin', 'cache_plugin', 'callback_plugin', 'connection_plugin', 'filter_plugin', 'inventory_plugin', 'lookup_plugin', 'shell_plugin', 'test_plugin', 'vars_plugin'):
        test_obj = PluginLoader(typ, package='ansible.plugins')
        test_obj.print_paths()


# Generated at 2022-06-21 05:39:10.945330
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    from .plugin_loader_test_case import mock_get_all_plugin_loaders

    def se_find_plugin_mock(sc, plugin_name, collection_list=()):
        if plugin_name == 'does_not_exist':
            raise AnsibleError('This is a test failure')
        elif plugin_name == 'resolve_failure':
            # This is a bit of a hack as the first argument should be a PluginLoader, but we don't have one
            # here.  There are probably better exceptions we can use to return from this method.
            raise TypeError('Unable to resolve plugin')

        name, suffix = plugin_name.rsplit('.', 1)
        if suffix == 'lookup':
            return 'ansible.plugins.lookup.%s' % name

# Generated at 2022-06-21 05:39:22.459440
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    cntx = PluginLoadContext()
    assert cntx.original_name is None
    assert cntx.redirect_list == []
    assert cntx.error_list == []
    assert cntx.import_error_list == []
    assert cntx.load_attempts == []
    assert cntx.pending_redirect is None
    assert cntx.exit_reason is None
    assert cntx.plugin_resolved_path is None
    assert cntx.plugin_resolved_name is None
    assert cntx.plugin_resolved_collection is None
    assert cntx.deprecated is False
    assert cntx.removal_date is None
    assert cntx.removal_version is None
    assert cntx.deprecation_warnings == []
   

# Generated at 2022-06-21 05:39:33.351136
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    name = 'name'
    collection_name = 'collection'
    deprecation_with_warning_text = {'warning_text': 'Warning'}
    deprecation_with_no_warning_text = {}
    deprecation_with_removal_date = {'removal_date': '2020-01'}
    deprecation_with_removal_version = {'removal_version': '2.10'}
    deprecation_with_removal_date_and_version = {'removal_date': '2020-01', 'removal_version': '2.10'}
    collection_versions = {
        'latest': '1.0.0'
    }

    plugin_load_context = PluginLoadContext()

# Generated at 2022-06-21 05:39:40.092030
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    import pytest
    test_shell = "sh"
    shell = get_shell_plugin(shell_type=test_shell)
    assert shell.SHELL_FAMILY == "sh"

# ################################################################
# Plugin classes, including abstract base class and mixin classes #
# ################################################################


# Generated at 2022-06-21 05:39:53.302027
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    """
    Test the constructor for class Jinja2Loader
    """
    assert Jinja2Loader("ansible.plugins.filter", "FilterModule", "filter_plugins")
    # This should not raise an exception
    Jinja2Loader("ansible.plugins.filter", "FilterModule", "filter_plugins")
    # This will raise an exception.
    try:
        Jinja2Loader("ansible.plugins.filter", "FilterModule", "test_plugins")
        assert False, "Expected a RuntimeError"
    except RuntimeError:
        pass

    # This will raise an exception.
    try:
        Jinja2Loader("ansible.plugins.filter", "FilterModule", "other_plugins")
        assert False, "Expected a ValueError"
    except ValueError:
        pass



# Generated at 2022-06-21 05:40:03.844660
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    pluginLoadContext = PluginLoadContext()
    redirect_name = "redirect_name"
    exit_reason = "exit_reason"
    pluginLoadContext.original_name = "original_name"
    pluginLoadContext.redirect("redirect_name")
    assert pluginLoadContext.original_name == "original_name"
    assert pluginLoadContext.pending_redirect == "redirect_name"
    assert pluginLoadContext.exit_reason == "pending redirect resolution from original_name to redirect_name"
    assert pluginLoadContext.resolved == False


# Generated at 2022-06-21 05:40:14.765523
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    # Test with paths
    paths = [
        'abc',
        'abc/def',
        'abc/def/ghi',
    ]
    assert PluginLoader._format_paths(paths) == "abc, abc/def, abc/def/ghi"
    # Test with error
    paths = [
        'abc',
        'abc/def',
        'abc/def/ghi',
        1,
    ]
    with pytest.raises(AnsibleError):
        PluginLoader._format_paths(paths)
    # Test without paths
    paths = []
    assert PluginLoader._format_paths(paths) == ""



# Generated at 2022-06-21 05:40:18.024464
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    """
    Check that get_with_context_result returns the expected value
    when called with valid parameters.
    """
    assert get_with_context_result(('a', 'b', 'c'), context=None) == 'c'
    assert get_with_context_result(('a', 'b', 'c'), context='a') == 'b'
    assert get_with_context_result(('a', 'b', 'c'), context='b') == 'c'
    assert get_with_context_result(('a', 'b', 'c'), context='d') == 'c'



# Generated at 2022-06-21 05:40:54.908586
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():

    class FakeClass:
        pass

    # Empty
    result = get_with_context_result()
    assert result._plugin_name == 'unknown'
    assert result._plugin_type == 'unknown'
    assert result._filters == {}
    assert result._found == True
    assert result._matched == True
    assert result._context == None
    assert result._objects == []

    # No Context - filters only
    result = get_with_context_result(plugin_type='test', plugin_name='test')
    assert result._plugin_name == 'test'
    assert result._plugin_type == 'test'
    assert result._filters == {}
    assert result._found == True
    assert result._matched == True
    assert result._context == None
    assert result._objects == []

    # With Context - No filters
    result = get

# Generated at 2022-06-21 05:40:59.010674
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    '''
    Unit test for method find_plugin of class PluginLoader
    '''
    plugin_loader = PluginLoader(category='action', package='ansible.plugins.action')
    name = 'copy'
    collection_list = None
    # get the plugin_load_context and check if the context is resolved or not
    plugin_load_context = plugin_loader.find_plugin_with_context(name, collection_list=collection_list)
    assert plugin_load_context.resolved
    # assert that the resolved name and path are as per expectation
    assert plugin_load_context.plugin_resolved_name == 'ansible.plugins.action.copy'

# Generated at 2022-06-21 05:41:01.380931
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    plugin_load_context = PluginLoadContext()
    plugin_load_context.nope('foo')
    assert plugin_load_context.pending_redirect == None
    assert plugin_load_context.exit_reason == 'foo'
    assert plugin_load_context.resolved == False
    assert plugin_load_context.resolved_fqcn == None



# Generated at 2022-06-21 05:41:11.223898
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert get_shell_plugin('sh').SHELL_FAMILY == 'sh'
    assert get_shell_plugin('pwsh').SHELL_FAMILY == 'pwsh'
    assert get_shell_plugin(executable='/usr/bin/sh').SHELL_FAMILY == 'sh'
    assert get_shell_plugin(executable='/usr/bin/bash').SHELL_FAMILY == 'sh'
    assert get_shell_plugin(executable='/usr/bin/zsh').SHELL_FAMILY == 'sh'
    assert get_shell_plugin(executable='/usr/bin/fish').SHELL_FAMILY == 'csh'
    assert get_shell_plugin(executable='/usr/bin/pwsh').SHELL_FAMILY == 'pwsh'

# Generated at 2022-06-21 05:41:18.833703
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    example = 'value'
    plugin_load_context = PluginLoadContext(resolved=True, plugin_resolved_name=example, plugin_resolved_path=example)
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == example
    assert plugin_load_context.plugin_resolved_path == example

    plugin_load_context = PluginLoadContext(resolved=False)
    assert not plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name is None
    assert plugin_load_context.plugin_resolved_path is None

    plugin_load_context = plugin_load_context.resolve(plugin_resolved_name=example, plugin_resolved_path=example)
    assert plugin_load_context.plugin_resolved_name

# Generated at 2022-06-21 05:41:28.013881
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    result = PluginLoader._get_with_context_result('singleton', 'test_singleton')
    assert isinstance(result, tuple)
    assert isinstance(result[0], AttributeDict)
    assert isinstance(result[1], str)
    assert isinstance(result[2], str)
    assert result[0]['name'] == 'test_singleton'
    assert result[2] == 'singleton'



# Generated at 2022-06-21 05:41:40.498443
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    ctx = PluginLoadContext()
    resolved_name = 'test_resolved_name'
    resolved_path = 'test_resolved_path'
    resolved_collection = 'test_resolved_collection'
    exit_reason = 'test_exit_reason'
    ctx.resolve(resolved_name, resolved_path, resolved_collection, exit_reason)
    assert ctx.pending_redirect is None
    assert ctx.plugin_resolved_name == resolved_name
    assert ctx.plugin_resolved_path == resolved_path
    assert ctx.plugin_resolved_collection == resolved_collection
    assert ctx.exit_reason == exit_reason
    assert ctx.resolved is True



# Generated at 2022-06-21 05:41:50.693136
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    plugin_loader = PluginLoader(package='',base_class='',class_name='')
    assert plugin_loader.format_paths([]) == ''
    assert plugin_loader.format_paths(['test1']) == '/test1'
    assert plugin_loader.format_paths(['test2', 'test3']) == '/test2, /test3'
    assert plugin_loader.format_paths(['test4', 'test5', 'test6']) == '/test4, /test5, /test6'

# Generated at 2022-06-21 05:42:02.530263
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    pl = PluginLoader('', '', '', '', '', '')
    paths = ["/home/user/some/long/path/ansible_collections/some/collection/plugins/action/some_action.py",
             "/home/user/another/long/path/ansible_collections/another/collection/plugins/action/another_action.py",
             "/home/user/short/another/collection/plugins/action/another_action.py", "/home/user/short/yet_another/action.py",
             "/home/user/short/test.py", "/home/user/short/module_utils/module.py"]


# Generated at 2022-06-21 05:42:13.157033
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    # test for a valid argument
    def test_valid0():
        plc = PluginLoadContext()
        plc.nope("PluginLoadContext")
    #test_valid0()

    # test for invalid argument
    def test_invalid0(arg1):
        plc = PluginLoadContext()
        plc.nope(arg1)
    #test_invalid0(4)

    # test for invalid argument
    def test_invalid1(arg1):
        plc = PluginLoadContext()
        plc.nope(arg1)
    #test_invalid1(None)
#test_PluginLoadContext_nope()

    def record_exit(self):
        self.resolved = False
        return self
