

# Generated at 2022-06-21 05:35:01.355840
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    p = PluginLoader()
    # Test when no paths are given
    assert p.format_paths([]) == '<None>'
    # Test when only one path is given
    assert p.format_paths(['/tmp/']) == '/tmp/'
    # Test when only two paths are given
    assert p.format_paths(['/tmp/', '/usr/']) == '/tmp/, /usr/'
    # Test when more than two paths are given
    assert p.format_paths(['/tmp/', '/usr/', '/var/lllllllllllllllllllllllllllllllllllllllllllllllllllllll/']) == '/tmp/, /usr/, /var/llllllllll...'

# Generated at 2022-06-21 05:35:02.235220
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    pass

# Generated at 2022-06-21 05:35:07.665332
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    gabs = collections.namedtuple('gabs', ['collections'])
    # Set up object
    obj = PluginLoader('package_name', 'base_class', 'class_name', 'paths', 'aliases')

    # Set up arguments
    state = gabs(collections=[])

    # Testing
    obj.__setstate__(state)

# Generated at 2022-06-21 05:35:20.121851
# Unit test for constructor of class PluginLoader
def test_PluginLoader():

    class OldPlugin(object):
        pass

    class NewPlugin(object):
        def __init__(self):
            pass

    old_plugin_loader = PluginLoader('ansible.plugins.old_plugin', 'OldPlugin', 'old/plugins')
    new_plugin_loader = PluginLoader('ansible.plugins.new_plugin', 'NewPlugin', 'new/plugins', 'NewBaseClass')

    # Test module_utils uses 'AnsibleModule' as class name.
    module_utils_loader = PluginLoader('ansible.module_utils', 'AnsibleModule', 'module_utils')

    assert old_plugin_loader._class_name == 'OldPlugin'
    assert old_plugin_loader._package == 'ansible.plugins.old_plugin'

# Generated at 2022-06-21 05:35:28.690503
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    loader = PluginLoader(package='ansible.plugins.modules', class_name='ModuleBase')
    plugin = loader.get('copy')
    assert isinstance(plugin, ModuleBase)

    plugin = loader.get('file')
    assert isinstance(plugin, ModuleBase)

    # Test rerouting
    plugin = loader.get('service')
    assert isinstance(plugin, ModuleBase)
    assert plugin._original_path.endswith('service.py')
    assert plugin._load_name == 'service'
    assert plugin._redirected_names == ['service']

    # Test alias
    plugin = loader.get('service_facts')
    assert isinstance(plugin, ModuleBase)
    assert plugin._original_path.endswith('service_facts.py')
    assert plugin._load_name == 'service'
    assert plugin._

# Generated at 2022-06-21 05:35:29.698243
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    r = PluginLoader.get()
    assert r is None


# Generated at 2022-06-21 05:35:36.432751
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    from ansible.plugins.filter.core import FilterModule
    from ansible.plugins.test import TestModule
    with pytest.raises(AnsibleError):
        Jinja2Loader('Not a good type', '.', 'ansible.plugins.filter')
    Jinja2Loader('filter', '.', 'ansible.plugins.filter', config=None, base_class=FilterModule)
    Jinja2Loader('test', '.', 'ansible.plugins.test', config=None, base_class=TestModule)



# Generated at 2022-06-21 05:35:39.403593
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    display = Display()

    get_with_context_result = GetWithContextResult('test_value', True, ['1', '2', '3'])

    # Call to_data()
    data = get_with_context_result.to_data()

    # Evaluate result
    assert data['value'] == 'test_value'
    assert data['changed'] == True
    assert data['msg'] == ['1', '2', '3']
    assert data['error'] == None



# Generated at 2022-06-21 05:35:50.884686
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    class UnitUnderTest(object):
        def __init__(self, a, b=None):
            self.a = a
            self.b = b

    actual = PluginLoader("ansible.test_plugins", "UnitUnderTest", C.DEFAULT_INTERNAL_PLUGIN_PATH, '', required_base_class=UnitUnderTest)
    #
    # test the following method: find_plugin(name, mod_type=None, ignore_deprecated=False, collection_list=None)
    #
    # 1. test being called by AnsibleLoader with no deprecated fields
    actual.find_plugin('name', mod_type=None, ignore_deprecated=False, collection_list=None)
    # 2. test being called by AnsibleLoader with deprecated fields

# Generated at 2022-06-21 05:35:56.478843
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    pl = PluginLoader('', '', '', 'ansible.plugins.test.test_module', 'TestModule')
    pl.package = 'ansible.plugins.test'
    plugin = pl.get('test_module')
    assert plugin.__class__.__name__ == 'TestModule'


# Generated at 2022-06-21 05:36:28.817236
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    path = '/my/path/to/plugins'
    internal = False
    ppc = PluginPathContext(path, internal)
    assert ppc.path == '/my/path/to/plugins'
    assert ppc.internal == False


# Generated at 2022-06-21 05:36:38.506800
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    plugin_loader = PluginLoader()
    plugin_loader.package = 'ansible.plugins.test_action'

    plugin_load_context = plugin_loader.find_plugin_with_context('foo')
    assert plugin_load_context.resolved == False
    assert plugin_load_context.search_error == 'No module named test_action.foo'

    assert plugin_loader.get_with_context(plugin_load_context.plugin_resolved_name) == None


# Generated at 2022-06-21 05:36:41.498863
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert add_dirs_to_loader('test') == None



# Generated at 2022-06-21 05:36:47.353003
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    plugin_loader = PluginLoader("foo.bar", "class_name")
    plugin_loader.add_directory("directory", "package")
    assert plugin_loader._get_paths() == ["directory"]
    assert plugin_loader._searched_paths == ["directory"]



# Generated at 2022-06-21 05:36:49.515772
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    # Test PluginLoader object can not be pickled
    pass

# Generated at 2022-06-21 05:37:03.025795
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert constants.C.DEFAULT_ACTION_PLUGIN_PATH == '/usr/share/ansible/plugins/action_plugins'
    assert constants.C.DEFAULT_CACHE_PLUGIN_PATH == '/usr/share/ansible/plugins/cache_plugins'
    assert constants.C.DEFAULT_CALLBACK_PLUGIN_PATH == '/usr/share/ansible/plugins/callback_plugins'
    assert constants.C.DEFAULT_CLICONF_PLUGIN_PATH == '/usr/share/ansible/plugins/cliconf_plugins'
    assert constants.C.DEFAULT_CONNECTION_PLUGIN_PATH == '/usr/share/ansible/plugins/connection_plugins'

# Generated at 2022-06-21 05:37:12.136269
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plugin_load_context = PluginLoadContext()
    assert not plugin_load_context.resolved
    assert plugin_load_context.exit_reason is None
    assert plugin_load_context.pending_redirect is None
    assert plugin_load_context.original_name is None
    assert not plugin_load_context.deprecated
    assert plugin_load_context.removal_date is None
    assert plugin_load_context.removal_version is None
    assert not plugin_load_context.deprecation_warnings
    assert plugin_load_context.resolved_fqcn is None
    assert plugin_load_context.plugin_resolved_collection is None



# Generated at 2022-06-21 05:37:13.517732
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    pass



# Generated at 2022-06-21 05:37:23.235428
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():

    # Happy path
    jl = Jinja2Loader(package='ansible.legacy.plugins.filter', subdir='filter_plugins')

    assert jl.package == 'ansible.legacy.plugins.filter'
    assert jl.subdir == 'filter_plugins'

    # Sanity checks
    # subdir = None
    with pytest.raises(AnsibleError):
        # NOTE: I think this should be changed to accept subdir = None as filter/test
        # plugin loader is the only one using this constructor.
        jl = Jinja2Loader(package='ansible.legacy.plugins.filter', subdir=None)

    # subdir = ''

# Generated at 2022-06-21 05:37:26.660291
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    p = PluginLoader('', '', ['.'], 'C.base_class', 'C.package')
    target = "<ansible.plugins.loader.PluginLoader object at 0x25b9d50>"
    assert repr(p) == target

# Generated at 2022-06-21 05:39:02.160928
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # Test id: 1
    PLUGIN_L = PluginLoader('', 'ansible.plugins.module_utils')

# Generated at 2022-06-21 05:39:11.481757
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():

    # Create module mock
    module_mock = MagicMock()
    module_mock.__name__ = 'ansible.plugins.test'

    # Get the class under test
    ClassUnderTest = get_class_under_test(__name__, 'PluginLoader')

    # Instantiate the class under test
    class_under_test_getstate = ClassUnderTest(
        package=module_mock,
        subdir='test',
        class_name='test',
        aliases={},
    )


# Generated at 2022-06-21 05:39:21.125765
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    loader = PluginLoader(
        class_name='CacheModule',
        base_class='BaseCacheModule',
        package='ansible.plugins.cache',
        config_base=C.DEFAULT_CACHE_PLUGIN_CONNECTION,
        config_module='ansible.plugins.cache.python_pickle',
    )

    obj = loader.get('python_pickle')
    assert 'BaseCacheModule' in str(obj)
    obj = loader.get_with_context('python_pickle')
    assert 'BaseCacheModule' in str(obj.object)



# Generated at 2022-06-21 05:39:32.878277
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():

    add_dirs_to_loader('action', ['/a/b/c/'])
    assert len(action_loader._get_paths()) == 1
    assert action_loader._get_paths()[0] == os.path.realpath('/a/b/c/')

    action_loader.add_directory('/a/b/c/')
    assert len(action_loader._get_paths()) == 2
    assert action_loader._get_paths()[1] == os.path.realpath('/a/b/c/')

    action_loader.add_directory('/a/b/c/')
    assert len(action_loader._get_paths()) == 2
    assert action_loader._get_paths()[1] == os.path.realpath('/a/b/c/')

# Generated at 2022-06-21 05:39:43.681800
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    registry = PluginLoaderRegistry()
    plugin_loader = PluginLoader(
        registry.get_plugin_loader_class('connection'), 'ansible.plugins.connection', C.CONNECTION_PLUGIN_PATH)
    plugin_loader.__setstate__({'aliases': {},
                                'base_class': 'ConnectionBase',
                                'class_name': 'Connection',
                                '_module_cache': {},
                                'package': 'ansible.plugins.connection',
                                'subdir': 'connection_plugins',
                                '_searched_paths': ['/usr/lib/python2.7/site-packages/ansible/plugins/connection']})



# Generated at 2022-06-21 05:39:52.682516
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    PL = PluginLoader(
        'ActionModule',
        'ansible.plugins.action',
        C.DEFAULT_ACTION_PLUGIN_PATH,
        'action_plugins',
        required_base_class='ActionBase'
    )
    action = PL.get('ping')
    assert isinstance(action, ActionModule)
    assert action._load_name == 'ping'
    action = PL.get('net_infos')
    assert isinstance(action, ActionModule)
    assert action._load_name == 'net_infos'


# Generated at 2022-06-21 05:40:03.963582
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():

    loader = Jinja2Loader('ansible.legacy.plugins.filter', 'FilterModule')
    assert loader.path == ['ansible/legacy/plugins/filter']
    assert loader.package == 'ansible.legacy.plugins.filter'
    assert loader.subdir == 'filter_plugins'
    assert loader.base_class == 'FilterModule'
    assert loader.class_name == 'FilterModule'
    assert loader.class_only is False
    assert loader._dedupe is True
    assert loader._searched_paths == loader._get_paths()



# Generated at 2022-06-21 05:40:11.911401
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    with warnings.catch_warnings(record=True) as log:
        # logging to console is disabled by default in Python 2.7+
        warnings.simplefilter('always')
        p = PluginLoader('ansible.plugins.callback', 'CallbackModule', '', 'callback_plugins', required_base_class='CallbackBase')
        assert p.get() == None



# Generated at 2022-06-21 05:40:25.354265
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # create mock obj for class AnsibleCollectionFinder
    ansible_collection_finder_class_mock = mock.MagicMock(spec=AnsibleCollectionFinder)
    # create mock object for class AnsibleCollectionFinder (uninitialized)
    ansible_collection_finder_instance_mock = ansible_collection_finder_class_mock.return_value
    # create mock obj for class AnsibleCollectionRef
    ansible_collection_ref_class_mock = mock.MagicMock(spec=AnsibleCollectionRef)
    # create mock object for class AnsibleCollectionRef (uninitialized)
    ansible_collection_ref_instance_mock = ansible_collection_ref_class_mock.return_value

    # get_collection_ref method of mock object ansible_collection_finder_instance_mock should return object mock

# Generated at 2022-06-21 05:40:26.967885
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    pass



# Generated at 2022-06-21 05:42:19.786488
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    args = ()
    kwargs = {}

    with pytest.raises(AnsibleError) as excinfo:
        get(args, kwargs)

    assert 'No code should call "get" for Jinja2Loaders (Not implemented)' in str(excinfo.value)

# Generated at 2022-06-21 05:42:27.013592
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    x = PluginLoadContext()
    assert x.original_name is None
    assert x.redirect_list == []
    assert x.error_list == []
    assert x.import_error_list == []
    assert x.load_attempts == []
    assert x.pending_redirect is None
    assert x.exit_reason is None
    assert x.plugin_resolved_path is None
    assert x.plugin_resolved_name is None
    assert x.plugin_resolved_collection is None  # empty string for resolved plugins from user-supplied paths
    assert x.deprecated is False
    assert x.removal_date is None
    assert x.removal_version is None
    assert x.deprecation_warnings == []
    assert x.resolved is False
    assert x._resolved_fq

# Generated at 2022-06-21 05:42:35.298888
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():

    # Test the test case
    class TestPlugin():
        pass

    loader = PluginLoader('ansible.legacy', 'TestPlugin', base_class=TestPlugin)
    assert loader.package == 'ansible.legacy'
    assert loader.class_name == 'TestPlugin'
    assert loader.base_class is TestPlugin
    assert loader.caching is True
    assert loader.subdir is None

    # Test that we can construct with caching disabled
    loader = PluginLoader('ansible.legacy', 'TestPlugin', base_class=TestPlugin, caching=False)
    assert loader.package == 'ansible.legacy'
    assert loader.class_name == 'TestPlugin'
    assert loader.base_class is TestPlugin
    assert loader.caching is False
    assert loader.subdir is None

    # Test that we can construct with