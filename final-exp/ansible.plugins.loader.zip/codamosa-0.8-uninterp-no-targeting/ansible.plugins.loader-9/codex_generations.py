

# Generated at 2022-06-21 05:33:52.500009
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():

    class FakeMetaPlugin:
        def __init__(self, class_name, package, base_class, subdir, *args, **kwargs):
            self.class_name = class_name
            self.package = package
            self.base_class = base_class
            self.subdir = subdir

    class FakeNamespace:
        def __init__(self, name, value=None):
            self.name = name
            if value:
                setattr(self, name, value)

    class FakePlugin:
        def __init__(self, name, return_value=None):
            self.name = name
            self.return_value = return_value

        def __call__(self, *args, **kwargs):
            if self.return_value:
                return self.return_value
            else:
                return

# Generated at 2022-06-21 05:34:06.008788
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    self = PluginLoader("action", "ActionModule", 'ansible.plugins.action', C.DEFAULT_INTERNAL_PLUGINS)
    self.package = "action"
    self.paths = ["/Users/dkonstan/workspace/ansible/lib/ansible/plugins/action", "/Users/dkonstan/workspace/ansible/lib/ansible/plugins/action/__init__.py"]
    self.class_name = "ActionModule"
    self._classes = {}
    self._module_cache = {}

# Generated at 2022-06-21 05:34:17.273448
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    plugin_path = './plugins'
    add_all_plugin_dirs(plugin_path)
    for name, obj in get_all_plugin_loaders():
        if obj.subdir:
            if plugin_path not in obj.directories:
                raise AssertionError("%s not in directories for %s" %(plugin_path, name))
        else:
            if plugin_path in obj.directories:
                raise AssertionError("%s in directories for %s" %(plugin_path, name))
# Test function test_add_all_plugin_dirs
test_add_all_plugin_dirs()


# Generated at 2022-06-21 05:34:23.615327
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    loader = getattr(sys.modules[__name__], '%s_loader' % 'action')
    loader.add_directory('/tmp', with_subdir=True)
    for path in paths:
        loader.add_directory(path, with_subdir=True)


# Generated at 2022-06-21 05:34:26.981106
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    my_class = PluginLoader('any.module', 'any.package')
    plugin = my_class.find_plugin('my_plugin')


# Generated at 2022-06-21 05:34:33.332390
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plc = PluginLoadContext()
    assert plc.original_name is None
    assert plc.redirect_list == []
    assert plc.error_list == []
    assert plc.import_error_list == []
    assert plc.load_attempts == []
    assert plc.pending_redirect is None
    assert plc.exit_reason is None
    assert plc.plugin_resolved_path is None
    assert plc.plugin_resolved_name is None
    assert plc.plugin_resolved_collection is None
    assert not plc.deprecated
    assert plc.removal_date is None
    assert plc.removal_version is None
    assert plc.deprecation_warnings == []
    assert not plc.resolved
    assert plc._resolved_

# Generated at 2022-06-21 05:34:44.844457
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    # These are the values that we expect the plugin loader to return
    actual = []

    def record_returned(plugin):
        actual.append(plugin)


# Generated at 2022-06-21 05:34:46.181812
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    assert False

# Generated at 2022-06-21 05:34:47.406886
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    pass


# Generated at 2022-06-21 05:34:50.893725
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    prc = PluginLoadContext()
    assert not prc.resolved
    prc.nope("Test reason")
    assert not prc.resolved
    assert prc.exit_reason == "Test reason"


# Generated at 2022-06-21 05:35:21.886738
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    global shell_loader
    shell_loader = ShellModuleLoader()
    shell_loader.get_module_path("shell")
    shell_loader.module_paths('shell')
    shell_loader.paths()
    shell_loader.index_path(None)
    shell_loader.index_path("/tmp/ansible")
    shell_loader.list_class_names()
    shell_loader.list_class_names("/tmp/ansible")
    shell_loader.list_class_names("/tmp/ansible/shell")
    shell_loader.list_plugin_names("/tmp/ansible/shell")
    shell_loader.list_plugin_names("/tmp/ansible/shell", "shell")
    shell_loader.all(shell_type="sh")
    shell_loader.get_all_plugin_load

# Generated at 2022-06-21 05:35:27.487710
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    PL = PluginLoader(package="ansible.modules", subdir="common")
    assert '.ansible/modules/common' == PL.format_paths(['.ansible/modules/common'])
    assert '.ansible/modules/common:.ansible/modules/common/subdir1:.ansible/modules/common/subdir2' == PL.format_paths(['.ansible/modules/common', '.ansible/modules/common/subdir1', '.ansible/modules/common/subdir2'])



# Generated at 2022-06-21 05:35:29.155195
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    context = PluginLoadContext()


# Generated at 2022-06-21 05:35:38.770149
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    import pytest
    from units.compat.mock import Mock, patch
    from ansible.utils.path import unfrackpath

    # prepare the test
    test_paths = ['/path/to/ansible/ansible/plugins/action', '/path/to/ansible/ansible/plugins/module']

    def check_args(loader, plugin_name, collection_list=None):
        assert plugin_name in ('first_plugin', 'second_plugin', 'third_plugin')
        if collection_list is not None:
            assert collection_list == 'collections'
        return (plugin_name, collection_list)

    def check_list_paths(loader, dirs, subdir, collection_list=None):
        assert dirs == test_paths
        assert subdir == loader.subdir

# Generated at 2022-06-21 05:35:44.845334
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    global _PLUGIN_PATH_CACHE

    test_function = 'foo'
    test_path1 = '/the/first/path'
    test_path2 = '/the/second/path'
    test_path3 = '/the/third/path'
    test_file1 = '/the/first/path/foo.py'
    test_file2 = '/the/second/path/foo.py'
    test_file3 = '/the/third/path/foo.py'
    test_name1 = 'the_first_foo'
    test_name2 = 'the_second_foo'
    test_name3 = 'the_third_foo'

    jl = Jinja2Loader('ansible.plugins.filter')

    # find_plugin should return None if there are no plugin paths
    _PLUGIN_PATH

# Generated at 2022-06-21 05:35:46.119841
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    import ansible.plugins.loader
    assert len(ansible.plugins.loader.get_all_plugin_loaders()) == 3



# Generated at 2022-06-21 05:35:48.888728
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    pass



# Generated at 2022-06-21 05:35:55.143320
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    # Test PluginLoader.__setstate__
    this = PluginLoader()
    # Skip test
    if True:
        raise SkipTest("Missing needed code: test_PluginLoader___setstate__")
    # Test PluginLoader.__setstate__
    this.package = 'ansible.plugins.filter'
    this.subdir = 'filter_plugins'
    this.class_name = 'FilterModule'
    this.base_class = 'FilterModule'
    this.found = False
    this.class_list = []
    this.aliases = []
    this.searched_paths = []
    this._searched_paths = []
    this.path_cache = {}
    this.cache_disabled = True
    this._module_cache = {}
    this.config_defs = {}

# Generated at 2022-06-21 05:35:57.418552
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # FIXME: This test is trivially passing, needs a better test
    loader = PluginLoader('', '', '', '', '')
    assert '' in loader


# Generated at 2022-06-21 05:36:06.388022
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    context = PluginLoadContext()
    result = context.record_deprecation(name=test_name, deprecation=test_deprecation, collection_name=test_collection_name)
    assert result.deprecated == True
    assert result.removal_date == None
    assert result.removal_version == None
    assert result.deprecation_warnings == ['test_name has been deprecated. test_warning_text']



# Generated at 2022-06-21 05:36:32.480789
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    instance = PluginLoader('ansible.plugins.action', 'ActionModule', 'ansible.plugins.action.ActionModule')
    instance._load_plugins()
    assert instance.get_with_context('setup').resolved is True
    assert instance.get_with_context('pingzzz').resolved is False
    assert 'setup' in instance
    assert 'pingzzz' not in instance

# Generated at 2022-06-21 05:36:40.488652
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    pl = PluginLoader()
    pl._searched_paths = ['/foo/bar', '/baz/blat', '/foo/bar/baz']
    assert pl.format_paths() == "['/foo/bar', '/baz/blat', '/foo/bar/baz']"
    pl._searched_paths = []
    assert pl.format_paths() == '[]'

# Generated at 2022-06-21 05:36:52.519876
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    from ansible.module_utils import path_dwim
    from ansible.utils.collection_list import CollectionList
    PATH_TO_PLUGINS = os.path.join(path_dwim(), 'plugins')

# Generated at 2022-06-21 05:37:02.698686
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    from ansible.plugins.loader import get_all_plugin_loaders

    plugin_loaders = get_all_plugin_loaders()
    assert len(plugin_loaders) > 0
    assert set([x[0] for x in plugin_loaders]) == set(['connection', 'module_utils', 'modules', 'lookup', 'filter', 'callback', 'action', 'inventory', 'vars'])
    assert set([x[1].__class__.__name__ for x in plugin_loaders]) == set(['PluginLoader'])


# Base class for all plugin types, holds data and methods common
# to all plugins.

# Generated at 2022-06-21 05:37:12.431341
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    my_plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS,
                                    C.DEFAULT_INVENTORY_ENABLED_HOST_PATTERNS)
    my_plugin_loader.package = 'ansible.plugins.action'
    my_plugin_loader.class_name = 'ActionModule'
    my_plugin_loader.aliases = {}
    my_plugin_loader._searched_paths = ['ansible/plugins/action']
    my_plugin_loader.paths = ['ansible/plugins/action']
    my_plugin_loader._config_defs = {}
    my_plugin_loader._module_cache = {}
    my_plugin_loader.subdir = 'action'

    expected

# Generated at 2022-06-21 05:37:22.380832
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    class FakeDeprecationWarning(object):
        def __init__(self, message, category, filename, lineno, file=None, line=None):
            self.message = message
            self.category = category
            self.filename = filename
            self.lineno = lineno
            self.file = file
            self.line = line

    def mock_warning(message, category, filename, lineno, file=None, line=None):
        global deprecation_warning
        deprecation_warning = FakeDeprecationWarning(message, category, filename, lineno, file, line)

    class FakeDisplay(object):
        def __init__(self):
            self.deprecated = mock_warning

    display = FakeDisplay()

    context = PluginLoadContext()

    result = context.record_deprecation('name', {}, '')

# Generated at 2022-06-21 05:37:31.662238
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    redirect_name = 'x.y.z.redirect_name'
    original_name = 'x.y.z.original_name'
    plc = PluginLoadContext()
    plc.original_name = original_name
    plc_redirected = plc.redirect(redirect_name)
    assert plc_redirected.pending_redirect == redirect_name
    assert plc_redirected.plugin_resolved_name == None
    assert plc_redirected.plugin_resolved_path == None
    assert plc_redirected.plugin_resolved_collection == None
    assert plc_redirected.exit_reason == 'pending redirect resolution from {0} to {1}'.format(original_name, redirect_name)

# Generated at 2022-06-21 05:37:36.377268
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    args = dict()
    set_loader = ansible.utils.plugin_docs.get_loader()
    set_loader.__setstate__(args)

# Generated at 2022-06-21 05:37:42.332689
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    msg = 'Description of test_PluginLoader_add_directory'
    lb = PluginLoader('')

    lb.add_directory('')
    lb.add_directory('/path/to/junk')



# Generated at 2022-06-21 05:37:47.225814
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():

    test_result = object()
    test_context = object()
    test_new_instance = object()

    class test_type:

        @classmethod
        def new_instance(cls, obj, context):
            assert obj is test_result
            assert context is test_context
            return test_new_instance

    result = get_with_context_result(test_result, test_context, test_type)

    assert result is test_new_instance



# Generated at 2022-06-21 05:40:35.958471
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    plugin_load_context = PluginLoadContext()
    plugin_load_context.pending_redirect = 'abc'
    plugin_load_context.exit_reason = 'exit_reason_before'
    plugin_load_context.resolved = True
    plugin_load_context.nope('exit_reason_after')
    assert plugin_load_context.pending_redirect == None
    assert plugin_load_context.exit_reason == 'exit_reason_after'
    assert plugin_load_context.resolved == False


# Generated at 2022-06-21 05:40:47.792668
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    loader = PluginLoader('unit_test',
                          'UnitTestClass',
                          'ansible.plugins',
                          'ansible.plugins.UnitTestBaseClass',
                          C.DEFAULT_INTERNAL_PLUGIN_PATH)

    # Normal path
    loader.add_directory('/home/user/ansible/lib/plugins/unit_test')
    # Local path (protected by ansible prefix)
    loader.add_directory('/usr/share/ansible/plugins/unit_test')
    # Global path (protected by ansible prefix)
    loader.add_directory('/usr/share/ansible/plugins')
    # Unknown path, not in list
    loader.add_directory('/usr/share/ansible/plugins/unknown')


# Generated at 2022-06-21 05:40:50.860294
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    ctx = PluginPathContext('/tmp', True)
    assert ctx.path == '/tmp'
    assert ctx.internal


# Generated at 2022-06-21 05:40:55.201691
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    '''
    :return: None
    '''
    # Init class
    result = get_with_context_result('foo', 'bar', 'baz')

    # Test __init__
    for name, value in [('object', 'foo'),
                        ('attribute', 'bar'),
                        ('message', 'baz')]:
        assert getattr(result, name) == value

    # Test __repr__
    assert repr(result) == "<AnsibleAttribute object 'foo' has no attribute 'bar'. baz>"

    # Test __str__
    assert str(result) == "foo.bar: baz"

# Generated at 2022-06-21 05:40:56.222649
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    pass



# Generated at 2022-06-21 05:40:58.907668
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    pass  # FIXME: Write this


# Generated at 2022-06-21 05:41:04.017810
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    p = PluginLoader(package='test_package',
                     searchpath=['./plugins/test_search_path'],
                     class_name='test_class_name', base_class=None)
    p.print_paths()



# Generated at 2022-06-21 05:41:07.038476
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    context = 'context1'
    result = 'result1'
    test_get_with_context_result_object = get_with_context_result(context, result)
    assert isinstance(test_get_with_context_result_object, object)
    assert test_get_with_context_result_object.context == 'context1'
    assert test_get_with_context_result_object.result == 'result1'



# Generated at 2022-06-21 05:41:17.683390
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    data = [
        ("/path", "['/path']"),
        ("/path1:/path2", "['/path1', '/path2']"),
    ]

    for (path, expected) in data:
        pl = PluginLoader(os.path.sep.join(["ansible", "plugins", "lookup"]), "LookupModule", True, 'lookup_plugins')

        pl._searched_paths = path.split(':')
        assert pl.format_paths(pl._searched_paths) == expected


# Generated at 2022-06-21 05:41:29.186545
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    plugload_ctx = PluginLoadContext()
    # test nope(self, exit_reason)
    # for the first time:
    plugload_ctx.nope("nope")
    assert plugload_ctx.resolved == False
    assert plugload_ctx.exit_reason == "nope"
    assert plugload_ctx.pending_redirect == None
    # for the second time:
    plugload_ctx.nope("nope")
    assert plugload_ctx.resolved == False
    assert plugload_ctx.exit_reason == "nope"
    assert plugload_ctx.pending_redirect == None
