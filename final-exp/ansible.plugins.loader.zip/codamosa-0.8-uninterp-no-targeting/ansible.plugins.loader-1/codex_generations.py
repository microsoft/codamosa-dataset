

# Generated at 2022-06-21 05:34:30.727357
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    assert len(get_all_plugin_loaders()) == 8


PluginLoader = namedtuple('PluginLoader', ('package', 'base_class', 'config_base_class', 'constants', 'subdir'))


# PluginLoader constants
CACHE_PLUGINS = True

# PluginLoader is a namedtuple with the following items
# package: the name of the import namespace to find plugins in
# base_class: the base class all plugins of this type should subclass from
# config_base_class: the base class all config plugins of this type should subclass from
# subdir: the location relative to the namespace where the plugin code should be located
__all__ = ['all', 'connection', 'shell', 'module', 'lookup', 'filter', 'test', 'callback']

# plugin loaders

# Generated at 2022-06-21 05:34:36.805555
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Load the plugin loader
    loader = PluginLoader("myplugins", "MyPlugin")
    # Call the method to search
    plugin_load_context = loader.find_plugin_with_context("myplugin01")
    # Check the results
    if plugin_load_context.resolved:
        return True
    else:
        return False


# Generated at 2022-06-21 05:34:46.089321
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    from ansible.errors import AnsibleError

    # TODO: return plugin_load_result object instead of bool.
    #  Method should not mutate input variables and should not have side effects.
    #  Instead it should return a PluginLoadResult object.
    #
    # def find_plugin_with_context(self, name, class_only=False, collection_list=None, plugin_load_context=None):


    # TODO: test find_plugin_with_context using mocked lookup_plugin_loader.
    #

    # TODO: test find_plugin_with_context using mocked connection_loader.
    #

    # TODO: test find_plugin_with_context using mocked shell_loader.
    #

    # TODO: test find_plugin_with_context using mocked cliconf_loader.
    #

    # TOD

# Generated at 2022-06-21 05:34:48.134381
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    pass

# Generated at 2022-06-21 05:34:57.534597
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    def _test_PluginLoadContext_record_deprecation(deprecation,expect_removal_date,expect_removal_version):
        ctx = PluginLoadContext()
        ctx.record_deprecation('Test', deprecation, 'ansible.builtin')
        assert ctx.deprecated == True
        assert ctx.removal_date == expect_removal_date
        assert ctx.removal_version == expect_removal_version


# Generated at 2022-06-21 05:35:09.280872
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    @contextlib.contextmanager
    def stdout_b():
        origin_stdout = sys.stdout
        sys.stdout = StringIO()
        yield
        sys.stdout = origin_stdout

    _ww = []
    (name, path, collection_list) = ("moduleName", "modulePath", "moduleCollectionList")
    loader = PluginLoader(
        name,
        'plugins/moduleName.py',
        'moduleClassName',
        'moduleBaseClassName',
        collection_list,
        _ww
    )

    with stdout_b():
        loader.print_paths()
    p = _ww[0]
    assert isinstance(p, str)
    assert p == "    plugins/moduleName.py"
    assert name in p


# Generated at 2022-06-21 05:35:18.464820
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    """Test __setstate__(...) of PluginLoader"""
    loader = PluginLoader(None, [u'/Users/chris/x/y/z', 'a', 'b', 'c'], None, None)
    loader.aliases = {u'foo': u'bar'}
    loader.package = u'foo1'
    loader.config_defns = {u'foo2': u'bar2'}
    loader._module_cache = {u'/Users/chris/x/y/z': u'bar3'}
    loader.class_name = u'foo4'
    loader.base_class = u'bar4'
    loader.subdir = u'foo5'
    state = {u'monkey': u'Hello World'}

# Generated at 2022-06-21 05:35:20.989234
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    assert isinstance(PluginPathContext(path="some/path", internal=True), PluginPathContext)



# Generated at 2022-06-21 05:35:23.839142
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    loader = Jinja2Loader('', '', '', '', 'ansible.legacy.plugins.filter', 'FilterModule')
    assert loader


# Generated at 2022-06-21 05:35:27.458537
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    loader = Jinja2Loader()

    # This would be a bug in the calling code if this was ever the result.
    # However, a user reported this was a problem and we want to catch it if
    # it ever happens again.  If this is a problem, please report it to
    # the Ansible project.
    assert loader.find_plugin('foo.py:bar') is None



# Generated at 2022-06-21 05:37:17.776659
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    import ansible.plugins.loader as loader
    plugin_load_context = loader.PluginLoadContext()
    plugin_load_context.collection_name = 'ansible.posix'
    plugin_load_context.collection_paths = {'ansible.posix': 'registry/ansible.posix/'}
    plugin_loader = loader.ModuleUtilShell()
    plugin_load_context = plugin_loader.find_plugin_with_context('shell', plugin_load_context=plugin_load_context)
    assert plugin_load_context.plugin_resolved_path == "registry/ansible.posix/plugins/shell/__init__.py"
    assert plugin_load_context.plugin_resolved_name == 'ansible.posix.shell'
    

# Generated at 2022-06-21 05:37:25.281846
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():

    class TestPlugin(object):
        def __init__(self, *args, **kwargs):
            pass

    # Create a test plugin in a temp directory for testing purposes
    with tempfile.TemporaryDirectory() as tmpdir:
        plugin_dir = os.path.join(tmpdir, 'test_plugins', 'action')
        utils.makedirs_safe(plugin_dir, mode=0o700)
        with open(os.path.join(plugin_dir, 'test_plugin1.py'), 'w') as testplugin:
            testplugin.write('from ansible.plugins.action import ActionBase')
            testplugin.write('\n\n')
            testplugin.write('class ActionModule(ActionBase):')
            testplugin.write('    pass')

        # Set plugin path to the tmp dir
        config.set_

# Generated at 2022-06-21 05:37:33.520252
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type='sh')
    assert isinstance(shell, Plugin)

    shell = get_shell_plugin(executable='/usr/bin/bash')
    assert isinstance(shell, Plugin)
    assert shell.executable == '/usr/bin/bash'

    shell = get_shell_plugin()
    assert isinstance(shell, Plugin)

    try:
        shell = get_shell_plugin(executable='/usr/bin/foo-bar')
    except Exception:
        pass
    else:
        raise Exception("Shell executable not recognized. Expect exception")



# Generated at 2022-06-21 05:37:45.390024
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    plugin_loader = PluginLoader('TestPlugins')
    assert 'TestPlugins' == plugin_loader.package
    assert 'TestPlugins._load_plugins' == plugin_loader.subdir
    assert 'TestPluginBase' == plugin_loader.base_class
    assert 'TestPlugin' == plugin_loader.class_name

# TODO: Loader must be able to find builtin plugins.
# TODO: Loader must not find non-existent plugins.
# TODO: Loader must deduplicate duplicate plugins.
# TODO: Loader must find plugins in collections.
# TODO: Loader must use fallback paths.
# TODO: Loader must handle symlinks.

# Generated at 2022-06-21 05:37:57.538484
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    from ansible.plugins.loader import jinja2_loader
    if jinja2_loader.Jinja2Loader.get == PluginLoader.get:
        pytest.skip('Jinja2Loader is not a subclass of PluginLoader')

    # No collection_list, no plugin
    assert jinja2_loader.Jinja2Loader.get('ansible.legacy.no_such_plugin') is None

    # No such collection, no plugin
    assert jinja2_loader.Jinja2Loader.get('no_such_collection.namespace.no_such_plugin') is None

    # Get a valid plugin from ansible.legacy (default collection)
    result = jinja2_loader.Jinja2Loader.get('ansible.legacy.map')

# Generated at 2022-06-21 05:38:02.392852
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    p = PluginLoadContext()
    p = p.nope('exit_reason')
    assert p.resolved == False
    assert p.exit_reason == 'exit_reason'
    assert p.pending_redirect == None


# Generated at 2022-06-21 05:38:04.673840
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    for path, internal in ((os.path.join('mycollection', 'plugins'), True), ('mycollection', False)):
        assert PluginPathContext(path, internal).path == path
        assert PluginPathContext(path, internal).internal == internal



# Generated at 2022-06-21 05:38:18.508864
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    import io

    p = PluginLoader('test_package', 'test_base_class', 'test_class', 'test_dir')

    with io.open(os.path.join(os.path.dirname(__file__), '../../lib/ansible/plugins/module_utils/basic.py'), 'r') as mufile:
        module_utils_text = mufile.read()
        module_utils = type('module_utils', (object,), {})
        exec(module_utils_text, module_utils.__dict__)
    p.module_utils = module_utils

    p._searched_paths = ['/no/such/path/']
    p._get_paths = lambda: ['/path/with/plugins/']

# Generated at 2022-06-21 05:38:30.108041
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    from ansible.plugins.loader import add_dirs_to_loader, lookup_loader
    from ansible.plugins.action import ActionBase
    from ansible.plugins import module_loader
    from ansible.module_utils._text import to_bytes

    lookup_paths = []
    for path in C.DEFAULT_LOOKUP_PLUGIN_PATH:
        b_path = to_bytes(path, errors='surrogate_or_strict')
        for subpath in ('lookup_plugins', 'lookup'):
            plugin_path = os.path.join(b_path, to_bytes(subpath))
            if os.path.isdir(plugin_path):
                lookup_paths.append(to_text(plugin_path))


# Generated at 2022-06-21 05:38:40.637971
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    collection_list = collections.OrderedDict()
    collection_list['my_namespace.my_collection'] = [os.path.join(os.path.dirname(__file__), 'fixtures', 'test_collections', 'my_namespace-my_collection-1.0.0')]
    expression = 'my_namespace.my_collection.plugins.plugins.test1_module'
    resolver = PluginLoader('', '', '', '', '', package='ansible_collections.my_namespace.my_collection.plugins.plugins')
    plugin = resolver.find_plugin(expression, collection_list=collection_list)
    assert 'my_namespace.my_collection.plugins.plugins.test1_module' == plugin
    assert 1 == len(collection_list)

# Generated at 2022-06-21 05:41:10.644140
# Unit test for function get_shell_plugin
def test_get_shell_plugin():

    shell = get_shell_plugin()
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'

    shell = get_shell_plugin('sh', '/bin/bash')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/bash'

    for shell in shell_loader.all():
        # Hack to insert a shell executable into the TestShell
        if shell.SHELL_FAMILY == 'test':
            setattr(shell, 'executable', '/bin/sh')
        shell = get_shell_plugin(shell.SHELL_FAMILY)
        assert shell.SHELL_FAMILY == shell.SHELL_FAMILY



# Generated at 2022-06-21 05:41:17.240351
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    PL = PluginLoader('ansible.plugins.action', 'ActionModule', 'ansible.plugins.action.ActionModule', '_loader', 'action_plugins')
    assert to_text(PL) == 'AnsibleActionModulePluginLoader(action_plugins, action, _loader, ansible.plugins.action.ActionModule, None)'


# Generated at 2022-06-21 05:41:30.111098
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
#
# Functions to simulate Python 3.7's mock.__getstate__() behavior
    def getstate(self):
        return self._get_child_mock(name='mock state', _new_name='mock state', _new_parent=None)

    def getstate_for_unserialize(self):
        obj_dict = self.__dict__.copy()
        for key in ['_mock_children', '_mock_name', '_mock_new_name', '_mock_parent', '_mock_new_parent']:
            if key in obj_dict:
                del obj_dict[key]
        obj_dict['__class__'] = type(self)  # in case it's a subclass
        return obj_dict

    # Set up mocks
    mock__new_name = Mock()


# Generated at 2022-06-21 05:41:40.803880
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    context = PluginLoadContext()
    assert context.original_name == None
    assert context.redirect_list == []
    assert context.error_list == []
    assert context.import_error_list == []
    assert context.load_attempts == []
    assert context.pending_redirect == None
    assert context.exit_reason == None
    assert context.plugin_resolved_path == None
    assert context.plugin_resolved_name == None
    assert context.deprecated == False
    assert context.removal_date == None
    assert context.removal_version == None
    assert context.deprecation_warnings == []
    assert context.resolved == False


# Generated at 2022-06-21 05:41:51.605696
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    import ansible.plugins
    p1 = PluginLoader('filter_loader', 'FilterModule', 'ansible.plugins.filter', C.FILTER_PLUGIN_PATH)
    # Pre-set the loaded modules
    p1._module_cache = {
        '/home/sadmins/ansible/lib/ansible/plugins/filter/timedelta.py': ansible.plugins.filter.timedelta
    }

    result = list(p1.all())
    assert result is not None
    assert len(result) == 1
    assert isinstance(result[0], type(ansible.plugins.filter.timedelta.FilterModule))



# Generated at 2022-06-21 05:41:53.085925
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    assert(True)


# Generated at 2022-06-21 05:42:03.454824
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    from ansible.plugins import module_loader
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collection_loader.exceptions import CollectionVersionNotFound
    from ansible.collections.ansible.builtin.plugins.module_utils.network.common.utils import load_provider
    class_only = True
    loader = module_loader.ModuleLoader(None, class_only=class_only)
    module_path = '/usr/share/ansible/plugins/modules/'
    module_name = 'ping'
    collection = AnsibleCollectionLoader()
    collection_fqcn = 'ansible.builtin'
    fq_name = 'ansible.builtin.ping'
    paths = [module_path]

# Generated at 2022-06-21 05:42:10.722314
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    plc = PluginLoadContext().record_deprecation('test-name1', {'removal_date': '2099-12-31'}, 'test-col')
    assert plc.deprecated
    assert plc.removal_date == '2099-12-31'
    assert plc.deprecation_warnings[0] == 'test-name1 has been deprecated.'


# Generated at 2022-06-21 05:42:20.502290
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    """
    :assumption: Plugin_load_context.redirect(redirect_name) should return object with object.resolved = False
    """
    plc = PluginLoadContext()
    redirect_name = 'redirect_name'
    plug_obj = plc.redirect(redirect_name)
    assert plug_obj.pending_redirect == redirect_name
    assert plug_obj.resolved == False


# Generated at 2022-06-21 05:42:21.663637
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    pass