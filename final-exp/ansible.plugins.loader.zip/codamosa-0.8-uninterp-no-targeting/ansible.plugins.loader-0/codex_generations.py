

# Generated at 2022-06-21 05:35:04.732481
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    test_PluginLoader__setstate__(None)


# Generated at 2022-06-21 05:35:09.528179
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert True


# this is a special plugin which uses the find_plugin() infrastructure to load a shell,
# so we can use the same infrastructure to load a shell plugin as we do for all
# other plugins.

# Generated at 2022-06-21 05:35:18.811610
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    from ansible.plugins.loader import (
        ActionBase,
        ActionModule,
        ConnectionBase,
        ConnectionModule,
        StrategyBase,
        StrategyModule,
        FilterModule,
        TerminalBase,
        TerminalModule,
        TestModule,
        LookupBase,
        LookupModule,
        CallbackModule,
        VarsModule,
    )


# Generated at 2022-06-21 05:35:28.221754
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    cls = collections.namedtuple('Module', ('name',))
    os.path.exists = lambda x: True
    os.path.isdir = lambda x: True
    cls.__file__ = 'test'
    try:
        import ansible_test.test.test_PluginLoader as test_PluginLoader
        test = test_PluginLoader
    except Exception:
        test = sys.modules[__name__]

    instance = PluginLoader('foo', 'cog', 'ansible.plugins')
    test.sys.modules = {}

    # test when the directory has already been checked, returns immediately
    instance._checked_dirs = {os.path.abspath('/a/b/c'): True}

# Generated at 2022-06-21 05:35:36.151177
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    filepath = os.path.join(FIXTURES_DIR, 'plugins', 'module_utils', 'test_loader.py')
    loader = Jinja2Loader('module_utils', 'test_loader', C.MODULE_UTILS_PATH)

# Generated at 2022-06-21 05:35:39.022743
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    pl = PluginLoader('my_package', 'my_class')
    pl.print_paths()



# Generated at 2022-06-21 05:35:45.898773
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    p = PluginLoader('p.test', 'p.test.plugins', 'test_plugin', 'TestPlugin', required_base_class='test_base')
    assert p.get('f1')
    assert p.get('f2')
    assert not p.get('f3')
    assert not p.get('f4')


# Generated at 2022-06-21 05:35:58.722670
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():

    class PLFake(PluginLoader):

        def __init__(self, package, subdir, aliases, class_name=''):
            super(PLFake, self).__init__(package, subdir, aliases, class_name)

        def _get_paths(self):
            # test data is all in one directory
            return ['test/utils/plugins/action_plugins']

    # test "all" with some invalid plugins
    pl = PLFake('ansible.plugins.action', 'action_plugins', {}, 'ActionBase')
    plugins = list(pl.all())

    assert len(plugins) == 4

    # test default plugin name
    assert 'copy' in plugins
    assert 'copy' in [plugin._load_name for plugin in plugins]

# Generated at 2022-06-21 05:36:09.508913
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    """ Test case to validate that a deprecation warning is logged if expected. """
    class myclass():
        def __init__(self, **kwargs):
            self.kwargs = kwargs
        def get_plugin_class(self, *args, **kwargs):
            pass
        def __reduce_ex__(self, *args, **kwargs):
            return (myclass, self.kwargs)
    plc = PluginLoadContext()
    plc.record_deprecation(myclass(deprecation={'warning_text': 'A Warning'}),
                           collection_name='test_warning')
    assert isinstance(plc.deprecation_warnings[0], str)
    assert ('has been deprecated. A Warning' in plc.deprecation_warnings[0])
    assert plc.dep

# Generated at 2022-06-21 05:36:18.658215
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    plugin_loader = PluginLoader("ansible.plugins.action", "ActionModule", C.DEFAULT_INTERNAL_ACTION_PLUGIN_PATH, "action_plugins")
    paths = plugin_loader._get_paths()
    try:
        assert not os.path.isdir("./ansible_collections/ansible/plugins/action")
    except AssertionError as e:
        pytest.fail("Failed to setup expecation for test_PluginLoader_add_directory . ")
    try:
        assert not any([path.find("./ansible_collections/ansible/plugins/action") >= 0 for path in paths])
    except AssertionError as e:
        pytest.fail("Failed to setup expecation for test_PluginLoader_add_directory . ")

    plugin_loader.add

# Generated at 2022-06-21 05:36:37.214951
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    assert len(get_all_plugin_loaders()) == 3



# Generated at 2022-06-21 05:36:46.287894
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin('sh')
    assert shell is not None
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'
    try:
        shell = get_shell_plugin(None, '/bin/bash')
    except AnsibleError:
        shell = None
    assert shell is None
    shell = get_shell_plugin(None, '/bin/sh')
    assert shell is not None
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'
    shell = get_shell_plugin(None, '/usr/bin/bash')
    assert shell is not None
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/usr/bin/bash'



# Generated at 2022-06-21 05:36:47.871989
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    pass # Not implemented


# Generated at 2022-06-21 05:36:52.188848
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    # Test normal case
    plugin_path_context = PluginPathContext(path=None, internal=False)
    assert plugin_path_context.path == None
    assert plugin_path_context.internal == False



# Generated at 2022-06-21 05:37:04.065744
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    '''
    unit test for PluginLoader class
    '''

    # test environment setup
    import tempfile, shutil

    # test constructor
    plugin_loader = PluginLoader("foo.bar", "baz", "Baz", "BazBase")
    assert plugin_loader.package == "foo.bar"
    assert plugin_loader.subdir == "baz"
    assert plugin_loader.class_name == "Baz"
    assert plugin_loader.base_class == "BazBase"

    # test search paths
    plugin_loader._get_paths = Mock(return_value = ["/baz/"])
    assert plugin_loader._searched_paths == []
    assert plugin_loader.all() == []
    assert plugin_loader._searched_paths == ["/baz/"]

    # test

# Generated at 2022-06-21 05:37:14.627498
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():

    # Test method all of class Jinja2Loader
    # This setup is specific to Jinja2Loader
    # It sets up the bare minimum of values to run the all() method.

    # NOTE: The all() method is the only method called by Ansible code and so is the only one tested.
    #       Jinja2Loader does not have find_plugin or get because of the custom all() method.

    import ansible.plugins.filter as filter_plugins
    import ansible.plugins.test as test_plugins
    from ansible.plugins.loader import Jinja2Loader

    from ansible.utils.path import unfrackpath
    from ansible.module_utils._text import to_text

    # This is the package that contains the actual jinja2 plugins ('filters' or 'tests'), not the ansible files
    # that contain the jinja2 plugins

# Generated at 2022-06-21 05:37:24.290428
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():

    pl = PluginLoader('')


# Generated at 2022-06-21 05:37:30.035863
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    context = PluginLoadContext()
    assert context.pending_redirect is None
    assert context.exit_reason is None
    assert context.plugin_resolved_path is None
    assert context.plugin_resolved_name is None
    assert context.plugin_resolved_collection is None
    assert context.resolved is False
    assert context.removal_date is None
    assert context.removal_version is None



# Generated at 2022-06-21 05:37:32.895725
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    plugin_load_context = PluginLoadContext()
    plugin_load_context.resolve('resolved_name', 'resolved_path', 'resolved_collection', 'exit_reason')
    assert plugin_load_context.resolved_fqcn == 'resolved_collection.resolved_name'


# Generated at 2022-06-21 05:37:46.567082
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    plc = PluginLoadContext()
    removal_date = '5000-01-01'
    removal_version = '5.5.5'
    deprecation = {'removal_date': removal_date, 'removal_version': removal_version}
    plc.record_deprecation('test name', deprecation, 'test_collection')
    assert plc.removal_date == removal_date
    assert plc.removal_version == removal_version
    deprecation = {'removal_date': removal_date, 'removal_version': None}
    plc.record_deprecation('test name', deprecation, 'test_collection')
    assert plc.removal_date == removal_date
    assert plc.removal_version == removal_version

# Generated at 2022-06-21 05:38:19.209535
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    plugin_loader = PluginLoader(package=None,
                                 directories=None,
                                 class_name=None,
                                 aliases=None,
                                 required_base_class=None)
    pickled_plugin_loader = pickle.dumps(plugin_loader)
    unpickled_plugin_loader = pickle.loads(pickled_plugin_loader)
    assert pickled_plugin_loader != unpickled_plugin_loader

# Generated at 2022-06-21 05:38:25.578846
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    import tempfile

    test_dir = tempfile.mkdtemp()
    test_dir_2 = tempfile.mkdtemp()
    os.makedirs(os.path.join(test_dir, 'a', 'b'))
    os.makedirs(os.path.join(test_dir, 'c'))
    os.makedirs(os.path.join(test_dir, 'd'))
    os.makedirs(os.path.join(test_dir, 'x', 'y'))
    os.makedirs(os.path.join(test_dir_2, 'q', 'r', 's'))

    # Test no files
    loader = PluginLoader('no_such_plugin', 'no_such_class', '.', 'test_finder_plugin')
    stop_after = loader

# Generated at 2022-06-21 05:38:39.229644
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    ''' Unit test for constructor of class PluginLoader '''

    cache_plugin_loader = PluginLoader('ansible.plugins.cache', 'CacheModule')
    assert cache_plugin_loader.class_name == 'CacheModule'
    assert cache_plugin_loader.package == 'ansible.plugins.cache'
    assert cache_plugin_loader._searched_paths == [os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible_cache_plugins')]

    # Note that self._module_paths is static for the life of the interpreter, so
    # the test for _get_paths() must be run before the first plugin is loaded.
    assert len(cache_plugin_loader._get_paths()) == 2

    # Test that the exceptions are caught and returned

# Generated at 2022-06-21 05:38:47.307309
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():

    obj = PluginLoader([''])

    # TODO: Add test code here
    try:
        ret = obj.format_paths(['', ''])
        assert False, 'AnsibleAssertionError: failed to assert that False is True'
    except AssertionError as e:
        pass



# Generated at 2022-06-21 05:38:54.169053
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    import os.path
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml import objects
    from ansible.plugins.loader import Jinja2Loader
    loader = Jinja2Loader(
        os.path.join(os.path.dirname(to_bytes(__file__)), 'ansible'),
        'ansible.plugins',
        'TestPlugins',
        'test'
    )
    assert loader.find_plugin('test_jinja2.bar') == os.path.join(loader.package_path, 'test', 'test_jinja2')
    loader._searched_paths = objects.AnsibleVaultEncryptedUnicode()

# Generated at 2022-06-21 05:39:01.808593
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    ''' this test is only for constructor as loader is not filled '''

    # create filter plugin loader
    jinja2_loader = Jinja2Loader('filter_plugins')
    assert jinja2_loader.class_name == 'FilterModule', 'Jinja2Loader() failed to initialize with correct class_name'

    # create test plugin loader
    jinja2_loader = Jinja2Loader('test_plugins')
    assert jinja2_loader.class_name == 'TestModule', 'Jinja2Loader() failed to initialize with correct class_name'



# Generated at 2022-06-21 05:39:11.277200
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    from ansible.plugins.loader import PluginLoader

    pl = PluginLoader("test", "base", "", '', None)
    fake_loader = PluginLoader("fakety", "fake", "", '', None)

    assert len(get_all_plugin_loaders()) == 1
    assert ('MODULE_CACHE', pl) in get_all_plugin_loaders()
    assert ('PATH_CACHE', pl) not in get_all_plugin_loaders()

    assert ('FAKE_CACHE', fake_loader) not in get_all_plugin_loaders()

    # reset globals list so subsequent calls to this or other tests don't
    # inadvertently pick up test fixtures as real plugins
    globals().pop('FAKE_CACHE', None)
    globals().pop('fake_loader', None)



# Generated at 2022-06-21 05:39:22.569127
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    # Test with unprivileged user (no write access to system paths)
    try:
        uid = os.geteuid()
    except AttributeError:
        pass
    else:
        # We only want to run this test once, so make sure we can restore
        # the privileges if needed
        if uid == 0:
            os.seteuid(0)
            priv_user = False
        else:
            os.seteuid(0)
            priv_user = True

# Generated at 2022-06-21 05:39:33.377987
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    ctx = PluginLoadContext()
    assert ctx.original_name == None
    assert ctx.redirect_list == []
    assert ctx.error_list == []
    assert ctx.import_error_list == []
    assert ctx.load_attempts == []
    assert ctx.pending_redirect == None
    assert ctx.exit_reason == None
    assert ctx.plugin_resolved_path == None
    assert ctx.plugin_resolved_name == None
    assert ctx.plugin_resolved_collection == None
    assert ctx.deprecated == False
    assert ctx.removal_date == None
    assert ctx.removal_version == None
    assert ctx.deprecation_warnings == []
    assert ctx.resolved == False
    assert ctx._res

# Generated at 2022-06-21 05:39:38.590323
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    ''' test_Jinja2Loader_find_plugin: Tests if Jinja2Loader class can be called to find_plugin '''

    # Initialize class
    global _JINJA2_RESOLVED_SOURCE_PATH
    _JINJA2_RESOLVED_SOURCE_PATH = None

    # Create a test loader
    loader = Jinja2Loader("ansible.plugins.test")

    # Check if calling find_plugin without name raises an exception
    with pytest.raises(AnsibleError):
        ansible_plugin = loader.find_plugin()

    # Check if calling find_plugin with name raises an exception
    with pytest.raises(AnsibleError):
        ansible_plugin = loader.find_plugin("test")

    # Check if calling find_plugin with name and collection_list does not raise an exception

# Generated at 2022-06-21 05:40:23.252314
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Testing PluginLoader object all method
    test_plugins = PluginLoader("")
    assert all(test_plugins.all(path_only=True)) == True



# Generated at 2022-06-21 05:40:29.370105
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    '''
    This tests the add_all_plugin_dirs function
    :return:
    '''
    try:
        import test

        test.TestPluginLoader.add_directory(os.path.join(os.path.dirname(__file__), 'test_loader'))
        test.test_add_all_plugin_dirs_called = False

        add_all_plugin_dirs('/path/to/nowhere')
        assert not test.test_add_all_plugin_dirs_called

        add_all_plugin_dirs(os.path.join(os.path.dirname(__file__), 'test_loader'))
        assert test.test_add_all_plugin_dirs_called
    finally:
        del sys.modules['test']



# Generated at 2022-06-21 05:40:38.852539
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # NOTE: Plugin loader only works with the ansible package.
    # NOTE: This test will fail on a fresh local dev environment
    #       because we don't put our test plugins in the base path.
    #       To make it work we would have to check all subdirs of the
    #       ansible package and add them to the search path.
    plugin_loader = PluginLoader('callback', 'CallbackModule')

    local_path = os.path.dirname(__file__)
    path1 = os.path.join(local_path, 'plugins/callback')
    path2 = os.path.join(local_path, 'plugins/module_utils')

    # plugin_loader.add_directory returns None and modifies the
    # state of the plugin_loader, so no check needed.
    plugin_loader.add_directory(path1)


# Generated at 2022-06-21 05:40:45.148251
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    '''
    Initialize a plugin_loader and check that the class attribute are correctly set.
    '''
    plugin_loader = PluginLoader(
        package='test_package',
        config=dict(),
        subdir='subdir',
        base_class='test_base_class',
        class_name='test_class_name',
        aliases=dict(),
    )
    assert plugin_loader.package == 'test_package'
    assert plugin_loader.config == dict()
    assert plugin_loader.subdir == 'subdir'
    assert plugin_loader.base_class == 'test_base_class'
    assert plugin_loader.class_name == 'test_class_name'
    assert plugin_loader.aliases == dict()



# Generated at 2022-06-21 05:40:50.858165
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    PL = PluginLoader('ansible.plugins', 'CacheModule', 'ansible.plugins.cache')
    for p in PL.all(_dedupe=False):
        assert isinstance(p, BaseCacheModule)


# Generated at 2022-06-21 05:40:54.687196
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    loader = PluginLoader(package='ansible.plugins.lookup', class_name='LookupBase')
    plugin = loader.get('file')
    assert plugin is not None

# Generated at 2022-06-21 05:40:57.200704
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    PL = PluginLoader('my_package', None, 'my_class', None, 'my_base_class')
    assert PL.format_paths(['one', 'two']) == 'one, two'



# Generated at 2022-06-21 05:41:04.383854
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    # type: () -> None
    ppc = PluginPathContext(path='/var/tmp', internal=False)
    assert ppc.path == '/var/tmp'
    assert not ppc.internal

plugin_path_contexts = defaultdict(list)  # type: DefaultDict[str, List[PluginPathContext]]



# Generated at 2022-06-21 05:41:09.401616
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # Create an instance of Jinja2Loader class
    jinja_loader = Jinja2Loader()

    # Try to find a plugin
    try:
        jinja_loader.find_plugin('plugin_name')
    except AnsibleError as e:
        display.display(e)
        display.display("\'find_plugin\' method for Jinja2Loaders is not implemented")


# Generated at 2022-06-21 05:41:15.731695
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    context = PluginLoadContext()
    msg = "Unit Test for method nope() of class PluginLoadContext, context.resolved should be: False"
    assert context.nope('exit_reason').resolved==False, msg
