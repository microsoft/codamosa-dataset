

# Generated at 2022-06-21 05:34:10.216357
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    test_context = PluginLoadContext()
    test_deprecation = {"warning_text": "test warning","removal_date": "2020-11-15","removal_version": "2.12.0"}
    test_name = "test_record_deprecation"
    test_collection_name = "test_collection"
    test_context.record_deprecation(test_name, test_deprecation, test_collection_name)
    assert test_context.deprecated == True
    assert test_context.removal_date == "2020-11-15"
    assert test_context.removal_version == "2.12.0"
    assert test_context.deprecation_warnings[0] == "test_record_deprecation has been deprecated. test warning"



# Generated at 2022-06-21 05:34:19.695756
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # Load test data
    import ansible.plugins
    # Test type is a subclass of PluginLoader
    # Find the plugin named name
    with pytest.raises(AnsibleError):
        ansible.plugins.all()
    # Check if a plugin named name exists
    with pytest.raises(AnsibleError):
        ansible.plugins.__contains__(None)
    # Instantiate a plugin of the given name using arguments
    with pytest.raises(AnsibleError):
        ansible.plugins.get(None)
    # Instantiate a plugin of the given name using arguments
    with pytest.raises(AnsibleError):
        ansible.plugins.get_with_context(None)
    # Iterate through all plugins of this type

# Generated at 2022-06-21 05:34:30.193021
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    from ansible.utils.collection_loader import _collection_finder
    from . import shell
    import tempfile
    import shutil
    import sys
    import imp

    # Redirect the plugin cache dir to a temp dir
    old_plugin_dir = _collection_finder.PLUGIN_PATH_CACHE
    new_plugin_dir = tempfile.TemporaryDirectory()
    _collection_finder.PLUGIN_PATH_CACHE = new_plugin_dir.name

    plugin_dir = os.path.join(new_plugin_dir.name, 'my_shell')
    os.mkdir(plugin_dir)
    # Write out a fake shell plugin

# Generated at 2022-06-21 05:34:41.690061
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    from ansible.utils.collection_loader._collection_finder import TestPluginLoader, TestModuleLoader
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    plugin_dir = os.path.join(test_dir, 'plugins')
    module_dir = os.path.join(test_dir, 'modules')
    os.mkdir(plugin_dir)
    os.mkdir(module_dir)

    def assert_plugin_dir_empty():
        assert not os.listdir(plugin_dir)


# Generated at 2022-06-21 05:34:44.398670
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    loader = PluginLoader('test', 'test', 'test', 'test')
    assert True


# Generated at 2022-06-21 05:34:47.460029
# Unit test for method find_plugin of class PluginLoader

# Generated at 2022-06-21 05:34:49.986741
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    pass


# Generated at 2022-06-21 05:34:52.933107
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    test_object = get_with_context_result('test_string1', 'test_string2', 'test_string3')
    assert test_object.plugin_name == 'test_string1'
    assert test_object.plugin_type == 'test_string2'
    assert test_object.cache_key == 'test_string3'



# Generated at 2022-06-21 05:34:59.650515
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    # test data and objects
    collection_paths = [os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'units', 'data', 'collection_loader')]
    collection_loader = AnsibleCollectionLoader(collection_paths)
    fixture_loader = Jinja2Loader(class_name='FixtureModule', package='ansible.tests.unit.plugins.loader.data.collection_loader', config_def_loader=collection_loader)
    plugin_loader = Jinja2Loader(class_name='FilterModule', package='ansible.tests.unit.plugins.loader.data.collection_loader', config_def_loader=collection_loader)

# Generated at 2022-06-21 05:35:03.943054
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    plugin_loader = PluginLoader(package='ansible.plugins.action', config=dict(), subdir=None)
    plugin_loader.add_directory(to_native(data_context().content.action_loader_path))
    output = plugin_loader.print_paths()
    assert os.path.exists(output)

# Generated at 2022-06-21 05:35:53.943113
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    ctx = PluginLoadContext()


# Generated at 2022-06-21 05:35:55.263757
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    PL = PluginLoader('source_plugins', 'SourceBase', 'ansible.plugins.source')
    assert PL.find_plugin("some_plugin") is None


# Generated at 2022-06-21 05:35:58.969533
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    test_object = PluginLoadContext()
    redirect_name = "redirect_name"
    exit_reason = "exit_reason"
    result = test_object.nope(exit_reason)
    assert result.pending_redirect is None
    assert result.exit_reason == exit_reason
    assert result.resolved == False


# Generated at 2022-06-21 05:36:08.928465
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    loader = PluginLoader(package='package', directories=['directory'], class_name='class_name', base_class='base_class')
    loader.add_directory('new_directory')
    assert loader.directories == ['directory', 'new_directory'], \
        'add_directory method of PluginLoader object should add a directory to the list of directories'

    loader = PluginLoader(package='package', directories=['directory'], class_name='class_name', base_class='base_class')
    loader.add_directory('directory')
    assert loader.directories == ['directory'], \
        'add_directory method of PluginLoader object should not add an already present directory to the list of directories'


# Generated at 2022-06-21 05:36:09.761897
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    pass

# Generated at 2022-06-21 05:36:10.346905
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    return



# Generated at 2022-06-21 05:36:19.103632
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    from ansible.plugins import action, cache, connection, lookup, module_utils, modules, shell, strategy, test, vars, filter
    all_plugin_loaders = [(a, b) for (a, b) in get_all_plugin_loaders()]

# Generated at 2022-06-21 05:36:31.930694
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    import ansible
    import ansible.plugins
    import ansible.plugins.action
    assert PluginLoader('action', 'plugins', 'ansible.plugins.action').find_plugin_with_context('say').plugin_resolved_name == 'say'
    assert PluginLoader('action', 'plugins', 'ansible.plugins.action').find_plugin_with_context('say').plugin_resolved_path == to_bytes('{0}/ansible/plugins/action/say.py'.format(os.path.dirname(ansible.__file__)))

# Generated at 2022-06-21 05:36:35.895503
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    instance = PluginPathContext("/tmp/foo", True)
    assert instance.path == "/tmp/foo"
    assert instance.internal == True


# Generated at 2022-06-21 05:36:40.956021
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    """
    Unit test for method find_plugin of class Jinja2Loader

    No tests, method is not defined

    :return:
    """
    loader = Jinja2Loader()
    try:
        loader.find_plugin('module')
    except:
        pass
    return


# Generated at 2022-06-21 05:37:14.627763
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    def check(paths, expected):
        r = PluginLoader.format_paths(paths)
        assert r == expected, "expected %r, got %r" % (expected, r)

    check([], '')
    check(['foo'], 'foo')
    check(['foo', 'bar'], 'foo, bar')
    check(['foo', 'bar', 'baz'], 'foo, bar, baz')
    check(['foo', 'a/b/c', 'bar', 'baz'], 'foo, bar, baz')
    check(['foo', 'a/b/c/bar', 'bar', 'baz'], 'foo, bar, baz')

# Generated at 2022-06-21 05:37:19.664743
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    plugin_loaders = get_all_plugin_loaders()
    assert plugin_loaders
    for plugin_loader in plugin_loaders:
        assert isinstance(plugin_loader[1], PluginLoader)
        assert plugin_loader[0] in globals()


# Generated at 2022-06-21 05:37:21.873930
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    loader = Jinja2Loader('', 'filter_loader')
    assert loader.package == 'ansible.plugins.filter_loader'
    assert loader.class_name == 'FilterModule'


# Generated at 2022-06-21 05:37:30.604252
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
  # Test execution

  # default object
  loader1 = PluginLoader('')
  # assert
  assert isinstance(loader1, PluginLoader)

  # object with given parameters
  loader2 = PluginLoader(
    'base_class',
    'class_name',
    package='package_name'
  )
  # assert
  assert isinstance(loader2, PluginLoader)



# Generated at 2022-06-21 05:37:33.836253
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    plugin_loaders = get_all_plugin_loaders()
    assert isinstance(plugin_loaders, tuple)
    assert len(plugin_loaders) == 1
    assert plugin_loaders[0] == ('action', ActionModuleLoader)


# Generated at 2022-06-21 05:37:46.854812
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    expected = get_with_context_result(None, '<MockContext>')

    # test successful case
    loader = Jinja2Loader()
    loader._searched_paths = ['a', 'b', 'c']
    loader._generate_name = MagicMock()
    loader._get_found_names = MagicMock()
    loader._get_found_names.return_value = ['b', 'c']
    loader._check_ignore = MagicMock()
    loader._check_ignore.return_value = True
    loader._import_plugin = MagicMock()
    loader._import_plugin.return_value = expected
    result = loader.get('test_name', 'test_config')
    assert result == expected

    # test invalid parameter case
    loader = Jinja2Loader()

# Generated at 2022-06-21 05:37:56.126024
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    # Test with invalid input
    invalid_inputs = [['', ''], [''], [[''], '']]
    for input in invalid_inputs:
        try:
            if len(input) == 1:
                PluginLoader(*input).print_paths()
            elif len(input) == 2:
                PluginLoader(*input).print_paths(*input)
        except Exception as e:
            if not isinstance(e, TypeError):
                raise Exception("For input: {0}, unexpected error: {1}".format(input, e))


# Generated at 2022-06-21 05:38:08.352770
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    from ansible.module_utils.six import with_metaclass
    from ansible.errors import AnsibleError
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.common.sys_info import is_windows
    from ansible.module_utils._text import to_native
    from ansible.utils.path import unfrackpath, split_path


    class PluginLoader_get_with_context_FileFinder(with_metaclass(PluginLoader, object)):

        def __init__(name, path_suffix):
            pass

    # real method
    # def get_with_context(self, name, *args, **kwargs):
    #     print(args)

    # path_suffix = ['tests/unit/module_utils/test_ansible

# Generated at 2022-06-21 05:38:20.345903
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    class_name = 'Connection'
    collection_list = []
    display = Display()
    package = 'ansible.plugins.connection'
    config = Config(parse_source=dict())
    paths = ['/home/username/.ansible/collections/ansible_collections/test_namespace/test_collection1/plugins/connections',
        '/home/username/.ansible/collections/ansible_collections/test_namespace/test_collection2/plugins/connections',
        '/home/username/.ansible/plugins/connections'
        ]
    base_class = 'ConnectionBase'
    plugin_load_context = PluginLoadContext(package=package, class_name=class_name, config=config, plugin_vars=None, display=display)

# Generated at 2022-06-21 05:38:22.917546
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''

    # FIXME: implement test_PluginLoader___setstate__
    assert False


# Generated at 2022-06-21 05:39:52.494824
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    plc = PluginLoadContext()
    plc.pending_redirect = 'foo'
    plc.plugin_resolved_name = 'foo'
    assert(plc.plugin_resolved_name == 'foo')
    plc.redirect('bar')
    assert(plc.plugin_resolved_name is None)
    assert(plc.pending_redirect == 'bar')


# Generated at 2022-06-21 05:40:02.230405
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    jin = Jinja2Loader('filter_plugins')
    assert jin.package is None
    assert jin.subdir == 'filter_plugins'
    assert jin.class_name == 'FilterModule'
    assert jin.base_class == 'FilterModule'
    assert jin.paths == [os.path.join(os.path.dirname(__file__), '..', '..', 'filter_plugins')]



# Generated at 2022-06-21 05:40:11.566494
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    from ansible import constants as C
    context = PluginLoadContext()
    resolved_name = 'unittest_resolved_name'
    resolved_path = C.DEFAULT_MODULE_PATH
    resolved_collection = 'unittest_resolved_collection'
    exit_reason = 'unittest_exit_reason'
    assert resolved_name == context.resolve(resolved_name, resolved_path, resolved_collection, exit_reason).plugin_resolved_name




# Generated at 2022-06-21 05:40:21.831195
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
  from ansible import context
  from ansible.module_utils.common._collections_compat import Mapping
  from ansible.module_utils._text import to_text
  from ansible.parsing.plugin_docs import read_docstring
  from ansible.plugins.loader import Jinja2Loader
  from ansible.utils.display import Display
  import ansible.plugins
  import ansible.plugins.filter
  import os

  # Initialize jinja2_loader instance

# Generated at 2022-06-21 05:40:23.923289
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    # TODO: Write a unit test for this method if possible. For now, just make sure
    # no exceptions are thrown.
    PluginLoader.__setstate__(None)

# Generated at 2022-06-21 05:40:31.461618
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    p = PluginLoader(package='ansible.plugins.strategy', config=dict(), directories=['/blah'])
    p.has_plugin = Mock(return_value=True)
    assert 'plugin' in p
    p.has_plugin.assert_called_once_with('plugin')


# Generated at 2022-06-21 05:40:39.482031
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    PL = PluginLoader('TestPluginLoader')

    # We should be able to resolve a plugin
    aspc = PL.get_with_context('async_task_poll_timeout')
    assert aspc.resolved
    assert not aspc.duplicate_found
    assert aspc.redirect_list == []
    assert not aspc.found_in_collection
    assert aspc.deprecated_aliases == []
    assert aspc.orig_resolved_name == 'async_task_poll_timeout'
    assert aspc.plugin_resolved_name == 'async_task_poll_timeout'
    assert aspc.plugin_resolved_path.endswith('lib/ansible/plugins/connection/__init__.py')

    # We should be able to resolve a built-in plugin

# Generated at 2022-06-21 05:40:45.724540
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    # Get necessary paths
    test_dir = os.path.dirname(os.path.abspath(__file__))
    files_dir = os.path.join(test_dir, 'files')
    # Get instances of necessary classes
    param_manager = SharedPluginManager()
    config_manager = SharedPluginManager()
    # Get plugins' path
    common_plugin_path = param_manager._get_search_path('ansible.plugins.common')
    module_plugin_path = config_manager._get_module_search_path('ansible.plugins.modules')
    # Get plugin loader instances
    config_loader = PluginLoader(package='ansible.modules', config_manager=config_manager, plugin_path_adder=module_plugin_path)

# Generated at 2022-06-21 05:40:58.858378
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    PLUGIN_PATH.append('./test/unit/utils/')
    PLUGIN_PATH.append('./test/unit/utils/find_plugin/')

    from ansible.plugins.filter.test_foo import TestFoo
    from ansible.plugins.filter.test_bar import TestBar
    from ansible.plugins.filter.test_baz import TestBaz
    from ansible.plugins.filter.test_baz_plugin_loader import TestBazPluginLoader

    test_plugin_loader = PluginLoader(
        package='ansible.plugins.filter',
        class_name='TestFoo',
        base_class=TestFoo,
    )
    # test_plugin_loader.find_plugin('test_baz.py')
    # test_plugin_loader.find_plugin('test_foo.py

# Generated at 2022-06-21 05:41:10.151696
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    from ansible.plugins import group_loader
    from ansible.plugins.loader import filter_loader, test_loader
    from ansible.plugins.test.core import TestModule
    pl = Jinja2Loader(class_name='TestModule', package='ansible.plugins.test', config=None, base_class=TestModule)
    assert issubclass(type(pl), PluginLoader)
    assert type(pl) is Jinja2Loader
    assert type(pl) is Jinja2Loader
    assert pl.is_subclass_instance(group_loader)
    assert pl.is_subclass_instance(filter_loader)
    assert pl.is_subclass_instance(test_loader)
    assert pl.is_subclass_instance(Jinja2Loader)
    assert Jinja2Loader.CUSTOM_DEDUPE is True