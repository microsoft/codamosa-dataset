

# Generated at 2022-06-21 05:34:19.770139
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    temp_instance = PluginLoader(base=None, class_name=None, package=None, config=None)
    result = temp_instance.__repr__()
    assert result == '<ansible.plugins.loader.PluginLoader object>'

# Generated at 2022-06-21 05:34:23.098722
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    loader = PluginLoader(os.path.sep.join([C.DEFAULT_MODULE_PATH, 'action']), 'ActionModule', required_base_class='ActionBase')
    # Cannot have a unit test for the printed order of a list
    assert True


# Generated at 2022-06-21 05:34:26.114016
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    plugin_loader = PluginLoader('test', 'ansible.test', 'TestModule')
    with pytest.raises(AnsibleError):
        plugin_loader.get('', class_only=True)

# Generated at 2022-06-21 05:34:32.528373
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    ctx = PluginLoadContext()
    assert ctx.plugin_resolved_path == None
    ctx = ctx.redirect('test_name')
    assert ctx.pending_redirect == 'test_name'
    ctx = ctx.nope('nope_test')
    assert ctx.exit_reason == 'nope_test'
    assert ctx.resolved == False
    ctx = ctx.resolve('test_name', 'test_path', 'test_collection', 'test_exit_reason')
    assert ctx.plugin_resolved_name == 'test_name'
    assert ctx.plugin_resolved_path == 'test_path'
    assert ctx.plugin_resolved_collection == 'test_collection'
    assert ctx.exit_reason == 'test_exit_reason'

# Generated at 2022-06-21 05:34:37.093795
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    tester = get_shell_plugin(None)
    assert tester.SHELL_FAMILY=='sh'
    tester = get_shell_plugin(None, '/usr/lite.exe')
    assert tester.SHELL_FAMILY=='sh'


# Generated at 2022-06-21 05:34:46.165670
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type='sh', executable='/bin/bash')
    assert shell.executable == '/bin/bash'
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.get_name() == 'sh'


shell_loader = PluginLoader('ShellModule', 'shell_', 'ansible.plugins.shells', C.DEFAULT_SHELL_PLUGIN_PATH, 'shell')
action_loader = PluginLoader('ActionModule', 'action_', 'ansible.plugins.action', C.DEFAULT_ACTION_PLUGIN_PATH, 'action')
cache_loader = PluginLoader('CacheModule', 'cache_', 'ansible.plugins.cache', C.DEFAULT_CACHE_PLUGIN_PATH, 'cache')

# Generated at 2022-06-21 05:34:52.385229
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    class_ = PluginLoader('ansible.plugins.filter.core', 'FilterModule')

    class_.package = 'ansible.plugins.filter.core'
    class_.subdir = 'filter_plugins'
    class_.class_name = 'FilterModule'

    ret = repr(class_)
    assert ret == "<ansible.plugins.filter.core.PluginLoader object at 0x1018b2c88>"


# Generated at 2022-06-21 05:34:58.898983
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    loader = PluginLoader(package='ansible.plugins.lookup',               # Plugin package
                          class_name='LookupBase',                        # Class in plugin module
                          config_key='LOOKUP',                            # config item in config file
                          directories=['ansible/plugins/lookup'],         # Search path
                          aliases={'ansible.plugins.lookup.password': 'password'}, # Aliases for plugins
                          config_base_dirs=['/etc/ansible/'],             # Base dir for config
                          )
    assert loader.find_plugin('password') == 'ansible.plugins.lookup.password'
    assert loader.find_plugin('no_such_plugin') == None


# Generated at 2022-06-21 05:35:09.782653
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    display.deprecated = Mock(return_value=None)
    plc = PluginLoadContext()
    plc.record_deprecation('foo')
    assert not plc.deprecated
    assert plc.removal_date is None
    assert plc.deprecation_warnings == []

    deprecation = {
        'warning_text': 'This is deprecated.',
        'removal_date': 'May 1, 2020',
        'removal_version': '2.10'
    }
    display.deprecated = Mock(return_value=None)
    plc = PluginLoadContext()
    plc.record_deprecation('foo', deprecation, 'some_collection')
    assert plc.deprecated
    assert plc.removal_date == 'May 1, 2020'
    assert plc.rem

# Generated at 2022-06-21 05:35:14.271392
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    loader = Jinja2Loader(None, None, 'ansible.legacy', 'base')
    assert loader.get('name', 'key') == (None, None)


# Generated at 2022-06-21 05:35:47.967597
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    x = PluginLoadContext
    x.redirect_list = []
    x.pending_redirect = 'ansible.posix.file'
    x.exit_reason = 'resolved to ansible.posix.file'
    x.original_name = 'ansible.legacy.file'
    x.plugin_resolved_path = None
    x.plugin_resolved_name = None
    x.plugin_resolved_collection = None
    x.deprecated = False
    x.removal_date = None
    x.removal_version = None
    x.deprecation_warnings = []
    x.resolved = True
    x.redirect('ansible.posix.file')
    x.exit_reason = 'resolved to ansible.posix.file'

# Generated at 2022-06-21 05:35:50.534273
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    assert PluginPathContext('/path', True).path == '/path'
    assert PluginPathContext('/path', True).internal is True



# Generated at 2022-06-21 05:35:54.635988
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():

    class MockPlugin(object):

        # "plugin" is a special method that is used by jinja2 to instantiate plugins.
        def plugin(self):
            pass

        @property
        def name(self):
            # jinja2 uses this as a way of avoiding duplicate plugins
            return getattr(self, '__name__')

    def mock_os_path_splitext(path):
        return abs(hash(path)), 'py'


# Generated at 2022-06-21 05:36:00.963868
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    import pytest
    """
    PluginLoadContext.redirect(redirect_name)
    """

    # test case 1
    context_1 = PluginLoadContext()
    context_1.original_name = 'original'
    context_1.redirect_list = ['redirect_list']
    context_1.error_list = ['error_list']
    context_1.import_error_list = ['import_error_list']
    context_1.load_attempts = ['load_attempts']
    context_1.pending_redirect = 'pending_redirect'
    context_1.exit_reason = 'exit_reason'
    context_1.plugin_resolved_path = 'plugin_resolved_path'
    context_1.plugin_resolved_name = 'plugin_resolved_name'

# Generated at 2022-06-21 05:36:03.681176
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    def _init_loader(path):
        return Jinja2Loader(path, 'ansible.plugins.filter', 'FilterModule')

    assert _init_loader('/foo/bar/baz') == Jinja2Loader('/foo/bar/baz', 'ansible.plugins.filter', 'FilterModule')
    assert _init_loader('/foo/bar/baz:qux') == Jinja2Loader('/foo/bar/baz:qux', 'ansible.plugins.filter', 'FilterModule')


# Generated at 2022-06-21 05:36:05.037023
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    test_plugin_loader = PluginLoader("Type", "class_name", "package", "plugins")
    assert test_plugin_loader.get(3.14) == None


# Generated at 2022-06-21 05:36:07.002180
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plc = PluginLoadContext()
    assert plc.resolved_fqcn is None



# Generated at 2022-06-21 05:36:08.651352
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    pass

# Generated at 2022-06-21 05:36:18.357189
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    class _Jinja2Loader(Jinja2Loader):
        def _get_paths(self):
            # Unit test support, mock out the paths
            return ('/some/path/some_plugin_name.py',)

        # We need to mock out some functions that we don't want to run as part of the unit test.
        # We use a fail-safe value for the return value so that we know that the function was called
        # but we don't need to worry about what the actual value should be, it is not important for
        # the purpose of the test.
        def _load_module_source(self, module_name, path):
            return '_load_module_source'

        def _load_config_defs(self, name, module, path):
            return '_load_config_defs'


# Generated at 2022-06-21 05:36:31.864938
# Unit test for method find_plugin_with_context of class PluginLoader

# Generated at 2022-06-21 05:37:14.808914
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    assert True


# Generated at 2022-06-21 05:37:24.397517
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    import os

    # Create a temp directory
    tempdir = os.path.realpath(tempfile.mkdtemp())

    # Create a temp plugin directory, with a subdir
    os.mkdir(os.path.join(tempdir, 'plugins'))
    os.mkdir(os.path.join(tempdir, 'plugins', 'lookup_plugins'))
    os.mkdir(os.path.join(tempdir, 'plugins', 'action_plugins'))

    # This should fail, because tempdir doesn't exist
    assert not os.path.isdir(os.path.join(tempdir, 'plugins', 'connection_plugins'))
    add_all_plugin_dirs(tempdir)
    # Verify that the temp plugin directory was added

# Generated at 2022-06-21 05:37:29.669959
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    result = get_with_context_result(context=None, context_type=None, loader_type=None)
    assert result.context is None
    assert result.context_type is None
    assert result.loader_type is None
    assert result.plugin_type is None
    assert result.plugin_name is None
    assert result.plugin is None

    result = get_with_context_result(context={}, context_type='context_type_val', loader_type='loader_type_val')
    assert result.context == {}
    assert result.context_type == 'context_type_val'
    assert result.loader_type == 'loader_type_val'
    assert result.plugin_type is None
    assert result.plugin_name is None
    assert result.plugin is None


# Generated at 2022-06-21 05:37:40.781034
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    p = PluginLoader("None", "None")
    # TODO: Mock class object, method __getstate__
    #with patch("ansible.utils.plugin_docs.PluginLoader.__getstate__.cache", new_callable=PropertyMock) as mock_module_cache:
    #    with patch("ansible.utils.plugin_docs.PluginLoader.__getstate__.paths", new_callable=PropertyMock) as mock_module_paths:
    #        mock_module_cache.return_value = True
    #        mock_module_paths.return_value = True
    #        assert p.__getstate__() == {'_module_cache': True, '_module_paths': True}
    # Mocking object instance method not working properly so returning blank dict

# Generated at 2022-06-21 05:37:44.710006
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    print('Testing PluginLoader.__repr__ ...\n')
    pl = PluginLoader()
    print('%r' % pl)
    print('pl.__repr__() = %r' % pl.__repr__())


# Generated at 2022-06-21 05:37:57.441985
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    loader = PluginLoader('ansible.plugins.test', 'TestPlugins')
    assert isinstance(loader, PluginLoader)
    loader.package='ansible.plugins.test'
    loader.class_name='TestPlugins'
    loader.base_class=None
    loader.subdir='test'
    loader.paths=['/tmp/ansible/lib/ansible/plugins/test']
    loader.aliases={}
    loader._searched_paths=['/tmp/ansible/lib/ansible/plugins/test']
    loader._config_defs={}
    loader._module_cache={}

    # Call method

# Generated at 2022-06-21 05:38:04.708923
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    """Test the add_directory method of class PluginLoader
    """
    ansible_loaders = plugin_loader.PluginLoader(
        'AnsibleModule',
        'ansible.plugins'
    )
    ansible_loaders.add_directory("./sample_plugin")

    # Test the result
    sample_plugin_path = "./sample_plugin"
    # FIXME
    # The list returned by the self._get_paths is not predictable.
    # investigate why and fix if needed
    #assert sample_plugin_path in ansible_loaders.searched_paths
    assert os.path.isdir(sample_plugin_path)



# Generated at 2022-06-21 05:38:17.110102
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    #Create a plugin loader
    plugin_loader = PluginLoader(package='ansible.plugins.connection',
                                         base_path=os.path.join(os.path.dirname(__file__), '..', 'lib', 'ansible', 'plugins', 'connection'),
                                         class_name='ConnectionBase',
                                         base_class='ansible.plugins.connection.ConnectionBase',
                                         require_plugin_name=True,
                                         extra_paths=[])
    #Collect the paths
    paths = plugin_loader.print_paths()
    #Test one entry from the paths
    assert paths[0] == 'ansible.plugins.connection.local'

# Generated at 2022-06-21 05:38:29.547113
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    path = '/home/user/plugin'
    plugin_loader = PluginLoader(path)
    plugin_loader.configuration_defs = dict()
    plugin_loader.aliases = dict()
    plugin_loader._searched_paths = str()
    plugin_loader._module_cache = dict()
    plugin_loader._searched_paths = str()
    plugin_loader._searched_collections = dict()
    plugin_loader._searched_collections = dict()
    plugin_loader._paths_cache = dict()
    plugin_loader._plugin_package_map = dict()

    # Invoke method
    plugin_loader.__getstate__()

    # Check if the attributes are not cached after __getstate__ is called
    assert plugin_loader.configuration_defs is None
    assert plugin_loader

# Generated at 2022-06-21 05:38:40.467117
# Unit test for method __contains__ of class PluginLoader

# Generated at 2022-06-21 05:39:10.730898
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    pl = PluginLoader(
        "ansible.plugins.action",
        "ActionModule",
        C.DEFAULT_ACTION_PLUGIN_PATH,
        "action_"
    )
    assert repr(pl) == "PluginLoader(class_name='ActionModule', package='ansible.plugins.action', config_base_names=['action_plugins'], config_section='defaults', aliases={}, required_base_class=None)"



# Generated at 2022-06-21 05:39:15.510252
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    o = PluginLoader()
    o.__setstate__({"collection_list": "collection_list", "class_name": "class_name", "package": "package"})


# Generated at 2022-06-21 05:39:18.375618
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin('sh', executable='sh')
    assert(isinstance(shell, ShellModule))


# Generated at 2022-06-21 05:39:22.386254
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    '''
    Test to instantiates a plugin of the given name using arguments.
    '''
    self = PluginLoader('Test', 'ansible.plugins.test')
    name = 'action'
    args = [1, 2]
    kwargs = {'kwargs': {}}
    obj = self.get_with_context(name, *args, **kwargs)
    return obj


# Generated at 2022-06-21 05:39:33.323452
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    cb = PluginLoadContext()

    # Test deprecation warning for empty data
    cb = cb.record_deprecation("name", {}, "some_collection")
    assert cb.deprecation_warnings == ['name has been deprecated.']
    assert cb.deprecated is True

    # Assert the deprecation warning is properly printed with no explicit warning text
    display.verbosity = 2
    with warnings.catch_warnings(record=True) as w:
        cb = cb.record_deprecation("name", {'removal_version': '3.0'}, "some_collection")
    assert len(w) == 1
    assert 'Deprecated' in str(w[-1].message)
    assert 'removal_version' in str(w[-1].message)

    # Assert

# Generated at 2022-06-21 05:39:43.954937
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    from ansible.plugins.shell.sh import ShellModule as ShShellModule
    from ansible.plugins.shell.bash import ShellModule as BashShellModule
    from ansible.plugins.shell.dash import ShellModule as DashShellModule
    from ansible.plugins.shell.ksh import ShellModule as KshShellModule
    from ansible.plugins.shell.tcsh import ShellModule as TcshShellModule
    from ansible.plugins.shell.zsh import ShellModule as ZshShellModule
    assert get_shell_plugin('sh').__class__.__name__ == ShShellModule.__name__
    assert get_shell_plugin('bash').__class__.__name__ == BashShellModule.__name__
    assert get_shell_plugin('dash').__class__.__name__ == DashShellModule.__name__
    assert get_shell_plugin

# Generated at 2022-06-21 05:39:48.507396
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    P = PluginLoader("your.package", "your.plugin_base.class")
    assert repr(P) == "< PluginLoader your.package your.plugin_base.class >"



# Generated at 2022-06-21 05:39:55.890588
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Ensure the method adds the directory to the search path
    loader = PluginLoader(
        'ansible.plugins.action',
        'ActionModule',
        C.DEFAULT_INVENTORY_PLUGINS_PATH,
        'action_plugins',
    )

    assert C.ANSIBLE_ACTION_PLUGINS not in loader._searched_paths
    # Directory path to add
    new_dir = '/path/ansible/plugins'
    loader.add_directory(new_dir)
    assert C.ANSIBLE_ACTION_PLUGINS in loader._searched_paths
    assert new_dir in loader._searched_paths


# Generated at 2022-06-21 05:39:59.295082
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    PLUGIN_PATH_CACHE.clear()
    os.environ.pop('ANSIBLE_CALLBACK_PLUGINS', None)
    os.environ.pop('ANSIBLE_CONNECTION_PLUGINS', None)
    os.environ.pop('ANSIBLE_LOOKUP_PLUGINS', None)
    os.environ.pop('ANSIBLE_NETCONF_PLUGINS', None)
    os.environ.pop('ANSIBLE_VARS_PLUGINS', None)
    os.environ.pop('ANSIBLE_FILTER_PLUGINS', None)
    os.environ.pop('ANSIBLE_STRATEGY_PLUGINS', None)
    os.environ.pop('ANSIBLE_ACTION_PLUGINS', None)

# Generated at 2022-06-21 05:40:08.015670
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    """Unit test for PluginLoader.__repr__"""

    plugin_loader_1 = PluginLoader(package='ansible.plugins.action', directory=None)
    plugin_loader_2 = PluginLoader(package='ansible.plugins.cache', directory='cache_plugins')
    plugin_loader_3 = PluginLoader(package='ansible.modules.network', directory='library')
    plugin_loader_4 = PluginLoader(package='ansible_collections.namespace.collection.plugins.module_utils', directory=None)
    plugin_loader_5 = PluginLoader(package='ansible_collections.namespace.collection.plugins.test', directory='test_plugins')


# Generated at 2022-06-21 05:41:30.886663
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    class Test_Jinja2Loader(Jinja2Loader):
        """
            Jinja2Loader that stores module data
        """
        def __init__(self, class_name, package, subdir, collection_list=None):
            super(Test_Jinja2Loader, self).__init__(class_name, package, subdir, collection_list=collection_list)
            # store all module data
            self.module_data = dict()

        def _load_module_source(self, name, path):
            # simulate module code
            module = super(Test_Jinja2Loader, self)._load_module_source(name, path)
            self.module_data[name] = (path, module)
            return module

    # NOTE: We assume no filters in plugin paths

# Generated at 2022-06-21 05:41:35.201890
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    assert(Jinja2Loader._PLUGIN_FILTERS['ansible.legacy']['base.py'] ==
           'base.py is a legacy wrapper for __init__.py')



# Generated at 2022-06-21 05:41:39.835095
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    assert False, "Unit tests not implemented"

    # Tests that otherwise pass None to the method.
    # Tests that we prevent case when not a string or a list
    # Tests that we prevent case when exit_reason is a list.
    #

# Generated at 2022-06-21 05:41:52.317088
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    b_path = os.path.expanduser(b'~/.ansible/plugins/')
    assert os.path.isdir(b_path)
    # Create some fake subdirs to add
    dirs = [b'action', b'action/test', b'become', b'connection', b'filter']
    for d in dirs:
        os.makedirs(os.path.join(b_path, d))
    for name, obj in get_all_plugin_loaders():
        if obj.subdir:
            plugin_path = os.path.join(b_path, obj.subdir)
            assert os.path.isdir(plugin_path)
            obj.add_directory(to_text(plugin_path))
            # Remove the directory from the list of ones to check
            dirs.remove

# Generated at 2022-06-21 05:42:03.149504
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin('bash', '/bin/bash')
    assert shell
    assert shell.SHELL_FAMILY == 'bash'
    assert shell.executable == '/bin/bash'
    assert shell.SHELL_NAME == 'bash'

    shell = get_shell_plugin('sh', '/bin/sh')
    assert shell
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'
    assert shell.SHELL_NAME == 'sh'

    shell = get_shell_plugin(None, '/bin/sh')
    assert shell
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'
    assert shell.SHELL_NAME == 'sh'


# Generated at 2022-06-21 05:42:10.818328
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    test_plugin_loaders = {}
    for plugin_type, plugin_loader in get_all_plugin_loaders():
        test_plugin_loaders[plugin_type] = plugin_loader
    assert plugin_loaders == test_plugin_loaders

plugin_loaders = {}
for plugin_type, plugin_loader in get_all_plugin_loaders():
    plugin_loaders[plugin_type] = plugin_loader()



# Generated at 2022-06-21 05:42:23.554947
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    import ansible.plugins.loader
    loaders = ansible.plugins.loader.get_all_plugin_loaders()
    assert len(loaders) > 0
    for plugin_type, plugin_loader in loaders:
        assert plugin_type.endswith('_loader')
        assert isinstance(plugin_loader, PluginLoader)
        assert isinstance(plugin_loader, type)
        assert issubclass(plugin_loader, PluginLoader)
        assert plugin_loader.subdir, "%s plugins have no subdir defined" % plugin_type


# This is a simple plugin loader which doesn't do any fancy
# things like caching or relocations. It just looks in the
# configured plugin directories, and loads things in order.
#
# It also implements the search_path structure used by the
# more complex loaders, so that it can be used as

# Generated at 2022-06-21 05:42:29.290030
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    import os
    import inspect
    import sys
    import tempfile

    currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    parentdir = os.path.dirname(currentdir)
    sys.path.insert(0, parentdir)

    # Set up the directories that we'll use to find plugins
    plugin_loader = Jinja2Loader('ansible.template.tmp', class_name='J2FilterModule')
    test_paths = [os.path.join(parentdir, 'test', 'template', 'filter_plugins')]

    # Make a temporary directory to use as the CWD