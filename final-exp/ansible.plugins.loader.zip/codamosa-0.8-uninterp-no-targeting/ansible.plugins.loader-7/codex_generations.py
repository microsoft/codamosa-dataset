

# Generated at 2022-06-21 05:34:59.229885
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    loader = PluginLoader(
        'action',
        'ActionModule',
        C.DEFAULT_ACTION_PLUGIN_PATH,
        'action_plugins',
    )

    assert_raises(AnsibleError, loader.all, path_only=True, class_only=True)

    action_plugins = sorted([a.__class__.__name__ for a in loader.all()])
    assert action_plugins == sorted([
        'ActionModule',
        'AsyncActionModule',
        'AsyncTaskActionModule',
        'TaskActionModule',
    ])

    action_paths = sorted(loader.all(path_only=True))

# Generated at 2022-06-21 05:35:09.659359
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    plugin_load_context = PluginLoadContext()
    plugin_load_context.resolve('test plugin_load_context name', 'test plugin_load_context path', 'test plugin_load_context collection', 'test plugin_load_context exit reason')
    assert plugin_load_context.plugin_resolved_name == 'test plugin_load_context name'
    assert plugin_load_context.plugin_resolved_path == 'test plugin_load_context path'
    assert plugin_load_context.plugin_resolved_collection == 'test plugin_load_context collection'
    assert plugin_load_context.exit_reason == 'test plugin_load_context exit reason'
    assert plugin_load_context.pending_redirect == None
    assert plugin_load_context.resolved == True

# Generated at 2022-06-21 05:35:18.707734
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Constructor test:
    # Using the constructor to create the class:
    #     PluginLoader(package, class_name=None, config=None, subdir=None, aliases=None, required_base_class=None)
    obj = PluginLoader('package', 'class_name', 'config', 'subdir', 'aliases', 'required_base_class')
    # Tests the method get_with_context of class PluginLoader:
    #     get_with_context(self, name, *args, **kwargs)
    obj.get_with_context('name')



# Generated at 2022-06-21 05:35:22.760635
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    assert all(isinstance(obj, PluginLoader) for name, obj in get_all_plugin_loaders())

# Note: this is needed until all plugins globally move to a new
#       style of inheriting baseclasses

# Generated at 2022-06-21 05:35:29.671175
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    # Setup
    display = Display()
    display.DEBUG = False
    display.verbosity = 2
    callback = MagicMock(return_value=None)
    display.display = callback

    # Execute
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_loader.find_plugin = MagicMock(return_value='/path/to/plugins/action')

    plugin_loader.get('setup')
    plugin_loader.get('setup')

    # Assert
    callback.assert_called_once_with('Loading action_plugin \'setup\' from /path/to/plugins/action (found_in_cache=True, class_only=False)')



# Generated at 2022-06-21 05:35:37.526327
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test case #1
    name = 'name'
    collection_list = None
    loader = PluginLoader('ansible.module_utils', 'Ansiballz', '_original_path', '_load_name', '_redirected_names', '_task_vars')
    res = loader.get_with_context(name, collection_list)
    assert not res.resolved
    assert res.plugin_resolved_name
    assert not res.plugin_resolved_path
    assert not res.redirect_list
    assert not res.object
    
    # Test case #2
    name = 'get_with_context_result'
    collection_list = None

# Generated at 2022-06-21 05:35:39.920156
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    foo = PluginLoadContext()
    foo.nope("exit_reason")
    assert foo.exit_reason == "exit_reason"
    assert foo.resolved == False


# Generated at 2022-06-21 05:35:48.609904
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    import sys
    import ansible.plugins.connection

    if sys.version_info[0] == 2:
        return # This test is not valid for py2.

    PluginLoader.add_directory(os.path.join(os.path.dirname(ansible.plugins.connection.__file__), '../test/unit/plugins'))
    res = PluginLoader('connection').get_with_context('test_get_with_context')
    assert res.object is None, res.errors

# Generated at 2022-06-21 05:35:52.935443
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    context = PluginPathContext(path=b'/this/is/a/path', internal=True)
    assert context.path == b'/this/is/a/path'
    assert context.internal is True


# Generated at 2022-06-21 05:35:57.173279
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    PL = PluginLoader(package='ansible.plugins.test.a', class_name='TestPlugin')
    PL.add_directory(DIRECTORY_TEST_FILES)
    assert PL._searched_paths[0] == DIRECTORY_TEST_FILES


# Generated at 2022-06-21 05:36:46.349321
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plc = PluginLoadContext()
    assert plc.original_name == None
    assert plc.redirect_list == []
    assert plc.error_list == []
    assert plc.import_error_list == []
    assert plc.load_attempts == []
    assert plc.pending_redirect == None
    assert plc.exit_reason == None
    assert plc.plugin_resolved_path == None
    assert plc.plugin_resolved_name == None
    assert plc.plugin_resolved_collection == None
    assert plc.deprecated == False
    assert plc.removal_date == None
    assert plc.removal_version == None
    assert plc.deprecation_warnings == []
    assert plc.resolved == False
    assert plc._res

# Generated at 2022-06-21 05:36:51.333514
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    loader = PluginLoader(
         package='my_package.plugins',
         class_name='Plugin',
         base_class='MyBaseClass'
    )
    with pytest.raises(Exception): # because no test data
        result = loader.get_with_context('test_plugin', *[], **{})


# Generated at 2022-06-21 05:36:57.051866
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Add the current directory to all plugin directories
    add_all_plugin_dirs('.')
    # Make sure there are at least some plugins in some directories
    for name, obj in get_all_plugin_loaders():
        assert len(obj._directories) > 0


# Generated at 2022-06-21 05:37:03.166632
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
  pl = PluginLoader( package='ansible.plugins.test',
                     config=None,
                     subdir='module_utils',
                     class_name='AnsibleModule',
                     base_class='AnsibleModule',
                     namespace='ansible.module_utils' )
  assert pl.__repr__() == '<ansible.plugins.loader.PluginLoader object for module_utils in ansible.plugins.test>'

# Generated at 2022-06-21 05:37:04.706416
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    assert PluginLoadContext().redirect("redirect_name").plugin_resolved_name == None

# Generated at 2022-06-21 05:37:06.364752
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    test_result = get_with_context_result({'a': 1}, ['a'])
    assert test_result.results == {'a': 1}
    assert test_result.context == ['a']
    assert test_result.not_found is None



# Generated at 2022-06-21 05:37:09.458365
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    player = PluginLoader()
    assert (player.__contains__('setup') is True)

# Generated at 2022-06-21 05:37:13.607112
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    print('Testing method get_with_context of <class PluginLoader>.')
    pass

# Generated at 2022-06-21 05:37:23.965336
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    name = 'test_name'
    collection_name = 'test_collection_name'
    deprecation = {'warning_text': 'no warning text specified', 'removal_version': '2.9'}
    exit_reason = 'pending redirect resolution from {0} to {1}'.format(name, name)

    test_plugin_load_context = PluginLoadContext()
    test_plugin_load_context.exit_reason = exit_reason
    test_plugin_load_context.record_deprecation(name, deprecation, collection_name)

    assert test_plugin_load_context.deprecated == True
    assert test_plugin_load_context.removal_version == '2.9'

# Generated at 2022-06-21 05:37:31.243294
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    # instantiate a PluginLoader
    pl = PluginLoader('acme.plugins', 'acme.plugins_cache')

    # test various path lists
    assert pl.format_paths("foo") == "foo"

    assert pl.format_paths([]) == ""
    assert pl.format_paths(['foo']) == "foo"
    assert pl.format_paths(['foo', 'bar']) == "foo,bar"
    assert pl.format_paths(['foo', 'bar', 'foo']) == "foo,bar"


# Generated at 2022-06-21 05:38:11.545655
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    context = PluginLoadContext()
    assert context.resolved is False
    assert context.pending_redirect is None
    assert context.exit_reason is None
    assert context.resolved_fqcn is None
    assert context.nope('dummy_exit') is context
    assert context.resolved is False
    assert context.exit_reason == 'dummy_exit'
    assert context.resolved_fqcn is None


# Generated at 2022-06-21 05:38:17.862000
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    class test(object):
        def __init__(self, *args, **kwargs):
            pass
    pl = PluginLoader('test', 'test', test, 'test')
    assert pl.package == 'test'
    assert pl.paths == []
    assert pl.class_name == 'test'
    assert pl.base_class == 'test'



# Generated at 2022-06-21 05:38:24.187585
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    class_name = 'foo'
    package = 'ansible.plugins.mock_plugin_loader'
    plugin_loader = PluginLoader(class_name, package)
    expected = class_name + "@" + package
    assert str(plugin_loader) == to_text(expected)


# Generated at 2022-06-21 05:38:32.403164
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    """
    Test function for get_with_context method of class PluginLoader
    """

    # Test return type
    print("PluginLoader - find_plugin (str)")
    assert not PluginLoader("foo").get_with_context("")
    assert PluginLoader("foo").get_with_context("file")

    # Test return type
    print("PluginLoader - find_plugin (list)")
    assert PluginLoader("foo").get_with_context(["file", "test"])

    # Test return type
    print("PluginLoader - find_plugin (str, class_only=True)")
    assert PluginLoader("foo").get_with_context("file", class_only=True)

    # Test return type
    print("PluginLoader - find_plugin (str, path_only=True)")
    assert PluginLoader("foo").get_with_

# Generated at 2022-06-21 05:38:33.667833
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    # TODO: Need to create some plugins to load
    assert False


# Generated at 2022-06-21 05:38:41.688995
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    import unittest
    import tempfile
    import shutil
    import ansible.errors as errors
    import ansible.utils.collection_loader

    #######################################################
    # Temporary test cases and data
    #######################################################
    def create_temp_dir(name):
        tempdir = tempfile.mkdtemp(prefix='ansible_test_%s_' % name)

        def cleanup_temp_dir():
            shutil.rmtree(tempdir)
        return tempdir, cleanup_temp_dir

    def create_temp_file(name, content=None):
        fd, path = tempfile.mkstemp(prefix='ansible_test_%s_' % name)
        if content:
            os.write(fd, to_bytes(content))
        return path


# Generated at 2022-06-21 05:38:52.895008
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # We create a mock to replace the actual import mechanism.
    # When the code tries to 'import os', we will return the
    # fake 'os' module.
    class FakeModule:
        def __init__(self, *args):
            self.FAKE_VAR = 'FAKE_VAR'
    # Test a simple case with a static path
    mock_find_plugin = Mock(return_value=FakeModule())
    api.load_library_module(mock_find_plugin, 'ansible.plugins.loader', '_find_plugin')
    # Test that the fake plugin is loaded and available under 'os'
    assert 'FAKE_VAR' in ansible.plugins.loader.os.__dict__
    # Test that find_plugin() was called with the correct arguments
    # The second parameter is a tuple, which represents a

# Generated at 2022-06-21 05:38:58.892674
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin('ssh')
    assert shell.SHELL_FAMILY == 'ssh'
    shell = get_shell_plugin(executable='ssh')
    assert shell.SHELL_FAMILY == 'ssh'



# Generated at 2022-06-21 05:39:08.266253
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    cls_name = 'PluginLoader'

    pluginloader = PluginLoader(cls_name)

    str_result = pluginloader.__getstate__()
    expected = '{"class_name": "PluginLoader", "package": "ansible.plugins", "path": {}, "_searched_paths": [], "_module_cache": {}}'
    assert str_result == expected, 'ansible.utils.plugin_docs.{0}() __getstate__ fail, expected {1}, got {2}'.format(cls_name, expected, str_result)

# Generated at 2022-06-21 05:39:21.467481
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    class_1 = PluginLoader([], '', '', False)
    class_1._get_paths = lambda  a: [[]]
    class_1.find_plugin = lambda  a: [[]]
    class_1.find_plugin_with_context = lambda  a: [[]]
    class_1.has_plugin = lambda  a: [[]]
    class_1._get_redirected_fq_name = lambda  a: [[]]
    class_1._load_module_source = lambda  a: [[]]
    class_1.get = lambda  a: [[]]
    class_1.get_with_context = lambda  a: [[]]
    class_1.all = lambda  a: [[]]
    class_1.all_with_context = lambda  a: [[]]
    class_1._load_config_

# Generated at 2022-06-21 05:39:40.621889
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    pluginLoadContext = PluginLoadContext()
    pluginLoadContext.nope('exit_reason')
    assert pluginLoadContext.resolved == False



# Generated at 2022-06-21 05:39:53.690182
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    obj = PluginLoader('Incorrect', 'base')
    obj.package = 'ansible.plugins.action'
    # Incorrect return type
    with pytest.raises(AssertionError) as execinfo:
        obj.find_plugin_with_context('example')
    assert 'returned value must be a PluginLoaderContext' in str(execinfo.value)

    # Test loading from a plugin file
    name = 'example'
    obj.package = 'ansible.plugins.action'
    plugin_load_context = obj.find_plugin_with_context(name)
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == name
    assert os.path.isabs(plugin_load_context.plugin_resolved_path)
    assert plugin_load_context.plugin_

# Generated at 2022-06-21 05:39:57.593709
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # What's the plugin path
    plugin_path = os.getcwd()
    assert plugin_path
    # add all plugin_dirs
    add_all_plugin_dirs(plugin_path)
    # validate all plugin_dirs
    for name, obj in get_all_plugin_loaders():
        if obj.subdir:
            plugin_path = os.path.join(b_path, to_bytes(obj.subdir))
            assert os.path.isdir(plugin_path)



# Generated at 2022-06-21 05:39:58.642389
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    pass

# Generated at 2022-06-21 05:40:07.566099
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    acr = AnsibleCollectionRef.from_str('my_namespace.my_collection')
    p = PluginLoadContext()
    dep_data = {
        'warning_text': 'test warning text',
        'removal_date': '2020-05-15',
        'removal_version': '9.0.0'
    }
    p.record_deprecation(acr, dep_data, collection_name='my_namespace.my_collection')
    assert p.deprecation_warnings == ['{0} has been deprecated. test warning text'.format(acr)]
    assert p.deprecated is True
    assert p.removal_date == dep_data['removal_date']
    assert p.removal_version is None



# Generated at 2022-06-21 05:40:18.241309
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # test for action plugin loader
    old_action_plugin_dirs = ['/old/action/dir1', '/old/action/dir2']
    new_action_plugin_dirs   = ['/new/action/dir1', '/new/action/dir2']

    old_action_plugin_paths = ['/old/action/dir1/a', '/old/action/dir2/b']
    new_action_plugin_paths = ['/new/action/dir1/c', '/new/action/dir2/d']

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        add_dirs_to_loader('action', old_action_plugin_dirs)
        # Ensures that the right arguments are passed to the loader.add_directory

# Generated at 2022-06-21 05:40:27.335451
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    import pytest
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import Jinja2Loader
    from ansible.utils.path import unfrackpath, tmp_plugin_path
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-21 05:40:38.105263
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    '''Unit test for constructor of class Jinja2Loader'''
    import ansible.plugins.cache as cp
    jj_loader = Jinja2Loader(cp, 'FilterModule', C.DEFAULT_JINJA2_EXTENSIONS, 'filter_plugins', 'filter')

    assert jj_loader.package == 'ansible.plugins.cache'
    assert jj_loader.class_name == 'FilterModule'
    assert jj_loader.subdir == 'filter_plugins'
    assert jj_loader.plugin_type == 'filter'

    # test _get_paths()
    jj_loader._searched_paths = []
    jj_loader._get_paths()

    # test _load_module_source()
    jj_loader._load_module_source('1', '2')

# Generated at 2022-06-21 05:40:43.561014
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    names = [
        'aaa',
        'bbb',
        'ccc',
        'ddd',
        'eee',
    ]
    for arg in names:
        assert PluginLoader.get(arg) == 'abc'



# Generated at 2022-06-21 05:40:46.672396
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    plugin_loader = PluginLoader(package='ansible.plugins.action', directories=[])
    assert repr(plugin_loader) == "PluginLoader(package='ansible.plugins.action', class_name='ActionModule', base_class=None)"


# Generated at 2022-06-21 05:41:19.850365
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    '''
    Unit test for method __contains__ of class PluginLoader
    '''

    import ansible.plugins.cache
    collection_list = ['/my/collections/path/ansible_collections/collection1/ansible_collections/collection2', '/my/collections/path/ansible_collections/collection1', '/my/collections/path']
    loader = PluginLoader(package='ansible.plugins.cache',
                          directories=collection_list,
                          class_name='CacheModule',
                          aliases={},
                          namespace_overrides={})

    assert(loader.has_plugin('action'))
    assert(not loader.has_plugin('action_nope'))
    assert(loader.has_plugin('action', collection_list=collection_list))

# Generated at 2022-06-21 05:41:28.596048
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    obj = PluginLoader('type', 'package', 'base')
    assert obj.format_paths(['/etc']) == "/etc"
    assert obj.format_paths(['/etc', '/usr']) == "/etc, /usr"
    assert obj.format_paths(['/a/long/path/this/is', '/usr']) == "/a/long/path/this/is, /usr"
    assert obj.format_paths([]) == ""



# Generated at 2022-06-21 05:41:41.225353
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    #print("\n----------")
    #print("testing PluginLoader.format_paths")
    class DummyPluginLoader(PluginLoader):
        def __init__(self, package, subdir):
            super(DummyPluginLoader, self).__init__(package, subdir)

    plugin_loader = DummyPluginLoader('ansible.plugins.filter', 'filter_plugins')
    paths = [
        '~/ansible/ansible/lib/ansible/plugins/filter/template.py',
        '~/ansible/ansible/lib/ansible/plugins/filter/debug.py'
    ]


# Generated at 2022-06-21 05:41:52.992920
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    """
    test __setstate__
    """

    # testing non-loaded pluginloader
    pl = PluginLoader(None, None, None, None)
    assert pl.package is None
    assert pl.base_class is None
    assert pl.class_name is None
    assert pl.paths is None
    assert pl.aliases == {}
    assert pl.module_cache == {}
    assert pl.searched_paths is None
    assert pl.config_defs == {}


# Generated at 2022-06-21 05:42:01.243756
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    import os
    os.environ['SHELL'] = '/bin/sh'
    assert get_shell_plugin('sh', '/bin/sh')
    assert get_shell_plugin('sh', '/bin/bash')
    assert get_shell_plugin(executable='/bin/sh')
    assert get_shell_plugin(executable='/bin/bash')
    assert get_shell_plugin(None, '/bin/sh')
    assert get_shell_plugin(None, '/bin/bash')



# Generated at 2022-06-21 05:42:12.705186
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    from ansible.plugins.loader import connection_loader, fragment_loader

    name = 'local'
    plugin_load_context = connection_loader.find_plugin_with_context(name)
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'local'
    assert plugin_load_context.plugin_resolved_fqcr == 'ansible.plugins.connection.local'
    assert plugin_load_context.plugin_resolved_path.endswith('connection/local.py')
    assert plugin_load_context.plugin_type == 'connection_loader'
    assert plugin_load_context.search_proxy_sections == ['connection_plugins', 'defaults']

    plugin_load_context = fragment_loader.find_plugin_with_context(name)
    assert plugin_load

# Generated at 2022-06-21 05:42:24.298689
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    context = PluginLoadContext()
    assert context.original_name is None
    assert len(context.redirect_list) == 0
    assert len(context.error_list) == 0
    assert len(context.import_error_list) == 0
    assert len(context.load_attempts) == 0
    assert context.pending_redirect is None
    assert context.exit_reason is None
    assert context.plugin_resolved_path is None
    assert context.plugin_resolved_name is None
    assert context.plugin_resolved_collection is None
    assert context.deprecated is False
    assert context.removal_date is None
    assert context.removal_version is None
    assert len(context.deprecation_warnings) == 0
    assert context.resolved is False
    assert context._resolved_

# Generated at 2022-06-21 05:42:34.653386
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
  plugin_loader = PluginLoader(
      package='ansible.plugins.action',
      config=None,
      subdir='modules',
      class_name='ActionModule',
      aliases={},
      required_base_class='ActionModule',
  )
  name = 'fake_plugin'
  mock_action_plugin_path = mock.mock_open(read_data='fake_action_plugin')
  with mock.patch('builtins.open', mock_action_plugin_path):
    result = plugin_loader.get_with_context(name)
  assert result.object is not None
  assert result.plugin_load_context.is_resolved
  assert result.plugin_load_context.plugin_resolved_fqcr is None
  assert result.plugin_load_context.plugin_resolved_name == name