

# Generated at 2022-06-21 05:34:21.809521
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    j2 = Jinja2Loader()
    actual = list(j2.all())
    assert len(actual) > 0



# Generated at 2022-06-21 05:34:28.189635
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    obj = PluginLoader()
    # Test with an instance of a class
    with pytest.raises(AnsibleError) as excinfo:
        PluginLoader.__getstate__(obj)
    assert to_text(excinfo.value) == 'PluginLoader instances are not allowed to be pickled'
    # Test with a string
    with pytest.raises(AnsibleError) as excinfo:
        PluginLoader.__getstate__("")
    assert to_text(excinfo.value) == 'PluginLoader instances are not allowed to be pickled'
    # Test with a number
    with pytest.raises(AnsibleError) as excinfo:
        PluginLoader.__getstate__(1)
    assert to_text(excinfo.value) == 'PluginLoader instances are not allowed to be pickled'
    # Test with

# Generated at 2022-06-21 05:34:33.197596
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    pl = PluginLoader('callback', 'ansible.plugins.callback', C.DEFAULT_CALLBACK_PLUGINS, 'callback', 'CallbackBase')
    obj = pl.get('debug')
    assert obj is not None
    assert isinstance(obj, object)
    pl = PluginLoader('connection', 'ansible.plugins.connection', C.DEFAULT_CONNECTION_PLUGINS, 'connection', 'ConnectionBase')
    obj = pl.get('local')
    assert obj is not None
    assert isinstance(obj, object)


# Generated at 2022-06-21 05:34:43.964348
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    from ansible.utils.plugin_docs import get_loader_docs
    from importlib import import_module
    for plugin_type, plugin_loader in get_all_plugin_loaders():
        if not plugin_type.startswith('_'):
            for name, plugin in sorted(plugin_loader.all().items()):
                if not name.startswith('_'):
                    assert plugin.__doc__
            const = import_module('ansible.constants.%s' % plugin_type)
            assert getattr(const, 'DOCUMENTATION')
            assert get_loader_docs(plugin_type, plugin_loader)
test_get_all_plugin_loaders.__test__ = True  # pylint: disable=invalid-name



# Generated at 2022-06-21 05:34:54.624942
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
  class_name = rand_str()
  package = rand_str()
  basedir = rand_str()
  subdir = rand_str()
  base_class = rand_str()

  MockPL = PluginLoader(class_name, package, basedir, subdir, base_class)

  expected = '<PluginLoader class_name=%s, package=%s, basedir=%s, subdir=%s, base_class=%s>' % (class_name, package, basedir, subdir, base_class)
  assert repr(MockPL) == expected

# Generated at 2022-06-21 05:35:09.418749
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    import ansible.plugins
    import ansible.plugins.callback
    import ansible.plugins.connection
    import ansible.plugins.lookup
    import ansible.plugins.shell
    import ansible.plugins.strategy
    import ansible.plugins.terminal

    # Global variables
    global _PLUGIN_FILTERS
    _PLUGIN_FILTERS = dict()

    # Declare mocks
    class MockModule:
        def __init__(self, path):
            self.path = path
        def load_module(self, fullname):
            return self.path

    class MockName:
        def __init__(self, fullname):
            self.fullname = fullname
        def __getattribute__(self, attr):
            return getattr(self.fullname, attr)


# Generated at 2022-06-21 05:35:18.739913
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    try:
        from unittest import mock, TestCase
    except ImportError:
        import mock
        from ansible.module_utils.six.moves import unittest as TestCase
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()
    from ansible.plugins.loader import PluginLoader
    plugin_loader = PluginLoader('cache', 'CacheModule', 'ansible.plugins.cache', 'base')

# Generated at 2022-06-21 05:35:28.166824
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plugin_load_context = PluginLoadContext()
    assert not plugin_load_context.original_name
    assert [] ==  plugin_load_context.redirect_list
    assert [] == plugin_load_context.error_list
    assert [] == plugin_load_context.import_error_list
    assert [] == plugin_load_context.load_attempts
    assert not plugin_load_context.pending_redirect
    assert not plugin_load_context.exit_reason
    assert not plugin_load_context.plugin_resolved_path
    assert not plugin_load_context.plugin_resolved_name
    assert not plugin_load_context.plugin_resolved_collection
    assert not plugin_load_context.deprecated
    assert not plugin_load_context.removal_date
    assert not plugin_load_context.rem

# Generated at 2022-06-21 05:35:37.670809
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    '''This is a smoke test for the constructor of class PluginLoader'''
    global _PLUGIN_PATH_CACHE
    from ansible.plugins import connection_loader

    # erase cached plugin paths to force a new load
    _PLUGIN_PATH_CACHE = {}

    # FIXME: this test should be split up so we can test individual components
    #        of the loader here

    # look for a connection plugin in default paths
    conns = connection_loader.all()
    assert len(conns) > 0

    # look for a lookup plugin in default paths
    local_lookup = PluginLoader('LookupModule', 'lookup_plugins')
    lookups = local_lookup.all()
    assert len(lookups) > 0

    # look for a callback plugin in default paths

# Generated at 2022-06-21 05:35:40.627737
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    """Tests that get_all_plugin_loaders() returns a list of all plugin loader classes"""
    plugin_loaders = [pl for (pl_name, pl) in get_all_plugin_loaders()]
    assert PluginLoader in plugin_loaders



# Generated at 2022-06-21 05:36:52.111353
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    try:
        get_shell_plugin('sh')
    except(AnsibleError) as exception:
        assert(str(exception) == "Either a shell type or a shell executable must be provided ")
    shell = get_shell_plugin('sh', '/bin/sh')
    assert(shell.executable == '/bin/sh')
    try:
        get_shell_plugin('bash')
    except(AnsibleError) as exception:
        assert(str(exception) == "Either a shell type or a shell executable must be provided ")
    shell = get_shell_plugin('bash', '/bin/bash')
    assert(shell.executable == '/bin/bash')

# Generated at 2022-06-21 05:37:03.986969
# Unit test for function add_dirs_to_loader

# Generated at 2022-06-21 05:37:08.390175
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    pl = PluginLoader('module', 'ansible.plugins.module_utils', C.DEFAULT_INTERNAL_PLUGIN_PATH)
    assert pl.get('boilerplate') == module_loader._ansible_boilerplate



# Generated at 2022-06-21 05:37:18.517673
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():

    class FakePluginBase(object):

        pass

    class FakeFilterPlugin(FakePluginBase):

        pass

    class FakeTestPlugin(FakePluginBase):

        pass

    class FakePluginLoader(Jinja2Loader):

        def _get_paths(self):

            return ['/usr/lib64/python3.6/site-packages/ansible/plugins/test_plugins']

    def get_fake_plugin(plugin_name):

        class FakePlugin():

            name = plugin_name

            def __init__(self, *args, **kwargs):
                pass

        return FakePlugin


    # create a fixture of all plugins
    global _FILTER_PLUGINS
    global _TEST_PLUGINS

# Generated at 2022-06-21 05:37:20.513991
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    assert PluginLoadContext().nope("exit_reason").resolved is False


# Generated at 2022-06-21 05:37:27.541088
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    pl = PluginLoader('')
    pl._searched_paths = ['one', 'two', 'three']
    pl._display_paths()
    assert pl._searched_paths == ['one', 'two', 'three']


# Generated at 2022-06-21 05:37:35.340143
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    test_PluginLoadContext = PluginLoadContext()
    assert test_PluginLoadContext.original_name == None
    assert test_PluginLoadContext.redirect_list == []
    assert test_PluginLoadContext.error_list == []
    assert test_PluginLoadContext.import_error_list == []
    assert test_PluginLoadContext.load_attempts == []
    assert test_PluginLoadContext.pending_redirect == None
    assert test_PluginLoadContext.exit_reason == None
    assert test_PluginLoadContext.plugin_resolved_path == None
    assert test_PluginLoadContext.plugin_resolved_name == None
    assert test_PluginLoadContext.plugin_resolved_collection == None
    assert test_PluginLoadContext.deprecated == False
    assert test_PluginLoadContext.removal_date == None
    assert test

# Generated at 2022-06-21 05:37:41.250178
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    pl = PluginLoader('Foo', 'ansible.plugins.Foo', C.DEFAULT_INVENTORY_ENABLED_PLUGINS, 'foo')
    assert pl.package == 'ansible.plugins.foo'



# Generated at 2022-06-21 05:37:44.047123
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    p = PluginLoader(package='ansible_collections.acme.testing')
    assert p.get('acme_test_plugin')



# Generated at 2022-06-21 05:37:57.130402
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    import random
    import string
    import tempfile
    import os

    def rand_ascii_str(num_chars):
        return ''.join(
            random.choice(string.ascii_uppercase + string.digits)
            for _ in range(num_chars)
        )

    # Create a PluginLoader and a tempfile for it to use
    plugin_loader = PluginLoader("", "", "")
    temp_dir = tempfile.gettempdir()
    tmp_file_path = os.path.join(temp_dir, rand_ascii_str(10))
    with open(tmp_file_path, 'a'):
        os.utime(tmp_file_path, None)

# Generated at 2022-06-21 05:38:29.643530
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    # arrange
    plugin_load_context = PluginLoadContext()
    plugin_load_context.original_name = 'original_name'

    # act
    plugin_load_context.redirect('redirect_name')

    # assert
    assert plugin_load_context.pending_redirect == 'redirect_name'
    assert plugin_load_context.exit_reason == 'pending redirect resolution from original_name to redirect_name'
    assert plugin_load_context.resolved == False


# Generated at 2022-06-21 05:38:38.552179
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    pl = PluginLoader('module_utils', 'module_utils', '_', required_base_class=object,
                                config_section='MODULE_UTILS', subdir='module_utils', aliases={})
    assert pl.package == 'module_utils'
    assert pl.class_name == '_'
    assert pl.required_base_class == object
    assert pl.config_section == 'MODULE_UTILS'
    assert pl.subdir == 'module_utils'
    assert pl.aliases == {}

    pl.add_directory('./test/unit/module_utils')

    assert pl._get_paths() == ['./test/unit/module_utils']


# Generated at 2022-06-21 05:38:51.524082
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    p = PluginLoadContext()
    # Test if case where warning_text is not given
    deprecation = {
        # "warning_text": "message"
        "removal_date": "2020-01-01"
    }
    p.record_deprecation("name", deprecation, "collection_name")
    assert p.deprecated == True
    assert p.removal_date == "2020-01-01"
    assert p.removal_version == None
    assert p.deprecation_warnings == ["name has been deprecated. 2020-01-01"]
    # Test if case where warning_text is given
    deprecation = {
        "warning_text": "message",
        "removal_date": "2020-01-01"
    }

# Generated at 2022-06-21 05:39:02.870770
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    """
    Jinja2Loader.all()
    """
    loader = Jinja2Loader('ansible.plugins.action', 'ActionModule', '', package_subdir='')

    # Empty
    loader.add_directory(os.path.join('test', 'lib', 'ansible', 'plugins', 'action'))
    result = loader.all()
    assert result == []

    # Found one
    loader.add_directory(os.path.join('test', 'plugins', 'action'))
    result = loader.all()
    assert result != []

    # We want this test to be robust, we don't want our test to fail if someone
    # adds or removes a plugin, so we just check that the count of plugins is
    # good.
    #
    # The count returned by test_plugins is always 4 because of the new plugins

# Generated at 2022-06-21 05:39:13.454066
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    # Create a plugin load context object
    plugin_load_context = PluginLoadContext()

    # Create a plugin name
    name = "foobar"

    # Create a deprecation
    deprecation = {
        'warning_text': 'Deprecated Test',
        'removal_date': '2018-01-01',
        'removal_version': None
    }

    # Test record_deprecation
    result = plugin_load_context.record_deprecation(name, deprecation, 'ansible_namespace')

    # Assert deprecation warnings
    warnings = result.deprecation_warnings
    warning = warnings[0]
    assert warning.strip() == 'foobar has been deprecated. Deprecated Test', warning

    # Assert warning_text property
    assert result.deprecation_warnings.warning_

# Generated at 2022-06-21 05:39:17.072195
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    # Test that the items in the collection get_with_context_result are initialized properly
    result = get_with_context_result('name', 'path', 'version', 'author', 'about')

    assert(result.get('name') == 'name')
    assert(result.get('path') == 'path')
    assert(result.get('version') == 'version')
    assert(result.get('author') == 'author')
    assert(result.get('about') == 'about')



# Generated at 2022-06-21 05:39:23.861319
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    context = PluginLoadContext()
    result = context.resolve('ping', '/usr/lib/ansible/module_utils/network/f5/plugins/modules/ping.py', '', '')
    assert result.pending_redirect is None
    assert result.plugin_resolved_name == 'ping'
    assert result.plugin_resolved_path == '/usr/lib/ansible/module_utils/network/f5/plugins/modules/ping.py'
    assert result.plugin_resolved_collection == ''
    assert result.exit_reason == ''
    assert result.resolved
    assert result.resolved_fqcn == 'ping'


# Generated at 2022-06-21 05:39:29.999306
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    foo = PluginLoader('')
    foo._searched_paths = ['test1', 'test2']
    assert foo.format_paths() == "['test1', 'test2']"
    assert foo.format_paths(indent=4) == "    ['test1', 'test2']"


# Generated at 2022-06-21 05:39:42.895068
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    plugin_loader = PluginLoader(
        'ansible_collections.test_org.test_namespace.plugins.some_plugin',
        'SomePlugin',
        'SomeBasePlugin'
    )

# Generated at 2022-06-21 05:39:53.670644
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader(): # Note: this is a *unit test*, not an *integration test*
    loader = getattr(sys.modules[__name__], 'Shell_loader')
    assert isinstance(loader, PluginLoader)
    assert loader.subdir == 'shell_plugins'
    paths = ('/foo/bar', '/bar/baz')
    for path in paths:
        loader.add_directory(path, with_subdir=True)
        assert path in loader._get_paths()
        assert os.path.join(path, 'shell_plugins') in loader._get_paths()
    loader.clear_directory_cache()



# Generated at 2022-06-21 05:40:44.474640
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
  pass
# Unit tests for method find_plugin of class Jinja2Loader

# Generated at 2022-06-21 05:40:50.565064
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    logger.info("Test start: method all of class PluginLoader")

# Generated at 2022-06-21 05:41:00.534708
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    context = PluginLoadContext()
    assert context.original_name is None
    assert context.redirect_list == []
    assert context.error_list == []
    assert context.import_error_list == []
    assert context.load_attempts == []
    assert context.pending_redirect is None
    assert context.exit_reason is None
    assert context.plugin_resolved_path is None
    assert context.plugin_resolved_name is None
    assert context.plugin_resolved_collection is None
    assert context.deprecated is False
    assert context.removal_date is None
    assert context.removal_version is None
    assert context.deprecation_warnings == []
    assert context.resolved is False
    assert context._resolved_fqcn is None


# Generated at 2022-06-21 05:41:10.944485
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    '''
    Unit test for method __getstate__ of class PluginLoader
    '''

    # From test/units/module_utils/test_cache_control.py::test_hash_dict_non_deterministic
    dict1 = dict(a=1, b=2, c=3, d=4)
    dict2 = dict(d=4, c=3, b=2, a=1)
    dict3 = dict(a=1, b=2, c=3, d=4)
    dict4 = dict(d=4, c=3, b=2, a=1)
    assert not (dict1 == dict2)
    assert dict1 == dict3
    assert dict2 == dict4
    assert hash(dict1) == hash(dict3)
    assert hash(dict2) == hash(dict4)

# Generated at 2022-06-21 05:41:16.189043
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell_loader.clear_all_errors()
    shell_loader.clear_none_errors()

    shell_loader.get('sh')
    
    try:
        shell_loader.get('sh1')
    except Exception:
        pass

    shell_loader.get('sh1', required=False)

    shell_loader.get('sh1', ignore_deprecated=True)

    # TODO: Compleated the test for other functions.


# Generated at 2022-06-21 05:41:17.909657
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    print('Testing method __contains__ of class PluginLoader')
    pl = PluginLoader()
    assert pl.__contains__('shell')

# Generated at 2022-06-21 05:41:22.592145
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    import ansible.parsing.dataloader

    obj = PluginLoader(None, None, None, None)

    obj.__setstate__({})

# Generated at 2022-06-21 05:41:28.821268
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    myplugin = PluginLoader(package='ansible.plugins.inventory', directories=[], class_name='myclass', aliases={},
                            cache={})
    assert len(myplugin.__getstate__()) == 2
    assert myplugin.__getstate__() == {'package': 'ansible.plugins.inventory', 'aliases': {}}


# Generated at 2022-06-21 05:41:40.667813
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    import ansible.plugins.loader
    res = ansible.plugins.loader.get_with_context_result(name='test', with_context=False)
    assert res['with_context'] == False
    assert res['name'] == 'test'
    res = ansible.plugins.loader.get_with_context_result(with_context=False)
    assert res['with_context'] == False
    assert set(res.keys()) == {'name', 'with_context'}
    res = ansible.plugins.loader.get_with_context_result()
    assert res['with_context'] == True
    assert set(res.keys()) == {'name', 'with_context'}



# Generated at 2022-06-21 05:41:52.737659
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    """
    Test that get_with_context_result returns the correct values.
    """

    # Try:
    # A successful call which finds the plugin

    ret = get_with_context_result(cache_loader, 'memory', 'test_context')

    assert len(ret.results) == 1
    assert_path_to_content(ret.results[0].file_name) == 'ansible/plugins/cache/memory.py'
    assert ret.success is True
    assert ret.errors == []
    assert isinstance(ret.results[0].plugin_context, 'test_context')

    # Try:
    # A call where the plugin is not found
