

# Generated at 2022-06-17 12:17:43.906422
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    from ansible.plugins.loader import PluginLoader
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collection_list import AnsibleCollectionRef
    from ansible.utils.collection_list import AnsibleCollectionRequirement
    from ansible.utils.collection_list import CollectionRequirementSpec
    from ansible.utils.collection_list import CollectionRequirementSpecParser
    from ansible.utils.collection_list import CollectionRequirementSpecParserError
    from ansible.utils.collection_list import CollectionRequirementSpecValidationError
    from ansible.utils.collection_list import CollectionRequirementSpecValidationErrorReason
    from ansible.utils.collection_list import CollectionRequirementSpecValidationErrorReasonCode
    from ansible.utils.collection_list import CollectionRequirementSpecValidationErrorReasonType

# Generated at 2022-06-17 12:17:54.241426
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    import ansible.plugins.loader
    import ansible.plugins.action
    import ansible.plugins.cache
    import ansible.plugins.callback
    import ansible.plugins.connection
    import ansible.plugins.cliconf
    import ansible.plugins.doc_fragments
    import ansible.plugins.filter
    import ansible.plugins.httpapi
    import ansible.plugins.inventory
    import ansible.plugins.lookup
    import ansible.plugins.module_utils
    import ansible.plugins.netconf
    import ansible.plugins.shell
    import ansible.plugins.strategy
    import ansible.plugins.terminal
    import ansible.plugins.test
    import ansible.plugins.vars
    import ansible.plugins.vars.host_group_vars
    import ansible.plugins

# Generated at 2022-06-17 12:18:02.561098
# Unit test for method find_plugin of class PluginLoader

# Generated at 2022-06-17 12:18:06.825953
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test with invalid path
    add_all_plugin_dirs('/invalid/path')
    # Test with valid path
    add_all_plugin_dirs(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible', 'plugins'))



# Generated at 2022-06-17 12:18:18.080081
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    # Test case 1:
    #   deprecation = None
    #   collection_name = None
    #   expected_result = None
    #   expected_removal_date = None
    #   expected_removal_version = None
    #   expected_deprecation_warnings = []
    #   expected_deprecated = False
    #   expected_exit_reason = None
    #   expected_resolved = False
    #   expected_pending_redirect = None
    #   expected_plugin_resolved_name = None
    #   expected_plugin_resolved_path = None
    #   expected_plugin_resolved_collection = None
    #   expected_resolved_fqcn = None
    deprecation = None
    collection_name = None
    expected_result = None
    expected_removal_

# Generated at 2022-06-17 12:18:18.833820
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # FIXME: This test is not implemented
    pass


# Generated at 2022-06-17 12:18:27.105270
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    import ansible.plugins.loader
    import ansible.plugins.action
    import ansible.plugins.cache
    import ansible.plugins.callback
    import ansible.plugins.connection
    import ansible.plugins.filter
    import ansible.plugins.inventory
    import ansible.plugins.lookup
    import ansible.plugins.shell
    import ansible.plugins.strategy
    import ansible.plugins.terminal
    import ansible.plugins.test
    import ansible.plugins.vars
    import ansible.plugins.module_utils
    import ansible.plugins.netconf
    import ansible.plugins.httpapi
    import ansible.plugins.cliconf
    import ansible.plugins.connection.network_cli
    import ansible.plugins.connection.network_http
    import ansible.plugins.connection.network

# Generated at 2022-06-17 12:18:40.399409
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('copy')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'copy'
    assert plugin_load_context.plugin_resolved_path == '/home/travis/build/ansible/ansible/lib/ansible/plugins/action/copy.py'
    assert plugin_load_context.redirect_list == []
    assert plugin_load_context.searched_paths == ['/home/travis/build/ansible/ansible/lib/ansible/plugins/action']
    assert plugin_load_

# Generated at 2022-06-17 12:18:45.924416
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    # Test for deprecation with removal_date
    plc = PluginLoadContext()
    plc.record_deprecation('test_plugin', {'warning_text': 'test_warning_text', 'removal_date': 'test_removal_date'}, 'test_collection_name')
    assert plc.deprecated
    assert plc.removal_date == 'test_removal_date'
    assert plc.removal_version is None
    assert plc.deprecation_warnings == ['test_plugin has been deprecated. test_warning_text']

    # Test for deprecation with removal_version
    plc = PluginLoadContext()

# Generated at 2022-06-17 12:18:55.970911
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # test with a non-existent plugin
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INTERNAL_PLUGINS_PATH, 'action_plugins')
    plugin_load_context = plugin_loader.find_plugin_with_context('non_existent_plugin')
    assert plugin_load_context.resolved is False
    assert plugin_load_context.plugin_resolved_name is None
    assert plugin_load_context.plugin_resolved_path is None
    assert plugin_load_context.redirect_list == []

    # test with an existing plugin
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INTERNAL_PLUGINS_PATH, 'action_plugins')
    plugin_load_context = plugin_loader.find_

# Generated at 2022-06-17 12:19:42.058982
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Test with a directory that does not exist
    loader = PluginLoader('foo')
    loader.add_directory('/tmp/foo')
    assert loader._get_paths() == []

    # Test with a directory that does exist
    loader = PluginLoader('foo')
    loader.add_directory(os.path.dirname(__file__))
    assert loader._get_paths() == [os.path.dirname(__file__)]

    # Test with a directory that does exist, but is already in the list
    loader = PluginLoader('foo')
    loader.add_directory(os.path.dirname(__file__))
    loader.add_directory(os.path.dirname(__file__))
    assert loader._get_paths() == [os.path.dirname(__file__)]

    # Test with a directory

# Generated at 2022-06-17 12:19:52.885424
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS, C.DEFAULT_INVENTORY_ENABLED_HOST_PATTERNS)
    assert 'ping' in loader
    assert 'ping' in loader
    assert 'ping' in loader
    assert 'ping' in loader
    assert 'ping' in loader
    assert 'ping' in loader
    assert 'ping' in loader
    assert 'ping' in loader
    assert 'ping' in loader
    assert 'ping' in loader
    assert 'ping' in loader
    assert 'ping' in loader
    assert 'ping' in loader
    assert 'ping' in loader
    assert 'ping' in loader
    assert 'ping' in loader
    assert 'ping' in loader

# Generated at 2022-06-17 12:19:54.375341
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # This is a unit test for method all of class PluginLoader
    # TODO: write unit test
    pass


# Generated at 2022-06-17 12:19:59.802153
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # Test with a non-existent plugin
    assert Jinja2Loader('ansible.plugins.filter', 'FilterModule').get('non_existent') is None

    # Test with a valid plugin
    assert Jinja2Loader('ansible.plugins.filter', 'FilterModule').get('json_query') is not None



# Generated at 2022-06-17 12:20:03.200497
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # test with invalid path
    add_all_plugin_dirs("/invalid/path")
    # test with valid path
    add_all_plugin_dirs(os.path.dirname(__file__))



# Generated at 2022-06-17 12:20:06.137165
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    '''
    Unit test for method get_with_context of class PluginLoader
    '''
    # TODO: Implement unit test for method get_with_context of class PluginLoader
    pass

# Generated at 2022-06-17 12:20:09.667428
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test the method all of class PluginLoader
    #
    # This method is not implemented yet.
    #
    # Args:
    #     None
    #
    # Returns:
    #     None
    #
    # Raises:
    #     None
    pass


# Generated at 2022-06-17 12:20:21.826608
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type='sh')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'

    shell = get_shell_plugin(shell_type='csh')
    assert shell.SHELL_FAMILY == 'csh'
    assert shell.executable == '/bin/csh'

    shell = get_shell_plugin(shell_type='fish')
    assert shell.SHELL_FAMILY == 'fish'
    assert shell.executable == '/usr/bin/fish'

    shell = get_shell_plugin(shell_type='powershell')
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.executable == 'powershell'


# Generated at 2022-06-17 12:20:26.857046
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INTERNAL_PLUGINS_PATH, 'action_plugins')
    assert 'copy' in plugin_loader

    # Test with a plugin that doesn't exist
    assert 'not_a_plugin' not in plugin_loader


# Generated at 2022-06-17 12:20:40.408672
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists in the default path
    plugin_loader = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action')
    plugin_load_context = plugin_loader.find_plugin_with_context('copy')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'copy'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/copy.py')

    # Test with a plugin that exists in the default path, but is not a valid plugin
    plugin_loader = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action')
    plugin_load_context = plugin_loader.find_plugin_with_context('__init__')
    assert not plugin_load_context

# Generated at 2022-06-17 12:21:07.683269
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    paths = ['/path/to/plugins']
    which_loader = 'action'
    loader = getattr(sys.modules[__name__], '%s_loader' % which_loader)
    for path in paths:
        loader.add_directory(path, with_subdir=True)
    assert loader.directories == paths


# Generated at 2022-06-17 12:21:16.544989
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type='sh')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'
    shell = get_shell_plugin(shell_type='csh')
    assert shell.SHELL_FAMILY == 'csh'
    assert shell.executable == '/bin/csh'
    shell = get_shell_plugin(shell_type='fish')
    assert shell.SHELL_FAMILY == 'fish'
    assert shell.executable == '/usr/bin/fish'
    shell = get_shell_plugin(shell_type='powershell')
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.executable == 'powershell'

# Generated at 2022-06-17 12:21:23.277533
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    # Test with shell_type
    shell = get_shell_plugin(shell_type='sh')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'

    # Test with executable
    shell = get_shell_plugin(executable='/bin/bash')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/bash'

    # Test with executable and shell_type
    shell = get_shell_plugin(shell_type='csh', executable='/bin/csh')
    assert shell.SHELL_FAMILY == 'csh'
    assert shell.executable == '/bin/csh'



# Generated at 2022-06-17 12:21:33.401877
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test with a valid plugin name
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.get_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path == 'ansible/plugins/action/ping.py'
    assert plugin_load_context.redirect_list == []
    assert plugin_load_context.object.__class__.__name__ == 'ActionModule'
    assert plugin_load_context.object._load_name == 'ping'

# Generated at 2022-06-17 12:21:41.864872
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test with no args
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionBase')
    plugin_loader.all()
    # Test with args
    plugin_loader.all(path_only=True)
    plugin_loader.all(class_only=True)
    plugin_loader.all(path_only=True, class_only=True)
    plugin_loader.all(path_only=True, class_only=True, _dedupe=False)
    # Test with invalid args
    with pytest.raises(AnsibleError):
        plugin_loader.all(path_only=True, class_only=True)


# Generated at 2022-06-17 12:21:43.272605
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # TODO: implement unit test for method get of class Jinja2Loader
    pass


# Generated at 2022-06-17 12:21:51.939745
# Unit test for method find_plugin of class PluginLoader

# Generated at 2022-06-17 12:21:58.872927
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    from ansible.plugins.loader import Jinja2Loader
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collection_loader import get_collection_ref_from_string
    from ansible.utils.collection_loader import get_collection_ref_from_path
    from ansible.utils.collection_loader import get_collection_ref_from_module
    from ansible.utils.collection_loader import get_collection_ref_from_module_name
    from ansible.utils.collection_loader import get_collection_ref_from_module_path
    from ansible.utils.collection_loader import get_collection_ref_from_module_spec
    from ansible.utils.collection_loader import get_collection_ref_from_module_

# Generated at 2022-06-17 12:21:59.963686
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # TODO: implement test
    pass

# Generated at 2022-06-17 12:22:10.996258
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test with no args
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS, 'action_plugins')
    assert len(list(loader.all())) > 0

    # Test with args
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS, 'action_plugins')
    assert len(list(loader.all('arg1', 'arg2'))) > 0

    # Test with kwargs
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS, 'action_plugins')

# Generated at 2022-06-17 12:22:40.797343
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test with a plugin that exists
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', 'action')
    plugin_load_context = loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.redirect_list == []

    # Test with a plugin that does not exist
    plugin_load_context = loader.find_plugin_with_context('does_not_exist')
    assert not plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name is None
    assert plugin

# Generated at 2022-06-17 12:22:50.867101
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # Test for function add_dirs_to_loader
    # Create a temporary directory
    import tempfile
    import shutil
    from ansible.plugins.loader import add_dirs_to_loader
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_shell_plugin
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_plugin_class
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_plugin_class
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_plugin_class

# Generated at 2022-06-17 12:22:56.371926
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Test with a directory that does not exist
    loader = PluginLoader('test_plugins', 'TestPlugin', 'test_plugins', 'test_plugins')
    loader.add_directory('/tmp/doesnotexist')
    assert loader._get_paths() == []

    # Test with a directory that does exist
    loader = PluginLoader('test_plugins', 'TestPlugin', 'test_plugins', 'test_plugins')
    loader.add_directory(os.path.dirname(__file__))
    assert loader._get_paths() == [os.path.dirname(__file__)]


# Generated at 2022-06-17 12:23:05.907600
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    # Test with shell_type
    shell_type = 'sh'
    shell = get_shell_plugin(shell_type)
    assert shell.SHELL_FAMILY == shell_type
    # Test with executable
    executable = '/bin/sh'
    shell = get_shell_plugin(executable=executable)
    assert shell.SHELL_FAMILY == 'sh'
    # Test with invalid executable
    executable = '/bin/invalid'
    try:
        shell = get_shell_plugin(executable=executable)
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError not raised"
    # Test with invalid shell_type
    shell_type = 'invalid'

# Generated at 2022-06-17 12:23:14.102339
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action')
    plugin_load_context = plugin_loader.find_plugin_with_context('copy')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'copy'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/copy.py')

    # Test with a plugin that does not exist
    plugin_loader = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action')
    plugin_load_context = plugin_loader.find_plugin_with_context('does_not_exist')
    assert not plugin_load_context.resolved
    assert plugin_load_context

# Generated at 2022-06-17 12:23:23.602387
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test with a valid plugin name
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.redirect_list == []
    assert plugin_load_context.plugin_searched_paths == ['/home/ansible/ansible/lib/ansible/plugins/action']
    assert plugin_load_context.plugin_found_in_cache is False

# Generated at 2022-06-17 12:23:26.815682
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    '''
    Unit test for method get_with_context of class PluginLoader
    '''
    # TODO: Implement test
    pass


# Generated at 2022-06-17 12:23:39.220708
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type='sh')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'

    shell = get_shell_plugin(shell_type='csh')
    assert shell.SHELL_FAMILY == 'csh'
    assert shell.executable == '/bin/csh'

    shell = get_shell_plugin(shell_type='fish')
    assert shell.SHELL_FAMILY == 'fish'
    assert shell.executable == '/usr/bin/fish'

    shell = get_shell_plugin(executable='/bin/bash')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/bash'


# Generated at 2022-06-17 12:23:45.974646
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    import ansible.plugins.loader
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_plugin_loader
    from ansible.plugins.loader import get_plugin_paths
    from ansible.plugins.loader import get_filter_plugins
    from ansible.plugins.loader import get_test_plugins
    from ansible.plugins.loader import get_lookup_plugins
    from ansible.plugins.loader import get_connection_plugins
    from ansible.plugins.loader import get_shell_plugins
    from ansible.plugins.loader import get_module_utils_paths
    from ansible.plugins.loader import get_module_paths
    from ansible.plugins.loader import get_action_plugins

# Generated at 2022-06-17 12:23:51.496142
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    from ansible.plugins.loader import PluginLoader
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.collection_loader import AnsibleCollectionRequirement
    from ansible.utils.collection_loader import get_collection_ref_from_string
    from ansible.utils.collection_loader import get_collection_ref_from_requirement
    from ansible.utils.collection_loader import get_collection_ref_from_path
    from ansible.utils.collection_loader import get_collection_ref_from_galaxy_info
    from ansible.utils.collection_loader import get_collection_ref_from_galaxy_meta
    from ansible.utils.collection_loader import get_collection_ref_from_galaxy_artifact
    from ansible.utils.collection_loader import get_collection_ref_

# Generated at 2022-06-17 12:24:41.743223
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test with a valid path
    path = '~/ansible/plugins'
    add_all_plugin_dirs(path)
    # Test with an invalid path
    path = '~/ansible/plugins/invalid'
    add_all_plugin_dirs(path)


# Generated at 2022-06-17 12:24:53.759371
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a valid plugin name
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('ping.py')
    assert plugin_load_context.redirect_list == []

    # Test with a valid plugin name that has a redirect
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context

# Generated at 2022-06-17 12:25:05.742194
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test with a valid path
    path = '~/ansible/plugins'
    b_path = os.path.expanduser(to_bytes(path, errors='surrogate_or_strict'))
    os.makedirs(b_path)
    for name, obj in get_all_plugin_loaders():
        if obj.subdir:
            plugin_path = os.path.join(b_path, to_bytes(obj.subdir))
            os.makedirs(plugin_path)
    add_all_plugin_dirs(path)
    for name, obj in get_all_plugin_loaders():
        if obj.subdir:
            assert(to_text(b_path) in obj.directories)
    # Test with an invalid path

# Generated at 2022-06-17 12:25:11.363064
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    assert plugin_loader.find_plugin('copy') is not None

    # Test with a plugin that does not exist
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    assert plugin_loader.find_plugin('does_not_exist') is None


# Generated at 2022-06-17 12:25:21.614016
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test with a valid plugin
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.get_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('ping.py')
    assert plugin_load_context.redirect_list == []

    # Test with a plugin that doesn't exist
    plugin_load_context = plugin_loader.get_with_context('does_not_exist')
    assert not plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name is None
    assert plugin_

# Generated at 2022-06-17 12:25:33.887861
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionBase', config_base=None, subdir=None, aliases=None, required_base_class=None)
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('ansible/plugins/action/ping.py')
    assert plugin_load_context.redirect_list == []

    # Test with a plugin that does not exist