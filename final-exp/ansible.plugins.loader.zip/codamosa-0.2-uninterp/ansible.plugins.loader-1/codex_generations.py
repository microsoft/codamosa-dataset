

# Generated at 2022-06-17 12:17:46.137444
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    from ansible.plugins.loader import add_dirs_to_loader
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_shell_plugin
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import cliconf_loader
    from ansible.plugins.loader import terminal_loader
    from ansible.plugins.loader import action_loader

# Generated at 2022-06-17 12:17:57.152107
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    from ansible.plugins.loader import PluginLoader
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.collection_loader import AnsibleCollectionRequirement
    from ansible.utils.collection_loader import CollectionsLoader
    from ansible.utils.collection_loader import get_collection_ref_from_string
    from ansible.utils.collection_loader import get_collection_ref_from_requirement
    from ansible.utils.collection_loader import get_collection_ref_from_path
    from ansible.utils.collection_loader import get_collection_ref_from_name
    from ansible.utils.collection_loader import get_collection_ref_from_galaxy_info
    from ansible.utils.collection_loader import get_collection_ref_from_galaxy_meta

# Generated at 2022-06-17 12:18:01.089737
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    assert plugin_loader.find_plugin('ping') is not None
    # Test with a plugin that doesn't exist
    assert plugin_loader.find_plugin('does_not_exist') is None


# Generated at 2022-06-17 12:18:11.424069
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    # Test with a single path
    assert PluginLoader.format_paths(['/path/to/plugins']) == '/path/to/plugins'
    # Test with multiple paths
    assert PluginLoader.format_paths(['/path/to/plugins', '/path/to/more/plugins']) == '/path/to/plugins, /path/to/more/plugins'
    # Test with multiple paths and a max_paths value
    assert PluginLoader.format_paths(['/path/to/plugins', '/path/to/more/plugins', '/path/to/even/more/plugins'], max_paths=2) == '/path/to/plugins, /path/to/more/plugins, and 1 other'
    # Test with multiple paths and a max_paths value of 1

# Generated at 2022-06-17 12:18:20.481466
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # Test with a valid plugin name
    jinja2_loader = Jinja2Loader()
    assert jinja2_loader.find_plugin('basename') == 'ansible.legacy.plugins.filter.basename'

    # Test with an invalid plugin name
    assert jinja2_loader.find_plugin('invalid_plugin_name') is None

    # Test with a valid plugin name from a collection
    assert jinja2_loader.find_plugin('ansible.builtin.basename') == 'ansible.builtin.plugins.filter.basename'

    # Test with an invalid plugin name from a collection
    assert jinja2_loader.find_plugin('ansible.builtin.invalid_plugin_name') is None

    # Test with a valid plugin name from a collection with a version
    assert jinja2

# Generated at 2022-06-17 12:18:28.008638
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    # Test with a list of paths
    paths = ['/path/to/plugins', '/path/to/more/plugins', '/path/to/even/more/plugins']
    assert PluginLoader.format_paths(paths) == '/path/to/plugins:/path/to/more/plugins:/path/to/even/more/plugins'

    # Test with a list of paths that contains a path with a colon
    paths = ['/path/to/plugins', '/path/to/more/plugins', '/path/to/even/more/plugins:/path/to/even/more/plugins']
    assert PluginLoader.format_paths(paths) == '/path/to/plugins:/path/to/more/plugins:/path/to/even/more/plugins:/path/to/even/more/plugins'

    # Test with a list of paths that contains

# Generated at 2022-06-17 12:18:31.139605
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert add_dirs_to_loader('shell', ['/path/to/shell/plugins']) is None


# Generated at 2022-06-17 12:18:43.241342
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_plugin_loader
    from ansible.plugins.loader import get_all_plugin_paths
    from ansible.plugins.loader import get_plugin_path
    from ansible.plugins.loader import get_all_plugin_names
    from ansible.plugins.loader import get_plugin_name
    from ansible.plugins.loader import get_all_plugin_classes
    from ansible.plugins.loader import get_plugin_class
    from ansible.plugins.loader import get_all_plugin_instances
    from ansible.plugins.loader import get_plugin_instance
    from ansible.plugins.loader import get_all_filter_plugins

# Generated at 2022-06-17 12:18:46.090078
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    '''
    Unit test for method __contains__ of class PluginLoader
    '''
    # TODO: Implement test
    pass


# Generated at 2022-06-17 12:18:52.865433
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    p = PluginLoader('foo', 'bar', 'baz')
    p._searched_paths = ['/a/b/c', '/d/e/f']
    assert p.format_paths(p._searched_paths) == '/a/b/c, /d/e/f'
    p._searched_paths = ['/a/b/c', '/a/b/c']
    assert p.format_paths(p._searched_paths) == '/a/b/c'
    p._searched_paths = ['/a/b/c', '/a/b/c', '/a/b/c']
    assert p.format_paths(p._searched_paths) == '/a/b/c'

# Generated at 2022-06-17 12:20:03.757617
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.loader import get_plugin_class
    from ansible.plugins.loader import get_plugin_class_by_name
    from ansible.plugins.loader import get_plugin_class_by_path
    from ansible.plugins.loader import get_plugin_class_by_type
    from ansible.plugins.loader import get_plugin_class_by_type_and_name
    from ansible.plugins.loader import get_plugin_class_by_type_and_path
    from ansible.plugins.loader import get_plugin_class_by_type_and_name_and_path

# Generated at 2022-06-17 12:20:04.658195
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # TODO: implement this test
    pass


# Generated at 2022-06-17 12:20:09.352914
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')

    # Test with a plugin that does not exist
    plugin_load_context = plugin_loader.find_plugin_with_context('does_not_exist')
    assert not plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name is None
    assert plugin_load_

# Generated at 2022-06-17 12:20:18.073605
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    plc = PluginLoadContext()
    plc.record_deprecation('name', {'warning_text': 'warning_text', 'removal_date': 'removal_date', 'removal_version': 'removal_version'}, 'collection_name')
    assert plc.deprecated == True
    assert plc.removal_date == 'removal_date'
    assert plc.removal_version == 'removal_version'
    assert plc.deprecation_warnings == ['name has been deprecated. warning_text']


# Generated at 2022-06-17 12:20:25.090752
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    '''
    Test the add_all_plugin_dirs function
    '''
    # Test with a valid path
    test_path = os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'units', 'module_utils', 'test_module_utils')
    add_all_plugin_dirs(test_path)
    for name, obj in get_all_plugin_loaders():
        if obj.subdir:
            plugin_path = os.path.join(test_path, obj.subdir)
            assert plugin_path in obj._directories

    # Test with an invalid path

# Generated at 2022-06-17 12:20:31.223914
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # Test with no args
    loader = Jinja2Loader()
    assert loader.get() is None

    # Test with args
    loader = Jinja2Loader()
    assert loader.get('test') is None


# Generated at 2022-06-17 12:20:42.202956
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test with no args
    assert list(PluginLoader.all()) == []

    # Test with args
    assert list(PluginLoader.all(1, 2, 3)) == []

    # Test with kwargs
    assert list(PluginLoader.all(path_only=True)) == []

    # Test with args and kwargs
    assert list(PluginLoader.all(1, 2, 3, path_only=True)) == []

    # Test with _dedupe set to False
    assert list(PluginLoader.all(_dedupe=False)) == []

    # Test with _dedupe set to False and args
    assert list(PluginLoader.all(1, 2, 3, _dedupe=False)) == []

    # Test with _dedupe set to False and kwargs

# Generated at 2022-06-17 12:20:50.014672
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    from ansible.plugins.loader import PluginLoader
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 12:20:55.766006
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test with no args
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_ACTION_PLUGIN_PATH, 'action_plugins')
    assert len(list(loader.all())) > 0

    # Test with args
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_ACTION_PLUGIN_PATH, 'action_plugins')
    assert len(list(loader.all(foo='bar'))) > 0

    # Test with kwargs
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_ACTION_PLUGIN_PATH, 'action_plugins')
    assert len(list(loader.all(foo='bar'))) > 0

    # Test with path_only

# Generated at 2022-06-17 12:21:05.972109
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('ansible/plugins/action/ping.py')
    assert plugin_load_context.redirect_list == []
    assert plugin_load_context.redirected_from is None

    # Test with a plugin that does not exist
    plugin_load_context = loader.find_plugin_with_context('does_not_exist')
    assert not plugin_load_context.resolved

# Generated at 2022-06-17 12:24:02.404503
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.loader import PLUGIN_PATH_CACHE
    from ansible.plugins.loader import PATH_CACHE
    from ansible.plugins.loader import MODULE_CACHE
    from ansible.plugins.loader import get_plugin_paths
    from ansible.plugins.loader import get_collection_paths
    from ansible.plugins.loader import get_collection_name_from_path
    from ansible.plugins.loader import get_collection_name_from_ns_name
    from ansible.plugins.loader import get_collection_name_from_ns_name

# Generated at 2022-06-17 12:24:04.481645
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # TODO: implement this test
    pass


# Generated at 2022-06-17 12:24:13.661554
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('setup')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'setup'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/setup.py')
    assert plugin_load_context.plugin_load_name == 'setup'
    assert plugin_load_context.plugin_load_path.endswith('/ansible/plugins/action/setup.py')
    assert plugin_load_context.redirect_list == []

    # Test with a plugin that does

# Generated at 2022-06-17 12:24:22.385716
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionModule', config_base_class='ActionModule')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('ansible/plugins/action/ping.py')

    # Test with a plugin that does not exist
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionModule', config_base_class='ActionModule')
    plugin_load_context = plugin_loader.find_plugin_with_context('doesnotexist')
    assert not plugin

# Generated at 2022-06-17 12:24:36.905738
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test with a simple plugin
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.get_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.redirect_list == []
    assert plugin_load_context.object.__class__.__name__ == 'ActionModule'
    assert plugin_load_context.object._load_name == 'ping'

# Generated at 2022-06-17 12:24:41.971585
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # Test with a valid plugin name
    plugin_loader = Jinja2Loader('ansible.plugins.filter', 'FilterModule')
    plugin_loader.add_directory(os.path.join(os.path.dirname(__file__), 'filter_plugins'))
    plugin_loader.find_plugin('to_nice_yaml')

    # Test with an invalid plugin name
    with pytest.raises(AnsibleError):
        plugin_loader.find_plugin('invalid_plugin_name')


# Generated at 2022-06-17 12:24:53.894961
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import PluginLoader
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath
    from ansible.utils.path import unfrackpath
    from ansible.utils.path import unfrackpath
    from ansible.utils.path import unfrackpath
    from ansible.utils.path import unfrackpath
    from ansible.utils.path import unfrackpath
    from ansible.utils.path import unfrackpath
    from ansible.utils.path import unfrackpath
    from ansible.utils.path import unfrackpath
    from ansible.utils.path import unfrackpath
    from ansible.utils.path import unfrackpath
    from ansible.utils.path import unfrackpath

# Generated at 2022-06-17 12:25:05.778364
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    from ansible.plugins.loader import PluginLoader
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collection_list import AnsibleCollectionRef
    from ansible.utils.collection_list import AnsibleCollectionRequirement
    from ansible.utils.collection_list import AnsibleCollectionRefList
    from ansible.utils.collection_list import AnsibleCollectionRequirementList
    from ansible.utils.collection_list import AnsibleCollectionRefList
    from ansible.utils.collection_list import AnsibleCollectionRequirementList
    from ansible.utils.collection_list import AnsibleCollectionRefList
    from ansible.utils.collection_list import AnsibleCollectionRequirementList
    from ansible.utils.collection_list import AnsibleCollectionRefList
    from ansible.utils.collection_list import AnsibleCollectionRequirement

# Generated at 2022-06-17 12:25:13.351747
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS, C.DEFAULT_INVENTORY_ENABLED_HOST_PATTERNS)
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path == 'ansible/plugins/action/ping.py'
    assert plugin_load_context.plugin_resolved_fqcr == 'ansible.plugins.action.ping'
    assert plugin_load_context.plugin_resolved_collection is None

# Generated at 2022-06-17 12:25:23.021578
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test with no args
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INTERNAL_TEMPLATE_MODULE_PATH, 'action_plugins')
    assert len(list(plugin_loader.all())) > 0

    # Test with args
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INTERNAL_TEMPLATE_MODULE_PATH, 'action_plugins')
    assert len(list(plugin_loader.all(foo='bar'))) > 0

    # Test with kwargs
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INTERNAL_TEMPLATE_MODULE_PATH, 'action_plugins')