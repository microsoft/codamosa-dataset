

# Generated at 2022-06-17 12:17:56.350474
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.plugins.loader import PluginLoader
    import ansible.plugins.action
    import ansible.plugins.cache
    import ansible.plugins.callback
    import ansible.plugins.connection
    import ansible.plugins.filter
    import ansible.plugins.inventory
    import ansible.plugins.lookup
    import ansible.plugins.shell
    import ansible.plugins.strategy
    import ansible.plugins.terminal
    import ansible.plugins.test
    import ansible.plugins.vars
    import ansible.plugins.module_utils
    import ansible.plugins.netconf

    # Test for class PluginLoader
    # Instance of PluginLoader with package ansible.plugins.action

# Generated at 2022-06-17 12:18:05.694132
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    import ansible.plugins.loader
    import ansible.plugins.action
    import ansible.plugins.cache
    import ansible.plugins.callback
    import ansible.plugins.connection
    import ansible.plugins.filter
    import ansible.plugins.inventory
    import ansible.plugins.lookup
    import ansible.plugins.shell
    import ansible.plugins.strategy
    import ansible.plugins.terminal
    import ansible.plugins.test
    import ansible.plugins.vars
    import ansible.plugins.module_utils
    import ansible.plugins.netconf

    # Test the case where we want an instance of the plugin
    plugin_loader = ansible.plugins.loader.PluginLoader(package='ansible.plugins.action')
    plugin_list = list(plugin_loader.all())

# Generated at 2022-06-17 12:18:13.606180
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test with a valid plugin
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', 'action')
    plugin_load_context = plugin_loader.get_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.redirect_list == []
    assert plugin_load_context.object.__class__.__name__ == 'ActionModule'
    assert plugin_load_context.object._load_name == 'ping'

# Generated at 2022-06-17 12:18:17.242266
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test with invalid path
    add_all_plugin_dirs('/invalid/path')
    # Test with valid path
    add_all_plugin_dirs(os.path.dirname(os.path.abspath(__file__)))



# Generated at 2022-06-17 12:18:25.461139
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.normal import ActionModule as NormalActionModule
    from ansible.plugins.action.copy import ActionModule as CopyActionModule
    from ansible.plugins.action.shell import ActionModule as ShellActionModule
    from ansible.plugins.action.synchronize import ActionModule as SynchronizeActionModule
    from ansible.plugins.action.template import ActionModule as TemplateActionModule
    from ansible.plugins.action.win_copy import ActionModule as WinCopyActionModule
    from ansible.plugins.action.win_shell import ActionModule as WinShellActionModule
    from ansible.plugins.action.win_template import ActionModule as WinTemplateActionModule
    from ansible.plugins.action.win_unzip import ActionModule as Win

# Generated at 2022-06-17 12:18:40.012116
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test with a valid plugin
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.get_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.redirect_list == []
    assert plugin_load_context.object.__class__.__name__ == 'ActionModule'
    assert plugin_load_context.object._load_name == 'ping'

# Generated at 2022-06-17 12:18:48.693173
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    import ansible.plugins.loader
    import ansible.plugins.action
    import ansible.plugins.cache
    import ansible.plugins.callback
    import ansible.plugins.connection
    import ansible.plugins.connection.network_cli
    import ansible.plugins.connection.network_winrm
    import ansible.plugins.connection.paramiko_ssh
    import ansible.plugins.connection.ssh
    import ansible.plugins.connection.winrm
    import ansible.plugins.filter
    import ansible.plugins.inventory
    import ansible.plugins.lookup
    import ansible.plugins.strategy
    import ansible.plugins.test
    import ansible.plugins.vars
    import ansible.plugins.terminal
    import ansible.plugins.callback.default
    import ansible.plugins.cache.memory
   

# Generated at 2022-06-17 12:18:50.265209
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert add_dirs_to_loader('shell', ['test_path']) == None


# Generated at 2022-06-17 12:18:51.328230
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # TODO: implement this test
    pass


# Generated at 2022-06-17 12:18:52.483804
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert add_dirs_to_loader('shell', ['test_path']) == None


# Generated at 2022-06-17 12:19:23.723332
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionBase', base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('copy')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'copy'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/copy.py')

    # Test with a plugin that does not exist
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionBase', base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('does_not_exist')
    assert not plugin_

# Generated at 2022-06-17 12:19:32.791035
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test with a valid path
    path = os.path.join(os.path.dirname(__file__), '..', '..', 'lib', 'ansible', 'plugins')
    add_all_plugin_dirs(path)
    for name, obj in get_all_plugin_loaders():
        if obj.subdir:
            plugin_path = os.path.join(path, obj.subdir)
            assert plugin_path in obj._directories
    # Test with an invalid path
    path = os.path.join(os.path.dirname(__file__), '..', '..', 'lib', 'ansible', 'plugins', 'not_a_dir')
    add_all_plugin_dirs(path)

# Generated at 2022-06-17 12:19:37.142125
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a valid plugin name
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionModule')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')

    # Test with a valid plugin name and a suffix
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionModule')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping', suffix='_plugin')
    assert plugin_load_context.resolved
    assert plugin_load_

# Generated at 2022-06-17 12:19:38.369840
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # FIXME: Add tests for this method
    pass


# Generated at 2022-06-17 12:19:40.851475
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # TODO: implement test
    pass


# Generated at 2022-06-17 12:19:52.690852
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test with a non-existent plugin
    loader = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action')
    result = loader.get_with_context('non_existent_plugin')
    assert result.object is None
    assert result.plugin_load_context.resolved is False
    assert result.plugin_load_context.plugin_resolved_name is None
    assert result.plugin_load_context.plugin_resolved_path is None
    assert result.plugin_load_context.redirect_list == []

    # Test with a plugin that exists
    result = loader.get_with_context('copy')
    assert result.object is not None
    assert result.plugin_load_context.resolved is True
    assert result.plugin_load_context.plugin_resolved_name == 'copy'

# Generated at 2022-06-17 12:19:59.303216
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test if the function can handle invalid path
    add_all_plugin_dirs('/invalid/path')
    # Test if the function can handle valid path
    add_all_plugin_dirs(os.path.dirname(__file__))



# Generated at 2022-06-17 12:20:08.235561
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS, C.DEFAULT_INVENTORY_ENABLED_HOST_PATTERNS)
    assert 'copy' in plugin_loader

    # Test with a plugin that does not exist
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS, C.DEFAULT_INVENTORY_ENABLED_HOST_PATTERNS)
    assert 'does_not_exist' not in plugin_loader


# Generated at 2022-06-17 12:20:09.231619
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # TODO: Implement unit test for method get_with_context of class PluginLoader
    pass


# Generated at 2022-06-17 12:20:14.408528
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin name that exists in the default path
    loader = PluginLoader('callback', 'ansible.plugins.callback', C.DEFAULT_CALLBACK_PLUGINS, 'callback', required_base_class='CallbackBase')
    plugin_load_context = loader.find_plugin_with_context('default')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'default'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/callback/default.py')

    # Test with a plugin name that exists in the default path and a collection
    loader = PluginLoader('callback', 'ansible.plugins.callback', C.DEFAULT_CALLBACK_PLUGINS, 'callback', required_base_class='CallbackBase')
    plugin

# Generated at 2022-06-17 12:20:42.263911
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    import ansible.plugins.loader
    import ansible.plugins.action
    import ansible.plugins.cache
    import ansible.plugins.callback
    import ansible.plugins.connection
    import ansible.plugins.cliconf
    import ansible.plugins.doc_fragments
    import ansible.plugins.filter
    import ansible.plugins.inventory
    import ansible.plugins.lookup
    import ansible.plugins.netconf
    import ansible.plugins.shell
    import ansible.plugins.strategy
    import ansible.plugins.terminal
    import ansible.plugins.test
    import ansible.plugins.vars
    import ansible.plugins.module_utils
    import ansible.plugins.modules
    import ansible.plugins.callback.default
    import ansible.plugins.connection.ssh

# Generated at 2022-06-17 12:20:50.563703
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    plugin_loader = PluginLoader(
        'ansible.plugins.action',
        'ActionModule',
        C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS,
        C.DEFAULT_INVENTORY_ENABLED_HOST_PATTERNS,
        'ansible.plugins.action.ActionModule',
        'action_plugins',
        required_base_class='ActionBase'
    )
    plugin_load_context = plugin_loader.find_plugin_with_context('copy')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'copy'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/copy.py')
    assert plugin_load_context.plugin

# Generated at 2022-06-17 12:21:01.953787
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # create a temp directory
    import tempfile
    tmpdir = tempfile.mkdtemp()
    # create a temp file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpfile.close()
    # create a temp subdirectory
    tmpdir2 = tempfile.mkdtemp(dir=tmpdir)
    # create a temp file in the subdirectory
    tmpfile2 = tempfile.NamedTemporaryFile(dir=tmpdir2, delete=False)
    tmpfile2.close()
    # create a temp subdirectory in the subdirectory
    tmpdir3 = tempfile.mkdtemp(dir=tmpdir2)
    # create a temp file in the subdirectory in the subdirectory

# Generated at 2022-06-17 12:21:13.466634
# Unit test for method get_with_context of class PluginLoader

# Generated at 2022-06-17 12:21:20.088029
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test with a valid plugin
    plugin_loader = PluginLoader(
        'ansible.plugins.action',
        'ActionModule',
        C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS,
        C.DEFAULT_INVENTORY_ENABLED_HOST_PATTERNS,
        'ansible.plugins.action.ActionBase',
        'action_plugins',
        'action',
        required_base_class='ActionBase',
    )
    plugin_load_context = plugin_loader.get_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'

# Generated at 2022-06-17 12:21:31.786129
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    class TestPluginLoadContext(PluginLoadContext):
        def __init__(self):
            super(TestPluginLoadContext, self).__init__()
            self.deprecation_warnings = []

    test_context = TestPluginLoadContext()
    test_context.record_deprecation('test_name', {'warning_text': 'test_warning_text'}, 'test_collection_name')
    assert test_context.deprecation_warnings == ['test_name has been deprecated. test_warning_text']
    assert test_context.deprecated == True
    assert test_context.removal_date == None
    assert test_context.removal_version == None

    test_context = TestPluginLoadContext()

# Generated at 2022-06-17 12:21:34.940794
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # TODO: implement test
    pass


# Generated at 2022-06-17 12:21:44.105718
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_plugin_loader
    from ansible.plugins.loader import get_all_plugin_loaders_by_package
    from ansible.plugins.loader import get_all_plugin_loaders_by_class
    from ansible.plugins.loader import get_all_plugin_loaders_by_type
    from ansible.plugins.loader import get_all_plugin_loaders_by_package_type
    from ansible.plugins.loader import get_all_plugin_loaders_by_class_type
    from ansible.plugins.loader import get_all_plugin_loaders_by_package_class
    from ansible.plugins.loader import get_all_plugin_load

# Generated at 2022-06-17 12:21:52.573836
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    # Test for deprecation with warning_text
    plc = PluginLoadContext()
    plc.record_deprecation('test_name', {'warning_text': 'test_warning_text'}, 'test_collection_name')
    assert plc.deprecated == True
    assert plc.removal_date == None
    assert plc.removal_version == None
    assert plc.deprecation_warnings == ['test_name has been deprecated. test_warning_text']

    # Test for deprecation with removal_date
    plc = PluginLoadContext()
    plc.record_deprecation('test_name', {'removal_date': 'test_removal_date'}, 'test_collection_name')
    assert plc.deprecated == True

# Generated at 2022-06-17 12:21:57.547066
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    '''
    Unit test for method __contains__ of class PluginLoader
    '''
    # TODO: Implement test
    raise SkipTest

# Generated at 2022-06-17 12:22:39.820291
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test for invalid path
    invalid_path = './invalid_path'
    add_all_plugin_dirs(invalid_path)
    # Test for valid path
    valid_path = './test/unit/utils/plugins/test_plugin_dir'
    add_all_plugin_dirs(valid_path)
    assert(valid_path in C.DEFAULT_MODULE_PATH)


# Generated at 2022-06-17 12:22:49.821639
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test with no args
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS)
    assert len(list(loader.all())) > 0

    # Test with args
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS)
    assert len(list(loader.all('foo', 'bar'))) > 0

    # Test with kwargs
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS)
    assert len(list(loader.all(foo='bar'))) > 0

    # Test with args and kwargs


# Generated at 2022-06-17 12:22:58.305957
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    import tempfile
    import shutil
    import os
    import os.path
    import sys
    import ansible.plugins
    import ansible.module_utils
    import ansible.modules
    import ansible.module_utils.common.collections

    # Create a temporary directory and add it to the plugin path
    temp_dir = tempfile.mkdtemp()
    sys.path.append(temp_dir)

    # Create a temporary directory for the module_utils directory
    temp_module_utils_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(temp_module_utils_dir, 'common'))
    os.mkdir(os.path.join(temp_module_utils_dir, 'common', 'collections'))

    # Create a temporary directory for the modules directory
    temp_modules

# Generated at 2022-06-17 12:23:06.500499
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Create a PluginLoader object
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionBase', base_class='ActionBase')
    # Create a plugin_load_context object
    plugin_load_context = PluginLoadContext()
    # Call the method find_plugin of class PluginLoader
    plugin_load_context = plugin_loader.find_plugin_with_context('ping', plugin_load_context=plugin_load_context)
    # Assert that the plugin_load_context object is not None
    assert plugin_load_context is not None
    # Assert that the plugin_load_context object is resolved
    assert plugin_load_context.resolved
    # Assert that the plugin_load_context object has a plugin_resolved_name
    assert plugin_load_context.plugin_resolved_name


# Generated at 2022-06-17 12:23:16.907208
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test that add_all_plugin_dirs doesn't add a directory that doesn't exist
    add_all_plugin_dirs('/tmp/does_not_exist')
    assert len(C.DEFAULT_MODULE_PATH) == len(MODULE_CACHE)

    # Test that add_all_plugin_dirs adds a directory that does exist
    add_all_plugin_dirs('/tmp')
    assert len(C.DEFAULT_MODULE_PATH) + 1 == len(MODULE_CACHE)

    # Test that add_all_plugin_dirs doesn't add a directory that exists but doesn't have a subdir
    add_all_plugin_dirs('/tmp')
    assert len(C.DEFAULT_MODULE_PATH) + 1 == len(MODULE_CACHE)

    # Test that

# Generated at 2022-06-17 12:23:27.074973
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('copy')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'copy'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/copy.py')

    # Test with a plugin that does not exist
    plugin_load_context = plugin_loader.find_plugin_with_context('does_not_exist')
    assert not plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name is None
    assert plugin_load_

# Generated at 2022-06-17 12:23:39.303522
# Unit test for method find_plugin_with_context of class PluginLoader

# Generated at 2022-06-17 12:23:45.995550
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    import ansible.plugins.loader
    import ansible.plugins.action
    import ansible.plugins.connection
    import ansible.plugins.lookup
    import ansible.plugins.callback
    import ansible.plugins.shell
    import ansible.plugins.strategy
    import ansible.plugins.vars
    import ansible.plugins.filter
    import ansible.plugins.test
    import ansible.plugins.terminal
    import ansible.plugins.cache
    import ansible.plugins.inventory
    import ansible.plugins.cliconf
    import ansible.plugins.httpapi
    import ansible.plugins.netconf
    import ansible.plugins.connection
    import ansible.plugins.module_utils
    import ansible.plugins.connection
    import ansible.plugins.doc_fragments

# Generated at 2022-06-17 12:23:58.614335
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test with a valid plugin
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INTERNAL_PLUGINS_PATH, 'action_plugins')
    plugin_load_context = plugin_loader.get_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.redirect_list == []
    assert plugin_load_context.object is not None

    # Test with a non-existent plugin
    plugin_load_context = plugin_loader.get_with_context('non_existent_plugin')
    assert not plugin_load_

# Generated at 2022-06-17 12:24:11.274836
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test with a valid plugin
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INTERNAL_PLUGINS_PATH, 'action_plugins')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/action_plugins/ping.py')
    assert plugin_load_context.plugin_load_name == 'ping'
    assert plugin_load_context.plugin_searched_paths == ['/etc/ansible/action_plugins', '/usr/share/ansible/action_plugins']
    assert plugin_load_context.redirect_

# Generated at 2022-06-17 12:24:35.770484
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # FIXME: This is a stub.
    pass


# Generated at 2022-06-17 12:24:39.987117
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # Test with a valid name
    loader = Jinja2Loader()
    assert loader.get('foo') is None

    # Test with an invalid name
    with pytest.raises(AnsibleError) as excinfo:
        loader.get('foo.bar')
    assert 'No code should call "get" for Jinja2Loaders' in str(excinfo.value)


# Generated at 2022-06-17 12:24:41.842152
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # TODO: Implement unit test for method get_with_context of class PluginLoader
    pass


# Generated at 2022-06-17 12:24:53.830203
# Unit test for method find_plugin of class PluginLoader

# Generated at 2022-06-17 12:25:05.777225
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.action import ActionModule
    from ansible.plugins.action.normal import ActionModule as ActionModule_normal
    from ansible.plugins.action.copy import ActionModule as ActionModule_copy
    from ansible.plugins.action.file import ActionModule as ActionModule_file
    from ansible.plugins.action.script import ActionModule as ActionModule_script
    from ansible.plugins.action.shell import ActionModule as ActionModule_shell
    from ansible.plugins.action.synchronize import ActionModule as ActionModule_synchronize
    from ansible.plugins.action.template import ActionModule as ActionModule_template
    from ansible.plugins.action.win_command import ActionModule as ActionModule_win_command
    from ansible.plugins.action.win_copy import ActionModule

# Generated at 2022-06-17 12:25:09.954906
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    assert plugin_loader.find_plugin('copy') is not None

    # Test with a plugin that does not exist
    assert plugin_loader.find_plugin('does_not_exist') is None


# Generated at 2022-06-17 12:25:20.468620
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test with a plugin that exists in the default path
    plugin_loader = PluginLoader('module_utils', 'AnsibleModule', 'ansible.module_utils')
    plugin_load_context = plugin_loader.find_plugin_with_context('basic')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'basic'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/module_utils/basic.py')

    # Test with a plugin that exists in the default path
    plugin_loader = PluginLoader('module_utils', 'AnsibleModule', 'ansible.module_utils')
    plugin_load_context = plugin_loader.find_plugin_with_context('basic')
    assert plugin_load_context.resolved

# Generated at 2022-06-17 12:25:31.008956
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test with no args
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS)
    assert isinstance(loader.all(), types.GeneratorType)
    # Test with args
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS)
    assert isinstance(loader.all(path_only=True), types.GeneratorType)
    # Test with kwargs
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS)
    assert isinstance(loader.all(path_only=True), types.GeneratorType)
   