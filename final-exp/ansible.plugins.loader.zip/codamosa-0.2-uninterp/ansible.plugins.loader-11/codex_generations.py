

# Generated at 2022-06-17 12:17:07.512183
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    assert PluginLoader('action', 'action_plugins', C.DEFAULT_ACTION_PLUGIN_PATH, 'ActionModule').find_plugin('ping') is not None
    # Test with a plugin that does not exist
    assert PluginLoader('action', 'action_plugins', C.DEFAULT_ACTION_PLUGIN_PATH, 'ActionModule').find_plugin('does_not_exist') is None


# Generated at 2022-06-17 12:17:09.334434
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert add_dirs_to_loader('shell', ['/path/to/shell/plugins']) == None


# Generated at 2022-06-17 12:17:20.347225
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    from ansible.plugins.loader import Jinja2Loader
    from ansible.plugins.loader import PluginLoader
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.collection_loader import AnsibleCollectionRequirement

# Generated at 2022-06-17 12:17:25.911737
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    ''' Test add_all_plugin_dirs '''
    # Test with invalid path
    add_all_plugin_dirs('/tmp/invalid_path')
    # Test with valid path
    add_all_plugin_dirs('/tmp')


# Generated at 2022-06-17 12:17:36.084583
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('ansible/plugins/action/ping.py')
    assert plugin_load_context.redirect_list == []

    # Test with a plugin that does not exist
    plugin_load_context = plugin_loader.find_plugin_with_context('does_not_exist')
    assert not plugin_load_context.resolved
    assert plugin_load_context.plugin

# Generated at 2022-06-17 12:17:39.047058
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    # TODO: implement this test
    pass


# Generated at 2022-06-17 12:17:46.977224
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test with path_only
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    assert len(list(loader.all(path_only=True))) > 0

    # Test with class_only
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    assert len(list(loader.all(class_only=True))) > 0

    # Test with class_only and path_only
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')

# Generated at 2022-06-17 12:17:49.696645
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell_type = 'sh'
    executable = '/bin/sh'
    shell = get_shell_plugin(shell_type, executable)
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == executable



# Generated at 2022-06-17 12:17:58.006332
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin name that is not in the cache
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionModule')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('ansible/plugins/action/ping.py')
    assert plugin_load_context.redirect_list == []

    # Test with a plugin name that is in the cache
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved

# Generated at 2022-06-17 12:18:06.166280
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test with no args
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_ACTION_PLUGIN_PATH, 'action_plugins')
    assert len(list(loader.all())) > 0

    # Test with args
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_ACTION_PLUGIN_PATH, 'action_plugins')
    assert len(list(loader.all(foo='bar'))) > 0

    # Test with path_only
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_ACTION_PLUGIN_PATH, 'action_plugins')
    assert len(list(loader.all(path_only=True))) > 0

    # Test with class_only

# Generated at 2022-06-17 12:18:46.460734
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists in the default path
    loader = PluginLoader('module_utils', 'ansible.module_utils')
    assert loader.find_plugin('basic') == 'ansible/module_utils/basic.py'

    # Test with a plugin that exists in the default path
    loader = PluginLoader('module_utils', 'ansible.module_utils')
    assert loader.find_plugin('basic') == 'ansible/module_utils/basic.py'

    # Test with a plugin that exists in the default path
    loader = PluginLoader('module_utils', 'ansible.module_utils')
    assert loader.find_plugin('basic') == 'ansible/module_utils/basic.py'

    # Test with a plugin that exists in the default path
    loader = PluginLoader('module_utils', 'ansible.module_utils')

# Generated at 2022-06-17 12:18:55.991523
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action', C.DEFAULT_ACTION_PLUGIN_PATH, 'action_plugins')
    plugin_load_context = plugin_loader.find_plugin_with_context('copy')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'copy'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/copy.py')
    assert plugin_load_context.plugin_load_name == 'copy'
    assert plugin_load_context.plugin_searched_paths == C.DEFAULT_ACTION_PLUGIN_PATH
    assert plugin_load_context.plugin_found_in_cache

# Generated at 2022-06-17 12:19:06.622733
# Unit test for function add_all_plugin_dirs

# Generated at 2022-06-17 12:19:10.048940
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    # TODO: Implement unit test for method __setstate__ of class PluginLoader
    #assert False, "Test not implemented"

# Generated at 2022-06-17 12:19:19.620546
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test with a valid plugin
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INTERNAL_PLUGINS_PATH, 'action_plugins')
    result = loader.get_with_context('ping')
    assert result.object is not None
    assert result.resolved is True
    assert result.plugin_resolved_name == 'ping'
    assert result.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert result.redirect_list == []

    # Test with a plugin that does not exist
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INTERNAL_PLUGINS_PATH, 'action_plugins')
    result = loader.get_with_context('does_not_exist')


# Generated at 2022-06-17 12:19:26.186008
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    plc = PluginLoadContext()
    plc.record_deprecation('name', {'warning_text': 'warning_text', 'removal_date': 'removal_date', 'removal_version': 'removal_version'}, 'collection_name')
    assert plc.deprecated == True
    assert plc.removal_date == 'removal_date'
    assert plc.removal_version == 'removal_version'
    assert plc.deprecation_warnings == ['name has been deprecated. warning_text']


# Generated at 2022-06-17 12:19:39.915105
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.plugin_search_paths == ['/home/user/.ansible/plugins/action', '/usr/share/ansible/plugins/action']
    assert plugin_load_context.redirect_list == []

    # Test with a plugin that does not exist

# Generated at 2022-06-17 12:19:49.279151
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    context = PluginLoadContext()
    context.record_deprecation('name', {'warning_text': 'warning_text', 'removal_date': 'removal_date', 'removal_version': 'removal_version'}, 'collection_name')
    assert context.deprecated == True
    assert context.removal_date == 'removal_date'
    assert context.removal_version == 'removal_version'
    assert context.deprecation_warnings == ['name has been deprecated. warning_text']


# Generated at 2022-06-17 12:19:56.491196
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    from ansible.plugins.loader import PluginLoader
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.collection_loader import AnsibleCollectionRequirement
    from ansible.utils.collection_loader import AnsibleCollectionRequirementSpec
    from ansible.utils.collection_loader import AnsibleCollectionSearchPath
    from ansible.utils.collection_loader import AnsibleCollectionVersion
    from ansible.utils.collection_loader import AnsibleCollectionVersionSpec
    from ansible.utils.collection_loader import CollectionRequirementSpec
    from ansible.utils.collection_loader import CollectionSearchPath
    from ansible.utils.collection_loader import CollectionVersion

# Generated at 2022-06-17 12:20:04.809818
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test with all default parameters
    pl = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    pl.all()

    # Test with all parameters
    pl = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    pl.all(path_only=True, class_only=True, _dedupe=False)


# Generated at 2022-06-17 12:20:59.427307
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # TODO: Add unit test
    pass



# Generated at 2022-06-17 12:21:08.122831
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INTERNAL_PLUGINS_PATH, 'action_plugins')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')

    # Test with a plugin that does not exist
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INTERNAL_PLUGINS_PATH, 'action_plugins')
    plugin_load_context = plugin_loader.find_plugin_

# Generated at 2022-06-17 12:21:19.233275
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test with a plugin that exists
    plugin_load_context = PluginLoader('action', 'action', 'ActionModule', 'ansible.plugins.action').find_plugin_with_context('copy')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'copy'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/copy.py')
    assert plugin_load_context.redirect_list == []

    # Test with a plugin that does not exist
    plugin_load_context = PluginLoader('action', 'action', 'ActionModule', 'ansible.plugins.action').find_plugin_with_context('does_not_exist')
    assert not plugin_load_context.resolved
    assert plugin_load_context.plugin_

# Generated at 2022-06-17 12:21:30.740930
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INTERNAL_PLUGINS_PATH, 'action_plugins')
    plugin_load_context = plugin_loader.find_plugin_with_context('copy')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'copy'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/copy.py')
    assert plugin_load_context.plugin_load_context_found_path.endswith('/ansible/plugins/action/copy.py')
    assert plugin_load_context.redirect_list == []

    # Test with a plugin that does not exist

# Generated at 2022-06-17 12:21:41.725272
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # FIXME: This test is not working.  It is not clear what the purpose of this test is.
    #        It needs to be fixed or removed.
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.loader import get_with_context_result
    from ansible.plugins.loader import PluginLoaderContext
    from ansible.plugins.loader import PluginLoaderContextNope
    from ansible.plugins.loader import PluginLoaderContextOk
    from ansible.plugins.loader import PluginLoaderContextRedirect
    from ansible.plugins.loader import PluginLoaderContextResolved
    from ansible.plugins.loader import PluginLoaderContextUnresolved
    from ansible.plugins.loader import PluginLoaderContextUnresolvedRedirect
    from ansible.plugins.loader import PluginLoaderContextUnresolvedRedirectList

# Generated at 2022-06-17 12:21:42.894657
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    # TODO: write unit test for method all of class Jinja2Loader
    pass


# Generated at 2022-06-17 12:21:51.657759
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test with no args
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS)
    assert len(list(loader.all())) > 0

    # Test with args
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS)
    assert len(list(loader.all(1, 2, 3))) > 0

    # Test with kwargs
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS)
    assert len(list(loader.all(a=1, b=2, c=3))) > 0

    # Test

# Generated at 2022-06-17 12:21:58.710284
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    from ansible.plugins.loader import Jinja2Loader
    from ansible.utils.collection_loader import AnsibleCollectionRef

    # We need to mock the base class's all method so that we can test the
    # differences in the Jinja2Loader's all method.
    def mock_all(self, *args, **kwargs):
        return ['a', 'b', 'c']

    Jinja2Loader.all = mock_all

    # We need to mock the base class's find_plugin method so that we can test the
    # differences in the Jinja2Loader's all method.
    def mock_find_plugin(self, name, collection_list=None):
        return name

    Jinja2Loader.find_plugin = mock_find_plugin

    # We need to mock the base class's get method so that we can test the
    # differences

# Generated at 2022-06-17 12:22:00.602378
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    # TODO: implement this test
    pass

# Generated at 2022-06-17 12:22:02.875867
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    # TODO: implement this test
    pass


# Generated at 2022-06-17 12:23:49.706825
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.redirect_list == []

    # Test with a plugin that does not exist
    plugin_load_context = loader.find_plugin_with_context('does_not_exist')
    assert not plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name

# Generated at 2022-06-17 12:23:55.152194
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test with no args
    plugin_load_context = PluginLoader.find_plugin_with_context()
    assert plugin_load_context.resolved == False
    assert plugin_load_context.plugin_resolved_name == None
    assert plugin_load_context.plugin_resolved_path == None
    assert plugin_load_context.redirect_list == None
    assert plugin_load_context.redirect_found == False
    assert plugin_load_context.redirect_from == None
    assert plugin_load_context.redirect_to == None
    assert plugin_load_context.redirect_from_plugin_name == None
    assert plugin_load_context.redirect_to_plugin_name == None
    assert plugin_load_context.redirect_from_plugin_path == None
    assert plugin_load_context.red

# Generated at 2022-06-17 12:24:03.135071
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test with a plugin that exists
    plugin_load_context = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action').find_plugin_with_context('copy')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'copy'
    assert plugin_load_context.plugin_resolved_path.endswith('ansible/plugins/action/copy.py')
    assert plugin_load_context.redirect_list == []

    # Test with a plugin that does not exist
    plugin_load_context = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action').find_plugin_with_context('does_not_exist')
    assert not plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_

# Generated at 2022-06-17 12:24:05.345955
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # TODO: Implement unit test for method all of class PluginLoader
    pass


# Generated at 2022-06-17 12:24:07.320401
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    '''
    Unit test for method __contains__ of class PluginLoader
    '''
    # TODO: Implement test
    pass


# Generated at 2022-06-17 12:24:16.153976
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type='sh')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'
    shell = get_shell_plugin(shell_type='csh')
    assert shell.SHELL_FAMILY == 'csh'
    assert shell.executable == '/bin/csh'
    shell = get_shell_plugin(shell_type='fish')
    assert shell.SHELL_FAMILY == 'fish'
    assert shell.executable == '/usr/bin/fish'
    shell = get_shell_plugin(shell_type='powershell')
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.executable == 'powershell'

# Generated at 2022-06-17 12:24:23.526861
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    # Create an instance of PluginLoader
    plugin_loader = PluginLoader('', '', '', '', '', '', '')
    # Create an instance of PluginLoader
    plugin_loader_1 = PluginLoader('', '', '', '', '', '', '')
    # Create an instance of PluginLoader
    plugin_loader_2 = PluginLoader('', '', '', '', '', '', '')
    # Create an instance of PluginLoader
    plugin_loader_3 = PluginLoader('', '', '', '', '', '', '')
    # Create an instance of PluginLoader
    plugin_loader_4 = PluginLoader('', '', '', '', '', '', '')
    # Create an instance of PluginLoader
    plugin_loader_

# Generated at 2022-06-17 12:24:31.810878
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    import ansible.plugins.loader
    import ansible.plugins.filter
    import ansible.plugins.test

    # TODO: move this to initalization and extract/dedupe plugin names in loader and offset this from
    # caller. It would have to cache/refresh on add_directory to reevaluate plugin list and dedupe.
    # Another option is to always prepend 'ansible.legac'y and force the collection path to
    # load/find plugins, just need to check compatiblity of that approach.
    # This would also enable get/find_plugin for these type of plugins.
    #
    # We have to instantiate a list of all files so that we can reverse the list.
    # We reverse it so that calling code will deduplicate this correctly.
    files = list(ansible.plugins.loader.filter_loader.all())

# Generated at 2022-06-17 12:24:41.965479
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    import ansible.plugins.action
    import ansible.plugins.cache
    import ansible.plugins.callback
    import ansible.plugins.cliconf
    import ansible.plugins.connection
    import ansible.plugins.filter
    import ansible.plugins.inventory
    import ansible.plugins.lookup
    import ansible.plugins.shell
    import ansible.plugins.strategy
    import ansible.plugins.terminal
    import ansible.plugins.test
    import ansible.plugins.vars
    import ansible.plugins.module_utils
    import ansible.plugins.modules
    import ansible.plugins.netconf

    # Test with default arguments
    action_loader = PluginLoader('ActionModule', 'ansible.plugins.action', C.DEFAULT_ACTION_PLUGIN_PATH, 'action_')

# Generated at 2022-06-17 12:24:53.925931
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test with no args
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INTERNAL_PLUGINS_PATH, 'action_plugins')
    assert len(list(plugin_loader.all())) > 0

    # Test with args
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INTERNAL_PLUGINS_PATH, 'action_plugins')
    assert len(list(plugin_loader.all(foo='bar'))) > 0

    # Test with kwargs
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INTERNAL_PLUGINS_PATH, 'action_plugins')
    assert len(list(plugin_loader.all(foo='bar'))) > 0

    #