

# Generated at 2022-06-17 12:18:31.887059
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Test with a directory that does not exist
    loader = PluginLoader('test_plugins', 'TestPlugin', 'test_plugins')
    loader.add_directory(os.path.join(os.path.dirname(__file__), 'test_plugins', 'non_existent_directory'))
    assert len(loader._get_paths()) == 1
    assert loader._get_paths()[0] == os.path.join(os.path.dirname(__file__), 'test_plugins', 'non_existent_directory')

    # Test with a directory that exists
    loader = PluginLoader('test_plugins', 'TestPlugin', 'test_plugins')
    loader.add_directory(os.path.join(os.path.dirname(__file__), 'test_plugins', 'test_plugin_loader'))

# Generated at 2022-06-17 12:18:43.040903
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    # test case 1
    plc = PluginLoadContext()
    plc.record_deprecation('name', {'warning_text': 'warning_text', 'removal_date': 'removal_date', 'removal_version': 'removal_version'}, 'collection_name')
    assert plc.deprecated == True
    assert plc.removal_date == 'removal_date'
    assert plc.removal_version == None
    assert plc.deprecation_warnings == ['name has been deprecated. warning_text']

    # test case 2
    plc = PluginLoadContext()
    plc.record_deprecation('name', {'warning_text': 'warning_text', 'removal_date': None, 'removal_version': 'removal_version'}, 'collection_name')
    assert pl

# Generated at 2022-06-17 12:18:50.877413
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test with no args
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionBase', base_class='ActionBase')
    assert plugin_loader.all()

    # Test with args
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionBase', base_class='ActionBase')
    assert plugin_loader.all(class_only=True)

    # Test with args
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionBase', base_class='ActionBase')
    assert plugin_loader.all(path_only=True)

    # Test with args
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionBase', base_class='ActionBase')
    assert plugin_loader.all

# Generated at 2022-06-17 12:18:51.843988
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    assert add_all_plugin_dirs('/tmp') is None


# Generated at 2022-06-17 12:18:53.449939
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    '''
    Unit test for method __contains__ of class PluginLoader
    '''
    # TODO: implement this test
    pass


# Generated at 2022-06-17 12:18:56.424155
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INTERNAL_PLUGINS_PATH, 'action_plugins')
    assert plugin_loader.__contains__('copy') == True
    assert plugin_loader.__contains__('not_a_plugin') == False


# Generated at 2022-06-17 12:19:01.339308
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test with a valid plugin name
    plugin_loader = PluginLoader(
        'ansible.plugins.action',
        'ActionModule',
        C.DEFAULT_ACTION_PLUGIN_PATH,
        'action_plugins',
        required_base_class='ActionBase'
    )
    plugin_load_context = plugin_loader.get_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.redirect_list == []
    assert plugin_load_context.object.__class__.__name__ == 'ActionModule'
    assert plugin_load_context.object

# Generated at 2022-06-17 12:19:09.873424
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin name that is not in the cache
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.resolved
    assert plugin_load_context.redirect_list == []

    # Test with a plugin name that is in the cache
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')

# Generated at 2022-06-17 12:19:15.740162
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action')
    assert 'copy' in plugin_loader
    # Test with a plugin that does not exist
    assert 'not_a_plugin' not in plugin_loader


# Generated at 2022-06-17 12:19:19.630882
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # TODO: implement this test
    pass


# Generated at 2022-06-17 12:20:08.542449
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test with a plugin that exists
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')

    # Test with a plugin that does not exist
    plugin_load_context = plugin_loader.find_plugin_with_context('does_not_exist')
    assert not plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name is None

# Generated at 2022-06-17 12:20:13.615708
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Test with a directory that does not exist
    pl = PluginLoader(None, None, None)
    pl.add_directory('/tmp/doesnotexist')
    assert pl._get_paths() == []

    # Test with a directory that exists
    pl = PluginLoader(None, None, None)
    pl.add_directory(os.path.dirname(__file__))
    assert os.path.dirname(__file__) in pl._get_paths()

    # Test with a directory that exists and a subdir
    pl = PluginLoader(None, None, None)
    pl.add_directory(os.path.dirname(__file__), 'filter_plugins')
    assert os.path.join(os.path.dirname(__file__), 'filter_plugins') in pl._get_paths()

    #

# Generated at 2022-06-17 12:20:25.239830
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.plugin_load_context_msg == 'plugin found'

    # Test with a plugin that does not exist
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context

# Generated at 2022-06-17 12:20:27.318465
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # TODO: implement
    pass


# Generated at 2022-06-17 12:20:35.752459
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test with a plugin that exists
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionModule')
    plugin_load_context = plugin_loader.get_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.redirect_list == []

    # Test with a plugin that does not exist
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionModule')
    plugin_load_context = plugin_loader.get_with_context('does_not_exist')
    assert not plugin_load_context

# Generated at 2022-06-17 12:20:43.862946
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # NOTE: this is a unit test for a method that is not used by any code.
    #       It is here to ensure that the method is implemented correctly.
    #       If this test fails, then the method should be removed.
    loader = Jinja2Loader('ansible.plugins.filter', 'FilterModule')
    loader.add_directory(os.path.join(os.path.dirname(__file__), 'filter_plugins'))
    assert loader.get('to_nice_yaml') is None
    assert loader.get('ansible.legacy.to_nice_yaml') is None
    assert loader.get('ansible.legacy.to_nice_yaml.to_nice_yaml') is None

# Generated at 2022-06-17 12:20:50.741450
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('ansible/plugins/action/ping.py')

    # Test with a plugin that does not exist
    plugin_load_context = plugin_loader.find_plugin_with_context('does_not_exist')
    assert not plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name is None
    assert plugin_load_context

# Generated at 2022-06-17 12:21:02.069123
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test that add_all_plugin_dirs() adds the plugin directories
    # to the plugin loaders
    #
    # We need to create a temporary directory that contains the
    # plugin directories.  Then we can call add_all_plugin_dirs()
    # and check that the plugin loaders have the directories added.
    #
    # We need to create a temporary directory that contains the
    # plugin directories.  Then we can call add_all_plugin_dirs()
    # and check that the plugin loaders have the directories added.
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary directory for the plugin loaders
    os.mkdir(os.path.join(tmpdir, 'action_plugins'))
    os.mk

# Generated at 2022-06-17 12:21:13.558720
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test with a valid plugin
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INTERNAL_PLUGINS_PATH, 'action_plugins')
    plugin_load_context = loader.get_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.plugin_load_name == 'ping'
    assert plugin_load_context.plugin_load_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.plugin_class_name == 'ActionModule'
    assert plugin_load

# Generated at 2022-06-17 12:21:23.405052
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    import ansible.plugins.filter.core
    import ansible.plugins.test.core
    import ansible.plugins.filter.json
    import ansible.plugins.test.json
    import ansible.plugins.filter.jinja2_filters
    import ansible.plugins.test.jinja2_tests

    # Test for filter plugins
    loader = Jinja2Loader('ansible.plugins.filter', 'FilterModule')
    assert loader.find_plugin('core') == ansible.plugins.filter.core
    assert loader.find_plugin('json') == ansible.plugins.filter.json
    assert loader.find_plugin('jinja2_filters') == ansible.plugins.filter.jinja2_filters

    # Test for test plugins
    loader = Jinja2Loader('ansible.plugins.test', 'TestModule')


# Generated at 2022-06-17 12:23:53.005592
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert False, "Test not implemented"



# Generated at 2022-06-17 12:24:02.404616
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionModule', config_base=None, config_def_ext='.yml', config_def_loader=None, subdir=None, aliases=None, required_base_class=None)
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('ansible/plugins/action/ping.py')

    # Test with a plugin that does not exist

# Generated at 2022-06-17 12:24:10.036402
# Unit test for method find_plugin_with_context of class PluginLoader

# Generated at 2022-06-17 12:24:15.793464
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # Test with valid loader
    add_dirs_to_loader('action', ['/tmp/test_action_path'])
    assert '/tmp/test_action_path' in action_loader._get_paths()

    # Test with invalid loader
    try:
        add_dirs_to_loader('invalid_loader', ['/tmp/test_action_path'])
    except AttributeError:
        pass
    else:
        assert False, 'Expected AttributeError'



# Generated at 2022-06-17 12:24:23.323342
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a non-existent plugin
    loader = PluginLoader('', '', '', '', '')
    assert loader.find_plugin('non-existent') is None

    # Test with a builtin plugin
    loader = PluginLoader('', '', '', '', '')
    assert loader.find_plugin('ping') == 'ansible.builtin.ping'

    # Test with a collection plugin
    loader = PluginLoader('', '', '', '', '')
    assert loader.find_plugin('test_plugin') == 'ansible.collections.test.plugins.test_plugin'

    # Test with a collection plugin and a collection_list
    loader = PluginLoader('', '', '', '', '')

# Generated at 2022-06-17 12:24:30.313919
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # Test with a valid plugin name
    jinja2_loader = Jinja2Loader()
    plugin = jinja2_loader.find_plugin('to_nice_yaml')
    assert plugin == 'ansible/plugins/filter/to_nice_yaml.py'

    # Test with an invalid plugin name
    plugin = jinja2_loader.find_plugin('invalid_plugin_name')
    assert plugin is None

    # Test with a plugin name that is a collection
    plugin = jinja2_loader.find_plugin('ansible.builtin.debug')
    assert plugin is None


# Generated at 2022-06-17 12:24:39.882541
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    from ansible.plugins.loader import add_dirs_to_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import cache_loader
    from ansible.plugins.loader import cliconf_loader
    from ansible.plugins.loader import httpapi_loader

# Generated at 2022-06-17 12:24:43.244207
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    '''
    Unit test for method __contains__ of class PluginLoader
    '''
    obj = PluginLoader('', '', '', '', '', '')
    assert obj.__contains__('') == False


# Generated at 2022-06-17 12:24:53.689222
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    """
    Test function add_dirs_to_loader
    """
    # Test with invalid loader
    try:
        add_dirs_to_loader('invalid_loader', ['/path/to/invalid/loader'])
    except AttributeError:
        pass
    else:
        raise AssertionError('add_dirs_to_loader did not raise AttributeError with invalid loader')

    # Test with valid loader
    try:
        add_dirs_to_loader('action', ['/path/to/valid/loader'])
    except AttributeError:
        raise AssertionError('add_dirs_to_loader raised AttributeError with valid loader')



# Generated at 2022-06-17 12:24:58.250750
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert add_dirs_to_loader('action', ['/path/to/action/plugins']) == None
