

# Generated at 2022-06-17 12:16:17.744479
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    from ansible.plugins.loader import PluginLoader
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import is_collection_ref
    from ansible.module_utils.common.collections import AnsibleCollectionRef
    from ansible.module_utils.common.collections import AnsibleCollectionRefList
    from ansible.module_utils.common.collections import CollectionLoader
    from ansible.module_utils.common.collections import is_collection_version_less_than
    from ansible.module_utils.common.collections import is_collection_version_equal_or_greater_than
    from ansible.module_utils.common.collections import is_collection_version_equal
    from ansible.module_utils.common.collections import is_collection_version_great

# Generated at 2022-06-17 12:16:22.153361
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # TODO: implement this test
    pass


# Generated at 2022-06-17 12:16:31.737572
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INTERNAL_PLUGINS_PATH, 'action_plugins')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')

    # Test with a plugin that does not exist
    plugin_load_context = plugin_loader.find_plugin_with_context('nonexistent')
    assert not plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name is None

# Generated at 2022-06-17 12:16:36.796523
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test with a valid plugin name
    plugin_loader = PluginLoader(
        'ansible.plugins.action',
        'ActionModule',
        'action_plugins',
        required_base_class='ActionBase'
    )
    plugin_load_context = plugin_loader.get_with_context('copy')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'copy'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/copy.py')
    assert plugin_load_context.redirect_list == []
    assert plugin_load_context.object.__class__.__name__ == 'ActionModule'

    # Test with a plugin name that does not exist
    plugin_load_context = plugin_loader.get

# Generated at 2022-06-17 12:16:44.177973
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    # Test for deprecation with removal_date
    plc = PluginLoadContext()
    plc.record_deprecation('test_plugin', {'warning_text': 'test warning', 'removal_date': '2099-01-01'}, 'test_collection')
    assert plc.deprecated is True
    assert plc.removal_date == '2099-01-01'
    assert plc.removal_version is None
    assert plc.deprecation_warnings == ['test_plugin has been deprecated. test warning']

    # Test for deprecation with removal_version
    plc = PluginLoadContext()
    plc.record_deprecation('test_plugin', {'warning_text': 'test warning', 'removal_version': '99.99.99'}, 'test_collection')
    assert pl

# Generated at 2022-06-17 12:16:48.707818
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    result = loader.get_with_context('ping')
    assert result.object.__class__.__name__ == 'Ping'
    assert result.plugin_resolved_name == 'ping'
    assert result.plugin_resolved_path.endswith('ping.py')
    assert result.resolved
    assert result.redirect_list == []
    assert result.plugin_load_context.plugin_resolved_name == 'ping'
    assert result.plugin_load_context.plugin_resolved_path.endswith('ping.py')
    assert result.plugin_load_context.resolved
    assert result.plugin_load_context.redirect_list == []
    assert result.plugin

# Generated at 2022-06-17 12:16:58.359555
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionModule')
    plugin_load_context = plugin_loader.find_plugin_with_context('copy')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'copy'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/copy.py')

    # Test with a plugin that does not exist
    plugin_load_context = plugin_loader.find_plugin_with_context('does_not_exist')
    assert not plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'does_not_exist'
    assert plugin_load_context.plugin

# Generated at 2022-06-17 12:17:06.364836
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type='sh')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'

    shell = get_shell_plugin(executable='/bin/bash')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/bash'

    shell = get_shell_plugin(shell_type='csh')
    assert shell.SHELL_FAMILY == 'csh'
    assert shell.executable == '/bin/csh'

    shell = get_shell_plugin(executable='/bin/tcsh')
    assert shell.SHELL_FAMILY == 'csh'
    assert shell.executable == '/bin/tcsh'


# Generated at 2022-06-17 12:17:15.238400
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type='sh')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'

    shell = get_shell_plugin(shell_type='csh')
    assert shell.SHELL_FAMILY == 'csh'
    assert shell.executable == '/bin/csh'

    shell = get_shell_plugin(shell_type='fish')
    assert shell.SHELL_FAMILY == 'fish'
    assert shell.executable == '/usr/bin/fish'

    shell = get_shell_plugin(executable='/bin/bash')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/bash'


# Generated at 2022-06-17 12:17:24.795302
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test with a plugin name that exists in the cache
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('copy')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'copy'
    assert plugin_load_context.plugin_resolved_path == '/home/travis/build/ansible/ansible/lib/ansible/plugins/action/copy.py'
    assert plugin_load_context.redirect_list == []
    assert plugin_load_context.plugin_load_context_msg == ''
    assert plugin_load_context.plugin_load_context_exception is None
    assert plugin_load

# Generated at 2022-06-17 12:18:38.144535
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test for invalid path
    add_all_plugin_dirs('/tmp/invalid_path')
    # Test for valid path
    add_all_plugin_dirs('/tmp')


# Generated at 2022-06-17 12:18:47.871097
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert getattr(sys.modules[__name__], '%s_loader' % 'action') == action_loader
    assert getattr(sys.modules[__name__], '%s_loader' % 'lookup') == lookup_loader
    assert getattr(sys.modules[__name__], '%s_loader' % 'callback') == callback_loader
    assert getattr(sys.modules[__name__], '%s_loader' % 'connection') == connection_loader
    assert getattr(sys.modules[__name__], '%s_loader' % 'shell') == shell_loader
    assert getattr(sys.modules[__name__], '%s_loader' % 'module_utils') == module_utils_loader
    assert getattr(sys.modules[__name__], '%s_loader' % 'filter') == filter_

# Generated at 2022-06-17 12:18:56.778373
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a valid plugin name
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionModule')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('ansible/plugins/action/ping.py')

    # Test with a valid plugin name and suffix
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionModule')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping', suffix='py')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin

# Generated at 2022-06-17 12:18:57.739699
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert True



# Generated at 2022-06-17 12:19:07.691248
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    '''
    This function tests the add_all_plugin_dirs function.
    '''
    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir)
    # Create a temporary subdirectory
    tmp_subdir = tempfile.mkdtemp(dir=tmp_dir)
    # Create a temporary file in the subdirectory
    tmp_subdir_file = tempfile.NamedTemporaryFile(dir=tmp_subdir)

    # Test that the directory is added to the plugin path
    add_all_plugin_dirs(tmp_dir)
    assert tmp_dir in C.DEFAULT_MODULE_PATH

    # Test that the file is not added to the plugin path
    add_all_

# Generated at 2022-06-17 12:19:18.180189
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test with no arguments
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    assert len(list(loader.all())) > 0

    # Test with path_only
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    assert len(list(loader.all(path_only=True))) > 0

    # Test with class_only
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    assert len(list(loader.all(class_only=True))) > 0

    # Test with _dedupe

# Generated at 2022-06-17 12:19:23.128893
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    '''
    Test add_all_plugin_dirs function
    '''
    # Test with invalid path
    path = "/tmp/invalid_path"
    add_all_plugin_dirs(path)
    # Test with valid path
    path = "./test/units/plugins/test_plugin_loader"
    add_all_plugin_dirs(path)
    # Test with valid path and subdir
    path = "./test/units/plugins/test_plugin_loader/action"
    add_all_plugin_dirs(path)



# Generated at 2022-06-17 12:19:24.287908
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 12:19:30.575854
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test with invalid path
    add_all_plugin_dirs('/invalid/path')
    # Test with valid path
    add_all_plugin_dirs(C.DEFAULT_MODULE_PATH)
    # Test with valid path with subdir
    add_all_plugin_dirs(os.path.join(C.DEFAULT_MODULE_PATH, 'action'))



# Generated at 2022-06-17 12:19:41.947914
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test with a plugin that does not exist
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INTERNAL_PLUGINS_PATH, 'action_plugins')
    plugin_load_context = plugin_loader.get_with_context('this_plugin_does_not_exist')
    assert plugin_load_context.resolved is False
    assert plugin_load_context.plugin_resolved_name is None
    assert plugin_load_context.plugin_resolved_path is None
    assert plugin_load_context.object is None
    assert plugin_load_context.redirect_list == []

    # Test with a plugin that exists

# Generated at 2022-06-17 12:20:03.404282
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # Test for invalid loader
    try:
        add_dirs_to_loader('invalid_loader', [])
        assert False
    except AttributeError:
        assert True

    # Test for valid loader
    add_dirs_to_loader('action', [])
    assert True



# Generated at 2022-06-17 12:20:11.682015
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    from ansible.plugins.loader import add_dirs_to_loader
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_shell_plugin
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_shell_plugin
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_shell_plugin
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_shell_plugin
    from ansible.plugins.loader import shell

# Generated at 2022-06-17 12:20:17.878954
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # Test with a valid plugin name
    plugin_loader = Jinja2Loader('ansible.plugins.filter', 'FilterModule')
    plugin_loader.add_directory(os.path.join(os.path.dirname(__file__), 'filter_plugins'))
    plugin = plugin_loader.get('to_nice_yaml')
    assert plugin is not None
    assert plugin.__name__ == 'to_nice_yaml'

    # Test with an invalid plugin name
    plugin = plugin_loader.get('invalid_plugin')
    assert plugin is None

    # Test with a valid plugin name but invalid plugin type
    plugin = plugin_loader.get('to_nice_yaml', class_only=True)
    assert plugin is None

    # Test with a valid plugin name but invalid plugin type

# Generated at 2022-06-17 12:20:20.854949
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    '''
    Unit test for method __contains__ of class PluginLoader
    '''
    # TODO: Add tests for this method
    pass


# Generated at 2022-06-17 12:20:30.776413
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test with no args
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionBase')
    plugin_loader.all()
    # Test with args
    plugin_loader.all(path_only=True)
    plugin_loader.all(class_only=True)
    plugin_loader.all(path_only=True, class_only=True)
    plugin_loader.all(path_only=True, _dedupe=False)
    plugin_loader.all(class_only=True, _dedupe=False)
    plugin_loader.all(path_only=True, class_only=True, _dedupe=False)
    # Test with args and kwargs
    plugin_loader.all(path_only=True, _dedupe=False, foo='bar')

# Generated at 2022-06-17 12:20:41.969945
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type='sh')
    assert shell.SHELL_FAMILY == 'sh'

    shell = get_shell_plugin(shell_type='csh')
    assert shell.SHELL_FAMILY == 'csh'

    shell = get_shell_plugin(executable='/bin/sh')
    assert shell.SHELL_FAMILY == 'sh'

    shell = get_shell_plugin(executable='/bin/csh')
    assert shell.SHELL_FAMILY == 'csh'

    shell = get_shell_plugin(executable='/bin/bash')
    assert shell.SHELL_FAMILY == 'sh'

    shell = get_shell_plugin(executable='/bin/tcsh')
    assert shell.SHELL_FAMILY == 'csh'

# Generated at 2022-06-17 12:20:45.293345
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # TODO: implement unit test for method get of class Jinja2Loader
    pass

# Generated at 2022-06-17 12:20:51.356309
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test with a valid plugin name
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.get_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.redirect_list == []

    # Test with a valid plugin name that is redirected
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.get_

# Generated at 2022-06-17 12:21:02.836712
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists in the default path
    plugin_loader = PluginLoader('callback', 'CallbackModule', 'ansible.plugins.callback', 'callback_plugins')
    assert plugin_loader.find_plugin('default') == 'ansible/plugins/callback/default.py'

    # Test with a plugin that exists in a custom path
    plugin_loader = PluginLoader('callback', 'CallbackModule', 'ansible.plugins.callback', 'callback_plugins', 'test/unit/plugins/callback')
    assert plugin_loader.find_plugin('default') == 'test/unit/plugins/callback/default.py'

    # Test with a plugin that does not exist
    plugin_loader = PluginLoader('callback', 'CallbackModule', 'ansible.plugins.callback', 'callback_plugins')
    assert plugin_loader.find_plugin('does_not_exist')

# Generated at 2022-06-17 12:21:14.196700
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # Test with a valid plugin name
    plugin_loader = Jinja2Loader('ansible.plugins.filter', 'FilterModule')
    plugin_loader.add_directory(os.path.join(os.path.dirname(__file__), 'filter_plugins'))
    plugin_loader.find_plugin('to_nice_yaml')

    # Test with a plugin name that does not exist
    plugin_loader = Jinja2Loader('ansible.plugins.filter', 'FilterModule')
    plugin_loader.add_directory(os.path.join(os.path.dirname(__file__), 'filter_plugins'))
    with pytest.raises(AnsibleError) as excinfo:
        plugin_loader.find_plugin('does_not_exist')

# Generated at 2022-06-17 12:22:22.370212
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Test with a directory that does not exist
    loader = PluginLoader(package='ansible.plugins.test', class_name='TestPlugin')
    loader.add_directory(os.path.join(os.path.dirname(__file__), 'test_plugins', 'test_dir'))
    assert len(loader._get_paths()) == 1
    assert os.path.join(os.path.dirname(__file__), 'test_plugins', 'test_dir') in loader._get_paths()
    # Test with a directory that exists
    loader = PluginLoader(package='ansible.plugins.test', class_name='TestPlugin')
    loader.add_directory(os.path.join(os.path.dirname(__file__), 'test_plugins', 'test_dir'))

# Generated at 2022-06-17 12:22:28.977236
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    from ansible.plugins.loader import Jinja2Loader
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    import os
    import sys
    import tempfile
    import shutil
    import pytest
    import glob
    import importlib

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary python module
    module_name = 'test_module'
    module_path = os.path.join(tmpdir, '%s.py' % module_name)

# Generated at 2022-06-17 12:22:31.089906
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    '''
    Unit test for method __contains__ of class PluginLoader
    '''
    # TODO: Implement test
    pass


# Generated at 2022-06-17 12:22:41.256071
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test with no args
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS)
    assert len(list(loader.all())) > 0

    # Test with args
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS)
    assert len(list(loader.all(path_only=True))) > 0

    # Test with args
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS)
    assert len(list(loader.all(class_only=True))) > 0

    # Test with args
    loader = PluginLoader

# Generated at 2022-06-17 12:22:47.347980
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    '''
    Test the function add_all_plugin_dirs
    '''
    # Test for invalid path
    add_all_plugin_dirs('/tmp/invalid_path')
    # Test for valid path
    add_all_plugin_dirs('/tmp')
    # Test for valid path with subdir
    add_all_plugin_dirs('/tmp/ansible_test')



# Generated at 2022-06-17 12:22:50.871731
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # FIXME: implement this test
    pass


# Generated at 2022-06-17 12:22:58.967270
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test with the default value of path_only
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionModule')
    plugin_loader.all()
    # Test with path_only set to True
    plugin_loader.all(path_only=True)
    # Test with class_only set to True
    plugin_loader.all(class_only=True)
    # Test with path_only and class_only set to True
    plugin_loader.all(path_only=True, class_only=True)
    # Test with _dedupe set to False
    plugin_loader.all(_dedupe=False)
    # Test with _dedupe set to False and path_only set to True
    plugin_loader.all(_dedupe=False, path_only=True)
    # Test with _dedupe set

# Generated at 2022-06-17 12:23:00.523259
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # TODO: implement this test
    pass


# Generated at 2022-06-17 12:23:05.607961
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # Test with invalid loader
    try:
        add_dirs_to_loader('invalid_loader', [])
    except AttributeError:
        pass
    else:
        assert False, 'add_dirs_to_loader did not raise AttributeError for invalid loader'

    # Test with valid loader
    try:
        add_dirs_to_loader('shell', [])
    except AttributeError:
        assert False, 'add_dirs_to_loader raised AttributeError for valid loader'



# Generated at 2022-06-17 12:23:14.068524
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    from ansible.plugins.loader import add_dirs_to_loader
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_shell_plugin
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import cache_loader

# Generated at 2022-06-17 12:24:16.896507
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    loader = PluginLoader(package='ansible.plugins.action', class_name='ActionModule')
    assert 'copy' in loader
    assert 'not_a_plugin' not in loader


# Generated at 2022-06-17 12:24:21.601358
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # Test with a valid loader
    add_dirs_to_loader('action', ['/tmp/action_plugins'])
    assert '/tmp/action_plugins' in action_loader.plugin_paths

    # Test with an invalid loader
    try:
        add_dirs_to_loader('invalid_loader', ['/tmp/invalid_loader_plugins'])
    except AttributeError:
        pass
    else:
        assert False, 'Expected AttributeError'



# Generated at 2022-06-17 12:24:29.967657
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a valid plugin name
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.redirect_list == []

    # Test with a valid plugin name that is redirected
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context

# Generated at 2022-06-17 12:24:31.911741
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert add_dirs_to_loader('action', ['/path/to/action']) == None


# Generated at 2022-06-17 12:24:35.972414
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # FIXME: implement this test
    pass


# Generated at 2022-06-17 12:24:43.327297
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test with a valid plugin
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INTERNAL_PLUGINS_PATH, 'action_plugins')
    plugin_load_context = loader.get_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.redirect_list == []

    # Test with a plugin that doesn't exist
    plugin_load_context = loader.get_with_context('does_not_exist')
    assert not plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_

# Generated at 2022-06-17 12:24:45.393369
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # TODO: implement this test
    assert False


# Generated at 2022-06-17 12:24:57.221923
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Test with a directory that does not exist
    loader = PluginLoader('test_plugins', 'TestPlugin', 'test_plugins')
    loader.add_directory('/tmp/does_not_exist')
    assert loader._get_paths() == []

    # Test with a directory that exists
    loader = PluginLoader('test_plugins', 'TestPlugin', 'test_plugins')
    loader.add_directory('/tmp')
    assert loader._get_paths() == ['/tmp']

    # Test with a directory that exists and is already in the list
    loader = PluginLoader('test_plugins', 'TestPlugin', 'test_plugins')
    loader.add_directory('/tmp')
    loader.add_directory('/tmp')
    assert loader._get_paths() == ['/tmp']

    # Test with a directory that exists and is already in

# Generated at 2022-06-17 12:25:06.268196
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test with a valid plugin name
    plugin_loader = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action')
    plugin_load_context = plugin_loader.get_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('ansible/plugins/action/ping.py')
    assert plugin_load_context.redirect_list == []

    # Test with a valid plugin name that has been redirected
    plugin_loader = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action')
    plugin_load_context = plugin_loader.get_with_context('ping6')
    assert plugin_load_context.resolved

# Generated at 2022-06-17 12:25:13.553376
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type='sh')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'

    shell = get_shell_plugin(shell_type='csh')
    assert shell.SHELL_FAMILY == 'csh'
    assert shell.executable == '/bin/csh'

    shell = get_shell_plugin(shell_type='fish')
    assert shell.SHELL_FAMILY == 'fish'
    assert shell.executable == '/usr/bin/fish'

    shell = get_shell_plugin(shell_type='powershell')
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.executable == 'pwsh'
