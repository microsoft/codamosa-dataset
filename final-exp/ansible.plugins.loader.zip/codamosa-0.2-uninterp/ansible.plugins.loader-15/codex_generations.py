

# Generated at 2022-06-17 12:16:56.807373
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Test with a valid directory
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS, 'action_plugins')
    plugin_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../lib/ansible/plugins/action'))
    assert os.path.join(os.path.dirname(__file__), '../../lib/ansible/plugins/action') in plugin_loader._get_paths()

    # Test with an invalid directory
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS, 'action_plugins')

# Generated at 2022-06-17 12:17:00.194624
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # This test is not yet implemented
    pass


# Generated at 2022-06-17 12:17:10.056863
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test with a valid directory
    b_path = os.path.expanduser(to_bytes(C.DEFAULT_MODULE_PATH, errors='surrogate_or_strict'))
    assert os.path.isdir(b_path)
    for name, obj in get_all_plugin_loaders():
        if obj.subdir:
            plugin_path = os.path.join(b_path, to_bytes(obj.subdir))
            if os.path.isdir(plugin_path):
                obj.add_directory(to_text(plugin_path))
                assert to_text(plugin_path) in obj._directories

    # Test with an invalid directory

# Generated at 2022-06-17 12:17:11.739853
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    # TODO: Implement test
    pass

# Generated at 2022-06-17 12:17:17.734261
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collection_loader import get_collection_roles_paths
    from ansible.utils.collection_loader import get_collection_paths
    from ansible.utils.collection_loader import get_collection_roles_paths
    from ansible.utils.collection_loader import get_collection_paths
    from ansible.utils.collection_loader import get_collection_roles_paths
    from ansible.utils.collection_loader import get_collection_paths
    from ansible.utils.collection_loader import get_collection_roles_paths
    from ansible.utils.collection_loader import get_collection_

# Generated at 2022-06-17 12:17:28.513991
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test with a plugin that exists in the core
    plugin_load_context = PluginLoader('action', '', 'action_plugins').find_plugin_with_context('copy')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'copy'
    assert plugin_load_context.plugin_resolved_path.endswith('/action_plugins/copy.py')
    assert plugin_load_context.redirect_list == []

    # Test with a plugin that exists in a collection
    plugin_load_context = PluginLoader('action', '', 'action_plugins').find_plugin_with_context('ansible.builtin.copy')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ansible.builtin.copy'

# Generated at 2022-06-17 12:17:41.436485
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Test with a directory that does not exist
    pl = PluginLoader('foo', 'bar', 'baz')
    pl.add_directory('/tmp/does/not/exist')
    assert pl._get_paths() == []

    # Test with a directory that does exist
    pl = PluginLoader('foo', 'bar', 'baz')
    pl.add_directory(os.path.dirname(__file__))
    assert pl._get_paths() == [os.path.dirname(__file__)]

    # Test with a directory that does exist and a subdirectory
    pl = PluginLoader('foo', 'bar', 'baz')
    pl.add_directory(os.path.dirname(__file__), 'subdir')

# Generated at 2022-06-17 12:17:50.543386
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    test_paths = ['/path/to/test1', '/path/to/test2']
    add_dirs_to_loader('action', test_paths)
    assert action_loader.paths == test_paths
    add_dirs_to_loader('cache', test_paths)
    assert cache_loader.paths == test_paths
    add_dirs_to_loader('callback', test_paths)
    assert callback_loader.paths == test_paths
    add_dirs_to_loader('cliconf', test_paths)
    assert cliconf_loader.paths == test_paths
    add_dirs_to_loader('connection', test_paths)
    assert connection_loader.paths == test_paths

# Generated at 2022-06-17 12:18:00.538201
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type='sh')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'

    shell = get_shell_plugin(shell_type='csh')
    assert shell.SHELL_FAMILY == 'csh'
    assert shell.executable == '/bin/csh'

    shell = get_shell_plugin(shell_type='fish')
    assert shell.SHELL_FAMILY == 'fish'
    assert shell.executable == '/usr/bin/fish'

    shell = get_shell_plugin(shell_type='powershell')
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.executable == 'powershell'


# Generated at 2022-06-17 12:18:11.099593
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionBase', base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('setup')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'setup'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/setup.py')

    # Test with a plugin that does not exist
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionBase', base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('does_not_exist')
    assert not plugin_

# Generated at 2022-06-17 12:19:25.370671
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # Test with a valid plugin
    plugin_loader = Jinja2Loader('ansible.plugins.filter', 'FilterModule')
    plugin_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../../lib/ansible/plugins/filter'))
    plugin_loader.find_plugin('to_yaml')

    # Test with an invalid plugin
    with pytest.raises(AnsibleError):
        plugin_loader.find_plugin('invalid_plugin')



# Generated at 2022-06-17 12:19:39.601890
# Unit test for method all of class Jinja2Loader

# Generated at 2022-06-17 12:19:41.203192
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # TODO: implement unit test for method find_plugin of class Jinja2Loader
    pass

# Generated at 2022-06-17 12:19:52.821476
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.loader import PluginLoader

    class TestPluginLoader(PluginLoader):
        subdir = 'test_subdir'

    # Create a temporary directory to use as a plugin path
    import tempfile
    tmpdir = tempfile.mkdtemp()
    # Create a subdirectory for the test plugin loader
    test_subdir = os.path.join(tmpdir, 'test_subdir')
    os.mkdir(test_subdir)

    # Create a plugin file in the test subdirectory
    plugin_file = os.path.join(test_subdir, 'test_plugin')

# Generated at 2022-06-17 12:20:02.445349
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Test with a directory that doesn't exist
    loader = PluginLoader('test_plugins', 'TestPlugin', 'test_plugins', 'test_plugins')
    loader.add_directory('/tmp/does_not_exist')
    assert loader._get_paths() == []

    # Test with a directory that does exist
    loader = PluginLoader('test_plugins', 'TestPlugin', 'test_plugins', 'test_plugins')
    loader.add_directory(os.path.dirname(__file__))
    assert loader._get_paths() == [os.path.dirname(__file__)]

    # Test with a directory that does exist, but is already in the list
    loader = PluginLoader('test_plugins', 'TestPlugin', 'test_plugins', 'test_plugins')

# Generated at 2022-06-17 12:20:03.762475
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # FIXME: This test is not complete
    pass

# Generated at 2022-06-17 12:20:11.931086
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('copy')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'copy'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/copy.py')

    # Test with a plugin that does not exist
    plugin_load_context = plugin_loader.find_plugin_with_context('does_not_exist')
    assert not plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name is None
    assert plugin_load_

# Generated at 2022-06-17 12:20:13.841975
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Create a PluginLoader object
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionBase')
    # Call method all of class PluginLoader
    plugin_loader.all()


# Generated at 2022-06-17 12:20:25.286296
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # Test with a valid plugin name
    assert Jinja2Loader('ansible.plugins.filter', 'FilterModule').find_plugin('to_yaml') == 'ansible.plugins.filter.to_yaml'

    # Test with a valid plugin name and a collection
    assert Jinja2Loader('ansible.plugins.filter', 'FilterModule').find_plugin('to_yaml', collection_list=['ansible.builtin']) == 'ansible.plugins.filter.to_yaml'

    # Test with a valid plugin name and a collection that is not the one that contains the plugin
    assert Jinja2Loader('ansible.plugins.filter', 'FilterModule').find_plugin('to_yaml', collection_list=['ansible.builtin']) == 'ansible.plugins.filter.to_yaml'

    # Test with a valid plugin

# Generated at 2022-06-17 12:20:39.848589
# Unit test for method find_plugin of class Jinja2Loader

# Generated at 2022-06-17 12:21:00.137093
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    # TODO: Implement test_PluginLoader___setstate__
    pass

# Generated at 2022-06-17 12:21:09.160990
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test with a valid plugin
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INTERNAL_PLUGINS_PATH, 'action_plugins')
    plugin_load_context = plugin_loader.get_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.object.__class__.__name__ == 'ActionModule'
    assert plugin_load_context.object._load_name == 'ping'

# Generated at 2022-06-17 12:21:12.677398
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    # TODO: Implement unit test for method __setstate__ of class PluginLoader
    #assert False, "Test not implemented"

# Generated at 2022-06-17 12:21:19.494648
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # Test with a valid plugin
    plugin_loader = Jinja2Loader('ansible.plugins.filter', 'FilterModule')
    plugin_loader.add_directory(os.path.join(os.path.dirname(__file__), 'test_plugins'))
    plugin_loader.find_plugin('test_plugin')

    # Test with an invalid plugin
    with pytest.raises(AnsibleError):
        plugin_loader.find_plugin('invalid_plugin')

    # Test with a plugin from a collection
    plugin_loader.add_directory(os.path.join(os.path.dirname(__file__), 'test_plugins_collections'))
    plugin_loader.find_plugin('ansible_collections.test_ns.test_coll.plugins.filter.test_plugin')

    # Test with an invalid plugin

# Generated at 2022-06-17 12:21:31.403856
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collection_list import AnsibleCollectionRef
    from ansible.plugins.loader import Jinja2Loader

    collection_loader = AnsibleCollectionLoader()
    collection_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../lib/ansible/plugins/filter/'))
    collection_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../lib/ansible/plugins/test/'))
    collection_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../lib/ansible/plugins/lookup/'))

# Generated at 2022-06-17 12:21:42.034465
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test with no args
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins')
    for plugin in loader.all():
        assert isinstance(plugin, ActionModule)

    # Test with args
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins')
    for plugin in loader.all(foo='bar'):
        assert isinstance(plugin, ActionModule)
        assert plugin.foo == 'bar'

    # Test with kwargs
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins')
    for plugin in loader.all(foo='bar'):
        assert isinstance(plugin, ActionModule)
        assert plugin.foo == 'bar'

    # Test with args and kwargs

# Generated at 2022-06-17 12:21:44.917764
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    '''
    Unit test for method __contains__ of class PluginLoader
    '''
    # TODO: Implement unit test
    pass


# Generated at 2022-06-17 12:21:52.562423
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader(
        'ansible.plugins.action',
        'ActionModule',
        C.DEFAULT_ACTION_PLUGIN_PATH,
        'action_plugins',
    )
    plugin_load_context = plugin_loader.find_plugin_with_context('debug')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'debug'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/debug.py')
    assert plugin_load_context.redirect_list == []

    # Test with a plugin that does not exist
    plugin_load_context = plugin_loader.find_plugin_with_context('not_a_plugin')
    assert not plugin

# Generated at 2022-06-17 12:21:54.519319
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    assert True



# Generated at 2022-06-17 12:22:03.876828
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    # Test with a simple state
    state = {'_searched_paths': ['/path/to/plugins']}
    plugin_loader = PluginLoader()
    plugin_loader.__setstate__(state)
    assert plugin_loader._searched_paths == ['/path/to/plugins']
    assert plugin_loader._module_cache == {}
    assert plugin_loader._config_defs == {}

    # Test with a more complex state
    state = {'_searched_paths': ['/path/to/plugins'],
             '_module_cache': {'/path/to/plugins/foo.py': 'module_foo'},
             '_config_defs': {'foo': 'bar'}}
    plugin_loader = PluginLoader()
    plugin_loader.__setstate__(state)

# Generated at 2022-06-17 12:22:39.385157
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    # TODO: implement this test
    pass


# Generated at 2022-06-17 12:22:49.261350
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test that a non-directory path is ignored
    add_all_plugin_dirs('/tmp/ansible_test_add_all_plugin_dirs')
    # Test that a directory path is added
    add_all_plugin_dirs(os.path.join(os.path.dirname(__file__), '..', '..', 'lib', 'ansible', 'plugins'))
    # Test that a directory path is added
    add_all_plugin_dirs(os.path.join(os.path.dirname(__file__), '..', '..', 'lib', 'ansible', 'modules'))
    # Test that a directory path is added

# Generated at 2022-06-17 12:22:53.035752
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    # TODO: implement this test
    pass


# Generated at 2022-06-17 12:22:56.012154
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    '''
    Test add_all_plugin_dirs function
    '''
    # Test invalid path
    add_all_plugin_dirs('/invalid/path')
    # Test valid path
    add_all_plugin_dirs(os.path.dirname(__file__))



# Generated at 2022-06-17 12:22:58.727036
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 12:23:03.466386
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # Test with a valid plugin
    plugin_loader = PluginLoader(
        'ansible.plugins.action',
        'ActionModule',
        C.DEFAULT_ACTION_PLUGIN_PATH,
        'action_plugins',
    )
    assert 'copy' in plugin_loader
    # Test with an invalid plugin
    assert 'invalid_plugin' not in plugin_loader


# Generated at 2022-06-17 12:23:08.390677
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    # TODO: Implement unit test for method __setstate__ of class PluginLoader
    #assert False, "Test case not implemented"

# Generated at 2022-06-17 12:23:14.353239
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test for invalid path
    add_all_plugin_dirs('/tmp/invalid_path')
    # Test for valid path
    add_all_plugin_dirs('/tmp')
    # Test for valid path with subdir
    add_all_plugin_dirs('/tmp/ansible')



# Generated at 2022-06-17 12:23:26.388386
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test with a valid plugin name
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.plugin_resolved_fqcr == 'ansible.plugins.action.ping'
    assert plugin_load_context.plugin_resolved_collection is None
    assert plugin_load_context.redirect_list == []
    assert plugin_load_context.redirect_found

# Generated at 2022-06-17 12:23:39.164704
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type='sh')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'

    shell = get_shell_plugin(shell_type='csh')
    assert shell.SHELL_FAMILY == 'csh'
    assert shell.executable == '/bin/csh'

    shell = get_shell_plugin(shell_type='fish')
    assert shell.SHELL_FAMILY == 'fish'
    assert shell.executable == '/usr/bin/fish'

    shell = get_shell_plugin(shell_type='powershell')
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.executable == 'powershell'

    shell = get_shell_plugin(executable='/bin/sh')

# Generated at 2022-06-17 12:24:43.836467
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('ansible/plugins/action/ping.py')
    assert plugin_load_context.plugin_load_name == 'ping'
    assert plugin_load_context.plugin_searched_paths == loader._searched_paths
    assert plugin_load_context.redirect_list == []

    # Test with a plugin that does not exist

# Generated at 2022-06-17 12:24:55.374468
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test with a valid plugin name
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INTERNAL_PLUGINS_PATH, 'action_plugins')
    plugin_load_context = plugin_loader.get_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('ping.py')
    assert plugin_load_context.redirect_list == []
    assert plugin_load_context.object is not None
    assert plugin_load_context.object._load_name == 'ping'
    assert plugin_load_context.object._original_path.endswith('ping.py')
    assert plugin_load_context

# Generated at 2022-06-17 12:24:58.957609
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # TODO: write unit test for method get of class Jinja2Loader
    pass


# Generated at 2022-06-17 12:25:08.266552
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Create a PluginLoader object
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionBase', config_base=None, subdir=None, aliases=None, required_base_class='ActionBase')
    # Test with a valid plugin name
    assert plugin_loader.find_plugin('setup') == 'ansible.plugins.action.setup'
    # Test with an invalid plugin name
    assert plugin_loader.find_plugin('invalid_plugin_name') is None


# Generated at 2022-06-17 12:25:19.747137
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # Test with a valid plugin name
    jinja2_loader = Jinja2Loader()
    plugin_name = 'ansible.legacy.plugins.filter.json_query'
    plugin_path = jinja2_loader.find_plugin(plugin_name)
    assert plugin_path is not None

    # Test with a valid plugin name and a collection list
    jinja2_loader = Jinja2Loader()
    plugin_name = 'ansible.legacy.plugins.filter.json_query'
    collection_list = [
        'ansible.legacy',
        'ansible.builtin',
        'ansible.collections.test_collection',
    ]
    plugin_path = jinja2_loader.find_plugin(plugin_name, collection_list=collection_list)

# Generated at 2022-06-17 12:25:23.916925
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # Test with a valid name
    loader = Jinja2Loader('ansible.plugins.filter', 'FilterModule')
    loader.add_directory(os.path.join(os.path.dirname(__file__), 'filter_plugins'))
    assert loader.get('to_nice_yaml') is not None

    # Test with an invalid name
    assert loader.get('invalid_name') is None
