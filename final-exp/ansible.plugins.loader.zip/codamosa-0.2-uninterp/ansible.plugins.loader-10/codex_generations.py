

# Generated at 2022-06-17 12:17:06.872485
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    loader = PluginLoader('', '', '', '', '', '', '', '', '', '', '', '')
    assert loader.find_plugin('', '') is None


# Generated at 2022-06-17 12:17:14.610310
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test with no args
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionModule')
    plugin_loader.all()

    # Test with args
    plugin_loader.all(path_only=True)
    plugin_loader.all(class_only=True)
    plugin_loader.all(path_only=True, class_only=True)

    # Test with kwargs
    plugin_loader.all(_dedupe=False)
    plugin_loader.all(path_only=True, _dedupe=False)
    plugin_loader.all(class_only=True, _dedupe=False)
    plugin_loader.all(path_only=True, class_only=True, _dedupe=False)

    # Test with args and kwargs

# Generated at 2022-06-17 12:17:23.044762
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    assert loader.find_plugin('ping') is not None

    # Test with a plugin that does not exist
    assert loader.find_plugin('does_not_exist') is None

    # Test with a plugin that exists in a collection
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase', collection_list=['ansible_collections.test.test_collection'])
    assert loader.find_plugin('ping') is not None

    # Test with a plugin that does not exist in a collection
    assert loader.find_plugin('does_not_exist') is None

    # Test with a plugin that exists in

# Generated at 2022-06-17 12:17:32.622499
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a simple plugin
    plugin_loader = PluginLoader('ansible.plugins.test.test_plugin_loader', 'TestPlugin', 'test_plugin', 'test_plugins')
    plugin_load_context = plugin_loader.find_plugin_with_context('test_plugin')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'test_plugin'
    assert plugin_load_context.plugin_resolved_path.endswith('test_plugin.py')
    assert plugin_load_context.redirect_list == []

    # Test with a plugin that is redirected to a builtin
    plugin_loader = PluginLoader('ansible.plugins.test.test_plugin_loader', 'TestPlugin', 'test_plugin', 'test_plugins')
    plugin_load_context = plugin

# Generated at 2022-06-17 12:17:43.011198
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type='sh')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'
    shell = get_shell_plugin(shell_type='sh', executable='/bin/bash')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/bash'
    shell = get_shell_plugin(executable='/bin/bash')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/bash'
    shell = get_shell_plugin(executable='/bin/zsh')
    assert shell.SHELL_FAMILY == 'csh'
    assert shell.executable == '/bin/zsh'



# Generated at 2022-06-17 12:17:54.938128
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    from ansible.plugins.loader import add_dirs_to_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import fragment_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import cliconf_loader
    from ansible.plugins.loader import netconf_loader
    from ansible.plugins.loader import terminal_loader

# Generated at 2022-06-17 12:18:06.445147
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    from ansible.plugins.loader import PluginLoader
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.collection_loader import AnsibleCollectionRequirement
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.collection_loader import AnsibleCollectionRequirement
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader import AnsibleCollectionFinder
    from ansible.utils.collection_loader import get_collection_roles_paths
    from ansible.utils.collection_loader import get_collection_paths
    from ansible.utils.collection_loader import get_collection_roles_paths
    from ansible.utils.collection_loader import get_collection_paths

# Generated at 2022-06-17 12:18:11.604237
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test with a valid path
    path = os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'units', 'module_utils', 'test_module_utils')
    add_all_plugin_dirs(path)
    assert 'test_module_utils' in sys.modules
    assert 'test_module_utils.test_module_utils' in sys.modules
    assert 'test_module_utils.test_module_utils.test_module_utils' in sys.modules
    assert 'test_module_utils.test_module_utils.test_module_utils.test_module_utils' in sys.modules
    assert 'test_module_utils.test_module_utils.test_module_utils.test_module_utils.test_module_utils' in sys.modules

# Generated at 2022-06-17 12:18:14.117389
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    assert len(list(loader.all())) > 0


# Generated at 2022-06-17 12:18:26.117158
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test with a simple plugin name
    plugin_load_context = PluginLoader('action', 'ActionModule').find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.redirect_list == []

    # Test with a plugin name that is a redirect
    plugin_load_context = PluginLoader('action', 'ActionModule').find_plugin_with_context('copy')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'copy'
    assert plugin_load_context.plugin_resolved_path.endsw

# Generated at 2022-06-17 12:19:16.277402
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    assert PluginLoader('action', 'action_plugins', 'ActionModule').find_plugin('ping') is not None
    # Test with a plugin that does not exist
    assert PluginLoader('action', 'action_plugins', 'ActionModule').find_plugin('not_a_plugin') is None


# Generated at 2022-06-17 12:19:27.223044
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    from ansible.plugins.loader import add_dirs_to_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import fragment_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import cache_loader
    from ansible.plugins.loader import cliconf_loader
    from ansible.plugins.loader import terminal_loader
    from ansible.plugins.loader import vars_loader

# Generated at 2022-06-17 12:19:38.260752
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    test_context = PluginLoadContext()
    test_context.record_deprecation('test_name', {'warning_text': 'test_warning_text'}, 'test_collection_name')
    assert test_context.deprecated == True
    assert test_context.removal_date == None
    assert test_context.removal_version == None
    assert test_context.deprecation_warnings == ['test_name has been deprecated. test_warning_text']
    assert test_context.resolved == False
    assert test_context.resolved_fqcn == None


# Generated at 2022-06-17 12:19:45.888776
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    '''
    Unit test for method all of class PluginLoader
    '''
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INTERNAL_ACTION_PLUGINS_PATH, 'action_plugins')
    assert len(list(loader.all())) > 0


# Generated at 2022-06-17 12:19:54.123735
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Test with a directory that exists
    loader = PluginLoader('test_plugins', 'TestPlugin', 'plugins')
    loader.add_directory(os.path.join(os.path.dirname(__file__), 'test_plugins'))
    assert len(loader._get_paths()) == 1
    assert loader._get_paths()[0] == os.path.join(os.path.dirname(__file__), 'test_plugins')
    # Test with a directory that does not exist
    loader = PluginLoader('test_plugins', 'TestPlugin', 'plugins')
    loader.add_directory(os.path.join(os.path.dirname(__file__), 'test_plugins_not_exist'))
    assert len(loader._get_paths()) == 0


# Generated at 2022-06-17 12:19:57.706395
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert add_dirs_to_loader('shell', ['/path/to/shell/plugins']) == None


# Generated at 2022-06-17 12:20:08.660762
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test with a plugin that exists in the default path
    plugin_load_context = PluginLoader('action', '', '', '', '', '', '', '', '', '').find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_path
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_collection is None

    # Test with a plugin that exists in a collection
    plugin_load_context = PluginLoader('action', '', '', '', '', '', '', '', '', '').find_plugin_with_context('ping', collection_list=['ansible_collections.test.test_collection'])
    assert plugin_load_context.resolved
   

# Generated at 2022-06-17 12:20:10.300193
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    # TODO: Implement test for method __setstate__ of class PluginLoader
    #assert False, "Test not implemented"

# Generated at 2022-06-17 12:20:15.265773
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test with a non-existent plugin
    plugin_loader = PluginLoader(package='ansible.plugins.test', class_name='Test', base_class='BaseClass')
    plugin_load_context = plugin_loader.find_plugin_with_context('non_existent_plugin')
    assert plugin_load_context.resolved is False
    assert plugin_load_context.plugin_resolved_name is None
    assert plugin_load_context.plugin_resolved_path is None
    assert plugin_load_context.redirect_list is None
    assert plugin_load_context.nope_reason is not None
    assert plugin_load_context.nope_reason.startswith('Plugin "non_existent_plugin" was not found')

    # Test with a valid plugin

# Generated at 2022-06-17 12:20:17.970036
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # TODO: Implement unit test for method find_plugin of class PluginLoader
    raise NotImplementedError()


# Generated at 2022-06-17 12:20:41.729521
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    # TODO: implement this test
    pass

# Generated at 2022-06-17 12:20:44.650599
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # TODO: implement
    pass


# Generated at 2022-06-17 12:20:46.110273
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # FIXME: This is a stub test, replace with real tests
    assert True


# Generated at 2022-06-17 12:20:53.279955
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test with a valid plugin
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.plugin_resolved_fqcr == 'ansible.plugins.action.ping'
    assert plugin_load_context.plugin_resolved_collection_name == 'ansible.builtin'

# Generated at 2022-06-17 12:21:04.830920
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('copy')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'copy'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/copy.py')
    assert plugin_load_context.redirect_list == []

    # Test with a plugin that does not exist
    plugin_load_context = plugin_loader.find_plugin_with_context('does_not_exist')
    assert not plugin_load_context.resolved

# Generated at 2022-06-17 12:21:10.941368
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    # TODO: Implement unit test for method __setstate__ of class PluginLoader
    #assert False, "Test not implemented"

# Generated at 2022-06-17 12:21:13.083548
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    # TODO: implement this test
    pass


# Generated at 2022-06-17 12:21:19.851324
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')

    # Test with a plugin that does not exist
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('does_not_exist')
   

# Generated at 2022-06-17 12:21:31.702930
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    loader = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action')
    assert loader.find_plugin('ping') is not None

    # Test with a plugin that does not exist
    loader = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action')
    assert loader.find_plugin('does_not_exist') is None

    # Test with a plugin that exists in a collection
    loader = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action')
    assert loader.find_plugin('ansible_collections.testns.testcoll.plugins.action.ping') is not None

    # Test with a plugin that does not exist in a collection
    loader = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action')


# Generated at 2022-06-17 12:21:34.868969
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # TODO: implement test
    pass


# Generated at 2022-06-17 12:22:22.721134
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    '''
    Test to make sure that the function add_all_plugin_dirs
    adds all the plugin directories in the path provided
    '''
    # Create a temporary directory
    import tempfile
    temp_dir = tempfile.mkdtemp()
    # Create a temporary directory inside the temporary directory
    temp_dir_1 = tempfile.mkdtemp(dir=temp_dir)
    # Create a temporary directory inside the temporary directory
    temp_dir_2 = tempfile.mkdtemp(dir=temp_dir)
    # Create a temporary directory inside the temporary directory
    temp_dir_3 = tempfile.mkdtemp(dir=temp_dir)
    # Create a temporary directory inside the temporary directory
    temp_dir_4 = tempfile.mkdtemp(dir=temp_dir)
    # Create a temporary directory inside the temporary directory

# Generated at 2022-06-17 12:22:33.422271
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.plugin_resolved_fqcr == 'ansible.plugins.action.ping'
    assert plugin_load_context.plugin_resolved_collection_name == 'ansible.builtin'

# Generated at 2022-06-17 12:22:39.787547
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test with a valid path
    path = os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'units', 'module_utils', 'test_module_utils')
    add_all_plugin_dirs(path)
    assert 'test_module_utils' in sys.path
    # Test with an invalid path
    path = os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'units', 'module_utils', 'invalid_path')
    add_all_plugin_dirs(path)
    assert 'invalid_path' not in sys.path



# Generated at 2022-06-17 12:22:47.348632
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    context = PluginLoadContext()
    context.record_deprecation('name', {'warning_text': 'warning_text', 'removal_date': 'removal_date', 'removal_version': 'removal_version'}, 'collection_name')
    assert context.deprecated == True
    assert context.removal_date == 'removal_date'
    assert context.removal_version == 'removal_version'
    assert context.deprecation_warnings == ['name has been deprecated. warning_text']


# Generated at 2022-06-17 12:22:53.998066
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # Test with a non-existent plugin
    loader = Jinja2Loader()
    assert loader.get('non_existent_plugin') is None

    # Test with an existing plugin
    loader = Jinja2Loader()
    assert loader.get('to_yaml') is not None


# Generated at 2022-06-17 12:23:00.024954
# Unit test for method get_with_context of class PluginLoader

# Generated at 2022-06-17 12:23:07.130364
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test with a valid path
    test_path = os.path.join(os.path.dirname(__file__), '..', '..', 'lib', 'ansible', 'plugins')
    add_all_plugin_dirs(test_path)
    for name, obj in get_all_plugin_loaders():
        assert obj.directories[0] == test_path

    # Test with an invalid path
    test_path = os.path.join(os.path.dirname(__file__), '..', '..', 'lib', 'ansible', 'plugins', 'invalid')
    add_all_plugin_dirs(test_path)
    for name, obj in get_all_plugin_loaders():
        assert obj.directories[0] == test_path



# Generated at 2022-06-17 12:23:14.924994
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin name that does not exist
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    assert loader.find_plugin('non_existent_plugin') is None

    # Test with a plugin name that exists
    assert loader.find_plugin('copy') is not None

    # Test with a plugin name that exists but is not a valid plugin
    assert loader.find_plugin('base') is None


# Generated at 2022-06-17 12:23:18.690764
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    # TODO: implement this test
    pass


# Generated at 2022-06-17 12:23:27.810336
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    from ansible.plugins.loader import PluginLoader
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collection_list import AnsibleCollectionRef
    from ansible.utils.collection_list import AnsibleCollectionRequirement
    from ansible.utils.collection_list import AnsibleCollectionRefList
    from ansible.utils.collection_list import AnsibleCollectionRequirementList
    from ansible.utils.collection_list import AnsibleCollectionRefList
    from ansible.utils.collection_list import AnsibleCollectionRequirementList
    from ansible.utils.collection_list import AnsibleCollectionRefList
    from ansible.utils.collection_list import AnsibleCollectionRequirementList
    from ansible.utils.collection_list import AnsibleCollectionRefList
    from ansible.utils.collection_list import AnsibleCollectionRequirement

# Generated at 2022-06-17 12:24:41.988959
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test with a valid plugin
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionBase', base_class='ActionBase',
                                 config_base='action_plugins', config_section='action_plugins',
                                 subdir=None, aliases=None, required_base_class=None)
    plugin_load_context = plugin_loader.get_with_context('ping')
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.resolved
    assert plugin_load_context.redirect_list == []

    # Test with a plugin that doesn't exist
    plugin_load_context = plugin_loader.get

# Generated at 2022-06-17 12:24:46.459761
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test with invalid path
    add_all_plugin_dirs('/invalid/path')
    # Test with valid path
    add_all_plugin_dirs(os.path.join(os.path.dirname(__file__), '../../'))



# Generated at 2022-06-17 12:24:57.540113
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test that all() returns an iterator
    assert isinstance(PluginLoader('ansible.plugins.action').all(), types.GeneratorType)
    # Test that all() returns an iterator of the correct type
    assert isinstance(next(PluginLoader('ansible.plugins.action').all()), ActionBase)
    # Test that all() returns an iterator of the correct type
    assert isinstance(next(PluginLoader('ansible.plugins.cache').all()), CacheModule)
    # Test that all() returns an iterator of the correct type
    assert isinstance(next(PluginLoader('ansible.plugins.callback').all()), CallbackBase)
    # Test that all() returns an iterator of the correct type
    assert isinstance(next(PluginLoader('ansible.plugins.connection').all()), ConnectionBase)
    # Test that all() returns an iterator of the correct

# Generated at 2022-06-17 12:25:06.399345
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.loader import get_plugin_class
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get

# Generated at 2022-06-17 12:25:13.644781
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test with no args
    plugin_load_context = PluginLoader.find_plugin_with_context()
    assert plugin_load_context.resolved == False
    assert plugin_load_context.plugin_resolved_name == None
    assert plugin_load_context.plugin_resolved_path == None
    assert plugin_load_context.plugin_load_context == None
    assert plugin_load_context.redirect_list == None
    assert plugin_load_context.nope_reason == 'No plugin name provided'

    # Test with no args
    plugin_load_context = PluginLoader.find_plugin_with_context(name='test')
    assert plugin_load_context.resolved == False
    assert plugin_load_context.plugin_resolved_name == None

# Generated at 2022-06-17 12:25:23.158731
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('setup')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'setup'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/setup.py')
    assert plugin_load_context.plugin_load_context.plugin_type == 'action_plugins'
    assert plugin_load_context.plugin_load_context.package == 'ansible.plugins.action'
    assert plugin_load_context.plugin_load_context.class_name == 'ActionModule'


# Generated at 2022-06-17 12:25:35.293908
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    from ansible.plugins.loader import PluginLoader
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collection_list import AnsibleCollectionRef
    from ansible.utils.collection_list import AnsibleCollectionRequirement
    from ansible.utils.collection_list import CollectionRequirementSpecifier
    from ansible.utils.collection_list import CollectionRequirementSpecifierType
    from ansible.utils.collection_list import CollectionRequirementSpecifierVersion
    from ansible.utils.collection_list import CollectionRequirementSpecifierVersionComparison
    from ansible.utils.collection_list import CollectionRequirementSpecifierVersionComparisonOperator
    from ansible.utils.collection_list import CollectionRequirementSpecifierVersionComparisonType
    from ansible.utils.collection_list import CollectionRequirementSpecifierVersionComparisonVersion
   