

# Generated at 2022-06-17 12:18:46.974792
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    pl = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS)
    for i in pl.all():
        assert isinstance(i, ActionModule)


# Generated at 2022-06-17 12:18:50.395931
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # FIXME: implement this
    pass


# Generated at 2022-06-17 12:18:56.837833
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # Test the case where the path is a directory
    # Create a temporary directory
    import tempfile
    import shutil
    import os
    import os.path
    import sys
    import ansible.plugins
    from ansible.plugins.loader import add_dirs_to_loader

    temp_dir = tempfile.mkdtemp()
    # Create a subdirectory
    subdir = os.path.join(temp_dir, 'subdir')
    os.mkdir(subdir)
    # Create a file in the subdirectory
    file_path = os.path.join(subdir, 'file')
    with open(file_path, 'w') as f:
        f.write('test')
    # Add the temporary directory to the module loader
    add_dirs_to_loader('module', [temp_dir])
    #

# Generated at 2022-06-17 12:19:07.207311
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    from ansible.plugins.loader import add_dirs_to_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import fragment_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import inventory_loader
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import cache_loader
    from ansible.plugins.loader import clicon

# Generated at 2022-06-17 12:19:10.270420
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    # TODO: Implement unit test for method __setstate__ of class PluginLoader
    #assert False, "Test case not implemented"

# Generated at 2022-06-17 12:19:19.804687
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # Test with a valid plugin name
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionModule')
    assert 'copy' in plugin_loader

    # Test with an invalid plugin name
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionModule')
    assert 'invalid_plugin_name' not in plugin_loader

    # Test with a valid plugin name from a collection
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionModule')
    assert 'test.copy' in plugin_loader

    # Test with an invalid plugin name from a collection
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionModule')
    assert 'test.invalid_plugin_name' not in plugin_loader



# Generated at 2022-06-17 12:19:30.112008
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type='sh')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'

    shell = get_shell_plugin(executable='/bin/bash')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/bash'

    shell = get_shell_plugin(executable='/bin/zsh')
    assert shell.SHELL_FAMILY == 'csh'
    assert shell.executable == '/bin/zsh'

    shell = get_shell_plugin(shell_type='csh', executable='/bin/zsh')
    assert shell.SHELL_FAMILY == 'csh'
    assert shell.executable == '/bin/zsh'



# Generated at 2022-06-17 12:19:34.794715
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type='sh')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'

    shell = get_shell_plugin(shell_type='sh', executable='/bin/bash')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/bash'

    shell = get_shell_plugin(executable='/bin/bash')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/bash'

    shell = get_shell_plugin(executable='/bin/zsh')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/zsh'



# Generated at 2022-06-17 12:19:36.209454
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    # TODO: Implement unit test for method __setstate__ of class PluginLoader
    pass

# Generated at 2022-06-17 12:19:46.449231
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    # Test case 1: deprecation is None
    context = PluginLoadContext()
    context.record_deprecation('name', None, 'collection_name')
    assert context.deprecated == False
    assert context.removal_date == None
    assert context.removal_version == None
    assert context.deprecation_warnings == []

    # Test case 2: deprecation is not None
    context = PluginLoadContext()
    context.record_deprecation('name', {'warning_text': 'warning_text'}, 'collection_name')
    assert context.deprecated == True
    assert context.removal_date == None
    assert context.removal_version == None
    assert context.deprecation_warnings == ['name has been deprecated. warning_text']

    # Test case 3: deprecation is not None and

# Generated at 2022-06-17 12:20:08.297767
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    # TODO: Implement test for method __setstate__ of class PluginLoader
    raise SkipTest


# Generated at 2022-06-17 12:20:13.334636
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Create a PluginLoader object
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS)

    # Add a directory to the search path
    plugin_loader.add_directory(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible', 'plugins', 'action'))

    # Check that the directory was added to the search path
    assert os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible', 'plugins', 'action') in plugin_loader._get_paths()

    # Check that the directory was added to the search path

# Generated at 2022-06-17 12:20:15.240794
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # TODO: implement this test
    pass


# Generated at 2022-06-17 12:20:24.153787
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    loader = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action')
    result = loader.get_with_context('ping')
    assert result.object is not None
    assert result.plugin_load_context.resolved
    assert result.plugin_load_context.plugin_resolved_name == 'ping'
    assert result.plugin_load_context.plugin_resolved_path is not None
    assert result.plugin_load_context.redirect_list == []
    assert result.plugin_load_context.plugin_searched_paths == loader._searched_paths


# Generated at 2022-06-17 12:20:33.333038
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    # Test for deprecation with warning_text
    plc = PluginLoadContext()
    deprecation = {'warning_text': 'This is a warning'}
    plc.record_deprecation('test_name', deprecation, 'test_collection')
    assert plc.deprecated
    assert plc.removal_date is None
    assert plc.removal_version is None
    assert plc.deprecation_warnings == ['test_name has been deprecated. This is a warning']

    # Test for deprecation with removal_date
    plc = PluginLoadContext()
    deprecation = {'removal_date': '2099-12-31'}
    plc.record_deprecation('test_name', deprecation, 'test_collection')
    assert plc.deprecated

# Generated at 2022-06-17 12:20:43.134792
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Test with a directory that does not exist
    loader = PluginLoader('foo', 'bar', 'baz')
    loader.add_directory('/tmp/does_not_exist')
    assert loader._get_paths() == []

    # Test with a directory that does exist
    loader = PluginLoader('foo', 'bar', 'baz')
    loader.add_directory('/tmp')
    assert loader._get_paths() == ['/tmp']

    # Test with a directory that does exist and a subdirectory
    loader = PluginLoader('foo', 'bar', 'baz')
    loader.add_directory('/tmp', 'subdir')
    assert loader._get_paths() == ['/tmp/subdir']

    # Test with a directory that does exist and a subdirectory that does not exist

# Generated at 2022-06-17 12:20:50.611888
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test with a valid plugin name
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    result = plugin_loader.get_with_context('ping')
    assert result.object is not None
    assert result.resolved is True
    assert result.plugin_resolved_name == 'ping'
    assert result.plugin_resolved_path is not None
    assert result.redirect_list == []

    # Test with a valid plugin name that is a redirect
    result = plugin_loader.get_with_context('service')
    assert result.object is not None
    assert result.resolved is True
    assert result.plugin_resolved_name == 'service'
    assert result.plugin_resolved_path is not None
    assert result.redirect

# Generated at 2022-06-17 12:20:53.922709
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS)
    assert len(list(loader.all())) > 0


# Generated at 2022-06-17 12:21:05.258798
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # Test adding a directory to a loader
    test_loader = PluginLoader('test_loader', 'test_plugin', 'TestPlugin')
    test_loader.add_directory(os.path.join(os.path.dirname(__file__), 'test_plugins'))
    assert len(test_loader.all()) == 1
    assert test_loader.all()[0].__name__ == 'TestPlugin'

    # Test adding a directory to a loader that doesn't exist
    try:
        add_dirs_to_loader('test_loader', [os.path.join(os.path.dirname(__file__), 'test_plugins')])
    except AttributeError:
        pass
    else:
        raise AssertionError('add_dirs_to_loader should raise an AttributeError when the loader does not exist')

   

# Generated at 2022-06-17 12:21:09.031126
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert add_dirs_to_loader('shell', ['test']) is None


# Generated at 2022-06-17 12:21:38.697935
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    # Test with a valid state
    state = {'_searched_paths': ['/path/to/plugins'], 'package': 'ansible.plugins.test', 'class_name': 'TestPlugin'}
    plugin_loader = PluginLoader(package='ansible.plugins.test', class_name='TestPlugin')
    plugin_loader.__setstate__(state)
    assert plugin_loader._searched_paths == ['/path/to/plugins']
    assert plugin_loader.package == 'ansible.plugins.test'
    assert plugin_loader.class_name == 'TestPlugin'
    # Test with an invalid state
    state = {'_searched_paths': ['/path/to/plugins'], 'package': 'ansible.plugins.test'}

# Generated at 2022-06-17 12:21:43.751191
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    # TODO: implement this test
    pass


# Generated at 2022-06-17 12:21:52.409590
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test with a valid plugin
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', 'action')
    plugin_load_context = plugin_loader.get_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.redirect_list == []
    assert plugin_load_context.object.__class__.__name__ == 'ActionModule'
    assert plugin_load_context.object._load_name == 'ping'

# Generated at 2022-06-17 12:21:57.826414
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    # FIXME: This test is not implemented
    pass

# Generated at 2022-06-17 12:22:02.232085
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    # TODO: implement this test
    pass


# Generated at 2022-06-17 12:22:07.196574
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    '''
    Unit test for method get_with_context of class PluginLoader
    '''
    # TODO: implement this test
    pass


# Generated at 2022-06-17 12:22:17.414340
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    # Test with a valid state
    loader = PluginLoader('test_plugin_loader', 'test_plugin_loader')
    state = {'package': 'test_plugin_loader', 'class_name': 'test_plugin_loader', 'base_class': None, '_searched_paths': [], '_module_cache': {}}
    loader.__setstate__(state)
    assert loader.package == 'test_plugin_loader'
    assert loader.class_name == 'test_plugin_loader'
    assert loader.base_class is None
    assert loader._searched_paths == []
    assert loader._module_cache == {}
    # Test with an invalid state
    loader = PluginLoader('test_plugin_loader', 'test_plugin_loader')

# Generated at 2022-06-17 12:22:21.255923
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    '''
    Unit test for method __contains__ of class PluginLoader
    '''
    # TODO: implement this test
    pass


# Generated at 2022-06-17 12:22:25.307415
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # TODO: implement
    pass


# Generated at 2022-06-17 12:22:38.430042
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type='sh')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'

    shell = get_shell_plugin(shell_type='csh')
    assert shell.SHELL_FAMILY == 'csh'
    assert shell.executable == '/bin/csh'

    shell = get_shell_plugin(shell_type='fish')
    assert shell.SHELL_FAMILY == 'fish'
    assert shell.executable == '/usr/bin/fish'

    shell = get_shell_plugin(shell_type='powershell')
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.executable == 'pwsh'


# Generated at 2022-06-17 12:23:11.246214
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test with no args
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionModule')
    plugin_loader.all()

    # Test with args
    plugin_loader.all(path_only=True)
    plugin_loader.all(class_only=True)
    plugin_loader.all(path_only=True, class_only=True)
    plugin_loader.all(_dedupe=False)
    plugin_loader.all(path_only=True, _dedupe=False)
    plugin_loader.all(class_only=True, _dedupe=False)
    plugin_loader.all(path_only=True, class_only=True, _dedupe=False)



# Generated at 2022-06-17 12:23:14.401023
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    # TODO: Implement unit test for method __setstate__ of class PluginLoader
    #assert False, "Test not implemented"

# Generated at 2022-06-17 12:23:26.388527
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    import ansible.plugins.loader
    import ansible.plugins.action
    import ansible.plugins.cache
    import ansible.plugins.callback
    import ansible.plugins.connection
    import ansible.plugins.cliconf
    import ansible.plugins.doc_fragments
    import ansible.plugins.filter
    import ansible.plugins.inventory
    import ansible.plugins.lookup
    import ansible.plugins.module_utils
    import ansible.plugins.netconf
    import ansible.plugins.shell
    import ansible.plugins.strategy
    import ansible.plugins.terminal
    import ansible.plugins.test
    import ansible.plugins.vars
    import ansible.plugins.vars.hostvars
    import ansible.plugins.vars.groupvars

# Generated at 2022-06-17 12:23:39.190924
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    """
    Test PluginLoader.all
    """
    # Test with default args
    plugin_loader = PluginLoader(
        'ansible.plugins.action',
        'ActionModule',
        C.DEFAULT_ACTION_PLUGIN_PATH,
        'action_plugins',
        required_base_class='ActionBase'
    )
    plugin_loader.all()
    # Test with args
    plugin_loader.all(path_only=True)
    plugin_loader.all(class_only=True)
    plugin_loader.all(_dedupe=False)
    plugin_loader.all(path_only=True, class_only=True)
    plugin_loader.all(path_only=True, _dedupe=False)
    plugin_loader.all(class_only=True, _dedupe=False)
    plugin_

# Generated at 2022-06-17 12:23:45.953347
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('copy')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'copy'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/copy.py')
    assert plugin_load_context.redirect_list == []
    assert plugin_load_context.search_paths == plugin_loader._get_paths()

    # Test with a plugin that does not exist

# Generated at 2022-06-17 12:23:55.386375
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test with a plugin that exists
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.redirect_list == []

    # Test with a plugin that does not exist
    plugin_load_context = loader.find_plugin_with_context('does_not_exist')
    assert not plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name

# Generated at 2022-06-17 12:24:00.325568
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test with invalid path
    add_all_plugin_dirs('/tmp/invalid_path')
    # Test with valid path
    add_all_plugin_dirs(C.DEFAULT_MODULE_PATH)
    # Test with valid path and subdir
    add_all_plugin_dirs(C.DEFAULT_MODULE_PATH + '/action')



# Generated at 2022-06-17 12:24:06.310827
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test with invalid path
    add_all_plugin_dirs('/invalid/path')
    # Test with valid path
    add_all_plugin_dirs(os.path.dirname(__file__))



# Generated at 2022-06-17 12:24:15.276110
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    '''
    Test that add_all_plugin_dirs adds all plugin dirs in the path provided
    '''
    # Create a fake plugin dir
    fake_plugin_dir = '/tmp/fake_plugin_dir'
    os.makedirs(fake_plugin_dir)

    # Create a fake action plugin
    fake_action_plugin = os.path.join(fake_plugin_dir, 'action_plugins')
    os.makedirs(fake_action_plugin)
    fake_action_plugin_file = os.path.join(fake_action_plugin, 'fake_action_plugin.py')
    with open(fake_action_plugin_file, 'w') as f:
        f.write('#!/usr/bin/python\n')
        f.write('from ansible.plugins.action import ActionBase\n')

# Generated at 2022-06-17 12:24:17.163588
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    # TODO: implement this test
    pass

# Generated at 2022-06-17 12:24:38.255781
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    # TODO: implement this test
    pass

# Generated at 2022-06-17 12:24:44.566286
# Unit test for method find_plugin_with_context of class PluginLoader

# Generated at 2022-06-17 12:24:56.699568
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type='sh')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'
    shell = get_shell_plugin(shell_type='csh')
    assert shell.SHELL_FAMILY == 'csh'
    assert shell.executable == '/bin/csh'
    shell = get_shell_plugin(shell_type='fish')
    assert shell.SHELL_FAMILY == 'fish'
    assert shell.executable == '/usr/bin/fish'
    shell = get_shell_plugin(shell_type='powershell')
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.executable == 'pwsh'
    shell = get_shell_plugin(shell_type='cmd')


# Generated at 2022-06-17 12:25:06.214367
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert get_shell_plugin(shell_type='sh')
    assert get_shell_plugin(executable='/bin/sh')
    assert get_shell_plugin(executable='/bin/bash')
    assert get_shell_plugin(executable='/bin/zsh')
    assert get_shell_plugin(executable='/bin/ksh')
    assert get_shell_plugin(executable='/bin/csh')
    assert get_shell_plugin(executable='/bin/tcsh')
    assert get_shell_plugin(executable='/bin/dash')
    assert get_shell_plugin(executable='/bin/fish')
    assert get_shell_plugin(executable='/bin/ksh93')
    assert get_shell_plugin(executable='/bin/mksh')

# Generated at 2022-06-17 12:25:16.228659
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action')
    plugin_load_context = plugin_loader.find_plugin_with_context('copy')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'copy'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/copy.py')

    # Test with a plugin that does not exist
    plugin_loader = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action')
    plugin_load_context = plugin_loader.find_plugin_with_context('foo')
    assert not plugin_load_context.resolved
    assert plugin_load_context.plugin_res

# Generated at 2022-06-17 12:25:25.514171
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test that we can add a directory to the module path
    test_path = '/tmp/test_add_all_plugin_dirs'
    os.mkdir(test_path)
    os.mkdir(os.path.join(test_path, 'module_utils'))
    add_all_plugin_dirs(test_path)
    assert os.path.join(test_path, 'module_utils') in sys.path
    os.rmdir(os.path.join(test_path, 'module_utils'))
    os.rmdir(test_path)



# Generated at 2022-06-17 12:25:39.295258
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    plc = PluginLoadContext()
    plc.record_deprecation('name', {'warning_text': 'text'}, 'collection_name')
    assert plc.deprecated == True
    assert plc.removal_date == None
    assert plc.removal_version == None
    assert plc.deprecation_warnings == ['name has been deprecated. text']
    plc.record_deprecation('name', {'warning_text': 'text', 'removal_date': 'date'}, 'collection_name')
    assert plc.deprecated == True
    assert plc.removal_date == 'date'
    assert plc.removal_version == None
    assert plc.deprecation_warnings == ['name has been deprecated. text', 'name has been deprecated. text']
    plc.record