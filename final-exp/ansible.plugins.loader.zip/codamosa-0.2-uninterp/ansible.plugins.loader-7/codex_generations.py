

# Generated at 2022-06-17 12:16:12.416234
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # Test adding a directory to a loader
    # This is a bit tricky because we don't want to actually add a directory to the loader
    # that we're using in the test.  So we create a new loader and add a directory to it.
    # Then we check that the directory was added.
    test_loader = PluginLoader('test_loader', 'test_plugin', 'TestPlugin')
    test_loader.add_directory('/tmp/test_dir')
    assert '/tmp/test_dir' in test_loader._directories



# Generated at 2022-06-17 12:16:23.740162
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    import ansible.plugins.loader
    import ansible.plugins.action
    import ansible.plugins.connection
    import ansible.plugins.shell
    import ansible.plugins.strategy
    import ansible.plugins.terminal
    import ansible.plugins.test
    import ansible.plugins.vars
    import ansible.plugins.callback
    import ansible.plugins.cliconf
    import ansible.plugins.httpapi
    import ansible.plugins.inventory
    import ansible.plugins.lookup
    import ansible.plugins.netconf
    import ansible.plugins.shell
    import ansible.plugins.module_utils
    import ansible.plugins.cache
    import ansible.plugins.filter
    import ansible.plugins.test
    import ansible.plugins.connection

# Generated at 2022-06-17 12:16:32.813587
# Unit test for method get_with_context of class PluginLoader

# Generated at 2022-06-17 12:16:37.778657
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test with a valid plugin name
    loader = PluginLoader('callback', 'ansible.plugins.callback', C.DEFAULT_CALLBACK_PLUGINS, 'callback', required_base_class='CallbackBase')
    plugin_load_context = loader.get_with_context('minimal')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'minimal'
    assert plugin_load_context.plugin_resolved_path.endswith('ansible/plugins/callback/minimal.py')
    assert plugin_load_context.redirect_list == []
    assert plugin_load_context.object is not None
    assert plugin_load_context.object._load_name == 'minimal'

# Generated at 2022-06-17 12:16:48.799850
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type='sh')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'

    shell = get_shell_plugin(shell_type='csh')
    assert shell.SHELL_FAMILY == 'csh'
    assert shell.executable == '/bin/csh'

    shell = get_shell_plugin(shell_type='fish')
    assert shell.SHELL_FAMILY == 'fish'
    assert shell.executable == '/usr/bin/fish'

    shell = get_shell_plugin(shell_type='powershell')
    assert shell.SHELL_FAMILY == 'powershell'
    assert shell.executable == 'pwsh'


# Generated at 2022-06-17 12:16:50.880114
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # Test with a valid plugin name
    assert Jinja2Loader('ansible.plugins.filter', 'FilterModule').find_plugin('to_json') == 'ansible.plugins.filter.to_json'

    # Test with an invalid plugin name
    assert Jinja2Loader('ansible.plugins.filter', 'FilterModule').find_plugin('invalid_plugin') is None


# Generated at 2022-06-17 12:16:59.909400
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test with a valid plugin
    plugin_loader = PluginLoader('callback', 'ansible.plugins.callback', C.DEFAULT_CALLBACK_PLUGINS, 'callback')
    plugin_load_context = plugin_loader.get_with_context('default')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'default'
    assert plugin_load_context.plugin_resolved_path.endswith('ansible/plugins/callback/default.py')
    assert plugin_load_context.redirect_list == []
    assert plugin_load_context.object.__class__.__name__ == 'CallbackModule'

    # Test with an invalid plugin
    plugin_load_context = plugin_loader.get_with_context('invalid')
    assert not plugin_load_context

# Generated at 2022-06-17 12:17:07.596329
# Unit test for method all of class Jinja2Loader

# Generated at 2022-06-17 12:17:09.413705
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert add_dirs_to_loader('module', ['/path/to/module']) == None


# Generated at 2022-06-17 12:17:10.893623
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # TODO: Implement unit test for method get_with_context of class PluginLoader
    pass


# Generated at 2022-06-17 12:19:22.588864
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # FIXME: This is a stub.  We need to implement this!
    raise NotImplementedError()


# Generated at 2022-06-17 12:19:28.251166
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.redirect_list == []

    # Test with a plugin that does not exist
    plugin_load_context = plugin_loader.find_plugin_with_context('does_not_exist')
    assert not plugin_load_context.resolved

# Generated at 2022-06-17 12:19:40.421284
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert get_shell_plugin(shell_type='sh')
    assert get_shell_plugin(executable='/bin/sh')
    assert get_shell_plugin(executable='/bin/bash')
    assert get_shell_plugin(executable='/bin/zsh')
    assert get_shell_plugin(executable='/bin/ksh')
    assert get_shell_plugin(executable='/bin/csh')
    assert get_shell_plugin(executable='/bin/tcsh')
    assert get_shell_plugin(executable='/bin/dash')
    assert get_shell_plugin(executable='/bin/fish')
    assert get_shell_plugin(executable='/bin/powershell')
    assert get_shell_plugin(executable='/bin/pwsh')

# Generated at 2022-06-17 12:19:44.216272
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # TODO: Implement unit test for method all of class PluginLoader
    pass


# Generated at 2022-06-17 12:19:53.650265
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('copy')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'copy'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/copy.py')
    assert plugin_load_context.redirect_list == []

    # Test with a plugin that doesn't exist
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find

# Generated at 2022-06-17 12:19:59.726439
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test with a valid path
    path = '~/ansible/plugins'
    add_all_plugin_dirs(path)
    # Test with an invalid path
    path = '~/ansible/plugins/invalid'
    add_all_plugin_dirs(path)


# Generated at 2022-06-17 12:20:03.832496
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_plugin_loader
    from ansible.plugins.loader import get_all_plugin_paths
    from ansible.plugins.loader import get_all_plugin_names
    from ansible.plugins.loader import get_plugin_path
    from ansible.plugins.loader import get_plugin_by_name
    from ansible.plugins.loader import get_plugin_class
    from ansible.plugins.loader import get_plugin_class_args
    from ansible.plugins.loader import get_parent_class
    from ansible.plugins.loader import get_all_plugin_loaders_by_type
    from ansible.plugins.loader import get_all_plugin_classes_by

# Generated at 2022-06-17 12:20:13.743358
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type='sh')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/sh'
    shell = get_shell_plugin(executable='/bin/bash')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/bin/bash'
    shell = get_shell_plugin(shell_type='csh')
    assert shell.SHELL_FAMILY == 'csh'
    assert shell.executable == '/bin/csh'
    shell = get_shell_plugin(shell_type='fish')
    assert shell.SHELL_FAMILY == 'fish'
    assert shell.executable == '/usr/bin/fish'
    shell = get_shell_plugin(shell_type='powershell')

# Generated at 2022-06-17 12:20:25.284200
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test with a valid directory
    test_dir = os.path.join(os.path.dirname(__file__), 'test_plugin_loader')
    add_all_plugin_dirs(test_dir)
    for name, obj in get_all_plugin_loaders():
        if obj.subdir:
            plugin_path = os.path.join(test_dir, obj.subdir)
            assert plugin_path in obj._directories

    # Test with an invalid directory
    test_dir = os.path.join(os.path.dirname(__file__), 'test_plugin_loader_invalid')
    add_all_plugin_dirs(test_dir)
    for name, obj in get_all_plugin_loaders():
        if obj.subdir:
            plugin_path = os.path.join

# Generated at 2022-06-17 12:20:39.847327
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    # Test case 1: deprecation warning is not None
    plc = PluginLoadContext()
    deprecation = {'warning_text': 'This is a deprecation warning', 'removal_date': '2020-01-01'}
    plc.record_deprecation('test_name', deprecation, 'test_collection')
    assert plc.deprecated
    assert plc.removal_date == '2020-01-01'
    assert plc.removal_version is None
    assert plc.deprecation_warnings == ['test_name has been deprecated. This is a deprecation warning']

    # Test case 2: deprecation warning is None
    plc = PluginLoadContext()
    deprecation = None

# Generated at 2022-06-17 12:21:20.349209
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Setup
    plugin_load_context = PluginLoadContext()
    plugin_load_context.plugin_name = 'test_plugin'
    plugin_load_context.plugin_type_name = 'test_type'
    plugin_load_context.package = 'test_package'
    plugin_load_context.search_path = 'test_search_path'
    plugin_load_context.collection_list = ['test_collection']
    plugin_load_context.suffix = 'test_suffix'

    # Test
    plugin_loader = PluginLoader(plugin_load_context)
    plugin_loader.find_plugin(plugin_load_context)

    # Verify
    assert plugin_loader.plugin_load_context == plugin_load_context


# Generated at 2022-06-17 12:21:31.906697
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    ''' Test the add_all_plugin_dirs function '''
    # Test with a valid path
    valid_path = os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'units', 'module_utils', 'test_module_utils')
    add_all_plugin_dirs(valid_path)
    for name, obj in get_all_plugin_loaders():
        if obj.subdir:
            assert valid_path in obj.package_paths
    # Test with an invalid path
    invalid_path = os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'units', 'module_utils', 'test_module_utils', 'invalid_path')

# Generated at 2022-06-17 12:21:43.296289
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # FIXME: this test is incomplete
    # FIXME: this test should be moved to a unit test file
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins')
    assert loader.find_plugin('ping') is not None
    assert loader.find_plugin('ping', collection_list=['ansible.builtin']) is not None
    assert loader.find_plugin('ping', collection_list=['ansible.builtin', 'ansible.builtin']) is not None
    assert loader.find_plugin('ping', collection_list=['ansible.builtin', 'ansible.builtin', 'ansible.builtin']) is not None

# Generated at 2022-06-17 12:21:51.410724
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test with a valid path
    path = os.path.join(os.path.dirname(__file__), '..', '..', 'lib', 'ansible', 'modules')
    add_all_plugin_dirs(path)
    assert len(MODULE_CACHE) > 0
    MODULE_CACHE.clear()

    # Test with an invalid path
    path = os.path.join(os.path.dirname(__file__), '..', '..', 'lib', 'ansible', 'modules', 'not_a_real_path')
    add_all_plugin_dirs(path)
    assert len(MODULE_CACHE) == 0
    MODULE_CACHE.clear()



# Generated at 2022-06-17 12:21:56.774490
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # FIXME: This is a stub.
    #       This test needs to be implemented.
    assert False


# Generated at 2022-06-17 12:22:02.552361
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test with a valid path
    test_path = 'test_path'
    test_subdir = 'test_subdir'
    test_plugin_path = os.path.join(test_path, test_subdir)
    test_plugin_loader = PluginLoader(test_subdir)
    globals()['test_plugin_loader'] = test_plugin_loader
    os.makedirs(test_plugin_path)
    add_all_plugin_dirs(test_path)
    assert test_plugin_loader.directories == [test_plugin_path]
    os.rmdir(test_plugin_path)
    os.rmdir(test_path)

    # Test with an invalid path
    test_path = 'test_path'
    test_subdir = 'test_subdir'
    test_plugin

# Generated at 2022-06-17 12:22:12.888519
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('copy')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'copy'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/copy.py')
    assert plugin_load_context.redirect_list == []
    assert plugin_load_context.plugin_searched_paths == ['/Users/michael/ansible/lib/ansible/plugins/action']

    # Test with a plugin that does not exist

# Generated at 2022-06-17 12:22:22.692403
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    '''
    Test add_all_plugin_dirs function.
    '''
    # Create a temporary directory to use for testing
    import tempfile
    tmpdir = tempfile.mkdtemp()
    # Create a temporary directory to use for testing
    import tempfile
    tmpdir = tempfile.mkdtemp()
    # Create a temporary directory to use for testing
    import tempfile
    tmpdir = tempfile.mkdtemp()
    # Create a temporary directory to use for testing
    import tempfile
    tmpdir = tempfile.mkdtemp()
    # Create a temporary directory to use for testing
    import tempfile
    tmpdir = tempfile.mkdtemp()
    # Create a temporary directory to use for testing
    import tempfile
    tmpdir = tempfile.mkdtemp()
    # Create a temporary directory to use for testing

# Generated at 2022-06-17 12:22:30.389932
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test for invalid path
    try:
        add_all_plugin_dirs('/tmp/invalid_path')
    except Exception as e:
        assert False, 'add_all_plugin_dirs() raised %s unexpectedly!' % e

    # Test for valid path
    try:
        add_all_plugin_dirs('/tmp')
    except Exception as e:
        assert False, 'add_all_plugin_dirs() raised %s unexpectedly!' % e


# Generated at 2022-06-17 12:22:37.966451
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # Test with a valid path
    path = '/tmp/ansible_test_path'
    os.mkdir(path)
    for name, obj in get_all_plugin_loaders():
        if obj.subdir:
            plugin_path = os.path.join(path, obj.subdir)
            os.mkdir(plugin_path)
    add_all_plugin_dirs(path)
    for name, obj in get_all_plugin_loaders():
        if obj.subdir:
            assert path in obj.plugin_paths
    # Test with an invalid path
    path = '/tmp/ansible_test_path_invalid'
    add_all_plugin_dirs(path)

# Generated at 2022-06-17 12:23:22.169954
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # Test with a plugin that exists
    assert 'copy' in PluginLoader('action')
    # Test with a plugin that does not exist
    assert 'does_not_exist' not in PluginLoader('action')


# Generated at 2022-06-17 12:23:28.643000
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Test with no args
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS, 'action_plugins')
    for plugin in loader.all():
        assert plugin.__class__.__name__ == 'ActionModule'

    # Test with args
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS, 'action_plugins')
    for plugin in loader.all(args=['arg1', 'arg2']):
        assert plugin.__class__.__name__ == 'ActionModule'
        assert plugin.args == ['arg1', 'arg2']

    # Test with kwargs

# Generated at 2022-06-17 12:23:37.309647
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')

    # Test with a plugin that does not exist
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins')
    plugin_load_context = plugin_loader.find_plugin_with_context('does_not_exist')
    assert not plugin_load_context.resolved
    assert plugin_load_context

# Generated at 2022-06-17 12:23:49.496440
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('ping.py')
    assert plugin_load_context.redirect_list == []
    assert plugin_load_context.plugin_load_context_list == []

    # Test with a plugin that does not exist
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin

# Generated at 2022-06-17 12:23:55.153329
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find_plugin_with_context('ping')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'ping'
    assert plugin_load_context.plugin_resolved_path.endswith('/ansible/plugins/action/ping.py')
    assert plugin_load_context.redirect_list == []

    # Test with a plugin that does not exist
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    plugin_load_context = plugin_loader.find

# Generated at 2022-06-17 12:24:03.479327
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # Test with a valid plugin
    loader = Jinja2Loader('ansible.plugins.filter', 'FilterModule')
    loader.add_directory(os.path.join(os.path.dirname(__file__), 'test_plugins'))
    plugin = loader.get('test_jinja2_plugin')
    assert plugin.FILTERS == {'test_jinja2_plugin': 'test_jinja2_plugin'}

    # Test with an invalid plugin
    loader = Jinja2Loader('ansible.plugins.filter', 'FilterModule')
    loader.add_directory(os.path.join(os.path.dirname(__file__), 'test_plugins'))
    plugin = loader.get('test_jinja2_plugin_invalid')
    assert plugin is None

    # Test with a plugin that does not exist


# Generated at 2022-06-17 12:24:07.652049
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # Test with a valid name
    jinja2_loader = Jinja2Loader()
    assert jinja2_loader.find_plugin('foo') == None

    # Test with a name that contains a dot
    assert jinja2_loader.find_plugin('foo.bar') == None


# Generated at 2022-06-17 12:24:14.771050
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # Create a mock object to replace 'ansible.module_utils.six.moves'
    mock_six_moves = MagicMock()
    mock_six_moves.__name__ = 'ansible.module_utils.six.moves'
    mock_six_moves.__file__ = 'ansible/module_utils/six/moves.py'

    # Create a mock object to replace 'ansible.module_utils.six'
    mock_six = MagicMock()
    mock_six.__name__ = 'ansible.module_utils.six'
    mock_six.__file__ = 'ansible/module_utils/six.py'
    mock_six.moves = mock_six_moves

    # Create a mock object to replace 'ansible.module_utils.parsing.convert_bool

# Generated at 2022-06-17 12:24:16.228082
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # TODO: write unit test for method get of class Jinja2Loader
    pass

# Generated at 2022-06-17 12:24:24.199017
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a valid plugin name
    plugin_loader = PluginLoader(package='ansible.plugins.action', class_name='ActionBase', config_base=None, config_def_ext=None, subdir=None)
    plugin_load_context = plugin_loader.find_plugin_with_context('setup')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'setup'
    assert plugin_load_context.plugin_resolved_path.endswith('ansible/plugins/action/setup.py')
    assert plugin_load_context.plugin_resolved_fqcr == 'ansible.plugins.action.setup'
    assert plugin_load_context.plugin_resolved_collection_name is None
    assert plugin_load_context.plugin_resolved_collection_version

# Generated at 2022-06-17 12:25:09.017479
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with a plugin that exists
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    assert plugin_loader.find_plugin('copy') is not None
    # Test with a plugin that does not exist
    assert plugin_loader.find_plugin('foobar') is None


# Generated at 2022-06-17 12:25:11.188393
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # TODO: implement this test
    pass


# Generated at 2022-06-17 12:25:14.853488
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # Test with a valid plugin name
    assert PluginLoader.__contains__('action', 'ping')
    # Test with an invalid plugin name
    assert not PluginLoader.__contains__('action', 'invalid_plugin_name')

# Generated at 2022-06-17 12:25:23.887089
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # Test with collection plugin
    j2_loader = Jinja2Loader('ansible.plugins.filter', 'FilterModule', 'ansible.plugins.filter.core')
    j2_loader.add_directory(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'units', 'module_utils', 'collection_plugins', 'test_collection', 'plugins', 'filter_plugins'))
    j2_loader.add_directory(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'units', 'module_utils', 'collection_plugins', 'test_collection', 'plugins', 'test_plugins'))