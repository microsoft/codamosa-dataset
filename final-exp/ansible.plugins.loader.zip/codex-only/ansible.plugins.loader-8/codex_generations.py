

# Generated at 2022-06-23 11:07:51.219481
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    import tempfile

    temp_dir = tempfile.mkdtemp()
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        add_all_plugin_dirs(temp_dir)
        assert not w
        base_plugins = [
            'action_plugins',
            'connection_plugins',
            'filter_plugins',
            'lookup_plugins',
            'module_utils',
            'terminal_plugins',
            'test_plugins'
        ]
        for base_plugin in base_plugins:
            plugin_path = os.path.join(temp_dir, base_plugin)
            os.mkdir(plugin_path)

# Generated at 2022-06-23 11:07:57.162762
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
  '''
  test_PluginLoader_find_plugin_with_context
  '''
  #self, path, package, directories, filter_result, logger
  plugin_load_context = PluginLoadContext(None, None, None, None, None)
  plugin_load_context.plugin_resolved_path = None
  plugin_load_context.resolved = None
  plugin_load_context.plugin_resolved_name = None
  plugin_load_context.redirect_list = None
  plugin_load_context.redirect_supported = None
  plugin_load_context.filtered = None
  plugin_load_context.matched_paths = ["matched_paths"]
  plugin_load_context.matched_count = 1
  assert plugin_load_context.plugin_resolved_path == None
  assert plugin_load_

# Generated at 2022-06-23 11:08:00.695158
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # TODO: Implement unit tests for class PluginLoader method all
    assert False


# Generated at 2022-06-23 11:08:10.462684
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    from ansible.plugins.shell import ShellModule
    shell = get_shell_plugin()
    assert isinstance(shell, ShellModule)

    shell = get_shell_plugin(shell_type='powershell')
    assert isinstance(shell, ShellModule)
    shell = get_shell_plugin(shell_type='powershell', executable="powershell.exe")
    assert isinstance(shell, ShellModule)
    shell = get_shell_plugin(shell_type='powershell', executable="C:\\windows\\system32\\WindowsPowerShell\\v1.0\\powershell.exe")
    assert isinstance(shell, ShellModule)
    # Bug#46780
    # If shell plugin is not compatable, it will raise an AnsibleError.
    # Note: Under Windows environment, this test will be skipped.

# Generated at 2022-06-23 11:08:21.489292
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    from ansible.errors import AnsibleError

    def get_finder_with_context(paths):
        def find_plugin_with_context(name, plugin_load_context):
            plugin_load_context.searched_paths = paths
            if name == 'not_exist':
                return plugin_load_context.nope('{0} is not eligible'.format(name))
            else:
                plugin_load_context.candidate_paths = [name]
                plugin_load_context.candidate_collection = None
                plugin_load_context.redirect_list = []
                plugin_load_context.resolved = True
                return plugin_load_context
        return find_plugin_with_context

    finder = PluginLoader(package='ansible.plugins', class_name='TestClass', base_class='ABC')

# Generated at 2022-06-23 11:08:32.571603
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    '''test add_all_plugin_dirs'''
    test_dir = os.path.join(os.getcwd(), 'test_dir')
    test_plugin_dir = os.path.join(test_dir, 'plugins')
    test_connection_dir = os.path.join(test_plugin_dir, 'connection')
    os.mkdir(test_dir)
    os.mkdir(test_plugin_dir)
    os.mkdir(test_connection_dir)

    add_all_plugin_dirs(test_dir)
    is_test_dir_in_list = False
    is_test_connection_dir_in_list = False
    for name, obj in get_all_plugin_loaders():
        if obj.subdir == 'connection':
            plugin_path = os.path.join

# Generated at 2022-06-23 11:08:34.076780
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plc = PluginLoadContext()
    assert plc is not None


# Generated at 2022-06-23 11:08:42.951029
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    j2l = Jinja2Loader('ansible.plugins.test_plugins', 'TestModule', '', 'test')
    assert j2l._searched_paths  == ['/etc/ansible/test_plugins', os.path.expanduser('~/.ansible/test_plugins'), 'library/test_plugins']
    assert j2l.package          == 'ansible.plugins.test_plugins'
    assert j2l.base_class       == ''
    assert j2l.subdir           == 'test_plugins'


# Generated at 2022-06-23 11:08:50.335321
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    mock_exit_reason = "mock_exit_reason"
    plc = PluginLoadContext()
    plc.nope(mock_exit_reason)
    assert plc.resolved == False
    assert plc.exit_reason == mock_exit_reason
    assert plc.plugin_resolved_path == None
    assert plc.plugin_resolved_name == None
    assert plc.plugin_resolved_collection == None
    assert plc.pending_redirect == None


# Generated at 2022-06-23 11:08:57.761970
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
  from ansible.executor.play_iterator import PlayIterator
  from ansible.playbook.play_context import PlayContext

  play_context = PlayContext()
  iterator = PlayIterator(play=None, play_context=play_context)

# Generated at 2022-06-23 11:09:00.954871
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    loader = Jinja2Loader()
    assert loader.find_plugin('str.strip') == None
    assert loader.find_plugin('str') == None



# Generated at 2022-06-23 11:09:04.633397
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    my_path = '.'
    my_internal = True
    plugin_path_context = PluginPathContext(my_path, my_internal)
    assert plugin_path_context.path == my_path
    assert plugin_path_context.internal == my_internal



# Generated at 2022-06-23 11:09:06.493983
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    assert(PluginPathContext("/tmp", False).path == "/tmp")
    assert(PluginPathContext("/tmp", False).internal == False)



# Generated at 2022-06-23 11:09:18.600890
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    answer = PluginLoader.format_paths({'/a/b/c/d', '/a/b/e/f'})
    assert(answer == "/a/b/c/d, /a/b/e/f")
    # test without leading slash
    answer = PluginLoader.format_paths({'/a/b/c/d', '/e/f'})
    assert(answer == "/a/b/c/d, /e/f")
    # test with leading slash
    answer = PluginLoader.format_paths({'/a/b/c/d', '/e/f'}, leading_slash=True)
    assert(answer == "a/b/c/d, e/f")
    # test with leading double slash

# Generated at 2022-06-23 11:09:21.739852
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    # normal usage
    loader = Jinja2Loader(path)

    # invalid path
    with pytest.raises(AnsibleError) as exc:
        loader = Jinja2Loader("/invalid/path")
    assert "Invalid config path /invalid/path" in to_text(exc)



# Generated at 2022-06-23 11:09:27.573593
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    loader = Jinja2Loader('ansible.plugins.filter.core', 'FilterModule', 'ansible.plugins.filter', None)

    loader._searched_paths = [os.path.join(os.path.dirname(__file__), 'filter_plugins')]
    # Test load by name.
    obj = loader.get('to_uuid')
    assert(obj, not None)
    assert(obj.__name__, equals, 'FilterModule')

    # Test load by path.
    obj = loader.get('to_uuid', os.path.join(os.path.dirname(__file__), 'filter_plugins', 'to_uuid.py'))
    assert(obj, not None)
    assert(obj.__name__, equals, 'FilterModule')

    # Test load by name with different args

# Generated at 2022-06-23 11:09:38.333206
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    def run_test(c):
        p = PluginLoader(*c['a'])
        p.print_paths(c['c'], c['b'])
        pass

    # Test cases for PluginLoader.print_paths

# Generated at 2022-06-23 11:09:44.925286
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # These tests check the behavior and correctness of PluginLoader.find_plugin()
    loader = PluginLoader('.', 'action_plugins')
    assert loader.find_plugin('ping.foo') == 'ping.foo'
    loader = PluginLoader('.', 'filter_plugins')
    assert loader.find_plugin('foo') == 'foo'
    loader = PluginLoader('.', 'lookup_plugins')
    assert loader.find_plugin('foo') == 'foo'
    loader = PluginLoader('.', 'callback_plugins')
    assert loader.find_plugin('foo') == 'foo'
    loader = PluginLoader('.', 'connection_plugins')
    assert loader.find_plugin('foo') == 'foo'
    loader = PluginLoader('.', 'shell_plugins')
    assert loader.find_plugin('foo') == 'foo'
    loader

# Generated at 2022-06-23 11:09:55.865178
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plc = PluginLoadContext()
    assert plc is not None
    assert plc.original_name is None
    assert len(plc.redirect_list) == 0
    assert len(plc.error_list) == 0
    assert len(plc.import_error_list) == 0
    assert len(plc.load_attempts) == 0
    assert plc.pending_redirect is None
    assert plc.exit_reason is None
    assert plc.plugin_resolved_path is None
    assert plc.plugin_resolved_name is None
    assert plc.plugin_resolved_collection is None
    assert not plc.deprecated
    assert plc.removal_date is None
    assert plc.removal_version is None

# Generated at 2022-06-23 11:10:08.016764
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    '''
    :returns: True if constructor of class PluginLoader is correct, False otherwise
    :rtype: bool
    '''

    PLUGIN_BASE_PATH = os.path.join(os.path.dirname(__file__), "unit_tests/files/plugins.collection/ns_1/plugins")

    # Test PluginLoader._get_package_paths()
    pl = PluginLoader(package="ns_1", base_path=PLUGIN_BASE_PATH, subdir="")
    actual_paths = sorted(pl._get_paths())
    expected_paths = sorted([PLUGIN_BASE_PATH])
    assert actual_paths == expected_paths, "Actual: %s, Expected: %s" % (actual_paths, expected_paths)

    # Test PluginLoader

# Generated at 2022-06-23 11:10:14.454452
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    plugin_loader = PluginLoader(
        'ansible.plugins', 'ModuleUtil', C.DEFAULT_MODULE_PATH,
        'module_utils', required_base_class='AnsibleModule'
    )
    assert plugin_loader.package == 'ansible.plugins'
    assert plugin_loader.subdir == 'module_utils'
    assert plugin_loader.class_name == 'ModuleUtil'
    assert plugin_loader.paths == C.DEFAULT_MODULE_PATH
    assert plugin_loader.base_class == 'AnsibleModule'



# Generated at 2022-06-23 11:10:20.440299
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert get_shell_plugin(shell_type="sh").__class__.__name__ == 'ShellModule'
    assert get_shell_plugin(executable="/bin/sh").__class__.__name__ == 'ShellModule'
    assert get_shell_plugin(shell_type="csh").__class__.__name__ == 'CshModule'
    assert get_shell_plugin(shell_type="fish").__class__.__name__ == 'FishModule'



# Generated at 2022-06-23 11:10:28.329512
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    # Test case 1:
    # Inputs: "exit_reason" = 'exit_reason'
    # Expected output: 
    # 'pending_redirect' = None, 'exit_reason' = 'exit_reason', 'resolved' = False

    _exit_reason = 'exit_reason'
    
    # Object initialization
    obj = PluginLoadContext()
    # Test
    _return = obj.nope(_exit_reason)
    # Comparing expected and actual output 
    _a = (_return.pending_redirect, _return.exit_reason, _return.resolved)
    _b = (None, _exit_reason, False)
    assert _a == _b, 'Test case 1 failed'
    # Test passed
test_PluginLoadContext_nope()


# Generated at 2022-06-23 11:10:31.946129
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
   # create a instance of the class
   plugin_loader = PluginLoader('ansible.plugins.module_utils','module_loader')
   assert plugin_loader.print_paths() is None

# Generated at 2022-06-23 11:10:34.649415
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    pluginpathcontext = PluginPathContext('/some/path/', True)
    assert pluginpathcontext.path == '/some/path/' and pluginpathcontext.internal is True



# Generated at 2022-06-23 11:10:41.009789
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    # Import at runtime so not all python files have to import PluginLoader
    from ansible.plugins.loader import PluginLoader
    loaders = get_all_plugin_loaders()
    assert len(loaders) > 15, 'There should be multiple plugin loaders'
    for (name, loader) in loaders:
        assert isinstance(loader, PluginLoader), '%s should be a plugin loader' % name



# Generated at 2022-06-23 11:10:44.990665
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    jinja2_loader = Jinja2Loader('ansible.plugins.filter', 'FilterModule', 'ansible.module_utils.six.moves')
    assert jinja2_loader.base_path == 'ansible/plugins/filter'



# Generated at 2022-06-23 11:10:49.749852
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    play_context_loader = PluginLoader('PlayContext', 'ansible.plugins.connection', C.DEFAULT_CONNECTION_PLUGIN_PATH, 'connection')

    assert play_context_loader.__repr__() == "PluginLoader(path=/home/rakesh/.ansible/plugins/connection, package=ansible.plugins.connection, class_name=PlayContext)"


# Generated at 2022-06-23 11:10:58.996304
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    base_dir = 'lib/ansible/plugins/test/unit/plugins/filter/'
    collection_name = 'ansible.legacy'
    paths = (f'{collection_name}/{base_dir}', base_dir)

    # Get a copy of the global logger, create a plugin loader and add our test plugin directory to it.
    global_logger = logging.getLogger()
    plugin_loader = Jinja2Loader.all(global_logger, collection_name, paths, 'FilterModule', 'BaseFilter')

    for i in plugin_loader:
        assert i.FILTER_PLUGIN_AVAILABLE


# Generated at 2022-06-23 11:11:06.645418
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    c = PluginLoadContext()
    c.resolve('name', 'path', 'collection', 'reason')
    assert c.resolved == True
    assert c.plugin_resolved_name == 'name'
    assert c.plugin_resolved_path == 'path'
    assert c.plugin_resolved_collection == 'collection'
    assert c.exit_reason == 'reason'
    assert c.pending_redirect == None
    assert c.resolved_fqcn == 'collection.name'


# Generated at 2022-06-23 11:11:13.762543
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    p = PluginLoader('ansible.plugins.lookup', 'LookupModule', C.DEFAULT_LOOKUP_PLUGIN_PATH, 'lookup_plugins')
    assert p.package == 'ansible.plugins.lookup'
    assert p.class_name == 'LookupModule'
    assert p.paths == C.DEFAULT_LOOKUP_PLUGIN_PATH
    assert p.subdir == 'lookup_plugins'



# Generated at 2022-06-23 11:11:26.033286
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    """
    Simple test for method all of class Jinja2Loader
    """
    from ansible.plugins.loader import jinja2_loader

    # This is a fake plugin path under the J2_CACHE_PLUGIN_PATH, that we used to not find.
    # If this path is not found, we see the problem of the cached plugins being used by
    # the jinja2_loader.  Since the order of the list was the first cache file, followed by
    # the other file, we were not correctly deduplicating the plugins.  A subset of plugins
    # were being inserted into the global list of plugins twice.
    #
    # If we find this path, we add it later on in the list.  This should show up as two files
    # that are the same.  It was not the cached plugins, so it did not have

# Generated at 2022-06-23 11:11:35.798558
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Set up mock objects
    test_collection = Mock()
    test_collection_loader = Mock()
    test_collection_loader.get_filtered_collections.return_value = [test_collection]
    test_plugin_finder = Mock()
    test_plugin_finder.find_plugin.return_value = PluginLoader._PluginSearchResult(resolved='apple', search_name='apples')
    test_collection_loader.find_plugin.return_value = PluginLoader._PluginSearchResult(resolved='banana', search_name='bananas')
    test_args = {
        'plugin_name': 'apple',
        'plugin_load_context': PluginLoader._PluginLoadContext(
            plugin_name='apples',
            collection_list=['collection'],
            plugin_type='apples'
        )
    }

   

# Generated at 2022-06-23 11:11:47.227218
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    plugin_loader = PluginLoader('', '', '', '', '', '', '')
    plugin_loader = PluginLoader('ansible.plugins.foo', 'Foo', '', '', '', '', '')
    plugin_loader = PluginLoader('ansible.plugins.foo', 'Foo', '', '', '', '', '', 'subdir')
    try:
        plugin_loader = PluginLoader('ansible.plugins.foo', 'Foo', '', '', '', '', '')
    except ImportError as e:
        print(e)
    try:
        plugin_loader = PluginLoader('foo.plugins.bar', 'Bar', '', '', '', '', '')
    except ImportError as e:
        print(e)



# Generated at 2022-06-23 11:11:55.309829
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    # Check type
    assert isinstance(PLUGIN_PATH, string_types)
    assert isinstance(PLUGIN_PATH_SET, set)

    # Check paths
    assert len(PLUGIN_PATH_SET) == len(PLUGIN_PATH.split(os.pathsep)), 'Inconsistent PLUGIN_PATH_SET'
    for path in PLUGIN_PATH_SET:
        assert isinstance(path, string_types)
        assert os.path.isdir(path), 'Path not exists: %s' % path


# Generated at 2022-06-23 11:12:03.145318
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    result = get_with_context_result({}, blacklist={}, whitelist={}, include_files={}, context_only_files={}, context_only_data={}, context_only_vars={})

    assert isinstance(result, WithContextResult)
    assert result._with_context_data == {}
    assert result._blacklist == {}
    assert result._whitelist == {}
    assert result._include_files == {}
    assert result._context_only_files == {}
    assert result._context_only_data == {}
    assert result._context_only_vars == {}

# Generated at 2022-06-23 11:12:11.888219
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    fake_shell_name = "fakeshell"
    fake_shell_class = type(fake_shell_name, (object,), dict(SHELL_FAMILY=fake_shell_name, COMPATIBLE_SHELLS=[]))
    setattr(sys.modules[__name__], fake_shell_name, fake_shell_class)
    result = get_shell_plugin(shell_type=fake_shell_name)
    assert isinstance(result, fake_shell_class)

    delattr(sys.modules[__name__], fake_shell_name)



# Generated at 2022-06-23 11:12:13.702199
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    result = get_with_context_result("action", "plugin")

    assert result is not None

    # Asserting the __str__ method
    assert "action" in str(result)
    assert "plugin" in str(result)



# Generated at 2022-06-23 11:12:16.882762
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    loader = PluginLoader(package='foo', subdir='bar')
    loader.add_directory('')
    assert loader._get_paths() == ['']


# Generated at 2022-06-23 11:12:18.119082
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert get_shell_plugin(executable='/bin/sh') is not None


# Generated at 2022-06-23 11:12:22.714685
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plc = PluginLoadContext()
    plc.exit_reason = 'testing'
    assert 'testing' == plc.exit_reason
    plc.nope('pending')
    assert 'pending' == plc.exit_reason
    assert False == plc.resolved


# Generated at 2022-06-23 11:12:25.433521
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    path_context = PluginPathContext(path='/tmp/path', internal=True)
    assert isinstance(path_context, PluginPathContext)
    assert path_context.path == '/tmp/path'
    assert path_context.internal is True


# Generated at 2022-06-23 11:12:35.441645
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    plugin_load_context = PluginLoadContext()
    plugin_load_context.record_deprecation("deprecation_test",{'warning_text':'no warning_text','removal_date':None,'removal_version':None},"unittest")
    assert plugin_load_context.deprecation_warnings[0] == 'deprecation_test has been deprecated.'
    plugin_load_context.record_deprecation("deprecation_test2",{'warning_text':'test warning_text','removal_date':None,'removal_version':None},"unittest")
    assert plugin_load_context.deprecation_warnings[1] == 'deprecation_test2 has been deprecated. test warning_text'

# Generated at 2022-06-23 11:12:38.915416
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    plugin_loader = PluginLoader(package='ansible.plugins.test.test_action_plugin')
    assert plugin_loader.get('action_test')


# Generated at 2022-06-23 11:12:50.684961
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    import shutil
    import tempfile
    import types

    def _test_loaded(loader, name, path):
        fullpath = os.path.join(path, to_bytes('%s.py' % name))
        module = loader.find_plugin(fullpath, name)
        assert module is not None
        assert hasattr(module, 'lookup_loader')
        assert isinstance(module.lookup_loader, types.FunctionType)

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 11:13:02.335278
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():

    class_instance = get_with_context_result(C.config.get_config_value)
    result = class_instance.get_plugin_variables()
    assert isinstance(result, tuple)
    assert len(result) == 2
    assert result[0] == result[1]
    assert isinstance(result[0], set)
    assert result[0] == {'any_plugin_vars', }

    class_instance = get_with_context_result(C.config.get_config_value, ['test_key'])
    result = class_instance.get_plugin_variables(['test_key'])
    assert isinstance(result, tuple)
    assert len(result) == 2
    assert result[0] == result[1]
    assert isinstance(result[0], set)

# Generated at 2022-06-23 11:13:06.656705
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    import sys
    sys.path.append('/home/bronaugh/dev/ansible/lib/ansible')
    import ansible.parsing.ajax
    import ansible.plugins.loader
    import ansible.utils.plugin_docs
    loader = ansible.plugins.loader.PluginLoader('cache', 'BaseCacheModule', 'PLUGIN_CACHE', 'cache_plugins', required_base_class='BaseCacheModule', config_options=ansible.parsing.ajax.PLUGIN_CONSTANTS, read_docs_from_docstring=True)
    state = {}
    loader.__setstate__

# Generated at 2022-06-23 11:13:18.312709
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    test_path = os.path.join(os.path.dirname(__file__), 'units')
    add_dirs_to_loader('terminal', [test_path])
    assert terminal_loader.get('base')
    assert terminal_loader.get('base') == terminal_loader.get('base')
    assert terminal_loader.get('base').__module__ == 'ansible.plugins.terminal.base'
    assert action_loader.get('ping')
    assert action_loader.get('ping') == action_loader.get('ping')
    assert action_loader.get('ping').__module__ == 'ansible.plugins.action.ping'



# Generated at 2022-06-23 11:13:23.312689
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    PL = PluginLoader("tst.module_utils", "tst", "tst", C.get_config, C.runner_on_failed)
    try:
        PL.add_directory("test/")
    except Exception as ex:
        assert False, "Exception unexpectedly raised: %s" % ex


# Generated at 2022-06-23 11:13:32.674025
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    mock_package = MagicMock(spec_set=str)
    mock_package.__repr__.return_value = 'mock_package'
    mock_class_name = MagicMock(spec_set=str)
    mock_class_name.__repr__.return_value = 'mock_class_name'
    mock_base_class = MagicMock(spec_set=str)
    mock_base_class.__repr__.return_value = 'mock_base_class'

    # Instantiate PluginLoader class
    mock_self = PluginLoader(mock_package, mock_base_class, mock_class_name)
    mock_self.__repr__()

    # Assert repr of class PluginLoader instance is as expected

# Generated at 2022-06-23 11:13:33.768008
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    """ Test for __repr__ """
    assert False

# Generated at 2022-06-23 11:13:44.487076
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    p = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', 'my_dir', required_base_class='ActionBase')
    p._get_paths.return_value = set()
    p._module_cache = {}
    p.find_plugin_with_context.side_effect = None
    p.find_plugin_with_context.return_value = PluginLoadContext(resolved=True, plugin_resolved_name='foo', plugin_resolved_path='/path/to/foo.py')
    p.get_with_context('foo').object = 'foo'
    p.get_with_context.return_value.object = 'foo'

    assert p.get_with_context('foo').object == 'foo'

# Generated at 2022-06-23 11:13:56.847719
# Unit test for method __setstate__ of class PluginLoader

# Generated at 2022-06-23 11:14:03.264294
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    '''
    Unit test for method __getstate__ on class PluginLoader
    '''
    plugin_loader = PluginLoader('my-base-class', 'my-package', 'my-subdir', 'my-classname')
    expected = {'aliases': None, 'class_name': 'my-classname', 'package': 'my-package', 'subdir': 'my-subdir', '_module_cache': {}, '_searched_paths': []}
    assert expected == plugin_loader.__getstate__()


# Generated at 2022-06-23 11:14:10.194793
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
      p = PluginLoader()
      p.add_directory('/path/to/a/directory')
      # unit test for method add_directory of class PluginLoader
      #add_directory is an instance method of class PluginLoader
      assert_true(isinstance(p.add_directory, types.MethodType))
      assert_equal(len(p.package_path), 1)

#Unit test for method _get_paths of class PluginLoader

# Generated at 2022-06-23 11:14:14.109967
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    exit_reason = 'exit_reason'
    resolved = False
    plc = PluginLoadContext
    a = plc.nope(plc, exit_reason)
    assert a.exit_reason == exit_reason
    assert a.resolved == resolved

# Generated at 2022-06-23 11:14:26.082199
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # Testing the PluginLoader.__contains__ function
    from ansible.plugins.module_utils.connection import Connection

    test_plugin_loader = PluginLoader('test_module', 'ansible_test_plugins')

    # Setting up the test by adding a test plugin to the module cache
    test_plugin_loader.add_directory(os.path.join(UNIT_TEST_DATA_ROOT_DIR, 'test_plugins'))
    test_plugin_loader._module_cache[os.path.join(UNIT_TEST_DATA_ROOT_DIR, 'test_plugins', 'test_cache.py')] = Connection

    # Testing that the plugin can be found
    assert 'module_utils.connection.Connection' in test_plugin_loader



# Generated at 2022-06-23 11:14:37.278125
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    plc = PluginLoadContext()
    assert not plc.resolved
    assert not plc.deprecated
    assert plc.pending_redirect is None
    assert plc.plugin_resolved_name is None
    assert plc.plugin_resolved_path is None
    assert plc.plugin_resolved_collection is None
    assert plc.exit_reason is None
    assert plc.deprecation_warnings == []

    plc.original_name = 'bitfield'
    plc.redirect('bitmask')
    assert not plc.resolved
    assert not plc.deprecated
    assert plc.pending_redirect == 'bitmask'
    assert plc.plugin_resolved_name is None
    assert plc.plugin_resolved_path is None
    assert plc.plugin

# Generated at 2022-06-23 11:14:47.645255
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.utils.plugin_docs import filter_examples
    from ansible.utils.display import Display
    from ansible.config.manager import ConfigManager
    from ansible import constants as C
    display = Display()
    config_manager = ConfigManager(display)
    config_manager._read_config_data(parse_options=True)
    display.verbosity = C.DEFAULT_DEBUG_LEVEL
    examples = PluginLoader('ansible.plugins.filter_loader', 'FilterModule', C.DEFAULT_INVENTORY_ENABLED).all(config_manager=config_manager)
    return filter_examples(examples)

# Generated at 2022-06-23 11:14:52.382564
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    assert isinstance(Jinja2Loader('', 'test', '', '', '', ''), PluginLoader)
    assert isinstance(Jinja2Loader('', 'test', '', '', '', ''), Jinja2Loader)

# Note: This is a metaclass.  The class name has to be PluginLoader

# Generated at 2022-06-23 11:15:04.572061
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():

    # Build a plugin loader that can load a filter plugin
    filter_loader = PluginLoader(
        'FilterModule',
        'ansible.plugins.filter',
        C.DEFAULT_FILTER_PLUGIN_PATH,
        'ansible.plugins.filter.core',
    )

    # Try to find a plugin by explicit path
    path = os.path.join(
        'ansible', 'plugins', 'filter', 'filesystem', 'filesize.py'
    )
    assert filter_loader.find_plugin(path) is not None

    # Try to find a base filter plugin
    base_filter = filter_loader.find_plugin('base')
    assert base_filter is not None

    # Try to find a non-existent plugin
    assert filter_loader.find_plugin('invalid') is None

    # Try to find namespace

# Generated at 2022-06-23 11:15:14.526292
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    p = PluginLoader('test_plugins', 'TestPlugins', 'test_module')
    assert p.package == 'test_plugins'
    assert p.subdir is None
    assert p.class_name == 'TestPlugins'
    assert p.base_class is None
    assert p.directories == []

    p = PluginLoader.load_from_file_name(__file__, 'test_plugins', 'TestPlugins', 'test_module')
    assert p.package == 'test_plugins'
    assert p.subdir is None
    assert p.class_name == 'TestPlugins'
    assert p.base_class is None
    assert p.directories == []



# Generated at 2022-06-23 11:15:21.976592
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    import tempfile
    path = tempfile.mkdtemp()
    for name, obj in get_all_plugin_loaders():
        (fd, f) = tempfile.mkstemp(prefix='ansible_%s_' % name, dir=path)
        os.close(fd)
    add_all_plugin_dirs(path)
    os.removedirs(path)



# Generated at 2022-06-23 11:15:26.486341
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    plugin_loader = PluginLoader(
        'test_package',
        'test_package',
        C.DEFAULT_INTERNAL_PLUGIN_PATH
    )
    assert plugin_loader.format_paths(["first_path", "second_path"]) == "['first_path', 'second_path']"


# Generated at 2022-06-23 11:15:34.597838
# Unit test for method __setstate__ of class PluginLoader

# Generated at 2022-06-23 11:15:36.179197
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    test_instance = get_with_context_result(Context(), 'test')
    assert isinstance(test_instance, str)
    assert test_instance == 'test'



# Generated at 2022-06-23 11:15:46.326100
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    context = PluginLoadContext()
    assert context.original_name is None
    assert context.redirect_list == []
    assert context.error_list == []
    assert context.import_error_list == []
    assert context.load_attempts == []
    assert context.pending_redirect is None
    assert context.exit_reason is None
    assert context.plugin_resolved_path is None
    assert context.plugin_resolved_name is None
    assert context.plugin_resolved_collection is None
    assert context.deprecated == False
    assert context.removal_date is None
    assert context.removal_version is None
    assert context.deprecation_warnings == []
    assert context.resolved == False
    assert context.resolved_fqcn is None
    assert context.record_deprecation

# Generated at 2022-06-23 11:15:56.678834
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    p = PluginLoader(
        class_name='Test', 
        package='ansible.plugins.test_plugin', 
        config_base='base', 
        subdir='test_plugin', 
        aliases={}, 
        auto_resolve=False, 
        base_class='ansible.plugins.test_plugin.test_plugin_base.TestPluginBase')
    res = p.__getstate__()
    # If there is any None value, this will raise a KeyError
    assert 'class_name' in res
    assert 'package' in res
    assert 'config_base' in res
    assert 'subdir' in res
    assert 'aliases' in res
    assert 'auto_resolve' in res
    assert 'base_class' in res

# Generated at 2022-06-23 11:15:59.237418
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    sample = PluginLoader('')
    assert sample.__getstate__() == {'aliases': {}, 'package': ''}

# Generated at 2022-06-23 11:16:12.393809
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    class DummyDeprecated(object):
        def __init__(self):
            self.warning_text = ''
            self.removal_date = None
            self.removal_version = None

    plc = PluginLoadContext()

    # test deprecation with removal_version
    deprecated = DummyDeprecated()
    deprecated.warning_text = 'foobar'
    deprecated.removal_version = '1.0'
    plc.record_deprecation('deprecated', deprecated, None)
    assert plc.deprecated
    assert plc.removal_version is None
    assert plc.removal_date is None
    assert plc.deprecation_warnings[0] == 'deprecated has been deprecated. foobar'

    # test deprecation with removal_date
    deprecated = DummyDeprecated()


# Generated at 2022-06-23 11:16:19.750567
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    plc = PluginLoadContext()
    plc.origional_name = 'foo'
    plc.redirect_list = []
    plc.error_list = []
    plc.import_error_list = []
    plc.load_attempts = []
    plc.pending_redirect = None
    plc.exit_reason = None
    plc.plugin_resolved_path = None
    plc.plugin_resolved_name = None
    plc.plugin_resolved_collection = None
    plc.deprecated = False
    plc.removal_date = None
    plc.removal_version = None
    plc.resolved = False

    plc.resolve('id1', 'id2', None, 'id5')

    assert plc.plugin_resolved_

# Generated at 2022-06-23 11:16:30.005621
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    PL = PluginLoader('module_utils', 'ansible.module_utils.module_common')

    PL_find_plugin = PL.find_plugin("six", collection_list='ansible_collections.ansible.builtin')
    if PL_find_plugin.resolved:
        if PL_find_plugin.plugin_resolved_name == "six":
            if PL_find_plugin.plugin_resolved_path == "ansible_collections.ansible.builtin.plugins.module_utils.six.py":
                print("test 1 pass")
            else:
                print("test 1 fail")
        else:
            print("test 1 fail")
    else:
        print("test 1 fail")
        

# Generated at 2022-06-23 11:16:31.129511
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    assert isinstance(get_with_context_result(None, None), WithContextResult)


# Generated at 2022-06-23 11:16:34.058463
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    p = PluginLoadContext()
    p.resolve('1', '2', '3', '4')
    assert p.resolved_fqcn == '3.1'


# Generated at 2022-06-23 11:16:47.152867
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    loader = PluginLoader('test')

    class TestFunc():
        def __init__(self, a, b=1, c=None):
            self.a = a
            self.b = b
            self.c = c

    class TestClass():
        def __init__(self, a, b=1, c=None):
            self.a = a
            self.b = b
            self.c = c

    plugin_loader = PluginLoader('ansible_collections.test.test_loader.test_plugins', 'Test', 'TestClass', 'test_loader')
    # Test without base class
    plugin_loader = PluginLoader('ansible_collections.test.test_loader.test_plugins', 'Test', None, 'test_loader')

    # Empty name

# Generated at 2022-06-23 11:16:55.382709
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    plc = PluginLoadContext()
    plc = plc.resolve('resolved_name', 'resolved_path', 'resolved_collection', 'exit_reason')
    assert plc.plugin_resolved_name == 'resolved_name'
    assert plc.redirect_list == []
    assert plc.error_list == []
    assert plc.import_error_list == []
    assert plc.load_attempts == []
    assert plc.pending_redirect == None
    assert plc.exit_reason == 'exit_reason'
    assert plc.resolved == True
    assert plc.original_name == None


# Generated at 2022-06-23 11:17:00.045661
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    # Not exhaustive (but if this fails, add a corresponding test to test_module_utils.py)
    plugin_loaders = get_all_plugin_loaders()
    assert len(plugin_loaders) >= 3
    assert ('ModuleLoader', ansible.plugins.ModuleLoader) in plugin_loaders
    assert ('ActionModuleLoader', ansible.plugins.ActionModuleLoader) in plugin_loaders
    assert ('ConnectionLoader', ansible.plugins.ConnectionLoader) in plugin_loaders



# Generated at 2022-06-23 11:17:06.256462
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    context = PluginLoadContext()
    context.original_name = 'random_original_name'
    assert context.nope("random_exit_reason") == context
    assert context.pending_redirect is None
    assert context.exit_reason == 'random_exit_reason'
    assert context.resolved == False


# Generated at 2022-06-23 11:17:09.078537
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    paths = ["/tmp/ansible", "/some/other/path", "/and/another/path"]
    which_loader = "action"
    loader = getattr(sys.modules[__name__], '%s_loader' % which_loader)
    for path in paths:
        loader.add_directory(path,with_subdir=True)
        assert path in PATH_CACHE[which_loader]


# Generated at 2022-06-23 11:17:18.140856
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    class UnitTest_(unittest.TestCase):
        def test_with_defaults(self):
            # _PluginLoader__getstate__
            # assert that class have required attributes
            with mock.patch.object(plugin_loader._PluginLoader, '__init__', lambda x, n, p, b, x0: None):
                instance = plugin_loader._PluginLoader()
                instance.__dict__['_PluginLoader__paths'] = mock.MagicMock()  # set default value for instance attribute '_PluginLoader__paths'
                instance.__dict__['class_name'] = 'class_name'  # set default value for instance attribute 'class_name'
                instance.__dict__['package'] = 'package'  # set default value for instance attribute 'package'
                instance.__dict__['_PluginLoader__module_cache']

# Generated at 2022-06-23 11:17:23.646299
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    # Method nope of class PluginLoadContext exists and returns a PluginLoadContext object
    cls = PluginLoadContext()
    cls.nope('exit_reason')
    assert cls.pending_redirect is None
    assert cls.exit_reason == 'exit_reason'
    assert cls.resolved is False



# Generated at 2022-06-23 11:17:35.932965
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # setup
    fake_plugin_load_context = FakePluginLoadContext()
    def fake_find(name, suffix=None):
        return []

    fake_candidate_path = 'ansible/plugins/lookup/pw.py'
    root = 'ansible/plugins/lookup'
    plugin_name = 'pw'
    candidate_fqcr = 'ansible.plugins.lookup.pw'

    def fake_is_valid_fqcr(fqcr, expected_candidate_fqcr):
        return fqcr == expected_candidate_fqcr


# Generated at 2022-06-23 11:17:44.062709
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    '''
    Unit test for method get of class Jinja2Loader
    '''
    import os
    from ansible.plugins.loader import Jinja2Loader

    os.environ['ANSIBLE_LIBRARY'] = '/etc/ansible'
    os.environ['ANSIBLE_FILTER_PLUGINS'] = '/etc/ansible/filter_plugins'
    os.environ['ANSIBLE_TEST_PLUGINS'] = '/etc/ansible/test_plugins'
    jinja2_loader = Jinja2Loader()
    assert jinja2_loader.get('map') == jinja2_loader.get('map')
