

# Generated at 2022-06-23 11:07:44.388503
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    class TestClass(object):
        pass
    test_class = TestClass()
    test_class.get = lambda x: type(test_class)
    test_class.SHELL_FAMILY = 'trivial'
    test_class.COMPATIBLE_SHELLS = ['trivial']
    shell_loader.plugin_manager.set(test_class)
    assert get_shell_plugin(None, 'trivial') is test_class
    shell_loader.plugin_manager.clear()



# Generated at 2022-06-23 11:07:50.072895
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    assert PluginLoader.format_paths(['one', 'two', 'three']) == "['one', 'two', 'three']"
    assert PluginLoader.format_paths(['one', 'two', 'three', 'four']) == "['one', 'two', 'three', ..., 'four']"
    assert PluginLoader.format_paths([]) == "[]"


# Generated at 2022-06-23 11:07:55.211925
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    # Test with existing shell type
    shell = get_shell_plugin(shell_type='sh')
    assert shell.get_name() == 'sh'

    # Test with a non-existing shell type
    test_shell_type = 'not_a_shell'
    shell = get_shell_plugin(shell_type=test_shell_type)
    assert shell.get_name() == test_shell_type

test_get_shell_plugin()



# Generated at 2022-06-23 11:07:57.654842
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    '''
    Unit test for method `__getstate__` of class `PluginLoader`
    '''
    pass

# Generated at 2022-06-23 11:08:03.953670
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    '''
    Unit test for method __contains__ of class PluginLoader

    This test is more of a stub right now, just ensuring code path coverage.
    '''
    plugin_loader = PluginLoader('ansible_collections.foo.bar.plugins', 'FoobarBase', 'foobar_plugin')
    assert plugin_loader.__contains__('invalid_name') == False



# Generated at 2022-06-23 11:08:12.762632
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    loader = PluginLoader("foo", "bar", "tmppath1:tmppath2", "baz", "qux")
    assert loader._package == "foo"
    assert loader._paths == ["tmppath1", "tmppath2"]
    assert loader._cachedir == "baz"
    assert loader._subdir == "qux"
    assert loader._searched_paths == []

    # look for the ansible.cfg file in the test directory, relative to this file
    # to set the ANSIBLE_CONFIG env var correctly.
    test_config_path = os.path.join(os.path.dirname(__file__), "ansible.cfg")
    if os.path.exists(test_config_path):
        os.environ["ANSIBLE_CONFIG"] = test_config_

# Generated at 2022-06-23 11:08:23.797120
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    '''
    Unit test for method get_with_context of class PluginLoader
    Args:
    Returns:
    Raises:
    '''
    class_name = 'C.DEFAULT_MODULE_LANG'  #class_name is a string
    package = 'ansible.module_utils'  #package is a string
    config_defs = {}  #config_defs is a dict
    base_class = 'ModuleUtilBase'  #base_class is a string
    subdir = 'module_utils'  #subdir is a string

    plugin_loader = PluginLoader()
    plugin_loader._find_plugins = lambda c: []
    plugin_loader.config_defs = config_defs
    plugin_loader.base_class = base_class
    plugin_loader.package = package
    plugin_loader

# Generated at 2022-06-23 11:08:25.674282
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    pass

# Generated at 2022-06-23 11:08:26.383522
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    assert False



# Generated at 2022-06-23 11:08:34.884539
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    """Unit test for method get of class PluginLoader"""

    # test for ansible.plugins.action.ActionModule
    action_plugin_loader = PluginLoader("action", "ActionModule", "ansible.plugins.action", "action_plugins", required_base_class="ActionBase")
    assert action_plugin_loader._load_context.paths == C.DEFAULT_ACTION_PLUGIN_PATH
    assert action_plugin_loader.all() == []

    # test for ansible.plugins.cache.CacheModule
    cache_plugin_loader = PluginLoader("cache", "CacheModule", "ansible.plugins.cache", "cache_plugins", required_base_class="CacheModule")
    assert cache_plugin_loader._load_context.paths == C.DEFAULT_CACHE_PLUGIN_PATH
    assert cache_plugin_loader.all

# Generated at 2022-06-23 11:08:48.322799
# Unit test for method __contains__ of class PluginLoader

# Generated at 2022-06-23 11:08:53.478448
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    reload(sys)

    class TestPlugin(object):
        def __init__(self, subdir):
            self.subdir = subdir

        def add_directory(self, path):
            pass

    sys.modules['ansible.plugins.action'] = TestPlugin
    sys.modules['ansible.plugins.action'].__file__ = ''

    def test_add_all_plugin_dirs(mocker):
        test_path = '/foo/bar'
        mocker.patch('os.path.isdir', return_value=True)
        mocker.patch('os.path.join', return_value='/foo/bar/action')

        mocker.patch('ansible.plugins.get_all_plugin_loaders', return_value=[('action', TestPlugin('action'))])

# Generated at 2022-06-23 11:09:04.409562
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    c = PluginLoader(package='ansible.plugins', subdir='filter_plugins')
    assert os.path.exists(os.path.join(c._get_paths()[0], '__init__.py'))
    assert c.package == 'ansible.plugins'
    assert c.subdir == 'filter_plugins'

    PLUGIN_PATH_MARKER = 'arbitrary string'
    class FakeOptions(object):
        '''
        A class which mocks the return value of the Options class.

        We use this because we do not want to rely on the Options class
        being set up during unit testing.
        '''
        def __init__(self):
            self.filter_plugins = PLUGIN_PATH_MARKER

    fake_options = FakeOptions()

    # plugin path for filter should be set

# Generated at 2022-06-23 11:09:12.117412
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():

    # Create stubs
    # These will be the fake plugins for our tests
    class FilterStub(object):
        def __init__(obj, *args, **kwargs):
            obj.foo = args[0]

    class FailStub(object):
        def __init__(obj, *args, **kwargs):
            raise Exception("Fake Exception")

    class TestStub(object):
        def __init__(obj, *args, **kwargs):
            obj.bar = args[0]

    class DerivedStub(object):
        def __init__(obj, *args, **kwargs):
            obj.bar = args[0]

    def fake_find_plugin(self, name, collection_list=None):
        # This method should never be used by this class
        raise Exception

    # Create two files to test

# Generated at 2022-06-23 11:09:21.498071
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    plugin_loader = PluginLoader('test', 'class', 'package', 'base')

# Generated at 2022-06-23 11:09:25.706806
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    # initialize the module
    plugin_loader = PluginLoader('action', 'ActionModule', 'ansible.plugins.action')
    # test method get of class PluginLoader
    assert False, "we don't have an automatic test for get"


# Generated at 2022-06-23 11:09:32.710956
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
	assert PluginLoader('').format_paths(['',
		'/some/path',
		'/other/path',
		'/home/user/path',
		'/home/user/long/path']) == '\'\', \'/other/path\', \'/home/user/path\', \'/home/user/l...\'',\
		'PluginLoader.format_paths() returned unexpected results'


# Generated at 2022-06-23 11:09:38.607160
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plc = PluginLoadContext()
    assert plc.original_name is None
    assert not plc.redirect_list
    assert not plc.error_list
    assert not plc.import_error_list
    assert not plc.load_attempts
    assert plc.pending_redirect is None
    assert plc.exit_reason is None
    assert plc.deprecated is False
    assert plc.removal_date is None
    assert plc.removal_version is None
    assert not plc.deprecation_warnings
    assert not plc.resolved
    assert plc.resolved_fqcn is None



# Generated at 2022-06-23 11:09:45.156339
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.display import Display
    from ansible.module_utils._text import to_text

    class MockOptions(object):
        def __init__(self, plugin_dirs=''):
            self.plugin_dirs = plugin_dirs

    plugin_loader = PluginLoader(package="ansible.plugins.action",
                                 config=Config(1),
                                 configuration=MockOptions(plugin_dirs=[]),
                                 display=Display(),
                                 subdir=None,
                                 class_name="ActionModule",
                                 aliases={},
                                 plugins=None,
                                 _basedirs=None) # pylint: disable=protected-access


# Generated at 2022-06-23 11:09:51.968565
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    plugin_load_context = PluginLoadContext(plugin_name='a.b.c', search_paths=(), config_definitions={})
    pl = PluginLoader('foo', 'ansible.plugins.filter', 'FilterModule', CUSTOM_PLUGIN_PATH, 'filter_plugins', config_definitions={})

    # expected error when plugin_name is not in the right format
    assert pl.find_plugin_with_context('foo.bar', plugin_load_context=plugin_load_context) == plugin_load_context.nope("Plugin name foo.bar does not match the pattern 'ansible.plugins.filter.foo_bar'")

    # expected error when plugin with the given name is not found
    assert pl.find_plugin_with_context('a.b.c', plugin_load_context=plugin_load_context) == plugin

# Generated at 2022-06-23 11:09:59.863607
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Unit test for method find_plugin_with_context of class PluginLoader

    # Initializing a new collection configured with /etc/ansible/collections
    c_collection_1 = AnsibleCollectionConfig('/etc/ansible/collections')

    # Initializing a new collection configured with /etc/ansible/collections2
    c_collection_2 = AnsibleCollectionConfig('/etc/ansible/collections2')

    # Initializing a new PluginLoader with prefix 'TestModule' and base class 'TestModule.Base'
    c_plugin_loader = PluginLoader('TestModule', 'TestModule.Base', '_TestModule', package='TestModule', config=c_collection_1)

    # Verifying that a call to PluginLoader.find_plugin_with_context('Base') will return an object for the plugin
    # 'TestModule.Base'

# Generated at 2022-06-23 11:10:10.142097
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():

    context = PluginLoaderContext(
        plugin_dirs=['tasks'],
        plugin_name='package',
        plugin_type='action',
    )
    with mock.patch.object(PluginLoader, '_find_fq_plugin', autospec=True) as mock_ffp:
        result = PluginLoader('module_utils').find_plugin_with_context(
            'package',
            plugin_load_context=context,
        )
        assert result == mock_ffp.return_value
        mock_ffp.assert_called_once_with(
            'package',
            'action_plugin',
            plugin_load_context=context,
        )


# Generated at 2022-06-23 11:10:21.160642
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plc = PluginLoadContext()
    assert plc.original_name is None
    assert plc.redirect_list == []
    assert plc.error_list == []
    assert plc.import_error_list == []
    assert plc.load_attempts == []
    assert plc.pending_redirect is None
    assert plc.exit_reason is None
    assert plc.plugin_resolved_path is None
    assert plc.plugin_resolved_name is None
    assert plc.plugin_resolved_collection is None
    assert not plc.deprecated
    assert plc.removal_date is None
    assert plc.removal_version is None
    assert plc.deprecation_warnings == []
    assert not plc.resolved
    assert plc.resolved_

# Generated at 2022-06-23 11:10:24.917876
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    # This unit test is just to ensure that the constructor of class Jinja2Loader
    # doesn't fail at import time.
    name = 'something'
    package = 'ansible.plugins.filter'
    dirs = ['some', 'dirs']
    j2_loader = Jinja2Loader(name, package, *dirs)



# Generated at 2022-06-23 11:10:36.897033
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    _test_dir = 'testdir'
    _test_dir_2 = 'testdir2'
    _test_dir_3 = 'testdir3'
    _test_dir_4 = 'testdir4'
    _test_dir_5 = 'testdir5'
    _test_dir_6 = 'testdir6'

    plugin_loader = PluginLoader()
    test_paths = []
    test_paths.append(_test_dir)
    test_paths.append(_test_dir + os.path.sep + _test_dir_2)

    result = plugin_loader.format_paths(test_paths)
    assert result == _test_dir + os.path.sep + _test_dir_2


# Generated at 2022-06-23 11:10:39.698488
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    assert isinstance(add_all_plugin_dirs('stub'),None)


# Generated at 2022-06-23 11:10:41.690553
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    pl = PluginLoader("", "", "", "")
    assert pl.print_paths() is None


# Generated at 2022-06-23 11:10:49.755966
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    plugin_loader = PluginLoader('./test/unit/plugins', 'All', 'test_plugins.spam')
    plugins = plugin_loader.all()
    plugin = next(plugins)
    from ansible.plugins.test.spam.module import B
    assert isinstance(plugin, B)
    plugin = next(plugins)
    from ansible.plugins.test.spam.module import C
    assert isinstance(plugin, C)
    plugin = next(plugins)
    from ansible.plugins.test.spam.plugin import D
    assert isinstance(plugin, D)


# Generated at 2022-06-23 11:10:52.306260
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    obj = PluginLoader('package', 'base_class', 'class_name')
    with pytest.raises(NotImplementedError):
        obj.__getstate__()


# Generated at 2022-06-23 11:10:55.570837
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    c = PluginLoader('action_plugins', 'ActionModule')
    res = c.__repr__()
    assert res == "PluginLoader('action_plugins', 'ActionModule')"


# Generated at 2022-06-23 11:11:04.485423
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    c = PluginLoadContext()
    c = c.resolve('test', '/usr/lib/ansible/plugins', '', 'resolved')
    assert c.pending_redirect is None
    assert c.plugin_resolved_name == 'test'
    assert c.plugin_resolved_path == '/usr/lib/ansible/plugins'
    assert c.plugin_resolved_collection == ''
    assert c.exit_reason == 'resolved'
    assert c.resolved is True

# Generated at 2022-06-23 11:11:05.136871
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    pass



# Generated at 2022-06-23 11:11:07.304450
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    obj = get_with_context_result(1, 2, 3)
    assert obj.value == 1
    assert obj.context == 2
    assert obj.result == 3

# Generated at 2022-06-23 11:11:08.408559
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    pass


# Generated at 2022-06-23 11:11:15.631129
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    loader = PluginLoader("foobar", "foobar_path", "foobar_package", "foobar_class_name")
    loader._searched_paths = ['/etc/ansible/foobar_path', '/usr/lib/ansible/foobar_path']
    assert loader.print_paths() == "['/etc/ansible/foobar_path', '/usr/lib/ansible/foobar_path']"


# Generated at 2022-06-23 11:11:24.954860
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():

    # set up a temporary ansible loader
    tmp_dir = os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible_test_JinjaLoader_all')
    os.makedirs(tmp_dir)
    plugin_loader = Jinja2Loader()
    plugin_loader.add_directory(tmp_dir)

    # File 1

# Generated at 2022-06-23 11:11:35.344683
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    # Testing PluginLoader.format_paths:
    #
    #    Return a string of paths formatted as a comma-separated list.
    #
    display.display("Testing PluginLoader.format_paths() ...")
    loader = PluginLoader('', '', '', '')
    result = loader.format_paths(['/a/b/c', '/a/b/d', '/a/b/e'])
    expected = "/a/b/c, /a/b/d, /a/b/e"
    display.display("  Expected: '%s'" % expected)
    display.display("  Result  : '%s'" % result)
    assert result == expected, 'Formatting of paths failed'



# Generated at 2022-06-23 11:11:47.739039
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    '''
    Creates a pluginloader instance of every type and checks if the
    plugin is loaded correctly
    '''

    # Test if filters are loaded correctly
    p = ModuleFinder(plugins=dict(filter_loader=PluginLoader('FilterModule', 'ansible.plugins.filter_plugins')))
    assert p.find_plugin('ipaddr') is not None

    # Test if modules are loaded correctly
    p = ModuleFinder(plugins=dict(module_loader=PluginLoader('ActionModule', 'ansible.plugins.action')))
    assert p.find_plugin('ping') is not None

    # Test if lookup plugins are loaded correctly
    p = ModuleFinder(plugins=dict(lookup_loader=PluginLoader('LookupModule', 'ansible.plugins.lookup')))
    assert p.find_plugin('first_found') is not None

# Generated at 2022-06-23 11:11:59.594460
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    # Test that passing deprecation as None sets self.deprecated to False
    plc = PluginLoadContext()
    plc.record_deprecation('name', None, 'collection_name')
    assert plc.deprecated == False
    # Test that passing deprecation with a warning_text sets self.deprecated to True
    plc = PluginLoadContext()
    plc = plc.record_deprecation('name', {'warning_text': 'warning'}, 'collection_name')
    assert plc.deprecated == True
    # Test that passing deprecation with a removal_date sets both self.deprecated and self.removal_date to True
    plc = PluginLoadContext()

# Generated at 2022-06-23 11:12:07.545365
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    '''
    plugin_loader = PluginLoader('filter_loader', 'ansible.plugins.filter_loader')
    assert plugin_loader.plugin_packages == ['ansible.plugins.filter_loader', 'ansible.plugins.filter_loader.legacy']
    '''

    # FIXME: we should probably change this to use mock instead of actual file system
    plugin_loader = PluginLoader('filter_loader', 'ansible.plugins.filter_loader')

    filter_paths = []
    for i in plugin_loader._get_paths():
        filter_paths.extend(glob.glob(to_native(os.path.join(i, "*.py"))))

    assert len(filter_paths) > 2

    assert len(plugin_loader._extra_dirs) == 2

# Generated at 2022-06-23 11:12:13.008510
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell_type='sh'
    executable=None
    assert shell_loader.get(shell_type) == get_shell_plugin(shell_type, executable)
    assert shell_loader.get(shell_type) == get_shell_plugin(executable)
    assert shell_loader.get(shell_type).__class__.__name__ == 'ShellModule'



# Generated at 2022-06-23 11:12:22.497467
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    # TestPluginLoader sub class for test
    class TestPluginLoader(PluginLoader):
        # Init for TestPluginLoader sub class
        def __init__(self, package, directories=None, class_name='object'):
            super(TestPluginLoader, self).__init__(package, directories=directories, class_name=class_name)
            self.plugin_dirs = directories

    # TestPluginLoader sub class for test
    class Test_PluginLoader(PluginLoader):
        # Init for Test_PluginLoader sub class
        def __init__(self, package, directories=None, class_name='object'):
            super(Test_PluginLoader, self).__init__(package, directories=directories, class_name=class_name)
            self.plugin_dirs = directories


# Generated at 2022-06-23 11:12:25.297381
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    all_loaders = get_all_plugin_loaders()
    assert len(all_loaders) > 0
    for name, tp in all_loaders:
        assert name.startswith('_')
        assert tp.__module__ == PluginLoader.__module__

# TODO: Rename to ModuleLoader.  This is only used for modules.

# Generated at 2022-06-23 11:12:35.369657
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    """Test PluginLoadContext.record_deprecation()"""
    # Create instance of PluginLoadContext
    plugin_load_context = PluginLoadContext()
    # Assert deprecation info is not stored in PluginLoadContext
    assert len(plugin_load_context.deprecation_warnings) == 0
    assert plugin_load_context.deprecated == False
    assert plugin_load_context.removal_date is None
    assert plugin_load_context.removal_version is None

    # Test deprecation and removal_date
    deprecation = {
        'warning_text': 'Test warning text',
        'removal_date': '2020-10-10',
    }
    # Test deprecation and removal_version

# Generated at 2022-06-23 11:12:38.915499
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    a = PluginLoadContext()
    b = a.nope("exit reason")
    assert b.exit_reason == "exit reason"
    assert b.resolved == False

# Generated at 2022-06-23 11:12:50.771397
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    # Test if name, package and _searched_paths of the class PluginLoader is equal to the expected value
    #
    # When the name, package and _searched_paths of the class PluginLoader is equal to the expected value,
    # the method __repr__ of class PluginLoader returns 'Ansible plugin loader of type <name> with the <package> base class searching in the following paths:
    # <_searched_paths>'
    #
    # Otherwise, raise AssertionError

    mocked_searched_paths = [
        'ansible/plugins/action',
        'ansible/plugins/actions',
        'ansible/plugins/connection']
    mocked_name = 'action'
    mocked_package = 'ansible.plugins.connection'

# Generated at 2022-06-23 11:12:54.793655
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    from ansible.utils.collection_loader import get_all_plugin_loaders
    loader_types = [type_info[1] for type_info in get_all_plugin_loaders()]
    assert PluginLoader in loader_types



# Generated at 2022-06-23 11:12:59.825658
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    plugin_loader = PluginLoader('test_package', 'test_class', 'test_base_class')
    # test that path_only works as intended by checking that the output is a string
    for _ in plugin_loader.all(path_only=True):
        assert isinstance(_, str)
# END UNIT TEST



# Generated at 2022-06-23 11:13:08.663508
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    import tempfile
    import shutil

    def makedirs(path):
        try:
            os.makedirs(path)
        except OSError:
            pass

    # Create a temp dir and then subdirs for a few plugin loaders
    # This is the cache format Ansible expects
    temp_dir = tempfile.mkdtemp()
    for plugin_type in ['connection', 'lookup', 'inventory', 'shell']:
        makedirs(os.path.join(temp_dir, 'plugins', plugin_type))

    # Add the temp dir to the plugin loaders
    add_dirs_to_loader(plugin_type, [temp_dir])

    # Now try to get a non-existent plugin
    try:
        connection_loader.get('fake_plugin')
    except AnsibleError:
        pass

# Generated at 2022-06-23 11:13:15.430679
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    loader = PluginLoader('.py', 'modules', 'module_utils')
    if not hasattr(loader, '__setstate__'):
        raise AssertionError('loader.__setstate__ is not defined')
    if not callable(loader.__setstate__):
        raise AssertionError('loader.__setstate__ is not callable')



# Generated at 2022-06-23 11:13:24.499925
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    PluginLoader = collections.namedtuple('PluginLoader', ['package'])
    loader = PluginLoader('ansible.plugins.cache')

    # get unused colors to fill in the colors field
    colors = {}
    colors['red'] = 'red'
    colors['blue'] = 'blue'
    colors['yellow'] = 'yellow'
    colors['green'] = 'green'
    colors['magenta'] = 'magenta'
    colors['purple'] = 'purple'
    colors['cyan'] = 'cyan'
    # find unused color for the new plugin
    for plugin in loader.all():
        if plugin._load_name in colors:
            del colors[plugin._load_name]
    color = colors[random.choice(list(colors.keys()))]
    # create a fake plugin

# Generated at 2022-06-23 11:13:26.002880
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
   add_all_plugin_dirs('/tmp/')


# Generated at 2022-06-23 11:13:34.443575
# Unit test for method find_plugin of class Jinja2Loader

# Generated at 2022-06-23 11:13:38.739400
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    context = PluginLoadContext()
    assert context.original_name == None
    assert context.redirect_list == []
    assert context.error_list == []
    assert context.import_error_list == []
    assert context.load_attempts == []
    assert context.pending_redirect == None
    assert context.exit_reason == None
    assert context.plugin_resolved_path == None
    assert context.plugin_resolved_name == None
    assert context.plugin_resolved_collection == None
    assert context.deprecated == False
    assert context.deprecation_warnings == []
    assert context.resolved == False



# Generated at 2022-06-23 11:13:48.180603
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    loader = Jinja2Loader()
    basename = os.path.basename(__file__)
    search_paths = [__file__]
    # Add a fake collection to the search path. We'll use the basename of this file as the collection name.
    loader._searched_paths = search_paths

    # fqcr that doesn't contain the collection
    name = 'dictfilter.default'
    # Plugin not found, should return (None, None, None)
    r = loader.find_plugin(name)
    assert r[0] is None
    # Should only search in base
    assert r[1] == search_paths
    # Returned relative path should be concatenation of collection name, package name and plugin name

# Generated at 2022-06-23 11:13:59.370116
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    context = None
    resolved_name = "resolved_name"
    resolved_path = "resolved_path"
    resolved_collection = "resolved_collection"
    exit_reason = "exit_reason"
    context = PluginLoadContext().resolve(resolved_name, resolved_path, resolved_collection, exit_reason)
    assert context.pending_redirect == None
    assert context.plugin_resolved_name == "resolved_name"
    assert context.plugin_resolved_path == "resolved_path"
    assert context.plugin_resolved_collection == "resolved_collection"
    assert context.exit_reason == "exit_reason"
    assert context.resolved == True


# Generated at 2022-06-23 11:14:07.359481
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    __loader = Jinja2Loader('ansible.plugins.filter.core', 'FilterModule', C.DEFAULT_INTERNAL_TEMPLATE_MODULE_PATH)

    # If ANY is not specified we fail to load dynamic filter plugin
    __loader.find_plugin('ANY')

    # If specified we do not fail to load dynamic filter plugin
    __loader.find_plugin('ANY', collection_list=['core'])



# Generated at 2022-06-23 11:14:16.663765
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():

    plugin_loader = PluginLoader(package=None, configure=None, subdir=None, aliases={}, class_name=None, base_class=None)
    # Test with state which has one required field plugin_loader.package
    state = {'package': 'None', 'configure': 'None', 'subdir': 'None', 'aliases': '{}', 'class_name': 'None', 'base_class': 'None'}
    plugin_loader.__setstate__(state)

    assert plugin_loader.package == 'None'

    plugin_loader = PluginLoader(package=None, configure=None, subdir=None, aliases={}, class_name=None, base_class=None)
    # Test with state which has one required field plugin_loader.configure

# Generated at 2022-06-23 11:14:21.940244
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    
    obj = PluginLoader()
    arg = None
    
    # do the test
    obj.__setstate__(arg)
    
    return


# Generated at 2022-06-23 11:14:24.029668
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    assert len(get_all_plugin_loaders()) > 0


# TODO: remove this once we no longer want to support the old-style callbacks?

# Generated at 2022-06-23 11:14:32.424013
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    test_obj = PluginLoadContext()
    deprecation = {'warning_text': 'test warning text', 'removal_date': 'test removal date'}
    ret_val = test_obj.record_deprecation('test name', deprecation, 'test collection name')
    assert ret_val == test_obj
    assert test_obj.deprecated is True
    assert test_obj.removal_date == 'test removal date'
    assert test_obj.removal_version is None
    assert test_obj.deprecation_warnings == ['test name has been deprecated. test warning text']

# Generated at 2022-06-23 11:14:36.530992
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    plugin = PluginLoader('ansible.plugins.lookup', 'LookupModule')
    assert isinstance(plugin, PluginLoader)
    s = pickle.dumps(plugin)
    p = pickle.loads(s)
    assert isinstance(p, PluginLoader)



# Generated at 2022-06-23 11:14:48.386041
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import Jinja2Loader
    from ansible.plugins.loader import PluginLoader


    class FakeArgs(object):
        pass

    class FakeJinja2Loader(Jinja2Loader):

        def __init__(self):
            super(FakeJinja2Loader, self).__init__()
            self.fake_args = FakeArgs()
            self.fake_args.templar_available_variables = None
            self.fake_args.ansible_inventory = None


        def get_filtered_paths(self, *args, **kwargs):
            return ["path_0", "path_1", "path_2"]

        def find_plugin(self, *args, **kwargs):
            return "test_value_1"



# Generated at 2022-06-23 11:15:01.203889
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    plugin_loader = PluginLoader('lookup_plugins', 'lookup_plugins', 'lookup', 'lookup')
    assert '/etc/ansible/lookup_plugins' in plugin_loader._get_paths()
    assert '/etc/ansible/lookup_plugins' in plugin_loader.paths
    
    plugin_loader = PluginLoader('shell_plugins', 'shell_plugins', 'shell', 'shell')
    assert '/etc/ansible/shell_plugins' in plugin_loader._get_paths()
    assert '/etc/ansible/shell_plugins' in plugin_loader.paths
    
    plugin_loader = PluginLoader('strategy_plugins', 'strategy_plugins', 'strategy', 'strategy')
    assert '/etc/ansible/strategy_plugins' in plugin_loader._get_paths()

# Generated at 2022-06-23 11:15:07.477133
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # set ansible to fake mode and set test environments
    ansible_mod = imp.load_source('ansible', os.path.join(os.path.abspath(os.path.dirname(__file__)), '../../lib/ansible'))
    ansible_mod.ModuleManager = imp.load_source('ModuleManager', os.path.join(os.path.abspath(os.path.dirname(__file__)), '../../lib/ansible/module_common.py'))
    ansible_mod.ModuleManager.ansible_module_imported = True
    ansible_mod.utils = imp.load_source('utils', os.path.join(os.path.abspath(os.path.dirname(__file__)), '../../lib/ansible/module_utils/basic.py'))

# Generated at 2022-06-23 11:15:19.550796
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    plugin_loader = PluginLoader(
        'test', 'TestPlugin', os.path.join(os.path.dirname(__file__), 'test_plugins'),
        'Test', 'test_config', 'test_config.yml')
    plugin_loader._searched_paths = ['top/path', 'second/path', 'third/path']
    assert_equal(plugin_loader.format_paths(['third/path', 'second/path', 'top/path']),
                 'third/path:second/path:top/path')
    assert_equal(plugin_loader.format_paths(['top/path']),
                 'top/path')
    assert_equal(plugin_loader.format_paths([]),
                 '')


# Generated at 2022-06-23 11:15:28.712871
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    test_subject = PluginLoader('')

    # Test setup
    test_subject.searched_paths = [
        '/foo/bar/baz',
        '/children/in/the/hall',
        '/plug/in/man',
        '/freed/to/choose',
        '/what/you/win',
        '/life/is/a/gas',
        '/paint/it/black'
    ]

    # Target
    result = test_subject.format_paths(test_subject.searched_paths)

    # Test assertions
    assert result == '/foo/bar/baz, /children/in/the/hall, ... /paint/it/black'


# Generated at 2022-06-23 11:15:37.881070
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    def test_loader():
        def __init__(self):
            self.paths = []

        def add_directory(self, *args, **kwargs):
            self.paths.append(*args)

    loader = test_loader()
    setattr(sys.modules[__name__], 'test_loader', loader)
    add_dirs_to_loader('test', ['a', 'b', 'c'])
    assert loader.paths == ['a', 'b', 'c']
    del sys.modules[__name__].test_loader



# Generated at 2022-06-23 11:15:45.660464
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    _test__PluginLoader___setstate__ = PluginLoader()
    state = {'aliases':{}, '_searched_paths':[], '_name':'collection', 'package':'ansible_collections.namespace.collection.plugins', 'class_name':'action', 'base_class':'ActionBase', '_conf':None, '_collection_list':None, '_module_cache':{}}
    _test__PluginLoader___setstate__.__setstate__(state)
    # This method modifies the state in-place, so it returns None instead of the modified state
    assert _test__PluginLoader___setstate__ == None

# Generated at 2022-06-23 11:15:55.700918
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    '''
    Test PluginLoader()
    '''

    names = (
        'action',
        'lookup',
        'connection',
        'shell',
        'shell_default',
        'python',
        'python_default',
    )
    directories = (
        'action_plugins',
        'lookup_plugins',
        'connection_plugins',
        'shell_plugins',
        'shell_default_plugins',
        'python_plugins',
        'python_default_plugins',
    )

    for name, directory in zip(names, directories):
        p = PluginLoader(name, 'test/test_utils/test_plugins/' + directory)
        assert isinstance(p, PluginLoader)



# Generated at 2022-06-23 11:15:57.863119
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    ctx = PluginLoadContext()
    assert not ctx.resolved
    assert not ctx.deprecated
    assert ctx.deprecation_warnings == []



# Generated at 2022-06-23 11:16:11.054987
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    test_class = PluginLoadContext()
    expected_warning_texts = ['The action plugin test_module has been deprecated. ',
                              'The action plugin test_module has been deprecated. This is a test for deprecation of action plugin test_module.',
                              'The action plugin test_module has been deprecated.',
                              'The action plugin test_module has been deprecated. This is a test for deprecation of action plugin test_module.']
    deprecation_cases = (
        None,
        {},
        {'warning_text': None},
        {'warning_text': ''},
        {'warning_text': 'This is a test for deprecation of action plugin test_module'},
    )

# Generated at 2022-06-23 11:16:19.272386
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    path = '/etc/ansible/'
    b_path = os.path.expanduser(to_bytes(path))
    add_all_plugin_dirs(path)
    for name, obj in get_all_plugin_loaders():
        assert os.path.isdir(obj.package_paths[0])
    assert not any(True for obj in get_all_plugin_loaders()
        if not os.path.isdir(obj.package_paths[0]))
    add_all_plugin_dirs('/etc/ansible/plugins/')
    for name, obj in get_all_plugin_loaders():
        assert os.path.isdir(obj.package_paths[1])

# Generated at 2022-06-23 11:16:24.173863
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method _PluginLoader__setstate__ of class PluginLoader
    '''

    obj = PluginLoader('', '', '', '', '', '')
    attr = Mock(return_value = None)
    obj.__setstate__(attr)

# Generated at 2022-06-23 11:16:29.746078
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    """ Mocking the globals as we cannot test the global variables directly """
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    result = get_all_plugin_loaders.__globals__['get_all_plugin_loaders']()
    assert (('a', 1) in result) is True
    assert (('b', 2) in result) is True
    assert (('c', 3) in result) is True



# Generated at 2022-06-23 11:16:33.719338
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    plugin_load_context = PluginLoadContext()
    plugin_load_context.nope("i can't... i can't find it")
    assert plugin_load_context.exit_reason == "i can't... i can't find it"
    assert plugin_load_context.pending_redirect == None and plugin_load_context.resolved == False
# End test for method nope of class PluginLoadContext



# Generated at 2022-06-23 11:16:43.364886
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    plugin_loader = PluginLoader(package='ansible.plugins.test', base_path=None)
    assert plugin_loader._searched_paths == []
    assert plugin_loader.add_directory(base_path='x') == 4
    assert plugin_loader._searched_paths == ['x/action_plugins', 'x/cache_plugins', 'x/callback_plugins', 'x/connection_plugins', 'x/lookup_plugins', 'x/module_utils', 'x/modules', 'x/filter_plugins', 'x/test_plugins']



# Generated at 2022-06-23 11:16:54.121574
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    ''' Test PluginLoader._find_plugin_with_context() '''

    # Set up a PluginLoader used to load filters
    plugin_loader = PluginLoader('filter_plugins', 'FilterModule', 'ansible.plugins.filter', C.DEFAULT_FILTER_PLUGIN_PATH)
    plugin_load_context = PluginLoadContext()

    # Set up a PluginLoader used to load modules
    module_plugin_loader = PluginLoader('module_plugins', 'ActionModule', 'ansible.plugins.action', C.DEFAULT_ACTION_PLUGIN_PATH, use_task_workdir_override=True)
    module_plugin_load_context = PluginLoadContext()

    # Tests for _find_plugin_with_context()

# Generated at 2022-06-23 11:17:04.216040
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    import ansible.plugins.lookup as lookup
    loader = PluginLoader(class_name='LookupModule', package='ansible.plugins.lookup', config_base_path=C.DEFAULT_LOOKUP_PLUGIN_CONFIG_NAMES, subdir=C.DEFAULT_LOOKUP_PLUGINS_PATH)
    loader.has_plugin('dummy')
    instance = loader.get('dummy')
    print('get a class instance, the modulename is %s' % instance.__module__)
    print('subclass of LookupModule: %s' % issubclass(instance.__class__, lookup.LookupBase))


# Generated at 2022-06-23 11:17:07.522671
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    PL = PluginLoader(package='ansible.plugins.testpackage', class_name='FakePlugin')
    assert PL.__repr__() == 'ansible.plugins.testpackage.FakePlugin'
    PL2 = PluginLoader(package='ansible.plugins.testpackage', class_name='FakePlugin', subdir='_role')
    assert PL2.__repr__() == 'ansible.plugins.testpackage._role.FakePlugin'



# Generated at 2022-06-23 11:17:10.288054
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # Setup test environment
    # check_plain_passwords is imported from ansible.plugins.action.ActionBase
    test_loader = Jinja2Loader()
    # Expected result is a plugin object
    expected_result = action_loader.get('check_plain_passwords')
    # Run test
    test_result = test_loader.get('check_plain_passwords')
    # Verify test results
    assert isinstance(test_result, type(expected_result))



# Generated at 2022-06-23 11:17:16.445752
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    # Test when result is a list
    result = ['foo']
    obj = get_with_context_result(result)
    assert obj.result == result
    assert obj.is_list

    # Test when result is a string
    result = 'bar'
    obj = get_with_context_result(result)
    assert obj.result == result
    assert not obj.is_list


# Unit tests for get_with_context

# Generated at 2022-06-23 11:17:24.754083
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    c1 = PluginPathContext('/this/is/a/path', False)
    c2 = PluginPathContext('/this/is/a/different/path', True)

    assert c1.path == '/this/is/a/path'
    assert c1.internal == False
    assert c1.__class__.__name__ == 'PluginPathContext'

    assert c2.path == '/this/is/a/different/path'
    assert c2.internal == True
    assert c2.__class__.__name__ == 'PluginPathContext'



# Generated at 2022-06-23 11:17:26.116919
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    PluginLoader(package="ansible")


# Generated at 2022-06-23 11:17:29.004755
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    res = get_with_context_result('test')
    assert('test' == res['value'])
    assert(None == res['context'])


# Generated at 2022-06-23 11:17:38.156647
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    '''
    Test the get method of class Jinja2Loader
    '''
    # Test when name is not a fully qualified collection ref
    name = 'test_name'
    jinja2_loader = Jinja2Loader()
    raised = False
    try:
        jinja2_loader.get(name)
    except Exception as e:
        raised = True
    assert raised

    # Test when name is a fully qualified collection ref
    name = AnsibleCollectionRef.fully_qualified_collection_ref(my_collection)
    jinja2_loader = Jinja2Loader()
    result = jinja2_loader.get(name)
    assert not result
