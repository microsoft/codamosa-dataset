

# Generated at 2022-06-23 11:07:48.020155
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test to make sure values returned from PluginLoader.find_plugin_with_context have correct class
    # and types
    def assert_correct_class_and_type(value, class_name, type_name):
        assert isinstance(value, class_name) or value is None
        assert isinstance(value, type_name) or value is None

    # Test to make sure the results returned from PluginLoader.find_plugin_with_context are correct
    def assert_plugin_load_context_results(context, cls, obj, plugin_resolved_name, plugin_resolved_path, resolved, redirect_list):
        assert context.object == obj
        assert_correct_class_and_type(context.cls, cls, type(obj))

# Generated at 2022-06-23 11:07:58.341594
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():

    from ansible.plugins.loader import jinja2_plugins

    # Load test cases for this method.
    # Note that we use a different test file for collection plugins because
    # that class does not prefetch 'ansible.legacy' plugin files.
    test_cases = yaml.safe_load(dedent('''\
    - {description: 'No plugins'}
    - {description: '2 plugins in 1 file'}
      path: mock_jinja2_plugins/filter_plugins_jinja2/test_loader.yaml
    - {description: '2 collection plugins in 1 file'}
      path: mock_jinja2_collection_plugins/filter_plugins_jinja2/test_loader.yaml
    '''))


# Generated at 2022-06-23 11:08:09.010381
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    pl = PluginLoader(BaseLoader, 'ansible.module_utils', C.DEFAULT_MODULE_UTILS_PATH)
    instance = pl.get('template')

    assert isinstance(instance, ModuleUtilityTemplate), "obj should be of type " + "ModuleUtilityTemplate"
    assert isinstance(instance, BaseLoader), "obj should be of type " + "BaseLoader"
    assert instance._load_name == 'template', instance._load_name + " should be of value " + "template"
    assert instance._original_path == to_bytes(os.path.join(C.DEFAULT_MODULE_UTILS_PATH, 'template.py')), instance._original_path + " should be of value " + to_bytes(os.path.join(C.DEFAULT_MODULE_UTILS_PATH, 'template.py'))



# Generated at 2022-06-23 11:08:14.899373
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    from ansible.utils.path import unfrackpath
    from ansible.utils.display import Display
    display = Display()

    # Create a new object to work with
    obj = PluginLoader('', '', '', '', '')

    # Set the internal property of the object
    obj.package = 'ansible.plugins.action'
    obj.name = 'template'
    obj.aliases = {
        'create': 'template',
        'save': 'template',
    }
    obj.class_name = 'ActionModule'
    obj.base_class = 'ActionBase'
    obj.minimizer = False
    obj.paths = '/path/to/ansible/action/plugins'
    obj.enable_devel_install = False

    # Get ready to call the __getstate__ method on the object

# Generated at 2022-06-23 11:08:15.733059
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    from ansible.utils.path import unfrackpath


# Generated at 2022-06-23 11:08:25.110279
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plc = PluginLoadContext()
    assert plc.original_name == None
    assert plc.redirect_list == []
    assert plc.error_list == []
    assert plc.load_attempts == []
    assert plc.pending_redirect == None
    assert plc.exit_reason == None
    assert plc.plugin_resolved_path == None
    assert plc.plugin_resolved_name == None
    assert plc.plugin_resolved_collection == None
    assert plc.deprecated == False
    assert plc.removal_date == None
    assert plc.removal_version == None
    assert plc.deprecation_warnings == []
    assert plc.resolved == False
    assert plc._resolved_fqcn == None


# Generated at 2022-06-23 11:08:30.455627
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    _plugin_loader = PluginLoader('action_plugin', package='ansible.plugins.action', subdir=None)
    plugin_load_context = _plugin_loader.find_plugin_with_context('copy')
    assert plugin_load_context.resolved is True
    assert plugin_load_context.plugin_resolved_path == '{0}/plugins/action/copy.py'.format(os.getcwd())



# Generated at 2022-06-23 11:08:38.876330
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    class PluginLoadContextClass:
        def resolve(self, resolved_name, resolved_path, resolved_collection, exit_reason):
            self.resolve_called = True
            self.resolved_name = resolved_name
            self.resolved_path = resolved_path
            self.resolved_collection = resolved_collection
            self.exit_reason = exit_reason
            return self
        def nope(self, exit_reason):
            self.nope_called = True
            self.exit_reason = exit_reason
            return self
        def __init__(self):
            self.exit_reason = None
    c = PluginLoadContextClass()
    print(c.exit_reason)
    c.redirect('redirect_name')
    print(c.exit_reason)


# Generated at 2022-06-23 11:08:50.683324
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    from ansible.mock import patch

    class TestCase(unittest.TestCase):
        def test_record_deprecation(self):
            deprecation = {'warning_text': 'Use new one', 'removal_date': '2018-07-01'}
            context = PluginLoadContext()
            self.assertFalse(context.deprecated)
            self.assertIsNone(context.removal_date)

            with patch('ansible.plugins.loader.display.deprecated', autospec=True) as mock_display_deprecated:
                context.record_deprecation('old', deprecation, 'x.y.z')

# Generated at 2022-06-23 11:08:57.918117
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Create a test plugin loader to iterate through all of its plugins
    plugin_loader = PluginLoader('ansible.plugins.test_plugins', 'TestPlugins', C.DEFAULT_CACHE_PLUGIN_TIMEOUT, 'test_plugins')
    # Create a list of all of the plugin_loader's plugins
    all_items = list(plugin_loader.all())
    # Confirm that there are a specific number of plugins
    assert len(all_items) == 2
    # Confirm the first plugin is correct
    assert all_items[0].__class__.__name__ == 'TestPlugins1'
    # Confirm the second plugin is correct
    assert all_items[1].__class__.__name__ == 'TestPlugins2'

# Generated at 2022-06-23 11:09:08.010089
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    plugin_loader = PluginLoader('test', 'test', 'test.test', 'test')
    _cache_module = {}
    _CUSTOM_DEDUPE = True

    display = Display()
    display.debug = _debug
    display.warning = _debug
    try:
        _import_module = __import__
    except ImportError as e:
        display.warning("Skipping plugin (path) as it seems to be invalid: {0}".format(str(e)))
        _import_module = None
    def _load_module_source(name, path):
        print(path)
        if path not in _cache_module:
            _cache_module[path] = _import_module(path)
        return _cache_module[path]

    plugin_loader._module_cache = _cache_module
    plugin

# Generated at 2022-06-23 11:09:19.533144
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Tests are only required to account for code paths other than the one taken
    # when the assertions fail.

    # Fails due to unmatched plugin
    pl = PluginLoader(package='ansible.plugins.action', class_name='ActionBase', base_class='ActionBase')
    with pytest.raises(AnsiblePluginNotFound):
        pl.find_plugin('doesnt_exist')

    # Fails due to failed property_key
    pl = PluginLoader(package='ansible.plugins.action', class_name='ActionBase', base_class='ActionBase', property_key='actions')
    with pytest.raises(AnsiblePluginNotFound):
        pl.find_plugin('doesnt_exist', plugin_load_context=AnsiblePluginLoadContext())

    # Fails due to no aliases

# Generated at 2022-06-23 11:09:31.704496
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    ''' test plugin loader class construction'''

    class PluginLoaderTest(PluginLoader):
        def __init__(self, package, directories):
            super(PluginLoaderTest, self).__init__(package, directories, 'thisisnotmyrealclassname')
            self.class_name = 'this_isnt_real_either'

    pl = PluginLoaderTest('foo.bar', ['/dev/null', '/tmp'])
    assert pl is not None
    assert pl.class_name == 'this_isnt_real_either'
    assert pl.base_class is None
    assert len(pl._searched_paths) == 2
    assert pl._searched_paths[0] == '/dev/null'
    assert pl._searched_paths[1] == '/tmp'


# Test the find_plugin()

# Generated at 2022-06-23 11:09:38.174821
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    # Initialization of plugin manager to run unit test
    plugin_manager = PluginLoader("", "", "", "", "")
    # Initialization of object plugin to run unit test
    plugin = PluginLoader("", "", "", "", "")
    # Initialization of dict object to run unit test
    dict_object = dict()
    # Call unit test
    plugin_manager.__setstate__(plugin, dict_object)


########################################
# TEST CODE FOR unit test
########################################

# Generated at 2022-06-23 11:09:47.503563
# Unit test for method all of class Jinja2Loader

# Generated at 2022-06-23 11:09:53.213918
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    with pytest.raises(AnsibleError) as ctx:
        Jinja2Loader('filter_plugins').all()
    assert 'No code should call "get"' in str(ctx.value)
    with pytest.raises(AnsibleError) as ctx:
        Jinja2Loader('filter_plugins').all().next()
    assert 'No code should call "get"' in str(ctx.value)
    assert Jinja2Loader('filter_plugins').all('/tmp/doesnot', 'exist', 'hopefully/').next() is None


# Pure test of class PluginLoader with a couple of plugins

# Generated at 2022-06-23 11:09:57.813123
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # Fixture setup
    fixture = PluginLoader(package=None, subdir=None)
    # Teardown setup
    try:
        actual = fixture.__contains__('name')

        expected = None
        assert expected == actual
    finally:
        # Teardown
        pass


# Generated at 2022-06-23 11:10:03.171141
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    data = load_fixture('PluginLoader_get.json')
    obj = PluginLoader(data['class_name'], data['package'], data['config'], data['subdir'], data['directories'], data['aliases'])
    assert obj.get('name', collection_list=data['collection_list']) == 'result'


# Generated at 2022-06-23 11:10:13.914413
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # This function is covered by parts of integration tests.
    # This is a trivial test to at least show it was called.
    add_dirs_to_loader('action', ['dummy/data/action_plugins'])
    add_dirs_to_loader('cache', ['dummy/data/cache_plugins'])
    add_dirs_to_loader('callback', ['dummy/data/callback_plugins'])
    add_dirs_to_loader('connection', ['dummy/data/connection_plugins'])
    add_dirs_to_loader('inventory', ['dummy/data/inventory_plugins'])
    add_dirs_to_loader('lookup', ['dummy/data/lookup_plugins'])
    add_dirs_to_loader('shell', ['dummy/data/shell_plugins'])


# Generated at 2022-06-23 11:10:16.685152
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    # TODO: should probably assert on getstate's type here, rather than just returning
    return getattr(PluginLoader, '__getstate__') is None


# Generated at 2022-06-23 11:10:25.725416
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    plugin_loaders = get_all_plugin_loaders()
    assert len(plugin_loaders) == 5
    assert plugin_loaders[0][0] == 'action_loader'
    assert plugin_loaders[0][1].__class__.__name__ == 'ActionLoader'
    assert plugin_loaders[1][0] == 'become_loader'
    assert plugin_loaders[1][1].__class__.__name__ == 'BecomeLoader'
    assert plugin_loaders[2][0] == 'cache_loader'
    assert plugin_loaders[2][1].__class__.__name__ == 'CacheLoader'
    assert plugin_loaders[3][0] == 'callback_loader'
    assert plugin_loaders[3][1].__class__.__name__ == 'CallbackLoader'
   

# Generated at 2022-06-23 11:10:27.583028
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # Check that the function executes for some arbitrary plugin type 'foo'
    add_dirs_to_loader("foo", ["/tmp"])



# Generated at 2022-06-23 11:10:32.593759
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    sut = PluginLoader('test', package='test', config={}, directories=[])
    plugin_load_context = PluginLoaderContext()
    plugin_load_context.resolved = True
    plugin_load_context.plugin_resolved_path = '/test/test'
    plugin_load_context.plugin_resolved_name = 'test'
    sut._module_cache['/test/test'] = None
    class Test:
        def __init__(self):
            pass
    Test.__name__ = 'test'
    Test.__module__ = 'test'
    sut._module_cache['/test/test'] = Test
    result = sut.get_with_context('test_result', _plugin_load_context=plugin_load_context)
    if result.object is not None:
        raise AssertionError

# Generated at 2022-06-23 11:10:35.679987
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert 'test_add_dirs_to_loader'

# import all plugins to ensure common code is run.
for plugin in all():
    pass



# Generated at 2022-06-23 11:10:41.638680
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    if isinstance(plugin_load_context.pending_redirect, basestring):
        assert (plugin_load_context.pending_redirect == redirect_name) , "Failed to redirect"
    else:
        assert (plugin_load_context.pending_redirect is None) , "Failed to redirect"


# Generated at 2022-06-23 11:10:51.573784
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    obj = PluginLoadContext()
    orig_exit_reason = 'original'
    new_exit_reason = 'new'
    assert obj.original_name is None
    assert obj.redirect_list == []
    assert obj.error_list == []
    assert obj.import_error_list == []
    assert obj.load_attempts == []
    assert obj.pending_redirect is None
    assert obj.exit_reason is None
    assert obj.plugin_resolved_path is None
    assert obj.plugin_resolved_name is None
    assert obj.plugin_resolved_collection is None
    assert not obj.deprecated
    assert obj.removal_date is None
    assert obj.removal_version is None
    assert obj.deprecation_warnings == []
    assert not obj.resolved

# Generated at 2022-06-23 11:11:04.173531
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    expected_results = {
        ('/some/path', '/another/path'): '"/some/path", "/another/path"',
        ('/some/path',): '"/some/path"',
        ('/some/path/with_a_long_name', '/another/path'): '"/some/path/with_a_long_name",\n"/another/path"',
        ('/some/path/with_a_long_name', '/another/path/also_with_a_long_name'): '"/some/path/with_a_long_name",\n"/another/path/also_with_a_long_name"',
    }

    for (paths, expected) in expected_results.items():
        actual = PluginLoader.format_paths(paths)

# Generated at 2022-06-23 11:11:08.705274
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # Setup
    o = PluginLoader()
    name = None
    collection_list = None

    # Test and verify
    assert o.has_plugin(name, collection_list)
    assert name in o
    assert not has_plugin(name, collection_list)
    assert name not in o


# Generated at 2022-06-23 11:11:15.468528
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    # PluginPathContext constructor should accept a string for the path and
    # a boolean for internal
    a = PluginPathContext('/path/to/plugins', True)
    b = PluginPathContext('/path/to/plugins', False)
    assert a.path == '/path/to/plugins'
    assert b.path == '/path/to/plugins'
    assert a.internal == True
    assert b.internal == False



# Generated at 2022-06-23 11:11:18.520683
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
  pl = PluginLoader('foo', 'bar', 'baz')
  assert set(pl.all()) == set()



# Generated at 2022-06-23 11:11:20.275302
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    assert False # TODO: implement your test here


# Generated at 2022-06-23 11:11:26.128511
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    from ansible.plugins.loader import Jinja2Loader, PluginLoader, C
    from ansible.module_utils.six import itervalues
    import ansible.plugins.test
    # Get all test plugins
    plugins = PluginLoader('FilterModule', 'ansible.plugins.test')
    jinja2_plugins = Jinja2Loader('FilterModule', 'ansible.plugins.test')

    # See which plugins have the same name across old and new calling code
    duplicated_plugins = set(plugins.all().keys()) & set(jinja2_plugins.all().keys())

# Generated at 2022-06-23 11:11:30.720644
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # We don't call get on this plugin loader.
    # This is because a plugin file can contain multiple plugins inside it
    # and the calling code wants a list of all plugins.
    # This method is not available because it would be confusing as to
    # which plugin from the file to return.
    pass

# Generated at 2022-06-23 11:11:38.838504
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    class Test(unittest.TestCase):
        def test_all(self):
            # Initialize a plugin loader
            plugin_loader = PluginLoader('lib/ansible/plugins/test', 'TestPlugin')
            # Modify the paths to test

# Generated at 2022-06-23 11:11:40.788263
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    assert 1 == 1  # TODO: implement your test here


# Generated at 2022-06-23 11:11:49.291361
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    """
    Tests for Jinja2Loader.all()
    """
    import ansible.plugins.cache
    from ansible.plugins.loader import Jinja2Loader

    jinja2_list = list(Jinja2Loader('ansible.plugins.cache', 'CacheModule').all())
    assert len(jinja2_list) > 0
    assert isinstance(jinja2_list[0], ansible.plugins.cache.CacheModule)

    jinja2_list = list(Jinja2Loader('ansible.plugins.cache', 'CacheModule', 'ansible.legacy').all())
    assert len(jinja2_list) == 0



# Generated at 2022-06-23 11:11:54.567507
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    o = PluginLoader('', '', '', '', '', '')
    assert o.has_plugin('setup')
    assert o.has_plugin('setuptool')
    assert o.has_plugin('setup_foo')
    assert o.has_plugin('ping')
    assert not o.has_plugin('non_existing_plugin')

# Generated at 2022-06-23 11:11:59.703277
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    pl = PluginLoader('bla', 'blub', 'blu')
    bla = '{0}'.format(pl)
    assert to_bytes(bla) == b'<ansible.plugins.blub.blu.PluginLoader object at 0x7f3f3e0e1da0>'

    with pytest.raises(AnsibleParserError):
        pl = PluginLoader('bla', 'blub', '')




# Generated at 2022-06-23 11:12:04.859905
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    pl = PluginLoader('.py', 'my_path', 'myplugins')
    assert len(pl.get_directories()) == 0
    add_all_plugin_dirs('/tmp')
    assert len(pl.get_directories()) == 0
    os.mkdir('/tmp/myplugins')
    add_all_plugin_dirs('/tmp')
    assert len(pl.get_directories()) == 1



# Generated at 2022-06-23 11:12:16.830598
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    # Create an instance of PluginLoader
    p = PluginLoader('ansible.plugins.lookup')
    # Create a list of paths
    paths = ['/home/ansible/collection_root/mycollection/myplugins/lookup_plugins',
             '/home/ansible/.ansible/plugins/lookup_plugins',
             '/home/ansible/ansible/lib/ansible/plugins/lookup_plugins']
    # Create the expected results
    expected_result = ',,\n* /home/ansible/collection_root/mycollection/myplugins/lookup_plugins\n* /home/ansible/.ansible/plugins/lookup_plugins\n* /home/ansible/ansible/lib/ansible/plugins/lookup_plugins\n,'
    # Call the format_paths method
    result = p.format_path

# Generated at 2022-06-23 11:12:24.277487
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    test_loader = PluginLoader(
                    'test_package',
                    'TestClass',
                    C.DEFAULT_MODULE_PATH,
                    'not_a_base_class')
    test_loader._searched_paths.append('/path/to/plugins')

    with patch.dict(C.__dict__, {'DEFAULT_DEBUG': True}):
        # plugin class not found, debug message is displayed
        result = test_loader.get('plugin_1')
        assert not result

        # plugin class found, debug message is displayed
        test_loader._module_cache['/path/to/plugins/plugin_1.py'] = MagicMock(TestClass='fake_class')
        result = test_loader.get('plugin_1')
        assert result == 'fake_class'

        # plugin is not a subclass of

# Generated at 2022-06-23 11:12:32.795853
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # mock out the data
    mock_globals = {
        "test_str_one": "str",
        "test_str_two": "str",
        "test_dict_one": "dict",
        "test_dict_two": "dict",
        "test_obj_one": PluginLoader(),
        "test_obj_two": PluginLoader(),
    }
    # Populate some data
    mock_globals["test_dict_one"].subdir = "dict_one"
    mock_globals["test_dict_two"].subdir = "dict_two"
    mock_globals["test_obj_one"].subdir = "obj_one"
    mock_globals["test_obj_two"].subdir = "obj_two"
    # Add directory to obj_one


# Generated at 2022-06-23 11:12:33.497781
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():

    pass

# Generated at 2022-06-23 11:12:38.485886
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    # PluginLoadContext.resolve(self, resolved_name, resolved_path, resolved_collection, exit_reason):
    plugin_load_context = PluginLoadContext()
    plugin_load_context.record_deprecation('test', {'warning_text': 'This is a deprecation warning'}, None)
    assert (plugin_load_context.deprecation_warnings[0] == 'test has been deprecated.  This is a deprecation warning')
    assert (plugin_load_context.deprecated == True)



# Generated at 2022-06-23 11:12:47.932694
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import call, patch
    from ansible.module_utils.common.warnings import PluginWarning

    exit_reason = "Reason for failure"
    ctx = PluginLoadContext()
    result = ctx.nope(exit_reason)
    assert exit_reason == result.exit_reason
    assert False == result.resolved
    assert None == result.pending_redirect
    assert None == result.plugin_resolved_name
    assert None == result.plugin_resolved_path
    assert None == result.plugin_resolved_collection


# Generated at 2022-06-23 11:12:59.922809
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    '''
    Unit test for method find_plugin of class PluginLoader
    '''

    # Set up mock context for lookup and plugin loading
    plugin_load_context = PluginLoadContext()
    plugin_load_context.class_name = ''
    plugin_load_context.package = ''
    plugin_load_context.package_path = ''
    plugin_load_context.var_name = ''
    plugin_load_context.collection_list = []

    # Set up mock collection to support the lookup and plugin loade
    collection_mock = Mock(autospec=AnsibleCollectionRef, spec_set=True)
    collection_mock._collection_info = Mock(autospec=CollectionRequirement, spec_set=True)
    collection_mock._collection_info.name = 'my_collection'
    collection_mock._

# Generated at 2022-06-23 11:13:03.231145
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    """
    Test class PluginPathContext constructor
    """
    plugin_path_context = PluginPathContext('abc', True)
    assert plugin_path_context.path == 'abc'
    assert plugin_path_context.internal



# Generated at 2022-06-23 11:13:07.148820
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():

    # Test 1: Test creation of new object when everything is passed
    test_object = get_with_context_result(context=1.1, result=2.2)
    assert test_object.context == 1.1
    assert test_object.result == 2.2

    # Test 2: Test creation of new object with default parameters
    test_object = get_with_context_result()
    assert test_object.context is None
    assert test_object.result is None



# Generated at 2022-06-23 11:13:20.275597
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    from ansible.utils.display import Display
    from ansible.plugins.loader import find_plugin
    from ansible.plugins.loader import PluginLoader
    display = Display()
    try:
        display.verbosity = 4
    except AttributeError:
        pass
    # Ansible will search for plugins in the defined order.
    # Names takes precedence over paths

# Generated at 2022-06-23 11:13:30.488505
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    # Init a plugin loader for filter plugins
    test = PluginLoader('FilterModule', 'FilterModule', 'ansible.plugins.filter_plugins')
    assert test.class_name == 'FilterModule'
    assert test.package == 'ansible.plugins.filter_plugins'
    assert test.subdir == 'filter_plugins'
    assert test.base_class == 'FilterModule'
    assert test.paths == _PLUGIN_PATH_CACHE['FilterModule']

    # Init a plugin loader for test plugins
    test = PluginLoader('TestModule', 'TestModule', 'ansible.plugins.test_plugins')
    assert test.class_name == 'TestModule'
    assert test.package == 'ansible.plugins.test_plugins'
    assert test.subdir == 'test_plugins'

# Generated at 2022-06-23 11:13:34.168605
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    BaseConnection = getattr(__import__('ansible.plugins.connection', fromlist=['BaseConnection']), 'BaseConnection')
    plugins = PluginLoader('ansible.plugins.connection', 'ConnectionBase', base_class=BaseConnection, required_base_class=True)
    connection = plugins.get_with_context('local').object
    assert hasattr(connection, 'connection')



# Generated at 2022-06-23 11:13:44.833859
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # 
    # Example test case
    # 
    display.display(u'test_PluginLoader_find_plugin_with_context()')
    params = {u'class_name': u'', u'package': u'', u'paths': [], u'subdir': u'', u'aliases': {}, u'_searched_paths': [], u'_module_cache': {}}

# Generated at 2022-06-23 11:13:57.253649
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Tests with AnsiblePlugin, AnsibleAction, ... as plugin type
    for plugin_type in ('ActionModule', 'CacheModule', 'CallbackModule', 'Connection', 'FilterModule', 'InventoryModule', 'LookupModule', 'PlaybookReader', 'ShellModule', 'TestModule'):
        plugin_loader = PluginLoader(plugin_type=plugin_type, package='ansible.plugins.%s' % plugin_type.lower())
        plugin_load_context = plugin_loader.find_plugin_with_context('dummy')
        assert plugin_load_context.plugin_resolved_name == 'dummy'
        assert plugin_load_context.plugin_resolved_path == '/ansible/lib/ansible/plugins/%s/dummy.py' % plugin_type.lower()

    # Tests with AnsibleModule as plugin type
    plugin

# Generated at 2022-06-23 11:14:05.282929
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # mocking the globals() and get_all_plugin_loaders()
    plugin_loaders = []
    def get_all_plugin_loaders():
        return plugin_loaders
    test_globals = {
        'get_all_plugin_loaders': get_all_plugin_loaders
    }
    test_plugin_loader = PluginLoader.load_plugin_terms(test_globals)
    plugin_loaders.append(('test_plugin_loader', test_plugin_loader))
    # mocking the module and the add_directory method
    b_test_dir = b'/test_dir/plugins/test_plugin_loader'
    module = MagicMock()
    module.add_directory = MagicMock()
    module.PluginLoader.add_directory = MagicMock()

# Generated at 2022-06-23 11:14:15.829713
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    '''
    Unit test for method `__getstate__` of class `PluginLoader`
    '''
    # Setup test environment
    curdir = os.path.dirname(os.path.realpath(__file__))
    testdir = os.path.dirname(os.path.dirname(curdir))
    parentdir = os.path.dirname(testdir)
    plugindir = os.path.join(testdir, 'test_plugins')
    for dir in [plugindir]:
        os.makedirs(dir, mode=0o755)
    data_loader_test_plugin_name = 'data_loader_test_plugin'
    test_plugin_name = 'test_plugin'

# Generated at 2022-06-23 11:14:20.048808
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    # pylint: disable=protected-access
    context = PluginPathContext(path='/tmp', internal=False)
    assert context._path == '/tmp'
    assert context._internal is False



# Generated at 2022-06-23 11:14:29.768007
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    loader = AnsibleLoader(None, 'fake_loader')
    plugin_load_context = PluginLoadContext()
    #assert not plugin_load_context.resolved
    plugin_load_context.resolve('fake_resolved_name', 'fake_resolved_path', 'fake_resolved_collection', 'fake_exit_reason')
    #assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'fake_resolved_name'
    assert plugin_load_context.plugin_resolved_path == 'fake_resolved_path'
    assert plugin_load_context.plugin_resolved_collection == 'fake_resolved_collection'
    assert plugin_load_context.exit_reason == 'fake_exit_reason'


# Generated at 2022-06-23 11:14:40.062098
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    reload(ansible_collections.ansible)
    reload(ansible_collections.ansible.plugins)
    found_set = set([name for (name, obj) in get_all_plugin_loaders()])
    expected_set = set()
    for plugin_dir in ('action', 'callback', 'cliconf', 'connection', 'doc_fragments', 'filter',
                       'inventory', 'lookup', 'netconf', 'shell', 'strategy', 'terminal',
                       'test', 'vars'):
        expected_set.add(plugin_dir.upper())
    assert expected_set == found_set, \
        'get_all_plugin_loaders(): found %s, expected %s' % (found_set, expected_set)
test_get_all_plugin_loaders()



# Generated at 2022-06-23 11:14:42.441252
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    pl = PluginLoader('foo')
    assert repr(pl) == "PluginLoader('foo')"

# Generated at 2022-06-23 11:14:51.197579
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    name = 'test.name'
    deprecation = {'warning_text': 'use another name', 'removal_date': '2025-12-31', 'removal_version': '6.0'}
    collection_name = 'test.collection'

    plugin_load_context = PluginLoadContext()
    plugin_load_context = plugin_load_context.record_deprecation(name, deprecation, collection_name)

    expected_deprecated = True
    expected_removal_date = '2025-12-31'
    expected_removal_version = '6.0'

    assert plugin_load_context.deprecated == expected_deprecated
    assert plugin_load_context.removal_date == expected_removal_date
    assert plugin_load_context.removal_version == expected_removal_version

# Generated at 2022-06-23 11:15:03.593656
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plugin_load_context = PluginLoadContext()
    assert plugin_load_context.original_name is None
    assert plugin_load_context.redirect_list == []
    assert plugin_load_context.error_list == []
    assert plugin_load_context.import_error_list == []
    assert plugin_load_context.load_attempts == []
    assert plugin_load_context.pending_redirect is None
    assert plugin_load_context.exit_reason is None
    assert plugin_load_context.plugin_resolved_path is None
    assert plugin_load_context.plugin_resolved_name is None
    assert plugin_load_context.plugin_resolved_collection is None
    assert plugin_load_context.deprecated is False
    assert plugin_load_context.removal_date is None
    assert plugin

# Generated at 2022-06-23 11:15:07.448572
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():

    add_dirs_to_loader('lookup', ['/dev/null/foo'])
    add_dirs_to_loader('callback', ['/dev/null/foo'])
    add_dirs_to_loader('filter', ['/dev/null/foo'])
    try:
        add_dirs_to_loader('noplug', ['/dev/null/foo'])
        assert False, 'Expected ValueError'
    except ValueError:
        pass


# Generated at 2022-06-23 11:15:12.978622
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    plc = PluginLoadContext()
    plc.resolve('test', 'test', 'test', 'test')
    plc.redirect('redirect')
    assert plc.pending_redirect == 'redirect'
    assert plc.exit_reason == 'pending redirect resolution from test to redirect'
    assert not plc.resolved



# Generated at 2022-06-23 11:15:25.252645
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # add_all_plugin_dirs with normal plugin folder
    plugin_test_dir =[]
    plugin_test_dir.append('/tmp/test_plugin/')
    plugin_test_dir.append('/tmp/test_plugin/action_plugins')
    plugin_test_dir.append('/tmp/test_plugin/cache_plugins')
    plugin_test_dir.append('/tmp/test_plugin/connection_plugins')
    plugin_test_dir.append('/tmp/test_plugin/callback_plugins')
    plugin_test_dir.append('/tmp/test_plugin/shell_plugins')
    plugin_test_dir.append('/tmp/test_plugin/inventory_plugins')
    plugin_test_dir.append('/tmp/test_plugin/filter_plugins')

# Generated at 2022-06-23 11:15:30.844849
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.plugins.loader import action_loader, connection_loader, shell_loader, module_loader, strategy_loader
    for loader in (action_loader, connection_loader, shell_loader, module_loader, strategy_loader,):
        paths = [plugin.__class__._load_name for plugin in loader.all(path_only=True)]
        display.display(paths)
        # FIXME: add assertions
# /Unit test for method all of class PluginLoader



# Generated at 2022-06-23 11:15:43.216853
# Unit test for method print_paths of class PluginLoader

# Generated at 2022-06-23 11:15:45.259630
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    print(PluginLoader("module_loader").print_paths())


# Generated at 2022-06-23 11:15:48.167885
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    '''
    Unit test for method __contains__ of class PluginLoader
    '''
    pass

# Generated at 2022-06-23 11:15:49.558591
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    add_all_plugin_dirs('~/.ansible/plugins')



# Generated at 2022-06-23 11:15:57.829522
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    fixture = PluginLoader()
    fixture._module_cache = PluginLoader._module_cache
    fixture._plugin_packages_paths = PluginLoader._plugin_packages_paths
    fixture._display_plugin_load = PluginLoader._display_plugin_load
    fixture._find_plugin_in_path = PluginLoader._find_plugin_in_path
    fixture._find_plugin_in_collection = PluginLoader._find_plugin_in_collection
    fixture._find_collection_in_collections = PluginLoader._find_collection_in_collections
    fixture._get_paths = PluginLoader._get_paths
    fixture._searched_paths = PluginLoader._searched_paths
    fixture._load_config_defs = PluginLoader._load_config_defs
    fixture._load_module_source = PluginLoader._load_module_

# Generated at 2022-06-23 11:15:59.321726
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    pass
# unit test for class PluginLoader

# Generated at 2022-06-23 11:16:07.509078
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    load_context=PluginLoadContext()
    assert load_context.redirect_list == []
    assert load_context.error_list == []
    assert load_context.load_attempts == []
    assert load_context.pending_redirect == None
    assert load_context.exit_reason == None

    shell = get_shell_plugin(shell_type='sh', executable='/usr/bin/sh')
    assert shell.executable == '/usr/bin/sh'



# Generated at 2022-06-23 11:16:17.918510
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # From module_utils.connection_loader.get()
    # def get(self, name, *args, **kwargs):
        def get_with_context(self, name, *args, **kwargs):
            return self.get_with_context(name, *args, **kwargs).object
    # Set _display_plugin_load function

# Generated at 2022-06-23 11:16:22.689000
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    ''' Unit tests for function `get_all_plugin_loaders`. '''
    # test: import module, has no side effects, no return values
    import_module('.plugins.loader', 'ansible')



# Generated at 2022-06-23 11:16:29.969025
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():

    plugin_loader = Jinja2Loader('ansible.legacy.', 'module_utils.module_common', 'ModuleUtilsModuleCommon')
    files = plugin_loader.all()

    assert isinstance(files, list)
    assert isinstance(files[0], str)
    assert files[0].endswith('action_plugins/module_utils.py')
    assert isinstance(files[-1], str)
    assert files[-1].endswith('module_utils/module_common.py')

    # TODO: need to test that top-level ansible.legacy plugins are loaded (but not collection ones)

# Generated at 2022-06-23 11:16:35.652155
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    # resolve with right arguments
    resolved_name = 'resolved_name'
    resolved_path = 'resolved_path'
    resolved_collection = 'resolved_collection'
    exit_reason = 'exit_reason'

    rch = PluginLoadContext()
    rch.resolve(resolved_name, resolved_path, resolved_collection, exit_reason)
    assert rch.pending_redirect is None
    assert rch.plugin_resolved_name == resolved_name
    assert rch.plugin_resolved_path == resolved_path
    assert rch.plugin_resolved_collection == resolved_collection
    assert rch.exit_reason == exit_reason
    assert rch.resolved is True


# Generated at 2022-06-23 11:16:42.694086
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    paths = ['/usr/share/ansible/plugins/module_utils', '/usr/share/ansible_plugins/action', '/home/username/.ansible/plugins/action', '/usr/share/ansible/plugins/action']
    assert PluginLoader.format_paths(paths) == 'action, module_utils, /home/username/.ansible/plugins/action'

# Generated at 2022-06-23 11:16:44.097606
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    pass


# Generated at 2022-06-23 11:16:54.499632
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    '''
    Test to check whether the find_plugin_with_context method of class PluginLoader is working correctly
    '''
    # Create a list of paths to be used to initialize a PluginLoader object
    orig_paths = (
        '/a/b/c',
        '/d/e',
    )
    # Create an instance of PluginLoader with paths as the above list
    p = PluginLoader(
        'ansible.plugins.test',
        module_finder=(lambda path, sentinel: glob.glob(os.path.join(path, 'test_*.py'))),
        module_prefix='test_',
        module_name='test',
        class_prefix='Test',
        class_name='Test'
    )
    p.add_directory(orig_paths[0])

# Generated at 2022-06-23 11:17:06.618389
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    test_dir = os.path.dirname(__file__)
    mock_plugin_dir = os.path.join(test_dir, 'lib', 'ansible', 'modules')
    loader = PluginLoader('ansible.modules._core', 'ModuleReplacer', '', 'core', 'module_utils')
    loader_with_subdirs = PluginLoader('ansible.modules._core', 'ModuleReplacer', '', 'core', 'module_utils', subdirs=['subdir'])

    assert isinstance(loader, PluginLoader)
    assert isinstance(loader_with_subdirs, PluginLoader)

    # Test that the mock module directory is not part of the path for the
    # module loader.

# Generated at 2022-06-23 11:17:12.072484
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    assert [('action_loader', action_loader), ('cache_loader', cache_loader), ('callback_loader', callback_loader), ('connection_loader', connection_loader), ('filter_loader', filter_loader), ('inventory_loader', inventory_loader), ('lookup_loader', lookup_loader), ('module_loader', module_loader), ('vars_loader', vars_loader)] == get_all_plugin_loaders()



# Generated at 2022-06-23 11:17:20.065235
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    c = Jinja2Loader('ansible.plugins.test', 'filter', 'Test')

    def check_path(name, path):
        ''' helper that calls get and verifies path is returned '''
        assert c.get(name, class_only=True, _initialize=False) == path

    # We know that this will only find stuff in 'ansible/plugins/test' so limit our search to that
    # directory
    c._searched_paths = [os.path.join(c.path, p) for p in ('', 'filter_plugins')]

    # also set the cache to be a set of all test plugins
    c._module_cache = {os.path.join(p, '__init__.py'): None for p in c._searched_paths}


# Generated at 2022-06-23 11:17:25.876915
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # pylint: disable=too-many-locals
    loader = PluginLoader(*C.DEFAULT_INTERNAL_PLUGIN_PATHS, package='ansible.plugins',
                          directories=['modules'], class_name='ModuleUtil')

    test_plugin_names = ['yum', 'yum', 'apt', 'apt', 'apt', 'apt', 'apt', 'apt', 'apt']

    test_directories = (
        'yum_3.3.0_all', 'yum',
        'apt_1.4.8_all', 'apt',
        'apt_2.5.5_all', 'apt',
        'apt_1.4.8_all', 'apt',
        'apt_2.5.5_all', 'apt',
    )

    test_plugin_path

# Generated at 2022-06-23 11:17:37.014714
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    context = PluginLoadContext()
    context.plugin_resolved_name = 'name'
    context.plugin_resolved_path = 'path'
    context.plugin_resolved_collection = 'collection'
    context.exit_reason = 'exitreason'
    context.resolved = True
    context.original_name = 'original_name'
    new_context = context.redirect('redirect_name')
    assert new_context.pending_redirect == 'redirect_name'
    assert new_context.original_name == 'original_name'
    assert new_context.plugin_resolved_name == 'name'
    assert new_context.plugin_resolved_path == 'path'
    assert new_context.plugin_resolved_collection == 'collection'