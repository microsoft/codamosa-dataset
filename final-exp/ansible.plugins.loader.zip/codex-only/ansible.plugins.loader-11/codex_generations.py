

# Generated at 2022-06-23 11:07:42.464783
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    # Constructor for PluginLoadContext

    plc = PluginLoadContext()
    assert(plc is not None)



# Generated at 2022-06-23 11:07:53.035052
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    # test_plugin_loader_get and test_plugin_load_context
    # tested against an old static plugin loader which was
    # much more limited and only returned a single path
    # this is testing against a dynamic loader
    loader = PluginLoader(
        'action',
        'ansible.plugins.action',
        'ActionModule',
        required_base_class='ActionBase',
        builtin_prefix='',
        cache_prefix='_',
    )
    assert not loader.has_plugin('test_plugin')
    with pytest.raises(AnsibleError):
        loader.get('test_plugin')

    assert loader.has_plugin('setup')
    found_instance = loader.get('setup')
    assert isinstance(found_instance, ActionBase)



# Generated at 2022-06-23 11:07:56.077697
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    plugin_loader = PluginLoader('', '')
    if plugin_loader.find_plugin('',''):
        print('find_plugin success')
    else:
        print('find_plugin failed')


# Generated at 2022-06-23 11:08:02.472101
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():

    my_loader = init_loader(
        class_name="FilterModule",
        base_class="FilterModule",
        package="ansible.plugins.filter",
        config_base_class="FilterConfig",
    )

    with pytest.raises(AnsibleError):
        # FIXME: implement this test
        my_loader.find_plugin('name.of.the.filter')


# Generated at 2022-06-23 11:08:11.882852
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    def test_basic_plugin_load(plugin_type_name, found_plugin_type, package, base_class, class_name, all_plugins, *args, **kwargs):
        class_only = kwargs.pop('class_only', False)
        results = {}
        for x in all_plugins:
            plugin = getattr(FoundPluginClass, found_plugin_type).find_plugin(x, *args, **kwargs)
            if plugin:
                module_path, class_name = plugin
                module = __import__(module_path, fromlist=[class_name])
                results[x] = getattr(module, class_name)
                if not class_only:
                    results[x] = results[x](*args, **kwargs)
        return results


# Generated at 2022-06-23 11:08:17.160590
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():

    # wrong argument
    with pytest.raises(AnsibleError) as exc:
        Jinja2Loader("tests", "j2")
    assert to_native(exc.value) == "Invalid Jinja2Plugin subclass: j2"

    # missing class name
    with pytest.raises(AnsibleError) as exc:
        Jinja2Loader("tests", "Jinja2Plugin")
    assert to_native(exc.value) == "Invalid Jinja2Plugin subclass: Jinja2Plugin"

    # wrong class name
    with pytest.raises(AnsibleError) as exc:
        Jinja2Loader("tests", "Jinja2Plugin", "Filter")
    assert to_native(exc.value) == "Invalid Jinja2Plugin subclass: Jinja2Plugin"

    # correct class name

# Generated at 2022-06-23 11:08:20.922257
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    assert(PluginLoadContext().resolve('resolved_name', 'resolved_path', 'resolved_collection', 'exit_reason') == PluginLoadContext().resolve('resolved_name', 'resolved_path', 'resolved_collection', 'exit_reason'))

# Generated at 2022-06-23 11:08:29.174000
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    pl = PluginLoader(package='ansible.plugins.lookup')
    assert pl.format_paths(['/a', '/b', '/a/c']) =='/a, /a/c and /b'
    assert pl.format_paths(['/a/c', '/a/b', '/a']) =='/a, /a/b and /a/c'
    assert pl.format_paths(['/a/b', '/a', '/a/c']) =='/a, /a/b and /a/c'
    assert pl.format_paths(['/a', '/a/c', '/a/b']) =='/a, /a/b and /a/c'

# Generated at 2022-06-23 11:08:36.477759
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    try:
        # Test PluginLoader.add_directory() with add_all_plugin_dirs
        import tempfile
        tmp_dir = tempfile.mkdtemp()
        tmp_plugin_dir = os.path.join(tmp_dir, 'plugins')
        os.makedirs(tmp_plugin_dir)
        # Create a temporary plugin in the temp directory
        with open(os.path.join(tmp_plugin_dir, 'mytest.py'), 'wb') as f:
            f.write(b"test_add_all_plugin_dirs_dummy_data")
        add_all_plugin_dirs(tmp_dir)
        path = PATH_CACHE['mytest']
        os.remove(path)
        os.removedirs(tmp_plugin_dir)
    finally:
        os.rem

# Generated at 2022-06-23 11:08:41.560901
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    for name, obj in get_all_plugin_loaders():
        assert isinstance(obj, PluginLoader)
        assert name in globals()
        assert globals()[name] is obj



# Generated at 2022-06-23 11:08:47.038324
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    loader = PluginLoader('module', 'plugins.module_utils', 'ModuleUtility')
    loader.add_directory(os.path.join(os.getcwd(), 'test_plugins', 'module_utils'), with_subdir=False)
    loader.print_paths()


# Generated at 2022-06-23 11:08:55.744231
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    from ansible.plugins import jinja_loader
    from ansible.plugins.loader import collection_loader

    # Invalid CollectionRef

# Generated at 2022-06-23 11:09:05.006108
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    loader = PluginLoader('foo', 'FooModule', C.DEFAULT_INTERNAL_PLUGINS_PATH, 'ansible.plugins.foo', required_base_class='AnsibleModule')
    assert loader._get_paths() == [C.DEFAULT_INTERNAL_PLUGINS_PATH]
    loader.add_directory(os.path.join(C.DEFAULT_INTERNAL_PLUGINS_PATH, 'foo'))
    assert loader._get_paths() == [C.DEFAULT_INTERNAL_PLUGINS_PATH, os.path.join(C.DEFAULT_INTERNAL_PLUGINS_PATH, 'foo')]

# Generated at 2022-06-23 11:09:05.649739
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    pass

# Generated at 2022-06-23 11:09:18.204216
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    from ansible import constants as C

    # create an isolate loader for tests
    # without C.role_path it will look in ansible/plugins/filter
    loader = Jinja2Loader(os.path.join(C._config.get_config_dir(), 'plugins', 'filter_plugins'))

    # full path to jinja_plugins in ansible core
    std_path = os.path.join(C.DEFAULT_MODULE_PATH, 'ansible', 'plugins', 'filter_plugins', 'jinja_plugins.py')
    # full path to jinja_plugins in my collection
    coll_path = os.path.join(C.DEFAULT_MODULE_PATH, 'ansible_collections', 'hco', 'test', 'plugins', 'filter_plugins', 'jinja_plugins.py')

    # create a fake

# Generated at 2022-06-23 11:09:23.179190
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    # Instantiation of plugin loader.
    loader = PluginLoader('callback', 'CallbackModule', 'ansible.plugins.callback', '_load_callback_plugins')
    # Instantiation of test plugin.
    test_plugin = TestPlugin('Test Plugin')
    # Value of expected result.
    expected_result = test_plugin.copy()
    # Value of actual result.
    actual_result = loader.get(expected_result._load_name, expected_result._original_path, expected_result._redirected_names)
    assert actual_result == expected_result


# Generated at 2022-06-23 11:09:31.093817
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    # setup
    context = PluginLoadContext()
    # assert
    assert context is not None
    assert context.original_name is None
    assert len(context.redirect_list) == 0
    assert len(context.error_list) == 0
    assert len(context.import_error_list) == 0
    assert len(context.load_attempts) == 0
    assert context.pending_redirect is None
    assert context.exit_reason is None
    assert context.plugin_resolved_path is None
    assert context.plugin_resolved_name is None
    assert context.plugin_resolved_collection is None
    assert not context.deprecated
    assert context.removal_date is None
    assert context.removal_version is None
    assert len(context.deprecation_warnings) == 0

# Generated at 2022-06-23 11:09:35.943019
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    # FIXME:  (py27) not implement in python2.7 

    # test_PluginLoader___getstate__() # with self.assertRaises(Exception):
    # test_PluginLoader___getstate__() # AnsibleParser(None).run()
    raise SkipTest  # removed or not implemented


# Generated at 2022-06-23 11:09:37.363343
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    pt = PluginLoader()
    assert isinstance(pt, PluginLoader)


import unittest

# Generated at 2022-06-23 11:09:47.089542
# Unit test for method all of class Jinja2Loader

# Generated at 2022-06-23 11:09:53.081626
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    cache = PluginLoader(class_name='CacheModule', package='ansible.plugins.cache', config_loader=None, base_class='BaseCacheModule')

    # Testing with existing module
    existing_module = cache.get('memory')
    assert repr(existing_module) == "PluginLoader(class_name='CacheModule', package='ansible.plugins.cache', config_loader=None, base_class='BaseCacheModule')"

# Generated at 2022-06-23 11:10:04.722268
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    class TestPluginLoader(object):
        ''' Test class to mock real PluginLoader class '''

        def __init__(self):
            self.package = 'ansible.plugins.test'
            self.base_class = 'BaseTestClass'
            self.class_name = 'TestClass'
            self.defs_file_names = ['test_defs']
            self.subdir = 'test_subdir'
            self.caching = True
            self._module_cache = {}
            self._paths = []

    # test __setstate__
    loader = TestPluginLoader()
    pickle_copy = pickle.dumps(loader)
    # in Python 2 pickle does not call __setstate__()
    # use a hack to set the pickle protocol to 2 if we are on Python 2 to trigger __setstate__()

# Generated at 2022-06-23 11:10:08.495458
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    plcontext = PluginLoadContext()
    assert plcontext.nope('foobar') == plcontext
    assert plcontext.exit_reason == 'foobar'
    assert not plcontext.resolved


# Generated at 2022-06-23 11:10:19.542785
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    load_context = PluginLoadContext()
    assert load_context.original_name is None
    assert load_context.redirect_list == []
    assert load_context.error_list == []
    assert load_context.import_error_list == []
    assert load_context.load_attempts == []
    assert load_context.pending_redirect is None
    assert load_context.exit_reason is None
    assert load_context.plugin_resolved_path is None
    assert load_context.plugin_resolved_name is None
    assert load_context.plugin_resolved_collection is None
    assert not load_context.deprecated
    assert load_context.removal_date is None
    assert load_context.removal_version is None
    assert load_context.deprecation_warnings == []

# Generated at 2022-06-23 11:10:27.584592
# Unit test for method all of class Jinja2Loader

# Generated at 2022-06-23 11:10:29.875286
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    result = get_with_context_result(None, None, None, None, None)
    # Version is None
    assert result.version == None
    # Context is None
    assert result.context == None
    # Name is None
    assert result.name == None
    # Loader is None
    assert result.loader == None

# Generated at 2022-06-23 11:10:41.448352
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    from ansible import constants as C

    plugin_loader = PluginLoader('test')

    pc = '{0}/test/'.format(C.get_config_val('DEFAULT_LOCAL_TMP'))
    pc2 = '{0}/test2/'.format(C.get_config_val('DEFAULT_LOCAL_TMP'))
    paths = [
        '{0}/test/a'.format(C.get_config_val('DEFAULT_LOCAL_TMP')),
        pc + 'b',
        '{0}/test/c'.format(C.get_config_val('DEFAULT_LOCAL_TMP')),
        pc + 'd'
    ]

    # Test what the method returns when we pass in a list of paths

# Generated at 2022-06-23 11:10:44.289346
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    with pytest.raises(NotImplementedError):
        plugin_loader = PluginLoader(None)
        plugin_loader.__contains__('foo', None)


# Generated at 2022-06-23 11:10:46.412566
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    try:
        shell = get_shell_plugin('fish')
    except:
        return False
    return True



# Generated at 2022-06-23 11:10:47.912629
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    plugin_load = PluginLoader()
    print(plugin_load)

# Generated at 2022-06-23 11:10:59.115766
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    from ansible.plugins.test.fake_plugins import FakePluginLoader
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    cl = AnsibleCollectionLoader()
    cl.set_collection_paths(os.path.join(os.path.dirname(__file__), 'filter_plugins'))
    cl.load()

    # We need to create a fake plugin loader
    p = FakePluginLoader(cl, 'filter_loader')
    # Create a new Jinja2Loader
    j = Jinja2Loader('filter_loader', p.paths, p.package, p.base_class, p.class_name)

    # Create the list of plugins
    plugins = list(j.all())

    # We should have six plugins
    assert len(plugins) == 6

    # The names should be in order
    assert plugins

# Generated at 2022-06-23 11:11:08.167443
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    fixture = PluginLoader(
        os.path.join(os.path.dirname(__file__), 'fixtures', 'test_plugin_loader'),
        'Foo',
        'foo',
        'FooBase',
    )

    assert fixture.__getstate__() == dict(
        package=fixture.package,
        subdir=fixture.subdir,
        path_list=fixture.path_list,
        class_name=fixture.class_name,
        base_class=fixture.base_class,
        aliases=fixture.aliases,
    )

# Generated at 2022-06-23 11:11:11.429686
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    plugin_loader = PluginLoader(package='testPackage', config=None, subdir='testSubdir')
    plugin_loader.__setstate__(None)


# Generated at 2022-06-23 11:11:24.488654
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.plugins.loader import _PLUGIN_PATH_CACHE
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import is_disabled_plugin
    from ansible.plugins.loader import remove_plugin_from_loaders

    plugin_paths = [
        os.path.join(os.path.dirname(__file__), 'test_plugins_disabled_exts'),
        os.path.join(os.path.dirname(__file__), 'test_plugins_excluded'),
    ]
    loaders = get_all_plugin_loaders(plugin_paths)
    # Start with a clean slate
    _PLUGIN_PATH_CACHE.clear()

    # Simple test with no exclusions


# Generated at 2022-06-23 11:11:26.435549
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    _test_PluginLoader()

# Generated at 2022-06-23 11:11:29.726739
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell_plugin = get_shell_plugin(shell_type='sh')
    assert shell_plugin.SHELL_FAMILY == 'sh'
    assert shell_plugin.executable == '/bin/sh'



# Generated at 2022-06-23 11:11:38.615734
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    def generate_PathSet(paths, default_value=False):
        return {path: default_value for path in paths}

    def generate_PathSet_With_Default_Paths(additional_paths, default_value=False):
        return generate_PathSet(DEFAULT_PATHS + additional_paths, default_value=default_value)

    paths = [ "/foo/bar/baz", "/x/y/z", ]
    path_set = generate_PathSet(paths)

    default_values = PluginLoader.format_paths(path_set)

    assert default_values == ", ".join(paths)

    path_set = generate_PathSet_With_Default_Paths(["/foo/bar/baz", "/x/y/z", ])
    default_values = PluginLoader.format_path

# Generated at 2022-06-23 11:11:44.659405
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS, 'action_plugins')
    result_group = loader.get('group')
    assert result_group.__name__ == 'ActionModule'
    assert result_group.__module__ == 'ansible_group'


# Generated at 2022-06-23 11:11:45.560423
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # This is a placeholder for a unit test that should test that all dirs are added to all plugin loaders
    pass



# Generated at 2022-06-23 11:11:49.607786
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    """Test Jinja2Loader.get"""
    import ansible.module_utils.six
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import string_types

    #
    # Test with some option value for _dedupe
    #
    _dedupe = None
    l = Jinja2Loader('ansible.plugins.j2_filters', 'FilterModule', C.get_config(C.p, C.DEFAULT_DEBUG))
    result = l.get('join', _dedupe=_dedupe)
    # Expected to return a bool
    assert isinstance(result, bool)

    #
    # Test with some option value for class_only
    #
    class_only = None

# Generated at 2022-06-23 11:11:51.642617
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    if not isinstance(PluginLoader.__getstate__(), dict):
        raise AssertionError()

# Generated at 2022-06-23 11:12:02.576160
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    new_context = PluginLoadContext()
    assert new_context.original_name is None
    assert new_context.redirect_list == []
    assert new_context.error_list == []
    assert new_context.import_error_list == []
    assert new_context.load_attempts == []
    assert new_context.pending_redirect is None
    assert new_context.exit_reason is None
    assert new_context.plugin_resolved_path is None
    assert new_context.plugin_resolved_name is None
    assert new_context.deprecated is False
    assert new_context.removal_date is None
    assert new_context.removal_version is None
    assert new_context.deprecation_warnings == []
    assert new_context.resolved is False
    assert new_context

# Generated at 2022-06-23 11:12:06.684163
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():  # test case for class PluginLoader
    loader = PluginLoader('', 'connection', 'Connection')
    with pytest.raises(AnsibleError):
        'value' in loader


# Generated at 2022-06-23 11:12:18.094471
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    # It's impossible to create a plugin loader without a specified type.  So we pass something in
    # to make it work.
    # FIXME: We should change this to something like
    # def __init__(self, subdir, package, base_class=None):
    # so we don't require a type to be passed in
    loader = PluginLoader(None, 'ansible.plugins.test_plugintype')
    loader._searched_paths = ['foo', 'bar']
    assert loader.format_paths() == '[\'foo\', \'bar\']'

    loader._searched_paths = []
    assert loader.format_paths() == '[]'

    loader._searched_paths = ['foo']
    assert loader.format_paths() == '\'foo\''

    # 'Look ma,

# Generated at 2022-06-23 11:12:19.636360
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    plc = PluginLoadContext()
    assert(plc.nope('nope') == plc)



# Generated at 2022-06-23 11:12:31.349372
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    # Test with a plugin method type
    original_name = 'test_plugin'
    exit_reason = 'Not able to resolve plugin'
    loader_context = PluginLoadContext()
    loader_context.resolve('test_plugin', '/path', 'my.collection', exit_reason)
    loader_context.nope('Not able to resolve plugin')
    assert loader_context.original_name==original_name
    assert loader_context.exit_reason==exit_reason
    assert loader_context.plugin_resolved_path=='/path'
    assert loader_context.plugin_resolved_collection=='my.collection'
    assert loader_context.resolved==False
    assert loader_context.pending_redirect==None
    assert loader_context.removal_date==None
    assert loader_context.removal_version==None
   

# Generated at 2022-06-23 11:12:32.334885
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    pass


# Generated at 2022-06-23 11:12:33.966002
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    assert (u'action_loader', PluginLoader) in get_all_plugin_loaders()



# Generated at 2022-06-23 11:12:41.071319
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    plugin_load_context1 = PluginLoadContext()
    resolved_name = "worker"
    resolved_path = "/tmp/ansible_task/action_plugins"
    resolved_collection = "my_collection"
    exit_reason = "exit reason"
    plugin_load_context1.resolve(resolved_name, resolved_path, resolved_collection, exit_reason)
    assert plugin_load_context1.plugin_resolved_name == resolved_name
    assert plugin_load_context1.plugin_resolved_path == resolved_path
    assert plugin_load_context1.plugin_resolved_collection == resolved_collection
    assert plugin_load_context1.exit_reason == exit_reason
    assert plugin_load_context1.resolved == True
    assert plugin_load_context1.pending_redirect == None
   

# Generated at 2022-06-23 11:12:42.525980
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # TODO: Add unit tests for Jinja2Loader.find_plugin
    assert True

# Generated at 2022-06-23 11:12:45.487933
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
  loader = PluginLoader(None)
  assert loader.__repr__() == "PluginLoader(class_name='None', package='None')"


# Generated at 2022-06-23 11:12:55.789841
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    class_obj = PluginLoadContext()
    assert class_obj.original_name is None
    assert class_obj.redirect_list == []
    assert class_obj.error_list == []
    assert class_obj.import_error_list == []
    assert class_obj.load_attempts == []
    assert class_obj.pending_redirect is None
    assert class_obj.exit_reason is None
    assert class_obj.plugin_resolved_path is None
    assert class_obj.plugin_resolved_name is None
    assert class_obj.plugin_resolved_collection is None
    assert class_obj.deprecated is False
    assert class_obj.removal_date is None
    assert class_obj.removal_version is None
    assert class_obj.deprecation_warnings == []
   

# Generated at 2022-06-23 11:13:00.740361
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    for test_input, expected in Jinja2LoaderTestGetData.test_data:
        actual = Jinja2Loader(test_data.TestData.jinja2_loader_package, test_data.TestData.jinja2_loader_base_class).get(test_input)
        assert actual == expected


# Generated at 2022-06-23 11:13:01.839913
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    pass


# Generated at 2022-06-23 11:13:08.733872
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    import sys
    import jinja2.exceptions
    sys.modules['_catalog'] = jinja2.exceptions
    try:
        # Ensure PluginLoader.get does not load filter or test plugins from collections
        loader = Jinja2Loader('filter_plugins', 'ansible.plugins.filter')
        plugins = list(loader.all())
        assert len(plugins) == 0

        loader = Jinja2Loader('test_plugins', 'ansible.plugins.test')
        plugins = list(loader.all())
        assert len(plugins) == 0
    finally:
        del sys.modules['_catalog']

# Generated at 2022-06-23 11:13:15.019526
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    pl = PluginLoader('_', '_', '_', '_')

    data = {'_seen_paths': ['_'], '_display_paths': ['_']}
    pl.__setstate__(data)

    assert pl._seen_paths == ['_']
    assert pl._display_paths == ['_']

# Generated at 2022-06-23 11:13:16.040144
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    pl = PluginLoader('test_collection.test_ns')
    pl.print_paths()



# Generated at 2022-06-23 11:13:24.788470
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    class temp_plugin:
        def __init__(self):
            self.deprecation = OrderedDict()
            self.deprecation['warning_text'] = "Test Warning text."
            self.deprecation['removal_date'] = "Test removal date."
            self.deprecation['removal_version'] = "Test removal version."
    temp_plugin = temp_plugin()
    plc = PluginLoadContext()
    plc.record_deprecation('plugin', temp_plugin.deprecation, None)
    assert plc.deprecated == True
    assert plc.removal_date == "Test removal date."
    assert plc.removal_version == "Test removal version."
    assert plc.deprecation_warnings[0] == "plugin has been deprecated. Test Warning text."

# Unit test

# Generated at 2022-06-23 11:13:33.768132
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # test_Jinja2Loader_get() uses the following static variables:
    #   C
    #   os
    #   PluginLoader
    #   to_text
    try:
        import pytest  # pylint: disable=W0611
    except ImportError:
        raise SkipTest
    import jinja2

    C.DEFAULT_INCLUDE_EXCLUDE = 'include_exclude.yml'

    assert os.path.exists(C.DEFAULT_INCLUDE_EXCLUDE)

    module = PluginLoader('ansible.plugins.filter', 'TestFilter', 'filter_plugins')
    test_filter = module.get('substring')

    assert isinstance(test_filter, jinja2.filters.TestFilter)

    # Test that a plugin we know does not exist

# Generated at 2022-06-23 11:13:34.744891
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    print(PluginLoader.print_paths())



# Generated at 2022-06-23 11:13:45.136923
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    '''
    Unit test using nose
    '''
    import ansible.plugins.action

    p = PluginLoader('action', 'ActionModule', 'ansible.plugins.action', 'action_plugins')
    assert p.package == 'ansible.plugins.action'
    assert p.subdir == 'action_plugins'
    assert p.class_name == 'ActionModule'
    assert p.paths == [os.path.join(os.path.dirname(ansible.plugins.action.__file__), 'action_plugins')]  # action_plugins/

    p = PluginLoader('cache', 'CacheModule', 'ansible.plugins.cache', 'cache')
    assert p.package == 'ansible.plugins.cache'
    assert p.subdir == 'cache'
    assert p.class_name == 'CacheModule'
   

# Generated at 2022-06-23 11:13:50.876153
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    ppc = PluginPathContext(path='/usr/lib/python3.6/site-packages/ansible/plugins/test_plugin.py', internal=True)
    assert ppc.path == '/usr/lib/python3.6/site-packages/ansible/plugins/test_plugin.py'
    assert ppc.internal


# Generated at 2022-06-23 11:13:58.086680
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    print("(" + __file__ + ") " + sys._getframe().f_code.co_name)

    loader = PluginLoader("base_class", "module_utils/foo.py", "ansible.push", "class_name")
    assert loader.__repr__() == "<PluginLoader base_class=module_utils/foo.py, package=ansible.push, class_name=class_name>"


# Generated at 2022-06-23 11:14:04.120032
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    # Create a default instance of PluginLoadContext.
    plugin_load_context = PluginLoadContext()
    # Create a new instance of PluginLoadContext with the redirect_name.
    plugin_load_context_redirect = plugin_load_context.redirect("cached_plugin_manager")
    # Confirm that the new instance of PluginLoadContext is not None.
    assert plugin_load_context_redirect is not None
    # Confirm that the pending_redirect of the new instance is equal to the redirect_name.
    assert plugin_load_context_redirect.pending_redirect == "cached_plugin_manager"
    # Confirm that the exit_reason of the new instance contains the redirect_name.
    assert "cached_plugin_manager" in plugin_load_context_redirect.exit_reason
    # Confirm that the resolved

# Generated at 2022-06-23 11:14:15.116567
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    # Setup the standard variables for all of the tests.
    package = "ansible.plugins.test"
    base_path = "./lib/ansible/plugins/test"
    paths = [os.path.abspath(base_path)]
    cls = "LookupModule"
    base_class = "LookupBase"

    cache = PluginLoaderCache()

    # Do the actual test
    loader = Jinja2Loader(package,  # the name of the package which contains the plugins
                          paths,  # a list of paths were plugins can be found
                          'filter_plugins',  # the name of the subdirectory to search in each path in paths
                          cls=cls,  # the name of the expected baseclass of the plugins
                          base_class=base_class,
                          )  # the path of the module which

# Generated at 2022-06-23 11:14:27.638997
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    temp_cwd = tempfile.mkdtemp()


# Generated at 2022-06-23 11:14:33.484834
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    args = []
    kwargs = {}

    # Setup mock objects
    stdin = MagicMock(name='stdin')
    stdout = MagicMock(name='stdout')
    stderr = MagicMock(name='stderr')

    mock_cli = MagicMock(name='CLI',
                         stdin=stdin,
                         stdout=stdout,
                         stderr=stderr)
    mock_display = MagicMock(name='Display',
                             verbosity=1)
    mock_plugin_loader = MagicMock(name='PluginLoader',
                                   display=mock_display,
                                   cli=mock_cli,
                                   package='ansible.plugins.action')


# Generated at 2022-06-23 11:14:42.052171
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    jinja2_loader = Jinja2Loader()
    jinja2_loader.package = 'ansible.legacy'
    jinja2_loader.class_name = 'FilterModule'
    # Defined in __init__.py, force to retrieve it
    jinja2_loader.directories = ''
    jinja2_loader.subdir = 'filter_plugins'

    # Find non-exist plugin
    plugin = jinja2_loader.find_plugin('ansible.legacy.plugins.filter_non_exist')
    assert plugin is not None

    # Find exist plugin
    plugin = jinja2_loader.find_plugin('ansible.legacy.plugins.filter_plugin')
    assert plugin is not None


# Generated at 2022-06-23 11:14:52.381727
# Unit test for method get of class PluginLoader

# Generated at 2022-06-23 11:15:03.741793
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    fqcn = 'collection.namespace.plugin_type.plugin_name'
    name = fqcn.split('.')[-1]
    deprecation = {'warning_text': 'warning_text', 'removal_date': 'removal_date', 'removal_version': 'removal_version'}
    # getting object of PluginLoadContext class
    plc = PluginLoadContext()
    plc.record_deprecation(name, deprecation, 'collection_name')
    if plc.removal_date is not None:
        plc.removal_version = None
    assert plc.deprecation_warnings == ['{0} has been deprecated. {1}'.format(name, 'warning_text')]


# Generated at 2022-06-23 11:15:05.508239
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    plugin = get_shell_plugin(shell_type='sh')
    assert plugin.SHELL_FAMILY == 'sh' and plugin.executable == '/bin/sh'



# Generated at 2022-06-23 11:15:07.520421
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # TODO: This won't work until we can mock the file system
    pass

# Generated at 2022-06-23 11:15:10.256445
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    jl = Jinja2Loader()

    # TODO: move to real test
    for t in jl.all(collection_list=[]):
        print(t)


# Generated at 2022-06-23 11:15:14.936889
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # Setup

    # Call the method
    try:
        returned = Jinja2Loader('ansible.plugins.filter','FilterModule').find_plugin('foo')
    except Exception as err:
        returned = err
    # Verify results
    assert False


# Generated at 2022-06-23 11:15:18.456372
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    context = PluginPathContext('/usr/lib/ansible', internal=True)
    assert context.path == '/usr/lib/ansible'
    assert context.internal is True



# Generated at 2022-06-23 11:15:24.926976
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    new_plugin_loader = PluginLoader('module_utils')
    new_plugin_loader._searched_paths = ['/path/to/ansible/module_utils/module1.pyc', '/path/to/ansible/module_utils/module2.py']
    assert new_plugin_loader.format_paths() == 'plugin/module_utils/module1.pyc, plugin/module_utils/module2.py'


# Generated at 2022-06-23 11:15:33.274249
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    # These tests require at least one environment variable to be set
    # In order to confirm the method produces the correct output
    empty_env = dict(os.environ)
    most_env = dict(os.environ)
    for i in os.environ:
        most_env.pop(i)
    for env in (empty_env, most_env):
        with patch.dict('os.environ', env, clear=True):
            pl = PluginLoader('test')
            assert pl.print_paths() == 'test_paths:  (none set)'


# Generated at 2022-06-23 11:15:44.913987
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    """ unit testing for method format_paths of class PluginLoader """
    pl = PluginLoader(None, 'paths')
    s = pl.format_paths(['/a/b/c/d', '/a/b/c/1'])
    assert s == '/a/b/.../d: /a/b/.../1', "failed to correctly format paths"
    s = pl.format_paths(['/a/b/c/d', '/a/b/c/2', '/a/b/c/3'])
    assert s == '/a/b/.../d: /a/b/c/2: /a/b/c/3', "failed to correctly format paths"

# Generated at 2022-06-23 11:15:51.522318
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    # Test default behavior of PluginLoader.print_paths (no args)
    foo = PluginLoader("ansible.test.dummy_plugins", 'DummyPlugin', 'dummy_plugins', 'dummy_plugins')
    yaml_content = foo.print_paths()

    assert yaml_content == os.path.join("ansible", "test", "dummy_plugins", "dummy_plugins")


# Generated at 2022-06-23 11:15:59.581782
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    loader = Jinja2Loader('ansible.plugins.filter', 'FilterModule')

    # TODO: refactor these paths to make them smaller/simpler
    fixtures_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'units', 'module_utils', 'filter_loader_fixtures')
    lookups_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'units', 'lookup_plugins')
    filter_path = os.path.join(os.path.dirname(__file__), '..', '..', 'filter_plugins')

    loader.module_locator.add_directory(fixtures_path)

# Generated at 2022-06-23 11:16:11.215526
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    from ansible.utils.shlex import shlex_split
    from ansible.module_utils.common.warnings import DeprecationWarning
    from ansible.utils.display import Display
    from ansible.collections.ansible.builtin.plugins.loader import PluginLoadContext
    context = PluginLoadContext()
    deprecation = {'warning_text': 'test', 'removal_date': '2017-10-26', 'removal_version': '6'}
    context.record_deprecation('Executor fake_executor', deprecation, 'ansible.builtin')
    #assert context.deprecation_warnings == ['Executor fake_executor has been deprecated. test']
    pass

# Generated at 2022-06-23 11:16:19.375772
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    class TestLoader(PluginLoader):
        def __init__(self):
            global_path = '/path/to/global_plugins'
            local_paths = ['/path/to/first_collection/plugins',
                           '/path/to/second_collection/plugins']

            self.package = 'test_package'
            self.class_name = 'CName'

            self._searched_paths = local_paths
            if PluginLoader.CACHE_PLUGIN_PATH is False:
                self._searched_paths.append(global_path)

            super(TestLoader, self).__init__(self.package, self.class_name,
                                             local_paths, global_path)

    loader = TestLoader()
    assert(loader.package == 'test_package')

# Generated at 2022-06-23 11:16:29.888150
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    PL = PluginLoader('foo', 'bar')

    # call case 1
    # call return None: no plugin found
    PL.find_plugin_with_context = Mock(return_value=resolved_plugin_result(False, None, None, None, None))
    assert not PL.get_with_context('test')

    # call case 2
    # call return plugin_load_context: resolved True, but no item found
    PL.find_plugin_with_context = Mock(return_value=resolved_plugin_result(True, 'test', '', None, None))
    assert not PL.get_with_context('test')

    # call case 3
    # call return plugin_load_context: resolved True, but plugin path not found

# Generated at 2022-06-23 11:16:31.707402
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    assert get_all_plugin_loaders() == [('get_all_plugin_loaders', get_all_plugin_loaders),
                                        ('PluginLoader', PluginLoader)]



# Generated at 2022-06-23 11:16:44.607679
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    from collections import namedtuple
    FakePluginLoader = namedtuple('FakePluginLoader',['subdir'])
    pl = FakePluginLoader(subdir='test')
    path_list = ['foo', 'bar', 'baz']
    pl._searched_paths = path_list
    # Using the _searched_paths as the list to format for this test
    search_paths = pl._searched_paths
    result = pl.format_paths(search_paths)
    # Specific string tests
    assert('./test' in result)
    assert('foo' in result)
    assert('bar' in result)
    assert('baz' in result)
    # Specific length and order tests
    assert(len(search_paths) + 2 == len(result.split('\n')))
   

# Generated at 2022-06-23 11:16:54.889401
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    def check_expected_path(expected_path, loader, name, collection_list=None):

        result = loader.find_plugin(name=name, collection_list=collection_list)

        assert expected_path == getattr(result, 'path', None)

    def check_expected_paths(expected_paths, loader, names, collection_list=None):

        for name in names:
            check_expected_path(expected_path=expected_paths[name], loader=loader, name=name, collection_list=collection_list)

    # setup
    cache_loader = Jinja2Loader('ansible.plugins.cache')
    filter_loader = Jinja2Loader('ansible.plugins.filter')
    test_loader = Jinja2Loader('ansible.plugins.test')


# Generated at 2022-06-23 11:17:02.117533
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    class_name = 'class_name'
    package = 'ansible.plugins.connection'
    base_class = 'ConnectionBase'
    config_entry = 'connection'
    class_collection_list = None
    package_collection_list = None

    # Instantiate a PluginLoader object
    plugin_loader = PluginLoader(class_name, package, base_class, config_entry, class_collection_list, package_collection_list)
    name = 'mock'
    args = ['args']
    kwargs = {'key': 'kwargs'}

    # Call PluginLoader.get_with_context method
    get_with_context_result = plugin_loader.get_with_context(name, args, kwargs)
    # Get the object and the plugin_load_context
    obj, plugin_load_context = get_

# Generated at 2022-06-23 11:17:13.026036
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    PL = PluginLoader(package='ansible_collections.nsbl.test',
                      config=dict(ANSIBLE_COLLECTIONS_PATHS="/dev/null"),
                      subdir='plugins',
                      aliases={},
                      class_name='TestCollectionPlugin',
                      base_class='ansible.plugins.loader.PluginLoader',
                      )
    print("Test 1: plugin path exists")
    path = os.path.dirname(os.path.abspath(__file__))
    PL.add_directory(path)
    assert path in PL._get_paths()
    print("Test 2: plugin path does not exist")
    path = '/not/an/existing/directory'
    PL.add_directory(path)
    assert path in PL._get_paths()



# Generated at 2022-06-23 11:17:24.487793
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    p = PluginLoader('ansible.plugins.*', 'FooBar')

    # Invalid base_class should raise exception
    with pytest.raises(AnsibleError):
        p = PluginLoader('ansible.plugins.*', 'FooBar', 'xyz')

    # Test for a non-existent package
    p = PluginLoader('ansible.plugins.foo', 'FooBar')
    # get_all_plugin_loaders will return empty list if no loaders are
    # registered for given plugin type
    assert p.get_all_plugin_loaders() == []
    # get_package_paths returns empty list if package is not found
    assert p.get_package_paths() == []


# create global plugin loaders that can be used by any code which needs to
# access plugins of a given type

_MAIN_

# Generated at 2022-06-23 11:17:31.969365
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    locals().update(get_all_plugin_loaders())
    assert(action == PluginLoader.action)
    assert(cache == PluginLoader.cache)
    assert(connection == PluginLoader.connection)
    assert(filter == PluginLoader.filter)
    assert(inventory == PluginLoader.inventory)
    assert(lookup == PluginLoader.lookup)
    assert(netconf == PluginLoader.netconf)
    assert(terminal == PluginLoader.terminal)
    assert(vars == PluginLoader.vars)



# Generated at 2022-06-23 11:17:41.358658
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():

    # Test constructor for expected failures
    try:
        ansible_loader = Jinja2Loader('test', 'failure.test')
    except AnsibleError:
        pass
    else:
        raise AssertionError('Expected an error from constructor but it did not happen.')

    # Test constructor for an expected success
    try:
        ansible_loader = Jinja2Loader('ansible.plugins.filter', 'Jinja2FilterModule')
    except AnsibleError:
        raise AssertionError('Expected no error from constructor but it happened.')
    else:
        pass

    # Test 'all' method.  Iterating over result is same as calling 'get'
    # There are no collection plugins for these types (yet).
    # We should only get plugins from ansible.legacy.
    # There should be no overlap between these