

# Generated at 2022-06-23 11:07:45.221500
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    assert False, "Test is not implemented"


# temporary global cache of plugins, based on looking up by class name
# this is used to reduce the number of times we have to load/parse a file
# to get the main class object from it.
_PLUGIN_CACHE = {}



# Generated at 2022-06-23 11:07:51.209970
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    loader = PluginLoader('module_utils', 'ModuleUtils', 'module_utils')
    context = loader.find_plugin_with_context('module_utils')
    assert context.resolved == True
    assert context.plugin_resolved_path == '/usr/lib/python2.7/site-packages/ansible/module_utils/module_utils.py'


# Generated at 2022-06-23 11:08:00.741097
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    """
    Testing Jinja2Loader (if any changes are made to the class, please update this test).

    * Verify exception thrown with empty name.
    * Verify exception thrown with empty new_style_class_name.
    * Verify exception thrown with empty package.
    * Verify exception thrown with empty subdir.
    * Verify exception thrown with empty config.
    * Verify exception thrown with empty config.
    """

    with pytest.raises(AnsibleError) as e:
        Jinja2Loader('', 'DummyClass', 'dummy.package', 'dummy.subdir', config=None)
    assert 'No name specified for plugin loader' in str(e)


# Generated at 2022-06-23 11:08:10.582906
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    # Create an instance of PluginLoader
    obj = PluginLoader('test_name', {}, '.', 'test_class_name', 'test_package', 'test_path')

    # Representation must contains the class name
    assert 'PluginLoader' in repr(obj), 'The representation should contain the class name'

    # Representation must contains the package name
    assert 'test_package' in repr(obj), 'The representation should contain the package name'

    # Representation must contains the class name
    assert 'test_class_name' in repr(obj), 'The representation should contain the class name'

    # Representation must contains the path name
    assert 'test_path' in repr(obj), 'The representation should contain the path name'

    # Representation must contains the aliases
    assert '{}' in repr(obj), 'The representation should contain the aliases'

# Generated at 2022-06-23 11:08:16.221631
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    from ansible.plugins.shell import ShellBase
    from ansible.module_utils.six import string_types
    from ansible.errors import AnsibleError
    from ansible.utils.path import unfrackpath
    from ansible import MODULE_CACHE
    # test with valid shell, not an executable
    shell = get_shell_plugin('sh')
    assert isinstance(shell, ShellBase)
    assert shell.SHELL_FAMILY == 'sh'
    # test with valid shell, executable is a file
    shell = get_shell_plugin('csh', '/bin/csh')
    assert isinstance(shell, ShellBase)
    assert isinstance(shell.executable, string_types)
    assert shell.executable == '/bin/csh'

# Generated at 2022-06-23 11:08:17.657759
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    assert isinstance(PluginLoader('foo', 'bar'), PluginLoader)

# Generated at 2022-06-23 11:08:23.352547
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():

    result = get_with_context_result(True, 'yes', True, 'yes')
    assert result == 'yes', result

    result = get_with_context_result(False, 'yes', True, 'yes')
    assert result is False, result

    result = get_with_context_result(True, 'yes', False, 'no')
    assert result == 'yes', result

    result = get_with_context_result(False, 'yes', False, 'no')
    assert result == 'no', result

    display.debug = True
    result = get_with_context_result(True, 'yes', False, 'no')
    assert result == 'yes', result

    result = get_with_context_result(False, 'yes', True, 'yes')
    assert result == 'ok', result

    C.PLUGIN_

# Generated at 2022-06-23 11:08:29.228182
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    p = PluginLoader('name', 'pkg', 'cls', 'base', 'subdir')
    assert p.name == 'name'
    assert p.package == 'pkg'
    assert p.class_name == 'cls'
    assert p.base_class == 'base'
    assert p.subdir == 'subdir'



# Generated at 2022-06-23 11:08:38.560438
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    jinja2Loader = Jinja2Loader()
    assert jinja2Loader.package == 'ansible.plugins.filter_loader'
    assert jinja2Loader.subdir == 'filter_plugins'
    assert jinja2Loader.base_paths == [b_('lib/ansible/plugins/filter_loader')]
    assert jinja2Loader.class_name == 'FilterModule'
    assert jinja2Loader.plugin_name_attr == 'FILTER_PLUGIN_CLASS'
    assert jinja2Loader.pkg_name == 'ansible.plugins.filter_loader'
    assert jinja2Loader.config_version == '1.0'
    assert jinja2Loader.deprecated_aliases == {}
    assert jinja2Loader.deprecated_context == []
    assert jin

# Generated at 2022-06-23 11:08:50.531867
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    m = mock.mock_open()
    with mock.patch('ansible.utils.plugin_docs.open', m, create=True):
        testargs = ['ansible-doc']
        with mock.patch.object(sys, 'argv', testargs):
            code, all_output = capsys.readouterr()
            m.assert_called_with(mock.ANY, 'r')

            testargs = ['ansible-doc', '-t', 'action']
            with mock.patch.object(sys, 'argv', testargs):
                code, all_output = capsys.readouterr()
                m.assert_called_with(mock.ANY, 'r')

            testargs = ['ansible-doc', '-t', 'vars']

# Generated at 2022-06-23 11:08:55.420301
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    # Create a sub class to make sure we're calling Display.__repr__()
    class TestClass(PluginLoader):
        def __init__(self):
            pass
    testobj = TestClass()
    testobj._subdirs = ['subdir']
    testobj._package = 'package'
    result = testobj.__repr__()
    assert result is not None, "Testcase failed - expected result not None"

# Generated at 2022-06-23 11:08:58.203717
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    context = PluginLoadContext()
    context.record_deprecation('a', {}, '')
    assert context.deprecated


# Generated at 2022-06-23 11:09:05.639759
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():

    # Test with valid argument(s)
    plugin_loader = PluginLoader("fake_package", "fake_directory", "fake_class_prefix")

    # Test with valid argument(s)
    plugin_loader = PluginLoader("fake_package", "fake_directory", "fake_class_prefix", "fake_base_class")

    # Test with valid argument(s)
    plugin_loader = PluginLoader("fake_package", "fake_directory", "fake_class_prefix", "fake_base_class", "fake_entry_point", )


# Generated at 2022-06-23 11:09:06.240047
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    assert type(get_all_plugin_loaders()) == list



# Generated at 2022-06-23 11:09:07.912154
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    plc = PluginLoadContext()
    plc.record_deprecation('name','deprecation','collection_name')


# Generated at 2022-06-23 11:09:13.432077
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
	# Test PluginLoader.__setstate__ with no args.
	try:
			PluginLoader.__setstate__()
	except TypeError as e:
			assert e, "Missing argument 'self' in __setstate__ of class PluginLoader"

# Generated at 2022-06-23 11:09:19.326256
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    p = PluginLoader('foo', 'class', 'base', 'plugins')
    assert p.package == 'foo'
    assert p.class_name == 'class'
    assert p.base_class == 'base'
    assert p.subdir == 'plugins'

# Unit tests for the globbing of PluginLoader.all()
# Note that these tests are not run with the rest of the unit test suite.  In the future
# they may be moved to a separate file which can be run with nose.

# Generated at 2022-06-23 11:09:31.665293
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type='sh')
    assert(shell.SHELL_FAMILY == 'sh')
    assert(shell.executable == '/bin/sh')
    shell2 = get_shell_plugin(executable='/usr/bin/csh')
    assert(shell.SHELL_FAMILY == 'sh')
    assert(shell.executable == '/bin/sh')
    assert(shell2.SHELL_FAMILY == 'csh')
    assert(shell2.executable == '/usr/bin/csh')
    with warnings.catch_warnings(record=True):
        shell3 = get_shell_plugin(executable='/usr/bin/csh', shell_type='sh')
        assert(shell3.SHELL_FAMILY == 'sh')

# Generated at 2022-06-23 11:09:37.768969
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    plc = PluginLoadContext()
    plc.record_deprecation("This is a name", {"warning_text":"Don't use this", "removal_date":"unset"}, "")
    plc.resolve("this", "a", "", "Foo")
    assert plc.resolved_fqcn == "this"
    assert plc.deprecated == True
    assert plc.removal_date == "unset"
    assert len(plc.deprecation_warnings) == 1
    assert plc.pending_redirect == None
    assert plc.error_list == []
    assert plc.exit_reason == "Foo"



# Generated at 2022-06-23 11:09:44.385699
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    """
    Unit test for constructor of class Jinja2Loader
    """
    jinja2loader = Jinja2Loader('filter_loader', 'ansible.plugins.loader.filter_loader.FilterModule')
    assert jinja2loader.package == 'ansible.plugins.loader.filter_loader'

    # below are for coverage purposes only

    jinja2loader.find_plugin('foo')
    jinja2loader.get('foo')

    assert jinja2loader.all() == []

# Generated at 2022-06-23 11:09:48.221315
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    from ansible.plugins.loader import PluginLoader
    PL = PluginLoader('faketype', 'ansible.plugins.faketype')
    PL.__setstate__({'package': 'ansible.plugins.faketype', 'class_name': 'faketype'})
    assert PL.package == 'ansible.plugins.faketype' and PL.class_name == 'faketype'


# Generated at 2022-06-23 11:09:52.513530
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    path = []
    name = 'lookup'
    plugin_load_context = AnsiblePluginLoadContext(None)
    loader = PluginLoader('lookup')
    assert loader
    # Call the method
    ret = loader.find_plugin(name, path, plugin_load_context)
    assert ret



# Generated at 2022-06-23 11:09:58.475629
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Create an object of class PluginLoader to test
    pluginloader = PluginLoader(
"base_class", 
"package", 
"name", 
"aliases")
    # Test for this method for cases when the plugin doesnt exist
    assert pluginloader.find_plugin("name", "collection_list") == 'True', 'Error - pluginloader.find_plugin() does not work'


# Generated at 2022-06-23 11:10:10.672844
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    
    # Testing default case
    # Arrange
    plugin_loader = PluginLoader('ansible.plugins', 'plugin', C.DEFAULT_CACHE_PLUGIN_PATH)
    collection_list = ['/etc/ansible/roles', '/etc/ansible/collections/ansible_collections/my_collections_one']
    plugin_load_context = PluginLoadContext(name='my_plugin', package='my_package', suffix='module', collection_list=collection_list)
    
    # Act
    plugin_load_context = plugin_loader.find_plugin_with_context('my_plugin', plugin_load_context=plugin_load_context)
    
    # Assert
    assert plugin_load_context.nope is True
    
    # Testing name with . in it
    # Arrange
    plugin

# Generated at 2022-06-23 11:10:18.561634
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    '''
    Test the resolve method of PluginLoadContext class
    '''
    context = PluginLoadContext()
    assert context.resolve('a', 'b', 'c', 'd') == context
    assert context.resolved == True
    assert context.exit_reason == 'd'
    assert context.plugin_resolved_name == 'a'
    assert context.plugin_resolved_path == 'b'
    assert context.plugin_resolved_collection == 'c'
    assert context.pending_redirect == None

# Generated at 2022-06-23 11:10:22.268597
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    from ansible.utils.plugin_docs import get_docstring
    # test a module loader
    plugin_loader = PluginLoader('module_utils', 'AnsibleModule')
    docs = get_docstring(plugin_loader)
    print(docs)


# Generated at 2022-06-23 11:10:29.193966
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():

    # Create mock context for ansible.plugins.cache.base.__init__
    class Context():
        loader = None
        jinja2_additional_directories = None
        jinja2_allowed_undefined_variables = ['hostvars', 'vars', 'group_names']
    context = Context()

    def _load_module_source(name, path):
        from ansible.plugins.filter import core, ipaddr, mathstuff
        from ansible.plugins.test import core, json, mathstuff

        # Create a fake module that we know the jinja2 logic can handle
        class FakeModule():
            FILTERS = core.FILTERS.copy()
            FILTERS.update(ipaddr.FILTERS)
            FILTERS.update(mathstuff.FILTERS)

            TESTS = core

# Generated at 2022-06-23 11:10:41.009991
# Unit test for function get_shell_plugin
def test_get_shell_plugin():

    # when shell_type is not provided we expect shell type to be set to sh
    shell_plugin = get_shell_plugin()
    assert shell_plugin.SHELL_FAMILY == 'sh'

    # when shell_type is None, executable is also none then it should raise exception
    try:
        shell_plugin = get_shell_plugin(None, None)
    except AnsibleError:
        pass

    # when shell_type is None and executable has some valid path then it should return the respective shell
    shell_plugin = get_shell_plugin(None, 'path/to/bash')
    assert shell_plugin.SHELL_FAMILY == 'sh'
    shell_plugin = get_shell_plugin(None, 'path/to/python')
    assert shell_plugin.SHELL_FAMILY == 'python'
    shell_plugin

# Generated at 2022-06-23 11:10:45.751770
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    plugLoadCtx = PluginLoadContext()
    plugLoadCtx.nope("exit_reason")
    assert plugLoadCtx.pending_redirect == None
    assert plugLoadCtx.exit_reason == "exit_reason"
    assert plugLoadCtx.resolved == False



# Generated at 2022-06-23 11:10:49.320927
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # Check that Jinja2Loader.find_plugin will return None if the plugin was not found
    plugin_loader = Jinja2Loader()
    # Check find_plugin with 'name' which does not match.
    assert plugin_loader.find_plugin('name') == None


# Generated at 2022-06-23 11:11:00.945468
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    this_context = PluginLoadContext()
    assert not this_context.error_list
    assert not this_context.import_error_list
    assert not this_context.load_attempts
    assert not this_context.redirect_list
    assert not this_context.resolved
    assert this_context.exit_reason is None
    assert this_context.plugin_resolved_name is None
    assert this_context.plugin_resolved_path is None
    assert this_context.plugin_resolved_collection is None
    assert not this_context.deprecated
    assert this_context.removal_date is None
    assert this_context.removal_version is None
    assert not this_context.deprecation_warnings
    assert not this_context.resolved

# Generated at 2022-06-23 11:11:10.853649
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    ctx            = PluginLoadContext()
    resolved_name  = 'Resolved Plugin Name'
    resolved_path  = 'Resolved Plugin Path'
    resolved_collection = 'Resolved Plugin Collection'
    exit_reason    = 'Exit Reason'
    ctx.resolve(resolved_name, resolved_path, resolved_collection, exit_reason)
    assert ctx.plugin_resolved_name == resolved_name
    assert ctx.plugin_resolved_path == resolved_path
    assert ctx.plugin_resolved_collection == resolved_collection
    assert ctx.exit_reason == exit_reason
    assert ctx.resolved == True


# Generated at 2022-06-23 11:11:23.902428
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Create a temporary directory
    import tempfile
    dir_fd, temp_dir_name = tempfile.mkstemp()
    # Create path to test directory
    test_dir_name = os.path.join(temp_dir_name, self.package, self.subdir)
    # Create test dir
    os.makedirs(test_dir_name)
    # Create test file
    test_file_name = os.path.join(test_dir_name, 'test.py')
    with open(test_file_name, 'a'):
        os.utime(test_file_name, None)
    # Call function
    self.add_directory(test_dir_name)
    # Check that it is included
    assert test_file_name in self._searched_paths
    # Clean up
   

# Generated at 2022-06-23 11:11:28.015630
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin('powershell', '/bin/powershell')
    assert shell.executable == '/bin/powershell'



# Generated at 2022-06-23 11:11:37.159002
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    #Test when user explicitly sets `removal_date` to `~` (None)
    deprecation = {'removal_date': None}
    collection_name = None
    name = 'test'

    plc = PluginLoadContext()
    plc.record_deprecation(name, deprecation, collection_name)
    assert plc.removal_date == None
    assert plc.removal_version == None
    assert plc.deprecation_warnings != []
    assert plc.deprecated == True

    #Test when user explicitly sets `removal_version` to `~` (None)
    deprecation = {'removal_version': None}
    collection_name = None
    name = 'test'

    plc = PluginLoadContext()

# Generated at 2022-06-23 11:11:48.280286
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    from ansible.plugins.loader import action_loader, cache_loader, callback_loader, connection_loader, lookup_loader, inventory_loader, module_loader, callback_loader, shell_loader, terminal_loader, fragment_loader, vars_loader, filter_loader
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.errors import AnsibleError, AnsibleOptionsError, AnsibleUndefinedVariable
    from ansible.module_utils.six.moves import cStringIO
    from ansible import constants as C
    import os
    import sys
    import ansible.constants as C
    import ansible.module_utils.six as six
    import json
    import copy
    import itertools

    module_name = 'setup'

# Generated at 2022-06-23 11:12:00.213666
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    ctx = PluginLoadContext()

    assert ctx.original_name == None
    assert ctx.redirect_list == []
    assert ctx.error_list == []
    assert ctx.import_error_list == []
    assert ctx.load_attempts == []
    assert ctx.pending_redirect == None
    assert ctx.exit_reason == None
    assert ctx.plugin_resolved_path == None
    assert ctx.plugin_resolved_name == None
    assert ctx.plugin_resolved_collection == None
    assert ctx.deprecated == False
    assert ctx.removal_date == None
    assert ctx.removal_version == None
    assert ctx.deprecation_warnings == []
    assert ctx.resolved == False



# Generated at 2022-06-23 11:12:11.402629
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    plugin_loader = PluginLoader(package='ansible.plugins.test', subdir=None, class_name='TestPlugin')

    # test_no_plugin_name_given
    plugin_loader.all = MagicMock()
    plugin_load_context = PluginLoadContext(self_class=plugin_loader, class_name='TestPlugin', module_name='test')
    result = plugin_loader.find_plugin_with_context(name=None, plugin_load_context=plugin_load_context)
    assert result is plugin_load_context

    # test_plugin_name_not_a_string
    plugin_load_context = PluginLoadContext(self_class=plugin_loader, class_name='TestPlugin', module_name='test')

# Generated at 2022-06-23 11:12:21.484055
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    ''' test that find_plugin works when directed to'''


# Generated at 2022-06-23 11:12:33.294593
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    # Check no deprecation
    lc = PluginLoadContext()
    lc.record_deprecation("test", None, None)
    assert not lc.deprecated
    assert not lc.removal_date
    assert not lc.removal_version
    assert not lc.deprecation_warnings
    assert lc.resolved

    # Check with deprecation
    lc = PluginLoadContext()
    lc.record_deprecation("test", {"warning_text": "This is deprecated"}, None)
    assert lc.deprecated
    assert not lc.removal_date
    assert not lc.removal_version
    assert lc.deprecation_warnings
    assert lc.resolved

    # Check with deprecation and removal_version
    lc = PluginLoadContext()


# Generated at 2022-06-23 11:12:41.367133
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    plugin_load_context = PluginLoadContext()
    plugin_load_context.original_name = 'initial_name'
    plugin_load_context.pending_redirect = None
    plugin_load_context.error_list = []
    plugin_load_context.import_error_list = []
    plugin_load_context.load_attempts = []
    plugin_load_context.exit_reason = None
    plugin_load_context.plugin_resolved_path = None
    plugin_load_context.plugin_resolved_name = None
    plugin_load_context.plugin_resolved_collection = None
    plugin_load_context.deprecated = False
    plugin_load_context.removal_date = None
    plugin_load_context.removal_version = None
    plugin_load_context.deprecation_

# Generated at 2022-06-23 11:12:52.416144
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    '''
    This test is a 'unit' test for the unit test code in
    the all method of the Jinja2Loader class.  This method has not been tested
    for side effects.  This test does not attempt to test whether or not the
    modules found in the filesystem are valid Python modules.
    '''
    import tempfile

    # We will create two directories to simulate a collection.
    import ansible.plugins.filter
    import ansible.plugins.test

    test_dir = {}
    test_dir['filter'] = tempfile.mkdtemp()
    test_dir['test'] = tempfile.mkdtemp()

    # We will create a file with multiple plugins inside of it.

# Generated at 2022-06-23 11:12:57.302550
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    a = PluginLoadContext()
    b = a.resolve("b","c","d","e")
    assert a is b
    assert a.pending_redirect is None
    assert a.plugin_resolved_name == "b"
    assert a.plugin_resolved_path == "c"
    assert a.plugin_resolved_collection == "d"
    assert a.exit_reason == "e"
    assert a.resolved == True

# Generated at 2022-06-23 11:13:03.230769
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():

    import os
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create the plugin file
    plugin_dir = os.path.join(tmpdir, 'action_plugins')
    os.makedirs(plugin_dir)
    plugin_file = os.path.join(plugin_dir, 'test_plugin.py')

# Generated at 2022-06-23 11:13:07.751262
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    from ansible.plugins.loader import action_loader # noqa

    module_path = os.path.join(os.path.dirname(__file__), 'test_plugins', 'loader_add_dirs_to_loader')
    add_dirs_to_loader(which_loader='action', paths=[module_path])

    assert('dummy' in action_loader.all())



# Generated at 2022-06-23 11:13:20.547133
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    _plugins = Jinja2Loader()
    _plugins.add_directory(DATA_DIR)
    p = _plugins.get('systemd.downtime_format')
    assert p.name == 'downtime_format'
    assert p.applies_to_callables == 'downtime_format'
    assert p.docs == """\
Strip timezone offset from systemd downtime format

This was added in Ansible 2.5, released in 2017-06-29
"""
    p = _plugins.get('systemd.downtime_format', class_only=True)
    assert p.__class__.__name__ == 'FilterModule'
    assert p.__class__.__module__ == 'ansible.plugins.filter.systemd'

# Generated at 2022-06-23 11:13:28.592074
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    # Test1: invoke constructor when path is a string
    plugin_path = PluginPathContext("/usr/share/ansible/plugins/modules", False)
    assert plugin_path.path == "/usr/share/ansible/plugins/modules"
    assert plugin_path.internal is False
    # Test2: invoke constructor when path is a list
    plugin_path = PluginPathContext("/usr/share/ansible/plugins/modules", False)
    assert plugin_path.path == "/usr/share/ansible/plugins/modules"
    assert plugin_path.internal is False



# Generated at 2022-06-23 11:13:33.741253
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    jl = Jinja2Loader('ansible.legacy', 'filter_plugin', 'AnsibleFilterModule')
    assert jl.find_plugin(name='misc.json') == [
        "/usr/lib/python3.6/site-packages/ansible/plugins/filter/misc.py"
        ]


# Generated at 2022-06-23 11:13:44.397622
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    context = PluginLoadContext()
    assert context.original_name is None
    assert context.redirect_list == []
    assert context.error_list == []
    assert context.import_error_list == []
    assert context.load_attempts == []
    assert context.pending_redirect is None
    assert context.exit_reason is None
    assert context.plugin_resolved_path is None
    assert context.plugin_resolved_name is None
    assert context.plugin_resolved_collection is None
    assert context.deprecated is False
    assert context.removal_date is None
    assert context.removal_version is None
    assert context.deprecation_warnings == []
    assert context.resolved is False
    assert context._resolved_fqcn is None


# Generated at 2022-06-23 11:13:56.006569
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    class MockPluginLoader(object):
        def __init__(self):
            self.subdir = ''
            self.directories = []

        def add_directory(self, directory):
            self.directories.append(directory)

    obj = MockPluginLoader()
    globals()['MockPluginLoader'] = obj

    plugin_path = '/path/to/mock/plugins'
    b_path = os.path.expanduser(to_bytes(plugin_path, errors='surrogate_or_strict'))
    os.makedirs(b_path)
    try:
        add_all_plugin_dirs(plugin_path)
        assert obj.directories[0] == plugin_path
    finally:
        os.rmdir(b_path)



# Generated at 2022-06-23 11:14:02.668493
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Create a PluginLoader object
    aaaaaaaaaa_obj = PluginLoader(
        class_name = 'aaaaaaaaaa',
        package = 'aaaaaaaaaa',
        config = 'aaaaaaaaaa',
    )

    # Test add_directory raises an exception
    with pytest.raises(AnsibleError):
        aaaaaaaaaa_obj.add_directory('aaaaaaaaaa')
    # Test add_directory returns the correct value
    assert aaaaaaaaaa_obj.add_directory('aaaaaaaaaa') is None


# Generated at 2022-06-23 11:14:06.430274
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():

    result = PluginLoader.format_paths(['/', '/path/to/somewhere'])
    assert result == "/:/path/to/somewhere"


# Generated at 2022-06-23 11:14:16.230650
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    PLUGIN_PATHS = ['plugins', '/usr/share/ansible_plugins']
    CACHE = {}
    MULTIPLIER = '_'
    DEDUPE_SCOPES = [
        '_get_cache',
        '_get_scope_paths_list',
        '_get_paths',
        '_get_global_scope_path',
    ]
    BASE_CLASS = None
    CLASS_NAME = 'ActionModule'
    MODULE_PATH = 'ansible.plugins.action'

    # PluginLoader object testing
    pluginloader = PluginLoader(
        PLUGIN_PATHS,
        CACHE,
        MULTIPLIER,
        DEDUPE_SCOPES,
        BASE_CLASS,
        CLASS_NAME,
        MODULE_PATH
    )



# Generated at 2022-06-23 11:14:27.996256
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Define global var for test
    global _PLUGIN_PATH_CACHE
    # plugin_name, plugin_path, alias
    test_data = [
        ('inventory', 'ansible/plugins/inventory/test.yaml', 'test-data'),
        ('easy_filter_plugin', 'ansible/plugins/filter/easy_filter_plugin.py', 'easy_filter_plugin'),
        ('doc_fragments', 'ansible/plugins/doc_fragments/easy_plugin.py', 'doc_fragments'),
    ]

    def fake_all_plugin_paths(self, conf=None):
        return_value =[]
        dirs = []
        # Build plugin path
        display.debug('Build plugin path in cache')

# Generated at 2022-06-23 11:14:36.837226
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    # create a plugin load context object
    obj = PluginLoadContext()

    # call method redirect of class PluginLoadContext
    new_obj = obj.redirect('redirect_name')

    # now the two object should be the same since redirect is a pure function
    # and new_obj should be an instance of PluginLoadContext

    assert new_obj == obj
    assert isinstance(new_obj, PluginLoadContext)
    assert new_obj.pending_redirect == 'redirect_name'
    assert new_obj.exit_reason == 'pending redirect resolution from None to redirect_name'
    assert new_obj.resolved == False


# Generated at 2022-06-23 11:14:38.681389
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    b = PluginLoadContext()
    assert b.resolve("name","path","collection",'exit_reason') == b


# Generated at 2022-06-23 11:14:42.377616
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    context = PluginPathContext('/foo/bar/', False)
    assert context.path == '/foo/bar/'
    assert context.internal is False



# Generated at 2022-06-23 11:14:52.468677
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
  # path_resolve_load_context
  from ansible.module_utils.common.collections import path_resolve_load_context
  PRLC = path_resolve_load_context

  # create test plugin collections

# Generated at 2022-06-23 11:14:54.159863
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    raise SkipTest()


# Generated at 2022-06-23 11:14:59.912561
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert path_loader.all()==[]
    paths=[os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test', 'plugins')]
    add_dirs_to_loader('path', paths)
    assert path_loader.all()!=[]
    path_loader.clear()



# Generated at 2022-06-23 11:15:03.165263
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    '''
    Make sure PluginLoader can __getstate__ w/o exception
    '''
    l = PluginLoader('foo', 'bar')
    l.__getstate__()


# Generated at 2022-06-23 11:15:06.197998
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test if we can map a given plugin name to a path.

    loader = PluginLoader('cli', 'CallbacksModule')
    # Success for valid plugins
    assert loader.find_plugin('CLICommon')
    assert loader.find_plugin('help_command')
    # Failure for valid plugins
    assert loader.find_plugin('does_not_exist')

# Generated at 2022-06-23 11:15:15.797837
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():

    plugins_found = {name: obj for (name, obj) in globals().items() if isinstance(obj, PluginLoader)}

    # Test that all plugins found in the globals() dictionary
    # also register with get_all_plugin_loaders
    assert plugins_found == get_all_plugin_loaders()

    # Ensure that all plugins that register with get_all_plugin_loaders
    # are also in the globals() dictionary
    for name, loader in get_all_plugin_loaders():
        assert name in globals()
        assert globals()[name] == loader
# Unit test get_all_plugin_loaders



# Generated at 2022-06-23 11:15:27.280692
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    ctx = PluginLoadContext()
    ctx.original_name = 'test'
    assert not ctx.resolved
    assert ctx.exit_reason is None
    assert ctx.pending_redirect is None
    assert ctx.plugin_resolved_name is not 'test'
    assert ctx.plugin_resolved_path is None
    assert ctx.plugin_resolved_collection is None
    ctx.nope('test_reason')
    assert not ctx.resolved
    assert ctx.exit_reason == 'test_reason'
    assert ctx.pending_redirect is None
    assert not ctx.plugin_resolved_name == 'test'
    assert ctx.plugin_resolved_path is None
    assert ctx.plugin_resolved_collection is None


# Generated at 2022-06-23 11:15:28.226330
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    get_all_plugin_loaders()



# Generated at 2022-06-23 11:15:40.506765
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin(): # pylint: disable=C0116
    def assert_Jinja2Loader_find_plugin(plugin_name, expected_plugin_name, expected_result, expected_plugin_path):
        # pylint: disable=C0103
        test_plugin_name, result, plugin_path = Jinja2Loader._find_plugin('test-loader', plugin_name, [])
        assert test_plugin_name == expected_plugin_name
        assert result == expected_result
        assert plugin_path == expected_plugin_path

        #NOTE: We are testing a private method here
        #pylint: disable=W0212

        # This logic is more complex than other plugins because a jinja2 plugin can be in
        # any ansible plugin file, this includes collection plugins.

        # We want to test the following cases
        #   1. plugin

# Generated at 2022-06-23 11:15:47.781106
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    plc = PluginLoadContext()
    plc.original_name = 'original_name'
    plc.redirect('redirect_name')
    assert plc.pending_redirect == 'redirect_name'
    assert plc.exit_reason == 'pending redirect resolution from original_name to redirect_name'
    assert not plc.resolved



# Generated at 2022-06-23 11:15:48.856643
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    assert False


# Generated at 2022-06-23 11:15:57.720185
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    call_args = [("foo",), ("bar",), ("baz",)]
    call_def = ["foo", "bar/", "baz"]

    # test _defined_search_paths
    def_path = PluginLoader._defined_search_paths()
    assert(def_path == [os.path.join(t, "ansible") for t in C.DEFAULT_LOOKUP_PLUGIN_PATH])

    # test format_paths
    formatted_paths = PluginLoader.format_paths(call_def)
    assert(formatted_paths == call_args)

    # test _get_paths
    paths = PluginLoader._get_paths()
    assert(paths == def_path)

    # test print_paths
    display_paths = PluginLoader.print_paths()


# Generated at 2022-06-23 11:16:01.540495
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    loader = Jinja2Loader()
    assert loader.find_plugin('asdf') == [], 'asdf should not exist in any jinja2 loader'



# Generated at 2022-06-23 11:16:14.087627
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    args = dict(
        package='package',
        subdir='subdir',
        class_name='class_name',
        aliases=dict(),
        plugin_dirs=list,
    )
    o = PluginLoader(**args)
    o.package = 'new_value'
    o.subdir = 'new_value'
    o.class_name = 'new_value'
    o.aliases = dict()
    o.plugin_dirs = list
    o.config_info = dict()
    o.pkg_info = dict()
    o._package_parts = list()
    o._collection_dirs = list()
    o._searched_paths = list()
    o._module_cache = dict()
    o._finder_cache = dict()


# Generated at 2022-06-23 11:16:17.800759
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    plc = PluginLoadContext()
    plc.nope('just say no')
    assert not plc.resolved
    assert plc.exit_reason == 'just say no'
    assert plc.pending_redirect is None


# Generated at 2022-06-23 11:16:29.426583
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    plugin_loader = PluginLoader("unit", "test", "properties", "constructor")

    # Check for the base variables which were set
    assert type(plugin_loader.package) is str
    assert plugin_loader.package == 'unit'
    assert type(plugin_loader.base_class) is str
    assert plugin_loader.base_class == 'test'
    assert type(plugin_loader.subdir) is str
    assert plugin_loader.subdir == 'properties'
    assert type(plugin_loader.class_name) is str
    assert plugin_loader.class_name == 'constructor'

    # Check for the other variables when they are not supplied in the constructor.
    assert type(plugin_loader.config_options) is list
    assert type(plugin_loader.config_options_snake_case) is list

# Generated at 2022-06-23 11:16:41.913179
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    '''
    Unit test for method find_plugin of class Jinja2Loader
    '''
    def _get_file_call_count(mock_get_plugin_paths):
        '''
        Get the call count of get_plugin_paths mock
        '''
        return len(mock_get_plugin_paths.call_args_list)

    # We do not mock the imports.  If you modify the imports, please update this test as well.
    # Any failure will result in the message: module '<module>' has no attribute '<attribute>'
    from ansible.plugins import test_loader

    class PluginLoaderFindPluginTestCase(unittest.TestCase):
        '''
        Test case for the find_plugin method of the Jinja2Loader class
        '''

# Generated at 2022-06-23 11:16:53.019573
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    """
    Verify that a PluginLoader object can be serialized using the pickle module.

    The method to be tested is __getstate__, which returns a dictionary of the contents of
    self.vars.

    The test discovers a valid plugin module and creates a PluginLoader object to load the
    plugin.

    The test serializes the PluginLoader object to a string and reloads it to verify that
    the load was successful.

    The test verifies that the expected exception is raised when a PluginLoader object is
    serialized using the deepcopy module.
    """
    # pylint: disable=import-error,unused-variable,too-many-locals,too-many-nested-blocks
    from ansible.plugins.loader import action_loader, connection_loader, module_loader
    from ansible.utils.plugin_docs import get_docstring



# Generated at 2022-06-23 11:17:04.719239
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.plugins.loader import PluginLoader

    # 1. Test PluginLoader.all with path_only return all plugin files
    plugin_path = os.path.join(os.path.dirname(__file__), "..", "..", "lib", "plugins")
    PL = PluginLoader("module_utils", "ansible.module_utils.module_common", "ansible.module_utils")
    PL._add_directory(plugin_path)
    all_module_utils = list(PL.all(path_only=True))
    all_module_utils_files = [os.path.basename(x) for x in all_module_utils]

# Generated at 2022-06-23 11:17:05.433142
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    pass

# Generated at 2022-06-23 11:17:09.803995
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    action_loader = PluginLoader('ActionModule', 'ansible.plugins.action', C.DEFAULT_ACTION_PLUGIN_PATH, 'action_plugins')
    result = action_loader.__setstate__('test_PluginLoader___setstate__')
    assert result == None


# Generated at 2022-06-23 11:17:18.654025
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    test_dir = 'test_dir'
    test_class = 'test_class'
    test_base_class = 'test_base_class'
    test_package = 'test_package'
    test_name = 'test_name'
    test_name_with_collection = 'collec.test_name'

    test_loader = Jinja2Loader(test_dir, test_class, test_base_class, test_package)
    assert test_loader.package == test_package
    assert test_loader.class_name == test_class
    assert test_loader.base_class == test_base_class
    assert test_loader.subdir == test_class + '_plugins'

    test_error = "No code should call 'get' for Jinja2Loaders (Not implemented)"

# Generated at 2022-06-23 11:17:20.454694
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    assert 'get_all_plugin_loaders' in globals()



# Generated at 2022-06-23 11:17:29.361034
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    redirect_name = "redirected_name"
    exit_reason = "can't find the plugin"
    plc = PluginLoadContext()
    plc = plc.redirect(redirect_name)
    plc = plc.nope(exit_reason)
    # new exit reason for the same name
    assert plc.exit_reason == "can't find the plugin"
    # new load attempt on the same name
    assert plc.load_attempts[-1][1] == "can't find the plugin"
    # new error list on the same name
    assert plc.error_list[-1][1] == "can't find the plugin"
    # should have been marked as resolved
    assert plc.resolved is False
    # should clear out pending redirect

# Generated at 2022-06-23 11:17:39.614260
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Example: [AnsiblePluginLoader('action_plugin', os.path.join(self.path, 'action_plugins')),
    # Example: AnsiblePluginLoader('become', os.path.join(self.path, 'become_plugins'))]
    my_loader = PluginLoader(class_name='MyClassName', package='my_loader_package', subdir='my_loader_subdir')
    # Parameter 'name' is the default name of an object passed to the function
    name = 'my_plugin'
    # Parameter 'extension' is the default name of an object passed to the function
    extension = '.py'

    # Parameter 'plugin_load_context' is the default name of an object passed to the function
    plugin_load_context = PluginLoadContext(**{'search_paths': {}, })



# Generated at 2022-06-23 11:17:47.951226
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    warning_text = 'invalid_argument has been deprecated. Action plugins must be named <action>.py'

    ctx = PluginLoadContext()
    ctx.record_deprecation('invalid_argument', {'warning_text': 'Action plugins must be named <action>.py'}, None)
    assert len(ctx.deprecation_warnings) == 1
    assert ctx.deprecation_warnings[0] == warning_text

    ctx = PluginLoadContext()
    ctx.record_deprecation('invalid_argument', {'warning_text': None}, None)
    assert len(ctx.deprecation_warnings) == 1
    assert ctx.deprecation_warnings[0] == 'invalid_argument has been deprecated. '

    ctx = PluginLoadContext()
    ctx.record_deprec