

# Generated at 2022-06-23 11:07:45.348120
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    instance = PluginLoadContext()
    assert instance.resolved_fqcn == None
    assert instance.resolve("resolved_name", "resolved_path", "resolved_collection", "exit_reason").resolved_fqcn == "resolved_name"


# Generated at 2022-06-23 11:07:47.509185
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    with pytest.raises(Exception):
        get_with_context_result(None)


# Generated at 2022-06-23 11:07:52.908981
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    ctx = PluginLoadContext()
    assert ctx.exit_reason is None
    ctx.resolve('test_resolve', 'test_resolve_path', None, 'test_reslove_exit')
    assert ctx.exit_reason == 'test_reslove_exit'
    assert ctx.resolved_fqcn == 'test_resolve'


# Generated at 2022-06-23 11:07:56.742678
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    class TestPluginLoader(PluginLoader):
        pass

    plugin_loader = TestPluginLoader()
    plugin_loader.print_paths()


# This is the unit test for class PluginLoader
#
# TODO: Move these to test/units/test_loader.py

# Generated at 2022-06-23 11:08:00.405653
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    '''
    Test plugin loader __getstate__
    '''
    obj = PluginLoader('_test', 'stub', C.get_config(parsed=False, variables=dict(DEFAULT_CACHE_PLUGIN='memory')))
    obj.__getstate__()
    assertTrue(True)

# Generated at 2022-06-23 11:08:01.570502
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    ctx = PluginLoadContext()
    assert ctx.resolved_fqcn is None



# Generated at 2022-06-23 11:08:05.052394
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    jl = Jinja2Loader('ansible.plugins.action', 'ActionModule', 'ansible.plugins.action.ActionBase')
    # TODO: why does adding this make this test work?
    from ansible.plugins.action import ActionBase
    # TODO: write some tests for this
    # TODO: this test is failing because there is no testing/test_action_testcase.py file.
    #       There may be other similar failures
    # obj = jl.get('testcase')



# Generated at 2022-06-23 11:08:13.410643
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    PLUGIN_PATH = '/my/path/'
    NAME = 'name'
    PLUGIN_PATH_LIST = ['/path/to/plugins', PLUGIN_PATH]
    plugin_loader = PluginLoader(NAME, PLUGIN_PATH, '', '', '', PLUGIN_PATH)
    plugin_loader.__setstate__({'_searched_paths': PLUGIN_PATH_LIST,
                                '_module_cache': {},
                                'class_name': None,
                                'package': None,
                                'base_class': None})
    assert plugin_loader._searched_paths == PLUGIN_PATH_LIST
    assert plugin_loader._module_cache == {}
    assert plugin

# Generated at 2022-06-23 11:08:16.107478
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    assert PluginLoadContext().nope('exit_reason').resolved is False


# Generated at 2022-06-23 11:08:25.311168
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    # Testing for a valid shell
    shell = get_shell_plugin('sh')
    assert shell._load_name == 'sh'

    # Testing for an invalid shell, this should raise an error
    with pytest.raises(AnsibleError, match='Either a shell type or a shell executable must be provided '):
        get_shell_plugin()

    # Testing for an invalid shell, this should raise an error
    with pytest.raises(AnsibleError, match='Could not find the shell plugin required '):
        get_shell_plugin('bogus')

# ***** CONNECTION PLUGINS *****

# For efficiency, we use a single module, connections/__init__.py,
# to load all of the base connection plugins
from ansible.plugins.connection.__init__ import ConnectionBase, connection_loader

# ****

# Generated at 2022-06-23 11:08:34.556560
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # PluginLoader.find_plugin()

    # Test with a valid plugin name
    plugin_load_context = PluginLoader(None).find_plugin_with_context('example')
    assert not plugin_load_context.resolved
    assert not plugin_load_context.direct
    assert not plugin_load_context.redirected
    assert not plugin_load_context.plugin_resolved_name
    assert not plugin_load_context.plugin_resolved_path
    assert not plugin_load_context.redirect_list

    # Test with a valid plugin name
    plugin_load_context = PluginLoader(None).find_plugin_with_context('action')
    assert plugin_load_context.resolved
    assert not plugin_load_context.direct
    assert not plugin_load_context.redirected

# Generated at 2022-06-23 11:08:41.093482
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    loader = PluginLoader("test_plugins")
    paths = [
        "/home/foo/bar",
        "/some/other/path",
        "/home/foo/bar"
    ]
    result = loader.format_paths(paths)
    assert result == "/home/foo/bar, /some/other/path"


# Generated at 2022-06-23 11:08:45.307313
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    resolved_name = 'resolved'
    resolved_path = 'path'
    resolved_collection = 'collection'
    exit_reason = 'exit'
    plc = PluginLoadContext()
    result = plc.resolve(resolved_name, resolved_path, resolved_collection, exit_reason)
    if not result.resolved:
        raise Exception('unit test failed')


# Generated at 2022-06-23 11:08:48.429525
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    obj = PluginLoader(class_name = 'foo', package = 'bar', config = None, subdir = 'foo')
    obj = PluginLoader(class_name = 'foo', package = 'bar', config = None, subdir = 'foo')
    state = {}
    obj.__setstate__(state)
    return True # passed



# Generated at 2022-06-23 11:08:53.701370
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    j2 = Jinja2Loader()
    assert j2 is not None


# Generated at 2022-06-23 11:08:55.483253
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    # FIXME: remove this test once all plugin loader subclasses are tested
    pass


# Generated at 2022-06-23 11:08:58.969963
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    '''Tests for plugins.add_all_plugin_dirs'''
    path = os.path.dirname(__file__)
    add_all_plugin_dirs(path)



# Generated at 2022-06-23 11:08:59.677224
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    pass


# Generated at 2022-06-23 11:09:04.679629
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    context = PluginLoadContext()
    result = context.resolve("resolved_name","resolved_path","resolved_collection","exit_reason")
    if result.resolved != True:
        print("Method resolve of class PluginLoadContext does not work as expected.")
    else:
        print("Unit test for method resolve of class PluginLoadContext passed.")


# Generated at 2022-06-23 11:09:12.275788
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    PL = PluginLoader("plugins", C.DEFAULT_MODULE_PATH, [], 'modules')
    PL.aliases['test_alias'] = 'test_module'
    PL.add_directory("test_path")
    PL.load_collections("test_collections_paths")

    deprecation_message = ("The 'test_obj_with_deprecation' parameter is no longer supported and its value has been "
                           "ignored.  It will be completely removed in version 2.11.  See https://github.com/ansible/"
                           "community/blob/devel/migrations/2.10.yml for migration instructions.")

    # Test 1 - Unit test to check function with specific parameter
    result = PL.get("test_module", foo="foo", bar="bar")
    assert result._load_name

# Generated at 2022-06-23 11:09:15.943991
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    context = PluginLoadContext()
    context.original_name = "context.original_name"
    redirect_name = "context.redirect_name"
    context.redirect(redirect_name)
    assert context.original_name == "context.original_name"
    assert context.redirect_list == []
    assert context.pending_redirect == "context.redirect_name"
    assert context.exit_reason == 'pending redirect resolution from context.original_name to context.redirect_name'
    assert context.resolved == False



# Generated at 2022-06-23 11:09:20.535001
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    assert PluginLoader('').format_paths([]) == '[]'
    assert PluginLoader('').format_paths(['/home/test']) == "['/home/test']"
    assert PluginLoader('').format_paths(['/home/test', '/home/test2']) == "['/home/test', '/home/test2']"


# Generated at 2022-06-23 11:09:32.669860
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():

    # Mock the loader
    mock_module = Mock(module_utils.plugins.loader.AnsibleModule)
    mock_module.ansible = Mock(module_utils.plugins.loader.AnsibleModule.ansible)
    mock_module.ansible.collection.collections = Mock(module_utils.plugins.loader.AnsibleModule.ansible.collection.collections)
    mock_module.ansible.collection.collections.root_paths = Mock(module_utils.plugins.loader.AnsibleModule.ansible.collection.collections.root_paths)
    mock_module.ansible.collection.collections.root_paths.return_value = ['/home/user1/collections']

# Generated at 2022-06-23 11:09:35.260964
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader.
    '''
    # Unimplemented
    pass

# Generated at 2022-06-23 11:09:46.950399
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plugin_load_context = PluginLoadContext()
    assert plugin_load_context.original_name == None
    assert plugin_load_context.redirect_list == []
    assert plugin_load_context.error_list == []
    assert plugin_load_context.import_error_list == []
    assert plugin_load_context.load_attempts == []
    assert plugin_load_context.pending_redirect == None
    assert plugin_load_context.exit_reason == None
    assert plugin_load_context.plugin_resolved_path == None
    assert plugin_load_context.plugin_resolved_name == None
    assert plugin_load_context.plugin_resolved_collection == None
    assert plugin_load_context.deprecated == False
    assert plugin_load_context.removal_date == None
    assert plugin

# Generated at 2022-06-23 11:09:57.144679
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    # Test with a non-existant plugin
    loader = PluginLoader('test', 'test_dir')
    with pytest.raises(AnsibleError):
        loader.get('doesnotexist')

    # Test with a 'path_only=True' plugin
    loader = PluginLoader('test', 'test_dir')
    with pytest.raises(AnsibleError):
        loader.get('doesnotexist', path_only=True)

    # Test with a 'class_only=True' plugin
    loader = PluginLoader('test', 'test_dir')
    with pytest.raises(AnsibleError):
        loader.get('doesnotexist', class_only=True)

    # Test with a non-existant plugin and a non-existant default
    loader = PluginLoader('test', 'test_dir')

# Generated at 2022-06-23 11:10:04.998784
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    from ansible.plugins.loader import Jinja2Loader

    loader = Jinja2Loader(paths=[__file__])
    plugins = loader.all()

    assert len(plugins) == 3

    # test selection via plugin_type
    plugin_names = list()
    for plugin in plugins:
        plugin_names.append(plugin.__name__)

    assert 'TestPluginClass' in plugin_names
    assert 'TestFilterClass' in plugin_names
    assert 'TestTestClass' in plugin_names

# Generated at 2022-06-23 11:10:06.776214
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    raise SkipTest  # TODO: implement your test here

# Generated at 2022-06-23 11:10:15.417079
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # test plugin_packages as string
    plugin_loader = PluginLoader(package='ansible.plugins', class_name='ModuleUtil')
    assert len(plugin_loader._extra_dirs) == 0
    plugin_loader.add_directory(directory='plugins/module_utils')
    assert len(plugin_loader._extra_dirs) == 1
    assert 'plugins/module_utils' in plugin_loader._extra_dirs

    # test plugin_packages as list
    plugin_loader = PluginLoader(package='ansible.plugins', class_name='ModuleUtil')
    plugin_loader.add_directory(directory=['plugins/module_utils'])
    assert len(plugin_loader._extra_dirs) == 1
    assert 'plugins/module_utils' in plugin_loader._extra_dirs

    # test plugin_packages as list,

# Generated at 2022-06-23 11:10:17.983394
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    obj = PluginPathContext('/path/to/plugins', False)
    assert obj.path == '/path/to/plugins'
    assert obj.internal == False


# Generated at 2022-06-23 11:10:26.317149
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    context = PluginLoadContext()
    assert context.__dict__ == {
        'original_name': None,
        'redirect_list': [],
        'error_list': [],
        'import_error_list': [],
        'load_attempts': [],
        'pending_redirect': None,
        'exit_reason': None,
        'plugin_resolved_path': None,
        'plugin_resolved_name': None,
        'plugin_resolved_collection': None,
        'deprecated': False,
        'removal_date': None,
        'removal_version': None,
        'deprecation_warnings': [],
        'resolved': False,
        '_resolved_fqcn': None,
    }


# Generated at 2022-06-23 11:10:30.608540
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
  # FIXME: This test code should be moved to a dedicated unit test file.
  # FIXME: Implement a real unit test here.
  arg = {}
  obj = PluginLoader(arg)
  obj.__contains__()
  pass


# Generated at 2022-06-23 11:10:41.700458
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    # Test
    pl = PluginLoader(b'foo', 'foo.plugins')
    pl.collection_list = CollectionLoader()
    pl.collection_list.collections = [
        {
            b"name": b"test.namespace",
            b"version": b"1.2.3",
            b"path": b"/test_collections/test.namespace-1.2.3"
        }
    ]
    pl.search_paths = [
        '/test_collections',
        '/other_test_collections'
    ]
    pl._searched_paths = [
        '/test_collections',
        '/other_test_collections'
    ]

# Generated at 2022-06-23 11:10:47.284957
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    cwd = os.getcwd()
    try:
        os.chdir(os.path.dirname(os.path.dirname(__file__)))
        for attr in PluginLoader.get_all_plugin_loaders():
            loader = PluginLoader(attr, 'ansible_collections.my_namespace.my_collection.plugins.modules')
            ls_all = os.listdir(loader._get_paths()[0])
            for f in ls_all:
                plugin = loader.get(os.path.splitext(f)[0])
                assert plugin is not None
                assert getattr(plugin, '_load_name') == os.path.splitext(f)[0]
    finally:
        os.chdir(cwd)


# Generated at 2022-06-23 11:10:52.264347
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    plugin_loader = PluginLoader('module_utils', 'ansible.module_utils')
    orig_stdout = sys.stdout
    sys.stdout = captured = io.StringIO()
    plugin_loader.print_paths()
    sys.stdout = orig_stdout
    assert captured.getvalue() == "search path = ['./_tmp/ansible_module_utils']\n"


# Generated at 2022-06-23 11:10:59.341823
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    import ansible.plugins.loader

    # Test when the plugin exists
    loader = ansible.plugins.loader.PluginLoader('action_plugin', 'ActionModule')
    assert 'copy' in loader

    # Test when the plugin does not exist
    loader = ansible.plugins.loader.PluginLoader('action_plugin', 'ActionModule')
    assert 'not_a_real_plugin' not in loader

# Generated at 2022-06-23 11:11:11.246451
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.module_utils.six import iteritems

    # Define the two test classes to be returned by the PluginLoader all method
    class TestClass(object):
        def __init__(self, name, args, kwargs):
            self.name = name
            self.args = args
            self.kwargs = kwargs

    class OtherClass(object):
        def __init__(self, name, args, kwargs):
            self.name = name
            self.args = args
            self.kwargs = kwargs
    # Define the classes that are used by the PluginLoader all method
    class_name = 'TestClass'
    base_class = 'OtherClass'
    package = 'ansible.plugins.test'
    subdir = 'test_plugins'
    # Define the arguments to be passed to the

# Generated at 2022-06-23 11:11:12.986388
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    j2l = Jinja2Loader()



# Generated at 2022-06-23 11:11:25.585308
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    from ansible.errors import AnsibleError
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible_collections.ansible.community.tests.unit.compat import unittest

    class TestJinja2Loader(unittest.TestCase):
        def setUp(self):
            self.display = Display()

        def tearDown(self):
            pass

        def test_get_TypeError(self):
            try:
                myjson = Jinja2Loader(None, {'fail': True}, 'ansible.poc.plugins.filter', 'FilterModule')
            except TypeError as exc:
                self.assertIsInstance(exc, TypeError)
                return
            self.fail('Expected TypeError from Jinja2Loader constructor')


# Generated at 2022-06-23 11:11:35.502649
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    a = get_with_context_result(1, 2)
    assert (a.result == 1) and (a.context == 2)


# Instantiate all the plugin objects

# Cache the list so we can iterate over it in a separate thread.
# In a future release, we'll move this to a separate init method
# and do it in a separate thread so that we don't delay the startup
# time of ansible-playbook
action_plugins = list(filter_loader.all())
action_plugins += list(action_loader.all(_PLUGIN_FILTERS.get('ansible.plugins.action', frozenset())))

all_callback_plugins = list(callback_loader.all())


# Generated at 2022-06-23 11:11:39.394410
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    plugin_path_context = PluginPathContext("/tmp", False)
    assert plugin_path_context.path == "/tmp"
    assert plugin_path_context.internal == False


# Generated at 2022-06-23 11:11:47.504237
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    '''Ensure the correct items are returned by get_all_plugin_loaders()'''
    valid_items = ['action_loader', 'cache_loader', 'callback_loader', 'connection_loader', 'filter_loader',
                   'lookup_loader', 'shell_loader', 'strategy_loader', 'test_loader', 'vars_loader']

    loaders = [(name, item) for name, item in globals().items() if isinstance(item, PluginLoader)]

    assert set([item[0] for item in loaders]) == set(valid_items)



# Generated at 2022-06-23 11:11:51.077122
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    from ansible.plugins.loader import get_with_context_result
    results = [{'foo': 'bar'}, None, 'a']

    for in_result in results:
        for context in [None, 'a']:
            with_context = get_with_context_result(in_result, context)

            # make sure we got a dict back
            assert isinstance(with_context, dict)

            # make sure we did not modify the input
            assert in_result == with_context

            # check the value of the context key
            assert with_context['context']['name'] == context
            assert with_context['foo'] == 'bar'



# Generated at 2022-06-23 11:11:54.572320
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    test_result = get_with_context('ansible.plugins.actions', 'ActionModule', C.DEFAULT_ACTION_PLUGIN_PATH, 'action_plugins', 'ActionBase')
    display.debug(to_text(test_result))

    display.debug(to_text(action_loader.get('script')))
    display.debug(to_text(action_loader.get('copy')))

    display.debug(to_text(action_loader.all()))

    display.debug(to_text(action_loader.has('copy')))
    display.debug(to_text(action_loader.has('action_')))

# Generated at 2022-06-23 11:11:57.780306
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    b_path = to_bytes(u'Test', errors='surrogate_or_strict')
    path = to_text(b_path)

    pluginPathContext = PluginPathContext(path, False)
    assert pluginPathContext.path == path
    assert not pluginPathContext.internal


# Generated at 2022-06-23 11:12:06.422302
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plc = PluginLoadContext()
    assert plc.original_name == None
    assert plc.redirect_list == []
    assert plc.error_list == []
    assert plc.import_error_list == []
    assert plc.load_attempts == []
    assert plc.pending_redirect == None
    assert plc.exit_reason == None
    assert plc.plugin_resolved_path == None
    assert plc.plugin_resolved_name == None
    assert plc.deprecated == False
    assert plc.removal_date == None
    assert plc.removal_version == None
    assert plc.deprecation_warnings == []
    assert plc.resolved == False
    assert plc._resolved_fqcn == None



# Generated at 2022-06-23 11:12:17.886870
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    ctx = PluginLoadContext()

    assert ctx.original_name == None
    assert ctx.redirect_list == []
    assert ctx.error_list == []
    assert ctx.import_error_list == []
    assert ctx.load_attempts == []
    assert ctx.pending_redirect == None
    assert ctx.exit_reason == None
    assert ctx.plugin_resolved_path == None
    assert ctx.plugin_resolved_name == None
    assert ctx.plugin_resolved_collection == None
    assert ctx.deprecated == False
    assert ctx.removal_date == None
    assert ctx.removal_version == None
    assert ctx.deprecation_warnings == []
    assert ctx.resolved == False



# Generated at 2022-06-23 11:12:24.887468
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    from ansible.utils.display import Display
    from ansible.utils.plugin_docs import get_docstring
    from ansible.config import get_config
    from ansible.errors import AnsibleError

    display = Display()
    config = get_config(display, [])
    plugin_loader = Jinja2Loader(class_name='FilterModule')

    plugin_loader._get_paths = lambda: [os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'units', 'lib', 'ansible_test_plugins')]

    # Test the case where we don't specify args or kwargs.
    plugins = plugin_loader.all()
    assert len(plugins) == 2  # One file has 2 plugins inside it.
    # We could test what's inside the plugin objects but that

# Generated at 2022-06-23 11:12:33.882833
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # Prepare test environment
    (fd, new_plugin_path) = tempfile.mkstemp()
    os.close(fd)
    plugin_name = 'test_plugin'
    plugin = dedent(
        '''
        import sys
        import os
        import operator
        import datetime

        _filter_plugins = {}
        _test_plugins = {}

        class FilterModule(object):
            def filters(self):
                return _filter_plugins

        class TestModule(object):
            def tests(self):
                return _test_plugins

        def test_plugin(a, b):
            now = datetime.datetime.now()
            if a == b and b == now:
                return True
            else:
                return False
        '''
    )

# Generated at 2022-06-23 11:12:41.813346
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    # Init args
    namespace = 'namespace'
    class_name = 'class_name'
    config = None
    subdir = 'subdir'
    package = 'package'
    base_class = 'base_class'
    aliases = {}
    
    # Init return values
    path = 'path'

    # Init args for calling constructor
    path = 'path'
    path_list = [path]

    # Init return value for calling constructor
    plugin_load_context = get_plugin_load_context_result(resolved=True, plugin_resolved_name='plugin_resolved_name', plugin_resolved_path='plugin_resolved_path', plugin_load_reason='plugin_load_reason', searched_paths=['searched_paths'], redirect_list=['redirect_list'])

    #

# Generated at 2022-06-23 11:12:46.978880
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    ''' Tests if add_all_plugin_dirs(path)
        1. if path directory exist , add each subdir under the path to plugin obj.add_directory(to_text(plugin_path))
        2. if path directory does not exist, display warning.
    '''
    b_path = os.path.expanduser(to_bytes("../test/test-plugins/not_exists", errors='surrogate_or_strict'))
    expected = "Ignoring invalid path provided to plugin path: '../test/test-plugins/not_exists' is not a directory"
    assert add_all_plugin_dirs(b_path) == display.warning(expected)

# Generated at 2022-06-23 11:12:56.436921
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    test_args = [list(args) for args in itertools.product([True, False], repeat=3)]
    pl = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins')
    assert len(list(pl.all(_dedupe=False))) > 0
    assert len(list(pl.all())) > 0

    pl = PluginLoader('ansible.plugins.cache', 'CacheModule', 'cache_plugins')
    assert len(list(pl.all(_dedupe=False))) > 0
    assert len(list(pl.all())) > 0

    pl = PluginLoader('ansible.plugins.callback', 'CallbackModule', 'callback_plugins')
    assert len(list(pl.all(_dedupe=False))) > 0
    assert len(list(pl.all())) > 0


# Generated at 2022-06-23 11:13:01.215415
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    jinja2_loader = Jinja2Loader('filter', base_paths='./test/units/lib/ansible/plugins/filter_plugins')
    length_of_paths = len(jinja2_loader.paths)
    assert length_of_paths == 1


# Generated at 2022-06-23 11:13:09.564774
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():

    from ansible import constants as C
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.loader import Jinja2Loader
    from ansible.collections import mock_collections
    from ansible.collections.ansible.plugins.filter import j2_filters_from

    # TODO: move this to initialization for all plugins, so always cached
    mock_collections.load()

    plugin = Jinja2Loader('filter', 'ansible.plugins.filter', C.DEFAULT_FILTER_PLUGIN_PATH, 'filters')

    # Test Jinja2Loader instantiation, set_collection and other types of plugins (e.g. action, connection, etc.)
    assert type(plugin) is Jinja2Loader
    plugin.set_collection('my.namespace', '/my/collections')
    plugin = Jin

# Generated at 2022-06-23 11:13:11.150747
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert add_dirs_to_loader('action', ['test']) == None


# Generated at 2022-06-23 11:13:22.436329
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Example:
    # _get_package_paths() should return a list of paths as strings
    plugin_loader = PluginLoader(package='test_package')
    _get_package_paths_return_value = plugin_loader._get_package_paths()
    assert isinstance(_get_package_paths_return_value, list)
    assert all(isinstance(item, string_types) for item in _get_package_paths_return_value)

    # Example:
    # _find_plugin(name, mod_type, subdir=None, collection_list=None) should return a string
    plugin_loader = PluginLoader(package='test_package')
    name, mod_type, subdir, collection_list = 'my_plugin', 'test_type', 'test_subdir', 'test_collection_list'


# Generated at 2022-06-23 11:13:25.565855
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    ansible_config = AnsibleConfig(ConfigManager())
    ansible_config.setenv('ANSIBLE_LIBRARY', os.path.join(unit_test_path, 'lib'))
    plugin_loader = Jinja2Loader(ansible_config=ansible_config)
    assert plugin_loader.get('strptime') is not None


# Generated at 2022-06-23 11:13:30.460460
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    ctx = PluginLoadContext()
    assert ctx.original_name is None
    assert ctx.redirect_list == []
    assert ctx.error_list == []
    assert ctx.import_error_list == []
    assert ctx.load_attempts == []
    assert ctx.pending_redirect is None
    assert ctx.exit_reason is None
    assert ctx.plugin_resolved_path is None
    assert ctx.plugin_resolved_name is None
    assert ctx.plugin_resolved_collection is None
    assert ctx.deprecated is False
    assert ctx.removal_date is None
    assert ctx.removal_version is None
    assert ctx.deprecation_warnings == []
    assert ctx.resolved is False
    assert ctx._res

# Generated at 2022-06-23 11:13:32.511075
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
   t = PluginLoader()
   assert False # TODO: implement your test here


# Generated at 2022-06-23 11:13:33.799028
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert str(get_shell_plugin(executable=__file__).executable) == __file__



# Generated at 2022-06-23 11:13:40.359033
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # This is a function scope mock
    @mock.patch('ansible.utils.display.omit_token', lambda x: x)
    @mock.patch('os.path.exists')
    def test(mock_exists, plugin_name, plugin_path, expected_plugin_dirs, existing_dir='', always_plugin=True):
        mock_exists.side_effect = [existing_dir != '']
        mock_exists.return_value = existing_dir != ''

        l = PluginLoader(plugin_name, '.', '', C.DEFAULT_INVENTORY_PLUGIN_PATH, True)
        actual_plugin_dirs = l._add_directory(plugin_path, always_plugin)

        assert_equal(actual_plugin_dirs, expected_plugin_dirs)

    test

# Generated at 2022-06-23 11:13:50.410499
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    '''
    Unit test for method PluginLoader.find_plugin
    '''
    # If you change these parameters, also update tests/unit/lib/ansible_test/_internal/test_PluginLoader.py
    # Also, change the test case name from test_PluginLoader_find_plugin to reflect the parameters
    plugin_loaders = [
        # test for the default case
        PluginLoader('shell_default_test', 'ShellModule', C.DEFAULT_SHELL_PLUGIN_PATH),
        # tests with shell_default_test
        PluginLoader('shell_default_test', 'ShellModule', ['shell_default_test_collection', 'shell_default_test_shell_plugins']),
    ]

    plugin_names = ['cat', 'copy', 'file', 'regular_plugin']


# Generated at 2022-06-23 11:13:53.113642
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    pl = PluginLoader('filder', 'lause', 's')
    assert isinstance(pl.__getstate__(), tuple)

# Generated at 2022-06-23 11:14:03.334163
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    import jinja2
    from ansible.plugins.loader import filter_loader
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    # All filters are expected to be callable classes, if they are functions it's a problem
    def my_filter_function(x, y, a=0.0, b=0.0):
        return x * y * (a + b)

    def my_filter_function_bad(x, y):
        return x * y


# Generated at 2022-06-23 11:14:14.592788
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    test_data = {
        # test data format: ( paths, expected_result )
        (["/a/b/c", "/d/e"], " ['/a/b/c', '/d/e']"),  # list of two or more paths
        (["/a/b/c", "/a/b/c/d"], " ['/a/b/c', '/a/b/c/d']"),  # list of two or more paths
        (["/a/b/c/d"], " ['/a/b/c/d']"),  # list of one path
        ([], " ['']"),  # list of no paths (treat as invalid)
    }

    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', required_base_class='ActionBase')


# Generated at 2022-06-23 11:14:27.220814
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    params = {}  # type: Dict[Any, Any]
    params['name'] = 'test'
    params['path_only'] = False
    params['class_only'] = False
    params['_dedupe'] = True
    # _get_paths has been mocked in tests/unit/loader/test_module_utils.py
    params['_dedupe'] = True
    # This function has been mocked in tests/unit/loader/test_module_utils.py
    params['_dedupe'] = True
    # This function has been mocked in tests/unit/loader/test_module_utils.py
    params['_dedupe'] = True
    # This function has been mocked in tests/unit/loader/test_module_utils.py
    params['_dedupe'] = True
    # This function has been mocked in tests/unit/

# Generated at 2022-06-23 11:14:28.141919
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    pass

# Generated at 2022-06-23 11:14:33.647113
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    c = PluginLoadContext()
    c.original_name = "a"
    b = c.redirect('b')
    assert c.original_name == b.original_name
    assert b.pending_redirect == "b"
    assert c.resolved is False
    assert b.resolved is False
# unit test for method resolve of class PluginLoadContext

# Generated at 2022-06-23 11:14:37.641936
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
        obj = PluginLoader()

        obj.aliases = mock.Mock()

        obj.__setstate__({'aliases': {'a': 'b'}})

        assert obj.aliases.update.call_count == 1
        assert obj.aliases.update.call_args_list[0][0][0] == {'a': 'b'}

# Generated at 2022-06-23 11:14:45.529501
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Simple test to cover init of PluginLoader with the three parameters
    # and the method find_plugin_with_context.
    class TestClass(object):
        pass
    pl = PluginLoader(package='package', base_class=TestClass, class_name='class_name')
    result = pl.find_plugin_with_context('a_name')
    assert result.resolved is False
    assert not result.plugin_resolved_path



# Generated at 2022-06-23 11:14:47.235170
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # FIXME: implement a test that actually tests something
    pass


# Generated at 2022-06-23 11:14:59.754703
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    from ansible.module_utils.six import PY2, PY3

    if PY2:
        from ansible.module_utils._text import to_native
    elif PY3:
        to_native = str

    # Test with deprecation provided
    plugin_name = 'test_plugin'
    deprecation = {'warning_text': 'warning_text', 'removal_date': '2020-01-01', 'removal_version': '3.0'}
    collection_name = 'test-collection'

    ctx = PluginLoadContext()
    ctx.record_deprecation(plugin_name, deprecation, collection_name)

    assert ctx.deprecated
    assert ctx.removal_date == '2020-01-01'
    assert ctx.removal_version is None


# Generated at 2022-06-23 11:15:08.845951
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # remove all the existing directories from the loader
    for loader in get_all_plugin_loaders():
        loader[1]._directories = []

    # add a test directory for each loader
    for loader in get_all_plugin_loaders():
        plugin_type = loader[0].replace('_loader', '')
        test_path = os.path.join(os.getcwd(), 'test', 'units', 'plugins', plugin_type, 'test_dir')
        add_dirs_to_loader(plugin_type, [test_path])
        assert test_path in loader[1]._directories

    # remove all the existing directories from the loader again to not influence following tests
    for loader in get_all_plugin_loaders():
        loader[1]._directories = []



# Generated at 2022-06-23 11:15:10.357003
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    assert isinstance(PluginLoader(base_class='object'), PluginLoader)



# Generated at 2022-06-23 11:15:23.275687
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    a = 'ansible.plugins.action.__init__'
    b = 'core'
    c = '__mro__'
    d = 'ansible.plugins.action.core'
    e = 'ansible.plugins.action.core.__init__'
    f = 'ansible.plugins.action'
    g = 'ansible_collections.foo.bar.plugins.action.__init__'
    h = 'ansible.plugins.action.__init__'

    pl = PluginLoader()

    assert pl.__contains__(a) == True
    assert pl.__contains__(b) == True
    assert pl.__contains__(c) == False
    assert pl.__contains__(d) == True
    assert pl.__contains__(e) == True
    assert pl.__cont

# Generated at 2022-06-23 11:15:31.983949
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    import sys

    class_name = "ActionModule"
    package = "ansible.plugins.action"
    config = ConfigParser()

    # Test all python paths are printed correctly
    loader = PluginLoader(class_name, package, "action_plugins", config, None)
    base_class = loader._get_paths()
    assert base_class == sys.path

    # Test when a plugin path is set it is added to the list of paths searched
    config.set('defaults', 'action_plugins', '/usr/share/ansible_plugins/action_plugins')
    loader = PluginLoader(class_name, package, "action_plugins", config, None)
    assert loader._get_paths() == ['/usr/share/ansible_plugins/action_plugins'] + sys.path


# Generated at 2022-06-23 11:15:43.870098
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    plc = PluginLoadContext()
    plc.original_name = 'a.b.c'
    plc.redirect_list = ['a.b.c', 'd.e.f', 'g.h.i']
    plc.error_list = []
    plc.import_error_list = []
    plc.load_attempts = []
    plc.pending_redirect = None
    plc.exit_reason = None
    plc.plugin_resolved_path = 'x.y.z'
    plc.plugin_resolved_name = None
    plc.plugin_resolved_collection = 'A.B.C'
    plc.deprecated = False
    plc.removal_date = None
    plc.removal_version = None
    plc.dep

# Generated at 2022-06-23 11:15:48.701599
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    pl = PluginLoader('foo', 'foo.bar', 'baz')
    assert pl.package == 'foo'
    assert pl.base_class == 'baz'
    assert pl.subdir == 'bar'


# Generated at 2022-06-23 11:15:51.821633
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    ctx = PluginLoadContext()
    ctx.nope('Test failure message')
    assert ctx.exit_reason == 'Test failure message'
    assert ctx.resolved == False



# Generated at 2022-06-23 11:15:53.957871
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    # getstate does not require any arguments
    args = []
    # call the method without arguments
    assert super(PluginLoader, PluginLoader).__getstate__() is None

# Generated at 2022-06-23 11:15:55.620149
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    '''
    Unit test for method __getstate__ of class PluginLoader
    '''
    pass

# Generated at 2022-06-23 11:16:01.549271
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    import tempfile

    # Make a temporary directory to hold the plugins
    temp_dir = tempfile.mkdtemp()

    # Make a temporary file with some plugins inside
    plugin_file_name = os.path.join(temp_dir, 'ansible_gather_facts.py')

# Generated at 2022-06-23 11:16:08.787257
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    context = PluginLoadContext()
    context.nope(exit_reason="Testing nope")
    
    assert context.pending_redirect == None, "pending_redirect should be None, but it is not."
    assert context.exit_reason == "Testing nope", "exit reason should contain 'Testing nope', but it does not."
    assert context.resolved == False, "resolved should be False, but it is not."


# Generated at 2022-06-23 11:16:18.364992
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    cls = collections.namedtuple('MockPluginLoader', ['path', 'package', 'base_class', 'class_name', 'aliases'])
    x = cls(path=None, package=None, base_class=None, class_name=None, aliases=None)

    # Calling PluginLoader.__contains__ with the arguments: {'collection_list': C.COLLECTIONS_PATHS}, returns:
    # <ERROR: no tests>
    x = cls(path=None, package=None, base_class=None, class_name=None, aliases=None)
    # Calling PluginLoader.__contains__ with the arguments: {'collection_list': C.COLLECTIONS_PATHS}, returns:
    # <ERROR: no tests>

# Generated at 2022-06-23 11:16:26.215856
# Unit test for method all of class PluginLoader

# Generated at 2022-06-23 11:16:33.477385
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    # test case 1:
    # deprecation: {'removal_version': '3.0', 'warning_text': 'This is a test plugin'}
    # name: 'simple_plugin'
    # collection_name: 'my_collection'
    # expect: warning_text shows 'This is a test plugin has been deprecated. removal_version: 3.0 collection_name: my_collection'

    deprecation = {'removal_version': '3.0', 'warning_text': 'This is a test plugin'}
    name = 'simple_plugin'
    collection_name = 'my_collection'
    plc = PluginLoadContext()
    plc.record_deprecation(name, deprecation, collection_name)

# Generated at 2022-06-23 11:16:37.128060
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    loader = PluginLoader('cache')
    all = list(loader.all())
    assert all
    assert len(all) == len(set(all))
# }}}

# PluginManager {{{

# Generated at 2022-06-23 11:16:49.630125
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    class MockDisplay(object):
        def __init__(self):
            self.deprecated_warnings = []
        def deprecated(self, warning_text, data=None, collection_name=None):
            self.deprecated_warnings.append(warning_text)
    display = MockDisplay()

    plc = PluginLoadContext()

# Generated at 2022-06-23 11:16:56.644423
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    c = PluginLoadContext()
    c.original_name = 'original_name'
    c.resolve("new_name", "/fake/path", "", "exit_reason")
    assert c.resolved
    assert c.pending_redirect is None
    assert c.plugin_resolved_name == "new_name"
    assert c.plugin_resolved_path == "/fake/path"
    assert c.plugin_resolved_collection is None
    assert c.exit_reason == "exit_reason"
    assert c.resolved_fqcn == "new_name"


# Generated at 2022-06-23 11:17:09.245524
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    import os
    import tempfile
    from ansible.compat.tests import unittest

    # Verify the order of the files returned
    # This is important to ensure the correct dedupe behavior in calling code

    from ansible.plugins.loader import Jinja2Loader

    def _create_test_file(fname, content):
        ''' writes test data to fname '''
        with open(fname, 'w') as f:
            f.write(content)

    class TestCase(unittest.TestCase):

        def setUp(self):
            self.directory = tempfile.mkdtemp()
            self.loader = Jinja2Loader(base_class='BaseClass', package='ansible.plugins.filter', subdir='filter_plugins')
            self.loader.add_directory(self.directory)


# Generated at 2022-06-23 11:17:10.613371
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    assert isinstance(get_all_plugin_loaders(), list)


# Generated at 2022-06-23 11:17:19.154903
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    from ansible.utils.collection_loader._collection_finder import get_full_collections_list
    from ansible.utils.collection_loader import FilesystemFinder, AnsibleCollectionConfig, CACHE_VALIDITY_TIME

    collections_list_dirs = get_full_collections_list(AnsibleCollectionConfig())

    filesystem_finder = FilesystemFinder(collections_list_dirs, CACHE_VALIDITY_TIME).find_collections()

    # Create a new directory which is not in the collections_list_dirs
    test_dirname = 'test_add_dirs_to_loader'
    test_dir = os.path.join('/tmp', test_dirname)
    test_file = os.path.join(test_dir, 'test_file')

# Generated at 2022-06-23 11:17:28.963306
# Unit test for method format_paths of class PluginLoader

# Generated at 2022-06-23 11:17:39.313331
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # Test add_dirs_to_loader with valid directory
    add_dirs_to_loader('action', ['./test/unit/loader/fixtures/test_add_dirs_to_loader/action_valid'])
    assert action_loader.module_paths[0] == './test/unit/loader/fixtures/test_add_dirs_to_loader/action_valid'
    action_loader.module_paths = []

    # Test add_dirs_to_loader with invalid directory
    add_dirs_to_loader('action', ['./test/unit/loader/fixtures/test_add_dirs_to_loader/action_invalid'])

# Generated at 2022-06-23 11:17:47.732032
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    # test constructor of class PluginLoader

    # Constructor of class PluginLoader
    # Test 1: plugin_dirs is None and subdir is not none

    with pytest.raises(AnsibleError) as err:
        loader = PluginLoader(None, 'action', 'ansible/actions')
    assert 'subdir must be None when plugin_dirs is None' in to_text(err.value)

    # Test 2: plugin_dirs is not None and subdir is None
    loader = PluginLoader([], 'action', 'ansible/actions')
    assert loader.subdir is None
    assert loader.package == 'ansible.actions'
    assert 'action' in vars(loader)
    assert len(loader._paths) == len(C.DEFAULT_ACTION_PLUGIN_PATH)