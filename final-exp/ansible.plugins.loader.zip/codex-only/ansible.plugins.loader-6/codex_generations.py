

# Generated at 2022-06-23 11:07:46.329599
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    ''' add any existing plugin dirs in the path provided '''

    b_path = os.path.expanduser(to_bytes("./test/units/plugins"))

    loader = PluginLoader("", "", "")

    if os.path.isdir(b_path):
        for name, obj in get_all_plugin_loaders():
            if obj.subdir:
                plugin_path = os.path.join(b_path, to_bytes(obj.subdir))
                if os.path.isdir(plugin_path):
                    obj.add_directory(to_text(plugin_path))





# Generated at 2022-06-23 11:07:52.090369
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    plugin_loader = PluginLoader(package='package', class_name='class_name', configured=False,
                                 subdir='plugin_dir', installed_only=False, filter=None)
    plugin_loader._searched_paths = ['test_path1', 'test_path2']
    assert plugin_loader.print_paths() == 'test_path1, test_path2'


# Generated at 2022-06-23 11:07:53.669090
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    loader = Jinja2Loader('', '', '', '')
    assert loader.find_plugin('str.join') == None


# Generated at 2022-06-23 11:07:56.032161
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    path = '/some/path'
    internal = True
    p = PluginPathContext(path, internal)
    assert p.path == path
    assert p.internal == internal



# Generated at 2022-06-23 11:07:58.603190
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    loader = Jinja2Loader()
    files = loader.all()
    assert len(files) > 0
    assert not isinstance(files[0], tuple)


# Generated at 2022-06-23 11:08:09.131459
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    '''
    Unit test for method __getstate__ of class PluginLoader
    '''

    # from ansible.plugins.loader import PluginLoader
    # plugin_loader = PluginLoader(package='ansible', class_name='CollectionModule')
    # data = plugin_loader.__getstate__()

    # assert isinstance(data['_searched_paths'], list) is True
    # assert isinstance(data['package'], string_types) is True
    # assert isinstance(data['class_name'], string_types) is True
    # assert isinstance(data['_collection_list'], CollectionList) is True
    # assert data['base_class'] == 'ActionBase'
    # assert data['subdir'] == 'action'
    # assert isinstance(data['_module_cache'], dict) is True
   

# Generated at 2022-06-23 11:08:13.485383
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # test that a call to function add_dirs_to_loader adds a path to the loader
    # it is passed
    # test that a call to function add_dirs_to_loader raises an exception
    # if paths is empty
    # test that a call to function add_dirs_to_loader works with 2 paths
    # test that a call to function add_dirs_to_loader raises an exception
    # if which_loader is not a str
    pass



# Generated at 2022-06-23 11:08:17.641913
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    loader = PluginLoader('ansible.module_utils', 'ModuleUtilsCore')
    name = 'apt_key'
    result = loader.find_plugin(name)

# Generated at 2022-06-23 11:08:23.717246
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    # Test strings against the repr of their objects
    # Note: The repr of PluginLoader depends on the subdir and package
    plugin_loader = PluginLoader(package='ansible.plugins.action',
                             subdir='actions',
                             class_name='ActionModule')
    plugin_loader_repr = "PluginLoader(package='ansible.plugins.action', subdir='actions', class_name='ActionModule')"
    assert repr(plugin_loader) == plugin_loader_repr



# Generated at 2022-06-23 11:08:28.865426
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    plugin_path_context = PluginPathContext('/home/user', False)
    assert plugin_path_context.path == '/home/user'
    assert plugin_path_context.internal == False
    assert plugin_path_context.__class__.__name__ == 'PluginPathContext'



# Generated at 2022-06-23 11:08:38.532962
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():

    my_loader = Jinja2Loader('j2')
    result = my_loader.loaders[:-1]
    expected = ['/tmp/j2', '/other/tmp/j2']
    assert result == expected

    # We also test the file!==plugin logic in all()
    class FakePlugin:
        def __init__(self, name, path):
            self.name = name
            self.path = path

    class FakeModule:
        j2_plugin1 = FakePlugin('j2_plugin1', '/tmp/j2_plugin1.py')
        j2_plugin2 = FakePlugin('j2_plugin2', '/tmp/j2_plugin2.py')

    # _module_cache is a dict of 'path': module.  Here, we fake that each file contains
    # 2 plugins.
    my_loader._

# Generated at 2022-06-23 11:08:50.569991
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    # Set up mock ansible_loader
    ansible_loader.__setstate__ = Mock(return_value=None)

    # Construct an instance of the PluginLoader class with the proper arguments
    plugin_loader = PluginLoader('', '', None, '', '')

    # Set up mock _get_paths
    plugin_loader._get_paths = Mock(return_value=[])


    # Call method
    try:
        plugin_loader.__setstate__(None)
    except:
        pass


    # Check __init__ call args
    ansible_loader.__setstate__.assert_called_with(None)

    # Check call count of methods
    assert ansible_loader.__setstate__.call_count == 1
    assert plugin_loader._get_paths.call_count == 1


# Unit test

# Generated at 2022-06-23 11:08:58.282824
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():

    display.debug('test_PluginLoader_get()')

    # Create instance of class PluginLoader with required arguments
    plugin_loader = PluginLoader('action_plugin', 'ansible.plugins.action', C.DEFAULT_ACTION_PLUGIN_PATH, '', 'action')

    # If error, fail test
    assert plugin_loader is not None and (plugin_loader.__class__) == PluginLoader, \
        'Failed to create instance of class PluginLoader with required arguments'

    # Try to get action plugin 'systemd'
    plugin_object = plugin_loader.get('systemd')
    # If error, fail test
    assert plugin_object is not None, \
        'Failed to get action plugin systemd'

    # Try to get action plugin 'ping'
    plugin_object = plugin_loader.get('ping')
    # If error

# Generated at 2022-06-23 11:09:01.060596
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin()
    assert shell is not None
    assert shell.SHELL_FAMILY == 'sh'



# Generated at 2022-06-23 11:09:06.392439
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    plugin_path_context = PluginPathContext('/path/to/plugins', True)
    assert plugin_path_context.path == '/path/to/plugins'
    assert plugin_path_context.internal == True


# Generated at 2022-06-23 11:09:11.138363
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    jjl = Jinja2Loader('ansible.plugins.filter', 'FilterModule')
    assert isinstance(jjl, Jinja2Loader)
    assert jjl.package == 'ansible.plugins.filter'
    assert jjl.class_name == 'FilterModule'
    assert jjl.paths is None
    assert jjl.base_class is None
    assert jjl.names is None
    assert jjl.require_module is None
    assert jjl.required_base_class is None
    assert jjl.other_attr is None


# Generated at 2022-06-23 11:09:13.697009
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    plc = PluginLoadContext()
    assert isinstance(plc.nope(exit_reason="Sth"), type(plc))



# Generated at 2022-06-23 11:09:22.206191
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    args = []
    kwargs = dict()
    obj = dict()
    setattr(obj, '_original_path', 'foo')
    setattr(obj, '_load_name', 'bar')
    setattr(obj, '_redirected_names', [])
    loader = PluginLoader('ansible.plugins.action', 'ActionModule', 'action_plugins', 'action', 'actions')
    result = loader.get_with_context('ping', *args, **kwargs)
    assert result.object.__class__.__name__ == 'Ping'
    assert result.name == 'ping'
    assert result.plugin_resolved_name == 'ping'
    assert result.plugin_resolved_path == 'ansible/plugins/action/ping.py'
    assert result.resolved
    assert result.path is None

# Generated at 2022-06-23 11:09:34.314489
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    with pytest.raises(AssertionError):
        PluginLoader('foo', '', '', '', '', '', '')
    with pytest.raises(AssertionError):
        PluginLoader('foo', '', '', '', '', '', '')
    with pytest.raises(AssertionError):
        PluginLoader('foo', '', '', '', '', '', '')
    with pytest.raises(AssertionError):
        PluginLoader('foo', '', '', '', '', '', '')
    with pytest.raises(AssertionError):
        PluginLoader('foo', '', '', '', '', '', '')
    with pytest.raises(AssertionError):
        PluginLoader('foo', '', '', '', '', '', '')
   

# Generated at 2022-06-23 11:09:41.990944
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():

    from ansible.utils.display import Display
    class plugin_mock(object):
        pass

    collection_loader = collections.CollectionLoader()

    file_loader = PluginLoader(display=Display(), package='files', config=plugin_mock(),
                               subdir='foo', aliases={}, class_name='files',
                               required_base_class=None,
                               collection_list=collection_loader)

    file_loader._get_paths = lambda *args, **kwargs: (os.path.join('foo', 'bar', 'baz'),)
    file_loader.has_plugin = lambda *args, **kwargs: True
    file_loader._find_plugin = lambda *args, **kwargs: (False, False, "something/something/something.py")

# Generated at 2022-06-23 11:09:48.473269
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    '''
    Unit test for constructor of class PluginLoader
    '''
    # We need to be able to instantiate a plugin loader using:
    #   t = PluginLoader("some.package", "somename", "SomeClass", "baseclass")

    # We need to be able to have it have a list of search paths
    # and have it add to it
    #   t.add_directory("/some/path")
    #   t.add_directory("/some/path") # should not add a duplicate
    #   t.get_all_paths()
    #   ['/some/path',]

    # We need to be able to load plugins (returning instances)
    #   t.get("pluginnme") -> SomeClass("pluginnme")

    # We need to be able to load all plugins:
    #   t

# Generated at 2022-06-23 11:09:51.243978
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    # we actually just want to make sure that this doesn't fail with a non-fatal error
    plugin_loader = Jinja2Loader('ansible.plugins.filter', 'FilterModule', 'filter_plugins')
    assert plugin_loader

# Unit test case for method get of class PluginLoader

# Generated at 2022-06-23 11:09:59.491114
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    # Test loading plugins using built-in paths
    loader = PluginLoader('ansible.plugins', 'ActionModule', 'action_plugins', required_base_class='ActionBase')
    assert loader.format_paths(loader._get_paths()) == '<ansible_plugins_dir/action_plugins>'

    # Test loading plugins using paths defined in config
    loader = PluginLoader('ansible.plugins', 'ActionModule', 'action_plugins', 'myplugins', required_base_class='ActionBase')
    assert loader.format_paths(loader._get_paths()) == '<myplugins_dir/action_plugins>'

    # Test loading collections plugins using BUILTIN_COLLECTION_PATHS (../../plugins/collections)

# Generated at 2022-06-23 11:10:11.257823
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # TODO: add missing tests
    # FIXME: add basic test for find_plugin
    from ansible.utils.loader import module_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import Jinja2Loader

    filter_plugin_names = [f.name for f in filter_loader.all()]
    assert 'basename' in filter_plugin_names

    test_plugin_names = [t.name for t in test_loader.all()]
    assert 'basename' in test_plugin_names

    assert filter_loader.find_plugin('basename').endswith('basename.py')
    assert test_loader.find_plugin('basename').endswith('basename.py')
    assert filter_loader.find_

# Generated at 2022-06-23 11:10:15.196478
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    path_context = PluginPathContext('/path/to/dir', True)
    assert path_context.path == '/path/to/dir'
    assert path_context.internal == True



# Generated at 2022-06-23 11:10:17.108027
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # Test for method find_plugin
    # of class Jinja2Loader
    j_l = Jinja2Loader("", "", "")
    assert j_l.find_plugin("foo.bar") == None
    assert j_l.find_plugin("foo") == None



# Generated at 2022-06-23 11:10:20.306815
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    plugin_load_context=PluginLoadContext()
    assert plugin_load_context.nope("test")
    assert plugin_load_context.exit_reason == "test"
    assert not plugin_load_context.resolved


# Generated at 2022-06-23 11:10:28.079271
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    args = [
        'lookups',
        {'_dedupe': False}
    ]
    kwargs = {
        'package': 'ansible.plugins.lookup',
        'base_class': 'LookupBase',
        'class_name': 'LookupModule',
        'class_only': False,
        'path_only': False
    }
    paths = []
    for i in range(3):
        paths.append({
            'path': '',
            'package': 'ansible.plugins.lookup',
            'base_class': 'LookupBase',
            'class_name': 'LookupModule',
            'class_only': False,
            'path_only': False
        })
    results = [
        None,
        None,
        []
    ]
    # Mock PluginLoader


# Generated at 2022-06-23 11:10:38.353252
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    assert Jinja2Loader('ansible.plugins.filter', 'FilterModule', 'filter_plugins').find_plugin('ansible.plugins.filter.regex_replace') == 'ansible.plugins.filter'
    assert Jinja2Loader('ansible.plugins.action', 'ActionModule', 'action_plugins').find_plugin('ansible.plugins.filter.regex_replace') is None
    assert Jinja2Loader('ansible.plugins.filter', 'FilterModule', 'filter_plugins').find_plugin(u'ansible.plugins.filter.regex_replace') == 'ansible.plugins.filter'
    assert Jinja2Loader('ansible.plugins.action', 'ActionModule', 'action_plugins').find_plugin(u'ansible.plugins.filter.regex_replace') is None

# Generated at 2022-06-23 11:10:46.783314
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    context = PluginLoadContext()
    name = 'foo'
    path = 'path/file/foo'
    collection = 'collection'
    reason = 'test'
    res_context = context.resolve(name, path, collection, reason)
    assert res_context.plugin_resolved_name == name
    assert res_context.plugin_resolved_path == path
    assert res_context.plugin_resolved_collection == collection
    assert res_context.exit_reason == reason
    assert res_context.resolved == True


# Generated at 2022-06-23 11:10:56.772107
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    context = PluginLoadContext()
    context.pending_redirect = 'pending_redirect'
    context.plugin_resolved_name = 'plugin_resolved_name'
    context.plugin_resolved_path = 'plugin_resolved_path'
    context.plugin_resolved_collection = 'plugin_resolved_collection'
    context.exit_reason = 'exit_reason'

    retval = context.resolve('resolved_name', 'resolved_path', 'resolved_collection', 'exit_reason')
    assert retval is context
    assert context.pending_redirect is None
    assert context.plugin_resolved_name == 'resolved_name'
    assert context.plugin_resolved_path == 'resolved_path'
    assert context.plugin_resolved_collection == 'resolved_collection'

# Generated at 2022-06-23 11:11:09.434104
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    class_name = 'ActionModule'
    package = 'ansible.plugins.action'
    # first use a non-existent name
    loader = PluginLoader(class_name, package)
    # Simulate the non-existent name
    loader.package_path = os.path.join(os.path.dirname(__file__), 'empty')
    loader.all() # os.listdir is called before looking up
    # The non-existent name is not in cache
    assert 'non_existent' not in loader._module_cache.keys()
    res = loader.find_plugin_with_context('non_existent')
    assert res.resolved is False
    # then use an existing name
    res = loader.find_plugin_with_context('copy')
    assert res.resolved is True

# Generated at 2022-06-23 11:11:22.512424
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    assert not get_all_plugin_loaders()
    class OldStyleClass:
        pass
    class NewStyleClass(object):
        pass
    def Function():
        pass
    global Variable
    Variable = 13
    # All of these should be skipped
    globals()['OldStyleClass'] = OldStyleClass
    globals()['NewStyleClass'] = NewStyleClass
    globals()['Function'] = Function
    globals()['Variable'] = Variable

    # This should be returned
    class PluginLoader:
        pass
    globals()['PluginLoader'] = PluginLoader
    assert get_all_plugin_loaders()
    # TODO: reset the globals?


# Generated at 2022-06-23 11:11:32.423335
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # type: () -> None
    collection_list = None # type: Optional[CollectionList]
    class_only = False
    name = 'collection.foo.bar'
    module_name = 'collection.foo.bar'
    class_name = 'Baz'
    package = 'foo.bar'
    search_paths = ['/a/b/c', '/x/y/z']
    base_class = 'AnsibleModule'
    subdir = 'action_plugins'
    redirected_names = dict()
    spec_only = False
    config_defs_path = '/a/b/c/collection.foo.bar.yaml'
    config_defs_path_2 = '/x/y/z/collection.foo.bar.yaml'
    config_defs_cache = dict()
    module_cache

# Generated at 2022-06-23 11:11:32.965368
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
  pass

# Generated at 2022-06-23 11:11:33.766116
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    pass

# Generated at 2022-06-23 11:11:34.758063
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    with pytest.raises(AssertionError):
        get_with_context_result(None, None, None)



# Generated at 2022-06-23 11:11:38.269858
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    p=PluginLoadContext()
    assert p.nope("Lol").exit_reason == "Lol"

# Generated at 2022-06-23 11:11:42.463125
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    # This method is not currently used.  It was only used for pickling
    # functionality that has since been removed.  It remains here since it is
    # a magic method, but it should be safe to remove it.
    pass

# Generated at 2022-06-23 11:11:50.222297
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    for name in ( 'foo', 'bar' ):
        assert name in PluginLoader

    loader = PluginLoader( 'foo', subdirs = False )
    def test_loader_get( name, *args, **kwargs ):
        loader.get( name, *args, **kwargs )

    test_loader_get( 'foo' )

    with pytest.raises(AnsibleError):
        test_loader_get( 'bar' )

    assert not PluginLoader.get('bar')
    loader = PluginLoader( 'unittest_config', subdirs = False )
    assert not PluginLoader.has_plugin('unittest_config')


# Generated at 2022-06-23 11:11:59.079029
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Declarations
    PL = PluginLoader(None, None, None)
    directory_to_add = os.path

    PL.add_directory(directory_to_add)


# Generated at 2022-06-23 11:12:09.364441
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    _paths = ['../../lib/ansible/plugins/filter_plugins', '../../lib/ansible/plugins/filter_plugins']
    _module_cache = []
    _package = 'ansible.plugins.filter_plugins'
    _class_name = 'FilterModule'
    _searched_paths = []
    _display = object()
    _config_defs = object()
    _config_defs_definitions = '_config_defs_definitions'
    _plugin_ignorelist = '_plugin_ignorelist'
    obj = PluginLoader(_paths, _module_cache, _package, _class_name, _searched_paths, _display, _config_defs)
    obj._config_defs_definitions = _config_defs_definitions
    obj._plugin_ignorelist

# Generated at 2022-06-23 11:12:12.567136
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    assert len(get_all_plugin_loaders()) > 0
    for (name, obj) in get_all_plugin_loaders():
        assert isinstance(obj, PluginLoader)



# Generated at 2022-06-23 11:12:17.543797
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import PluginLoader

    plugin_loaders = get_all_plugin_loaders()
    for name, obj in plugin_loaders:
        assert isinstance(obj, PluginLoader)



# Generated at 2022-06-23 11:12:29.084607
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    p = PluginLoader('')

# Generated at 2022-06-23 11:12:37.604968
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():

    tests = [
        # Expected to fail
        ([], '', None, 'base'),
        (['/abc'], '', None, 'base'),

        # Expected to succeed
        (['/abc'], '', None, None),
        (['/abc'], '', 'ansible.plugins.filter.core', 'FilterModule'),
    ]

    for args, fromlist, package, class_name in tests:
        try:
            loader = Jinja2Loader(*args, fromlist=fromlist, package=package, class_name=class_name)
        except Exception as e:
            assert class_name is not None, 'Invalid args for Jinja2Loader should raise exception'
        else:
            assert class_name is None, 'Valid args for Jinja2Loader should succeed'



# Generated at 2022-06-23 11:12:49.479476
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    #
    # _dedupe:
    #
    # loop through each file, run _display_plugin_load and
    # yield a plugin instance
    #
    # The jinja2 module doesn't have a real "class" field
    # so we use isinstance(plugin, BaseExtension)
    # to test for subclass types

    from ansible import context
    context._init_global_context(config=None)
    from ansible.plugins.filter.legacy import AnsibleCoreJinja2FilterModule
    from ansible.plugins.filter.core import Jinja2Filters

    class test_Jinja2Loader_all_Mixin(object):
        def __init__(self):
            self._module_cache = {}
            self._searched_paths = ['/path/to/ansible/plugins']
           

# Generated at 2022-06-23 11:12:57.662168
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    obj = PluginLoader("", "", "")
    # The PluginLoader class does not implement __contains__.
    # Instead, PluginLoader uses has_plugin() to implement __contains__.
    # It seems to me that this is a trick by Ansible to avoid
    # name conflicts with plugins that have the name __contains__.
    # This trick will only work with Python 2, because in Python 3
    # there is no __contains__ method in object.
    assert obj.__contains__("") == obj.has_plugin("")


# Generated at 2022-06-23 11:13:04.536076
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    ansible = Ansible()
    plugin_loader = PluginLoader(package='ansible.plugins.inventory', class_name='BaseInventoryPlugin')
    try:
        obj = plugin_loader.get('my_plugin')
    except Exception as inst:
        display.error(str(inst))
        pytest.fail("module.py:Failed to instantiate class 'BaseInventoryPlugin' with name 'my_plugin'")

    assert obj.__class__.__name__ == 'MyPlugin'


# Generated at 2022-06-23 11:13:05.906597
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    data = b''
    result = _PluginLoader(data).__repr__()
    assert result == "<_PluginLoader name='?'>"

# Generated at 2022-06-23 11:13:19.481376
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # the test_plugins plugin loader has already been initialized
    # so we'll just test the effects of adding directories to it
    p = PluginLoader('test_plugins')

    # add a directory that doesn't exist
    assert p.add_directory('a_bogus_path') == 0

    # add a non-directory
    assert p.add_directory('/etc/passwd') == 0

    # add a directory containing a module
    assert p.add_directory(os.path.join(os.getcwd(), 'test/test_plugins/')) == 1

    # add another directory containing a module
    assert p.add_directory(os.path.join(os.getcwd(), 'test/test_plugins/')) == 1

    # add a directory that exists but is empty

# Generated at 2022-06-23 11:13:30.131270
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    p = PluginLoadContext()
    p.resolve(1, 2, 3, 4).__dict__.keys()
    p.resolve(1, 2, 3, 4).__dict__.values()
    p.resolve(1, 2, 3, 4).__dict__['resolved'] == True
    p.resolve(1, 2, 3, 4).__dict__['plugin_resolved_name'] == 1
    p.resolve(1, 2, 3, 4).__dict__['plugin_resolved_path'] == 2
    p.resolve(1, 2, 3, 4).__dict__['plugin_resolved_collection'] == 3
    p.resolve(1, 2, 3, 4).__dict__['exit_reason'] == 4
    p.resolve(1, 2, 3, 4).__dict

# Generated at 2022-06-23 11:13:34.543975
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    garbage_collect()
    garbage_collect()
    garbage_collect()
    garbage_collect()

    loader = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action')
    with pytest.raises(AttributeError):
        loader.__getstate__()

# Generated at 2022-06-23 11:13:39.704043
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Redirect import to wrapper
    #FIXME, this is not working as expected, all the imports in ansible.utils.collection_loader are not working as expected
    import ansible.utils.collection_loader
    ansible.utils.collection_loader.importlib_import = wrapper_import_collection
    PLUGIN_PATH = [
        os.path.join(os.path.dirname(__file__), 'data', 'plugins'),
        os.path.join(os.path.dirname(__file__), 'data', 'plugins', 'action'),
        os.path.join(os.path.dirname(__file__), 'data', 'plugins', 'action', 'test_namespace'),
    ]
    # create a tmp module list with same name but different contents to see if it is loading the correct module

# Generated at 2022-06-23 11:13:48.695347
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    # We don't want to actually import jinja2 here, so we use the magic mock
    j2_loader = Jinja2Loader(b_('ansible.plugins.filter'), 'FilterModule', 'ansible.plugins.filter.jinja2_type.filter_loader')
    assert j2_loader

    # Basic test of our ability to load a small number of test plugins.
    # This doesn't check the details of the plugins, but it does exercise most of the init code.

    # TODO: When there is a way to correctly test this, we should compare the output to the expected output.
    #       We can either copy the expected output into the test, or have it write to a file and compare it.
    #       Right now, we just check that it can run without error.
    files = j2_loader.all()
    assert files



# Generated at 2022-06-23 11:13:51.064857
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
  pl = PluginLoader('package', 'class')
  pl.__getstate__()


# Generated at 2022-06-23 11:13:52.382853
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # FIXME: do test
    pass



# Generated at 2022-06-23 11:14:02.934163
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    import tempfile
    from ansible.module_utils.six import PY3

    # Use a temporary directory for the test
    with tempfile.TemporaryDirectory() as temp_dir:
        # Create test modules in the directory
        for (name, contents) in EXISTING_MODULE_PATH_TO_CONTENTS.items():
            module_path = os.path.join(temp_dir, name)
            os.makedirs(os.path.dirname(module_path), exist_ok=True)

            with open(module_path, 'wb') as fh:
                fh.write(contents.encode('utf-8'))

        # Create the Jinja2Loader

# Generated at 2022-06-23 11:14:11.563887
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    executable = '/bin/bash'
    shell_type = 'sh'
    shell = get_shell_plugin(shell_type, executable)
    if not shell:
        raise AnsibleError("Error get shell plugin")
    assert shell.executable == executable

    shell_type = 'bad'
    try:
        shell = get_shell_plugin(shell_type, executable)
        if not shell:
            raise AnsibleError("Error get shell plugin")
        assert False
    except AnsibleError:
        assert True
    return True



# Generated at 2022-06-23 11:14:19.439956
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    test_class = get_with_context_result(TestClass)
    assert test_class.__name__ == 'TestClass'
    assert not hasattr(test_class, 'mock_context')

    test_context_class = get_with_context_result(TestClass, 'mock_context')
    assert test_context_class.__name__ == 'TestClass'
    assert hasattr(test_context_class, 'mock_context')



# Generated at 2022-06-23 11:14:28.939604
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    context = PluginLoadContext()
    assert context.resolve(resolved_name='test_resolved_name',resolved_path='test_resolved_path',
                           resolved_collection='test_resolved_collection',exit_reason='test_exit_reason') == context
    assert context.plugin_resolved_name == 'test_resolved_name'
    assert context.plugin_resolved_path == 'test_resolved_path'
    assert context.plugin_resolved_collection == 'test_resolved_collection'
    assert context.exit_reason == 'test_exit_reason'
    assert context.pending_redirect == None
    assert context.resolved == True


# Generated at 2022-06-23 11:14:31.946582
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    lc = PluginLoadContext()
    lc.resolve('a','b','c','d')
    assert lc.resolved_fqcn == 'c.a'



# Generated at 2022-06-23 11:14:41.581018
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    obj = PluginLoader('')
    class_name = '_PluginLoader__searched_paths'
    before = getattr(obj, class_name)
    obj.add_directory('/playbooks')
    after = getattr(obj, class_name)
    if 'playbooks' in before:
        assert False, 'PluginLoader.add_directory() modified existing list'
    else:
        assert 'playbooks' in after, 'PluginLoader.add_directory() did not update list'
    with pytest.raises(AnsibleError, match='An empty directory path was passed to PluginLoader.add_directory()'):
        obj.add_directory('')
    obj = PluginLoader('')

# Generated at 2022-06-23 11:14:52.103863
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    print('Testing record_deprecation')
    import warnings
    warnings.filterwarnings('always')
    load_context = PluginLoadContext()
    deprecation = {'warning_text': '', 'removal_date': '', 'removal_version': '', 'RemovedInVersion': ''}
    load_context.record_deprecation('name', deprecation=deprecation, collection_name='collection_name')
    assert load_context.deprecated == True
    assert load_context.removal_date == None
    assert load_context.removal_version == None
    assert load_context.deprecation_warnings == ['name has been deprecated.']


# Generated at 2022-06-23 11:14:56.770135
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    obj = PluginLoader(base_class=None, package='base_class', subdir="subdir", aliases={})
    assert repr(obj) == "<ansible.plugins.loader.PluginLoader base_class/subdir>"


# Generated at 2022-06-23 11:15:05.175136
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    test_ctx = PluginLoadContext()
    new_ctx = test_ctx.redirect("test")
    assert new_ctx == test_ctx
    assert new_ctx.resolved == False
    assert new_ctx.redirect_list == []
    assert new_ctx.plugin_resolved_name is None
    assert new_ctx.plugin_resolved_path is None
    assert new_ctx.pending_redirect == "test"
    assert new_ctx.exit_reason == 'pending redirect resolution from None to test'
    assert new_ctx.plugin_resolved_collection is None



# Generated at 2022-06-23 11:15:10.503372
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    plc = PluginLoadContext()
    assert plc.resolved == False
    redirect_name = 'helloworld'
    plc.redirect(redirect_name)
    assert plc.pending_redirect == redirect_name
    assert plc.resolved == False
    assert plc.exit_reason == 'pending redirect resolution from None to helloworld'

# Generated at 2022-06-23 11:15:23.370893
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    """
    Test to verify the plugin_loader.PluginLoader.format_paths method.
    """
    loader = PluginLoader('ansible.plugins.module_utils')

# Generated at 2022-06-23 11:15:25.888250
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    test_plugin_loader = PluginLoader(package='plugins')
    paths = test_plugin_loader.print_paths()
    assert paths is not None


# Generated at 2022-06-23 11:15:31.641590
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    add_dirs_to_loader('action', ['../test/units/modules/test/support/actions-legacy'])
    assert os.path.join(os.path.dirname(__file__), 'test/test_utils.py') in action_loader._module_paths
    assert os.path.join(os.path.dirname(__file__), 'test/units/modules/test/support/actions-legacy/test_utils.py') not in action_loader._module_paths



# Generated at 2022-06-23 11:15:34.440301
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    print("Testing find_plugin")

    plugin_loader = PluginLoader('ansible.plugins.')
    plugin_loader.find_plugin('always', collection_list=None)


# Generated at 2022-06-23 11:15:41.479428
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    x = PluginLoader(package='TestPackage',
                     directories=['TestDirectory'],
                     class_name='TestClass',
                     base_class=None,
                     **{})
    # TODO: This is a stub to prevent pycharm from complaining about the function being unused.
    #  Refactor and remove the stub after writing tests for the function.
    pass


# Generated at 2022-06-23 11:15:53.561699
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    from ansible.plugins import filters, tests
    from ansible.errors import AnsibleError

    # Test initialization
    # Test for a good set of parameters
    jl = Jinja2Loader('ansible.plugins.filters', 'FilterModule')
    jl.add_directory(os.path.dirname(filters.__file__))
    assert jl.paths == [os.path.dirname(filters.__file__)]
    assert jl.package == 'ansible.plugins.filters'
    assert jl.subdir == 'filter_plugins'
    assert jl.class_name == 'FilterModule'
    assert jl.base_class == 'FilterModule'

    # Test for a good set of parameters
    jl = Jinja2Loader('ansible.plugins.tests', 'TestModule')
    jl

# Generated at 2022-06-23 11:16:04.903486
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    # create an instance of the class to be tested
    plugin_loader = PluginLoader()
    # patch the object attribute 'package'

# Generated at 2022-06-23 11:16:16.147881
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    context = PluginLoadContext()
    assert context.original_name is None
    assert context.redirect_list is not None
    assert context.resolved is False
    assert context.error_list is not None
    assert context.import_error_list is not None
    assert context.load_attempts is not None
    assert context.pending_redirect is None
    assert context.exit_reason is None
    assert context.plugin_resolved_path is None
    assert context.plugin_resolved_name is None
    assert context.plugin_resolved_collection is None
    assert context.deprecated is False
    assert context.removal_date is None
    assert context.removal_version is None
    assert context.deprecation_warnings is not None
    assert context._resolved_fqcn is None

# Unit test

# Generated at 2022-06-23 11:16:18.015736
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    import os
    print('get_with_context: ', os.path)
    assert True

# Generated at 2022-06-23 11:16:29.505631
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    #
    # Test that find_plugin returns the correct plugin fqcn
    #
    pl = PluginLoader('sometype', 'ansible.plugins.sometype', C.DEFAULT_INVENTORY_PLUGIN_PATH, 'sometype')
    result = pl.find_plugin('foo')
    assert result == 'ansible.plugins.sometype.foo'
    result = pl.find_plugin('bar')
    assert result is None
    result = pl.find_plugin('foo', collection_list=['ansible_collections.namespace.foo'])
    assert result == 'ansible_collections.namespace.foo.plugins.sometype.foo'
    result = pl.find_plugin('bar', collection_list=['ansible_collections.namespace.foo'])
    assert result is None


# Generated at 2022-06-23 11:16:42.016583
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    # Test with provided a specific plugin type
    pluginLoader = PluginLoader('module_utils', 'ModuleUtilsCore')
    assert pluginLoader.package == 'ansible.module_utils'
    assert pluginLoader.class_name == 'ModuleUtilsCore'
    assert pluginLoader.path_priority == ['module_utils']
    assert pluginLoader.base_class is None
    assert pluginLoader.all_candidates == {}
    assert pluginLoader.aliases == {}

    # Test with default args, the default plugin type is 'module'
    pluginLoader = PluginLoader()
    assert pluginLoader.package == 'ansible.modules'
    assert pluginLoader.class_name == 'AnsibleModule'
    assert pluginLoader.path_priority == ['modules']
    assert pluginLoader.base_class is None
    assert pluginLoader.all_candidates == {}
   

# Generated at 2022-06-23 11:16:47.012773
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    """ Unit test to verify add_dirs_to_loader() """
    assert hasattr(sys.modules[__name__], 'module_loader')


# TODO: This can probably be depricated if we don't try to support single transform loading
#       from both module_utils AND plugins/modules

# Generated at 2022-06-23 11:16:56.529490
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    file1 = C.get_config_value('DEFAULT_MODULE_PATH') + '/test_module.py'
    file2 = C.get_config_value('DEFAULT_MODULE_PATH') + '/test_module.ps1'
    file3 = C.get_config_value('DEFAULT_MODULE_PATH') + '/test_module.exe'
    mock_file_system = Mock()
    mock_file_system.isfile.side_effect = lambda name: name in [file1, file2, file3]
    mock_file_system.split_path.side_effect = lambda name: [name, 'test_module']
    mock_file_system.path_dwim.side_effect = lambda name: name
    mock_file_system.get_real_path.side_effect = lambda name: name


# Generated at 2022-06-23 11:17:03.897403
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    context = PluginLoadContext()
    assert not context.resolved
    assert not context.plugin_resolved_path
    assert not context.plugin_resolved_collection
    assert not context.plugin_resolved_name
    assert not context.exit_reason
    assert not context.deprecated
    assert not context.removal_date
    assert not context.removal_version
    assert len(context.deprecation_warnings) == 0



# Generated at 2022-06-23 11:17:10.297921
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    ''' Unit test for function add_dirs_to_loader '''
    from ansible.plugins import module_loader
    module_loader.all.clear()
    add_dirs_to_loader('module', ['/usr/local/lib/ansible/modules', './my_modules'])

    assert(len(module_loader.all()) == 0)
    assert(len(module_loader.path_cache) == 2)


# Generated at 2022-06-23 11:17:18.754284
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    loader = PluginLoader(os.path.join("path", "to", "plugins"))
    assert len(loader.aliases) == 0
    loader.add_directory("/some/path")
    assert len(loader.aliases) == 0
    loader.package = "ansible.plugins"
    loader.class_name = "ShellModule"
    loader.base_class = "Module"
    loader.get("plugin.name", "/dev/null")
    loader.all("some.thing")
    loader.has_plugin("some.thing", ["collection1", "collection2"])
    loader.find_plugin("some.thing", ["collection1", "collection2"])
    loader.find_plugin_with_context("some.thing", ["collection1", "collection2"])

# Generated at 2022-06-23 11:17:28.679404
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    import tempfile
    import shutil
    import multiprocessing
    import os
    tmpdir = tempfile.mkdtemp()
    tmpdir2 = tempfile.mkdtemp()
    tmpdir3 = tempfile.mkdtemp()
    tmpdir4 = tempfile.mkdtemp()

    modules_path1 = os.path.join(tmpdir, 'module_utils')
    modules_path2 = os.path.join(tmpdir2, 'module_utils')
    plugins_path1 = os.path.join(tmpdir3, 'plugins')
    plugins_path2 = os.path.join(tmpdir4, 'plugins')

    paths = [tmpdir, tmpdir2, tmpdir3, tmpdir4]
    os.makedirs(modules_path1)

# Generated at 2022-06-23 11:17:39.173722
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    # test with the expected defaults
    # test with all True except display_paths
    # test with all True except display_prio
    # test with all True except display_nops
    pl = PluginLoader("TestLoader")
    pl.add_directory("dir1", with_subdir=False)
    if not os.path.isdir("dir1"):
        os.mkdir("dir1")
    
    with open("dir1/__init__.py", "w") as f:
        f.write("")
    with open("dir1/f1.py", "w") as f:
        f.write("")
    with open("dir1/f2.py", "w") as f:
        f.write("")
    pl.print_paths()
