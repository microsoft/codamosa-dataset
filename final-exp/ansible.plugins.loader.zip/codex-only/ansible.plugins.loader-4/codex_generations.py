

# Generated at 2022-06-23 11:07:52.866312
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    this_class = class_of(PluginLoader)
    this_class_instance = this_class()
    assert this_class_instance.format_paths([]) == "None"
    assert this_class_instance.format_paths(["a"]) == "a"
    assert this_class_instance.format_paths(["a", "b"]) == "a,b"
    assert this_class_instance.format_paths(["a", "b", "c"]) == "a,b,c"

# Generated at 2022-06-23 11:07:57.019133
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    # Constructor will call check_conditional() which requires a valid config object to exist but
    # at this point we haven't initialized Ansible yet.
    # Need to setup PlayContext object first.
    p = PluginLoader(None, '', '', '', '')
    assert p is not None


# Generated at 2022-06-23 11:08:07.756651
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    redirect_test_name = 'redirect_test_name'
    redirect_test_context = PluginLoadContext()
    redirect_test_context.original_name = 'original_name_test'
    redirect_result = redirect_test_context.redirect(redirect_test_name)
    fail_flag = True
    if redirect_result.pending_redirect == redirect_test_name and redirect_result.exit_reason == 'pending redirect resolution from original_name_test to redirect_test_name' and redirect_result.resolved == True:
        fail_flag = False
    if fail_flag:
        raise AssertionError('Test of method redirect of class PluginLoadContext FAILED\n')


# Generated at 2022-06-23 11:08:18.520562
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    from ansible.plugins.loader import PluginLoader

    plugin_loader = PluginLoader('connections')
    plugin_load_context = plugin_loader.find_plugin('netconf')
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'netconf'
    assert plugin_load_context.plugin_resolved_class == 'NetworkConnection'
    assert plugin_load_context.plugin_resolved_path.endswith('ansible/plugins/connections/netconf.py')
    assert plugin_load_context.plugin_type == 'connection'
    assert plugin_load_context.redirect_list == []
    assert not plugin_load_context.cached

    plugin_load_context = plugin_loader.find_plugin('network_cli')
    assert plugin_load_context.res

# Generated at 2022-06-23 11:08:19.108327
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    pass



# Generated at 2022-06-23 11:08:27.634431
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    loader = PluginLoader(package='ansible_collections.test.test_plugin_loader.test_plugins',
                          subdir='test_plugins',
                          class_name='PluginLoaderTest1')
    assert 'PluginLoaderTest1' in loader
    assert 'test_plugins.test_PluginLoader.PluginLoaderTest1' in loader
    assert 'test_plugins.test_PluginLoader.PluginLoaderTest2' in loader
    assert 'test_plugins.test_PluginLoader.PluginLoaderTest2a' in loader
    assert 'test_plugins.test_PluginLoader.PluginLoaderTest2b' in loader
    assert 'test_plugins.test_PluginLoader.Test2' in loader
    assert 'test_plugins.test_PluginLoader.Test2a' in loader
    assert 'test_plugins.test_PluginLoader.Test3' in loader

# Generated at 2022-06-23 11:08:32.443367
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    c = PluginLoader(package='ansible.plugins.test', directories=[tmp_dir_path], class_name='Test')
    assert c.get_with_context('bogus').resolved is False
    assert c.get_with_context('test_plugin').resolved is True
    assert c.get_with_context('test_plugin').object.__class__.__name__ == 'TestPlugin'

# Generated at 2022-06-23 11:08:36.650464
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    plc = PluginLoadContext()
    plc.record_deprecation(name='connections.local', deprecation=dict(warning_text="warning_text"), collection_name='test_collection')
    assert plc.deprecation_warnings == ['connections.local has been deprecated. warning_text']


# Generated at 2022-06-23 11:08:42.093492
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    plugin_path_context = PluginPathContext(path="path", internal=False)

    assert plugin_path_context is not None
    assert plugin_path_context.path == "path"
    assert plugin_path_context.internal == False


# Generated at 2022-06-23 11:08:45.839324
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    assert PluginPathContext('/test/test_path', False).path == '/test/test_path'
    assert PluginPathContext('/test/test_path', False).internal is False



# Generated at 2022-06-23 11:08:49.105973
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin(shell_type='sh', executable='/usr/bin/sh')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/usr/bin/sh'



# Generated at 2022-06-23 11:08:57.620825
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    test_context = PluginLoadContext()
    warnings.simplefilter("ignore")
    test_context.record_deprecation("test_name", { "warning_text": "This feature is deprecated", "removal_version": "2.9" }, "")
    assert test_context.exit_reason == None
    assert test_context.plugin_resolved_path == None
    assert test_context.plugin_resolved_name == None
    assert test_context.plugin_resolved_collection == None
    assert test_context.deprecated == True
    assert test_context.removal_date == None
    assert test_context.removal_version == "2.9"
    assert test_context.deprecation_warnings == ["test_name has been deprecated. This feature is deprecated"]

# Generated at 2022-06-23 11:09:06.173474
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert getattr(sys.modules[__name__], 'shell_loader', None) is None
    add_dirs_to_loader('shell', ['/path/to/shells'])
    assert isinstance(getattr(sys.modules[__name__], 'shell_loader'), PluginLoader)
    assert getattr(sys.modules[__name__], 'shell_loader').package != 'ansible.plugins.shell'
    assert getattr(sys.modules[__name__], 'shell_loader').directory == '/path/to/shells'
    assert getattr(sys.modules[__name__], 'shell_loader')._find_path_cache == {}



# Generated at 2022-06-23 11:09:13.166944
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():

    class TestPlugin(object):
        def __init__(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c

    # Create a fake module with one plugin
    plugin_path = '/path/to/test_plugin'

    fake_module = types.ModuleType(plugin_path)
    fake_module.TestPlugin = TestPlugin

    # Create a loader and patch it with fake module
    test_loader = PluginLoader('test_loader', 'path', 'package', 'class', 'base_class')
    test_loader._module_cache = {plugin_path: fake_module}

    # Create a load context

# Generated at 2022-06-23 11:09:17.142228
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    # Test instantiation of the class
    my_test_loader = PluginLoader("module_utils", 'ansible.module_utils', 'AnsibleModule')

    # Test repr
    repr(my_test_loader)

    # Make sure the class variables are accessible
    my_test_loader.package
    my_test_loader.config_def_cache_file
    my_test_loader.subdir
    my_test_loader.class_name
    my_test_loader.aliases
    my_test_loader.base_class

    # Test the logic to build paths
    my_test_loader._base_dirs()

# Generated at 2022-06-23 11:09:23.105306
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    import ansible.plugins.loader
    loader = ansible.plugins.loader.Jinja2Loader()

    from ansible.errors import AnsibleError
    try:
        loader.get('dummy')
    except AnsibleError:
        pass
    except Exception as e:
        assert False, 'Jinja2Loader.get(dummy) did not raise AnsibleError as expected, instead raised %s' % e

    from ansible.plugins.loader import find_plugin
    plugin = find_plugin('lookup','dns')
    assert plugin == 'plugin', 'Find plugin dns lookup is not returning plugin module as expected'



# Generated at 2022-06-23 11:09:34.915312
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    import ansible.plugins.loader
    loader = ansible.plugins.loader.PluginLoader('callback')
    # test with a bare name
    ctx = loader.find_plugin_with_context('foo')
    assert ctx.resolved
    assert ctx.plugin_name == 'foo'
    assert ctx.plugin_resolved_name == 'foo'
    assert ctx.plugin_resolved_path.endswith('/ansible/plugins/callback/foo.py')

    # test redirects
    ctx = loader.find_plugin_with_context('default')
    assert ctx.resolved
    assert ctx.plugin_name == 'default'
    assert ctx.plugin_resolved_name == 'default'

# Generated at 2022-06-23 11:09:42.317614
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    plugin_load_context = PluginLoadContext()
    plugin_load_context = plugin_load_context.record_deprecation(name='', deprecation={}, collection_name='')
    assert plugin_load_context.removal_date is None
    assert plugin_load_context.deprecation_warnings == []



# Generated at 2022-06-23 11:09:49.124497
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():

    obj = PluginLoader("some.name", "some.package", "some.class_name")
    assert isinstance(obj, object)

    obj.aliases = {
        'foo': 'bar',
        'bar': 'zebra',
    }

    obj.subdir = 'filter_plugins'

    obj._module_cache = {
        'module_path': None,
    }

    obj._searched_paths = []

    obj.plugin_paths = [
        '/some/path',
        '/some/other/path',
    ]

    result = repr(obj)

# Generated at 2022-06-23 11:09:50.264059
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    assert get_all_plugin_loaders()



# Generated at 2022-06-23 11:09:58.913521
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    plugin_loader = PluginLoader(
        package='ansible.plugins.lookup',
        class_name='LookupBase'
    )
    assert plugin_loader._class_name == 'LookupBase'
    assert plugin_loader._class_name == plugin_loader.class_name
    assert plugin_loader._alias_packages == ['ansible_collections.all', 'ansible_collections.ansible.builtin', 'ansible_collections.ansible.builtin.plugins', 'ansible_collections.config_collection.plugins', 'ansible_collections.community.general.plugins']
    assert plugin_loader._package == 'ansible.plugins.lookup'
    assert plugin_loader._package == plugin_loader.package
    assert plugin_loader._paths == plugin_loader.paths

# Generated at 2022-06-23 11:10:11.057904
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Test with specific path to test module
    module_path = os.path.join(os.path.dirname(__file__), 'test_utils')
    plugin_load_context = PluginLoader(package='ansible_collections.ansible.test.test_utils', subdir='plugins', class_name='TestClass', base_class='TestBaseClass', config_base='test_config').get_with_context('testplugin.py', collection_list=['ansible.test'], path_only=True)

    assert plugin_load_context.resolved is True
    assert plugin_load_context.plugin_resolved_name == 'test_utils.testplugin.TestClass'
    assert plugin_load_context.plugin_resolved_path == os.path.join(module_path, 'plugins', 'testplugin.py')

# Generated at 2022-06-23 11:10:20.095751
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Test for method __setstate__ of class PluginLoader
    '''
    # FIXME: This should actually test something,
    #        but it doesn't work because _get_paths is not defined anywhere
    if False:
        _test_plugin_loader = PluginLoader(package='ansible.plugins.test')

        # Since pylint does not know about the dynamic nature of PluginLoader,
        # and since it does not find the __setstate__ method, it emits a false positive
        _test_plugin_loader.__setstate__({'_searched_paths': _test_plugin_loader._get_paths()})

# Generated at 2022-06-23 11:10:27.902399
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    ctx = PluginLoadContext()
    assert ctx.original_name == None
    assert ctx.redirect_list == []
    assert ctx.error_list == []
    assert ctx.import_error_list == []
    assert ctx.load_attempts == []
    assert ctx.pending_redirect == None
    assert ctx.exit_reason == None
    assert ctx.plugin_resolved_path == None
    assert ctx.plugin_resolved_name == None
    assert ctx.plugin_resolved_collection == None
    assert ctx.deprecated == False
    assert ctx.removal_date == None
    assert ctx.removal_version == None
    assert ctx.deprecation_warnings == []
    assert ctx.resolved == False
    assert ctx._res

# Generated at 2022-06-23 11:10:38.173436
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    a = {'warning_text': 'Something here', 'removal_date': 'today'}
    b = {'warning_text': 'Something here', 'removal_date': 'tomorrow'}
    c = {'warning_text': 'Something here', 'removal_date': 'yesterday'}
    d = {'warning_text': 'Something here', 'removal_version': '1.1'}
    e = {'warning_text': 'Something here', 'removal_version': '1.2'}
    f = {'warning_text': 'Something here', 'removal_version': '1.0'}
    g = {'warning_text': 'Something here'}

# Generated at 2022-06-23 11:10:49.668514
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    pl = PluginLoader("foo/bar", "baz", "buzz", "bizz")
    assert pl.package == 'baz', pl.package
    assert pl.base_class == 'buzz', pl.base_class
    assert pl.subdir == 'bizz', pl.subdir
    assert pl.paths == ['foo/bar'], pl.paths
    assert pl.aliases == {}, pl.aliases

    # Test that it accepts a directory as a string
    pl = PluginLoader("foo/bar", "baz", "buzz", "bizz", dirs="dir1")
    assert pl.paths == ['dir1'], pl.paths

    # Test that it accepts a list of directories

# Generated at 2022-06-23 11:10:56.350757
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    b_temp_directory = tempfile.mkdtemp(prefix='tests')
    _dirs = ['dir1', 'dir2', 'dir3']
    # Test to add multiple directories
    for d in _dirs:
        os.mkdir(os.path.join(b_temp_directory, d))
    # Instantiate an object to call a test function
    pl = PluginLoader(package="test.pkg")
    pl.add_directory(b_temp_directory, 'dir1')
    # Test item in list is a byte string returned by os.listdir()
    assert isinstance(list(pl._listdir())[0], bytes)
    # Test item in the list is returned with full path
    assert list(pl._listdir())[0].startswith(b_temp_directory)
    # Test full path is converted to unic

# Generated at 2022-06-23 11:11:08.664048
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():

    from ansible.utils.display import Display
    from ansible.utils.plugin_docs import get_docfragment

    class Args:
        deprecated = True
        collection = 'ansible.builtin'
        collection_path = '.'
        fragment = None

    args = Args()
    display = Display()
    context = PluginLoadContext()
    test1 = {
        "description": "This is an example plugin.",
        "deprecated": {
            "reason": "This plugin was never a real one, just an example.",
            "warning_text": "In Ansible 2.0, this plugin will be removed.",
            "removal_date": "Fri Jun 24 2020",
            "removal_version": "6.0.0"
        }
    }
    context.original_name = 'shell'
    context.record

# Generated at 2022-06-23 11:11:22.038863
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    proxy_loader = PluginLoader('this_is.a.package_for_unit_testing_only', package_subdir='plugins', aliases={}, required_base_class=None)
    plugin_paths = set(plugin_path for plugin_path in proxy_loader._get_paths())
    assert plugin_paths == set(['test_plugins'])
    proxy_loader.add_directory('/home/foo/.ansible/plugins/bar/')
    plugin_paths = set(plugin_path for plugin_path in proxy_loader._get_paths())
    assert plugin_paths == {'/home/foo/.ansible/plugins/bar/', 'test_plugins'}
    proxy_loader.add_directory('/home/foo/.ansible/plugins/baz/')

# Generated at 2022-06-23 11:11:32.137400
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    def _fake_isdir(path):
        return path.endswith('/test_dir')

    def _fake_isfile(path):
        return True

    class PluginLoader:
        def __init__(self, name, path):
            self.name = name
            self.path = path
            PluginLoader.counter += 1

        def add_directory(self, path):
            PluginLoader.result.append(self.name, path)

    class PluginLoader2(PluginLoader):
        pass

    class PluginLoader1(PluginLoader):
        # no subdir
        pass

    paths = ['/path/to/ansible/test_dir', '/path/to/ansible/test_dir2']

    old_isdir = os.path.isdir
    old_isfile = os.path.isfile
    old_gl

# Generated at 2022-06-23 11:11:39.650396
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    if not os.path.isdir('testplugin'):
        os.mkdir('testplugin')
    add_all_plugin_dirs('testplugin')
    if os.path.isdir('testplugin/action'):
        display.warning("testplugin/action has been added")
    else:
        assert False
    if os.path.isdir('testplugin/connection'):
        display.warning("testplugin/connection has been added")
    else:
        assert False
    if os.path.isdir('testplugin/shell'):
        display.warning("testplugin/shell has been added")
    else:
        assert False
    if os.path.isdir('testplugin/strategy'):
        display.warning("testplugin/strategy has been added")
    else:
        assert False

# Generated at 2022-06-23 11:11:48.844159
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    plugin_loader = PluginLoader()
    plugin_loader.add_directory('path1')
    assert plugin_loader._get_paths() == ['path1']
    plugin_loader.add_directory('path2', with_subdir=True)
    assert plugin_loader._get_paths() == ['path1', 'path2/action_plugins', 'path2/cache_plugins', 'path2/callback_plugins', 'path2/cliconf_plugins', 'path2/connection_plugins', 'path2/filter_plugins', 'path2/httpapi_plugins', 'path2/inventory_plugins', 'path2/lookup_plugins', 'path2/shell_plugins', 'path2/vars_plugins']


# Generated at 2022-06-23 11:12:00.350930
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():

    def reset_loader(which_loader):
        setattr(sys.modules[__name__], '%s_loader' % which_loader, PluginLoader("%s %s" % (which_loader, "plugin"), "%s_%s" % (which_loader, 'plugin')))

    tmpdir = os.path.join(C.DEFAULT_LOCAL_TMP, "ansible_test_plugin_loader")
    if os.path.exists(tmpdir):
        shutil.rmtree(tmpdir)

    os.makedirs(tmpdir)

    default_dirs = sys.modules[__name__].action_loader.get_dirs()
    for dirname in default_dirs:
        os.makedirs(os.path.join(tmpdir, os.path.basename(dirname)))

   

# Generated at 2022-06-23 11:12:07.992391
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    class TestPluginLoader(PluginLoader):
        def __init__(self):
            super(TestPluginLoader, self).__init__('ansible.plugins.action. TestPluginLoader', '', 'TestPluginLoader', 'TestPluginLoader')

    data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

    display.verbosity = 4
    ploader = TestPluginLoader()

    # test basic find_plugin
    path = ploader.find_plugin('ping')
    assert path.endswith('ping')

    # test basic find_plugin_with_context
    plugin_load_context = ploader.find_plugin_with_context('ping')
    assert plugin_load_context.plugin_resolved_path.endswith('ping')

    #

# Generated at 2022-06-23 11:12:10.818346
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    b_path = '/tmp/test_add_all_plugin_dirs'
    display.verbosity = 3
    add_all_plugin_dirs(b_path)



# Generated at 2022-06-23 11:12:17.150570
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    j2l = Jinja2Loader('ansible.plugins.filter','FilterModule','core', 'filter_plugins')
    assert j2l._dedupe == False
    assert j2l.package == 'ansible.plugins.filter'
    assert j2l.class_name == 'FilterModule'
    assert j2l.base_class == 'core'
    assert j2l.subdir == 'filter_plugins'


# Generated at 2022-06-23 11:12:23.115461
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    import doctest
    from ansible.parsing.dataloader import DataLoader

    yaml_plugins = load_plugins(os.path.join(os.path.dirname(__file__), '..', 'plugins'))
    yaml_filter_loader = Jinja2Loader('ansible.plugins.yaml_filters', 'FilterModule', 'yamlfilter_base', yaml_plugins)

    loader = DataLoader()

    def get_filter(name):
        return yaml_filter_loader.get(name)

    doctest.run_docstring_examples(get_filter, globals())

# Generated at 2022-06-23 11:12:24.835598
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    # FIXME: write test
    pass


# Generated at 2022-06-23 11:12:28.306417
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():

    # plugin_finder_system.find_plugin(name, class_only=class_only, mod_type=mod_type)

    # FIXME: don't know how to test, need some real plugins
    pass

# Generated at 2022-06-23 11:12:31.566505
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    import ansible.plugins.callback
    loader = ansible.plugins.callback.CallbackModule.get_loader()
    callbacks = loader.get('default', 'sample.load')
    assert callbacks



# Generated at 2022-06-23 11:12:33.924296
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    '''Unit test for method find_plugin of class PluginLoader.

    :returns: None
    :rtype: None

    '''
    pass

# Generated at 2022-06-23 11:12:40.083341
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    # We are testing that we can use the class.
    # We don't really care about the path mocks at the moment.
    ansible_paths = AnsiblePath()
    loader = Jinja2Loader('test', 'test', 'test', 'test', ansible_paths.path)
    assert loader is not None


# Generated at 2022-06-23 11:12:44.288020
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    '''
    jinja2_loader = Jinja2Loader('ansible.test_plugins','test','test')
    res = jinja2_loader.find_plugin('ping')
    assert res == 'ansible/test_plugins/test/ping.py'
    '''
    pass


# Generated at 2022-06-23 11:12:55.019193
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    p = PluginLoader("ansible_collections.nsbl.collection.plugins.tests.unit.modules", "FooModule", '_', 'foo_', ['args'])
    p.add_directory(os.path.join(os.path.dirname(__file__), 'fixtures', 'valid_plugins'))

    r = p.find_plugin(name='bar')
    assert not r.resolved
    assert r.name == 'bar'
    assert r.resolved_with == 'nope'

    r = p.find_plugin(name='foo_bar')
    assert r.resolved
    assert r.name == 'foo_bar'
    assert r.resolved_with == 'original'
    assert r.plugin_resolved_name == 'foo_bar'

# Generated at 2022-06-23 11:13:05.668021
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    # String to reference the class being tested
    test_class = "PluginLoader"

    #########################################################################
    # This section tests the creation of a new object using the default   #
    # constructor.                                                         #
    #########################################################################
    print(">>>\n>>> RUNNING '{0}' TESTS\n>>>".format(test_class))

    #########################################################################
    # This section tests the creation of a new object using the default   #
    # constructor.                                                         #
    #########################################################################

    # Plugin:
    # name = 'a'
    # suffix = 'py'

    plugin_name = 'a'
    plugin_suffix = '.py'
    expected_return = 'a'
    expected_return_class = 'PluginLoaderContext'


# Generated at 2022-06-23 11:13:10.309971
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    path = os.path.join(os.getcwd(), '../test/sanity/code/plugins')
    add_all_plugin_dirs(path)
    assert len(MODULE_CACHE) == 1



# Generated at 2022-06-23 11:13:14.292774
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    class PluginLoaderTest(unittest.TestCase):
        def test_get_with_context(self):
            # test get_with_context(name,*args,**kwargs):
            pass


# Generated at 2022-06-23 11:13:24.056518
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    class TestPlugin(object):
        pass

    loader1 = PluginLoader("test", "TestPlugin", "TestModuleName", "test/path")
    loader2 = PluginLoader("test", "TestPlugin", "TestModuleName", ["test/path1", "test/path2"])
    loader3 = PluginLoader("test", "TestPlugin", "TestModuleName", ["test/path1", ["test/path2", "test/path3"]])

    loader_with_base = PluginLoader("test", "TestPlugin", "TestModuleName", "test/path", class_only=True, base_class="TestBaseClass")
    loader_with_base.load_plugin(TestPlugin())

    # Test loading module with 'base' in the name. This will also test whether the
    # 'base' file is successfully added to the filter list and skipped.
   

# Generated at 2022-06-23 11:13:28.863312
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    plc = PluginLoadContext()
    plc_2 = plc.redirect('foo')
    assert plc_2.pending_redirect == 'foo'
    assert plc_2.exit_reason == 'pending redirect resolution from None to foo'
    assert plc_2.resolved is False


# Generated at 2022-06-23 11:13:39.841230
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    class MockJinja2Plugin():
        pass
    class MockJinja2Plugin2():
        pass

    import tempfile
    temp_dir = tempfile.mkdtemp()

    # Create 2 directories, with 2 files having different plugins in each directory.
    # Then we'll get all the plugins and make sure we have 4.
    file_path = os.path.join(temp_dir, 'test_jinja2_plugin.py')
    with open(file_path, 'w') as f:
        f.write('class MockJinja2Plugin():\n')
        f.write('  pass\n')

    file_path = os.path.join(temp_dir, 'test_jinja2_plugin2.py')

# Generated at 2022-06-23 11:13:42.644170
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    '''
    Unit test for method get of class Jinja2Loader
    '''
    # This class does not implement get for this type of plugin, do not add tests
    pass

# Generated at 2022-06-23 11:13:54.854837
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    play_context = PlayContext('localhost', True, False, play=Play().load({}, loader=MockLoader()))
    loader = PluginLoader('type_name', 'parent_class', 'package_name', 'path1')
    loader.aliases = {'foo': 'bar'}
    loader._searched_paths = ['path1', 'path2']
    loader._display = True
    loader._package = 'package_name'

    # Test without aliases
    loader.aliases = {}
    loader.__setstate__(loader.__getstate__())
    assert loader.aliases == {}

    # Test with aliases
    loader.aliases = {'foo': 'bar'}
    loader.__setstate

# Generated at 2022-06-23 11:13:58.776474
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    from ansible.plugins.loader import collection_loader
    loader = PluginLoader('collection', 'CollectionsFinder', 'collections', aliases=[])
    results = loader.find_plugin('test', collection_list=[])
    assert results == None


# Generated at 2022-06-23 11:14:05.034527
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    # Test get_with_context_result with good context
    sample_str = 'good_context'
    sample_callback_result = get_with_context_result(sample_str)
    assert sample_callback_result['output'] == sample_str
    assert sample_callback_result['context'] == sample_str

    # Test get_with_context_result with None context
    sample_str = 'None_context'
    sample_callback_result = get_with_context_result(sample_str, context=None)
    assert sample_callback_result['output'] == sample_str
    assert sample_callback_result['context'] is None

# Generated at 2022-06-23 11:14:15.686738
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    import collections
    name = 'test_PluginLoader_name13121'
    collection_list = 'test_PluginLoader_collection_list13122'
    expected = 'test_PluginLoader_expected13123'
    has_plugin_mock = collections.namedtuple('has_plugin_mock', 'expected,call_count')
    
    def has_plugin_mock(name, collection_list):
        has_plugin_mock.call_count += 1
        assert has_plugin_mock.expected.name == name
        assert has_plugin_mock.expected.collection_list == collection_list
        return has_plugin_mock.expected.return_value

    has_plugin_mock.expected = has_plugin_mock(name, collection_list)
    has_plugin_mock.call_count = 0
    

# Generated at 2022-06-23 11:14:27.823769
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    # Class to replace 'imp'
    class MockImp:

        # Mocks imp.find_module
        @staticmethod
        def find_module(name, path=None):
            modules = {'ansible.plugins.connection.ssh': '/ansible/plugins/connection/ssh.py',
                       'ansible.plugins.cache.memory': '/ansible/plugins/cache/memory.py'}
            return modules.get(name)

    # Class to replace 'importlib'
    class MockImportlib:

        # Mocks importlib.import_module
        @staticmethod
        def import_module(name):
            modules = {'ansible.plugins.cache': '/ansible/plugins/cache'}
            return modules.get(name)

    # Class to replace 'importlib.util'

# Generated at 2022-06-23 11:14:36.324690
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    '''
    Unit test for PluginLoader.get_with_context
    '''
    curr = os.path.dirname(os.path.realpath(__file__))
    os.chdir(curr)

    name = 'fixture'
    loader = PluginLoader(
        package='ansible.plugins',
        config=None,
    )
    result = loader.get_with_context(name=name)

    assert result.resolved
    assert result.plugin_resolved_name == name
    assert isinstance(result.object, test_module.FixtureModule)



# Generated at 2022-06-23 11:14:38.533001
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    c = PluginPathContext("/foo/bar", True)
    assert c.path == "/foo/bar"
    assert c.internal is True


# Generated at 2022-06-23 11:14:46.200318
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    import ansible.plugins.module_loader

    # This test must ensure that the constructor of PluginLoader does not
    # attempt to import any ansible.plugins package, to avoid import errors
    # when some plugins are not available on the testing system

    # Create an instance of PluginLoader
    loader = PluginLoader(
        'module_utils',
        'ActionModule',
        C.DEFAULT_MODULE_UTILS_PATH,
        'ansible.module_utils',
        'ansible.module_utils'
    )

    assert loader.package == 'ansible.module_utils'
    assert 'ansible.module_utils' not in sys.modules

    # In addition, we need to make sure that no import of the module
    # ansible.plugins was attempted, either directly nor indirectly
    # This is required because the modules in the package ansible.

# Generated at 2022-06-23 11:14:54.211695
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    from ansible.plugins.loader import _PLUGIN_PATH_CACHE

    # 1. find_plugin with args name and collection_list
    ansible_collection = 'ansible.collection.test'

# Generated at 2022-06-23 11:15:05.505753
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    plc = PluginLoadContext()
    plc.original_name = 'original_name'
    plc.redirect_list = []
    plc.error_list = []
    plc.import_error_list = []
    plc.load_attempts = []
    plc.pending_redirect = None
    plc.exit_reason = None
    plc.plugin_resolved_path = None
    plc.plugin_resolved_name = None
    plc.plugin_resolved_collection = None
    plc.deprecated = False
    plc.removal_date = None
    plc.removal_version = None
    plc.deprecation_warnings = []
    plc.resolved = False
    plc._resolved_fqcn = None
    assert plc

# Generated at 2022-06-23 11:15:10.308359
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    plugin_path = '/tmp/ansible-test/test_plugins'
    from unittest.mock import patch
    with patch('ansible.plugins.loader.PluginLoader.add_directory') as mock_add_directory:
        add_all_plugin_dirs(plugin_path)
        mock_add_directory.assert_not_called()



# Generated at 2022-06-23 11:15:13.851995
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    pl = PluginLoader('tests.units.test_plugin_loader.fake_package', 'FakeClass')
    assert list(pl.all()) == ["path/to/file1", "path/to/file2"]

# Generated at 2022-06-23 11:15:16.910879
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    pl = PluginLoader('foo', 'bar')
    assert pl.__repr__() == 'foo.bar'


# Generated at 2022-06-23 11:15:28.138416
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    # Case where shell_type has to be used to get the right shell
    shell = get_shell_plugin(shell_type='sh')
    assert shell.HAS_PERSISTENT_CONNECTIONS is True
    assert shell._ps_cls.__name__ == 'Command'

    shell = get_shell_plugin(shell_type='powershell')
    assert shell.HAS_PERSISTENT_CONNECTIONS is True
    assert shell._ps_cls.__name__ == 'Powershell'

    # Case where shell_type has to be inferred from executable
    shell = get_shell_plugin(executable='/bin/sh')
    assert shell.HAS_PERSISTENT_CONNECTIONS is True
    assert shell._ps_cls.__name__ == 'Command'


# Generated at 2022-06-23 11:15:32.671133
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    p=PluginLoadContext()
    exit_reason = 'TEST'
    p.nope(exit_reason)
    assert p.exit_reason == exit_reason
    assert p.resolved == False


    # QA function to test new code added to class PluginLoadContext

# Generated at 2022-06-23 11:15:44.543573
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    pl = PluginLoader("ansible.plugins")
    pl.package = "ansible.plugins.test"
    pl.class_name = "Test"
    pl.subdir = "filter_plugins"
    pl.base_class = "FilterModule"

    pl._searched_paths = ['0']
    pl.aliases = {'some_alias': 'some_name'}

    expected_result = dict(
        package='ansible.plugins.test',
        class_name='Test',
        subdir='filter_plugins',
        base_class='FilterModule',
        _searched_paths=['0'],
        aliases={'some_alias': 'some_name'},
        api_version=2
    )
    actual_result = pl.__getstate__()
    assert expected_result == actual_

# Generated at 2022-06-23 11:15:49.467752
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell_plugin = get_shell_plugin('csh')
    shell_plugin_2 = get_shell_plugin('sh')

    assert shell_plugin.__name__ == 'Csh'
    assert shell_plugin_2.__name__ == 'ShellModule'



# Generated at 2022-06-23 11:15:53.693014
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    from ansible.plugins.loader import PluginLoadContext
    from ansible.plugins.loader import PluginLoader
    from ansible.utils.display import Display
    from __main__ import display
    load_context = PluginLoadContext()
    display = Display()
    load_context.nope('exit_reason')
    assert load_context.exit_reason == 'exit_reason'



# Generated at 2022-06-23 11:15:54.564318
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    assert False, "Test if the method returns the correct value"

# Generated at 2022-06-23 11:15:59.855447
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    loader = PluginLoader("faketype", base_class='type', package="ansible.plugins.faketype", config_base="Ftype", subdir=None, aliases={})
    assert loader.package == "ansible.plugins.faketype"
    assert loader.base_class == "type"
    assert loader.category == "faketype"
    assert loader.class_name == "Ftype"
    assert loader.config_base == "Ftype"
    assert loader.subdir is None
    assert loader.aliases == {}


# Generated at 2022-06-23 11:16:12.934068
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    p1 = PluginLoader('test', 'prefix', 'name', 'cls')
    p1._searched_paths = None
    expected = "/path1:123,/path2:345"
    p1._found_paths = ['/path1', '/path2']
    p1._counters = {'/path1': 123, '/path2': 345}
    result = p1.format_paths()
    assert result == expected

    expected = "path1:123,path2:345"
    p1._found_paths = ['path1', 'path2']
    p1._counters = {'path1': 123, 'path2': 345}
    result = p1.format_paths()
    assert result == expected

    expected = "path1:0,path2:0"
    p1._found

# Generated at 2022-06-23 11:16:25.332551
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    global __loader
    ############################################################################################
    # Test for method get of class PluginLoader
    ############################################################################################
    # Test of invalid base class
    ############################################################################################
    # Check that it fails when the base class is invalid
    # (in this case, ansible.plugins.cache.base)
    # NOTE: Ansible has no plugin cache

    # Case 1
    # Ensure that the correct error is raised
    # when requesting a plugin that does not exist
    # ansible.plugins.cache is not implemented

    # Case 2
    # Ensure that the correct error is raised
    # when requesting a plugin that exists, but is not of a given base class
    # ansible.plugins.cache is not implemented

    # Case 3
    # Ensure that the correct error is raised
    # when requesting a plugin that exists, but is not

# Generated at 2022-06-23 11:16:33.031239
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    """
    The following is what we are testing:

    .. code-block:: python

        j2t = Jinja2Loader('ansible.plugins.filter', 'FilterModule', 'plugins/filters')
        j2t.load_plugins()
        plugins = j2t.all()

    We just did the 3 lines above.
    """
    global _PLUGIN_FILTERS
    global _PLUGIN_PATH_CACHE
    global _PLUGIN_FILES_CACHE

    def init_plugin_cache_path(path, paths):
        _PLUGIN_PATH_CACHE[path] = paths

    def init_plugin_cache_files_glob(path, files):
        _PLUGIN_FILES_CACHE[path] = files


# Generated at 2022-06-23 11:16:43.466575
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    result = get_with_context_result(
        ['one', 'two', 'three'], 'var_prefix', context_only=True)
    assert len(result) == 1
    assert result[0] == {'var_prefix': 'one', 'var_prefix+': ['two', 'three']}

    result = get_with_context_result(
        ['one', 'two', 'three'], 'var_prefix', context_only=False)
    assert len(result) == 1
    assert result[0] == {'var_prefix': 'one', 'var_prefix+': ['two', 'three']}



# Generated at 2022-06-23 11:16:48.898101
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    res = PluginLoadContext()
    res.resolve('resolved_name', 'resolved_path', 'resolved_collection', 'exit_reason')
    assert res.resolved == True
    assert res.pending_redirect == None
    assert res.plugin_resolved_name == 'resolved_name'
    assert res.plugin_resolved_path == 'resolved_path'
    assert res.plugin_resolved_collection == 'resolved_collection'
    assert res.exit_reason == 'exit_reason'

# Generated at 2022-06-23 11:16:57.758333
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    class Namespace(object):
        def __init__(self, **kwargs):
            for key in kwargs:
                setattr(self, key, kwargs[key])

    loader = Jinja2Loader(
        Namespace(
            package='ansible.legacy.plugins.filter',
            basedir='/ansible/lib/ansible/plugins/filter',
            class_name='FilterModule'),
    )

    # This is a mockup of the directory structure.
    #
    # ansible/
    # - lib/
    #   - ansible/
    #     - plugins/
    #       - filter/
    #         - __init__.py
    #         - base.py
    #         - test_plugin_name.py

    # We mock up the return value from _get_paths() to

# Generated at 2022-06-23 11:17:03.660525
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    foo_path_context = PluginPathContext('foo', False)
    assert foo_path_context.path == 'foo'
    assert foo_path_context.internal == False
    bar_path_context = PluginPathContext('bar', True)
    assert bar_path_context.path == 'bar'
    assert bar_path_context.internal == True


# Generated at 2022-06-23 11:17:14.124984
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Test with no alias mapping, path only
    loader = PluginLoader('foo.bar', package='ansible.plugins.foo', config={})
    assert loader.find_plugin('baz') == 'ansible/plugins/foo/baz.py'

    # Test with no alias mapping, no path
    loader = PluginLoader('foo.bar', package='ansible.plugins.foo', config={})
    assert loader.find_plugin('baz', mod_type='.bars') is None

    # Test with alias mapping, path only
    loader = PluginLoader('foo.bar', package='ansible.plugins.foo', aliases={'baz': 'bing'}, config={})
    assert loader.find_plugin('baz') == 'ansible/plugins/foo/bing.py'

    # Test with alias mapping, no path

# Generated at 2022-06-23 11:17:24.532715
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    # no collection path, no collection name
    assert (PluginLoadContext().resolve('name', '/path', None, '').resolved_fqcn == 'name')
    # collection path, no collection name
    assert (PluginLoadContext().resolve('name', '/path', '', '').resolved_fqcn == 'name')
    # collection path, collection name
    assert (PluginLoadContext().resolve('name', '/path', 'namespace.name', '').resolved_fqcn == 'namespace.name.name')
    # no collection path, collection name
    assert (PluginLoadContext().resolve('name', None, 'namespace.name', '').resolved_fqcn == 'namespace.name.name')



# Generated at 2022-06-23 11:17:35.702074
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    # Set up mock data
    mock_args = [(['/home/fred/ansible/lib/ansible/plugins/module_utils', '/home/fred/ansible/module_utils', '/home/fred/ansible/module_utils', '/home/fred/ansible/module_utils', '/home/fred/ansible/module_utils', '/home/fred/ansible/module_utils', '/home/fred/ansible/module_utils', '/home/fred/ansible/module_utils', '/home/fred/ansible/module_utils', '/home/fred/ansible/module_utils'], {})]

    for args, kwargs in mock_args:
        # Execute the code to be tested
        PluginLoader.print_paths(*args, **kwargs)


# Generated at 2022-06-23 11:17:38.523078
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    obj = Jinja2Loader(package=None, config=None, path=None, subdir='filter_plugins')
    assert obj.get('hostvars')




# Generated at 2022-06-23 11:17:42.705811
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    plugin_load_context = PluginLoadContext()
    exit_reason = "dummy"
    plugin_load_context.nope(exit_reason)
    assert plugin_load_context.exit_reason == exit_reason
    assert plugin_load_context.resolved == False
    assert plugin_load_context.pending_redirect == None