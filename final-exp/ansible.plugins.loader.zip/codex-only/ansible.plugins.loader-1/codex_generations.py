

# Generated at 2022-06-23 11:07:46.618569
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    plugin_loader = PluginLoader(
        package='ansible.plugins.action',
        class_name='ActionModule',
        base_path='/plugins/action',
        aliases={'bad': 'good'},
        cache={'cache': 'cached'}
    )
    plugin_loader.searchpaths = ['searchpath']
    assert repr(plugin_loader) == "PluginLoader(class_name='ActionModule', package='ansible.plugins.action', base_path='/plugins/action', aliases={'bad': 'good'}, cache={'cache': 'cached'}, searchpaths=['searchpath'])"


# Generated at 2022-06-23 11:07:56.888268
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    plugin_load_context = PluginLoadContext()
    plugin_load_context.original_name = 'test'
    plugin_load_context.redirect_list.append('test_1')
    plugin_load_context.resolve('test_2', '/tmp', 'ansible.collections.test', 'success')
    assert plugin_load_context.original_name == 'test'
    assert plugin_load_context.redirect_list == ['test_1', 'test_2']
    assert plugin_load_context.error_list == []
    assert plugin_load_context.import_error_list == []
    assert plugin_load_context.load_attempts == []
    assert plugin_load_context.pending_redirect is None
    assert plugin_load_context.exit_reason == 'success'
    assert plugin_load

# Generated at 2022-06-23 11:08:03.614117
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    plugin_loader = PluginLoader(
            package='ansible.plugins.filter',
            class_name='FilterModule',
            base_class='FilterModule',
            config_base_class='FilterModule',
            aliases={}
    )
    plugin_loader.all()
    plugin_loader = PluginLoader(
            package='ansible.plugins.test',
            class_name='TestModule',
            base_class='TestModule',
            config_base_class='TestModule',
            aliases={}
    )
    plugin_loader.all()
    plugin_loader = PluginLoader(
            package='ansible.plugins.lookup',
            class_name='LookupBase',
            base_class='LookupBase',
            config_base_class='LookupBase',
            aliases={}
    )
    plugin_loader.all()


# Generated at 2022-06-23 11:08:08.883786
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    # TODO: This should be moved to a pytest style test.
    #       This is so we can actually test the logic.
    from ansible.plugins.loader import collection_finder
    playbook_dir = 'playbooks/'
    collection_path = collection_finder._get_collection_paths_for_directory(playbook_dir)
    collection_list = collection_finder.get_collection_list(collection_path)

    # make sure to include jinja2 in plugins directories
    collection_list.append(MockCollection('ansible.legacy.plugins'))
    loader = Jinja2Loader(collection_list=collection_list)

    display.debug('filter plugins')
    display.debug('')

    filter_plugins = list(loader.all(class_only=True))

    # These plugins should come from the original ansible

# Generated at 2022-06-23 11:08:12.063856
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    loader = PluginLoader('foo')
    state = dict(searched_paths=['/foo/bar/baz'])
    loader.__setstate__(state)
    assert loader._searched_paths == state['searched_paths']


# Generated at 2022-06-23 11:08:23.117251
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    """
    Unit test for method __getstate__ of class PluginLoader
    """

    # Initialize a dummy plugin loader instance for testing
    plugin_loader = PluginLoader("my.package")

    # Call the __getstate__ method and get the corresponding state
    state = plugin_loader.__getstate__()

    assert 'package' in state
    assert state.get('package') == "my.package"
    assert 'base_class' not in state
    assert 'subdir' not in state
    assert 'class_name' not in state
    assert 'all_candidates' not in state
    assert '_searched_paths' not in state
    assert '_module_cache' not in state
    assert '_config_defs' not in state
    assert 'aliases' not in state

# Generated at 2022-06-23 11:08:31.584824
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    '''
    Unit test for method __contains__ of class PluginLoader
    '''
    # pylint: disable=no-member
    mock_self = MagicMock(spec=type('PluginLoader'))
    # pylint: enable=no-member
    mock_name = MagicMock(spec=str)
    mock_collection_list = MagicMock(spec=list)
    return_val = mock_self.has_plugin(mock_name, collection_list=mock_collection_list)
    assert return_val


# Generated at 2022-06-23 11:08:36.800025
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    """
    Make sure that PluginLoader.__getstate__() returns a valid state
    """

    class TestPluginLoader(PluginLoader):
        def __init__(self, *args, **kwargs):
            super(TestPluginLoader, self).__init__(*args, **kwargs)
            self._module_cache = {}

    _pickle_test(TestPluginLoader('test', 'test_plugintype'))

# Generated at 2022-06-23 11:08:43.773427
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    executable=['/bin/bash','','None']
    for i in executable:
        if i is '':
            shell = get_shell_plugin('sh', i)
        else:
            shell = get_shell_plugin(executable=i)
        if i=='/bin/bash':
            assert shell.executable==i
        else:
            assert shell.executable==None


# Generated at 2022-06-23 11:08:48.141011
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    plug = Jinja2Loader("ansible.legacy.filter_plugins", "FilterModule", C.DEFAULT_FILTER_PLUGIN_PATH)
    #assert isinstance(plug, Jinja2Loader)


# Generated at 2022-06-23 11:08:53.864539
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    plugin_load_context = PluginLoadContext()
    plugin_load_context.resolve('foo', 'bar', 'collection', 'reason')
    assert plugin_load_context.plugin_resolved_name == "foo"
    assert plugin_load_context.plugin_resolved_path == "bar"
    assert plugin_load_context.plugin_resolved_collection == "collection"
    assert plugin_load_context.exit_reason == "reason"
    assert plugin_load_context.resolved == True


# Generated at 2022-06-23 11:08:58.577570
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    obj = PluginLoadContext()
    assert obj.plugin_resolved_path is None
    assert obj.plugin_resolved_name is None
    assert obj.exit_reason is None
    assert obj.resolved is False
    obj.resolve('aa','bb','cc', 'dd')
    assert obj.plugin_resolved_path == 'bb'
    assert obj.plugin_resolved_name == 'aa'
    assert obj.plugin_resolved_collection == 'cc'
    assert obj.exit_reason == 'dd'
    assert obj.resolved is True

# Generated at 2022-06-23 11:09:08.537435
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    import ansible.plugins.test as test
    from ansible.utils.module_docs import get_docstring
    p = PluginLoader('test_plugins', 'TestModule', '.', 'test')
    plugins = list(p.all('param1'))
    assert len(plugins) == 1
    assert isinstance(plugins[0], test.TestModule)
    assert plugins[0].test_param() == 'param1'

    p = PluginLoader('test_plugins', 'TestModule', '.', 'test')
    plugins = list(p.all(test=42, ansible=43))
    assert len(plugins) == 1
    assert isinstance(plugins[0], test.TestModule)
    assert plugins[0].test_param() == 42
    assert plugins[0].ansible_param() == 43


# Generated at 2022-06-23 11:09:19.694438
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():

    # Test with a variety of input, and make sure that the return value is what we expected
    loader = PluginLoader('ansible.plugins.action', C.DEFAULT_ACTION_PLUGIN_PATH, 'ActionModule', 'common/action_plugin.py')
    assert loader.find_plugin('cli') == 'ansible.plugins.action.cli'
    assert loader.find_plugin('command') == 'ansible.builtin.command'
    assert loader.find_plugin('invalid') is None

    loader = PluginLoader('ansible.plugins.action', '', 'ActionModule', 'common/action_plugin.py')
    assert loader.find_plugin('cli') == 'ansible.plugins.action.cli'
    assert loader.find_plugin('command') is None
    assert loader.find_plugin('invalid') is None


# Generated at 2022-06-23 11:09:23.262720
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():


    obj = PluginLoader(b'foo.bar', 'FooLoader')
    # TODO: implement test_PluginLoader_get_with_context



# Generated at 2022-06-23 11:09:34.964296
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin('sh','/bin/sh')
    assert shell.executable == '/bin/sh'
    assert isinstance(shell, ShellBase)


_AVAILABLE_PLUGINS = {}

all_plugin_type_names = set()

for name, obj in globals().items():
    if isinstance(obj, PluginLoader) and name != 'plugin_loader':
        all_plugin_type_names.add(obj.package)

__all__ = ['get_all_plugin_loaders', 'get_shell_plugin'] + list(all_plugin_type_names)

# TODO: Remove this when we're sure that all plugin loaders are modularized

# Generated at 2022-06-23 11:09:38.672537
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    plugin_loader = PluginLoader(package='ansible.plugins.filter', base_class='FilterModule', class_name='FilterModule', aliases={},
                                 required_base_class=None, config_base=None)
    plugin_loader.add_directory() 

# Generated at 2022-06-23 11:09:42.004572
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    # There should be 3 plugin loaders, the base class PluginLoader and the
    # two derived classes, ActionPluginLoader and LookupPluginLoader
    assert len(get_all_plugin_loaders()) == 3

# Generated at 2022-06-23 11:09:44.724542
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    l = PluginLoader("foo.bar")
    l.add_directory("/foo/bar")
    l.add_directory("baz")
    assert l._get_paths() == ["/foo/bar", os.path.join("baz", "foo", "bar")]


# Generated at 2022-06-23 11:09:51.523447
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    class TestPluginLoader(PluginLoader):
        ''' used in unit tests '''
        def __init__(self, package, subdir, directories=None, plugin_loader_class_name="plugin_loader_class"):
            super(TestPluginLoader, self).__init__(package, subdir, directories=directories, plugin_loader_class_name=plugin_loader_class_name)

    # no config defs load
    foo = TestPluginLoader('foo', 'bar')
    assert isinstance(foo, PluginLoader)
    assert foo.package == 'foo'
    assert foo.subdir == 'bar'
    assert foo.class_name == 'plugin_loader_class'

    # empty config defs load
    foo = TestPluginLoader('foo', 'bar', plugin_loader_class_name=None)

# Generated at 2022-06-23 11:09:53.186940
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    a = get_with_context_result([1, 2, 3, 4], 'example')
    assert len(a) == 4
    assert a[0] == (1, 'example')
    assert a[-1] == (4, 'example')



# Generated at 2022-06-23 11:10:04.774762
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    # loaders = [('action', 'Actions'), ('cache', 'Cache'), ('callback', 'Callbacks'), ('cliconf', 'CLIConfs'),
    #           ('connection', 'Connections'), ('documentation', 'Documentations'), ('filter', 'Filters'),
    #           ('inventory', 'Inventories'), ('lookup', 'Lookups'), ('shell', 'Shells'), ('module_utils', 'ModuleUtils'),
    #           ('netconf', 'NetConfs'), ('terminal', 'Terminals'), ('test', 'Tests'), ('vars', 'Vars'),
    #           ('fragment', 'Fragments')]
    loader = PluginLoader('action', 'Actions', 'ansible.plugins.action')
    assert loader.package == 'ansible.plugins.action'
    assert loader.class_name == 'Actions'

# Generated at 2022-06-23 11:10:06.011097
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    pass


# Generated at 2022-06-23 11:10:07.844670
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    # Test that we can get all the plugin loaders from this module
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import PluginLoader
    for name, obj in globals().items():
        if isinstance(obj, PluginLoader):
            assert (name, obj) in get_all_plugin_loaders()



# Generated at 2022-06-23 11:10:19.417720
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    import warnings
    # Test deprecated() with removal_version
    def verify_warning_deprecated_removal_version(warning_message, date, version, collection_name):
        if not version:
            return None
        return version == '1.0'
    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")
        context = PluginLoadContext()
        deprecation = {
            'removal_version': '1.0',
            'warning_text': '',
            'version_added': None,
            'date_added': None,
            'removal_date': None,
            'collection_name': 'collection'
        }
        context.record_deprecation('plugin_name', deprecation, 'collection')
        #

# Generated at 2022-06-23 11:10:27.500146
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plugin_load_context = PluginLoadContext()
    assert plugin_load_context.original_name is None
    assert plugin_load_context.redirect_list == []
    assert plugin_load_context.error_list == []
    assert plugin_load_context.import_error_list == []
    assert plugin_load_context.load_attempts == []
    assert plugin_load_context.pending_redirect is None
    assert plugin_load_context.exit_reason is None
    assert plugin_load_context.plugin_resolved_path is None
    assert plugin_load_context.plugin_resolved_name is None
    assert plugin_load_context.plugin_resolved_collection is None
    assert plugin_load_context.deprecated is False
    assert plugin_load_context.removal_date is None
    assert plugin

# Generated at 2022-06-23 11:10:36.935209
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    # Adding 3 elements to the list
    PLUGIN_PATH.append('/usr/share/ansible/plugins/test/test')

    # get()
    plugin_loader = PluginLoader(
        class_name='Plugin',
        package='test.test',
        config_base='config',
        cachedir='/tmp/test'
    )
    plugin_loader.get(name='Plugin')

    # get_with_context()
    plugin_loader = PluginLoader(
        class_name='Plugin',
        package='test.test',
        config_base='config',
        cachedir='/tmp/test'
    )
    plugin_loader.get_with_context(name='Plugin')


# Generated at 2022-06-23 11:10:44.396988
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    context = PluginLoadContext()
    assert len(context.redirect_list) == 0
    assert context.exit_reason == None
    assert context.plugin_resolved_path == None
    assert context.plugin_resolved_name == None
    assert context.plugin_resolved_collection == None
    assert context.deprecated == False
    assert context.removal_date == None
    assert context.removal_version == None


# Generated at 2022-06-23 11:10:47.245121
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    test_paths = ['/test/path/one', '/test/path/two']
    add_dirs_to_loader('action', test_paths)

# Generated at 2022-06-23 11:10:52.912188
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # Setup
    jinja2_loader = Jinja2Loader("", "", "", "")

    # Test execution
    try:
        jinja2_loader.get("", "", "")
        assert False, "Unreachable code"
    except AssertionError as ae:
        # Test assertions
        raise
    except Exception as e:
        # Test assertions
        assert True, "Unexpected exception: " + str(e)




# Generated at 2022-06-23 11:10:55.835231
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    pl = PluginLoader('ansible.plugins.module_utils')
    assert repr(pl) == "PluginLoader('module_utils', 'module_utils', '_utils')"



# Generated at 2022-06-23 11:11:08.625704
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    '''
    Test if the object can be serialized and unserialized without losing state
    '''

    current_dir = os.path.dirname(os.path.realpath(__file__))

    test_dir = os.path.join(current_dir, '__test1__')

    try:
        # Clean up test directory
        shutil.rmtree(test_dir)
    except OSError:
        pass

    # Create test directory
    os.mkdir(test_dir)

    # PluginLoader object
    plugin_loader = PluginLoader(
        'ansible.module_utils.module_finder',
        'ansible.module_utils.module_finder.Finder',
        '/tmp/ansible',
        '.',
        'ansible.module_utils',
        'utils',
    )

# Generated at 2022-06-23 11:11:22.035822
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():

    from ansible.plugins.loader import PluginLoader, get_all_plugin_loaders
    # Most likely, this plugin isn't installed
    pl = PluginLoader("cache", "BaseCacheModule", "ansible.plugins.cache.base")

    assert(pl == pl.__getstate__())

    assert(not pl == PluginLoader("cli", "Cli", "ansible.cli"))

    # assert(not pl == get_all_plugin_loaders()['cache'])
    # unfortunately this is not true, as the PluginLoaders created here have no _module_cache
    # assert(not pl == get_all_plugin_loaders().get('cache'))
    cached_pl = get_all_plugin_loaders().get('cache')
    assert(cached_pl)

    assert(not pl == cached_pl.__getstate__())

# Generated at 2022-06-23 11:11:23.784523
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # PluginLoader.test_all()
    return None


# Generated at 2022-06-23 11:11:31.434584
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    loader = PluginLoader('foo.class', 'foo', 'ansible.plugins.foo')
    loader.aliases = {'bar': 'baz'}
    assert 'bar' in loader
    assert 'baz' in loader
    assert 'xxx' not in loader
    assert 'ansible.plugins.foo.bar.qux' not in loader
    assert 'ansible.plugins.foo.baz.qux' not in loader


# Generated at 2022-06-23 11:11:32.801318
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    result = get_with_context_result('foo', 'bar')
    assert result.name == 'foo'
    assert result.plugin == 'bar'
    assert result.context == []



# Generated at 2022-06-23 11:11:34.019913
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    assert PluginPathContext(path=None, internal=None)



# Generated at 2022-06-23 11:11:37.120276
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    # Test instatiation of class Jinja2Loader
    j2l = Jinja2Loader()
    assert isinstance(j2l, Jinja2Loader), "Expected Jinja2Loader instance, got: %s" % type(j2l)
    assert isinstance(j2l, PluginLoader), "Expected PluginLoader instance, got: %s" % type(j2l)



# Generated at 2022-06-23 11:11:42.344870
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    test_result = get_with_context_result()
    assert test_result.plugin_type == '_base_terminal'
    assert test_result.plugin_name == '_base_terminal'
    assert not test_result.plugin_name_is_class_name
    assert test_result.plugin_class is None
    assert test_result.plugin is None
    assert test_result.class_path == 'ansible.plugins._base_terminal'
    assert not test_result.is_collection
    assert test_result.collection_name is None
    assert test_result.collection_version is None
    assert test_result.set_metadata_and_return_self() == test_result



# Generated at 2022-06-23 11:11:51.099865
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    loader = PluginLoader(
        'PluginType',     # package
        '_',              # suffix
        C.DEFAULT_CACHE_PLUGIN_TIMEOUT, # timeout
        'basename',       # class_name
        'baseclass',      # base_class
        'modulepath'      # searched_path
        )

    mock_get_plugin_paths = MagicMock()
    mock_get_plugin_paths.return_value = ['path', 'path2']

    with patch('ansible.utils.plugin_docs.get_plugin_paths', mock_get_plugin_paths), \
            patch.dict(sys.modules, {'modulepath': MagicMock()}):

        loader.get('my_plugin')


# Generated at 2022-06-23 11:11:52.670171
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    assert len(get_all_plugin_loaders()) > 0



# Generated at 2022-06-23 11:11:56.036777
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    plc = PluginLoadContext()
    assert plc.resolved is False
    assert plc.pending_redirect is None
    plc.redirect('foo')
    assert plc.pending_redirect == 'foo'
    assert plc.resolved is False


# Generated at 2022-06-23 11:12:05.503865
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    from ansible.module_utils._text import to_text

# Generated at 2022-06-23 11:12:11.296647
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    test_instance = PluginLoader('some.package', 'some.path')
    expected = {
        'class_name': 'some.path',
        'subdir': 'some.path',
        'package': 'some.package'
    }
    actual = test_instance.__getstate__()
    assert expected == actual, "PluginLoader.__getstate__ returned unexpected result"

# Generated at 2022-06-23 11:12:15.550583
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    pl = PluginLoader('ignore', 'ignore', 'ignore')
    assert to_text(pl) == '<ansible.utils.plugin_docs.PluginLoader object at 0x%x>' % id(pl)


# Generated at 2022-06-23 11:12:16.577437
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    p = plugins.module_loader.get('include_vars', class_only=True)
    assert p is None, p


# Generated at 2022-06-23 11:12:24.114069
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    # Test an invalid collection name
    assert not Jinja2Loader(AnsibleCollectionLoader(), os.path.join(load_fixture_path('plugins'), 'filter_plugins'), 'ansible.plugins.filter', 'FilterModule').get('invalid-name')

    # Test an invalid collection + plugin name
    assert not Jinja2Loader(AnsibleCollectionLoader(), os.path.join(load_fixture_path('plugins'), 'filter_plugins'), 'ansible.plugins.filter', 'FilterModule').get('invalid-name.invalid-plugin')

    # Test a valid collection that is not installed

# Generated at 2022-06-23 11:12:29.223920
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    pl = PluginLoader('foo.bar')
    assert pl.format_paths([]) == ''
    assert pl.format_paths(['path1']) == 'path1'
    assert pl.format_paths(['path1', 'path2', 'path3']) == 'path1,path2,path3'



# Generated at 2022-06-23 11:12:34.537507
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    plugin_load_context = PluginLoadContext()
    plugin_load_context.resolve('resolved_name','resolved_path','resolved_collection','exit_reason')
    # Check the value of resolved_fqcn
    if plugin_load_context.resolved_fqcn != 'resolved_collection.resolved_name':
        print('ERROR: Incorrect value of resolved_fqcn')



# Generated at 2022-06-23 11:12:41.485125
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    loader = PluginLoader('mock_package', 'mock_base_class', 'mock_subdir')
    loader._searched_paths = [
        "/usr/lib/python2.7/site-packages/ansible/plugins/action",
        "/usr/lib/python2.7/site-packages/ansible/plugins/action/mock_subdir",
        "/usr/share/ansible/plugins/action",
        "/usr/share/ansible/plugins/action/mock_subdir",
        "/etc/ansible/plugins/action",
        "/etc/ansible/plugins/action/mock_subdir",
        "/home/somebody/.ansible/plugins/action",
        "/home/somebody/.ansible/plugins/action/mock_subdir"
    ]


# Generated at 2022-06-23 11:12:45.231626
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    dirs1 = ['dir1', 'dir2', 'dir3', 'dir4', 'dir5']
    dirs2 = ['dir1', 'dir2', 'dir3']
    add_dirs_to_loader('action', dirs1)
    add_dirs_to_loader('cache', dirs2)
    assert set(dirs1) == set(action_loader.all_dirs)
    assert set(dirs2) == set(cache_loader.all_dirs)

# Generated at 2022-06-23 11:12:51.858375
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    name = None
    args = None
    kwargs = None
    my_obj = None
    class_only = None
    collection_list = None
    # TODO: Add your test cases here
    assert(get_with_context_result(my_obj, my_obj).object == my_obj)
    assert(get_with_context_result(my_obj, my_obj).nope == my_obj)

# Generated at 2022-06-23 11:12:59.480267
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    context = PluginLoadContext()
    context.record_deprecation('test_plugin', {'warning_text': 'This plugin is deprecated', 'removal_date': '2020-01-01'}, 'ansible.builtin')
    assert context.deprecation_warnings == ['test_plugin has been deprecated. This plugin is deprecated']
    assert context.removal_date == '2020-01-01'
    assert context.removal_version is None
    assert context.plugin_resolved_name is None
    assert context.plugin_resolved_path is None
    assert context.plugin_resolved_collection is None
    assert context.exit_reason is None
    assert not context.resolved

    context = PluginLoadContext()

# Generated at 2022-06-23 11:13:07.071748
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    instance = PluginLoader(b'', '')
    # _find_plugin_paths
    assert instance._find_plugin_paths() == []
    # _find_builtin_plugin_paths
    assert instance._find_builtin_plugin_paths() == []
    # _find_collections_plugin_paths
    assert instance._find_collections_plugin_paths() == []
    # _get_paths
    assert instance._get_paths() == []
    # find_plugin
    assert instance.find_plugin('foo') == None
    # find_plugin_with_context
    assert instance.find_plugin_with_context('foo') == None
    # has_plugin
    assert instance.has_plugin('foo') == None
    # _update_object

# Generated at 2022-06-23 11:13:10.421960
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell_type = 'cmd'
    executable = 'cmd'
    assert get_shell_plugin(shell_type, executable)



# Generated at 2022-06-23 11:13:22.361689
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    loader = PluginLoader("__init__", "ansible.plugins.__init__", C.DEFAULT_INTERNAL_CACHE_PLUGIN_PATH)
    loader.package = None
    loader.class_name = None
    loader.type_name = None
    loader.base_class = None
    loader.directories = None
    loader.aliases = None
    loader._searched_paths = None
    loader.base_class_name = None
    loader.aliases = None
    loader._module_cache = None
    loader.class_only = None
    loader.path_only = None
    loader.base_class_name = None
    loader.base_class = None
    loader.path_only = None
    loader.class_only = None

    assert loader.__getstate__() == None



# Generated at 2022-06-23 11:13:26.276409
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    plugins = PluginLoader('ansible.plugins.test.test_pluginloader', package='ansible.plugins.test')
    assert repr(plugins) == "ansible.plugins.test.test_pluginloader (caching): ['ansible/plugins/test']"



# Generated at 2022-06-23 11:13:30.688736
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    try:
        loader = PluginLoader('ansible.plugins.filter', 'FilterModule', 'ansible.plugins.filter.core', 'FilterModule', required_base_class='FilterModule')
        obj = loader.get('to_nice_json')
        assert obj != None
    except Exception as e:
        assert False


# Generated at 2022-06-23 11:13:37.101453
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    path = "/test/path/"
    plugin_path = None
    for name, obj in get_all_plugin_loaders():
        if obj.subdir:
            plugin_path = os.path.join(path, to_bytes(obj.subdir))
            break
    # Mock the exists and isdir functions to return true
    os.path.exists = MagicMock(return_value=True)
    os.path.isdir = MagicMock(return_value=True)
    # Call the method to test
    add_all_plugin_dirs(path)
    # Check the plugin path was added
    assert(plugin_path in sys.path)
    # Check that the plugin path was set as the first directory to get loaded from
    assert(sys.path[0] == plugin_path)

# Generated at 2022-06-23 11:13:47.022558
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    pl = PluginLoader("myplugins", "my.plugins")

    paths = ["/path/to/plugins", "/path/to/plugins2", "/path/to/plugins3"]
    expected = "{0:d} entries: {1!s}, {2!s}, {3!s}".format(len(paths), paths[0], paths[1], paths[2])
    actual = pl.format_paths(paths)
    assert actual == expected

    paths = ["/path/to/plugins", "/path/to/plugins2", "/path/to/plugins3", "/path/to/plugins4", "/path/to/plugins5", "/path/to/plugins6"]

# Generated at 2022-06-23 11:13:59.509040
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    # Test deprecated plugin in Ansible
    ctx = PluginLoadContext()
    ctx.record_deprecation('action_test',
                           {'warning_text': "test", 'version': 'test'},
                           collection_name='')
    assert ctx
    assert ctx.deprecated is True
    assert ctx.removal_version is None
    assert ctx.removal_date is None

    # Test deprecated plugin with deprecation parsing error in Ansible
    ctx = PluginLoadContext()
    ctx.record_deprecation('action_test',
                           {'warning_text': "test", 'version': None},
                           collection_name='')
    assert ctx
    assert ctx.deprecated is True
    assert ctx.removal_version is None
    assert ctx.removal

# Generated at 2022-06-23 11:14:04.516453
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    my_loader = Jinja2Loader()
    assert(my_loader.package == 'ansible.plugins.j2_filters' and
           my_loader.base_class == 'FilterModule' and
           len(my_loader.subdir) == 0)

# Generated at 2022-06-23 11:14:08.861200
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    plc = PluginLoadContext()
    plc.resolve('foo', '/bar/baz', 'doom.bar', 'it worked')
    assert plc.plugin_resolved_name == 'foo'


# Generated at 2022-06-23 11:14:09.936931
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    p = PluginLoadContext


# Generated at 2022-06-23 11:14:17.795371
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    def setUpModule():
        sys.path.append(os.path.dirname(os.path.dirname(__file__)))

    def tearDownModule():
        sys.path.pop()

    class TestPluginLoader(PluginLoader):
        def __init__(self):
            super(TestPluginLoader, self).__init__('ansible.plugins.test', 'Test', '_')

    # Create a new instance of PluginLoader
    test_plugin_loader = TestPluginLoader()

    # Assert that the private variable searched_paths is empty
    assert test_plugin_loader._searched_paths == []

    # Assert that the private variable _module_cache is empty
    assert test_plugin_loader._module_cache == {}

    # Populate the private variable searched_paths with list of paths
    test_plugin_loader

# Generated at 2022-06-23 11:14:22.485890
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # Test empty plugin path
    with pytest.raises(AnsibleLoaderError):
        loader = Jinja2Loader([])
        plugin = loader.find_plugin('truncate.py')

    # Test that the default plugin path is used when no path is given
    loader = Jinja2Loader()
    plugin = loader.find_plugin('truncate.py')
    assert plugin is None

    # Test that the default plugin path is used when empty path is given
    loader = Jinja2Loader([])
    plugin = loader.find_plugin('truncate.py')
    assert plugin is None

    # Test that the default plugin path is used when None is given
    loader = Jinja2Loader(None)
    plugin = loader.find_plugin('truncate.py')
    assert plugin is None

    # Test None name

# Generated at 2022-06-23 11:14:24.223997
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    paths = ['/tmp/foo']
    ret = add_dirs_to_loader('foo', paths)
    assert ret is None


# Generated at 2022-06-23 11:14:32.211980
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    context = PluginLoadContext()
    assert context.exit_reason is None
    assert context.pending_redirect is None
    assert context.resolved is False

    plugin_name = 'example'
    exit_reason = 'test nope'
    context.original_name = plugin_name

    context.nope(exit_reason)
    assert context.exit_reason == exit_reason
    assert context.pending_redirect is None
    assert context.resolved is False
    assert f'{context}' == f'{plugin_name}: {exit_reason}'



# Generated at 2022-06-23 11:14:40.568635
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    # The following test is not very much related to the functionality of the method being tested,
    # but it is done this way to avoid the setup of a file system with the required files (which
    # would be a lot more work).
    pl = PluginLoader('abc.def', '', require_one_of=('a',))
    pl._searched_paths = ['path1', 'path2', 'path3']
    res = pl.format_paths(pl._searched_paths)
    assert len(res) == 3
    assert res[0] == 'path1'
    assert res[1] == 'path2'
    assert res[2] == 'path3'



# Generated at 2022-06-23 11:14:48.517919
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    ctx = PluginLoadContext()
    ctx.original_name = 'foo'
    ctx.redirect('bar')

    assert ctx.resolved is False
    assert ctx.plugin_resolved_name == 'bar'
    assert ctx.plugin_resolved_path == None
    assert ctx.plugin_resolved_collection == None
    assert ctx.exit_reason == 'pending redirect resolution from foo to bar'

    assert ctx.redirect_list == []



# Generated at 2022-06-23 11:14:54.971589
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    plc = PluginLoadContext()
    plc.original_name = 'foo.bar'
    plc.redirect('baz.boz')
    assert plc.pending_redirect == 'baz.boz'
    assert plc.exit_reason == 'pending redirect resolution from foo.bar to baz.boz'
    assert plc.resolved is False


# Generated at 2022-06-23 11:15:06.022279
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell_plugin = get_shell_plugin(shell_type=None, executable='C:\\Test\\bash.exe')
    assert shell_plugin.SHELL_FAMILY == 'sh'
    assert shell_plugin.executable == 'C:\\Test\\bash.exe'

    shell_plugin = get_shell_plugin(shell_type='sh', executable=None)
    assert shell_plugin.SHELL_FAMILY == 'sh'

    try:
        shell_plugin = get_shell_plugin(shell_type=None, executable=None)
        assert False
    except AnsibleError:
        assert True

    try:
        shell_plugin = get_shell_plugin(shell_type='not_a_shell_type', executable=None)
        assert False
    except AnsibleError:
        assert True



# Generated at 2022-06-23 11:15:18.179961
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    PLUGIN_PATH_CACHE.clear()
    test_path_one = os.path.join(os.path.realpath(os.path.dirname(__file__)), u'data/test_plugin_loader')
    test_path_two = os.path.join(os.path.realpath(os.path.dirname(__file__)), u'data/test_plugin_loader/plugins')
    test_path_three = u'non/existing/path'

    add_all_plugin_dirs(test_path_one)
    assert to_text(test_path_one) in PLUGIN_PATH_CACHE[action]
    assert len(PLUGIN_PATH_CACHE[action]) == 1

    add_all_plugin_dirs(test_path_two)
    assert to_

# Generated at 2022-06-23 11:15:24.840832
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    context = PluginLoadContext()
    context.resolve('redirect_test', 'redirect_test', 'redirect_test', 'redirect_test')
    assert context.plugin_resolved_name == 'redirect_test'
    assert context.plugin_resolved_path == 'redirect_test'
    assert context.plugin_resolved_collection == 'redirect_test'
    assert context.exit_reason == 'redirect_test'

# Generated at 2022-06-23 11:15:33.510984
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
  lo = PluginLoader()
  lo.aliases = dict()
  lo.aliases['test'] = 'test'
  lo.package = 'ansible.plugins.test'
  lo.class_name = 'test'
  lo.base_class = ''
  lo.subdir = 'test'
  lo._searched_paths = ['/Users/wglanzer/Desktop/ansible/lib/ansible/plugins/test', '/usr/local/lib/ansible/plugins/test']
  lo._module_cache = dict()
  lo._module_cache['/Users/wglanzer/Desktop/ansible/lib/ansible/plugins/test/__init__.py'] = None

# Generated at 2022-06-23 11:15:38.546263
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    output = get_all_plugin_loaders()
    assert isinstance(output, list)  # don't care about the plugins but they should be a list
    assert list(output[0]) == ['action', ActionLoader]



# Generated at 2022-06-23 11:15:47.447112
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    """Test the PluginLoader.__repr__ method"""
    class TestPluginLoader(PluginLoader):
        pass

    # Use the actual implementation to create a concrete implementation
    actual_plugin_loader = TestPluginLoader(
        'ansible_collections.nsbl.test.plugins.module_utils', 'TestModuleUtils', 'TestModuleUtilsBase', 'modules_utils')

    # If the object did not exist it would be None, but we want to test if it is a concrete instance of the class
    assert actual_plugin_loader is not None

    # Get the repr of the object
    r = repr(actual_plugin_loader)

    # The repr of the object should be equal to the expected string

# Generated at 2022-06-23 11:15:51.521485
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    from ansible.plugins.loader import get_all_plugin_loaders

    plugin_loader = get_all_plugin_loaders()["connection"]()

    assert plugin_loader.find_plugin('local') == plugin_loader.find_plugin('local')


# Generated at 2022-06-23 11:15:59.608869
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test PluginLoader.find_plugin_with_context() using a subdirectory that contains a module.
    # This method handles the special case where there is a module, but it is not a valid plugin.

    # Create a temporary test directory.
    test_directory = tempfile.TemporaryDirectory()

    # Create a subdirectory for the test.
    test_subdir = tempfile.mkdtemp(dir=test_directory.name)

    # Create a subdirectory to trigger the special case.
    module_subdir = tempfile.mkdtemp(dir=test_subdir)

    # Create a bogus module to trigger the special case.
    with open(os.path.join(module_subdir, "module_only.py"), 'w') as module:
        # Write some code to the module.
        module.write("print('foo')")



# Generated at 2022-06-23 11:16:10.784829
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    fake_name = 'fake_name_value'
    fake_package = 'fake_package_value'
    fake_base_class = 'fake_base_class_value'

    plugin_loader = PluginLoader(fake_name, fake_package, fake_base_class, None)

    real_result = plugin_loader.__repr__()

    fake_result = '''
PluginLoader(name=fake_name_value, package=fake_package_value, class_name=None, config_name=None, aliases={}, plugin_dirs=[])
'''.strip()

    assert real_result == fake_result, "Unit test for method __repr__ of class PluginLoader failed"

# Generated at 2022-06-23 11:16:19.193512
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    import re
    import os
    import tempfile
    import shutil
    import contextlib
    from ansible.utils.display import Display
    from ansible.errors import AnsibleError

    # Test of autoloading plugins
    display = Display()
    plugin_loader = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INTERNAL_ACTION_PLUGIN_CLASS, '', '', '_')
    tmp_action_path = tempfile.mkdtemp()
    tmp_action_path_2 = tempfile.mkdtemp()
    tmp_action_path_3 = tempfile.mkdtemp()
    action_file_1 = os.path.join(tmp_action_path, "win_ping.py")

# Generated at 2022-06-23 11:16:22.170385
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    p = PluginPathContext('test', True)
    assert p.path == 'test'
    assert p.internal is True



# Generated at 2022-06-23 11:16:31.336927
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    '''
    PluginLoadContext: test for method record_deprecation
    '''
    # deprecation without warning_text
    context = PluginLoadContext()
    context = context.record_deprecation('test_name', {
        'removal_date': '2021-10-10',
        'removal_version': '1.3.3'
    }, 'test_collection')
    assert context.deprecated == True
    assert context.removal_date == '2021-10-10'
    assert context.removal_version == '1.3.3'
    assert context.deprecation_warnings == ['test_name has been deprecated.']

    # deprecation with warning_text
    context = PluginLoadContext()

# Generated at 2022-06-23 11:16:44.302334
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-23 11:16:48.368298
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    class MockModule():
        def __init__(self, file_name):
            self.file_name = file_name
            self.plugin_name = 'plugin_{}'.format(file_name)
            self.plugin_class_name = 'PluginClass{}'.format(file_name)

    class MockObj():
        def __init__(self, file_name):
            self.file_name = file_name
            self.plugin_name = 'plugin_{}'.format(file_name)
            self.plugin_class_name = 'PluginClass{}'.format(file_name)

    files = ['__init__.py', 'module1.py', 'module2.py', 'module3.py', 'module4.py']

    import os.path
    from io import StringIO

# Generated at 2022-06-23 11:16:57.469568
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    import collections
    import tempfile
    import shutil
    import os
    import sys

    # create a custom collection with a module named 'test_module' and a plugin named 'test_plugin'
    _tempdir = None

# Generated at 2022-06-23 11:17:07.638839
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    from collections import Mapping

    from ansible.parsing.plugin_docs import read_docstring

    ds = read_docstring(PluginLoader)
    assert 'ansible.plugins.action' in ds
    assert isinstance(ds['ansible.plugins.action'], Mapping)
    assert ds['ansible.plugins.action']['is_valid_name'] == 'ansible.plugins.action.is_valid_name'
    assert ds['ansible.plugins.action']['get_all_plugin_loaders'] == 'ansible.plugins.action.get_all_plugin_loaders'


# Generated at 2022-06-23 11:17:11.460594
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    p = PluginLoader("foo", "path/to/somewhere", "myclass")
    assert p._package == "foo"
    assert p._paths == ["path/to/somewhere"]
    assert p._class_name == "myclass"


# Generated at 2022-06-23 11:17:23.178778
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    MockPluginLoader = Mock()
    MockPluginLoader._module_cache = {'mock_key': 'mock_value'}
    MockPluginLoader._module_cache.__getstate__ = Mock(return_value={'mock_state_key': 'mock_state_value'})
    MockPluginLoader._magic = 'mock_magic_value'
    MockPluginLoader._magic.__getstate__ = Mock(return_value='mock_magic_state_value')
    state = {'_magic': 'mock_magic', 'mock_other_key': 'mock_other_value', '_module_cache': {'mock_key': 'mock_value'}}

    MockPluginLoader.__setstate__(state)

    expected_module_cache = {'mock_key': 'mock_value'}

# Generated at 2022-06-23 11:17:35.470846
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    """
    Unit test for method all of class Jinja2Loader
    """

    class MockPluginLoader(Jinja2Loader):
        """
        Mock object for PluginLoader
        """

        def __init__(self, *args, **kwargs):
            """
            Constructor
            """

            self.base_class = kwargs.pop('base_class', None)
            self.package = kwargs.pop('package', None)
            self.subdir = kwargs.pop('subdir', None)
            self.paths = kwargs.pop('paths', None)
            self.searched_paths = kwargs.pop('searched_paths', None)

        def _get_paths(self):
            """
            Getter for paths
            """

            return self.paths



# Generated at 2022-06-23 11:17:38.563252
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    context = PluginLoadContext()
    assert not context.resolved
    assert context.resolve('woot', '/path/to/woot.py', '/path/to', 'unit test').resolved