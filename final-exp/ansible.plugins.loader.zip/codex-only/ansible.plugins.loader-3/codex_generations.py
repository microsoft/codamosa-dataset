

# Generated at 2022-06-23 11:07:51.165325
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    class_ = PluginLoader
    func = getattr(class_, 'print_paths')
    # Prepare mock objects

    loader = class_('', '', '', ['foo'])

    print_string = 'foo'
    with patch.object(class_, '_get_paths') as mock_get_paths:
        mock_get_paths.return_value = ['bar']
        with patch.object(BuiltinBase, 'display', create=True) as mock_display:
            func(loader, print_string)
            mock_display.display.assert_called_with('%s: bar' % print_string)


# Generated at 2022-06-23 11:07:54.154435
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    from ansible.utils.plugin_docs import check_docstring
    from ansible.plugins import module_loader
    plugin_loader = module_loader

    assert hasattr(plugin_loader, "print_paths")
    msg = plugin_loader.print_paths()
    assert isinstance(msg, type(None))

# Generated at 2022-06-23 11:08:01.756009
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    s = set(get_all_plugin_loaders())
    assert len(s) == len(get_all_plugin_loaders())
    # special check so we won't get false positive if someone changes the function name
    assert 'get_all_plugin_loaders' in globals()
    assert 'test_get_all_plugin_loaders' in globals()
    assert ('get_all_plugin_loaders', test_get_all_plugin_loaders) not in s
    assert ('test_get_all_plugin_loaders', test_get_all_plugin_loaders) not in s



# Generated at 2022-06-23 11:08:11.594276
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    from ansible.plugins.loader import PluginLoader

    # Initialize an object of class PluginLoader with the following attributes
    # class_name: attribute_value_pairs

# Generated at 2022-06-23 11:08:13.491677
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    ppc = PluginPathContext('/foo', None)
    assert ppc.path == '/foo'
    assert ppc.internal is None



# Generated at 2022-06-23 11:08:24.368661
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plc = PluginLoadContext()
    assert plc.original_name is None
    assert [] == plc.redirect_list
    assert [] == plc.error_list
    assert [] == plc.import_error_list
    assert [] == plc.load_attempts
    assert plc.pending_redirect is None
    assert plc.exit_reason is None
    assert plc.plugin_resolved_path is None
    assert plc.plugin_resolved_name is None
    assert plc.plugin_resolved_collection is None
    assert not plc.deprecated
    assert plc.removal_date is None
    assert plc.removal_version is None
    assert [] == plc.deprecation_warnings
    assert not plc.resolved
    assert plc._resolved_

# Generated at 2022-06-23 11:08:27.505063
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    class Foo(object):
        def __init__(self, *args, **kwargs):
            pass

    jinja2_loader_check = Jinja2Loader('ansible.plugins.filter', 'Foo', 'filter_plugins', 'ansible.plugins.filter')
    assert jinja2_loader_check._package == 'ansible.plugins.filter'
    assert jinja2_loader_check._subdir == 'filter_plugins'

# Generated at 2022-06-23 11:08:35.393725
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    test = PluginLoader('foo')
    test._removed_paths = ['bar']

    # Add to non-duplicate and not in removed paths
    test._add_directory('baz')
    assert test._searched_paths == ['baz']
    assert test._removed_paths == ['bar']

    # Add to non-duplicate but in a removed path
    test._add_directory('bar/baz')
    assert test._searched_paths == ['baz']
    assert test._removed_paths == ['bar']

    # Add to a duplicate path
    test._add_directory('baz')
    assert test._searched_paths == ['baz']
    assert test._removed_paths == ['bar']



# Generated at 2022-06-23 11:08:48.943470
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    '''
    Unit test of PluginLoader.__repr__
    '''

    plugin_loader = PluginLoader('units.mock.test_plugin_loader', 'units.mock.test_plugin_loader.base')

    fake_plugin = MagicMock()
    fake_plugin.__repr__.return_value = 'fake_plugin'

# Generated at 2022-06-23 11:08:58.962972
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    class A:
        def __init__(self):
            self.deprecated = False
            self.deprecation_warnings = []
            self.removal_date = None
            self.removal_version = None
        def deprecated(self, warning_text):
            self.deprecated = True
            self.deprecation_warnings.append(warning_text)
    a = A()
    name = 'name'
    deprecation = {'warning_text': 'warning', 'removal_date': 'date'}
    class B:
        def __init__(self, a):
            self.a = a
    b = B(a)
    b.record_deprecation(name, deprecation)
    assert b.a.deprecated

# Generated at 2022-06-23 11:09:01.424568
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    pass



# Generated at 2022-06-23 11:09:03.640708
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    assert PluginLoader.__contains__('/home/jon/ansible/lib/ansible/errors.py', 'name') == True


# Generated at 2022-06-23 11:09:09.428020
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    test = PluginLoadContext()
    test = test.resolve('new_resolve_name','test.py','test', 'reason')
    if test.plugin_resolved_name != 'new_resolve_name' or test.plugin_resolved_path != 'test.py' \
            or test.plugin_resolved_collection != 'test' or test.exit_reason != 'reason' or test.resolved != True:
        print("test class PluginLoadContext method resolve : failed")



# Generated at 2022-06-23 11:09:12.164925
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():

    assert not PluginLoadContext().pending_redirect
    assert PluginLoadContext().original_name is None



# Generated at 2022-06-23 11:09:21.531632
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    obj = PluginLoader(package='ansible.plugins.action', class_name='ActionBase')
    obj.find_plugin = lambda name: '/Users/henrik/GitHub/ansible/lib/ansible/plugins/action/copy.py'
    obj.class_name = 'ActionBase'
    obj.package = 'ansible.plugins.action'
    obj.paths = ['/Users/henrik/GitHub/ansible/lib/ansible/plugins/action']
    obj.aliases = {}
    obj.class_only = False
    obj._searched_paths = ['/Users/henrik/GitHub/ansible/lib/ansible/plugins/action']
    obj.base_class = 'ActionBase'
    obj._module_cache = {}
    obj._config_def_cache = {}


# Generated at 2022-06-23 11:09:24.008859
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    assert all(isinstance(x[1], PluginLoader) for x in get_all_plugin_loaders())



# Generated at 2022-06-23 11:09:26.651782
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    obj = PluginLoadContext()
    obj.redirect('redirect')
    assert obj.resolved is False
    assert obj.exit_reason == 'pending redirect resolution from None to redirect'
    assert obj.pending_redirect == 'redirect'



# Generated at 2022-06-23 11:09:36.871615
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    from ansible.module_utils.six import PY3

    if PY3:
        PL = PluginLoader("", "", "", "")
        # Unit: __getstate__
        # Verify: __main__:None
        assert PL.__getstate__() == {'aliases': {}, '_module_cache': {}, '_searched_paths': []}
    else:
        PL = PluginLoader("", "", "", "")
        # Unit: __getstate__
        # Verify: __main__:None
        assert PL.__getstate__() == ({'aliases': {}, '_module_cache': {}, '_searched_paths': []}, None)



# Generated at 2022-06-23 11:09:46.139936
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    import ansible.plugins.loader
    plugin_class_name='Plugin'
    base_class_name='BaseClass'
    package_name='ansible.plugins'
    subdir='module_utils'
    prog='module'

    plugin_loader = PluginLoader.loaders[ansible.plugins.loader.C.MODULE_UTILS_PATH]
    assert isinstance(plugin_loader, PluginLoader)
    assert plugin_loader.package == package_name
    assert plugin_loader.class_name == plugin_class_name
    assert plugin_loader.base_class == base_class_name
    assert plugin_loader.subdir == subdir
    assert plugin_loader.prog == prog


# Generated at 2022-06-23 11:09:53.310758
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    plc = PluginLoadContext()
    plc.original_name = 'plugin_name'
    plc.redirect('redirected_plugin')
    assert(plc.original_name == 'plugin_name')
    assert(plc.pending_redirect == 'redirected_plugin')
    assert(plc.exit_reason == 'pending redirect resolution from plugin_name to redirected_plugin')
    assert(plc.resolved is False)


# Generated at 2022-06-23 11:09:58.606350
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    import ansible.plugins
    test_obj = PluginLoader('FilterModule', 'ansible.plugins.filter', C.DEFAULT_FILTER_PLUGIN_PATH, 'filter', required_base_class='FilterModule')
    # pylint: disable=unused-variable
    result = test_obj.get_with_context('to_yaml')

# Generated at 2022-06-23 11:10:03.614733
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    context = PluginPathContext('foo', True)
    assert context.path == 'foo'
    assert context.internal
    assert to_bytes(str(context)) == 'foo(internal)'
    context.internal = False
    assert to_bytes(str(context)) == 'foo'


# Generated at 2022-06-23 11:10:09.003729
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # Test function "find_plugin" of class Jinja2Loader:
    #
    # Scenario:
    #   Given a Jinja2Loader object
    #   When Calling find_plugin(arg1, [arg2])
    #   Then AnsibleError exception will be raised

    pass



# Generated at 2022-06-23 11:10:12.283265
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    plugin_path_context = PluginPathContext('/path', False)
    assert plugin_path_context.path == '/path'
    assert plugin_path_context.internal is False



# Generated at 2022-06-23 11:10:22.684915
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    COLLECTIONS_PATHS = [
        'plugins/collection_a/ansible_collections/collection_a/plugins/module_utils',
        'plugins/collection_a/ansible_collections/collection_a/plugins/modules',
        'plugins/collection_b/ansible_collections/collection_b/plugins/module_utils',
        'plugins/collection_b/ansible_collections/collection_b/plugins/modules',
    ]

    COLLECTION_SEARCH_PATH = ['plugins/collection_a/ansible_collections/collection_a', 'plugins/collection_b/ansible_collections/collection_b', 'plugins']


# Generated at 2022-06-23 11:10:24.531350
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    plugin_load_context = PluginLoadContext()
    plugin_load_context.resolved_fqcn()


# Generated at 2022-06-23 11:10:27.610118
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # FIXME: No test for this method
    raise SkipTest


# Generated at 2022-06-23 11:10:33.642077
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    plugin_loader = PluginLoader('foo', 'bar', '', 'baz')
    assert plugin_loader.__getstate__() == (None, {'_config_definitions': {}, '_searched_paths': None, '_module_cache': {}, 'class_name': 'baz', 'aliases': {}, 'package': 'foo', 'subdir': 'bar'})



# Generated at 2022-06-23 11:10:43.309873
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=VariableManager())

    # Test that the __contains__ method of PluginLoader class
    # returns True when a valid plugin is passed.
    plugin_loader = PluginLoader('action_plugin', 'ActionModule', None)
    valid_plugin = 'debug'
    assert valid_plugin in plugin_loader

    # Test that the __contains__ method of PluginLoader class
    # returns False when a invalid plugin is passed.
    invalid_plugin = 'debug1'
    assert invalid_plugin not in plugin_loader

    # Test that the __contains

# Generated at 2022-06-23 11:10:44.972342
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    result = PluginLoader.get_with_context_result()
    assert isinstance(result, tuple)
    assert len(result) == 2

    plugin = result[0]
    context = result[1]

    assert plugin is None
    assert context == 'None'



# Generated at 2022-06-23 11:10:49.346722
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    """Test PluginLoader.get"""
    PLUGIN_LOADER = PluginLoader('test',
                                 'Tests/Fixtures/plugins',
                                 'Base',
                                 'TestPlugin')
    PLUGIN_LOADER.disable_extension_loading()

    plugin = PLUGIN_LOADER.get('test_plugin_fixture', path='/root')
    assert plugin.__class__.__name__ == 'TestPlugin'


# Generated at 2022-06-23 11:10:50.229839
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    print (PluginLoader.get)

# Generated at 2022-06-23 11:10:51.801894
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # FIXME: NEED TEST
    assert False, "Unimplemented test"


# Generated at 2022-06-23 11:10:53.229618
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    assert False, 'This test needs to be written' 

# Generated at 2022-06-23 11:10:59.866881
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    '''
    Used to generate test data
    '''

    loader = PluginLoader(package='ansible_collections.example.mysql.plugins.module_utils', class_name='AnsibleModule', base_class='ansible.module_utils.common.AnsibleModule')
    data = loader.__getstate__()



# Generated at 2022-06-23 11:11:11.569463
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Use case 1:
    # Redirected plugin name has full fq collection name and collection_list contains the same fq collection name
    pl = PluginLoader("shell_plugins", "ActionModule", "", collections_paths=C.COLLECTIONS_PATHS)
    pl.add_directory(os.path.join(os.path.dirname(__file__), 'test/test_plugins'))
    plugin_load_context = pl.find_plugin_with_context("my.ns.testing.molecule", collection_list=["my.ns.testing"])

    assert plugin_load_context is not None
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_path.endswith("/test/test_plugins/molecule.py")
    assert plugin_load_context

# Generated at 2022-06-23 11:11:23.208580
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    context = PluginLoadContext()
    resolved_name = 'foo'
    resolved_path = 'path/to/foo'
    resolved_collection = None
    exit_reason = 'to foo'
    new_context = context.resolve(resolved_name, resolved_path, resolved_collection, exit_reason)
    assert new_context.pending_redirect is None
    assert new_context.resolved is True
    assert new_context.plugin_resolved_name == resolved_name
    assert new_context.plugin_resolved_path == resolved_path
    assert new_context.plugin_resolved_collection is resolved_collection
    assert new_context.exit_reason == exit_reason


# Generated at 2022-06-23 11:11:28.402150
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    # Ensure the correct value if the plugin is not found.
    plugin_loader = PluginLoader('collect_logs', 'ansible_collections.community.general.plugins.modules', C.DEFAULT_MODULE_PATH, 'collect_logs', 'ansible_collections.community.general.plugins.modules.collect_logs.CollectLogs')
    assert plugin_loader.get('collect_logs') is None

    # Ensure the correct value if the plugin is found.
    plugin_loader = PluginLoader('aws', 'ansible_collections.amazon.aws.plugins.modules', None, 'aws', 'ansible_collections.amazon.aws.plugins.modules.aws.Aws')
    assert plugin_loader.get('aws', 'us-east-1') == 'us-east-1'

    # Make sure we can load a plugin from

# Generated at 2022-06-23 11:11:32.776898
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    assert PluginLoader.format_paths(searched_paths=['/a/b/c', '/d/e/f', '/g/h']) == "'/a/b/c', '/d/e/f', '/g/h'"
    assert PluginLoader.format_paths(searched_paths=[]) == ''



# Generated at 2022-06-23 11:11:36.230162
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    which_loader = 'connection'
    paths = ['path1', 'path2']
    loader = getattr(sys.modules[__name__], '%s_loader' % which_loader)
    for path in paths:
        loader.add_directory(path, with_subdir=True)


# Generated at 2022-06-23 11:11:40.637344
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    jl = Jinja2Loader('test_package', 'test_class', 'test_base_class', 'test_subdir')
    jl.find_plugin('foo.bar')

# Generated at 2022-06-23 11:11:45.391721
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    j2l = Jinja2Loader()
    assert j2l.class_name == 'FilterModule'
    assert j2l.class_name == j2l.base_class
    assert j2l.package == 'ansible.plugins.filter'
    assert j2l.subdir == 'filter_plugins'



# Generated at 2022-06-23 11:11:52.413563
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    # create plugin loader objects on the fly to be type safe and not muck with global state
    pd = PluginLoader('action', 'actions', 'ActionModule', require_subdir=False)
    pd.add_directory('/path/to/actions')
    assert pd.paths == ['/path/to/actions']
    pd.add_directory('/path/to/more/actions')
    assert pd.paths == ['/path/to/actions', '/path/to/more/actions']

    pd = PluginLoader('action', 'actions', 'ActionModule', require_subdir=True)
    pd.add_directory('/path/to/actions')
    assert pd.paths == ['/path/to/actions']
    pd.add_directory('/path/to/more/actions')

# Generated at 2022-06-23 11:12:00.186741
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    p1 = PluginLoader('ansible.plugins.filter', 'TestFilterPlugin')
    g1 = p1.get('tests.unit.test_loader.TestFilterPlugin')()
    Assert(g1.filter('foo')) == 'foo'
    Assert(p1.get('tests.unit.test_loader.TestFilterPlugin', class_only=True).__name__) == 'TestFilterPlugin'
    Assert(p1.get('tests.unit.test_loader.TestFilterPlugin', path_only='tests/unit/test_loader.py')) == 'tests/unit/test_loader.py'
    # Test for failure for get method
    with pytest.raises(AnsibleError):
        p1.get(None)
        # Test for failure for get method

# Generated at 2022-06-23 11:12:11.353745
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():

    # Init class
    plugin_loader = Jinja2Loader(package='ansible.plugins.filter', subdir='filter_plugins')

    # Call method under test
    plugins = plugin_loader.all()

    # Assert number of plugins returned
    assert len(plugins) == 27

    # Assert files in reverse order with base file first
    assert os.path.basename(plugins[0]) == 'base.py'
    assert os.path.basename(plugins[26]) == 'last.py'

    # Instantiate our own dict class and make sure it uses jinja2_plugin_name as key
    class Dict(dict):
        def __setitem__(self, k, v):
            dict.__setitem__(self, type(v).__name__, v)

    # Init class
    plugin_loader = Jinja

# Generated at 2022-06-23 11:12:19.557967
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    plugin_load_context = PluginLoadContext()
    name = 'deprecation_test'
    deprecation = {'removal_date': '2.14', 'warning_text': 'test'}
    collection_name = 'test_collection'
    plugin_load_context.record_deprecation(name, deprecation, collection_name)
    assert plugin_load_context.removal_date == '2.14'
    assert plugin_load_context.deprecation_warnings == ['deprecation_test has been deprecated. test']
    assert plugin_load_context.deprecated



# Generated at 2022-06-23 11:12:31.305634
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.hash_tester import HashTester

    loader_all = PluginLoader("hash_tester", 'ansible.plugins.hash_tester', 'HashTester', 'hash_tester')

    assert "md5" in loader_all
    assert not "fake" in loader_all

    loader_one = PluginLoader("hash_tester", 'ansible.plugins.hash_tester', 'HashTester', 'hash_tester', 'single')
    loader_none = PluginLoader("hash_tester", 'ansible.plugins.hash_tester', 'HashTester', 'hash_tester', 'does_not_exist')

    assert "md5" in loader_one
    assert not "fake" in loader_one
    assert not "md5" in loader

# Generated at 2022-06-23 11:12:39.922404
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    plugin_loader = PluginLoader('test_plugin_loader', 'plugin_path', 'test_class_name')
    plugin_loader._searched_paths = [
        'a', 'b'
    ]

    expected_output = 'a\nb'
    assert expected_output == plugin_loader.format_paths()

    plugin_loader._searched_paths = [
        os.path.join('a', 'b', 'c'),
        os.path.join('d', 'e', 'f'),
        os.path.join('g', 'h')
    ]

    expected_output = os.path.join('a', 'b', 'c') + '\n' + os.path.join('d', 'e', 'f') + '\n' + os.path.join('g', 'h')
   

# Generated at 2022-06-23 11:12:45.138906
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
  # setup
  our_plugin_loader = PluginLoader(b'foo', 'bar', 'baz', 'qux')
  # exercise
  actual_value = our_plugin_loader.__repr__()
  # verify
  assert actual_value == "PluginLoader(b'foo', 'bar', 'baz', 'qux')"
  # cleanup
  pass




# Generated at 2022-06-23 11:12:55.569404
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    raw_data = {
        'data': {
            'plugin1.foo': 'j2 plugin name 1',
            'plugin2.foo': 'j2 plugin name 2',
            'plugin3.foo': 'j2 plugin name 3',
        },
        'paths': [
            'file1.py',
            'file2.py',
            'file3.py',
        ],
        'result': {
            'plugin1.foo': 'j2 plugin name 1',
            'plugin2.foo': 'j2 plugin name 3',
            'plugin3.foo': 'j2 plugin name 3',
        },
    }

    class Plugin:
        # pylint: disable=too-few-public-methods
        name = None
        def __init__(self, name):
            self.name = name


# Generated at 2022-06-23 11:13:06.041270
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    plugin_load_context = PluginLoadContext(plugin_resolved_name='neutron.ml2',
                                            plugin_resolved_path='/root/.ansible/collections/ansible_collections/openstack/openstack/plugins/modules/neutron.py',
                                            searched_paths=[],
                                            resolved=True,
                                            collection_name='openstack',
                                            collection_version_match='',
                                            collection_version_min='',
                                            plugin_name='neutron',
                                            plugin_type_name='module',
                                            config_opts=None,
                                            collection_list=[])
    plugin_load_context.plugin_resolved_fqcr = 'openstack.openstack.neutron'

# Generated at 2022-06-23 11:13:19.576656
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    plugin_load_context = PluginLoadContext()
    plugin_load_context = plugin_load_context.record_deprecation('test_name', {'removal_date': '2099-06-06'}, 'test_collection_name')
    assert plugin_load_context.removal_date == '2099-06-06'
    plugin_load_context = plugin_load_context.record_deprecation('test_name', {'removal_version': '4.0.0'}, 'test_collection_name')
    assert plugin_load_context.removal_version == '4.0.0'
    plugin_load_context = plugin_load_context.record_deprecation('test_name', {'warning_text': 'Warning Text added'}, 'test_collection_name')

# Generated at 2022-06-23 11:13:29.783306
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    redirect_name = 'ansible.builtin.i_dont_exist'
    plugin_load_context = PluginLoadContext()
    plugin_load_context.original_name = 'ansible.builtin.terminal'
    plugin_load_context.plugin_resolved_name = 'ansible.builtin.terminal'
    plugin_load_context.plugin_resolved_path = '/usr/lib/python2.7/dist-packages/ansible/modules/files/templates.py'
    plugin_load_context.plugin_resolved_collection = None
    plugin_load_context.exit_reason = 'resolved from ansible.builtin.terminal'
    assert plugin_load_context.redirect(redirect_name) == plugin_load_context


# Generated at 2022-06-23 11:13:35.788540
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    # Test case when shell_type is provided
    assert get_shell_plugin(shell_type="bash")
    # Test case when shell type is not provided and an executable value is provided
    assert get_shell_plugin(executable="sh")
    # Test case when no shell_type or executable is provided
    try:
        get_shell_plugin()
    except AnsibleError:
        pass
    else:
        raise Exception("Expected AnsibleError")


# Generated at 2022-06-23 11:13:46.060786
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    assert(1==1)
    return True

# end of unit test

    def record_error(self, message):
        self.error_list.append(message)
        if self.resolved:
            raise AnsiblePluginCircularRedirect(message)
        return self

    def record_import_error(self, error):
        self.import_error_list.append(error)
        return self

    def record_load_attempt(self, name):
        self.load_attempts.append(name)
        return self

    def record_redirect(self, redirect_name):
        self.redirect_list.append(redirect_name)
        return self


# Generated at 2022-06-23 11:13:49.664247
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    obj = get_with_context_result(1, [1, 2])
    assert obj.result == 1
    assert obj.context == [1, 2]



# Generated at 2022-06-23 11:13:52.896730
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    return 0
    # TODO: remove this stub if this method is implemented
    raise NotImplementedError("method redirect of class PluginLoadContext not implemented")



# Generated at 2022-06-23 11:14:03.229162
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    '''
    Unit test for method add_directory of class PluginLoader
    '''
    # generator function to generate test fixtures
    # param:
    #       add: item to add
    #       expected: expected result after calling add_directory method
    def gen_fixtures(add_params, expected):
        for f in add_params:
            yield (f,expected)

    # item is a list of directory
    # expected is a list of expected result
    items = [['test/a'], ['test/b', 'test/c']]
    expected = [['test/a'], ['test/b', 'test/c']]

    fixtures = gen_fixtures(items, expected)

    # test method add_directory by checking the result after calling this method

# Generated at 2022-06-23 11:14:07.834786
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    class PluginPathContextTest(object):
        def __init__(self):
            self.path = 'test'
            self.internal = 'test'
    
    plugin = PluginPathContextTest()

    assert(isinstance(plugin, PluginPathContextTest))


# Generated at 2022-06-23 11:14:16.872520
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    loader = Jinja2Loader('module_utils', 'ModuleUtilBase', 'ansible.module_utils')
    loader.add_directory(utils.plugins.module_finder._get_paths_from_path_list(['ansible/plugins/filter_plugins/'])[0])
    loader.add_directory(utils.plugins.module_finder._get_paths_from_path_list(['ansible/plugins/test_plugins/'])[0])

    # We expect a list of files in reverse order (otherwise the deduplication
    # is wrong)
    # We also have several ansible files (ansible.py, etc) which we don't care about.
    # Our mock object will return those after we find the first jinja2 plugin
    # in their file.

# Generated at 2022-06-23 11:14:28.658265
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    plugin_load_context = PluginLoadContext()
    resolved_name = "name"
    resolved_path = "path"
    resolved_collection = "ansible_collections.namespace.repo"
    exit_reason = "exit reason"
    plugin_load_context.pending_redirect = "name"
    plugin_load_context.plugin_resolved_name = "name"
    plugin_load_context.plugin_resolved_path = "path"
    plugin_load_context.plugin_resolved_collection = "ansible_collections.namespace.repo"
    plugin_load_context.exit_reason = "exit reason"
    plugin_load_context.resolved = True
    plugin_load_context.resolve(resolved_name, resolved_path, resolved_collection, exit_reason)
    assert plugin

# Generated at 2022-06-23 11:14:39.214906
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    context = PluginLoadContext()
    context.original_name = 'foo'
    # Check that we can redirect to a valid name, the result is resolved and
    # the pending_redirect is cleared
    context.redirect('bar')
    assert not context.resolved
    assert not context.pending_redirect
    assert context.exit_reason == 'pending redirect resolution from foo to bar'

    # Check that we can't redirect to an empty name, the result is not resolved
    # and there is no pending redirect
    context = PluginLoadContext()
    context.original_name = 'foo'
    context.redirect('')
    assert not context.resolved
    assert not context.pending_redirect
    assert context.exit_reason == 'empty redirect name'

    # Check that we can't redirect to None, the result is not resolved

# Generated at 2022-06-23 11:14:50.728996
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    # Test with valid data
    plc = PluginLoadContext()
    resolved_name = 'test_resolved_name'
    resolved_path = '/test/resolved/path'
    resolved_collection = 'test_resolved_collection'
    exit_reason = 'test_exit_reason'
    plc.resolve(resolved_name, resolved_path, resolved_collection, exit_reason)
    assert plc.resolved_fqcn == 'test_resolved_collection.test_resolved_name'
    assert plc.pending_redirect is None
    assert plc.plugin_resolved_name is resolved_name
    assert plc.plugin_resolved_path is resolved_path
    assert plc.plugin_resolved_collection is resolved_collection
    assert plc.exit_reason == exit_reason
   

# Generated at 2022-06-23 11:14:58.425484
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    # Verify constructor works as expected
    jl = Jinja2Loader()
    assert jl.subdir == 'filter_plugins', 'subdir is wrong'
    assert jl.package == 'ansible.plugins.filter', 'package is wrong'
    assert jl.class_name == 'FilterModule', 'class_name is wrong'
    assert jl.base_class == 'FilterModule', 'base_class is wrong'


# Generated at 2022-06-23 11:15:08.012606
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    #Example:
    obj = PluginLoadContext()
    obj.resolve('abc' , 'abc_path' , 'abc_collection', 'abc_reason')
    obj.redirect('abc_redirect')
    assert obj.original_name == 'abc'
    assert obj.redirect_list == ['abc_redirect']
    assert obj.error_list == []
    assert obj.import_error_list == []
    assert obj.load_attempts == []
    assert obj.plugin_resolved_path == 'abc_path'
    assert obj.plugin_resolved_name == 'abc_redirect'
    assert obj.plugin_resolved_collection == 'abc_collection'
    assert obj.exit_reason == 'pending redirect resolution from abc to abc_redirect'
    assert obj.resolved == False
#

# Generated at 2022-06-23 11:15:13.956832
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    from ansible.plugins import __all__ as plugins
    all_plugins = get_all_plugin_loaders()
    assert len(all_plugins) == len(plugins), \
        "There are {0} plugin loaders, but only {1} plugin names were found.  Loaders: {2} Names: {3}".format(
            len(all_plugins), len(plugins), all_plugins, plugins
        )



# Generated at 2022-06-23 11:15:16.979085
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    obj = PluginPathContext('/path', True)
    assert obj.path == '/path'
    assert obj.internal is True



# Generated at 2022-06-23 11:15:20.823848
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    pluginpath1 = PluginPathContext('/tmp/a', False)
    assert pluginpath1.path == '/tmp/a'
    assert not pluginpath1.internal



# Generated at 2022-06-23 11:15:30.447621
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    print("Testing method: find_plugin")
    lib.test_support.verbose = 1
    loader = PluginLoader("", "", None, None)
    def test_find_plugin_1():
        # Attempting to find a plugin that doesn't exist
        plugin_load_context = loader.find_plugin("nothing_to_see_here")
        assert plugin_load_context.can_support_collections == False
        assert plugin_load_context.resolved == False
        assert plugin_load_context.nope("This is expected") == None
        assert plugin_load_context.error("Error message") == "Error message"
        assert plugin_load_context.warning("Warning message") == "Warning message"
        assert plugin_load_context.collection_list == []
        assert plugin_load_context.namespace == ""
        assert plugin

# Generated at 2022-06-23 11:15:33.100984
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    '''
    Unit test for method get of class PluginLoader
    '''
    # TODO: Implement test
    assert False



# Generated at 2022-06-23 11:15:41.858955
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    pl = PluginLoader('', '', '', '', '')
    # Add one directory
    pl.add_directory("directory1")
    assert pl._directories == set(['directory1'])
    # Add same directory
    pl.add_directory("directory1")
    assert pl._directories == set(['directory1'])
    # Add other directory
    pl.add_directory("directory2")
    assert pl._directories == set(['directory1', 'directory2'])

# Generated at 2022-06-23 11:15:53.813495
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    fake_plugin_data = """
        def test1(a, b):
          return a
    """
    tmp_dir = tempfile.mkdtemp()

    try:
        fake_plugin = os.path.join(tmp_dir, 'ansible.legacy/test_plugins/test_plugin.py')
        os.makedirs(os.path.dirname(fake_plugin))
        with open(fake_plugin, 'w') as f:
            f.write(fake_plugin_data)

        # Loader for test_plugin
        t = Jinja2Loader('ansible.legacy')
        t.add_directory(tmp_dir)

        p = t.find_plugin('test1')

        assert p == fake_plugin
    finally:
        shutil.rmtree(tmp_dir)



# Generated at 2022-06-23 11:15:59.067771
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    load_context = PluginLoadContext()
    redirect_name = 'redirect_name'
    original_name = 'original_name'
    actual = load_context.redirect(redirect_name)
    actual.original_name = original_name
    expected = PluginLoadContext()
    expected.pending_redirect = redirect_name
    expected.exit_reason = 'pending redirect resolution from {0} to {1}'.format(original_name, redirect_name)
    expected.resolved = False
    assert actual == expected


# Generated at 2022-06-23 11:16:12.119001
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    context = PluginContext('common/main.yml', 'PluginType', 'some_path')

    # check creating object without context
    result = get_with_context_result(False, plugin_context=None)
    assert result.success is False
    assert result.plugin_context is None
    assert result.source_name is None
    assert result.plugin_type is None
    assert result.path is None

    # check creating object with context
    result = get_with_context_result(True, plugin_context=context)
    assert result.success is True
    assert result.plugin_context.source_name is 'common/main.yml'
    assert result.plugin_context.plugin_type is 'PluginType'
    assert result.plugin_context.path is 'some_path'

# Generated at 2022-06-23 11:16:15.688152
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    path = os.path.dirname(os.path.dirname(__file__))
    loader = add_dirs_to_loader('module', [path])
    assert loader.get('echo') is not None, 'Module loader should find echo module'


# Generated at 2022-06-23 11:16:17.887270
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # set up params
    l = Jinja2Loader()
    assert l.get() is None



# Generated at 2022-06-23 11:16:29.466650
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    _PLUGIN_FILTERS = {'action': set(), 'cache': set(), 'callback': set(), 'cliconf': set(), 'connection': set(), 'filter': set(), 'httpapi': set(), 'inventory': set(), 'lookup': set(), 'shell': set(), 'strategy': set(), 'terminal': set(), 'test': set(), 'vars': set()}
    p = PluginLoader('action', 'ansible.plugins.action', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS, 'action')
    p._searched_paths = ['action']
    p._get_paths = lambda: ['action']
    p.package = 'ansible.plugins.action'
    p.aliases = []
    p.class_name = 'action'

# Generated at 2022-06-23 11:16:42.016774
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Test no collection_list arg
    loader = PluginLoader('something', 'ansible.plugins.something.plugin', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS, 'ansible_plugins.something.')
    plugin_load_context = loader.find_plugin_with_context('name', collection_list=[])
    if not plugin_load_context.resolved or not plugin_load_context.plugin_resolved_path:
        pass
        # FIXME: this is probably an error (eg removed plugin)
        # assert False
    # Test collection_list arg
    plugin_load_context = loader.find_plugin_with_context('name', collection_list=['the_one'])

# Generated at 2022-06-23 11:16:53.097964
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    plugin_loader = {}
    plugin_load_context = PluginLoadContext(plugin_name='lookup/foo.py', package_name='ansible_collections.ansible.collection_foo')
    plugin_loader['ansible_collections.ansible.collection_foo'] = {'_data_path' : 'tests/data/'}
    plugin_loader['ansible_collections.ansible.collection_bar'] = {'_data_path' : 'tests/data/'}
    result = plugin_loader['ansible_collections.ansible.collection_foo'].find_plugin_with_context('lookup/foo.py', plugin_load_context)
    assert result.resolved
    assert result.plugin_resolved_name == 'lookup/foo.py'

# Generated at 2022-06-23 11:16:55.164002
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    test1 = '''
    '''

# Generated at 2022-06-23 11:17:02.252473
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    match_plugin_load_context = _MatchPluginLoadContext()

    def create_searched_paths_mock_callable(*args, **kwargs):
        if 'filter_' in args[0] or args[0] == 'test_plugins':
            return ['/usr/lib/python2.7/site-packages/ansible/plugins/%s' % args[0]]

# Generated at 2022-06-23 11:17:09.312969
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    pl = PluginLoader('')
    paths = ['/home/admin/.ansible/plugins/action', '/usr/share/ansible/plugins/action']
    result = pl.format_paths(paths)
    assert result == '\'/home/admin/.ansible/plugins/action\', \'/usr/share/ansible/plugins/action\'', 'unexpected result of PluginLoader.format_paths'


# Generated at 2022-06-23 11:17:11.180848
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    from ansible.errors import AnsibleError
    assert AnsibleError('hello') is not None


# Generated at 2022-06-23 11:17:17.103262
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    class a(object):
        def get_with_context(*args, **kwargs):
            return args, kwargs

    myclass = a()
    res = getattr(myclass, 'get_with_context', None)
    assert res(*(1, 2, 3), **{'a': 'b'}) == ((1, 2, 3), {'context': None, 'a': 'b'})



# Generated at 2022-06-23 11:17:27.572711
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    import ansible.plugins.shell.generic as generic_shell
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    # basic shell check, default
    plugin = get_shell_plugin()
    assert isinstance(plugin, generic_shell.ShellModule)

    # basic shell check with type
    plugin = get_shell_plugin(shell_type="sh")
    assert isinstance(plugin, generic_shell.ShellModule)

    # basic shell check with type and executable
    plugin = get_shell_plugin(shell_type="sh", executable="/bin/sh")
    assert isinstance(plugin, generic_shell.ShellModule)

    # try specifying an executable and let it autodetect

# Generated at 2022-06-23 11:17:38.116604
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    obj= PluginLoadContext()
    obj.nope('exit_reason')
    assert obj.__dict__ == {'original_name': None, 'redirect_list': [], 'error_list': [], 'import_error_list': [], 'load_attempts': [], 'pending_redirect': None, 'exit_reason': 'exit_reason', 'plugin_resolved_path': None, 'plugin_resolved_name': None, 'plugin_resolved_collection': None, 'deprecated': False, 'removal_date': None, 'removal_version': None, 'deprecation_warnings': [], 'resolved': False, '_resolved_fqcn': None}
#Unit test for method add_redirect_list of class PluginLoadContext

# Generated at 2022-06-23 11:17:39.829384
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    loader = PluginLoader(None, '', None, '', '')
    loader.add_directory(None, True)


# Generated at 2022-06-23 11:17:47.284278
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    # a list of PluginLoader instances that contain the data for the test cases
    test_data = []
    # test case: a list of paths that should be formatted and replaced by a list of expected paths
    test_case = []
    # list of paths that should be formatted
    paths = []
    # list of expected paths
    expected_paths = []
    # list of lists of test cases
    test_cases = []

    # initialize the test data by creating instances of PluginLoader
    test_data.append(PluginLoader('foo', 'bar', 'baz', C.DEFAULT_CACHE_PLUGIN_FILENAMES, config_def_loader_class=None))

    # initialize the test cases
    # "a" is a duplicate of "b", "b" is a duplicate of "c", "a" should be removed and "b" should