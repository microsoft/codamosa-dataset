

# Generated at 2022-06-23 11:07:48.162396
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Create target object
    # args:
    #  name: string
    #  package: string
    #  paths: string
    #  base_class: string
    #  class_name: string
    #  subdir: None
    #  aliases: dict
    paths = None
    plugin_loader = PluginLoader(name='my_name', package='my_package', paths=paths, base_class='my_base_class', class_name='my_class_name', subdir=None, aliases={})
    # Create test args:
    name = 'my_plugin'
    collection_list = None
    # Call method
    test_result = plugin_loader.find_plugin(name, collection_list=collection_list)
    # Check result
    assert test_result == None


# Generated at 2022-06-23 11:07:53.502881
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert get_shell_plugin('sh')
    assert get_shell_plugin('csh')
    assert not get_shell_plugin('not-a-shell')
    assert get_shell_plugin(executable='sh')
    assert get_shell_plugin(executable='csh')
    assert not get_shell_plugin(executable='not-an-executable')


# Generated at 2022-06-23 11:08:04.128748
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    """
    Test the method 'Jinja2Loader.all'
    """

# Generated at 2022-06-23 11:08:09.829176
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    '''
    :return:
    '''
    # test working with collection name only
    assert Jinja2Loader.find_plugin('xyz.collection.filter') is None

    # test working with collection name and plugin name
    assert Jinja2Loader.find_plugin('xyz.collection.filter.myfilter') is None

    # test working with plugin name only
    assert Jinja2Loader.find_plugin('myfilter') is None



# Generated at 2022-06-23 11:08:20.791741
# Unit test for method __contains__ of class PluginLoader

# Generated at 2022-06-23 11:08:26.881244
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    # NOTE: This is a unit test for a method that should never be called.
    # But we're testing it anyways to make sure it works
    files = []
    for path in ('/path/to/a/file', '/path/to/another/file'):
        mock_module = MagicMock()
        mock_module.JINJA2_FILTERS = {'filter_one': 'one', 'filter_two': 'two', 'filter_three': 'three'}
        mock_module.JINJA2_TESTS = {'test_one': 'one', 'test_two': 'two'}
        mock_module.JINJA2_FILTERS_MODULE = mock_module
        mock_module.JINJA2_TESTS_MODULE = mock_module
        files.append(mock_module)

# Generated at 2022-06-23 11:08:37.004221
# Unit test for method format_paths of class PluginLoader

# Generated at 2022-06-23 11:08:46.614933
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    plugin_loader = PluginLoader(
        'ansible.plugins',
        'Test',
        'TestModule',
        C.DEFAULT_INVENTORY_ENABLED_GROUP_PREFIX + 'test'
    )

    assert plugin_loader.package == 'ansible.plugins'
    assert plugin_loader.class_name == 'Test'
    assert plugin_loader.config_base == 'TestModule'
    assert plugin_loader.base_class is None
    assert plugin_loader.subdir is None

# Generated at 2022-06-23 11:08:51.668106
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    with patch.object(Jinja2Loader, 'find_plugin', autospec=True) as mock_find_plugin:
        obj = Jinja2Loader(None, None, None)
        mock_find_plugin.assert_not_called()

        obj.find_plugin(name='foo')
        mock_find_plugin.assert_called_once_with(obj, name='foo')



# Generated at 2022-06-23 11:08:57.280746
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    name = "Test Name"
    cls = PluginLoader("Test Package", "Test Class Name", "Test Base Class Name", "Test Sub Dir")
    plugin_load_context = cls.find_plugin_with_context(name)
    assert plugin_load_context.plugin_resolved_name == name
    assert plugin_load_context.plugin_resolved_path is None
    assert plugin_load_context.redirect_list == []
    assert plugin_load_context.resolved == False
    assert plugin_load_context.message == name + " is not found"

# Generated at 2022-06-23 11:09:03.352256
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    #FIXME: This method is bad. It does not test anything.
    #       It creates a plugin loader, loads a plugin and returns it.
    #       Nothing of the above is tested in any way.
    #       The name of the method should be updated to reflect what it actually does.
    loader = Jinja2Loader()
    plugin = loader.find_plugin('async_status.py')

    return plugin


# Generated at 2022-06-23 11:09:08.091584
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
  Jinja2Loader_obj = Jinja2Loader(package=None, config=None, subdir='', class_name=None, aliases=None, names=None,
                                  base_class=None)

  with pytest.raises(AnsibleError):
    Jinja2Loader_obj.find_plugin(name=None)


# Generated at 2022-06-23 11:09:11.213323
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    path_internal = PluginPathContext('/some/path', True)
    assert path_internal is not None



# Generated at 2022-06-23 11:09:16.407853
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    from ansible.plugins import module_loader, connection_loader, lookup_loader, filter_loader, test_loader, action_loader, fragment_loader
    loader_list = [module_loader, connection_loader, lookup_loader, filter_loader, test_loader, action_loader, fragment_loader]
    for loader in loader_list:
        loader.print_paths()



# Generated at 2022-06-23 11:09:17.686456
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    pass


# Generated at 2022-06-23 11:09:24.118350
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():

    PL = PluginLoader('dummy', 'dummy', 'dummy')
    paths = ['/some/path/here', '/else/where/over/there']
    expected = "/some/path/here, /else/where/over/there"

    # test default behavior
    actual = PL.format_paths(paths)
    assert expected == actual, "expected: %s, actual: %s" % (expected, actual)

    # test making the path list shorter
    expected = "/some/path/here, ..., /else/where/over/there"
    actual = PL.format_paths(paths, _max_length=len(expected))
    assert expected == actual, "expected: %s, actual: %s" % (expected, actual)

    # test making the path list longer

# Generated at 2022-06-23 11:09:35.865208
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    PL = PluginLoader('_test', 't', 'T')
    PL._get_paths = MagicMock(return_value=[])
    PL._load_module_source = MagicMock(return_value=lambda:None)
    obj1 = MagicMock()
    obj2 = MagicMock()
    type(obj1).__subclasscheck__ = MagicMock(return_value=True)
    type(obj2).__subclasscheck__ = MagicMock(return_value=True)
    obj1.__init__ = MagicMock()
    obj2.__init__ = MagicMock()
    PL._module_cache = {
        "path1": obj1,
        "path2": obj2,
        "path3": obj1,
        "path4": obj2
    }
    PL._searched

# Generated at 2022-06-23 11:09:38.394365
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    p = PluginLoader('', '')
    p._searched_paths = ['b', 'a']
    assert p.format_paths() == "a, b"



# Generated at 2022-06-23 11:09:44.977419
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():

  # Additional tests using first-party collections.
  # These tests will fail if the installed collections are not compatible with the
  # source tree that is currently installed.
  firstparty_collections = (
    'ansible_collections.dell.osc',
    'ansible_collections.sensu.sensu_go',
  )

  # Test a first-party collection that is not in the built-in collections
  # list. This ensures that plugins from first-party collections, whether
  # built-in or not, are not loaded.
  # This test will fail if the installed collections are not compatible with the
  # source tree that is currently installed.
  bad_collection = 'ansible_collections.ansible.unittest'

# Generated at 2022-06-23 11:09:55.909497
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    p = PluginLoadContext()
    assert p.original_name is None
    assert p.redirect_list == []
    assert p.error_list == []
    assert p.import_error_list == []
    assert p.load_attempts == []
    assert p.pending_redirect is None
    assert p.exit_reason is None
    assert p.plugin_resolved_path is None
    assert p.plugin_resolved_name is None
    assert p.plugin_resolved_collection is None
    assert p.deprecated is False
    assert p.removal_date is None
    assert p.removal_version is None
    assert p.deprecation_warnings == []
    assert p.resolved is False
    assert p._resolved_fqcn is None



# Generated at 2022-06-23 11:10:01.954240
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
#
# Declarations
#
    my_loader = None # type: PluginLoader
#
# Setup
#
    my_loader = PluginLoader('', '', '', '')
#
# Unit Tests
#
#
# Testing
#
    my_loader.find_plugin('', '', '', '')
    assert True # TODO: implement your test here
#
# Teardown
#
#

# Generated at 2022-06-23 11:10:11.684787
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    """Test to ensure that we properly handle the state of the PluginLoader with __get_state__/__set_state__"""
    cache = PluginLoader._module_cache
    try:
        PluginLoader._module_cache = {}
        pl = PluginLoader('ignore_me.plugins', 'NotImportant')
        expected = {'_caching': {}, '_searched_paths': [], 'aliases': {}, 'package': 'ignore_me.plugins', '_configs_def': {}, 'class_name': 'NotImportant'}
        actual = pl.__getstate__()
        assert expected == actual

    finally:
        PluginLoader._module_cache = cache



# Generated at 2022-06-23 11:10:22.228900
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    """
    Unit test for method print_paths of PluginLoader
    """

    import copy
    import tempfile

    from ansible.module_utils.six import PY2, string_types
    from ansible.module_utils._text import to_bytes, to_native

    # initialize a cache
    p = PluginLoader("action", "Foo", C.DEFAULT_ACTION_PLUGIN_PATH, 'action_plugins', required_base_class="ActionBase")
    # grab a tempfile
    (fd, tpath) = tempfile.mkstemp(prefix="ansible_test_")
    os.close(fd)

    all_paths = p.get_all_paths()
    # add a new path, ensure it's printed and in the list
    p.add_directory(tpath)
    assert p.print

# Generated at 2022-06-23 11:10:25.263484
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    # Check if method get of class PluginLoader is working properly
    plugin_loader = PluginLoader('action_plugin', 'ActionModule', 'ansible.plugins.action')
    action_plugin = plugin_loader.get('ping.py')
    assert action_plugin is not None


# Generated at 2022-06-23 11:10:30.704677
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    plc = PluginLoadContext()
    assert not plc.resolved
    assert plc.resolve('name', 'path', 'coll', 'reason') is plc
    assert plc.resolved
    assert plc.plugin_resolved_name == 'name'
    assert plc.plugin_resolved_path == 'path'
    assert plc.plugin_resolved_collection == 'coll'
    assert plc.exit_reason == 'reason'


# Generated at 2022-06-23 11:10:35.374195
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():

    obj1 = get_with_context_result(None, None)
    assert obj1.get_with_context() is None

    class TestClass(object):
        def __init__(self, name):
            self.name = name

        def __repr__(self):
            return u'TestClass(%s)' % self.name

        def get_with_context(self):
            return self.name

    obj2 = get_with_context_result(TestClass(u'obj2'), None)
    assert obj2.get_with_context() == u'obj2'

    obj3 = get_with_context_result(None, TestClass(u'obj3'))
    assert obj3.get_with_context() == u'obj3'


# Generated at 2022-06-23 11:10:47.153206
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    print(PluginLoader.__contains__.__doc__)
    # Initialize plugin loader
    plugin_loader = PluginLoader(
        'MyPlugin',
        'ansible.plugins.lookup',
        C.config.get_config_value('DEFAULT_MODULE_PATH'),
        'lookup_plugins',
        required_base_class='LookupBase'
    )
    class_only = False
    collection_list = None

    # Call method
    plugin_loader.has_plugin('Plugin1', collection_list=collection_list)

    # Get result of the method
    result = plugin_loader.has_plugin('Plugin1', collection_list=collection_list)
    print("Result:", result)
# Initialize plugin loader

# Generated at 2022-06-23 11:10:52.863844
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    test_PluginLoadContext = PluginLoadContext()
    result = test_PluginLoadContext.resolve(resolved_name="test",resolved_path="test",resolved_collection="test", exit_reason="test")
    assert result.pending_redirect is None
    assert result.plugin_resolved_name == "test"
    assert result.plugin_resolved_path == "test"
    assert result.plugin_resolved_collection == "test"
    assert result.exit_reason == "test"
    assert result.resolved is True


# Generated at 2022-06-23 11:11:05.594288
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():

    # creating a Mock class to check if all() method has been called with filter_plugin argument
    class MockAnsibleJinja2Loader(Jinja2Loader):
        def __init__(self, filter_plugin):
            self.filter_plugin = filter_plugin
            self.all_called = False

        def all(self, **kwargs):
            self.all_called = True
            return ['module_utils/basic', 'filter_plugins/basic']

    # creating an instance of class Jinja2Loader and checking if find_plugin is handled properly
    filter_plugin = MockAnsibleJinja2Loader(True)
    # returning two plugin paths
    assert ['module_utils/basic', 'filter_plugins/basic'] == filter_plugin.find_plugin('test_plugin')
    assert filter_plugin.all_called is True

   

# Generated at 2022-06-23 11:11:12.195907
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    # test __init__
    test1 = PluginLoadContext()
    assert test1.original_name == None
    assert test1.redirect_list == []
    assert test1.error_list == []
    assert test1.load_attempts == []
    assert test1.pending_redirect == None
    assert test1.exit_reason == None
    assert test1.plugin_resolved_path == None
    assert test1.plugin_resolved_name == None
    assert test1.plugin_resolved_collection == None
    assert test1.deprecated == False
    assert test1.removal_date == None
    assert test1.removal_version == None
    assert test1.deprecation_warnings == []
    assert test1.resolved == False


# Generated at 2022-06-23 11:11:20.358189
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    a_pl = PluginLoader('a', 'b')

    # Mock the update_object function to make sure it is called
    a_pl.update_object = mock.MagicMock()

    a_pl._module_cache = mock.MagicMock()
    a_pl._module_cache.__getitem__ = mock.MagicMock(return_value='loaded_module')

    # Mocking the class initialization
    obj = mock.MagicMock()
    obj.__class__ = mock.MagicMock()
    obj.__init__ = mock.MagicMock()

    # Setting up the return value of the getattr
    type(a_pl._module_cache['path']).b = mock.PropertyMock(return_value=obj)

    # Mock the display plugin load function

# Generated at 2022-06-23 11:11:27.441985
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    pl = PluginLoader("test", "test")
    pl.has_plugin = MagicMock(return_value=True)
    pl.paths = ["path1", "path2"]

    result = "test_action" in pl

    assert result == True, "Expected: %s \n Actual: %s"%(True, result)
    assert pl.has_plugin.call_count == 1
    pl.has_plugin.assert_called_with("test_action", collection_list=["path1", "path2"])


# Generated at 2022-06-23 11:11:28.020808
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    pass

# Generated at 2022-06-23 11:11:32.353541
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    test_loader = Jinja2Loader('', '', '', '', '',)
    with pytest.raises(AnsibleError) as error_info:
        test_loader.get()

    assert "No code should call \"get\" for Jinja2Loaders (Not implemented)" == str(error_info.value)

# Generated at 2022-06-23 11:11:35.637257
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    loader = PluginLoader(
        package='ansible.plugins',
        config=None,
        subdir='lookup_plugins',
        aliases=None,
        class_name='LookupModule',
        base_class='BaseLookupModule'
    )
    result = loader.has_plugin('template')
    assert result



# Generated at 2022-06-23 11:11:38.733618
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    pluginloadcontext = PluginLoadContext()
    assert pluginloadcontext.nope("test") == pluginloadcontext


# Generated at 2022-06-23 11:11:49.291148
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    """
    :return:
    """
    which_loader = 'action'
    dirs = [
        '/var/lib/awx/plugins/action',
        '/var/lib/awx/plugins/callback',
        '/var/lib/awx/plugins/connection',
        '/var/lib/awx/plugins/filter',
        '/var/lib/awx/plugins/inventory',
        '/var/lib/awx/plugins/lookup',
        '/var/lib/awx/plugins/module_utils',
        '/var/lib/awx/plugins/shell',
        '/var/lib/awx/plugins/strategy',
        '/var/lib/awx/plugins/test',
        '/var/lib/awx/plugins/vars'
    ]


# Generated at 2022-06-23 11:11:51.926927
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    load = PluginLoader(package='ansible.plugins', subdir='lookup')
    load.print_paths()


# Generated at 2022-06-23 11:11:59.703602
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    # Issue #29264
    import copy

    plugin_loader = PluginLoader('ActionModule', 'action', 'ansible.plugins.action')
    assert not hasattr(plugin_loader, '_module_cache')

    plugin_loader._module_cache = {}
    plugin_loader_copy = copy.copy(plugin_loader)
    assert hasattr(plugin_loader_copy, '_module_cache')



# Generated at 2022-06-23 11:12:01.815230
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    for plugin in ['name', 'path', 'collection', 'exit_reason']:
        assert hasattr(PluginLoadContext, plugin)



# Generated at 2022-06-23 11:12:08.109097
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    import copy
    plugin_loader = PluginLoader()
    try:
        assert not isinstance(copy.copy(plugin_loader), PluginLoader)
        assert not isinstance(copy.deepcopy(plugin_loader), PluginLoader)
    except AssertionError:
        raise AssertionError(msg='Failed to test method __getstate__')
    return True



# Generated at 2022-06-23 11:12:18.385665
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert get_shell_plugin(executable='/bin/bash').SHELL_FAMILY == 'Bash'
    assert get_shell_plugin(executable='/bin/sh').SHELL_FAMILY == 'Sh'
    assert get_shell_plugin(executable='/bin/fish', shell_type='csh').SHELL_FAMILY == 'Csh'
    assert get_shell_plugin(executable='unknown', shell_type='csh').SHELL_FAMILY == 'Csh'
    assert get_shell_plugin(shell_type='csh').SHELL_FAMILY == 'Csh'
    assert get_shell_plugin(shell_type='csh').executable == '/bin/csh'



# Generated at 2022-06-23 11:12:22.309890
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    # Set up the parameters for the test
    loader = PluginLoader('', '', '', '')
    obj = PluginLoader('', '', '', '')
    fields = {}

    # The code we are testing
    try:
        state = obj.__getstate__()
    except Exception as e:
        state = None

    # Make assertions
    assert state is not None

# Generated at 2022-06-23 11:12:25.781598
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    _plugin_loader = PluginLoader('filter_plugins')
    assert isinstance(_plugin_loader, PluginLoader)
    assert isinstance(_plugin_loader.get('unique'), list)
    assert isinstance(_plugin_loader.get('join'), list)
    assert isinstance(_plugin_loader.get('hash'), str)
    try:
        assert isinstance(_plugin_loader.get('abc'), str)
    except:
        return True
    return False


# Generated at 2022-06-23 11:12:26.906579
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    # The method get of the class Jinja2Loader is already tested.
    return

# Generated at 2022-06-23 11:12:29.982877
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    # init
    module_loader.directories = []

    # test
    add_dirs_to_loader('module', ['/tmp'])
    assert module_loader.directories == ['/tmp']



# Generated at 2022-06-23 11:12:30.828168
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    pass


# Generated at 2022-06-23 11:12:35.310257
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    p = PluginPathContext("/library", False)
    assert p.path == os.path.expanduser("/library")
    assert p.internal is False

# PluginLoader objects are used to load plugins from a given path, and have
# knowledge of what subdirectories plugins are contained in.  They also are
# used to create the basic documentation fragments used in the generated
# documentation.

# Generated at 2022-06-23 11:12:36.688986
# Unit test for method __getstate__ of class PluginLoader

# Generated at 2022-06-23 11:12:43.923429
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    pldr = PluginLoader('borg')
    found_plugin_with_context = pldr.find_plugin_with_context('ansible_collections.test.test_collection.test_plugins.borg.test_plugin')
    assert found_plugin_with_context.plugin_fqcn == 'ansible_collections.test.test_collection.test_plugins.borg.test_plugin', \
        "FQCN {0} of plugin found by PluginLoader.find_plugin_with_context is wrong. Should be 'ansible_collections.test.test_collection.test_plugins.borg.test_plugin'".format(
            found_plugin_with_context.plugin_fqcn)


# Generated at 2022-06-23 11:12:51.603248
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    path_list = ['/my/path/plugin1.py', '/my/path/plugin2.py', '/my/path/plugin3.py', '/my/path/plugin4.py', '/my/path/plugin5.py']
    assert PluginLoader.format_paths(path_list) == "/my/path/plugin1.py, /my/path/plugin2.py, /my/path/plugin3.py, /my/path/plugin4.py, /my/path/plugin5.py"


# Generated at 2022-06-23 11:12:58.838401
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    package = 'ansible.legacy.plugins.filter'
    filter_loader = Jinja2Loader(package)

    returned = list(filter_loader.all())
    assert len(returned) > 0
    assert set(returned) == {'grep', 'map', 'rejectattr', 'selectattr', 'unique', 'flatten'}

    package = 'ansible.legacy.plugins.test'
    test_loader = Jinja2Loader(package)

    returned = list(test_loader.all())
    assert len(returned) > 0
    assert set(returned) == {'type_debug', 'and_', 'in', 'has_all', 'truthy', 'equals', 'version_compare',
                             'defined', 'has_any'}



# Generated at 2022-06-23 11:13:06.825695
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    """Constructor for plugin loader

    The loader should properly initialize the attributes of a plugin loader object.
    """
    loader = PluginLoader(package='ansible.plugins.test', class_name='TestClass', base_class='BaseClass',
        subdir=None, aliases={'testalias': 'testname', 'testalias2': 'testname2'})
    assert loader.package == 'ansible.plugins.test'
    assert loader.class_name == 'TestClass'
    assert loader.base_class == 'BaseClass'
    assert loader.subdir is None
    assert loader.aliases == {'testalias': 'testname', 'testalias2': 'testname2'}


# Generated at 2022-06-23 11:13:12.523458
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # Test with default args
    collection_loader = get_collection_loader()
    module_loader = get_all_plugin_loaders()['module_utils']
    assert 'os_module' in module_loader
    assert 'os_module' not in collection_loader



# Generated at 2022-06-23 11:13:15.541843
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    assert PluginLoadContext().redirect('redirect_name').pending_redirect == 'redirect_name'


# Generated at 2022-06-23 11:13:17.737672
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    pl = PluginLoader('foo.bar')
    assert pl.get('baz') is None


# Generated at 2022-06-23 11:13:29.132985
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    lib = PluginLoader('', '', '', '', '', C.DEFAULT_INTERNAL_PLUGIN_PATH)
    ansible_collections_namespace = 'ansible_collections.namespace'
    ansible_collections_namespace_plugin = 'ansible_collections.namespace.plugin'
    namespace = 'namespace'
    plugin = 'namespace.plugin'
    plugin_path = "/path/to/ansible_collections/namespace/plugins/module_utils/plugin.py"
    assert lib.find_plugin_with_context(ansible_collections_namespace, collection_list=[]) is None
    lib.package = ansible_collections_namespace

# Generated at 2022-06-23 11:13:39.839995
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    context = PluginLoadContext()
    assert context.original_name == None
    assert context.redirect_list == []
    assert context.error_list == []
    assert context.import_error_list == []
    assert context.load_attempts == []
    assert context.pending_redirect == None
    assert context.exit_reason == None
    assert context.plugin_resolved_path == None
    assert context.plugin_resolved_name == None
    assert context.plugin_resolved_collection == None
    assert context.deprecated == False
    assert context.removal_date == None
    assert context.removal_version == None
    assert context.deprecation_warnings == []
    assert context.resolved == False
    assert context._resolved_fqcn == None


# Generated at 2022-06-23 11:13:47.104530
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    pl = PluginLoader('ansible.plugins.lookup', 'LookupModule')
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)
    try:
        # first, test to see if the path is added if it's a directory
        pl.add_directory(temp_path)
        assert temp_path in pl._get_paths()
        # now try adding a non-directory
        pl.add_directory(temp_path + '_nein_nein_nein')
        assert temp_path + '_nein_nein_nein' not in pl._get_paths()
    finally:
        os.remove(temp_path)

# Generated at 2022-06-23 11:13:59.642360
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    loader = Jinja2Loader('filter_loader', 'ansible.plugins.filter', C.DEFAULT_FILTER_PLUGIN_PATH, 'FilterModule')
    assert loader.package == 'ansible.plugins.filter'
    assert loader.subdir == 'filter_plugins'
    assert loader.class_name == 'FilterModule'
    assert loader.plugins is None
    assert loader._searched_paths == C.DEFAULT_FILTER_PLUGIN_PATH
    assert not hasattr(loader, 'base_path')
    assert loader.base_class is None

FILTER_PLUGINS = Jinja2Loader('filter_loader', 'ansible.plugins.filter', C.DEFAULT_FILTER_PLUGIN_PATH, 'FilterModule')

# Generated at 2022-06-23 11:14:02.896348
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    name = None
    args = None
    kwargs = None
    # Call method
    result = PluginLoader.get_with_context(name, *args, **kwargs)
    # Verify the result
    assert isinstance(result, get_with_context_result)


# Generated at 2022-06-23 11:14:13.099728
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    '''
    Make sure the plugin loader works as expected.
    '''

    # Verify that if the python path is modified, the plugin loader
    # looks in the correct place for a module.  Now that the plugin
    # directories are determined at import time, the easiest way to
    # set the python path is to insert it in front of the existing
    # one.
    sys.path.insert(0, '/tmp')
    PL = PluginLoader('tmp', 'foo')
    assert '/tmp/ansible/plugins/tmp' in PL._get_paths()
    assert '/tmp/ansible/plugins/tmp/foo.py' == PL.find_plugin('foo')


# Generated at 2022-06-23 11:14:26.037791
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plugin_load_context=PluginLoadContext()
    assert plugin_load_context.original_name is None
    assert plugin_load_context.redirect_list == []
    assert plugin_load_context.error_list == []
    assert plugin_load_context.import_error_list == []
    assert plugin_load_context.load_attempts == []
    assert plugin_load_context.pending_redirect is None
    assert plugin_load_context.exit_reason is None
    assert plugin_load_context.plugin_resolved_path is None
    assert plugin_load_context.plugin_resolved_name is None
    assert plugin_load_context.plugin_resolved_collection is None
    assert plugin_load_context.deprecated == False
    assert plugin_load_context.removal_date is None
    assert plugin

# Generated at 2022-06-23 11:14:27.618055
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    assert len(get_all_plugin_loaders()) > 0



# Generated at 2022-06-23 11:14:31.700139
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():

    from ansible.errors import AnsibleError
    from ansible.plugins import jinja2_loader
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.loader.inventory import inventory_loader

    class MyJinja2Loader(Jinja2Loader):
        pass

    class MyJinja2Loader2(Jinja2Loader):
        pass

    class MyJinja2Loader3(Jinja2Loader):
        pass

    class MyJinja2Loader4(MyJinja2Loader2):
        pass

    class MyInventoryLoader(PluginLoader):
        pass

    class MyInventoryLoader2(PluginLoader):
        pass

    class MyInventoryLoader3(MyInventoryLoader):
        pass


# Generated at 2022-06-23 11:14:41.433467
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # Set up
    test_loader = PluginLoader('foo', 'foo.plugins', C.DEFAULT_INTERNAL_PLUGIN_PATH, 'foo.base', required_base_class='foo.base.FooBase')

    # Test
    # Should return an instance of PluginLoadContext
    test_loader.find_plugin(name='bar')

    # Test
    # Test for when collection_list is None
    test_loader.find_plugin(name='bar', collection_list=None)

    # Test
    # Test for when collection_list is not None
    temp_collection_list = [
        AnsibleCollectionRef.from_str("foo.bar"),
        AnsibleCollectionRef.from_str("foo.qux")
    ]

# Generated at 2022-06-23 11:14:52.040599
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    '''
    Unit test for method add_directory of class PluginLoader
    '''
    PL = PluginLoader('dummy', 'base', '_')

    # Verify that an assertion is triggered when we attempt to
    # add a directory that does not exist
    failed = False

    try:
        PL.add_directory(path='dummy')
    except AssertionError:
        failed = True

    assert failed is True

    # Create a temp directory and test that when a valid directory is
    # added, the correct path is returned
    tmpdir = tempfile.mkdtemp()

    with open('%s/test.py' % tmpdir, 'w') as f:
        f.write('test')

    paths = PL.add_directory(path=tmpdir)

    assert paths == ['%s/test.py' % tmpdir]

# Generated at 2022-06-23 11:14:57.274617
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    plc = PluginLoadContext()
    assert plc.redirect_list == []
    assert plc.resolved == False
    plc.redirect('test')
    assert plc.redirect_list == ['test']
    assert plc.resolved == False


# Generated at 2022-06-23 11:15:03.862307
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    assert 'action_loader' in globals()
    assert 'cache_loader' in globals()
    assert 'connection_loader' in globals()
    assert 'filter_loader' in globals()
    assert 'inventory_loader' in globals()
    assert 'lookup_loader' in globals()
    assert 'module_loader' in globals()
    assert 'shell_loader' in globals()
    assert 'strategy_loader' in globals()
    assert 'terminal_loader' in globals()
    assert 'test_loader' in globals()
    assert 'vars_loader' in globals()
    assert 'vars_prompt_loader' in globals()
    assert 'callback_loader' in globals()
    assert 'callback_loader' in globals()
    plugin_loaders = get_all_plugin

# Generated at 2022-06-23 11:15:16.334609
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    test_path = '/some/base/path'
    b_path = os.path.expanduser(to_bytes(test_path, errors='surrogate_or_strict'))
    os.path.isdir = Mock(return_value=True)
    os.path.join = Mock(return_value=test_path)
    os.path.isdir = Mock(return_value=True)
    # test with non-existing directory provided
    add_all_plugin_dirs('/tmp/does-not-exist')
    assert not os.path.isdir.called
    assert not os.path.join.called
    # Test with existing directory provided
    os.path.isdir.return_value = True
    add_all_plugin_dirs(test_path)
    os.path.isdir.assert_

# Generated at 2022-06-23 11:15:19.618099
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    """ Make sure get_with_context_result is callable without any arguments """
    get_with_context_result()



# Generated at 2022-06-23 11:15:29.095206
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    loader = PluginLoader()
    assert loader.__getstate__() == {'package': 'ansible_collections.testns.testcoll', 'class_name': 'TestPlugin', 'configurable': True, 'directories': ['/home/dan/projects/ansible/test/units/modules/support/test_plugins_loader/testns/testcoll/plugins/test_plugin/'], 'aliases': {}, '_module_cache': {}, '_searched_paths': ['/home/dan/projects/ansible/test/units/modules/support/test_plugins_loader/testns/testcoll/plugins/test_plugin/'], '_plugin_aliases': {}, '_resolver_cache': {}}


# Generated at 2022-06-23 11:15:39.233997
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    # NOTE: We're mostly testing to make sure the 'all' method can take a list and process it as a generator
    import sys
    sys.modules['jinja2.filters'] = jinja2.filters
    sys.modules['jinja2.tests'] = jinja2.tests

    from ansible.plugins.loader import Jinja2Loader

    loader = Jinja2Loader('filter_loader', 'ansible.plugins.filter_loader', 'FilterModule', 'ansible.plugins.filter_loader.base')
    files = loader.all()
    assert isinstance(files, list)


# Generated at 2022-06-23 11:15:43.463417
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    # constructor with path and internal
    context = PluginPathContext('chdir', True)
    assert context.path == 'chdir'
    assert context.internal

    # constructor with path only
    context = PluginPathContext('chdir2')
    assert context.path == 'chdir2'
    assert not context.internal



# Generated at 2022-06-23 11:15:51.743180
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    '''
  This is a test for method get of class plugin loader
  '''
    global _PLUGIN_PATH_CACHE
    _PLUGIN_PATH_CACHE = {}
    #Test the default case
    obj = PluginLoader(class_name='ShellModule', package='ansible.runner.action_plugins', config=None, subdir=None, aliases={}, required_base_class='ActionBase')
    assert obj.get(name='shell') is not None


# Generated at 2022-06-23 11:15:54.108527
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    from ansible.plugins.shell import ShellBase
    result = get_shell_plugin("powershell")
    assert result.SHELL_FAMILY == "powershell"
    assert isinstance(result, ShellBase)


# Generated at 2022-06-23 11:15:59.837387
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    PLUGIN_PATH = ['rocky','paul','buster','stormy','spot','marbles','lucky','olaf','apollo','penny','dakota','daisy']
    for dir_name in PLUGIN_PATH:
            os.mkdir(dir_name)
    for dir_name in PLUGIN_PATH:
        add_all_plugin_dirs(dir_name)
    for dir_name in PLUGIN_PATH:
        os.removedirs(dir_name)
    print('unit test for function add_all_plugin_dirs success')


# Generated at 2022-06-23 11:16:12.817362
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    import os
    import tempfile
    from ansible.plugins.loader import PluginLoadContext

    ctx = PluginLoadContext()

    test_dir = tempfile.mkdtemp()
    path = os.path.join(test_dir, 'ansible_collections/foo_bar/bar/plugins/modules/bad_module.py')
    path2 = os.path.join(test_dir, 'ansible_collections/foo_bar/bar/plugins/modules/foo.py')
    os.makedirs(os.path.dirname(path))

    with open(path2, 'a') as f:
        f.write('')

    # test for path not exist
    exit_reason = "file does not exist: {}".format(path)
    ctx.nope(exit_reason)


# Generated at 2022-06-23 11:16:25.238777
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    import json
    import pprint
    x = PluginLoadContext()
    x = x.record_deprecation('name', {'warning_text': 'foo', 'removal_version': '2.14'}, 'ansible.builtin')
    x = x.record_deprecation('name', {'warning_text': 'foo', 'removal_version': '2.14'}, 'ansible.builtin')
    pprint.pprint(json.loads(json.dumps(x, default=lambda o: o.__dict__, sort_keys=True)))
    # TODO: Without the above two lines this test is broken because pprint and json.dump call different methods on the set
    x = PluginLoadContext()

# Generated at 2022-06-23 11:16:32.949081
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    def test_shell_match(filename, expected_shell):
        shell = get_shell_plugin(executable=filename)
        assert shell.SHELL_FAMILY == expected_shell

    test_shell_match('/bin/sh', 'sh')
    test_shell_match('/bin/bash', 'bash')
    test_shell_match('/bin/zsh', 'sh')
    test_shell_match('/bin/ksh', 'sh')
    test_shell_match('/bin/dash', 'sh')
    test_shell_match('/bin/sh.distrib', 'sh')
    test_shell_match('/bin/csh', 'csh')
    test_shell_match('/bin/tcsh', 'csh')
    test_shell_match('/bin/fish', 'fish')
    test

# Generated at 2022-06-23 11:16:46.101477
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    cls = Jinja2Loader(package='ansible.plugins.action', subdir='my_subdir', base_class='my_base_class')
    # Test with correct arguments
    name = 'myname'
    collection_list = ['bar', 'baz']
    result = cls.get(name, collection_list=collection_list)

    assert isinstance(result, tuple)
    assert len(result) == 2
    assert callable(result[0])
    assert isinstance(result[1], PluginLoaderContext)
    assert result[1].searched_paths == cls.get_all_search_paths()
    assert result[1].collections_searched is False
    assert result[1].redirected_names == []

    # Test with correct arguments and plugins from collections

# Generated at 2022-06-23 11:16:55.815588
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():

    loader = Jinja2Loader('', '', '', '', '')

    # test find_plugin for valid name
    with patch.object(loader, 'find_plugin') as mocked_find_plugin:
        mocked_find_plugin.return_value = 'fake_value'
        result = loader.find_plugin('name')
        mocked_find_plugin.assert_called_once_with('name')
        assert result == 'fake_value'

    # test find_plugin for valid name with unique name
    with patch.object(loader, 'find_plugin') as mocked_find_plugin:
        mocked_find_plugin.return_value = 'fake_value'
        result = loader.find_plugin('name', 'collection_list')
        mocked_find_plugin.assert_called_once_with('name', 'collection_list')

# Generated at 2022-06-23 11:16:57.835680
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    pr = PluginLoadContext()
    assert pr.nope(exit_reason="foo").exit_reason == "foo"
    assert pr.exit_reason == "foo"

# Generated at 2022-06-23 11:17:09.954486
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    try:
        from ansible.utils.collection_loader import AnsibleCollectionLoader
    except ImportError:
        # Some older Ansible versions don't have a collection loader
        return

    acr = AnsibleCollectionRef.parse('ansible.builtin')

    plugin_loader = PluginLoader(
        'ansible.plugins.lookup',
        'LookupModule',
        invoke_on_load=True,
        use_cwd=False,
        class_only=False,
    )

    # No existing collection
    collection_loader = AnsibleCollectionLoader()
    c_list = collection_loader.get_collection_list()
    plugin_load_context = PluginLoadContext()


# Generated at 2022-06-23 11:17:18.752526
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    import ansible.plugins.test.test_loader
    import ansible.plugins.action.ActionBase

    def load_module_source(module_name, path):
        return ansible.plugins.test.test_loader

    def update_object(obj, name, path):
        return obj

    def debug(msg):
        print(msg)

    action_loader = Jinja2Loader(
        'action', module_utils.module_loader.ActionModuleLoader, C.DEFAULT_MODULE_PATH,
        package=ansible.plugins.action, config=None,
        base_class=ansible.plugins.action.ActionBase
    )

    action_loader._load_module_source = load_module_source
    action_loader._update_object = update_object

# Generated at 2022-06-23 11:17:24.152144
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
  from nose.tools import assert_equals, assert_false
  context = PluginLoadContext()
  context.nope('reason')
  assert_equals(context.pending_redirect, None)
  assert_equals(context.exit_reason, 'reason')
  assert_false(context.resolved)


# Generated at 2022-06-23 11:17:36.021740
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    loader = PluginLoader('ansible.plugins.callback', 'CallbackModule', 'callback', required_base_class='CallbackBase')
    loader._searched_paths = [
        '/home/user/.ansible/plugins/callback',
        '/home/user/playbook/custom-plugins/callback',
        '/usr/share/ansible/plugins/callback',
        '/usr/local/lib/ansible/plugins/callback',
        '/etc/ansible/plugins/callback',
    ]

    expected = '/home/user/.ansible/plugins/callback:/home/user/playbook/custom-plugins/callback'
    got = loader.format_paths()
    assert expected == got, "Expected {0} but got {1}".format(expected, got)


# Generated at 2022-06-23 11:17:39.128578
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # See also:
    #   - test/units/test_ModuleUtility.py:test_get_action_tokens()

    # TODO: Add tests for this method

    pass
