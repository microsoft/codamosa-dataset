

# Generated at 2022-06-23 11:07:42.130024
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    plc = PluginLoadContext()
    plc.redirect('foo')
    assert plc.pending_redirect == 'foo'
    assert plc.exit_reason == 'pending redirect resolution from None to foo'
    assert not plc.resolved



# Generated at 2022-06-23 11:07:50.216586
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    '''
    Unit test for method "__repr__" of class "PluginLoader"
    '''

    name = 'action_plugin'
    base_class = 'ActionBase'

    obj = PluginLoader(name, 'ansible.plugins.action', base_class=base_class)
    assert obj.__repr__() == "<ansible.utils.plugin_docs.PluginLoader object: name: action_plugin, package: ansible.plugins.action, class_name: ActionBase, base_class: ansible.plugins.action.ActionBase>"

# Generated at 2022-06-23 11:07:53.335729
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    plug = PluginLoader('lookup_plugins', 'lookup_plugins', 'lookup_plugins', 'lookup_plugins').get('', '')
    assert plug.__class__.__name__ == 'lookup_plugins'

# Generated at 2022-06-23 11:07:57.150756
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    class TestClass(object):
        pass
    loader = Jinja2Loader(TestClass, '.')
    assert loader.package == '.'
    assert loader.class_name == 'TestClass'
    assert loader.subdir is None
    assert loader.base_class is object

# Generated at 2022-06-23 11:08:03.467356
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    for name, obj in get_all_plugin_loaders():
        if obj.subdir:
            plugin_path = os.path.join('/tmp', to_bytes(obj.subdir))
            if os.path.isdir(plugin_path):
                obj.add_directory(to_text(plugin_path))



# Generated at 2022-06-23 11:08:05.579581
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    context = PluginPathContext('/foo/bar', True)
    assert context.path == '/foo/bar'
    assert context.internal is True


# Generated at 2022-06-23 11:08:09.794051
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    from ansible.plugins import module_loader
    module_loader.add_directory('.')
    assert '.' in module_loader.package_path
    assert '.' in module_loader.paths
    assert '.' in module_loader.directory_caches
    assert '.' in module_loader.plugin_paths['.']


# Generated at 2022-06-23 11:08:11.780336
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    context = PluginLoadContext()
    context.nope("exit_reason")
    assert context.resolved == False
    assert context.exit_reason == "exit_reason"

# Generated at 2022-06-23 11:08:15.833486
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    pl = PluginLoader('ansible.plugins.filter', 'FilterModule')

    print("Test for method all of class PluginLoader.")
    print(pl.all(class_only=False))


# Generated at 2022-06-23 11:08:25.180460
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert (get_shell_plugin(shell_type='sh').SHELL_FAMILY) == 'sh'
    assert (get_shell_plugin(shell_type='csh').SHELL_FAMILY) == 'csh'
    assert (get_shell_plugin(shell_type='fish').SHELL_FAMILY) == 'fish'
    assert (get_shell_plugin(shell_type='powershell').SHELL_FAMILY) == 'powershell'
    assert (get_shell_plugin(shell_type='sh', executable='./my.sh').SHELL_FAMILY) == 'sh'
    assert (get_shell_plugin(shell_type='sh', executable='my.sh').SHELL_FAMILY) == 'sh'

# Generated at 2022-06-23 11:08:29.365810
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    loader = PluginLoader('test', 'test_plugins', 'test_', 'test.plugins', 'Test')
    result = list(loader.all())
    assert set(result) == {('Test_1', 'Test_2', 'Test_3')}

# Generated at 2022-06-23 11:08:35.952219
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    class_name = 'FilterModule'
    package = 'ansible.plugins.filter_plugins'
    subdir = 'filter_plugins'
    base_class = 'FilterModule'
    j2 = Jinja2Loader(class_name, package, subdir, base_class)
    assert j2.class_name == class_name
    assert j2.package == package
    assert j2.subdir == subdir
    assert j2.base_class == base_class



# Generated at 2022-06-23 11:08:46.566717
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    with pytest.raises(AnsibleError) as excinfo:
        PluginLoader('')
    assert to_text('One of the following must be specified: "package", "directory", "class_name"') in to_text(excinfo.value)

    # Create a plugin loader without specifying a plugin type
    plugin_loader = PluginLoader('ansible.plugins.test', 'Test')

    # TODO: Add test for class_name
    # TODO: Add test for class_only
    # TODO: Add test for config_def

# Generated at 2022-06-23 11:08:51.738879
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    from ansible.utils.path import unfrackpath
    from ansible.parsing.utils.yaml import from_yaml, AnsibleLoader
    plugin_load_context = PluginLoadContext()
    plugin_load_context.record_deprecation(
        name='test',
        deprecation={'warning_text': 'test', 'removal_date': 'test', 'removal_version': 'test'},
        collection_name='test'
    )
    assert plugin_load_context.removal_date == 'test'
    assert plugin_load_context.removal_version == 'test'
    assert plugin_load_context.deprecation_warnings == ['test has been deprecated. test']



# Generated at 2022-06-23 11:08:56.783061
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    plugin_loader = PluginLoader("ansible.plugins.ActionModule")
    plugin_load_context = plugin_loader.find_plugin_with_context("setup")
    assert plugin_load_context.is_valid
    assert plugin_load_context.plugin_name == 'setup'
    assert plugin_load_context.plugin_resolved_name == 'setup'
    assert plugin_load_context.plugin_resolved_path is not None
    assert plugin_load_context.plugin_resolved_path.endswith("ansible/plugins/action/setup.py")
    assert plugin_load_context.plugin_load_name == "setup"
    assert plugin_load_context.plugin_searched_path is not None

# Generated at 2022-06-23 11:09:00.125977
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
  loader_pluginloader = PluginLoader('test_only')
  assert loader_pluginloader.__repr__() == "PluginLoader(test_only)"


# Generated at 2022-06-23 11:09:08.718844
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    context = PluginLoadContext()
    context.plugins = {'resolved_name': 'resolved_path'}
    exit_reason = 'exit_reason'
    resolved_name = 'resolved_name'
    resolved_path = 'resolved_path'
    resolved_collection = 'resolved_collection'
    context.resolve(resolved_name, resolved_path, resolved_collection, exit_reason)
    assert context.pending_redirect is None
    assert context.plugin_resolved_name == resolved_name
    assert context.plugin_resolved_path == resolved_path
    assert context.plugin_resolved_collection == resolved_collection
    assert context.exit_reason == exit_reason
    assert context.resolved == True



# Generated at 2022-06-23 11:09:14.573368
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    path = os.path.expanduser('~/.ansible')
    if os.path.isdir(path):
        add_all_plugin_dirs(path)
    else:
        os.mkdir(path)
        add_all_plugin_dirs(path)
        os.rmdir(path)



# Generated at 2022-06-23 11:09:22.692428
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    '''

    :return:
    '''

    from ansible.utils.path import unfrackpath

    pl = PluginLoader('whatever')
    assert str(pl) == "<ansible.plugins.whatever.whatever object at 0x%x>" % id(pl)
    del pl

    p = PluginLoader('Cog')
    assert str(p) == "<ansible.plugins.cog.Cog object at 0x%x>" % id(p)
    del p

    q = PluginLoader('cog', 'ansible.plugins.cog', 'Cog', 'cog', C.DEFAULT_COG_PATH)
    assert str(q) == "<ansible.plugins.cog.Cog object at 0x%x>" % id(q)
    del q

    # test the wrapper, which is the real thing we use



# Generated at 2022-06-23 11:09:31.258286
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    deprecation_info = {'warning_text': 'test warning_text', 'removal_date': 'test removal_date', 'removal_version': 'test removal_version'}
    load_context = PluginLoadContext()
    load_context.record_deprecation('test name', deprecation_info, 'test name')
    # assert load_context.deprecated
    # assert load_context.removal_date == 'test removal_date'
    # assert load_context.deprecation_warnings == ['test name has been deprecated. test warning_text']



# Generated at 2022-06-23 11:09:31.782737
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    pass



# Generated at 2022-06-23 11:09:39.895400
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    
    PluginLoader = AnsiblePluginLoader(package='', directories=[], class_name='', base_class='', enable_local_dump=False)
    
    # test with invalid directory
    directory = 'a0x3c3f7a5a8f0c0f9b5a050b57244ce6e8c6d7'
    assert PluginLoader.add_directory(directory) == False
    
    # test with valid directory
    directory = '/tmp/plugin_loader_test/a0x3c3f7a5a8f0c0f9b5a050b57244ce6e8c6d7'
    assert PluginLoader.add_directory(directory) == True
    


# Generated at 2022-06-23 11:09:46.479157
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    mock_config = make_mock_config()
    mock_config.get_value = MagicMock(side_effect = [
        # return paths to look
        [(('/test-ansible/lib/ansible/plugins/test-dir', False),),
         (('/test-ansible/lib/ansible/plugins/test-dir/test-pkg', False),),
        ],
        # return the config for the package
        [(('/test-ansible/lib/ansible/plugins/test-dir/test-pkg/__init__.py', False),),
        ],
    ])
    mock_config.DEFAULT_CACHE_PLUGIN_CONNECTION = None

# Generated at 2022-06-23 11:09:54.265195
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    '''
    plugin_loader.get_with_context(name, *args, **kwargs) -> PluginLoadContext(plugin_object, plugin_load_context)
    '''
    def get_with_context(self, name, *args, **kwargs):
        class_only = kwargs.pop('class_only', False)
        collection_list = kwargs.pop('collection_list', None)
        if name in self.aliases:
            name = self.aliases[name]
        plugin_load_context = self.find_plugin_with_context(name, collection_list=collection_list)
        if not plugin_load_context.resolved:
            return get_with_context_result(None, plugin_load_context)

        name = plugin_load_context.plugin_resolved_name
        path

# Generated at 2022-06-23 11:10:05.561456
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    '''
    Constructor of class PluginLoader accepts 1 argument named 'package'.
    package is the name of the package which the plugins to be loaded are in.
    The constructor will save the argument 'package' in variable 'self.package'.
    It will also set variable 'self.path' to ['<ansible>/lib/ansible/plugins/<package>'].
    '''
    package_name = 'cache'
    expected_package = package_name
    expected_path = [to_bytes('%s/lib/ansible/plugins/%s' % (C.DEFAULT_MODULE_PATH, package_name))]
    pl = PluginLoader(package_name)
    assert expected_package == pl.package
    assert expected_path == pl.path


# Generated at 2022-06-23 11:10:09.449572
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    # Test resolve
    b = PluginLoadContext()
    result = b.resolve('resolved_name', 'resolved_path', 'resolved_collection', 'exit_reason')
    print(result)



# Generated at 2022-06-23 11:10:13.160856
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    result = ResultObj()

    context_result = get_with_context_result(result, 'context')

    assert context_result.context == 'context'



# Generated at 2022-06-23 11:10:23.239182
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    # setup
    def fake_super_all(self, *args, **kwargs):
        fake_super_all.times_called += 1
        fake_super_all_expected_args = {'path_only': False, '_dedupe': True, 'class_only': False}
        fake_super_all_expected_kwargs = {}
        if args != fake_super_all_expected_args:
            raise Exception('args != expected_args')
        if kwargs != fake_super_all_expected_kwargs:
            raise Exception('kwargs != expected_kwargs')
        return ['file1', 'file2', 'file3', 'file4', 'file5']
    fake_super_all.times_called = 0
    subdir = 'ansible.legacy'

# Generated at 2022-06-23 11:10:31.939254
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    plugin_name = 'test_add_dirs_to_loader'
    plugin_path = os.path.join(C.DEFAULT_LOCAL_TMP, '%s_plugin_path' % plugin_name)
    paths = [plugin_path]
    try:
        os.mkdir(plugin_path)
    except OSError:
        pass
    add_dirs_to_loader('lookup', paths)
    lookup_plugins = lookup_loader._get_all_plugins()
    assert os.path.basename(plugin_path) in lookup_plugins
    add_dirs_to_loader('callback', paths)
    callback_plugins = callback_loader._get_all_plugins()
    assert os.path.basename(plugin_path) in callback_plugins

# initialize plugin loaders

lookup_

# Generated at 2022-06-23 11:10:33.721534
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    try:
        loader = Jinja2Loader('ansible.plugins.cache')
        j2_plugins = loader.get(name)
        display.error("Jinja2Loader.get() should not exist.  Docs are wrong.")
    except AnsibleError:
        pass


# Generated at 2022-06-23 11:10:43.367731
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    plugin_loader = PluginLoader('not_a_real_plugin', 'my_plugins')

    plugin_load_context = PluginLoadContext()
    plugin_load_context.plugin_type = 'not_a_real_plugin'
    plugin_load_context.plugin_name = 'fake_ok_plugin'
    plugin_load_context.plugin_load_errors = []
    plugin_load_context.plugin_resolved_path = os.path.abspath('test/fixtures/my_plugins/fake_ok_plugin.py')
    plugin_load_context.plugin_resolved_name = 'fake_ok_plugin'
    plugin_load_context.redirect_list = []
    plugin_load_context.mtime = time.time()

# Generated at 2022-06-23 11:10:52.764652
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    class_obj = PluginLoader
    obj = class_obj()
    def test_format_paths_1():
        try:
            obj.format_paths(None)
        except TypeError:
            pass
    def test_format_paths_2():
        try:
            obj.format_paths(str)
        except TypeError:
            pass
    def test_format_paths_3():
        try:
            obj.format_paths('str')
        except TypeError:
            pass
    def test_format_paths_4():
        try:
            obj.format_paths(1)
        except TypeError:
            pass
    def test_format_paths_5():
        try:
            obj.format_paths(1.0)
        except TypeError:
            pass
   

# Generated at 2022-06-23 11:10:59.465477
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    p = PluginLoadContext()
    p.record_deprecation('MOCK_NAME', {'warning_text': 'MOCK_TEXT', 'removal_date':'MOCK_DATE', 'removal_version':'MOCK_VERSION'})
    assert p.deprecation_warnings == ['MOCK_NAME has been deprecated. MOCK_TEXT']



# Generated at 2022-06-23 11:11:01.483781
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    from ansible.plugins.loader import PluginLoader
    l = PluginLoader("foo", "blah", "blah")
    l.print_paths("/dev/null")


# Generated at 2022-06-23 11:11:13.361156
# Unit test for function get_shell_plugin

# Generated at 2022-06-23 11:11:25.748063
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    load_context = PluginLoadContext()
    assert load_context.original_name is None
    assert len(load_context.load_attempts) == 0
    assert load_context.pending_redirect is None
    assert load_context.exit_reason is None
    assert load_context.plugin_resolved_path is None
    assert load_context.plugin_resolved_name is None
    assert load_context.plugin_resolved_collection is None
    assert load_context.deprecated is False
    assert load_context.removal_date is None
    assert load_context.removal_version is None
    assert len(load_context.deprecation_warnings) == 0
    assert load_context.resolved is False
    assert load_context.resolved_fqcn is None



# Generated at 2022-06-23 11:11:29.515934
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # create instance of class PluginLoader with arb. args
    with patch.object(PluginLoader, 'has_plugin', return_value=True):
        x = PluginLoader(None)
        assert x.__contains__() == True



# Generated at 2022-06-23 11:11:31.129382
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    # FIXME: add tests for this method!
    return


# Generated at 2022-06-23 11:11:34.892213
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    plc = PluginLoadContext()
    assert not plc.resolved
    assert not plc.redirect_list
    assert not plc.error_list
    assert not plc.import_error_list
    assert not plc.load_attempts
    assert not plc.pending_redirect
    assert not plc.exit_reason

    plc_redirected = plc.redirect('foo')
    assert not plc_redirected.resolved
    assert not plc_redirected.redirect_list
    assert not plc_redirected.error_list
    assert not plc_redirected.import_error_list
    assert not plc_redirected.load_attempts
    assert plc_redirected.pending_redirect is 'foo'
    assert plc

# Generated at 2022-06-23 11:11:43.906604
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    result=PluginLoadContext()
    result.record_deprecation('invoke_debug', {'removal_date': '2.0', 'warning_text': 'removed in Ansible 2.0'}, 'collection')
    assert result.deprecated == True
    assert result.removal_date == '2.0'
    assert result.deprecation_warnings == ['invoke_debug has been deprecated. removed in Ansible 2.0']
    assert result.removal_version == None


# Generated at 2022-06-23 11:11:51.801537
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    from ansible.utils.plugin_docs import get_docstring
    from ansible.errors import AnsibleError
    test_paths = [os.path.abspath(os.path.join(os.path.dirname(__file__),'..','..','..','test','units',
                                          'module_loader','docs_fragments')),]
    plugin_types = ['callback','lookup','filter','action','vars','terminal','strategy','connection','shell','test']
    def test_plugin_type(plugin_type):
        count = 0
        add_dirs_to_loader(plugin_type, test_paths)
        plugin_loader = getattr(sys.modules[__name__], '%s_loader' % plugin_type)

# Generated at 2022-06-23 11:12:02.739221
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    my_config = {'ANSIBLE_ACTION_PLUGINS': '~/ansible/plugins/action',
                 'ANSIBLE_LIBRARY': '~/ansible/plugins/module'}
    my_loader = PluginLoader(class_name='ActionModule', package='ansible.plugins.action', config=my_config, subdir='action_plugins')
    my_loader.find_plugin('copy')
    my_config = {'ANSIBLE_ACTION_PLUGINS': '~/ansible/plugins/action',
                 'ANSIBLE_LIBRARY': '~/ansible/plugins/module'}
    my_loader = PluginLoader(class_name='ActionModule', package='ansible.plugins.action', config=my_config, subdir='action_plugins')
    my_loader.find_plugin('copy')
    my_

# Generated at 2022-06-23 11:12:15.143255
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    for test_run in [1]:
        _name = 'action_plugin'
        _class_name = 'ActionModule'
        _package = 'ansible.plugins.action'

        plugin_loader_instance = PluginLoader(_name, _package, config=None)
        # Test signature detection
        plugin_loader_instance.get_with_context(_name)
        # Test return value
        plugin_load_context = plugin_loader_instance.get_with_context(_name)
        assert isinstance(plugin_load_context, PluginLoadContext)
        display.display(type(plugin_load_context))
        display.display(type(plugin_load_context.object))
        assert plugin_load_context.object is not None
        display.display(type(plugin_load_context.plugin_resolved_name))
        assert plugin_load

# Generated at 2022-06-23 11:12:25.831333
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    '''
    Unit test for method plugins.loader.__contains__
    '''

    # Ensure that that the method takes an unknown plugin name as argument and
    # ensure that the method returns False when it does take an unknown
    # plugin name.
    test_loader = PluginLoader('nonexistent')
    assert not (test_loader.__contains__('nonexistent'))

    # Ensure that that the method takes a known plugin name as argument and
    # ensure that the method returns True when it does take a known
    # plugin name.
    import ansible.plugins.action
    test_loader = PluginLoader('action', 'ansible.plugins.action')
    assert (test_loader.__contains__('setup'))

    # Ensure that that the method takes an empty string as argument and
    # ensure that the method raises an exception when it does

# Generated at 2022-06-23 11:12:35.730607
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    # The following call should not raise any exception
    my_loader = PluginLoader(
        'ansible.plugins.action',
        'ActionModule',
        C.DEFAULT_ACTION_PLUGIN_PATH,
    )

    # The following call should not raise any exception too
    my_loader = PluginLoader(
        'ansible.plugins.action',
        'ActionModule',
        'dummy/path',
    )

    # Create default plugin loaders
    my_loader = action_loader
    my_loader = cache_loader
    my_loader = connection_loader
    my_loader = shell_loader
    my_loader = module_loader
    my_loader = lookup_loader
    my_loader = lookup_loader
    my_loader = strategy_loader
    my_loader = test_loader

    # The following loaders should have

# Generated at 2022-06-23 11:12:40.706869
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    pluginloader = Jinja2Loader()

    from ansible.errors import AnsibleError
    try:
        pluginloader.get('it works', class_only=True)
    except AnsibleError:
        pass
    else:
        raise AssertionError('it works')



# Generated at 2022-06-23 11:12:51.846152
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    import ansible.plugins.loader
    import collections
    test_item = 'ansible.plugins.loader.Jinja2Loader'
    # instantiate object
    obj = getattr(ansible.plugins.loader, test_item)()
    # test as a generator
    # (call first to instantiate)
    test_first_item = 'ansible.plugins.filter.ipaddr'
    for i in obj.all():
        assert i.__module__ == test_first_item
        break
    # test as a list
    test_results = obj.all()
    test_first_item = 'ansible.plugins.filter.ipaddr'
    assert test_results[0].__module__ == test_first_item
    # test as a tuple
    test_results = obj.all()

# Generated at 2022-06-23 11:12:59.447399
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    c1 = PluginLoadContext()
    assert c1.original_name == None
    assert c1.redirect_list == []
    assert c1.error_list == []
    assert c1.import_error_list == []
    assert c1.load_attempts == []
    assert c1.pending_redirect == None
    assert c1.exit_reason == None
    assert c1.plugin_resolved_path == None
    assert c1.plugin_resolved_name == None
    assert c1.plugin_resolved_collection == None
    assert c1.deprecated == False
    assert c1.removal_date == None
    assert c1.removal_version == None
    assert c1.deprecation_warnings == []
    assert c1.resolved == False
    assert c1._res

# Generated at 2022-06-23 11:13:06.204533
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    import os
    import tempfile

    try:
        # Create a temp directory and enter the context manager
        with tempfile.TemporaryDirectory() as temp_dir:
            plugin_paths = (
                os.path.join("a", "b", "c"),
                os.path.join(temp_dir, "a", "b"),
                os.path.join(temp_dir, "a"),
            )
            test_instance = PluginLoader("foo.bar", "test_class", plugin_paths)
            result = test_instance.print_paths()
            assert result == plugin_paths
    except Exception as err:
        print(err)
        assert False

# Generated at 2022-06-23 11:13:13.042075
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    args = []
    kwargs = dict()
    paths = [
        'foo/bar',
        'bar/bar'
    ]
    loader = PluginLoader('foo', 'bar', 'bar', 'bar', 'bar')
    loader._searched_paths = paths
    loader.print_paths()


# Generated at 2022-06-23 11:13:16.508184
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    PL = PluginLoader('testplugin', 'plugins')
    PL.load_plugin_paths()
    assert PL.find_plugin('b') == 'b.py'

# Generated at 2022-06-23 11:13:24.881598
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    plugin_loader = PluginLoader('foo', 'bar')
    # test empty list
    assert plugin_loader.format_paths([]) == "[]"
    # test list with one entry
    assert plugin_loader.format_paths(['first']) == '[first]'
    # test list with two entries
    assert plugin_loader.format_paths(['first', 'second']) == '[first, second]'
    # test list with more than two entries
    assert plugin_loader.format_paths(['first', 'second', 'third']) == '[first, second, third]'
    # test list with more than two entries and with specific rounding
    assert plugin_loader.format_paths(['first', 'second', 'third', 'fourth'], 3) == '[first, second, third, ...]'

# Generated at 2022-06-23 11:13:31.846022
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    plugin_load_context = PluginLoadContext()
    plugin_load_context.resolve('test_name', 'test_path', 'test_collection', 'reason_1')
    assert plugin_load_context.resolved == True
    assert plugin_load_context.plugin_resolved_name == 'test_name'
    assert plugin_load_context.plugin_resolved_path == 'test_path'
    assert plugin_load_context.plugin_resolved_collection == 'test_collection'
    assert plugin_load_context.exit_reason == 'reason_1'


# Generated at 2022-06-23 11:13:33.255338
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
  # The test below always passes.
  assert 1 == 1

# Generated at 2022-06-23 11:13:37.681861
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    ''' Test for Jinja2Loader.all method '''

    with patch("os.path.isdir", return_value=True), \
        patch("os.path.exists", side_effect=[True, False]), \
        patch("os.path.isfile", return_value=True), \
        patch("os.path.join", return_value='/path/to/plugin/test.py'), \
        patch("os.listdir", side_effect=[["test.py"], []]):
        plugin = Jinja2Loader.all(list_dirs=True)

        assert ['test.py'] == plugin



# Generated at 2022-06-23 11:13:46.547845
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 2

    test_loader = PluginLoader('test')

    # Test if the method raises a TypeError if the required parameter 'name' is missing
    try:
        test_loader.get()
    except TypeError:
        pass
    else:
        fail("Expected to fail without parameter 'name'")

    # Test if the method returns None if no plugin with the given name is found
    result = test_loader.get('nonexistent')
    assert result is None

    # Test if a plugin is found if a name is given
    result = test_loader.get('test')
    assert result is not None



# Generated at 2022-06-23 11:13:54.345308
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    '''
    Unit test for method add_directory of class PluginLoader
    '''
    loader = PluginLoader('test', 'tests.unit.data.plugins.loader', C.DEFAULT_INVENTORY_PLUGINS_PATH)

    loader.add_directory(C.DEFAULT_INVENTORY_PLUGINS_PATH)

    assert C.DEFAULT_INVENTORY_PLUGINS_PATH in sys.path


# Generated at 2022-06-23 11:13:56.654426
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():  # type: () -> None
    from ansible.collection.collection_loader import get_all_plugin_loaders
    for _, loader in get_all_plugin_loaders():
        loader.add_directory('/dev/null')



# Generated at 2022-06-23 11:13:59.775510
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    p = PluginLoadContext()
    p.nope('possible reason')
    assert p.exit_reason == 'possible reason'
    assert p.resolved == False
    assert p.original_name == None



# Generated at 2022-06-23 11:14:12.292176
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    is_directory = lambda path: mock_isdir.get(path, False)
    mock_isdir = {
        '/': True,
        '/etc': True,
        '/etc/ansible': True,
        '/etc/ansible/roles': True,
        '/etc/ansible/modules': True,
        '/etc/ansible/plugins': True,
    }
    os_path = {'isdir': is_directory}
    os_path_j = {'join': mock_join, 'expanduser': mock_expanduser}
    os = {'path': os_path_j}
    add_all_plugin_dirs(os, os_path)
    assert 1 == len(get_all_plugin_loaders(PluginLoader))



# Generated at 2022-06-23 11:14:24.936488
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():

# test with real data
    plugin_resolved_path = '/home/ec2-user/.ansible/collections/ansible_collections/datadog/integrations/plugins/modules/datadog_api.py'
    plugin_resolved_name = 'datadog.integrations.datadog_api'
    # expected output: PluginLoadContext(resolved=True, plugin_resolved_path='/home/ec2-user/.ansible/collections/ansible_collections/datadog/integrations/plugins/modules/datadog_api.py', plugin_resolved_name='datadog.integrations.datadog_api', collection_resolved_name='datadog.integrations', redirect_list=[])

# Generated at 2022-06-23 11:14:35.991093
# Unit test for method format_paths of class PluginLoader

# Generated at 2022-06-23 11:14:47.794160
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    paths = ["/home/ansible/myplugins/1/action", "/home/ansible/myplugins/2/action", "/home/ansible/myplugins/3/action"]
    paths_to_search = ["/home/ansible/myplugins/1/action", "/home/ansible/myplugins/1/action/my_plugins", "/home/ansible/myplugins/2/action", "/home/ansible/myplugins/2/action/my_plugins", "/home/ansible/myplugins/3/action", "/home/ansible/myplugins/3/action/my_plugins"]
    action_loader.plugin_paths = []
    add_dirs_to_loader("action", paths)
    assert action_loader.plugin_paths == paths_to_search



# Generated at 2022-06-23 11:15:00.348823
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    import inspect
    import collections
    test_plugin_loaders = []
    for (name, obj) in globals().items():
        if (isinstance(obj, type) and
                issubclass(obj, PluginLoader) and
                obj.__module__ == __name__ and
                obj != PluginLoader):
            test_plugin_loaders.append(name)
    # If a new plugin loader type is added, update the unit test to test for it

# Generated at 2022-06-23 11:15:03.862098
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    module = imp.new_module('test_get_shell_plugin')
    module.shell_loader = PluginLoader('ShellModule', 'ansible.plugins.shell', C.DEFAULT_SHELL_PLUGIN_PATH, config_base='shell_plugins')
    # default to sh
    assert 'sh' == get_shell_plugin()(module).DEFAULT_EXECUTABLE.split('/')[-1]


# Generated at 2022-06-23 11:15:16.330767
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    print('Testing PluginLoader find_plugin_with_context')
    loader = PluginLoader('lookup_plugin')
    plugin_load_context = loader.find_plugin_with_context(name='test_plugins.no_plugin')
    print('Plugin load context is %s' % plugin_load_context)
    assert plugin_load_context.resolved == False
    assert plugin_load_context.reason == 'Plugin not found'
    plugin_load_context = loader.find_plugin_with_context(name='.')
    print('Plugin load context is %s' % plugin_load_context)
    assert plugin_load_context.resolved == False
    assert plugin_load_context.reason == 'Plugin name cannot be empty'
    plugin_load_context = loader.find_plugin_with_context(name='-.1_orig')
   

# Generated at 2022-06-23 11:15:22.087408
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    pl = PluginLoader(
        package='ansible.plugins.action',
        config=dict(DEFAULT_ACTION_PLUGIN_PATH=[
            'lib/ansible/plugins/action',
            'docsite/source/plugins/action',
        ]),
    )
    # TODO: write test


# Generated at 2022-06-23 11:15:31.335402
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    context = PluginLoadContext()
    assert context.original_name == None
    assert context.exit_reason == None
    assert context.plugin_resolved_path == None
    assert context.plugin_resolved_name == None
    assert context.plugin_resolved_collection == None
    assert context.deprecated == False
    assert context.removal_date == None
    assert context.removal_version == None
    assert context.deprecation_warnings == []
    assert context.resolved == False
    assert context.pending_redirect == None
    assert context._resolved_fqcn == None

    context.redirect('name')
    assert context.original_name == None
    assert context.exit_reason == 'pending redirect resolution from None to name'
    assert context.plugin_resolved_path == None
    assert context

# Generated at 2022-06-23 11:15:37.479178
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    result = get_with_context_result(action_loader, 'ping', 'ping')

    assert result.plugin == 'ping'
    assert result.plugin_type == 'action'
    assert result.plugin_loader == action_loader
    assert result.plugin_ref == 'ping'

    result = get_with_context_result(action_loader, 'ping', 'ansible.builtin.ping')

    assert result.plugin == 'ping'
    assert result.plugin_type == 'action'
    assert result.plugin_loader == action_loader
    assert result.plugin_ref == 'ansible.builtin.ping'

    result = get_with_context_result(action_loader, 'ansible.builtin.ping', 'ansible.builtin.ping')

    assert result.plugin == 'ping'
    assert result.plugin_type

# Generated at 2022-06-23 11:15:41.905274
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    p = PluginPathContext('/tmp/plugin', False)
    assert(p.path == '/tmp/plugin')
    assert(p.internal is False)
    p = PluginPathContext('/tmp/plugin', True)
    assert(p.internal)



# Generated at 2022-06-23 11:15:50.260370
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    result = PluginLoader.get_with_context_result(True)
    assert result == (True, None)

    result = PluginLoader.get_with_context_result(True, 'the context')
    assert result == (True, 'the context')

    result = PluginLoader.get_with_context_result(False, 'the context')
    assert result == (False, 'the context')

    result = PluginLoader.get_with_context_result(False)
    assert result == (False, None)



# Generated at 2022-06-23 11:15:55.426110
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    class_name = 'test_loader'
    class_obj = type(class_name, (object,), {})
    globals()[class_name] = class_obj
    sys.modules[__name__].test_loader = class_obj
    paths = ['/path1']
    add_dirs_to_loader(which_loader='test', paths=paths)
    assert getattr(sys.modules[__name__], 'test_loader')._get_paths() == paths



# Generated at 2022-06-23 11:16:08.635295
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    # NOTE: This test only covers the special logic included in Jinja2Loader.all()
    # Not the logic from the base loader class.
    from ansible.plugins.loader import filter_loader, test_loader

    test_file1 = 'ansible_test_file1.py'
    test_file2 = 'ansible_test_file2.py'
    test_file3 = 'ansible_test_file3.py'
    test_file4 = 'ansible_test_file4.py'
    test_plugin1 = 'TestFilter1'
    test_plugin2 = 'TestFilter2'
    test_plugin3 = 'TestFilter3'
    test_plugin4 = 'TestFilter4'
    test_plugin5 = 'TestFilter5'

    test_filter_plugins_dir1 = tempfile.mkdtemp()

# Generated at 2022-06-23 11:16:14.132679
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    pc = PluginLoadContext()
    assert (pc.redirect('test') == pc)
    assert (pc.redirect_list == [])
    assert (pc.pending_redirect is 'test')
    assert (pc.exit_reason == 'pending redirect resolution from None to test')
    assert (pc.resolved is False)


# Generated at 2022-06-23 11:16:15.070221
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    pass


# Generated at 2022-06-23 11:16:21.627143
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    from ansible.plugins.__init__ import get_all_plugin_loaders

    pl = get_all_plugin_loaders()[0]

    with mock.patch.object(PluginLoader, '__reduce_ex__', mock_reduce_ex):
        assert pl.__setstate__([1, 2, 3]) == None


# Generated at 2022-06-23 11:16:28.405583
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    class FakeContext(object):
        pass

    with pytest.raises(AnsibleError):
        _ = get_with_context_result('ansible.plugins.action', FakeContext())

    with pytest.raises(AnsibleError):
        _ = get_with_context_result('ansible.plugins', FakeContext())

    with pytest.raises(AnsibleError):
        _ = get_with_context_result('ansible.plugins.invalid_plugin_type', FakeContext())

    with pytest.raises(AnsibleError):
        _ = get_with_context_result('ansible.plugins.action_test', FakeContext())

# Generated at 2022-06-23 11:16:33.053914
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    loader = PluginLoader('whatever', 'whatever_class', 'whatever_base_class', 'whatever_package')
    loader._searched_paths = ['/path/1', '/path/2', '/path/3']
    assert loader.print_paths() == '/path/1, /path/2, /path/3'



# Generated at 2022-06-23 11:16:46.196663
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    name = 'name'
    collection_list = 'collection_list'

    #Test when in aliases
    PL = PluginLoader('package', '_prefix', '_class_name', 'path_list', 'aliases')
    PL.aliases = dict(name='name')
    PL.has_plugin = Mock(return_value=None)
    PL.__contains__('name', collection_list)
    PL.has_plugin.assert_called_once_with('name', collection_list)

    PL.aliases = dict()
    PL.has_plugin = Mock(return_value=True)
    assert PL.__contains__('name', collection_list) == True

    #Test when not in aliases
    PL.aliases = dict(name='name')
    PL.has_plugin = Mock(return_value=None)


# Generated at 2022-06-23 11:16:55.814860
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    print('Testing method __contains__ of class PluginLoader')
    # Setup
    loader = PluginLoader('test_package', 'test_subdir', 'test_class_name',
                                            'test_basedir', 'test_module_path')
    arg_name_value = ansible.module_utils.basic._ANSIBLE_ARGS
    arg_name_value_1 = ansible.module_utils.basic._ANSIBLE_ARGS
    arg_name_value_1.append('test')
    # Test
    result = loader.__contains__('test_name')
    # Verify
    assert isinstance(result, bool)
    assert result
    # Test
    result = loader.__contains__('test_name', arg_name_value)
    # Verify
    assert isinstance(result, bool)
    assert result

# Generated at 2022-06-23 11:17:01.629580
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Path to the test plugins
    TEST_CACHE_PLUGIN_PATH = os.path.join(os.path.dirname(__file__), 'test_plugins', 'cache')
    # the following folder doesn't exist and should therefore be ignored
    TEST_INVALID_CACHE_PLUGIN_PATH = os.path.join(TEST_CACHE_PLUGIN_PATH, '__init__.py')
    # The test class is called 'MemoryCache' and is located in the test folder.
    # It will be used to test the search for ansible_collections.collection_name.plugins.cache.MemoryCache
    TEST_COLLECTION_NAME = 'test_collection'
    TEST_CACHE_CLASS_NAME = 'MemoryCache'
    # Create a new PluginLoader and load the test plugin
    loader

# Generated at 2022-06-23 11:17:04.167950
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    loader = PluginLoader('dummy_module')
    loader.__getstate__()


# Generated at 2022-06-23 11:17:07.668467
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.plugins import action_loader
    # Test that a plugin loader can find all of the action plugins.
    action_plugin_loader = action_loader._create_plugin_loader()
    plugins = list(action_plugin_loader.all())
    assert len(plugins) > 0
    for p in plugins:
        assert not isinstance(p, type)
        assert hasattr(p, 'run')
        assert callable(p.run)


# Generated at 2022-06-23 11:17:08.900974
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    plugin_loader = PluginLoader('test_plugins', 'Test_module')
    assert plugin_loader



# Generated at 2022-06-23 11:17:11.416508
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    context = PluginPathContext(path='./test_path', internal=True)
    assert context.path == './test_path'
    assert context.internal is True


# Generated at 2022-06-23 11:17:19.718435
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
  # Setup
  package = 'package'
  path = ['path']
  class_name = 'class_name'
  base_class = 'base_class'
  all_plugins = {'key': 'value'}
  plugin_cache = {'key': 'value'}
  plugin_loading_priorities = {'key': 'value'}
  aliases = {'key': 'value'}
  loader = PluginLoader(package, path, class_name, base_class, all_plugins, plugin_cache, plugin_loading_priorities, aliases)
  # Operation
  r = loader.__repr__()
  # Verification/Assertion
  assert r == "<ansible.utils.plugin_docs.PluginLoader package=package, class_name=class_name>"



# Generated at 2022-06-23 11:17:29.147378
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    class PluginLoadContext():
        def __init__(self):
            self.original_name = None
            self.redirect_list = []
            self.error_list = []
            self.import_error_list = []
            self.load_attempts = []
            self.pending_redirect = None
            self.exit_reason = None
            self.plugin_resolved_path = None
            self.plugin_resolved_name = None
            self.plugin_resolved_collection = None  # empty string for resolved plugins from user-supplied paths
            self.deprecated = False
            self.removal_date = None
            self.removal_version = None
            self.deprecation_warnings = []
            self.resolved = False
            self._resolved_fqcn = None


# Generated at 2022-06-23 11:17:39.452015
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plc=PluginLoadContext()
    assert getattr(plc, 'original_name', None) is None
    assert getattr(plc, 'redirect_list', None) == []
    assert getattr(plc, 'error_list', None) == []
    assert getattr(plc, 'import_error_list', None) == []
    assert getattr(plc, 'load_attempts', None) == []
    assert getattr(plc, 'pending_redirect', None) is None
    assert getattr(plc, 'exit_reason', None) is None
    assert getattr(plc, 'plugin_resolved_path', None) is None
    assert getattr(plc, 'plugin_resolved_name', None) is None