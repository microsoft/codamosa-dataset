

# Generated at 2022-06-23 11:07:43.259790
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
  '''unit test for method __setstate__'''
  pass

# Generated at 2022-06-23 11:07:45.431397
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # assert PluginLoader.__contains__ == has_plugin
    assert True



# Generated at 2022-06-23 11:07:54.858744
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    resolved_name = "testResolved"
    resolved_path = "testPath"
    resolved_collection = "testCollection"
    exit_reason = "testReason"
    plc = PluginLoadContext()
    assert plc.resolve(resolved_name, resolved_path, resolved_collection, exit_reason) == plc
    assert plc.pending_redirect == None
    assert plc.plugin_resolved_name == resolved_name
    assert plc.plugin_resolved_path == resolved_path
    assert plc.plugin_resolved_collection == resolved_collection
    assert plc.exit_reason == exit_reason
    assert plc.resolved == True


# Generated at 2022-06-23 11:07:59.707896
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    pluginloader = PluginLoader('test')
    pluginloader.__setstate__({'class_name': 'test', 'package': 'test', 'base_class': 'test', 'paths': 'test', 'aliases': 'test', '_searched_paths': 'test', '_debug': 'test', '_module_cache': 'test', '_display': 'test'})


# Generated at 2022-06-23 11:08:04.256811
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    state = dict(package='test', aliases={'old': 'new'})
    pl = PluginLoader()
    assert pl.package != 'test'
    assert 'old' not in pl.aliases
    pl.__setstate__(state)
    assert pl.package == 'test'
    assert 'old' in pl.aliases


# Generated at 2022-06-23 11:08:06.034909
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():

    # TODO: create a test
    pass


# Generated at 2022-06-23 11:08:10.726182
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    plc = PluginLoadContext()
    r = plc.nope(exit_reason="Test")
    assert r.plugin_resolved_name == None
    assert r.plugin_resolved_path == None
    assert r.plugin_resolved_collection == None
    assert r.pending_redirect == None
    assert r.exit_reason == "Test"
    assert r.resolved == False

# Generated at 2022-06-23 11:08:16.595971
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    '''
    Unit test for method all of class PluginLoader
    '''
    loader = PluginLoader('LookupModule', 'ansible.plugins.lookup')
    result = loader.all('args', _dedupe=False)
    assert isinstance(result, types.GeneratorType)
    assert list(result)  # there should be some plugins to return


# Generated at 2022-06-23 11:08:20.645077
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    assert PluginLoadContext().resolve('test_resolved_name', 'test_resolved_path', 'test_resolved_collection', 'test_exit_reason').plugin_resolved_name == 'test_resolved_name'
    assert PluginLoadContext().resolve('test_resolved_name', 'test_resolved_path', 'test_resolved_collection', 'test_exit_reason').plugin_resolved_path == 'test_resolved_path'
    assert PluginLoadContext().resolve('test_resolved_name', 'test_resolved_path', 'test_resolved_collection', 'test_exit_reason').plugin_resolved_collection == 'test_resolved_collection'

# Generated at 2022-06-23 11:08:26.737535
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    # test a valid plugin loader
    loader = PluginLoader('filter_loader', 'FilterModule', 'ansible.plugins.filter_plugins', C.DEFAULT_FILTER_PLUGIN_PATH)
    assert loader.package == 'ansible.plugins.filter_plugins'
    assert loader.class_name == 'FilterModule'
    assert loader.paths == C.DEFAULT_FILTER_PLUGIN_PATH
    assert loader.paths == loader._get_paths()
    assert loader._searched_paths == loader._get_searched_paths()
    assert loader.base_class == 'FilterModule'
    assert not loader.aliases

    # test the default plugin loader
    loader = PluginLoader('default_loader', '', '', '')
    assert not loader.package
    assert not loader.class_name
   

# Generated at 2022-06-23 11:08:36.873623
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    from ansible.module_utils.six.moves import StringIO
    from ansible.plugins import action

    my_stdout = StringIO()

    # Using None and [] for suffix, None for subdir and True for class_only and False for path_only
    # get method returns None
    # When we want a class, we should not set path_only to True
    pl = PluginLoader(package='ActionModule', suffix=None, subdir=None, class_only=True, path_only=False)

    pl.get('test', my_stdout=my_stdout)

    # Using None and [] for suffix, "action" for subdir and True for class_only and False for path_only
    # get method returns None
    # When we want a class, we should not set path_only to True

# Generated at 2022-06-23 11:08:49.789664
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    p = PluginLoadContext()
    assert p.original_name is None
    assert p.redirect_list == []
    assert p.error_list == []
    assert p.import_error_list == []
    assert p.load_attempts == []
    assert p.pending_redirect is None
    assert p.exit_reason is None
    assert p.plugin_resolved_path is None
    assert p.plugin_resolved_name is None
    assert p.plugin_resolved_collection is None
    assert p.deprecated is False
    assert p.removal_date is None
    assert p.removal_version is None
    assert p.deprecation_warnings == []
    assert p.resolved is False
    assert p._resolved_fqcn is None


# Generated at 2022-06-23 11:08:54.413985
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    c = PluginLoadContext()
    c.resolve('r1','r2','r3', 'r4')
    assert c.plugin_resolved_name == 'r1'
    assert c.plugin_resolved_path == 'r2'
    assert c.plugin_resolved_collection == 'r3'
    assert c.exit_reason == 'r4'
    assert c.resolved == True


# Generated at 2022-06-23 11:08:57.669114
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    name = "ansible.builtin.debug"
    deprecation = {'warning_text': 'hello'}
    plc = PluginLoadContext()
    plc.record_deprecation(name, deprecation, None)
    assert plc.deprecated
    assert plc.deprecation_warnings == ['ansible.builtin.debug has been deprecated. hello']



# Generated at 2022-06-23 11:09:07.889872
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    plugin_loader = PluginLoader('filter_loader', 'filter_plugins', C.DEFAULT_FILTER_PLUGIN_PATH, 'FilterModule')
    assert plugin_loader.format_paths([
        '/path/to/my/filter_plugins',
        '/path/to/my/other_filter_plugins',
        '/path/to/my/test_filter_plugins'
    ]) == "'/path/to/my/filter_plugins', '/path/to/my/other_filter_plugins'"

    plugin_loader = PluginLoader('test_loader', 'test_plugins', C.DEFAULT_TEST_PLUGIN_PATH, 'TestModule')

# Generated at 2022-06-23 11:09:12.208556
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    plc = PluginLoadContext()
    plc.nope('test')
    assert(plc.pending_redirect is None)
    assert(plc.exit_reason == 'test')


# Generated at 2022-06-23 11:09:17.440361
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    loader = PluginLoader('ansible.plugins.filter', 'FilterModule')
    files = list(loader.all())
    files .reverse()

    assert len(files) == 5
    assert files[0].__name__ == 'ansible_filter_pathsep'
    assert files[1].__name__ == 'ansible_filter_length_of_unfiltered_items'
    assert files[2].__name__ == 'ansible_filter_indent'
    assert files[3].__name__ == 'ansible_filter_subelements'
    assert files[4].__name__ == 'extract_duplicates'



# Generated at 2022-06-23 11:09:21.913077
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    c = PluginLoadContext()
    c.resolve("a", "b", "c", "d")
    assert c.pending_redirect == None
    assert c.plugin_resolved_name == "a"
    assert c.plugin_resolved_path == "b"
    assert c.plugin_resolved_collection == "c"
    assert c.exit_reason == "d"
    assert c.resolved == True


# Generated at 2022-06-23 11:09:24.686378
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    args = dict()
    v = PluginLoader(**args)
    assert v.__getstate__() == args

# Generated at 2022-06-23 11:09:36.210197
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plc = PluginLoadContext()
    assert plc.original_name == None
    assert plc.redirect_list == []
    assert plc.error_list == []
    assert plc.import_error_list == []
    assert plc.load_attempts == []
    assert plc.pending_redirect == None
    assert plc.exit_reason == None
    assert plc.plugin_resolved_path == None
    assert plc.plugin_resolved_name == None
    assert plc.plugin_resolved_collection == None
    assert plc.deprecated == False
    assert plc.removal_date == None
    assert plc.removal_version == None
    assert plc.deprecation_warnings == []
    assert plc.resolved == False
    assert plc._res

# Generated at 2022-06-23 11:09:46.985746
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plc = PluginLoadContext()
    assert not plc.redirect_list
    assert not plc.error_list
    assert not plc.import_error_list
    assert not plc.load_attempts
    assert not plc.pending_redirect
    assert not plc.exit_reason
    assert not plc.plugin_resolved_path
    assert not plc.plugin_resolved_name
    assert not plc.plugin_resolved_collection
    assert not plc.deprecated
    assert not plc.removal_date
    assert not plc.removal_version
    assert not plc.deprecation_warnings
    assert not plc.resolved
    assert not plc._resolved_fqcn


# Generated at 2022-06-23 11:09:47.931769
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
  pass


# Generated at 2022-06-23 11:09:54.033490
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    obj1 = PluginLoadContext()
    assert not obj1.resolved
    assert obj1.exit_reason == None
    assert obj1.original_name == None
    assert obj1.redirect_list == []
    assert obj1.error_list == []
    assert obj1.deprecated == False
    assert obj1.removal_date == None
    assert obj1.removal_version == None
    assert obj1.deprecation_warnings == []



# Generated at 2022-06-23 11:09:56.940194
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    plug = PluginLoader('ansible.plugins.action')
    result = [plug.all(class_only=True)]
    assert result == []


# Generated at 2022-06-23 11:09:57.993658
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    _test_PluginLoader___setstate__()



# Generated at 2022-06-23 11:10:01.179819
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    assert_raises(AnsibleError, PluginLoader('nonexistent', '', '', 'basename').find_plugin, 'test.py')


# Generated at 2022-06-23 11:10:11.724426
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    lc = PluginLoadContext()
    lc.record_deprecation('foo', {'warning': 'bar'}, 'collection')
    assert lc.deprecated
    assert lc.deprecation_warnings == ['foo has been deprecated. bar']
    lc.record_deprecation('bar', {'warning_text': '42', 'removal_date': '2050-01-01', 'removal_version': 1000000}, 'collection')
    assert lc.deprecated
    assert lc.removal_date == '2050-01-01'
    assert lc.removal_version is None
    assert lc.deprecation_warnings == ['foo has been deprecated. bar', 'bar has been deprecated. 42']



# Generated at 2022-06-23 11:10:22.227536
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plc = PluginLoadContext()
    assert plc.original_name == None
    assert plc.redirect_list == []
    assert plc.error_list == []
    assert plc.import_error_list == []
    assert plc.load_attempts == []
    assert plc.pending_redirect == None
    assert plc.exit_reason == None
    assert plc.plugin_resolved_path == None
    assert plc.plugin_resolved_name == None
    assert plc.plugin_resolved_collection == None
    assert plc.deprecated == False
    assert plc.removal_date == None
    assert plc.removal_version == None
    assert plc.deprecation_warnings == []
    assert plc.resolved == False
    assert plc.res

# Generated at 2022-06-23 11:10:29.077055
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plugloadcontext = PluginLoadContext()
    assert plugloadcontext.original_name is None
    assert isinstance(plugloadcontext.redirect_list, list)
    assert not plugloadcontext.redirect_list
    assert isinstance(plugloadcontext.error_list, list)
    assert not plugloadcontext.error_list
    assert isinstance(plugloadcontext.import_error_list, list)
    assert not plugloadcontext.import_error_list
    assert isinstance(plugloadcontext.load_attempts, list)
    assert not plugloadcontext.load_attempts
    assert plugloadcontext.pending_redirect is None
    assert plugloadcontext.exit_reason == 'Not yet resolved'
    assert plugloadcontext.plugin_resolved_path is None
    assert plugloadcontext.plugin_resolved_name is None

# Generated at 2022-06-23 11:10:34.844207
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    fixture = [
        {
            'args': {'name': 'template', 'collection_list': None},
            'result': None,
        },
    ]

    jinjaloader = Jinja2Loader()
    for item in fixture:
        assert jinjaloader.find_plugin(**item['args']) == item['result']


# Generated at 2022-06-23 11:10:45.993457
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    """Test if PluginLoader.get method return expected result"""
    def return_searched_paths(name):
        return [
            '/home/jose/.ansible/plugins/module_utils',
            '/usr/share/ansible/plugins/module_utils',
            '/var/lib/awx/venv/awx/lib/python3.6/site-packages/ansible/plugins/module_utils'
        ]

    # The find_plugin method should return the path
    # where MyModule is located.
    my_module_path = '/var/lib/awx/venv/awx/lib/python3.6/site-packages/ansible/plugins/module_utils/my_module.py'
    def find_plugin(name, *args, **kwargs):
        return my_module_path

    #

# Generated at 2022-06-23 11:10:54.167409
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    def test_instance():
        example = PluginLoader('example')
        assert repr(example) == "PluginLoader(package='example', class_name='example', base_class=None, require_package=True)"
    def test_class_only():
        example = PluginLoader('example', class_only=True)
        assert repr(example) == "PluginLoader(package='example', class_name='example', base_class=None, require_package=True, class_only=True)"
    def test_required_base_class():
        example = PluginLoader('example', base_class='ExampleBaseClass')
        assert repr(example) == "PluginLoader(package='example', class_name='example', base_class='ExampleBaseClass', require_package=True)"

# Generated at 2022-06-23 11:10:58.034562
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    pl = PluginLoader('my_plugin_type', 'my_dir', 'my_package.my_class')
    assert pl.has_plugin('my_plugin') == True



# Generated at 2022-06-23 11:11:10.298662
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    # Return a minimum valid `ansible_collections.ns.plugins.module_utils.ns1.some_module.some_class` object
    def mock_load_module(class_name, module_name=None, path=None):
        return type(
            '{0}.{1}'.format(module_name, class_name),
            (object,),
            {'__loader__': {'name': module_name, 'path': path}, '__name__': '{0}.{1}'.format(module_name, class_name)}
        )

    class_name = 'some_class'
    module_name = 'ns1.some_module'

    plugin_load_context = PluginLoadContext()
    exit_reason = 'nope'
    plugin_load_context.nope(exit_reason)

    #

# Generated at 2022-06-23 11:11:13.928097
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    path = 'path'
    internal = False
    plugin_path_context = PluginPathContext(path, internal)
    assert plugin_path_context.path == path
    assert plugin_path_context.internal == internal



# Generated at 2022-06-23 11:11:22.035204
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    loaders = get_all_plugin_loaders()
    assert isinstance(loaders, list)
    assert len(loaders) > 0

    # Assert that each object is a PluginLoader, and that they have a search_paths method
    for name, loader in loaders:
        assert isinstance(loader, PluginLoader)
        assert hasattr(loader, 'search_paths')
        assert hasattr(loader.search_paths, '__call__')



# Generated at 2022-06-23 11:11:27.131157
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    '''
    Unit test for method get_with_context of class PluginLoader
    '''
    name = 'PluginLoader'
    class_name = '_PluginLoader__sort_names'
    package = 'ansible.plugins.loader'
    base_class = 'PluginLoader'
    config_def = 'plugin_defs'
    loader = PluginLoader(name, class_name, package, base_class, config_def)
    # Test with invalid name
    name = 'test_name'
    try:
        loader.get_with_context(name)
    except AnsibleError as err:
        assert 'could not locate any %s' % name in to_text(err)


# Generated at 2022-06-23 11:11:33.205954
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    #setup
    my_plugin_dir = './test/unit/plugins/test_plugin_dir'
    TOOLS_PLUGIN_PATH='./test/unit/plugins'
    C.DEFAULT_MODULE_PATH=TOOLS_PLUGIN_PATH
    #test
    add_all_plugin_dirs(my_plugin_dir)
    #assert
    assert any(x.startswith(my_plugin_dir) for x in sys.path)


# Generated at 2022-06-23 11:11:39.009898
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # Testing find_plugin_with_context by calling it with get_with_context
    import os
    import sys
    import shutil

    sys.path.append("..")
    from lib.loader import PluginLoader
    from lib.config import Config
    from lib.ansible_util import AnsibleError

    from lib.collections import CollectionLoader
    from lib.collections import list_collections

    def cleanup(path):
        for i in os.listdir(path):
            shutil.rmtree(os.path.join(path, i))

    def init_collection_loader(parent_dir, subdir, plugin_type):
        collection_loader = CollectionLoader()
        collection_loader.load(parent_dir)

# Generated at 2022-06-23 11:11:49.444141
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plugin_load_context = PluginLoadContext()
    assert plugin_load_context.original_name is None
    assert plugin_load_context.redirect_list == []
    assert plugin_load_context.error_list == []
    assert plugin_load_context.import_error_list == []
    assert plugin_load_context.load_attempts == []
    assert plugin_load_context.pending_redirect is None
    assert plugin_load_context.exit_reason is None
    assert plugin_load_context.plugin_resolved_path is None
    assert plugin_load_context.plugin_resolved_name is None
    assert plugin_load_context.plugin_resolved_collection is None
    assert not plugin_load_context.deprecated
    assert plugin_load_context.removal_date is None
    assert plugin_

# Generated at 2022-06-23 11:11:53.002973
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    pl = PluginLoader('foo')
    paths = ['a', 'b']
    result = pl.format_paths(paths)
    assert result == 'a, b'



# Generated at 2022-06-23 11:11:58.386930
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    # Test setup
    PL = PluginLoader('ansible.plugins.action_plugins', 'ActionModule', 'action')
    assert PL.__repr__() == "PluginLoader: 'ActionModule' plugins from '/home/user/projects/ansible/lib/ansible/plugins/action_plugins'"
test_PluginLoader___repr__()



# Generated at 2022-06-23 11:12:01.769851
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    # Test construction with no args
    plugin_loader = PluginLoader('')
    assert plugin_loader

    # Test construction with args
    plugin_loader = PluginLoader('', '', '', '', [])
    assert plugin_loader



# Generated at 2022-06-23 11:12:13.892167
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    loader = PluginLoader('ansible.plugins.test.foo', 'FooBase', 'ansible.plugins.test')
    assert loader.package == 'ansible.plugins.test'
    assert loader.subdir == 'foo'
    assert loader.paths == [os.path.join(os.path.dirname(__file__), 'plugins', 'test', 'foo')]
    assert loader.aliases == {}

    loader2 = PluginLoader.load_subdir_from_directory('tests/unit/plugins/test/foo', 'FooBase', 'ansible.plugins.test')
    assert loader2.subdir == 'foo'
    assert loader2.paths == [os.path.join(os.path.dirname(__file__), 'plugins', 'test', 'foo')]
    assert loader.aliases == {}



# Generated at 2022-06-23 11:12:18.711829
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    plc = PluginLoadContext()
    assert isinstance(plc, PluginLoadContext)
    assert plc.redirect('foo') == plc
    assert plc.pending_redirect == 'foo'
    assert plc.exit_reason == 'pending redirect resolution from None to foo'
    assert not plc.resolved



# Generated at 2022-06-23 11:12:21.181040
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    # Test for print_paths()
    plugin = PluginLoader('')
    assert len(plugin.plugin_paths) > 0
    assert plugin.print_paths() == None


# Generated at 2022-06-23 11:12:27.929076
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    args = dict(
        name=dict(type='str', required=True),
        package=dict(type='str', required=True),
        path=dict(type='list'),
    )
    p = PluginLoader( 'name', 'package', path=['path'] )
    assert repr(p) == "PluginLoader(name='name', package='package', paths=['path'])"



# Generated at 2022-06-23 11:12:30.200154
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # TODO: unit test for method find_plugin of class Jinja2Loader
    pass


# Generated at 2022-06-23 11:12:34.827598
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    redirect_name = "name"
    exit_reason = "reason"

    obj = PluginLoadContext();
    obj.redirect(redirect_name);
    obj_result = obj.nope(exit_reason);

    assert not obj.pending_redirect
    assert obj.exit_reason == exit_reason
    assert not obj.resolved
    assert obj_result


# Generated at 2022-06-23 11:12:41.609587
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    """
    Test add_dirs_to_loader
    """
    # Add a module_dir containing an invalid module (blah.py)
    # and a valid module (priority.py).
    module_dir = os.path.join(os.path.dirname(__file__), '..', 'test', 'sanity', 'validate-modules', 'validate-modules')
    add_dirs_to_loader('module', [module_dir])

    # make sure the loader is loading module_dir, and we can import the valid module
    assert module_dir in MODULE_CACHE[module_dir]
    assert MODULE_CACHE[module_dir].get('priority.py')
    assert MODULE_CACHE[module_dir].get('__init__.py')

    # make sure the invalid module is not there
   

# Generated at 2022-06-23 11:12:46.393563
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    path1 = PluginPathContext('/path1', False)
    assert path1.path == '/path1'
    assert path1.internal is False

    path2 = PluginPathContext('/path2', True)
    assert path2.path == '/path2'
    assert path2.internal is True



# Generated at 2022-06-23 11:12:53.321653
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    """Tests whether the function get_all_plugin_loaders returns all defined plugin loaders"""

    def my_plugin_loader():
        """An example plugin loader
        """

    TestPlugin = get_plugin_class('test')
    p = TestPlugin()
    p.__class__.my_plugin_loader = my_plugin_loader
    plugin_loaders = get_all_plugin_loaders()
    assert plugin_loaders == [(name, obj) for (name, obj) in globals().items() if isinstance(obj, PluginLoader)]


# Generated at 2022-06-23 11:13:03.879305
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    # Test that PluginLoader subclasses are returned
    def test_class(pc):
        return isinstance(pc, type) and issubclass(pc, PluginLoader)

    assert test_class(ActionModuleLoader)
    assert test_class(CacheModuleLoader)
    assert test_class(CallbackModuleLoader)
    assert test_class(ConnectionModuleLoader)
    assert test_class(FilterModuleLoader)
    assert test_class(LookupModuleLoader)
    assert test_class(LibraryFinder)
    assert test_class(ModuleUtilsLoader)
    assert test_class(TestModuleLoader)
    assert test_class(VarsPluginLoader)

# TODO: remove this const after removing ansible.constants.DEFAULT_HASH_BEHAVIOUR
DEFAULT_HASH_BEHAVIOUR = 'replace'



# Generated at 2022-06-23 11:13:15.430771
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    p = PluginLoader('', '', '', '', '')
    assert p.format_paths(
        '/path/to/plugins') == "['/path/to/plugins']"
    assert p.format_paths(
        ['/path/to/plugins1', '/path/to/plugins2']) == "['/path/to/plugins1', '/path/to/plugins2']"
    assert p.format_paths(
        '/path/to/plugins1:/path/to/plugins2:') == "['/path/to/plugins1', '/path/to/plugins2']"

# Generated at 2022-06-23 11:13:25.957745
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.plugins.loader import get_all_plugin_loaders, PluginLoader
    from ansible.utils import context_objects as co

    if get_all_plugin_loaders():
        plugin_loaders = get_all_plugin_loaders()

        for plugin_type, plugin_loader in plugin_loaders.items():
            if not isinstance(plugin_loader, PluginLoader):
                raise AssertionError("Failed to assert that the type of plugin_loader is PluginLoader.")

    plugin_loader = PluginLoader(
        'callback',
        'ansible.plugins.callbacks',
        C.DEFAULT_CALLBACK_PLUGIN_PATH,
        'callback',
        'CallbacksBase'
    )

    plugin_loader.all()


# Generated at 2022-06-23 11:13:29.844026
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    '''
    Unit test for method print_paths of class PluginLoader
    '''
    loader = PluginLoader('', '', '', '', '', '')
    loader._searched_paths = []
    loader.package = 'ansible'
    loader.class_name = 'lookup'
    loader.base_class = ''
    loader.subdir = 'lookup_plugins'
    loader.all = ''
    mock_display = MagicMock()
    loader.display = mock_display
    loader._print_paths()
    assert mock_display.called



# Generated at 2022-06-23 11:13:40.580794
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    loader = PluginLoader('')
    expected = 'a/b/c, d/e, f/g/'
    assert loader.format_paths(['a/b/c', 'd/e', 'f/g/']), expected
    expected = 'a/b/c'
    assert loader.format_paths(['a/b/c']), expected
    expected = 'a/b/c, d/e, f/g/'

# Generated at 2022-06-23 11:13:50.826849
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
  from tempfile import TemporaryDirectory

  from ansible.utils.path import unfrackpath

  from ansible.errors import AnsibleError

  p = PluginLoader("ActionModule", package="ansible.plugins.action", config={}, subdir="action_plugins")

  action_plugins_path = unfrackpath("$ANSIBLE_LIB/ansible/plugins/action/")


# Generated at 2022-06-23 11:14:01.923482
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # FIXME: hardwired path
    with patch('ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.facts.legacy', FakeModuleFacts()):
        collection_list = ActionModule.get_collection_list()

        ld = PluginLoader(
            'ActionModule',
            package='ansible_collections.notmintest.not_a_real_collection.plugins.action',
            collection_list=collection_list
        )
        # find_plugin_with_context should load the requested module
        assert ld.find_plugin('ping', collection_list=collection_list).plugin_resolved_path == os.path.join('/home/whoever/ansible/ansible_collections/notmintest/not_a_real_collection', 'plugins/action/ping.py')

# Generated at 2022-06-23 11:14:06.782924
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    load_context = PluginLoadContext()
    load_context.nope("exit_reason")
    assert load_context.exit_reason == 'exit_reason'
    assert load_context.resolved is False



# Generated at 2022-06-23 11:14:16.369306
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    p = PluginLoadContext()
    plc = p.redirect("foo.bar")
    assert plc.pending_redirect == "foo.bar"
    assert plc.original_name is None
    assert plc.redirect_list == []
    assert plc.error_list == []
    assert plc.import_error_list == []
    assert plc.load_attempts == []
    assert plc.exit_reason == 'pending redirect resolution from None to foo.bar'
    assert plc.plugin_resolved_path is None
    assert plc.plugin_resolved_name is None
    assert plc.plugin_resolved_collection is None
    assert not plc.deprecated
    assert plc.removal_date is None
    assert plc.removal_version is None
    assert pl

# Generated at 2022-06-23 11:14:27.488185
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    plugin_loader = PluginLoader(None, '', '', '', [])
    assert plugin_loader.format_paths([system_playbooks_path, '/test/test', 'relative']) == '%s, /test/test, relative' % system_playbooks_path
    assert plugin_loader.format_paths(['/test/test', system_playbooks_path, 'relative']) == '/test/test, %s, relative' % system_playbooks_path
    assert plugin_loader.format_paths(['/test/test', 'relative']) == '/test/test, relative'
    assert plugin_loader.format_paths(['/test/test', '/test/test']) == '/test/test'


# Generated at 2022-06-23 11:14:36.230000
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    # Test with one path
    assert PluginLoader.format_paths(['/etc/ansible/galaxy/plugins/cache']) == "'/etc/ansible/galaxy/plugins/cache'"
    # Test with  two paths
    assert PluginLoader.format_paths(['/etc/ansible/galaxy/plugins/cache', '/etc/ansible/galaxy/plugins/action']) == "'/etc/ansible/galaxy/plugins/cache', '/etc/ansible/galaxy/plugins/action'"
    # Test with empty paths
    assert PluginLoader.format_paths([]) == ''



# Generated at 2022-06-23 11:14:44.462700
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
	plugin_load_context = ansible.module_utils.plugin_loader._PluginLoadContext()
	import sys
	import ansible.constants
	import ansible.module_utils.six
	import ansible.module_utils.six.moves
	import ansible.module_utils.six.moves.urllib.parse
	import ansible.module_utils.six.moves.urllib.request
	import ansible.parsing.ajson
	import ansible.utils.collection_loader
	import ansible.utils.collection_list

	plugin_load_context = ansible.module_utils.plugin_loader._PluginLoadContext()

	# Class: ansible.module_utils.plugin_loader.PluginLoader

# Generated at 2022-06-23 11:14:49.684202
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    '''
    Unit test for method __getstate__ of class PluginLoader
    '''
    loader = PluginLoader('my_class', 'my_package', 'my_base_class')
    plugin_load_context = loader.find_plugin_with_context('my_plugin')
    assert plugin_load_context == loader.__getstate__()


# Generated at 2022-06-23 11:14:56.080566
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    '''
    Test PluginLoader
    '''

    # Constructor of class PluginLoader
    assert PluginLoader.__new__(PluginLoader, 'connection', 'ansible.plugins.connection')
    assert PluginLoader.__new__(PluginLoader, 'connection', 'ansible.plugins.connection', config=load_config_file())



# Generated at 2022-06-23 11:14:56.837112
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    pass

# Generated at 2022-06-23 11:14:57.959215
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():

    assert False, "unit test not implemented"


# Generated at 2022-06-23 11:14:59.231635
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    context = PluginLoadContext()
    print(context.nope('nope_reason'))



# Generated at 2022-06-23 11:15:05.782825
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    from unittest.mock import Mock, patch

    class TestJinja2Plugin(object):
        def __init__(self, *args, **kwargs):
            pass

        def get_plugin(self):
            pass

    class TestJinja2Loader(Jinja2Loader):
        def __init__(self, pkg, class_name, base_class, subdir, aliases=None, required_base_class=True):
            super(TestJinja2Loader, self).__init__(pkg, class_name, base_class, subdir, aliases=aliases, required_base_class=required_base_class)

        def _get_paths(self):
            return ['./unit/plugins/plugin_loader/fixtures/']


# Generated at 2022-06-23 11:15:17.971473
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    config = {'DEFAULT_MODULE_PATH': '/usr/share/ansible:/usr/local/share/ansible'}
    config.update(C.config)
    config['DEFAULT_MODULE_PATH'] = "/usr/share/ansible/modules:/usr/local/share/ansible/modules"

    path = config.get('DEFAULT_MODULE_PATH').split(os.pathsep)
    files = set()
    for item in path:
        files.update(glob.glob(to_native(os.path.join(item, "*.py"))))

    assert len(files) >= 2
    assert any("/usr/share/ansible/modules/net_tools/ios/aaa.py" in s for s in files)

# Generated at 2022-06-23 11:15:22.345924
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    class MockDisplay:
        display = Display()
    plc = PluginLoadContext().nope('exit_reason')
    assert plc.resolved == False
    assert plc.exit_reason == 'exit_reason'

# Generated at 2022-06-23 11:15:26.046522
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    loader = PluginLoader("foo.bar", "foo.bar.baz")
    loader.package =  "foo.bar"
    loader.subdir = "foo.bar.baz"

    returner = loader.format_paths(["foo", "bar", "baz"])
    print(returner)

# Generated at 2022-06-23 11:15:27.780898
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    plugin_loaders = get_all_plugin_loaders()
    assert plugin_loaders



# Generated at 2022-06-23 11:15:35.406911
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    class Tester(Jinja2Loader):
        # all the class vars are set to the same value so we can avoid the module import in the super().__init__()
        def __init__(self):
            super(Jinja2Loader, self).__init__(class_name=None, package=None, base_class=None)
            self._searched_paths = []
            self._module_cache = {}

    t = Tester()

    # Take the existing list and create a list of files to return from .all()
    # Each file has a list of jinja2 plugins.  We will prepend the jinja2 plugin names with the file
    # name so that our tests can assert on them.

# Generated at 2022-06-23 11:15:46.019977
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    class MockModule:
        def __init__(self, module_name, attr):
            self.name = module_name
            self.attr = attr
    class MockPluginLoadContext:
        def __init__(self):
            self.plugin_name = 'foo'
            self.resolved = True
            self.plugin_resolved_name = 'bar'
            self.plugin_resolved_path = 'baz'
            self.redirect_list = ['foo', 'bar']
            self.plugin_config_defs = dict()
            self.nope_cache_key = None
            self.nope_cache_value = None
        def nope(self, msg):
            self.nope_cache_key = msg
            self.nope_cache_value = None
            return self

# Generated at 2022-06-23 11:15:56.454235
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():

    class Jinja2Filter(object):
        def __init__(self):
            self.__doc__ = 'Filter plugin'

    class Jinja2Test(object):
        def __init__(self):
            self.__doc__ = 'Test plugin'

    class Jinja2Module(object):
        def __init__(self):
            self.__doc__ = 'Module plugin'

    class Jinja2Module(object):
        def __init__(self):
            self.__doc__ = 'Module plugin'

    class Jinja2Filter(object):
        def __init__(self):
            self.__doc__ = 'Filter plugin'

    class Jinja2Test(object):
        def __init__(self):
            self.__doc__ = 'Test plugin'

    jinja2_filter_loader = Jinja2

# Generated at 2022-06-23 11:16:08.997929
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    from ansible.plugins import AnsibleError

    # Initialize a PluginLoader object
    test_obj = PluginLoader('ansible.module_utils')

    resolved = False
    for suffix in ('', '_utils'):
        for name in ('internal_argument_spec', 'common'):
            # Create a modified copy of the PluginLoadContext object
            plugin_load_context = PluginLoadContext('ansible.module_utils.{0}'.format(name), suffix)
            plugin_load_context.nope = 'core'

            # Create a modified copy of the AnsibleError object
            ansible_error = AnsibleError('foo bar')
            ansible_error.API_VERSION = 1

            # Invoke the method under test

# Generated at 2022-06-23 11:16:15.116906
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    context_result = get_with_context_result(foo_valid=1, bar_valid=2)
    assert hasattr(context_result, 'foo_valid')
    assert hasattr(context_result, 'bar_valid')
    assert not hasattr(context_result, 'not_valid')

    assert context_result.foo_valid == 1
    assert context_result.bar_valid == 2



# Generated at 2022-06-23 11:16:27.547570
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    a = Mock()
    a._searched_paths = ['a', 'b', 'c']
    a._module_cache = {'a': 'b'}
    a._package_paths = ['d', 'e']
    a.package = 'f'
    a.class_name = 'g'
    a.base_class = 'h'
    a.subdir = 'i'
    a.CUSTOM_DEDUPE = True
    a.collection_name = 'j'
    a.collection_list = ['k']
    a.aliases = {'m': 'n'}
    a.config_defs = {'o': 'p'}
    a.config_data = {'q': 'r'}
    a.alias_data = {'s': 't'}
   

# Generated at 2022-06-23 11:16:38.618596
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # No `collection` so no collection_list
    loader = PluginLoader('some_class', 'some_package', 'some_base_class')

    # No collections in context if no collection given
    context = loader.find_plugin_with_context('some_plugin')
    actual = context.collection_paths
    expected = []
    assert actual == expected, 'Got: %s' % actual

    # No collections in context if collection given, but no plugin is found
    loader = PluginLoader('some_class', 'some_package', 'some_base_class', collection='my_namespace.my_collection')
    context = loader.find_plugin_with_context('some_plugin')
    actual = context.collection_paths
    expected = []
    assert actual == expected, 'Got: %s' % actual

    # If collections are found,

# Generated at 2022-06-23 11:16:48.691116
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    test_context = PluginLoadContext()
    exit_reason_1 = 'exit_reason_1'
    test_context.nope(exit_reason_1)
    assert test_context.exit_reason == exit_reason_1
    assert test_context.pending_redirect == None
    assert test_context.resolved == False
    exit_reason_2 = 'exit_reason_2'
    test_context.nope(exit_reason_2)
    assert test_context.exit_reason == exit_reason_2
    assert test_context.pending_redirect == None
    assert test_context.resolved == False
    

# Generated at 2022-06-23 11:16:52.643012
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    plugin_loader = PluginLoader()
    out = to_text(six.StringIO())
    with redirect_stdout(out):
        plugin_loader.print_paths()
    assert out.strip().split('\n') == plugin_loader._get_paths()


# Generated at 2022-06-23 11:16:53.661762
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    pass


# Generated at 2022-06-23 11:16:55.061713
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    assert True, 'FIXME: write this unit test'



# Generated at 2022-06-23 11:17:02.174501
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Instantiate a plugin loader
    plugin_loader = C.ansible._internal_utils.loader.PluginLoader(path=['/path/to/somewhere/'], package='ansible.plugins.lookup')
    # Check that the plugin loader executed correctly
    lookup_plugin = plugin_loader.get(name='dynamic_inventory')
    # Check that the plugin executed correctly
    from ansible.plugins.loader import lookup_loader
    lookup_plugin_class = lookup_loader.get('dynamic_inventory', class_only=True)
    # Check that the plugin executed correctly
    for obj in plugin_loader.all('ansible.plugins.filter'):
        pass
    # Check that the plugin executed correctly
    for obj in plugin_loader.all('ansible.plugins.filter', class_only=True):
        pass
    # Check that

# Generated at 2022-06-23 11:17:13.428572
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    config_mock = MagicMock(name='config_mock')
    collection_mgr_mock = MagicMock(name='collection_mgr_mock', return_value=None)
    # patching the decorator
    module_patcher = patch('ansible.module_utils.basic._ANSIBLE_ARGS', new={'config_file': ['/some/file'], 'ansible_collections_path': ['/some/path'], 'verbosity': 3, 'module_path': ['/some/path']})
    module_patcher.start()

    # mock all the imports that this module does

# Generated at 2022-06-23 11:17:17.488007
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    jinja2_loader_1 = Jinja2Loader('filter_loader', 'ansible.plugins.filter', 'FilterModule', 'FilterBase')
    jinja2_loader_2 = Jinja2Loader('filter_loader', 'ansible.plugins.filter', 'FilterModule', 'FilterBase')
    assert jinja2_loader_1 == jinja2_loader_2

    # Test the dict interface works.
    test_dict = {}
    test_dict[jinja2_loader_1] = 1
    # Make sure that the hash of the instances is the same.
    assert id(jinja2_loader_1) != id(jinja2_loader_2)
    test_dict[jinja2_loader_2] = 2
    assert len(test_dict) == 1

    # Test that we can iterate the

# Generated at 2022-06-23 11:17:27.908572
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
  loader = PluginLoader(package='ansible.plugins.connection', class_name='ConnectionBase', base_class='ConnectionBase', aliases={'smart': 'smartssh', 'ssh': 'smartssh'}, min_subdir_count=1)

  # No args
  result = loader.print_paths()
  assert result is None, "print_paths() should return None for the test PluginLoader"

  # One arg
  result = loader.print_paths(False)
  assert result is None, "print_paths() should return None for the test PluginLoader"

  # With print=True
  stream = MockStream()
  result = loader.print_paths(True, stream)
  assert result is None, "print_paths() should return None for the test PluginLoader"

# Generated at 2022-06-23 11:17:36.718913
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():

    class Foo(object):
        def __init__(self, x):
            self.x = x

    jl = Jinja2Loader('ansible.legacy.j2', 'foo', Foo)
    assert jl.package == 'ansible.legacy.j2'
    assert jl.paths == [os.path.join(os.path.expanduser('~'), u'.ansible/plugins/j2')]
    assert jl._searched_paths == []
    assert jl.class_name == 'foo'
    assert jl._module_cache == {}


# Generated at 2022-06-23 11:17:45.903665
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    '''
    Unit test for method __getstate__ of class PluginLoader
    '''
    fixture_expected = {
        'package': '',
        'base_class': None,
        'class_name': '',
        'aliases': {},
        'categories': [],
        '_module_cache': {},
        '_searched_paths': [os.path.sep],
        '_configs_loaded': [],
    }
    # This code could be put in a setup method for an AnsibleModule, but atm it is not worth it
    # We create a module object and initialize the plugins
    # The problem is that we don't have a real module and we also don't have any arguments
    tmp_module = collections.namedtuple("FakeModule", "ANY, argument_spec")
    tmp_module