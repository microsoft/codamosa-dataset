

# Generated at 2022-06-23 11:07:47.427234
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    x = PluginLoadContext()
    assert isinstance(x.nope('this method returns an object of type PluginLoadContext'), PluginLoadContext)
    assert x.resolved == False
    assert x.exit_reason != None
    assert x.exit_reason == 'this method returns an object of type PluginLoadContext'
    assert x.pending_redirect == None


# Generated at 2022-06-23 11:07:53.853006
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    from ansible import plugins
    import types

    assert isinstance(plugins, types.ModuleType)
    assert plugins.ActionBase not in globals()

    found_loaders = get_all_plugin_loaders()
    assert isinstance(found_loaders, list)
    assert len(found_loaders) > 0

    for name, loader in found_loaders:
        assert (name, loader) in globals().items()
        assert isinstance(loader, PluginLoader)



# Generated at 2022-06-23 11:07:55.858490
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    context = PluginPathContext('test_path', internal=True)
    assert context.path == 'test_path'
    assert context.internal is True


# Generated at 2022-06-23 11:08:01.232578
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    """
    Test that we can add a directory to the shell plugin loader
    """
    plugin_dir = os.path.join(os.path.dirname(__file__), 'shell_plugins')
    sys.modules[__name__].shell_loader = PluginLoader('shell')
    add_dirs_to_loader('shell', [plugin_dir])
    result = [x for x in sys.modules[__name__].shell_loader._get_paths()]
    assert(plugin_dir in result)



# Generated at 2022-06-23 11:08:02.712778
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # TODO: implement
    pass

# Generated at 2022-06-23 11:08:12.082588
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():

    # FIXME: what is the purpose of this test?

    # Implicit mode
    # FIXME: it looks like this is a test for method __getnewargs__
    #   is this the test we want, or do we want a test for __setstate__?
    # FIXME: the call to display.debug makes this test dependent on the state of the display module
    #   this is a problematic dependency and should be avoided
    # FIXME: the call to display.debug also makes this test dependent on the state of C.DEFAULT_DEBUG
    #   this is also a problematic dependency and should be avoided
    # FIXME: this test has no assertion
    gpl = PluginLoader('gpl')

    # Explicit mode
    # FIXME: this test calls method __setstate__ with no arguments
    #   what is the expected behavior here?

# Generated at 2022-06-23 11:08:15.778513
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    p = PluginLoader("test.plugins.test_plugin")
    assert p._get_paths() == [os.path.join("test","plugins","test_plugin")]


# Generated at 2022-06-23 11:08:25.180213
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():

    class FakeActionModule(object):
        def __init__(self, thingy):
            self.something = thingy

    class FakeCacheModule(object):
        def __init__(self, thingy):
            self.something = thingy

    class FakeFilterModule(object):
        def filters(self):
            return dict(test_filter=lambda x: x)

    # Create a test directory
    temp_dir = tempfile.mkdtemp()
    # Create a fake action plugin
    action_plugin_directory = os.path.join(temp_dir, 'action')
    os.makedirs(action_plugin_directory)
    open(os.path.join(action_plugin_directory, 'test_action.py'), 'a').close()
    # Create a fake cache plugin
    cache_plugin_directory = os.path.join

# Generated at 2022-06-23 11:08:34.044643
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    # Test when shell_type and executable are provided
    shell = get_shell_plugin('csh', '/usr/bin/csh')
    assert shell.executable == '/usr/bin/csh'
    shell = get_shell_plugin('sh', '/bin/sh')
    assert shell.executable == '/bin/sh'
    # Test when only shell_type is provided
    shell = get_shell_plugin('mksh')
    assert shell.SHELL_FAMILY == 'mksh'
    # Test when only executable is provided
    try:
        shell = get_shell_plugin(executable='/usr/bin/csh')
    except AnsibleError:
        assert True
    # Test when neither shell_type nor executable are provided

# Generated at 2022-06-23 11:08:43.060521
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    # Loads the pickled object from a file
    (plugin_loader_reload, temp_file) = pickle.load(open('tests/unit/utils/fixtures/PluginLoader/__getstate__/serialized_pickled_object.pkl','rb'))

    # Gets the PluginLoader object from the loaded object with tuple unpacking
    (plugin_loader,) = plugin_loader_reload

    # Compares the original PluginLoader object with the unpickled PluginLoader object
    assert plugin_loader == plugin_loader_reload

# Generated at 2022-06-23 11:08:48.322263
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    """
    Unit test method nope of class PluginLoadContext
    """
    plc = PluginLoadContext()
    assert isinstance(plc.nope('test'), PluginLoadContext)
    assert plc.exit_reason == 'test'
    assert plc.resolved == False


# Generated at 2022-06-23 11:08:53.502904
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    C.clear_loaders_cache()
    C.DEFAULT_MODULE_PATH = '/xxx/yyy/zzz:/ddd/'
    add_all_plugin_dirs(C.DEFAULT_MODULE_PATH)
    assert MODULE_CACHE[0] == '/xxx/yyy/zzz/module_utils'
    assert MODULE_CACHE[1] == '/xxx/yyy/zzz/action_plugins'
    assert MODULE_CACHE[2] == '/xxx/yyy/zzz/lookup_plugins'
    assert MODULE_CACHE[3] == '/xxx/yyy/zzz/filter_plugins'
    assert MODULE_CACHE[4] == '/xxx/yyy/zzz/callback_plugins'

# Generated at 2022-06-23 11:08:56.364654
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    import ansible.plugins.filter
    files = Jinja2Loader('ansible.plugins.filter', 'FilterModule', 'ansible.plugins.filter.core').all()

    assert len(files) == len(ansible.plugins.filter.FILTERS)



# Generated at 2022-06-23 11:09:06.793119
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    # unit test for the method record_deprecation of class PluginLoadContext
    class TestPluginLoadContext(object):
        def __init__(self):
            pass
    test_plugin_load_context = TestPluginLoadContext()
    result = test_plugin_load_context.record_deprecation(name='ansible.builtin.debug', deprecation={}, collection_name=None)
    assert result == test_plugin_load_context, "The result is right"
    deprecation = {'removal_version': '2.13', 'warning_text': '~'}
    result = test_plugin_load_context.record_deprecation(name='ansible.builtin.debug', deprecation=deprecation, collection_name=None)

# Generated at 2022-06-23 11:09:13.554691
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    loader_context = PluginLoadContext()
    assert not loader_context.pending_redirect
    assert not loader_context.original_name
    assert not loader_context.exit_reason
    assert not loader_context.plugin_resolved_path
    assert not loader_context.plugin_resolved_name
    assert not loader_context.plugin_resolved_collection
    assert not loader_context.deprecated
    assert not loader_context.removal_date
    assert not loader_context.removal_version
    assert not loader_context.resolved
    assert not loader_context.redirect_list
    assert not loader_context.error_list
    assert not loader_context.import_error_list
    assert not loader_context.load_attempts

    resolved_name = 'foo.bar'

# Generated at 2022-06-23 11:09:19.148355
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    p = PluginLoadContext()
    assert p.original_name == None

    p.original_name = 'test'
    assert p.original_name == 'test'

    assert p.redirect_list == []
    assert p.error_list == []
    assert p.import_error_list == []
    assert p.load_attempts == []

    assert p.pending_redirect == None

    assert p.exit_reason == None
    assert p.plugin_resolved_path == None
    assert p.plugin_resolved_name == None
    assert p.plugin_resolved_collection == None
    assert p.deprecated == False
    assert p.removal_date == None
    assert p.removal_version == None
    assert p.deprecation_warnings == []
    assert p.resolved == False

# Generated at 2022-06-23 11:09:31.618001
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    jinja2_directories = ['/home/jenkins/ansible/test/units/modules/test_utils/testdata/wrapper/plugins/filter_plugins',
                          '/home/jenkins/ansible/test/units/modules/test_utils/testdata/wrapper/plugins/test_plugins']

    for jinja2_directory in jinja2_directories:
        files = os.listdir(jinja2_directory)
        plugin_files = []
        for f in files:
            plugin_files.append(os.path.join(jinja2_directory, f))

        # make sure it's the same for filter and test plugins
        # make sure it's the same for filter and test plugins
        assert len(Jinja2Loader('', '', 'cache', collection_list=[]).all()) == 0
       

# Generated at 2022-06-23 11:09:40.492591
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # 0
    pl = PluginLoader('test_plugins', MODULE_CACHE_MODULES, '', '_test_plugins')
    pl._get_paths = lambda: ['test_path']
    pl._load_module_source = lambda a, b: {
        '_test_plugins.TestClass': TestClass,
        '_test_plugins.TestClassWithArgs': TestClassWithArgs
    }[a]

    plugin_load_context = AnsiblePluginLoadContext()
    plugin_load_context.plugin_resolved_name = '_test_plugins.TestClass'
    plugin_load_context.plugin_resolved_path = '_test_plugins.TestClass'
    pl.find_plugin_with_context = lambda a: plugin_load_context
    obj = pl.get_with_context('TestClass').object

# Generated at 2022-06-23 11:09:47.057848
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    # TODO: find out why this test is failing when run as part of a group with pytest
    temp_dir = C.DEFAULT_LOCAL_TMP
    if not os.path.exists(temp_dir):
        os.mkdir(temp_dir)
    list_files = [
        'my_tests/my_test1.py',
        'my_tests/my_test2.py',
        'my_tests/my_test3.py',
    ]
    for f in list_files:
        with open(os.path.join(temp_dir, f), 'w+') as content:
            content.write("def my_assert(var):\n    return 'my assert'\n\n")


# Generated at 2022-06-23 11:09:55.493201
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    from ansible.utils.plugin_docs import get_docstring

    def find_plugin(name, plugin_type=None, collection_list=None):
        """
        Wraps the find_plugin method so we get an accurate traceback in the event of an error.
        """
        if plugin_type:
            plugin_type = '.' + plugin_type
        else:
            plugin_type = ''

        try:
            plugin = getattr(AnsiblePluginLoader, plugin_type.replace('.', '_')).find_plugin(name, collection_list=collection_list)
        except Exception as e:
            display.warning("Invalid Plugin %s (%s): %s" % (plugin_type, name, to_text(e)))
            raise

# Generated at 2022-06-23 11:10:07.523963
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    class FakeEntrypoint:
        @property
        def entry_point(self):
            return 'faketest.test'

        def load(self):
            return lambda x: x

    def test_Jinja2Loader_find_plugin_with_entrypoint(tmpdir):
        tmpdir.join('__init__.py').write('#')
        tmpdir.join('faketest.py').write('#')

        p = Jinja2Loader('faketest.test', 'filter_plugins', 'faketest', 'mytest')
        p.add_directory(str(tmpdir))

        with patch.object(p, '_get_entrypoints', return_value=[FakeEntrypoint()]):
            res = p.find_plugin('faketest.test')

        assert res is not None


# Generated at 2022-06-23 11:10:11.907395
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    import mock

    # Test base case (no args), and case with empty args
    plugin_loader = PluginLoader('')

    # Test case with empty args
    plugin_loader = PluginLoader('', '', '')

    # Test case with non-empty args
    plugin_loader = PluginLoader('foo', 'bar', 'baz')



# Generated at 2022-06-23 11:10:22.351298
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    pl = PluginLoader(basename='', package='test', class_name='test_class')
    pl._searched_paths = ['test/path1', '/test/path2']
    result = pl.format_paths(pl._searched_paths)
    assert result == "test/path1,/test/path2"

    # Test for function format_paths of class PluginLoader if package has collections
    pl = PluginLoader(basename='', package='ansible.plugins.module_utils', class_name='module_utils_class')
    pl._searched_paths = ['/test/ansible/plugins/module_utils/path1', '/test/ansible/collections/test_collection/plugins/module_utils/path2', 'test/ansible/plugins/module_utils/path3']
    result

# Generated at 2022-06-23 11:10:29.204627
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    # Test PluginLoader.__init__()
    pl = PluginLoader(
        'ModuleUtils',
        'module_utils',
        C.DEFAULT_MODULE_UTILS_PATH,
        'module_utils',
        required_base_class='ModuleUtilsBase'
    )
    assert pl.package == 'module_utils'
    assert pl.paths == C.DEFAULT_MODULE_UTILS_PATH
    assert pl.directory == 'module_utils'
    assert pl.package_name == 'ModuleUtils'
    assert pl.class_name == 'ModuleUtils'
    assert pl.base_class == 'ModuleUtilsBase'

    # Test PluginLoader.__getattr__()
    pl = PluginLoader('test', 'unit.module_loader.test', 'test_path')

# Generated at 2022-06-23 11:10:33.000916
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    obj = PluginPathContext(path='/path/to/somewhere', internal=True)
    assert obj
    assert obj.path == '/path/to/somewhere'
    assert obj.internal == True



# Generated at 2022-06-23 11:10:35.979213
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    loader = PluginLoader('', '', '', '', '', '')
    loader.all()
# -----------------------------------------------------------
# END OF PluginLoader, BEGINNING OF PluginPoller
# -----------------------------------------------------------

# Generated at 2022-06-23 11:10:48.206578
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():

    class FakeLoader(Jinja2Loader):
        def __init__(self, *args, **kwargs):
            super(FakeLoader, self).__init__('test', 'fake', *args, **kwargs)

        def _get_paths(self): return ['/foo/bar']

    class FakeModule(object):
        class FakeClass(object):
            def __init__(self, *args, **kwargs):
                # FakeClass.__init__ instantiates a plugin
                self.args = args
                self.kwargs = kwargs

            def __call__(self, a, b, c, d=None):
                # FakeClass.__call__ is also a plugin
                return {'args': [a, b, c], 'kwargs': {'d': d}}


# Generated at 2022-06-23 11:10:50.970492
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():

    # call the constructor with just a context
    context = 'test_context'
    sut = get_with_context_result(context)

    # assert that the context was set
    assert sut.context == context

    # assert that the result is None
    assert sut.result is None

    # call the constructor with a context and result
    result = 'test_result'
    sut = get_with_context_result(context, result)

    # assert that the result was set
    assert sut.result == result

# Generated at 2022-06-23 11:10:54.922676
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    test_dict = {}
    def test_func():
        pass
    test_dict["PluginLoader"] = PluginLoader
    test_dict["testfunc"] = test_func
    assert set(get_all_plugin_loaders()).issubset(set(test_dict.items()))



# Generated at 2022-06-23 11:11:00.257448
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    name = None
    package = None
    path = None
    plugin_loader = PluginLoader(name, package, path)
    state = None
    result = plugin_loader.__setstate__(state)
    assert result is None


# Generated at 2022-06-23 11:11:12.111636
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    from ansible.plugins.loader import Jinja2Loader
    from ansible import context
    from ansible.plugins.loader import _get_package_paths

    def mock_get_all_plugin_loaders(subdir):
        if subdir == 'filter_plugins':
            path = '/test/filters'
        else:
            path = '/test/tests'
        return [path]

    # make sure the legacy path is not recorded during init to ensure test results
    # can be reliably predicted
    def mock_get_legacy_path():
        return None

    loader = Jinja2Loader()

    # assert plugin will be found in the legacy path
    context.CLIARGS._get_all_plugin_loaders = mock_get_all_plugin_loaders

# Generated at 2022-06-23 11:11:24.865686
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    '''
    verify we get a jinja2 object from loader in 'ansible.legacy' namespace
    '''
    from ansible.plugins.loader import Jinja2Loader
    import os
    import tempfile
    import sys

    # create a temporary directory
    tmp_dir = tempfile._mkdtemp(suffix='test_Jinja2Loader_get')

    # setup sys path to point to our temporary directory
    if tmp_dir not in sys.path:
        sys.path.append(tmp_dir)

    os.chdir(tmp_dir)
    open('__init__.py', 'a').close()  # create __init__.py

    # create a directory 'filter_plugins'
    os.mkdir('filter_plugins')
    open('filter_plugins/__init__.py', 'a').close

# Generated at 2022-06-23 11:11:30.858078
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    loader = PluginLoader(
        "ansible.plugins.action",
        C.DEFAULT_ACTION_PLUGIN_PATH,
        "ActionModule",
        "action",
        required_base_class="ActionBase"
    )

    all = loader.all()
    assert isinstance(all, types.GeneratorType)
    assert len(list(all)) > 0


# Generated at 2022-06-23 11:11:36.591004
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    plugin_loader = PluginLoader('package', 'baseclass', 'classname')
    assert repr(plugin_loader) == '''<ansible.plugins.loader.PluginLoader object at 0x7f38dcdc9940>
  (_full_package_name=ansible.plugins.package, _aliases={}, _package_name=package, _package_path=None, _base_class=baseclass, _class_count=0, _package_overrides={}, _class_name=classname, _paths=None, _searched_paths=[], _module_cache={})'''


# Generated at 2022-06-23 11:11:48.155859
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    from ansible.compat.tests.mock import patch
    from ansible.compat.tests.mock import MagicMock

    class MockDisplay(MagicMock):
        """
        Class to handle the AnsibleDisplay object
        """
        class Display:
            DEPRECATE = 'deprecate'
            WARNING = 'warning'
            FATAL = 'fatal'

        def __init__(self):
            super(MockDisplay, self).__init__()

        def deprecated(self, msg, version=None, date=None, collection_name=None):
            return msg

        def warning(self, msg):
            return msg


# Generated at 2022-06-23 11:12:00.209619
# Unit test for method format_paths of class PluginLoader

# Generated at 2022-06-23 11:12:07.890943
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    class warn:
        def __init__(self):
            self.message = ''
            self.collection_name = None
            self.date = None
            self.version = None
        def deprecated(self, *args, **kw):
            self.message = args[0]
            self.collection_name = kw.get('collection_name', None)
            self.date = kw.get('date', None)
            self.version = kw.get('version', None)
    display.deprecated = warn()
    plc = PluginLoadContext()
    plc.record_deprecation('test', {'warning_text': 'message'}, 'test_collection')
    assert display.deprecated.message == 'test has been deprecated. message'
    assert display.deprecated.collection_name == 'test_collection'

# Generated at 2022-06-23 11:12:18.917205
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    test_loader = Jinja2Loader()

    # Temporary.  We'll remove this once we remove the 'filter_plugins' and 'test_plugins' dir from the
    # ansible.legacy package and move those plugins into their collections.
    test_loader.add_directory(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'filter_plugins'), with_subdir=True)
    test_loader.add_directory(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_plugins'), with_subdir=True)

    test_loader.add_directory(os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', 'filter_plugins'), with_subdir=True)
    test

# Generated at 2022-06-23 11:12:21.316837
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    assert all([isinstance(obj, PluginLoader) for (name, obj) in get_all_plugin_loaders()])



# Generated at 2022-06-23 11:12:33.170729
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    print("Start test_PluginLoader_find_plugin ...")
    from ansible_collections import ansible_collections_name, ansible_collections_path

    tests = []


# Generated at 2022-06-23 11:12:35.169983
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    # This class is abstract and thus has no public constructor
    with pytest.raises(AnsibleError):
        PluginLoader()



# Generated at 2022-06-23 11:12:47.719729
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    from ansible.module_utils.six.moves import StringIO

    import sys
    if six.PY3:
        from unittest.mock import patch
    else:
        from mock import patch


# Generated at 2022-06-23 11:12:52.374774
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    p = PluginLoader()
    p.__setstate__({"_searched_paths": [], "package": "","path_base": "","all_candidates": {}, "_module_cache": {}, "class_name": "","base_class": "","subdir": "","aliases": {}})

# Generated at 2022-06-23 11:13:02.924392
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    # Test that all fields are initialized correctly
    c = PluginLoadContext()
    assert c.original_name is None
    assert c.redirect_list == []
    assert c.error_list == []
    assert c.import_error_list == []
    assert c.load_attempts == []
    assert c.pending_redirect is None
    assert c.exit_reason is None
    assert c.plugin_resolved_path is None
    assert c.plugin_resolved_name is None
    assert c.plugin_resolved_collection is None
    assert not c.deprecated
    assert c.removal_date is None
    assert c.removal_version is None
    assert c.deprecation_warnings == []
    assert not c.resolved
    assert c.resolved_fqcn is None
   

# Generated at 2022-06-23 11:13:08.907599
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    fake_module = 'fake_module'
    plugin_load_context = PLUGIN_LOAD_CONTEXT.PLUGIN_NOT_FOUND
    paths = 'fake_paths'
    package = 'fake_package'
    base_class = 'fake_base_class'
    class_name = 'fake_class_name'
    cache = 'fake_cache'
    aliases = 'fake_aliases'

    plugin_loader = PluginLoader(paths=paths, package=package,
        base_class=base_class, class_name=class_name, config_defs=config_defs,
        in_memory_cache=cache, aliases=aliases
    )

    plugin_loader.pkg_mgr = fake_module
    plugin_loader.load_context = plugin_load_context

    result = plugin_loader

# Generated at 2022-06-23 11:13:11.046295
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    for name, obj in get_all_plugin_loaders():
        assert isinstance(obj, PluginLoader)


# Generated at 2022-06-23 11:13:14.065520
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    p = PluginPathContext('Path_01', True)
    assert p.path == 'Path_01'
    assert p.internal == True


# Generated at 2022-06-23 11:13:23.963214
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # Simple test of a scenario where we are looking for a
    # plugin in multiple locations and the lookup should succeed
    test_dir = "test_dir"
    pdir = "my_dir"
    pfqcr = "my_col.my_ns.my_plugin"
    pname = "my_plugin"

    # Create the top level path to test_dir
    tdp = os.path.join(filesep, test_dir)
    os.makedirs(tdp)

    # Make the test_dir/my_dir path
    mdp = os.path.join(tdp, pdir)
    os.makedirs(mdp)

    # Create the plugin file
    fp = os.path.join(mdp, pname + ".py")
    open(fp, 'a').close()

    #

# Generated at 2022-06-23 11:13:27.023558
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    context = PluginPathContext('some/file/path', internal=True)
    # Check that the constructor was called properly
    assert context.path == 'some/file/path'
    assert context.internal is True


# Generated at 2022-06-23 11:13:29.654417
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    context = PluginLoadContext()
    print(context.resolve('resolved_name', 'resolved_path', 'resolved_collection', 'exit_reason'))


# Generated at 2022-06-23 11:13:32.148045
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    loader = PluginLoader('filter_plugins', package='ansible')
    if 'json_query' not in loader:
        raise AssertionError('ansible.plugins.filter.json_query not found')


# Generated at 2022-06-23 11:13:36.561926
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    # test creating a plugin loader without args
    plugin_loader = PluginLoader()
    assert plugin_loader is not None
    assert plugin_loader.package is None
    assert plugin_loader.subdir is None
    assert plugin_loader.base_class is None
    assert plugin_loader.class_name is None


# Generated at 2022-06-23 11:13:39.251166
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    # plugin_loader = PluginLoader()
    # assert_equal(expected, plugin_loader.__getstate__())
    raise SkipTest 


# Generated at 2022-06-23 11:13:48.447100
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    from ansible.module_utils.facts import PluginLoader # import PluginLoader to make it available to mock_runner
    PluginLoader.get_with_context = mock_runner('ansible.module_utils.facts.PluginLoader', '_TestCases', 'PluginLoader.get_with_context')
    def test_get_with_context(self, name, collection_list=None, *args, **kwargs):
        # mock self.find_plugin
        self.find_plugin = mock_runner('ansible.module_utils.facts.PluginLoader', '_TestCases', 'PluginLoader.find_plugin')
        def test_find_plugin(self, name, collection_list=None):
            test_find_plugin_context = PluginLoadContext(name)
            test_find_plugin_context.resolved = True
            test_find_plugin

# Generated at 2022-06-23 11:14:00.527677
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    class FakeDisplay(object):
        def deprecated(self, text, **kwargs):
            self.text = text
            self.kwargs = kwargs

    context = PluginLoadContext()
    fake_display = FakeDisplay()
    collection = "ansible_collections.my_namespace.my_collection"
    name = "my_plugin.my_module"
    # test that deprecation is correctly recorded by record_deprecation
    my_deprecation = {u"warning_text": u"test warning text"}
    context.record_deprecation(name, my_deprecation, collection)
    assert context.deprecated == True
    assert context.deprecation_warnings == ["my_plugin.my_module has been deprecated. test warning text"]
    assert context.removal_date == None
    assert context.rem

# Generated at 2022-06-23 11:14:12.970662
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    '''
    This is not a real unit test.  It is meant to be run manually to test the
    PluginLoader class.  To run it:

    1. Comment out the lines below so that the script is just defining the function
    2. Run the script with -c so that it executes normally (not with -m)
    3. Run it with -m so that it executes as a module

    The point is that the first time it runs it uses the normal Python import
    mechanism which sets __name__ to "__main__".  The second time it sets
    __name__ to the name of the module which changes the code path in the
    constructor of PluginLoader.
    '''

    import pprint


# Generated at 2022-06-23 11:14:16.640928
# Unit test for function add_all_plugin_dirs
def test_add_all_plugin_dirs():
    """
    Make sure that add_all_plugin_dirs doesn't fail if the path doesn't
    exist
    """
    assert not add_all_plugin_dirs('/tmp/no_such_dir')


# Generated at 2022-06-23 11:14:28.526593
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    plugin_load_context = PluginLoadContext()
    plugin_load_context.callback = mock.MagicMock()
    for name in ('', None, 'not.a.name'):
        with pytest.raises(AnsibleError):
            PluginLoader.find_plugin_with_context(name)
    name = 'ansible.builtin.invalid'
    with pytest.raises(AnsibleError):
        PluginLoader.find_plugin_with_context(name)
    name = 'ansible.builtin.invalid'
    with pytest.raises(AnsibleError):
        PluginLoader.find_plugin_with_context(name, plugin_load_context=plugin_load_context)

# Generated at 2022-06-23 11:14:33.672348
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    """
    Test PluginLoader __contains__
    """
    pl = PluginLoader(package='dummy_package', namespaces=['dummy_namespace'])
    pl.all = MagicMock(return_value=[
        'some_plugin'
    ])

    # Test
    assert 'some_plugin' in pl

# Generated at 2022-06-23 11:14:37.356306
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    from ansible.plugins.loader import get_with_context_result

    # If the test is run on a "non-5.5" system, this will fail, meaning (hopefully) that
    # we have not downgraded our minimum required version of Python.
    assert get_with_context_result().get_result() == NOT_FOUND



# Generated at 2022-06-23 11:14:49.600829
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    plugin_load_context = PluginLoader.find_plugin_with_context('mock')
    assert plugin_load_context.plugin_resolved_name == 'mock'
    assert plugin_load_context.resolved
    assert '/lib/ansible/plugins/action/mock.py' == plugin_load_context.plugin_resolved_path
    assert plugin_load_context.caches['plugins'].has_plugin('mock')

    plugin_load_context = PluginLoader.find_plugin_with_context('non_existing_plugin')
    assert not plugin_load_context.plugin_resolved_name
    assert not plugin_load_context.resolved
    assert not plugin_load_context.plugin_resolved_path

# Generated at 2022-06-23 11:14:57.163840
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    pl = PluginLoader(package='ansible.plugins.action', class_name='ActionBase')
    expected = {
        'foo': ['/foo'],
        'bar': ['/foo', '/bar'],
        'baz': ['/foo', '/bar', '/baz'],
    }
    for paths, result in expected.items():
        assert result == pl._format_paths(paths)



# Generated at 2022-06-23 11:15:07.312798
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    pl = PluginLoader('/usr/lib/python2.7/dist-packages', 'ansible.plugins.action', 'ActionModule')

# Generated at 2022-06-23 11:15:15.532699
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    lookup_cache = dict()
    plugin_loader = PluginLoader('ansible.plugins.lookup', 'LookupModule', lookup_cache, 'ansible.plugins.lookup.lookup_loader', 'lookup_plugins')
    name = 'test_name'
    suffix = '_test_suffix'

    assert plugin_loader.find_plugin(name, suffix, 'invalid_scope') is None
    assert plugin_loader.find_plugin(name, suffix) is None
    assert plugin_loader.find_plugin(name) is None



# Generated at 2022-06-23 11:15:17.324793
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    assert len(get_all_plugin_loaders()) > 0


# Generated at 2022-06-23 11:15:28.360503
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    from ansible.config.manager import ConfigManager
    from ansible.errors import AnsibleError

    class MockLoader(Jinja2Loader):
        def __init__(self, *args, **kwargs):
            self._searched_paths = args[1]
            self._module_cache = {}
            self._plugin_paths = ConfigManager(None, None).plugin_paths()

            # this is required in jinja2loader because it uses
            # default_safe_str_substitutions which is set by config
            # this is also what the unit test uses, hence we define it here
            self.subdir = 'filter_plugins'
            self._subdir = 'filter_plugins'

        def _load_module_source(self, name, path):
            # mock function
            return {'name': name}

# Generated at 2022-06-23 11:15:40.804577
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
  from ....constants import AnsibleModuleType
  from ....plugins.loader import collections_loader
  from ....utils.collection_loader import AnsibleCollectionFinder
  from ....utils.collection_loader._collection_finder import AnsibleCollectionConfig

  # first we'll test the error condition when both path_only and class_only are set
  loader = PluginLoader(AnsibleModuleType.ACTION_PLUGIN, package='ansible.plugins.action', config=None, subdir=None, aliases=None,
      class_name='ActionModule', base_class='ActionBase', required_base_class=None)

  loader.all(path_only=True, class_only=True)
  assert False, "Failed to raise expected AnsibleError"

  # next we'll test the error condition when we try to pass parameters to each plugin

# Generated at 2022-06-23 11:15:53.382112
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins.filter.core import FilterModule
    from ansible.plugins.lookup.core import LookupModule
    from ansible.plugins.strategy.core import StrategyModule
    from ansible.plugins.action.core import ActionModule
    from ansible.plugins.cache.core import CacheModule
    from ansible.plugins.callback.core import CallbackModule
    from ansible.plugins.connection.core import ConnectionModule
    from ansible.plugins.converter.core import ConverterModule
    from ansible.plugins.test.core import TestModule
    from ansible.plugins.terminal.core import TerminalModule
    from jinja2 import filters
    from jinja2 import tests

    assert type(PluginLoader('filter').get('json')) == FilterModule
    assert type

# Generated at 2022-06-23 11:16:00.135364
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    PL = PluginLoader("module_utils", "ModuleUtils")
    PL.__setstate__({})
    PL.__setstate__({
        'package': 'module_utils',
        'subdir': 'test',
        'class_name': 'ClassName',
        'base_class': 'BaseClass',
        '_searched_paths': [],
        '_found_paths': [],
        '_paths_cache': False,
        '_modules_cache': False,
        '_categories': {},
        '_aliases': {},
        '_added_names': [],
        '_config_defs': {},
    })


# Generated at 2022-06-23 11:16:03.730399
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    expected_result = (1, 2, 3)
    test_result = get_with_context_result(expected_result).result
    assert test_result == expected_result



# Generated at 2022-06-23 11:16:12.555315
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    plc = PluginLoadContext()
    assert plc.resolved == False
    plc.resolve("test", "/path/to/plugin", "test.plugins", "everything is fine")
    assert plc.resolved == True
    assert plc.plugin_resolved_name == "test"
    assert plc.plugin_resolved_path == "/path/to/plugin"
    assert plc.plugin_resolved_collection == "test.plugins"
    assert plc.exit_reason == "everything is fine"


# Generated at 2022-06-23 11:16:19.789538
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    # This function MUST be kept up to date with the plugin loaders that are in this file.
    assert get_all_plugin_loaders() == [
        ('action_loader', action_loader),
        ('cache_loader', cache_loader),
        ('callback_loader', callback_loader),
        ('connection_loader', connection_loader),
        ('filter_loader', filter_loader),
        ('test_loader', test_loader),
        ('module_loader', module_loader),
        ('shell_loader', shell_loader),
        ('strategy_loader', strategy_loader),
        ('terminal_loader', terminal_loader),
        ('vars_loader', vars_loader),
        ('lookup_loader', lookup_loader),
        ('fragment_loader', fragment_loader),
        ('inventory_loader', inventory_loader),
    ]

# Generated at 2022-06-23 11:16:21.098474
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    assert 1 == 1


# Generated at 2022-06-23 11:16:30.800138
# Unit test for method format_paths of class PluginLoader

# Generated at 2022-06-23 11:16:43.415338
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():

    # None is passed as the deprecation argument
    load_context = PluginLoadContext()
    load_context.record_deprecation('a.b', None, 'stdlib')
    assert not load_context.deprecated and not load_context.removal_date and not load_context.removal_version and not load_context.deprecation_warnings

    # empty dict is passed as the deprecation argument
    load_context = PluginLoadContext()
    load_context.record_deprecation('a.b', {}, 'stdlib')
    assert not load_context.deprecated and not load_context.removal_date and not load_context.removal_version and not load_context.deprecation_warnings

    # dict with only warning_text is passed as the deprecation argument
    load_context = PluginLoadContext()

# Generated at 2022-06-23 11:16:52.429064
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    TESTING_PATH_FRAGMENT = 'unit_testing!'
    TEST_DIR = 'test__add_dirs_to_loader'
    DEFAULT_PATH_FRAGMENT = 'ANSIBLE_'

    test_loader = PluginLoader('TestName', 'TestModule', '', '')

    assert test_loader.directories == set()
    assert test_loader.paths == []

    # Add a directory and make sure it shows up
    test_loader.add_directory(TEST_DIR)
    assert test_loader.directories == {TEST_DIR}
    assert test_loader.paths == [TEST_DIR + '*']

    # Add a directory and make sure no changes
    test_loader.add_directory(TEST_DIR)
    assert test_loader.directories == {TEST_DIR}

# Generated at 2022-06-23 11:16:56.758642
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    p = PluginLoader("module")
    plugin_cache = {'/path/to/plugins/module/name.py': object()}
    p._module_cache = plugin_cache
    assert p.__repr__() == "PluginLoader(module,<{0}>,['{1}'])".format(plugin_cache, p.package_path)


# Generated at 2022-06-23 11:17:09.245950
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    class DummyClass(object):
        def __init__(self, *args, **kwargs):
            pass

    def plugin_load_context_nope(msg):
        class DummyClass2(DummyClass):
            def __init__(self, msg):
                self.msg = msg
        return DummyClass2(msg)

    class DummyClass3(DummyClass):
        def __init__(self, candidate_fqcr):
            self.candidate_fqcr = candidate_fqcr

    class DummyClass4(DummyClass):
        def __init__(self, name):
            self.name = name

    class DummyClass5(DummyClass):
        def __init__(self, path):
            self.path = path


# Generated at 2022-06-23 11:17:12.570793
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
  PL = PluginLoader(package='foo', class_name='bar', config=None, basedir=None, subdir=None)
  assert repr(PL) == '<ansible.plugins.loader.PluginLoader foo.bar>'


# Generated at 2022-06-23 11:17:20.357528
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    import ansible.plugins.filter.core as core
    import ansible.plugins.test.core as core
    a = PluginLoader("action", "ActionModule", "ansible.plugins.action", C.DEFAULT_INVENTORY_ENABLED_GROUP_PREFIXES)
    b = PluginLoader("cache", "CacheModule", "ansible.plugins.cache", C.DEFAULT_INVENTORY_ENABLED_GROUP_PREFIXES)
    c = PluginLoader("callback", "CallbackModule", "ansible.plugins.callback", C.DEFAULT_INVENTORY_ENABLED_GROUP_PREFIXES)

# Generated at 2022-06-23 11:17:26.150547
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    import ansible.plugins.cache as cache_module
    import ansible.plugins.filter.core as core_module

    # The jinja2 filters in each file (updated in reverse order).
    # The first file will be list, the second file will be dunder_list
    deduped_filters_1 = []
    deduped_filters_2 = []

    # The jinja2 filters in each file (in reverse order because of the way the plugin loader will work).
    # This one is not deduped.
    filters_2 = []

    # Manually create a few objects
    # We set up a few files in the directory.  One will contain "list" and "dunder_list".
    # The calling code will deduplicate these when adding them so we can duplicate them here.
    # The second file will contain the

# Generated at 2022-06-23 11:17:37.224763
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    if 'test_get_all_plugin_loaders' not in globals():
        globals()['test_get_all_plugin_loaders'] = PluginLoader('testtype', 'test_get_all_plugin_loaders', '', '', '')
    assert len([x[0] for x in get_all_plugin_loaders() if x[0] == 'test_get_all_plugin_loaders']) >= 1
    del globals()['test_get_all_plugin_loaders']
    assert len([x[0] for x in get_all_plugin_loaders() if x[0] == 'test_get_all_plugin_loaders']) == 0


# TODO: add unit tests for the various exceptions in all_* functions

# TODO: use a factory class for instantiating plugins, so we can

# Generated at 2022-06-23 11:17:46.284275
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell = get_shell_plugin()
    assert shell is not None
    shell = get_shell_plugin(shell_type='sh')
    assert shell is not None
    shell = get_shell_plugin(shell_type='csh')
    assert shell is not None
    shell = get_shell_plugin(shell_type='fish')
    assert shell is not None
    shell = get_shell_plugin(shell_type='ksh')
    assert shell is not None
    shell = get_shell_plugin(shell_type='bash')
    assert shell is not None
    shell = get_shell_plugin(shell_type='powershell', executable='powershell.exe')
    assert shell is not None
    # Get shell for executable
    shell = get_shell_plugin(executable='/bin/bash')
    assert shell is not None