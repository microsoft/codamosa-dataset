

# Generated at 2022-06-23 11:07:46.205803
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    result = PluginLoader("**", "**", "**").find_plugin_with_context("**")
    assert result.plugin_resolved_name == "**"
    assert result.plugin_resolved_path is None
    assert result.resolved is False
    assert result.bypassed is False
    assert result.nope_reason is None

# Generated at 2022-06-23 11:07:54.728176
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # Initialize
    argspec = inspect.getfullargspec(PluginLoader.all)
    assert argspec.args == ['self', '_dedupe', 'path_only', 'class_only']
    assert argspec.varargs == 'args'
    assert argspec.varkw == 'kwargs'
    assert argspec.defaults == (True, False, False)
    assert argspec.kwonlyargs == []
    assert argspec.kwonlydefaults == None
    assert argspec.annotations == {}
    # Execute
    result = PluginLoader.all(**{'_dedupe': True, 'path_only': False, 'class_only': False})

# Generated at 2022-06-23 11:07:58.415142
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():

    test_paths = ['/tmp/ansible/modules', '/tmp/ansible/lookup_plugins']
    test_loader = 'lookup'
    check_if_add_dirs_to_loader_work(test_loader, test_paths)


# Generated at 2022-06-23 11:08:01.202784
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    try:
        PluginLoadContext().nope("test message")
    except:
        assert True
    else:
        assert False


# Generated at 2022-06-23 11:08:10.913617
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    # Constructor for ActionModuleLoader
    for ext in C.DEFAULT_ACTION_PLUGIN_WHITELIST:
        ActionModuleLoader(ext)

    # Constructor for CacheModuleLoader
    CacheModuleLoader()

    # Constructor for CallbackModuleLoader
    CallbackModuleLoader()

    # Constructor for ConnectionModuleLoader
    ConnectionModuleLoader()

    # Constructor for FilterModuleLoader
    FilterModuleLoader()

    # Constructor for LookupModuleLoader
    LookupModuleLoader()

    # Test the __contains__() method
    # AnsibleModuleLoader base class expects module_utils as first argument
    assert 'ansible.module_utils.basic' in AnsibleModuleLoader('ansible.module_utils.basic', 'basic')

    # Constructor for StrategyModuleLoader
    StrategyModuleLoader()

    # Constructor for TestModuleLoader


# Generated at 2022-06-23 11:08:15.976240
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    p = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS, C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS)
    assert p.get('ping', 'ping') == ping


# Generated at 2022-06-23 11:08:25.247710
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    '''assert that get_all_plugin_loaders returns a list of tuples'''
    # Setup: Create a dummy module and a new plugin loader
    fake_mod = sys.modules.get('ansible.plugins.test_get_all_plugin_loaders')
    if fake_mod:
        del sys.modules['ansible.plugins.test_all_plugin_loaders']
    dummy_loader = PluginLoader('test_get_all_plugin_loaders', 'ansible.plugins.test_get_all_plugin_loaders')

    # Test: Ensure that the dummy loader is there
    all_loaders = get_all_plugin_loaders()
    assert (dummy_loader.package, dummy_loader) in all_loaders

    # Teardown: Delete the dummy module

# Generated at 2022-06-23 11:08:29.893921
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    loader = PluginLoader('ansible.plugins.cache', 'CacheModule', 'setup', 'ansible.module_utils.basic.AnsibleModule')

    class_only = True
    class_only = False
    expeceted_result = None
    result = loader.get('nope', class_only=class_only)
    assert result == expeceted_result

# Generated at 2022-06-23 11:08:38.643274
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    # pylint: disable=undefined-variable
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # pylint: disable=unused-argument
    def dummy_object():
        pass
    # pylint: enable=unused-argument
    module_name = 'ansible_collections.acme.test1.plugins.module.dummy'
    new_object = type(module_name, (dummy_object, ), {})
    sys.modules[module_name] = new_object
    module_path = dict()
    module_path["collection"] = "ansible_collections.acme.test1"
    module_path["name"] = 'plugins.module.dummy'
    module_path["subdir"] = "modules"
   

# Generated at 2022-06-23 11:08:50.608628
# Unit test for method find_plugin_with_context of class PluginLoader

# Generated at 2022-06-23 11:08:58.986308
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    context = PluginLoadContext()
    assert(context.original_name is None)
    assert(context.redirect_list == [])
    assert(context.error_list == [])
    assert(context.load_attempts == [])
    assert(context.pending_redirect is None)
    assert(context.exit_reason is None)
    assert(context.plugin_resolved_path is None)
    assert(context.plugin_resolved_name is None)
    assert(context.plugin_resolved_collection is None)
    assert(context.deprecated == False)
    assert(context.removal_date is None)
    assert(context.removal_version is None)
    assert(context.deprecation_warnings == [])
    assert(context.resolved == False)

# Generated at 2022-06-23 11:09:03.436271
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    # obj = PluginLoadContext
    obj = PluginLoadContext()
    assert obj.original_name is None
    assert obj.redirect_list == []
    assert obj.error_list == []
    assert obj.import_error_list == []
    assert obj.load_attempts == []
    assert obj.pending_redirect is None
    assert obj.exit_reason is None
    assert obj.plugin_resolved_path is None
    assert obj.plugin_resolved_name is None
    assert obj.plugin_resolved_collection is None
    assert not obj.deprecated
    assert obj.removal_date is None
    assert obj.removal_version is None
    assert obj.deprecation_warnings == []
    assert not obj.resolved



# Generated at 2022-06-23 11:09:04.500449
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    assert False, "Test not implemented"



# Generated at 2022-06-23 11:09:05.861370
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    # TODO: implement unit test
    pass



# Generated at 2022-06-23 11:09:10.137067
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    ctx = PluginLoadContext()
    ctx.resolve('a', 'b', 'c', 'd')
    assert ctx.plugin_resolved_name == 'a'
    assert ctx.plugin_resolved_path == 'b'
    assert ctx.plugin_resolved_collection == 'c'
    assert ctx.pending_redirect is None
    assert ctx.exit_reason == 'd'
    assert ctx.resolved is True

# Generated at 2022-06-23 11:09:15.330434
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    """Test PluginLoadContext.nope()"""

    error_string = "Error message"
    plugin_load_context = PluginLoadContext()

    plugin_load_context = plugin_load_context.nope(error_string)
    assert plugin_load_context.exit_reason == error_string
    assert plugin_load_context.resolved == False



# Generated at 2022-06-23 11:09:18.995223
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    module = sys.modules[__name__]
    m = module.get_all_plugin_loaders
    result = m()
    assert result[0][0] == 'action'
    assert result[0][1].__class__.__name__ == 'ActionPluginLoader'



# Generated at 2022-06-23 11:09:31.617592
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    """Performs unit tests for method format_paths of class PluginLoader."""
    plugin_paths = ["/usr/lib/python2.7/dist-packages/ansible/plugins/action.py",
                    "/usr/share/ansible/plugins/action.py",
                    "/home/user/ansible_plugins/action.py"]

    expected_results = ["/usr/lib/.../ansible/plugins/action.py",
                        "/usr/share/.../ansible/plugins/action.py",
                        "/home/user/.../ansible/plugins/action.py"]

    plugin_loader = PluginLoader("action", plugin_paths)
    actual_results = plugin_loader.format_paths(plugin_paths)
    assert actual_results == expected_results


# Generated at 2022-06-23 11:09:40.494664
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    assert PluginLoader.print_paths.__doc__ is not None
    assert PluginLoader.print_paths.__dict__ is not None
    assert isinstance(PluginLoader.print_paths, types.FunctionType)
    assert isinstance(PluginLoader.print_paths.__code__, types.CodeType)
    assert isinstance(PluginLoader.print_paths.__code__.co_argcount, int)
    assert isinstance(PluginLoader.print_paths.__code__.co_consts, tuple)
    assert isinstance(PluginLoader.print_paths.__code__.co_varnames, tuple)
    assert isinstance(PluginLoader.print_paths.__code__.co_filename, str)
    assert isinstance(PluginLoader.print_paths.__code__.co_name, str)

# Generated at 2022-06-23 11:09:47.053737
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    assert Jinja2Loader().package == 'ansible.plugins.filter'
    assert Jinja2Loader().subdir == 'filter_plugins'
    assert Jinja2Loader().base_class == 'FilterModule'
    assert Jinja2Loader().class_name == 'FilterModule'
    assert Jinja2Loader().paths == [
        'ansible/plugins/filter_plugins',
        'ansible/plugins/filter_plugins/deprecated',
        'ansible/plugins/filter_plugins/modules',
        'ansible/plugins/filter_plugins/modules/deprecated',
        'ansible/plugins/filter_plugins/extras',
    ]
    assert Jinja2Loader().paths_hash == hash('ansible/plugins/filter_plugins')

# Generated at 2022-06-23 11:09:57.145286
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    # body of plugin_load_context
    plc = PluginLoadContext()
    assert plc.original_name is None
    assert plc.redirect_list == []
    assert plc.error_list == []
    assert plc.import_error_list == []
    assert plc.load_attempts == []
    assert plc.pending_redirect is None
    assert plc.exit_reason is None
    assert plc.plugin_resolved_path is None
    assert plc.plugin_resolved_name is None
    assert plc.plugin_resolved_collection is None
    assert plc.deprecated is False
    assert plc.removal_date is None
    assert plc.removal_version is None
    assert plc.deprecation_warnings == []
    assert plc.res

# Generated at 2022-06-23 11:10:05.941546
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    plugin_loader = PluginLoader(base_class=None, class_name=None, package=None, config=None, subdir=None)
    plugin_loader.__setstate__(pickle.dumps({'names': [1], 'paths': [1], 'package': 1, 'config': 1, 'subdir': 1}))
    assert plugin_loader.names == [1]
    assert plugin_loader.paths == [1]
    assert plugin_loader.package == 1
    assert plugin_loader.config == 1
    assert plugin_loader.subdir == 1

# Generated at 2022-06-23 11:10:15.158417
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    '''
    Test PluginLoader.find_plugin with examples.
    '''

    from ansible.utils.path import unfrackpath

    module_loader = PluginLoader(
        "Module",
        "ansible.plugins.loader",
        C.DEFAULT_MODULE_PATH,
        'module',
        required_base_class="AnsibleModule"
    )

    # Test with a builtin module name that is not a subfolder
    assert unfrackpath(module_loader.find_plugin("ping"), follow=False) == os.path.join(unfrackpath(C.DEFAULT_MODULE_PATH, follow=False), "network", "ping.py")
    # Test with a builtin module name that is a subfolder
    assert unfrackpath(module_loader.find_plugin("systemd"), follow=False) == os

# Generated at 2022-06-23 11:10:22.059731
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    pl = PluginLoader("test", './test_utils/plugins')
    plugin_info = pl._get_paths()
    assert "./test_utils/plugins" in plugin_info
    assert len(pl._get_paths()) == 2
    assert "./test_utils/myplugins" in pl._get_paths()
    pl.add_directory("./test_utils/myplugins2")
    assert len(plugin_info) == 3
    assert "./test_utils/myplugins2" in pl._get_paths()


# Generated at 2022-06-23 11:10:24.845267
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    host = PluginLoader()
    host.module_utils_path = None
    host.__setstate__({'package': 'ansible.plugins.connection'})
    assert host.package == 'ansible.plugins.connection'


# Generated at 2022-06-23 11:10:36.897996
# Unit test for method record_deprecation of class PluginLoadContext

# Generated at 2022-06-23 11:10:46.270626
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    import ansible.plugins.loader
    plugin_loaders = ansible.plugins.loader.get_all_plugin_loaders()
    assert len(plugin_loaders) > 0
    assert isinstance(plugin_loaders[0], tuple)
    assert isinstance(plugin_loaders[0][0], string_types)
    assert issubclass(plugin_loaders[0][1], PluginLoader)

# Note: this class is a refactoring of the magic used in utils.plugins.
# Any changes or fixes here may need to be ported over to that module.

# Generated at 2022-06-23 11:10:54.331623
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    test_path = '/home/xyz'
    add_dirs_to_loader('module', [test_path])
    paths = module_loader.paths
    assert test_path in paths

# Note to self: do not add _loader to the end of the variable name.
#   It gets masked by the property

# Generated at 2022-06-23 11:11:07.243849
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    # Test for compat
    shell_loader.load_plugin('sh')
    shell = get_shell_plugin(executable='sh')
    assert shell.SHELL_FAMILY == 'sh'

    shell = get_shell_plugin(executable='bash')
    assert shell.SHELL_FAMILY == 'sh'

    shell = get_shell_plugin(executable='csh')
    assert shell.SHELL_FAMILY == 'csh'

    # Test for explicit shell_type
    shell = get_shell_plugin(shell_type='fish')
    assert shell.SHELL_FAMILY == 'fish'

    # Test for invalid executable
    shell = get_shell_plugin(shell_type='csh', executable='invalid_shell')
    assert shell.SHELL_FAMILY == 'csh'



# Generated at 2022-06-23 11:11:10.025015
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():

    j2ldr = Jinja2Loader('ansible.legacy.plugins.filter', class_name='FilterModule')

    # Iterate through all the files
    for i in j2ldr.all():
        pass



# Generated at 2022-06-23 11:11:20.982569
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    from ansible.parsing.dataloader import DataLoader
    loader = Jinja2Loader(
        'ansible.plugins.filter_plugins',
        'ansible.plugins.tests.test_filter_loader.TestFilters',
        '',  # package_path
        'ansible.plugins.filter.core',  # config_base
        config=Config(False, False),
        loader=DataLoader()
    )

    from ansible.plugins.filter.core import flatten
    assert isinstance(loader.all(), list)
    assert loaded_classes_count(loader.all()) == 2
    assert set(loader.all()) == set((flatten,))



# Generated at 2022-06-23 11:11:31.286299
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    '''
    Unit test for method __getstate__ of class PluginLoader
    '''
    from ansible.plugins.loader import PluginLoader

    import os.path
    import sys

    _temp = sys.modules['ansible.plugins.loader']
    _temp2 = os.path.join('my', 'path', 'to', 'ansible')
    _temp3 = {'my.path.to.ansible': _temp2}
    _temp4 = '/my/path/to/ansible/modules/network/fortios'
    _temp5 = _temp3.copy()
    _temp6 = 'module'
    _temp7 = os.path.join('my', 'path', 'to', 'ansible', 'modules', 'network', 'fortios', '__init__.py')

# Generated at 2022-06-23 11:11:39.181957
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    config = ConfigParser()
    config.read(["/etc/ansible/ansible.cfg"])
    config._sections['defaults']['action_plugins'] = './lib/ansible/plugins/action'
    config._sections['defaults']['cache_plugins'] = './lib/ansible/plugins/cache'
    config._sections['defaults']['callback_plugins'] = './lib/ansible/plugins/callback'
    config._sections['defaults']['cliconf_plugins'] = './lib/ansible/plugins/cliconf'
    config._sections['defaults']['connection_plugins'] = './lib/ansible/plugins/connection'
    config._sections['defaults']['filter_plugins'] = './lib/ansible/plugins/filter'

# Generated at 2022-06-23 11:11:44.765294
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    class TestPluginLoader(PluginLoader):
        pass
    test_instance = TestPluginLoader()
    globals()['test_instance'] = test_instance
    try:
        assert(get_all_plugin_loaders() == [('test_instance', test_instance)])
    finally:
        del globals()['test_instance']



# Generated at 2022-06-23 11:11:55.397844
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, Mock, MagicMock
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_bytes
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import PluginLoader, PluginNotFound
    from ansible.utils.collection_list import CollectionList

    # Note
    # Collection plugins are tested via the unit tests for ActionModule and Connection:
    # test_module_load_dynamically works with a variety of connection and module plugins
    # test_collections_lookup_plugins tests a variety of lookup plugins
    # test_connection_loading and test_module_loading test the loading of connection and module plugins


# Generated at 2022-06-23 11:12:05.441340
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    plugin_load_context = PluginLoadContext()
    assert plugin_load_context.pending_redirect is None
    assert plugin_load_context.resolved is False
    context = plugin_load_context.nope('exit_reason')
    assert context.exit_reason == 'exit_reason'
    assert context.pending_redirect is None
    assert context.resolved is False

    import ansible_collections.test.not_a_real_one.plugins.modules.my_test

    context = plugin_load_context.resolve('ansible_collections.test.not_a_real_one.plugins.modules.my_test',
                                          '/xxxx',
                                          'ansible_collections.test.not_a_real_one',
                                          'exit_reason')
    assert context.plugin_

# Generated at 2022-06-23 11:12:16.158421
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    test_plugin_name = 'Test_plugin'
    test_plugin_redirect = 'Test_plugin_redirect'
    exit_reason = 'Redirect from' + test_plugin_name + ' to ' + test_plugin_redirect
    test_pluginloadcontext = PluginLoadContext()
    test_pluginloadcontext.original_name = test_plugin_name
    test_pluginloadcontext = test_pluginloadcontext.redirect(test_plugin_redirect)
    assert(test_pluginloadcontext.pending_redirect == test_plugin_redirect)
    assert(test_pluginloadcontext.exit_reason == exit_reason)
    assert(test_pluginloadcontext.resolved == False)


# Generated at 2022-06-23 11:12:23.274997
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    loader = PluginLoader(class_name='', package='ansible.plugins.connection', config=None, subdir=None, aliases=None, required_base_class=None)
    plugin_load_context = loader.find_plugin_with_context('local', collection_list=None)
    assert plugin_load_context.resolved
    assert plugin_load_context.plugin_resolved_name == 'local'
    assert plugin_load_context.plugin_resolved_path.endswith('local.py')


# Generated at 2022-06-23 11:12:33.971611
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    warning_text = "This is a test."
    removal_date = "01/01/01"
    removal_version = "1.0.0"
    name = "test_plugin"
    collection_name = "test_collection"

    test = PluginLoadContext()
    test.record_deprecation(name, {"warning_text": warning_text, "removal_date": removal_date, "removal_version": removal_version}, collection_name)

    assert test.deprecation_warnings[0] == "{0} has been deprecated. {1}".format(name, warning_text)
    assert test.removal_date == removal_date
    assert test.removal_version == removal_version
    assert test.deprecated


# Generated at 2022-06-23 11:12:38.885379
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    plugin_loader = PluginLoader(
        'ansible.plugins.windows',
        '.ps1',
        'WindowsModule',
        '_windows',
        ['windows_modules'],
        C.DEFAULT_MODULE_PATH
    )
    name = 'win_shell'
    collection_list = 'collections.list'
    result = plugin_loader.has_plugin(name, collection_list)
    assert result is False


# Generated at 2022-06-23 11:12:46.738057
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    c = PluginLoadContext()
    c.original_name = 'fqcn'
    c.resolve('fqcn', 'path', 'ansible.builtin', 'reason')
    assert c.plugin_resolved_name == 'fqcn'
    assert c.plugin_resolved_path == 'path'
    assert c.plugin_resolved_collection == 'ansible.builtin'
    assert c.exit_reason == 'reason'
    assert c.resolved



# Generated at 2022-06-23 11:12:47.932512
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    pass


# Generated at 2022-06-23 11:12:56.991143
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    loader = PluginLoader(package='ansible.plugins.test', class_name='TestClass', base_class='BaseClass')
    assert loader.find_plugin('foo') is None
    assert loader.find_plugin('foo', collection_list=['not_a_collection']) is None
    assert loader.find_plugin('ansible.plugins.test.foo', collection_list=['not_a_collection']).plugin_resolved_path.endswith('/test_test_class_foo.py')
    assert loader.find_plugin('ansible.plugins.test.foo', collection_list=['not_a_collection']).plugin_resolved_name == 'ansible.plugins.test.foo'

# Generated at 2022-06-23 11:13:02.143146
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    plugin_loader=PluginLoader('foo', 'bar', 'baz', 'qux')
    output_repr = plugin_loader.__repr__()
    assert isinstance(output_repr, str)
    assert output_repr == "PluginLoader('foo', 'bar', 'baz', 'qux')"


# Generated at 2022-06-23 11:13:10.084148
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    test_plugin_loader = PluginLoader(package='test_package', subdir='test_subdir', aliases={}, class_name='test_class_name')
    test_plugin_loader._searched_paths = ['TestPath1', 'TestPath2']
    test_plugin_loader._module_cache = {'TestModule1': 'TestModule1Module', 'TestModule2': 'TestModule2Module'}
    test_plugin_loader.base_class = 'test_base_class'
    test_plugin_loader.package = 'test_package'
    test_plugin_loader.subdir = 'test_subdir'
    test_plugin_loader.class_name = 'test_class_name'

    assert test_plugin_loader.find_plugin('TestPlugin2') == ('TestPlugin2', 'TestModule2')

# Generated at 2022-06-23 11:13:17.085322
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    plugin_loader = PluginLoader(
        'ansible.plugins.test',
        'TestPlugins',
        'ansible/plugins/test',
        '*.py'
    )
    try:
        # test print_paths normal
        plugin_loader.print_paths()
    except Exception as ex:
        assert 'No handlers could be found for logger' in str(ex)


# Generated at 2022-06-23 11:13:21.102658
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # set up the mocks

    # initialize the class
    plugin_loader = PluginLoader()
    # assertEquals(expected, plugin_loader.get_with_context(name, *args, **kwargs))
    raise NotImplementedError()


# Generated at 2022-06-23 11:13:23.353732
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # TODO: implement test get_with_context of PluginLoader
    raise NotImplementedError()

# Generated at 2022-06-23 11:13:26.752122
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    # Test __init__() with no argument, should set 'error' as None
    r = get_with_context_result()
    assert r.get('error') is None

    # Test __init__() with one argument, should set 'error' as the argument
    r = get_with_context_result('Some error')
    assert r.get('error') == 'Some error'

# Generated at 2022-06-23 11:13:34.194593
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():

    import ansible.plugins.loader
    plugin_loader = ansible.plugins.loader.PluginLoader(
        class_name='FooLoader',
        base_class='ansible.plugins.cache.FooCacheModule',
        package='ansible.plugins.cache',
        configurable=True,
    )

    plugin_loader.subdir = 'subdir'

    assert_equals(plugin_loader.__getstate__(), {
        'class_name': 'FooLoader',
        'base_class': 'ansible.plugins.cache.FooCacheModule',
        'package': 'ansible.plugins.cache',
        'configurable': True,
        'subdir': 'subdir',
    })


# Generated at 2022-06-23 11:13:43.267937
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plc = PluginLoadContext()
    # Check for attribute location
    attributes = ['_resolved_fqcn', 'deprecated', 'deprecation_warnings', 'exit_reason', 'error_list', 'import_error_list',
                  'load_attempts', 'original_name', 'pending_redirect', 'plugin_resolved_path', 'plugin_resolved_name',
                  'plugin_resolved_collection', 'removal_date', 'removal_version', 'redirect_list', 'resolved']
    for attribute in attributes:
        assert hasattr(plc, attribute), "PluginLoadContext missing '{0}' attribute".format(attribute)



# Generated at 2022-06-23 11:13:50.621208
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    #
    # setup
    #
    # Make paths that are not in the Ansible library path
    my_lib_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
    my_modules_dir = os.path.join(my_lib_dir, 'test_utils', 'plugins', 'modules')
    my_action_plugins_dir = os.path.join(my_lib_dir, 'test_utils', 'plugins', 'action_plugins')
    display.verbosity = 4

    # Get module and action plugin directories
    module_dirs = PATH_CACHE['module_utils'][:]
    module_dirs.extend(C.DEFAULT_MODULE_PATH)
    action_plugin_dirs = PATH_CACHE

# Generated at 2022-06-23 11:13:51.271868
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    pass

# Generated at 2022-06-23 11:13:59.140274
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    # Test string as state
    obj = PluginLoader()
    obj.__setstate__("some string")
    assert obj.package == "some string"

    # Test dict as state
    obj = PluginLoader()
    obj.__setstate__({"package": "another string"})
    assert obj.package == "another string"

    # Test broken state
    obj = PluginLoader()
    with pytest.raises(AnsiblePluginError):
        obj.__setstate__(42)


# Generated at 2022-06-23 11:14:12.293675
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    l = PluginLoader('Test', 'test_plugins', 'TestPlugin', 'test_module', 'test_package')
    l.set_find_plugins_in_cwd_enabled(True)

    args = (1, 2, 'a')
    kwargs = {'b': 3}

    instance = l.get('test_module', *args, **kwargs)
    assert instance.__class__.__name__ == 'TestModule'
    assert instance.called == True
    for i in range(len(args)):
        assert instance.args[i] == args[i]

    assert instance.kwargs == kwargs
    assert instance.kwargs == kwargs

    state = pickle.dumps(l)


# Generated at 2022-06-23 11:14:16.386658
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    print("test: construct plugin loader")
    plugins = PluginLoader('ActionModule', 'ansible.plugins.action', C.DEFAULT_ACTION_PLUGIN_PATH, require_init=False)
    print("plugin action names: %s" % plugins.all())



# Generated at 2022-06-23 11:14:28.348985
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    def _assert_paths_as_expected(paths_given, paths_expected):
        pl = PluginLoader('')
        assert pl.format_paths(paths_given) == paths_expected

    test_cases = dict()
    test_cases[0] = {'paths_given': [], 'paths_expected': ''}
    test_cases[1] = {'paths_given': ['/path/one'], 'paths_expected': '/path/one'}
    test_cases[2] = {'paths_given': ['/path/one', '/path/two'], 'paths_expected': '/path/one:/path/two'}

# Generated at 2022-06-23 11:14:37.177052
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    context = PluginLoadContext()
    context.record_deprecation('a', {'warning_text': 'b'}, 'c')
    context.record_deprecation('d', {'removal_date': 'e'}, 'f')
    context.record_deprecation('g', {'removal_version': 'h'}, 'i')
    assert context.deprecated
    assert context.removal_date == 'e'
    assert context.removal_version == 'h'
    assert context.deprecation_warnings == ['a has been deprecated. b', 'd has been deprecated. ', 'g has been deprecated. ']



# Generated at 2022-06-23 11:14:38.532789
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    # TODO: add unit test for print_paths method
    assert False

# Generated at 2022-06-23 11:14:41.374455
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    assert(PluginLoader('foo', 'bar') == ({}, ['bar'], 'foo'))


# Generated at 2022-06-23 11:14:52.009339
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    '''
    Unit test for method find_plugin_with_context of class PluginLoader
    '''
    # TODO: static dependency on compiled_collections_path
    # TODO: static dependency on role_data_path
    # TODO: static dependency on collections_path
    # TODO: static dependency on plugin_dirs
    # TODO: Do we need to fetch config to parse collections_paths?
    config = {}
    plugin_loader = PluginLoader(config=config, package='ansible.plugins.lookup', subdir='lookup_plugins', config_base=None, class_name='LookupModule', aliases={}, required_base_class='LookupBase', injectors={})

# Generated at 2022-06-23 11:15:04.219926
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    plc = PluginLoadContext()
    # Test case: no deprecation information
    deprecation1 = {}
    plc.record_deprecation('name1', deprecation1, 'collection_name')
    assert plc.deprecated is False
    assert plc.removal_date is None
    assert plc.removal_version is None
    assert plc.deprecation_warnings == []
    # Test case: deprecation information exists, but removal date and removal version are both missing
    deprecation2 = {'warning_text': 'warning1'}
    plc.record_deprecation('name2', deprecation2, 'collection_name')
    assert plc.deprecated is True
    assert plc.removal_date is None
    assert plc.removal_version is None

# Generated at 2022-06-23 11:15:10.010775
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    loader_name = 'shell'
    paths = ['modules/shell/']
    add_dirs_to_loader(loader_name, paths)
    loader = loaders['shell']
    assert(paths[0] in loader._get_paths())

# Backwards compat / alias
add_dir_to_loader = add_dirs_to_loader


# Generated at 2022-06-23 11:15:22.928013
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    plugin_loader = PluginLoader(
        'unit_test',
        'base_class',
        'docstring',
        'c.b.a',
        'cls',
        'subdir',
        required_base_class=None,
    )

    class DummyClass(object):
        ''' Helper class '''


# Generated at 2022-06-23 11:15:26.701195
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    # create a PluginLoader with default args
    plugin_loader = PluginLoader()

    # verify that plugin_loader.has_plugin is False, when name is not in the container
    assert not plugin_loader.has_plugin('name')

    # verify that plugin_loader.has_plugin is True, when name is in the container
    assert plugin_loader.has_plugin('name')


# Generated at 2022-06-23 11:15:36.855874
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    loader = Jinja2Loader('ansible.plugins.loader', 'Test', '', '', config=None)
    collection_list = [
        'ansible.builtin',
        'ansible.collections.somespace.somemod.somecollection',
        'my.collection',
        'ansible.collections.somespace.somemod.somecollection2',
        'ansible.collections.somespace.somemod.somecollection3',
    ]
    try:
        loader.find_plugin('not.a.filter')
    except AnsibleError:
        pass
    else:
        assert False, 'AnsibleError should be raised'

    # plugin_name is fully qualified collection resource

# Generated at 2022-06-23 11:15:41.223261
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    p = PluginLoader('')
    p.test_setstate_state = {PluginLoader.__setstate__.__name__: None}
    p.__setstate__(None)
    assert False, "Test with assert"


# Generated at 2022-06-23 11:15:45.008832
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    # skip the one that is a class
    assert 'PluginLoader' not in [x[0] for x in get_all_plugin_loaders()]



# Generated at 2022-06-23 11:15:50.304837
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
  loader = PluginLoader(class_name='string', package='string', directories=[])
  state = {'aliases': {}, '_caching_for': 0, '_caching_hash': 'string', '_caching_plugin': 'string'}
  loader.__setstate__(state)


# Generated at 2022-06-23 11:15:58.377047
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    # 1. test no deprecation
    deprecation = {}
    plc = PluginLoadContext()
    plc.record_deprecation('test_name', deprecation, 'test_collection_name')
    assert plc.deprecation_warnings == []
    assert plc.deprecated == False

    # 2. test deprecation
    deprecation = {'warning_text': 'This is a warning text.'}
    plc = PluginLoadContext()
    plc.record_deprecation('test_name', deprecation, 'test_collection_name')
    assert plc.deprecation_warnings == ['test_name has been deprecated. This is a warning text.']
    assert plc.deprecated == True


# Generated at 2022-06-23 11:16:07.616515
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    p = PluginLoadContext()
    assert p.resolve('resolved_name', 'resolved_path', 'resolved_collection', 'exit_reason') == p
    assert p.pending_redirect is None
    assert p.plugin_resolved_name == 'resolved_name'
    assert p.plugin_resolved_path == 'resolved_path'
    assert p.plugin_resolved_collection == 'resolved_collection'
    assert p.exit_reason == 'exit_reason'
    assert p.resolved is True

# Generated at 2022-06-23 11:16:10.265116
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    obj = PluginLoader()
    assert repr(obj) == '<ansible.utils.plugin_docs.PluginLoader>'


# Generated at 2022-06-23 11:16:18.507392
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():

    loader = Jinja2Loader(configuration.DEFAULT_INTERNAL_FILE_META_OVERRIDE, '*')

    set_collection_path('ansible.legacy')

    for plugin in loader.all():
        # NOTE: This is just a quick check to make sure we don't get any collection plugins,
        # calling code will have a more specific check
        assert 'ansible.legacy' in plugin.__module__

    reset_collection_path()

    # Nothing is currently using this method
    #
    # with pytest.raises(AnsibleError) as err:
    #     loader.get('something')
    #
    # assert 'No code should call "get"' in err.value.message


# Generated at 2022-06-23 11:16:24.367208
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    pl = PluginLoader('ansible.plugins.action', 'ActionModule', C.DEFAULT_INVENTORY_ENABLED_GROUP_PATTERNS, C.DEFAULT_INVENTORY_IGNORED_GROUP_PATTERNS)
    assert pl.has_plugin('ping')



# Generated at 2022-06-23 11:16:25.004429
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    pass



# Generated at 2022-06-23 11:16:31.466502
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    obj = PluginLoader('str')
    args = 'str'
    obj.add_directory(args)  # No error
    args = Path('str')
    obj.add_directory(args)  # No error
    args = Path('')
    obj.add_directory(args)  # No error
    args = 'str'
    obj.add_directory(args)  # No error
    args = Path('str')
    obj.add_directory(args)  # No error
    args = Path('')
    obj.add_directory(args)  # No error


# Generated at 2022-06-23 11:16:41.539234
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    simple_action_loader = PluginLoader(
        'ActionModule',
        'ansible.plugins.action',
        C.DEFAULT_ACTION_PLUGIN_PATH,
        'action_plugins',
        required_base_class='ActionBase'
    )
    obj, plugin_load_context = simple_action_loader.get_with_context('setup', 'playbook', '/var/lib/awx/venv/ansible/ansible.cfg')
    assert_equal(obj._load_name, 'setup')
    assert_equal(obj._redirected_names, [])


# Generated at 2022-06-23 11:16:52.642918
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    import os

    # Test the default case, where the name is not a fully qualified collection reference.
    jl = Jinja2Loader(selfnames='ansible.plugins.filter', package='ansible.plugins.filter', config=None, paths=[os.path.dirname(__file__)])
    plugin = jl.find_plugin('fqdn')
    assert plugin, "We were expecting to find 'fqdn' plugin in jinja2 plugin directory"

    # Test the case where the name is a fully qualified collection reference.
    jl = Jinja2Loader(selfnames='ansible.plugins.filter', package='ansible.plugins.filter', config=None, paths=[os.path.dirname(__file__)])
    plugin = jl.find_plugin('ansible_collections.namespace.collection.fqdn')


# Generated at 2022-06-23 11:17:00.442449
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    from ansible.plugins.loader import PluginLoader
    from ansible.plugins import module_loader
    import ansible.plugins.action.shell
    def test_PluginLoader_all_empty_cache():
        import os
        import tempfile
        temp_dir = tempfile.mkdtemp()
        cd = os.chdir(temp_dir)
        # test that all() runs if self._module_cache is empty
        class MyPL(PluginLoader):
            pass
        pl = MyPL('ansible.plugins.action', 'ActionModule')
        result = list(pl.all())
        assert isinstance(result, list), "'result' has wrong type"
        assert len(result) == 0, "'result' should be empty"
        # cleanup
        os.chdir(cd)
        os.rmdir(temp_dir)
   

# Generated at 2022-06-23 11:17:06.566430
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    plc = PluginLoadContext()
    plc.nope("Exit_reason for not finding the plugin")
    print("Pending redirect ", plc.pending_redirect)
    print("Resolved ", plc.resolved)
    if(plc.exit_reason):
        print("Exit Reason ", plc.exit_reason)



# Generated at 2022-06-23 11:17:07.980539
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    all_output = list(PluginLoader.all())
    assert all_output
    for index, output in enumerate(all_output):
        assert output



# Generated at 2022-06-23 11:17:17.972292
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    result = PluginLoader.get_with_context_result(None, None, None)
    assert result == (None, False)
    result = PluginLoader.get_with_context_result(True, None, None)
    assert result == (None, False)
    result = PluginLoader.get_with_context_result(None, True, None)
    assert result == (None, False)
    result = PluginLoader.get_with_context_result(None, None, True)
    assert result == (None, False)
    result = PluginLoader.get_with_context_result(True, True, True)
    assert result == (True, False)
    result = PluginLoader.get_with_context_result(None, None, {'class_only': True})
    assert result == (None, True)
    result = PluginLoader.get

# Generated at 2022-06-23 11:17:27.028299
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    x=PluginLoadContext()
    a=x.resolve("resolved_name","resolved_path","resolved_collection","exit_reason")
    print("a.pending_redirect:",a.pending_redirect)
    print("a.plugin_resolved_name:",a.plugin_resolved_name)
    print("a.plugin_resolved_path:",a.plugin_resolved_path)
    print("a.plugin_resolved_collection:",a.plugin_resolved_collection)
    print("a.exit_reason:",a.exit_reason)
    print("a.resolved:",a.resolved)

# Generated at 2022-06-23 11:17:38.077189
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    pl = PluginLoader('module_utils', 'ModuleUtilsCore')
    assert isinstance(pl.get_with_context('systemd'), get_with_context_result)
    assert isinstance(pl.get_with_context('systemd').plugin_load_context, get_plugin_loader_context) is True
    assert isinstance(pl.get_with_context('systemd').plugin_load_context.resolved_name, str) is True
    assert isinstance(pl.get_with_context('systemd').plugin_load_context.redirect_list, list) is True
    assert isinstance(pl.get_with_context('systemd').object, getattr(sys.modules[__package__], 'Systemd')) is True

# Generated at 2022-06-23 11:17:46.680413
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    got_plugins = get_all_plugin_loaders()
    assert len(got_plugins) > 0, "get_all_plugin_loaders did not return any items"
    assert len([x for x in got_plugins if isinstance(x, tuple) and len(x) == 2]) == len(got_plugins), "get_all_plugin_loaders returned some items that are not two-element tuples"
    name_set = set([x[0] for x in got_plugins])
    assert len(name_set) == len(got_plugins), "get_all_plugin_loaders returned plugin names that aren't unique"
    for name, plugin_loader in got_plugins:
        assert isinstance(name, (str, unicode)), "get_all_plugin_loaders returned a plugin name that is not a string"