

# Generated at 2022-06-23 11:07:48.093153
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():

    context = PluginLoadContext()
    # test that when deprecation is specified, we get the correct results
    deprecation = {'warning_text': 'sample warning_text', 'removal_version': '9.9.9'}
    assert context.record_deprecation('name', deprecation, 'my_collection') == context
    assert context.removal_version == '9.9.9'
    assert context.removal_date is None
    assert context.deprecation_warnings == ['name has been deprecated. sample warning_text']
    # test that when deprecation is None, we get the correct results
    deprecation = None
    assert context.record_deprecation('name', deprecation, 'my_collection') == context
    assert context.deprecation_warnings is None
    # test that when dep

# Generated at 2022-06-23 11:07:58.379036
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Make sure that duplicates are not added
    loader = PluginLoader(package="foo")
    loader.add_directory(os.path.join(os.path.dirname(__file__), "loading_data"), with_subdir=False)
    loader.add_directory(os.path.join(os.path.dirname(__file__), "loading_data"), with_subdir=False)
    assert len(loader._get_paths()) == 1

    # Make sure that add_directory works with and without with_subdir
    loader = PluginLoader(package="foo")
    loader.add_directory(os.path.join(os.path.dirname(__file__), "loading_data"), with_subdir=False)

# Generated at 2022-06-23 11:08:01.144723
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    """
    Ensure we can initialize the object
    """
    obj = get_with_context_result('test')
    assert obj.name == 'test'
    assert obj.path is None
    assert obj.with_context is None
    assert obj.result is None



# Generated at 2022-06-23 11:08:10.878866
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    plugin_load_context = None
    test_loader = PluginLoader('foo', 'fizz', 'buzz', 'plugin_loader_test')
    test_loader.package = 'ansible.plugins.foo'
    test_loader.aliases = set(['fizzbuzz'])
    test_loader._get_paths = MagicMock()
    test_loader._get_paths.return_value = ['/path/to/plugins']
    test_loader.find_plugin_with_context = Mock()
    test_loader.find_plugin_with_context.return_value = plugin_load_context
    test_loader.find_plugin_with_context.side_effect = TestPluginLoader.find_plugin_with_context(plugin_load_context)

# Generated at 2022-06-23 11:08:11.708651
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    PluginPathContext('test_path', True)



# Generated at 2022-06-23 11:08:14.620835
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    pl = PluginLoader('test_package', 'test_dir', 'test_class_name')
    pl._searched_paths = ['/a/b/c', '/d/e/f']
    exp = '{0}\n{1}'.format('/a/b/c', '/d/e/f')
    assert pl.format_paths() == exp


# Generated at 2022-06-23 11:08:16.830697
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    PluginLoader(package='ansible.plugins.connection')



# Generated at 2022-06-23 11:08:18.111800
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    pass



# Generated at 2022-06-23 11:08:26.855032
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    '''
    Creates an instance of PluginLoader and verify basic attributes
    '''
    pl = PluginLoader('foo', 'foo.plugins', 'ansible.plugins.foo.FooBase')
    assert pl
    assert isinstance(pl, PluginLoader)
    assert pl.package == 'ansible.plugins.foo'
    assert pl.base_class == 'FooBase'
    assert pl.class_name == 'FooBase'
    assert not pl.aliases
    assert pl.subdir == 'foo_plugins'
    assert pl._destroy_plugins_on_exit

    #
    # Try with aliases, None base_class, and disable plugin cleaning at exit
    #

# Generated at 2022-06-23 11:08:28.752373
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    test_pluginloadcontext = PluginLoadContext()
    a = test_pluginloadcontext.nope('pending redirect')
    assert a.pending_redirect == None


# Generated at 2022-06-23 11:08:35.145934
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # Test add_directory without exception
    loader = PluginLoader(package='test_package',
                          directory='test_directory',
                          class_name='test_class_name',
                          base_class='test_base_class')
    loader.add_directory('test_path')
    assert len(loader._paths) == 1
    assert loader._paths == ['test_path']


# Generated at 2022-06-23 11:08:45.982784
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    loader = PluginLoader('foo')
    loader._cz_cache = None
    assert loader.__getstate__() == {'_dir_path': ['foo'], '_dir_path_cache': {}, '_dir_path_cached': False, 'package': 'foo', 'base_class': None, 'class_name': '', 'subdir': '', 'aliases': {}, '_searched_paths': [], '_module_cache': {}, '_plugin_count': 0, '_config_defs': {}, '_cz_cache': None}


# Generated at 2022-06-23 11:08:49.268597
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    my_plugin_loader = PluginLoader('ansible.plugins', 'PluginLoaderTestCase')
    assert 'foobar' in my_plugin_loader
    assert 'bazquux' not in my_plugin_loader


# Generated at 2022-06-23 11:08:53.117068
# Unit test for method record_deprecation of class PluginLoadContext
def test_PluginLoadContext_record_deprecation():
    context = PluginLoadContext()
    assert not context.deprecated
    assert not context.removal_date
    assert not context.removal_version
    assert not context.deprecation_warnings

    context.record_deprecation('test_plugin', {'warning_text': 'Foo bar'}, 'my.collection')
    assert context.deprecated
    assert not context.removal_date
    assert not context.removal_version
    assert context.deprecation_warnings == ['test_plugin has been deprecated. Foo bar']

    context.record_deprecation('test_plugin', {'warning_text': 'Foo bar', 'removal_date': '2019-01-01'}, 'my.collection')
    assert context.deprecated
    assert context.removal_date == '2019-01-01'

# Generated at 2022-06-23 11:08:59.109061
# Unit test for method find_plugin of class PluginLoader
def test_PluginLoader_find_plugin():
    loader = PluginLoader("ansible.plugins.action", "ActionModule", C.DEFAULT_ACTION_PLUGIN_PATH, 'action_plugins', required_base_class="ActionBase")
    plugin = loader.find_plugin("ping")
    assert plugin == 'ansible.plugins.action.ping'

    plugin = loader.find_plugin("non_existing_plugin")
    assert plugin is None

    loader = PluginLoader("ansible.plugins.filter", "FilterModule", C.DEFAULT_FILTER_PLUGIN_PATH, 'filter_plugins', required_base_class="FilterModule")
    plugin = loader.find_plugin("ipaddr")
    assert plugin == 'ansible.plugins.filter.ipaddr'


# Generated at 2022-06-23 11:09:00.951158
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    c = PluginLoadContext()
    c.exit_reason = 'test'
    assert c.exit_reason == 'test'
    c.nope('nope test')
    assert not c.resolved
    assert not c.pending_redirect
    assert c.exit_reason == 'nope test'

# Generated at 2022-06-23 11:09:05.094299
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    # methods that are being tested
    # - find_plugin_with_context
    loader = PluginLoader('ansible.plugins.lookup')
    plugin_load_context = loader.find_plugin_with_context('password', collection_list=None)
    assert plugin_load_context.plugin_resolved_name == 'password'

# Generated at 2022-06-23 11:09:06.088242
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    assert False # TODO: Implement test



# Generated at 2022-06-23 11:09:09.583025
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    # FIXME - this should be a unit test, but we'd need to mock the globals for this to work
    # We can't use the ansible.plugins.__dict__ here because that one already has
    # the plugins from the plugins/ directories into it
    loader_classes = get_all_plugin_loaders()
    assert len(loader_classes) > 0



# Generated at 2022-06-23 11:09:11.288827
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    plugin_load_context=PluginLoadContext()
    plugin_load_context.nope('exit_reason')
    assert plugin_load_context.pending_redirect is None


# Generated at 2022-06-23 11:09:17.595572
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    assert len(shell_loader.all()) == 0

    load_plugins(subdir="shell")
    assert len(shell_loader.all()) == 3

    shell = get_shell_plugin(shell_type='sh')
    assert shell.__class__.__name__ == "ShellModule"

    shell = get_shell_plugin(shell_type='powershell')
    assert shell.__class__.__name__ == "Powershell"

    shell = get_shell_plugin(shell_type='command')
    assert shell.__class__.__name__ == "Command"

    shell = get_shell_plugin(executable='/bin/bash')
    assert shell.__class__.__name__ == "ShellModule"

    shell = get_shell_plugin(executable='/usr/bin/bash')
    assert shell.__class__

# Generated at 2022-06-23 11:09:25.601246
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    x = None
    # From Ansible 2.3
    # The test below is from Ansible 2.3, but has been commented out
    # as it fails in Ansible 2.4 (and the output for the test has been
    # commented out)
#    x = Jinja2Loader(None, None)
#    assert x.get('foo') is None


# Generated at 2022-06-23 11:09:36.871802
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    context = PluginLoadContext()
    context.original_name = 'original_name'
    context.redirect_list = ['redirect_name_1', 'redirect_name_2']
    context.exit_reason = 'pending redirect resolution from original_name to redirect_name_2'
    context.plugin_resolved_name = None
    context.plugin_resolved_path = 'resolved_path'
    context.resolved = False
    context.plugin_resolved_collection = None

    result = context.resolve('resolved_name', 'resolved_path', 'resolved_collection', 'exit_reason')
    assert result.original_name == 'original_name'
    assert result.redirect_list == ['redirect_name_1', 'redirect_name_2']

# Generated at 2022-06-23 11:09:38.548136
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    assert PluginPathContext('path', True)


# Generated at 2022-06-23 11:09:41.954012
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    """
    Unit test for method get of class Jinja2Loader

    :param self:
    :return:
    """
    loader = Jinja2Loader()
    assert loader.get('default') == True



# Generated at 2022-06-23 11:09:43.487561
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    result = PluginLoader.print_paths()
    assert result is None, "Unexpected result, got `%s`" % result


# Generated at 2022-06-23 11:09:47.749513
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    wcr = PluginLoader._get_with_context_result(1, ['error', 'warning'], 2)
    assert wcr.result == 1
    assert wcr.error_list == ['error', 'warning']
    assert wcr.raw_result == 2


# Unit tests for class PluginLoader
# Uses a mock file system with the following layout to test PluginLoader methods
#
# root
# |- collection1
# |  |- plugins
# |  |  |- module_utils    # directory
# |  |  |- filter_plugins  # symlink to ../other_plugins/filter_plugins
# |  |- docs
# |
# |- collection2
# |  |- plugins
# |  |  |- module_utils    # directory
# |  |     |- foo.py       # module_utils file

# Generated at 2022-06-23 11:09:55.695330
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    plugin_loader = PluginLoader(package='ansible.plugins.cache', base_class='BaseCacheModule', class_name='CacheModule')
    plugin_loader.package = 'ansible.plugins.cache'
    plugin_loader.base_class = 'BaseCacheModule'
    plugin_loader.class_name = 'CacheModule'
    actual_results = str(plugin_loader)
    expected_results = '<PluginLoader class_name=CacheModule package=ansible.plugins.cache base_class=BaseCacheModule>'
    assert actual_results == expected_results, "'ansible.plugins.loader.PluginLoader.__repr__()' failed"


# Generated at 2022-06-23 11:10:07.797142
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():

    # Test with a temporary directory
    with tempfile.TemporaryDirectory() as temp_dirname:

        # Test with a temporary file
        with tempfile.NamedTemporaryFile(dir=temp_dirname) as temp_file:
            temp_file.close()

            # Test with a temporary subdirectory
            temp_subdirname = tempfile.mkdtemp(prefix='subdir_', dir=temp_dirname)

            # Test without paths
            assert PluginLoader.print_paths(paths=None) == '<None>'

            # Test with a single path
            assert PluginLoader.print_paths(paths=temp_file.name) == temp_file.name

            # Test with multiple paths

# Generated at 2022-06-23 11:10:15.866768
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():
    with setup_cache_dir() as cache_dir:
        with setup_conf_dir() as conf_dir:
            conf_file = conf_dir + 'ansible.cfg'
            with open(conf_file, 'w') as f:
                f.write("[defaults]\nroles_path=" + cache_dir + "\n")
            os.environ['ANSIBLE_CONFIG'] = conf_file
            loader = PluginLoader('callback')
            callback = Mock()
            callback.name = 'minimal'
            callback.path = cache_dir + 'callback_plugins/minimal.py'
            callback.__package__ = 'ansible.plugins.callback'
            callback.__file__ = cache_dir + 'callback_plugins/minimal.py'
            callback.__loader__ = loader
            # calling constructor
           

# Generated at 2022-06-23 11:10:17.335619
# Unit test for method get_with_context of class PluginLoader
def test_PluginLoader_get_with_context():
    # PluginLoader(*args, **kwargs)
    pass


# Generated at 2022-06-23 11:10:19.459758
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    # Exercise the class definition for PluginLoadContext
    load_context = PluginLoadContext()
    assert isinstance(load_context, PluginLoadContext)



# Generated at 2022-06-23 11:10:27.554408
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    '''
    Test for method __getstate__ of class PluginLoader
    '''
    plugin_loader = AnsiblePluginLoader(b'ansible.plugins.test.test_inner_test', 'AnsiblePlugin', 'faked_base_class', '__init__')

    # Create mock objects
    class_name = b'AnsiblePlugin'
    package = b'ansible.plugins.test.test_inner_test'
    base_class = 'faked_base_class'
    init_name = b'__init__'

    # Call method
    result = plugin_loader.__getstate__()

    # Verify attributes
    assert result['class_name'] == class_name
    assert result['package'] == package
    assert result['base_class'] == base_class
    assert result['init_name'] == init_

# Generated at 2022-06-23 11:10:29.620144
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    p = PluginLoader('', '', '', '', '')
    assert p.print_paths() == ''

# Generated at 2022-06-23 11:10:41.415465
# Unit test for method find_plugin_with_context of class PluginLoader
def test_PluginLoader_find_plugin_with_context():

    # test with collections
    with patch.object(PluginLoader, '_get_package_paths') as mock_paths:
        mock_paths.return_value = [
            'ansible.builtin',
            'collections.testns.collection1',
            'collections.testns.collection2'
        ]
        loader = PluginLoader('action_plugin', 'ansible.plugins.action', C.DEFAULT_ACTION_PLUGIN_PATH, 'action')

        # simple collection file
        test_plugin = loader.find_plugin_with_context('testns.collection1.testns.collection1.action')
        assert test_plugin.resolved
        assert test_plugin.redirect_list == ['testns.collection1.action']

# Generated at 2022-06-23 11:10:43.725782
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    context = PluginPathContext('/tmp/context', False)
    assert context.path == '/tmp/context'
    assert context.internal is False



# Generated at 2022-06-23 11:10:47.849734
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    test_data = []
    for (name, obj) in globals().items():
        if not isinstance(obj, PluginLoader):
            continue
        test_data.append((name, obj))
    assert test_data == get_all_plugin_loaders()



# Generated at 2022-06-23 11:10:49.833331
# Unit test for function add_dirs_to_loader
def test_add_dirs_to_loader():
    new_loader = add_dirs_to_loader("shell", ['/usr/bin/python', '/etc/ansible/plugins/shell'])



# Generated at 2022-06-23 11:10:54.777668
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    name = 'name'

    mocker = Mocker()
    has_plugin_mock = mocker.replace('ansible.errors.AnsibleError')
    has_plugin_mock()
    mocker.result(None)
    mocker.replay()

    pl = PluginLoader(name)
    assert pl.__contains__(name) is None
    mocker.verify()


# Generated at 2022-06-23 11:11:07.753251
# Unit test for method __getstate__ of class PluginLoader
def test_PluginLoader___getstate__():
    '''
    Unit test for method __getstate__ of class PluginLoader
    '''
    import ansible.plugins
    pl = PluginLoader()
    pl._searched_paths = ['.', './plugins/']

    # Test with base_class is set
    pl.base_class = 'ActionBase'
    pl.package = 'ansible.plugins.action'
    pl.class_name = 'ActionBase'
    obj = pl.__getstate__()
    assert obj == {'class_name': 'ActionBase', '_searched_paths': ['./plugins/'], 'base_class': 'ActionBase', 'package': 'ansible.plugins.action'}

    # Test with base_class is None
    pl.base_class = None
    pl.package = 'ansible.plugins.connection'


# Generated at 2022-06-23 11:11:11.961286
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():

    plugin_loader = Jinja2Loader()
    try:
        plugin_loader.find_plugin('stdout')
    except AnsibleError as e:
        assert to_text(e) == 'No code should call "find_plugin" for Jinja2Loaders (Not implemented)'

    try:
        plugin_loader.find_plugin('my_collection.my_plugin')
    except AnsibleError as e:
        assert to_text(e) == 'No code should call "find_plugin" for Jinja2Loaders (Not implemented)'



# Generated at 2022-06-23 11:11:14.136367
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    p = PluginLoader('')
    assert 'PluginLoader' in repr(p)



# Generated at 2022-06-23 11:11:26.308756
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    """
    Check that Jinja2Loader.find_plugin returns the right plugin.
    """
    jinja2_plugin_dir = os.path.join(data_context().content.collection_dir, 'ansible_collections', 'community', 'general', 'plugins', 'filter_plugins')
    jinja2_loader = Jinja2Loader(
        'ansible.plugins.filter',
        'FilterModule',
        os.path.join(jinja2_plugin_dir, '*.py'),
        '',
        'filter'
    )

    # Invalid FQCR
    # NOTE: this is wrong unit test, because it expects the error raised, but
    # the loader will import any collections that are installed, so
    # the functionality of this test is wrong, because 'community.general.plugins.filter_plugins.dict'
   

# Generated at 2022-06-23 11:11:35.977148
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    plc = PluginLoadContext()

    plc.original_name = 'module_utils.module_commons'
    plc.redirect_list = ['module_utils.module_commons_force_override']
    plc.error_list = []
    plc.import_error_list = []
    plc.load_attempts = ['module_utils.module_commons_force_override', 'module_utils.module_commons']
    plc.pending_redirect = None
    plc.exit_reason = None
    plc.plugin_resolved_path = None
    plc.plugin_resolved_name = None
    plc.plugin_resolved_collection = None
    plc.deprecated = False
    plc.removal_date = None
    plc.removal_

# Generated at 2022-06-23 11:11:47.945807
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    # test with an invalid shell type
    try:
        get_shell_plugin(shell_type='unknow')
    except AnsibleError:
        pass
    else:
        assert False

    # test with an valid shell type and with an invalid executable
    shell = get_shell_plugin(shell_type='csh')
    assert shell.SHELL_FAMILY == 'csh'

    # test with an valid shell type and with a valid executable
    shell = get_shell_plugin(shell_type='sh', executable='/usr/bin/sh')
    assert shell.SHELL_FAMILY == 'sh'
    assert shell.executable == '/usr/bin/sh'

    # test without an shell type nor a shell executable
    try:
        get_shell_plugin()
    except AnsibleError:
        pass

# Generated at 2022-06-23 11:11:51.925974
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    loader = PluginLoader('ansible.plugins.connection', 'ConnectionBase', C.DEFAULT_CONNECTION_PLUGIN_PATH, 'connection', required_base_class='ConnectionBase')
    print(loader.all())

# Generated at 2022-06-23 11:11:55.596363
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    obj = PluginLoadContext()
    assert not obj.resolved
    assert obj.resolve('resolved_name', 'resolved_path', 'resolved_collection', 'exit_reason')
    assert obj.resolved


# Generated at 2022-06-23 11:12:00.443457
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    plc = PluginLoadContext()
    expected = PluginLoadContext()
    expected.pending_redirect = None
    expected.exit_reason = 'expected test exit_reason'
    expected.resolved = False
    assert plc.nope('expected test exit_reason') == expected

# Generated at 2022-06-23 11:12:11.784641
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    '''
    Ensure we get the correct file names, in the correct order
    '''
    p = Jinja2Loader('')
    p._searched_paths = ['/a/b/c', '/a/b/d', '/a/b/e']

# Generated at 2022-06-23 11:12:21.698351
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    from ansible.errors import AnsibleError, AnsibleInternalError

    # Create a mock module (fake_package) with fake files
    fake_files = [
        "fake_package/test.py",
        "fake_package/init.py",
        "fake_package/other.py",
    ]
    mock_module = mock.MagicMock()
    mock_module.__file__ = 'fake_package/__init__.py'
    mock_module.__path__ = fake_files
    mock_module.__name__ = 'fake_package'

    # Create a mock _load_module_source function, allowing to return function
    # defined inside of mock_module (using the path in the same way as the
    # mock_module.__file__ attribute, removing the extension for compatibility)

# Generated at 2022-06-23 11:12:33.537588
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    kwargs = dict(
        subdir='callback_plugins/foo/bar',
        package='ansible.plugins.callback',
        directories=['/home/foo/bar']
    )
    valid = dict(kwargs)
    loader = PluginLoader(**kwargs)
    if 'directories' not in valid:
        del valid['directories']
    else:
        valid['directories'] = ['/home/foo/bar']
    for k in tuple(kwargs):
        if k not in valid:
            del kwargs[k]
    dict.__setitem__(kwargs, 'directories', ['/home/foo/bar'])

# Generated at 2022-06-23 11:12:41.574516
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    class_name = 'Connection'
    package = 'ansible.plugins.connections'
    config_def_subdir = 'connection_plugins'
    plugin_subdir = 'connections'
    base_class = 'ConnectionBase'

    base_path = os.path.join(collection_loader._collection_paths[0], 'ansible_collections/testns/testcoll')
    search_path = os.path.join(base_path, 'plugins/connection_plugins')

    plugin_subdir = 'connection_plugins'

    pl = PluginLoader(class_name, package, config_def_subdir, plugin_subdir, base_class)
    pl.add_directory(base_path)

    assert search_path in pl._searched_paths


# Generated at 2022-06-23 11:12:45.341736
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    _v = VarsModule()
    _v.VARS = dict(string = "string", number = 123, boolean = True)

    assert _v.VARS == dict(string = "string", number = 123, boolean = True)


# Generated at 2022-06-23 11:12:55.754250
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
  import ansible
  # Test normal case
  ansible_payload = ansible.plugins.loader.PluginLoader()
  payload_directory = '/etc/ansible/'
  ansible_payload.add_directory(payload_directory)
  ansible_payload._searched_paths.append(payload_directory)
  assert ansible_payload._searched_paths == ['/etc/ansible/']
  # Test duplicate case, does not add to list
  ansible_payload = ansible.plugins.loader.PluginLoader()
  ansible_payload.add_directory(payload_directory)
  assert ansible_payload._searched_paths == []
  # Test case where directory is not a string, throws error
  ansible_payload = ansible.plugins.loader.PluginLoader

# Generated at 2022-06-23 11:13:00.650460
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    plc = PluginLoadContext()
    assert plc.pending_redirect is None
    assert plc.resolved is False
    plc.redirect('redirect_to')
    assert plc.pending_redirect == 'redirect_to'
    assert plc.resolved is False


# Generated at 2022-06-23 11:13:09.422059
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    def test_it(name, base_type, base_path, paths, package, class_name, collection_list=None, expect=None, exception=None):
        loader = Jinja2Loader(base_type, base_path, paths, package, class_name, collection_list=collection_list)
        if expect is not None:
            obj = loader.get(name, config=load_config_definitions(package, '', loader._get_paths()))
            assert obj.__class__.__name__ == expect['__class__.__name__']
        if exception is not None:
            with pytest.raises(exception):
                loader.get(name, config=load_config_definitions(package, '', loader._get_paths()))


# Generated at 2022-06-23 11:13:21.303665
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    from ansible.plugins.loader import Jinja2Loader
    import ansible.constants as C
    import os

    # path getting for this plugin is done in Jinja2Loader
    _plugin_paths = Jinja2Loader._get_paths()

    # NOTE: we are using _get_paths to get the path, it internally returns:
    #      1. paths from ANSIBLE_LIBRARY
    #      2. paths from ANSIBLE_JINJA2_FILTERS_PLUGINS
    #      3. our default paths
    # This is the closest to what users would do to import a jinja2 plugin, without actually being a user.

    # get the path to test_jinja2.py

# Generated at 2022-06-23 11:13:24.217149
# Unit test for constructor of class PluginLoader
def test_PluginLoader():
    loader = PluginLoader('shell_plugins', 'ShellModule', C.DEFAULT_SHELL_PLUGIN_PATH, 'ansible.plugins.shell')
    assert loader != None


# Generated at 2022-06-23 11:13:29.396105
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    pl = PluginLoader('ansible.plugins.testplugin', 'AnsiblePluginTest', 'Test', 'ansible.plugins.testplugin')
    assert repr(pl) == u"PluginLoader(package='ansible.plugins.testplugin', class_name='AnsiblePluginTest', base_class='Test', config_base='ansible.plugins.testplugin')"


# Generated at 2022-06-23 11:13:37.236030
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():

    # No parametrization for this test yet
    # Set up test objects
    plugin = PluginLoader()
    plugin.aliases = {}
    plugin.package = None
    plugin.base_class = None
    plugin.all_commands = None
    plugin.class_name = None
    plugin.categories = []
    plugin.display = None
    plugin._config_defs = {}

    # Derive expected results
    expected = plugin

    # Method to test
    plugin.__setstate__(state=None)

    # Make assertions
    assert plugin == expected

# Generated at 2022-06-23 11:13:40.580374
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    '''
    Unit test for method __setstate__ of class PluginLoader
    '''
    obj = PluginLoader()
    # Construct args
    state = {}
    obj.__setstate__(state)

# Generated at 2022-06-23 11:13:47.898434
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    from ansible.plugins.cache import BaseFileCacheModule
    stub_loader = Jinja2Loader(None,
                               'ansible.plugins.cache',
                               C.CACHE_PLUGIN_FILENAMES,
                               package='ansible.plugins.cache')
    stub_loader._module_cache = {
        'test': {
            'base_file_cache': BaseFileCacheModule
        }
    }
    module = stub_loader.get('test')
    assert module is not None, 'base_file_cache should have been returned'
    assert module.__name__ == 'BaseFileCacheModule'
    assert module.name == 'test'

# Generated at 2022-06-23 11:13:54.030208
# Unit test for method format_paths of class PluginLoader
def test_PluginLoader_format_paths():
    p = PluginLoader('test')
    assert 'test/path' == p.format_paths('test/path')
    p._searched_paths = ['test/path1', 'test/path2']
    assert 'test/path1,test/path2' == p.format_paths()


# Generated at 2022-06-23 11:13:57.807938
# Unit test for method resolve of class PluginLoadContext
def test_PluginLoadContext_resolve():
    # Arrange
    test_object = PluginLoadContext()
    resolved_name = 'resolved_name'
    resolved_path = 'resolved_path'
    resolved_collection = 'resolved_collection'
    exit_reason = 'exit_reason'

    # Act
    result = test_object.resolve(resolved_name, resolved_path, resolved_collection, exit_reason)

    # Assert
    assert isinstance(result, PluginLoadContext)
    assert result.pending_redirect is None
    assert result.plugin_resolved_name == resolved_name
    assert result.plugin_resolved_path == resolved_path
    assert result.plugin_resolved_collection == resolved_collection
    assert result.exit_reason == exit_reason
    assert result.resolved == True

# Generated at 2022-06-23 11:14:01.733627
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    loader = PluginLoader(base_package='unit_test', class_name='unit_test')
    loader._searched_paths = ['path1', 'path2', 'path3']
    assert loader.format_paths(loader._searched_paths) == 'path1, path2, path3'
    assert loader.format_paths(loader._searched_paths, indent=8) == '        path1, path2, path3'

# Generated at 2022-06-23 11:14:11.688148
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    my_collection_list = [ 'foo', 'bar' ]
    my_args = [ 'baz', 'buz' ]
    my_kwargs = { 'blep': 'blap' }

    loader = Jinja2Loader()

    # force to test main class logic
    with pytest.raises(AnsibleError) as excinfo:
        loader.get('foo', my_collection_list, my_args, my_kwargs)

    assert str(excinfo.value) == 'No code should call "get" for Jinja2Loaders (Not implemented)'


# Generated at 2022-06-23 11:14:12.314395
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    pass

# Generated at 2022-06-23 11:14:20.577219
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    params = {
        'package': 'package',
        'directories': ['dir'],
        'class_name': 'class_name',
        'base_class': 'base_class',
        'aliases': {'alias': 'name'},
        '_module_cache': {'a': 1, 'b': 2},
    }
    pl = PluginLoader(**params)
    assert repr(pl) == 'PluginLoader(package="package", class_name="class_name", base_class="base_class", directories=["dir"])'

# Generated at 2022-06-23 11:14:26.581649
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    plugin_loader = PluginLoader('foo', 'bar', 'baz')
    plugin_loader._searched_paths = ['/test/path/one', '/test/path/two']
    assert plugin_loader.print_paths() == '[\'foo\', \'/test/path/one\', \'/test/path/two\']'



# Generated at 2022-06-23 11:14:37.549938
# Unit test for method all of class Jinja2Loader
def test_Jinja2Loader_all():
    # Test that we return the expected list of plugins
    def assert_expected_plugins(plugin_loader, expected_plugins):
        # We make the list of expected_plugins of set
        return len(set(expected_plugins) - set(plugin_loader.all())) == 0

    # Test that the order in which we return Jinja2 plugins
    # matches the order of the source files
    def assert_expected_order(plugin_loader, expected_order):
        order_found = [x['name'] for x in plugin_loader.all()]
        return order_found == expected_order

    from tests.lib import get_data_path

    source_dir = get_data_path('callback_plugins')

    # Define a test for an ansible file, we'll use the same format for all tests.
    # We put the name of the plugin,

# Generated at 2022-06-23 11:14:38.559482
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    pass



# Generated at 2022-06-23 11:14:45.585398
# Unit test for method get of class PluginLoader
def test_PluginLoader_get():
    h = PluginLoader('ansible.plugins.action', 'ActionModule', '_ansible_action_')

    m = h.get('copy')
    assert 'copy' in m._load_name
    assert m._load_name.startswith('_ansible_action_')
    assert 'copy' in m.__dict__['_redirected_names']


# Generated at 2022-06-23 11:14:49.559688
# Unit test for method __contains__ of class PluginLoader
def test_PluginLoader___contains__():
    print("Test that has_plugin, i.e. __contains__ works as expected")
    test_loader = PluginLoader()
    assert test_loader.has_plugin('raw') is False
    raw_plugin_loader = PluginLoader('RawModule')
    assert raw_plugin_loader.has_plugin('raw') is True


# Generated at 2022-06-23 11:14:54.330388
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    obj = PluginLoadContext()
    result = obj.nope('exit_reason')
    assert result.exit_reason == 'exit_reason'
    assert result.resolved == False
    assert result.pending_redirect == None



# Generated at 2022-06-23 11:15:00.073586
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    from ansible.plugins.loader import get_all_plugin_loaders
    assert isinstance(get_all_plugin_loaders(), list)
    for name, obj in get_all_plugin_loaders():
        assert isinstance(name, str)
        assert obj.__class__.__name__ == 'PluginLoader'


# Generated at 2022-06-23 11:15:09.013460
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    from ansible.plugins.loader import get_shell_plugin
    from ansible.plugins.shells import ShellBase
    from ansible.errors import AnsibleError

    # test for expect shell
    expected = 'expect'
    result = get_shell_plugin(expected)
    assert isinstance(result, ShellBase)
    assert result.SHELL_NAME == expected
    result = get_shell_plugin(executable='expect')
    assert isinstance(result, ShellBase)
    assert result.SHELL_NAME == expected

    # test for bash shell
    expected = 'bash'
    result = get_shell_plugin(expected)
    assert isinstance(result, ShellBase)
    assert result.SHELL_NAME == expected
    result = get_shell_plugin(executable='bash')
    assert isinstance(result, ShellBase)

# Generated at 2022-06-23 11:15:10.221027
# Unit test for method add_directory of class PluginLoader
def test_PluginLoader_add_directory():
    # TODO
    pass

# Generated at 2022-06-23 11:15:23.132832
# Unit test for method find_plugin of class PluginLoader

# Generated at 2022-06-23 11:15:26.301181
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    context = PluginPathContext("/a/path/to/some/ansible/code", False)
    assert context.path == "/a/path/to/some/ansible/code"
    assert context.internal is False


# Generated at 2022-06-23 11:15:30.686292
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    context = PluginLoadContext()
    assert context.original_name == None
    assert context.redirect_list == []
    assert context.error_list == []
    assert context.import_error_list == []
    assert context.load_attempts == []
    assert context.pending_redirect == None
    assert context.exit_reason == None


# Generated at 2022-06-23 11:15:43.131198
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    # Test that all of the plugin loaders are being properly loaded
    found_loaders = {}
    for name, loader in get_all_plugin_loaders():
        found_loaders[name] = loader
    # Test count
    assert len(found_loaders) == 6, "Expected 6 plugin loaders, found %s" % len(found_loaders)
    # Test specific loaders
    assert found_loaders['action'] == PluginLoader.action, "Expected action loader to be in dict"
    assert found_loaders['callback'] == PluginLoader.callback, "Expected callback loader to be in dict"
    assert found_loaders['cliconf'] == PluginLoader.cliconf, "Expected cliconf loader to be in dict"

# Generated at 2022-06-23 11:15:47.564043
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    from ansible.plugins.loader import PluginLoader
    plugins = get_all_plugin_loaders()
    for name, loader in plugins:
        assert isinstance(loader, PluginLoader)



# Generated at 2022-06-23 11:15:50.628268
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    # tests the constructor for PluginPathContext
    pc = PluginPathContext(path='/some/path', internal=True)
    assert pc.path == '/some/path'
    assert pc.internal


# Generated at 2022-06-23 11:15:52.241952
# Unit test for method all of class PluginLoader
def test_PluginLoader_all():
    # FIXME: write unit test for test_PluginLoader_all
    pass


# Generated at 2022-06-23 11:15:55.495100
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    obj = PluginLoader('fake_package', 'fake_base', 'fake_class')
    output = str(obj)
    assert output == '<PluginLoader(fake_package, fake_base, fake_class)>'



# Generated at 2022-06-23 11:16:00.402227
# Unit test for constructor of class PluginPathContext
def test_PluginPathContext():
    plugin_path_context = PluginPathContext(path='/usr/lib/ansible/plugins', internal=False)
    assert plugin_path_context.path == '/usr/lib/ansible/plugins'
    assert plugin_path_context.internal is False



# Generated at 2022-06-23 11:16:06.589635
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    v = get_with_context_result('test', 'sample', 'test/sample')
    assert v.res == 'test/sample'
    assert v.context == ('test', 'sample')
    assert v is not None
    assert v.res is not None
    assert str(v) == 'test/sample'



# Generated at 2022-06-23 11:16:11.795821
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    '''
    AnsiblePluginLoader.PluginLoader test cases
    '''
    obj = PluginLoader(filter_loader)

    # No input parameters
    repr = repr(obj)
    assert repr == '<ansible.plugins.loader.PluginLoader object at 0x7f744e56bd68>'



# Generated at 2022-06-23 11:16:19.535538
# Unit test for method redirect of class PluginLoadContext
def test_PluginLoadContext_redirect():
    print("Testing redirect of PluginLoadContext")
    plugin_load_context = PluginLoadContext()
    plugin_load_context.resolve('exit_reason','exit_reason','exit_reason','exit_reason')
    assert plugin_load_context.pending_redirect is None
    assert plugin_load_context.plugin_resolved_name == 'exit_reason'
    assert plugin_load_context.plugin_resolved_path == 'exit_reason'
    assert plugin_load_context.plugin_resolved_collection == 'exit_reason'
    assert plugin_load_context.exit_reason == 'exit_reason'
    assert plugin_load_context.resolved is True

    plugin_load_context.redirect('redirect')
    assert plugin_load_context.pending_redirect == 'redirect'
    assert plugin_load_

# Generated at 2022-06-23 11:16:24.760381
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    global _PLUGIN_FILTERS

    base_class = 'BasePlugin'
    class_name = 'Exec'
    package = 'ansible.plugins.action'
    subdir = 'action'


# Generated at 2022-06-23 11:16:35.582032
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    c = PluginLoadContext()
    c.original_name = 'original'
    c.exit_reason = 'I have an exit reason'
    c.resolved = True
    c.pending_redirect = 'pending'
    c.plugin_resolved_name = 'resolved'
    c.plugin_resolved_path = 'path/resolved'
    c.plugin_resolved_collection = 'collection_resolved'
    assert(c.original_name == 'original')
    assert(c.exit_reason == 'I have an exit reason')
    assert(c.resolved)
    assert(c.pending_redirect == 'pending')
    assert(c.plugin_resolved_name == 'resolved')
    assert(c.plugin_resolved_path == 'path/resolved')

# Generated at 2022-06-23 11:16:48.496034
# Unit test for constructor of class Jinja2Loader
def test_Jinja2Loader():
    import sys
    import tempfile
    import shutil

    # Create temporary directory, do test, remove directory
    # Note: temporary directory will be removed recursively even if exception is raised.
    #       temporary directory will contain subdirectories 'filter_plugins' and 'test_plugins'.
    tempdir = tempfile.mkdtemp()
    sys.path.insert(0, tempdir)

    def get_loader(name):
        # test initialization
        return Jinja2Loader(name)

    def create_file(dir_name, base_name, content):
        # test add_directory
        file_name = dir_name + '/' + base_name
        with open(file_name, 'w') as f:
            f.write(content)


# Generated at 2022-06-23 11:16:51.594007
# Unit test for function get_shell_plugin
def test_get_shell_plugin():
    shell_plugin = get_shell_plugin(shell_type='sh')
    assert shell_plugin.name == 'sh'
    assert shell_plugin.executable == '/bin/sh'



# Generated at 2022-06-23 11:16:54.791226
# Unit test for method nope of class PluginLoadContext
def test_PluginLoadContext_nope():
    obj = PluginLoadContext()
    outcome = obj.nope('test exit reason')
    assert outcome.pending_redirect == None
    assert outcome.exit_reason == 'test exit reason'
    assert outcome.resolved == False
    return 1

# Generated at 2022-06-23 11:17:02.067220
# Unit test for constructor of class PluginLoadContext
def test_PluginLoadContext():
    plc = PluginLoadContext()
    assert plc.original_name is None
    assert plc.redirect_list == []
    assert plc.error_list == []
    assert plc.import_error_list == []
    assert plc.load_attempts == []
    assert plc.pending_redirect is None
    assert plc.exit_reason is None
    assert plc.plugin_resolved_path is None
    assert plc.plugin_resolved_name is None
    assert plc.plugin_resolved_collection is None
    assert plc.deprecated is False
    assert plc.removal_date is None
    assert plc.removal_version is None
    assert plc.deprecation_warnings == []
    assert plc.resolved is False
    assert plc._res

# Generated at 2022-06-23 11:17:13.294029
# Unit test for method find_plugin of class Jinja2Loader
def test_Jinja2Loader_find_plugin():
    """
    Unit test for method Jinja2Loader.find_plugin
    """
    # test_results

# Generated at 2022-06-23 11:17:13.937915
# Unit test for method __setstate__ of class PluginLoader
def test_PluginLoader___setstate__():
    pass

# Generated at 2022-06-23 11:17:17.271337
# Unit test for constructor of class get_with_context_result
def test_get_with_context_result():
    """Unit test for class get_with_context_result
    """

    # Test the constructor of the class
    result = get_with_context_result()
    assert result is None



# Generated at 2022-06-23 11:17:20.456283
# Unit test for method print_paths of class PluginLoader
def test_PluginLoader_print_paths():
    # Initialize a PluginLoader object
    p = PluginLoader()

    # Check if the PluginLoader object was initialized correctly
    assert isinstance(p, PluginLoader)


# Generated at 2022-06-23 11:17:24.748959
# Unit test for method __repr__ of class PluginLoader
def test_PluginLoader___repr__():
    # Test with no options
    p1 = PluginLoader(None)
    expected = "PluginLoader(None, None, None, None, 'ansible_collections.test.test_loader', None, [])"
    assert repr(p1) == expected

    # Test with a base class
    p2 = PluginLoader(None, base_class='BaseClass')
    expected = "PluginLoader(None, None, None, 'BaseClass', 'ansible_collections.test.test_loader', None, [])"
    assert repr(p2) == expected

    # Test with a subdir
    p3 = PluginLoader(None, subdir='subdir')
    expected = "PluginLoader(subdir, None, None, None, 'ansible_collections.test.test_loader', None, [])"

# Generated at 2022-06-23 11:17:28.701612
# Unit test for method get of class Jinja2Loader
def test_Jinja2Loader_get():
    '''
    # set up test data
    # run code to be tested
    # assert expected results
    '''
    raise AnsibleError('Jinja2Loader does not implement get() (Not implemented)')


# Generated at 2022-06-23 11:17:39.094282
# Unit test for function get_all_plugin_loaders
def test_get_all_plugin_loaders():
    # List of plugin loaders in Ansible.
    EXPECTED_PLUGIN_LOADERS = [
        'DeviceModuleLoader',
        'ActionModuleLoader',
        'CacheModuleLoader',
        'CallbackModuleLoader',
        'ConnectionModuleLoader',
        'FilterModuleLoader',
        'InventoryModuleLoader',
        'LookupModuleLoader',
        'ModuleReplacerLoader',
        'ModuleUtilsLoader',
        'NetconfModuleLoader',
        'PostProcessingFilterModuleLoader',
        'ShellModuleLoader',
        'StrategyModuleLoader',
        'TestModuleLoader',
        'VarsModuleLoader',
    ]

    for (name, obj) in get_all_plugin_loaders():
        assert name in EXPECTED_PLUGIN_LOADERS
        assert isinstance(obj, PluginLoader)
        EXPECTED