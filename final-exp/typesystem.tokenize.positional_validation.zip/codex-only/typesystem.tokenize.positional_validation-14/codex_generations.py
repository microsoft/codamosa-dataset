

# Generated at 2022-06-24 11:00:00.410060
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typing import Set
    from pytest import raises
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class TestSchema(Schema):
        foo = String(max_length=4)

    # Test that a validation error is raised for the 'max_length' code.
    with raises(ValidationError) as exc:
        validate_with_positions(
            token=Token("hello", start_position=0, end_position=4), validator=TestSchema
        )

    messages = exc.value.messages()
    assert len(messages) == 1
    assert messages[0].text == "Must have no more than 4 characters."
    assert messages[0].code == "max_length"
    assert messages[0].start_position == 0
    assert messages[0].end_position

# Generated at 2022-06-24 11:00:10.196975
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class ArtistSchema(Schema):
        name = Field(str, max_length=50)
        age = Field(int, minimum=0, maximum=150)

    schema = ArtistSchema()

    tokens = tokenize({})
    token = tokens["."]
    assert validate_with_positions(token=token, validator=schema) == {}

    tokens = tokenize({"name": "Jane", "age": 25})
    assert validate_with_positions(token=tokens["."], validator=schema) == {
        "name": "Jane",
        "age": 25,
    }

    tokens = tokenize({"age": 25})

# Generated at 2022-06-24 11:00:19.236020
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from tests import schemas
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.utils import get_tokens
    from typesystem.text import Position
    from typesystem.fields import Integer

    # type checking and doctests
    t = get_tokens({"type": "number"})
    assert validate_with_positions(token=t[0], validator=Integer) is None

    s = schemas.PersonWithId
    input_dict = {"id": "x"}
    token = Token(data=input_dict, schema=s)
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=s)

# Generated at 2022-06-24 11:00:25.826118
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.json_schema import JSONSchema
    from jsonschema.exceptions import ValidationError

    schema = JSONSchema({"type": "object", "properties": {"property": {}}})

    token = Token(value={"property": None}, schema=schema)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    val_error = exc_info.value
    message = val_error.messages[0]
    assert message.start_position == (1, 0)
    assert message.end_position == (1, 1)
    assert message.code == "required"
    assert message.index == ("property",)

# Generated at 2022-06-24 11:00:28.354312
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # See https://www.python.org/dev/peps/pep-0484/#typing-tests
    assert validate_with_positions  # typing: ignore

# Generated at 2022-06-24 11:00:40.019844
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer

    class Person(Schema):
        name = String(min_length=2)
        age = Integer(gte=18)

    schema = Person()
    token = Token(
        {"name": "john", "age": 17},
        start=[(0, 0), (0, 5), (0, 8), (0, 9)],
        end=[(0, 9), (0, 6), (0, 10), (0, 10)],
    )

    messages = []
    actual = None
    try:
        actual = validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        messages = list(error.messages())
    assert actual is None

# Generated at 2022-06-24 11:00:40.784668
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-24 11:00:50.982857
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from json import loads

    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokens import ObjectToken
    from typesystem.base import Message
    from typesystem.schemas import Object
    from typesystem.fields import Field

    def prepare(schema, data):
        enclosing_token = Token(value=data)
        parsed_data = tokenize(data)
        object_token = ObjectToken(
            parsed_data, enclosing_token=enclosing_token
        )
        return object_token, schema


# Generated at 2022-06-24 11:01:01.580068
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Token
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    from typesystem.base import Message
    from typesystem.tokenize.parse import JSONParseError

    class AddressSchema(Schema):
        street = String()
        zip_code = Integer()

    class ArtistSchema(Schema):
        name = String(required=True)
        age = Integer(required=True)
        address = AddressSchema()

    token = Token("{}", "<string>")
    try:
        validate_with_positions(token=token, validator=ArtistSchema())
    except ValidationError as exc:
        error_messages = [message.text for message in exc.messages()]

# Generated at 2022-06-24 11:01:05.635086
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_string

    # Normal case
    field = Field(type="string", min_length=2, max_length=3)
    source = '{"foo": "bar"}'
    token = tokenize_string(source)
    value = validate_with_positions(token=token, validator=field)
    assert value.raw == "bar"
    assert value.start_position.char_index == 7
    assert value.end_position.char_index == 11

    # Empty value
    source = '{"foo": ""}'
    token = tokenize_string(source)
    with raises(ValidationError):
        validate_with_positions(token=token, validator=field)

    # Too long value
    source = '{"foo": "baz"}'
    token = tokenize

# Generated at 2022-06-24 11:01:16.270317
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class TestSchema(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer")

    # Test the case where there is no error.
    json_data = '{"name":"John Doe","age":42}'
    token = Token.parse_text(text=json_data)
    token = TestSchema().validate(token.value)
    validate_with_positions(token=token, validator=TestSchema)

    # Test the case where there is an error.
    json_data = '{"age":42}'
    token = Token.parse_text(text=json_data)
    # There is an error.
    with pytest.raises(ValidationError):
        TestSchema().validate(token.value)
    # There is an error with position information

# Generated at 2022-06-24 11:01:25.383540
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class ExampleSchema(Schema):
        field = Field(required=True)

    source = '{"foo": "bar"}'
    token = Token.parse(source=source)

    expected = {
        "default": (2, 3, 2, 6),
        "required": (2, 1, 2, 3),
    }
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=ExampleSchema)

    for message in error.value.messages:
        assert message.start_position == Position(*expected[message.code])



# Generated at 2022-06-24 11:01:33.857751
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    token = tokenize(
        source="""
            {
                "foo": "bar"
            }
        """
    )
    schema = Schema(fields={
        "foo": Field(required=True),
    })
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as exc:
        assert exc.messages() == [
            Message(
                text="The field 'foo' is required.",
                code="required",
                index=["foo"],
                start_position=Position(0, 5),
                end_position=Position(1, 12),
            )
        ]

# Generated at 2022-06-24 11:01:42.902756
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field("name")
        age = Field(int)

    data = {"name": "Joe", "age": "twenty"}
    token = Token(data, (1, 1))
    with raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    error = exc_info.value
    assert len(error.messages()) == 1
    assert error.messages()[0].code == "invalid_type"
    assert (
        error.messages()[0].text == "Expected int. Got str instead."
    )
    assert len(error.messages()[0].index) == 1
    assert error.messages()[0].start_position.char_index == 9

# Generated at 2022-06-24 11:01:53.164177
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.tokenize.rules import ObjectRule

    class UserSchema(Schema):
        name = String()

    token = Token(
        value={"name": ""}, rule=ObjectRule(), start_position=0, end_position=10
    )
    try:
        validate_with_positions(token=token, validator=UserSchema)
    except ValidationError as error:
        assert error.messages()[0].start_position.char_index == 1
        assert error.messages()[0].end_position.char_index == 7

# Generated at 2022-06-24 11:02:00.249125
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Boolean, String, Integer, Schema, Array

    dummy = Schema(fields={"value": Integer()})
    array = Array(element=dummy)
    schema = Schema(fields={"array": array, "value": Integer()})
    token = Token(
        token_type="Object",
        fields=[("array", "Array"), ("value", "String")],
        values=[
            [
                Token(
                    token_type="Object",
                    fields=[("value", "Integer")],
                    values=[123],
                )
            ],
            "hello",
        ],
    )
    result = validate_with_positions(token=token, validator=schema)
    assert isinstance(result, dict)
    assert len(result) == 2
    assert isinstance(result["array"], list)
   

# Generated at 2022-06-24 11:02:07.025113
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.testing import validator

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(
            token=Token(value={"field": None}), validator=validator.fields["field"]
        )
    assert excinfo.value.messages[0].text == 'The field "field" is required.'
    assert excinfo.value.messages[0].start_position.char_index == 8

# Generated at 2022-06-24 11:02:18.933344
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.types import String

    token = Token(
        "key",
        {"x": {"y": "value"}},
        start={"char_index": 2, "line_number": 3},
        end={"char_index": 10, "line_number": 10},
    )


# Generated at 2022-06-24 11:02:30.000472
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer

    field = Integer(min_value=1)
    token = Token(
        name="integer",
        value="cheese",
        start=Token.Position(line_index=1, char_index=6),
        end=Token.Position(line_index=1, char_index=12),
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)
    error_message = exc_info.value.messages()[0]
    assert error_message.code == "min_value"
    assert error_message.index[0] == "integer"
    assert error_message.start_position.line_index == 1
    assert error_message.start_position.char_index == 6

# Generated at 2022-06-24 11:02:40.277474
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class User(Schema):
        username = Field(type="string", min_length=10)
        password = Field(type="string", min_length=10)

    token = tokenize('{"username": "bob"}')
    User.validate(token)

    try:
        validate_with_positions(token=token, validator=User)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'password' is required."
        assert message.start_position.line_number == 1
        assert message.start_position.char_index == 1
        assert message.end_position.line_number == 1
        assert message.end_position.char_index == 22



# Generated at 2022-06-24 11:02:50.920778
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import Message
    from typesystem.fields import String, Integer
    from typesystem.schemas import Object, Array
    from typesystem.tokenize import tokenize
    from typesystem.validate import validate_with_positions

    schema = Object({"foo": Array(items=Integer())})
    token = tokenize('{"foo": ["bar"]}')
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert len(error.messages) == 1
        message = error.messages[0]
        assert message.text == 'Error validating array element: "bar" is not a valid integer.'
        assert message.start_position.line_number == 1
        assert message.start_position.char_index == 13
        assert message

# Generated at 2022-06-24 11:02:58.722536
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize import tokenize

    field = String(min_length=1)
    token = tokenize("")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)

    message = exc_info.value.messages[0]
    assert message == Message(
        code="required",
        text="The field "" is required.",
        index=(),
        start_position=token.start,
        end_position=token.end,
    )

# Generated at 2022-06-24 11:03:06.176638
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest

    from jmespath import lexer
    from typesystem.schemas import Schema, String
    from typesystem.tokenize.tokens import Token
    from .conftest import assert_messages

    query = lexer.compile("a.b.c")

    class MySchema(Schema):
        a = String(required=True)
        b = String(required=True)
        c = String(required=True)

    token = Token.from_node(query)
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=MySchema)
    assert len(excinfo.value.messages()) == 3

# Generated at 2022-06-24 11:03:11.167221
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokenize import tokenize

    schema = Schema(fields={"product": {"fields": {"name": {"required": True}}}})
    data = {"product": {"name": "Monitor"}}
    tokens = list(tokenize(data))
    validate_with_positions(token=tokens[0], validator=schema)

# Generated at 2022-06-24 11:03:19.245197
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem.tokenize import tokenize
    from typesystem.schemas import Integer
    from typesystem.base import SchemaMeta

    class IntegerField(Field, metaclass=SchemaMeta):
        schema = Integer()
        required = True

    text = "{1 2 3 4}"
    token = tokenize(text)
    try:
        validate_with_positions(token=token, validator=IntegerField())
        assert False, "Expected ValidationError."
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 1 is required."
        assert message.code == "required"
        assert message.index == (0,)
        assert message.start_position.char_index == 0

# Generated at 2022-06-24 11:03:27.849817
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.base import Location
    import typesystem.fields as fields

    token = Token(
        value={},
        start=Location(file_name="", line=1, column=1, char_index=0),
        end=Location(file_name="", line=1, column=1, char_index=0),
    )
    try:
        validate_with_positions(token=token, validator=fields.Dictionary(fields={}))
    except ValidationError as error:
        [message] = error.messages()
        assert message.text == "The field {} is required."
        assert message.code == "required"
        assert message.index == tuple()

# Generated at 2022-06-24 11:03:37.353566
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type="string", pattern=r"\d{3}")
    token = Token(
        value="123",
        start=Token.Position(line=1, char_index=5),
        end=Token.Position(line=1, char_index=8),
    )
    assert validate_with_positions(token=token, validator=field) == "123"

    field = Field(type="string", pattern=r"\d{3}")
    token = Token(
        value="1234",
        start=Token.Position(line=1, char_index=5),
        end=Token.Position(line=1, char_index=9),
    )

# Generated at 2022-06-24 11:03:45.337443
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # This is a bit tricky to test since it depends on how errors are raised.
    # So we do a minimal test to make sure it doesn't error out.
    import typesystem
    from typesystem.tokenize.parser import parse
    from typesystem.tokenize.scanner import UnicodeScanner

    schema = typesystem.Schema(fields={"name": typesystem.String(max_length=3)})
    document = '{"name": "Hello, World!"}'
    tokens, errors = parse(UnicodeScanner(document), schema)
    assert tokens
    validate_with_positions(
        token=tokens, validator=schema
    )

# Generated at 2022-06-24 11:03:54.788596
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.parser import parse_schema
    from typesystem.tokenize import tokenize

    schema = parse_schema(
        """
        type Person {
            name: String!
            age: Int!
        }
    """
    )

    text = """
    {
        name: "Fred",
        age: 20
    }
    """

    tokens = tokenize(text)

    assert validate_with_positions(token=tokens, validator=schema) == {
        "name": "Fred",
        "age": 20,
    }

# Generated at 2022-06-24 11:04:04.291298
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize.base import Lexer
    from typesystem.tokenize.tokens import IntegerToken
    from typesystem.tokenize.positions import Line, Column

    class TestLexer(Lexer):
        def tokenize(self, data: str, *, filename: str = "") -> typing.List[Token]:
            return [IntegerToken(line=1, column=6, end_line=1, end_column=6)]

    field = Integer(required=True)
    validator = TestLexer(field=field)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=validator.tokenize("", filename="")[0], validator=field)


# Generated at 2022-06-24 11:04:09.422498
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """Test if correct errors are raised when required field is not given"""

    from typesystem.fields import String

    from typesystem.tokenize.utils import parse_typed_value

    typed_schema = String()
    typed_value = parse_typed_value("123")

    with pytest.raises(ValidationError):
        validate_with_positions(
            token=typed_value, validator=typed_schema
        )

# Generated at 2022-06-24 11:04:18.406069
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import Tokenizer
    from typesystem.schemas import Object
    from typesystem.fields import String

    class TestSchema(Object):
        name = String()

    schema = TestSchema(strict=True)

    tokenizer = Tokenizer()

    raw_text = """{
        "name": "Federico",
        "foo": "bar"
    }"""
    token = tokenizer.tokenize(raw_text)
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=schema)
    assert  {
        message.text for message in exc.value.messages
    } == {"The field 'foo' was not expected."}


# Generated at 2022-06-24 11:04:21.496847
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema({"foo": Field(required=True)})
    token = Token({"foo": None}, [])
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=schema)

    message = exc.value.messages[0]
    assert message.start_position == (1, 2)

# Generated at 2022-06-24 11:04:26.131675
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position
    from typesystem.tokenize.markers import Marker
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Author(Schema):
        name = String(required=True)

    class Book(Schema):
        title = String(required=True)
        author = Author()

    json_data = """
    {
        "title": "The Catcher In The Rye"
    }
    """


# Generated at 2022-06-24 11:04:35.041932
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import TokenStream
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import Integer, String

    class Person(Schema):
        name = String(required=True)
        age = Integer(required=True)

    source = '{"name": "bob", "age": "not an integer"}'
    token_stream = TokenStream(source=source)
    token = Token(value=token_stream.parse())

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        messages = error.messages()

        start_position, end_position = (
            messages[0].start_position,
            messages[0].end_position,
        )

        assert start_position.line_index == 1

# Generated at 2022-06-24 11:04:43.575110
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class PersonSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer", required=False)

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(
            token=Token({"name": "Jane", "age": "thirty"}), validator=PersonSchema()
        )

    assert exc.value.messages()[0].start_position.line_number == 1
    assert exc.value.messages()[0].start_position.char_index == 8
    assert exc.value.messages()[0].end_position.line_number == 1
    assert exc.value.messages()[0].end_position.char_index == 13

# Generated at 2022-06-24 11:04:53.959168
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import fields as ts_fields, schemas as ts_schemas
    from typesystem.tokenize import tokens as ts_tokens
    from typesystem.tokenize import tokenize as ts_tokenize

    class ListField(ts_fields.Field):
        def validate(self, value):
            return [self.sub_field.validate(v) for v in value]

    class ListSchema(ts_schemas.Schema):
        def get_field_map(self):
            return {"list": ListField(sub_field=ts_fields.String())}

    schema = ListSchema()

# Generated at 2022-06-24 11:04:59.968752
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.positions import Positions
    from typesystem.tokenize import tokenize
    from typesystem.types import String
    from typesystem.schemas import Schema

    class User(Schema):
        name = String(max_length=100)

    tokens = tokenize({"name": "spam"})
    token = tokens[0]
    try:
        validate_with_positions(
            token=token, validator=User,
        )
    except ValidationError as error:
        assert error.messages()[0].start_position == Positions(line=1, char_index=1)
        assert error.messages()[0].end_position == Positions(line=1, char_index=2)

# Generated at 2022-06-24 11:05:09.738759
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, String

    schema = Schema({"foo": Integer(), "bar": String()})
    try:
        validate_with_positions(token={"foo": "1", "bar": "baz"}, validator=schema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.index == ["foo"]
        assert message.start_position.line_index == 1
        assert message.start_position.char_index == 5
        assert message.end_position.line_index == 1
        assert message.end_position.char_index == 7

# Generated at 2022-06-24 11:05:18.543867
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    from typesystem.fields import Array, Boolean, Number, String

    if not hasattr(test_validate_with_positions, "schema"):
        test_validate_with_positions.schema = Array(
            items=Boolean(), min_items=2, max_items=5
        )

# Generated at 2022-06-24 11:05:26.342127
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.test_tokenize.test_tokens import TokenizerTestCase
    from tests.test_tokenize.test_tokens import PersonSchema
    from typesystem.cases import PascalCase
    from typesystem import Text

    tokenizer = TokenizerTestCase.Tokenizer(case=PascalCase)

    schema = PersonSchema(case=PascalCase)
    token = tokenizer.parse(
        """
        {
            "firstName": "Leeroy",
            "lastName": "Jenkins",
            "age": 42
        }
        """
    )
    schema.validate(token)

    token = tokenizer.parse(
        """
        {
            "firstName": "Leeroy",
            "lastName": "Jenkins"
        }
        """
    )

# Generated at 2022-06-24 11:05:35.092824
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.compat import NoneType
    from typesystem.tokenize import parse, Tokenizer
    from typesystem.tokenize.tokens import FieldToken, IndexToken, RootToken

    class AddressSchema(Schema):
        street = Field(type=str)
        number = Field(type=str, required=False)

    address = AddressSchema(
        {
            "street": "Wall Street",
            # "number": "22"  # Uncomment to make test pass.
        }
    )

    data = "address"
    tokenizer = Tokenizer(
        token_classes=[FieldToken, IndexToken, RootToken],
        schema=AddressSchema,
    )
    token = tokenizer.tokenize(data)

# Generated at 2022-06-24 11:05:40.671386
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from hypothesis import given, strategies as st
    from typesystem.tokenize import tokenize

    from .context import load_schema

    person_schema = load_schema("person.json")
    person_schema.validate_with_positions = validate_with_positions
    token = tokenize(
        """
        {
          "first_name": null,
          "last_name": "Smith"
        }
        """
    )

    # from typesystem import fields, validators
    #
    # @given(st.data())
    # def test(data):
    #     first_name = fields.String(required=True)
    #     last_name = fields.String(required=True)
    #     schema = type(
    #         "Person", (Schema,), {"first_name": first_

# Generated at 2022-06-24 11:05:46.068118
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object

    class Post(Object):
        title = Field(type="string", min_length=1)

    from typesystem.tokenize.parser import parse_json

    token = parse_json('{"title": "123"}')
    validate_with_positions(token=token, validator=Post)

    token = parse_json('{"title": ""}')
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=Post)
    assert exc.value.messages[0].start_position == (1, 14)
    assert exc.value.messages[0].end_position == (1, 15)

    token = parse_json('{"title": [1]}')

# Generated at 2022-06-24 11:05:55.980037
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # type: () -> None
    from typesystem.examples import Person
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token

    person = Person.validate({})
    token = Token.from_object(person)
    token = tokenize(token)

    with pytest.raises(ValidationError) as error:
        validate_with_positions(validator=Person, token=token)

    message = error.value.messages[0]

    assert message.code == "required"
    assert message.text == "The field 'age' is required."
    assert message.start_position.line_number == 6
    assert message.start_position.char_index == 27
    assert message.end_position.line_number == 6
    assert message.end_position.char_

# Generated at 2022-06-24 11:06:04.233893
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import types

    class TestField(Field):
        def validate_token(self, token):
            return validate_with_positions(
                token=token,
                validator=types.String(),
            )

    field = TestField()

    try:
        field.validate_token(Token(
            value=True,
            start={
                "line_number": 2,
                "char_index": 4,
            },
            end={
                "line_number": 2,
                "char_index": 4,
            },
        ))
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "Value must be of type 'string'."
        assert message.code == "type_error"
        assert message

# Generated at 2022-06-24 11:06:13.465359
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # type: () -> None
    class Person(Schema):
        name = Field(type="string")

    token = Token.factory("{'name': 1}", path="/foo")
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "Value 1 is not of type string."
        assert message.code == "type_error.string"
        assert message.index == ("name",)

        assert message.start_position.line == 1
        assert message.start_position.char_index == 8
        assert message.start_position.path == "/foo"

        assert message.end_position.line == 1
        assert message.end

# Generated at 2022-06-24 11:06:21.950457
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, Float, String, Object, Array

    class Foo(Object):
        bar = Integer()
        baz = Float()

    class Bar(Object):
        foo = Foo()
        qux = String()
        quux = Array(items=Object(properties={"foo": Foo()}))

    def validate_token(token: Token) -> typing.Any:
        return validate_with_positions(token=token, validator=Bar)

    invalid_token = Token.parse(
        """\
{
    "foo.baz": "foo",
    "quux": [
        {
            "foo.quux": "foo"
        }
    ]
}
"""
    )


# Generated at 2022-06-24 11:06:34.176857
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String
    from typesystem.tokenize.tokens import Token, Tokenizer

    tokenizer = Tokenizer(
        tokenization_rules=[
            (r"\#{2}", "header-2"),
            (r"\#{4}", "header-4"),
            (r"[0-9]+", "code"),
            (r"[\:\,\-\.\;\(\)\#0-9a-zA-Z\?\_\!\s]+", "word"),
        ]
    )

    token = tokenizer.tokenize(
        """
#### Header 2
Another header 2 and some code 123:

#####`123`Header 4 with code

Just some words.
    """
    )

    token.lookup(["header-2"])


# Generated at 2022-06-24 11:06:43.456494
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class User(Schema):
        """Test validation with positions"""

        email = Field(type="email", required=True)


# Generated at 2022-06-24 11:06:51.452395
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import fields
    from typesystem.tokenize.tokens import Token

    class UserSchema(fields.Schema):
        name = fields.String(required=True)

    token = Token(
        "object",
        start=Token.Position(line_number=1, char_index=0),
        end=Token.Position(line_number=3, char_index=0),
        children={},
    )

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=UserSchema)

    messages = excinfo.value.messages

# Generated at 2022-06-24 11:06:58.583321
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.json import tokenize_json

    from typesystem.utils.yaml import load_yaml

    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema

    schema = load_yaml(
        """
        type: object
        properties:
            name:
                type: string
            age:
                type: integer
        required:
            - name
    """
    )

    class Person(Schema):
        name = String
        age = Integer

    tree = tokenize_json('{"name": "John"}')

    try:
        validate_with_positions(token=tree, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].code == "required"

# Generated at 2022-06-24 11:07:06.839897
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Structure, Integer

    validator = Structure(
        {"a": Integer()}
    )

    try:
        validate_with_positions(token=tokenize(""), validator=validator)
    except ValidationError as error:
        message = error.messages[0]
        assert message.text == 'The field "a" is required.'
        assert message.start_position.char_index == 0  # type: ignore
        assert message.end_position.char_index == 0  # type: ignore

# Generated at 2022-06-24 11:07:11.815679
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokens

    class Bool(Field):
        primitive = bool

    class Integer(Field):
        primitive = int

    class Data(Schema):
        a = Bool()
        b = Integer()

    example = tokens.Dict([
        tokens.DictEntry(
            tokens.Field(name="a", start_position=tokens.Position(line=1, char_index=0)),
            tokens.Value(value="x"),
        ),
        tokens.DictEntry(
            tokens.Field(name="b", start_position=tokens.Position(line=1, char_index=2)),
            tokens.Value(value=True),
        ),
    ])


# Generated at 2022-06-24 11:07:21.503157
# Unit test for function validate_with_positions
def test_validate_with_positions():

    field = Field(title="Title", required=True)
    token = Token(
        "document",
        [
            Token("chapter", [Token("title", "Foo", [0, 0], [0, 8])], [0, 0], [0, 8]),
            Token("chapter", [Token("title", "Bar", [4, 0], [4, 8])], [4, 0], [4, 8]),
        ],
        [0, 0],
        [4, 8],
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)

    assert exc_info.value.messages[0].start_position == (4, 0)

# Generated at 2022-06-24 11:07:32.102954
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.scanner import Scanner
    from typesystem.types import Number
    from typesystem.schemas import Schema

    schema = Schema(
        properties={
            "a": Field(type=Number(minimum=0), required=True),
            "b": Field(type=String()),
            "c": Field(
                type=Number(maximum=5),
                required=True,
                allow_null=True,
                allow_blank=True,
            ),
        }
    )


# Generated at 2022-06-24 11:07:43.026374
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Create a simple field
    field = Field(type="string", required=True)

    # Create a simple document
    document = Token.from_py({})

    try:
        validate_with_positions(token=document, validator=field)
        assert False, "no exception was raised"
    except ValidationError as error:
        # The error message should contain an element "name"
        assert error.messages() == [
            Message(
                text="The field 'name' is required.",
                code="required",
                index=("name",),
                start_position=Position(line=0, char_index=0),
                end_position=Position(line=0, char_index=2),
            )
        ]



# Generated at 2022-06-24 11:07:53.864851
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields.dictionaries import Dict
    from typesystem.fields.lists import List
    from typesystem.fields.numbers import Integer
    from typesystem.fields.strings import String
    from typesystem.tokenize import tokenize

    token = tokenize('{"a": null}')

    class MySchema(Schema):
        """My super schema"""

        d = Dict(fields={"a": Integer()})

    schema = MySchema()

    try:
        schema.validate(token.value)
        assert False, "Expected error"
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1, "There should be only one error message"
        assert messages[0].text == "The field 'a' is required."

# Generated at 2022-06-24 11:07:59.446195
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(primitive=str)
    token = Token(value="Hi", start=(1, 1), end=(1, 3))

    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert message.position == (1, 1)

# Generated at 2022-06-24 11:08:08.518515
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.testing import assert_error
    from typesystem.tokenize.tokens import compose

    @compose(start="a", value=1)
    def field():
        from typesystem.fields import Integer
        return Integer()

    assert_error(
        validate_with_positions,
        {"validator": field, "token": "b"},
        messages=[("Invalid index 'b'.", 1, 6)],
    )



# Generated at 2022-06-24 11:08:19.224459
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    from typesystem.base import Message
    from typesystem.tokenize.tokens import Token

    @typesystem.schema
    class UserSchema(typesystem.Schema):
        first_name: str

    user_data = """{
        "first_name": "John"
    }
    """
    user_token = Token.from_value(user_data)

    schema = UserSchema()
    schema.validate(
        user_token.value
    )  # This will work since all required fields are present

    user_data = """{
    }
    """
    user_token = Token.from_value(user_data)

    with pytest.raises(typesystem.ValidationError) as exc:
        schema.validate(user_token.value)


# Generated at 2022-06-24 11:08:23.624877
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(value={"name": "Pascal"}, start=None, end=None)
    assert validate_with_positions(
        token=token, validator=Schema({"name": Field(type="string")})
    ) == {"name": "Pascal"}



# Generated at 2022-06-24 11:08:32.330140
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from collections import OrderedDict
    import yaml
    
    schema = Schema(
        {
            "test": Field(required=False),
            "test_list": Field(type="list", items=Field(type="str")),
            "test_dict": Field(
                type="dict",
                required=False,
                properties={
                    "test": Field(required=False),
                },
            ),
        }
    )
    
    message = "The field 'test' is required."
    message_list = \
        'Item 0: String "foo" is too short. Must be at least 3 characters long.'
    message_dict = "Property 'test' is required."
    
        

# Generated at 2022-06-24 11:08:40.509008
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Tokenizer
    from typesystem.types import String
    from .fixtures import schema, schema_token

    tokenizer = Tokenizer(schema, value=schema_token)
    token = tokenizer.token

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=String(max_length=10))

    error = exc.value
    message = error.messages()[0]
    assert message.text == 'String is too long.'
    assert message.start_position.char_index == 29  # noqa: E241,E501
    assert message.end_position.char_index == 43  # noqa: E241,E501

    with pytest.raises(ValidationError) as exc:
        validate_with_

# Generated at 2022-06-24 11:08:46.537698
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object
    from typesystem.fields import Integer

    class NumberSchema(Object):
        number = Integer()

    token = Token(
        {
            "number": "one"
        },
        start=0,
        end=9,
    )
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=NumberSchema)

    error_messages = exc.value.messages
    error_message: Message

    error_message = error_messages[0]
    assert error_message.code == "invalid_type"
    assert error_message.text == "Expected type integer, found one."
    assert error_message.start_position == Position(0, 8)

# Generated at 2022-06-24 11:08:54.968712
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """Tests that the validate_with_positions function returns the correct excpetion type and with messages containing
    correct positional information.
    """
    from typesystem import String

    with pytest.raises(ValidationError) as e:
        validate_with_positions(
            token=Token(
                value={"name": ""}, start=Position(line_index=0, char_index=0), end=Position(line_index=4, char_index=6)
            ),
            validator=Schema(fields={"name": String(required=True)}),
        )

    message = e.value.messages[0]
    assert message.type is Message
    assert message.text == 'The field "name" is required.'
    assert message.start_position.line_index == 0
    assert message.start_position.char

# Generated at 2022-06-24 11:09:04.904480
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import RootToken
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.visitors import replace_tokens
    from typesystem import String
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.visitors import replace_tokens

    text = """
    {
        name: "John"
    }
    """

    schema = Schema({"name": String()})
    tokens = tokenize(text)
    assert tokens.start == (1, 1)
    assert tokens.end == (5, 1)
    assert tokens.value == {}
    assert tokens.key == None
    assert type(tokens) == RootToken


# Generated at 2022-06-24 11:09:10.237642
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    from typesystem import String, Number

    schema = String[3, 4] + Number[1]

    content = """
        foo
        bar
        1
        2
        3
        4
    """

    token = tokenize(content=content)
    v = validate_with_positions(token=token, validator=schema)
    assert v == "foo1"

# Generated at 2022-06-24 11:09:16.419538
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.primitives import Integer
    from typesystem.core import ValidationError

    token = Token(
        {
            "name": "donald",
            "age": "55",
            "items": [
                {"name": "donald2", "age": "33"},
                {"name": "donald3", "age": "33"},
            ],
        }
    )
    field = Field(name="age", type=Integer())
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)
    messages = exc_info.value.messages
    assert len(messages) == 1
    assert messages[0].text == "The field 'age' must be an integer."
    assert messages[0].start_position.char_index == 15



# Generated at 2022-06-24 11:09:26.999585
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import Integer
    from typesystem.exceptions import Error
    from typesystem.json_schema import JSONEncoder

# Generated at 2022-06-24 11:09:35.321788
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    field = String(name="test")
    validator = field.as_validator()

    token = Token(value="test", start=(0, 1), end=(0, 5))
    assert validate_with_positions(token=token, validator=validator) == "test"
    assert validate_with_positions(token=token, validator=String) == "test"

    # If a field is missing, we expect the error's start_position to be None
    token = Token(value=None, start=(0, 1), end=(0, 1))
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=validator)
    assert exc_info.value.messages[0].start_position is None
   

# Generated at 2022-06-24 11:09:42.854700
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object

    class ObjectSchema(Object):
        field = Field(type="string")

    # Test required
    with pytest.raises(ValidationError) as error:
        validate_with_positions(
            token=Token({"}": {"type": Token.TYPE_PUNCTUATION}}, start=7, end=8),
            validator=ObjectSchema,
        )
    assert error.value.messages[0].start_position.char_index == 7
    assert error.value.messages[0].end_position.char_index == 7
    assert error.value.messages[0].text == "The field 'field' is required."

    # Test invalid type

# Generated at 2022-06-24 11:09:47.659258
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String

    string = String(max_length=3)
    token = Token("foo", start=0, end=3, children=[])

    # No error
    result = validate_with_positions(token=token, validator=String)
    assert result == "foo"

    # With error
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=string)
    message = excinfo.value.messages[0]
    assert message.index == []
    assert message.start_position == 0
    assert message.end_position == 3

# Generated at 2022-06-24 11:09:57.572644
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type="string", pattern="^\\d+$")
    field.format = lambda value: str(int(value))