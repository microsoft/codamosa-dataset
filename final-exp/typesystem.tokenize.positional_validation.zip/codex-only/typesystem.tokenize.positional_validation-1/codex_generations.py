

# Generated at 2022-06-24 10:59:59.656158
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.tokenize import tokenize

    class MySchema(Schema):
        title = String(required=True)

    token = tokenize({})
    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as error:
        assert error.message == "The field 'title' is required."
        assert error.index == ("title",)
        assert error.start_position == token.start
        assert error.end_position == token.end



# Generated at 2022-06-24 11:00:10.330187
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    import dataclasses
    from typesystem.tokenize.token_types import TokenType
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position
    from typesystem.tokenize.streams import TokenStream
    from typesystem.tokenize.lexers import JsonLexer

    class PositionToken(Token):
        start: Position
        end: Position

    class PositionTokenType(TokenType):
        TOKEN_CLASS = PositionToken
        IGNORE_TOKEN = False

    class JsonLexerWithPositions(JsonLexer):
        TOKEN_CLASS = PositionToken
        TOKEN_TYPE_CLASS = PositionTokenType

    @dataclasses.dataclass
    class Hi(typesystem.String):
        pass


# Generated at 2022-06-24 11:00:19.379034
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import JSONSchema
    from typesystem.tokenize.tokens import DataToken, JsonToken
    from . import assert_validation_error
    from .test_tokenize import make_json_token

    def get_error():
        schema = JSONSchema(properties={"foo": {"type": "number"}})
        token = make_json_token({"bar": "baz"}, start_index=0, end_index=7)
        error = assert_validation_error(validate_with_positions, token=token, validator=schema)
        messages = error.messages()

        message = messages[0]
        assert isinstance(message, Message)
        assert message.index == ["foo"]
        assert message.start_position.index == 0
        assert message.start_position

# Generated at 2022-06-24 11:00:25.940662
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import JSONSchema
    assert validate_with_positions(
        token=Token(
            {
                "name": "Alice",
                "age": "22",
                "numbers": [1, 2, 3],
                "owned_by": {"foo": "bar"},
            },
            start=2,
            end=3,
        ),
        validator=JSONSchema(
            {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "age": {"type": "integer"},
                    "numbers": {"type": "array", "items": {"type": "integer"}},
                    "owned_by": {"type": "object", "properties": {"foo": {"type": "string"}}},
                },
            }
        ),
    )

# Generated at 2022-06-24 11:00:37.870992
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem.base import testing
    from typesystem.fields import Integer
    from typesystem.tokenize import tokenize

    class IntegerList(Schema):
        integers = Integer(many=True)

    schema = IntegerList()

    tokens = tokenize("[1, 2, 3, 4]")
    value = validate_with_positions(token=tokens, validator=schema)
    assert value == [1, 2, 3, 4]

    tokens = tokenize("[1, 2, 'foo', 4]")
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=tokens, validator=schema)

# Generated at 2022-06-24 11:00:48.842790
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import TokenTypes
    from typesystem.tokenize import tokenize

    schema = TokenTypes(properties={"foo": TokenTypes()})

    tokens = tokenize("{}", schema)

    try:
        validate_with_positions(token=tokens[0], validator=schema)
    except ValidationError as error:
        assert len(error.messages) == 1
        message = error.messages[0]
        assert message.text == "The field 'foo' is required."
        assert message.start_position.line_index == 0
        assert message.start_position.char_index == 1
        assert message.end_position.line_index == 0
        assert message.end_position.char_index == 1



# Generated at 2022-06-24 11:00:55.502361
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import Tokenizer, Line, Position

    class SimpleSchema(Schema):
        field = Field(type="string")

    class SimpleTokenizer(Tokenizer):
        def find_tokens(self, lines: typing.List[Line]) -> typing.List[Token]:
            return [Token({"field": "foo"})]

    text_file_path = os.path.join(os.path.dirname(__file__), "data", "simple.txt")
    text = open(text_file_path, encoding="utf-8").read()

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(
            token=SimpleTokenizer(text=text).token, validator=SimpleSchema
        )

# Generated at 2022-06-24 11:01:06.364993
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class PersonSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer", minimum=0, maximum=120)
        id = Field(required=False)
        timestamp = Field(type="datetime", required=False)

    class DataSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer", minimum=0, maximum=120)
        person = Field(type=PersonSchema)

    schema = DataSchema()
    data = {
        "name": "Alan Turing",
        "age": 0,
        "person": {"name": "Alan Turing", "age": 0, "id": "AT", "timestamp": "1912-06-23"},
    }

# Generated at 2022-06-24 11:01:08.193470
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-24 11:01:13.581148
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem

    class MySchema(typesystem.Schema):
        foo: str

    token = Token.from_dict({"foo": "b"})
    error = None
    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as exc:
        error = exc

    assert error
    assert error.message == "The field 'foo' is required."
    assert error.start_position
    assert error.end_position



# Generated at 2022-06-24 11:01:26.104534
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Integer, Structure, Schema
    from typesystem.tokenize import Token, TokenizeError

    schema = Schema(Structure({"name": String(), "age": Integer()}))

    token = Token.from_json({"name": "joe", "age": "20"}, "json")

    # Test passing undefined fields.
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=schema)


# Generated at 2022-06-24 11:01:33.976138
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import StructSchema

    class SimpleSchema(StructSchema):
        foo = Field(type="integer")

    from typesystem.tokenize.infer import infer_token_from

    foo = infer_token_from({"foo": "bar"})
    try:
        validate_with_positions(token=foo, validator=SimpleSchema)
    except ValidationError as error:
        assert error.messages()[0].code == "type"
        assert (
            error.messages()[0].text
            == "Value 'bar' is not valid for type 'integer'."
        )
        assert error.messages()[0].start_position.char_index == 5
        assert error.messages()[0].end_position.char_index == 8

# Generated at 2022-06-24 11:01:39.585012
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    token = tokenize("<root><data><key>hello</key></data></root>")
    print(token)
    try:
        validate_with_positions(
            token=token,
            validator=Schema(
                properties={"data": Schema(properties={"key": Field(type="string")})}
            ),
        )
    except ValidationError as error:
        messages = error.messages()
        from pprint import pprint

        pprint(messages)
    else:
        raise RuntimeError("This shouldn't happen.")



# Generated at 2022-06-24 11:01:46.623158
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer

    assert validate_with_positions(
        token=Token(
            value={
                "foo": [{"bar": "x"}, {"bar": "y"}, {"bar": "z"}],
                "numbers": [1, 2, 3, 4],
            },
            start=(1, 0),
            end=(1, 30),
        ),
        validator=Integer(name="numbers", min_length=5),
    ) == {
        "foo": [{"bar": "x"}, {"bar": "y"}, {"bar": "z"}],
        "numbers": [1, 2, 3, 4],
    }


# Generated at 2022-06-24 11:01:55.545610
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token, TokenList

    class Record(Schema):
        name = Field(type="string")
        description = Field(type="string")
        rating = Field(type="integer", required=False)

    tokens = TokenList(
        [
            Token(value="name", start=(1, 0), end=(1, 4)),
            Token(value="description", start=(2, 0), end=(2, 11)),
            Token(value="rating", start=(3, 0), end=(3, 6)),
        ]
    )


# Generated at 2022-06-24 11:02:06.669684
# Unit test for function validate_with_positions
def test_validate_with_positions():
    def validate_positions(text):
        # type: (str) -> typing.Any
        token = Token.from_str(text)
        return validate_with_positions(token=token, validator=Field(required=True))

    try:
        validate_positions("")
    except ValidationError as error:
        message = error.messages()[0]
        assert message.start_position.char_index == 0
        assert message.end_position.char_index == 0
        assert message.text == "The field '' is required."

    try:
        validate_positions("{}")
    except ValidationError as error:
        message = error.messages()[0]
        assert message.start_position.char_index == 0
        assert message.end_position.char_index == 1

# Generated at 2022-06-24 11:02:15.281608
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String  # type: ignore
    from typesystem.tokenize import tokenize

    class UserSchema(Schema):
        name = String(max_length=3)  # type: ignore
        age = String()

    tokens = tokenize({})
    schema = UserSchema()
    try:
        validate_with_positions(token=tokens.lookup("/"), validator=schema)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.start_position.char_index == 1
        assert message.text == "The field 'name' is required."

    tokens = tokenize({"name": "Mary"})

# Generated at 2022-06-24 11:02:26.929621
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_str
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer

    class SimpleSchema(Schema):
        age: Integer
        name: String

    tokens = tokenize_str("{age=23, name=Jakub}")
    token = tokens[0]

    try:
        validate_with_positions(token=token, validator=SimpleSchema)
    except ValidationError as error:
        messages = sorted(
            error.messages(), key=lambda m: m.start_position.line  # type: ignore
        )

# Generated at 2022-06-24 11:02:31.497708
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.types import SchemaType, IntegerType

    class MySchema(Schema):
        a = IntegerType(required=True)
        b = SchemaType(MySchema)

    schema = MySchema()

    values = {"a": 1, "b": {"a": 2, "b": {"a": 3}}}
    token = tokenize(values)
    messages = validate_with_positions(token=token, validator=schema)
    assert messages is None

# Generated at 2022-06-24 11:02:41.392417
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position

    start = Position(line=1, column=1, char_index=0)
    end = Position(line=1, column=10, char_index=9)
    token = Token(
        start=start, end=end, value={"type": "root", "fields": {"name": "name"}},
    )
    schema = {"name": {"type": "string", "required": True}}

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        messages = list(error.messages())
        assert len(messages) == 1
        message = messages[0]
        assert message.start_position.line == start.line

# Generated at 2022-06-24 11:02:48.883493
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import Integer
    from typesystem.tokenize.compiler import compile_token

    schema = {"a": {"b": {"c": Integer()}}}
    token = compile_token({"a": {"b": "hello"}}, schema)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)


# Generated at 2022-06-24 11:02:55.437976
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.common import tokenize_json
    from typesystem.tokenize.parser import parse_json
    import json
    import pytest

    class UserSchema(Schema):
        username = Field(type="string")
        age = Field(type="integer")

    data = {"username": "bob"}
    tokens = tokenize_json(data)
    root_token = parse_json(tokens)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=root_token, validator=UserSchema)
    exc: ValidationError = exc_info.value
    assert "The field 'age' is required." in json.dumps(exc.messages)
    # FIXME
    #

# Generated at 2022-06-24 11:03:02.602386
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import validate_with_positions, Integer
    from typesystem.tokenize.tokens import Token

    integer = Integer()
    value = {"id": 1, "name": "Bob"}
    token = Token.create(value)

    validate_with_positions(token=token, validator=integer)

    try:
        validate_with_positions(token=token, validator=integer)
    except ValidationError as error:
        assert 'The field "id" is required.' in str(error)
        assert 'The field "name" is required.' in str(error)
        assert 'The field "age" is required.' in str(error)

# Generated at 2022-06-24 11:03:09.869723
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(required=True)

    token = Token(value={"name": None})
    value = validate_with_positions(token=token, validator=Person)
    assert value is Undefined
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    message = exc_info.value.messages[0]
    assert message.text == 'The field "name" is required.'
    assert message.code == "required"
    assert message.start_position.line_number == 1
    assert message.start_position.char_index == 2
    assert message.end_position.line_number == 1
    assert message.end_position.char_index == 8

# Generated at 2022-06-24 11:03:19.069876
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json

    from typesystem.schemas import Schema
    from typesystem.tokenize.lexers import Lexer

    from .test import (
        create_schema,
        create_schema_with_fields,
        create_schema_with_required_fields,
    )

    class MySchema(Schema):
        field_one = Field(type="string")
        field_two = Field(type="string")

    schema = MySchema()
    tokens = list(Lexer(json.dumps({"field_one": "test"})))

    try:
        validate_with_positions(token=tokens[0], validator=schema)
    except ValidationError as error:
        messages = error.messages()

    assert len(messages) == 1
    message = messages[0]


# Generated at 2022-06-24 11:03:23.998744
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    content = b'{"number": 123.456, "greeting": "hello", "name": "world"}'
    schema = Schema(fields={"greeting": Field(required=True)})

    with pytest.raises(ValidationError):
        validate_with_positions(token=tokenize(content), validator=schema)

# Generated at 2022-06-24 11:03:32.813366
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema({"name": Field(types=[str])})
    token = Token(
        "schema.name",
        start_line=1,
        start_col=1,
        end_line=1,
        end_col=6,
        value="hello",
    )
    validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-24 11:03:39.900936
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.examples.jsonschema import JsonSchemaField

    field = JsonSchemaField(schema={"type": "number"})

    token = Token(
        "int",
        int,
        source_text="1",
        start=Token.Position(char_index=0, line_index=0),
        end=Token.Position(char_index=1, line_index=0),
    )

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=field)

    assert len(excinfo.value.messages) == 1
    message = excinfo.value.messages[0]
    assert message.text == "expected Integer"
    assert message.code == "invalid"

# Generated at 2022-06-24 11:03:48.733013
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from tests.test_utils.test_fields import Message

    class AuthorSchema(Schema):
        name = String()

    class BookSchema(Schema):
        author = AuthorSchema()
        title = String(min_length=5)

    token = Token.parse(
        {
            "author": {"name": "Graham"},
            "title": "New England",
        }
    )

    class In_Memory_Field(Field):
        """A Field subclass with no coercion methods for testing purposes."""
        def clean(self, value):
            return value

        def serialize(self, value):
            return value


# Generated at 2022-06-24 11:03:58.649655
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem

    # Define a schema for some JSON
    class JSONSchema(typesystem.Schema):
        string = typesystem.String()
        number = typesystem.Number()
        boolean = typesystem.Boolean()
        null = typesystem.Null()

    # Construct a string of JSON
    source = json.dumps(
        {
            "string": "Hello World!",
            "number": 3.14,
            "boolean": True,
            "null": None,
        }
    )

    # Parse the code
    from typesystem.tokenize import parse

    tokens = parse(source)

    # Validate the schema.

# Generated at 2022-06-24 11:04:06.510481
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Object, Integer, fields
    from typesystem.tokenize.tokens import ObjectToken

    class ObjectValidator(Object):
        foo = String(required=True)
        bar = Integer(required=False)

    token = ObjectToken({"foo": "bar"})
    messages = validate_with_positions(token=token, validator=ObjectValidator)

    expected_messages = [
        Message(
            text="The field 'bar' is required.",
            code="required",
            index=["bar"],
            start_position=token['foo'].end,
            end_position=token['foo'].end,
        ),
    ]
    assert messages == expected_messages

    class ObjectValidator(Object):
        foo = fields.Integer()


# Generated at 2022-06-24 11:04:14.828677
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokens import String
    from typesystem.tokenize.parser import parse_string

    def assert_message(message, text, code, index, start_position, end_position):
        assert message.text == text, repr(message.text)
        assert message.code == code
        assert message.index == index
        assert message.start_position == start_position
        assert message.end_position == end_position

    class Person(Schema):
        name = String(min_length=4)
        age = String(pattern="^[0-9]{1,3}$")

    data = '{"name": "Billy", "age": 1.5}'
    token = parse_string(data)

# Generated at 2022-06-24 11:04:22.189753
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(
        {"foo": Field(of=int),},
        self_validations=[
            lambda self, value: validate_with_positions(
                token=value, validator=self
            ),
        ],
    )
    with pytest.raises(ValidationError) as excinfo:
        schema.validate({"bar": 9})
    messages = excinfo.value.messages
    assert len(messages) == 1
    assert messages[0].text == "The field 'foo' is required."
    assert messages[0].start_position == Position(0, 0)
    assert messages[0].end_position == Position(0, 1)
    assert messages[0].code == "required"


# Generated at 2022-06-24 11:04:26.404404
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.fields import TokenizedInteger, TokenizedString
    from typesystem.tokenize.tokens import (
        Array,
        ArrayEnd,
        ArrayStart,
        Char,
        FieldName,
        Object,
        ObjectEnd,
        ObjectStart,
        Value,
    )

    data = '{"a": {"b": [null, 1, "foo"]}}'


# Generated at 2022-06-24 11:04:35.269368
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type="string", required=True)
    token = Token(
        "object",
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 6},
        value={"name": "foo"},
        items=[
            Token(
                "object_key",
                start={"line_index": 1, "char_index": 1},
                end={"line_index": 1, "char_index": 5},
                value="name",
            ),
            Token(
                "string",
                start={"line_index": 1, "char_index": 6},
                end={"line_index": 1, "char_index": 11},
                value="foo",
            ),
        ],
    )

# Generated at 2022-06-24 11:04:44.407031
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.conftest import INTEGER_SCHEMA

    from typesystem.tokenize.tokenizer import Tokenizer
    from typesystem.tokenize.position import Position, TextPositions

    text_positions = TextPositions("""{"a": 0}""")
    tokenizer = Tokenizer(text_positions)
    token = tokenizer.tokenize()

    try:
        validate_with_positions(token=token, validator=INTEGER_SCHEMA)
    except ValidationError as e:
        assert e.messages[0].code == "integer"
        assert e.messages[0].index == ("a",)
        assert e.messages[0].start_position == Position(line=1, column=4, char_index=4)

# Generated at 2022-06-24 11:04:51.958476
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from .tokenize import tokenize

    tokens = tokenize(b'{"foo": "bar"}')
    assert validate_with_positions(token=tokens, validator=String(required=False))
    assert not validate_with_positions(token=tokens, validator=String(required=True))

    tokens = tokenize(b"")
    assert not validate_with_positions(token=tokens, validator=String(required=False))
    assert not validate_with_positions(token=tokens, validator=String(required=True))

# Generated at 2022-06-24 11:05:05.038722
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Array, Integer
    from typesystem.tokenize.tokens import Token

    # Successful validation, no error raised
    token = Token(value=[1, 1, 2, 3, 5, 8, 13])
    result = validate_with_positions(
        token=token, validator=Array(items=Integer(), min_length=3)
    )

    assert result == [1, 1, 2, 3, 5, 8, 13]

    # ValidationError raised with positions of validation messages
    token = Token(value=[1, 1, 2, 3, 5, 8, 13])
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(
            token=token, validator=Array(items=Integer(), max_length=3)
        )


# Generated at 2022-06-24 11:05:13.759700
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from pydantic import BaseModel, Field as ModelField
    from pydantic.error_wrappers import ValidationError as ModelError
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    class User(BaseModel):
        id: int
        name: str

    schema = Schema(
        token_class=Token, fields={"id": ModelField(int, gt=0), "name": ModelField(str)}
    )
    assert validate_with_positions(
        token=Token({"id": -1, "name": "Bob"}, start=(1, 0), end=(1, 11)), validator=schema
    ) == User(id=1, name="Bob")

# Generated at 2022-06-24 11:05:18.994017
# Unit test for function validate_with_positions
def test_validate_with_positions():
    
    # Example of function behaviour
    result = validate_with_positions(
        token=Token(
            key='my_token',
            value=1,
            start=Position(line_index=0, char_index=0),
            end=Position(line_index=0, char_index=1),
            parent=None,
        ),
        validator=Field(primitive_type=int),
    )
    assert result == 1
    result = validate_with_positions(
        token=Token(
            key='my_token',
            value="",
            start=Position(line_index=0, char_index=0),
            end=Position(line_index=0, char_index=1),
            parent=None,
        ),
        validator=Field(primitive_type=str),
    )

# Generated at 2022-06-24 11:05:26.523215
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.base import ValidationError
    from typesystem.fields import String, Integer

    schema = Schema(
        fields={
            "foo": String(max_length=3),
            "bar": Integer(max_value=5),
            "baz": Integer(min_value=5),
            "quuxl": Integer(min_value=10),
            "quuxr": Integer(min_value=10),
        }
    )

    token = tokenize(
        """
        {
            "foo": "hello",
            "bar": -1,
            "baz": 4,
            "quuxl": 1,
            "quuxr": 1
        }
    """
    )

# Generated at 2022-06-24 11:05:35.205239
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema

    class Counter(Field):
        def validate(self, value):
            if value == 123:
                raise ValidationError("This is not a counter.")

    class ListSchema(Schema):
        list = Field(sub_fields=[Counter()])

    schema = ListSchema()
    tokens = tokenize("dict", {"list": [123]})[0]
    try:
        validate_with_positions(token=tokens, validator=schema)
    except ValidationError as error:
        assert str(error) == (
            "This is not a counter.\n"
            "  Start: Line 1, Column 11\n"
            "  End: Line 1, Column 12"
        )

# Generated at 2022-06-24 11:05:43.036288
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import define_schema

    DocumentSchema = define_schema(title=str, age=int)
    try:
        validate_with_positions(
            token=Token(
                value={},
                start=Token.Position(line_no=1, char_no=1, char_index=0),
                end=Token.Position(line_no=1, char_no=14, char_index=13),
            ),
            validator=DocumentSchema,
        )
    except ValidationError as error:
        pass
    else:
        assert False
        raise


# Generated at 2022-06-24 11:05:53.801458
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typing import Type
    from typesystem.fields import String, Integer
    from typesystem.validators import MaxLength
    from typesystem.tokens import StringToken
    from typesystem.schemas import Schema
    from typesystem.fields import Field
    from typesystem.types import ObjectType

    class AnimalType(ObjectType):
        name: Type[String] = String(validators=[MaxLength(6)])
        age: Type[Integer] = Integer()

    def test_validate(validator, token):
        validate_with_positions(token=token, validator=validator)

    def test_invalid(validator):
        token = StringToken('{"name": "tyrion", "age": "8"}', start=(1, 1))

# Generated at 2022-06-24 11:06:04.908888
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Array, Integer, Object, String, Typed

    from .lexer import lex
    from .parser import parse

    schema = Object(
        properties={
            "array": Array(value=Integer()),
            "object": Object(properties={"string": String()}),
        }
    )

    code = """
object = {
  array = [1, "foo", 3],
  object = {
    string = "foo",
  },
}
"""

    code = "\n" + code.strip() + "\n"

    tokens = lex(code=code)
    root_token = parse(tokens=tokens)

    value = validate_with_positions(
        token=root_token, validator=schema
    )  # type: ignore


# Generated at 2022-06-24 11:06:14.801456
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    from tests.utils import parse_json

    token = parse_json('{"x": "foo"}')
    field = String(required=True)

    error = None
    try:
        validate_with_positions(token=token.lookup(["y"]), validator=field)
    except ValidationError as exc:
        error = exc

    assert error
    assert error.messages() == [
        Message(
            code="required",
            text="The field 'y' is required.",
            index=["y"],
            start_position=token.start.child(2, 0),
            end_position=token.start.child(2, 0),
        )
    ]

# Generated at 2022-06-24 11:06:23.891756
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer
    from typesystem.tokenize.tokens import FileToken
    from typesystem.schemas import Schema
    from typesystem.parser import Position, FileText
    from typesystem.tokenize.handlers import tokenize_json

    file_tokens = tokenize_json(
        """[{"name": "a", "age": 1}, {"name": 2, "age": "b"}]""",
        origin="example.json",
    )

    class Person(Schema):
        name = String()
        age = Integer()

    class People(Schema):
        people = Person[:]

    people = People(file_tokens)


# Generated at 2022-06-24 11:06:34.378258
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import IntegerField
    import json
    import pytest
    from hypothesis import given
    from typesystem_jwt.hypothesis import hypothesis_settings
    from typesystem_jwt.hypothesis import valid_json

    @given(json_string=valid_json())
    def test_validate_with_positions(json_string):
        json_object = json.loads(json_string)
        token = tokenize(json_object)
        try:
            validate_with_positions(token=token, validator=IntegerField())
        except ValidationError as error:
            for message in error.messages():
                start_position = message.start_position
                end_position = message.end_position

# Generated at 2022-06-24 11:06:45.704903
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.types import String
    from typesystem.tokenize.parse import tokenize

    token = tokenize(
        {
            "fruits": ["apple", "orange", "banana"],
            "other_fruits": [
                {"type": "grape", "color": "purple"},
                {"type": "kiwi", "color": "green"},
            ],
        }
    )
    schema = Schema({
        "fruits": [String],
        "other_fruits": [
            {
                "type": String(max_length=15),
                "color": String(max_length=15),
            }
        ]
    })
    token = token.resolve("other_fruits", 0)
    
    with pytest.raises(ValidationError) as exc:
        validate_with_

# Generated at 2022-06-24 11:06:52.701199
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem.fields import String, Integer
    from typesystem.schemas import Object

    class Animal(Schema):
        name = String(required=True)
        age = Integer()

    class Person(Schema):
        name = String(required=True)
        age = Integer(required=True)
        animal = Animal(required=True)

    token = Token.from_python(
        {
            "name": "John",
            "age": 30,
            "animal": {"name": "Fluffy", "age": 2},
        }
    )

    validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-24 11:07:04.199221
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import Tokenizer
    from typesystem.schemas import Schema
    from typesystem import fields
    from typesystem.fields import String

    tokenizer = Tokenizer()
    source = '{"name": ["bad", "json"]}'
    tokens = tokenizer.tokenize(source)
    schema = Schema(fields={"name": fields.String()})
    try:
        validate_with_positions(token=tokens, validator=schema)
    except ValidationError as error:
        assert error.messages()[0].start_position.line == 0
        assert error.messages()[0].start_position.char_index == 14
        assert error.messages()[0].end_position.line == 0

# Generated at 2022-06-24 11:07:11.585366
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str, max_length=20)
        age = Field(type=int, gt=18)

    s = """
    {
        "name": "Rob",
        "age": 20
    }
    """

    token = tokenize(s)
    person = validate_with_positions(token=token, validator=Person)
    assert person == {"name": "Rob", "age": 20}

    token = tokenize(s)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person(required=["color"]))

    assert exc_info.type == ValidationError
    message = exc_info.value.message_by_

# Generated at 2022-06-24 11:07:21.349764
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class FooSchema(Schema):
        bar = String(required=True)

    token = Token(value={"foobar": "baz"}, kind="object", name="name")

    try:
        validate_with_positions(token=token, validator=FooSchema)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field bar is required."
        start_position = token.start.copy()
        start_position.row += 2
        start_position.col += 2
        end_position = start_position.copy()
        end_position.row += 1
        end_position.col += 3
        assert message.start_position == start_position

# Generated at 2022-06-24 11:07:25.451962
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import doctest

    doctest.testmod(
        name="validate_with_positions",
        optionflags=doctest.ELLIPSIS,
        extraglobs={"Token": Token, "Field": Field},
    )

# Generated at 2022-06-24 11:07:34.345169
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.tokenize.parser import parse

    schema = Schema({"name": Field(required=True)})
    token = parse("{}")
    with pytest.raises(ValidationError) as e:
        validate_with_positions(validator=schema, token=token)
    assert len(e.value.messages()) == 1
    message = e.value.messages()[0]
    assert message.start_position.char_index == 1
    assert message.end_position.char_index == 2

    schema = Schema({"name": Field(required=True)})
    token = token.lookup("name")
    with pytest.raises(ValidationError) as e:
        validate_with_positions(validator=schema, token=token)

# Generated at 2022-06-24 11:07:39.411387
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import (
        token_with_position,
        tokenize_string,
        tokenize_file,
    )
    from typesystem.schemas import Schema
    import sys
    import json

    class TitleSchema(Schema):
        title = Field(required=True, min_length=5)

    class BookSchema(Schema):
        title = Field(required=True, min_length=5)
        author = Field(required=False, min_length=5)
        year = Field(required=False)

    text = """
    {
        "title": "Python",
        "author": "Guido",
        "year": 1995
    }
    """

# Generated at 2022-06-24 11:07:46.602534
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object
    from typesystem.tokenize.tokens import TextToken
    from typesystem.fields import String as StringField
    from typesystem import types

    class PersonSchema(Object):
        first_name = StringField(required=True)
        last_name = StringField(required=True)

    token = TextToken(
        value={
            "first_name": "",
            "last_name": "",
            "nonexistent_field": "",
        },
        start=Location(line=1, char_index=1),
        end=Location(line=3, char_index=2),
    )
    try:
        PersonSchema.validate(token.value)
    except ValidationError as error:
        messages = error.messages()

# Generated at 2022-06-24 11:07:55.547858
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import parse_json
    from typesystem.fields import Integer
    from typesystem.schemas import Object

    schema = Object({"number": Integer()})
    token = parse_json('{"number": "x"}')
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.start_position == token.lookup(["number"]).start
        assert message.end_position == token.lookup(["number"]).end
        assert message.code == "invalid-type"
        assert message.text == "Expected a number."

# Generated at 2022-06-24 11:08:06.529946
# Unit test for function validate_with_positions
def test_validate_with_positions():
    def assert_correct_error(
        json_value,
        error_JSON,
        tokenizer,
        validator,
        expected_output,
        expected_message,
    ):
        token = tokenizer(json_value)
        try:
            validate_with_positions(token=token, validator=validator)
        except ValidationError as err:
            assert err.to_json() == error_JSON
            assert err.message() == expected_message
            assert str(err) == expected_output
        else:
            assert False

    schema = Schema.parse_string("string")

# Generated at 2022-06-24 11:08:17.578333
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json

    from typesystem.tokenize.tokenize import tokenize

    text = """
    {
        "name": "John Smith",
        "age": 10,
        "friends": ["Alice", "Bob"],
        "address": {
            "zipcode": "12345",
            "city": "New York"
        }
    }
    """
    tokens = tokenize(text)
    token = tokens[0]
    assert validate_with_positions(token=token, validator=Field(accepts=dict)) == json.loads(text)

    class Person(Schema):
        name = Field(accepts=str)
        age = Field(accepts=int)
        friends = Field(accepts=[str])
        address = Field(accepts=dict)


# Generated at 2022-06-24 11:08:23.761078
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class MySchema(Schema):
        name = Field(required=True)

    bad_data = {"no_name": {"here": []}}
    token = Token(bad_data)
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=MySchema)


# Generated at 2022-06-24 11:08:30.160530
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import JSONSchema

    token = Token(value={"bar": {"baz": [1, 3]}}, start=[], end=[])

    schema = JSONSchema({"additionalProperties": False})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    message = exc_info.value.messages()[0]
    assert message.start_position == token.start
    assert message.end_position == token.end



# Generated at 2022-06-24 11:08:36.279532
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import Tokenizer
    from typesystem.tokenize.tokens import ObjectToken
    from typesystem.fields import String

    text = """
    {
        "name": "john doe",
        "age": "50"
    }
    """
    tokenizer = Tokenizer(text)
    tokenizer.tokenize()
    object_token = ObjectToken(tokenizer.tokens[0])
    string_token = object_token.lookup(["name"])

    result = validate_with_positions(
        token=string_token, validator=String(max_length=10)
    )
    assert result == "john doe"

# Generated at 2022-06-24 11:08:41.646757
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # type: () -> None
    from typesystem.base import ValidationError
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Entry(Schema):
        title = String()

    data = u'{"title": "hello"}'
    token = Token()
    token.tokens = [Token(Type="Object", value=data)]

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=token.tokens[0], validator=Entry()  # type: ignore
        )

    assert exc_info.value.messages()[0].start_position.char_index == 1



# Generated at 2022-06-24 11:08:52.114398
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import String

    token = tokenize(b'{"name": "foo", "age": "twenty"}')
    schema = {
        "name": String(),
        "age": String(),
        "email": String(required=True),
    }
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    messages = exc_info.value.messages
    messages = sorted(
        messages, key=lambda m: m.start_position.char_index  # type: ignore
    )
    assert len(messages) == 2
    assert messages[0].code == "required"

# Generated at 2022-06-24 11:09:01.001797
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.positions import Position, Range

    start = Position(line_index=2, char_index=2)
    end = Position(line_index=3, char_index=5)
    range_ = Range(start=start, end=end)
    token = Token(value=set(), range=range_)
    field = Field(name="field", validators=[lambda v: v])
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=field)
    message = error.value.messages[0]
    assert message.start_position == start
    assert message.end_position == end
    assert message.index == ["field"]

# Generated at 2022-06-24 11:09:10.836150
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token
    from typesystem.typing import String

    class ClassSchema(Schema):
        field = String(required=True)


# Generated at 2022-06-24 11:09:21.550035
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .test_parser import tokenize
    from .test_validator import Person, PersonSchema

    s = """
    {
        "name": null,
        "phone": "1234567890",
        "gender": "unknown",
    }
    """
    token = tokenize(s)
    assert validate_with_positions(token=token, validator=Person) == Person(
        name=None, phone="1234567890", gender="unknown", age=None
    )

    s = """
    {
        "name": null,
        "phone": "1234567890",
        "gender": "unknown",
    }
    """
    token = tokenize(s)

# Generated at 2022-06-24 11:09:31.638095
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from collections import namedtuple
    from typesystem.base import PositionalMark, ValidationError
    from typesystem.fields import Field, Integer
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.errors import TokenizedError, TokenizedErrorReason

    # This field requires a value of 1
    class FooField(Field):
        def validate(self, value):
            if value != 1:
                raise ValidationError(messages=[Message(code="invalid", text="")])
            return value

    # The token should just look like this, with the line and column values defined

# Generated at 2022-06-24 11:09:40.911493
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, ListToken, DictToken, StringToken

    class MySchema(Schema):
        required_field = Field(type=str, required=True)

    token = DictToken(
        value={
            "required_field": "hello",
            "not_required_field": 1,
            "list_field": [
                DictToken(value={"string_field": "nested-1"}),
                DictToken(value={"string_field": "nested-2"}),
                DictToken(value={"integer_field": 1}),
            ],
        },
        start=(10, 10),
        end=(10, 100),
    )


# Generated at 2022-06-24 11:09:51.566297
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    schema = Schema({"name": {"first": str, "last": str}})

    error = None
    try:
        validate_with_positions(
            token=tokenize({"name": {"first": "Mike", "last": ""}}), validator=schema
        )
    except ValidationError as e:
        error = e

    assert error is not None
    assert len(error.messages()) == 1
    message = error.messages()[0]
    assert message.text == "String value expected."
    assert message.code == "invalid_type"
    assert message.index == ("name", "last")
    assert message.start_position.line == 1
    assert message.start_position.char_index == 24
    assert message.end_position