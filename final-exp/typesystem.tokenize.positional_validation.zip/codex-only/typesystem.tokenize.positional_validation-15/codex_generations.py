

# Generated at 2022-06-24 11:00:01.185785
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import datetime
    import typing
    import typesystem
    from typesystem.base import Message, ValidationError
    from typesystem.fields import Field
    from typesystem.forms import Form
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    from typesystem_json.tokenize import json
    from typesystem_json.tokenize import tokenize

    # NOTE:
    #
    # To make this work, I had to do this:
    #
    # sed -i '/jsonschema/"3.0.1"/a\\"start_position": {"type": "integer"},\\n    "end_position": {"type": "integer"},' typesystem/schemas.py
    #
    # This is because typesystem's error messages don't include position info,
    # so

# Generated at 2022-06-24 11:00:10.927458
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typing import List

    from typesystem.fields import String
    from typesystem.errors import Error
    from typesystem.tokenize.tokenize import tokenize

    field = String()
    token = tokenize('{"foo": "bar", "missing": null}')

    def pprint_error(error: Error) -> List[str]:
        messages = sorted(
            error.messages(),
            key=lambda m: m.start_position.line_index,  # type: ignore
        )

        pprint: List[str] = []

# Generated at 2022-06-24 11:00:18.760976
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class MyValidator(Field):
        def to_python(self, value):
            if value != "correct":
                raise ValidationError({"value": "incorrect value"})
            return value

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=Token("incorrect", None), validator=MyValidator())

    [message] = exc_info.value.messages
    assert message.code == "value"
    assert message.text == "incorrect value"
    assert message.start_position == Position(0, 0, 0)
    assert message.end_position == Position(1, 0, 1)

# Generated at 2022-06-24 11:00:25.449089
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokenizer import Tokenizer
    from typesystem.validators import Length

    string = '{"x": "foo", "y": "bar", "z": [{"a": 1}]}'
    tokenizer = Tokenizer(string)
    token = tokenizer.tokenize()
    field = String(validators=[Length(min=10)])
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert error.messages()[0].text == "Ensure this value has at least 10 characters (it has 3)."
        assert error.messages()[0].start_position.line == 0
        assert error.messages()[0].start_position.char_index == 18
        assert error.mess

# Generated at 2022-06-24 11:00:33.508891
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class TestSchema(Schema):
        foo = Field(type="str", required=True)

    token = Token({"foo": "bar"})

    assert validate_with_positions(token=token, validator=TestSchema) == {"foo": "bar"}

    token = Token({})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=TestSchema)

    message = exc_info.value.messages[0]
    assert message.text == "The field 'foo' is required."



# Generated at 2022-06-24 11:00:39.511958
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    from typesystem.tokenize import Tokenizer

    tokenizer = Tokenizer()
    token = tokenizer.tokenize('{"foo": 1}')["payload"]

    try:
        validate_with_positions(token=token, validator=String)
    except ValidationError as error:
        message = next(iter(error.messages()))
        assert message.code == "invalid_type"
        assert message.text == "Expected string."
        assert message.start_position == token.start
        assert message.end_position == token.end
        assert message.index == ["foo"]

    token = tokenizer.tokenize('{"foo": 1}')["payload"].lookup("foo")


# Generated at 2022-06-24 11:00:50.093506
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.cases import (
        DictField,
        IntegerField,
        Position,
        StringField,
        Struct,
    )
    from tests.tokenize import get_tokens
    from typesystem.fields import Array

    class BookSchema(Struct):
        title = StringField()
        pages = IntegerField()
        chapters = Array[DictField({"title": StringField(), "pages": IntegerField()})]

    schema = BookSchema()


# Generated at 2022-06-24 11:00:52.780140
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-24 11:01:01.853657
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Integer, Array, Dict, compute_schema
    from typesystem.tokenize.tokens import (
        Token,
        TokenType,
        BracketToken,
        BracketTokenType,
        ObjectToken,
    )

    # Create simple Token tree

# Generated at 2022-06-24 11:01:10.696703
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parse import parse_string
    from typesystem.tokenize.lex import lex
    from typesystem.schemas import Schema
    from typesystem.validators import Validator, check_type

    class Person(Schema):
        name = Field(type=str, required=True)
        age = Field(type=int)
        is_cool = Field(type=bool)

        class Options:
            default_error_mapping = {
                bool: check_type(type_=bool, required=True, message="Hey!")
            }

        def get_is_cool(self) -> bool:
            return self.name == "John"

    class AlwaysFalseValidator(Validator):
        def validate(self, value):
            return False

    token = parse_string("{}")
    assert validate

# Generated at 2022-06-24 11:01:11.104524
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass  # TODO

# Generated at 2022-06-24 11:01:20.447971
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(
        {
            "name": Field(primitive_type=str, required=True),
            "age": Field(primitive_type=int, required=True),
        }
    )

    token = Token(
        value={
            "name": "Foo",
            "age": "not a number",
        },
        start=Position(line_index=0, char_index=0),
        end=Position(line_index=5, char_index=22),
    )

    try:
        schema.validate(token.value)
    except ValidationError as error:
        positional_error = validate_with_positions(
            token=token, validator=error.validator
        )
        assert len(positional_error.messages) == 2
        message = positional_error.mess

# Generated at 2022-06-24 11:01:21.679386
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-24 11:01:31.562926
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    # test failure case
    class Person(Schema):
        last_name = Field(str)

    raw_data = {
        "last_name": "Shubin",
        "first_name": "Robert",
    }

    token = Token.from_mapping(raw_data, start=(1, 1), end=(2, 1))

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.code == "required"
        assert message.text == "The field 'first_name' is required."



# Generated at 2022-06-24 11:01:39.586592
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(
        {
            "items": {
                "type": "object",
                "properties": {
                    "id": {"type": "integer"},
                    "name": {"type": "string"},
                    "properties": {"type": "object"},
                },
                "required": ["id", "name"],
            }
        }
    )

    token = Token.parse(
        {
            "items": [
                {
                    "id": 1,
                    "properties": {"color": "red"},
                    "foo": 1,
                },
                {
                    "name": "foo",
                    "properties": {"color": "blue"},
                    "foo": 2,
                },
                {"name": "bar"},
                {},
            ]
        }
    )


# Generated at 2022-06-24 11:01:45.517888
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import ObjectToken
    from typesystem.tokenize.tokens import StringToken
    from typesystem.fields import String

    schema = Schema(properties={"foo": String(min_length=1)})
    token = ObjectToken(
        {"foo": StringToken("bar")},
        start=Position(0, 0, 0),
        end=Position(3, 3, 3),
    )
    value = validate_with_positions(token=token, validator=schema)
    assert value == {"foo": "bar"}



# Generated at 2022-06-24 11:01:55.188177
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer

    from .tokenize import parse_tokens


# Generated at 2022-06-24 11:02:06.379824
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # type: () -> None
    from typesystem import String, Integer, Boolean
    from typesystem.tokenize import tokenize

    class MySchema(Schema):
        name = String(max_length=2)
        age = Integer(minimum=0)
        active = Boolean()

    token = tokenize({"name": "three", "active": "yes", "age": -1})
    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as error:
        assert len(error.messages()) == 3
        name_message, active_message, age_message = error.messages()
        assert name_message.text == "Ensure this field has no more than 2 characters."
        assert name_message.start_position.char_index == 22
        assert name_message

# Generated at 2022-06-24 11:02:14.553429
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.tokenize.tokens import StringToken

    class PersonSchema(Schema):
        name = String()

    token = StringToken('{"name": "John"}', start=0, end=15)
    try:
        validate_with_positions(token=token, validator=PersonSchema())
    except ValidationError as error:
        message = error.messages()[0]
        assert message.start_position.line_number == 1
        assert message.start_position.char_index == 7
        assert message.end_position.char_index == 15
    else:
        assert False, "Validation should fail"

# Generated at 2022-06-24 11:02:21.970839
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    from .utils import convert_error_to_message, ConcreteClass

    validator = ConcreteClass()
    validator.fields["field"] = Field(type="integer")

    # valid value
    assert validate_with_positions(
        token=tokenize("ConcreteClass(field=1)"), validator=validator
    ) == {"field": 1}

    # invalid value
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=tokenize("ConcreteClass(field=invalid)"), validator=validator
        )
    messages = convert_error_to_message(exc_info)
    assert len(messages) == 1
    message = messages[0]

# Generated at 2022-06-24 11:02:30.986637
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    from .conftest import NotRequired

    class TestSchema(Schema):
        """Schema used in tests."""

        field = NotRequired(str)

    token = tokenize([{"field": "test"}])[0]
    validate_with_positions(token=token, validator=TestSchema())

    result = TestSchema.validate({"field": "test"})
    assert result == {"field": "test"}

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=NotRequired(int))

    message = excinfo.value.messages[0]

    assert message.text == "The value should be an integer"
    assert message.start_position.line_index == 0

# Generated at 2022-06-24 11:02:41.072806
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .helper import TextPosition

    token = {
        "foo": {"hello": "world"},
        "bar": "test",
        "buz": [{"buz": 1}, {}, None],
    }

    class FooSchema(Schema):
        foo = Field(sub_fields={"hello": Field(required=True)})
        bar = Field(required=True)
        buz = Field(sub_fields={"buz": Field(required=True)})

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=FooSchema)
    assert len(exc_info.value.messages) == 2

# Generated at 2022-06-24 11:02:48.489282
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize as tokenize_string

    class SimpleSchema(Schema):
        foo = Field("foo")

    token = tokenize_string("{}")
    try:
        validate_with_positions(token=token, validator=SimpleSchema)
    except ValidationError as e:
        messages = e.messages()
        assert len(messages) == 1
        assert messages[0].text == "The field 'foo' is required."

# Generated at 2022-06-24 11:02:55.170717
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse
    from typesystem.tokenize.validators import resolve_validator
    from typesystem.types import String

    schema = parse("name: string")
    assert validate_with_positions(
        token=schema, validator=schema.validators[0]
    ) == resolve_validator(String(), "")

    schema = parse("name: string\nage: integer")
    assert validate_with_positions(
        token=schema, validator=schema.validators[0]
    ) == resolve_validator(String(), "")
    assert validate_with_positions(
        token=schema, validator=schema.validators[1]
    ) == resolve_validator(String(), "")

    schema = parse("name: string\n")

# Generated at 2022-06-24 11:03:01.362530
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Container, Member

    class Person(Schema):
        name = Member(type=str, required=True)

    token = Token.parse('{"name": null}')
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=Person)
    assert excinfo.value.messages[0].start_position.line == 1
    assert excinfo.value.messages[0].start_position.column == 12

# Generated at 2022-06-24 11:03:08.901971
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class PetSchema(Schema):
        name = Field(type="string")
        type = Field(type="string", choices=["Dog", "Cat"])

    schema = PetSchema()

    token = Token(
        value={
            "name": "Rover",
            "type": "Dog",
            "owner": {"name": "Foo", "age": 10},
            "friends": [{"name": "Bar", "age": 20}],
        },
        location={
            "path": [],
            "start": {"line_number": 1, "char_index": 0},
            "end": {"line_number": 24, "char_index": 31},
            "file": "",
        },
    )

    assert validate_with_positions(token=token, validator=schema) == token.value

   

# Generated at 2022-06-24 11:03:16.151039
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class Person(Schema):
        name = Field(type="string")

    token = Token(
        {
            "name": "John",
            "age": 25,
        },
        start=StartPosition(line_number=1, char_index=0),
        end=EndPosition(line_number=1, char_index=1),
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'age' is not allowed."
        assert message.start_position == token.start
        assert message.end_position == token.end

# Generated at 2022-06-24 11:03:26.667446
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type="integer")

    token = Token(value=None, start={"line_number": 1, "char_index": 3}, end={"line_number": 1, "char_index": 5})
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field None is required."
        assert message.code == "required"
        assert message.start_position == {"line_number": 1, "char_index": 3}
        assert message.end_position == {"line_number": 1, "char_index": 5}


# Generated at 2022-06-24 11:03:36.187172
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.positions import Position
    from typesystem.tokenize.tokens import Token

    token = Token(
        name="my_token",
        value={"first": "John", "last": "Smith"},
        start=Position(char_index=0, line_index=0),
        end=Position(char_index=12, line_index=0),
    )
    errors = validate_with_positions(token=token, validator=PersonSchema)
    assert len(errors.messages) == 1
    assert errors[0]["text"] == "The field {'middle'} is missing. You must provide exactly one value."
    assert errors[0]["code"] == "missing"



# Generated at 2022-06-24 11:03:41.368340
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.jsonschema import tokenize_jsonschema
    from typesystem.jsonschema import JSONSchema

    schema = JSONSchema({"type": "integer"})
    token = next(iter(tokenize_jsonschema("foo", schema)))
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    assert exc_info.value.messages()[0].start_position.char_index == 0
    assert exc_info.value.messages()[0].start_position.line_index == 0
    assert exc_info.value.messages()[0].start_position.column_index == 0
    assert exc_info.value.messages()[0].end_position.char_

# Generated at 2022-06-24 11:03:49.502376
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.errors import ParseError
    from typesystem.fields import Integer
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import List

    input_text = "[1, , 3, , 5]"

# Generated at 2022-06-24 11:03:59.000453
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.base import Message
    from typesystem.fields import Integer
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        foo = Integer(min_value=3)

    tokens = tokenize("{}")
    result = validate_with_positions(token=tokens, validator=TestSchema)
    assert result == {}
    try:
        tokens = tokenize(
            """
        {
            "foo": 2
        }
        """
        )
        validate_with_positions(token=tokens, validator=TestSchema)
    except ValidationError as error:
        messages = []

# Generated at 2022-06-24 11:04:09.223725
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    import json
    from typesystem.tokenize.parse import parse_string

    class PersonSchema(typesystem.Schema):
        name = typesystem.String(required=True)
        age = typesystem.Integer(min_value=0, max_value=100)


    data = json.dumps({"name": "Joe", "age": "uh oh"})
    tokens = parse_string(data)

# Generated at 2022-06-24 11:04:16.961776
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class MySchema(Schema):
        foo = Field(type="integer")

    token = Token.parse(MySchema, {"bar": "none"})

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=MySchema)

    assert exc_info.value.messages() == [
        Message(
            text="The field 'foo' is required.",
            code="required",
            index=["foo"],
            start_position=token.start,
            end_position=token.end,
        )
    ]



# Generated at 2022-06-24 11:04:23.303044
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class MyField(Field):
        pass

    class MySchema(Schema):
        field = MyField(required=True)

    @MyField.validator(pre=True)
    def check_even(instance, value):
        if value % 2 != 0:
            raise instance.error("yeah, no")

    value = [0, 1, 2]

    token = Token(value=value, start=0, end=100)
    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as error:
        for message in error.messages():
            assert message.code == "required"
            assert message.text == "The field 'field' is required."
            assert message.start_position.char_index == 1
            assert message.end_position.char_index

# Generated at 2022-06-24 11:04:33.830442
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem.schemas import Schema
    from typesystem.fields import Boolean
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.lexers import SimpleLexer, SimpleToken

    from typesystem.validators import validate_with_positions

    class CounterLexer(SimpleLexer):
        def get_tokens(self, text: str) -> typing.List[SimpleToken]:
            return [
                SimpleToken(
                    token_type="counter",
                    start_position=0,
                    length=len(text),
                    value=int(text),
                )
            ]

    class SchemaWithPosition(Schema):
        _lexer_class = CounterLexer

    class MySchema(SchemaWithPosition):
        count = Integer(min_value=10)


# Generated at 2022-06-24 11:04:40.867533
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.lexer import lex
    from typesystem.tokenize.parser import parse
    from json import loads

    token = parse(lex(loads('{"foo": false}')))
    print(validate_with_positions(token=token, validator={"foo": bool}))

    try:
        validate_with_positions(token=token, validator={"foo": int})
    except ValidationError as error:
        assert error.messages()[0].start_position.char_index == 8

# Generated at 2022-06-24 11:04:48.102171
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """Unit test for function validate_with_positions
    """
    from typesystem.tokenize.parser import parse

    class TestSchema(Schema):
        foo = Field(type=int, required=True)

    source = '{foo: 2, bar: "three"}'
    token = parse(string=source)

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=TestSchema())

    error_messages = excinfo.value.messages
    assert len(error_messages) == 1
    assert error_messages[0].text == "The field 'bar' is required."
    assert error_messages[0].start_position.line_number == 1
    assert error_messages[0].start_position.char_index == 7

# Generated at 2022-06-24 11:04:54.925692
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(properties={"foo": {"type": "string"}})
    data = {"bar": "baz"}
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=Token(value=data, schema=schema), validator=schema)
    error = excinfo.value
    assert error.messages()[0].start_position == TextPosition(line=1, char_index=1)
    assert error.messages()[0].end_position == TextPosition(line=1, char_index=4)

# Generated at 2022-06-24 11:05:05.212536
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Dict
    from typesystem import Integer
    from typesystem.tokenize.tokens import DictToken, IntegerToken, Token

    class Document(Dict):
        id = Integer()

    tokens = [
        DictToken(start=0, end=1, value=[(Token("id", 0, 4), IntegerToken(0, 4, "foo"))]),
    ]

    try:
        validate_with_positions(token=tokens[0], validator=Document)
    except ValidationError as error:
        assert error.messages[0].text == "Must be a valid integer."
        assert error.messages[0].start_position.char_index == 2
        assert error.messages[0].end_position.char_index == 4

# Generated at 2022-06-24 11:05:13.922052
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.json_schema import JSONSchema
    from typesystem.tokenize import tokenize_json

    schema = JSONSchema({
        'type': 'object',
        'properties': {
            'name': {'type': 'string', 'pattern': '^[a-z]+$'},
            'age': {'type': 'integer'},
        },
        'required': ['name'],
    })

    data = """
    {
        name: "bob",
        age: 64,
    }
    """

    tokens = tokenize_json(data)
    try:
        validate_with_positions(token=tokens, validator=schema)
    except ValidationError as error:
        assert "validation" in str(error)
        messages = list(error.messages())
       

# Generated at 2022-06-24 11:05:23.098970
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem import Integer, String
    from typesystem.tokenize import tokens, tokenize

    class Person(Schema):
        name = String(max_length=5)
        age = Integer(maximum=150)

    token = tokenize(
        {"name": "David", "age": "50"},
        tokens.DictionaryToken,
        {
            "name": tokens.StringToken,
            "age": tokens.IntegerToken,
        },
    )
    validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-24 11:05:33.540999
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class TestSchema(Schema):
        pass

    @TestSchema.field("first")
    def first(value):
        return value

    @TestSchema.field("nested")
    def nested(value):
        return value

    @TestSchema.field("third")
    def third(value):
        return value


# Generated at 2022-06-24 11:05:41.914360
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Integer

    class Person(Schema):
        name = String()
        age = Integer()

    token = Token(Person, {"name": "John", "age": "54"})
    validate_with_positions(validator=Person, token=token)

    token["name"] = ""
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(validator=Person, token=token)
    error_msg = exc_info.value.messages[0]
    assert error_msg.text == "String value is empty."
    assert error_msg.start_position.line == 1
    assert error_msg.start_position.char_index == 10
    assert error_msg.end_position.char_index == 11

    token["age"] = "three"

# Generated at 2022-06-24 11:05:49.501206
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    field = String(min_length=1)

    from typesystem.tokenize.tokenize import tokenize

    token = tokenize("test")
    validate_with_positions(token=token, validator=field)

    token = tokenize("")
    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=token, validator=field)
    assert error_info.value.messages()[0].start_position.char_index == 0



# Generated at 2022-06-24 11:06:00.769545
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize import tokenize, Token

    token = tokenize("""{"foo": 123}""", start_position=(1, 1))
    validator = Integer()
    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'foo' is required."
        assert message.code == "required"
        assert message.index == ["foo"]
        position = message.start_position
        assert position.line == 1
        assert position.column == 1
        assert position.char_index == 0
        position = message.end_position
        assert position.line == 1
        assert position.column == 9
        assert position.char_index

# Generated at 2022-06-24 11:06:01.371852
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-24 11:06:11.243106
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    import typesystem_pyramid

    class Body(typesystem.Schema):
        __typesystem__ = {
            "metadata": {"location": "body", "encoding": "json"}
        }
        name = typesystem.String(max_length=10)
        age = typesystem.String()

    class Query(typesystem.Schema):
        __typesystem__ = {
            "metadata": {"location": "query"}
        }
        name = typesystem.String(max_length=10)
        age = typesystem.String()

    class Request(typesystem_pyramid.Request):
        __typesystem__ = {
            "metadata": {
                "path": "/test"
            }
        }
        querystring = Query()
        body = Body()


# Generated at 2022-06-24 11:06:20.458995
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import yaml
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    from typesystem.tokenize.loaders import StringLoader
    from typesystem.tokenize.tokens import Token

    class TestSchema(Schema):
        name = String()
        age = Integer()

    source = """
    name: John
    age: "30"
    """
    loader = StringLoader(source=source)
    token: Token = loader.load()
    try:
        validate_with_positions(token=token, validator=TestSchema())
    except ValidationError as error:
        assert error

# Generated at 2022-06-24 11:06:26.849394
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.exceptions import ValidationError
    from typesystem.tokenize.tokens import DocumentToken

    class TestSchema(Schema):
        name = Field(required=True, type=str)

    document = DocumentToken([{"token_type": "object", "value": {"name": None}}])

    with pytest.raises(ValidationError):
        validate_with_positions(token=document.children[0], validator=TestSchema)

# Generated at 2022-06-24 11:06:27.812954
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-24 11:06:35.790351
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, List, Object

    schema = Schema(
        properties={
            "name": String(required=True),
            "age": Integer(maximum=100),
            "admins": List(items=Integer()),
        }
    )

    token = Token.from_yaml(
        text="""
        name: "foo"
        age: null
        admins:
          - 1
          - gotcha
    """
    )

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 2
        assert messages[0].start_position.line == 7
        assert messages[0].start_

# Generated at 2022-06-24 11:06:46.469440
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem import fields
    from typesystem import schemas
    from typesystem.schemas import Mapping, Sequence

    schema = Mapping(
        {"a": Mapping({"b": Sequence([Mapping({"c": fields.Integer()})])})},
        start_position=None,
    )

    tokens = tokenize("{'a': {'b': [{'c': 1, 'd': 2}]}}")
    token = tokens[0]  # type: ignore

    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=schema.fields["a"])

    tokens = tokenize("{'a': {'b': [{'c': True}]}}")
    token = tokens[0]  #

# Generated at 2022-06-24 11:06:55.177327
# Unit test for function validate_with_positions
def test_validate_with_positions():
    test_schemas: typing.Dict[str, typing.Any] = {
        "inner_schema": Schema(
            fields={
                "name": Field(required=True),
                "age": Field(required=True),
                "address": Field(required=True),
            }
        ),
        "schema": Schema(
            fields={
                "inner_schema": Field(
                    required=True, type=test_schemas["inner_schema"]
                ),
                "outer_name": Field(required=True),
            }
        ),
    }

    class DocumentToken(Token):
        inner_schema = Token(type=test_schemas["inner_schema"])
        outer_name = Token(required=True)

    # test required fails on None

# Generated at 2022-06-24 11:07:05.602761
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest

    from typesystem.base import Message, ValidationError
    from typesystem.fields import Integer
    from typesystem.tokenize.tokens import CharToken, Token

    tokens = [
        CharToken(type="integer", value="1", start=0, end=0),
        CharToken(type="integer", value="12", start=1, end=1),
        CharToken(type="integer", value="123", start=2, end=2),
    ]
    integer = Integer()

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(
            token=Token(tokens=tokens, start=0, end=2), validator=integer
        )
    assert len(excinfo.value.messages) == 3

# Generated at 2022-06-24 11:07:14.381904
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.types import String

    token = tokenize('{"a": {"b": 1}}')
    validator = String(name="a")
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=validator)

    assert error.value.messages[0].start_position.char_index == 3
    assert error.value.messages[0].end_position.char_index == 12

# Generated at 2022-06-24 11:07:23.401075
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Tok, Pos, tokenize

    schema = Schema(
        {
            "name": Field(type="string"),
            "age": Field(type="integer"),
            "address": Schema(
                {
                    "street": Field(type="string"),
                    "postcode": Field(type="string"),
                    "country": Field(type="string"),
                }
            ),
        }
    )

    def _validate(token, *, validator=schema):
        try:
            return validate_with_positions(
                token=token, validator=validator
            )
        except ValidationError as error:
            return error.messages()


# Generated at 2022-06-24 11:07:33.095239
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import Integer, String, Array
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = String()
        age = Integer()

    class People(Schema):
        people = Array(items=Person())

    token = Token(
        type="object",
        value={"people": [{"name": "Vincent", "age": 12}]},
        start=(2, 3),
        end=(2, 14),
    )

    instance = validate_with_positions(token=token, validator=People())
    assert instance.people[0].name == "Vincent"


# Generated at 2022-06-24 11:07:43.851507
# Unit test for function validate_with_positions
def test_validate_with_positions():
    test_data = json.loads(
        """
    {
        "string": "foo",
        "integer": 123,
        "integer2": 456,
        "float": 123.456,
        "datetime": "2018-12-24T14:30:00+05:00",
        "date": "2018-12-24",
        "time": "14:30:00+05:00",
        "url": "https://example.com/",
        "email": "spam@eggs.biz",
        "enum": "one"
    }
    """
    )
    token = Token.from_python(test_data)

    class TestSchema(Schema):
        string = Field(type="string")
        integer = Field(type="integer", name="integer2")

# Generated at 2022-06-24 11:07:54.258717
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import types, Schema

    class ListSchema(Schema):
        items = types.Array(types.Integer())

    token = Token.new(value=["a", "b", "c"], token_type={"key": "list"})

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=ListSchema())
    assert exc_info.value.messages[0].text == (
        "Value at index 0 is not of type 'integer'."
    )
    assert exc_info.value.messages[0].start_position == (1, 0)
    assert exc_info.value.messages[0].end_position == (2, 0)


# Generated at 2022-06-24 11:08:05.513227
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    from .utils import PositionalToken
    from .utils import Position, PositionSource

    pets = String(enum=["cat", "dog"])

    value_errors = []

    def record_valueerror(err):
        value_errors.append(err)
        raise err

    source = PositionSource(b'{"pets": ["cat", "bird"]}')
    start_position = Position(source, line=1, char_index=15)

    token = PositionalToken(
        value=["cat", "bird"], start=start_position, end=start_position
    )

    try:
        validate_with_positions(validator=pets, token=token)
    except ValueError as err:
        record_valueerror(err)

    assert len(value_errors) == 1  #

# Generated at 2022-06-24 11:08:16.416766
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem import fields, schemas

    schema = schemas.Schema(
        fields={
            "name": fields.StringField(required=True),
            "email": fields.EmailField(required=True),
        }
    )
    token = tokenize(data=b'{"name": "Test"}')

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    messages = exc_info.value.messages()
    assert len(messages) == 1
    message = messages[0]
    assert message.text == "The field 'email' is required."
    assert message.index == ("email",)
    assert message.start_position.line == 2
    assert message.start

# Generated at 2022-06-24 11:08:27.851451
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from pyfakefs.fake_filesystem_unittest import Patcher
    from typesystem.tokenize.positions import Position
    from typesystem.tokenize.tokens import FieldToken, ListToken, ObjectToken


# Generated at 2022-06-24 11:08:35.602763
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.test_tokenize.test_tokens import TokenStub

    class FieldStub(Field):
        def validate(self, value):
            raise ValidationError(self.message, code="invalid")

    field = FieldStub(name="foo")

    token = TokenStub(value=None, start=0, end=1)
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == 'The field "foo" is invalid.'
        assert message.code == "invalid"
        assert message.start_position == 0
        assert message.end_position == 1

# Generated at 2022-06-24 11:08:43.049768
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.main import to_tokens, to_json
    from typesystem.fields import String

    assert isinstance(
        validate_with_positions(
            token=to_tokens(to_json("""{"a": ""}""")), validator=Schema({"a": String()})
        ),
        dict,
    )

    with pytest.raises(ValueError) as e:
        validate_with_positions(
            token=to_tokens(to_json("""{"b": ""}""")), validator=Schema({"a": String()})
        )
    assert (  # Field 'a' is required.
        e.value.messages[0].text == "The field 'a' is required."
    )

# Generated at 2022-06-24 11:08:52.239197
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.validators import required
    from typesystem.tokenize import tokenize

    def parse_article(text: str, *, start: int, end: int) -> typing.List[Token]:
        tokens = list(tokenize(text))
        for token in tokens:
            token.start.char_index += start
            token.end.char_index += end
        return tokens

    text = """
    title: Something
    author: Thijs
    rating: 8
    """

    articles = [
        dict(
            title="Something",
            author="Trudy",
            rating=8,
            text="A great article",
        ),
        dict(
            title="Something",
            author="Thijs",
            rating=8,
        ),
    ]


# Generated at 2022-06-24 11:09:02.447688
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.validators import String
    from typesystem.fields import Integer
    from typesystem.schemas.json_schema import OpenApiSchema
    from typesystem.schemas.meta import MetaSchema

    schema = {
        "type": "object",
        "properties": {
            "a": {"type": "string", "maxLength": 3},
            "b": {"type": "string"},
        },
        "required": ["b"],
    }

    data = {"a": "hello"}
    assert validate_with_positions(
        token=tokenize(data),
        validator=OpenApiSchema(schema=MetaSchema().validate(schema)),
    ) == data

# Generated at 2022-06-24 11:09:11.477981
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.components import Table, Row
    from typesystem.tokenize import Token


# Generated at 2022-06-24 11:09:22.324841
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.exceptions import InvalidType

    from .tokenize.test import tokenize_text
    from .test_base import TestSchema

    schema = TestSchema()

    def assert_token_value(tokens: typing.List[Token], index: typing.List[int]):
        token = tokens
        for i in index:
            token = token[i]
        return token

    tokens = tokenize_text(text=u"""
        {
            title: "Hello, world!",
            field: 42,
            sub: {
                text: "This is a test.",
            }
        }
    """)
    required_field = assert_token_value(tokens=tokens, index=[3, 6])
    validator = schema.validators["field"]
    required_field.value = None  #

# Generated at 2022-06-24 11:09:32.205780
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Token

    from test_typesystem.test_fields import (
        AllowedValuesField,
        AlwaysErrorField,
        AlwaysOkField,
    )

    schema = Schema(
        {"allowed": AllowedValuesField(allowed_values=[0, 1])},
        {"not_allowed": AllowedValuesField(allowed_values=[2, 3])},
    )

    token = Token(
        {
            "allowed": 0,
            "not_allowed": 2,
        },
        start=Token.Point(line_index=0, char_index=0),
        end=Token.Point(line_index=10, char_index=10),
    )


# Generated at 2022-06-24 11:09:41.416726
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import ObjectToken

    class DetailSchema(Schema):
        name = String(required=True)
        title = String()

    class ContactSchema(Schema):
        name = String(required=True)
        details = DetailSchema(required=True)

    token = ObjectToken([("name", "Jane Doe"), ("details", {})])


# Generated at 2022-06-24 11:09:51.668814
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import pytest
    from typesystem.tokenize.tokens import TokenJSON
    from typesystem.fields import Boolean

    json_source = json.dumps({"foo": [True, {}]})
    token = TokenJSON(json_source)
    assert validate_with_positions(token=token, validator=Boolean)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Boolean(required=True))
    assert exc_info.value.messages == [
        Message(
            text='The field "foo" is required.',
            code="required",
            index=(),
            start_position=token.start,
            end_position=token.end,
        )
    ]
