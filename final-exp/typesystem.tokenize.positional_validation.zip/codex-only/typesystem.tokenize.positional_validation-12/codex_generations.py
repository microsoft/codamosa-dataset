

# Generated at 2022-06-24 11:00:01.489351
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import struct, string
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    schema = struct.Struct({"field": string.String(required=True)})

    token = Token(
        kind="struct",
        value={},
        start={},
        end={},
        lookup=lambda index: Token(
            kind="struct",
            value={},
            start={},
            end={},
            lookup=lambda index: Token(
                kind="string",
                value="",
                start={},
                end={},
                lookup=lambda index: Token(
                    kind="string",
                    value="",
                    start={},
                    end={},
                    lookup=lambda index: None,
                ),
            ),
        ),
    )


# Generated at 2022-06-24 11:00:11.106674
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    from typesystem.tokenize import tokenize

    schema = typesystem.Schema(properties={"foo": typesystem.String()})
    tokens = tokenize({"foo": "bar"})
    data = validate_with_positions(token=tokens, validator=schema)
    assert data == {"foo": "bar"}

    schema = typesystem.Object(
        properties={"foo": typesystem.String(required=True)},  # type: ignore
    )
    tokens = tokenize({"foo": "bar"})
    data = validate_with_positions(token=tokens, validator=schema)
    assert data == {"foo": "bar"}


# Generated at 2022-06-24 11:00:20.092207
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import TokenizeError
    from typesystem.tokenize.tokens import Token
    from typesystem.schemas import Schema
    import json

    class UserSchema(Schema):
        name = Field(required=True, max_length=50)
        email = Field(required=True, type="string", pattern="@")
        age = Field(required=True, type="integer")
        is_active = Field(required="boolean")

    class PostSchema(Schema):
        url = Field(required=True, max_length=50)
        user = Field(required=True, type=UserSchema)
        likes = Field(required=True, type="integer")


# Generated at 2022-06-24 11:00:28.675747
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import parse_json

    token = parse_json('{"a": 1, "b": "foo", "c": null}')
    schema = Schema(
        {
            "a": Field(type="integer"),
            "b": Field(type="string"),
            "c": Field(type="integer", required=False),
        }
    )

    validate_with_positions(token=token, validator=schema)

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)
    messages = excinfo.value.messages()
    assert len(messages) == 2
    assert messages[0].start_position == (0, 1)
    assert messages[0].end_position == (0, 4)


# Generated at 2022-06-24 11:00:40.179892
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .utils import make_token

    class UsernameField(Field):
        def __init__(self, *args, **kwargs):
            super().__init__(
                str, error_messages={
                    "min_length": "Username must be at least 5 characters.",
                }, *args, **kwargs
            )

        def validate(self, value, *args, **kwargs):
            return super().validate(value, *args, **kwargs)

    class UserSchema(Schema):
        username = UsernameField(min_length=5)

    token = make_token({"username": "walter"})

# Generated at 2022-06-24 11:00:50.573047
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Tokenizer
    from typesystem.base import Errors
    from typesystem import types


    class Person(Schema):
        name = types.String(min_length=3)


    tokenizer = Tokenizer(Person, line_numbers=True)
    tokens = tokenizer.split('{"name": ""}')

# Generated at 2022-06-24 11:00:55.049855
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Token(typing.NamedTuple):
        value: str

    assert validate_with_positions(token=Token(value="foo"), validator=Field(type=str)) == "foo"



# Generated at 2022-06-24 11:00:56.398860
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass  # TODO

# Generated at 2022-06-24 11:01:04.279605
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.errors import TokenizeError
    import pytest
    from unittest.mock import patch

    class TestSchema(Schema):
        name = Field(required=True, max_length=100)
        age = Field(required=True, min_value=18)

    content = """
    name: A bad name
    age: 16
    """
    with patch.object(TestSchema, "validate", wraps=TestSchema.validate) as mock:
        with pytest.raises(TokenizeError) as exc:
            validate_with_positions(token=tokenize(content), validator=TestSchema)

        assert mock.call_count == 1
        assert mock.call_args == (({},), {})

# Generated at 2022-06-24 11:01:11.548861
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import io
    import typesystem
    import typesystem.tokenize
    import typesystem.tokenize.text

    schema = typesystem.Schema(
        {"string": typesystem.String(min_length=1)},
        input_processor=typesystem.tokenize.text.token_input_processor,
    )

    invalid = io.StringIO('{"string": ""}')
    with pytest.raises(typesystem.ValidationError) as excinfo:
        schema.validate_from_file(invalid)
    assert str(excinfo.value) == (
        "ValidationError: [\n"
        "  'The field \"string\" is required.'\n"
        "  'String value is too short.'\n"
        "]"
    )


# Generated at 2022-06-24 11:01:16.251666
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tests.schema_validator_tests import Book

    token = Token.parse(
        {
            "title": "The Three Musketeers",
            "author": "Alexandre Dumas",
            "pages": 235,
        }
    )
    validate_with_positions(token=token, validator=Book)
    token = Token.parse(
        {
            "title": "The Three Musketeers",
            "pages": 235,
        }
    )
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=Book)
    error = exc.value
    assert len(error.messages()) == 1
    msg = error.messages()[0]

    assert msg.text == "The field 'author' is required."


# Generated at 2022-06-24 11:01:22.974267
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.json_schema import JSONSchema
    from typesystem.tokenize.tokens import Token
    from typesystem.types import String
    from tokenize import tokenize, untokenize, TokenInfo
    from io import BytesIO

    string = '{ "foo": "hello, world" }'

    f = BytesIO(string.encode("utf-8"))
    tokens = tokenize(f.readline)
    schema = JSONSchema.from_field(String(min_length=12))

    token_list: typing.List[TokenInfo] = list(tokens)
    token_list.append(TokenInfo(0, "", (0, 0), (0, 0), ""))
    token_tree = Token.from_list(token_list)


# Generated at 2022-06-24 11:01:33.434279
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.code_generator import CodeGenerator, Token
    from typesystem.tokenize.reader import Reader
    # Generate a Reader
    code_generator = CodeGenerator(
        name="test",
        fields=[
            {"name": "foo", "type": "string"},
            {"name": "bar", "type": "integer"},
            {"name": "baz", "type": "integer"},
            {"name": "qux", "type": "object"},
        ],
        deserializers=['def deserialize(self, data, **kwargs):\n    return data'],
        version=1,
    )
    reader = Reader([code_generator])
    # Generate a token
    schema = reader.get_schema("test")

# Generated at 2022-06-24 11:01:42.811145
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema

    class T(Schema):
        x = 1
        y = 2
        z = 3

    from typesystem.tokenize.tokens import Token

    token = Token(T, {"x": 1, "y": 2, "z": 3})
    validate_with_positions(token=token, validator=T)

    token = Token(T, {"x": 1, "y": 2})
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=T)
    messages = excinfo.value.messages
    assert messages[0].text == 'The field "z" is required.'
    assert messages[0].start_position.line == 1
    assert messages[0].start_position.column == 5

# Generated at 2022-06-24 11:01:54.550661
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Array, Boolean, Integer, String
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import JSONToken, RootToken

    TEST_DATA = """\
    [
        {
            "key": true,
            "value": 42
        }
    ]"""
    schema = Schema(
        fields={
            "key": String(max_length=10),
            "value": Integer(),
        }
    )
    token = JSONToken(RootToken(), [True, 42])
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert error.messages()[0].start_position == (1, 0)

# Generated at 2022-06-24 11:02:05.917498
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Any, Array, Boolean, Integer, Number, String, Tuple
    from typesystem.tokenize.tokens import Token

    token = Token(
        value={"a": 1, "b": [{"c": 1}, {"c": 2}]},
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=1, column=27, char_index=26),
    )

    field = String(max_length=2)

    try:
        validate_with_positions(token=token, validator=field)

        assert False, "validation must always be failed"
    except ValidationError as error:
        messages = list(error.messages())


# Generated at 2022-06-24 11:02:11.441914
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer

    schema = Integer()

    from typesystem.tokenize.tokenize import tokenize_string

    tokens = tokenize_string("typesystem.dict(foo=123, bar=456)", name="test")
    token = tokens.lookup(["bar"])

    assert token.value == 456

    assert validate_with_positions(token=token, validator=schema) == 456

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Integer(min_value=1000))
    [message] = exc_info.value.messages()
    assert message.code == "min_value"
    assert message.text == "Must be at least 1000."
    assert message.start_position.char_index == 30

# Generated at 2022-06-24 11:02:20.430542
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Field(required=True, type="string")

    token = Token(value="foo", start=(1, 1), end=(1, 4))
    validate_with_positions(token=token, validator=schema)
    assert token.value == "foo"

    token = Token(value=None, start=(1, 1), end=(1, 1))
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=schema)
    messages = exc.value.messages
    assert len(messages) == 1
    message = messages[0]
    assert message.code == "required"
    assert message.start_position.line == 1
    assert message.start_position.char_index == 1
    assert message.end_position.line == 1
   

# Generated at 2022-06-24 11:02:28.862866
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize, tokenize_source
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    source = """
    {
        "numbers": [
            1,
            2
        ],
        "name": "joe",
        "password": "secret"
    }
    """
    schema = Schema(
        {"numbers": [Integer()], "name": String(), "password": String(required=True)}
    )
    try:
        validate_with_positions(
            token=tokenize_source(source=source), validator=schema
        )
    except ValidationError as error:
        found = set(map(str, error.messages()))

# Generated at 2022-06-24 11:02:38.558384
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import StringType
    from typesystem.fields import String
    from typesystem.errors import ValidationError

    field = String(required=True)
    data = StringType(data='{"foo": "bar"}')
    value = validate_with_positions(token=data, validator=field)
    assert value == "bar"

    data = StringType(data='{}')
    try:
        value = validate_with_positions(token=data, validator=field)
    except ValidationError as error:
        message = error.messages[0]
        assert message.start_position.line == 1
        assert message.end_position.line == 1

# Generated at 2022-06-24 11:02:46.318802
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(str)
        age = Field(int)

    token = Token.parse(
        {
            "name": "Ponyo",
            "age": "four",
            "favorite_color": "",
            "favorite_food": "peach",
        }
    )

    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-24 11:02:53.673818
# Unit test for function validate_with_positions
def test_validate_with_positions():  # type: () -> None
    class SimpleSchema(Schema):
        foo = Field(type="string")

    token = Token(
        value={"foo": 123},
        start=collections.namedtuple("Position", ("line", "column", "char_index"))(
            1, 0, 0
        ),
        end=collections.namedtuple("Position", ("line", "column", "char_index"))(
            1, 0, 0
        ),
    )
    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=token, validator=SimpleSchema)

    assert len(error_info.value.messages) == 1
    message = error_info.value.messages[0]

# Generated at 2022-06-24 11:03:02.207129
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer
    from typesystem.tokenize.tokens import Token

    token = Token(
        value=[
            {"num": 1, "name": "John Doe"},
            {"num": 2, "name": "Jane Doe"},
        ],
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 4, "char_index": 3},
    )

    validator = List(
        items={
            "num": Integer(),
            "name": String(min_length=3, max_length=100),
        }
    )

    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as exc:
        messages = exc.messages()
        assert len(messages) == 1


# Generated at 2022-06-24 11:03:09.606270
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(
        {"list": [{"name": {"type": "string", "required": True}}], "name": {"type": "string"}}
    )

    # Test required field
    value = {"list": [{"name": "hi"}, {"name": "ho"}]}
    token = Token(schema=schema, value=value)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    assert len(exc_info.value.messages) == 1
    assert exc_info.value.messages[0].text == "The field 'name' is required."
    assert exc_info.value.messages[0].index == ("list", 1, "name")

    # Test required field

# Generated at 2022-06-24 11:03:19.069665
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import type_, types
    from typesystem.tokenize.tokens import Token
    from tests.regression.basic.schema import MovieSchema

    token = Token(
        value={
            "title": "The Terminator",
            "release_date": "1984-10-26",
            "director": "James Cameron",
        }
    )

    movie = validate_with_positions(token=token, validator=MovieSchema())
    assert movie["title"] == "The Terminator"
    assert movie["release_date"] == datetime.date(1984, 10, 26)
    assert movie["director"] == "James Cameron"

    token = Token(value={"title": 1, "release_date": "1984-10-26", "director": 1})


# Generated at 2022-06-24 11:03:27.722787
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema

    class ExampleSchema(Schema):
        title = "Example schema"
        properties = {
            "name": {"type": "string", "required": True},
            "age": {"type": "integer", "required": True},
        }

    from typesystem.tokenize.parser import parse

    example = parse(
        """
        {
          "name": "Paul",
          "age": "32"
        }
        """,
        id="example",
    )

    try:
        validate_with_positions(token=example, validator=ExampleSchema)
    except ValidationError as e:
        error_message = e.messages[0]
        assert error_message.code == "type"
        assert error_message.text == "Not a valid integer."


# Generated at 2022-06-24 11:03:37.283563
# Unit test for function validate_with_positions
def test_validate_with_positions():
    validator = Field(type="string")
    parser = Parser()
    tokens = '{ "foo": "bar" }'
    token = list(parser.parse(tokens))[0]
    assert validate_with_positions(token=token, validator=validator) == {"foo": "bar"}

    token = list(parser.parse(tokens))[0].lookup(["foo"])
    assert validate_with_positions(token=token, validator=validator) == "bar"

    token = list(parser.parse(tokens))[0].lookup(["bar"])
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=validator)

# Generated at 2022-06-24 11:03:46.648883
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema, Object
    from typesystem.tokenize.tokens import Token

    schema = Schema(
        type="object",
        fields={
            "name": {"type": "string", "required": True},
            "dob": {"type": "string", "pattern": "\\d{4}-\\d{2}-\\d{2}"},
        },
    )

    token = Token.parse("{}")
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'name' is required."
        assert message.code == "required"
        assert message.index

# Generated at 2022-06-24 11:03:51.010458
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    validator = String(required=True)
    token = Token(type="string", value="lol")
    validate_with_positions(token=token, validator=validator)
    assert True

# Generated at 2022-06-24 11:03:52.648639
# Unit test for function validate_with_positions

# Generated at 2022-06-24 11:03:57.497490
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class PetSchema(Schema):
        name = Field(type=str)

    token = Token(
        value={
            "name": "Joe"
        },
        start="./pet-schema.json:0:0",
        end="./pet-schema.json:0:12",
    )
    validate_with_positions(token=token, validator=PetSchema)

# Generated at 2022-06-24 11:04:05.944741
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer

    class SizeSchema(Schema):
        width = Integer()
        height = Integer()

    data = {"width": 1, "height": 2}
    token = Token(value=data)
    validate_with_positions(token=token, validator=SizeSchema)
    data = {"width": "a", "height": 2}
    token = Token(value=data)
    exp = dict(
        text="String value found.  Integer value expected.",
        code="invalid",
        start_position=dict(line=1, index=3, char_index=3, column=4),
        end_position=dict(line=1, index=5, char_index=5, column=6),
        index=["width"])


# Generated at 2022-06-24 11:04:16.113517
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Post(Schema):
        id = Field(type="integer")
        title = Field(type="string")
        tags = Field(type="array", items=Field(type="string"))

    token = Token(
        value={
            "id": 123,
            "tags": ["a", 1, "b"],
        },
        start={
            "line": 1,
            "column": 1,
            "char_index": 0,
        },
        end={
            "line": 3,
            "column": 18,
            "char_index": 21,
        },
    )

    try:
        validate_with_positions(token=token, validator=Post)
    except ValidationError as error:
        assert len(error.messages()) == 2

# Generated at 2022-06-24 11:04:16.630471
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-24 11:04:24.071195
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Token
    from typesystem.fields import String, Integer

    class Person(Schema):
        name = String(min_length=1, max_length=5)
        age = Integer()

    sample_json = """
    {
        "name": "John",
        "age": 20
    }
    """

    sample_value = json.loads(sample_json)
    token = Token.from_value(value=sample_value, start=0, end=len(sample_json))
    validate_with_positions(validator=Person, token=token)

    sample_json = '{"name": "John"}'
    sample_value = json.loads(sample_json)
    token = Token.from_value(value=sample_value, start=0, end=len(sample_json))


# Generated at 2022-06-24 11:04:33.868990
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.standard_library import String

    token = Token(
        start=(1, 2),
        end=(1, 7),
        value={
            "foo": "abc",
            "bar": 123,
        },
    )
    schema = Schema(
        fields={
            "foo": String(),
            "bar": String(),
        },
    )
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.start_position.line_number == 1
        assert message.start_position.char_index == 10
        assert message.end_position.line_number == 1

# Generated at 2022-06-24 11:04:43.942907
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(type=str, required=True)

    # missing field
    token = Token(
        value={}, start=Position(file_path="example.md", line=1, char_index=0), end=Position(file_path="example.md", line=1, char_index=4)
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    exc_info.match("The field 'name' is required.")

    # incorrect type

# Generated at 2022-06-24 11:04:53.662177
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.parser import Parser
    from typesystem.tokenize import Tokenizer

    schema = Parser().parse(
        {
            "type": "object",
            "properties": {
                "name": {"type": "string", "minLength": 2},
                "age": {"type": "integer", "minimum": 2},
            },
        }
    )

    data = {"age": 0}
    error_text = (
        "Expected an object with 'name' and 'age'. Got {'age': 0}"
    )
    try:
        validate_with_positions(
            token=Tokenizer().tokenize(data), validator=schema
        )
    except ValidationError as error:
        assert error.messages()[0].text == error_text



# Generated at 2022-06-24 11:05:00.401117
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Import inside test to avoid loop
    from typesystem.tokenize import tokenize, Token
    from typesystem.schemas import Schema
    from unittest.mock import Mock

    class PersonSchema(Schema):
        name = Field(type="string", nullable=False)
        age = Field(type="integer", nullable=False)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=Token(value={}, data=tokenize("{}")[0]),
            validator=PersonSchema(),
        )

    assert len(exc_info.value.messages) == 2
    assert exc_info.value.messages[0].index == []
    assert exc_info.value.messages[1].index == []


# Generated at 2022-06-24 11:05:11.074718
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token

    token = Token(
        value={"value": ""},
        start={"line": 1, "char_index": 1},
        end={"line": 1, "char_index": 10},
    )

    validator = String(required=True)

    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'value' is required."
        assert message.start_position.line == 1
        assert message.start_position.char_index == 1
        assert message.end_position.line == 1
        assert message.end_position.char_index == 10

# Generated at 2022-06-24 11:05:18.445535
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json

    t1 = '{"name": ""}'
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(
            token=Token(json.loads(t1), path=[]),
            validator=Schema({"name": Field(required=True)}),
        )
    exc = excinfo.value
    assert len(exc.messages) == 1
    message = exc.messages[0]
    assert message.text == "The field 'name' is required."
    assert message.start_position.char_index == 8

# Generated at 2022-06-24 11:05:21.078880
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-24 11:05:22.151745
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions() == None

# Generated at 2022-06-24 11:05:32.974891
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Composed, Object

    class Shape(Schema):
        color = Field(str, default="red")
        size = Field(int, default=1)

    class Picture(Object):
        circles = Field(Composed(Shape, many=True, strict=True))
        triangles = Field(Composed(Shape, many=True, strict=True))

    instance = Picture(
        {
            "circles": [
                {"color": "red"},
                {"color": "green", "size": 2},
                {"color": "blue"},
            ],
            "triangles": [
                {"color": "red", "size": 5},
                {"color": "green", "size": 2},
                {"color": "blue"},
            ],
        }
    )

    assert instance.validate() == instance

# Generated at 2022-06-24 11:05:41.492940
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.positions import SourcePosition
    from typesystem.tokenize.tokens import Boolean, DictToken, Integer, ListToken, String
    from typesystem.validators import Integer as IntegerValidator


# Generated at 2022-06-24 11:05:51.357280
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(fields={"name": Field(required=True)})
    token = Token(
        type="start_object",
        start=(1, 0),
        end=(2, 0),
        value={},
        children=[],
        lookup={},
        schema=schema,
    )
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=schema)
    messages = exc.value.messages
    assert len(messages) == 1
    message = messages[0]
    assert message.code == "required"
    assert message.index == ("name",)
    assert message.start_position == Position(line=1, col=0, idx=0)

# Generated at 2022-06-24 11:06:02.552981
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Boolean, Choice, Dictionary, List, Text, Integer

    class User(Schema):
        first_name = Text(max_length=10)
        last_name = Text()
        active = Boolean()
        age = Integer()
        roles = List(
            Choice(items=[Text(enum=["admin", "moderator"])])
        )
        permissions = Dictionary(keys=Text(), items=Integer(minimum=0))

    token = Token.parse({
        "first_name": "john",
        "last_name": "doe",
        "active": True,
        "age": 42,
        "roles": ["admin", "moderator"],
        "permissions": {
            "posts": 10,
            "comments": 20
        },
    })


# Generated at 2022-06-24 11:06:12.198518
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.token import Token, TokenType
    from typesystem.tokenize.tokens import (
        TOKEN_TYPE_TO_FIELD_TYPE,
        FieldType,
    )
    from typesystem.fields import Boolean, Integer

    assert validate_with_positions(
        token=Token(
            value=True,
            token_type=TokenType.BOOLEAN,
            start=1,
            end=2,
            children=[],
        ),
        validator=Boolean,
    ) is True

    assert validate_with_positions(
        token=Token(
            value=123,
            token_type=TokenType.INTEGER,
            start=1,
            end=2,
            children=[],
        ),
        validator=Integer,
    ) == 123


# Generated at 2022-06-24 11:06:20.308321
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.positions import CharIndex, ColumnIndex, LineIndex
    from typesystem.tokenize.tokens import Token, ValueToken

    schema = Schema({"foo": Field(required=True)})
    instance = {
        "foo": [
            {
                "name": "bar",
                "age": 32,
                "address": {
                    "street": "123 Main Street",
                    "city": "Austin",
                    "state": "TX",
                },
            }
        ]
    }
    token = ValueToken(value=instance, start=CharIndex(0), end=CharIndex(200))

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert len(error.messages) == 1

# Generated at 2022-06-24 11:06:26.158244
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(type="string", required=True)

    token = Token({"name": "John"}, 0, 20)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert "Missing data for required field." in str(exc_info)

# Generated at 2022-06-24 11:06:35.269809
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize_from_file_object
    from typesystem.tokenize.positions import Position

    path = os.path.dirname(__file__)
    with open(os.path.join(path, "simple_schema.ts")) as file:
        token = tokenize_from_file_object(file=file)

    class MySchema(Schema):
        name = Field(type="string")

    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as error:
        # The error should contain a single message.
        assert len(error.messages()) == 1

        # The message should be for the missing name field.
        message = error.messages()[0]

# Generated at 2022-06-24 11:06:46.023423
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.core import tokenize
    from typesystem.tokenize.python import PythonType
    from typesystem.schemas import Schema, fields

    class Todo(Schema):
        title = fields.String()
        tags = fields.Array(fields.String())
        done = fields.Boolean()

    token = tokenize({"title": None, "done": True, "tags": None}, PythonType)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Todo())
    messages = exc_info.value.messages
    assert [m.start_position.char_index for m in messages] == [8, 25, 32]

    class Todo(Schema):
        title = fields.String(required=False)


# Generated at 2022-06-24 11:06:54.850095
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Setup
    class User(Schema):
        name = Field(type="string")

    class Comment(Schema):
        user = Field(type=User)

    comment = Comment(
        """
        { 
            user: {
                name: 123
            }
        }
    """
    )
    # Exercise
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=comment.token, validator=comment)
    assert isinstance(error.value.messages[0], Message)
    assert error.value.messages[0].start_position.offset == 35
    assert error.value.messages[0].end_position.offset == 38


# Generated at 2022-06-24 11:07:05.257406
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from jsonschema import validate
    from typesystem.tokenize.parser import parse_json
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import JSONSchema

    schema = {
        "type": "object",
        "properties": {"name": {"type": "string", "required": True}},
        "required": ["name"],
    }

    data = """
    {
        "name": "Eric",
        "age": 35,
        "children": ["Eric Jr.", "Marcus"]
    }
    """
    root_token = parse_json(data)
    field_token = root_token.lookup("properties", "name")

    # Test a field

# Generated at 2022-06-24 11:07:14.021955
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize_document

    class FooSchema(Schema):
        field1: str
        field2: str

    tokenized = tokenize_document({"field1": "value1", "field2": "value2"})
    assert len(tokenized.fields) == 1
    _field = FooSchema.fields["field1"]
    validate_with_positions(token=tokenized.fields[0], validator=_field)

# Generated at 2022-06-24 11:07:22.105282
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token

    token = Token(
        value={
            "name": "Bruce",
            "address": {
                "city": "Gotham",
                "postal_code": "GC",
                "state": "xyz",
                "country": "US",
            },
        }
    )

    class Address(Schema):
        class Meta:
            title = "Address"

        country = String(
            length=2,
            validators=["in:CA,US"],
        )
        state = String(
            length=2,
            validators=["in:CA,US"],
        )
        city = String()

# Generated at 2022-06-24 11:07:27.529603
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem

    class SimpleSchema(typesystem.Schema):
        name = typesystem.String(min_length=1)

    token = Token("{name: 'foo'}")
    validated_data = validate_with_positions(token=token, validator=SimpleSchema)

    assert validated_data == {"name": "foo"}



# Generated at 2022-06-24 11:07:31.875712
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from pygments.token import Whitespace
    from typesystem.tokenize.tokens import Token

    schema = String()
    token = Token("spam", Whitespace, (1, 2), (1, 6), {}, [])
    try:
        validate_with_positions(
            token=token, validator=schema,
        )
    except ValidationError as e:
        assert e.messages()[0].start_position == (1, 2)
        assert e.messages()[0].end_position == (1, 6)

# Generated at 2022-06-24 11:07:43.674960
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import IdentifierToken
    from typesystem.tokenize.tokens import WhitespaceToken

    from typesystem.fields import IntegerField

    identifier = IdentifierToken("foo", start_position=(1, 0))
    whitespace = WhitespaceToken(" ", start_position=(1, 3))

    field = IntegerField()

    # ValidationError positions are correct
    try:
        value = validate_with_positions(token=identifier, validator=field)
    except ValidationError as error:
        assert str(error) == (
            "The field 'foo' is required.\n"
            "The field 'foo' is missing a value.\n"
        )

# Generated at 2022-06-24 11:07:54.048880
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import TextToken, ListToken, MapToken

    token = MapToken(
        start={"row": 1, "column": 2},
        end={"row": 2, "column": 3},
        value={
            "name": TextToken(
                start={"row": 1, "column": 2},
                end={"row": 1, "column": 2},
                value="johndoe",
            ),
            "age": TextToken(
                start={"row": 1, "column": 2},
                end={"row": 1, "column": 2},
                value="old",
            ),
        },
    )
    validator = Schema(
        {"name": Field(type="text", required=True), "age": Field(type="integer")}
    )

# Generated at 2022-06-24 11:08:05.475330
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parse import parse_file
    from typesystem.validators import IntegerValidator, ArrayValidator
    from typesystem.fields.collection import Array
    array = Array(items=IntegerValidator(), min_length=1)
    tokens = parse_file("data/basic.txt")
    array.validate(tokens)
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=tokens, validator=array)

# Generated at 2022-06-24 11:08:14.743530
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type="string")
    # successfully validate a value
    assert validate_with_positions(
        token=Token(value="hello"), validator=field
    ) == "hello"
    # an exception with positional message is raised if value fails validation
    with pytest.raises(ValidationError) as info:
        validate_with_positions(token=Token(value=1), validator=field)
    assert info.value.messages() == [
        Message(
            text="1 is not a string.",
            code="invalid",
            start_position=None,
            end_position=None,
            index=[],
        )
    ]

# Generated at 2022-06-24 11:08:23.078460
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class Person(Schema):
        name = Field(str)
        age = Field(int)
        status = Field(str)

    token = Token(
        value={
            "name": "Monty",
            "age": "Python",
            "status": "Awesome",
            "extra": "data",
        },
        start=Token.Position(
            line_number=1, line_start=0, line_end=0, char_index=0, line_length=0
        ),
        end=Token.Position(
            line_number=2, line_start=0, line_end=0, char_index=0, line_length=0
        ),
    )

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=Person)



# Generated at 2022-06-24 11:08:31.946676
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, String

    class Document(Schema):
        name = String(max_length=1)
        age = Integer()

    token = Token(
        {
            "name": "Dick",  # too long
            "age": 32,
            "position": "Administrative Assistant",  # extra field
            "salary": 100,   # extra field
        }
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Document)
    print(exc_info.value.messages)

    assert exc_info.value.__cause__ is None

    messages = exc_info.value.messages
    assert len(messages) == 2

    message = messages[0]

# Generated at 2022-06-24 11:08:36.864635
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer
    from typesystem.tokenize import tokenize

    schema = Integer(required=True)
    token = tokenize('{"foo": [1, 2, 3]}')

    validate_with_positions(token=token, validator=schema)

    token = tokenize('{"foo": []}')
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-24 11:08:49.469755
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.string import tokenize
    from typesystem.schemas import Object
    from typesystem.fields import String, Integer

    class PersonSchema(Object):
        age = Integer(minimum=18)
        name = String()

    schema = PersonSchema()
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=tokenize("""{"age":12, "name":"John"}""", schema), validator=schema
        )
    error = exc_info.value

    message = error.messages()[0]
    assert isinstance(message.start_position, int)
    assert isinstance(message.end_position, int)
    assert message.start_position == 32
    assert message.end_position == 34
    assert message.text

# Generated at 2022-06-24 11:08:58.295490
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer
    from typesystem.tokenize import parse
    from typesystem.testing import run_validation_test

    schema = type("MySchema", (Schema,), {"my_field": String(min_length=1)})
    token = parse("{}")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    assert exc_info.value.messages()[0].text == 'The field "my_field" is required.'
    assert exc_info.value.messages()[0].start_position == (1, 1)
    assert exc_info.value.messages()[0].end_position == (2, 1)


# Generated at 2022-06-24 11:09:05.822050
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.positions import Positions
    from typesystem.tokenize.tokens import Token
    from typesystem.validators import LengthValidator

    field = String(validators=[LengthValidator(min=2)])

    positions = Positions(
        lines=[
            "",
            "1",
            "4",
            "5",
            "    6",
            "7",
        ]
    )

    # Check basic validation error
    token = Token(
        value={"a": {"b": "", "c": "short"}}, position_mapping=positions
    )
    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=token, validator=field)

    assert error_info.value

# Generated at 2022-06-24 11:09:09.945354
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema({"foo": Field(primitive_type="string")})
    with pytest.raises(ValidationError) as error:
        validate_with_positions(
            token=Token(
                value={},
                start=Token.Position(line=0, char_index=0),
                end=Token.Position(line=0, char_index=1),
            ),
            validator=schema,
        )
    assert error.value.messages()[0].start_position.line == 0
    assert error.value.messages()[0].end_position.line == 0

# Generated at 2022-06-24 11:09:20.914246
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Text

    text = """
{
    "name": "Bob",
    "age": "unknown"
}
"""
    field = Text()

    from typesystem.tokenize.tokens import ObjectToken, TextToken

    token = ObjectToken(children=[
        TextToken(value="Bob", start=(2, 6), end=(2, 9)),
        TextToken(value="unknown", start=(3, 6), end=(3, 13)),
    ])

    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        start = message.start_position
        end = message.end_position
        assert start.line == 3

# Generated at 2022-06-24 11:09:31.205974
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object, Integer, Boolean
    from typesystem.tokenize.lexer import lex

    json_schema = {
        "type": "object",
        "properties": {
            "def": {
                "type": "integer",
                "minimum": 0,
                "maximum": 5
            },
            "ghi": {
                "type": "boolean"
            }
        },
        "required": [
            "def",
            "ghi"
        ]
    }

    schema_class = Object.from_json(json_schema)


# Generated at 2022-06-24 11:09:35.621149
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class MySchema(Schema):
        foo = Field(type="string", required=True)

    data = {"foo": "a"}
    source = json.dumps(data)
    tokens = Tokenizer.tokenize(source=source)
    token = tokens[0]
    validate_with_positions(token=token, validator=MySchema)

# Generated at 2022-06-24 11:09:46.648880
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem import types
    import collections

    schema = types.Schema(
        {
            "username": types.String,
            "email": types.String,
            "address": {
                "line1": types.String,
                "line2": types.String,
                "zipcode": types.String,
            },
        }
    )

    schema(
        {"username": "foobar", "email": "foo@bar.com"}
    )  # should not raise an exception


# Generated at 2022-06-24 11:09:56.622531
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema, Structure
    from typesystem.fields import Integer, String, Boolean
    from typesystem.tokenize import Token, Tokenize
    from typesystem.tokenize.utils import tokenize_json_file, tokenize_yaml_file
    from io import StringIO
    import json
    import pytest

    #
    schema = Schema(
        name="Test Schema",
        fields={
            "name": String(),
            "age": Integer(),
            "registered": Boolean(),
        },
    )

    # Test JSON
    json_string = """
    {
        "name": "Kevin"
    }
    """
    tokens = tokenize_json_file(StringIO(json_string))
    assert isinstance(tokens, list)
    assert len(tokens) == 3