

# Generated at 2022-06-24 11:00:01.320683
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import NoExtraSchema, OrderedSchema

    class DictionaryField(Field):
        def validate_mapping(self, mapping):
            return {
                key: validate_with_positions(
                    token=value, validator=self.child
                )
                for key, value in mapping.items()
            }

    class ObjectSchema(OrderedSchema):
        id = DictionaryField(child=str)

    class RootSchema(NoExtraSchema):
        objects = ObjectSchema(many=True)

    schema = RootSchema()


# Generated at 2022-06-24 11:00:09.981408
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    from . import TestSchema

    schema = TestSchema()
    token = tokenize(schema, {"key": "value"})
    assert isinstance(token, Token)

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text=f"The field {repr('contains')!r} is required.",
                code="required",
                index=["contains"],
                start_position=token.start,
                end_position=token.end,
            )
        ]

# Generated at 2022-06-24 11:00:19.018585
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """Unit test for function validate_with_positions"""
    from typesystem.tokenize.visitors.parser import JSONParser

    class BasicSchema(Schema):
        a = 3
        b = "hello"

    # Add the positional information from the parser
    # (the parser doesn't care about schemas, it just cares about position info)
    parser = JSONParser()
    doc = parser.parse(
        """{
        "a": 3,
        "b": "hello"
    }"""
    )
    try:
        validate_with_positions(token=doc, validator=BasicSchema())
    except ValidationError as error:
        assert error.messages
        assert len(error.messages) == 1
        assert error.messages[0].text == "The field 'c' is required. (missing)"



# Generated at 2022-06-24 11:00:27.926511
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize import decode_json
    from typesystem.tokenize.tokens import Dict, Key, Literal, Sequence, Text

    tokens = decode_json("""
        {
          "name": "Bob",
          "age": "42",
          "jobs": ["plumber", "writer"],
          "addresses": [
            {
              "type": "home",
              "street": "Main"
            },
            {
              "type": "work",
              "street": 123
            }
          ]
        }
    """)

# Generated at 2022-06-24 11:00:39.672935
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem.tokenize.jsonschema

    schema = typesystem.tokenize.jsonschema.tokenize_schema(
        {
            "type": "object",
            "properties": {
                "foo": {"type": "string", "required": True},
                "bar": {"type": "number", "required": True},
            },
        }
    )
    assert validate_with_positions(token=schema, validator=schema).dump() == {
        "foo": "",
        "bar": 0,
    }
    assert validate_with_positions(token=schema, validator=schema).dump() == {
        "foo": "",
        "bar": 0,
    }

    with pytest.raises(ValidationError) as excinfo:
        validate_with_pos

# Generated at 2022-06-24 11:00:50.258214
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import StringToken

    field = String(required=True)
    token = StringToken(value="", start=0, end=1)

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=field)

    assert len(excinfo.value.messages) == 1
    message = excinfo.value.messages[0]
    assert message.text == "The field '' is required."
    assert message.start_position == 0
    assert message.end_position == 1
    assert message.index == ()

    field = String(required=True)
    token = StringToken(value="test", start=0, end=1)

# Generated at 2022-06-24 11:01:01.527567
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem  # noqa

    class Position(typing.NamedTuple):
        line_number: int
        char_index: int

    class PositionedToken(Token):
        def __init__(self, start: Position, end: Position, *, value: typing.Any) -> None:
            self.start = start
            self.end = end
            self.value = value

        def lookup(self, index: typing.Union[str, int, tuple]) -> "Token":
            if isinstance(index, str):
                index = (index,)
            elif not isinstance(index, tuple):
                index = (index,)

# Generated at 2022-06-24 11:01:08.931057
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import TextToken, TokenList
    from typesystem.fields import String
    from typesystem.tokenizers import simple_tokenizer

    tokens = simple_tokenizer("ab c")
    assert validate_with_positions(token=tokens, validator=String()) == "ab c"

    field = String(required=True)
    tokens = TokenList([TextToken("ab c")])
    assert validate_with_positions(token=tokens, validator=field) == "ab c"

    tokens = TokenList([TextToken("")])
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=tokens, validator=field)
    message = excinfo.value.messages[0]

# Generated at 2022-06-24 11:01:19.002522
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.tokenize.utils import tokenize

    list_schema = Schema(name="List", fields={"items": [String(min_length=1)]})

    token = tokenize("[1, 2]", "List")
    value = validate_with_positions(token=token, validator=list_schema)
    assert value["items"][0] == "1"

    token = tokenize("", "List")
    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=token, validator=list_schema)
    positional_error = error_info.value
    assert len(positional_error.messages) == 1

# Generated at 2022-06-24 11:01:29.663456
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(
        {"a": Field(required=True)},
        meta={"source": "for testing"},
        source="for testing",
    )
    token = Token({"a": "x"}, "for testing", start=0, end=10)

    with raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)
    assert len(excinfo.value.messages) == 1
    message = excinfo.value.messages[0]
    assert message.text == "The field 'a' is required."
    assert message.start_position == (1, 2)
    assert message.end_position == (1, 2)



# Generated at 2022-06-24 11:01:36.577781
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokens import JsonTokenizer
    from typesystem.schemas import Object
    from typesystem.fields import String

    class ErrorSchema(Object):
        field1 = String()


# Generated at 2022-06-24 11:01:45.021776
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import TokenizeError

    from typesystem.fields import Integer, String
    from typesystem.schemas import Object
    from typesystem.tokenize.tokens import ObjectToken

    schema = Object({"name": String(), "age": Integer()})
    token = ObjectToken(
        obj={
            "name": "John",
            "age": "42",
            "job": {
                "title": "Python developer",
                "company": "Django Software Foundation",
            },
        },
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 60},
    )

    with pytest.raises(TokenizeError) as excinfo:
        schema.validate(token.value)
    assert excinfo.type == TokenizeError
   

# Generated at 2022-06-24 11:01:54.947235
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from collections import namedtuple
    from typesystem.validators import String
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token

    class TestSchema(Schema):
        field_one = String()
        field_two = String(required=True)

    # Mock the `start` and `end` properties of Token
    class Foo(int):
        @property
        def start(self):
            return None

        @property
        def end(self):
            return None

    Position = namedtuple("Position", ("line_index", "char_index"))

    def lookup(self, index: typing.List[str]) -> "Token":
        return Token(value=None, start=Position(0, 0), end=Position(0, 0), lookup=lookup)

    data

# Generated at 2022-06-24 11:02:01.740427
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        first_name = Field(required=True, min_length=1)
        last_name = Field(required=True, min_length=1)

    from typesystem.tokenize.tokens import ObjectToken

    token = ObjectToken({})
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-24 11:02:09.884869
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer

    class Person(Schema):
        age = Integer()

    token = Token.create({"age": "123"})
    assert validate_with_positions(token=token, validator=Person) == {"age": 123}

    token = Token.create({"age": "abc"})
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=Person)
    assert len(excinfo.value.messages) == 1
    assert excinfo.value.messages[0].start_position == token.lookup(["age"]).start

# Generated at 2022-06-24 11:02:17.086922
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    source = """\
    name: Alex
    age: 10
    """

    # Create a schema
    class PersonSchema(Schema):
        name = Field(required=True, type=str)
        age = Field(required=True, type=int)

    # Parse the source
    tokens = tokenize(source)

    # Validate against the schema
    validate_with_positions(token=tokens, validator=PersonSchema)

# Generated at 2022-06-24 11:02:29.944003
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from . import make_token

    token = make_token(value={}, path=["data"])

    class Dog(Schema):
        name = Field(type="string", required=True)
        sound = Field(type="string")

    try:
        validate_with_positions(token=token, validator=Dog)
    except ValidationError as error:
        assert len(error.messages) == 1

        message = error.messages[0]
        assert message.text == "The field 'name' is required."
        assert message.code == "required"
        assert message.index == ["data", "name"]
        assert message.start_position.line == 1
        assert message.start_position.line_index == 0
        assert message.start_position.char_index == 9

        assert message.end_position.line

# Generated at 2022-06-24 11:02:40.235747
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem

    class Person(typesystem.Schema):
        name = typesystem.String(required=True)
        age = typesystem.Integer(required=True)

    token = Token(
        [
            Token(key="name", value="Molly"),
            Token(key="age", value="forty-two"),
            Token(key="hobbies", value=["chess"]),
        ]
    )

    with pytest.raises(typesystem.ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    messages = exc_info.value.messages
    assert len(messages) == 2

    name_message, age_message = messages

    assert name_message.text == "The field 'hobbies' is required."
    assert name_message.start

# Generated at 2022-06-24 11:02:50.921451
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Object
    from typesystem.tokenize.tokens import ObjectToken

    class ASchema(Object):
        a = String()
        b = Integer()

    schema = ASchema()
    assert validate_with_positions(
        token=ObjectToken(
            {
                "key": KeyToken(0, 4, word="a"),
                "value": StringToken("foo", 10, 14),
                "comma": None,
            },
            start=0,
            end=14,
        ),
        validator=schema["a"],
    ) == "foo"

# Generated at 2022-06-24 11:03:00.623874
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import JSONTokenizer

    class Person(Schema):
        """A simple object schema."""

        name = Field(format="string")
        age = Field(format="integer")

    data = '{"person": {"name": "John", "age": "twenty-nine"}}'
    # Pulled from helper function `assert_error_equal`.
    tokenizer = JSONTokenizer()
    tokens = list(tokenizer(data))
    root = tokens[0]
    person_token = root.lookup("person")
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=person_token, validator=Person)

# Generated at 2022-06-24 11:03:08.249187
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.base import ValidationError
    from typesystem.fields import String, Field

    from .tokens import Token

    class UserSchema(Schema):
        class Meta:
            fields = ["name", "email"]

        name = String(max_length=100)
        email = String(max_length=100, required=True)

    token = Token.from_primitive(
        {"name": "John", "email": "john@example.com"}, position=0
    )
    assert validate_with_positions(
        token=token, validator=UserSchema
    ) == {"name": "John", "email": "john@example.com"}

    token = Token.from_primitive({"name": "John"}, position=0)
    error = pytest

# Generated at 2022-06-24 11:03:16.770896
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.scanner import Scanner

    text = '{"a": 1, "b": null}'
    token = Scanner(text).tokenize()

    schema = Schema.extend(
        a=Field.integer(required=True),
        b=Field.integer(),
    )

    try:
        validated = validate_with_positions(
            token=token, validator=schema
        )
    except ValidationError as error:
        assert error.messages() == [
            Message(
                code="required",
                index=("b",),
                start_position=token.lookup(("b",)).start,
                end_position=token.lookup(("b",)).end,
                text="The field 'b' is required.",
            ),
        ]

# Generated at 2022-06-24 11:03:25.546969
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    from .fields import Int

    token = tokenize("1")[0]

    validate_with_positions(token=token, validator=Int())

    try:
        validate_with_positions(token=token, validator=Int(required=True))
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text.startswith("The field")
        assert message.text.endswith("is required.")
        assert message.code == "required"
        assert message.index == [""]
        assert message.start_position.char_index == 0
        assert message.end_position.char_index == 0

# Generated at 2022-06-24 11:03:34.724825
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_json
    from typesystem.tokenize.tokens import JsonArray, JsonField, JsonNumber, JsonObject
    from typesystem.fields import Array, Boolean, Integer, Object, String

    object_ = Object(properties={"a": Integer(), "b": Boolean(), "c": String()})

    def validate_object_a(token: JsonObject) -> typing.Any:
        value = validate_with_positions(token=token, validator=object_)
        return value

    array_ = Array(items=object_)

    def validate_array_0(token: JsonArray) -> typing.Any:
        value = validate_with_positions(token=token, validator=array_)
        return value


# Generated at 2022-06-24 11:03:36.823299
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema({"name": Field(required=True, primitive_type=str)})
    token = Token.from_value({"name": "Hello"})
    validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-24 11:03:46.225741
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    from typesystem import core

    class PostSchema(typesystem.Schema):
        title = typesystem.String(max_length=200)
        body = typesystem.String(max_length=1000)

    post = core.Object(
        {"title": "The Martian", "body": "based on a true story"},
        schema=PostSchema,
        start=core.Position(line=0, char_index=0),
        end=core.Position(line=0, char_index=113),
    )

    with pytest.raises(core.ValidationError) as e:
        validate_with_positions(token=post, validator=PostSchema())


# Generated at 2022-06-24 11:03:57.565114
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.tokenize.tokens import ArrayToken, FieldToken, ObjectToken
    from typesystem.tokenize.tokens import TextToken

    class SimpleObject(Schema):
        count = Field(type="integer")
        name = Field(type="string")
        optional = Field(type="string", required=False)


# Generated at 2022-06-24 11:04:02.802530
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import Message
    from typesystem.fields import String
    from typesystem.schemas import Object, Schema

    from .tokens import literal_token

    class Person(Schema):
        name = String()

    person = Person()

    validator: Field = person.fields["name"]
    token = literal_token(name="name", value="")


# Generated at 2022-06-24 11:04:15.848857
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Schema
    from .tokenize.tokens import tokenize

    class ObjectSchema(Schema):
        required_string = String()

    schema = ObjectSchema()

    # Test valid object
    token = tokenize({"required_string": "foo"})
    value = validate_with_positions(token=token, validator=schema)
    assert value == {"required_string": "foo"}

    # Test missing required string
    token = tokenize({"bar": "foo"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    assert exc_info.value.messages()[0].code == "required"

# Generated at 2022-06-24 11:04:21.957495
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """
    Tests that the validate_with_positions function
    """

    # JSON string
    json_str = """{ "param": "hello world" }"""

    class MySchema(Schema):
        param = Field(type="string")

    token = Token(json_str)

    # First, test that the non-positional validation works
    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError:
        raise ValueError(
            "The original non-positional validation isn't working!"
        ) from None

    # Now, test that the positional validation works
    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as ex:
        assert len(ex.messages()) == 1

# Generated at 2022-06-24 11:04:32.006419
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class SimpleSchema(Schema):
        s: str
        i: int
        f: float

        class Meta:
            _required = ["s", "i", "f"]

    # NB need to pass in a simple Token graph here
    t = Token({"s": "hello", "i": 1, "f": 0.5})
    val = validate_with_positions(token=t, validator=SimpleSchema)

    assert val == {"s": "hello", "i": 1, "f": 0.5}
    assert val.Token.get("s").start == (1, 1)
    assert val.Token.get("s").end == (1, 6)
    assert val.Token.get("i").start == (1, 7)
    assert val.Token.get("i").end == (1, 8)
   

# Generated at 2022-06-24 11:04:37.596814
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    class MySchema(Schema):
        field = Field(required=True)

    content = b"{}"
    token = Token(value={}, content=content)
    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as error:
        message = next(iter(error.messages()))
        assert message.text == "The field 'field' is required."
        # TODO: write better test



# Generated at 2022-06-24 11:04:46.229165
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer

    field = Integer()
    token = Token("foo", value=42)
    assert field.validate(42) == 42
    assert validate_with_positions(token=token, validator=field) == 42

    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=Integer(minimum=43))

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Integer(minimum=43))

    message = exc_info.value.messages[0]
    assert message.start_position.line == 1
    assert message.start_position.char_index == 0
    assert message.end_position.line == 1
    assert message.end_position.char_index

# Generated at 2022-06-24 11:04:55.816475
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.schemas import Schema
    from typesystem.fields import Field
    from typesystem.tokenize.tokens import ObjectToken

    class PersonSchema(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = ObjectToken(
        start=(5, 2), end=(5, 9), fields=[("name", "Adam"), ("age", "30")]
    )
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=PersonSchema)
    error = excinfo.value
    assert error.messages()[0].index == ["age"]
    assert error.messages()[0].start_position == (5, 8)

# Generated at 2022-06-24 11:05:05.748668
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Required field missing
    token = Token(None, (1, 0), (1, 1))
    field = Field(required=True)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)
    message = exc_info.value.messages()[0]
    assert message.text == "The field None is required."
    assert message.start_position.line == 1
    assert message.start_position.char_index == 0
    assert message.end_position.line == 1
    assert message.end_position.char_index == 1
    # Not an integer
    token = Token(123, (1, 0), (1, 2))
    field = Field(type="integer")

# Generated at 2022-06-24 11:05:14.157435
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.test_tokenize import Position, Token

    token1 = Token(
        "test",
        {"user": {"foo": "hello"}},
        start_position=Position(char_index=0, line_number=1),
        end_position=Position(char_index=5, line_number=2),
    )

    class SecondarySchema(Schema):
        foo = Field(type="string")

    class PrimarySchema(Schema):
        user = Field(type=SecondarySchema)

    token = token1.lookup("user")
    try:
        validate_with_positions(token=token, validator=PrimarySchema)
        assert False, "should have raised an error"
    except ValidationError as error:
        messages = error.messages()

# Generated at 2022-06-24 11:05:24.526106
# Unit test for function validate_with_positions
def test_validate_with_positions():

    # Create a test validator
    class StringValidator(Schema):
        value = Field(types.String)

    # Create a number token
    token = Token(
        type="number",
        value=42,
        start=Position(line_index=1, char_index=2),
        end=Position(line_index=1, char_index=3),
    )

    # Test the validator
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=StringValidator)

    # Check the validation error
    assert len(excinfo.value.messages) == 1
    assert excinfo.value.messages[0].text == 'Value is the wrong type. Expected string, got integer.'

# Generated at 2022-06-24 11:05:33.613447
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenError

    schema = Schema([Field("name", format="ascii")], strict=True)
    token = Token("name", "", [("name", "Django"), ("age", 2)])
    validated = validate_with_positions(validator=schema, token=token)
    assert validated == {"name": "Django", "age": 2}

    token = Token("name", "", [("age", 2)])
    try:
        validate_with_positions(validator=schema, token=token)
    except TokenError as error:
        assert error.token is token
        assert error.messages() == [Message(text="name is required", code="required")]



# Generated at 2022-06-24 11:05:42.015701
# Unit test for function validate_with_positions
def test_validate_with_positions():
    string = "Hello, world"
    token = Token("hello", start=(1, 1), end=(2, 4), root=string)

    class Hello(Field):
        def validate(self, value):
            raise ValidationError({"hello": ["invalid"]})

    class World(Field):
        def validate(self, value):
            raise ValidationError({"world": ["invalid"]})

    class HelloSchema(Schema):
        hello = Hello()
        world = World()

    try:
        validate_with_positions(token=token, validator=HelloSchema)
    except ValidationError as error:
        messages = error.messages()
    else:
        raise AssertionError("Expected a ValidationError to be raised")

    assert messages[0].text == "The field 'hello' is invalid."


# Generated at 2022-06-24 11:05:43.833142
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # TODO
    pass

# Generated at 2022-06-24 11:05:54.572953
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Schema as TypesystemSchema
    from typesystem.types import String

    class MySchema(TypesystemSchema):
        foo = String(max_length=10)
        bar = String(max_length=5)

    from typesystem.tokenize.json import tokenize

    tokens = tokenize({"foo": "hello world", "bar": "foo bar"}, path=".")

    token = tokens[0]["foo"]

# Generated at 2022-06-24 11:06:03.563549
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from pygments import highlight
    from pygments.lexers import JsonLexer
    from pygments.formatters import TerminalFormatter

    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class RequestSchema(Schema):
        name = String(required=True)

    json_string = '{"foo": "bar"}'
    tokens = tokenize(json_string)
    try:
        validate_with_positions(
            token=tokens[0], validator=RequestSchema()
        )
    except ValidationError as error:
        assert len(error.messages()) == 1
        assert error.messages()[0].code == "required"
        assert error.messages

# Generated at 2022-06-24 11:06:04.055079
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass #FIXME

# Generated at 2022-06-24 11:06:13.314130
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.typing import String
    from typesystem.tokenize import tokenize

    p = tokenize('{"foo": "bar"}', source="{'foo': 'bar'}")
    token = p[0]
    string_field = String(name="foo")
    assert validate_with_positions(token=token, validator=string_field) == "bar"

    p = tokenize('{"foo": "bar"}', source="{'foo': 'bar'}")
    token = p[0]
    string_field = String(name="baz")
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=string_field)
    messages = excinfo.value.messages
    assert len(messages) == 1
    message = messages

# Generated at 2022-06-24 11:06:16.867169
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.compiler import compile

    schema = String()
    token = compile("value")

    validate_with_positions(token=token, validator=schema)
    assert token.value == "value"



# Generated at 2022-06-24 11:06:24.057269
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import Integer

    schema = Schema({"key": Integer(required=True)})

    # Try with a missing key
    token = Token({"key": None})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    errors = exc_info.value.messages()
    assert len(errors) == 1
    error = errors[0]
    assert error.index == ["key"]
    assert error.start_position.filename == "typesystem/tokenize.py"
    assert error.start_position.line_index == 0
    assert error.start_position.char_index == 0

# Generated at 2022-06-24 11:06:29.653240
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.core import Integer

    class Child(Schema):
        age = Integer(minimum=0)

    class Test(Schema):
        name = Integer(required=True)
        child = Child()

    from typesystem.tokenize import tokenize

    tokenize("{}", Test)

# Generated at 2022-06-24 11:06:36.495606
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import String
    from typesystem.schemas import Schema

    schema = Schema(
        {"name": String(min_length=2), "age": String(min_length=3)}, required=["name"]
    )
    token = tokenize({"name": "J", "age": "12"}, schema)
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=schema)
    messages = error.value.messages
    assert len(messages) == 2
    assert messages[0].start_position == (1, 4)
    assert messages[0].end_position == (1, 5)
    assert messages[0].text == "String is too short"

# Generated at 2022-06-24 11:06:47.116318
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class AuthorSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    class BookSchema(Schema):
        title = Field(type="string")
        author = Field(type="object", validators=[AuthorSchema])

    json_input = """
    {
        "title": "The Godfather",
        "author": {
            "name": "Mario Puzo",
            "age": 78
        }
    }
    """

    tokens = tokenize(json_input)

# Generated at 2022-06-24 11:06:55.617206
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest

    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    class Foo(Schema):
        foo = String(required=True)
        bar = String(required=True)
        baz = Integer()
        bazbaz = String()


# Generated at 2022-06-24 11:07:05.954035
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class Schema1(Schema):
        foo = Field(type="string", required=False)
        bar = Field(type="string", required=False)

    schema1 = Schema1()
    schema1.validate({"foo": "example"})

    token = Token.parse({"foo": "example"}, start=(0, 0), end=(0, 0))

    validate_with_positions(validator=Schema1(), token=token)

    token = Token.parse({}, start=(0, 0), end=(0, 0))


# Generated at 2022-06-24 11:07:17.420106
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Tokenizer

    tokenizer = Tokenizer()
    token = tokenizer.parse(
        """
        {
            "first_name": "Jane",
            "last_name": null,
            "other_names": ["", "Joe"],
        }
    """
    )

    from typesystem.schemas import Schema

    class Person(Schema):
        first_name = "string"
        last_name = "string"
        other_names = ["string"]

    try:
        validate_with_positions(token=token, validator=Person)
        assert False, "expected ValidationError"
    except ValidationError as error:
        assert len(error.messages) == 2

        first_name_message = error.messages[0]
        assert first_name_message.text

# Generated at 2022-06-24 11:07:25.700989
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class SimpleSchema(Schema):
        name = Field(type=str, max_length=10)

    token = Token({"name": "Bob"}, start=(1, 0), end=(1, 8))

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=SimpleSchema)

    error = exc_info.value
    assert len(error.messages()) == 1

    message = error.messages()[0]
    assert message.text == "Ensure this value has at most 10 characters (it has 3)."
    assert message.code == "max_length"
    assert message.index == ("name",)

    # position is a namedtuple (line, char_index)
    assert message.start_position == (1, 5)
    assert message

# Generated at 2022-06-24 11:07:34.539546
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.test_tokenize import build_tokens
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = Field(type=str, required=True)
        age = Field(type=int)

    tokens = build_tokens([{"name": "John", "age": "abc"}])
    token = tokens[0]

    try:
        validate_with_positions(token=token, validator=PersonSchema)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "Value must be of type 'int'."
        assert message.start_position.line == 1
        assert message.start_position.char_index == 9
        assert message.end_position.line == 1

# Generated at 2022-06-24 11:07:44.517814
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    from typesystem.exceptions import ValidationError
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        id = Integer(required=True)
        name = String(min_length=2)

    tokens = tokenize('{"id": 1, "name": "dave"}')
    assert tokens.value == {"id": 1, "name": "dave"}
    assert tokens.json_pointer == "#"
    validate_with_positions(token=tokens, validator=UserSchema)

    tokens = tokenize('{"id": 1}')
    assert tokens.value == {"id": 1}
    assert tokens.json_pointer == "#"

# Generated at 2022-06-24 11:07:54.947545
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # type: () -> None
    from typesystem.tokenize.lexical import lexical_scan
    from typesystem.tokenize.syntactical import parse
    from typesystem.primitives import Boolean, String

    class Name(Schema):
        first = String()
        last = String()

    class User(Schema):
        name = Name(required=True)
        admin = Boolean(required=True)

    schema = User()

    tokens = lexical_scan("{ name: %s }", "Adam")
    token = parse(tokens)

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)
    message = excinfo.value.messages[0]

# Generated at 2022-06-24 11:08:02.795673
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object

    class Person(Object):
        fields = {"name": Field(type="string")}

    token = Token(
        {},
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 15},
    )
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-24 11:08:10.141031
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from pytest import raises
    from typesystem.validators import String
    from typesystem import parse
    from tests.tokenize.test_simple_types import Int

    int_type = Int()

    string_type = String(min_length=3)

    class TestIntegerSchema(Schema):
        integer = int_type

    class TestSchema1(Schema):
        foo = TestIntegerSchema(required=True)
        bar = string_type(required=True)

    with raises(ValidationError) as exc_info:
        validate_with_positions(
            token=parse("", TestSchema1), validator=TestSchema1()
        )

# Generated at 2022-06-24 11:08:20.419176
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.json import tokenize_json

    class TestSchema(Schema):
        name = Field(str)
        age = Field(int, required=True)

    # For convenience we create a class that can be called directly as a function
    class TestValidator(object):
        def __call__(self, *, token):
            return validate_with_positions(token=token, validator=TestSchema)

    # Set up a tokenizer that uses our validator
    tokenizer = tokenize_json(
        validators={
            "answer": TestValidator(),
        }
    )

    # This shouldn't raise an exception
    tokenizer.validate('{"answer": {"name": "peter", "age": "12"}}')

    # This should raise an exception

# Generated at 2022-06-24 11:08:29.922258
# Unit test for function validate_with_positions

# Generated at 2022-06-24 11:08:36.566347
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokenize import Token

    schema = {"type": "string"}

    errors = None
    try:
        token = tokenize("", schema=schema)
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        errors = error.messages
    assert len(errors) == 1
    assert errors[0].code == "required"
    assert errors[0].start_position == Token.Position(char_index=0, line=1, column=1)
    assert errors[0].end_position == Token.Position(char_index=0, line=1, column=1)



# Generated at 2022-06-24 11:08:49.429850
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from hypothesis import given
    from .hypothesis import test_parse, test_serialize
    from typesystem.schemas import Schema
    from typesystem.tokenize import Tokenizer
    from typesystem.tokenize.tokens import Token

    tokenizer = Tokenizer()

    class TestSchema(Schema):

        uid = Field(type="string", required=True)
        optional = Field(type="string", required=False)

    @given(test_serialize(), test_parse(tokenizer, "a"))
    def test(serialized, token):
        try:
            validate_with_positions(token=token, validator=TestSchema)
        except ValidationError as error:
            assert error.messages()[0].text == "The field 'uid' is required."
    test()

# Generated at 2022-06-24 11:08:58.260495
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parsers import Parser
    from typing import Any

    parser = Parser(
        fields={
            "test": {"type": "string"},
            "list": {"type": "list", "items": {"type": "string", "required": True}},
        }
    )

    value: Any = {"list": [1]}


# Generated at 2022-06-24 11:09:08.355881
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Composable

    class CommentSchema(Composable, Schema):
        title = String()
        body = String()
        email = String(required=False)

    token = Token(
        {
            "title": "Hello World",
            "body": "How are you?",
        },
        start_position=(1, 1),
    )
    try:
        validate_with_positions(token=token, validator=CommentSchema)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1

        message = messages[0]
        assert message.index == ["email"]
        assert message.start_position.line_index == 1
        assert message.start_position.char_index

# Generated at 2022-06-24 11:09:18.659520
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    schema = Schema(
        {
            "name": Field(required=True),
            "age": Field(type="number", required=True),
            "manager": Schema({"name": Field(required=True)}),
        }
    )

    tokens = tokenize("""
{
  "name": "First Name"
}
""")

    token = tokens[0]
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=schema)


# Generated at 2022-06-24 11:09:29.468902
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Array
    from typesystem.fields import String, Integer
    from typesystem.tokenize.parse import parse, Position
    from typesystem.tokenize.tokens import Token

    class Object(Schema):
        name = String()
        age = Integer()

    validator = Array[Object]()
    payload = '[{"name": "Jane"}, {"name": "Doe", "age": 30}]'
    token = parse(validator, payload)

    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as error:
        assert len(error.messages()) == 1
        assert error.messages()[0].start_position == Position(
            line=1, line_index=0, char_index=9
        )
        assert error

# Generated at 2022-06-24 11:09:39.786387
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.lexer import Lexer
    from typesystem.tokenize.parse import parse_value

    lexer = Lexer()

    validator = Field(type="boolean")
    tokens = list(lexer("null"))
    assert list(validator.iter_errors(parse_value(tokens))) == []

    token = parse_value(tokens)
    assert validate_with_positions(token=token, validator=validator) is None

    tokens = list(lexer("foo"))
    token = parse_value(tokens)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Field(type="number"))
    messages = exc_info.value.messages
    assert len(messages) == 1

# Generated at 2022-06-24 11:09:50.159440
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Object, Integer, definition

    object_schema = definition(
        {"name": String, "age": Integer, "favorite_colors": [String]}
    )
    token = Token.from_dict({"name": "Muppy", "age": "8.5"})
    try:
        validate_with_positions(token=token, validator=object_schema)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        message = messages[0]
        assert message.text == "The field 'favorite_colors' is required."
        assert message.start_position.line == 1
        assert message.start_position.column == 1
        assert message.end_position.line == 1

# Generated at 2022-06-24 11:09:59.593273
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import ObjectToken, StringToken

    token = ObjectToken(
        start=None,
        end=None,
        value={
            "first": StringToken(
                start=None, end=None, value="already validated"
            ),
            "second": StringToken(
                start=None,
                end=None,
                value="not yet validated",
            ),
        },
    )
    try:
        validate_with_positions(
            token=token,
            validator=String(required=True, min_length=10),
        )
    except ValidationError as error:
        message = sorted(error.messages(), key=lambda i: i.index)[0]
        assert message.start_position.char_index == 29
       