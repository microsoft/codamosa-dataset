

# Generated at 2022-06-24 11:00:03.170572
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import JSONTokenizer
    from typesystem.schemas import Object

    class ProductSchema(Object):
        id = Field(type="integer")
        name = Field()
        price = Field()

    raw = r"""
    {
        "id": 1,
        "name": "foo",
        "price": "bar",
    }
    """

    tok = JSONTokenizer(raw=raw)
    try:
        validate_with_positions(token=tok.token(), validator=ProductSchema)
    except ValidationError as e:
        assert e.messages()[0].start_position == (2, 32)
        assert e.messages()[1].start_position == (3, 24)
        return
    assert False, "Expected ValidationError"

# Generated at 2022-06-24 11:00:09.452253
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        letter = Field(str, regex=r"^[a-z]$")
        number = Field(str, regex=r"^[0-9]$")

    source = "a1"
    tokens = tokenize(source, start="TestSchema")
    token = tokens[0]
    validate_with_positions(token=token, validator=TestSchema)

# Generated at 2022-06-24 11:00:15.239287
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object

    class Person(Object):
        name = Field(str)
        age = Field(int)
        employed = Field(bool, required=False)

    import json

    person = Person()
    person.validate({"name": "foo", "employed": True})
    person.validate({"name": "foo", "age": 17, "employed": True})
    person.validate({"name": "foo", "age": 17, "employed": False})
    with pytest.raises(ValidationError) as exc:
        person.validate({"name": "foo", "age": 17})

# Generated at 2022-06-24 11:00:23.110279
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize.tokens import Object

    token = Object(value={"a": "1", "b": "2"})

    assert validate_with_positions(
        token=token, validator=Integer()
    ) == {"a": 1, "b": 2}

    try:
        validate_with_positions(
            token=token, validator=Integer(required=True)
        )
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text='The field "c" is required.',
                code="required",
                index=("c",),
                start_position=(1, 12),
                end_position=(1, 12),
            )
        ]


# Generated at 2022-06-24 11:00:33.461458
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem
    from typesystem.tokenize import tokenize

    schema = typesystem.Schema({"name": typesystem.String(required=True)})

    data = {}

    tokens = tokenize(data)
    token = tokens.get("")


# Generated at 2022-06-24 11:00:37.259736
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import types, fields

    class Person(Schema):
        name = fields.String()
        age = fields.Integer()
        friends = types.Array(types.String())

    schema = Person()
    token = Token.parse(dict(name="John", age="40"))
    validate_with_positions(token=token, validator=schema)



# Generated at 2022-06-24 11:00:42.803366
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Arrange
    json_data = "{{'a': 1}}"
    token: Token = Token.parse(json_data)
    schema = Schema(a=Field(int))

    # Act
    try:
        validate_with_positions(token=token, validator=schema)
        assert False
    except ValidationError as error:
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.column == 2
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.column == 3

# Generated at 2022-06-24 11:00:51.980323
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import os
    import json
    import typesystem
    from typesystem.tokenize.tokens import Document
    from typesystem.tokenize.parser import parse

    current_path = os.path.dirname(__file__)
    example_path = os.path.join(current_path, "example.json")
    with open(example_path) as fp:
        example_json = fp.read()
    example = json.loads(example_json)

    class Person(typesystem.Schema):
        name: typing.List[str] = typesystem.String()
        friends: typing.List["Person"] = typesystem.Array(items="self")

    document = parse(example_json)
    try:
        Person.validate(example)
    except ValidationError as error:
        new_messages = []

# Generated at 2022-06-24 11:01:00.763103
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import BaseTokenizer
    from typesystem.tokenize.tokens import TextToken
    from typesystem import types

    class Tokenizer(BaseTokenizer):
        def __init__(self, source: str):
            self._source = source

        @property
        def source(self) -> str:
            return self._source

        def tokenize(self) -> typing.Iterator[Token]:
            yield TextToken(
                tokenizer=self,
                start=self.create_position(line_index=0, char_index=0),
                end=self.create_position(line_index=0, char_index=len(self.source)),
                value=self.source,
            )


# Generated at 2022-06-24 11:01:01.599007
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert False, "not implemented"

# Generated at 2022-06-24 11:01:09.083988
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Boolean, Integer
    from typesystem.schemas import Object
    from typesystem.tokenize import tokenize

    class Person(Schema):
        age = Integer()

    schema = Object(properties={
        "name": {
            "type": "string"
        },
        "person": Person
    })

    token = tokenize("{}")

    # This should throw an error and include the error message
    # but *not* include the `start_position` and `end_position`
    # properties.
    try:
        validate_with_positions(token=token, validator=schema)
        assert False
    except ValidationError as error:
        for message in error.messages():
            assert "start_position" not in message
            assert "end_position" not in message

    #

# Generated at 2022-06-24 11:01:16.338470
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer
    from typesystem.tokenize import tokenize, SourcePosition

    schema = Integer()
    schema.validate = lambda value, *args: validate_with_positions(
        token=token, validator=schema
    )
    source_position = SourcePosition(line_number=1, char_index=1)
    token = tokenize("1", source_position)

    try:
        schema.validate(token.value)
    except ValidationError as error:
        assert error.messages()[0].start_position == source_position
        assert error.messages()[0].end_position == source_position



# Generated at 2022-06-24 11:01:27.849839
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .base import get_tree

    class Address(Schema):
        street = Field(type="string")

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        address = Field(type=Address)

    data = {"name": "foo", "age": "bar", "address": {"street": 1}}
    tree = get_tree(data)
    assert tree.errors == (
        'At path: "age": Invalid type, expected "integer".',
        'At path: "address": At path: "street": Invalid type, expected "string".',
    )

    tree = get_tree(data, Person)

# Generated at 2022-06-24 11:01:38.512528
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.typing import JSONSchema

    from tests.test_tokenize.utils import tokenize

    class Author(Schema):
        id = Field(type=int, required=True)
        name = Field(type=str, required=True)

    class Book(Schema):
        title = Field(type=str, required=True)
        year = Field(type=int, required=True)
        author = Field(type=Author, required=True)

    book = Book(
        title="The Old Man and the Sea",
        year=1952,
        author={"id": "123", "name": "Ernest Hemingway"},
    )

    schema = JSONSchema.generate_schema(book)
    token = tokenize(book, schema)


# Generated at 2022-06-24 11:01:45.669374
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from jsonschema import validate

    schema = {
        "type": "object",
        "properties": {
            "foo": {"type": "string"},
            "bar": {"type": "string"},
            "bat": {"type": "string"},
        },
        "required": ["foo"],
    }

    input_ = """
        {
          foo: 'a',
          bat: 'd',
        }
    """

    try:
        validate(tokenize(input_), schema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'bar' is required."



# Generated at 2022-06-24 11:01:55.245468
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    field = Field(name="foo", type="string", required=True)
    token = tokenize({"foo": "bar"})
    value = validate_with_positions(token=token, validator=field)
    assert value == "bar"

    schema = Schema(
        fields={"foo": Field(name="foo", type="string", required=True)}
    )
    token = tokenize({"foo": "bar"})
    value = validate_with_positions(token=token, validator=schema)
    assert value == {"foo": "bar"}

    token = tokenize({})
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert error.messages()[0].start_

# Generated at 2022-06-24 11:02:04.117539
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.models import Model, Text, fields
    from typesystem.tokenize.tokenizer import tokenize

    class Person(Model):
        name = fields.Text()
        age = fields.Integer()

    token = tokenize({"name": "doug"})
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=Person)
    assert error.value.messages()[0].start_position.line == 1
    assert error.value.messages()[0].start_position.char_index == 6

# Generated at 2022-06-24 11:02:13.675247
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import parse

    class UserSchema(Schema):
        name = Field(type="string")
        email = Field(type="string", required=True)
        age = Field(type="integer")

    user_text = """
    name: "João"
    email: "joao.silva@example.org"
    age: 42"""

    token = parse(user_text)
    assert token.value["name"] == "João"
    assert validate_with_positions(
        token=token, validator=UserSchema
    ) == {"name": "João", "email": "joao.silva@example.org", "age": 42,}

    user_text = """
    name: "João"
    age: 42"""

    token = parse(user_text)
   

# Generated at 2022-06-24 11:02:21.542831
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.scanner import scan

    # Create token
    token = scan(data='{"foo": 1, "bar": "abc"}')

    # Create validator
    class Validator(Schema):
        foo = Field(type="integer")
        bar = Field(type="string")

    # Validate
    try:
        validate_with_positions(token=token, validator=Validator)
    except ValidationError as error:
        # Check message
        message = error.messages()[0]
        assert message.text == 'The field "bar" is required.'
        assert message.code == "required"
        assert message.start_position.line == 1
        assert message.start_position.column == 4
        assert message.start_position.char_index == 3

# Generated at 2022-06-24 11:02:28.895732
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Object, Field as FieldToken

    class ObjectToken(Object):
        id = Field(type="string")

    try:
        validate_with_positions(
            token=ObjectToken(None, id=None),
            validator=ObjectToken.fields["id"],
        )
        assert False
    except ValidationError as error:
        assert len(error.messages) == 1
        message = error.messages[0]
        assert message.start_position.line == 4
        assert m

# Generated at 2022-06-24 11:02:34.704864
# Unit test for function validate_with_positions
def test_validate_with_positions():
    code = """
    example = {
        "name": "Dan",
        "age": 42
    }
    """

    schema = Schema(
        {
            "name": Field(str),
            "age": Field(int),
        }
    )

    for token in tokenize(code):
        validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-24 11:02:43.564304
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Actor(Schema):
        first_name = Field(type=str, required=True)
        last_name = Field(type=str, required=True)

    class Movie(Schema):
        director = Field(type=str, required=True)  # type: ignore
        title = Field(type=str, required=True)  # type: ignore
        actors = Field(type=Actor, required=True, many=True)  # type: ignore


# Generated at 2022-06-24 11:02:53.233544
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem import String
    from typesystem.tokenize.tokens import Token, TokenTypes, Tokenizer

    class Person(Schema):
        first_name = String(required=True)
        last_name = String(required=True)

    tokenizer = Tokenizer()
    tokens = tokenizer.parse(
        b"""
    ---
    first_name:
    """
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=tokens, validator=Person,
        )


# Generated at 2022-06-24 11:03:01.891484
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse
    from typesystem.schemas import Object

    class Point(Schema):
        x = Field(required=True, type="number")
        y = Field(required=True, type="number")

    class Customer(Schema):
        name = Field(required=True, type="string")
        location = Field(required=True, type=Point)

    customer = Customer()
    tree = parse('{"name": "Alice", "location": {"x": 1, "y": 2}}')
    value = validate_with_positions(token=tree, validator=customer)
    assert value == {"name": "Alice", "location": {"x": 1, "y": 2}}


# Generated at 2022-06-24 11:03:09.353030
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Prepare

    class SampleSchema(Schema):
        foo = Field(type="string")
        bar = Field(type="integer")

    sut = validate_with_positions
    validator = SampleSchema()

    # Execute

    with pytest.raises(ValidationError) as ex:
        sut(
            token=Token(value={}),
            validator=validator,
        )

    # Verify
    assert len(ex.value.messages) == 2
    messages = ex.value.messages
    assert messages[0].text == 'The field "foo" is required.'
    assert messages[1].text == 'The field "bar" is required.'
    assert messages[0].start_position.line == 1
    assert messages[0].start_position.char_index == 1

# Generated at 2022-06-24 11:03:14.273349
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class User(Schema):
        name = Field(required=True)
        age = Field(type=int)

    token = Token(
        name="user",
        type=dict,
        value={
            "name": "John",
            "age": "17",
            "favorite_language": "Python",
        },
    )

    with pytest.raises(ValidationError):
        # This should raise a validation error with the correct positions.
        validate_with_positions(token=token, validator=User)



# Generated at 2022-06-24 11:03:23.245198
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer

    class Email(String):
        pattern = r".*@.*\..*"

    class User(Schema):
        name = String()
        age = Integer(minimum=18)
        email = Email(required=True)

    token = Token(
        value={
            "name": "Bob",
            "age": 17,
        },
        start=1,
        end=2,
    )
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=User)

# Generated at 2022-06-24 11:03:36.572018
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import Tokenizer
    from typesystem.tokenize.tokens import StringToken
    from typesystem.fields import String
    from typesystem.schemas import Schema

    schema = Schema(
        {"name": String},
    )
    tokenizer = Tokenizer(delimiter="\n")
    token = tokenizer.parse("")  # type: ignore
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert [m.text for m in error.messages()] == ["The field 'name' is required."]


# Generated at 2022-06-24 11:03:45.987485
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from unittest.mock import Mock

    error = ValidationError(
        [
            Message(index=["x"], text="x is required", code="required",),
            Message(index=["z"], text="z is required", code="required",),
        ]
    )

    token = Mock()
    token.start.line_index = 1
    token.start.char_index = 1
    token.end.line_index = 1
    token.end.char_index = 2
    token.lookup = Mock(side_effect=lambda index: token)

    validator = Mock()
    validator.validate = Mock(side_effect=error.__class__(error.messages()))


# Generated at 2022-06-24 11:03:56.832992
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import JSONToken, TokenError

    schema = Schema.of({"a": str})
    add_positions = lambda token: token.add_positions(source="{}")
    tokens = JSONToken.parse("{}").map(add_positions)
    message = validate_with_positions(token=tokens, validator=schema)
    assert message.text == "The field 'a' is required."

    tokens = JSONToken.parse("{'a': []}").map(add_positions)
    message = validate_with_positions(token=tokens, validator=schema)
    assert message.text == "Expected type <class 'str'> for value ['a']."



# Generated at 2022-06-24 11:04:05.547851
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Root, String, Tuple


# Generated at 2022-06-24 11:04:14.198880
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Integer, Boolean
    from typesystem.tokenize import parse_token

    test_data = """
    first: str
    second: int
    third: bool
    """
    token = parse_token(test_data)
    assert validate_with_positions(
        token=token, validator=Schema({"first": String(required=True)}),
    ) == {"first": "str"}

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=token, validator=Schema({"fourth": String(required=True)}),
        )
    assert exc_info.value.messages()[0].start_position == (1, 6)

# Generated at 2022-06-24 11:04:18.838406
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import Message
    from typesystem.fields import Integer
    from typesystem.tokenize.tokens import Token

    field = Integer()

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(
            token=Token(value=None, start=(1, 1), end=(1, 1)), validator=field
        )

    messages = excinfo.value.messages
    assert messages == [
        Message(
            text="The field None is required.",
            code="required",
            index=[None],
            start_position=(1, 1),
            end_position=(1, 1),
        )
    ]


# Generated at 2022-06-24 11:04:29.705170
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import json_tokens

    class ArticleSchema(Schema):
        title = Field(type=str)
        author = Field(type=str)
        missing_field = Field(type="str", required=True)

    token = json_tokens({})
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=ArticleSchema)


# Generated at 2022-06-24 11:04:37.866173
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_string
    from typesystem.validators import Integer, Required
    from typesystem.validators import validate_with_positions
    from typesystem.validators import ValidationError

    class TestSchema(Schema):

        a = Integer(required=True)
        b = Integer(required=True)
        c = Integer()

    token = tokenize_string(
        """
    {
        a: 1,
        b: 2,
        c: 4
    }
    """
    )
    result = validate_with_positions(
        token=token, validator=TestSchema()
    )
    assert result == {"a": 1, "b": 2, "c": 4}


# Generated at 2022-06-24 11:04:46.411415
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.field_validators import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokens import TokenPosition

    class It(Schema):
        name = String()

    start_position = TokenPosition()
    token = Token(It.validate, "name", "John")  # type: ignore
    token.start = start_position
    token.end = None
    token.children = []

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=It)
    assert exc_info.value.messages[0].text == "The field 'end' is required."

# Generated at 2022-06-24 11:04:51.500304
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class PersonSchema(Schema):
        name = Field(str)
        age = Field(int)

    with pytest.raises(exceptions.ValidationError) as exc_info:
        validate_with_positions(
            token=Token("john", {"name": Token("john", "john"), "age": Token("30", 30)}),
            validator=PersonSchema,
        )

    message = exc_info.value.messages[0]
    assert message.text == "The field 'age' is required."

# Generated at 2022-06-24 11:05:00.166683
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from datetime import date

    from typesystem.schemas import Structure

    from tests.conftest import MockToken

    class Person(Structure):
        name = Field(str)
        age = Field(int, max_value=100)
        born_on = Field(date)

    # Basic example using a field
    token = MockToken(
        {
            "name": {"name": "John"},
            "age": {"age": 200},
            "born_on": {"born_on": "2020-01-01"},
        }
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    messages = exc_info.value.messages
    assert len(messages) == 2

# Generated at 2022-06-24 11:05:11.036121
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Array, Object

    class TestSchema(Schema):
        sub_field = Array[int]

    class TestField(Field):
        schema_class = TestSchema

    token = Token(
        "test",
        {
            "sub_field": [
                {},
                {"foo": "this is not a number"},
                {"bar": True},
            ]
        },
        None,
        None,
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=TestField)  # type: ignore
    assert exc_info.value.messages()[0].code == "required"
    assert exc_info.value.messages()[0].text == "The field 0 is required."
   

# Generated at 2022-06-24 11:05:21.524626
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Cursor:
        def __init__(self, index: int, line: int, column: int) -> None:
            self.index = index
            self.line = line
            self.column = column

    class Position:
        def __init__(
            self, char_index: int, line: int, line_offset: int, column: int
        ) -> None:
            self.char_index = char_index
            self.line = line
            self.line_offset = line_offset
            self.column = column

    class Token:
        def __init__(self, value: int, start: Cursor, end: Cursor) -> None:
            self.value = value
            self.start = start
            self.end = end

        def lookup(self, index):
            assert index == [0]
            return

# Generated at 2022-06-24 11:05:22.014392
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-24 11:05:32.890960
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.json_schema import JsonSchema

    class MySchema(JsonSchema):
        email = {"type": "string", "format": "email"}
        name = {"type": "string", "minLength": 3}

    schema = MySchema()

    # The token object must be of type Token
    with pytest.raises(Exception):
        assert validate_with_positions(token="", validator=schema)

    with pytest.raises(ValidationError):
        validate_with_positions(
            token=Token(value={"email": "", "name": "hi"}), validator=schema
        )


# Generated at 2022-06-24 11:05:41.492991
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import Token, Char
    from typesystem.fields import Integer

    class MyField(Field):
        def validate(self, value):
            if value > 10:
                raise ValidationError(
                    "Value is too large", code="value_too_large",
                )
            else:
                return value

    token: Token[int] = Token(value=11, start=Char(), end=Char())
    try:
        validate_with_positions(token=token, validator=MyField())
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "Value is too large"
        assert message.code == "value_too_large"
        assert message.index == tuple()
        assert message.start_position == Char()

# Generated at 2022-06-24 11:05:50.020805
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class Validator(Field):
        def validate(self, value):
            raise ValidationError("Invalid data")

    validator = Validator()
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=Token("a"), validator=validator)
    assert exc.value.messages()[0].start_position == (0, 0, 0)
    assert exc.value.messages()[0].end_position == (0, 0, 1)
    assert exc.value.messages()[0].text == "Invalid data"
    assert exc.value.messages()[0].code == "invalid"

# Generated at 2022-06-24 11:06:01.047891
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import parse

    value = {"name": None}
    token = parse(value)
    assert token.value == value

    class UserSchema(Schema):
        name = Field(type=str, required=True)

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=UserSchema)
    message = exc.value.messages()[0]
    assert message.text == "The field 'name' is required."
    assert message.start_position.line == 1
    assert message.start_position.char_index == 10  # ':'
    assert message.end_position.line == 1
    assert message.end_position.char_index == 10

# Generated at 2022-06-24 11:06:10.930173
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import pytest
    from typesystem.schemas import Object
    from typesystem.tokenize.tokens import Token, TokenType

    class Person(Object):
        fields = {
            "name": Field(required=True),
            "age": Field(required=True),
            "siblings": Field(required=False),
        }

    text = '{"name": "Jane", "age": 35}'
    token = Token(
        token_type=TokenType.Dict, value=json.loads(text), start=0, end=len(text)
    )

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=Person())


# Generated at 2022-06-24 11:06:20.188671
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Tokenizer, fields, schemas

    @schemas.schema
    class Person:
        name = fields.String()
        age = fields.Integer()

    tokenizer = Tokenizer(Person)
    person_tokens = tokenizer.get_tokens('{"name": "Bob", "age": "20"}')
    validate_with_positions(
        token=person_tokens[0].value.lookup(["age"]),
        validator=Person.fields["age"],
    )
    # this raises because of the "20" value
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=person_tokens[0], validator=Person,
        )

# Generated at 2022-06-24 11:06:34.107269
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import datetime
    from typesystem.fields import Integer, String, Date
    from typesystem.schemas import RootSchema
    from typesystem.tokenize.parser import parse

    class UserSchema(RootSchema):
        name = String()
        age = Integer()
        birth_date = Date()
        meta = {"strict": False}

    text = """
    {
        "name": "",
        "age": "42",
    }
    """
    user = parse(UserSchema, text)
    try:
        validate_with_positions(token=user, validator=UserSchema)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1

# Generated at 2022-06-24 11:06:45.662226
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import CharToken
    from typesystem.fields import Date
    from typesystem.schemas import Object

    class Person(Object):
        name = Field(type="string")
        birthday = Field(type=Date)

    token = CharToken(
        value='{"name": "", "birthday": "1978-08-19"}',
        start="1:1",
        end="1:30",
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 2
        assert error.messages()[0].start_position.char_index == 11
        assert error.messages()[1].start_position.char_index == 22

# Generated at 2022-06-24 11:06:54.626172
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema

    class SecuritySchema(Schema):
        type = "object"
        properties = {
            "security": {"type": "array", "items": {"type": "string"}},
        }

    security_schema = SecuritySchema()

    from typesystem.tokenize.tokens import Token

    token = Token.read({"security": ["s1", "s2", "s3"]})

    try:
        validate_with_positions(token=token, validator=security_schema)
    except ValidationError as error:
        assert error.messages() == list()

    token = Token.read({"security": ["s1", "s2", "s3", 1]})

# Generated at 2022-06-24 11:07:05.042161
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokenize import Tokenize

    text = """\
    {
        "name": "",
        "profile_url": "",
        "description": ""
    }\
    """

    schema = Schema(properties={"name": String(), "description": String()})
    tokenize = Tokenize(text=text)
    token = tokenize.tokenize()

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 2
        assert messages[0].code == "required"
        assert messages[0].text == 'The field "profile_url" is required.'
        assert messages[0].start_position.line == 0

# Generated at 2022-06-24 11:07:16.486928
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import Text, Date, Boolean
    from typesystem.tokenize.tokens import Token

    class PersonSchema(Schema):
        name = Text()
        birthdate = Date()
        alive = Boolean()

    token = Token(
        value={"alive": "yes"},
        start={"line": 0, "char_index": 0},
        end={"line": 0, "char_index": 7},
    )
    token = token.lookup("name")
    token = token.lookup(["birthdate"])
    token = token.lookup(["alive"])
    validate_with_positions(token=token, validator=Boolean())

# Generated at 2022-06-24 11:07:22.769372
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    data = {
        "name": "Mary",
        "age": "30",
    }

    tokens = tokenize(data)
    try:
        validate_with_positions(token=tokens, validator=Person)
    except ValidationError:
        pass
    else:
        assert False, "should have failed"

    assert len(tokens.errors) == 1
    error = tokens.errors[0]
    assert error.code == "invalid_type"
    assert error.text == "Expected an integer."
    assert error.start_position.line == 1
    assert error.start_position.col == 10
    assert error.start_

# Generated at 2022-06-24 11:07:29.039896
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    from typesystem.tokenize.base import tokenize_schema
    from typesystem.tokenize.base import Token
    from typesystem.tokenize.base import Tokenizer
    from unittest import mock


    schema = typesystem.Object(
        properties={
            "name": typesystem.String(required=True),
            "color": typesystem.String(required=True),
            "coordinates": typesystem.Array(items=typesystem.Integer(), required=True),
        }
    )

    schema.tokenizer = Tokenizer(schema=tokenize_schema)

    value = {"coordinates": [[1, 2], [3, 4, 5]], "color": "green"}
    with mock.patch("typesystem.tokenize.base.tokenize_value") as mock_tokenize:
        mock_

# Generated at 2022-06-24 11:07:35.509926
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class UserSchema(Schema):
        name = Field(type=str)

    source = """<User />"""

    tokens = lex(source)
    assert tokens[0]
    assert tokens[0].start.char_index == 0
    assert tokens[0].end.char_index == 6

    try:
        validate_with_positions(token=tokens[0], validator=UserSchema)
    except ValidationError as error:
        assert len(error.messages) == 1
        message = error.messages[0]
        assert message.start_position.char_index == 3
        assert message.end_position.char_index == 5
        assert message.text == "The field 'name' is required."

# Generated at 2022-06-24 11:07:45.016178
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Literal, Object, String
    from typesystem.schemas import ObjectSchema
    from typesystem.fields import StringField

    json_text = """
    {
        "name": "John",
        "age": 42
    }
    """

    class PersonSchema(ObjectSchema):
        name = StringField(required=True)

    class RootSchema(ObjectSchema):
        person = PersonSchema()

    token = Literal.parse(json_text)

# Generated at 2022-06-24 11:07:53.391506
# Unit test for function validate_with_positions
def test_validate_with_positions():

    token = Token(
        key="object",
        value={
            "name": "Foo",
            "children": [{"name": "Bar"}, {"name": "Baz"}],
        },
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=15, char_index=14),
    )

    class Child(Schema):

        name = String()

    class Object(Schema):

        name = String()
        children = Array[Child]()

    validate_with_positions(token=token, validator=Object)



# Generated at 2022-06-24 11:08:04.518962
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.tokenize import json_tokenize

    schema = Schema({"email": String()})

    tokens = json_tokenize({"email": "hello@example.com"})
    assert validate_with_positions(token=tokens[0], validator=schema) == {
        "email": "hello@example.com"
    }

    tokens = json_tokenize({"name": "John Doe"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens[0], validator=schema)
    message = exc_info.value.messages[0]
    assert message.text == "The field 'email' is required."

# Generated at 2022-06-24 11:08:15.615926
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import PrimitiveToken, TokenList

    token_a = PrimitiveToken(["a"], (1, 0), (1, 1))
    token_b = PrimitiveToken(["b"], (1, 2), (1, 3))
    token_c = PrimitiveToken(["c"], (1, 4), (1, 5))

    class FieldA(Field):
        def validate(self, value: typing.Any, **options: typing.Any) -> typing.Any:
            if value != "a":
                self.error("bad_value", value=value)
            return value


# Generated at 2022-06-24 11:08:23.553115
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token, INTEGER, STRING
    from typesystem.types import Integer

    schema = Schema(properties={"foo": Integer(), "bar": Integer()})
    input_ = Token(
        type=INTEGER, value=1, start=1, end=2, children=[Token(type=STRING, value="foo")]
    )

    positional_messages = []
    try:
        validate_with_positions(token=input_, validator=schema)
    except ValidationError as error:
        positional_messages = error.messages


# Generated at 2022-06-24 11:08:32.785996
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object

    class Person(Object):
        name = Field(type="string")

    from typesystem.tokenize import tokenize

    # generate a token from a string
    token = tokenize(
        '{"name": "", "name2": "val2"}'
    ).get_child_token(["name2"])
    assert token.value == ""

    # validate token, pass
    validate_with_positions(token=token, validator=Field(type="string"))

    # validate token, fail: required
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=Field(type="string", required=True))
    # validate token, fail: schema
    with pytest.raises(ValidationError):
        validate_with_pos

# Generated at 2022-06-24 11:08:36.744848
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.json_schema import JSONSchema
    from typesystem.fields import String

    class MissingName(JSONSchema):
        name: String(required=True)

    token = Token("{}")
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=MissingName)

# Generated at 2022-06-24 11:08:45.510019
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Empty  # type: ignore

    schema = Schema({"foo": Field(required=True)})
    token = Empty(value={})
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'foo' is required."
        assert message.start_position.line == 1
        assert message.end_position.line == 1



# Generated at 2022-06-24 11:08:54.216890
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    from typesystem.tokenize.tokens import ObjectToken
    from typesystem.tokenize.tokens import IdentifierToken
    from typesystem.tokenize.tokens import LiteralToken


# Generated at 2022-06-24 11:09:04.375097
# Unit test for function validate_with_positions
def test_validate_with_positions():
    
    from typesystem.tokenize import tokenize, Position

    def assert_messages_at(tokens: typing.Iterable[Token], expected: typing.Iterable[Position], message):
        tokens = list(tokens)
        try:
            validate_with_positions(
                    token=tokens[0], validator=validator
                )
        except ValidationError as error:
            messages = list(error.messages())
        else:
            assert False, f"Did not raise"

        def position(message):
            return message.start_position, message.end_position

        expected = list(expected)
        messages = list(position(m) for m in messages)
        assert expected == messages, message

    validator = Field(type=int)

# Generated at 2022-06-24 11:09:12.386118
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize

    schema = Schema(fields={"name": {"type": "string"}})

    struct = {"name": "foo"}
    token = tokenize(**struct)

    try:
        validate_with_positions(
            validator=schema, token=token.lookup(index=["name"])
        )
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'name' is required."
        assert message.start_position.char_index == 2
        assert message.end_position.char_index == 2
        return

    # Execution should not reach here
    assert False



# Generated at 2022-06-24 11:09:23.436316
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import sys
    import io
    import json

    # Define a validator
    class User(Schema):
        username = Field(type="string")
        password = Field(type="string")

    # Create a Token from a JSON string
    json_string = """{"username": "alan", "password": "topsecret"}"""
    token = Token.from_json(json_string)

    # Create a stream to capture stderr
    old_stderr = sys.stderr
    sys.stderr = stderr = io.StringIO()

    # Call this function
    try:
        validate_with_positions(token=token, validator=User)
    except ValidationError as error:
        # Read what was captured
        sys.stderr = old_stderr
        stderr_text = st

# Generated at 2022-06-24 11:09:33.050221
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize, Token
    from typesystem.fields import String, Integer

    string = String(max_length=1)
    integer = Integer(maximum=0)

# Generated at 2022-06-24 11:09:42.077973
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class MyType(Field):
        def __init__(self, *, choices=None, **kwargs):
            super().__init__(**kwargs)
            self.choices = choices

        def validate(self, value):
            if self.choices is not None and value not in self.choices:
                raise ValidationError(
                    f"{value!r} is not allowed.", code="invalid_choice"
                )

    data = "[]\n\n"
    tokens = [
        Token("l_bracket", "["),
        Token("r_bracket", "]"),
        Token.newline(),
        Token.newline(),
    ]
    foo_type = MyType(
        name="foo", choices=["bar", "baz"], description="A field named `foo`."
    )

# Generated at 2022-06-24 11:09:51.373560
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.py_ast import Field, Schema, Text

    def check(
        *,
        schema: typing.Type[Schema],
        json: typing.Any,
        expected_tokens: typing.List[Token],
        fails: bool = False,
    ):
        with pytest.raises(ValidationError) as exc:
            field = Field(schema=schema, allow_null=False)
            field.validate_with_positions(json)

        if fails:
            assert exc.value.messages()
            return

        messages = [
            (message.text, message.start_position.char_index)
            for message in exc.value.messages()
        ]

# Generated at 2022-06-24 11:09:57.602614
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    from typesystem.tokenize.base import Tokenizer

    class Basic(typesystem.Schema):
        name = typesystem.String()

    tokenizer = Tokenizer()
    token = tokenizer.tokenize("name:")
    try:
        validate_with_positions(validator=Basic, token=token)
    except ValidationError as error:
        message = error.messages[0]
        assert message.text == "The field 'name' is required."
        assert message.start_position.char_index == 5

