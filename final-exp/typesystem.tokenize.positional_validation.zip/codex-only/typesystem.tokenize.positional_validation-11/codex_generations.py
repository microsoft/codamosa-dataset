

# Generated at 2022-06-24 10:59:59.126123
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import lex

    schema = Schema(fields=[Field(key="title", type="string"), Field(key="qty", type="integer")])

    token = lex(
        text='''{
    "title": "BOOK",
    "qty": 1
}''',
    )

    assert validate_with_positions(token=token, validator=schema) == {
        "title": "BOOK",
        "qty": 1,
    }

# Generated at 2022-06-24 11:00:08.009415
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse

    class FooSchema(Schema):
        fields = (
            {"name": "bar"},
            {"name": "baz"},
            {"name": "qux", "required": True},
            {"name": "quux", "required": True},
        )

    data = {
        "bar": ["x", "y", "z"],
        "baz": {"a": 1, "b": 2, "c": 3},
    }
    tokens = parse(data)
    validate_with_positions(token=tokens, validator=FooSchema)



# Generated at 2022-06-24 11:00:14.354790
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize

    token = tokenize("{'foo': 42}")
    assert token.lookup(["foo"]).start.position == (1, 5)
    assert token.lookup(["foo"]).end.position == (1, 9)

    class MySchema(Schema):
        foo = Integer(required=True)  # type: ignore
        bar = String()

    schema = MySchema()
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)
    error = excinfo.value
    assert len(error.messages()) == 2

    message = error.messages()[0]

# Generated at 2022-06-24 11:00:19.836837
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Tokenizer
    from typesystem.schemas import Schema
    from typesystem.types import String

    token = Tokenizer().tokenize(
        b'{"name": "", "age": null, "address": {}}'
    )

    # Basic schema to test with
    class Person(Schema):
        name = String(required=True)
        address = String(required=True)

    validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-24 11:00:26.839502
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class SampleSchema(Schema):
        foo = String()
        bar = String()

    from typesystem.tokenize import tokenize

    tokens = tokenize("""
        foo: "ABC"
        bar: 123
    """)

    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(
            token=tokens, validator=SampleSchema,
        )
    assert error_info.value.messages()[0].text == 'The field "bar" has an invalid type.'

# Generated at 2022-06-24 11:00:32.579075
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import parse
    from typesystem import types
    from typesystem.schemas import Schema

    class BookSchema(Schema):
        title = types.String(required=True)
        year = types.Integer()

    schema = parse(BookSchema)
    try:
        validate_with_positions(token=schema, validator=BookSchema)
    except ValidationError as error:
        messages = sorted(
            error.messages(), key=lambda m: m.start_position.char_index  # type: ignore
        )
        assert len(messages) == 1
        message = messages[0]
        assert message.code == "required"
        assert message.text == "The field 'title' is required."
        assert message.start_position.line_number == 0
        assert message

# Generated at 2022-06-24 11:00:42.112937
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import linetokenizer

    person = Schema(
        {
            "first_name": Field(type=str, required=False),
            "last_name": Field(type=str, required=False),
            "occupation": Field(type=str, required=False),
            "birth_year": Field(type=int, required=False),
            "birth_month": Field(type=int, max=12, min=1, required=False),
            "birth_day": Field(type=int, max=31, min=1, required=False),
        }
    )

    # Test valid input
    line = b"John\tDoe\tEngineer\t1980\t10\t12"
    token = Token(line, linetokenizer.linux_line_tokenizer(line))
    result = validate_with

# Generated at 2022-06-24 11:00:48.063281
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import ObjectToken
    from typesystem import Tokenizer

    tokenizer = Tokenizer({"foo": String()})
    token = ObjectToken(
        value={"foo": "bar"}, start=(1, 0), end=(1, 6), schema=tokenizer.schema
    )
    validate_with_positions(token=token, validator=tokenizer)

# Generated at 2022-06-24 11:00:53.885392
# Unit test for function validate_with_positions

# Generated at 2022-06-24 11:00:57.837091
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import JSONSchema
    from typesystem.json_schema import typesystem_to_json_schema

    schema = JSONSchema(typesystem_to_json_schema({"a": "string"}))
    schema.validate({"a": "hello"})

# Generated at 2022-06-24 11:01:07.892735
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize import make_tokens
    from typesystem.tokenize.tokens import Token

    validator = String(min_length=1)
    token = Token(value={"a": "a"}, tokens=[])
    assert validate_with_positions(token=token, validator=validator) == token.value

    token = Token(value={"a": None}, tokens=[])

# Generated at 2022-06-24 11:01:15.943026
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token({"name": "Person"}, start=[0, 0], end=[0, 6])
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=Person)
    errors = excinfo.value.messages()
    assert errors[0].text == "The field 'age' is required."
    assert errors[0].code == "required"
    assert errors[0].index == ["age"]
    assert errors[0].start_position == (0, 0)
    assert errors[0].end_position == (0, 6)

# Generated at 2022-06-24 11:01:26.741337
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    class Snippet(Schema):
        title = Field(primitive=str, required=True)
        code = Field(primitive=str, required=True)

    def make_token(**kwargs) -> Token:
        return Token(
            value={
                "title": "Foo",
                "code": "bar",
            },
            **kwargs
        )

    token = make_token(
        start=Token.Position(line=1, line_index=0),
        end=Token.Position(line=1, line_index=10),
    )

    validate_with_positions(token=token, validator=Snippet())



# Generated at 2022-06-24 11:01:34.725255
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem import fields

    class Person(Schema):
        name = fields.String()
        age = fields.Integer()

    data = {"name": "john"}
    token = tokenize(data)

    try:
        validate_with_positions(token=token, validator=Person())
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'age' is required."
        assert message.code == "required"
        assert message.start_position.line == 1
        assert message.start_position.char_index == 2
        assert message.end_position.line == 1
        assert message.end_position.char_index == 4

# Generated at 2022-06-24 11:01:44.234984
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """Test validate_with_positions function."""
    class MySchema(Schema):
        field_with_no_default = Field(type="string")
        field_with_default = Field(type="string", default="default value")

    token = Token(
        value={
            "field_with_default": "value",
        },
    )

    assert validate_with_positions(
        token=token, validator=MySchema
    ) == {
        "field_with_no_default": None,
        "field_with_default": "value",
    }

    token = Token(
        value={
            "field_with_no_default": None,
        },
    )

# Generated at 2022-06-24 11:01:54.717491
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(str, required=True)

    try:
        # doctest: +SKIP
        validate_with_positions(
            token=tokenize("{}"), validator=Person
        )
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.code == "required"
        assert message.text == "The field 'name' is required."
        assert message.index == ("name",)
        assert message.start_position == (1, 2)
        assert message.end_position == (1, 2)


# Generated at 2022-06-24 11:02:03.711903
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import fields
    from typesystem.tokenize.tokens import ObjectToken  # type: ignore

    token = ObjectToken(start=1, end=3, value={1: 1})

    # Check that a normal error message is returned
    field = fields.Integer(required=True)
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=field)

    assert len(error.value.messages) == 1
    message = error.value.messages[0]
    assert message.start_position == 1
    assert message.end_position == 3

    # Check that a nested error message is returned

# Generated at 2022-06-24 11:02:08.657488
# Unit test for function validate_with_positions
def test_validate_with_positions():
    address = {
        "street": "Baker Street",
        "number": "221B",
        "post_code": "NW1 6XE"
    }
    token = Token.from_object(address)
    try:
        validate_with_positions(token=token, validator=AddressSchema)
    except Exception as error:
        print(error)


# Generated at 2022-06-24 11:02:16.596004
# Unit test for function validate_with_positions
def test_validate_with_positions():  # pylint: disable=unused-variable
    from .tokenize.tokenizer import Tokenizer
    from .emit.emitter import Emitter
    from .parser.parser import Parser
    from .lark import ParseError

    class Name(Field):
        primitive = str

    class Address(Field):
        primitive = str

    class Person(Schema):
        name: Name
        address: Address
        age: int

    yaml_data = """
        name: David
        address: 123 Main St
        age: 34
    """


# Generated at 2022-06-24 11:02:27.039181
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Document
    from typesystem.tokenize.tokenizer import Tokenizer
    from typesystem.fields import Array, Integer

    string = """{
        "foo": [1, 2, 3]
    }"""
    token = Tokenizer(string=string).parse()  # type: ignore
    assert issubclass(type(token), Document)
    validator = Array(
        items=Integer(minimum=4, exclusive=True),
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=validator)

    assert exc_info.value.messages()[0].start_position.line == 3
    assert exc_info.value.messages()[0].start_position.line == 3

# Generated at 2022-06-24 11:02:33.759970
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import Message
    from typesystem.parser import Token as TokenAsDict
    from typesystem.schemas import Object

    token = Token.from_python(
        {
            "a": "foo",
            "b": 123,
            "c": [1, 2, 3],
            "d": {
                "x": "hello",
                "y": "world",
            }
        }
    )

    # A failing case:
    class MySchema(Object):
        a = Field(required=True)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=MySchema)


# Generated at 2022-06-24 11:02:42.620356
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import Boolean
    from typesystem.schemas import Schema
    from typesystem.tokenize.lexers import Lexer

    class MySchema(Schema):
        field = Boolean()
        number = Boolean()

    with pytest.raises(ValidationError) as excinfo:
        tree = Token(
            value={
                "field": "abc",
                "number": "abc",
            }
        )

        validate_with_positions(token=tree, validator=MySchema)

    messages = excinfo.value.messages()
    assert messages[0].start_position == tree.field.start
    assert messages[1].start_position == tree.number.start



# Generated at 2022-06-24 11:02:52.482372
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Text
    from typesystem.tokenize.tokens import ObjectToken
    from typesystem.schemas import Schema

    class ExampleSchema(Schema):
        name = String(min_length=1)
        description = Text(required=False)

    schema = ExampleSchema()

    class UserSchema(Schema):
        users = [schema]

    user_schema = UserSchema()

    value = {"users": [{"name": "suzumiya", "description": "ahhhh"}]}
    expected = [
        {
            "name": "suzumiya",
            "description": "ahhhh",
        }
    ]
    assert user_schema.parse(value, validate=False) == expected

    user_schema.validate(value)


# Generated at 2022-06-24 11:03:03.084981
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import jsonschema.exceptions

    from typesystem.schemas import Schema
    from typesystem.fields import Object, Integer, String

    with open("tests/schemas/user.json") as file:
        schema = json.load(file)
    validator = Schema.from_data(schema)

    payload = {
        "age": "30",
        "first_name": "Leeroy",
        "last_name": "Jenkins",
        "profession": "artist",
    }

# Generated at 2022-06-24 11:03:11.954722
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # type: () -> None
    class Root(Schema):
        required_string = Field(type=str, required=True)

    # Typecast Field, raise ValidationError
    field = Root.fields["required_string"]
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=Token(key="required_string", value=None), validator=field)
    assert len(exc_info.value.messages) == 1
    message = exc_info.value.messages[0]
    assert message.index == ("required_string",)
    assert message.text == "The field 'required_string' is required."
    assert message.start_position == (1, 0)
    assert message.end_position == (1, 0)

    # Typecast Field, raise Val

# Generated at 2022-06-24 11:03:19.470627
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokens import Token, Position
    from typesystem.fields import Str, Integer, Array
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = Str()
        age = Integer()

    class MyArraySchema(Schema):
        people = Array(MySchema)

    # Test with a field
    data = {"name": "john", "age": ""}
    token = Token(value=data, start=Position(line=1, char_index=1))

# Generated at 2022-06-24 11:03:27.965203
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize, Token

    data = {"first": "John", "last": "Doe", "age": "nyeh"}
    tokens = tokenize(data)
    assert [t.value for t in tokens] == ["John", "Doe", "nyeh"]

    schema = Schema(
        {
            "first": Field(required=True),
            "last": Field(required=True),
            "age": Field(type="integer"),
        }
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens[0], validator=schema)
    assert len(exc_info.value.messages) == 2
    assert len(exc_info.value.messages[0].start_position) == 4
   

# Generated at 2022-06-24 11:03:37.421017
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.primitives import Integer
    from typesystem.tokenize.tokenizer import tokenize

    # A min value of 10 is defined, but the value 5 is given
    string = '[{"id": 5}]'
    schema = Schema({"id": Integer(min_value=10)})
    tokens = tokenize(string)
    try:
        validate_with_positions(token=tokens, validator=schema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        assert error.messages()[0].code == "min_value"
        assert error.messages()[0].index == ("0", "id")

# Generated at 2022-06-24 11:03:43.561949
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type="string")
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=Token(5), validator=field)
    message = excinfo.value.messages[0]
    assert message.text == "Value must be of type string."
    assert message.start_position == (1, 4)
    assert message.end_position == (1, 4)



# Generated at 2022-06-24 11:03:49.909762
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem.exceptions import ValidationError as TypeSystemValidationError
    from typesystem import String

    error = String(min_length=1)

    token = Token(start="<start>", end="<end>", value="My name is")

    try:
        validate_with_positions(token=token, validator=error)
    except TypeSystemValidationError as exc:
        message = exc.messages()[0]
        assert message.index == ["My name is"]
        assert message.start_position.char_index == "<start>"
        assert message.end_position.char_index == "<end>"
    else:
        assert False

# Generated at 2022-06-24 11:03:59.194201
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Arrange
    from typesystem.tokenize.tokens import DocumentToken
    from typesystem.tokenize.tokens import StringValueToken
    from typesystem.tokenize.tokens import StringToken
    from typesystem.tokenize.tokens import NumberToken
    from typesystem.tokenize.tokens import BooleanToken
    from typesystem.tokenize.tokens import NullToken

    from typesystem.fields import String
    from typesystem.fields import Number
    from typesystem.fields import Boolean
    from typesystem.fields import Null

    from typesystem.fields import Integer
    from typesystem.fields import Float

    from typesystem.fields import Resource

    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = String(min_length=1, max_length=10)


# Generated at 2022-06-24 11:04:08.454215
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import parse as tokenize

    token = tokenize("""{
    "name": "Harry"
}""")

    class Name(Field):
        def validate(self, data):
            if data != "Harry":
                raise ValidationError("Should be Harry.")

    # If the error has no position, then it should be added
    schema = Schema({"name": Name()})
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert error.messages()[0].start_position.line_index == 1
        assert error.messages()[0].start_position.char_index == 18



# Generated at 2022-06-24 11:04:17.881691
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError
    from typesystem.tokenize.positions import Position

    class TestSchema(Schema):
        field = String(required=True)

    token = Token(
        value={"field": ""},
        start=Position(char_index=0),
        end=Position(char_index=10),
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=TestSchema)


# Generated at 2022-06-24 11:04:28.937925
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from parsimonious.nodes import Node
    from typesystem import Integer, Object

    class SimpleSchema(Object):
        a: typing.Dict[str, Integer]

    token = Token(
        Node(expr=None, children=[], text=""),
        {"a": {"b": "1", "c": "x"}},
        start_position=None,
        end_position=None,
    )

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=SimpleSchema)
    assert len(excinfo.value.messages) == 1
    assert excinfo.value.messages[0].text == 'Invalid value for Integer(): "x"'
    assert excinfo.value.messages[0].start_position.line == 1
    assert excinfo

# Generated at 2022-06-24 11:04:37.370318
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer, String
    from typesystem.tokenize.tokenizer import Tokenizer
    from typesystem.tokenize.positions import Position

    class Person(Schema):
        name = String(required=True)
        age = Integer()

    text = """
        {
            "name": "Sam",
            "age": 31
        }
    """

    tokenizer = Tokenizer(text=text)
    token = tokenizer.tokenize()

    Person.validate(token.value)
    assert validate_with_positions(token=token, validator=Person) is True

    token.value["age"] = "xxx"
    with pytest.raises(ValidationError) as excinfo:
        Person.validate(token.value)

# Generated at 2022-06-24 11:04:46.065166
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # mock
    class Token:
        def __init__(self, value, start, end):
            self.value = value
            self.start = start
            self.end = end

        def lookup(self, index):
            return self

    # mypy complains about this, but i think it's a false warning in this case
    # mypy: ignore-error

    class MockValidationError(ValidationError):
        pass

    class Validator:
        def validate(self, value):
            raise MockValidationError(
                messages=[
                    Message(
                        text="error",
                        code="code",
                        index=[0],
                        start_position=Position(1, 2),
                        end_position=Position(3, 4),
                    )
                ]
            )

    validator = Validator()

# Generated at 2022-06-24 11:04:53.178092
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize, get_tokens

    schema = Schema({"foo": {"bar": Field(float)}})

    source = {"foo": {"bar": "wrong_type"}}
    tokens = get_tokens(tokenize(source))
    token_tree = tokens[source]
    try:
        validate_with_positions(token=token_tree, validator=schema)
    except ValidationError as exc:
        error = exc.messages[0]

        assert error.text == "Expected float but got str instead."
        assert error.code == "invalid_type"

        assert error.start_position.line == 1
        assert error.start_position.column == 16
        assert error.start_position.char_index == 15


# Generated at 2022-06-24 11:05:05.098562
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(
        token=Token("12", start=None, end=None, _path=[("data", "a")]),
        validator=Field(type=int),
    ) == 12
    assert validate_with_positions(
        token=Token("abc", start=None, end=None, _path=[("data", "a")]),
        validator=Field(type=int),
    ) == "abc"
    try:
        validate_with_positions(
            token=Token(None, start=None, end=None, _path=[("data", "a")]),
            validator=Field(type=int),
        )
    except ValidationError as error:
        assert str(error) == "The field 'a' is required."

# Generated at 2022-06-24 11:05:13.824148
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        name="example",
        value={"key": "value"},
        start={"line": 1, "char_index": 2},
        end={"line": 3, "char_index": 4},
    )
    validator = Schema([("key", Field(required=True, type="string"))])
    assert validate_with_positions(token=token, validator=validator) == token.value
    token.value = {}
    with pytest.raises(ValidationError) as info:
        validate_with_positions(token=token, validator=validator)
    messages = info.value.messages()
    message = messages[0]
    assert message.text == "The field 'key' is required."
    assert message.start_position == token.start
    assert message.end_position

# Generated at 2022-06-24 11:05:23.022197
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.fields import Array
    from typesystem.schemas import Object
    from typesystem.tokenize import tokenize

    class TestSchema(Object):
        array_field = Array(items={"type": "string"})

    tokens = tokenize({"array_field": ["foo", "bar"]})
    assert validate_with_positions(
        token=tokens.lookup(["array_field"]), validator=TestSchema
    ) == {"array_field": ["foo", "bar"]}

    tokens = tokenize({"array_field": [1, "bar"]})
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=tokens.lookup(["array_field"]), validator=TestSchema)
    assert exc

# Generated at 2022-06-24 11:05:33.503390
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from tests.tokenize.test_tokenize import tokenize

    schema = Schema({"name": "string", "age": "integer"}, strict=True)
    source = '{"name": "Joe", "age": "18"}'
    tokens = tokenize(source)
    token = tokens
    message = validate_with_positions(token=token, validator=schema)
    assert message[0].start_position.offset == 13
    assert message[0].start_position.char_index == 13
    assert message[0].end_position.offset == 17
    assert message[0].end_position.char_index == 17


# Utility for adding a `source` attribute to token instances, used as a
# positional context when flattening a token tree into a validation error
# message.


# Generated at 2022-06-24 11:05:41.914005
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize_json import tokenize_json
    from typesystem.types import String, Integer, Array

    schema = Array(items=String())

    tokens = tokenize_json("[1, 2]")
    token = tokens.lookup()  # (array, '[1, 2]')
    text = token.end.line_text
    assert text == "[1, 2]"
    try:
        schema.validate(token.value)
    except ValidationError as error:
        assert len(error.messages()) == 2
        message = error.messages()[-1]
        assert message.index == (0,)
        assert message.start_position.line_index == 0
        assert message.start_position.char_index == 1
        assert message.end_position.line_index == 0
       

# Generated at 2022-06-24 11:05:51.624696
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Doc, List, Primitive

    from ._test_validation import (
        check_error,
        check_message,
        check_value,
    )

    # Basic
    check_value(
        validate_with_positions,
        token=Doc(
            [
                Primitive("a", start=0, end=1),
                Primitive("b", start=1, end=2),
                Primitive("c", start=2, end=3),
            ]
        ),
        validator=Field(type=str),
        value=["a", "b", "c"],
    )

    # Errors with positions

# Generated at 2022-06-24 11:06:02.667024
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer, String
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token

    token = tokenize("""
    {
      "a": null,
      "b": null,
      "c": "foo"
    }
    """)

    field = String(required=True, description="FOO!")
    schema = field.as_schema(name="bar")


# Generated at 2022-06-24 11:06:07.297446
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Tokenize
    
    class Person(Schema):
        name = Field(type="string")
    
    def test_person_with_name():
        token = Tokenize("""
            {
                "name": "foo"
            }
        """)
    
        try:
            validate_with_positions(token=token, validator=Person)
        except ValidationError:
            raise AssertionError("should be valid")
    
    def test_person_with_no_name():
        token = Tokenize("""
            {
                "name": ""
            }
        """)
    

# Generated at 2022-06-24 11:06:16.059921
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(type="string")

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=Token("foo", start_position=Position(0, 0), end_position=Position(0, 3)),
            validator=Person,
        )
    assert exc_info.value.messages() == [
        Message(
            text="The field name is required.",
            code="required",
            index=("name",),
            start_position=Position(0, 0),
            end_position=Position(0, 3),
        )
    ]



# Generated at 2022-06-24 11:06:26.347239
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object
    from typesystem.fields import Text, Integer
    from typesystem.tokenize.tokens import ObjectToken
    from typesystem.tokenize.transformers import tokenize

    schema = Object(
        {"name": Text(), "age": Integer()}
    )

    token = tokenize(schema)
    assert isinstance(token, ObjectToken)
    assert token.start.char_index == 0
    assert token.end.char_index == 3

    # valid
    validate_with_positions(token=token, validator=schema)

    # invalid
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    # Assert that the first validation error is correct:
    #   -

# Generated at 2022-06-24 11:06:34.176952
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class UserSchema(Schema):
        name = String()

    schema = UserSchema()
    token = Token("name", "", 42, 42)
    field = schema.fields["name"]
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=field)

    error = exc.value
    assert len(error.messages()) == 1
    message = error.messages()[0]
    assert message.start_position == 42
    assert message.end_position == 42

# Generated at 2022-06-24 11:06:43.456245
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    from typesystem.tokenize.tokens import BaseToken

    def test_error():
        class Thing(typesystem.Schema):
            name = typesystem.String(required=True)

        class Root(typesystem.Schema):
            thing = Thing()

        token = BaseToken(value={"name": ""})
        with pytest.raises(typesystem.ValidationError) as exc_info:
            validate_with_positions(token=token, validator=Root)

# Generated at 2022-06-24 11:06:51.451777
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import JsonToken

    class JsonSchema(Schema):
        field1 = String()

    token = JsonToken.from_json({"field1": "foo"})

    # Perform validation
    validate_with_positions(token=token, validator=JsonSchema)

    # -------

    token = JsonToken.from_json({})

    try:
        # Perform validation
        validate_with_positions(token=token, validator=JsonSchema)
    except ValidationError as error:
        for message in error.messages():
            assert message.start_position == token.end
            assert message.end_position == token.end

    # -------


# Generated at 2022-06-24 11:06:58.583071
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from python_ta import check_types

    from dataclasses import dataclass
    from typing import Any, Union, List, TYPE_CHECKING
    from json import dumps

    from . import tokenize

    if TYPE_CHECKING:
        from .tokenize.tokens import Token

    @dataclass
    class ListField(Field):
        items: Field

        def validate_items(self, items: typing.List[Any]) -> typing.List[Any]:
            return [
                validate_with_positions(token=item[0], validator=self.items)
                for item in items
            ]

    @dataclass
    class ObjectField(Field):
        fields: typing.Dict[str, Field]


# Generated at 2022-06-24 11:07:08.825855
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.parser.parser import parse, load_grammar
    from typesystem.tokenize.tokenizer import tokenize

    load_grammar("tests/fixtures/positional_messages.yaml")

    with open("tests/fixtures/positional_messages.txt") as f:
        text = f.read()
    tokens = tokenize(text)
    ast = parse(tokens)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=ast, validator=Schema)
    assert len(exc_info.value.messages) == 6
    assert exc_info.value.messages[0].code == "required"
    assert exc_info.value.messages[1].code == "type"
    assert exc_info.value.mess

# Generated at 2022-06-24 11:07:20.111846
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer

    field = Integer()

    token = Token("1", start=1, end=2)
    validate_with_positions(token=token, validator=field)

    token = Token("", start=5, end=5)
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=field)
    assert excinfo.value.messages() == [
        Message(
            text="The field '' is required.",
            code="required",
            index="",
            start_position=5,
            end_position=5,
        )
    ]

    token = Token(1, start=1, end=2)
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions

# Generated at 2022-06-24 11:07:31.962379
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import Tokenizer
    from typesystem.tokenize.default_tokenizers import default_tokenizer
    from typesystem.fields import Array, Integer

    class TestSchema(Schema):
        foo = Array[Integer]()

    tokenizer = Tokenizer(tokenizers=[default_tokenizer])
    try:
        validate_with_positions(token=tokenizer(b""), validator=TestSchema)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text='"foo" is a required field.',
                code="required",
                index=("foo",),
                start_position=None,
                end_position=None,
            )
        ]


# Generated at 2022-06-24 11:07:43.675746
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.positions import Position
    from typesystem.tokenize.tokens import ArrayToken, FieldToken, ObjectToken

    # The token below represents a JSON object:
    #
    #   { "field": ["A"] }
    #
    # The array token (id=1) contains a string token (id=3) that represents the
    # string "A".

# Generated at 2022-06-24 11:07:54.048018
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem import String, Integer
    from typesystem.schemas import Schema

    class FooSchema(Schema):
        name = String("Name")
        age = Integer("Age")

    token = Token("{}")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=FooSchema)


# Generated at 2022-06-24 11:08:05.474527
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.token_source import TokenSource
    from typesystem.tokenize.tokens import ListToken
    from typesystem.fields import BooleanField

    text = "{% include 'file.json' %}"
    validator = BooleanField()
    source = TokenSource(text=text)
    token = ListToken(value=[source])

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=validator)

    assert exc_info.value.args == ([],)
    assert len(exc_info.value.messages()) == 1
    message = exc_info.value.messages()[0]

    assert message.text == "Expected a boolean."
    assert message.code == "invalid_type"
    assert message.start_

# Generated at 2022-06-24 11:08:16.372981
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema({"name": Field(required=True, primitive=str)})

    token = Token(
        value={},
        tokens={
            "name": Token(
                start={"line": 1, "column": 2, "char_index": 2},
                end={"line": 1, "column": 6, "char_index": 6},
            )
        },
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    assert len(exc_info.value.messages) == 1
    message = exc_info.value.messages[0]
    assert message.start_position.line == 1
    assert message.start_position.column == 2
    assert message.start_position.char_index == 2

# Generated at 2022-06-24 11:08:27.810393
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import ObjectToken
    from typesystem.tokens import Dictionary
    from typesystem.schemas import Schema
    from typesystem.fields import Field
    from typesystem import types

    schema = Schema(
        fields={
            "first_name": Field(type=types.String()),
            "last_name": Field(type=types.String()),
            "age": Field(type=types.Integer()),
        }
    )


# Generated at 2022-06-24 11:08:35.819426
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .harness import BasicSchema

    token = Token(
        "root", value={"a": "foo", "b": "bar", "c": [{"d": "123"}]}, start=None, end=None
    )
    token = token.lookup(["c"])[0].lookup(["d"])
    try:
        validate_with_positions(token=token, validator=BasicSchema.fields["a"])
    except ValidationError as error:
        # When expect to fail, assert contains expected message
        assert error.messages() == [
            Message(
                text="This field is required.",
                code="required",
                index=["c", 0, "d"],
                start_position=token.start,
                end_position=token.end,
            )
        ]

# Generated at 2022-06-24 11:08:44.552649
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .test_tokenize import parse_string

    class Shirt(Schema):
        size = Field(type="string", required=True)
        color = Field(type="string", required=True)

    data = """
    {
        "size": "large",
        "color": "red"
    }
    """
    token = parse_string(data)

    validate_with_positions(token=token, validator=Shirt)



# Generated at 2022-06-24 11:08:45.353036
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-24 11:08:54.081422
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class TestSchema(Schema):
        field1 = Field(type="string", required=True)
        field2 = Field(type="string", required=True)

    with open("tests/tokenize/fixtures/positional_errors.py", "r") as f:
        data = f.read()

    tokens = [token for token in tokenize(data)]
    token = Token(tokens)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=TestSchema)

    messages = sorted(
        exc_info.value.messages,
        key=lambda m: m.start_position.char_index,
    )

# Generated at 2022-06-24 11:09:04.293142
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Integer

    token = Token(
        value="""
        [
            {"id": "123"},
            {"id": "foo"},
            {"id": "456"}
        ]
    """
    )

    class ItemSchema(Schema):
        id = Integer(min_value=1)

    class CollectionSchema(Schema):
        items = ItemSchema[:]

    try:
        validate_with_positions(
            token=token.value.as_json(), validator=CollectionSchema
        )
    except ValidationError as error:
        assert [message.code for message in error.messages()] == ["min_value"]
        assert error.messages()[0].start_position.line == 3
        assert error.messages()[0].start_position.char_index == 11

# Generated at 2022-06-24 11:09:12.817280
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_text

    # This function is tested in the tests for Field and Schema.
    # Here just simple round-trip tests to verify that the
    # `validate_with_positions` method works as expected.

    schema = Schema({"name": Field(str)}, unknown="error")
    token1 = tokenize_text(r'{"name": "bob"}', start_position=0)
    validate_with_positions(token=token1, validator=schema)

    token2 = tokenize_text(r'{"wrong_name": "bob"}', start_position=0)
    with pytest.raises(ValidationError) as einfo:
        validate_with_positions(token=token2, validator=schema)

    field_error = einfo.value

# Generated at 2022-06-24 11:09:23.903050
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, fields
    from typesystem.tokenize import tokenize

    token = tokenize("{")[0]  # type: ignore

    class BodySchema(Schema):
        name = String(required=True)
        age = fields.Integer(required=True)

    def validate(
        *, token: Token, validator: typing.Union[Field, typing.Type[Schema]]
    ) -> typing.Any:
        return validate_with_positions(token=token, validator=validator)

    with pytest.raises(ValidationError) as exc_info:
        validate(token=token, validator=BodySchema)
    messages = exc_info.value.messages
    assert messages[0].code == "required"
    assert messages[0].index == ["name"]

# Generated at 2022-06-24 11:09:33.403865
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Any
    from typesystem.tokenize.tokens import FileToken

    def extract_messages(errors):
        return [str(m) for m in errors.messages()]

    field = Any()
    file = '{"a":1}'
    token = FileToken(file)

    field.validate(token.value)

    try:
        field.validate({})
    except ValidationError as e:
        assert extract_messages(e) == [
            "a is required (code=required)",
            "Value must be JSON-encodable (code=encodable)",
        ]
        assert [m.start_position.char_index for m in e.messages()] == [1, 1]

# Generated at 2022-06-24 11:09:38.950223
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem import String, Integer

    class Food(Schema):
        name = String(required=True)
        calories = Integer()

    tokens = tokenize(
        {
            "name": "apple",
            "calories": "100",
        }
    )
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=tokens[0], validator=Food)
    error = excinfo.value

# Generated at 2022-06-24 11:09:49.109188
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(properties={"name": Field(type="string")})
    data = {
        "name": "Charlemagne",
        "age": "72",
        "bad_field": [1.0, 2.0],
    }
    token = Token.from_data(data)
    try:
        validate_with_positions(token=token, validator=schema)
        assert False, "Expected a validation error"
    except ValidationError as error:
        assert len(error.messages) == 4
        first_message = error.messages[0]
        assert first_message.text == "Expected type 'object', received type 'string'"
        assert first_message.start_position.column == 1
        age = error.messages[1]

# Generated at 2022-06-24 11:09:58.866928
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """
    >>> from typesystem.tokenize.base import Token
    >>> from typesystem.fields import String
    >>> from typesystem.schemas import ObjectSchema
    >>>
    >>> class ExampleSchema(ObjectSchema):
    ...     foo = String(required=True)
    >>>
    >>> token = Token(name="root",
    ...               start_line=10,
    ...               start_char=0,
    ...               end_line=10,
    ...               end_char=1,
    ...               value={})
    >>>
    >>> validate_with_positions(token=token, validator=ExampleSchema)
    Traceback (most recent call last):
    ...
    ValidationError: The field 'foo' is required. (line 10, column 1)
    """
    ...