

# Generated at 2022-06-24 11:00:00.299379
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import parse_token

    @parse_token("{a: [1, 2, 3]}")
    class Schema(typesystem.Schema):
        a = typesystem.Array(typesystem.Integer(), min_items=4)

    try:
        validate_with_positions(token=token, validator=Schema)
        assert False
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'a' must have 4 items or more."
        assert message.start_position.line_number == 1
        assert message.start_position.char_index == 0
        assert message.end_position.line_number == 1
        assert message.end_position.char_index == 17

# Generated at 2022-06-24 11:00:10.091034
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import (
        String,
        Integer,
        Object,
        FieldSet,
        Link,
        Constant,
        DateTime,
        Date,
        Time,
    )

    from typesystem.tokenize import Tokenizer
    from typesystem.utils import SimpleFieldSet

    class DataSchema(Schema):
        type = String(constant="data")
        data = Object(
            fields={
                "a": String(enum=["A", "B"]),
                "b": String(),
                "c": Integer(),
            }
        )

    class LinkSchema(Schema):
        type = String(constant="link")

# Generated at 2022-06-24 11:00:19.162492
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.fields import Name
    from tests.schemas import Person
    import pytest
    import json

    data = json.dumps(
        {
            "name": {
                "first": "John",
                "last": "",
                "nickname": "",
            }
        }
    )
    tokens = Token.parse(data)
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=tokens, validator=Person)
    messages = sorted(
        exc.value.messages(),
        key=lambda m: m.start_position.char_index,  # type: ignore
    )
    assert len(messages) == 2
    assert messages[0].text == "The field 'nickname' is required."
    assert messages[0].code

# Generated at 2022-06-24 11:00:28.062664
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import BaseToken, TokenInfo

    class MyField(Field):
        def validate(self, value, **kwargs):
            if value != "foo":
                self.error("The value is not foo.", code="foo_required")

    class MyField2(Field):
        def validate(self, value, **kwargs):
            if value != "foo":
                self.error("The value is not foo.", code="foo_required")


# Generated at 2022-06-24 11:00:39.782396
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """Test validate_with_positions."""
    import typesystem

    class NestedSchema(typesystem.Schema):
        nested_field = typesystem.String()

    class TestSchema(typesystem.Schema):
        top_level_field = typesystem.String(required=True)
        nested_field = NestedSchema()

    # pylint: disable=no-value-for-parameter
    test_schema = TestSchema()

    def check_validate(data, expected_start=0, expected_end=0):
        token = Token(value=data, start={"line": 0, "col": 0, "char": 0}, end=None)

# Generated at 2022-06-24 11:00:47.457468
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.tokenize.parser import parse

    class Foo(Schema):
        a = Field(type="string", max_length=1)
        b = Field(type="string", max_length=3)
        c = Field(type="string", max_length=2)

    token = parse("""{"a": "a", "b": "bb", "c": "ccc"}""")
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=Foo)

# Generated at 2022-06-24 11:00:53.373300
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    import typesystem.tokenize
    import typesystem.tokenize.tokens

    schema = {
        "email": typesystem.String(required=True),
        "first_name": typesystem.String(required=True),
        "last_name": typesystem.String(),
        "user_id": typesystem.String(required=True),
        "address": {
            "street": typesystem.String(required=True),
            "city": typesystem.String(),
            "zipcode": typesystem.String(),
        },
    }

    source = '{"email":"joe@example.com","first_name":"Joe","last_name":"Smith","user_id":"abc123","address": {"street":"123 Oak Lane","city":"Anywhere","zipcode":"12345"}}'

# Generated at 2022-06-24 11:01:02.177656
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import Message
    from typesystem.exceptions import ValidationError
    from typesystem.tokenize.tokens import FieldToken, ListToken, ObjectToken
    from typesystem.tokenize.tokens import StringToken
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    class Company(Schema):
        name = Field(type="string")
        employees = Field(type="list", items=Person)


# Generated at 2022-06-24 11:01:10.722658
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from decimal import Decimal, InvalidOperation
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token, TokenType

    field = String(min_length=1, max_length=1)
    try:
        validate_with_positions(token=Token(value={}, type=TokenType.FIELD), validator=field)
    except ValidationError as e:
        assert len(e.messages()) == 3
        assert [
            msg.start_position.line_number for msg in e.messages()
        ] == [3, 3, 3]
        assert [
            msg.start_position.char_index for msg in e.messages()
        ] == [3, 9, 15]

# Generated at 2022-06-24 11:01:14.817826
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String
    from typesystem.tokenize.tokens import Token

    class ExampleSchema(Schema):
        foo = String()

    example = ExampleSchema.parse('{ "foo": "bar" }')

    result = validate_with_positions(
        token=example.document, validator=ExampleSchema
    )

    assert result == {"foo": "bar"}

    example = ExampleSchema.parse('{ "foo": 123 }')
    try:
        validate_with_positions(token=example.document, validator=ExampleSchema)
    except ValidationError as error:
        assert len(error.messages) == 1
        assert isinstance(error.messages[0], Message)
        assert error.messages[0].index == ["foo"]
        assert error.messages[0].text

# Generated at 2022-06-24 11:01:26.470036
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import Field, Boolean, Integer, String

    class TestSchema(Schema):
        foo = Boolean(required=True)
        bar = Integer(required=True)
        baz = String(required=True)

    assert validate_with_positions(
        token={"foo": False, "bar": 42, "baz": "hello"}, validator=TestSchema
    ) == {"foo": False, "bar": 42, "baz": "hello"}

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token={}, validator=TestSchema)

# Generated at 2022-06-24 11:01:33.438160
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import tokenize_str
    from typesystem.fields import String
    import io
    import sys

    try:
        old_stderr = sys.stderr
        sys.stderr = io.StringIO()
        token = tokenize_str("{}", as_json=True)
        try:
            validate_with_positions(token=token, validator=String())
        except ValidationError:
            output = sys.stderr.getvalue()
            assert output == "line 1, char 1: The field 'data' is required."
    finally:
        sys.stderr = old_stderr

# Generated at 2022-06-24 11:01:42.812393
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.position import Position
    from typesystem.schemas import Schema
    from typesystem.fields import Field

    class Person(Schema):
        name = Field(type="string", required=True)

    class MyArray(Schema):
        items = [Person]

    class MyObject(Schema):
        values = {"int": Person}


# Generated at 2022-06-24 11:01:54.550740
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema, String
    from typesystem.fields import Integer

    class HelloSchema(Schema):
        hello = Integer(required=True)

    schema = HelloSchema(required=False, strict=True)
    token = Token(value={}, start=None, end=None)
    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=token, validator=schema)
    errors = error_info.value.messages
    assert len(errors) == 1
    assert errors[0].start_position is None

    # Case 2
    token = Token(value={}, start={"line": 1, "char_index": 0}, end=None)
    with pytest.raises(ValidationError) as error_info:
        validate_

# Generated at 2022-06-24 11:02:05.916889
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Validator, Mapping
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.finders import find_token

    class FinalMapping(Mapping):
        mapping = {"id": Integer(), "name": String()}

    input = {
        "id": "1",
        "name": "foo",
        "extra": "value",
    }
    token = find_token(input, "")

    try:
        validate_with_positions(token=token, validator=FinalMapping)
        raise AssertionError("there should be an error")
    except ValidationError as error:
        messages = [m.text for m in error.messages()]

# Generated at 2022-06-24 11:02:14.783826
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Array
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import DocumentToken

    class PersonSchema(Schema):
        name = Field(type=str)
        age = Field(type=int)

    def test_validate_with_positions():
        fields = {
            "name": "John Smith",
            "age": "20",
        }
        tokens = [
            Token(name="name", value=fields["name"], start=0),
            Token(name="age", value=fields["age"], start=10),
        ]
        token = DocumentToken(tokens=tokens)
        try:
            validate_with_positions(token=token, validator=PersonSchema)
        except ValidationError as error:
            assert len

# Generated at 2022-06-24 11:02:22.048568
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Note: this doesn't test the behavior when Schema is used as the validator
    # because it wouldn't make sense to do so at this point.

    from typesystem.tokenize import tokenize

    token = tokenize("hello")
    field = Field(type=str)

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=field)
    assert excinfo.value.messages[0].start_position.line == 1
    assert excinfo.value.messages[0].start_position.col == 1
    assert excinfo.value.messages[0].end_position.line == 1
    assert excinfo.value.messages[0].end_position.col == 5

    token = tokenize("hello")
    field = Field(type=int)

# Generated at 2022-06-24 11:02:29.469414
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize import Token

    class Post(Schema):
        title = str
        content = str

    token = Token(
        value={
            "title": "...",
            "content": "...",
            "empty": "",
        },
        start=Token.Position(line=1, char_index=1),
        end=Token.Position(line=1, char_index=1),
    )
    validate_with_positions(token=token, validator=Post)



# Generated at 2022-06-24 11:02:39.422957
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """
    Tests that the function validate_with_positions returns a ValidationError
    with error messages that have position information attached to them.
    """
    token = Token("foo", [])
    try:
        validate_with_positions(token=token, validator=Field(required=True))
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field '' is required.",
                code="required",
                index=(),
                start_position=(0, 0, 1),
                end_position=(0, 0, 1),
            )
        ]
    else:
        assert False, "Did not get the expected exception"


__all__ = ["validate_with_positions"]

# Generated at 2022-06-24 11:02:50.884097
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.exceptions import Required
    from typesystem.fields import String, Text
    from typesystem.tokenize.tokens import Context
    from typesystem.tokenize.visitors import FieldVisitor, SchemaVisitor
    from typesystem.types import get_type
    from tests.test_schemas import PropertySchema, ProductSchema

    # When: A field visitor is created and the field is validated.
    text = "a" * 10
    token = Token(
        Context([{"description": "description", "name": "name", "type": "string"}], 0, 0),
        text,
    )
    field: Field = get_type("string")(min_length=20)
    visitor = FieldVisitor([token], [field])

    # Then: The ValidationError contains start and end positions.

# Generated at 2022-06-24 11:02:59.947998
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String

    field = String()

    token = Token(name="foo", value="bar", start=[0, 0], end=[0, 3])
    validate_with_positions(token=token, validator=field)

    with pytest.raises(ValidationError):
        token = Token(name="foo", value=None, start=[0, 0], end=[0, 3])
        validate_with_positions(token=token, validator=field)



# Generated at 2022-06-24 11:03:07.775536
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.templatetags import parse
    from typesystem.schemas import Schema
    from typesystem.fields import String, Array, Integer

    schema = Schema(fields={"list": Array(items=Integer())})

    token = parse("{{ list }}")
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)

    assert excinfo.value.messages()[0].start_position.char_index == 0
    assert excinfo.value.messages()[0].end_position.char_index == 23

    token = parse("{{ list.append('b') }}")

# Generated at 2022-06-24 11:03:14.930307
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Structure
    from typesystem.tokenize.tokens import Token

    # Test with None input
    class TestSchema(Structure):
        value = {"type": int}
    schema = TestSchema()
    token = Token.from_dict({"value": None})
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=schema)

    # Test with unexpected keyword argument
    class TestSchema(Structure):
        value = {"type": int}
    schema = TestSchema()
    token = Token.from_dict({"value": 1, "extra": None})
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=schema)

    # Test with nested structure

# Generated at 2022-06-24 11:03:26.291391
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Array, Integer, String
    from typesystem.text import Lexer

    schema = Array(items=Integer())

    # We'll simulate a token stream, with a full token that includes positional
    # information, as well as a partial token.

# Generated at 2022-06-24 11:03:32.363526
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Boolean, String, Integer, Object

    schema = Object(properties={"first_name": String(), "last_name": String()})
    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(
            token=Token("{}"),
            validator=schema
        )
    assert len(error_info.value.messages) == 2
    assert error_info.value.messages[0].text == 'The field "first_name" is required.'
    assert error_info.value.messages[1].text == 'The field "last_name" is required.'
    for message in error_info.value.messages:
        assert message.start_position.line == 1
        assert message.end_position.line == 1
        assert message.start_position.char

# Generated at 2022-06-24 11:03:38.904014
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, Object

    class MySchema(Schema):
        id = Integer(required=True)

    schema = MySchema()

    errors = []

    try:
        status = validate_with_positions(
            token=Token(value={"id": None}),
            validator=schema,
        )
    except ValidationError as error:
        errors = error.messages()

    assert len(errors) == 1
    assert errors[0].text == "The field 'id' is required."
    assert errors[0].start_position == (0, 0)
    assert errors[0].end_position == (0, 0)



# Generated at 2022-06-24 11:03:46.055171
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import Parser

    parser = Parser()
    token = parser.parse("{}", "example.json")
    validator = Schema(fields={"a": {"type": "integer"}})
    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert token.start == message.start_position
        assert token.end == message.end_position

# Generated at 2022-06-24 11:03:57.432813
# Unit test for function validate_with_positions
def test_validate_with_positions():
    def string_validator(x):
        if x == "test":
            return x
        else:
            raise ValidationError("Wrong value")

    value = "test"
    start = (1, 0)
    end = (1, 4)
    token = Token(
        value=value,
        start=start,
        end=end,
    )

    validate_with_positions(
        token=token, validator=Field(type=str, validators=[string_validator]),
    )
    # If validation is correct test should pass

    token = Token(
        value="wrong",
        start=start,
        end=end,
    )

# Generated at 2022-06-24 11:04:05.945091
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class ExampleSchema(Schema):
        example = Field(required=True)

    token = Token(
        value={"example": "foo"},
        source_text='{"example": "foo"}',
        start=Position(line_index=1, char_index=0),
        end=Position(line_index=1, char_index=15),
    )

    assert validate_with_positions(
        token=token, validator=ExampleSchema
    ) == {"example": "foo"}

# Generated at 2022-06-24 11:04:16.113469
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import ArrayToken, ObjectToken, LiteralToken

    token = ObjectToken(
        "",
        {
            "foo": LiteralToken("", [["bar"], [True]]),
            "baz": LiteralToken("", [["qux"], [None]]),
        },
    )
    value = validate_with_positions(token=token, validator=schema)
    assert value == {"foo": "bar", "baz": None}

    token = ObjectToken(
        "", {"foo": LiteralToken("", [["bar"], [123]])}
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-24 11:04:19.149946
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class Person(Schema):
        name = Field(type="string")

    token = Token(
        {
            "name": "test",
            "location": {"start": {"line": 1, "column": 1}, "end": {"line": 1, "column": 5}},
        }
    )

    validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-24 11:04:20.323300
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert False

# Generated at 2022-06-24 11:04:30.386121
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(fields={"foo": Field(primitive="string"), "bar": Field(primitive="integer")},)
    token = Token(
        value={
            "foo": "bar",
            "bar": "baz",
        },
        start={
            "line_no": 0,
            "char_index": 0,
            "byte_index": 0,
        },
        end={
            "line_no": 0,
            "char_index": 26,
            "byte_index": 26,
        },
    )

# Generated at 2022-06-24 11:04:38.196920
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.exceptions import TokenizationError

    from typesystem.tokenize.tokens import ObjectToken

    from typesystem import fields
    from typesystem.schemas import Schema

    def validate_number(value: int) -> int:
        if value < 5:
            raise ValidationError(text="Too small.")
        return value

    Person = Schema(properties={"name": fields.String, "age": validate_number})

    token = ObjectToken([("name", "Fred"), ("age", 3)])

    try:
        validate_with_positions(
            token=token, validator=Person
        )  # pragma: no cover
        assert False, "Should raise TokenizationError"
    except TokenizationError as error:
        error.messages  # type: ignore

# Generated at 2022-06-24 11:04:46.620918
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.text import Source, Position

    source = Source("""
    {
        "a": true,
        "b": "text",
        "c": ["text", "text", "text"],
        "d": {
            "e": {
                "f": true
            },
            "g": true,
            "h": false,
            "i": null
        }
    }
    """)
    token = tokenize(source)  # type: ignore

    class Nested(Schema):
        a = Field(type="boolean")
        b = Field(type="string")
        c = Field(type="array", items=Field(type="string"))

# Generated at 2022-06-24 11:04:55.955306
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import Position, Token
    from typesystem.validation import validate_with_positions

    data = {
        "people": [
            {"name": "Paul Garvey", "age": 33, "extra": "foo"},
            {"name": "Jane Smith", "age": 20},
        ]
    }

    schema = Schema({"people": [{"name": str, "age": int}]})

    token = Token.from_data(data)

    messages = []

    try:
        validate_with_positions(
            token=token, validator=schema
        )  # should raise ValidationError
    except ValidationError as error:
        messages = error.messages()

    assert messages[0].text == "The field 'extra' is not allowed."
    assert messages[0].start

# Generated at 2022-06-24 11:04:56.653269
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-24 11:05:06.110263
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import tokenize

    class TestSchema(Schema):
        required = Field(required=True)
        optional = Field(required=False)

    schema = TestSchema()

    source = "required=foo optional=bar"
    tokens = tokenize(source)
    token = tokens[1]
    value = validate_with_positions(token=token, validator=schema.required)
    assert value == "foo"

    source = "required=foo"
    tokens = tokenize(source)
    token = tokens[1]
    value = validate_with_positions(token=token, validator=schema.optional)
    assert value == "foo"

    source = "required=foo optional=bar"
    tokens = tokenize(source)
    token = tokens[1]
   

# Generated at 2022-06-24 11:05:14.437641
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer  # noqa

    token = Token(
        value={
            "first_name": "John",
            "last_name": "Doe",
            "age": "42",
        },
        start=(0, 0, 0),
        end=(1, 0, 1),
    )
    class PersonSchema(Schema):
        first_name = Field(type=str, required=True)
        last_name = Field(type=str, required=True)
        age = Field(type=Integer, required=True)

# Generated at 2022-06-24 11:05:23.381853
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import ValidationMessage as Message
    from typesystem.schemas import Schema
    from typesystem.fields import String
    #
    # This is a unit test for the function "validate_with_positions". Because
    # it is a function we can't use the usual testing mechanism.
    #
    token = Token(
        value=["foo", {"a": ["bar", "baz"]}],
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 5, "column": 1, "char_index": 17},
    )
    #
    # Create a schema
    #
    class MySchema(Schema):
        a = String()


# Generated at 2022-06-24 11:05:33.661191
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.parser import parse_schema
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import MissingValueToken

    schema = parse_schema("""
    one: integer
    two: string
    """)

    with raises(ValidationError) as exc_info:
        text = "one: 1\nthree: 3\n"
        tokens = tokenize(text)
        validate_with_positions(token=tokens, validator=schema)

# Generated at 2022-06-24 11:05:42.048393
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        start=Position(line_index=0, char_index=0),
        end=Position(line_index=0, char_index=5),
        value="hello",
    )
    field = Field(type=str, required=True)
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=field)

    message = excinfo.value.messages[0]
    assert message.text == "The field '' is required."
    assert message.code == "required"
    assert message.start_position.line_index == 0
    assert message.start_position.char_index == 0
    assert message.end_position.line_index == 0
    assert message.end_position.char_index == 5

# Generated at 2022-06-24 11:05:50.660761
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import types, error_messages, errors, validators

    class TestSchema(types.Schema):
        text = types.Token()
        count = types.Integer(required=True)

    Schema = TestSchema()
    with pytest.raises(errors.ValidationError) as e:
        validate_with_positions(
            token=Token(
                {
                    "text": "6",
                    "count": None,
                }
            ),
            validator=Schema,
        )
    assert e.value.messages() == [
        error_messages.RequiredField(field="count", index=["count"],),
    ]

# Generated at 2022-06-24 11:06:01.945105
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.tokenize.tokens import Token, TokenType

    class Person(Schema):
        name = Field(type="string", required=True)

    def _build_tokens(text):
        from typesystem.tokenize import tokenize

        return list(tokenize(text))

    # Basic test
    tokens = _build_tokens('{"name": "Ada Lovelace"}')
    validate_with_positions(token=tokens[0], validator=Person)

    # Missing a required field
    tokens = _build_tokens('{}')
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens[0], validator=Person)


# Generated at 2022-06-24 11:06:11.694197
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokenize import tokenize_value

    class User(Schema):
        name = String(required=True)
        age = String()

    value = {"name": "Tim", "age": 42}
    tokens: typing.List[Token] = tokenize_value(value)

    with pytest.raises(ValidationError) as info:
        validate_with_positions(token=tokens[0], validator=User)

    message = info.value.messages[0]

    assert message.text == "The field 'age' is required."
    assert message.start_position.line_index == 0
    assert message.start_position.char_index == 12
    assert message.end_position.line_

# Generated at 2022-06-24 11:06:20.910591
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem import types
    
    class PersonSchema(types.Schema):
        name = types.String(max_length=100)
        surname = types.String(max_length=100)
        age = types.Integer()

    with pytest.raises(ValidationError) as exc_info:
        person = validate_with_positions(
            token=Token(
                value={
                    "name": "Bob",
                    "surname": "Smith",
                    "not_age": "18",
                },
                start=(1, 3),
                end=(4, 5),
            ),
            validator=PersonSchema(),
        )
    error = exc_info.value
    errors = error.messages()
    assert len(errors) == 1

# Generated at 2022-06-24 11:06:31.051764
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize, ERROR
    from typesystem.tokenize.parse import parse
    from typesystem.fields import String, Integer

    class UserSchema(Schema):
        username = String()
        first_name = String()
        last_name = String()
        age = Integer()

    token_list = tokenize('{"username": "jane",  "age": "42"}')
    tokens = parse(token_list)
    assert tokens[0].lookup(["age", "value"]).type == ERROR  # type: ignore
    assert tokens[0].lookup(["age", "value"]).value == '"42"'


# Generated at 2022-06-24 11:06:38.799543
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.parser import parse_token_stream
    from typesystem.tokenize import tokenize
    from typesystem.exceptions import ValidationError

    token = tokenize('{"foo": "bar"}')
    assert validate_with_positions(token=token, validator=String()) == "bar"

    schema = parse_token_stream('{"foo": String()}')
    assert validate_with_positions(token=token, validator=schema) == {"foo": "bar"}

    token = tokenize('{"foo": 1}')
    assert validate_with_positions(token=token, validator=String()) == 1

    schema = parse_token_stream('{"foo": String()}')
    with pytest.raises(ValidationError) as exc_info:
        validate_with

# Generated at 2022-06-24 11:06:48.846403
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.examples import Person, PersonSchema
    from typesystem.tokenize import tokenize, token_to_python

    schema = PersonSchema()

    def test(*, json: str, expected: typing.Any) -> None:
        tokens = tokenize(json=json)
        result = validate_with_positions(
            token=token_to_python(tokens[0]), validator=schema
        )
        assert expected == result

    json = '{"name": "bob", "age": "eighteen"}'
    with pytest.raises(ValidationError) as error:
        test(json=json, expected=None)
    assert "In line 1, character 16:" in str(error.value)

    json = '{"name": "bob", "age": 18}'

# Generated at 2022-06-24 11:06:54.093389
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class PersonSchema(Schema):
        name = Field(str, min_length=5)
        age = Field(int, min_value=13)

    data = {"name": "Bob", "age": "10"}

    schema = PersonSchema()
    schema.validate(data)


    class PersonSchema(Schema):
        name = Field(str, min_length=5)
        age = Field(int, min_value=13)

    data = {"name": "Bob", "age": "10"}

    schema = PersonSchema()
    try:
        validate_with_positions(token=Token(data), validator=schema)
    except ValidationError as error:
        assert error.messages[0].start_position == Position(line=0, char_index=0)
        assert error.mess

# Generated at 2022-06-24 11:07:04.867462
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import types
    import jmespath

    class MySchema(Schema):
        name = types.String(required=True)

    schema = MySchema()
    schema.validate({"name": "Fred"})

    with pytest.raises(ValidationError) as excinfo:
        schema.validate({})

    message = excinfo.value.messages[0]
    assert message.start_line == 1
    assert message.start_column == 1
    assert message.end_line == 1
    assert message.end_column == 1
    assert message.text == "The field 'name' is required."


# Generated at 2022-06-24 11:07:17.296048
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # This field is used in the example below
    class NameField(Field):
        pass

    class PersonSchema(Schema):
        name = NameField()

    schema = PersonSchema()

    # Here we have a token object that represents the entire string
    #
    # {
    #     "name": "",
    #     "age": 20
    # }
    #
    # We will be validating the "name" field, which is empty.
    token = Token(
        value='{"name": "", "age": 20}',
        start=Position(column=0, line=1, char_index=0),
        end=Position(column=21, line=2, char_index=22),
    )

    # First we get the child token
    child = token.lookup(["name"])

    # Then

# Generated at 2022-06-24 11:07:23.097273
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.fields import Integer as TInteger
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize

    Schema1 = Schema({"a": TInteger()})

    tokens = tokenize('{"a": 12.5}', Schema1)
    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=tokens, validator=Schema1)

    assert len(error_info.value.messages) == 1
    message = error_info.value.messages[0]
    assert message.start_position.char_index == 5
    assert message.end_position.char_index == 7
    assert message.text == "Float number must be an integer."

# Generated at 2022-06-24 11:07:32.892996
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Error messages are copied over to error with start and end positions of
    # the relevant token in the error message tree.
    from typesystem.fields import String

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=Token.create({"url": "", "title": ""}), validator=String())
    assert excinfo.value.messages[0].start_position.char_index == 0
    assert excinfo.value.messages[1].start_position.char_index == 13
    assert excinfo.value.messages[0].end_position.char_index == 13
    assert excinfo.value.messages[1].end_position.char_index == 26


# Generated at 2022-06-24 11:07:43.782740
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import String

    data = {
        "items": ["hello", "goodbye", "goodbye", "hello"],
        "items-metadata": [
            {"example": "hello", "start": {"line": 1, "column": 1}},
            {"example": "goodbye", "start": {"line": 2, "column": 1}},
            {"example": "goodbye", "start": {"line": 3, "column": 1}},
            {"example": "hello", "start": {"line": 4, "column": 1}},
        ],
    }
    token = Token(value=data)

    schema = Schema(name="schema", fields={"items": String()})

# Generated at 2022-06-24 11:07:54.177025
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Validator(Field):
        def validate(self, value, context=None):
            if value is not None:
                return value
            else:
                raise ValidationError(
                    "You must specify a value.", code="required"
                )

    class User(Schema):
        name = Validator()

    token = Token.container(
        Token.container(
            Token.mapping(key=Token.text(value="name"), value=Token.text(None)),
            Token.mapping(key=Token.text(value="age"), value=Token.text("21")),
        )
    )
    messages = validate_with_positions(
        token=token, validator=User,
    ).messages()
    assert [m.text for m in messages] == ["The field 'name' is required."]

# Generated at 2022-06-24 11:08:05.514407
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema({"test": {"required": True}})
    token = Token(
        type="object",
        value={"test": None},
        start={"line": 1, "char_index": 15},
        end={"line": 3, "char_index": 5},
    )

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)

    assert len(excinfo.value.messages) == 1
    message = excinfo.value.messages[0]
    assert message.text == "The field 'test' is required."
    assert message.code == "required"
    assert message.index == ["test"]
    assert message.start_position == {"line": 1, "char_index": 20}

# Generated at 2022-06-24 11:08:15.527069
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Tokenizer
    import typesystem
    tokenizer = Tokenizer(
        typesystem.object(properties={"a": typesystem.integer(), "b": typesystem.string()})
    )
    json_token = tokenizer.bytestring_token(b'{"a": 123, "b": "hello"}')
    token = tokenizer.token(json_token)

    try:
        validate_with_positions(token=token, validator=tokenizer.validator)
    except ValidationError as error:
        for message in error.messages():
            assert message.start_position is not None
            assert message.end_position is not None
    else:
        assert False, "An exception should have been raised"

# Generated at 2022-06-24 11:08:23.525496
# Unit test for function validate_with_positions

# Generated at 2022-06-24 11:08:32.753170
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.errors import TokenizeError
    from typesystem.tokenize.lexers import BaseLexer

    class TestLexer(BaseLexer):
        def tokenize(self, text: str) -> typing.Iterator[Token]:
            yield Token(
                type="string",
                value=text,
                start=Token.Position(line=1, column=1, char_index=0),
                end=Token.Position(line=1, column=10, char_index=9),
            )

    lexer = TestLexer()
    token = lexer.lex_document("testing")

# Generated at 2022-06-24 11:08:40.873458
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Token, TokenType
    from typesystem.tokenize.exceptions import TokenizeError
    from typesystem.tokenize.position import Position, Source
    from typesystem.tokenize.tokens import Object
    from typesystem.tokenize.tokenizers import BaseTokenizer, ObjectTokenizer
    from typesystem.validators import String

    class PositionTokenizer(BaseTokenizer):
        def process(self, source: Source) -> Token:
            return Token(
                value=None,
                start=Position(line=1, char_index=1),
                end=Position(line=1, char_index=1),
            )

    class StringTokenizer(BaseTokenizer):
        def process(self, source: Source) -> Token:
            token_type = TokenType.STRING

# Generated at 2022-06-24 11:08:51.998482
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import parse_token
    import pytest

    token = parse_token(
        '{"foo": 1, "bar": 2, "qux": {"quux": 3, "corge": 4}, "grault": [{"garply": 5}], "waldo": 6, "fred": 7, "plugh": 8, "xyzzy": 9}'
    )

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)
    messages = excinfo.value.messages()
    assert [m.code for m in messages] == [
        "required",
        "required",
        "required",
        "required",
        "required",
        "required",
        "required",
    ]
    assert messages

# Generated at 2022-06-24 11:09:02.725231
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.types import Integer
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import ArrayToken, ObjectToken

    schema = Schema(fields={"invalid": Integer(required=True)})
    token = tokenize(schema, {"valid": "item"})
    assert isinstance(token, ObjectToken)

    messages = []
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        messages = error.messages()

    assert len(messages) == 1
    assert messages[0].text == "The field 'invalid' is required."
    assert messages[0].start_position.char_index == 2
    assert messages[0].end_position.char_index == 2


# Generated at 2022-06-24 11:09:09.125742
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    source = """
    [
      {
        "string": "foo",
        "number": 1,
        "boolean": true,
        "array": [1, 2, 3]
      }
    ]
    """

    @dataclass
    class Position:
        line_index: int
        column_index: int
        char_index: int

    @dataclass
    class SourcePosition:
        start_position: Position
        end_position: Position

    tokens = tokenize(source=source)
    token = tokens[0]

    @dataclass
    class MyTypeSystem:
        string: str
        number: float
        boolean: bool
        array: typing.List[int]

    with pytest.raises(ValidationError) as error:
        validate

# Generated at 2022-06-24 11:09:19.844174
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Structure

    class Person(Structure):
        name = Field(type=str)
        age = Field(type=int, required=False)
        birth_date = Field(type=str, required=False)

    input_text = "{name:Ali}\n"
    tokens = tokenize(input_text)
    assert isinstance(tokens, list)
    assert len(tokens) == 1
    assert isinstance(tokens[0], Token)

    token = tokens[0]
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert len(exc_info.value.messages) == 2

# Generated at 2022-06-24 11:09:22.918356
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.validators import String
    from typesystem.tokenize import tokenize

    token = tokenize("{'foo': 'bar', 'baz': []}")
    schema = Schema({"foo": String, "baz": [String]})

    assert validate_with_positions(token=token, validator=schema) == {
        "foo": "bar",
        "baz": [],
    }



# Generated at 2022-06-24 11:09:32.653046
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import get_type_name
    from typesystem.string_types import String
    from typesystem.tokenize.tokens import ObjectToken

    def get_token_value(token):
        if not isinstance(token, ObjectToken):
            return token.value

        return dict((k, get_token_value(v)) for (k, v) in token.items())

    # Test required field
    schema = String(name="test")
    token = ObjectToken()
    token.start = Position(line=0, line_index=0, char_index=0)
    token.end = Position(line=0, line_index=0, char_index=0)

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        expected

# Generated at 2022-06-24 11:09:41.359019
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import String

    schema = Schema.of({"name": String()})
    token = tokenize({"name": ""})[0]
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        message = error.messages[0]
        assert message.text == "A non-empty string is required."
        assert message.start_position.line_number == 1
        assert message.start_position.char_index == 9
        assert message.end_position.line_number == 1
        assert message.end_position.char_index == 11

# Generated at 2022-06-24 11:09:51.614325
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    schema = Schema(fields={"f" : Field(required=True)})
    text = '{"f": "x"}'
    tokens = tokenize(text)
    validate_with_positions(token=tokens, validator=schema)

    try:
        validate_with_positions(token=tokens.lookup("f"), validator=schema)
    except ValidationError as error:
        assert isinstance(error.messages(), list)
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.index == ("f",)
        assert message.text == "The field 'f' is required."
        assert message.start_position.line_index == 1
        assert message.start_position.char

# Generated at 2022-06-24 11:10:00.032027
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import ObjectToken

    token = ObjectToken(
        {"name": ObjectToken({"first": "John", "last": "Doe"})},
        start_line=1,
        start_column=1,
        end_line=3,
        end_column=3,
    )

    from typesystem.fields import Dict, Structure, String

    class Person(Structure):
        fields = {
            "name": Dict(
                {"first": String(max_length=5), "last": String(max_length=10)}
            )
        }

    person = Person(required=["name"])

    try:
        person.validate(token.value)
    except ValidationError as error:
        messages = []