

# Generated at 2022-06-24 11:00:00.513403
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse
    from typesystem import fields, schemas
    from typesystem.tokenize import start_position

    token = parse(object_name="person", text="""{"name": "", "age": null}""")
    start_position.set_start_position(token, char_index=0, line_number=1)

    class Person(schemas.Schema):
        name = fields.String(required=True)
        age = fields.Integer(required=True)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    errors = exc_info.value.messages(type=Message)
    assert errors[0].text == 'The field "name" is required.'

# Generated at 2022-06-24 11:00:10.638421
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import json_tokenizer
    from typesystem.schemas import Object, String

    class Person(Schema):
        name = String(max_length=10)

    token = json_tokenizer.tokenize('{"name": "Bob"}')

    assert validate_with_positions(token=token, validator=Person) == {"name": "Bob"}

    try:
        validate_with_positions(token=token, validator=Object(name=String(max_length=1)))
    except ValidationError as error:
        assert list(error.messages())[0].code == "invalid_type"
        assert list(error.messages())[0].start_position.char_index == 8
    else:
        raise AssertionError("ValidationError not raised")



# Generated at 2022-06-24 11:00:18.762458
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(primitive="string")
    token = Token("foo", start=Position(char_index=0), end=Position(char_index=3))
    validate_with_positions(token=token, validator=field)
    token = Token(None, start=Position(line=0, char_index=0), end=Position(line=0, char_index=0))
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=field)
    assert str(exc.value) == (
        'Invalid value\n  at "" (line 0, column 0)\n'
        '  - The field "" is required.'
    )

# Generated at 2022-06-24 11:00:25.478069
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem
    import typesystem.tokenize.json as json_tokenizer

    class MySchema(Schema):
        name = typesystem.String()

    # Test correct json file.
    tokens = json_tokenizer.parse_file("./tests/data/test.json")
    result = validate_with_positions(token=tokens, validator=MySchema)
    assert result == {"name": "Jane"}

    # Test incorrect json file.
    tokens = json_tokenizer.parse_file("./tests/data/test.json")
    del tokens["name"]
    try:
        validate_with_positions(token=tokens, validator=MySchema)
    except typesystem.ValidationError as error:
        error_index = error.messages()[1].index

# Generated at 2022-06-24 11:00:37.287099
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse_string
    from typesystem.tokenize.tokens import Token

    class Name(Field):
        pass

    class Person(Schema):
        name = Name(required=True)

    root = parse_string("foo=bar\nname=John Doe")
    assert root.validate(Person) == {"name": "John Doe"}

    try:
        root.validate(Person)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'name' is required."
        assert str(error) == (
            "Line 1, Character 10: The field 'name' is required.\n"
            "Line 2, Character 6: Value is invalid."
        )
    else:
        assert False, "Expected validation error"

# Generated at 2022-06-24 11:00:42.417705
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    schema = Person()

    with pytest.raises(ValidationError):
        token = tokenize(
            {
                "name": "Harry Potter",
                "age": "10",
                "hobby": "Quidditch",
            }
        )
        validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-24 11:00:51.747894
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import dataclasses
    from typesystem.fields import (
        Any,
        Array,
        Boolean,
        Choice,
        Date,
        DateTime,
        Enum,
        Number,
        Object,
        String,
    )

    @dataclasses.dataclass(frozen=True)
    class Location:
        line: int
        column: int

        def __str__(self) -> str:
            return f"line {self.line}, column {self.column}"

    @dataclasses.dataclass(frozen=True)
    class Range:
        start: Location
        end: Location

        def __str__(self) -> str:
            return f"{self.start} - {self.end}"


# Generated at 2022-06-24 11:01:00.653304
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(primitive_type=str)
    token = Token("foo", ((0, 1), (0, 4)))
    assert validate_with_positions(token=token, validator=field) == "foo"

    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=Token(value=""), validator=field)
    messages = [message for message in error_info.value.messages()]
    assert len(messages) == 1
    assert messages[0].index == ()
    assert messages[0].text == "The field '' is required."
    assert messages[0].code == "required"
    assert messages[0].start_position.line_index == 0
    assert messages[0].start_position.char_index == 0
    assert messages[0].end

# Generated at 2022-06-24 11:01:07.143460
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.enums import Enumeration
    from typesystem.fields import String
    from typesystem.tokenize.tokens import TokenType

    class Color(Enumeration):

        BLUE = "blue"
        RED = "red"

    field = Color(name="color")

    @Schema.define
    class MySchema:
        color = field

    token = Token(
        token_type=TokenType.VALUE,
        value="blu",
        start={
            "line": 1,
            "index": 0,
            "char_index": 0,
        },
        end={"line": 1, "index": 3, "char_index": 3},
    )


# Generated at 2022-06-24 11:01:16.875315
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from unit_test.typesystem.tokenize.test_tokens import test_sample  # type: ignore
    from unit_test.typesystem.schemas import test_schema  # type: ignore

    with pytest.raises(ValidationError) as exception:
        validate_with_positions(token=test_sample, validator=test_schema())
    error = exception.value

# Generated at 2022-06-24 11:01:28.244473
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.examples import Person

    token = Token(
        {
            "name": "John Smith",
            "age": 42,
            "favorite_colors": ["red", "blue", "green"],
        }
    )
    validate_with_positions(token=token, validator=Person)
    try:
        validate_with_positions(token=token, validator=Person(required=["favorite_foods"]))
        assert False
    except ValidationError as error:
        assert [message.text for message in error.messages()] == [
            'The field "favorite_foods" is required.'
        ]
        assert error.messages()[0].start_position.char_index == 27
        assert error.messages()[0].end_position.char_index == 43

# Generated at 2022-06-24 11:01:38.985725
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class PersonSchema(Schema):
        name = Field(type="string")

    token = Token(
        value={
            "actor": {
                "name": "",
                "addresses": [
                    {
                        "type": "HOME",
                        "location": {
                            "country": "USA",
                            "address": {
                                "address_line1": "",
                                "city": "Austin",
                                "state": "Texas",
                            },
                        },
                    }
                ],
            },
            "addresses": ["a", "b"],
        }
    )
    person = token.lookup(["actor", "name"])
    schema = PersonSchema()

# Generated at 2022-06-24 11:01:46.251095
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_json
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError

    schema = Schema(fields={"name": String()})
    o = object()
    token = tokenize_json({"name": o})
    validate_with_positions(token=token, validator=schema)

    token = tokenize_json({})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    message = exc_info.value.messages[0]
    assert message.start_position.line == 1
    assert message.start_position.column == 2
    assert message.start_position.char_index == 1

# Generated at 2022-06-24 11:01:55.468418
# Unit test for function validate_with_positions
def test_validate_with_positions():

    import pytest

    source = {
        "source": {
            "name": "store1",
            "price": 800,
            "location": {
                "address": {
                    "street": "Elm",
                    "zipcode": 78401,
                    "city": "Harlingen",
                },
                "longitude": -97.696,
                "latitude": 26.198,
            },
        },
        "time": "2019-07-27T07:00:00Z",
        "events": [],
    }
    token = Token(source, path=["source", "location", "address"])
    with pytest.raises(ValidationError) as record:
        validate_with_positions(token=token, validator=Field(required=True))


# Generated at 2022-06-24 11:02:06.602102
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import tempfile

    from typesystem.schemas import JSONSchema

    json_schema = {
        "type": "object",
        "properties": {
            "bar": {"type": "number"},
            "baz": {"type": "integer"},
            "qux": {"type": "string"},
        },
    }
    json_document = {"foo": 10, "bar": 20, "baz": 30, "qux": "hello"}

    schema = JSONSchema(json_schema)
    token = Token.from_json(json_document)
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
        json.dump(json_document, f, sort_keys=True)

# Generated at 2022-06-24 11:02:11.786558
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import types
    from typesystem.tokenize.containers import TokenList
    from typesystem.tokenize.tokens import StringToken
    from typesystem.tokenize.utils import Position

    field = types.Integer(required=False)
    token = StringToken(
        value="12",
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=3, char_index=2),
    )
    output = validate_with_positions(token=token, validator=field)
    assert output == 12
    assert token.validated_value == 12


# Generated at 2022-06-24 11:02:20.605843
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type="string")
    # This error message should be changed
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(
            token=Token("x", start=Position(line_index=0, char_index=0), end=Position(line_index=0, char_index=1)),
            validator=field,
        )
    assert exc.value.messages[0].text == "The field x is required."
    assert exc.value.messages[0].start_position.line_index == 0
    assert exc.value.messages[0].start_position.char_index == 0
    assert exc.value.messages[0].end_position.line_index == 0
    assert exc.value.messages[0].end_position.char_index == 1


# Generated at 2022-06-24 11:02:27.724980
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object
    from typesystem.fields import String

    class Person(Object):
        name = String()
        age = String()

    token = Token(
        lookup=lambda path: None,
        start=None,
        end=None,
        keys=[],
        value={"name": "Foo"},
    )

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=Person)

    assert [message.text for message in exc.value.messages()] == [
        f"The field 'age' is required.",
    ]

# Generated at 2022-06-24 11:02:36.698319
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(type_=str)
        age = Field(type_=int)

    with pytest.raises(ValidationError) as exc_info:
        token = Token(value={}, start=(1, 1), end=(1, 2))
        validated = validate_with_positions(token=token, validator=Person)

    assert validated is exc_info.value.messages
    assert str(validated[0]) == "Line 1, column 1: The field 'name' is required."
    assert str(validated[1]) == "Line 1, column 1: The field 'age' is required."



# Generated at 2022-06-24 11:02:43.043954
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.primitives import String
    from typesystem.tokenize.reader import tokenize

    data = "hello!"
    string_field = String()
    token = tokenize(data)
    try:
        validate_with_positions(token=token, validator=string_field)
    except ValidationError as error:
        message = error.messages[0]
        assert message.start_position.char_index == 0
        assert message.end_position.char_index == 6
    else:
        assert False

# Generated at 2022-06-24 11:02:46.806979
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    token = tokenize('{"foo": "bar"}')

    class MySchema(Schema):
        foo = Field(str, required=True)

    validate_with_positions(token=token, validator=MySchema)



# Generated at 2022-06-24 11:02:53.963729
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import String
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token

    string = "Hello World!"
    assert validate_with_positions(token=tokenize(string), validator=String()) == string

    string = "Hello World!\nHello World!"
    token = tokenize(string)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=String())
    messages = sorted(exc_info.value.messages, key=lambda m: m.start_position.line_index)

# Generated at 2022-06-24 11:03:02.399225
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typing import List, Union

    from typesystem.tokenize import parse
    from typesystem.number import Integer
    from typesystem.string import String

    schema = Integer(minimum=10)
    string = "hello"
    string_token = parse(string)
    
    assert string_token.kind == "string"
    assert validate_with_positions(token=string_token, validator=schema) == schema.validate(string)


    schema = Integer(maximum=10)
    string = "12"
    string_token = parse(string)
    
    assert string_token.kind == "number"
    assert validate_with_positions(token=string_token, validator=schema) == schema.validate(string)

    schema = Integer(maximum=10)
    string = "12"
    string_

# Generated at 2022-06-24 11:03:09.741362
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.fields import String

    token = Token.create({'name': 'Harry'})
    validator = String(name='name')

    assert validate_with_positions(token=token, validator=validator) == 'Harry'

    with pytest.raises(ValidationError) as err:
        validate_with_positions(token=Token.create({'age': 'twenty'}), validator=validator)
    messages = [Message(
        text='The field name is required.',
        code='required',
        index=('name',),
        start_position=Position(line=1, char_index=1),
        end_position=Position(line=1, char_index=1))]
    assert err.value.messages == messages


# Generated at 2022-06-24 11:03:19.069198
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.positions import LineAndCharPosition, Position

    open_position = Position(line=2, char_index=0)
    close_position = Position(line=2, char_index=9)
    token = Token(value=None, open_position=open_position, close_position=close_position)

    class UserSchema(Schema):
        username = Field(typing.Type[str])

    errors = None
    try:
        validate_with_positions(token=token, validator=UserSchema)
    except Exception as e:
        errors = e

    assert errors is not None
    assert len(errors.messages) == 1
    assert errors.messages[0].index == ["username"]

# Generated at 2022-06-24 11:03:27.723330
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.typing import String

    token = Token(
        value={"name": ""},
        start={"line_number": 10, "column_number": 0, "char_index": 0},
        end={"line_number": 10, "column_number": 0, "char_index": 0},
    )
    field = Field(type=String, required=True)  # type: ignore

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)

    message = exc_info.value.messages[0]
    assert message.index == ("name",)
    assert message.start_position == {
        "line_number": 10,
        "column_number": 0,
        "char_index": 0,
    }


# Generated at 2022-06-24 11:03:37.282330
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    valid_data = '{"name": "Bob", "age": 35}'
    tree = tokenize(valid_data)
    validate_with_positions(token=tree, validator=Person)

    invalid_data = '{"name": "Bob"}'
    tree = tokenize(invalid_data)
    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=tree, validator=Person)
    messages = list(reversed(list(error_info.value.messages())))
    assert messages[0].code == "required"
    assert messages[1].code == "invalid"

##############################################################################


# Generated at 2022-06-24 11:03:46.648765
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # type: () -> None
    field = Field(type=int)
    token = Token(type="int", value=5, start=0, end=1)
    assert validate_with_positions(token=token, validator=field) == 5

    token = Token("string", "5", start=0, end=1)
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert len(error.messages) == 1
        message = error.messages[0]
        assert message.text == "Must be int."
        assert message.code == "type"
        assert message.start_position.line == 0
        assert message.start_position.column == 0
        assert message.end_position.line == 0
        assert message.end_position

# Generated at 2022-06-24 11:03:54.266696
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize

    class EmailSchema(Schema):
        email = Field(format="email")

    schema = EmailSchema()
    email = "test@example.com"
    text = f"Welcome, {email}!"
    token = tokenize(text, partial_expression=email)
    validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-24 11:03:54.688215
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-24 11:04:04.153816
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    from typesystem.token import Token

    class SomeSchema(Schema):
        name: typesystem.String = typesystem.String(max_length=5)

    token = Token(
        value={"name": "hello"},
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 2, "char_index": 5},
    )
    result = validate_with_positions(token=token, validator=SomeSchema)
    default_message = result["_errors"][0]
    assert default_message.text == "The field 'name' is too long."
    default_message = default_message.json()
    assert default_message["index"] == ["name"]
    assert default_message["code"] == "max_length"
    assert default_message

# Generated at 2022-06-24 11:04:13.186490
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import parse_source, Tokenizer
    from typesystem.tokenize.visitors import FlattenVisitor
    from typesystem.tokenize.utils import get_message_path

    source = """
        {
            "foo": {
                "bar": "baz",
                "baz": "buzz"
            }
        }
    """
    flatten = FlattenVisitor()
    tokens = flatten.visit(parse_source(source))
    validator = Field(type="string", min_length=3)
    validate_with_positions(token=tokens[0], validator=validator)

# Generated at 2022-06-24 11:04:21.252315
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import ValueToken, Token
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = String(required=True)
        age = Integer()

    token = {
        "name": "Alice",
        "age": "I'm not an integer",
        "favorite_color": "red",
    }
    token = ValueToken(token).start_at(0, 0, 0)


# Generated at 2022-06-24 11:04:31.391932
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String
    import typesystem.tokenize as tokenize
    import typesystem.tokenize.fields

    field = String(max_length=3, required=True)
    schema = tokenize.fields.Structure(
        foo=field, bar=tokenize.fields.Structure(baz=field)
    )
    token = tokenize.parse("""
    foo: "a"
    bar:
        baz: "b"
    """)

    assert schema.validate(token.value) == {
        "foo": "a", "bar": {"baz": "b"}
    }

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-24 11:04:41.270006
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert (
        validate_with_positions(
            token=Token(
                value={"name": "Jessica", "email": "jessica@example.com"},
                start=Position(line_index=1, char_index=1),
                end=Position(line_index=5, char_index=10),
            ),
            validator=ContactSchema,
        )
        == {"name": "Jessica", "email": "jessica@example.com"}
    )


# Generated at 2022-06-24 11:04:52.155745
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # pylint: disable=no-member

    class Body(Schema):
        foo = Field(type="string")
        bar = Field(type="integer", required=True)

    from typesystem.tokenize.tokens import Token

    root = Token(value={"foo": "x", "bar": None})
    token = root.lookup(["bar"])
    try:
        validate_with_positions(token=token, validator=Body)
    except ValidationError as error:
        tokens = error.messages()
        assert len(tokens) == 1
        token = tokens[0]
        assert token.code == "required"
        assert token.text == "The field 'bar' is required."
        assert token.start_position.char_index == 13
        assert token.end_position.char_

# Generated at 2022-06-24 11:04:57.923123
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # pylint: disable=unused-variable
    import pathlib
    import json
    import typesystem

    source = pathlib.Path("tests/fixtures/simple_yaml_schema.yaml")
    with source.open("rb") as file_stream:
        data = file_stream.read()

    stringified = json.dumps(data, ensure_ascii=False)
    token = Token.from_string(stringified)
    schema = typesystem.Schema.from_yaml(data)

    assert validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-24 11:05:06.633783
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize import TokenError, ValidationError

    class Issue(Schema):
        title = Field(type=str)
        number = Field(type=int)

    def validate_with_positions(
        *, token: Token, validator: typing.Union[Field, typing.Type[Schema]]
    ) -> typing.Any:
        try:
            return validator.validate(token.value)
        except ValidationError as error:
            messages = []
            for message in error.messages():
                if message.code == "required":
                    field = message.index[-1]
                    token = token.lookup(message.index[:-1])
                    text = f"The field {field!r} is required."

# Generated at 2022-06-24 11:05:14.775205
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import textwrap
    from typesystem.tokenize.tokenizer import Tokenizer

    data = json.loads(
        textwrap.dedent(
            """
    {
        "name": "John Doe",
        "age": 0
    }
    """
        )
    )
    tokenizer = Tokenizer()
    tokens = tokenizer.tokenize(data)

    from typesystem import Schema, fields

    class User(Schema):
        name = fields.String(min_length=1)
        age = fields.Integer(minimum=18)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens, validator=User)

    message = exc_info.value.messages()[0]

# Generated at 2022-06-24 11:05:24.618320
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(fields={"name": Field(type="string")})
    token = Token(
        name="test",
        segments=[
            Token(
                name="data",
                segments=[
                    Token(
                        name="name",
                        value="Arne",
                        start=Point(line=2, char_index=7),
                        end=Point(line=2, char_index=11),
                    )
                ],
                start=Point(line=2, char_index=0),
                end=Point(line=2, char_index=18),
            )
        ],
    )
    data = validate_with_positions(token=token, validator=schema)
    assert data == {"name": "Arne"}



# Generated at 2022-06-24 11:05:33.965976
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class ExampleSchema(Schema):
        bar = Field(type="string")
        baz = Field(type="integer")

    token = Token(
        value={
            "foo": "bar",
            "bar": {
                "baz": "qux"
            },
            "baz": "quux",
        },
        start={
            "line_index": 1,
            "char_index": 1,
        },
        end={
            "line_index": 5,
            "char_index": 6,
        },
    )

    try:
        validate_with_positions(token=token, validator=ExampleSchema)
    except ValidationError as error:
        assert len(error.messages()) == 3

# Generated at 2022-06-24 11:05:36.962001
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.validators import String

    token = tokenize('{"foo": 1}')["foo"]
    assert validate_with_positions(token=token, validator=String()) is None

# Generated at 2022-06-24 11:05:40.737485
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # given,
    class MySchema(Schema):
        foo = Field(required=True)

    # expect,
    with pytest.raises(ValidationError):
        validate_with_positions(
            token=Token(value={"foo": None}, source="{}"), validator=MySchema
        )



# Generated at 2022-06-24 11:05:47.042596
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.validators import String

    errors = None
    try:
        tokenize("[1,2", validate_with_positions, validator=String())
    except ValidationError as error:
        errors = error.messages()
    assert errors is not None
    assert len(errors) == 1
    assert errors[0].start_position == (1, 4)

# Generated at 2022-06-24 11:05:58.431059
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_string

    class AuthSchema(Schema):
        email = Field(type="string")
        password = Field(type="string")

    token = tokenize_string(
        '{email: "user@host.com", password: "pwd", not_defined: null}'
    )

    try:
        validate_with_positions(token=token, validator=AuthSchema)
        assert False, "Expected error"
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'not_defined' is not defined."
        assert message.code == "not_defined"
        assert message.start_position.line == 1

# Generated at 2022-06-24 11:06:04.360466
# Unit test for function validate_with_positions
def test_validate_with_positions():
    with pytest.raises(ValueError) as excinfo:
        @validate_with_positions(token="token")
        def validator():
            return None
    assert (
        excinfo.value.args[0]
        == "You can only decorate a validator (of type Field or Schema) with this decorator"
    )

# Generated at 2022-06-24 11:06:12.600558
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class PhoneNumberSchema(Schema):

        def get_validators(self, field: Field) -> typing.List[typing.Callable]:
            return [
                super().get_validators(field),
                validate_with_positions,
            ]

        number = Field(str)

    with pytest.raises(ValidationError) as exc_info:
        PhoneNumberSchema.validate("{number: ''}")

    assert '"The field \'number\' is required."' in str(exc_info.value)
    assert "start=line 1, char 3" in str(exc_info.value)
    assert "end=line 1, char 17" in str(exc_info.value)

# Generated at 2022-06-24 11:06:21.386346
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class CategorySchema(Schema):
        name = Field(type="string")

    class ProductSchema(Schema):
        name = Field(type="string")
        category = Field(type="object", schema=CategorySchema)

    class ShoppingListSchema(Schema):
        name = Field(type="string")
        products = Field(type="list", items=ProductSchema)

    schema = ShoppingListSchema()
    value = {"name": "Snacks"}
    data = json.dumps(value)
    tokens = tokenize(data)
    try:
        validate_with_positions(token=tokens[0], validator=schema)
    except ValidationError as error:
        error = format_error(error)

# Generated at 2022-06-24 11:06:34.107426
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import from_json
    from typesystem.strings import String
    from typesystem.fields import Field, Number

    schema = Schema([String(min_length=1), Number()])

    document = from_json(b"{'a': 'hello'}")
    assert validate_with_positions(token=document, validator=schema) == {"a": "hello"}

    schema = Schema([String(min_length=1), Number()])

    document = from_json(b"{}")
    try:
        validate_with_positions(token=document, validator=schema)
    except ValidationError as error:
        assert error.messages()[0].start_position.line_index == 1  # type: ignore
        assert error.messages()[0].start_

# Generated at 2022-06-24 11:06:45.662124
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Structure, fields

    class MySchema(Structure):
        name = fields.String(required=True)
        age = fields.Integer(required=True)

    token = Token.from_python(
        {
            "name": "Joe",
            "age": "Not an integer",
            "missing_field": "Something",
            "empty_object": {},
        }
    )

    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as error:
        message = error.messages[0]
        assert (
            message.start_position == token.lookup("age").start
        ), "Should start at the beginning of the `age` string"

# Generated at 2022-06-24 11:06:54.627257
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.contrib.tokenize._utils import Position

    assert validate_with_positions(
        token=Token(
            value={"titles": ["{}", "{}"], "authors": ["{}", "{}"]},
            start=Position(line=1, char_index=1),
            end=Position(line=1, char_index=50),
        ),
        validator=BookSchema,
    ) == {"titles": ["{}", "{}"], "authors": ["{}", "{}"]}


# Generated at 2022-06-24 11:07:01.333396
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import StructureSchema, Text
    from typesystem.tokenize.tokenize import Tokenizer

    class PersonSchema(StructureSchema):
        name = Text()

    tokenizer = Tokenizer()
    tokens = tokenizer.tokenize(b'{"name": "Bill"}')
    validated_tokens = validate_with_positions(
        token=tokens[0], validator=PersonSchema
    )

# Generated at 2022-06-24 11:07:08.805511
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    token = Token(
        {
            "name": "Tom",
            "age": 20,
            "address": {
                "street": "Trevino Road",
                "city": "Fargo",
                "zip": 58078,
                "state": "ND",
            },
        },
        start=0,
        end=100,
    )

    field = String(required=True)

    # Valid token
    assert validate_with_positions(token=token, validator=field) == "Tom"

    # Required key not found
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=Token(value={}, start=0, end=100), validator=field
        )
    assert exc_info.value

# Generated at 2022-06-24 11:07:20.063390
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    import typesystem
    import typesystem.tokenize

    class Child(typesystem.String):
        def validate(self, value):
            value = super().validate(value)
            if not value:
                raise typesystem.ValidationError({"": "no child data, please!"})
            return value

    class ChildSchema(typesystem.Schema):
        child = Child(required=True)

    schema = typesystem.Schema(
        name=typesystem.String(),
        child_data=ChildSchema(required=True),
    )

    data = {"child_data": {"child": ""}}
    token = typesystem.tokenize.tokenize(data)


# Generated at 2022-06-24 11:07:31.961264
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    with patch.object(Person, "validate") as mock_validate:
        mock_validate.side_effect = ValidationError(
            messages=[Message(code="error-code", index=["age"], text="bad age")]
        )

        try:
            validate_with_positions(
                token=Token(value={"name": "Mark", "age": "notaninteger"}, start={}),
                validator=Person,
            )
        except ValidationError as error:
            assert error.messages[0].code == "error-code"
            assert error.messages[0].index == ["age"]
            assert error.messages[0].text == "bad age"
            assert error.mess

# Generated at 2022-06-24 11:07:43.674728
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from io import StringIO
    from typing import Any
    from typesystem.tokenize.step import tokenize
    from typesystem.tokenize.tokens import Source
    from typesystem.environments import default_environment
    from typesystem.schemas import Schema
    from typesystem.fields import Object, Field, Boolean
    from typesystem.exceptions import ValidationError

    class ExampleSchema(Schema):
        class Meta:
            environment = default_environment

        on_off = Boolean()

    schema = ExampleSchema()

    input_text = """
    {
        "on_off": true
    }
    """
    # Create the source
    source = Source(StringIO(input_text), file_path="/test.json")

    # Tokenize the source

# Generated at 2022-06-24 11:07:48.834376
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Tokenizer
    from typesystem.fields import String

    tokenizer = Tokenizer({"id": "def"})
    token = tokenizer.parse("""
        {
            "id": "def"
        }
    """)
    field = String(name="id", required=True)
    validate_with_positions(token=token, validator=field)



# Generated at 2022-06-24 11:07:56.258394
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    import isodate

    class EventSchema(Schema):
        id = Field(type="string")
        timestamp = Field(type=isodate.datetime_isoformat, required=True)
        description = Field(type="string")

    schema = EventSchema()

    tokens = Token.parse(
        """
        id: 12345
        timestamp: 2019-01-02T12:34:56Z
        description: Something happened.
    """
    )

    validate_with_positions(token=tokens, validator=schema)



# Generated at 2022-06-24 11:08:06.919236
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_with_positions
    from typesystem.tokenize.validators import TokenValidator
    from typesystem.fields import String, Integer, Array

    source = (
        "x: 5\n"
        "array:\n"
        "  - foo\n"
        "  - bar\n"
        "  - baz\n"
        "dict:\n"
        "  hello: world\n"
    )

    # Define a type for our data.
    class Dummy(Schema):
        x = Integer()
        array = Array(items=String())
        dict = {String(): String()}

    # Validate the data.
    tokens = list(tokenize_with_positions(source=source, validator=TokenValidator()))[0]
    validate_

# Generated at 2022-06-24 11:08:17.964229
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize.parser import parse

    # Verify error message points to the position of the error
    token = parse("[1, 2, x]")
    try:
        validate_with_positions(
            token=token, validator=List(contents=Integer(), min_items=3,)
        )
    except ValidationError as error:
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 10
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.char_index == 11
    else:
        assert False

    # Verify error message points to the position of the error

# Generated at 2022-06-24 11:08:28.688894
# Unit test for function validate_with_positions
def test_validate_with_positions(): # noqa
    import toml
    from typesystem.tokenize.loaders import load_toml

    schema = load_toml(
        """
        [foo]
        a = 1
        """,
        Schema(
            foo=Schema(
                a=Field(min_length=2),
                b=Field(required=True),
            )
        )
    )
    token = Token(toml.loads("""
        [[foo]]
        a = "a"
        """))


# Generated at 2022-06-24 11:08:36.456020
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse

    parsed = parse(
        """
        {
          id: 1,
          "name": "peter",
          nested: {
            "sub-field": "sub-field-value"
          }
        }
    """
    )

    class UserSchema(Schema):
        id = Field(type=int)
        name = Field(type=str)
        nested = Field(type=dict)  # we lack a schema for this dictionary

    try:
        validate_with_positions(token=parsed, validator=UserSchema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]

# Generated at 2022-06-24 11:08:48.423520
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokens import Tokenizer

    tokenizer = Tokenizer()

    class Person(Schema):
        name = Field(type="string", required=True)

    doc = "fred"
    Person.validate(doc)

    with pytest.raises(ValidationError) as exc_info:
        Person.validate("")

    error = exc_info.value.messages[0]
    assert error.code == "required"
    assert error.index == ("name",)

    with pytest.raises(ValidationError) as exc_info:
        tokenizer.tokenize("", Person)
    error = exc_info.value.messages[0]
    assert error.code == "required"
    assert error.index == ("name",)



# Generated at 2022-06-24 11:08:57.434761
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Array
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokenizers import split
    from typesystem.tokenize.tokens import DataToken, Token

    schema = Schema(fields=[Array(items=Array(items=[int]))])

    tokens = split("[[99]]", token_type=DataToken)
    tokens[0].start = 1, 1
    tokens[0].end = 1, 1
    tokens[1].start = 1, 2
    tokens[1].end = 1, 4
    tokens[2].start = 1, 5
    tokens[2].end = 1, 6
    tokens[3].start = 1, 7
    tokens[3].end = 1, 8
    tokens[4].start = 1, 9
    tokens[4].end = 1, 10


# Generated at 2022-06-24 11:09:07.535466
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import types

    class User(types.Schema):
        first_name = types.String()
        last_name = types.String()

    input = """
    [
        {
            "first_name": "Erik",
        },
        {
            "first_name": "Bob",
            "last_name": "Builder"
        }
    ]
    """

    token = Token.from_string(input)

    assert User.validate(token[0]) == {"first_name": "Erik"}
    assert User.validate(token[1]) == {"first_name": "Bob", "last_name": "Builder"}

    try:
        User.validate(token)
    except ValidationError as error:
        assert len(error.messages()) == 3
        message = error.messages()

# Generated at 2022-06-24 11:09:12.373965
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """ Unit test for function validate_with_positions """

    from typesystem.tokenize import tokenize

    from tests.test_tokenize import TEST_DATA

    from typesystem.schemas import Schema
    from typesystem.fields import Integer, String

    from typesystem.tokenize.tokens import Token, LBRACE, RBRACE

    from typesystem.exceptions import ValidationError

    from tests.test_tokenize import TEST_DATA

    schema_class = Schema.of(
        fields={
            "int": Integer(default=5),
            "str": String(default="hello"),
            "required_int": Integer(required=True),
        }
    )

    # no error
    token = tokenize(TEST_DATA["ok"])

# Generated at 2022-06-24 11:09:23.436342
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from tests.test_tokenize.test_tokens import MyToken

    class MySchema(Schema):
        name = Field(str)
        number = Field(int)

    token = MyToken('{"number": 100, "name": "", "favourite_color": "blue"}')
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=MySchema)

    messages = list(error.value.messages)
    assert messages[0].code == "required"
    assert messages[0].start_position.char_index == 9
    assert messages[0].end_position.char_index == 9

    assert messages[1].code == "invalid_type"
    assert messages[1].start

# Generated at 2022-06-24 11:09:33.049788
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        {
            "hello": {
                "number": "123",
                "list": ["hi", 1, 2],
            },
            "b": 1,
        },
        name="",
        start_position=Position(line=1, column=1, char_index=0),
        end_position=Position(line=1, column=30, char_index=29),
    )
    class MySchema(Schema):
        hello = Schema({
            "number": Field(type=int),
            "list": Field(type=list, items=Field(type=int)),
        })
        b = Field(type=int)

    value = validate_with_positions(token=token, validator=MySchema)

# Generated at 2022-06-24 11:09:42.077994
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type="integer")

    token = Token(value={"foo": 42}, start=None, end=None, path=["root"])

    value = validate_with_positions(token=token, validator=field)
    assert value == {"foo": 42}

    # missing field
    token = Token(value={}, start=None, end=None, path=["root"])
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=field)
    message = excinfo.value.messages[0]
    assert message.code == "type_error"
    assert message.text == "Expected a dictionary."

    # missing field
    field = Field(name="foo", type="integer")

# Generated at 2022-06-24 11:09:51.373711
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class SimpleField(Field):
        def __init__(self, *args, **kwargs):
            kwargs.setdefault("required", True)
            super().__init__(*args, **kwargs)

    class MySchema(Schema):
        required = SimpleField(primitive="string")
        optional = SimpleField(primitive="string")

    token = Token(value={"required": "ok", "optional": None})
    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as error:
        messages = list(error.messages())

# Generated at 2022-06-24 11:09:59.860323
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.core import parse
    from typesystem.tokenize.tokens import Token

    from .test_field import test_field as field

    from typesystem.schemas import Schema as schema

    from typesystem.fields import Field as field
    from typesystem.types import Typestring as typestring

    from typesystem.fields import Integer as integer
    from typesystem.fields import Float as float
    from typesystem.array import Array as array

    from typesystem.object import Object as object
    from typesystem.object import Required as required
    from typesystem.object import Optional as optional
