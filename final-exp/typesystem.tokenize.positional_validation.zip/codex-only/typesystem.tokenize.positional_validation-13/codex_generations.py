

# Generated at 2022-06-24 11:00:01.341327
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    validator = Schema({"a": Field(required=True),})
    token = tokenize({"b": "a"}, path="/", validator=validator)
    try:
        assert validate_with_positions(token=token, validator=validator)
        assert False, "Expected error"
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'a' is required."
        assert (
            error.messages()[0].start_position.line == 1
        ), "Expected line to be 1 (start)"
        assert (
            error.messages()[0].start_position.column == 0
        ), "Expected column to be 0 (start)"

# Generated at 2022-06-24 11:00:11.075797
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import validate
    from typesystem.tokenize import parse, tokenize

    class User(Schema):
        name = Field(type="string")
        email = Field(type="string")

    invalid_string, tokens = tokenize("{")
    errors = list(User.validate_tokens(tokens))
    assert errors  # ensure our test case is valid
    token_message = errors[0]
    assert isinstance(token_message, Message)
    assert token_message.start_position.char_index == 0
    assert token_message.end_position.char_index == 1

    try:
        validate(User(), invalid_string)
        raise AssertionError("Expected an error")
    except ValidationError as error:
        messages = error.messages()
        message = messages

# Generated at 2022-06-24 11:00:20.057863
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Array
    from typesystem.tokenize.tokens import Token

    token = Token(
        value=[{"name": "Alice"}],
        start=Token.Position(char_index=0, line_number=0, column_number=0),
        end=Token.Position(char_index=12, line_number=0, column_number=12),
    )

    def validate_name(value):
        if value != "Alice":
            raise ValidationError("Name must be Alice.")

    validator = Array({"name": validate_name})

    assert validate_with_positions(token=token, validator=validator) == [
        {"name": "Alice"}
    ]


# Generated at 2022-06-24 11:00:28.676726
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.fields import String, Float, Number
    from typesystem.schemas import Schema
    from typesystem.tokenize.base import Tokenizer

    class TestSchema(Schema):
        foo = Float()
        bar = String()

        class Meta:
            strict = True

    tokenizer = Tokenizer(TestSchema())
    token = tokenizer.tokenize('{"foo": "invalid", "bar": 1}')
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=TestSchema)
    message1 = exc_info.value.messages[0]
    assert message1.text == "'invalid' is not of type 'number'"
    assert message1.code == "type_error.number"
   

# Generated at 2022-06-24 11:00:40.178107
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema({"a": {"b": {"c": Field()}}})
    token = Token({"a": {"b": {"c": "hello"}}})

    # Valid: No error
    validate_with_positions(token=token, validator=schema)

    # Invalid: Required
    token = Token({})
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'a' is required."
        assert error.messages()[0].start_position == (1, 0)
        assert error.messages()[0].end_position == (1, 0)
        assert error.messages()[1].text == "The field 'b' is required."

# Generated at 2022-06-24 11:00:49.575000
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import io

    class TestSchema(Schema):
        name = Field(type="string", required=True)

    data = {"name": 3}

    with pytest.raises(ValidationError) as exc_info:
        with io.StringIO() as fp:
            json.dump(data, fp)
            token = Token.parse(fp.getvalue())
            validate_with_positions(token=token, validator=TestSchema)
    message = exc_info.value.messages[0]
    assert message.text == "The field 'name' is required."
    assert message.start_position == (1, 12)
    assert message.end_position == (1, 16)

# Generated at 2022-06-24 11:00:54.805200
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Token, tokens_from_string
    from typesystem.schemas import Schema
    from typesystem.fields import String

    # test for invalid token
    invalid_token_string = """
    {
        "person": {
            "first_name": "John",
            "last_name": "Smith"
        }
    }
    """

    invalid_tokens = tokens_from_string(invalid_token_string)
    invalid_token = invalid_tokens.lookup(["person", "age"])
    validator = Schema({"person": {"age": String()}})
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=invalid_token, validator=validator)
    assert excinfo.value.mess

# Generated at 2022-06-24 11:01:05.444721
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.serializers import serialize_positions

    number_field = Field(repr="A number", primitive_type=int)

    schema = Schema(
        {
            "foo": number_field,
            "bar": [number_field, number_field],
            "baz": {"a": number_field, "b": number_field},
        }
    )

    token = Token(
        {
            "foo": "abc",
            "bar": ["abc", "def"],
            "baz": {"a": "ghi", "b": "jkl"},
        },
        positions=serialize_positions(),
    )


# Generated at 2022-06-24 11:01:06.417652
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-24 11:01:16.874569
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    from .tokenize.test_load_tokens import load_tokens

    schema = Schema(
        {
            "a": {"required": True, "type": String},
            "b": {"required": True, "type": Integer},
            "c": {"required": True, "type": Integer},
            "d": {"required": True, "type": Integer},
        }
    )

    tokens = load_tokens(
        {
            "a": "foo",
            "b": 1,
            "c": 2,
            "d": 3,
        }
    )


# Generated at 2022-06-24 11:01:25.096364
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object

    class Person(Object):
        fields = {"name": {"type": "string"}}

    token = Token({"name": "Joe"}, start=0, end=5)
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        messages = list(error.messages)
        assert messages[0].start_position.char_index == 0
        assert messages[0].end_position.char_index == 5
    else:
        assert False

# Generated at 2022-06-24 11:01:33.618510
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Validator(Field):
        def validate(self, value):
            if value == "hello":
                return value
            else:
                self.error("invalid value")

    class Schema(typesystem.Schema):
        name = typesystem.String(required=True)


# Generated at 2022-06-24 11:01:42.989851
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class PersonSchema(Schema):
        name = Field(type=str)
        age = Field(type=int)

    class AddressSchema(Schema):
        street = Field(type=str)
        person = Field(type=PersonSchema)

    token = Token(
        value={
            "street": "My Street",
            "person": {"name": "Foo"},
        }
    )

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(
            token=token, validator=AddressSchema
        )

    error = excinfo.value


# Generated at 2022-06-24 11:01:51.289132
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import BundleSchema, Schema

    from typesystem.tokenize.parser import parse_file

    from ..examples import simple_bundle_schema

    token = parse_file(simple_bundle_schema, source_path="bundle.toml")

    bundle_schema = BundleSchema(schema=Schema())

    validate_with_positions(token=token, validator=bundle_schema)

# Generated at 2022-06-24 11:02:04.519178
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Author(Schema):
        name = Field(str)

    class Book(Schema):
        title = Field(str)
        tags = Field([str])
        author = Field(Author)

    class Library(Schema):
        books = Field([Book], required=True)

    data = {"books": []}
    token = Token(data, key="library", start="(", end=")")

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=Library)

    # The message's index is the key path to get to the error
    message = error.value.message

# Generated at 2022-06-24 11:02:13.983804
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token

    schema = Schema({"name": String(required=True)})
    token = Token.parse({"hello": "world"})
    validate_with_positions(token=token, validator=schema)
    token = Token.parse({})
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as e:
        assert e.messages[0].text == "The field 'name' is required."
        assert e.messages[0].start_position.char_index == 2
        assert e.messages[0].end_position.char_index == 2

# Generated at 2022-06-24 11:02:21.698288
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import FieldToken, TextToken
    from typesystem.types import String

    class Schema(Schema):
        field = String()

    token = FieldToken(
        value={
            "field": "value"
        },
        start=TextToken(start=0, end=0, text={"field": "value"}),
        end=TextToken(start=1, end=1, text={"field": "value"}),
        name="field",
        lookup=lambda: TextToken(start=0, end=0, text={"field": "value"}),
    )


# Generated at 2022-06-24 11:02:30.873817
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    from tests.utils import DummyValidator
    schema = DummyValidator(required=True)
    json_str = '{"foo": "bar"}'
    # the below trick is here to make the tokenizer not read from stdin
    # which is requried to make the integration test work
    # TODO: remove this line once an alternative tokenizer is implemented
    json_str = f"{len(json_str)}\n{json_str}"
    token = Token.from_json(json_str)
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)
    field = excinfo.value.messages()[0].index[-1]
    start = excinfo.value.messages()[0].start_position

# Generated at 2022-06-24 11:02:40.950716
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse

    schema = Schema(properties={"foo": Field(type="string")})
    content = '{"foo": "bar"}'
    token = parse(content)
    assert validate_with_positions(token=token, validator=schema) == {
        "foo": "bar"
    }

    content = '{"foo": 123}'
    token = parse(content)
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)

    messages = excinfo.value.messages()
    assert len(messages) == 1
    message = messages[0]
    assert message.text == "The value must be a string."
    assert message.data == 123

# Generated at 2022-06-24 11:02:46.747848
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import fields
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import TokenError

    source = """
    {
        "name": "test",
        "name": "test",
        "numbers": [
            1, 2, 3
        ]
    }
    """
    schema = {
        "name": fields.String(required=True),
        "numbers": fields.Array(items=fields.Number()),
    }
    tokens = tokenize(source)
    validate_with_positions(token=tokens, validator=schema)



# Generated at 2022-06-24 11:02:53.937112
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.parser import parse_value
    import datetime

    class MySchema(Schema):
        b = Field(type=datetime.date)
        x = Field(type=datetime.date)

    token = parse_value({"b": None, "a": 1})
    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as error:
        message = error.messages[0]
        assert message.text == "The field 'x' is required."
        assert message.start_position.line == 1
        assert message.start_position.char_index == 2
        assert message.end_position.line == 1
        assert message.end_position.char_index == 3


# Generated at 2022-06-24 11:03:02.400069
# Unit test for function validate_with_positions
def test_validate_with_positions():
    number_field = Field(type="number")
    token = Token(
        type=str,
        value="a",
        start=Position(line_index=1, char_index=1),
        end=Position(line_index=2, char_index=1),
    )
    try:
        validate_with_positions(token=token, validator=number_field)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        message = messages[0]
        assert message.text == "Expected a number."
        assert message.code == "type"
        assert message.index == []
        assert message.start_position == Position(line_index=1, char_index=1)

# Generated at 2022-06-24 11:03:08.561943
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize_schema
    import pytest

    class Person(Schema):
        name: str
        age: int
        friends: typing.List[str]

    tokens = tokenize_schema(Person)

    with pytest.raises(ValidationError):
        validate_with_positions(token=tokens.lookup(["friends"]), validator=Field(type=str))

    with pytest.raises(ValidationError):
        validate_with_positions(token=tokens.lookup(["age"]), validator=Person)



# Generated at 2022-06-24 11:03:16.773767
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import ValidationError
    from typesystem.fields import (
        Any,
        Array,
        Boolean,
        Dict,
        Float,
        Integer,
        Number,
        Object,
        String,
    )
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    schema = Schema(fields=(Object(),))
    token = Token(value=[], start=(1, 1), end=(2, 1))
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert len(error.messages) == 1
        assert error.messages[0].text == "The field '__root__' is required."

# Generated at 2022-06-24 11:03:21.706446
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem.positions import Position
    from typesystem.tokenize.tokens import FieldToken, ListToken, ObjectToken, ValueToken
    from typesystem.tokenize import tokenize

    token = tokenize(
        {
            "name": "Jon",
            "age": None,
            "hobbies": ["biking", 12],
            "address": {},
        }
    )

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)
        hobbies = Field(type=[str, int])
        address = Field(type=Schema)

    try:
        validate_with_positions(
            token=token, validator=Person
        )  #  should throw a ValidationError
    except ValidationError as error:
        messages = error.messages()


# Generated at 2022-06-24 11:03:32.290748
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.positions import Position
    from typesystem.tokenize import Token

    class JsonField(Field):

        def validate(self, value):
            if not isinstance(value, (int, float, str)):
                raise ValidationError(
                    [
                        Message(
                            text=f"Must be a string, number, or array.",
                            code="invalid",
                            start_position=Position(line=13),
                            end_position=Position(line=13),
                        )
                    ]
                )
            return value

    json_field = JsonField()
    token = Token(
        value="foo",
        token_type="string",
        start=Position(line=13, char_index=23),
        end=Position(line=13, char_index=27),
    )
   

# Generated at 2022-06-24 11:03:39.699488
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    import typesystem.tokenize

    class Foo(typesystem.Schema):
        baz = typesystem.Float()

    class Bar(typesystem.Schema):
        foo = Foo()

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=typesystem.tokenize.tokenize({"foo": {"baz": "abc"}}),
            validator=Bar()
        )

    messages = exc_info.value.messages
    assert len(messages) == 1
    message = messages[0]
    assert message.text == 'Value "abc" is not a valid float.'
    assert message.start_position.line_index == 0
    assert message.start_position.column_index == 12
    assert message.end_position.line_

# Generated at 2022-06-24 11:03:46.055323
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from pprint import pprint
    from typesystem.fields import String
    from typesystem.tokenize import tokenize

    token = tokenize('{"a": "b"}')
    # pprint(token)

    class Person(Schema):
        name = String()

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as e:
        print(e)  # noqa
        pprint(list(e.messages()))
        assert e.messages()[0].index == ["name"]

# Generated at 2022-06-24 11:03:57.432258
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    schema_source = """
    import typesystem

    class Person(typesystem.Schema):
        name = typesystem.String(required=True)
        age = typesystem.Integer()

    class Party(typesystem.Schema):
        people = typesystem.List(typesystem.Item(Person))
    """
    schema = tokenize(schema_source)
    errors = schema.validate().messages()
    assert not errors

    instance = {"people": [{"name": "Alice", "age": "not an integer"}]}
    errors = schema.validate(instance).messages()
    assert len(errors) == 1
    error = errors[0]
    assert error.start_position.line == 0
    assert error.end_position.line == 0
    assert error.start_

# Generated at 2022-06-24 11:04:05.945583
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # pylint: disable=import-outside-toplevel
    from typing import Optional

    from typesystem.schemas import Schema

    from typesystem.fields import Integer
    from typesystem.tokenize.tokens import Token

    class ExampleSchema(Schema):

        foo = Integer(required=True)
        bar = Integer(required=True)
        baz = Integer(required=False)

    schema = ExampleSchema()

    token = Token(
        {
            "foo": 123,
            "bar": "abc",
            "baz": None,
            "qux": 456,
        },
        start=None,
        end=None,
    )

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-24 11:04:16.114421
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokenizers import tokenize

    schema = Integer(min_value=0)

    token = tokenize("-100")[0]
    try:
        validate_with_positions(token=token, validator=schema)
        assert False
    except ValidationError as error:
        start = error.messages[0].start_position
        end = error.messages[0].end_position
        assert start.char_index == end.char_index == 0

        token = tokenize("{'a': 1}")[0]
        try:
            validate_with_positions(token=token, validator=schema)
            assert False
        except ValidationError as error:
            start = error

# Generated at 2022-06-24 11:04:22.179033
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(string)
    assert validate_with_positions(
        token=Token(value="z", start=(0, 0)), validator=field
    ) == "z"

    field = Field(string, required=True)
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=Token("", start=(0, 0)), validator=field)
    assert error.value.messages == [
        Message(
            text="The field '' is required.",
            code="required",
            index=(0,),
            start_position=(0, 0),
            end_position=(0, 0),
        )
    ]

    class TestSchema(Schema):
        a = Field(string)
        b = Field(integer, required=True)

    schema = TestSchema()

# Generated at 2022-06-24 11:04:24.947050
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.lexers import markdown_lexer, markdown_normalizer

    schema = Schema(fields={"name": Field(required=True)})

    validator = schema.bind(lexer=markdown_lexer, normalizer=markdown_normalizer)
    try:
        validator.validate("")
    except ValidationError as error:
        assert error.messages[0].start_position == (1, 1)



# Generated at 2022-06-24 11:04:33.542333
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class TestSchema(Schema):
        a = Field(required=True)
        b = Field()

    raw_json = '{"a": 1, "b": "2"}'
    token = parse_token(raw_json)

    validate_with_positions(token=token, validator=TestSchema)

    token = parse_token(raw_json, max_tokens=1)

    try:
        validate_with_positions(token=token, validator=TestSchema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        assert error.messages()[0].start_position.char_index == 14
        assert error.messages()[0].end_position.char_index == 19

# Generated at 2022-06-24 11:04:43.739728
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.schemas import Author
    from tests.tokenize import (
        first_quote,
        last_quote,
        second_quote,
        white_space,
        first_name,
    )
    from typesystem.exceptions import MissingValue

    with raises(ValidationError):
        validate_with_positions(
            token=first_name, validator=Author
        )

    with raises(ValidationError) as exc_info:
        validate_with_positions(token=first_quote, validator=Author)

    message = exc_info.value.messages[0]
    assert message.code == "required"
    assert message.index == ("first_name",)
    assert message.text == "The field 'first_name' is required."
    assert message.start_position == first_quote.start

# Generated at 2022-06-24 11:04:51.326177
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import ObjectToken
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(str)

    schema = Person()
    token = ObjectToken(
        start={
            "index": 0,
            "line": 0,
            "column": 0,
            "char_index": 0,
        },
        end=None,
        name=None,
        value={},
    )
    validate_with_positions(
        token=token, validator=schema,
    )

# Generated at 2022-06-24 11:05:00.013918
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    from typesystem.tokenize.tokens import Token

    class StringField(typesystem.String):
        def get_default(self, value, context=None):
            return "default"

    schema = typesystem.Schema(properties={"test": StringField()})

    token = Token(
        value={"test": None},
        start=(1, 1),
        end=(1, 1, 3),
        fields={"test": Token(value=None)},
    )

    with pytest.raises(typesystem.ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-24 11:05:11.035795
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from pytest import raises
    from typesystem.schema import Schema
    from typesystem.fields import String
    from typesystem.tokenize import tokenize_string

    class MySchema(Schema):
        field = String(required=True)

    token = tokenize_string("{")
    schema = MySchema()

    with raises(ValidationError) as exception:
        validate_with_positions(token=token, validator=schema)

    error = exception.value
    assert len(error.messages) == 1
    assert error.messages[0].text == "The field 'field' is required."

    assert error.messages[0].start_position.line == 1
    assert error.messages[0].start_position.char_index == 0


# Generated at 2022-06-24 11:05:20.865812
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class User(Schema):
        first_name = Field(str, max_length=20, required=True)
        last_name = Field(str, max_length=20, required=True)
        age = Field(int, required=True)

    schema = User()
    token = Token(
        {
            "first_name": "John",
            "last_name": "Doe",
            "age": "30",
        },
        start=TokenPosition(row=0, col=0, char_index=0, line_text="test"),
        end=TokenPosition(row=0, col=0, char_index=0, line_text="test"),
    )

# Generated at 2022-06-24 11:05:28.613364
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """The function should preserve the error messages from a schema validator."""
    from typesystem.tokenize.positional import PositionalToken, PositionalTokenizer

    class Person(Schema):
        name = Field(type="string", required=True)
        location = Field(type="string", required=True)

    schema = Person()

    json_string = '{"name": "John Doe"}'
    tokens = PositionalTokenizer().tokenize(json_string)
    positional_token: PositionalToken = PositionalToken.from_dict(tokens[0])

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=positional_token, validator=schema)

    messages = exc_info.value.messages
    assert len(messages) == 1

# Generated at 2022-06-24 11:05:37.159595
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import os
    import sys
    import tempfile
    import uuid
    import typesystem

    # Create a temporary file with JSON content.
    content = """
    {
        "name": "foo",
        "name": "bar",
        "topic": "foo/bar",
        "created": "2019-08-10T12:00:00.1Z"
    }
    """
    json_path = tempfile.mkstemp(suffix=".json")[1]
    with open(json_path, "wt") as f:
        f.write(content)

    class TopicSchema(typesystem.Schema):
        name = typesystem.String(min_length=3, max_length=10)
        public = typesystem.Boolean(required=False)


# Generated at 2022-06-24 11:05:44.293778
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.validators import integer

    field = integer()
    token = Token.from_python({"foo": {"bar": "12"}})
    value = validate_with_positions(token=token, validator=field)
    assert value == 12
    assert isinstance(value, int)

    token = Token.from_python({"foo": {"bar": "abc"}})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)

    messages = exc_info.value.messages()
    assert len(messages) == 1
    assert messages[0].start_position.line == 1
    assert messages[0].start_position.char_index == 13
    assert messages[0].end_position.line == 1

# Generated at 2022-06-24 11:05:55.032217
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import Tokenizer
    from typesystem.tokenize.types import TokenType, TokenizeError

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    def validate(schema: typing.Type[Schema], text: str) -> None:
        tokenizer = Tokenizer()
        token = tokenizer.tokenize(text)
        validate_with_positions(token=token, validator=schema)

    # valid data
    validate(Person, '{"name":"Jane","age":30}')

    # invalid data
    with pytest.raises(TokenizeError) as exc_info:
        validate(Person, '{"name":30}')

    # Check validation error contains positional information
    error = exc_info.value
    assert len

# Generated at 2022-06-24 11:06:02.951287
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.json import decode

    class User(Schema):
        name = Field(type=str)

    token = decode("{}")
    try:
        validate_with_positions(token=token, validator=User)
    except ValidationError as exception:
        assert exception.messages()
        assert exception.messages()[0].start_position.line == 1
        assert exception.messages()[0].start_position.col == 1
        assert exception.messages()[0].end_position.line == 1
        assert exception.messages()[0].end_position.col == 0
    else:
        assert False, "Expected error"


# Generated at 2022-06-24 11:06:11.911047
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    token = Token(
        type="object",
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 2, "char_index": 10},
        value={},
    )

    string_field = String(name="name")

    try:
        validate_with_positions(token=token, validator=string_field)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'name' is required.",
                code="required",
                index=["name"],
                start_position=token.start,
                end_position=token.end,
            )
        ]



# Generated at 2022-06-24 11:06:21.057139
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    tokens = tokenize("{name: 'alice', age: 33 }")
    token = tokens[0][0]
    validate_with_positions(token=token, validator=Person)

    tokens = tokenize("{name: 'alice'}")
    token = tokens[0][0]
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as e:
        message = e.messages()[0]
        assert message.start_position.line == 1
        assert message.start_position.char_index == 11

    tokens = tokenize("{name: 'alice', age: '33'}")
   

# Generated at 2022-06-24 11:06:31.053455
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import type_cast
    from typesystem.fields import Integer
    from typesystem.tokenize.tokenizers import tokenize

    token = tokenize(
        {"foo": {"bar": {"bazi": "abc"}}},
        path=["foo", "bar", "bazi"],
        base_path=["foo", "bar"],
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Integer())
    message = exc_info.value.messages[0]
    assert message.start_position.line == 1
    assert message.start_position.char_index == 16
    assert message.end_position.line == 1
    assert message.end_position.char_index == 19

# Generated at 2022-06-24 11:06:38.802259
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import types, error_messages

    class Person(Schema):
        name = types.String()
        age = types.Integer()

    token_text = '{"name": "", "age": 27}'
    root_token = Token.create_from_string(token_text)

    token_name_start = root_token.children[0].children[1].children[1]
    token_name_end = root_token.children[0].children[1].children[1]
    token_age_start = root_token.children[0].children[2].children[1]
    token_age_end = root_token.children[0].children[2].children[1]


# Generated at 2022-06-24 11:06:48.849180
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.exceptions import ValidationError
    from typesystem.tokenize.parser import Tokens, tokenize
    from typesystem.fields import Boolean, Number, Object, String

    class Person(Object):
        name = String(max_length=10)
        age = Number()
        gender = String(max_length=10)
        email = String(max_length=50)
        active = Boolean()
        type = String(max_length=30)

    try:
        validate_with_positions(
            token=tokenize(Tokens.parse('{"name": "Ana", "type": "humanoid"}')),
            validator=Person,
        )
    except ValidationError as error:
        assert len(error.messages()) == 2

# Generated at 2022-06-24 11:06:55.947090
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    from typesystem.schemas import Schema
    from typesystem.fields import *
    from typesystem.tokenize.tokens import *
    from typesystem.base import Message

    class MySchema(Schema):
        first_name = String(required=True)
        last_name = String(required=True)
        age = Integer()

    token = ObjectToken(
        start=Position(line=1, char_index=0),
        end=Position(line=1, char_index=80),
        value={
            "first_name": "John",
            "age": 22,
        },
    )


# Generated at 2022-06-24 11:07:06.192567
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize import parse, tokenize

    class UserSchema(Schema):
        name = Field(str, max_length=250, required=True)

    def run_test(source: str, expected_error: str) -> None:
        tokens = list(tokenize(source))
        with pytest.raises(ValidationError) as exception_info:
            validate_with_positions(
                token=parse(tokens), validator=UserSchema()  # type: ignore
            )
        error = exception_info.value.messages
        assert len(error) == 1
        message = error[0]
        assert message.text == expected_error
        assert message.code == "required"


# Generated at 2022-06-24 11:07:17.457863
# Unit test for function validate_with_positions
def test_validate_with_positions(): # noqa
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token
    from typesystem.validators import Length
    from typesystem.errors import ValidationError

    class Book(Schema):
        title = String()
        author = String(validators=[Length(min=2)])

    token = Token.parse(
        "{'title': 'A Clockwork Orange', 'author': 1}",
        start={"line_number": 1, "char_index": 1},
    )

# Generated at 2022-06-24 11:07:25.764875
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typing import List

    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    class MySchema(Schema):
        name = String(required=True)
        email = String(required=True)

    data = {"name": "Alice", "email": "alice@email.com"}
    json = '{"name": "Alice", "email": "alice@email.com"}'
    token = Token.from_json(json)
    token = token.lookup(["root"])
    valid = validate_with_positions(token=token, validator=MySchema)

    assert valid == data
    assert valid == MySchema(data=data)

    token = token.lookup(["root"])

# Generated at 2022-06-24 11:07:34.565845
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import ValidationError
    from typesystem.fields import Integer
    from typesystem.tokenize.tokens import NumberToken

    token = NumberToken(value=1, start=(1, 0), end=(1, 1))
    try:
        validate_with_positions(
            token=token, validator=Integer(min_value=5, max_value=10)
        )
    except ValidationError as error:
        message, = error.messages()
        assert message.text == "Must be between 5 and 10."
        assert message.start_position == (1, 0)
        assert message.end_position == (1, 1)

    token = NumberToken(value=1, start=(1, 0), end=(1, 1))

# Generated at 2022-06-24 11:07:44.518017
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse
    from typesystem.fields import String

    test_schema = Schema(
        {"name": String(required=True), "age": String(required=True)}
    )
    # The input text below is intentionally wrong
    input_text = "name: 'John'\nage: 'Unkown'\n"
    token = parse(input_text)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=test_schema)
    messages = exc_info.value.messages()
    assert len(messages) == 2
    assert messages[0].text == "The field 'name' is required."
    assert messages[0].start_position.line_index == 1

# Generated at 2022-06-24 11:07:54.625940
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object, String
    from typesystem.tokenize.lexers import Lexer
    from typesystem.tokenize.tokens import RootToken, Token
    
    class Person(Schema):
        name = String()
    
    input = "{ name: 1 }"
    schema = Object(properties={"person": Person()})
    lexer = Lexer(input)
    root_token = RootToken(lexer)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=root_token, validator=schema)
        
    token = exc_info.value.messages[0].start_position.token
    assert token.lexeme == "1"
    assert isinstance(token, Token)

# Generated at 2022-06-24 11:08:05.804554
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import parse_string

    class Settings(Schema):
        name = Field(str, required=True)
        age = Field(int, required=True)
        children = Field(int)

    token = parse_string("name='John Doe', age=42, children=null")

    # Check that a missing required field results in a message with the correct
    # start and end positions
    try:
        validate_with_positions(token=token, validator=Settings)
        assert False
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        assert messages[0].start_position.line_number == 1
        assert messages[0].start_position.char_index == 0
        assert messages[0].end_position.line_number == 1
       

# Generated at 2022-06-24 11:08:16.908770
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import sys

    import pytest
    from typesystem.fields import Float
    from typesystem.schemas import Schema

    from typesystem.tokenize.tokens import Token, ValueToken

    if "win" in sys.platform and sys.version_info[:2] < (3, 8):
        pytest.skip("positions")

    class Point(Schema):
        x = Float(required=True)
        y = Float(required=True)

    token = Token(type="map", value={})

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=Point)


# Generated at 2022-06-24 11:08:20.962781
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    person = {
        "name": "Person",
        "age": 12,
    }

    token = Token(value=person)
    validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-24 11:08:28.765579
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        start=Position(line_number=1, line_index=0, char_index=0, line="abc"),
        end=Position(line_number=1, line_index=0, char_index=3, line="abc"),
        value="abc",
    )

    class TextField(Field):
        def validate(self, value):
            if len(value) > 2:
                raise ValidationError({"max_length": "Too long!"})
            else:
                return value

    field = TextField()
    field.validate_with_positions = validate_with_positions

    assert field.validate(token) == "abc"


# Generated at 2022-06-24 11:08:29.695499
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-24 11:08:37.181386
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class BookType(Schema):
        title = Field(string_types)

    class BookSchema(Schema):
        book = BookType.as_field()

    lexer = lexers.JsonLexer()
    token = lexer.parse("{}")
    try:
        validate_with_positions(token=token, validator=BookSchema)
    except ValidationError as error:
        message = error.messages[0]
        assert message.start_position.line_number == 1
        assert message.start_position.char_index == 2
        assert message.end_position.line_number == 1
        assert message.end_position.char_index == 4
    else:
        assert False

# Generated at 2022-06-24 11:08:42.505364
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse_string
    from typesystem.fields import Boolean

    token = parse_string("{\"a\": 3}")
    assert validate_with_positions(token=token, validator=Boolean)

# Generated at 2022-06-24 11:08:51.686170
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize

    class MySchema(Schema):
        name = Field(str, min_length=1)
        age = Field(int, min_value=0)

    token = tokenize({"name": "", "age": -1})

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=MySchema)
    msg = exc_info.value.messages()
    assert msg[0].text == "The field 'name' is required."
    assert msg[1].text == "Ensure this value is greater than or equal to 0."

# Generated at 2022-06-24 11:09:02.683494
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = String()
        age = String()

    # Test regular string
    token = tokenize("{")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert len(exc_info.value.messages()) == 1
    assert exc_info.value.messages()[0].start_position.char_index == 0
    assert exc_info.value.messages()[0].end_position.char_index == 1

    # Test embedded string

# Generated at 2022-06-24 11:09:11.653063
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    from typesystem.tokenize.tokens import Token, TokenType, TokenPos

    class AddressSchema(Schema):
        country = Field(type=str, required=False)
        city = Field(type=str, required=True)

    class CompanySchema(Schema):
        name = Field(type=str, required=True)
        address = Field(type=AddressSchema, required=True)

    company = json.loads('{"name": "Mozilla", "address": {"country": "USA"}}')


# Generated at 2022-06-24 11:09:17.422206
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import TokenTreeParser, Position

    field = Field(type="integer")
    message_text = "Value is not a valid integer."

    lexer = TokenTreeParser()
    token = lexer.tokenize("""{
        "a": 1,
        "b": "hello"
    }""")
    assert validate_with_positions(token=token, validator=field) == 1
    assert token.children[1].tokens[1].children[1].value == 1

    token = lexer.tokenize("""{
        "a": [null, 2],
        "b": "hello"
    }""")
    token.children[1].tokens[1].children[1].children[0].value = None

# Generated at 2022-06-24 11:09:28.275960
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.core import Tokenizer
    from typesystem.tokenize import tokens
    from typesystem.fields import String

    tokenizer = Tokenizer()
    token = tokenizer.tokenize("foo = 'bar'")
    assert isinstance(token, tokens.Object)

    # String
    assert validate_with_positions(token=token.properties[0], validator=String()) == "bar"

    # Validation error
    validator = String(min_length=4)
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token.properties[0], validator=validator)

    field_message = error.value.messages[0]
    assert field_message.text == '"bar" is too short.'

# Generated at 2022-06-24 11:09:35.861207
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.lexers import Lexer
    from typesystem.tokenize.positions import Position, PositionMap

    class Args(Schema):
        a = Field(int)
        b = Field(str)

    position_map = PositionMap(
        start=Position(line=0, column=0, char_index=0),
        end=Position(line=1, column=5, char_index=5),
    )
    lexer = Lexer.from_text(text="-a1 -bfoo", position_map=position_map)
    tokens = lexer.lex()
    assert len(tokens) == 2

    token = tokens[0]
    assert token.name == "a"
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions

# Generated at 2022-06-24 11:09:46.829518
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokenizer import Tokenizer
    from typesystem import ValidationError

    data = {"foo": "bar"}
    tokenizer = Tokenizer(data=data)
    token = tokenizer.parse()

    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=Integer(required=True))

    # 'foo' should be a required field.
    err = validate_with_positions.__wrapped__.__code__
    print(inspect.getsourcelines(err)[0])

    # Now that we can see that the value of the field is passed to validate, we
    # should be able to see our positional error messages.
    # 1. return an error.
   

# Generated at 2022-06-24 11:09:56.149825
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    # This one should work.
    person = Person({"name": "Fred", "age": 42})
    print(person.validate())

    # This one won't, but it should have the correct locations of the messages.
    try:
        token = tokenize('{"name": "Fred"}')
        Person.validate(token)
    except ValidationError as error:
        for message in error.messages():
            print(message, message.start_position.line, message.start_position.column)


if __name__ == "__main__":
    test_validate_with_positions()