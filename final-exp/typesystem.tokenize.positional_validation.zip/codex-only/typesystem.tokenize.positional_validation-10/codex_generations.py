

# Generated at 2022-06-24 11:00:03.774044
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = String()
        age = Integer(min_value=0, max_value=100)

    text = """
    name: Max
    age: 200
    """

    tokens = tokenize(text)
    validated = validate_with_positions(
        # FIXME: this is wrong, a Schema should not be a validator
        validator=Person,
        token=tokens.lookup([]),
    )
    assert validated == {
        "name": "Max",
        "age": 200,
    }


# Generated at 2022-06-24 11:00:12.569740
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import Integer
    from typesystem.tokenize.parser import parse_document

    tokens = parse_document("""
        type Query {
            node(id: "A") {
                id: ID!
            }
        }
    """)

# Generated at 2022-06-24 11:00:21.377310
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.utils import tokenize

    schema = Schema({"foo": str, "bar": str})
    token = tokenize(schema, {"foo": None, "bar": None})

# Generated at 2022-06-24 11:00:26.861158
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, CharPosition

    class TestSchema(Schema):
        name = Field(str)

    token = Token(
        value={},
        start=CharPosition(0, 0),
        end=CharPosition(1, 1),
        lookup=lambda *args: token,
    )

    try:
        validate_with_positions(token=token, validator=TestSchema)
    except ValidationError as error:
        assert error.messages()[0].start_position == token.start
        assert error.messages()[0].end_position == token.end
    else:
        raise AssertionError("Expected a ValidationError to be raised")



# Generated at 2022-06-24 11:00:39.097402
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import JSONSchema
    from typesystem.tokenize import tokenize
    from typesystem.types import String
    from typesystem.utils import PrettyJsonSchema

    schema = {"type": "string"}
    validator = JSONSchema(schema)
    token = tokenize('{"test": "string value"}')
    validate_with_positions(token=token, validator=validator)

    schema = {"type": "string"}
    token = tokenize('{"test": 123}')
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=validator)

    schema = {"type": "string"}
    validator = JSONSchema(schema)
    token = tokenize("string value")

# Generated at 2022-06-24 11:00:49.662993
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Schema(typesystem.Schema):
        name = typesystem.String(max_length=10)


# Generated at 2022-06-24 11:00:54.853222
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import Field
    from typesystem.tokenize.parse import parse
    from typesystem.tokenize.tokens import Token

    class UserSchema(Schema):
        name = Field(required=True)
        age = Field(type="integer")

    def test_schema():
        return UserSchema()

    def test_field(key, **kwargs):
        return UserSchema().fields.get(key, **kwargs)

    # validate_with_positions accepts Token and Field or Schema
    validate_with_positions(token=Token(""), validator=test_schema())

    def test_function(token, validator):
        validate_with_positions(token=token, validator=validator)

    # Assert the function raises Val

# Generated at 2022-06-24 11:01:05.490574
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    import typesystem_text
    from typesystem.tokenize.tokens import PositionalToken
    # test value 
    text = "true"
    # test validator
    validator = typesystem_text.Boolean()
    # test token
    token = PositionalToken(value={"value": text})
    # call function
    with pytest.raises(typesystem.ValidationError) as exc:
        validate_with_positions(token=token, validator=validator)
    assert exc.value.messages[0].start_position.char_index == 0
    assert exc.value.messages[0].end_position.char_index == 3
    
    
    
    
    
from typing import Text
from typesystem.tokenize.scanner import Scanner



# Generated at 2022-06-24 11:01:16.196804
# Unit test for function validate_with_positions
def test_validate_with_positions():
    t = Token(
        {
            "a": Token(1),
            "b": Token(
                {
                    "c": Token(None),
                    "d": Token(None),
                }
            ),
        }
    )
    class SubSchema(Schema):
        a = Field(type=int)
        b = Field(type=SubSchema)

    schema = SubSchema(required=["a", "b"])
    try:
        validate_with_positions(token=t, validator=schema)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'c' is required."
        assert error.messages()[0].code == "required"
        assert error.messages()[1].text == "The field 'd' is required."

# Generated at 2022-06-24 11:01:27.064552
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.json_schema import JSONSchema

    schema = JSONSchema(properties={
        'name': {
            'type': 'string'
        },
        'age': {
            'type': 'integer'
        },
    }, required=['hello'])

    token = Token.from_json_string('{"name": "Alex", "food": "pizza"}')
    assert token.value == {'name': 'Alex', 'food': 'pizza'}

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        for message in error.messages:
            print(message.text)
            assert message.start_position.char_index < message.end_position.char_index

# Generated at 2022-06-24 11:01:34.951733
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.api import tokenize
    from typesystem.tokenize.token_types import ObjectToken, StringToken
    from typesystem import fields
    from typesystem.exceptions import ValidationError

    class BasicSchema(Schema):
        name = fields.String()

    tokens = tokenize({"name": 123})
    token = tokens[0]
    error = None
    try:
        validate_with_positions(token=token, validator=BasicSchema)
    except ValidationError as e:
        error = e
    assert isinstance(error.messages[0], Message)
    assert error.messages[0].start_position == token.children[0].children[0].start
    assert error.messages[0].end_position == token.children[0].children[0].end

# Generated at 2022-06-24 11:01:44.375201
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse_string
    from typesystem.schemas import JSONSchema
    from typesystem import fields
    from typesystem import errors

    schema = JSONSchema(
        {
            "type": "object",
            "properties": {
                "title": {"type": "string", "minLength": 10},
                "layout": {"type": "string", "minLength": 2},
                "body": {"type": "string", "minLength": 50},
                "published": {"type": "boolean"},
            },
            "required": ["title", "body", "published"],
        }
    )

    token = parse_string(
        {
            "title": "This is the title",
            "published": True,
        }
    )


# Generated at 2022-06-24 11:01:54.750812
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import ValidationError
    from typesystem.tokenize.base import _FilePosition
    from typesystem.tokenize.tokens import Object

    object_ = Object([])
    position = _FilePosition(line=1, column=0, char_index=0)
    object_.start = position
    object_.end = position
    object_.value = []

    try:
        validate_with_positions(token=object_, validator=object_)
    except ValidationError as error:
        assert (
            str(error) == "Expected an object, got []."
        ), "Expected to raise an error when validating objects with wrong token"
        assert (
            error.messages()[0].start_position == position
        ), "Expected start position to be set on error message"

# Generated at 2022-06-24 11:02:05.750856
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.simple import Tokenizer
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    class UserSchema(Schema):
        name = String(required=True)
        email = String()

    tokenizer = Tokenizer()
    token = tokenizer.tokenize(
        {
            "name": "",
            "email": "foobar",
        }
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=UserSchema)

    assert len(exc_info.value.messages) == 1
    assert exc_info.value.messages[0].text == "The field 'name' is required."



# Generated at 2022-06-24 11:02:09.412051
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_file

    class Query(Schema):
        name = Field(str)

    query = Query(name="Julia")
    assert validate_with_positions(
        token=tokenize_file("<string>", "query { name }")[0], validator=query
    )

# Generated at 2022-06-24 11:02:14.988195
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import Parser

    from .test_tokenize import tokenize_test_schema

    parser = Parser(schema=tokenize_test_schema)
    token = parser.parse('{"a": 1, "b": 2}')
    validate_with_positions(token=token, validator=tokenize_test_schema)

# Generated at 2022-06-24 11:02:24.479998
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(str)
        age = Field(int)

    import typesystem
    with typesystem.testing.capture_errors() as errors:
        validate_with_positions(
            token=typesystem.tokenize.parse(dict(name="John", age="fifteen")),
            validator=Person,
        )
        errors[0].text == '"fifteen" must be an int.'
        assert errors[0].start_position.char_index == 11
        assert errors[0].end_position.char_index == 18

# Generated at 2022-06-24 11:02:31.431285
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Structure

    class User(Structure):
        id = Field(type=int)
        name = Field(type=str, required=True)
        is_active = Field(type=bool)

    schema = User()
    try:
        schema.validate({"id": "foo", "is_active": False})
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'name' is required.",
                code="required",
                index=("name",),
            ),
            Message(
                text="Expected int but got 'foo'.",
                code="invalid",
                index=("id",),
            ),
        ]


# Generated at 2022-06-24 11:02:41.352446
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer, Array
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token, StringToken

    class Foo(Schema):
        name = String(min_length=2)
        age = Integer(minimum=1)
        items = Array(items=Integer())

    token = StringToken(value='{"name": "Joe", "items": ["a"]}')
    token = token.lookup(["items", 0])

    try:
        validate_with_positions(token=token, validator=Foo.fields["items"].items)
    except ValidationError as error:
        assert len(error.messages()) == 2
        assert error.messages()[0].start_position.char_index == 20

# Generated at 2022-06-24 11:02:48.827255
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .example_schemas import ExampleSchema
    from .tokenize import Token

    token: Token = {
        "header": "Example",
        "items": [
            {"name": {"first": "John", "last": "Doe"}},
            {"name": {"last": "Doe"}},
            {"name": ""},
            {"name": None},
            {},
        ],
    }

    # No error
    assert validate_with_positions(token=token, validator=ExampleSchema) == token

    # Header missing
    error = validate_with_positions(
        token={**token, "header": None}, validator=ExampleSchema
    )

# Generated at 2022-06-24 11:02:55.419484
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import RootToken
    from typesystem.exceptions import ValidationError
    from typesystem.fields import Integer, String

    class Person(Schema):
        name = String()
        age = Integer()

    token = RootToken(
        {
            "name": "John Doe",
            "age": "invalid",
        },
        start=Token.Position(line=1, column=1, line_index=0, char_index=0),
    )

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-24 11:03:03.686145
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_json

    token = tokenize_json("""{
        "a": "b"
    }""")
    schema = Schema(fields={"a": Field(required=True), "b": Field(required=True)})
    try:
        validate_with_positions(token=token[0], validator=schema)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        assert messages[0].code == "required"
        assert messages[0].text == "The field 'b' is required."
        assert messages[0].index == ("b",)
        assert messages[0].start_position == (22, 23)
        assert messages[0].end_position == (22, 23)



# Generated at 2022-06-24 11:03:12.548961
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.positions import Position

    def assert_range(token, start_line, end_line):
        assert token.start.line_index == start_line
        assert token.end.line_index == end_line

    assert_range(
        validate_with_positions(
            token=Token(value=1, start=Position(line_index=1), end=Position(line_index=2)),
            validator=Field(type="string"),
        ),
        start_line=1,
        end_line=2,
    )


# Generated at 2022-06-24 11:03:19.837300
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.simple import tokenize

    class Person(Schema):
        name = Field(required=True)
        age = Field(type="integer", required=True)

    json = """{"name": "Alice", "age": "twenty"}"""
    tokens = tokenize(json)
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=tokens, validator=Person)

    errors = error.value.messages()
    assert len(errors) == 1
    assert errors[0].text == "Must be an integer."
    assert errors[0].start_position.line == 1
    assert errors[0].start_position.char_index == 19
    assert errors[0].end_position.line == 1
    assert errors[0].end_position.char

# Generated at 2022-06-24 11:03:25.234726
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Dict, String

    schema = Dict({"name": String(required=True)})

    token = Token(value={"n": "joe"}, start=(1, 0), end=(1, 10))

    # Error from 'required'
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=schema)
    assert error.value.messages()[0].text == "The field 'name' is required."
    assert error.value.messages()[0].start_position.line_number == 1
    assert error.value.messages()[0].start_position.char_index == 0
    assert error.value.messages()[0].end_position.line_number == 1
    assert error.value.messages

# Generated at 2022-06-24 11:03:36.642696
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize import Tokenizer


# Generated at 2022-06-24 11:03:41.034574
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class RootSchema(Schema):
        my_field = Field(required=True, types=int)

    root = RootSchema()
    token = Token({"my_field": "foo"})
    assert validate_with_positions(token=token, validator=root) is None



# Generated at 2022-06-24 11:03:50.049909
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from json import loads

    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize

    JsonSchema = Schema.of_fields({"name": String()})

    obj = {
        "schema": {"name": "test"},
        "json": '{"name": "test"}',
    }
    obj_with_error = {
        "schema": {"name": "test"},
        "json": "{}",
    }
    token = tokenize(obj["json"])
    JsonSchema.validate(token.value)

    token = tokenize(obj_with_error["json"])

# Generated at 2022-06-24 11:03:59.263403
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.contrib.tokenize.test_tokenize import (
        M,
        R,
        S,
        T,
        token_tree,
    )
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        name = String(
            max_length=2,
            error_messages={"max_length": "Foo {max_length} {value!r}"},
        )

    token = token_tree(
        [
            T("{"),
            M("name", [S("John")]),
            T("}"),
            R(","),
            S("John"),
        ]
    )

# Generated at 2022-06-24 11:04:09.462518
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem import String, Integer
    from typesystem.tokenize.parser import Parser
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = String()
        age = Integer(minimum=18)

    class PersonList(Schema):
        people = Person.list()

    parser = Parser()
    example = """
    people:
      name: Alice
      age: 33
      name: Bob
      age: 22
      name: Carl
      age: 17
    """
    token = parser.parse(example)
    with pytest.raises(ValidationError) as error:
        PersonList.validate(token.value)

# Generated at 2022-06-24 11:04:15.420868
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object, String

    field = String(name="test")
    token = Token(value={"test": "hi"}, start=[0, 0], end=[0, 0])
    validation = validate_with_positions(token=token, validator=field)
    assert validation == "hi"

    class TestObject(Object):
        test = String()

    token = Token(value={"test": "hi"}, start=[0, 0], end=[0, 0])
    validation = validate_with_positions(token=token, validator=TestObject)
    assert validation == {"test": "hi"}

# Generated at 2022-06-24 11:04:22.674912
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parse import parse
    from typesystem.tokenize.tokens import PrimitiveToken, Token
    from typesystem.fields import String, Array

    class TestSchema(Schema):
        fields = [String, String(), String()]

    token = Token(
        value=["foo", "bar", "baz"],
        primitive=PrimitiveToken(value=["foo", "bar", "baz", "qux"]),
    )
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=TestSchema)

    messages = error.value.messages
    assert [message.index for message in messages] == [[3]]
    assert [message.start_position.line_index for message in messages] == [1]

# Generated at 2022-06-24 11:04:32.555814
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem
    import typesystem.tokenize
    import typesystem.validators

    schema = typesystem.Schema.from_dict(
        {
            "a": {"type": "number", "optional": True},
            "b": {"type": "number", "optional": False},
            "c": {"type": "number", "optional": False},
        }
    )

    bad = """
        [
            {
                "b": "b",
                "c": "c"
            },
            {
                "a": 1
            },
            {
                "a": 1,
                "b": 2
            }
        ]
    """
    tokens = typesystem.tokenize.tokenize(bad)

# Generated at 2022-06-24 11:04:38.899564
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.primitives import String
    from typesystem.tokenize.tokenizer import tokenize

    schema = ["" + "" for _ in range(100)]
    schema[30] = "hello"

    token = tokenize(schema)
    try:
        validate_with_positions(token=token, validator=String(max_length=5))
    except ValidationError as error:
        message = error.messages()[0]
        assert message.start_position == Position(0, 30, 30)
        assert message.end_position == Position(0, 35, 35)
        assert message.text == "String value is too long."
    else:
        raise AssertionError("String value is too long.")



# Generated at 2022-06-24 11:04:47.023187
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import Tokenizer
    from typesystem.tokenize.json import JSONTokenizer

    import json
    import typesystem

    class UserSchema(typesystem.Schema):
        username = typesystem.String()
        password = typesystem.String()

    tokenizer = JSONTokenizer()
    tokens = tokenizer.tokenize(UserSchema, json.loads('{"username": null}'))
    assert tokens[0].start.line_number == 1
    assert tokens[0].start.char_index == 0
    assert tokens[0].end.char_index == 1
    assert tokens[0].end.line_number == 1
    assert tokens[1].value == "username"
    assert tokens[1].start.char_index == 2
    assert tokens[1].end.char_index == 10

# Generated at 2022-06-24 11:04:56.054303
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from collections import OrderedDict
    from typesystem.fields import Any, Array, Boolean, DateTime, Integer, String
    from typesystem.schemas import Schema

    schema = Schema(
        name="InventoryItem",
        fields=OrderedDict(
            [
                ("part_number", Integer()),
                ("description", String(max_length=10)),
                ("completed", Boolean()),
                ("created_at", DateTime(format="%Y-%m-%d %H:%M:%S %z")),
                ("tags", Array(items=String(max_length=8))),
            ]
        ),
    )


# Generated at 2022-06-24 11:05:05.873187
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    import pytest
    import json
    import io
    from typesystem.tokenize.tokenizer import make_tokenizer

    field = typesystem.String(min_length=2)
    schema = typesystem.Schema({"field1": field})
    text = '{"field1": "ok"}'

    tokenizer = make_tokenizer(io.StringIO(text))
    token = tokenizer.next_token()

    assert validate_with_positions(token=token, validator=schema) == {
        "field1": "ok"
    }

    text = '{"field1": ""}'

    tokenizer = make_tokenizer(io.StringIO(text))
    token = tokenizer.next_token()


# Generated at 2022-06-24 11:05:14.253485
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, Schema, String, ValidationError

    class BookSchema(Schema):
        title = String(required=True)
        pages = Integer(minimum=100)

    token = Token(
        value={
            "title": "The Python Language",
            "pages": "foobar",
            "year": 1999,
        }
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=BookSchema)

    messages = exc_info.value.messages()
    assert len(messages) == 2
    assert messages[0].code == "invalid"
    assert messages[1].code == "required"
    assert messages[1].index == ("year",)


# Generated at 2022-06-24 11:05:20.501892
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.parser import parse_text
    from typesystem.tokenize.tokens import ParserToken

    class Structure(Schema):
        field = String(required=True)

    token = ParserToken(value={}, start=None, end=None)
    errors = validate_with_positions(token=token, validator=Structure)
    # assert errors

# Generated at 2022-06-24 11:05:28.544943
# Unit test for function validate_with_positions
def test_validate_with_positions():
    def test_message(message, expected_text, expected_index, expected_start, expected_end):
        assert message.text == expected_text
        assert message.index == expected_index
        assert message.start_position.to_tuple() == expected_start
        assert message.end_position.to_tuple() == expected_end

    class Person(Schema):
        name = Field(str, required=True)
        city = Field(str, required=True)
        age = Field(int)

    class Exit(Schema):
        age = Field(int)

    with pytest.raises(ValidationError) as error:
        validate_with_positions(
            token=tokenize("{name: 'alice', city: 'london', age: 'twenty'}"),
            validator=Person,
        )

# Generated at 2022-06-24 11:05:37.082107
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize import make_token

    token = make_token(value={"name": "Bob", "name2": "Bob"}, path="<path>")
    validator = Schema({"name": String(required=True), "name2": String(required=True)})

    # Should not raise an error
    validate_with_positions(token=token, validator=validator)

    # Should raise an error
    with pytest.raises(ValidationError) as error:
        token = make_token(value={"name": None, "name2": "Bob"}, path="<path>")
        validate_with_positions(token=token, validator=validator)


# Generated at 2022-06-24 11:05:44.242075
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import TokenParser

    parser = TokenParser()
    token = parser.parse(
        """
    {
        "name": "jane doe",
        "age": "15"
    }
    """
    )
    schema = Schema({"name": Field(), "age": Field(type="integer")})

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    messages = exc_info.value.messages
    assert len(messages) == 1
    message = messages[0]
    assert message.code == "type"
    assert message.start_position.line == 5
    assert message.start_position.column == 11
    assert message.end_position.line == 5

# Generated at 2022-06-24 11:05:54.995457
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Structure, String

    def test_fixture(
        *, data: dict, validator: typing.Type[Schema], error_messages: typing.List[str]
    ) -> None:
        import json

        schema = validator()
        token = Token(value=data, start={"line_index": 0, "char_index": 1})

# Generated at 2022-06-24 11:06:03.741945
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json

    from typesystem.schemas import Object
    from typesystem.fields import String

    schema = Object(properties={"foo": String()})

    test_cases = [
        # Empty
        ({"foo": ""}, '{ "foo": "" }'),
        # Missing field
        ({}, '{ }'),
        # Extra field
        ({"foo": "", "bar": ""}, '{ "foo": "", "bar": "" }'),
    ]

    for value, json_string in test_cases:
        token = Token(value=value)
        try:
            validate_with_positions(token=token, validator=schema)
        except ValidationError as e:
            errors = e.messages()
            assert len(errors) == 1
            if errors[0].code == "required":
                field

# Generated at 2022-06-24 11:06:09.319513
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import string, number, array
    from typesystem.tokenize.tokens import Token

    field = string(max_length=3, min_length=2)
    number_field = number()

    schema = array(items=field, min_length=1)
    schema.fields[0].min_length = 2


# Generated at 2022-06-24 11:06:18.871727
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        value={"val1": 1, "val2": 2, "val3": 3},
        start=TokenPosition(line=1, column=1, char_index=0),
        end=TokenPosition(line=1, column=20, char_index=19),
    )
    field = Field.from_schemas(fields={"val1": int})

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)

    assert len(exc_info.traceback) == 1

# Generated at 2022-06-24 11:06:28.204801
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(
        name="required",
        validators={"required": None},
        components=[
            {"name": "nested", "validators": {"required": None}},
            {"name": "nested_2", "validators": {"required": None}},
        ],
    )
    token = Token(
        [
            Token(
                name="required",
                start_position=LinePosition(1, 0),
                end_position=LinePosition(1, 8),
            ),
            Token(
                name="nested",
                start_position=LinePosition(1, 8),
                end_position=LinePosition(1, 16),
            ),
        ],
        start_position=LinePosition(1, 0),
        end_position=LinePosition(1, 16),
    )

# Generated at 2022-06-24 11:06:34.438927
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class ErrorSchema(Schema):
        foo = Field(type="integer")

    text = '{"foo": "bar"}'
    token = Token.from_json(json.loads(text))
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=ErrorSchema)

    message = exc_info.value.messages()[0]
    assert message.start_position == Position(char_index=9)
    assert message.end_position == Position(char_index=12)



# Generated at 2022-06-24 11:06:45.705570
# Unit test for function validate_with_positions
def test_validate_with_positions():

    with pytest.raises(
        ValidationError, match=r"The field 'name' is required\."
    ) as excinfo:
        validate_with_positions(
            token=Token(
                value={"age": 323},
                start=Position(line_index=0, char_index=0),
                end=Position(line_index=0, char_index=10),
            ),
            validator=Schema({"name": Field(required=True)}),
        )
    excinfo.match(re.escape(r"The field 'name' is required."))
    assert [message.start_position.line_index for message in excinfo.value.messages] == [
        0
    ]

# Generated at 2022-06-24 11:06:52.689767
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from pytest import raises
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class MySchema(Schema):
        name = String(min_length=1, max_length=10)
        age = String()


# Generated at 2022-06-24 11:07:02.462264
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import JSONTokenizer
    from typesystem.fields import String, Integer

    tokenizer = JSONTokenizer()
    token = tokenizer.tokenize('{"x": "foo", "y": "bar"}')
    schema = Schema(
        {
            "x": String(),
            "y": Integer(min_value=0),
        }
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    assert exc_info.value.messages()[0].start_position.char_index == 13

# Generated at 2022-06-24 11:07:09.211754
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import create_token_tree
    from typesystem import fields
    import json

    class CitySchema(Schema):
        name = fields.String()

    class LocationSchema(Schema):
        address = fields.String()
        city = fields.Nested(CitySchema)

    class PersonSchema(Schema):
        name = fields.String()
        location = fields.Nested(LocationSchema)

    json_str = (
        '{"name": "Benjamin", "location": {"address": "123 Main St", "city": {"name": "New York"}}}'
    )
    token = create_token_tree(json.loads(json_str))
    validate_with_positions(token=token, validator=PersonSchema)

# Generated at 2022-06-24 11:07:20.383989
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import ValidationError
    from typesystem.fields import Integer
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token

    token = tokenize(
        {
            "null": None,
            "integer": 1,
            "string": "1",
            "empty_string": "",
            "list": [1, 2, 3],
            "null_list": None,
        },
        filename="<testcase>",
    )

    invalid_token = token.lookup(["null"])
    assert isinstance(invalid_token, Token)

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=invalid_token, validator=Integer)

# Generated at 2022-06-24 11:07:32.033656
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema({"field": Field()})
    json = "{}"
    document = yaml.parse(json)
    token = Token.from_yaml_node(document)
    assert validate_with_positions(token=token, validator=schema) == {}

    json = "{field: 123}"
    document = yaml.parse(json)
    token = Token.from_yaml_node(document)
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)
    messages = excinfo.value.messages()
    message = messages[0]
    assert message.start_position == (2, 5)
    assert message.end_position == (2, 9)



# Generated at 2022-06-24 11:07:43.678019
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .test_tokenize import basic_token
    from .test_validate import test_person_validation
    from typesystem.tokenize.token_validator import TokenValidator

    token = basic_token()

    assert validate_with_positions(token=token, validator=test_person_validation) == {
        "name": "Penny Lane",
        "email": "penny@example.com",
        "age": 25,
        "friends": [{"name": "John"}, {"name": "Paul"}, {"name": "George"}],
    }

    try:
        validate_with_positions(token=token, validator=TokenValidator(Field(str)))
    except ValidationError as error:
        message = error.messages()[0]
        assert message.code == "type"

# Generated at 2022-06-24 11:07:54.047742
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Object, ObjectField, String

    def validate_name(value: str) -> str:
        if len(value) > 3:
            raise ValidationError(message="Name must be less than 3 characters")
        return value

    class Person(Schema):
        name = String(validators=[validate_name])

    input_ = Object(
        fields=[
            ObjectField(name="name", value=String(value="Bob"))
        ]
    )

    try:
        output = validate_with_positions(token=input_, validator=Person)
    except ValidationError as error:
        expected_message = (
            "The field 'name' must be less than 3 characters. (name)"
        )
        assert str(error) == expected_message

# Generated at 2022-06-24 11:08:01.081132
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Tokenizer

    from .models import Person

    tokenizer = Tokenizer(Person.validators)
    tokenizer.load("{}")
    tokenizer.tokenize()
    token = tokenizer.root_tokens[0]
    assert validate_with_positions(
        token=token, validator=Person
    ) == {"name": "", "age": None}

# Generated at 2022-06-24 11:08:09.375491
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from dataclasses import dataclass
    from typesystem.base import Message
    from typesystem.fields import Integer
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    @dataclass
    class Person(Schema):
        name: str = Field(required=True)
        age: int = Field(required=True)
        nickname: str = Field(required=True)

    json_content = """
    {
        "name": "Albert",
        "age": 42,
        "nickname": "Al"
    }
    """
    token = Token.parse(json_content)
    try:
        Person.validate(token.value)
    except ValidationError as error:
        print("Error: ", error.messages())

# Generated at 2022-06-24 11:08:19.999413
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Schema, fields
    from typesystem.tokenize.tokens import TokenList

    class TestSchema(Schema):
        name = fields.String(required=True)
        age = fields.Integer()

    token_list = TokenList(
        [{"name": "test", "age": "test"}, {"name": "test", "age": "test"}]
    )

    # Test case: Validate without errors
    validate_with_positions(token=token_list, validator=TestSchema)
    # Test case: Validate with positional errors
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token_list[0], validator=TestSchema)

# Generated at 2022-06-24 11:08:29.102915
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.integer import Integer
    from typesystem.tokenize.tokens import RootToken, StringToken

    field = Integer(minimum=1)
    root = RootToken()
    root.add_child("children", StringToken("foo", start=1, end=4))

    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=root.children[0], validator=field)

    assert error_info.value.messages() == [
        Message(
            text="Ensure this value is greater than or equal to 1.",
            code="min_value",
            index=("children", 0),
            start_position=1,
            end_position=4,
        )
    ]



# Generated at 2022-06-24 11:08:37.626075
# Unit test for function validate_with_positions
def test_validate_with_positions():
    item = Token("foo", position=(1, 0), end_position=(1, 3), children=[])
    schema = typesystem.Schema(fields={"foo": typesystem.Boolean()})

    # TypeError: Object of type 'Token' is not JSON serializable
    with pytest.raises(TypeError):
        schema.validate(item.value)

    validator = schema.fields["foo"]
    with pytest.raises(typesystem.ValidationError) as error:
        validate_with_positions(token=item, validator=validator)


# Generated at 2022-06-24 11:08:49.509466
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.utils import parse
    from typesystem.fields import Integer

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=parse('{"foo": 42, "bar": 7}'), validator=Schema(properties={"baz": Integer()})
        )

    messages = exc_info.value.messages()
    assert len(messages) == 1
    assert messages[0].text == 'The field "bar" is not an allowed key.'
    assert messages[0].start_position.line == 1
    assert messages[0].start_position.column == 11
    assert messages[0].end_position.line == 1

# Generated at 2022-06-24 11:08:58.327083
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test the field type
    assert validate_with_positions(
        token=Token(
            value={"foo": "bar"},
            start=None, # type: ignore
            end=None, # type: ignore
        ),
        validator=Field(type=dict, fields={"foo": Field(type=str)}),
    ) == {"foo": "bar"}

    # Test the error with a validation error
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=Token(
                value={"foo": 123},
                start=None, # type: ignore
                end=None, # type: ignore
            ),
            validator=Field(type=dict, fields={"foo": Field(type=str)}),
        )

# Generated at 2022-06-24 11:09:05.851443
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.tokenize.tokens import from_json
    from typesystem.fields import String, Integer

    raw = '{"foo": "foo", "bar": 3}'
    data = from_json(raw)

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=data, validator=String())

    messages = error.value.messages()
    assert len(messages) == 1
    assert messages[0].index == []
    assert messages[0].start_position.line_index == 0
    assert messages[0].start_position.char_index == 0
    assert messages[0].end_position.line_index == 0
    assert messages[0].end_position.char_index == 14


# Generated at 2022-06-24 11:09:14.689376
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    schema = Schema(
        {
            "name": String(min_length=1),
            "age": String(),
        }
    )

    from typesystem.tokenize.lexer import lex
    from typesystem.tokenize.lexer import Token

    tokens = schema.tokenize({"name": "John", "age": 23})
    token = Token.from_list(tokens)

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.code == "string_invalid_type"

# Generated at 2022-06-24 11:09:26.096036
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize import tokenize, ParseError
    from typesystem.tokenize.tokens import Token

    field = String(max_length=5)

    value, end_index = tokenize("'Hello'")
    token = Token(value, start=0, end=end_index)
    assert validate_with_positions(token=token, validator=field) == "Hello"

    value, end_index = tokenize("'Hello'")
    token = Token(value, start=0, end=end_index)
    try:
        validate_with_positions(token=token, validator=String(max_length=4))
    except ValidationError as error:
        assert error.messages()[0].text == "Must be at most 4 characters long."
       

# Generated at 2022-06-24 11:09:34.822591
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parse import tokenize
    from typesystem.tokenize.constants import TokenType

    schema = Schema(fields={"foo": Field(required=True)})
    tokens = tokenize("""{"foo": "bar"}""")
    data = tokens.validate(schema)
    assert data == {"foo": "bar"}

    tokens = tokenize("""{"foo": null}""")
    try:
        tokens.validate(schema)
    except ValidationError as error:
        message: Message = error.messages()[0]
        assert message.start_position.line_index == 0
        assert message.start_position.char_index == 7
        assert message.end_position.line_index == 0
        assert message.end_position.char_index == 11

# Generated at 2022-06-24 11:09:39.297176
# Unit test for function validate_with_positions
def test_validate_with_positions():

    assert validate_with_positions(
        token=Token(value={"a": 1}, start=(0, 0), end=(0, 1)),
        validator=Field(type="object", properties={"a": Field(type="number")}),
    ) == {
        "a": 1
    }



# Generated at 2022-06-24 11:09:49.731820
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema, Structure
    from typesystem.tokenize.parser import parse

    class UserSchema(Schema):
        class Meta:
            root = True

        name = Field()

    schema = UserSchema()
    token = parse(
        "{ 'name': 1 }",
        start_position={"line_number": 1, "char_index": 1},
        end_position={"line_number": 1, "char_index": 15},
    )
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        [message] = error.messages()
        assert {
            "line_number": 1,
            "char_index": 8,
        } == message.start_position

# Generated at 2022-06-24 11:09:59.322746
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Array, Text
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.source import Line, Source

    source = Source(
        lines=[
            Line(index=0, text="data = [")
        ]
    )
    array = Array(items=Text())

    token = Token(
        name="array",
        value=["a"],
        start=source.lines[0].positions[0],  # 1-st character of the line
        end=source.lines[0].positions[4],  # 5-th character of the line
    )

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=array)
