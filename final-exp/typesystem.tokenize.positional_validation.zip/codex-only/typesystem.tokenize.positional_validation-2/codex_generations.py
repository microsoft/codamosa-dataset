

# Generated at 2022-06-24 11:00:06.964758
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, Object, String

    schema = Object(properties={"name": String(), "age": Integer()})
    text = '{"name": "Paul", "age": "42"}'

    token = Token.create_from(json.loads(text))
    try:
        # This works
        schema.validate(token.value)
        assert False
    except ValidationError as error:
        assert len(error.messages()) == 1
        assert error.messages()[0].index == ["age"]
        assert error.messages()[0].code == "type_error.integer"
        assert error.messages()[0].text == "Value must be an integer."

    token = Token.create_from(json.loads(text))

# Generated at 2022-06-24 11:00:14.474483
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # pylint: disable=redefined-outer-name
    from typesystem import types, schemas

    def assert_message(
        *,
        expected_message: str,
        expected_code: str,
        token: typing.Any,
        field: Field,
    ) -> None:
        with pytest.raises(ValidationError, match=expected_message):
            validate_with_positions(token=token, validator=field)
            raise AssertionError("Validation should have raised.")


# Generated at 2022-06-24 11:00:23.776939
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.lexers import JsonLexer
    from typesystem.tokenize.serializers import JsonTokenSerializer
    from typesystem.tokenize.tokens import PrimitiveType, Token

    from typesystem.fields import Text
    from typesystem.schemas import Object
    from typesystem.validators import OneOf

    class Document(Object):

        type = Text(validators=[OneOf(["document"])])

    json_string = '{"type": "document"}'

    value, errors = JsonLexer().lex(
        string=json_string, serializer=JsonTokenSerializer()
    )

    assert PrimitiveType.validate(value) is value

    document = Document()
    document_type = document.fields["type"]

    # Ensure that the simplistic Text validator works
    assert Text

# Generated at 2022-06-24 11:00:27.537066
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.sentinels import JSONStringSentinel
    from typesystem.validators import IntegerValidator

    sentinel = JSONStringSentinel('{"a": "b"}')
    token = sentinel.token.lookup(["a"])
    assert validate_with_positions(token=token, validator=IntegerValidator()) is None

# Generated at 2022-06-24 11:00:39.375850
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import lex, Token

    from typesystem.exceptions import PositionalError

    token = lex("[1, 123, hello, true]")
    token = Token(
        token=token,
        start=None,
        end=None,
        lookup=lambda indexes: token,
        location=Location(line=1, column=1, char_index=0),
    )

    schema = Schema(fields=[Field(type=str), Field(type=int)])

    with pytest.raises(PositionalError) as e:
        validate_with_positions(token=token, validator=schema)

    messages = sorted(e.value.messages, key=lambda m: m.start_position.char_index)

    assert messages[0].text == "The field [1] is required."


# Generated at 2022-06-24 11:00:49.967796
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.fields import Integer
    from typesystem.schemas import Validator

    class ExampleSchema(Schema):
        a = Integer(max_value=10)
        b = Integer(min_value=1)

    token = Token(
        "a.b",
        value={
            'a': {
                'b': 1
            }
        }
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=ExampleSchema)

# Generated at 2022-06-24 11:01:01.528704
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.exceptions import ValidationError
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema
    from typesystem.tokenize.token_types import TokenType
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        first_name = String(required=True)
        age = Integer(min_value=0)

    class Event(Schema):
        name = String()
        location = String()
        time = String()

    class Schedule(Schema):
        people = Person.as_list()
        events = Event.as_list()

    class ScheduleWithComments(Schema):
        people = Person.as_list()
        events = Event.as_list()

        class Meta:
            # This is a comment
            comment = "#"

   

# Generated at 2022-06-24 11:01:10.668463
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import Integer, String
    from typesystem.tokenize import tokenize_json

    class Person(Schema):
        id = Integer(required=True)
        name = String(required=True)

    data = {
        "id": 1,
        "name": "John",
    }

    tokens = tokenize_json(data)
    validate_with_positions(token=tokens[0], validator=Person)

    data = {
        "id": 1,
    }

    tokens = tokenize_json(data)
    with pytest.raises(ValidationError) as e:
        validate_with_positions(token=tokens[0], validator=Person)

# Generated at 2022-06-24 11:01:20.137539
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema({"foo": Field(str)})

    token = Token.from_data({"foo": "bar"}, start=None, end=None)

    assert validate_with_positions(token=token, validator=schema) == {"foo": "bar"}

    token = Token.from_data({"baz": "bar"}, start=None, end=None)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    error = exc_info.value

    assert error.messages == [
        Message(
            text='The field "foo" is required.',
            code="required",
            index=("foo",),
            start_position=None,
            end_position=None,
        )
    ]



# Generated at 2022-06-24 11:01:31.351514
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokens, tokenize
    from typesystem import fields, schemas

    fields = [
        fields.String(required=True),
        fields.String(required=True),
        fields.Integer(min_value=5),
    ]
    schema = schemas.Schema(fields=fields)


# Generated at 2022-06-24 11:01:39.420446
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        first_name = Field(type=str, required=True)
        last_name = Field(type=str, required=True)

    def _get_token(value):
        "Simulate typesystem.tokenize.tokenize.Token"
        start = {"line": 1, "column": 1, "char_index": 0}
        end = {"line": 1, "column": 10, "char_index": 9}
        return Token(
            start=start,
            end=end,
            lookup=lambda x: _get_token(value),
            value=value,
        )

    valid = _get_token({"first_name": "", "last_name": "Doe"})

# Generated at 2022-06-24 11:01:46.532928
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int, required=True)

    with pytest.raises(ValueError) as excinfo:
        validate_with_positions(
            token=Token(value={"name": "Harry"}, start=(1, 0), end=(1, 3)),
            validator=Person,
        )
    assert "The field 'age' is required." in str(excinfo.value)

    with pytest.raises(ValueError) as excinfo:
        validate_with_positions(
            token=Token(value={"age": "Harry"}, start=(1, 0), end=(1, 3)),
            validator=Person,
        )
    assert "Invalid type. Expected int, received str." in str(excinfo.value)

# Generated at 2022-06-24 11:01:54.167478
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer
    from typesystem.tokenize.tokens import StringToken

    schema = Schema(properties={"foo": String(), "bar": Integer()})
    source = """
    {
        "foo": "hello",
        "bar": "xyz"
    }
    """
    token = StringToken(source=source)
    try:
        validate_with_positions(validator=schema, token=token)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        assert messages[0].start == (3, 14)
        assert messages[0].end == (3, 18)

# Generated at 2022-06-24 11:02:05.626747
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    s = String()
    token = Token(value="foo")
    assert validate_with_positions(token=token, validator=s) == "foo"

    s = String(min_length=5)
    token = Token(value="foo")
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=s)
    assert exc.value.messages()[0] == Message(
        index=(0,),
        start_position=token.start,
        end_position=token.end,
        code="min_length",
        text="Must be at least 5 characters.",
    )

    s = String(required=True)
    token = Token(value="")

# Generated at 2022-06-24 11:02:11.287256
# Unit test for function validate_with_positions
def test_validate_with_positions():
    validator = Field(type=str)
    token = Token(value={"foo": "bar"}, start=None, end=None)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=validator)
    assert exc_info.value.messages == [
        Message(
            text="Expected a string.",
            code="invalid",
            index=(),
            start_position=None,
            end_position=None,
        )
    ]

# Generated at 2022-06-24 11:02:20.340529
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.lexer import lex
    from typesystem.tokenize.base import Tokenizer

    class MyTokenizer(Tokenizer):
        def lex(self, lexer):
            self.lex_text(lexer, "h")
            self.lex_text(lexer, "ello")
            self.lex_text(lexer, " ")
            self.lex_text(lexer, "w")
            self.lex_text(lexer, "orld")

    class MyField(Field):
        def check_type(self, value, path):
            return "hello world"

    my_field = MyField(tokenizer=MyTokenizer)
    text = "hello world"
    tokens = list(lex(text, tokenizer=MyTokenizer))

# Generated at 2022-06-24 11:02:30.396585
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from examples.json_schema import minmax_age_schema, schema
    from typesystem.tokenize.tokens import LiteralToken, ObjectToken

    t = ObjectToken([("name", LiteralToken("joe")), ("age", LiteralToken("30"))], [])
    validate_with_positions(token=t, validator=schema)

    t = ObjectToken(
        [("name", LiteralToken("joe")), ("age", LiteralToken("8"))], []
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=t, validator=schema)

    error_messages = exc_info.value.messages
    print(error_messages)


# Generated at 2022-06-24 11:02:40.619679
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """Unit tests for function validate_with_positions."""

    field = Field(type="string", max_length=5)
    schema = Schema(fields={"foo": field})
    token = Token(
        value={"foo": "h" * 6},
        start=Position(line_number=1, char_index=0),
        end=Position(line_number=1, char_index=13),
        lookup=lambda indx: Token(
            value=token.value["foo"],
            start=Position(line_number=1, char_index=4),
            end=Position(line_number=1, char_index=12),
        ),
    )

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=field)
    assert len

# Generated at 2022-06-24 11:02:50.920766
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.errors import ValidationError
    from typesystem.fields import String

    field = String(required=True)
    token = Token(value={"name": "Adam"})
    validated = validate_with_positions(validator=field, token=token)
    assert validated == {"name": "Adam"}

    token = Token(value={"name": "Adam", "age": "34"})
    validated = validate_with_positions(validator=field, token=token)
    assert validated == {"name": "Adam", "age": "34"}

    token = Token(value={"age": "34"})
    try:
        validate_with_positions(validator=field, token=token)
    except ValidationError as error:
        print(error.messages)
        assert error.messages[0].text

# Generated at 2022-06-24 11:03:00.621101
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")


# Generated at 2022-06-24 11:03:08.215450
# Unit test for function validate_with_positions
def test_validate_with_positions():

    """
    token:
    {
        "id": [0],
        "items": [[[0, 0], 8, 10]],
        "type": [[[1, 0], 0, 5]],
        "name": [[[2, 0], 6, 11]],
    }
    validator:
    {
        "items": {
            "type": "string",
            "required": True,
        },
        "type": "string",
        "name": {
            "type": "unicode",
            "required": True,
        },
    }
    """

    # Normal

# Generated at 2022-06-24 11:03:16.771401
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.lexers import JsonLexer
    from typesystem.tokenize.parser import JsonParser
    from typesystem.types import String

    with pytest.raises(ValidationError) as excinfo:
        lexer = JsonLexer()
        parser = JsonParser(lexer)
        tokens = parser.parse(b'{"foo": null}')
        validate_with_positions(token=tokens, validator=String())

    messages = excinfo.value.messages
    message = messages[0]
    assert message.code == "type_error.string"
    assert message.start_position.byte_index == 8
    assert message.end_position.byte_index == 13
    assert message.start_position.char_index == 6  # "\n    ^~~~~"
    assert message

# Generated at 2022-06-24 11:03:25.547091
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import FieldToken, ObjectToken
    from typesystem.tokenize.utils import to_token

    token = to_token(
        {"title": "My Title", "content": "My Content", "tags": ["tech", "python"]}
    )
    assert isinstance(token, ObjectToken)
    assert validate_with_positions(token=token, validator=SampleSchema) == {
        "title": "My Title",
        "content": "My Content",
        "tags": ["tech", "python"],
    }

    token = token.lookup(["content"])
    assert isinstance(token, FieldToken)
    assert validate_with_positions(token=token, validator=SampleSchema.fields["content"]) == "My Content"


# Generated at 2022-06-24 11:03:34.723138
# Unit test for function validate_with_positions
def test_validate_with_positions():
    data = {"name": "a", "value": 5, "nested": {"a": 1}}
    token = Token.parse(data)

    class SubDocument(Schema):
        name = Field(required=True)
        value = Field(type="integer", required=True)

    class Document(Schema):
        nested = Field(type=SubDocument, required=True)

    try:
        validate_with_positions(token=token, validator=Document)
    except ValidationError as error:
        messages = error.messages()
    assert len(messages) == 1
    message = messages[0]
    assert message.text == "The field 'name' is required."
    assert message.code == "required"
    assert message.index == ["nested"]
    assert message.start_position.char_index == 24


# Generated at 2022-06-24 11:03:39.509898
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type="string")
    token = Token("", [("", 0), ("", 0), (42, 21)], [("", 0)])
    with pytest.raises(ValidationError) as info:
        validate_with_positions(token=token, validator=field)
    error = info.value
    assert error.args[0] == "String value expected."
    assert error.messages() == [
        Message(
            index=[],
            text="String value expected.",
            code="invalid_type",
            start_position=(0, 0),
            end_position=(4, 20),
        ),
    ]

# Generated at 2022-06-24 11:03:45.079200
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.number import Number
    from typesystem.tokenize import tokenize

    token = tokenize('{"foo": null}')
    schema = Schema(fields={"foo": Number(required=True)})
    with pytest.raises(ValidationError, match=r"The field 'foo' is required\."):
        validate_with_positions(
            token=token[0], validator=schema
        )

# Generated at 2022-06-24 11:03:55.558297
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Field, String
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize

    class Pet(Schema):
        name = String()

    class Person(Schema):
        name = String()
        pet = Field(Pet)

    data = {"name": "Fred", "pet": {"name": "Garfield"}}
    tokens = list(tokenize(Person(), data))

    # Validate normally, note the lack of position information.
    Person().validate(data)

    # Validate with position information.
    validate_with_positions(token=tokens[0], validator=Person())

# Generated at 2022-06-24 11:04:04.627552
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type="string", required=True)
    schema = Schema({"foo": field})
    token = Token(
        {"foo": "bar"},
        start_position=Token.Position(1, 1, 1),
        end_position=Token.Position(1, 2, 2),
    )

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)

    error = excinfo.value
    assert error.messages() == [
        Message(
            text='The field "foo" is required.',
            code="required",
            index=[],
            start_position=Token.Position(1, 1, 1),
            end_position=Token.Position(1, 2, 2),
        )
    ]

    token = Token

# Generated at 2022-06-24 11:04:15.917791
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object, String

    class Person(Schema):
        name = String(required=True)

    token = Person.parse('{"name": ""}')
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'name' must not be blank."
        assert message.code == "blank"
        assert message.index == ["name"]
        assert not message.start_position.line_index
        assert message.start_position.char_index == 9
        assert message.end_position.line_index == 0
        assert message.end_position.char_index == 11
        return
    raise Ass

# Generated at 2022-06-24 11:04:22.033571
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.lexer import lex
    from typesystem.tokenize.parser import parse

    field = String(nullable=False)
    schema = Schema({"value": field}, allow_extras=True)

    source = "{\"value\": null}"
    tokens = lex(source)
    document = parse(tokens)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=document, validator=schema)

    assert len(exc_info.value.messages) == 1
    message = exc_info.value.messages[0]

    assert message.start_position.line == 1
    assert message.start_position.column == 17
    assert message.start_position.char_index == 16

   

# Generated at 2022-06-24 11:04:32.095264
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.exceptions import ValidationError as ValidationError2
    from typesystem.fields import String
    from collections import namedtuple
    from typesystem.tokenize.tokens import Token

    class BaseToken(typing.NamedTuple):
        start: int
        end: int

    class StringToken(BaseToken):
        value: str

    class IntegerToken(BaseToken):
        value: int

    class NumberToken(BaseToken):
        value: float

    class ObjectToken(BaseToken):
        fields: list

        def __getitem__(self, key):
            for token in self.fields:
                if token.name == key:
                    return token.value
            raise KeyError()

    class FieldToken(BaseToken):
        name: str
        value: BaseToken


# Generated at 2022-06-24 11:04:36.657837
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions.__doc__ == (
        "validate_with_positions(*,"
        " token:typing.Union[typesystem.tokenize.tokens.Token, int],"
        " validator:typing.Union[typesystem.fields.base.BaseField,"
        " typing.Type[typesystem.schemas.base.BaseSchema]]"
        ") -> typing.Any\n"
    )



# Generated at 2022-06-24 11:04:44.972352
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema({"a": {"b": Field(required=True)}})
    token = Token.build(schema, {"a": {"b": None}})
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'b' is required."
        assert message.start_position.line == 1
        assert message.start_position.char_index == 6
        assert message.start_position.col == 7
        assert message.end_position.line == 1
        assert message.end_position.char_index == 8
        assert message.end_position.col == 9

# Generated at 2022-06-24 11:04:54.671331
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokens import Token, PositionToken
    from typesystem.validators import String, Integer, List
    import pytest
    import json

    class PositionalSchema(Schema):
        name = String()
        count = Integer()
        tags = List(items=String())

    data = {"name": "Bob", "count": "ten", "tags": [2]}
    token = Token.from_native(json.loads(json.dumps(data)))
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=PositionalSchema)
    exc_info.match("^3 errors$")

    # Check that each error has a positional message.

# Generated at 2022-06-24 11:04:58.422578
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Given a token for a dict
    token = Token("dict", {})

    # When the dict is validated
    validator = Schema({"a": Field(str)})
    validate_with_positions(token=token, validator=validator)

    # Then it validates
    token.value
    token.value = {"a": 2}
    validate_with_positions(token=token, validator=validator)


# Generated at 2022-06-24 11:05:10.955983
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class AuthorSchema(Schema):
        name = Field(str, required=True)

    class BookSchema(Schema):
        title = Field(str, required=True)
        author = Field(AuthorSchema)

    book = '{"author": {"name": "John"}, "title": "Basic Types"}'
    token = Token(value=book, start=Position(char_index=0), end=Position(char_index=47))
    validate_with_positions(token=token, validator=BookSchema)

    book = '{"author": {"name": "John"}, "title": "Basic Types", "year": null}'
    token = Token(value=book, start=Position(char_index=0), end=Position(char_index=58))

# Generated at 2022-06-24 11:05:20.591068
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import Parser
    from typesystem.tokenize.token import Token

    with open("tests/tokenize/stubs/simple_schema.py", "r") as file:
        schema_source = file.read()

    with open("tests/tokenize/stubs/simple_schema_data.py", "r") as file:
        data_source = file.read()

    parser = Parser(schema_source, data_source)
    schema_token = parser.parse()

    from typesystem.tokenize.validation_results import ValidationResult

    result = ValidationResult(schema_token)
    result.validate()

    assert result.error_count == 1
    assert result.error_count == len(result.errors)


# Generated at 2022-06-24 11:05:25.489810
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import Field, String
    from typesystem.tokenize.parser import parse_string

    class SampleSchema(Schema):
        text = String(required=False)

    token = parse_string(json.dumps({"text": 1}))
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=SampleSchema)
        assert exc.index == ["text"]



# Generated at 2022-06-24 11:05:34.505566
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Array, String
    from typesystem.tokenize.tokens import ObjectToken, PropertyToken

    object_token = ObjectToken(value={}, start=None, end=None)
    object_token.properties["foo"] = PropertyToken(
        value={"bar": ["a", "b"], "baz": "spam"},
        start=None,
        end=None,
    )

    array = Array(items=String())
    assert validate_with_positions(token=object_token.properties["foo"], validator=array)
    assert object_token.properties["foo"].value == ["a", "b"]

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=object_token.properties["foo"], validator=String())
    assert exc

# Generated at 2022-06-24 11:05:39.934587
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class User(Schema):
        name = Field(type=str)

    token = Token.from_mapping({"name": "John"})

    User.validate(token)

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=User)

    assert error.value.messages()[0].start_position.byte_index == 1
    assert error.value.messages()[0].end_position.byte_index == 5

# Generated at 2022-06-24 11:05:40.381595
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-24 11:05:41.056483
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-24 11:05:44.712465
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(str)
        age = Field(int)

    try:
        validate_with_positions(
            token=Token(start=(1, 1), end=(3, 1), value={"name": "Alice", "age": "40"}),
            validator=Person,
        )
    except ValidationError as error:
        messages = error.messages()
        assert messages[0].start_position == (2, 3)



# Generated at 2022-06-24 11:05:55.292012
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.lexer import Lexer
    from typesystem.tokenize.parser import Parser
    from typesystem.tokenize.tokens import Token

    class ExampleSchema(Schema):
        field_1: str
        field_2: str

    source = "{field_1: 'a', field_2: 'b'}"
    lexer = Lexer()
    tokens, errors = lexer.lex(source)

    assert not errors

    parser = Parser()
    tree = parser.parse(tokens)

    assert isinstance(tree, Token)
    assert tree.name == "Mapping"

    try:
        validate_with_positions(token=tree, validator=ExampleSchema())
    except ValidationError as error:
        assert len

# Generated at 2022-06-24 11:06:03.893679
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import Tokenizer
    from typesystem.tokenize.tokens import LiteralToken, ListToken
    from typesystem.fields import Integer

    tokenizer = Tokenizer()

    token = tokenizer.tokenize(b"123,[]")
    assert type(token) is ListToken
    assert type(token.tokens[0]) is LiteralToken
    assert token.tokens[0].start == (0, 0)
    assert token.tokens[0].end == (0, 3)
    assert token.tokens[1].start == (0, 4)
    assert token.tokens[1].end == (0, 5)

    validate_with_positions(token=token.tokens[0], validator=Integer.validate)


# Generated at 2022-06-24 11:06:13.197510
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import IntegerField
    from typesystem.schemas import SchemaMeta
    from typesystem.tokenize.tokens import Document, ListToken, ObjectToken, StringToken

    class Address(Schema):
        street = StringField()
        postal_code = StringField(name="zip_code")

    class User(Schema):
        name = StringField()
        age = IntegerField()
        address = Address()


# Generated at 2022-06-24 11:06:21.797631
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.parser.parser import EndOfToken, EndOfFile, TokenizerState
    from typesystem.tokenize.tokenizer import Position
    from typesystem.tokenize.tokens import StringToken
    from typesystem.types import String
    from io import StringIO

    def validate_json(json_str):
        json_str_io = StringIO(json_str)
        tokenizer = TokenizerState(json_str_io)
        token = tokenizer.read_token()
        validate_with_positions(token=token, validator=String("json"))
        assert tokenizer.read_token() == EndOfToken

    validate_json("42")
    validate_json("null")
    validate_json("true")
    validate_json("false")
    validate_json("[]")
    validate_json("{}")

# Generated at 2022-06-24 11:06:31.155367
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Collection, types

    class IntegerToken(types.Integer, Token):
        pass

    class IntegerList(Collection, Token):
        item_type = IntegerToken

    token = IntegerList(value=[IntegerToken(value="5"), IntegerToken(value="10")])
    assert isinstance(token, IntegerList)

    validate_with_positions(token=token, validator=IntegerList)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=token, validator=IntegerList(min_items=3, item_type=IntegerToken)
        )
    message = exc_info.value.messages()[0]
    assert message.code == "min_items"
    assert message.text == 'List has less items than 3.'
    assert message.index

# Generated at 2022-06-24 11:06:37.697080
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.lexers import Lexer
    from typesystem.lexical_graphs import JSONGraph
    from typesystem.lexical_errors import LexicalError

    import pytest

    class MySchema(Schema):
        name = Field(type="string", required=True)
        amount = Field(type="integer")

    lexer = Lexer(graph=JSONGraph)
    payload = "{name:null}"
    with pytest.raises(LexicalError) as error:
        validate_with_positions(token=lexer.tokenize(payload), validator=MySchema)
    assert error.value.messages()[0].text == "The field 'name' is required."

# Generated at 2022-06-24 11:06:46.613114
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import types

    class Person(Schema):

        name = types.String(required=True)

    token = Token.parse("{'name': ''}")
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'name' is required.",
                code="required",
                index=("name",),
                start_position=token.value.start + 2,
                end_position=token.value.end - 1,
            )
        ]


# NOTE: this only works with python3.6+

# Generated at 2022-06-24 11:06:55.248647
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Schema, fields
    from typesystem.tokenize.parser import parse
    from typesystem.tokenize.tokens import Token

    schema = Schema(
        {"property": fields.Integer(required=True, nullable=False)}
    )  # type: ignore

    token = parse('{"property": null}')
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=schema)
    assert exc.value.messages() == [
        Message(
            text="The field 'property' is required.",
            code="required",
            index=["property"],
            start_position=Token(14, 17),
            end_position=Token(14, 17),
        )
    ]


# Generated at 2022-06-24 11:07:05.636644
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem import Schema, String

    schema = Schema(properties=dict(name=String()))

    # Can't use assertRaises here, because we need the positional messages

# Generated at 2022-06-24 11:07:16.855073
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.base import ExampleSchema, ExampleField

    token = Token({"field1": "123"})
    assert validate_with_positions(token=token, validator=ExampleField()) == 123

    token = Token({"field1": "Incorrect"})
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=ExampleField())

    token = Token({"field1": "123"})
    assert validate_with_positions(token=token, validator=ExampleSchema()) == {"field1": 123}

    token = Token({"field1": "Incorrect"})
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=ExampleSchema())

# Generated at 2022-06-24 11:07:23.433372
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Arrange
    import typesystem

    class Info(typesystem.Object):
        name = typesystem.String()
        email = typesystem.String()
        age = typesystem.Integer()
    
    # Act and Assert
    try:
        validate_with_positions(token=Token(value={'age': '1'}), validator=Info)
        assert False, "Should throw ValidationError"
    except ValidationError as err:
        assert err.messages()[0].text == "The field 'email' is required."

# Generated at 2022-06-24 11:07:31.690927
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class SimpleSchema(Schema):
        foo = Field()

    raw_tokens = Token(
        {"foo": "bar"},
        [(0, 2), (2, 3), (3, 4), (4, 6)],
        [(0, 6)],
        [(0, 4), (4, 5), (5, 6)],
    )
    schema = SimpleSchema()

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=raw_tokens, validator=schema)

    assert exc.value.messages()[0].index == ["foo"]



# Generated at 2022-06-24 11:07:38.167066
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String
    import typesystem.tokenize

    schema = String()
    program = '"test"'
    tree = typesystem.tokenize.tokenize(program)

    assert validate_with_positions(token=tree, validator=schema) == program

# Generated at 2022-06-24 11:07:46.038000
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class SubSchema(Schema):
        subfield = Field(required=True)

    class SchemaClass(Schema):
        field = Field(required=True)
        subfield = SubSchema()

    text = """{"field": "test", "subfield": {"subfield": 2}}"""

    token = Token(text=text)
    token.validate(SchemaClass)

    text = """{"field": "test", "subfield": {}}"""

    token = Token(text=text)
    try:
        token.validate(SchemaClass)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'subfield' is required."
        assert message.code == "required"
        assert message

# Generated at 2022-06-24 11:07:56.196229
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    token = tokenize({"foo": "bar"})
    schema = Schema(
        fields={"foo": Field(types=str, required=True)},
        required=["foo"],
    )
    assert validate_with_positions(token=token, validator=schema) == {"foo": "bar"}

    token = tokenize({"foo": None})
    schema = Schema(
        fields={"foo": Field(types=str, required=True)},
        required=["foo"],
    )
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'foo' is required."
        assert error.messages()[0].start

# Generated at 2022-06-24 11:08:06.890920
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Movie(Schema):
        title = Field(type="string", min_length=2)
        year = Field(type="integer", minimum=1900)

    data = [{"title": "title"}]
    token = Token.from_value(data)
    try:
        validate_with_positions(token=token, validator=Movie)
    except ValidationError as error:
        messages = []
        for i, message in enumerate(error.messages()):
            assert message.code == "required"
            assert message.index == [i, "year"]
            assert message.start_position == (1, 13)
            assert message.end_position == (1, 13)
            assert message.text == "The field 'year' is required."
            messages.append(message)
        assert len(messages) == 1


# Generated at 2022-06-24 11:08:17.964463
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema, Integer

    class Person(Schema):
        name = Integer()
        age = Integer()

    token = tokenize('{"name": "Jane Doe", "age": 42}')
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == 'Expected an integer but got a string.'
        assert message.code == 'invalid_type'
        assert message.index == ('Person', 'age')
        assert message.start_position.line == 1
        assert message.start_position.character == 14
        assert message.end_position.line == 1
        assert message.end_position.character == 17


# Generated at 2022-06-24 11:08:24.014474
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Object

    class SimpleSchema(Schema):
        name = String()
        age = Integer(minimum=5)

    class NestedSchema(Schema):
        first = SimpleSchema
        second = SimpleSchema

    class NestedSchemaWithLists(Schema):
        first = Object[SimpleSchema]
        second = Object[SimpleSchema]

    # no errors
    validate_with_positions(
        token=Token([validate_with_positions, "first"], {"name": "Bruce Wayne", "age": 42}),
        validator=NestedSchema,
    )

# Generated at 2022-06-24 11:08:32.637946
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # This unit test doesn't pass because of
    # https://github.com/python/mypy/issues/5246
    from typesystem.schemas import Schema

    from .tokenize import Tokenizer

    index = Tokenizer.tokenize(
        "order_id: 1234\n"
        "order_date_time: 2020-01-01T00:00:00\n"
        "status: SHIPPED\n"
        "line_items: [\n"
        '  { product_id: "1", quantity: 10, unit_price: 100.1 },\n'
        '  { product_id: "2", quantity: 20, unit_price: 200.2 },\n'
        "]\n"
    )


# Generated at 2022-06-24 11:08:40.771007
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json

    class Serializable:
        def __init__(self, value):
            self.value = value

        def to_json(self):
            return json.dumps(self.value)

    def field_from_json(value):
        return Serializable(value)

    class Movie(Schema):
        title = Field(field_from_json)
        production_budget = Field(field_from_json)
        year = Field(field_from_json)

    from typesystem.tokenize.tokenizer import Tokenizer

    tokenizer = Tokenizer()
    tokens = tokenizer.from_string(
        """
        {
            "title": "Star Wars",
            "production_budget": "Not Known",
            "year": 2018
        }
    """
    )
    token = tokens[0]

# Generated at 2022-06-24 11:08:42.020802
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-24 11:08:52.382634
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import types, validate_with_positions
    from typesystem.tokenize.parser import parse
    import typesystem.tokenize.lexer as lexer

    @types.schema
    class Person:
        name = types.string()
        age = types.integer(minimum=21)

    errors = Person.validate('{"name": "John Doe", "age": 20}')
    assert len(errors) == 1
    assert errors[0].code == "min_value"

    text = '{"name": "John Doe", "age": 20}'
    tokens = parse(lexer.lex(text=text))
    token = tokens[2]
    errors = validate_with_positions(token=token, validator=Person.get_field("age"))
    assert len(errors) == 1

# Generated at 2022-06-24 11:09:02.969483
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tests.schema import UserSchema

    data = {"name": "erik"}
    token = Token.from_python(data)

    try:
        validate_with_positions(token=token, validator=UserSchema)
    except ValidationError as error:
        assert len(error.messages()) == 2

        message = error.messages()[0]
        assert message.code == "required"
        assert message.index == ("e-mail",)
        assert message.start_position.line == 1
        assert message.start_position.char_index == 3
        assert message.end_position.line == 1
        assert message.end_position.char_index == 9

        message = error.messages()[1]
        assert message.code == "required"

# Generated at 2022-06-24 11:09:11.889208
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Document(Schema):
        title = Field(str, required=True)

    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(
            token=Token(
                "title",
                {"title": None},
                start=Position(line=0, column=10),
                end=Position(line=0, column=11),
            ),
            validator=Document,
        )


# Generated at 2022-06-24 11:09:21.106435
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import Field, String

    class Person(Schema):
        name = String(max_length=10)
        age = Field()

    token = Token(
        {"name": "", "age": "10"},
        start=1,
        end=2,
        lookup=lambda i: None,
        path=["root"],
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    assert exc_info.value.messages()[0].text == "The field 'name' is required."

# Generated at 2022-06-24 11:09:31.364529
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import SchemaMeta
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.utils import FileLocation

    class Person(Schema, metaclass=SchemaMeta):
        name = Field(str, required=True)

    # Test with a missing required field
    tokens = tokenize('{"age": 20}', start_pos=FileLocation(1, 1))

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens[0], validator=Person)


# Generated at 2022-06-24 11:09:40.648122
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class TestSchema(Schema):
        value = Field(required=True, primitive_type="number")

    class TestRecursiveSchema(Schema):
        value = Field(required=True, primitive_type="object")
        recursive = Field(required=True, type_=TestRecursiveSchema)

    # Test positional message with a primitive field
    message = Message(
        text="The field 'value' is required.",
        code="required",
        index=["value"],
        start_position=Token.Position(line=1, char_index=6, column=5),
        end_position=Token.Position(line=1, char_index=9, column=5),
    )

# Generated at 2022-06-24 11:09:46.723637
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class PersonSchema(Schema):
        """A person"""
        name = Field(str)

    tokens = tokenize([{"name": "Steve"}])
    try:
        validate_with_positions(token=tokens[0], validator=PersonSchema())
    except ValidationError as error:
        assert error.messages()[0].start_position.char_index == 1

# Generated at 2022-06-24 11:09:56.699908
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from datetime import datetime
    from json import loads
    from typesystem.fields import DateTime
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token

    body = '{"mydatetime": "2020-01-01"}'.encode()
    token = Token(loads(body))
    schema = Schema(
        {"mydatetime": DateTime(minimum=datetime(2020, 1, 1), required=True)}
    )