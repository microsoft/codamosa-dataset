

# Generated at 2022-06-24 10:59:58.924201
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """
    Test validate_with_positions
    """
    from typesystem.schemas import Schema
    from typesystem.fields import Integer, String
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.scanner import Scanner
    from typesystem.tokenize.types import TokenType
    from typesystem.tokenize.lexer import Lexer

    scanner = Scanner()
    lexer = Lexer(scanner)
    INTEGER = Integer()
    STRING = String()

    schema = Schema([("x", INTEGER), ("y", STRING)])
    schema.validate(["foo", "bar"])

    filename = "nonexistent"
    tokens = lexer.lex(filename, "foo: 1, bar: 'hello'")
    token_list = []


# Generated at 2022-06-24 11:00:09.678016
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class MyType(Field):
        python_type = str

        def validate_python_value(self, value: typing.Any) -> typing.Any:
            if value != "valid":
                raise ValidationError(messages=["Invalid value"])

    class MySchema(Schema):
        my_field = MyType()

    schema = MySchema()
    token = Token(
        value=None,
        start=Token.Position(line_index=0, char_index=0),
        end=Token.Position(line_index=0, char_index=0),
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema.my_field)
    message = exc_info.value.messages[0]
   

# Generated at 2022-06-24 11:00:17.113781
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token("a")({"b": Token("a")({"c": Token("a")})})
    try:
        validate_with_positions(
            token=token, validator=Schema({"a": Schema({"b": Schema({"c": str})})})
        )
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'a' is required."
        assert message.code == "required"
        assert message.index == ["a"]
        assert message.start_position.char_index == 1
        assert message.end_position.char_index == 2

# Generated at 2022-06-24 11:00:26.950994
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .base_test import (
        TEST_FIELD,
        TEST_SCHEMA,
        TEST_VALUE,
        assert_message_equal,
        assert_message_in,
        assert_message_not_in,
    )
    from .conftest import assert_raises_with_message

    token = Token.from_python(TEST_VALUE)

    validate_with_positions(token=token, validator=TEST_FIELD)
    validate_with_positions(token=token, validator=TEST_SCHEMA)
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=TEST_SCHEMA(required=["h", "i"]))
    error = excinfo.value

# Generated at 2022-06-24 11:00:39.178314
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    from typesystem.tokenize import Token, tokenize

    schema = Schema(
        {"name": String(max_length=10), "age": Integer(maximum=150)}, required=["name"]
    )
    doc = "name: John, age: 36"
    tokens = tokenize(doc)
    validate_with_positions(token=tokens, validator=schema)

    doc = "name: John, age: 36"
    tokens = tokenize(doc)
    try:
        validate_with_positions(token=tokens, validator=schema)
    except Exception as error:
        assert str(error) == '{"name": ["The field required is required."]}'



# Generated at 2022-06-24 11:00:49.750919
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    from typesystem.fields import AnyField, String, Integer
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize
    
    class TestSchema(Schema):
        foo: int
        bar: str
        
    schema = TestSchema()
    data = {
        "foo": "not an int",
        "baz": "should not be here",  # extra field
    }
    data_str = json.dumps(data)
    
    token = tokenize(data_str)
    
    try:
        validate_with_positions(
            token=token, validator=schema
        )
    except ValidationError as error:
        assert len(error.messages()) == 2

# Generated at 2022-06-24 11:01:01.527780
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.utils import tokenize

    schema = Schema(fields=[Field(name="name", type="string", required=True)])
    token = tokenize({"foo": "bar"}, schema)
    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=token, validator=schema)

    errors = error_info.value.messages()
    assert len(errors) == 1
    assert errors[0].text == "The field 'name' is required."
    assert errors[0].start_position.line_index == 0
    assert errors[0].start_position.char_index == 1
    assert errors[0].end_position.line_index == 0
    assert errors[0].end_position.char_index == 4

# Generated at 2022-06-24 11:01:08.971561
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.json_schema import JSONSchema
    from typesystem.fields import Boolean
    from typesystem.tokenize.json_tokens import JSONToken

    schema = JSONSchema({"type": "string"})
    token = JSONToken("42", "integer")
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)
    message = excinfo.value.messages[0]
    assert message.text == "Incorrect type for value 42. Expected string."
    assert message.start_position.line == 0
    assert message.start_position.char_index == 0

    field = Boolean()
    token = JSONToken("42", "integer")
    with pytest.raises(ValidationError) as excinfo:
        validate

# Generated at 2022-06-24 11:01:19.032315
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.utils import tokenize
    from typesystem.schemas import ObjectSchema, Text
    from typesystem.fields import Integer

    class Person(ObjectSchema):
        name = Text(required=True)
        age = Integer(minimum=0, maximum=150)

    root = tokenize("""{
        name: "Sam",
        age: 28
    }""")

    validate_with_positions(token=root, validator=Person())
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=root, validator=Person(required=["job"]))

    messages = exc_info.value.messages
    assert messages[0].text == "The field 'job' is required."
    assert messages[0].start_position.line == 2

# Generated at 2022-06-24 11:01:29.661870
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from pytest import raises
    from typesystem.fields import String
    from typesystem.tokenize.tokens import ObjectToken

    schema = dict(foo=String(required=True))
    data = {}
    token = ObjectToken(data, schema)

    with raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=schema)

    message = exc.value.messages[0]

    assert message.index == ("foo",)
    assert message.start_position.line_number == 1
    assert message.start_position.char_index == 2
    assert message.end_position.line_number == 1
    assert message.end_position.char_index == 6

# Generated at 2022-06-24 11:01:36.577703
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typing import Dict, List

    from typesystem.tokenize.tokens import EmptyToken, Token, TokenType

    from .compat import mock

    d = {
        "foo": {
            "bar": "hello world",
            "baz": "goodbye world",
        },
        "user": {
            "id": "abcd-efgh-ijkl",
            "name": "Jeremy",
        }
    }

    tokens: List[Token] = []
    current_token = EmptyToken()
    for key in d:
        tokens.append(current_token)

# Generated at 2022-06-24 11:01:44.508680
# Unit test for function validate_with_positions
def test_validate_with_positions():

    import typesystem
    import pytest

    with pytest.raises(typesystem.ValidationError) as exc_info:
        validate_with_positions(
            token=Token(value={"foo": 2}, start="11:6", end="12:8"),
            validator=typesystem.Boolean(required=True),
        )

    assert len(exc_info.value.messages) == 1
    message = exc_info.value.messages[0]

    assert message.code == "type_error.boolean"
    assert message.index == []
    assert message.text == "Expected a boolean value."
    assert message.start_position == "11:6"
    assert message.end_position == "12:8"

# Generated at 2022-06-24 11:01:54.235070
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema({"foo": {"baz": Field(type="string")}})

    data = '{"foo": {"bar": 23}}'

    try:
        validate_with_positions(
            token=schema.tokenize(data), validator=schema
        )
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'baz' is required."
        assert message.index == ("foo", "baz")
        assert message.start_position.line == 1
        assert message.start_position.char_index == 8
        assert message.end_position.line == 1
        assert message.end_position.char_index == 11
    else:
        assert False

# Generated at 2022-06-24 11:02:05.668896
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # type: () -> None
    from typesystem.schemas import Object
    from typesystem.fields import Integer

    class TestSchema(Object):
        field1 = Integer()
        field2 = Integer()
        field3 = Integer(required=True)
        field4 = Integer()
        field5 = Integer()

    # Test an error in a non-required field.

# Generated at 2022-06-24 11:02:11.332222
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class PointSchema(Schema):
        x = Field(type=int, required=True)
        y = Field(type=int, required=True)

    class ShapeSchema(Schema):
        shape = Field(
            type=str, one_of=["point", "line", "circle"], required=True
        )
        point = Field(type=PointSchema, required=False)

    class DrawingSchema(Schema):
        username = Field(type=str, min_length=1, max_length=255, required=True)
        shapes = Field(type=ShapeSchema, list=True)

    class DocumentSchema(Schema):
        drawing = DrawingSchema()


# Generated at 2022-06-24 11:02:19.004388
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize, untokenize

    from typesystem import fields

    class Person(fields.Object):
        name = fields.String()
        age = fields.Integer()
        likes = fields.Array(fields.String())

    token = tokenize({})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        messages = error.messages()
        assert token.start == messages[0].start_position
        assert token.end == messages[0].end_position
        assert [m.text for m in messages] == ["Missing data for required field."]

# Generated at 2022-06-24 11:02:27.897245
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    from typesystem.fields import Integer
    from typesystem.tokenize.positions import Position
    from typesystem.tokenize.tokens import ListToken, MapToken, StringToken
    from typesystem.tokenize.tokenize_json import tokenize_json

    data = json.dumps([1, {"foo": "bar", "baz": "qux"}])
    tokens = tokenize_json(data)

# Generated at 2022-06-24 11:02:38.829190
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.api import tokenize

    from .tests.utils import get_error_message_positions
    test_json = '{"foo": true, "bar": null, "batz": 12}'
    tokens = tokenize(test_json)

    schema = Schema(
        {"foo": String(), "bar": Integer(), "batz": Integer(allow_null=True)}
    )
    errors = get_error_message_positions(lambda: validate_with_positions(token=tokens[0], validator=schema))

# Generated at 2022-06-24 11:02:46.758764
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(type="string")

    class Team(Schema):
        members = Field(type="array", items=Person)

    # We need this dummy token, but we don't really use it.
    token = Token([]).add_key("members").push([])

    person = {
        "name": "Jane Doe",
    }
    item_token = token.add_key(-1).push(person)
    validate_with_positions(token=item_token, validator=Person)

    invalid_person = {
        "age": 1,
    }
    item_token = token.add_key(-1).push(invalid_person)

# Generated at 2022-06-24 11:02:53.938798
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem import fields, schemas

    from .test_fields import Person, get_person_schema

    schema = get_person_schema()

    # Error at root level
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=tokenize({"age": "twenty"}), validator=schema
        )
    assert exc_info.value.messages[0].text == "Expected a valid integer."
    assert exc_info.value.messages[0].start_position == (1, 8)
    assert exc_info.value.messages[0].end_position == (1, 14)
    assert exc_info.value.messages[0].index == ()

# Generated at 2022-06-24 11:03:02.134565
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Array, Integer

    counter = [0]

    class MySchema(Schema):
        numbers = Array(items=Integer())

        def validate(self, data):
            counter[0] += 1
            return super().validate(data)

    schema = MySchema()

    token = Token(key="numbers", value=[1, 2, 3])
    validate_with_positions(token=token, validator=schema.fields["numbers"])
    assert counter == [1]

    token = Token(key="numbers", value=[1, None, 3])
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=schema.fields["numbers"])
    assert counter == [1]

# Generated at 2022-06-24 11:03:09.552274
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test valid data.
    class TestValidator(Field):
        def validate(self, value: str) -> str:
            if value == "bar":
                return value
            else:
                raise ValidationError(
                    [
                        Message(
                            code="invalid",
                            text="Expected the value 'bar'.",
                            index=[],
                            start_position=None,
                            end_position=None,
                        )
                    ]
                )

    token = Token(
        ["foo", "bar"],
        [
            Token(value="foo", start=0, end=1),
            Token(value="bar", start=2, end=3),
        ],
        start=0,
        end=3,
    )


# Generated at 2022-06-24 11:03:16.814403
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType

    from .gherkin import Feature


# Generated at 2022-06-24 11:03:25.581582
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Number
    from typesystem.tokenize.tokens import ObjectToken, TextToken

    token = ObjectToken(
        {
            "name": TextToken("hello"),
            "age": TextToken("hello"),
            "address": TextToken("hello"),
        },
        {
            "name": (0, 1),
            "age": (2, 3),
            "address": (4, 5),
        },
        parent=None,
    )
    schema = Schema(
        {
            "name": Field(required=True),
            "age": Number(),
            "address": Field(required=True),
        }
    )
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        messages = error.messages()


# Generated at 2022-06-24 11:03:34.760243
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field()
    token = Token(value="a value", start=1, end=1)
    result = validate_with_positions(token=token, validator=field)
    assert result == "a value"

    # Exceptions should be re-raised with positional error messages
    field.validators = [lambda v: False]
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)
    assert len(exc_info.value.messages()) == 1
    message = exc_info.value.messages()[0]
    assert message.text == "This value does not match the expected data type."

# Generated at 2022-06-24 11:03:44.127021
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import JSONSchema, INTSchema

    with pytest.raises(ValidationError):
        validate_with_positions(
            token=Token(value={"value": {"a": {"b": 1}}, "name": "test"}),
            validator=JSONSchema(
                {
                    "properties": {
                        "value": {"properties": {"a": {"properties": {"b": {"type": "number"}}}}}
                    }
                }
            ),
        )

    with pytest.raises(ValidationError):
        validate_with_positions(
            token=Token(value={"value": {"a": {"b": 1}}, "name": "test"}),
            validator=INTSchema(min_value=10),
        )


# Generated at 2022-06-24 11:03:57.092818
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.fields import String
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.exceptions import TokenError

    with pytest.raises(
        ValidationError,
        match=(r"^ValidationError: \n"
               r"The field 'name' is required.\n"
               r"\n"
               r"At: Line 1, Column 2.$"),
    ):
        validate_with_positions(token=tokenize(''), validator=String(required=True))

    with pytest.raises(
        ValidationError,
        match=r"^ValidationError: \n"
              r"This field is required.\n"
              r"\n"
              r"At: Line 1, Column 2.$",
    ):
        validate_with

# Generated at 2022-06-24 11:04:03.944969
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest

    from typesystem.tokenize import parse
    from typesystem.number import Number
    from typesystem.schemas import Structure

    token = parse('{"foo":1}')
    structure = Structure({"foo": Number()})
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=structure)

    assert excinfo.value.messages()[0].start_position.column == 2
    assert excinfo.value.messages()[0].start_position.line == 0

# Generated at 2022-06-24 11:04:13.078857
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Integer

    token = Token(value={"age": 42, "name": "brian"}, position=None)
    person = Schema(properties={"age": Integer(minimum=18), "name": String()})

    person.validate(token.value)
    assert validate_with_positions(token=token, validator=person) == token.value

    token = Token(value={"age": 17, "name": "brian"}, position=None)
    person = Schema(properties={"age": Integer(minimum=18), "name": String()})

    with pytest.raises(ValidationError) as error:
        person.validate(token.value)  # required
    assert validate_with_positions(token=token, validator=person) == token.value
    assert error.value.mess

# Generated at 2022-06-24 11:04:21.165254
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from json import loads
    from typesystem.tokenize import tokenize
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class User(Schema):
        email = String(max_length=100)

    for input_text, error_text in (
        ('{"email": ""}', "value is too short"),
        ('{"email": "foo"}', "value is too short"),
        ('{"email": "foo@example.org"}', "value is too short"),
        ('{"email": "foo@example.org@example.org"}', "value is too long"),
    ):
        token_list = tokenize(input_text)
        token_dict = token_list[0]

# Generated at 2022-06-24 11:04:31.391057
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String

    schema = String(min_length=2)

    # Invalid Token
    token = Token(
        value={}, start=Position(line_index=0, char_index=0), end=Position(line_index=0, char_index=1)
    )
    error = ValidationError(
        messages=[
            Message(
                index=[],
                code="type_error",
                text="Expected a string but got {}".format(type(token.value).__name__),
            )
        ]
    )
    with pytest.raises(ValidationError, match=str(error)):
        validate_with_positions(token=token, validator=schema)

    # Valid Token

# Generated at 2022-06-24 11:04:41.226104
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object
    from typesystem.fields import Field

    class Person(Object):
        name = Field()

    class AddressBook(Object):
        people = Field(array_of=Person)

    token = Token(
        "value",
        {
            "people": [
                {"name": "Eric Idle"},
                {"age": 20},
                {"name": "John Cleese"},
            ]
        },
        start_position=None,
        end_position=None,
        start_fraction=0,
        end_fraction=1,
    )


# Generated at 2022-06-24 11:04:52.103192
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_string

    class Person(Schema):
        name = Field(type=str, required=True)
        age = Field(type=int, required=True)

    token = tokenize_string('{"name": "Foo", "age": "string"}', "<string>")

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=Person)

    # The tokenize module adds this function as an attribute to a Token
    # instance, so we retrieve the function from the token.
    assert token.lookup is not None

    assert excinfo.value.messages()[0].text == "The field 'age' is not of type 'integer'."
    assert excinfo.value.messages()[0].index == (1,)


# Generated at 2022-06-24 11:05:05.038585
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, Object

    class Schema(Object):
        field = Integer()

    class Schema2(Object):
        field = Integer(required=True)

    class Schema3(Object):
        field = Integer(default=1)

    # Normal field
    assert validate_with_positions(
        token=Token("""{"field": 123}""", 0), validator=Schema,
    ) == {"field": 123}
    assert validate_with_positions(
        token=Token("""{"field": "123"}""", 0), validator=Schema,
    ) == {"field": 123}

    # Optional fields
    assert validate_with_positions(
        token=Token("""{"field": null}""", 0), validator=Schema,
    ) == {}
    assert validate_with_positions

# Generated at 2022-06-24 11:05:13.759303
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.jsonschema import Schema as JsonSchema
    from typesystem.tokenize.tokens import Token
    from tests.support.tokens import make_token, TokenWithValue

    class AuthorSchema(JsonSchema):
        title = "Author"

        class Options:
            fields = {
                "name": "string",
                "age": "number",
                "friends": {"type": "list", "items": {"$ref": "#"}},
            }

    author = make_token(TokenWithValue({"name": "Alice"}))

    author_schema = AuthorSchema()
    validate_with_positions(token=author, validator=author_schema)

    invalid_author = make_token(TokenWithValue({"name": 1}))

# Generated at 2022-06-24 11:05:22.995672
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String

    validator = String()

    class Article(Schema):
        title = String()
        body = String()

    token = Token(
        "root",
        {"title": "My title", "body": "My body"},
        start=Position(1, 1, 1),
        end=Position(3, 1, 2),
    )

    assert validate_with_positions(token=token, validator=Article) == token.value

    try:
        validate_with_positions(token=token, validator=validator)
        assert False, "Expected ValidationError"
    except ValidationError as error:
        for message in error.messages():
            print(message.start_position, message.end_position, message.text)

    # TODO: add more unit tests for this function
   

# Generated at 2022-06-24 11:05:33.184558
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.lexical import StringToken
    from typesystem.tokenize.lexical import StringSource
    from typesystem.fields import String

    class Foo(Schema):
        property = String()

    token_value = {"property": "bar"}
    token = StringToken(StringSource("", ""), token_value, (1, 0))
    try:
        validate_with_positions(token=token, validator=Foo)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.index == ["root", "property"]
        assert message.start_position.line_number == 2
        assert message.start_position.char_index == 8
    else:
        assert False, "Should have raised exception"

# Generated at 2022-06-24 11:05:41.565665
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import structure, text
    from typesystem.tokenize.base import Token

    class State(structure.Structure):
        name = text.Text(required=True)
        postcode = text.Text(required=True)
        cities = structure.Structure(fields={"name": text.Text()})
        cities.many = True


# Generated at 2022-06-24 11:05:51.352243
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Import is here to avoid circular imports
    from typesystem.tokenize import Token, lex, lex_string

    # Unit test for function lex

    def test_lex():
        text = """
        {
            "name": "John Doe",
            "age": 42
        }
        """
        token_types = [
            Token.LEFT_BRACE,
            Token.STRING,
            Token.COLON,
            Token.STRING,
            Token.COMMA,
            Token.STRING,
            Token.COLON,
            Token.NUMBER,
            Token.RIGHT_BRACE,
        ]
        for token, token_type in zip(lex_string(text), token_types):
            assert token.token_type == token_type

    test_lex()

# Generated at 2022-06-24 11:06:02.518968
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.test_positions import InvalidInputWithPositions
    from tests.test_positions import InvalidToken, BaseSchema, MySchema

    token = InvalidToken()
    validator = MySchema()
    try:
        validate_with_positions(token=token, validator=validator)
    except InvalidInputWithPositions as error:
        message = error.messages()[0]
        assert message.code == "required"
        assert message.index == ["my_field"]
        assert message.start_position.line == 2
        assert message.start_position.char_index == 6

    error = message.text
    assert error == "The field 'my_field' is required."

    message = error.messages()[1]
    assert message.code == "required"

# Generated at 2022-06-24 11:06:12.171716
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Foo(Schema):
        bar = Field(type=int)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=Token(
                "foo.bar",
                [
                    Token("foo", {}, start_char=0, end_char=1),
                    Token("bar", "baz", start_char=2, end_char=5),
                ],
                start_char=0,
                end_char=5,
            ),
            validator=Foo(),
        )

# Generated at 2022-06-24 11:06:17.076931
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(str)

    token = Token(value=None)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages() == [Message(code="required", text="The field 'name' is required.")
]
from typesystem.fields import Field



# Generated at 2022-06-24 11:06:27.259599
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    token = Token(
        value={"foo": "bar"},
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 3, "column": 6, "char_index": 14},
    )

    try:
        validate_with_positions(validator=String(), token=token)
    except ValidationError as error:
        assert len(error.messages()) == 1

        message = error.messages()[0]
        assert message.text == "Expected a string, but got a dictionary."
        assert message.start_position == {"line": 1, "column": 1, "char_index": 0}
        assert message.end_position == {"line": 3, "column": 6, "char_index": 14}

    nested_token

# Generated at 2022-06-24 11:06:35.637352
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Token, Tokenizer
    from typesystem.tokenize.tokens import INLINE_TOKEN_TYPE_MAP
    from typesystem.schemas import Schema
    from typesystem.fields import String

    schema = Schema({String(name="name")})

    text = """
    {
        "name": 123
    }
    """
    tokenizer = Tokenizer(text=text, token_type_map=INLINE_TOKEN_TYPE_MAP)
    tokens = tokenizer.tokenize()
    token = tokens[0]
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        messages = error.messages()
        message = messages[0]

# Generated at 2022-06-24 11:06:46.319546
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    # Error message with no index
    s = String()
    field = Field()
    field.validators.append(lambda v: raise_validation_error("test error"))
    token = Token("", "", "", "")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)
    assert [
        Message(
            text="test error",
            code="required",
            index=(),
            start_position=token.start,
            end_position=token.end,
        )
    ] == exc_info.value.messages()

    # Error message with index
    s = String()
    field = Field()

# Generated at 2022-06-24 11:06:55.074252
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import SourceToken

    # Test that a ValidationError with positional data is returned when the
    # validator fails
    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(
            token=SourceToken(
                start={"index": 0, "line": 1, "column": 1},
                end={"index": 1, "line": 1, "column": 2},
                value={"foo": ""},
            ),
            validator=Schema({"foo": Field(name="foo")}),
        )

    # Test that the ValidationError correctly relays positional information
    # from both the schema and the source token
    messages = error_info.value.messages()
    assert len(messages) == 1
    message = messages[0]


# Generated at 2022-06-24 11:07:05.465363
# Unit test for function validate_with_positions
def test_validate_with_positions():
    if not hasattr(tokenize, "tokenize"):
        return

    from typesystem import types

    class Person(Schema):
        name = types.String(required=True)
        age = types.Integer(required=True, minimum=18)

    validator = Person()
    token = tokenize.tokenize("{}")
    token = tokenize.build_tree(token)

    try:
        validate_with_positions(
            token=token, validator=types.String(required=True)
        )
    except ValidationError as error:
        assert error.messages()[0].start_position.char_index == 1
        assert error.messages()[0].end_position.line_number == 1
        assert error.messages()[1].start_position.char_index == 4
        assert error

# Generated at 2022-06-24 11:07:17.345537
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type="string")
    token = Token(
        "",
        value="abc",
        # Here we are going to pretend start is at the end
        # and end is at the start, in order to detect if the
        # logic is using the correct order.
        start=Token.Position(line=1, column=2, char_index=5),
        end=Token.Position(line=1, column=1, char_index=1),
    )
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(validator=field, token=token)
        for message in exc.value.messages():
            assert message.code == "required"
            assert message.text == "The field None is required."
            assert message.start_position.line == 1

# Generated at 2022-06-24 11:07:23.129610
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import sys

    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.tokenize.lexers import create_lexer
    from typesystem.tokenize.util import TokenStream
    from typesystem.schemas import Schema, fields

    sys.path.append(".")
    python_lexer = create_lexer("py")
    token_stream = TokenStream(
        python_lexer, "import typesystem", filename="<stdin>"
    )

    class ValidationError(Exception):
        def __init__(self, message=""):
            self.message = message

    class MyField(fields.Field):
        def validate(self, value):
            if value == "typesystem":
                raise ValidationError("You cannot import typesystem!")
            return value


# Generated at 2022-06-24 11:07:32.893952
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.exceptions import SchemaError
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Document, ValueToken
    from typesystem.types import String

    schema = Schema({}, additional_properties=False)

    token = ValueToken(Document({}), "", (0, 0), (0, 1))
    try:
        validate_with_positions(token=token, validator=schema)
    except SchemaError as error:
        message = error.messages[0]
        assert message.start_position.char_index == 0
        assert message.end_position.char_index == 1

        assert isinstance(str(error), str)

    token = ValueToken(Document({}), "", (0, 0), (0, 1))

# Generated at 2022-06-24 11:07:43.785924
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.types import Integer
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.positions import Position, CharPosition

    schema = Integer(required=True)
    tokens = tokenize("")

    try:
        validate_with_positions(token=tokens, validator=schema)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field required is required.",
                code="required",
                index=(),
                start_position=Position(
                    line=1, column=1, char_index=0, line_starts=[0]
                ),
                end_position=Position(
                    line=1, column=1, char_index=0, line_starts=[0]
                ),
            )
        ]

# Generated at 2022-06-24 11:07:54.175332
# Unit test for function validate_with_positions
def test_validate_with_positions():  # noqa
    from typesystem.tokenize.schema import TokenizerSchema

    class Query(Schema):
        foo = Field(str)

    query_schema = TokenizerSchema(token_schema=Query)
    query_token = query_schema.validate(
        [{"foo": 1}, {"foo": 2}, {"foo": 3}, {"foo": 1}]
    )

    try:
        query_schema.validate({"foo": 1})  # type: ignore
        assert False, "should raise ValidationError"
    except ValidationError as e:
        assert len(e.messages()) == 1
        message = e.messages()[0]
        assert message.code == "required"
        assert str(message) == "The field 'foo' is required."


# Generated at 2022-06-24 11:08:05.513175
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typing import Any, Union
    from typesystem.base import Message
    from typesystem.fields import Field
    from typesystem.schemas import Schema
    from typesystem.tokenize.lexer import lexer
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.util import tokenize_string


# Generated at 2022-06-24 11:08:13.323312
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem._tokenize.lexer.tokenize import iter_tokens
    from typesystem._validation.validators import Object
    from typesystem.compat import Literal, Text, Union

    to_validate = {"hello": "world", "foo": "bar"}
    tokens = list(iter_tokens(to_validate))
    token = tokens[0]

    class MySchema(Object):
        hello = Text()
        foo = Union[Literal[None], Text]()
        foo.allow_null = Fals

# Generated at 2022-06-24 11:08:22.134050
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import SourcePosition
    from typesystem.exceptions import ValidationError
    from typesystem.fields import String, Integer, Array

    text = '{"foo": [1, "bar"]}'
    tokens = json.loads(text)
    root = Token("root", value=tokens)

# Generated at 2022-06-24 11:08:30.965859
# Unit test for function validate_with_positions
def test_validate_with_positions():
    value = {
        "a": {"b": {"c": [{"d": 1}, {"d": 2}]}, "e": {"f": ["g"]}},
        "h": {"i": {"j": [1, 2, 3]}, "k": {"l": [{"m": "n"}, {"o": "p"}]}},
    }

    try:
        from typesystem.tokenize.validators import tokenize_value

        validator = Schema(fields={"a": Schema(fields={"b": Schema(fields={"c": Schema(fields={"d": Field(required=True)})})})})
        validate_with_positions(token=tokenize_value(value), validator=validator)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error

# Generated at 2022-06-24 11:08:37.789635
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize

    class JsonSchema(Schema):
        name = "object"
        properties = {"x": {"name": "integer"}}

    schema = JsonSchema()

    tokens = tokenize("{ }")
    value = validate_with_positions(token=tokens[0], validator=schema)
    assert value == {}

    tokens = tokenize("{ 'x': 0 }")
    value = validate_with_positions(token=tokens[0], validator=schema)
    assert value == {"x": 0}

    tokens = tokenize("{ 'x': 0.5 }")

# Generated at 2022-06-24 11:08:49.585700
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # This token contains nothing so the validator should throw an error
    token = Token(start_offset=1, value=None)
    field = Field(required=True)
    error = None
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as e:
        error = e

    assert len(error.messages()) == 1
    message = error.messages()[0]

    assert message.text == "The field None is required."
    assert message.code == "required"
    assert message.index == (None,)
    assert message.start_position.char_index == 1
    assert message.start_position.line_index == 0
    assert message.end_position.char_index == 1
    assert message.end_position.line_index == 0

    # This

# Generated at 2022-06-24 11:08:57.782058
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    from .conftest import MySchema

    schema = MySchema()
    token = tokenize("""
    {"a": 2}
    """)

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        messages = error.messages()
        # assert messages[0].start_position.line == 2
        # assert messages[0].start_position.char_index == 4
        # assert messages[0].end_position.line == 2
        # assert messages[0].end_position.char_index == 5
        assert messages[0].text == "Value '2' is not a valid string."



# Generated at 2022-06-24 11:09:07.860648
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """Test function validate_with_positions."""
    # noinspection PyUnresolvedReferences
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize

    class ExampleSchema(Schema):
        name = Field(type=str, required=True)
        age = Field(type=int, required=False)

    token = tokenize("{}")
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=ExampleSchema())
    assert exc.value.messages[0].text == (
        "The field 'name' is required."
    )  # type: ignore
    assert exc.value.messages[0].start_position.line == 1  # type: ignore

# Generated at 2022-06-24 11:09:14.165929
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        value="foo",
        start=(0, 0, 0),
        end=(0, 3, 3),
    )
    field = Field(type=str, min_length=5)
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "Ensure this value has at least 5 characters (it has 3)."
        assert message.start_position == token.start
        assert message.end_position == token.end

# Generated at 2022-06-24 11:09:25.315178
# Unit test for function validate_with_positions
def test_validate_with_positions():

    tree = Token({"f": Token("hello", start=(1, 3), end=(1, 8))})
    field = Field(str, required=True)

    # Case: No errors occur
    try:
        validate_with_positions(token=tree.lookup("f"), validator=field)
    except ValidationError:
        raise AssertionError("validate_with_positions raised an error even though no errors occured")

    # Case: An error occurs
    try:
        validate_with_positions(token=tree.lookup("g"), validator=field)
    except ValidationError as error:
        for message in error.messages():
            if isinstance(message, Message):
                assert message.code == "required"
                assert message.start_position.char_index == 1
                assert message.end_

# Generated at 2022-06-24 11:09:34.456032
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize import parse
    from typesystem.tokenize.tokens import ObjectToken

    input = "{}"
    schema = Schema(fields={"hello": String(min_length=10)})
    tokens = parse(input, start="object")
    token = ObjectToken(begin=0, end=len(input), children=tokens)
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'hello' is required."
        assert message.start_position.line_index == 0
        assert message.start_position.char_index == 0
        assert message

# Generated at 2022-06-24 11:09:39.546867
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class MyField(Field):
        description = 'A field'

        def validate(self, value):
            if value == 'fail':
                raise ValidationError([Message('The field failed', code='failed')])
            return value

    class MySchema(Schema):
        my_field = MyField(default='hello')

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=Token('hello', start=Position(char_index=0), end=Position(char_index=5)),
            validator=MySchema,
        )


# Generated at 2022-06-24 11:09:50.075096
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.fields import String
    from typesystem.schemas import Structure

    class Address(Structure):
        full_name = String()
        street = String()

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=tokenize('{"full_name": "Alyssa P. Hacker"}'),
            validator=Address,
        )

    assert len(exc_info.value.messages) == 1
    assert exc_info.value.messages[0].start_position.line == 0
    assert exc_info.value.messages[0].start_position.char_index == 15
    assert exc_info.value.messages[0].end_position.line == 0
    assert exc_

# Generated at 2022-06-24 11:09:59.589554
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Tokenizer

    class Person(Schema):
        name = Field(str)
        age = Field(str)

    tokenizer = Tokenizer(
        tokens=[
            Token(name="object", value={"name": "Joe", "age": "a"}),
        ]
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=tokenizer.tokens[0], validator=Person
        )
