

# Generated at 2022-06-24 11:00:00.243117
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.tokenize.string import tokenize
    from typesystem.json_schema import fields, schemas

    with pytest.raises(ValidationError) as exc_info:
        token = tokenize(json.dumps({"foo": "foo"}))
        validate_with_positions(token=token, validator=schemas.Schema)

    messages = exc_info.value.messages

    assert messages[0].text == "The field 'bar' is required."
    assert messages[0].start_position == (1, 7)
    assert messages[0].end_position == (1, 7)

    assert messages[1].text == "The field 'baz' is required."
    assert messages[1].start_position == (1, 7)
    assert messages[1].end_position

# Generated at 2022-06-24 11:00:10.017042
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Boolean, Integer
    from typesystem.schemas import Object, Array
    from typesystem.tokenize import tokenize

    token = tokenize('{"foo":42, "bar": true, "missing": null}')

    validator = Object({
        "foo": Integer(),
        "bar": Boolean(),
    })

    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as error:
        assert len(error.messages()) == 1
        assert error.messages()[0].text == "The field 'missing' is required."
        assert error.messages()[0].start_position.char_index == 10
        assert error.messages()[0].end_position.char_index == 21

# Generated at 2022-06-24 11:00:19.054524
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class PersonSchema(Schema):
        first_name = Field(types=str)
        last_name = Field(types=str)

    instance = """
        {
            "first_name": "John"
        }
    """
    tokens = list(tokenize(instance))
    token = Token(tokens, [])
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=PersonSchema)
    assert str(exc_info.value) == "Wrong number of keys. Expected 2, found 1."

    message = exc_info.value.messages()[0]
    assert message.text == "Wrong number of keys. Expected 2, found 1."

# Generated at 2022-06-24 11:00:26.504042
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokenizer import Tokenizer

    tokenizer = Tokenizer()
    token = tokenizer.tokenize(content='{"foo": "bar"}')

    field = String(name="foo", required=True)
    validate_with_positions(token=token, validator=field)  # No error raised

    try:
        validate_with_positions(token=(), validator=field)
    except ValidationError as error:
        message = error.messages[0]
        assert message.code == "required"
        assert message.text == "The field 'foo' is required."

# Generated at 2022-06-24 11:00:27.004370
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-24 11:00:39.179785
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import ObjectToken, StringToken

    string_token_0 = StringToken(
        value="",
        start=0,
        end=0,
        index=None,
        parent=None,
        parent_index=None
    )

    string_token_1 = StringToken(
        value="",
        start=1,
        end=1,
        index=None,
        parent=None,
        parent_index=None
    )

    string_token_2 = StringToken(
        value="",
        start=2,
        end=2,
        index=None,
        parent=None,
        parent_index=None
    )


# Generated at 2022-06-24 11:00:45.264273
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(required=True, max_length=3)
        age = Field(required=True)

    token = Token(
        {
            "name": "Bob",
            "age": 30,
        }
    )

    validate_with_positions(token=token, validator=Person)



# Generated at 2022-06-24 11:00:52.952344
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Number
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.exceptions import TokenizeError

    class MySchema(Schema):
        foo = String()
        bar = Number()

    token = tokenize({"foo": "bar"})
    try:
        validate_with_positions(token=token, validator=MySchema)
    except TokenizeError as error:
        assert error.messages() == [
            Message(
                text="The field 'bar' is required.",
                code="required",
                index=["bar"],
                start_position=4,
                end_position=4,
            )
        ]

# Generated at 2022-06-24 11:01:01.974259
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """Test that error message has positional information."""

    from typesystem import Any, Bool, DateTime, Integer, String
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize
    from typesystem.validators import Length

    class Person(Schema):
        name = String()
        age = Integer()
        is_creator = Bool(optional=True)

    class MySchema(Schema):
        person = Person()
        title = String(validators=[Length(max=10)])
        date = DateTime()
        info = Any()

    class MySchema2(Schema):
        person = Person()
        title = String(validators=[Length(max=10)])
        date = DateTime()
        info = Any()


# Generated at 2022-06-24 11:01:10.697083
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import fields as typesystem_fields
    from typesystem import schemas as typesystem_schemas

    class PersonSchema(typesystem_schemas.Schema):
        name = typesystem_fields.String()

    person_schema = PersonSchema()
    token = Token(
        kind="object",
        value={"name": "James Bond"},
        start={"line": 0, "char": 0},
        end={"line": 1, "char": 0},
        lookup=lambda path: Token(
            kind="string",
            value="James Bond",
            start={"line": 1, "char": 5},
            end={"line": 1, "char": 17},
        ),
    )

# Generated at 2022-06-24 11:01:13.524748
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object, String

    schema = Object(properties={"foo": String()})
    value = {"foo": "bar"}

    result = validate_with_positions(
        token=Token(value=value, start=Token.Position(1, 4), end=Token.Position(1, 13)),
        validator=schema,
    )
    assert result == value



# Generated at 2022-06-24 11:01:26.116090
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.parser import parse_schema

    schema = parse_schema("""
    {
        "items": {
            "items": [
                {"id": "uuid", "name": "str", "answer": 42},
                {"id": "uuid", "name": "str", "answer": 42},
                {"id": "uuid", "name": "str", "answer": 42},
                {"id": "uuid", "name": "str", "answer": 42},
            ]
        }
    }
    """)
    assert validate_with_positions(
        token=schema, validator=validate_with_positions
    )
    assert schema.errors()
    token = schema.errors()[0].token
    assert token.start.line == 2
    assert token.start.column == 10


# Generated at 2022-06-24 11:01:36.725930
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import Token
    from tests.tokenize import Position
    from typesystem.fields import Integer
    from typesystem.tokenize.messages import ValidationError
    from tests.tokenize import assert_messages


# Generated at 2022-06-24 11:01:45.147737
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer

    from .tokenize import tokenize, token_type_iter
    from .tokenize.tokens import Token

    from .parser.ast import AST
    from .parser.operators import Operator
    from .parser.parser import parse

    from .lex import lex

    from .exceptions import ParserError

    from dataclasses import dataclass

    @dataclass
    class Position:
        line_number: int
        char_index: int

    @dataclass
    class Source:
        name: str
        text: str

        def __post_init__(self):

            self.tokens = list(tokenize(text=self.text))

# Generated at 2022-06-24 11:01:55.007948
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from string import ascii_letters
    import random
    import inspect

    import typesystem
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema

    class ExampleSchema(Schema):
        field1 = Integer()
        field2 = String()

    # We need to add a sentinel character to the stream of input
    # to help with determining the end_position.
    ascii_letters += "¶"

    def generate_random_input(schema: typesystem.Schema, max_string_len: int = 50):
        """
        Generate random input for a given schema.

        """
        fields = schema.fields.values()
        if fields:
            # Choose a field randomly.
            field = random.choice(list(fields))

# Generated at 2022-06-24 11:02:06.269423
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import (  # noqa: WPS433
        Tokenize,
    )
    from typesystem import Text, Integer  # noqa: WPS433

    schema = Schema({
        "foo": Text(min_length=1),
        "bar": Text(),
        "baz": Integer(minimum=0),
    })

    tokenize = Tokenize()

    try:
        validate_with_positions(token=tokenize(""), validator=schema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert str(message) == "The field 'foo' is required."
        assert message.code == "required"
        assert message.start_position.line == 1
        assert message.start_

# Generated at 2022-06-24 11:02:10.336631
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem

    class PersonSchema(typesystem.Schema):
        name = typesystem.String(required=True)

    token = Token(value={}, start={}, end={})
    with pytest.raises(typesystem.ValidationError) as error:
        validate_with_positions(token=token, validator=PersonSchema)

    assert error.value.messages()[0].start_position == {
        "line": 1,
        "col": 1,
        "char_index": 0,
    }

# Generated at 2022-06-24 11:02:19.905364
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.functions import validate_with_positions
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token, PathToken
    from typesystem.serializers.json import JSONSerializer
    from typesystem.schemas import Schema
    from typesystem.base import ValidationError, Message

    schema = Schema({"name": String(required=True)})
    serializer = JSONSerializer()

    data = {
        "name": None,
        "children": [
            {"name": None},
            {"name": None},
            {"name": None},
            {"name": None},
            {"name": None},
        ],
    }
    token = Token(value=data, serializer=serializer, create_path_token=PathToken)


# Generated at 2022-06-24 11:02:28.387280
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import Tokenizer, TextTokenizer
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError

    class MySchema(Schema):
        name = String(required=True)

    tokenizer = Tokenizer(schema=MySchema(), tokenizer=TextTokenizer())

    try:
        validate_with_positions(token=tokenizer(""), validator=MySchema())
    except ValidationError as error:
        message = error.messages()[0]
        assert message.start_position.line_number == 1
        assert message.start_position.char_index == 1
        assert message.end_position.line_number == 1
        assert message.end_position.char_index == 0


# Unit

# Generated at 2022-06-24 11:02:39.244716
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import parse_tokens
    from typesystem.tokenize.tokens import Empty, String, TokenList

    from typesystem.fields import String as StringField

    class User(Schema):
        name = StringField()

    token_list = parse_tokens('{"name": "matt"}')
    assert isinstance(token_list, TokenList)
    assert len(token_list) == 1
    token = token_list[0]
    assert validate_with_positions(
        token=token, validator=User
    ) == {"name": "matt"}

    token_list = parse_tokens('{"name": "matt", "age": 12}')
    assert isinstance(token_list, TokenList)
    assert len(token_list) == 1
    token

# Generated at 2022-06-24 11:02:50.885287
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    # No validation errors
    token = Token({"name": "Joe", "age": 6}, start=5, end=10)
    value = validate_with_positions(token=token, validator=Person)
    assert value == {"name": "Joe", "age": 6}

    # Field not found
    token = Token({"namee": "Joe", "age": 6}, start=5, end=10)
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()
        assert all(message.start_position == 5 for message in error.messages())

# Generated at 2022-06-24 11:03:03.024744
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # type: () -> None
    from typesystem import Schema, fields

    class FooSchema(Schema):
        bar = fields.Field(required=True)
        baz = fields.Field(required=True)

    tokenizer = Tokenizer(start=Position(line=1, char_index=1), value={"bar": 3})
    with pytest.raises(ValidationError) as ei:
        validate_with_positions(validator=FooSchema, token=tokenizer)
    messages = ei.value.messages()
    assert messages[0].code == "required"
    assert messages[0].text == 'The field "baz" is required.'
    assert messages[0].start_position.line == 1
    assert messages[0].start_position.char_index == 3



# Generated at 2022-06-24 11:03:10.142290
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer

    class TestSchema(Schema):
        a = Integer(required=True)
        b = String()

    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token

    x = tokenize(
        {
            "a": 1,
            "b": 2,
        }
    )
    with pytest.raises(ValidationError):
        validate_with_positions(token=x, validator=TestSchema())

    x = tokenize(
        {
            "a": 1,
            "b": "hello",
        }
    )
    validate_with_positions(token=x, validator=TestSchema())


# Generated at 2022-06-24 11:03:16.827978
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        validate_with_positions(
            token=Token(value={"foo": 42}),
            validator=Schema(fields={"foo": Field()}),
        )
    except ValidationError as error:
        assert len(error.messages()) == 1
        error = error.messages()[0]
        assert error.text == "The field 'bar' is required."
        assert error.start_position.line_number == 1
        assert error.start_position.line_index == 0
        assert error.start_position.char_index == 1
        assert error.end_position.line_number == 1
        assert error.end_position.line_index == 0
        assert error.end_position.char_index == 5
        assert error.code == "required"

# Generated at 2022-06-24 11:03:25.617619
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String
    from typesystem.tokenize.tokens import Object, String as StringToken

    def assert_positional_error(
        token: Token,
        validator: typing.Union[Field, typing.Type[Schema]],
        expected_message: str,
        code: str = None,
        *,
        start_line=None,
        start_column=None,
    ):
        if isinstance(expected_message, Exception):
            expected_message = str(expected_message)
        with pytest.raises(ValidationError) as exc_info:
            validate_with_positions(token=token, validator=validator)
        message = exc_info.value.messages[0]
        assert message.text == expected_message

        if code:
            assert message.code == code



# Generated at 2022-06-24 11:03:34.797730
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import (
        Array,
        Integer,
        Object,
        String,
    )
    from typesystem.tokenize.objects import (
        create_tokens,
        Position,
    )
    from typesystem.utils import validate_schema
    from typesystem.validators import (
        one_of,
        validate_not_blank,
    )

    schema: typing.Dict[str, typing.Any] = {
        "name": String(validators=[validate_not_blank]),
        "pages": Array(
            items=Object(
                {"number": Integer(validators=[validate_not_blank]), "title": String()}
            )
        ),
    }

    class Book(Schema):
        title = String(validators=[validate_not_blank])


# Generated at 2022-06-24 11:03:44.167769
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        {
            "name": "Alice",
            "age": "",
            "height": "",
            "weight": {
                "foo": "bar",
                "baz": [],
            },
        },
        start_position=Position(filename="test.py", line_number=1, line_offset=15),
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        error_messages = error.messages()

        assert len(error_messages) == 3

        assert error_messages[0].text == "'' is not a valid integer."

# Generated at 2022-06-24 11:03:57.092363
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parse_tokens import parse_tokens

    schema = Schema(type="object", properties={"foo": {"type": "string"}})

    token = parse_tokens(source_code=b'{"foo": 1}')
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    messages = exc_info.value.messages
    assert len(messages) == 1
    message = messages[0]
    assert message.text == "The field 'foo' is invalid."
    assert message.code == "invalid"
    assert message.start_position.line == 1
    assert message.start_position.char_index == 8
    assert message.end_position.line == 1
   

# Generated at 2022-06-24 11:04:05.758945
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest

    token = Token(
        {
            "name": {"first": "Joe", "last": "Bob"},
            "birthday": "2016-09-28T00:00:00Z",
            "favorite_color": "Red",
            "shoesize": 9.5,
        }
    )
    class MySchema(Schema):
        name = {"first": str, "last": str}
        birthday = datetime.date()
        favorite_color = str
        shoesize = float

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=MySchema)

# Generated at 2022-06-24 11:04:14.467079
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer")

    token = Token(
        value={
            "name": "Joshapi",
            "age": True,
        },
        start={"line_number": 5, "char_index": 2},
        end={"line_number": 9, "char_index": 3},
    )
    try:
        validate_with_positions(token=token, validator=Person)
        assert False, "should raise an error"
    except ValidationError as error:
        assert len(error.messages()) == 1

# Generated at 2022-06-24 11:04:21.937429
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import validate_with_positions
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.types import Integer
    import yaml

    yaml_str = """
    - a
    - b: 1
    - c:
      - d: foo
      - e:
        - f: 2
        - g: 3
    - h:
      - i: 4
    """
    assert tokenize(yaml.safe_load(yaml_str)) == Token.from_yaml(yaml_str)

    class MySchema(Schema):
        a = Integer()
        b = Integer()
        c = Schema(a=Integer(), b=Integer())


# Generated at 2022-06-24 11:04:31.966311
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import types
    from typesystem.tokenize import tokenize

    def validate(s):
        # type: (str) -> typing.Tuple[typing.Any, typing.List[Message]]
        field = types.String()  # type: Field
        schema = type(
            "TestSchema", (Schema,), {"name": field, "age": field, "height": field}
        )
        # type: typing.Type[Schema]
        tokens = tokenize(s)
        value = validate_with_positions(token=tokens[0], validator=schema)
        return value, tokens
    # no errors
    value, tokens = validate('{"name": "josh", "age": "30", "height": "5/10"}')

# Generated at 2022-06-24 11:04:38.940116
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer

    token = Token(value=10, start=0, end=1)
    assert validate_with_positions(token=token, validator=Integer) == 10

    token = Token(value="", start=0, end=1)
    try:
        validate_with_positions(token=token, validator=Integer)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field <root> is required."
        assert message.code == "required"
        assert message.index == []
        assert message.start_position.line_index == 0
        assert message.start_position.char_index == 0
        assert message.end_position.line_index == 0
        assert message.end_position.char_index == 1

# Generated at 2022-06-24 11:04:47.051955
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize, Token

    schema = Field(type="string")


# Generated at 2022-06-24 11:04:56.054547
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import ObjectToken, StringToken
    from typesystem.fields import String
    from typesystem.schemas import Object

    class String(String):
        def error_message(self, token, value) -> str:
            return f"The field {token.name!r} has no value."

    class Object(Object):
        field = {
            "foo": String(required=True),
            "bar": String(required=True),
        }

    token = ObjectToken.from_mapping({"bar": ""})
    with pytest.raises(ValidationError) as exc_info:
        print(validate_with_positions(token=token, validator=Object))
    exc = exc_info.value

    assert len(exc.messages()) == 2
    start, end = exc

# Generated at 2022-06-24 11:05:01.517084
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Token
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import validate_with_positions
    from typesystem.fields import String, Integer

    class TestSchema(Schema):
        text = String()
        number = Integer()

    validator = TestSchema()
    token = Token(
        value={
            "text": "Hello World",
            "missing": "field",
            "number": "not a number",
        },
        start=(0, 0),
        end=(0, 0),
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=validator)

    assert 3 == len(exc_info.value.messages)

# Generated at 2022-06-24 11:05:06.621814
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Boolean
    from typesystem.tokenize import tokenize

    data = {"field": True}
    token = tokenize(data)
    try:
        validate_with_positions(token=token.get(["field"]), validator=Boolean())
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        message = messages[0]
        assert message.text == "This field is required."
        assert message.start_position.position == (1, 7)
        assert message.end_position.position == (2, 3)
    else:
        assert False, "ValidationError not raised"

# Generated at 2022-06-24 11:05:10.268696
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    token = tokenize({"field": "a"})
    field = Field(type="string", required=True)
    validate_with_positions(token=token.lookup(["field"]), validator=field)



# Generated at 2022-06-24 11:05:15.721038
# Unit test for function validate_with_positions
def test_validate_with_positions():
    v1 = {"type": "string", "minLength": 2}
    assert validate_with_positions(token={}, validator=v1) == {}

    v2 = {
        "type": {"type": "object"},
        "properties": {
            "a": {"type": "integer"},
        },
    }
    token = {
        "a": 1,
        "b": 3,
    }
    assert validate_with_positions(token=token, validator=v2) == token

    v3 = {"type": "object"}
    assert validate_with_positions(token={}, validator=v3) == {}

# Generated at 2022-06-24 11:05:25.517190
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.base import ValidationError
    from typesystem.fields import String
    from typesystem.fields.compound import List, Object
    from typesystem.tokenize import Token, TokenizeError
    from typesystem.tokenize.tokens import Token

    # Setup test data
    schema = Object(
        {
            "a": String(),
            "b": String(required=True),
            "c": Object({"d": String(required=True)}),
            "e": List(String(), required=True),
        }
    )
    document = {
        "a": "Hello",
        "c": {"d": "Hello"},
        "e": ["Hello", "World"],
        "f": "Hello",
    }
    token = Token.from_object(document)

    # Test validation with

# Generated at 2022-06-24 11:05:31.785916
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token

    class MySchema(Schema):
        field1 = String(required=True)
        field2 = String(required=True)


    class RootToken(Token):
        field1 = Token(value="foo")
        field2 = Token(value="bar")


    token = RootToken()
    validate_with_positions(token=token, validator=MySchema)

# Generated at 2022-06-24 11:05:38.415571
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    assert tokenize("[]") == Token("json", [])
    assert validate_with_positions(
        token=tokenize("[]"), validator=Field(name="field", type=list)
    ) == []

    assert validate_with_positions(
        token=tokenize("'string'"), validator=Field(name="field", type=list)
    ) == ["string"]

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(
            token=tokenize("'string'"), validator=Field(name="field", type=int)
        )
    message = excinfo.value.messages[0]
    assert message.index == ("field",)
    assert message.text == "Expected an integer."

# Generated at 2022-06-24 11:05:44.975951
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    from typesystem.fields import String
    from typesystem.tokenize.positions import Position
    from typesystem.tokenize.tokens import Token

    data = """{"foo": 2, "bar": "x"}"""
    token = Token.from_data(data, schema={"foo": String(), "bar": String()})
    try:
        validate_with_positions(token=token, validator=String())
    except ValidationError as error:
        message = error.messages()[0]
        assert message.code == "required"
        assert message.text == "The field 'bar' is required."
        assert message.start_position == Position(
            line=1,
            column=0,
            char_index=0,
            line_text=data.splitlines()[0],
        )


# Generated at 2022-06-24 11:05:55.463616
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.lexer import lex
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.utils import Position

    schema = Schema(properties={"check_me": {"type": "string"}})

    def validate(value: str) -> typing.Any:
        token = Token(
            value=value,
            start=Position(char_index=2, line_index=1, line_offset=2),
            end=Position(char_index=3, line_index=1, line_offset=3),
        )
        return validate_with_positions(token=token, validator=schema)

    assert validate('{"check_me": "ok"}') == {"check_me": "ok"}


# Generated at 2022-06-24 11:06:03.993023
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, String  # type: ignore
    from typesystem.tokenize.lexers import lex_json
    from typesystem.tokenize.parsers import parse_json  # type: ignore
    from typesystem.tokenize.tokens import Token, TokenType  # type: ignore

    schema = Schema(
        {"foo": String(min_length=2), "bar": Integer()}, required=["foo"]
    )

    INPUT = """{"foo": "hey"}"""
    TOKENS = lex_json(INPUT)
    ROOT = parse_json(TOKENS)

    try:
        validate_with_positions(token=ROOT, validator=schema)
    except ValidationError as error:
        assert len(error.messages()) == 1

# Generated at 2022-06-24 11:06:13.274821
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_json
    from typesystem.schemas import Schema

    class Pet(Schema):
        type = "string"
        name = "string"
        age = "integer"

    class Person(Schema):
        name = "string"
        pets = ["object", [Pet]]

    root_token = tokenize_json('{"name": "frank", "pets": [{"age": "3"}]}')
    assert (
        validate_with_positions(token=root_token, validator=Person)
        == {"name": "frank", "pets": [{"age": 3}]}
    )

    root_token = tokenize_json('{"name": "frank", "pets": [{"age": "3"}]}')

# Generated at 2022-06-24 11:06:16.713931
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(_value={"key1": "value1"}, path=["obj"])

    class MySchema(Schema):
        key1: str
        key2: str

    assert validate_with_positions(token=token, validator=MySchema)

# Generated at 2022-06-24 11:06:26.849274
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.token_types import TokenType
    from typesystem.tokenize.tokens import ArrayToken, ObjectToken

    class FieldWithPosition(Field):
        def validate_with_positions(self, token):
            return validate_with_positions(
                token=token, validator=self
            )

    class SchemaWithPosition(Schema):
        def validate_with_positions(self, token):
            return validate_with_positions(
                token=token, validator=self
            )


# Generated at 2022-06-24 11:06:27.813016
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-24 11:06:35.792607
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    token = tokenize("{'a': 1, 'b': None}")

    class SampleSchema(Schema):
        a = Field(type="integer", required=True)
        b = Field(type="boolean")

    validate_with_positions(token=token, validator=SampleSchema)

    token = tokenize("{'a': '1', 'b': None}")

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=SampleSchema)

    error = exc.value.messages[0]
    assert error.start_position == token.lookup(index=["a"]).start
    assert error.end_position == token.lookup(index=["a"]).end
    assert error

# Generated at 2022-06-24 11:06:46.470301
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, Object, String

    class SchemaA(Schema):
        a = Integer(required=True)

    class SchemaB(Schema):
        b = String()

    class SchemaC(Schema):
        c = Object(properties={"a": SchemaA(), "b": SchemaB()})

    assert validate_with_positions(
        token=Token(
            type_="object",
            value={"c": {"a": {"a": "hello"}, "b": {"b": {"one": 1, "two": 2}}}},
        ),
        validator=SchemaC(),
    ) == {
        "c": {
            "a": {"a": 1},
            "b": {"b": {"one": "1", "two": "2"}},
        }
    }

# Generated at 2022-06-24 11:06:51.940209
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    token = tokenize("""{
        "a": 1,
        "b": 2,
        "c": 3,
        "d": 4,
        "required": "",
        "foo": "bar"
    }""")

    schema = Schema({"a": Field(int), "required": Field(str, required=True)})

    validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-24 11:06:56.093162
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import RawTokenizer
    from typesystem.tokenize import tokenize

    tokenizer = RawTokenizer()
    value = {"a": 2, "b": [1, 2, 3], "c": {"d": "e"}}
    tokens = tokenize(tokenizer, value)
    assert validate_with_positions(token=tokens, validator=Schema()) == value

# Generated at 2022-06-24 11:07:06.309166
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from io import StringIO
    from typesystem.tokenize.tokenizer import Tokenizer

    class Document(Schema):
        title = Field(type="string", required=True)
        body = Field(type="string", default=None)

    data = """
    {
        "title": "hello",
    }
    """

    tokenizer = Tokenizer(stream=StringIO(data))
    token = tokenizer.tokenize()

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=Document)


# Generated at 2022-06-24 11:07:17.530990
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.tokenize.parser import parse_string
    from typesystem.schemas import Object
    from typesystem import fields
    from pyrsistent import pmap

    class AlbumSchema(Schema):
        title = fields.String(required=True)
        tracks = fields.List(fields.Integer())
        type = fields.String()

    def test_raise():
        token = parse_string("{}")
        schema = AlbumSchema()
        with pytest.raises(ValidationError) as exc:
            validate_with_positions(token=token, validator=schema)
        error_messages = exc.value.messages()
        assert len(error_messages) == 1
        message = error_messages[0]

# Generated at 2022-06-24 11:07:25.789437
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import schema, schema_decorator
    from typesystem.fields import Array, Dict, String, Integer

    class ShallowSchema(Schema):
        name = String()
        age = Integer()

    @schema_decorator
    def deeper_schema():
        return {
            'name': String(),
            'friends': Array(Dict({'name': String()}))
        }

    @schema_decorator
    def nested_schema():
        return {
            'name': String(),
            'details': schema(ShallowSchema),
            'other_details': schema(deeper_schema)
        }


# Generated at 2022-06-24 11:07:33.156549
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    # Setup
    class Item(Schema):
        name = Field(str)

    # Run code to be tested
    try:
        validate_with_positions(
            token=tokenize(data={"x": "foo", "y": "bar"}), validator=Item()
        )
    except ValidationError as error:
        actual = error.messages()

# Generated at 2022-06-24 11:07:43.851623
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import Schema as TypesystemSchema # noqa: F401
    from typesystem.tokenize.parser import parse_token
    from typesystem.schemas import Dict
    from typesystem.fields import String

    class Person(TypesystemSchema):
        name = String(required=True)

    class AddressBook(TypesystemSchema):
        address_book = Dict(
            fields={
                "person": Person,
            },
            required=True,
        )

    def check_validation_position(text, *, error_index=0):
        token = parse_token(text)
        try:
            validate_with_positions(token=token, validator=AddressBook)
        except ValidationError as e:
            assert e.messages[error_index].end_position.line == 1

# Generated at 2022-06-24 11:07:54.257988
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import StringToken
    from typesystem.assertions import Equals
    from typesystem.fields import String

    token = StringToken(
        '"test"',
        start_position=StringToken.Position(line=1, column=1, char_index=0),
        end_position=StringToken.Position(line=1, column=6, char_index=5),
    )

    # Test with a simple validator
    validator = Equals("test")
    assert validate_with_positions(token=token, validator=validator) == "test"

    # Test with a field that contains the Equals validator
    validator = String(validators=[Equals("test")])
    assert validate_with_positions(token=token, validator=validator) == "test"



# Generated at 2022-06-24 11:07:54.831938
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-24 11:08:05.984310
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Array, Object

    class MySchema(Schema):
        a = String(min_length=5)
        b = Array[String](required=False)
        c = Array[Object](required=False, properties={"d": String(max_length=3)})

    token = Token.parse(
        {"a": "This is fine", "b": ["This is fine", "This is too long"], "c": [{"d": "ok"}]}
    )

    with pytest.raises(ValidationError) as err:
        validate_with_positions(token=token, validator=MySchema())

    messages = sorted(err.value.messages(), key=lambda m: m.start_position.line)


# Generated at 2022-06-24 11:08:13.594953
# Unit test for function validate_with_positions
def test_validate_with_positions():
    with pytest.raises(ValidationError):
        validate_with_positions(
            token=Token(
                [
                    "nested",
                    "and",
                    "nested",
                    "string",
                    "not",
                    "required",
                    "and",
                    "this",
                    "is",
                    "a",
                    "string",
                ],
                "hello",
            ),
            validator=_field,
        )
        # assert 0 == 1


_field = Field(typing.Optional[str])

# Generated at 2022-06-24 11:08:22.340418
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class User(Schema):
        name = String(max_length=10)
        age = Integer()

    data = '{"age": 15}'
    token = tokenize(data)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=User)
    [message] = exc_info.value.messages
    assert message.text == "The field 'name' is required."
    assert message.code == "required"
    assert message.index == ["name"]
    assert message.start_position.line == 0
    assert message.start_position.char_index == 0
    assert message.end_position

# Generated at 2022-06-24 11:08:31.783951
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Use the parser to create some tokens:
    from typesystem.tokenize.tests.test_tokenize import tokenize

    t = tokenize(
        '{"name": ""}',
        fields={"name": {"type": "string", "required": True}},
    )
    # Check it works without positional errors:
    validate_with_positions(token=t.root, validator=Schema)
    # Check it works with positional errors:
    try:
        validate_with_positions(
            token=t.root, validator={"type": "string", "required": False}
        )
    except ValidationError as error:
        positional_message = list(error.messages())[0]
        assert positional_message.start_position == (1, 18)

# Generated at 2022-06-24 11:08:40.039368
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import JsonPointer, JsonToken
    from typesystem.tokenize.tokens import StartPosition, EndPosition

    json_pointer = JsonPointer.from_parts(["$", "items", 0, "title"])
    start_position = StartPosition(line=1, column=5, char_index=5)
    end_position = EndPosition(line=1, column=6, char_index=6)
    token = JsonToken(
        json_pointer=json_pointer,
        start=start_position,
        end=end_position,
        value="a",
    )

    error_message_text = "'a' is too short"
    error_message_code = "min_length"


# Generated at 2022-06-24 11:08:50.616683
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class BookSchema(Schema):
        title = Field(required=True)
        price = Field(required=True, type="integer")
        authors = Field(array=True)

        class Meta:
            strict = False
            allow_unknown = True

    tree = Token(
        value={
            "title": "The Art of Computer Programming",
            "price": 100,
            "authors": ["Donald Knuth"],
            "published_date": "1968-01-01",
        }
    )
    with raises(ValidationError) as exc_info:
        validate_with_positions(token=tree, validator=BookSchema())

# Generated at 2022-06-24 11:09:01.122142
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tokenize import tokenize
    from typesystem.tokenize import tokenize_python_value
    from typesystem.tokenize.tokens import PythonToken

    def test(expression: str, *, value: typing.Any, errors: typing.List[str]):
        if isinstance(value, typing.List):
            value = [PythonToken(token) for token in tokenize(value[0].encode())]
        else:
            value = PythonToken(tokenize(value.encode())[0])


# Generated at 2022-06-24 11:09:10.946345
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import Text
    import numpy

    class TokenType(Schema):
        token_type = Text()

    class TokenReference(Schema):
        reference = Text(required=True)

    class TokenSchema(Schema):
        token_type = Text(required=True)
        token_reference = TokenReference()

    from typesystem.tokenize.parse import parse

    token = parse(
        """
[
    {
        "token_type": "apple",
    },
    {
        "token_type": "banana",
        "token_reference": {
            "reference": "grape"
        }
    }
]
"""
    )


# Generated at 2022-06-24 11:09:19.893782
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize.parser import parse_token

    try:
        validate_with_positions(token=parse_token("{x: 2}"), validator=Integer())
    except ValidationError as error:
        text = str(error)
    assert text == """\
Invalid JSON.

1. {"x": 2}
                  ^
   Error: Expected a dictionary.

2. {"x": 2}
      ^
   Error: Expected the key "x" to be a string.

3. {"x": 2}
         ^
   Error: Expected an integer.

Use the --verbose flag for more details."""

# Generated at 2022-06-24 11:09:30.306261
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import requests

    class Request(Schema):
        method = Field(type=str)

    # This makes it easy to test functionality with a token that is
    # invalid because it is missing a field.
    token = Token(
        {
            "method": "GET",
            "url": "https://example.com",
            "headers": {"User-Agent": "typesystem"},
        }
    )
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=Request)

    res = requests.get("https://example.com")


# Generated at 2022-06-24 11:09:37.158490
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest

    from typesystem.tokenize.tokens import LineTokenizer, ErrorToken

    validator = Field(name="field", type_="string", required=True)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=LineTokenizer("foo", None).tokenize()[0], validator=validator
        )
    assert not exc_info.value.messages()[0].start_position.line_number
    assert exc_info.value.messages()[0].start_position.char_index == 0
    assert exc_info.value.messages()[0].end_position.line_number == 0
    assert exc_info.value.messages()[0].end_position.char_index == 3


# Generated at 2022-06-24 11:09:47.532202
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer

    class UserSchema(Schema):
        name = String()
        age = Integer()

    class LoginSchema(Schema):
        username = String()
        password = String(required=True)

    class OrganizationSchema(Schema):
        name = String()
        users = LoginSchema(many=True)

    class MessageSchema(Schema):
        user = UserSchema()
        organization = OrganizationSchema()

    data = {
        "user": {"name": "Harry", "age": 36},
        "organization": {"name": "Pokerface", "users": [{}]},
    }

    schema = MessageSchema()
    token = Token(data, start=(0, 0), end=(0, 0))

# Generated at 2022-06-24 11:09:56.852238
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from json import loads
    from typesystem.schemas import Schema, fields
    from ..tokenize.mmap import mmap_tokenize

    class ProductSchema(Schema):
        description = fields.String(min_length=2)
        in_stock = fields.Boolean()

    # test: json decoding
    token = mmap_tokenize(b'{"description": "", "in_stock": true}', "json")
    try:
        validate_with_positions(token=token, validator=ProductSchema)
    except ValidationError as error:
        assert error.messages()[0].text == 'Shorter than minimum length 2.'
        assert error.messages()[0].start_position == token.start
        asse