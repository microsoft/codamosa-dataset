

# Generated at 2022-06-24 11:00:01.433748
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.exceptions import SchemaError
    from typesystem.schemas import Schema
    from typesystem.tokenize.parser import parse_string

    class MySchema(Schema):
        foo = Field(type="string")

    tree = parse_string(
        """
        foo: 1234
        bar: "baz"
        """,
        schema_class=MySchema,
    )

    with pytest.raises(SchemaError) as exc_info:
        validate_with_positions(token=tree, validator=MySchema)

    message = exc_info.value.messages[0]
    assert message.text == 'The field "foo" is required.'
    assert message.code == "required"
    assert message.start_position.char_index == 0
    assert message.end_

# Generated at 2022-06-24 11:00:11.104072
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import Tokenizer
    from typesystem.tokenize.tokens import ArrayToken
    from typesystem.tokenize.tokens import ObjectToken
    from typesystem.tokenize.tokens import StringToken
    from unittest.mock import MagicMock
    import click

    class TestTokenizer(Tokenizer):
        def __init__(self, data: str):
            super().__init__(data)
            self.token_class = MagicMock()
            self.token_class.return_value = self.tokens[0]

        def _split(self, data: str):
            self.tokens = []
            for index, c in enumerate(reversed(data)):
                token = StringToken(data, index, index + 1)
                self.tokens

# Generated at 2022-06-24 11:00:20.092671
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import io
    import json
    import typesystem

    schema = typesystem.Schema(properties={"prop": True})

    json_text = b"""
    {
        "prop": 123
    }
    """.strip()

    json_text_with_errors = b"""
    {
        "prop2": 123
    }
    """.strip()

    errors = []
    json_text_with_errors_no_positions = b"""
    {
        "prop": 123,
        "prop2": 123
    }
    """.strip()

    result = validate_with_positions(
        token=schema.token(json.loads(json_text)), validator=schema
    )
    assert result == {"prop": 123}


# Generated at 2022-06-24 11:00:27.060788
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import ObjectToken
    from typesystem.fields import String
    import typesystem
    # This can be an arbitrary string of JSON
    json_string = '{ "name": "Bob", "age": "20" }'
    token = ObjectToken.from_json(json_string)
    result = typesystem.validate_with_positions(token=token, validator=typesystem.Schema(
        fields={
            "name": String,
            "age": String,
        }
    ))
    assert result == {"name": "Bob", "age": "20"}


# Generated at 2022-06-24 11:00:34.963159
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import Tokenizer
    from typesystem.tokenize.text import TextTokenizer
    from typesystem.tokenize.json import JsonTokenizer
    from typesystem.tokenize.yaml import YamlTokenizer
    from typesystem.tokenize.toml import TomlTokenizer

    from typesystem.fields import Integer, String

    field = Integer(required=True)

    for tokenize in [
        Tokenizer,
        TextTokenizer,
        JsonTokenizer,
        YamlTokenizer,
        TomlTokenizer,
    ]:
        with pytest.raises(ValidationError) as exc_info:
            token = tokenize.parse_string("")
            validate_with_positions(token=token, validator=field)

        messages = exc_info.value.messages()


# Generated at 2022-06-24 11:00:40.565302
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.json import JSON

    # Generate a token tree
    token = Token.parse(JSON, {"title": "The title"})

    class BookSchema(Schema):
        title = Field(String())

    # Validate the token tree
    validate_with_positions(
        token=token, validator=BookSchema()
    )

# Generated at 2022-06-24 11:00:50.838787
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Boolean, String, Integer
    from typesystem.schemas import Structure

    class User(Structure):
        name = String()
        age = Integer()
        active = Boolean()

    token = Token(data={
        "name": "Hans",
        "age": "5",
        "active": True,
    },
        start={
            "line": 2,
            "column": 3,
            "char_index": 5,
        },
        end={
            "line": 6,
            "column": 7,
            "char_index": 19,
        },
    )

    # All fields are valid
    validate_with_positions(token=token, validator=User)

    # Empty token
    token = Token(data={}, start=None, end=None)

# Generated at 2022-06-24 11:01:03.430014
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import NullToken, Token

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    try:
        validate_with_positions(
            token=NullToken(
                start=Token.StartPosition(line=1, char_index=0),
                end=Token.EndPosition(line=1, char_index=0),
                value={},
            ),
            validator=Person,
        )
    except ValidationError as error:
        messages = error.to_primitive()

    message = messages[0]
    assert message["text"] == "The field 'name' is required."
    assert message["code"] == "required"
    assert message["index"] == ["name"]

# Generated at 2022-06-24 11:01:10.439942
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse_text

    class MySchema(Schema):
        field_1 = Field()

    class MySchema2(Schema):
        field_1 = MySchema

    token = parse_text("{}", MySchema2)

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=MySchema2)
    assert "The field 'field_1' is required." in str(excinfo.value)
    assert (
        excinfo.value.messages()[0].start_position.char_index == 2
    )  # type: ignore

# Generated at 2022-06-24 11:01:10.834991
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-24 11:01:20.258523
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Tokens
    from typesystem.types import IntegerField

    tokens = Tokens.parse(
        input_text='{"field": "test"}', raw_input_text='{"field": "test"}'
    )
    field = IntegerField()
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens.children[0].children[1], validator=field)
    assert (
        exc_info.value.messages()[0].start_position.line_index == 0
    )
    assert (
        exc_info.value.messages()[0].start_position.char_index == 14
    )

# Generated at 2022-06-24 11:01:31.351679
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """Test helper function."""
    import pytest
    from typesystem.tokenize.tokens import DictionaryToken


# Generated at 2022-06-24 11:01:39.421893
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.json_schema import Object
    import typesystem
    from typesystem.tokenize import tokenize

    class Movie(typesystem.Object):
        title = typesystem.String(required=True)
        genre = typesystem.String(required=True, enum=["action", "horror"])
        year = typesystem.Integer(minimum=1900, maximum=2020)
        director = typesystem.String()

    schema = Movie()

    movie = {
        "title": "Avengers: Endgame",
        "genre": "action",
        "year": 2019,
        "director": "Anthony Russo",
    }

    movie_json = json.dumps(movie, sort_keys=True)
    tokens = tokenize(movie_json)
    token = tokens[0]

# Generated at 2022-06-24 11:01:46.533028
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from unittest import mock

    token = mock.Mock()
    token.value = object()
    token.start.line_index = 1
    token.start.char_index = 2
    token.end.line_index = 3
    token.end.char_index = 4

    validator = mock.Mock()
    validator.validate.side_effect = ValidationError(
        [Message("Error", index=[0, "foo"])]
    )

    token.lookup.return_value = mock.Mock()
    token.lookup.return_value.start.line_index = 5
    token.lookup.return_value.start.char_index = 6
    token.lookup.return_value.end.line_index = 7

# Generated at 2022-06-24 11:01:54.977747
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.primitives import String
    from typesystem.exceptions import ValidationError
    from typesystem.tokenize.positions import Position

    string = '{"foo": "bar"}'

    tokens = tokenize(string)

    value = validate_with_positions(token=tokens[0], validator=String())
    assert value == string

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=tokens[1], validator=String())
    messages = exc.value.messages
    assert len(messages) == 1
    assert messages[0].start_position == Position.from_dict({'line': 1, 'column': 2})

# Generated at 2022-06-24 11:02:06.229822
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize, Token
    from typesystem.schemas import Schema
    from typesystem.fields import Field

    class OrderItemSchema(Schema):
        name = Field(required=True)
        quantity = Field(required=True, type="integer")
        price = Field(required=True, type="number")

    class OrderSchema(Schema):
        items = Field(required=True, type="list", items=OrderItemSchema)


# Generated at 2022-06-24 11:02:10.615524
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schema import Schema
    from typesystem.fields import String, Integer
    import typesystem
    class PetSchema(typesystem.Schema):
        name = String(required=True)
        age = Integer()
        weight = Integer()

    schema = PetSchema()
    token = Token({"name":"Gorilla"})
    validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-24 11:02:20.110906
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .syntax import (
        to_tokens,
        field,
        object_,
        array,
        string,
        integer,
        number,
        boolean,
        keyword,
    )


# Generated at 2022-06-24 11:02:28.579745
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.exceptions import ValidationError
    from typesystem.tokenize.tokens import Token

    class IntSchema(Field):
        def validate(self, value):
            try:
                return int(value)
            except ValueError:
                self.error("Invalid integer")

    class NameSchema(Field):
        def validate(self, value):
            if value != "sarah":
                self.error("Invalid name", code="invalid")

    schema = {"name": NameSchema(), "age": IntSchema()}
    json_string = '{"name": "sarah", "age": "thirty"}'
    token = Token.parse(json_string)

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert error

# Generated at 2022-06-24 11:02:39.378294
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    token = tokenize(
        """
        {
          "name": "Morty",
          "age": 13.5,
          "spouse": null
        }
    """
    )

    assert isinstance(token, Token)

    class CharacterSchema(Schema):
        age = Field(of=float)
        name = Field(of=str, required=True)
        spouse = Field(of=str, required=False)

    try:
        validate_with_positions(token=token, validator=CharacterSchema)
    except ValidationError as exc:
        messages = exc.messages()
        for message in messages:
            assert message.index is not None
            assert message.start_position is not None
            assert message.end_position is not None

# Generated at 2022-06-24 11:02:50.884127
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, List

    schema = Schema(fields={"title": String(), "age": Integer()})
    schema.validate_with_positions(
        value={
            "title": "Sherlock Holmes",
            "age": 19,
            "stuff": [{"n": 1, "c": 0}, {"n": 2, "c": 0}],
        }
    )

    schema = Schema(fields={"stuff": List(items=Schema(fields={"n": Integer()}))})
    try:
        schema.validate_with_positions(value={"stuff": [{"n": 1, "c": 0}]})
    except ValidationError as error:
        message = error.messages()[0]
        line = message

# Generated at 2022-06-24 11:03:03.025113
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.test_tokenize.test_tokens import TestToken
    token = TestToken("value", start_position=4, end_position=8)
    field = Field()
    assert field.validate("value") == "value"
    assert validate_with_positions(token=token, validator=field) == "value"
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Field(required=True))
    assert len(exc_info.value.messages) == 1
    message = exc_info.value.messages[0]
    assert message.text == 'The field "value" is required.'
    assert message.code == "required"
    assert message.index == ()
    assert message.start_position == token.start


# Generated at 2022-06-24 11:03:03.509326
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass  # TODO

# Generated at 2022-06-24 11:03:12.382566
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Integer, Array, Object
    from typesystem.tokenize.tokens import StringToken

    field = String(max_len=3)
    token = StringToken(start=(1, 2), end=(1, 4), value="foo")
    assert validate_with_positions(token=token, validator=field) == "foo"

    field = String(max_len=1)
    token = StringToken(start=(1, 2), end=(1, 4), value="foo")
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=field)
    assert excinfo.value.messages[0].start_position == (1, 2)
    assert excinfo.value.messages[0].end_position == (1, 4)

# Generated at 2022-06-24 11:03:19.761133
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(
        {
            "a": Field(type="string", required=True),
            "b": Field(
                type="array",
                items=Field(
                    {
                        "c": Field(type="integer", required=True),
                        "d": Field(type="string", required=True),
                    }
                ),
            ),
        }
    )

    token = Token(
        "object",
        {
            "a": "value of a",
            "b": [{"c": 1, "d": "value of d"}],
        },
        (1, 1),
    )

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        messages = error.messages()
    assert len(messages) == 1

# Generated at 2022-06-24 11:03:28.160708
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import pytest
    from typesystem.tokenize.input_stream import InputStream
    from typesystem.tokenize.lexer import lex
    from typesystem.tokenize.tokens import Token
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Person(Schema):
        name = String(required=True)

    text = """{
        "name": "John",
    }"""
    tokens = lex(stream=InputStream(s=text))
    tree = tokens[0]
    validate_with_positions(token=tree, validator=Person)

    text = """{
        "age": 20,
    }"""
    tokens = lex(stream=InputStream(s=text))
    tree = tokens[0]

# Generated at 2022-06-24 11:03:37.522926
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Object, String
    from typesystem.fields import Array

    schema = Object({"items": Array(of=String())})
    token = tokenize({"items": ["a", 1, None]}, schema)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)


# Generated at 2022-06-24 11:03:46.857655
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from io import StringIO
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.tokenize.lexers import Lexer

    class JsonSchema(Schema):
        name = String()

    body = StringIO('{"name": ""}')
    lexer = Lexer(body)
    token = lexer.next_object()
    try:
        validate_with_positions(token=token, validator=JsonSchema())
    except ValidationError as error:
        assert error.messages()[0].start_position.line == 0
        assert error.messages()[0].end_position.line == 0
        assert error.messages()[0].start_position.char_index == 11
        assert error.messages()[0].end_position.char_

# Generated at 2022-06-24 11:03:57.912610
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer

    token = Token(
        value={
            "x": {"y": {"z": [{"main": 0}, {"main": "1"}, {"main": "two"}, {"main": "3"}]}}
        },
        start=Token.Position("file", 1, 1),
        end=Token.Position("file", 1, 100),
    )

    field = Integer(name="main", min_value=0, max_value=2)

    assert validate_with_positions(token=token, validator=field) == 0

    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 3


# Generated at 2022-06-24 11:04:01.433720
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_str
    from typesystem.fields import Integer

    token = tokenize_str('{"id": "42"}')
    token.lookup(["id"]).value = "foo"
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=Integer(required=True))
    assert len(exc.value.messages) == 1
    message = exc.value.messages[0]
    assert message.text == "Must be an integer."
    assert message.code == "type"
    assert message.index == ["id"]
    assert message.start_position == (1, 9)
    assert message.end_position == (1, 12)

# Generated at 2022-06-24 11:04:15.814469
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Thing(Field):
        regex = "[a-z]+"

    class Example(Schema):
        foo = Thing()

    from typesystem.tokenize import tokenize

    text = '{"foo": 5}'
    tokens = tokenize(text)
    data = tokens["data"]


# Generated at 2022-06-24 11:04:21.935925
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema

    class Invalid(Schema):
        name = Field()
        age = Field(validators=[int])

    test_data = {
        "name": "Tobias",
        "age": "A",
    }
    tokens = tokenize(test_data)

    try:
        validate_with_positions(token=tokens, validator=Invalid)
    except ValidationError as error:
        messages = []
        for message in error.messages:
            token = tokens.lookup(message.index)

# Generated at 2022-06-24 11:04:31.966143
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """
    validate_with_positions adds position information to errors.
    """
    from typesystem.tokenize.base import get_tokenizer
    from typesystem.tokenize.errors import TokenizeError

    tokenizer = get_tokenizer("json")

    class Author(Schema):
        name = Field(type="string", required=True)

    class Article(Schema):
        title = Field(type="string", required=True)
        author = Field(type="object", required=True, validators=[Author()])

    input_string = """{
      "title": "First article",
      "author": {
        "name": "Joe"
      }
    }"""

    with pytest.raises(TokenizeError) as excinfo:
        token = tokenizer.parse(input_string)
    assert excinfo.value

# Generated at 2022-06-24 11:04:38.940053
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.forms import Object
    from typesystem.mapping import Mapping
    from typesystem.schemas import Schema

    class Profile(Object):
        name = Field(required=True)

    class User(Object):
        profile = Field(validator=Profile)
        age = Field(str)

    class UserSchema(Mapping):
        email = Field(str)

    class Organization(Object):
        name = Field(str, required=True)

    class UserObject(Object):
        user = Field(User)
        organization = Field(Organization)

    class TestSchema(Schema):
        user = UserSchema(required=True)
        organizations = Field([Organization])


# Generated at 2022-06-24 11:04:47.051928
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.schemas import QuerySchema
    from typesystem.tokenize.tokens import StringToken

    class MySchema(QuerySchema):
        foo = Integer()


    query = "foo=bar"
    token = StringToken(value=query)
    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(validator=MySchema, token=token)
    message = error_info.value.messages[0]
    assert message.text == 'Not a valid integer.'
    assert message.start_position.line == 1
    assert message.start_position.char_index == 4
    assert message.end_position.line == 1
    assert message.end_position.char_index == 7

# Generated at 2022-06-24 11:04:49.383382
# Unit test for function validate_with_positions
def test_validate_with_positions():
    result = validate_with_positions(
        token=Token.parse("foo: 123"),
        validator=Field(type="integer", required=True),
    )
    assert result == 123

# Generated at 2022-06-24 11:04:57.638646
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parsers import LiteralParser, ObjectParser

    parser = ObjectParser(
        data={
            "foo": LiteralParser(),
            "bar": ObjectParser(
                data={
                    "baz": LiteralParser(),
                },
            ),
        },
    )

    token = parser.parse("{foo: 1, bar: {}}")

    # The following field is required
    try:
        validate_with_positions(
            token=token,
            validator=Field(type_=int, required=False),
        )
    except ValidationError as error:
        for message in error.messages():
            assert message.text == 'The field "bar.baz" is required.'
            assert message.code == "required"
            assert message.start_position.char_index == 11


# Generated at 2022-06-24 11:05:06.467057
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import Any, Integer, String
    from typesystem.tokenize import tokenize

    class MySchema(Schema):
        b = Integer()
        a = String()
        c = Any()

    try:
        validate_with_positions(
            token=tokenize("[1, 2"),
            validator=MySchema(),
        )
    except ValidationError as error:
        assert error.messages() == sorted(
            error.messages(), key=lambda m: m.start_position.line  # type: ignore
        )

# Generated at 2022-06-24 11:05:14.661406
# Unit test for function validate_with_positions
def test_validate_with_positions():

    hello_world_json = """{
        "hello": {
            "world": [
                "is",
                "cool"
            ]
        }
    }"""

    token = Token.parse(hello_world_json)

    class HelloWorldSchema(Schema):
        hello = Field(dict, fields={"world": Field(list, items=Field(str))})

    validate_with_positions(token=token, validator=HelloWorldSchema)

    assert "hello" in token
    token = token["hello"]
    assert "world" in token
    token = token["world"]
    assert len(token) == 2

    token = token[1]

# Generated at 2022-06-24 11:05:24.980525
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Book(Schema):
        title = Field(type=str)
        author = Field(type=str)

    @dataclass
    class Position:
        line: int
        char_index: int

    @dataclass
    class Token:
        value: typing.Any
        start: Position
        end: Position

        def lookup(self, key):
            return self

    with pytest.raises(ValidationError) as exc_info:
        token = Token(value={"title": "foo"}, start=Position(1, 0), end=Position(1, 4))
        validate_with_positions(token=token, validator=Book)


# Generated at 2022-06-24 11:05:34.195722
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize import Lexer
    from typesystem.tokenize.tokens import DocumentToken

    lexer = Lexer(schema={"name": String(min_length=1)})
    doc = DocumentToken.create(lexer=lexer, content={"name": "test"})
    validate_with_positions(token=doc, validator=lexer)

    doc = DocumentToken.create(lexer=lexer, content={"name": ""})
    with pytest.raises(ValidationError):
        validate_with_positions(token=doc, validator=lexer)

    doc = DocumentToken.create(lexer=lexer, content={})

# Generated at 2022-06-24 11:05:38.684227
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int, required=False)

    data = {"name": "Eric", "age": "invalid"}
    token = Token.from_native(data)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    errors = exc_info.value.messages
    start, end = errors[0].start_position, errors[0].end_position
    assert (start.line_number, start.char_index) == (1, 16)
    assert (end.line_number, end.char_index) == (1, 22)

    start, end = errors[1].start_position, errors[1].end_position

# Generated at 2022-06-24 11:05:39.097798
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-24 11:05:49.021999
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize.tokenizer import tokenize

    def assert_error(message: str, *, code: str, token: Token) -> None:

        message = Message(
            text=message,
            code=code,
            index=[],
            start_position=token.start,
            end_position=token.end,
        )
        assert ValidationError([message])

    integer = Integer()

    token = tokenize("abc", "abc")
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=integer)
    assert_error("Expected a valid integer.", code="invalid", token=token)

    token = tokenize("123", "123")

# Generated at 2022-06-24 11:06:00.241466
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.testing import String


# Generated at 2022-06-24 11:06:08.287834
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Integer, fields
    from typesystem.tokenize.tokens import ObjectToken, ScalarToken

    field = fields.Dict({
        "name": fields.String(),
        "age": fields.Integer(),
    })

    obj_token = ObjectToken(
        start=0,
        end=15,
        children={
            "name": ScalarToken(start=2, end=7, value="Alice"),
            "age": ScalarToken(start=10, end=12, value="32"),
        },
    )

    assert field.validate(obj_token.value) == {
        "name": "Alice",
        "age": 32,
    }


# Generated at 2022-06-24 11:06:18.222850
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import fields, schemas
    from typesystem.tokenize.tokens import Token

    class ParentSchema(schemas.Schema):
        name = fields.String()

    class ChildSchema(schemas.Schema):
        parent = ParentSchema()

    schema = ChildSchema()

    token = Token({"parent": {"name": "a"}}, 0, 1)
    validate_with_positions(token=token, validator=schema)

    # If name is missing, then the error should be raised with an
    # index and start_position.
    token = Token({"parent": {}}, 0, 1)
    with pytest.raises(ValidationError, match="1:1:1:1") as err:
        validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-24 11:06:28.115152
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema({"user": {"type": "string", "required": True}})
    input_ = {"b": "user"}
    token = Token(value=input_).lookup("a").lookup("b")

    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=token, validator=schema)

    error = error_info.value
    assert error.messages[0].text == "The field 'user' is required."
    assert error.messages[0].start_position.line_index == 2
    assert error.messages[0].start_position.char_index == 4
    assert error.messages[0].end_position.line_index == 2
    assert error.messages[0].end_position.char_index == 10

# Generated at 2022-06-24 11:06:32.414818
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import String

    string = String(min_length=5)

    token, _ = tokenize("hello")

    try:
        validate_with_positions(token=token, validator=string)
    except ValidationError as error:
        message = error.messages[0]
        assert message.index == []
        assert message.text == "Must have at least 5 characters."
        assert message.start_position.row == 0
        assert message.end_position.row == 0
        assert message.start_position.col == 0
        assert message.end_position.col == 4

# Generated at 2022-06-24 11:06:44.089248
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.test_tokenize_types import TestTypes, TestSchema

    token = Token(value={"a": "b"}, schema=TestTypes)
    validator = TestSchema()

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=validator)

    for message in exc.value.messages():
        assert message.text == "This field is required."
        if message.code == "required":
            assert message.start_position.line_number == 1
            assert message.start_position.char_index == 13
            assert message.end_position.line_number == 1
            assert message.end_position.char_index == 14
        elif message.code == "invalid_type":
            assert message.start_position.line_number == 1

# Generated at 2022-06-24 11:06:49.399001
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import Integer
    from typesystem.schemas import Schema

    class Users(Schema):
        age = Integer()

    json_string = "{'age': 'bad'}"
    tokens = tokenize(json_string)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens[0], validator=Users())
    assert isinstance(exc_info.value.messages[0], Message)
    assert exc_info.value.messages[0].start_position.char_index == 5
    assert exc_info.value.messages[0].end_position.char_index == 8

# Generated at 2022-06-24 11:06:57.191736
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token

    raw = '{"foo": "bar", "baz": {"quux": 123}}'
    token = Token.from_json(raw)

    try:
        validate_with_positions(token=token, validator=String())
    except ValidationError as error:
        message = error.messages[0]
        assert message.text.startswith("Expected a string.")

        start = message.start_position.char_index
        end = message.end_position.char_index
        snippet = raw[start:end]
        assert snippet == '"bar"'

    validate_with_positions(
        token=token.lookup(["baz", "quux"]), validator=String()
    )



# Generated at 2022-06-24 11:07:07.061996
# Unit test for function validate_with_positions
def test_validate_with_positions():

    # Setup
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position
    from typesystem.tokenize.streams import Stream
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer

    class TestSchema(Schema):
        s = String(required=True)
        i = Integer(required=True)

    text = """
    {
      "s": "x",
      "i": 1
    }
    """

# Generated at 2022-06-24 11:07:17.530760
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import Tokenizer
    from typesystem.tokenize.tokens import Token

    class Foo(Schema):
        foo = Field(type="string")
        bar = Field(type="string", required=True)

    tokenizer = Tokenizer()
    tokens = tokenizer.tokenize("{}")
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=Token.from_list(tokens), validator=Foo)
    assert error.value.messages() == [
        Message(
            text="The field 'bar' is required.",
            code="required",
            index=["bar"],
            start_position=(1, 1),
            end_position=(1, 1),
        )
    ]

# Generated at 2022-06-24 11:07:25.303747
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema

    schema = Schema({"a": Field(type="string", required=True)})
    valid_token = Token.object({"a": "hello"}, position=42)
    validate_with_positions(token=valid_token, validator=schema)
    invalid_token = Token.object({}, position=42)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=invalid_token, validator=schema)
    messages = exc_info.value.messages
    assert len(messages) == 1
    message = messages[0]
    assert message.start_position.char_index == 42



# Generated at 2022-06-24 11:07:32.722472
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.parser import parse
    from typesystem.tokenize.exceptions import TypeSystemError

    text = "def foo(): pass"
    result = parse(tokenize(text))
    assert isinstance(result, typing.Any)

    text = "def ()(): pass"
    with pytest.raises(TypeSystemError) as exc_info:
        parse(tokenize(text))

    assert len(exc_info.value.messages[0].start_position) == 4
    assert exc_info.value.messages[0].text == "Function name expected."

# Generated at 2022-06-24 11:07:43.784072
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    from typesystem.tokenize.parser import Parser
    from typesystem.tokenize.tokens import Token

    class MySchema(typesystem.Schema):
        field1 = typesystem.Integer(required=True)

    # Valid
    valid_tokens = Parser.parse("{field1:42}")
    assert len(valid_tokens) == 1
    assert validate_with_positions(token=valid_tokens[0], validator=MySchema) == {
        "field1": 42
    }

    # Invalid
    tokens = Parser.parse("{field1:hello}")
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=tokens[0], validator=MySchema)


# Generated at 2022-06-24 11:07:54.175835
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Schema
    from typesystem.tokenize.tokens import Object, String

    import json
    from textwrap import dedent

    schema = Schema({"name": String(min_length=3)})

    token = Object(
        {"name": String(value="kim", start=10, end=13)},
        start=0,
        end=19,
    )

    token = Object(
        {"name": String(value="kim", start=10, end=13)},
        start=0,
        end=19,
    )

    validate_with_positions(token=token, validator=schema)


# Generated at 2022-06-24 11:08:05.512574
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .examples import TodoSchema
    from .examples import with_positions

    todo_schema = TodoSchema()

    # Valid input
    todo = {"title": "Setup new project", "done": False}
    todo_token = with_positions.tokenize(todo)
    result = validate_with_positions(token=todo_token, validator=todo_schema)
    assert result == todo

    # Invalid input
    todo = {"title": "Setup new project", "done": "yep"}
    todo_token = with_positions.tokenize(todo)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=todo_token, validator=todo_schema)
    assert exc

# Generated at 2022-06-24 11:08:13.687765
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    from pydantic import BaseModel

    class Person(BaseModel):
        name: str

    class People(Schema):
        items = Person()

    token = tokenize("[{}]")
    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=token, validator=People)


# Generated at 2022-06-24 11:08:22.403337
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Boolean, Text
    from typesystem.tokenize.types import TokenType
    from typesystem.validators import min_length, required

    token = Token(TokenType.OBJECT, {}, 0, 0, 0, 0)
    token.children.append(Token(TokenType.KEY, "name", 0, 0, 0, 0))
    token.children.append(Token(TokenType.TEXT, "", 0, 0, 0, 0))

    field = Text(validators=[required(), min_length(1)])

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=field)


# Generated at 2022-06-24 11:08:31.858602
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import operator
    import typesystem

    field = typesystem.String(max_length=3)

    # Failure
    json_str = """{
        "a": "hello",
        "b": "world"
    }"""
    token = Token.from_json(json_str)
    token = token.lookup(["a"])

    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "String should not be longer than 3 characters."
        assert message.start_position.line == 1
        assert message.start_position.char_index == 9
        assert message.end_position.line == 1
        assert message.end_position.char_index == 15



# Generated at 2022-06-24 11:08:40.107538
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import String
    from typesystem.tokenize import tokenize

    schema = String(max_length=1)
    tokens = list(tokenize("Hello, world!"))

# Generated at 2022-06-24 11:08:50.667629
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer

    token = Token(
        value={"a": "1", "b": ""},
        start=Position(char_index=0, line_index=0),
        end=Position(char_index=9, line_index=0),
    )

    validator = {"a": Integer(), "b": Integer(required=True)}

    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as error:
        start_position, end_position = error.positions
        assert start_position == Position(
            char_index=4, line_index=0
        ), "start_position"
        assert end_position == Position(
            char_index=7, line_index=0
        ), "end_position"


# Generated at 2022-06-24 11:09:01.162268
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import String, Value

    schema = Schema({"name": String(min_length=1)})
    tokens = list(tokenize("{name:null}"))
    token = tokens[1]
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema.fields["name"])
    assert exc_info.value.messages() == [
        Message(
            text="The field 'name' must have at least 1 characters.",
            code="min_length",
            index=("name",),
            start_position=token.start,
            end_position=token.end,
        )
    ]



# Generated at 2022-06-24 11:09:10.981294
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type="string", pattern="[0-9]+")
    token = Token(
        value="foo", start={"line_number": 1, "char_index": 0}, end={"line_number": 1, "char_index": 3}
    )
    with pytest.raises(ValidationError) as e:
        validate_with_positions(token=token, validator=field)
    assert len(e.value.messages) == 1
    message = e.value.messages[0]
    assert message.text == 'Value does not match pattern "[0-9]+".'
    assert message.code == "pattern"
    assert message.start_position == {"line_number": 1, "char_index": 0}

# Generated at 2022-06-24 11:09:21.590258
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Token

    class User(Schema):
        name = Field(type=str)
        age = Field(type=int)

    class UserWithOptionalAge(User):
        age = Field(type=int, required=False)

    @validate_with_positions.register(Field)
    def validate_field_with_positions(
        *, token: Token, validator: typing.Union[Field, typing.Type[Schema]]
    ) -> typing.Any:
        assert isinstance(validator, Field)

# Generated at 2022-06-24 11:09:25.652709
# Unit test for function validate_with_positions
def test_validate_with_positions():


    class TestSchema(Schema):
        name = "string"

    schema = TestSchema()
    schema.validate_with_positions = validate_with_positions
    with pytest.raises(ValidationError, match="The field 'name' is required."):
        schema.validate(None)

# Generated at 2022-06-24 11:09:34.622793
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokens

    # Basic validation
    token = tokens.StringToken(value="string")
    field = Field(type="string")
    assert validate_with_positions(token=token, validator=field) == "string"

    # Missing field
    token = tokens.StringToken(value="string")
    field = Field(type="string", required=True)
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=field)
    assert error.value.messages() == [Message(code="required", text="Required.")]

    # Invalid string
    token = tokens.StringToken(value="string")
    field = Field(type="string", pattern="^(foo|bar)")

# Generated at 2022-06-24 11:09:42.814245
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Tokenizer
    from typesystem.tokenize.tokens import NullToken, StrToken
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class TestSchema(Schema):

        token = String(required=True)

    tokenizer = Tokenizer()
    token = tokenizer.tokenize("test")

    schema = TestSchema()
    schema.validate_with_positions(token=token)

    token = NullToken()
    token.start = tokenizer.position()
    token.end = tokenizer.position()
    try:
        schema.validate_with_positions(token=token)
    except ValidationError as error:
        messages = list(error.messages())
        assert messages[0].start_position.byte_index == 0


# Generated at 2022-06-24 11:09:47.770959
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Array, String
    from typesystem.tokenize import tokenize

    schema = Array(items=String())
    token = tokenize(schema, ["x", "y", "z"], path="root")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    assert exc_info.value.messages[0].start_position.char_index == 0
    assert exc_info.value.messages[1].start_position.char_index == 2
    assert exc_info.value.messages[2].start_position.char_index == 4

# Generated at 2022-06-24 11:09:56.149116
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.run import tokenize

    from typesystem.fields import Integer

    class UserSchema(Schema):
        id = Integer()

    tokens = tokenize(
        {
            "id": "12",
            "username": "jane",
            "email": "jane@example.com",
            "age": None,
        }
    )

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=tokens, validator=UserSchema)
    assert excinfo.value.messages()[0].start_position.line == 3

