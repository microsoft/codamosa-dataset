

# Generated at 2022-06-24 10:59:55.723476
# Unit test for function validate_with_positions
def test_validate_with_positions():
    tok = Token(
        root_value={"a": {"b": {"c": [{"d": 1, "e": 2}, {"f": 3, "g": 4}]}}},
        start=SourcePosition(char_index=0),
        end=SourcePosition(char_index=12345),
    )
    value = validate_with_positions(
        token=tok.lookup("a", "b", 0, "e"),
        validator=Field(type="integer", required=True),
    )
    assert value == 2

# Generated at 2022-06-24 11:00:03.330553
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.lexers import JsonLexer
    from typesystem.tokenize.token_types import JsonToken

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = JsonLexer().lex("{}")  # type: ignore
    assert token == JsonToken(
        type="dict", value={}, start_position=None, end_position=None,
    )

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-24 11:00:12.274198
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import tokens_from_file
    from typesystem.tokenize.ast import parse
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.schemas.base import _DeferredField

    class MySchema(Schema):
        foo = String(required=True)

    MySchema._fields_to_deferred_field()

    source = """
    foo
    bar
    """

    tokens = tokens_from_file(source)

    try:
        validate_with_positions(
            token=parse(tokens=tokens), validator=MySchema
        )
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]

# Generated at 2022-06-24 11:00:19.518987
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer, Object
    from typesystem.tokenize.tokens import Token

    class personSchema(Schema):
        name = Integer()

    token = Token(
        value={
            "name": "123",
            "age": "123",
        },
        start=(1, 0),
        end=(1, 3),
    )
    try:
        validate_with_positions(token=token, validator=personSchema)
    except ValidationError as error:
        assert str(error) == "Invalid data:\n\n1.1-2   Expected an integer."

# Generated at 2022-06-24 11:00:26.048374
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import Integer, Object
    from typesystem.tokenize import tokenize, tokens_to_tree
    from typesystem.tokenize.tokens import Token

    class TestSchema(Schema):
        foo = Integer(required=True)
        bar = Integer(required=True)

    class TestObject(Object):
        properties = {"bar": Integer(required=True)}

    # Test an error present at the top level of the tree,
    tokens = tokenize("{}", TestSchema)
    tokens_tree = tokens_to_tree(tokens)
    errors = TestSchema.validate(tokens_tree.value)
    assert len(errors) == 2

    with pytest.raises(ValidationError) as exc_info:
        validate_

# Generated at 2022-06-24 11:00:38.124218
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from ..tokenize.fixtures import invalid_tokens, valid_tokens

    # schemas to test
    class Shape:
        name: str

    class Root:
        shapes: typing.List[Shape]

    # Make this a Field rather than a Schema so validators.validate works
    class RootField(Field):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, schema_cls=Root, **kwargs)

    # Test validators
    for token in valid_tokens:
        validate_with_positions(token=token, validator=RootField())

    for token in invalid_tokens:
        with pytest.raises(ValidationError):
            validate_with_positions(token=token, validator=RootField())

# Generated at 2022-06-24 11:00:49.212929
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.types import String, Integer

    schema = Schema([String(), Integer(required=False)])
    token = Token.from_python(data=["alice", "bob", 42])

    with pytest.raises(ValidationError) as error:
        result = validate_with_positions(token=token, validator=schema)
    assert len(error.value.messages) == 2
    assert error.value.message() == (
        "Expected a list of 2 items, but got 3 items. The field 1 is required."
    )

    # Test the order of the error messages.
    messages = error.value.messages
    assert messages[0].code == messages[1].code == "required"
    assert messages[0].index[-1] == 1

# Generated at 2022-06-24 11:00:54.442025
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import LiteralToken
    from typesystem.fields import String

    token = LiteralToken(
        start=0,
        end=5,
        value=5,
        lookup=None,
        sub_tokens=[],
        location=(),
    )

    try:
        validate_with_positions(token=token, validator=String())
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="This field must be a string.",
                code="invalid_type",
                index=(),
                start_position=0,
                end_position=5,
            )
        ]
        return
    raise AssertionError("Should have raised a ValidationError")

# Generated at 2022-06-24 11:01:02.574130
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import types, fields
    from typesystem.tokenize import tokenize, tokens

    token = tokenize(
        text="""{
    "name": "Eric",
    "age": "",
    "email": "test@test.com"
}""",
    )

    class BasicUser(Schema):
        name = fields.StringField(max_length=100)
        age = types.IntegerField(allow_null=True)
        email = fields.StringField()

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=BasicUser)

    [email_message, age_message, name_message] = error.value.messages()

    assert email_message.start_position.line == 5

# Generated at 2022-06-24 11:01:10.887078
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import TokenizedString
    from typesystem.fields import String, Number
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    def check(*, text, expected):
        token = Token.parse(text)
        expected_message = Message(
            code=expected[0],
            index=expected[1],
            text=expected[2],
            start_position=expected[3],
            end_position=expected[4],
        )
        with pytest.raises(ValidationError) as excinfo:
            validate_with_positions(token=token, validator=String(max_length=3))
        result = excinfo.value.args[0]
        assert len(result) == 1
        assert result[0] == expected_message


# Generated at 2022-06-24 11:01:16.833038
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from collections import OrderedDict
    from typesystem.tokenize import tokens
    from typesystem.validators import String

    validator = String()
    token = tokens.Map(
        OrderedDict(
            [
                ("name", tokens.String("Alice")),
                ("age", tokens.Integer(30)),
                ("email", tokens.String("alice@example.com")),
            ]
        )
    )
    validate_with_positions(token=token, validator=validator)

# Generated at 2022-06-24 11:01:28.195197
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import Tokenizer
    from typesystem.tokenize import string_to_tokens

    tokenizer = Tokenizer(tokenize_type=string_to_tokens)
    tokens = tokenizer.tokenize('{"foo": "bar"}', "json")
    token = tokens[0].children[0]

    # without our function
    try:
        validate_with_positions(token=token, validator=Field(required=True))
    except ValidationError as error:
        messages = error.messages()
        assert messages[0].text == ("The field 'foo' is required.")
        assert messages[0].start_position is None
        assert messages[0].end_position is None

    # with our function

# Generated at 2022-06-24 11:01:38.952418
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize_string

    tokens = tokenize_string(
        """
        {
            "a": "hello",
            "b": 123,
            "c": 3.2,
            "d": true,
            "e": false,
            "f": null,
            "g": [3, 2.1],
            "h": {
                "i": "inner value",
                "j": [3.4]
            }
        }
        """
    )

    token = tokens[0]

    try:
        validate_with_positions(token=token, validator=Field(required=True))
        assert False, "should not happen"
    except ValidationError as exc:
        assert len(exc.messages()) == 1

# Generated at 2022-06-24 11:01:46.220229
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import Tokenizable
    from typesystem.tokenize.tokens import Token
    from typesystem import fields
    import attr
    import pytest

    @attr.attrs(auto_attribs=True)
    @attr.s(frozen=True)
    class Position:
        line_number: int
        char_index: int

    def make_token(
        *, value: typing.Any, start: Position, end: Position
    ) -> Tokenizable:
        return Token(
            value,
            start_position=start,
            end_position=end,
        )

    class Person(Schema):
        name = fields.String(required=True)
        age = fields.Integer(required=True)


# Generated at 2022-06-24 11:01:55.442326
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    import typer_typesystem.core
    import typesystem.tokenize
    import json
    import typing

    def test_validate_with_positions_with_error():
        json_string = """
        {"name": "A"}
        """
        token = typesystem.tokenize.loads(json_string)
        assert isinstance(token, typesystem.tokenize.tokens.DictToken)
        schema = typer_typesystem.core.TyperSchema(
            name=typesystem.String(max_length=5), age=typesystem.Integer()
        )

# Generated at 2022-06-24 11:02:01.393946
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    token = Token(value={"foo": 123}, start=None, end=None)
    error = None
    try:
        validate_with_positions(token=token, validator=String(name="foo"))
    except ValidationError as e:
        error = e
    assert error
    assert error.messages()[0].start_position
    assert error.messages()[0].start_position.line == 1
    assert error.messages()[0].start_position.char_index == 0

# Generated at 2022-06-24 11:02:11.152661
# Unit test for function validate_with_positions
def test_validate_with_positions():
    string = """{1: a, 2: b}"""
    tokens = Token(text=string).tokenize_from_text()

    def validator_schema(token):
        return {
            "1": token.get("1"),
            "2": validate_with_positions(token=token.get("2"), validator=Field(type=str)),
        }

    try:
        assert validate_with_positions(token=tokens, validator=validator_schema) == {
            "1": "a",
            "2": "b",
        }
    except ValidationError as error:
        assert "The field '1' is required" in error.message()
        assert "The field '2' is required" in error.message()


# Generated at 2022-06-24 11:02:18.935194
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.lexer import Token
    from typesystem.tokenize.streams import CharStream
    from typesystem.tokenize.tokens import KeywordToken

    from typesystem.fields import String

    field = String(title="", min_length=4, max_length=6)

    token = KeywordToken(
        value="jimbo",
        index=(),
        start=CharStream(file_path="", line=1, char_index=0),
        end=CharStream(file_path="", line=1, char_index=5),
    )

    validate_with_positions(token=token, validator=field)

# Generated at 2022-06-24 11:02:26.880850
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize import tokenize

    source = """
    key: value
    """.lstrip().replace("\n", "\\n")
    tokens = tokenize(source)

    with pytest.raises(ValidationError):
        validate_with_positions(token=tokens, validator=String(required=True))



# Generated at 2022-06-24 11:02:33.662125
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer

    from .tokenize import tokenize
    from .tokens import Field, Number

    from .types import Query

    token1 = Field("foo", value="bar")
    token2 = Field("bar", value=Field("abc", value=Number("1")))
    token3 = Field("bar", value=Field("def", value="2"))
    root_token = Field(None, value=[token1, token2, token3])

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=root_token, validator=Query)
    assert excinfo.value.messages()[0].start_position == token3.start
    assert excinfo.value.messages()[0].end_position == token3.end

    # Here is the same test

# Generated at 2022-06-24 11:02:34.305668
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-24 11:02:43.285575
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests import schemas

    token = Token(
        value={"a": 1, "b": 2},
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 1, "column": 10, "char_index": 9},
    )

# Generated at 2022-06-24 11:02:52.981668
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    class ProductSchema(Schema):
        name = Field(str, required=True)
        price = Field(str, required=True)
        available = Field(bool, required=True)

    token = Token.parse(
        b'{"name":"Chair","price":"$199.99","available":true}',
        filename="example.json",
    )
    schema = ProductSchema()

    # No exceptions thrown
    validate_with_positions(token=token, validator=schema)

    # Missing a required field
    token = Token.parse(
        b'{"name":"Chair","available":true}',
        filename="example.json",
    )

# Generated at 2022-06-24 11:02:58.333003
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokenize import tokenize

    class SampleSchema(Schema):
        name = String(required=True)

    document = '{"name": "Example"}'
    tokens = list(tokenize(document, json=True))
    value = validate_with_positions(token=tokens[0], validator=SampleSchema)
    assert value == {"name": "Example"}

# Generated at 2022-06-24 11:03:04.896221
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        value={"age": 10},
        start=Position(line_index=0, char_index=0),
        end=Position(line_index=1, char_index=0),
    )
    schema = Schema.of({"age": Field.of(type="integer", minimum=18)})
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-24 11:03:13.016050
# Unit test for function validate_with_positions
def test_validate_with_positions():
    validator = Schema({
        "user_id": Field(type="string"),
    })
    try:
        validate_with_positions(
            token=Token(
                value={},
                start=Token.Position(line_index=1, char_index=1),
                end=Token.Position(line_index=2, char_index=1),
            ),
            validator=validator,
        )
    except ValidationError as error:
        assert len(error.messages()) == 1
        assert error.messages()[0].start_position.line_index == 1
        assert error.messages()[0].start_position.char_index == 1
        assert error.messages()[0].end_position.line_index == 2
        assert error.messages()[0].end_position.char_

# Generated at 2022-06-24 11:03:19.244520
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from tests.test_tokenize import tokenize_example1

    tokens = tokenize(tokenize_example1)

    from tests.test_schemas import Employee

    try:
        validate_with_positions(token=tokens, validator=Employee)
    except ValidationError as error:
        report = error.format(tokenize_example1)
        assert report == (
            "The field 'age' is required.\n"
            "The field 'name' is required.\n"
            "The field 'department' is required."
        )
        return

    assert False, "Should return a ValidationError."

# Generated at 2022-06-24 11:03:27.850329
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Object
    from typesystem.fields import String

    class PersonSchema(Schema):
        first_name = String()
        last_name = String()

    person = Object(
        {
            "first_name": "Tom",
            "last_name": "Sawyer",
        },
        start=0,
        end=20,
    )

    assert validate_with_positions(token=person, validator=PersonSchema)

    person = Object(
        {
            "first_name": None,
            "last_name": "Sawyer",
        },
        start=0,
        end=20,
    )


# Generated at 2022-06-24 11:03:37.352800
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Schema, String

    class User(Schema):
        name = String(min_length=3)

    token = Token(value={"name": "a"}, start={"line": 0, "char_index": 0}, end={"line": 0, "char_index": 3})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=User())

    message = exc_info.value.messages()[0]
    assert message.text == "The field 'name' may not be less than 3 characters."
    assert message.index == ("name",)
    assert message.start_position == {"line": 0, "char_index": 0}
    assert message.end_position == {"line": 0, "char_index": 1}

   

# Generated at 2022-06-24 11:03:46.709648
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.errors import ValidationError
    from typesystem.fields import Text, Integer, List
    from typesystem.tokenize import tokenize

    schema = List(items=Integer())

    tokens = list(tokenize("[1, 2, a, 3, 4]"))

    try:
        validate_with_positions(token=tokens[2], validator=schema)
    except ValidationError as error:
        message = error.messages()[0]
        text = message.text
        code = message.code
        start_index = message.start_position.index
        end_index = message.end_position.index
        assert text == "string is not valid integer"
        assert code == "invalid_type"
        assert start_index == 3
        assert end_index == 4


# Generated at 2022-06-24 11:03:57.827176
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import sys
    import warnings
    import pytest

    from typesystem.exceptions import Missing
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import DictToken, RootToken

    from tests.tokenize.utils import make_field

    schema = Schema(
        make_field("name", required=True),
        make_field("age", type="integer"),
    )

    with pytest.warns(RuntimeWarning):
        warnings.warn(
            f"The tokenization step is not supported on {sys.platform!r}.", RuntimeWarning
        )

    root = RootToken(value={})
    value = validate_with_positions(token=root, validator=schema)
    assert value == {
        "name": None,
        "age": None,
    }

   

# Generated at 2022-06-24 11:04:06.160121
# Unit test for function validate_with_positions
def test_validate_with_positions():
    mm = {"fields": {"id": {"type": "integer"}}}
    token = Token(
        value={
            "id": "123",
            "title": "This is a title",
            "description": "This is a description",
        },
        start=Start(line=1, character=0),
        end=End(line=1, character=1),
    )
    try:
        pu.validate_with_positions(token=token, validator=Podcast)
    except ValidationError as error:
        assert len(error.messages) == 1
        message = error.messages[0]
        assert message.end_position.line == 1
        assert message.end_position.character == 1
        assert message.start_position.line == 1
        assert message.start_position.character == 0

# Generated at 2022-06-24 11:04:16.229606
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class SimpleSchema(Schema):
        foo = Field(type="integer")

    # The 'foo' field is required.
    value = []
    token = Token(value=value, start_position=None, end_position=None)
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=SimpleSchema)
    assert len(excinfo.value.messages()) == 2
    for message in sorted(excinfo.value.messages(), key=lambda m: m.code):
        if message.code == "required":
            assert message.start_position == (1, 0)
            assert message.end_position == (1, 0)
            assert message.text == "The field 'foo' is required."
        else:
            assert message.start_position

# Generated at 2022-06-24 11:04:22.248892
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.array import Array

    from typesystem.integer import Integer
    from typesystem.schemas import Object
    from typesystem.string import String

    from pydantic import BaseModel as _BaseModel
    from pydantic.fields import FieldInfo
    from pydantic.main import BaseModel as PydanticModel

    class ExtendedModel(Object):
        _locations = ["body"]
        _pydantic_model_: PydanticModel

        def _pydantic_model_class_(self):
            new_dict = {}
            for name, field in self.fields.items():
                if isinstance(field, Array):
                    value = typing.Sequence[field.item_type._pydantic_model_]
                elif isinstance(field, Object):
                    value = field._pydantic_model_
               

# Generated at 2022-06-24 11:04:29.794066
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from test_pages import page
    page.start_position.char_index = 0
    field = Field(type="string", min_length=1)
    try:
        validate_with_positions(token=page, validator=field)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'title' is required."
        assert error.messages()[0].start_position.char_index == 0
        assert error.messages()[0].end_position.char_index == 9
    else:
        assert False, "Should raise a ValidationError"

# Generated at 2022-06-24 11:04:40.325356
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    import typesystem.tokenize
    import typesystem.tokenize.tokens
    import typesystem.tokenize.util

    class Other(typesystem.Schema):
        id: str
        name: str

    class Schema(typesystem.Schema):
        name: str
        other: Other

    schema = Schema()

    source = """
        name: Foo
        other:
            name: Bar
    """

    token = typesystem.tokenize.tokenize(source)
    with pytest.raises(typesystem.ValidationError) as exc:
        schema.validate(token)

    messages = exc.value.messages()
    message = messages[0]
    assert message.text == "The field name is required."
    assert message.index == ("other", "id")
    assert message

# Generated at 2022-06-24 11:04:47.825023
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class Movie(Schema):
        name = Field(type="string")

    class MovieCollection(Schema):
        movies = Field(type="array", items={
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "rating": {"type": "integer"},
            }
        })

    class EmptyMovieCollection(Schema):
        movies = Field(type="array", items=Movie)

    # Basic usage

# Generated at 2022-06-24 11:04:56.579560
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class InnerSignature(Schema):
        param_required = fields.String("param-required")
        param_optional = fields.String("param-optional", required=False)

    class Signature(Schema):
        param_required = fields.String("param-required")
        param_optional = fields.String("param-optional", required=False)
        param_nested = InnerSignature("param-nested")

    class Parameters(Schema):
        param_required = fields.String("param-required")
        param_optional = fields.String("param-optional", required=False)
        param_nested = InnerSignature("param-nested")

    token = _make_token()

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=Signature)



# Generated at 2022-06-24 11:05:05.270482
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem

    from typesystem.tokenize import tokenize

    class MySchema(typesystem.Schema):
        x = typesystem.Integer()
        y = typesystem.Integer()

    tokens = list(tokenize(json.dumps({"x": "abc", "y": "def"})))

    try:
        validate_with_positions(
            token=tokens[0], validator=MySchema(partial=True)
        )
    except ValidationError as error:
        for message in error.messages():
            print(message.start_position)
            print(message.end_position)


test_validate_with_positions()

# Generated at 2022-06-24 11:05:06.086153
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-24 11:05:14.407406
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # pylint: disable=redefined-outer-name
    import json
    import typesystem
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.exceptions import ValidationError

    schema = typesystem.Schema(
        properties={
            "name": typesystem.String(required=True),
            "age": typesystem.Integer(min_value=18),
        }
    )
    tokenized_string = tokenize(
        """{
          "name": "Jeffrey",

          "age": 15
        }"""
    )
    errors = []
    try:
        schema.validate(tokenized_string)
    except ValidationError as error:
        errors.extend(error.messages())

    # A message with a position
    error = errors[0]
    assert error.text

# Generated at 2022-06-24 11:05:23.358496
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Boolean
    from typesystem.schemas import TokenSchema
    from typesystem.tokenize import lex, Position

    class TestSchema(TokenSchema):
        foo = Boolean()

    class TestSchemaWithOptional(TokenSchema):
        foo = Boolean(required=False)

    tokens = lex("(foo true)")

    class Wrapper:
        def lookup(self, index):
            if index == 0:
                return tokens[1]
            else:
                return tokens[0]

    token = Wrapper()
    token.value = tokens
    try:
        validate_with_positions(token=token, validator=TestSchema)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'foo' is required."

# Generated at 2022-06-24 11:05:33.650692
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize as tokenize_yaml, TokenType

    token = tokenize_yaml(b"foo: bar")[0]
    assert token.type == TokenType.Mapping

    class TestSchema(Schema):
        foo = Field(str)

    # positional error
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=TestSchema)

    assert exc_info.value.messages()[0].start_position.char_index == 5
    assert exc_info.value.messages()[0].end_position.char_index == 5

    # non-positional error
    with pytest.raises(ValidationError) as exc_info:
        TestSchema().validate({"foo": None})

# Generated at 2022-06-24 11:05:42.057778
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from json import loads
    from typesystem.schemas import Object
    from typesystem.fields import String
    import pytest

    class MySchema(Schema):
        foo = String(required=True)
        bar = String(required=True)

    token = Token.from_json(loads("""
{
    "type": "object",
    "fields": {
        "foo": {
            "type": "string",
            "value": null
        },
        "bar": {
            "type": "string",
            "value": "baz"
        }
    }
}
    """))
    schema = MySchema()

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-24 11:05:48.057596
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema

    class MySchema(Schema):
        message: str = Field(required=True)

    token = Token.from_dict(
        type="document", value={"message": "Hello world!"}, _parents=[]
    )
    print(validate_with_positions(token=token, validator=MySchema))

# Generated at 2022-06-24 11:05:59.139450
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from textwrap import dedent

    token = tokenize(
        dedent(
            """\
        {
            "name": "Homer Simpson",
            "address": {
                "street": "742 Evergreen Terrace",
                "city": "Springfield",
                "state": "Oregon"
            }
        }
    """
        )
    )
    person_schema = Schema.of(
        {"name": Field(type="string"), "address": Field(type=Schema.of({"state": Field(type="string")}))}
    )
    try:
        validate_with_positions(token=token, validator=person_schema)
    except ValidationError as error:
        message = error.messages()[0]

# Generated at 2022-06-24 11:06:09.655202
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schematics import (
        Boolean,
        Integer,
        List,
        String,
    )
    from typesystem.tokenize.tokens import BooleanToken, IntegerToken, ListToken
    from typesystem.tokenize.tokens import StringToken

    field = List(type=String())
    value = "not-a-list"
    token = ListToken(value=value)
    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=token, validator=field)
    message = error_info.value.messages[0].text
    assert message == f"Expected an array, but got {type(value)!r}."

    field = List(type=Boolean())
    value = [True, False, False, False, True]
   

# Generated at 2022-06-24 11:06:18.096403
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        validate_with_positions(
            token=Token(
                value={"foo": "bar", "nested": {"bar": [1, 2]}},
                start=Position(
                    line=1,
                    column=1,
                    char_index=0,
                    line_text="l1\nl2\n",
                ),
                end=Position(
                    line=2,
                    column=1,
                    char_index=6,
                    line_text="l2\n",
                ),
            ),
            validator=Schema(
                {"foo": Field(required=True), "bar": Field(required=True)}
            ),
        )
    except ValidationError as error:
        message = error.messages()[0]

# Generated at 2022-06-24 11:06:28.036660
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from collections import namedtuple
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.messages import Message
    from typesystem.tokenize.positional import Position

    class Document(Token):
        @property
        def title(self) -> Token:
            return self.lookup("title")

        @property
        def author(self) -> Token:
            return self.lookup("author")

        @property
        def chapters(self) -> "Document":
            return self.lookup("chapters")

        @property
        def publisher(self) -> Token:
            return self.lookup("publisher")


# Generated at 2022-06-24 11:06:35.884574
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="number", required=False)

    doc = """
    {
        "name": "Foo Bar",
        "age": "27"
    }
    """

    try:
        validate_with_positions(
            token=tokenize(doc), validator=Person
        )
    except ValidationError as error:
        assert error.messages == [
            Message(
                text="Value should be an instance of float.",
                code="type",
                index=("age",),
                start_position=Position(char_index=28, line_index=3),
                end_position=Position(char_index=30, line_index=3),
            )
        ]




# Generated at 2022-06-24 11:06:42.847336
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import ValidationError
    from typesystem.string import String

    import yaml

    validator = String()

    # Valid
    token = Token("example", (1, 0), (1, 7))
    validate_with_positions(token=token, validator=validator)

    # Invalid
    with pytest.raises(ValidationError):
        token = Token("", (1, 0), (1, 0))
        validate_with_positions(token=token, validator=validator)

# Generated at 2022-06-24 11:06:51.084967
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema, Enum
    from typesystem.fields import Field, String, Integer, DateTime, Boolean, Float
    from datetime import datetime
    import pytest
    class User(Schema):
        first_name = String(min_length=1)
        last_name = String()
        age = Integer()
        date_joined = DateTime()
        is_active = Boolean()
        balance = Float()
        user_type = Enum(["admin", "normal"])


# Generated at 2022-06-24 11:06:58.366952
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse
    from typesystem.tokenize.tokens import Token
    from typesystem.types import Integer, String

    schema = Schema(fields={"name": String(), "age": Integer()})

    token = parse("{name: 'John', age: 30}")
    assert validate_with_positions(validator=schema, token=token) == {
        "name": "John",
        "age": 30,
    }

    token = parse("{name: 'John'}")
    try:
        validate_with_positions(validator=schema, token=token)
    except ValidationError as error:
        messages = list(error.messages())

    assert messages[0].text == "The field age is required."
    assert messages[0].code == "required"


# Generated at 2022-06-24 11:07:07.351066
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesys import Token, Tokenizer
    from typesystem.tokenize.tokens import BaseToken
    from typesystem import Array, Boolean, Integer, Number, Object, String

    tokenizer = Tokenizer()
    tokenizer.accept(Array, "[{values}]")
    tokenizer.accept(Boolean, "true")
    tokenizer.accept(Boolean, "false")
    tokenizer.accept(Integer, "-?{digits}{fraction}?")
    tokenizer.accept(Number, "{integer}(e[+-]?{digits})?")
    tokenizer.accept(Object, "{{properties}}")
    tokenizer.accept(String, "\"{body}\"")

    schema = Object(
        properties={"numbers": Array(items=Number(), min_items=2)}
    )


# Generated at 2022-06-24 11:07:15.704940
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token("test")
    try:
        validate_with_positions(token=token, validator=Field(required=True))
    except ValidationError as error:
        first_message = error.messages()[0]
        assert first_message.text == "The field 'test' is required."
        assert first_message.code == "required"
        assert first_message.start_position.char_index == 0
        assert first_message.end_position.char_index == 4
    else:
        raise AssertionError("ValidationError not raised.")


# Generated at 2022-06-24 11:07:22.644537
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    token = Token(
        value={
            "first_name": "",
            "last_name": "",
            "address": {
                "street": "",
                "town": {
                    "name": "",
                    "zip_code": "",
                },
                "country": {
                    "name": "",
                    "code": "",
                },
            }
        },
        start=Index(line_index=0, char_index=0),
        end=Index(line_index=0, char_index=0),
    )


# Generated at 2022-06-24 11:07:29.040156
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer, List
    from typesystem.tokenize.sliding_window import SlidingWindow

    class Person(Schema):
        first_name = String(required=True)
        last_name = String(required=True)
        age = Integer()
        addresses = List(items=String())

    class AddressBook(Schema):
        name = String()
        person = Person()

    addresses_book, _ = SlidingWindow.from_string(
        r"""
    {
      "name": "paul",
      "person": {
        "first_name": "paul",
        "last_name": "hildebrandt",
        "age": "33"
      },
      "addresses": ["home", "work"]
    }"""
    )
    token = addresses_book.look

# Generated at 2022-06-24 11:07:35.859743
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.lexemes import Lexeme

    class Person(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer")

    source = Lexeme(value={"first_name": "Peter", "last_name": "Parker"}, start=0, end=32)
    
    try:
        validate_with_positions(token=source, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position.line == 0
        assert error.messages()[0].start_position.column == 9
        assert error.messages()[0].end_position.column == 19
        
        assert error.messages()[1].start_position.line == 2

# Generated at 2022-06-24 11:07:40.325093
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import SourcePosition

    class Thing(Field):
        pass

    source_tokens = [
        Token(value="a", start=SourcePosition(line=1, char_index=0), end=None)
    ]
    token = Token(
        value={},
        start=SourcePosition(line=1, char_index=0),
        end=None,
        lookuper=lambda index, _: source_tokens[0],
    )

    with pytest.raises(ValidationError) as error:
        Thing(required=True).validate(token.value)

    assert error.value.messages()[0].start_position == SourcePosition(
        line=1, char_index=0
    )

# Generated at 2022-06-24 11:07:47.104096
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.byte_stream import ByteStream
    from typesystem.tokenize.tokens import Object
    from typesystem.tokenize.tokens import String
    from typesystem.tokenize.tokens import ValidationError

    class MySchema(Schema):
        key = String(required=True)

    source = "{" "  key: 'foo'" "}".encode("utf-8")

    # Test a fully valid source
    byte_stream = ByteStream(source)
    token = Object(byte_stream.range(position=0))
    result = validate_with_positions(token=token, validator=MySchema)
    assert result == {"key": "foo"}

    # Test a source with a required field missing
    source = "{}".encode("utf-8")
    byte_stream

# Generated at 2022-06-24 11:07:56.906265
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import dataclasses
    from typesystem.fields import String, Integer
    from typesystem.schemas import Structure
    from typesystem.tokenize.parser import parse

    class MyStructure(Structure):
        a = Integer()
        b = String()

    @dataclasses.dataclass
    class MyToken(Token):
        myattribute: int

    token = MyToken(
        {
            "a": 0,
            "b": 1,
            "c": 2,
        },
        myattribute=1,
        meta={},
    )

    validate_with_positions(token=token, validator=MyStructure)

    del MyStructure.fields['b']
    del MyStructure.fields['c']


# Generated at 2022-06-24 11:08:01.566688
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem.schemas import Schema

    s = Schema(
        {
            "a": Field(type="number"),
            "b": Field(type="number", max_value=5, required=False),
            "c": Field(type="string", max_length=3),
        }
    )
    token = Token(
        value={
            "a": 5,
            "c": "d",
        },
        start_position=Token.Position(
            start_index=0,
            char_index=0,
            line_index=0,
            line=None,
        ),
    )
    assert validate_with_positions(token=token, validator=s) == {
        "a": 5,
        "c": "d",
    }


# Generated at 2022-06-24 11:08:06.800917
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.lexer import lex
    from typesystem.tokenize.parse import parse

    token = lex("foo")
    token = parse(token)
    assert validate_with_positions(token=token, validator=Field(name="foo")) == "foo"

    token = lex("foo")
    token = parse(token)[0]
    assert validate_with_positions(token=token, validator=Field(name="bar")) == "foo"

# Generated at 2022-06-24 11:08:16.373452
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object
    from typesystem.fields import String

    class User(Object):
        name = String(max_length=16)

    token = Token(value={"name": ""})
    try:
        validate_with_positions(token=token, validator=User)
    except ValidationError as error:
        message, = error.messages()
        assert message.start_position.line == 1
        assert message.start_position.column == 9
        assert message.start_position.char_index == 8
        assert message.end_position.line == 1
        assert message.end_position.column == 9
        assert message.end_position.char_index == 8



# Generated at 2022-06-24 11:08:27.810378
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # NOQA
    from typesystem.tokenize.tokens import Object, Pair

    schema = Schema(fields={"name": Field(required=True)})

    token = Object([Pair(key="name", value="Foo")])

    validate_with_positions(token=token, validator=schema)

    token = Object([])

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)

    assert len(excinfo.value.messages()) == 1
    message = excinfo.value.messages()[0]
    assert message.text == "The field 'name' is required."
    assert message.code == "required"
    assert message.index == ("name",)

# Generated at 2022-06-24 11:08:35.819710
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Integer

    token = Token.build({"name": "Fred", "age": 100})

    class Person(Schema):
        name = String()
        age = Integer()

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert False

    token = Token.build({"name2": "Fred", "age": 100})

    try:
        validate_with_positions(token=token, validator=Person)
        assert False
    except ValidationError as error:
        assert str(error) == '"name" is a required field'

    token = Token.build({"name2": "Fred", "age": 100})

# Generated at 2022-06-24 11:08:47.704835
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from pydantic import BaseModel

    class Model(BaseModel):
        name: str

        class Config:
            validate_assignment = True

    error = ""
    try:
        validate_with_positions(
            token=Token(
                {
                    "name": {"first": "john", "last": "doe"},
                    "age": None,
                },
                start=(1, 0, 0),
                end=(1, 34, 0),
            ),
            validator=Model,
        )
    except ValidationError as exc:
        error = str(exc)
    assert error == "ValidationError: model - age is required (<unknown>): age is required (<unknown>)"



# Generated at 2022-06-24 11:08:55.888966
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, Tokens
    from typesystem import fields
    from typesystem import errors

    class ExampleField(Field):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.valid_values = [1, 2]

        def validate(self, value):
            if value not in self.valid_values:
                raise errors.ValidationError(
                    f"{value!r} is not a valid value; must be one of {self.valid_values!r}."
                )
            return value

    class ExampleSchema(Schema):
        example_field = ExampleField()
        required_field = fields.String(required=True)

    # ExampleSchema
    field = ExampleField()

# Generated at 2022-06-24 11:09:03.573653
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.json import parse_json
    from typesystem.tokenize.text import text_from_file

    text = text_from_file("tests/fixtures/record.json")
    token = parse_json(text)
    try:
        validate_with_positions(token=token, validator=Record)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'id' is required."
        assert message.start_position.line == 13
        assert message.start_position.char_index == 17
        assert message.end_position.line == 13
        assert message.end_position.char_index == 19



# Generated at 2022-06-24 11:09:10.873888
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, String
    from typesystem.tokenize.tokens import UniversalDict

    class Person(Schema):
        id = Integer(minimum=1)
        name = String()

    tree = UniversalDict()
    tree.data = {"id": "foo"}

    try:
        validate_with_positions(
            token=tree, validator=Person
        )
    except ValidationError as error:
        assert error.messages[0].start_position.line == 1
        assert error.messages[0].start_position.char_index == 4


__all__ = ("validate_with_positions",)

# Generated at 2022-06-24 11:09:21.551471
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import parse_token_stream
    from typesystem.tokenize.token_types import String  # noqa

    schema = Schema(fields={"id": String()})
    token = parse_token_stream({"id": "hello"})
    assert validate_with_positions(token=token, validator=schema) == {"id": "hello"}

    schema = Schema(fields={"id": String()})
    token = parse_token_stream({})
    with raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-24 11:09:26.126805
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class NameSchema(Schema):
        first_name = Field(type="string", min_length=1)
        last_name = Field(type="string", min_length=1)

        @property
        def full_name(self):
            return self.first_name + " " + self.last_name

    def mk_token(text: str, start: int = 0, end: int = None) -> Token:
        return Token(
            value=text,
            start={
                "line": 0,
                "column": start,
                "char_index": start},
            end={
                "line": 0,
                "column": end or len(text) - 1,
                "char_index": end or len(text) - 1},
        )

    message = None

# Generated at 2022-06-24 11:09:34.853543
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from pygments.token import Token as PygmentsToken
    from typesystem.tokenize.lexers import PythonLexer

    code = """
        foo = 1
        foo = 2
    """
    lexer = PythonLexer()
    tokens = lexer.get_tokens(code)
    tokens = [t for t in tokens if t[0] != PygmentsToken.Text]

    # Test multiple errors
    value = validate_with_positions(token=tokens[4], validator=Field(type=str))
    assert value == "2"

    # Test error in nested list
    with pytest.raises(ValidationError):
        validate_with_positions(
            token=tokens[7], validator=Field(type=typing.List[str])
        )

    # Test error bubbling up through

# Generated at 2022-06-24 11:09:40.372474
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import textwrap
    from typesystem.schemas import Array, Integer, Schema
    from typesystem.tokenize import lex
    from typesystem.tokenize.lexer import Lexer

    schema = Array(items=Integer(minimum=-5))

    input_ = "[1, 2, 3, 4, 5, 6, 7]"
    tokens = lex(input_=input_, lexer_cls=Lexer)
    value = tokens[0].value
    try:
        schema.validate(value)
        raise AssertionError("should have raised validation error.")
    except ValidationError as error:
        messages = [str(message) for message in error.messages()]

# Generated at 2022-06-24 11:09:50.619927
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import os.path
    import yaml

    filename = os.path.join(os.path.dirname(__file__), "data", "webhook.yaml")
    tokens = list(Token.iter_parse(filename, parser="yaml"))
    webhook_schema = tokens[0].lookup("components", "schemas", "webhook")
    message_schema = tokens[0].lookup("message")

    # Validate message schema
    schema = webhook_schema.lookup("properties", "message")
    validate_with_positions(token=message_schema, validator=schema.validator)

    # Validate message schema with error
    message_schema.value.pop(0)
