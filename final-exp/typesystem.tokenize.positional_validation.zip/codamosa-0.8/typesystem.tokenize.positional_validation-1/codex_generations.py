

# Generated at 2022-06-12 16:01:24.416997
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .parser import parse
    from .fields import Number, String
    from .schemas import Object

    class Foobar(Object):
        foo = Number(required=True)
        bar = String()

    string = """
    {
        "foo": "not a number",
        "bar": "bar is fine",
    }
    """
    token = parse(string)

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=Foobar)

    assert len(error.value.messages) == 2

    message = error.value.messages[0]
    assert message.text == "The field 'foo' is required."
    assert message.code == "required"
    assert message.index == ("foo",)

# Generated at 2022-06-12 16:01:35.068092
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token, TokenKind
    from typesystem.tokenize.positions import Position

    required = String(required=True)
    optional = String(required=False)
    schema = Schema({"required": required, "optional": optional})

    token = Token(
        kind=TokenKind.OBJECT,
        value={},
        start=Position(line_index=0, char_index=0),
        end=Position(line_index=2, char_index=0),
    )

# Generated at 2022-06-12 16:01:44.035725
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import fields
    from typesystem.tokenize.tokens import CharToken
    from typesystem.tokenize.compilers import compile_token

    field = fields.String(max_length=2)
    validator = compile_token(field)
    assert validate_with_positions(token=CharToken("X", 0, 1), validator=validator) == "X"

    with pytest.raises(ValidationError):
        validate_with_positions(
            token=CharToken("XXX", 0, 3), validator=validator
        )

# Generated at 2022-06-12 16:01:53.386425
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(
        {
            "name": {"type": str},
            "age": {"type": int},
            "linked_accounts": {
                "type": [
                    {
                        "network": {"type": str, "enum": ['facebook', 'twitter']},
                        "usernames": {"type": str},
                    }
                ]
            },
        }
    )
    token = Token.parse(
        {
            "name": "John Doe",
            "age": 12,
            "linked_accounts": [
                {"network": "facebook", "usernames": "john_doe"},
                {"network": "twitter", "usernames": "john_doe"},
                {"network": "facebook", "usernames": [1, 2]},
            ],
        }
    )

# Generated at 2022-06-12 16:02:03.631601
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class TestSchema(Schema):
        x = Field()
        y = Field()

    test_input = """{"x": "hello", "y": "world"}"""
    tokens = list(Token.parse_dict(test_input))
    assert tokens == [
        Token("{", tokens=[]),
        Token("x", tokens=[
            Token("hello", tokens=[])
        ]),
        Token("y", tokens=[
            Token("world", tokens=[])]),
        Token("}", tokens=[])
    ]
    validated = validate_with_positions(validator=TestSchema, token=tokens[0])
    assert validated == {"x": "hello", "y": "world"}

    class TestSchema2(Schema):
        x = Field()


# Generated at 2022-06-12 16:02:14.887241
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer
    from tests.utils import samples

    schema = Schema({"first_name": String(), "last_name": String()})
    validator = schema.field("last_name")
    token = Token(value="foo", index=1)
    assert "foo" == validate_with_positions(validator=validator, token=token)

    samples_schema = Schema({"samples": validator})
    samples_token = Token(
        value=samples.Samples(),
        index=0,
        children={"samples": samples.Samples().tokens()},
    )
    assert samples.Samples().mapping == validate_with_positions(
        token=samples_token, validator=samples_schema
    )

    person_schema = Sche

# Generated at 2022-06-12 16:02:19.969741
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.validators import String
    from typesystem.tokenize import tokenize

    schema = {
        "name": String(),
    }

    value = {"age": 25}

    tokens = tokenize(value, schema=schema)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens, validator=schema)
    assert isinstance(exc_info.value.messages[0], Message)
    assert exc_info.value.messages[0].end_position.char_index > 0

# Generated at 2022-06-12 16:02:29.045369
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.lexer import tokenize
    from typesystem.tokenize.tokens import ObjectStart
    from typing import Type, TypeVar
    from typesystem.base import Message

    # Create our schema
    class Beast(Schema):
        name = Field(type=str)

    def validate_beast(value: object) -> Type[Beast]:
        return validate_with_positions(token=value, validator=Beast)

    # Populate our schema
    text = '{"name": "unicorn"}'
    tokens = tokenize(text)
    assert len(tokens) == 1
    token = tokens[0]
    assert isinstance(token, ObjectStart)

    # Validate
    validated = validate_beast(token)
    assert validated.data == {"name": "unicorn"}

    # Create

# Generated at 2022-06-12 16:02:38.066260
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.positional import Position, positions_to_text
    from typesystem.tokenize import tokenize_text
    from tests.positional_test_data import (
        json_sample,
        sample_schema_class,
        sample_validation_errors,
    )
    
    schema = sample_schema_class()
    try:
        validate_with_positions(
            token=tokenize_text(json_sample().decode()),
            validator=schema,
        )
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 5
        assert positions_to_text(messages) == sample_validation_errors()

# Generated at 2022-06-12 16:02:44.843084
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest

    from typesystem.fields import String
    from typesystem.tokenize.elements import Word
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position

    class Root(Schema):
        name = String()

    token = Token(
        {
            "text": "hello",
            "position": Position(line=1, column=2, char_index=1),
            "elements": [Word("hello")],
        }
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Root)

    message = exc_info.value.messages()[0]
    assert message.code == "required"

# Generated at 2022-06-12 16:02:58.224971
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    schema = Schema(fields={"a": {"type": "string"}, "b": {"type": "string"}})

    text = '{"a": "a", "b": 1}'
    tokens = list(tokenize(text=text))
    token = tokens[2]

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=schema)

    messages = error.value.messages
    assert len(messages) == 1
    message = messages[0]

    assert message.code == "invalid_type"
    assert message.text == "The value is not a string."
    assert message.start_position.line == 1
    assert message.start_position.char_index == 10

# Generated at 2022-06-12 16:03:09.110006
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import DictToken
    from typesystem.tokenize.tokens import ListToken
    from typesystem.tokenize.tokens import StringToken

    from tests.data import NoDictField, PersonSchema

    errors = []
    try:
        validate_with_positions(
            token=DictToken(
                [
                    ("first", StringToken("John")),
                    ("last", StringToken("Doe")),
                    ("number", StringToken("John", start=(1, 10), end=(1, 10))),
                ],
                start=(0, 0),
                end=(1, 20),
            ),
            validator=NoDictField(),
        )
    except ValidationError as error:
        errors = error.messages()

    assert len(errors) == 1
   

# Generated at 2022-06-12 16:03:19.352831
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, String

    class SimpleSchema(Schema):
        name = String(min_length=1, max_length=10)
        age = Integer(minimum=0, maximum=100)

    from typesystem.tokenize.parser import parse

    token = parse("""{
  "name": "christian",
  "age": 37
}""")

    validator = SimpleSchema()
    validate_with_positions(token=token, validator=validator)

    token = parse("""{
  "age": 37
}""")

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=validator)
    error_message = exc_info.value.messages()
    assert len(error_message) == 1


# Generated at 2022-06-12 16:03:30.077093
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Token, Tokenizer
    from typesystem.tokenize.tokens import TokenType

    class Example(Schema):
        required_field = Field(validators=["required"])

    tokenizer = Tokenizer()

# Generated at 2022-06-12 16:03:39.439382
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class PersonSchema(Schema):
        name = Field(str)
        age = Field(int)
        friends = Field(array_of=Field(str))

    with pytest.raises(ValidationError) as _context:
        validate_with_positions(
            token={"name": "Jane Doe", "age": "23", "friends": ["Bob", "Sue"]},
            validator=PersonSchema,
        )

    messages = _context.value.messages()
    assert len(messages) == 1

    message = messages[0]
    assert message.start_position.line == 1
    assert message.start_position.char_index == 2
    assert message.end_position.line == 1
    assert message.end_position.char_index == 4

# Generated at 2022-06-12 16:03:44.756322
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parse import parse
    from typesystem.schemas import Schema, Object, String

    class TestSchema(Schema):
        name = String()

    schema = TestSchema()
    token = parse("{}")
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        message = error.messages[0]
        assert message.start_position.line_index == 1  # type: ignore
        assert message.start_position.char_index == 1  # type: ignore
        assert message.start_position.line_text == "{}"  # type: ignore
        assert message.end_position.line_index == 1  # type: ignore
        assert message.end_position.char_index == 2  # type: ignore

# Generated at 2022-06-12 16:03:54.751024
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import make_token
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError

    class AddressSchema(Schema):
        street = String()

    token = make_token(
        {
            "street": "Elm Street",
            "zip": "90210",
        }
    )
    try:
        validate_with_positions(token=token, validator=AddressSchema())
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'zip' is not allowed.",
                code="invalid",
                index=["zip"],
                start_position=token.end,
                end_position=token.end,
            )
        ]
   

# Generated at 2022-06-12 16:04:02.700650
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize_string
    from typesystem.tokenize.tokens import Token

    schema = Schema()
    schema["name"] = str

    token = Token(
        value={"name": 2},
        lookup=lambda x: Token(
            value={"name": 2},
            lookup=lambda x: Token(
                value={"name": 2},
                lookup=lambda x: Token(
                    value={"name": 2}, lookup=lambda x: Token(value=2)
                ),
            ),
        ),
    )


# Generated at 2022-06-12 16:04:12.241768
# Unit test for function validate_with_positions

# Generated at 2022-06-12 16:04:22.879497
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Schema
    from typesystem.tokenize.tokens import String
    from typesystem.fields import String as StringField
    from typesystem.exceptions import ValidationError
    from typesystem.tokenize.position import TextPosition


    class Person(Schema):
        name = StringField(max_length=10)
        age = IntegerField(minimum=0)

    class Company(Schema):
        name = StringField(max_length=10)
        employees = ArrayField(items=Person)

    token = String(
        value={"name": "Pieter", "age": -1},
        start=TextPosition(line=1, column=1, char_index=0),
        end=TextPosition(line=1, column=13, char_index=12),
    )

# Generated at 2022-06-12 16:04:37.791938
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import parse
    from typesystem.tokenize.tokens import Token

    token = parse(
        """
        {
            "id": 23,
            "title": "Hello world"
        }
    """
    )

    class Book(Schema):
        id = Field(type=int, required=True)
        title = Field(required=True)

    try:
        validate_with_positions(token=token, validator=Book)
    except ValidationError as error:
        messages = error.messages()
        assert messages[0].text == 'Found unexpected field. The field "title" is required.'
        assert messages[0].code == "unexpected"

# Generated at 2022-06-12 16:04:43.421605
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import List, String
    from typesystem.tokenize import tokenize

    string_schema = String(min_length=1)
    list_schema = List(items=string_schema)
    token = tokenize([])[0]
    messages = list(list_schema.validate_messages(token.value))
    assert messages[0].start_position == token.start

# Generated at 2022-06-12 16:04:50.853268
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Array, Boolean, Integer, DateTime

    class Post(Schema):
        title = String(max_length=10)
        body = String(required=False)
        tags = Array[String]
        published = Boolean()

    class BlogSchema(Schema):
        posts = Array[Post]
        num_pages = Integer()

    class BlogPostSchema(Schema):
        timestamp = DateTime()
        blog = BlogSchema()

    from typesystem.tokenize import tokenize
    from typesystem.tokenize import lexical_analysis as la


# Generated at 2022-06-12 16:05:02.058698
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Dict, String

    # Make a field with a required key
    field = Dict(name="fields", properties={"name": String(required=True)})

    # Nothing provided -> error with message
    try:
        validate_with_positions(
            token=Token(start=(0, 0), end=(0, 0), value={}), validator=field
        )
        assert False
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.index == ["name"]
        assert message.text == "The field 'name' is required."
        assert message.start_position == (0, 0)
        assert message.end_position == (0, 0)

    # Optional key not provided -> no error
    value

# Generated at 2022-06-12 16:05:13.095986
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typing
    import pytest
    from typesystem import fields
    from typesystem.tokenize.tokenizer import StringTokenizer

    class Person(Schema):
        name = fields.String(required=True)
        age = fields.Integer(min=0)

    tokenizer = StringTokenizer(Person)
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=tokenizer.tokenize(b""), validator=Person)

    assert exc.value.messages() == [
        Message(
            text="The field 'name' is required.",
            code="required",
            index=("name",),
            start_position=tokenizer.tokenize(b"").start,
            end_position=tokenizer.tokenize(b"").end,
        )
    ]


# Generated at 2022-06-12 16:05:24.057193
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import JSONTokenizer

    tokenizer = JSONTokenizer()
    source = """
    {
        "foo": "bar",
        "baz": [
            "foo",
            "bar",
            "baz"
        ],
        "qux": null
    }
    """
    token = tokenizer.tokenize(source)
    foo = token.get("foo")
    baz = token.get("baz")
    qux = token.get("qux")

    class ExampleSchema(Schema):
        foo = Field(type=str)
        baz = Field(type=str, required=True)
        qux = Field(type=str, required=True)

    validate_with_positions(token=foo, validator=ExampleSchema)

# Generated at 2022-06-12 16:05:29.393644
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema

    from .tokenize import tokenize

    class Person(Schema):
        name = Field(required=True)
        age = Field(type="integer")

    value = {"name": "jane", "age": "20"}
    token = tokenize("person", value)
    Person.validate(value)

    validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-12 16:05:35.277615
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import Token, Tokenizer

    schema = Schema(fields={"name": Field(required=True)})
    tokenizer = Tokenizer(schema=schema)

    data = {"name": "Dave"}
    token = tokenizer.tokenize(data)
    token
    assert validate_with_positions(token=token, validator=schema) == data

    data = {}
    token = tokenizer.tokenize(data)
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-12 16:05:44.025625
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Field
    from typesystem.tokenize.parser import parse
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.types import String

    class mySchema(Schema):
        field1 = String(required=True)

    s = tokenize("{'field1': 'Hello'}")
    tokens = parse(s)
    x = validate_with_positions(token=tokens, validator=mySchema)  # Test 1

    s = tokenize("{'field1': 123}")
    tokens = parse(s)
    try:
        x = validate_with_positions(token=tokens, validator=mySchema)
    except ValidationError as err:
        assert len(err.messages()) == 1  # Test 2


# Generated at 2022-06-12 16:05:54.283473
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    class PersonSchema(Schema):
        name = String(max_length=5)

    token = Token(
        value={"name": "Monty"},
        start=Position(line_index=1, char_index=0, line_number=1),
        end=Position(line_index=14, char_index=14, line_number=1),
    )

    try:
        PersonSchema().validate(token.value)
        assert False  # we should never get here
    except ValidationError as error:
        message = str(error)
        assert message == "name is too long"


# Generated at 2022-06-12 16:06:06.307322
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    source = """{"foo": 123}"""
    from typesystem.tokenize.positions import Position
    from typesystem.tokenize.peektoken import peektoken

    token = peektoken(source, Position(line=1, char_index=0))
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Field(type="integer"))
    assert (
        str(exc_info.value)
        == "Invalid value 123.\n"
        "  1  | {\"foo\": 123}"
        "\n      ^^^^^^^^^"
    )

# Generated at 2022-06-12 16:06:11.872500
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem

    source = json.dumps({"foo": "bar"})
    tokens = typesystem.tokenize.json.tokens(source)

    schema = typesystem.Schema({"foo": typesystem.String(max_length=3)},)
    error = validate_with_positions(token=tokens, validator=schema)

    [message] = error.messages()
    assert message.index == ["foo"]
    assert message.code == "max_length"



# Generated at 2022-06-12 16:06:20.292747
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Person(Schema):
        name = String()

    data = [
        {},
        {"name": "jane", "age": 32},
        {"name": "jane"},
        {"age": 32},
        {"name": "", "age": 32},
    ]
    for item in data:
        try:
            validate_with_positions(
                validator=Person, token=Person.parse(value=item)
            )
        except ValidationError as error:
            raise ValueError(error)

# Generated at 2022-06-12 16:06:32.314273
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema({"name": Field()})
    parser = schema.get_parser()
    data = {"name": "Paul"}
    token = parser.parse(data)

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert len(error.messages()) == 0
    else:
        assert False, "ValidationError was not raised."

    data = {}
    token = parser.parse(data)

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.start_position.line_index == 0
        assert message.start_position.char_

# Generated at 2022-06-12 16:06:43.508852
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import string_to_tokens

    from .fields import Integer
    from .schemas import Object

    class ObjectField(Field):
        pass

    class Author(Object):
        name = ObjectField(token_name="string")
        age = Integer()


# Generated at 2022-06-12 16:06:49.438066
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class PersonSchema(Schema):
        name = Field(str)
        age = Field(int)

    # Failure
    token = Token.build({"name": None, "age": 17})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(validator=PersonSchema, token=token)

    error = exc_info.value
    assert error.messages()[0].text == "The field 'name' is required."
    assert error.messages()[0].start_position == (1, 10)
    assert error.messages()[0].end_position == (1, 11)

    # Success
    token = Token.build({"name": "John", "age": 17})

# Generated at 2022-06-12 16:06:58.143291
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    tok = Token(value = {'a': 3},
                start = (10, 20),
                end = (10, 20),
                lookup = lambda pth : Token.from_value(pth, {}))

    assert validate_with_positions(validator = Field(required = True), token = tok) == {'a': 3}

    try:
        validate_with_positions(validator = Field(), token = tok)

    except ValidationError as e:
        errors = e.messages
        assert len(errors) == 2

        assert errors[0].start_position == (10, 20)
        assert errors[0].end_position == (10, 20)
        assert errors[0].text == "The field 'a' is required."

        assert errors

# Generated at 2022-06-12 16:07:10.332654
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class ChildSchema(Schema):
        required_position = Field(required=True)
        optional_position = Field(required=False)

    class ParentSchema(Schema):
        required_position = Field(required=True)
        optional_position = Field(required=False)
        child = ChildSchema()

    class ChildSchema(Schema):
        required = Field(required=True)
        optional = Field(required=False)

    class ParentSchema(Schema):
        required = Field(required=True)
        optional = Field(required=False)
        child = ChildSchema()

    from typesystem.tokenize.json import decode


# Generated at 2022-06-12 16:07:16.497593
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import (
        Integer,
        Object,
        String,
        array_field,
        fields,
        object_field
    )
    from typesystem.tokenize.tokenize import tokenize

    type_schema = Object(
        fields={
            "count": Integer,
            "items": array_field(
                fields={
                    "text": String,
                    "value": String,
                }
            ),
        }
    )

    token = tokenize(
        '{"count": "abc", "items": [{"text": "foo"},{"value": 123}]}'
    )

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(validator=type_schema, token=token)

    errors = excinfo.value.messages()


# Generated at 2022-06-12 16:07:21.680626
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String
    from typesystem.tokenize import tokenize

    token = tokenize("foo")
    String(required=True).validate(tokens=token)
    with pytest.raises(ValidationError) as err:
        String(required=True).validate(tokens=token[:0])
    assert err.value.messages()[0].start_position.char_index == -1

# Generated at 2022-06-12 16:07:38.744288
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.schema import TokenSchema
    from typesystem.error import Message as MessageType

    schema = TokenSchema(name="root", code="root", fields=[{"name": "foo"}])

    from typesystem.tokenize.tokens import Token

    class TokenMock(Token):
        """A mock token with predefined start & end attributes."""

        def __init__(self, start, end):
            self.start = start
            self.end = end

    token = TokenMock(start=(1, 0), end=(1, 2))

    # no error
    validate_with_positions(token=token, validator=schema)

    # error

# Generated at 2022-06-12 16:07:47.408338
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import datetime

    from typesystem.tokenize.types import TokenType

    from .utils import setup_json

    setup_json()

    from .conftest import example_schema

    from typing import List

    from typesystem.base import ValidationError

    import json


# Generated at 2022-06-12 16:07:56.088280
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import ObjectToken
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        first_name = String()
        last_name = String(required=True)
        age = Integer()

    token = ObjectToken(
        {
            "first_name": "Joe",
            "last_name": "Bob",
            "age": 42,
            "nick_name": "jj",
            "other_names": ["j2"],
            "age2": 43,
        }
    )


# Generated at 2022-06-12 16:07:56.755776
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-12 16:08:07.287471
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(str, required=True)

    token = Token(
        start=Position(line_index=2, char_index=2, line_text="name: ~str: Person"),
        end=Position(line_index=2, char_index=2, line_text="name: ~str: Person"),
        value={},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-12 16:08:14.623089
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema, String
    schema = Schema(
        fields={
            "name": String(max_length=5),
            "age": String(max_length=10)
        }
    )
    # positive test
    object_data = validate_with_positions(
        token=tokenize(data=schema.dumps(data={"name": "foo", "age": "123"})),
        validator=schema,
    )
    assert object_data == {"name": "foo", "age": "123"}
    # negative test

# Generated at 2022-06-12 16:08:17.367420
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json

    import pytest

    from typesystem.tokenize import tokenize as tokenizer

    token = tokenizer(json.loads("""{"a": "1"}"""))
    schem

# Generated at 2022-06-12 16:08:28.052811
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    from typesystem.schemas import Structure

    class Pet(Structure):
        fields = {
            "species": "text",
            "name": {"type": "text", "required": False},
        }

    class Person(Structure):
        fields = {"name": "text", "pets": [Pet]}

    token_stream = tokenize(
        data={"name": "John", "pets": ["sparrow", "cat", {"species": "dog"}]},
        schema=Person,
    )
    token = next(token_stream)
    with pytest.raises(ValidationError) as error_context:
        validate_with_positions(token=token, validator=Person)
    ex = error_context.value

# Generated at 2022-06-12 16:08:38.695837
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from nth.typesystem.tokenize.tokenizer import tokenize_string
    from nth.typesystem.tokenize.tokens import Token

    token = tokenize_string("""{
        "example": {
            "one": 1,
            "two": "two",
            "three": "three",
            "four": "four"
        }
    }""")
    example = {
        "one": 1,
        "two": "two",
        "three": "three",
        "four": "four",
    }

    example_token = token.lookup("example")
    schema = {
        "one": int,
        "two": str,
        "three": str,
        "four": str,
    }

# Generated at 2022-06-12 16:08:46.990300
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(fields={"foo": Field(required=True)})
    token = Token(value={"foo": None}, start=(1, 2), end=(2, 3))
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=schema)
    message = error.value.messages()[0]
    assert message.text == "The field 'foo' is required."
    assert message.start_position == token.start
    assert message.end_position == token.end

# Generated at 2022-06-12 16:09:06.272279
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Given:
    class A(Schema):
        a = Field(required=True, type="string")

    # When:
    value = A.validate({"a": "hello"})

    # Then:
    assert value == {"a": "hello"}

    # When:
    with pytest.raises(ValidationError) as exception:
        validate_with_positions(token=Token('{"a": 5}', {"a": 5}), validator=A)

    # Then:
    message = exception.value.messages[0]
    assert message.text == 'The value "5" is not valid for field "a".'
    assert message.code == "invalid"
    assert message.start_position.line == 1
    assert message.start_position.col == 7
    assert message.end_position.line

# Generated at 2022-06-12 16:09:15.178051
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Tokens
    from typesystem.validators import Length

    field = String(validators=[Length(min=1)])
    tokens = tokenize("""{"name": ""}""")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens, validator=field)

    assert len(exc_info.value.messages()) == 1
    message = exc_info.value.messages()[0]
    assert message.index == ("name",)
    assert message.start_position == tokens.lookup(("name",)).start
    assert message.end_position == tokens.lookup(("name",)).end


# Generated at 2022-06-12 16:09:23.786790
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class NameSchema(Schema):
        first = Field(type="string")
        last = Field(type="string")

    class PersonSchema(Schema):
        name = Field(type="object", schema=NameSchema)
        age = Field(type="integer")

    # Argument token:
    with pytest.raises(TypeError):
        validate_with_positions(
            token=42, validator=PersonSchema
        )  # type: ignore

    # Argument validator:
    with pytest.raises(TypeError):
        validate_with_positions(
            token=Token.from_value(42), validator=42
        )  # type: ignore

# Generated at 2022-06-12 16:09:34.914891
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Address(Schema):
        street_name = Field(type="string")
        street_number = Field(type="number")

    class User(Schema):
        name = Field(type="string")
        age = Field(type="number")
        address = Field(type=Address)

    token = Token(
        {
            "name": "John Doe",
            "age": "42",
            "address": {
                "street_number": "24",
            },
        },
        start=Position(line=1, character=1),
        end=Position(line=6, character=14),
    )


# Generated at 2022-06-12 16:09:42.614956
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # type: () -> None
    from typesystem.tokenize import tokenize

    token = tokenize({"age": "16"}, name="Person")

    field = Field(name="age", type=int)

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=field)
        assert excinfo.value.messages[0].start_position == (1, 11)
        assert excinfo.value.messages[0].end_position == (1, 16)

# Generated at 2022-06-12 16:09:49.073916
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    validator = Schema([String(), String()])
    token = Token(
        value=[Token(value="one"), Token(value="two")],
        start=TokenPosition(
            line_index=0, char_index=0, line_char_index=0, lines=[], text=''
        ),
        end=TokenPosition(
            line_index=0, char_index=0, line_char_index=0, lines=[], text=''
        ),
    )

    # Valid
    validate_with_positions(token=token, validator=validator)

    # Invalid

# Generated at 2022-06-12 16:09:56.258563
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import sys
    import typesystem

    class Person(typesystem.Schema):
        name = typesystem.String()
        age = typesystem.Integer()

    schema = Person()

    # Empty dict
    value = "{}"
    token = Token(Token.Dictionary, value, start=None, end=None)
    with pytest.raises(typesystem.ValidationError) as e:
        validate_with_positions(token=token, validator=schema)
    lines = list(filter(None, e.value.messages[0].text.split("\n")))
    assert lines[:4] == ["{", "    name = <missing>", "    age = <missing>", "}"]
    assert len(lines) == 6

    # Missing name
    value = '{"age": 42}'
    token

# Generated at 2022-06-12 16:10:05.036828
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Schema, String

    class Person(Schema):
        name = String()

    token = Token(value={"name": ""}, start=(1, 1), end=(1, 11))
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    assert exc_info.value.messages() == [Message(
        text="The field 'name' is required.",
        code="required",
        index=("name", ),
        start_position=Pos((1, 6)),
        end_position=Pos((1, 11)),
    )]



# Generated at 2022-06-12 16:10:12.421176
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_json
    from typesystem.schemas import Schema, fields
    from typesystem.exceptions import ValidationError
    from typesystem.tokenize.positions import Position

    schema = Schema({"name": fields.String()})
    json_string = '{"name": "Jane"}'
    tokens = tokenize_json(json_string)
    assert validate_with_positions(token=tokens, validator=schema) == {
        "name": "Jane"
    }

    json_string = "{}"
    tokens = tokenize_json(json_string)
    try:
        validate_with_positions(token=tokens, validator=schema)
    except ValidationError as error:
        message = error.messages[0]

# Generated at 2022-06-12 16:10:22.772362
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String

    token = String.parse("foo")
    validated = validate_with_positions(token=token, validator=String)
    assert validated == "foo"
    token = String.parse("")
    try:
        validate_with_positions(token=token, validator=String(required=True))
    except ValidationError as error:
        message = error.messages[0]
    assert message.code == "required"
    assert message.index == []
    assert message.start_position.line == 1
    assert message.start_position.column == 1
    assert message.end_position.line == 1
    assert message.end_position.column == 1

# Generated at 2022-06-12 16:10:52.387459
# Unit test for function validate_with_positions

# Generated at 2022-06-12 16:10:58.765794
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.primitives import Text
    from typesystem.tokenize.token_types import TokenType
    from typesystem.tokenize.tokens import Token

    string = "hello"
    token = Token(token_type=TokenType.Value, start={}, end={}, value=string)
    validator = Text()

    result = validate_with_positions(token=token, validator=validator)
    assert result is string


# Generated at 2022-06-12 16:11:04.885649
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer
    from typesystem.tokenize.tokens import FieldToken

    token = FieldToken(value=None, start=None, end=None, name="foo")
    try:
        validate_with_positions(token=token, validator=Integer(required=True))
        assert False
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'foo' is required."
        assert message.code == "required"
        assert message.index == ["foo"]
        assert message.start_position == token.start
        assert message.end_position == token.end



# Generated at 2022-06-12 16:11:13.045069
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.schema import Schema
    from typesystem.fields import Any, String
    import pytest

    class Position:
        def __init__(self, line: int, char_index: int) -> None:
            self.line = line
            self.char_index = char_index

    schema = Schema({"name": String()})

    def validate(value: typing.Any) -> typing.Any:
        return validate_with_positions(
            token=Token(value, start=Position(1, 0), end=Position(1, len(value))),
            validator=schema,
        )

    with pytest.raises(ValidationError) as exc_info:
        validate("")
