

# Generated at 2022-06-12 16:01:18.671957
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import BaseField, Integer
    from typesystem.schemas import Object
    from typesystem.tokenize.tokens import Token

    class MyValidator(Integer):
        pass

    validator = MyValidator(required=True)

    token = Token(
        value="12",
        start=("test.py", 2, 1),
        end=("test.py", 2, 3),
        lookup=mock.Mock(return_value=token),
    )
    value = validate_with_positions(token=token, validator=validator)
    assert value == 12

    token.value = "foo"
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=validator)
    assert exc_info.value

# Generated at 2022-06-12 16:01:24.929444
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import type_validator, types

    class MySchema(Schema):
        name = types.String()
        age = types.Integer()

    token = Token(
        {
            "name": "John",
            "age": "fifteen",
            "city": "New York",
        },
        start=Token.Location(line=1, col=1, char_index=0),
        end=Token.Location(line=1, col=28, char_index=27),
    )
    validator = type_validator(MySchema)

    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=validator)

    error = pytest.raises(ValidationError, validate_with_positions, token=token, validator=validator)

# Generated at 2022-06-12 16:01:35.507458
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class QuestionSchema(Schema):
        q = Field(required=True, max_length=50)
        a = Field(required=True)

    try:
        validate_with_positions(token=Token({"q": "", "a": "answer"}, (1, 2)), validator=QuestionSchema)
    except ValidationError as error:
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 5
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.char_index == 5
        assert error.messages()[1].start_position.line == 1
        assert error.messages()[1].start_position.char_index == 10


# Generated at 2022-06-12 16:01:46.536249
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    from typesystem.tokenize.parser import parse_object, parse_token

    schema = typesystem.Schema(properties={"a": typesystem.Integer(required=True)})
    token = parse_object(parse_token("{}"), {"a": 1})

    value = validate_with_positions(token=token, validator=schema)

    assert value == {"a": 1}

    schema = typesystem.Schema(properties={"a": typesystem.Integer(required=True)})
    token = parse_object(parse_token("{}"), {})

    try:
        value = validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        [message] = error.messages()
        assert message.code == "required"
        assert message

# Generated at 2022-06-12 16:01:50.501178
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test that if a message is raised from a field, the field has position information
    from typesystem.structures import Dict
    from typesystem.types import String
    from typesystem.tokenize.tokens import DictToken


# Generated at 2022-06-12 16:01:56.746135
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.validation.test_tokenize import tokenize
    from typesystem import String

    schema = String(max_length=15)

    token = tokenize("You can't handle the truth!", "test.txt")
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.column == 16
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.column == 20

# Generated at 2022-06-12 16:02:08.639251
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.schemas import Array, Dictionary

    token = Token.load(
        value={"foo": ["bar"]},
        schema={
            "foo": [
                {
                    "bar": Integer(required=True),
                    "baz": Integer(),
                }
            ]
        },
    )
    validator = Dictionary(
        properties={
            "foo": Array(items=Dictionary(properties={"bar": Integer(required=True)}))
        }
    )

    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as exc:
        assert len(exc.messages()) == 1
        message = exc.messages()[0]
        assert message.index == ("foo", 0, "baz")
       

# Generated at 2022-06-12 16:02:16.620878
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        value={"name": "", "height": "", "age": ""},
        start={"line": 0, "column": 0, "char_index": 0},
        end={"line": 0, "column": 0, "char_index": 0},
    )
    validator = Field(required=True, trim_whitespace=True, pattern="\d*")
    validate_with_positions(token=token, validator=validator)
    token = Token(
        value={"name": "", "height": "", "age": ""},
        start={"line": 1, "column": 0, "char_index": 0},
        end={"line": 1, "column": 0, "char_index": 0},
    )

# Generated at 2022-06-12 16:02:24.985226
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """
    Unit test for function validate_with_positions.
    """

    import json
    import typesystem.tokenize.lexers

    from typesystem.fields import String, Integer

    from typesystem.tokenize.lexers import Lexer

    from pathlib import Path

    from pydantic import BaseModel

    class User(BaseModel):
        name: str
        age: int

    json_data = Path("tests/examples/json_example.json").read_text(encoding="utf-8")
    json_schema = {
        "name": {"types": ["string"]},
        "age": {"types": ["integer"]},
    }

    json_expectation = {
        "name": "John Doe",
        "age": 39,
    }

    items = []

# Generated at 2022-06-12 16:02:35.852554
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from collections import namedtuple
    from typesystem import String
    import typesystem
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.position import Position
    from typesystem.tokenize.source import StringSource
    from typesystem.fields import String as StringField

    # Setup a source with a tiny JSON-like snippet
    source = StringSource(
        string=(
            '{'
            ' "name": "", '
            ' "age": "nan", '
            ' "address": {'
            '   "line_1": "", '
            '   "line_2": "abc" '
            ' } '
            '}'
        ),
        name="test.json",
    )

    # Setup tokens to match the structure of the source text

# Generated at 2022-06-12 16:02:45.468185
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema({"name": Field(required=True)})
    token = Token(
        {"name": "Dave"},
        SourcePosition(line_index=2, char_index=2),
        SourcePosition(line_index=2, char_index=10),
    )
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=schema)
    assert (
        str(error.value)
        == "validation error in line 2, character 2-10: The field 'name' is required."
    )

# Generated at 2022-06-12 16:02:55.522220
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Construct a json token
    token = Token(
        value={"foo": "bar"},
        start=Token.Position(line=1, column=2, char_index=3),
        end=Token.Position(line=4, column=5, char_index=6),
    )
    # Construct a field
    field = Field(type="string", required=True)
    # Validate the token with the field
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=field)

# Generated at 2022-06-12 16:03:00.461298
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize import tokens
    from typesystem.tokenize.tokens import parse_start_position

    start_position = parse_start_position("""
        {
            "foo": 1
        }""")
    token = tokens.Object(
        value={
            "foo": tokens.Integer(value=1, start=start_position.step(8), end=start_position.step(9))
        },
        start=start_position,
        end=start_position,
    )

    assert (
        validate_with_positions(token=token, validator=Integer(required=True))
        == 1
    )


# Generated at 2022-06-12 16:03:11.826043
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json

    from typesystem.tokenize.tokens import Token, TypesystemTokenError
    from typesystem.tokenize import tokenize
    from typesystem import Schema, fields, ErrorMessage

    json_string = '{"name": "Emerson", "email": "emerson@example.com"}'
    user_schema = Schema(properties={"name": fields.String(), "email": fields.String()})
    try:
        tokenize(json_string)
    except TypesystemTokenError as e:
        assert isinstance(e.messages[0], ErrorMessage)
        assert e.messages[0].text == "An unexpected token was found in the input."
        assert e.messages[0].index == []
        assert e.messages[0].code == "unexpected"

# Generated at 2022-06-12 16:03:20.515097
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem
    from typesystem.tokenize.tokens import JsonToken, JsonTokens

    class SimpleSchema(typesystem.Schema):
        name = typesystem.String(max_length=10)

    # Valid
    s = json.dumps({"name": "spam"})
    t = JsonTokens(s)
    for name, value in SimpleSchema.load(t):
        print(name, value)

    # Invalid
    s = json.dumps({"name": "spamspamspam"})
    t = JsonTokens(s)
    try:
        for name, value in SimpleSchema.load(t):
            print(name, value)
    except ValidationError as e:
        message = e.messages[0]
        assert message.start_

# Generated at 2022-06-12 16:03:30.638778
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema

    from tests.schema import SchemaTest

    class MySchema(SchemaTest):
        day = Field(type="integer", description="Day of the month")
        month = Field(type="string", description="Month of the year")
        year = Field(type="integer", description="Year")

    schema = MySchema()
    token = Token(
        value={
            "day": 8,
            "month": "August",
            "year": "Nineteen Eighty-Four",
        },
        start=Position(char_index=0, line_index=0),
        end=Position(char_index=30, line_index=0),
    )

    value: typing.Any = validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-12 16:03:40.210620
# Unit test for function validate_with_positions
def test_validate_with_positions():
    l1 = [1, 2, 3]
    l2 = [{"name": "foo"}]
    class MySchema(Schema):
        list_of_ints = Field(type=str)
        list_of_objs = Field(type=str)
    data = {"list_of_ints": l1, "list_of_objs": l2}
    token = Token(data, "")
    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as error:
        assert len(error.messages()) == 2
        message = error.messages()[0]
        assert message.text == "The field 0 is required."
        assert message.code == "required"
        assert message.index == ["list_of_ints", 0]
        assert message

# Generated at 2022-06-12 16:03:49.654555
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(str)

    token = Token(
        key="person",
        value={
            "name": ""
        },
        end=Position(line=1, char_index=21),
        start=Position(line=1, char_index=0),
    )
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=Person)
    assert error.value.messages[0].text == "The field 'name' is required."
    assert error.value.messages[0].start_position.char_index == 8
    assert error.value.messages[0].end_position.char_index == 9



# Generated at 2022-06-12 16:03:59.098682
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    from typesystem.schemas import Schema
    from typesystem.fields import Integer

    class IntegerSchema(Schema):
        data = Integer()

    schema = IntegerSchema()
    json_string = json.dumps({"data": "test"})

    try:
        validate_with_positions(
            token=schema.tokenize(json_string),
            validator=schema.fields["data"],
        )
    except ValidationError as error:
        message = sorted(error.messages(), key=lambda m: m.start_position.line)
        assert message[0].text == "'test' is not a valid integer"
        assert message[0].start_position.line == 1
        assert message[0].start_position.char_index == 9
        assert message[0].end_position

# Generated at 2022-06-12 16:04:09.875530
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import textwrap
    from io import StringIO
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Object

    class Token(object):
        def __init__(self, value):
            self.value = value

    class Object(object):
        def __init__(self, name, **kwargs):
            self.name = name
            for k, v in kwargs.items():
                setattr(self, k, v)

    simple_data = textwrap.dedent(
        """
    {
        "name": "foo",
        "age": "20",
        "location": "typing.Union[Field, typing.Type[Schema]]"
    }
    """
    )
    simple = Object(name=str, age=int, location=str)

# Generated at 2022-06-12 16:04:21.873267
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """ Test : function validate_with_positions """

    class SomeSchema(Schema):
        a = Field(type="integer")
        b = Field(type="integer")

    from typesystem.tokenize import tokenize_json

    token = tokenize_json('{"a": 1, "b": 2}')

    validate_with_positions(token=token, validator=SomeSchema)



# Generated at 2022-06-12 16:04:28.461769
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pathlib
    import typesystem_parse.parse

    directory = pathlib.Path(__file__).parent
    source_code = directory.joinpath("data/sample_code.py").read_text()

    tokens = typesystem_parse.parse.parse(source_code)
    module = typesystem_parse.tokenize.types.Module.from_tokens(tokens)

    try:
        module.validate()
    except ValidationError as error:
        print(error.text)


if __name__ == "__main__":
    test_validate_with_positions()

# Generated at 2022-06-12 16:04:38.839322
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_html
    from typesystem.primitives import String

    validator = String()

    source = "<html><body></body></html>"
    tokens = tokenize_html(source)

    assert tokens[1].start == Position(column=0, char_index=4, line=1)
    assert tokens[1].end == Position(column=0, char_index=6, line=1)

    # The field 'foo' is required.
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens[1], validator=validator)


# Generated at 2022-06-12 16:04:48.323623
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.field import Field
    from typesystem.types.string import String
    from typesystem.tokenize.tokens import Token

    class MySchema(Schema):
        id = String(required=True)

    schema = MySchema()

    token = Token(
        path="/user",
        value=list(
            (
                ("id", 2, (3, 4)),
                ("name", 2, (3, 4)),
                ("age", 2, (3, 4)),
                ("registered", 2, (3, 4)),
            )
        ),
    )
    try:
        schema.validate(token.value)
    except Exception as error:
        validate_with_positions(token=token, validator=schema)



# Generated at 2022-06-12 16:04:59.491373
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Text

    token = Token.from_python(
        {
            "foo": "bar",
            "baz": {
                "qux": "quux",
            },
        }
    )

    try:
        validate_with_positions(token=token, validator={"foo": Text(), "bar": Text()})
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'bar' is required.",
                index=["bar"],
                start_position=token.lookup(["bar"]).start,
                end_position=token.lookup(["bar"]).end,
            )
        ]



# Generated at 2022-06-12 16:05:05.335897
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position

    schema = Schema("Schema1", properties=[("title", String), ("author", Integer)])
    token = {
        "Schema1": {
            "title": Token("Foo Bar", start=Position(0, 0, 0), end=Position(1, 4, 5)),
            "author": Token("100", start=Position(2, 7, 6), end=Position(3, 9, 8)),
        }
    }
    output = validate_with_positions(validator=schema, token=token)

    assert output == {"title": "Foo Bar", "author": 100}

# Generated at 2022-06-12 16:05:17.134320
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from pytest import raises
    from typesystem.tokenize.parser import Lexer, parser
    from typesystem.types import String
    from typesystem.validators import MinLength

    with raises(ValidationError) as error:
        lexer = Lexer({"bar": String(validators=[MinLength(1)])})
        parsed = parser.parse("{}", lexer=lexer)
        token = parsed.tokens[0]
        validate_with_positions(token=token, validator=parsed.schema)


# Generated at 2022-06-12 16:05:27.222673
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token("", {})

    def test_field_validation(
        *, field: Field, value: typing.Any, expected: typing.Any
    ) -> None:
        assert validate_with_positions(
            token=Token(value, start=Position(line=1, char_index=0)), validator=field
        ) == expected

    def test_schema_validation(
        *, schema: typing.Type[Schema], value: typing.Any, expected: typing.Any
    ) -> None:
        assert validate_with_positions(
            token=Token(value, start=Position(line=1, char_index=0)), validator=schema
        ) == expected

    test_field_validation(field=Field(required=True), value="", expected="")

# Generated at 2022-06-12 16:05:29.757523
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer

    token = Token(start=1, end=2, value=1)

    validate_with_positions(token=token, validator=Integer())

# Generated at 2022-06-12 16:05:36.845745
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Tokenizer

    tokenizer = Tokenizer(
        {
            "type": "array",
            "items": {"type": "string"},
        }
    )
    token = tokenizer.tokenize("[1, true, null]")

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=tokenizer.schema)
    messages = exc_info.value.messages

    # Check that ValidationError message is correct
    assert str(exc_info.value) == (
        "The field '0' is required.\n"
        "The field '1' is required.\n"
        "The field '2' must be of type 'string'."
    )

    # Check that ValidationError message contains correct index


# Generated at 2022-06-12 16:06:02.093493
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.exceptions import ValidationError as TypeSystemValidationError
    from typesystem.schemas import Array

    class MySchema(Schema):
        ints = Array[int]

    # valid input
    assert validate_with_positions(
        token=Token(value="[1,1,2,3,5]", start=None, end=None), validator=MySchema
    ) == {"ints": [1, 1, 2, 3, 5]}

    # invalid input
    try:
        validate_with_positions(
            token=Token(value="[1,ab,2,3,5]", start=None, end=None), validator=MySchema
        )
    except TypeSystemValidationError as e:
        raise
    else:
        raise Exception("Expected ValidationError")

# Generated at 2022-06-12 16:06:11.225823
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schema import IntSchema
    from typesystem.tokenize import TokenizeSchema

    schema = TokenizeSchema(
        {
            "one": IntSchema(),
            "two": IntSchema(),
            "three": IntSchema(),
            "four": {
                "five": IntSchema(),
                "six": IntSchema(),
                "seven": IntSchema(),
            },
            "eight": IntSchema(),
        }
    )

    token = schema.tokenize("{one: 1, two: 'a', eight: 5}")
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        message = list(error.messages())[0]

# Generated at 2022-06-12 16:06:21.738437
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.validators import String
    from typesystem.tokenize.lexer import Lexer
    from typesystem.tokenize.parse import Parser
    from typesystem.tokenize.position import Position
    from typesystem.tokenize.tokens import (
        FieldToken,
        ListToken,
        ObjectToken,
    )

    code = """data = 1 | "hello" | { a: 1, b: 2 } | [1, 2, 3, false] | true | false"""
    lexer = Lexer(code=code)
    parser = Parser(lexer=lexer)
    token = parser.parse()
    assert isinstance(token, FieldToken)
    assert token.start == Position(char_index=0, line=0, column=0)

# Generated at 2022-06-12 16:06:32.088193
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(properties={"foo": Field(required=True)})
    token = Token(
        value={"foo": None},
        start=Token.Position(line_number=1, index=0, char_index=0),
        end=Token.Position(line_number=1, index=12, char_index=12),
    )

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert len(error.messages) == 1
        message = error.messages[0]
        assert message.start_position.char_index == 4  # type: ignore
        assert message.end_position.char_index == 8  # type: ignore

# Generated at 2022-06-12 16:06:42.897298
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Text, Integer

    from .invalid_objects import INVALID

    errors = []
    for value in INVALID:
        try:
            validate_with_positions(
                token=Token(value=value), validator=Text(max_length=10)
            )
        except ValidationError as e:
            errors.append(e)

    # one error each
    assert len(errors) == len(INVALID)

    errors = []
    for value in INVALID:
        try:
            validate_with_positions(token=Token(value=value), validator=Integer())
        except ValidationError as e:
            errors.append(e)

    # one error each
    assert len(errors) == len(INVALID)

# Generated at 2022-06-12 16:06:47.321998
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema, String

    schema = Schema(properties={"field": String(required=True)})
    text = '{"field": "value"}\n'
    tokens = list(tokenize(text))
    token = tokens[0]
    validate_with_positions(token=token, validator=schema)

    text = '{"field": ""}\n'
    tokens = list(tokenize(text))
    token = tokens[0]
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-12 16:06:57.394154
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.tokenize.positions import Position

    class Product(Schema):
        name = Field(str)
        price = Field(int)

    def assert_message(
        *, message: Message, code: str, index: typing.Tuple[str, ...], text: str,
    ):
        assert message.code == code
        assert message.index == index
        assert message.text == text


# Generated at 2022-06-12 16:07:10.204768
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.json_tokens import JSON

    json = JSON(
        value={
            "a": 1,
            "b": 2,
            "c": {"d": {"e": "hello", "f": "there"}},
            "g": {"h": {"i": "world", "j": "something"}}
        },
        start=(1, 3),
        end=(1, 3),
    )

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=json, validator=JSON)


# Generated at 2022-06-12 16:07:16.048211
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import Field

    class MyField(Field):
        error_messages = {"required": "My required message."}

    field = MyField(required=True)
    token = Token("MyField", 0, 0, value=None)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)

    message = exc_info.value.messages[0]

    assert message.start_position.line_number == 0
    assert message.start_position.char_index == 0
    assert message.end_position.line_number == 0
    assert message.end_position.char_index == 6

# Generated at 2022-06-12 16:07:21.176675
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Source
    from typesystem.tokenize.utils import tokenize

    source = Source(text="{}")
    tokens = tokenize(source)

    from typesystem.schemas import Schema

    class MySchema(Schema):
        field = "foo"

    validate_with_positions(token=tokens[0], validator=MySchema)

# Generated at 2022-06-12 16:07:57.521715
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import validator
    from typesystem.fields import String
    from typesystem.tokenize.tokens import DocumentToken, ArrayToken, ObjectToken
    from typesystem.tokenize.positions import Position
    from typesystem.tokenize.positions import PositionValue

    class CharPosition(Position):
        def __init__(self, char_index: int) -> None:
            self.char_index = char_index

    class CharPositionValue(PositionValue):
        def __init__(self, char_index: int) -> None:
            self.char_index = char_index

        @classmethod
        def start(cls) -> "CharPositionValue":
            return cls(-1)

        @classmethod
        def end(cls) -> "CharPositionValue":
            return cls(1000000)

       

# Generated at 2022-06-12 16:08:03.324947
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    from typesystem.tokenize import tokenize
    from typesystem.base import Message

    text = '{"a": "x"}'

    tokens = list(tokenize(text))
    assert len(tokens) == 1

    token = tokens[0]
    schema = {
        "type": "object",
        "properties": {
            "a": {"type": "string", "minLength": 2}
        }
    }

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError:
        pass


# Generated at 2022-06-12 16:08:12.072126
# Unit test for function validate_with_positions
def test_validate_with_positions():
    d = {"a": "data"}
    token = Token(
        value=d,
        start={"line_number": 1, "char_index": 1},
        end={"line_number": 1, "char_index": 5},
    )

    class Validator(Field):
        def __init__(self, *, required=True, **kwargs):
            super().__init__(**kwargs)
            self.required = required

        def validate(self, value: typing.Any) -> typing.Any:
            if self.required and not value:
                self.fail("required")
            return value

    field = Validator(name="a")

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)


# Generated at 2022-06-12 16:08:22.689239
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    token = tokenize('{"a": "1", "b": [1, 2, 3]}')
    try:
        validate_with_positions(
            token=token, validator=Schema({"a": int, "b": [int]}),
        )
    except ValidationError as error:
        # get the first message
        first_message = sorted(error.messages(), key=lambda m: m.start_position.char_index)[0]
        assert first_message.text == "Value 1 is not of type 'integer'."
        assert first_message.start_position.char_index == 10



# Generated at 2022-06-12 16:08:30.145832
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(str)
        age = Field(str)

    source = {"name": "foo", "age": "bar"}
    tokens = tokenize(source)
    token = tokens[0]

    # Output of validation error should contain specified token positions
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    message = exc_info.value[0]
    assert message.index == ["age"]
    assert message.start_position == token.end
    assert message.end_position == token.end

    source = {"name": "foo"}
    tokens = tokenize(source)
    token = tokens[0]

    # Output of validation error should contain start_

# Generated at 2022-06-12 16:08:35.657329
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer

    from .tokens import Tokenizer

    tokens = Tokenizer().tokenize('{"number": "5"}')
    result = validate_with_positions(
        token=tokens.lookup(["number"]), validator=Integer(required=True)
    )
    assert result == 5

# Generated at 2022-06-12 16:08:43.314714
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class TestSchema(Schema):
        name = Field(str)
        age = Field(int)

    class TestSchemaWithRequiredFields(Schema):
        name = Field(str, required=True)
        age = Field(int, required=True)

    schema = TestSchema()

    # Simple value without errors
    token = Token(value={"name": "John", "age": 40}, start=Position(0, 0, 0), end=Position(4, 0, 4))
    schema.validate(token)

    # Value that contains error
    token = Token(value={"name": "John", "age": "40"}, start=Position(0, 0, 0), end=Position(4, 0, 4))
    with pytest.raises(ValidationError):
        schema.validate(token)

    # Value

# Generated at 2022-06-12 16:08:53.985994
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from json import loads
    from typesystem.fields import Object as TObject, String

    class Root(Schema):
        id = String(format="uuid", required=True)
        name = String(max_length=100, required=True)

    class Object(Schema):
        root = Root(required=True)

    expected = TObject({"root": {"id": "a" * 36, "name": "hello"}})
    token = Token.parse(expected)
    data = validate_with_positions(token=token, validator=Object)
    assert data == expected

    expected = TObject({"root": {"id": "a" * 36, "name": "hello" * 100}})
    token = Token.parse(expected)
    with pytest.raises(ValidationError) as context:
        validate_with

# Generated at 2022-06-12 16:09:03.797809
# Unit test for function validate_with_positions
def test_validate_with_positions():
    def assert_message(message: Message, expected: str) -> None:
        assert message.text == expected

    from typesystem.tokenize import tokenize

    schema = {"fields": [{"name": "foo", "type": "string", "required": True}, "bar"]}
    token = tokenize({"foo": None, "bar": "foobar"})
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)
    assert_message(excinfo.value.messages()[0], "The field 'foo' is required.")
    assert_message(excinfo.value.messages()[1], "The field 'bar' is required.")

# Generated at 2022-06-12 16:09:13.458009
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Given
    import json
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize_json

    class Person(Schema):
        name = Field(required=True)
        address = Field()

    json_str = """{"name": "Foo", "address": null}"""
    tokens = tokenize_json(json_str)

    # When
    try:
        validate_with_positions(token=tokens, validator=Person)
    except ValidationError as error:
        # Then
        assert len(error.messages()) == 1

        message = error.messages()[0]
        lines = message.text.splitlines()
        assert len(lines) == 2
        assert lines[0] == "  {"
        assert lines[1] == "^ Expected string."

# Generated at 2022-06-12 16:10:22.724851
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import StructureSchema
    class Person(StructureSchema):
        first_name = Field(str)
        last_name = Field(str)
    person = Person()
    source = "Foo Bar"
    token = Token(source, index=0, name="Person")
    token.add_child(Token(source, index=0, name="first_name"))
    token.add_child(Token(source, index=4, name="last_name"))
    try:
        validate_with_positions(token=token, validator=person)
    except ValidationError as error:
        messages = [message.text for message in error.messages()]
        assert messages == ["The field 'last_name' is required."]

# Generated at 2022-06-12 16:10:29.986304
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize, Token
    from typesystem.native import String
    from typesystem.fields import Integer
    from typesystem.schemas import Object, Array

    schema = Object(properties={"message": String, "number": Integer})
    input = '{"message": "", "number": "foo"}'
    token = tokenize(input)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    messages = exc_info.value.messages
    assert [m.code for m in messages] == ["required", "invalid_type"]
    assert messages[0].text == f"The field {repr('message')} is required."
    assert messages[0].start_position == (2, 1)
   

# Generated at 2022-06-12 16:10:35.161968
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import ObjectToken, Token
    from typesystem.tokenize.positions import Position

    field = Field(type="integer")
    token = ObjectToken(
        start=Position(),
        end=Position(),
        name="field1",
        value=tokenize("abc"),
    )

    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == 'Must be a number, got "abc"'
        assert message.start_position == token.start
        assert message.end_position == token.end



# Generated at 2022-06-12 16:10:42.525091
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class ExampleField(Field):
        def validate(self, value):
            raise ValidationError(
                [
                    Message(
                        text="Error 1",
                        code="error-1",
                        index=["a", "b", "c"],
                    ),
                    Message(
                        text="Error 2",
                        code="error-2",
                        index=["d"],
                    ),
                ]
            )

    class ExampleSchema(Schema):
        a = ExampleField()

    token = Token.from_mapping(
        {"a": {"b": {"c": "d"}}},
        start_pos=Position(line=1, char_index=1),
        end_pos=Position(line=4, char_index=4),
    )

# Generated at 2022-06-12 16:10:53.140607
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        "key",
        value={"a": "Value A", "b": "Value B"},
        start=Position(line_index=1, char_index=1),
        end=Position(line_index=1, char_index=1),
    )
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=Schema({"c": Field(required=True)}, partial=True))
    assert error.value.messages == [Message(
        index=[],
        text="The field 'c' is required.",
        code="required",
        start_position=Position(line_index=1, char_index=1),
        end_position=Position(line_index=1, char_index=1),
    )]

# Generated at 2022-06-12 16:11:02.593438
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    import typesystem.tokenize as tokenize

    class MySchema(typesystem.Schema):
        field = typesystem.String(min_length=3)

    tokens = list(
        tokenize.tokenize_string("""
{
    "field": "fo"
}
        """)
    )
    assert len(tokens) == 2

    try:
        validate_with_positions(token=tokens[1], validator=MySchema)
    except typesystem.ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.start_position.line_number == 3
        assert message.start_position.char_index == 5
        assert message.end_position.line_number == 3

# Generated at 2022-06-12 16:11:10.265500
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json

    from typesystem.schemas import Object

    from typesystem.tokenize.schemas import JSONSchema  # type: ignore
    from typesystem.tokenize.tokens import parse_json  # type: ignore

    from .test_token import load_example

    raw_json = load_example("book.json")
    token = parse_json(raw_json)
    schema = JSONSchema.create_from_raw_schema(
        load_example("book.schema.json")
    )
    assert type(validate_with_positions(token=token, validator=schema)) is Object