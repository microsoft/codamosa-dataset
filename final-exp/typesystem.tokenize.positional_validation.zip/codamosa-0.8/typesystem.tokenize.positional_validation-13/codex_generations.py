

# Generated at 2022-06-12 16:01:18.230731
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, Object
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.position import Position
    from pytest import raises

    class Validator(Object):
        foo = Integer(required=True)

    token = Token(
        value={},
        start=Position(line_index=1, char_index=0),
        end=Position(line_index=1, char_index=5),
    )
    with raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Validator)
    assert exc_info.value.messages()[0].start_position == Position(
        line_index=1, char_index=0
    )
    assert exc_info.value.messages()[0].end_position == Position

# Generated at 2022-06-12 16:01:24.677100
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import error_handler
    from typesystem.compat import JSON

    from typesystem.tokenize.tokens import make_token_tree
    from typesystem.tokenize.positions import make_start_end_position
    from typesystem.tokenize.token_types import TokenType

    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.parser import parse


# Generated at 2022-06-12 16:01:35.325711
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    from typesystem.tokenize.tokenizer import tokenize

    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema as TypesystemSchema

    class ChildSchema(TypesystemSchema):
        name = String(required=True)
        age = Integer(required=True)

    class ParentSchema(TypesystemSchema):
        children = ChildSchema(required=True, many=True)

    raw_string = '{"children": [{"age": "10", "name": "Alice"}]}'
    tokens = tokenize(raw_string)

    with pytest.raises(ValidationError) as e_info:
        validate_with_positions(token=tokens[-1], validator=ParentSchema)

    [message] = e_info.value.messages



# Generated at 2022-06-12 16:01:44.963757
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parse import parse_source

    source = """{
       "foo": "bar",
       "baz": 3,
       "qux": [
          true,
          false
       ]
    }"""
    token = parse_source(source)

    class SimpleSchema(Schema):
        foo = Field(str)
        baz = Field(int)
        qux = Field(typing.List[bool])

    validate_with_positions(token=token, validator=SimpleSchema)

if __name__ == "__main__":
    test_validate_with_positions()

# Generated at 2022-06-12 16:01:53.842157
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .testing import (
        fields,
        schemas,
    )
    from .testing.dummy import TEST_ENUMS
    from .tokenize import parse_string
    from .tokenize.errors import TokenizationError
    from typesystem.enums import Enum
    import typesystem

    # Ensure that a message is produced to describe an error
    token = parse_string("x")
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=fields.Integer())
    assert error.value.messages()[0].text == "Value must be a valid integer."
    assert error.value.messages()[0].end_position == token.end

    # Ensure that a message is produced for a non-default value
    token = parse_string("1")
   

# Generated at 2022-06-12 16:02:04.361872
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Value
    from typesystem.integer import Integer
    from typesystem.string import String
    from typesystem.object import Object

    class User(Schema):
        id = Integer()
        username = String()

    schema = Object(
        {"users": Value([User()])},
        error_formatter=lambda message: str(message),
    )

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(
            token=tokenize(
                """
        {
            "users": [
                {
                    "username": "Alex",
                }
            ]
        }
        """
            ),
            validator=schema,
        )

# Generated at 2022-06-12 16:02:12.503862
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem.fields import Integer

    token = Token(name="a", value=1, start=0, end=0)

    try:
        validate_with_positions(token=token, validator=Integer())
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field a is required.",
                code="required",
                index=("a",),
                start_position=token.start,
                end_position=token.end,
            )
        ]
    else:
        assert False, "Validator should have failed."



# Generated at 2022-06-12 16:02:19.709867
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem import String, Object
    from typesystem.tokenize.tokens import _ObjectToken, StringToken

    class MinInt(Field):
        def validate(self, value):
            try:
                value = int(value)
                if value < 0:
                    message = Message(
                        text="Integer value must be greater than 0",
                        code="min_int",
                        index=(),
                    )
                    raise ValidationError(message)
                return value
            except ValueError:
                message = Message(
                    text="This is not an integer.",
                    code="invalid_int",
                    index=(),
                )
                raise ValidationError([message])

    class Person(Schema):
        age = MinInt()

    person: Object = {"age": "10"}

# Generated at 2022-06-12 16:02:23.027622
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    tokens = tokenize("""{
        "number": 42,
    }""")
    token = list(tokens)[0]
    schema = Schema(fields={"number": Field(type="number")})
    validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-12 16:02:34.361012
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class MySchema(Schema):
        field1 = Field(validators=[validate_with_positions])
        field2 = Field(validators=[validate_with_positions])

    token = Token(
        value={
            "field1": "foo",
            "field2": "bar",
            "field3": "baz",
        },
        start=Token(value={"field1": "foo"}, end=Token(value=None)),
        end=Token(value=None),
    )

    token.start.start = token.start.end
    token.start.end = token.end

    token.end.start = token.end
    token.end.end = token.end


# Generated at 2022-06-12 16:02:44.536979
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    token = Token(value="foo", start=(0, 0), end=(0, 3))
    assert validate_with_positions(token=token, validator=String()) == "foo"

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=String(required=True))
    assert exc.value.messages() == [
        Message(
            text='String value was expected.',
            code='invalid_type',
            index=[],
            start_position=(0, 0),
            end_position=(0, 3),
        )
    ]

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=String(min_length=5))
   

# Generated at 2022-06-12 16:02:54.804207
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class Profile(Schema):
        name = Field(type="string")

    class User(Schema):
        profile = Field(type="object", properties=Profile())

    def test_string():
        token = Token(
            {
                "type": "object",
                "start": 0,
                "end": 1,
                "value": {
                    "profile": {
                        "name": {"type": "string", "start": 2, "end": 3, "value": "Bob"}
                    }
                },
            }
        )

        data = validate_with_positions(token=token, validator=User())

        assert data == {"profile": {"name": "Bob"}}


# Generated at 2022-06-12 16:03:02.734580
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token

    raw_json = """{
        "integer": 123,
        "string": "foo",
        "number": 456.78,
        "dict": {"foo": "bar"},
        "list": ["a", "b"]
    }"""

    field_schema = {
        "integer": Field(type="integer"),
        "string": Field(type="string"),
        "number": Field(type="number"),
        "dict": Field(type="object"),
        "list": Field(type="array"),
    }
    field = Field(type="object", properties=field_schema)

    token = tokenize(raw_json)

    with pytest.raises(ValidationError) as error:
        validate_with_

# Generated at 2022-06-12 16:03:11.606838
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize
    from typesystem.types import String

    schema_class = Schema({"name": String()})
    token = tokenize("{}")[0]
    try:
        validate_with_positions(token=token, validator=schema_class)
    except ValidationError as error:
        assert isinstance(error.messages()[0], Message)
        assert error.messages()[0].start_position == token.start
        assert error.messages()[0].end_position == token.end

# Generated at 2022-06-12 16:03:18.741038
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, String  # noqa
    from typesystem.tokenize.json import load

    schema = {"name": String(required=True), "age": Integer()}
    validator = Schema.of(schema)
    token = load({"age": 42})

    validate_with_positions(token=token, validator=validator)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=validator)

    message = exc_info.value.messages[0]
    assert message.text == "The field 'name' is required."
    assert message.code == "required"
    assert message.index == ["name"]

# Generated at 2022-06-12 16:03:26.417862
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    token = Token(value="Hello, world!", start=[1, 1], end=[1, 14])

    with raises(ValidationError) as error:
        validate_with_positions(
            token=token, validator=String(max_length=5, min_length=5)
        )

    assert error.value.format_text() == """\
    Validation error:

    1:1: The field value must be between 5 and 5 characters long.
    """



# Generated at 2022-06-12 16:03:34.609672
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from sys import version_info
    from io import StringIO

    from typesystem.tokenize.lexers import lex
    from typesystem.tokenize.parsers import parse
    from typesystem.tokenize.errors import ParseError
    from typesystem.field_serializers import deserialize

    field = Field(
        serializer=deserialize,
        deserializer=deserialize,
        validators=[
            lambda value: isinstance(value, int),
            lambda value: value > 10,
        ],
    )

    source = """\
    [
        1,
        "a",
        {
            "foo": "bar"
        }
    ]
    """

    stream = StringIO(source)
    tokens = lex(stream)
    tokens = parse(tokens)


# Generated at 2022-06-12 16:03:42.629710
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    class TokenWithPositions(Token):
        def __init__(self, text, position=None, index=None, **kwargs):
            super().__init__(text, **kwargs)
            self.start = position
            self.end = position

    class TestSchema(Schema):
        name = Field(type=int)

    token = TokenWithPositions("{}")
    token.add("name", TokenWithPositions("3", position="0:2"))

    with pytest.raises(ValueError) as excinfo:
        validate_with_positions(token=token, validator=TestSchema)

    assert str(excinfo.value) == "The field 'name' is required."



# Generated at 2022-06-12 16:03:46.557950
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Definition, Number

    definition = Definition("1")
    definition.add_field("foo", Number(), required=True)
    token = definition.tokenize("{}")
    assert token.start.char_index == 0
    assert token.end.char_index == 1
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=definition)
    assert excinfo.value.messages == [
        Message(
            code="required",
            text="The field 'foo' is required.",
            index=("root", "foo"),
            start_position=token.start,
            end_position=token.end,
        )
    ]

# Generated at 2022-06-12 16:03:51.179913
# Unit test for function validate_with_positions
def test_validate_with_positions():

    import typesystem
    from typesystem.tokenize.lexer import lex
    from typesystem.tokenize.tokens import Token, TokenType

    try:
        class Person(typesystem.Schema):
            name = typesystem.String()

        lex(None)
        validate_with_positions(
            token=Token(
                type=TokenType.DICT_FIELD, value="name", children=[Token(type=None)]
            ),
            validator=Person,
        )
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'name' is required."
        assert message.code == "required"
        assert message.index == ("name",)
        assert message.start_position.line_number == 1
        assert message.start_position.column_

# Generated at 2022-06-12 16:04:02.847063
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(token=Token("foo"), validator=Field(type="string")) == "foo"
    assert validate_with_positions(token=Token(5), validator=Field(type="integer")) == 5



# Generated at 2022-06-12 16:04:12.332837
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.json_schema import JSONSchema
    from typesystem.tokenize.tokenizer import Tokenizer

    class Post:
        a: typing.Optional[str]
        b: str

    schema = JSONSchema.from_string(
        """
        {
            "definitions": {
                "Post": {
                    "type": "object",
                    "properties": {
                        "a": {
                            "type": "string"
                        },
                        "b": {
                            "type": "string"
                        }
                    },
                    "required": ["b"],
                    "additionalProperties": false
                }
            }
        }
        """
    )
    tokenizer = Tokenizer(document='''
    {
        "b": "qux"
    }
    ''')

# Generated at 2022-06-12 16:04:22.949425
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    from typesystem.tokenize import tokenize_json
    from typesystem.schemas import Object

    class TestSchema(Schema):
        age = Field(type=int)

    class PersonSchema(Object):
        name = Field(type=str)
        age = TestSchema

    value = tokenize_json("""{"name": "Oscar", "age": "10"}""")
    try:
        PersonSchema.validate(value)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        message = messages[0]
        assert message.text == "Invalid type. Expected int but got str."

# Generated at 2022-06-12 16:04:28.815413
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import parse_string
    from typesystem.types import String

    schema = String(required=True)
    token = parse_string("hello world")

    error = None
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as e:
        error = e

    assert error is not None
    messages = list(error.messages())
    assert len(messages) == 1
    message = messages[0]
    assert message.start_position.line_index == 0
    assert message.start_position.char_index == 0
    assert message.start_position.char_length == 11
    assert message.end_position.line_index == 0
    assert message.end_position.char_index == 11
    assert message.end_position.char

# Generated at 2022-06-12 16:04:37.980577
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Tokenizer

    class Person(Schema):
        name = Field(str)

    tokenizer = Tokenizer(Person)
    token = tokenizer.tokenize('{"name": 4}')
    assert len(token.errors) == 0
    assert len(token.lookup(["name"]).errors) == 0

    # Token must be a string
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert (
        str(exc_info.value) == "There are 1 error(s).\n\n"
        "0. The field 'name' is required."
    )

# Generated at 2022-06-12 16:04:44.716735
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import types
    from typesystem.tokenize import tokenize
    
    source = '''
    # A comment
    {
      "foo": "bar",
      "baz": [1, 2, 3]
    }
    '''
    tokens = tokenize(source)
    token = next(tokens)
    assert validate_with_positions(token=token, validator=types.Dictionary) == {"foo": "bar", "baz": [1, 2, 3]}

# Generated at 2022-06-12 16:04:51.516762
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Integer

    # Arrange
    message_text = "The field 'a' is required."
    message_code = "required"
    token = Token(
        value={},
        start=(0, 0),
        end=(1, 0),
    )
    validator = Integer(required=True)

    # Act
    exception = None
    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as err:
        exception = err

    # Assert
    assert exception.messages == [
        Message(
            text=message_text,
            code=message_code,
            index=("a",),
            start_position=token.start,
            end_position=token.end,
        )
    ]

# Generated at 2022-06-12 16:05:02.511575
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize import tokenize

    # Normal operation
    token = tokenize({"a": "foo"})["a"]
    assert validate_with_positions(
        token=token, validator=String(min_length=4)
    ) == "foo"

    # Required
    token = tokenize({"a": "foo"})["a"]
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=String(required=True))
    assert len(exc_info.value.messages) == 1
    message = exc_info.value.messages[0]
    assert message.code == "required"
    assert message.text == "The field 'a' is required."
    assert message.start

# Generated at 2022-06-12 16:05:13.661334
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import pytest
    import typesystem
    import typesystem.tokenize.tokens as tokens

    class Person(Schema):
        name = typesystem.String()
        age = typesystem.Integer()
        email = typesystem.String(regex="@")

    class PersonList(Schema):
        people = typesystem.List(Person)

    text = """
    [
        {
            "name": "John",
            "email": "john@example.com"
        },
        {
            "name": "Joe",
            "email": "joe@example.com"
        }
    ]
    """
    data = json.loads(text)

    token = tokens.Token.parse(data)

# Generated at 2022-06-12 16:05:22.426078
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from collections import OrderedDict
    from typesystem.fields import String

    class TestSchema(Schema):
        field = String(required=True)
        other_field = String()

    input = OrderedDict([("other_field", "value"), ("field", "")])
    token = Token.from_python_value(input)
    try:
        validate_with_positions(token=token, validator=TestSchema)
    except ValidationError as error:
        message = error.messages[0]
        assert message.start_position.char_index == 22
        assert message.end_position.char_index == 24

# Generated at 2022-06-12 16:05:42.595403
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    user_schema = Schema(fields={"name": String(required=True)})

    token = Token(value={"name": "Erik"}, start=0, end=0)
    validate_with_positions(token=token, validator=user_schema)

# Generated at 2022-06-12 16:05:53.503426
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    def get_start_positions(messages):
        return [m.start_position for m in messages]

    def get_end_positions(messages):
        return [m.end_position for m in messages]

    from typesystem import String
    from typesystem.main import Query

    query = Query(["x", "y"], String(min_length=1))
    document = """
        query MyQuery {
            x
            y
        }
    """
    tokens = tokenize(document)
    try:
        validate_with_positions(token=tokens, validator=query)
    except ValidationError as error:
        messages = error.messages()

# Generated at 2022-06-12 16:06:01.706959
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import fields, tokenize

    assert validate_with_positions(
        token=tokenize.tokenize_data({"example": "example"}, ""),
        validator=fields.String(max_length=5, min_length=5),
    ) == {"example": "example"}

    try:
        validate_with_positions(
            token=tokenize.tokenize_data({"example": "example"}, ""),
            validator=fields.String(max_length=4, min_length=5),
        )
    except ValidationError as error:
        message = error.messages.pop()
        assert message.text.startswith("The field 'example' must be at least 5 characters long.")
        assert message.start_line == 1
        assert message.start_char == 15
        assert message.end_line

# Generated at 2022-06-12 16:06:10.913682
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        first_name = Field(type="string")
        last_name = Field(type="string")

    token: Token = Token(
        type="object",
        value={"first_name": "Joe"},
        start=Position(char_index=7),
        end=Position(char_index=9),
    )
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=Person)
    message = exc.value.messages[0]
    assert message.text == "The field 'last_name' is required."
    assert message.code == "required"
    assert message.index == ("last_name",)
    assert message.start_position == Position(char_index=7)
    assert message.end_position == Position

# Generated at 2022-06-12 16:06:21.698914
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Document
    from typesystem.tokenize import tokenize
    from typesystem.types import Object
    from typesystem.fields import Field

    schema = Object({"name": Field(str)})

    # Test required field
    text = "{}"
    tokenized_document, offset_map = tokenize(text)
    token = Document(tokenized_document)
    errors = validate_with_positions(token=token, validator=schema)

    assert errors is None
    assert token.data == {}

    tokenized_document, offset_map = tokenize(text)
    token = Document(tokenized_document)

# Generated at 2022-06-12 16:06:32.718889
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import Tokenizer

    validator = Field(required=True, primitive_type="string")

    tokenizer = Tokenizer('{"key": "value"}')
    token = next(tokenizer)
    validate_with_positions(token=token, validator=validator)

    validator = Field(required=True, primitive_type="string")
    tokenizer = Tokenizer('{"key": null}')
    token = next(tokenizer)
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=validator)

    validator = Field(required=True, primitive_type="integer")
    tokenizer = Tokenizer('{"key": "value"}')
    token = next(tokenizer)

# Generated at 2022-06-12 16:06:43.559843
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Array
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokenizer import Tokenizer

    def test_value():
        return [1, 2]

    # class TestSchema(Schema):
    #     a = String(required=True)
    #     b = Integer(required=True)

    # tokenizer = Tokenizer(test_value)
    # token = tokenizer.tokenize()

    # for i in range(4, len(token.children[0].children)):
    #     token = token.children[0].children[i]
    #     validator = TestSchema.fields[i - 4]
    #     validate_with_positions(token=token, validator=validator)

    test_value = 1
    tokenizer = Tokenizer

# Generated at 2022-06-12 16:06:53.446997
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        validate_with_positions(
            token=Token(value=[], start=Position(line=1, char_index=0), end=Position(line=1, char_index=0)),
            validator=Schema([Field(type=int)]),
        )
    except ValidationError as error:
        error_message = error.message()
        assert error_message.text in (
            'The field "[0]" is required.',
            'The field "0" is required.',
        )
        assert error_message.code == "required"
        assert error_message.index == (0,)
        assert error_message.start_position.line == 1
        assert error_message.start_position.char_index == 0
        assert error_message.end_position.line == 1
        assert error_message.end

# Generated at 2022-06-12 16:06:59.913558
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer

    class Item(Schema):
        id = Integer(required=True, default=123)

    # Test it can catch ValidationError: required
    with pytest.raises(ValidationError):
        item = validate_with_positions(
            token=Token(value={"id": ""}, start=None, end=None), validator=Item
        )

    # Test it can report correct position info
    item = validate_with_positions(
        token=Token(value={"name": "blah"}, start=None, end=None), validator=Item
    )
    assert item["id"] == 123
    assert item._errors[0].start_position == (0, 0)
    assert item._errors[0].start_position == (0, 0)

# Generated at 2022-06-12 16:07:09.170899
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Schema

    class Person(Schema):
        name = Field()

    class User(Schema):
        person = Person()

    from typesystem.tokenize import Token

    person = Token({"name": "John"}, start_position=[1, 5], end_position=[1, 20])
    user = Token({"person": person}, start_position=[1, 0], end_position=[1, 122])

    validate_with_positions(token=person, validator=Person)
    # token = user.lookup(["person"])
    # validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-12 16:07:49.986640
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class NodeValidator(Field):
        def validate(self, value):
            self.validate_item(value, 0)
            self.validate_item(value, 1)
            self.validate_item(value, 2)
            return value

        def validate_item(self, value, index):
            if index not in value:
                text = f"The field {index!r} is required."
                raise ValidationError(text=text, code="required")
            if value[index] is None:
                text = f"The field {index!r} cannot be None."
                raise ValidationError(text=text, code="invalid")

    class RootValidator(Field):
        validator = NodeValidator()


# Generated at 2022-06-12 16:07:54.809899
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String
    from typesystem.tokenize.parse import parser

    schema = String(max_length=2)
    document = '{"$ref": "https://foo"}'
    token = parser.parse(document)
    with pytest.raises(ValidationError) as e:
        validate_with_positions(token=token, validator=schema)
    assert e.value.messages[0].start_position.byte_index == 5

# Generated at 2022-06-12 16:08:02.786035
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object, String
    from typesystem.tokenize.parser import parse

    class Person(Object):
        name = String(required=True)

    token = parse('{"name": "John"}')

    result = validate_with_positions(token=token, validator=Person)
    assert result == {"name": "John"}

    token = parse('{}')

    try:
        validate_with_positions(token=token, validator=Person)
        assert False
    except ValidationError as error:
        assert len(error.messages()) == 1

# Generated at 2022-06-12 16:08:11.649033
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.positions import Position
    from tests.field import IntegerField

    start = Position(line_number=1, char_index=1)
    end = Position(line_number=1, char_index=2)
    token = Token(value="1", start=start, end=end)

    field = IntegerField(required=True)
    validate_with_positions(token=token, validator=field)

    token.value = None
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == 'The field "value" is required.'
        assert message.code == "required"
        assert message.start_position == token.start
        assert message.end_

# Generated at 2022-06-12 16:08:12.142207
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-12 16:08:17.746017
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.positions import Position

    start = Position(char_index=0)
    end = Position(char_index=1)

    token = Token("a", start, end)
    field = Field(type="string")
    validate_with_positions(token=token, validator=field)

    token = Token(None, start, end)
    validate_with_positions(token=token, validator=field)

    start = Position(line_number=10, line_index=1, char_index=3)
    end = Position(line_number=10, line_index=1, char_index=4)
    token = Token(None, start, end)

# Generated at 2022-06-12 16:08:24.861776
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Foo(Field):
        def validate(self, value):
            if value < 5:
                raise ValidationError("Error")

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=Token(value="1", lookups=["foo"]), validator=Foo())

    assert excinfo.value.messages()[0].start_position == (1, 1)



# Generated at 2022-06-12 16:08:35.705044
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_json

    schema = Schema({"foo": Field(required=True)})
    try:
        validate_with_positions(token=tokenize_json("{}"), validator=schema)
    except ValidationError as error:
        assert error.messages()[0].code == "required"
        assert error.messages()[0].text == "The field 'foo' is required."
        assert error.messages()[0].start_position.line_number == 1
        assert error.messages()[0].start_position.column_number == 2
        assert error.messages()[0].end_position.line_number == 1
        assert error.messages()[0].end_position.column_number == 3

# Generated at 2022-06-12 16:08:43.343698
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import Tokenizer
    from typesystem import String, Integer

    class Person(Schema):
        name = String()
        age = Integer()

    tokenizer = Tokenizer()
    person = Person()

    document = tokenizer.tokenize(
        """
        name: John
        age: 40
        """
    )
    validate_with_positions(token=document, validator=person)

    document = tokenizer.tokenize(
        """
        name: John
        """
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=document, validator=person)

    [message] = exc_info.value.messages
    assert message.text == "The field 'age' is required."
    assert message.start_

# Generated at 2022-06-12 16:08:53.985319
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Token
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class AuthorSchema(Schema):
        name = String()

    class BookSchema(Schema):
        title = String()
        pages = String(required=False)
        author = AuthorSchema(required=False)

    token = Token.parse(
        {
            "title": "Clean Code",
            "author": {
                "name": "Markus"
            }
        }
    )
    validate_with_positions(
        token=token, validator=BookSchema
    )

    with pytest.raises(ValidationError):
        validate_with_positions(
            token=token, validator=BookSchema
        )


# Generated at 2022-06-12 16:10:09.182842
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize

    from . import Employee, EmployeeSchema

    token = tokenize(
        {
            "first_name": "Arthur",
            "last_name": "Dent",
            "favorite_color": "puce",
        }
    )
    assert validate_with_positions(token=token, validator=EmployeeSchema) == Employee(
        first_name="Arthur", last_name="Dent", favorite_color="puce"
    )

    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=token, validator=Employee)


# Generated at 2022-06-12 16:10:21.429561
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test that if there is a required field, we give the position of the
    # offending field token.
    schema = Schema({"name": Field(required=True)})
    data = {}
    token = Token.root(data)
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.start_position.char_index == 1
        assert message.end_position.char_index == 6
        assert message.text.startswith("The field 'name' is required.")

    # Test that if there is not a required field, we give the position of any
    # token that fails validation.

    data = {"name": "Joe"}
    token = Token.root(data)

# Generated at 2022-06-12 16:10:27.815830
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token

    class User(Schema):
        name = String(min_length=1)

    class UserToken(Token):
        schema = User

    def validate(token: Token) -> None:
        validate_with_positions(token=token, validator=User)

    token = UserToken(value={})

    with pytest.raises(ValidationError) as error:
        validate(token)

    assert error.value.messages[0].field == "name"
    assert error.value.messages[0].text == "The field 'name' is required."
    assert error.value.messages[0].code == "required"
    assert error.value.messages[0].start

# Generated at 2022-06-12 16:10:36.254419
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    token = tokenize("hello")[0]

    class IP(Field):
        scalar_type = str

    try:
        validate_with_positions(token=token, validator=IP(max_length=2))
    except ValidationError as error:
        message = error.messages()[0]
        assert message.get_info() == {
            "text": "Must have no more than 2 characters.",
            "code": "max_length",
            "index": [0, "hello"],
            "start_position": token.start,
            "end_position": token.end,
        }



# Generated at 2022-06-12 16:10:43.086896
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class Person(Schema):
        name = Field(type=str)

    token = Token(
        value={
            "name": 1234,
        }
    )

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=Person)

    message = excinfo.value.messages[0]
    assert message.index == ("name",)
    assert message.text == "Must be of type str."
    assert message.code == "type_error"
    assert message.start_position.char_index == 8
    assert message.start_position.line_index == 0
    assert message.end_position.char_index == 12
    assert message.end_position.line_index == 0



# Generated at 2022-06-12 16:10:53.734402
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(str, required=True)
        age = Field(int)

    token = Token.build_object(
        {
            "name": Token.build(value="Dave", start=(1, 9), end=(1, 13)),
            "age": Token.build("invalid", start=(2, 9), end=(2, 16)),
        }
    )

    with pytest.raises(ValidationError) as e:
        validate_with_positions(token=token, validator=Person)
    assert e.value.messages() == [
        Message(
            text="Expected an int but got str.",
            code="invalid",
            index=("age",),
            start_position=(2, 9),
            end_position=(2, 16),
        )
    ]

# Generated at 2022-06-12 16:11:01.959297
# Unit test for function validate_with_positions
def test_validate_with_positions():
    data = {
        "a": 1,
        "b": 2,
        "c": [
            {"a": 1, "b": 2},
            {"a": 3, "b": 4},
        ],
    }

    token = Token.from_native(data)

    class TestSchema(Schema):
        a = Field(type="integer")
        b = Field(type="integer")

    try:
        validate_with_positions(token=token, validator=TestSchema)
    except ValidationError as error:
        messages = error.messages()

# Generated at 2022-06-12 16:11:08.906635
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Movie(Schema):
        name = Field(type='string', required=True)
        year = Field(type='integer', required=True)

    movie = {'year': 2020}
    token = Token(value=movie)
    error = validate_with_positions(token=token, validator=Movie)
    assert error.messages()[0].start_position == (1, 1, 1)
    assert error.messages()[0].end_position == (1, 1, 1)